package com.example

import com.example.engine.Black76OptionsEngine
import com.example.engine.DigitalTwinSimulationEngine
import com.example.engine.HedgeAndRiskEngine
import com.example.engine.PricingAndBasisEngine
import com.example.model.OptionType
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun testBlack76Greeks() {
        val greeks = Black76OptionsEngine.calculateGreeks(
            forwardPrice = 80.0,
            strike = 80.0,
            timeToExpiryYears = 0.25,
            riskFreeRate = 0.05,
            volatility = 0.30,
            type = OptionType.CALL
        )
        assertTrue("Call price should be positive", greeks.price > 0.0)
        assertTrue("Delta should be between 0 and 1", greeks.delta in 0.0..1.0)
        assertTrue("Gamma should be positive", greeks.gamma > 0.0)
        assertTrue("Vega should be positive", greeks.vega > 0.0)
    }

    @Test
    fun testPricingAndBasisDeliveredPrice() {
        val basis = PricingAndBasisEngine.calculateDeliveredPrice(
            benchmarkPrice = 82.45,
            locationBasis = 2.50,
            qualityDifferential = 0.40,
            freight = 1.85,
            storageCost = 0.45,
            insuranceCost = 0.12,
            financingTax = 0.28,
            destination = "Rotterdam"
        )
        val expected = 82.45 + 2.50 + 0.40 + 1.85 + 0.45 + 0.12 + 0.28
        assertEquals(expected, basis.deliveredPrice, 0.001)
    }

    @Test
    fun testCrackSpread() {
        val crack = PricingAndBasisEngine.calculateCrack321(
            crudePricePerBbl = 80.0,
            gasolinePricePerBbl = 100.0,
            dieselPricePerBbl = 110.0
        )
        // (2*100 + 1*110 - 3*80) / 3 = (200 + 110 - 240) / 3 = 70 / 3 = 23.333
        assertEquals(70.0 / 3.0, crack.value, 0.001)
    }

    @Test
    fun testDigitalTwinSimulation() {
        val sim = DigitalTwinSimulationEngine.simulateShock(
            DigitalTwinSimulationEngine.SimulatedEvent.MAJOR_MINE_OUTAGE
        )
        assertTrue("Propagation steps should not be empty", sim.propagationSequence.isNotEmpty())
        assertTrue("Price delta should be positive on supply disruption", sim.finalPriceDeltaPct > 0)
    }
}
