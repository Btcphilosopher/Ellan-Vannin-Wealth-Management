package com.example.data

import com.example.engine.Black76OptionsEngine
import com.example.engine.HedgeAndRiskEngine
import com.example.engine.PricingAndBasisEngine
import com.example.model.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object MasterCommodityRepository {

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
    fun currentTimeStr(): String = dateFormat.format(Date())

    // 1. MASTER COMMODITIES (Taxonomy & Specifications)
    val commodities: List<CommodityMaster> = listOf(
        CommodityMaster(
            id = "EN-BRENT",
            symbol = "BRENT",
            name = "Brent Crude Oil",
            nameEn = "Brent Crude Oil",
            nameCn = "布伦特原油",
            category = Sector.ENERGY,
            subCategory = "Crude Hydrocarbons",
            physicalForm = PhysicalForm.LIQUID_HYDROCARBON,
            unit = "bbl",
            currency = "USD",
            benchmark = "ICE Brent Crude / Platts BFOET",
            exchange = "ICE Europe",
            country = "United Kingdom",
            region = "North Sea",
            qualityStandard = "Light Sweet Crude (38.3° API, 0.40% S)",
            deliveryStandard = "FOB Sullom Voe / Hound Point / Pipeline Blend",
            storageClass = "Atmospheric Floating Roof Tanks",
            specification = CommoditySpecification(
                grade = "North Sea BFOET Blend",
                apiGravity = 38.3,
                sulphurPct = 0.40,
                density = 835.0,
                qualityTolerance = "API 37.5-39.5, Sulphur max 0.45%",
                chemicalComposition = mapOf("TAN" to "< 0.11 mg KOH/g", "Reid Vapor Pressure" to "6.8 psi", "Pour Point" to "-6°C")
            )
        ),
        CommodityMaster(
            id = "EN-WTI",
            symbol = "WTI",
            name = "WTI Crude Oil (Cushing)",
            nameEn = "West Texas Intermediate",
            nameCn = "西德克萨斯中质原油",
            category = Sector.ENERGY,
            subCategory = "Crude Hydrocarbons",
            physicalForm = PhysicalForm.LIQUID_HYDROCARBON,
            unit = "bbl",
            currency = "USD",
            benchmark = "NYMEX Light Sweet Crude",
            exchange = "NYMEX / CME",
            country = "United States",
            region = "Permian / Cushing OK",
            qualityStandard = "Domestic Sweet (40.5° API, 0.24% S)",
            deliveryStandard = "FOB Enterprise / Enbridge / Plains Cushing Terminal",
            storageClass = "Cushing Terminal Hub Storage",
            specification = CommoditySpecification(
                grade = "Cushing Light Sweet Domestic",
                apiGravity = 40.5,
                sulphurPct = 0.24,
                density = 822.0,
                qualityTolerance = "API 37.0-42.0, Sulphur max 0.42%",
                chemicalComposition = mapOf("Nickel" to "< 1.0 ppm", "Vanadium" to "< 2.0 ppm", "RVP" to "7.2 psi")
            )
        ),
        CommodityMaster(
            id = "EN-HH",
            symbol = "HENRY-HUB",
            name = "Henry Hub Natural Gas",
            nameEn = "Henry Hub Natural Gas",
            nameCn = "亨利港天然气",
            category = Sector.ENERGY,
            subCategory = "Natural Gas",
            physicalForm = PhysicalForm.COMPRESSED_GAS,
            unit = "MMBtu",
            currency = "USD",
            benchmark = "NYMEX Natural Gas",
            exchange = "NYMEX",
            country = "United States",
            region = "Louisiana",
            qualityStandard = "Pipeline Quality Methane (>1,000 Btu/scf)",
            deliveryStandard = "FOB Sabine Pipe Line LLC Hub Erath LA",
            storageClass = "Depleted Salt Cavern Storage",
            specification = CommoditySpecification(
                grade = "Dry Pipeline Spec",
                energyContentBtu = 1028.0,
                purityPct = 95.8,
                qualityTolerance = "Gross heating value min 967 Btu/scf, Water max 7 lbs/MMcf",
                chemicalComposition = mapOf("CH4 (Methane)" to "95.8%", "C2H6 (Ethane)" to "2.9%", "CO2" to "< 1.5%")
            )
        ),
        CommodityMaster(
            id = "EN-TTF",
            symbol = "TTF-GAS",
            name = "Dutch TTF Natural Gas",
            nameEn = "Title Transfer Facility Gas",
            nameCn = "荷兰TTF天然气",
            category = Sector.ENERGY,
            subCategory = "Natural Gas",
            physicalForm = PhysicalForm.COMPRESSED_GAS,
            unit = "EUR/MWh",
            currency = "EUR",
            benchmark = "ICE Dutch TTF Gas",
            exchange = "ICE Endex",
            country = "Netherlands",
            region = "Northwest Europe",
            qualityStandard = "High-Calorific H-Gas Grid Specification",
            deliveryStandard = "Virtual Trading Point (VTP) Title Transfer",
            storageClass = "Underground Gas Storage (UGS Bergermeer)",
            specification = CommoditySpecification(
                grade = "Groningen High Calorific",
                energyContentBtu = 1045.0,
                qualityTolerance = "Wobbe Index 49.2-56.5 MJ/m3",
                chemicalComposition = mapOf("CH4" to "92.4%", "N2" to "< 1.8%", "H2S" to "< 5 mg/m3")
            )
        ),
        CommodityMaster(
            id = "EN-LNG",
            symbol = "LNG-ASIA",
            name = "Platts JKM LNG Asia",
            nameEn = "Japan Korea Marker LNG",
            nameCn = "日韩标杆液化天然气",
            category = Sector.ENERGY,
            subCategory = "Cryogenic Gas",
            physicalForm = PhysicalForm.CRYOGENIC_LIQUID,
            unit = "MMBtu",
            currency = "USD",
            benchmark = "Platts JKM DES Asia",
            exchange = "Platts / CME",
            country = "International",
            region = "North Asia (Japan, S. Korea, Taiwan, China)",
            qualityStandard = "Standard Lean Cryogenic LNG (-161.5°C)",
            deliveryStandard = "DES Ship-to-Shore Discharge Flange",
            storageClass = "Full Containment Cryogenic Above-ground Tanks",
            specification = CommoditySpecification(
                grade = "Commercial Cryogenic LNG",
                energyContentBtu = 1055.0,
                density = 450.0,
                qualityTolerance = "Gross heating value 1,020 - 1,140 Btu/scf",
                chemicalComposition = mapOf("Methane" to "91.2%", "Ethane" to "6.4%", "Propane" to "1.8%")
            )
        ),
        CommodityMaster(
            id = "EN-DIESEL",
            symbol = "DIESEL-ULSD",
            name = "Ultra-Low Sulfur Diesel (ULSD)",
            nameEn = "Ultra-Low Sulfur Diesel 10ppm",
            nameCn = "超低硫柴油",
            category = Sector.ENERGY,
            subCategory = "Refined Distillates",
            physicalForm = PhysicalForm.LIQUID_HYDROCARBON,
            unit = "gal",
            currency = "USD",
            benchmark = "NYMEX ULSD Heating Oil",
            exchange = "NYMEX",
            country = "United States / ARA",
            region = "US Gulf Coast / New York Harbor",
            qualityStandard = "ASTM D975 10ppm Maximum Sulfur",
            deliveryStandard = "FOB New York Harbor / Colonial Pipeline",
            storageClass = "Dedicated Refined Product Tanks",
            specification = CommoditySpecification(
                grade = "Euro 5 / EPA ULSD",
                sulphurPct = 0.001,
                density = 832.0,
                qualityTolerance = "Cetane index min 40, Flash point min 52°C",
                chemicalComposition = mapOf("Polycyclics" to "< 8%", "Water/Sediment" to "< 0.05%")
            )
        ),
        CommodityMaster(
            id = "MT-GOLD",
            symbol = "XAU",
            name = "Gold Spot 999.9",
            nameEn = "Loco London Physical Gold",
            nameCn = "现货黄金",
            category = Sector.PRECIOUS_METALS,
            subCategory = "Precious Bullion",
            physicalForm = PhysicalForm.REFINED_INGOT,
            unit = "oz t",
            currency = "USD",
            benchmark = "LBMA Gold Price AM/PM",
            exchange = "LBMA / CME COMEX",
            country = "United Kingdom",
            region = "London Loco",
            qualityStandard = "LBMA Good Delivery Bar 400 t oz (min 99.5% pure)",
            deliveryStandard = "Unallocated / Allocated Vault Transfer London",
            storageClass = "LBMA Approved High-Security Bank Vaults",
            specification = CommoditySpecification(
                grade = "99.99% Fine Gold Bar",
                purityPct = 99.99,
                density = 19320.0,
                qualityTolerance = "Purity minimum 99.50% (Good Delivery)",
                chemicalComposition = mapOf("Au" to ">= 99.99%", "Ag" to "< 0.005%", "Fe" to "< 0.001%")
            )
        ),
        CommodityMaster(
            id = "MT-SILVER",
            symbol = "XAG",
            name = "Silver Spot 999",
            nameEn = "Loco London Physical Silver",
            nameCn = "现货白银",
            category = Sector.PRECIOUS_METALS,
            subCategory = "Precious Bullion",
            physicalForm = PhysicalForm.REFINED_INGOT,
            unit = "oz t",
            currency = "USD",
            benchmark = "LBMA Silver Price",
            exchange = "LBMA / COMEX",
            country = "United Kingdom",
            region = "London Loco",
            qualityStandard = "LBMA Good Delivery 1000 oz Bar (min 99.9% pure)",
            deliveryStandard = "Allocated London Vault Receipt",
            storageClass = "LBMA Vault Storage",
            specification = CommoditySpecification(
                grade = "99.9% Fine Silver Bar",
                purityPct = 99.90,
                density = 10490.0,
                qualityTolerance = "Purity minimum 99.90%",
                chemicalComposition = mapOf("Ag" to ">= 99.90%", "Cu" to "< 0.08%")
            )
        ),
        CommodityMaster(
            id = "BM-COPPER",
            symbol = "HG-COPPER",
            name = "LME Copper Grade A Cathode",
            nameEn = "High Grade Copper Cathode",
            nameCn = "LME一级电解铜",
            category = Sector.BASE_METALS,
            subCategory = "Non-Ferrous Metals",
            physicalForm = PhysicalForm.CATHODE,
            unit = "mt",
            currency = "USD",
            benchmark = "LME Copper Official Cash / COMEX HG",
            exchange = "LME / CME",
            country = "Chile / Global",
            region = "Global Warehouse Sheds (Rotterdam / Busan)",
            qualityStandard = "BS EN 1978:1998 (Cu-CATH-1) min 99.9935% Cu",
            deliveryStandard = "LME Approved Warehouse Warrant",
            storageClass = "Bonded Heavy-Duty Metals Shed",
            specification = CommoditySpecification(
                grade = "Grade A Electrolytic Cathode",
                cuContentPct = 99.9935,
                purityPct = 99.9935,
                qualityTolerance = "Total impurities maximum 65 ppm",
                chemicalComposition = mapOf("Cu" to ">= 99.9935%", "Pb" to "< 5 ppm", "Bi" to "< 2 ppm", "O2" to "< 25 ppm")
            )
        ),
        CommodityMaster(
            id = "BM-ALUM",
            symbol = "ALUMINIUM",
            name = "Primary High Grade Aluminium",
            nameEn = "Primary Aluminium 99.7%",
            nameCn = "原铝99.7%",
            category = Sector.BASE_METALS,
            subCategory = "Light Metals",
            physicalForm = PhysicalForm.REFINED_INGOT,
            unit = "mt",
            currency = "USD",
            benchmark = "LME Aluminium Cash",
            exchange = "LME",
            country = "Global",
            region = "Global LME Warehouses",
            qualityStandard = "High Grade P1020A (min 99.7% Al)",
            deliveryStandard = "LME Warrant Ingot Bundle",
            storageClass = "Dry Metal Storage Shed",
            specification = CommoditySpecification(
                grade = "P1020A Ingot",
                purityPct = 99.70,
                qualityTolerance = "Fe max 0.20%, Si max 0.10%",
                chemicalComposition = mapOf("Al" to ">= 99.70%", "Fe" to "< 0.20%", "Si" to "< 0.10%", "Zn" to "< 0.03%")
            )
        ),
        CommodityMaster(
            id = "FR-IRON",
            symbol = "IRON-ORE-62",
            name = "Iron Ore 62% Fe Fines CFR China",
            nameEn = "Iron Ore Fines 62% Fe",
            nameCn = "铁矿石62%粉矿",
            category = Sector.FERROUS,
            subCategory = "Ferrous Raw Materials",
            physicalForm = PhysicalForm.SOLID_BULK,
            unit = "dmt",
            currency = "USD",
            benchmark = "Platts IODEX 62% Fe CFR Qingdao",
            exchange = "SGX / DCE",
            country = "Australia / Brazil",
            region = "CFR Qingdao / Caofeidian",
            qualityStandard = "Pilbara Fines Spec (Fe 62.0%, SiO2 4.0%, Al2O3 2.25%)",
            deliveryStandard = "CFR Main Ports China Discharge Flange",
            storageClass = "Port Open-Air Bulk Stockpiles",
            specification = CommoditySpecification(
                grade = "Pilbara Standard Blend Fines",
                feContentPct = 62.0,
                moisturePct = 8.0,
                qualityTolerance = "Fe penalty/premium per 1% Fe; Silica max 5.0%, Phosphorus max 0.09%",
                chemicalComposition = mapOf("Fe" to "62.0%", "SiO2" to "4.2%", "Al2O3" to "2.2%", "P" to "0.075%", "S" to "0.03%")
            )
        ),
        CommodityMaster(
            id = "CR-LITHIUM",
            symbol = "LITHIUM-LCE",
            name = "Lithium Carbonate Battery Grade",
            nameEn = "Lithium Carbonate 99.5% Min",
            nameCn = "电池级碳酸锂",
            category = Sector.BATTERY_CRITICAL,
            subCategory = "Battery Precursors",
            physicalForm = PhysicalForm.SOLID_BULK,
            unit = "mt",
            currency = "USD",
            benchmark = "Fastmarkets / GFEX Battery Grade LCE",
            exchange = "GFEX / CME",
            country = "Chile / China",
            region = "East Asia C&F",
            qualityStandard = "YS/T 582-2013 Battery Grade Li2CO3 min 99.5%",
            deliveryStandard = "Sealed Moisture-Barrier Big Bags (1,000 kg)",
            storageClass = "Temperature & Humidity Controlled Clean Warehouse",
            specification = CommoditySpecification(
                grade = "Battery Grade Powder",
                purityPct = 99.55,
                moisturePct = 0.25,
                qualityTolerance = "Magnetic impurities max 50 ppb; Na max 0.025%",
                chemicalComposition = mapOf("Li2CO3" to ">= 99.55%", "Na" to "< 0.02%", "Ca" to "< 0.01%", "Fe" to "< 0.001%")
            )
        ),
        CommodityMaster(
            id = "AG-CORN",
            symbol = "CORN",
            name = "Corn No. 2 Yellow",
            nameEn = "Yellow Dent Corn No. 2",
            nameCn = "CBOT美玉米2号",
            category = Sector.AGRICULTURE,
            subCategory = "Grains",
            physicalForm = PhysicalForm.AGRICULTURAL_GRAIN,
            unit = "bu",
            currency = "USD",
            benchmark = "CBOT Corn Futures",
            exchange = "CBOT / CME",
            country = "United States",
            region = "Illinois Waterway / US Gulf",
            qualityStandard = "USDA No. 2 Yellow Corn (min 54.0 lb/bu test weight)",
            deliveryStandard = "FOB Vessel Gulf / Barge Illinois River",
            storageClass = "Concrete Grain Elevator Silos (Aerated)",
            specification = CommoditySpecification(
                grade = "US No. 2 Yellow Corn",
                moisturePct = 14.5,
                qualityTolerance = "Max moisture 15.0%, Broken corn & foreign material max 3.0%",
                chemicalComposition = mapOf("Starch" to "72.0%", "Protein" to "8.8%", "Oil" to "4.0%")
            )
        ),
        CommodityMaster(
            id = "AG-WHEAT",
            symbol = "WHEAT-SRW",
            name = "Soft Red Winter Wheat No. 2",
            nameEn = "Chicago SRW Wheat",
            nameCn = "软红冬小麦2号",
            category = Sector.AGRICULTURE,
            subCategory = "Grains",
            physicalForm = PhysicalForm.AGRICULTURAL_GRAIN,
            unit = "bu",
            currency = "USD",
            benchmark = "CBOT Wheat Futures",
            exchange = "CBOT / CME",
            country = "United States",
            region = "Midwest / Gulf Ports",
            qualityStandard = "USDA No. 2 Soft Red Winter Wheat",
            deliveryStandard = "CBOT Registered Warehouse Receipt",
            storageClass = "Licensed Terminal Elevators",
            specification = CommoditySpecification(
                grade = "US No. 2 SRW",
                proteinPct = 10.5,
                moisturePct = 13.5,
                qualityTolerance = "Test weight min 58.0 lb/bu, Defect total max 4.0%",
                chemicalComposition = mapOf("Falling Number" to "> 300 sec", "Gluten" to "24.5%")
            )
        ),
        CommodityMaster(
            id = "AG-SOY",
            symbol = "SOYBEANS",
            name = "Soybeans No. 2 Yellow",
            nameEn = "Yellow Soybeans No. 2",
            nameCn = "大豆2号",
            category = Sector.AGRICULTURE,
            subCategory = "Oilseeds",
            physicalForm = PhysicalForm.AGRICULTURAL_GRAIN,
            unit = "bu",
            currency = "USD",
            benchmark = "CBOT Soybeans Futures",
            exchange = "CBOT / CME",
            country = "United States / Brazil",
            region = "US Gulf / Santos",
            qualityStandard = "USDA No. 2 Yellow Soybeans (min 54 lb/bu)",
            deliveryStandard = "FOB Santos / Barge CIF Gulf",
            storageClass = "Grain Silos with Temperature Monitoring",
            specification = CommoditySpecification(
                grade = "US No. 2 Yellow",
                proteinPct = 35.0,
                moisturePct = 13.0,
                qualityTolerance = "Oil content min 18.5%, Heat damage max 0.5%",
                chemicalComposition = mapOf("Protein (Dry)" to "35.2%", "Crude Fat/Oil" to "19.1%")
            )
        ),
        CommodityMaster(
            id = "SF-COFFEE",
            symbol = "COFFEE-C",
            name = "Arabica Coffee 'C' Contract",
            nameEn = "Coffee 'C' Standard Arabica",
            nameCn = "阿拉比卡咖啡",
            category = Sector.SOFT_COMMODITIES,
            subCategory = "Softs",
            physicalForm = PhysicalForm.AGRICULTURAL_GRAIN,
            unit = "lb",
            currency = "USD",
            benchmark = "ICE Coffee 'C' Futures",
            exchange = "ICE Futures US",
            country = "Brazil / Colombia",
            region = "South America",
            qualityStandard = "Green Arabica washed/natural beans in 60kg jute bags",
            deliveryStandard = "ICE Licensed Port Warehouse (Antwerp, Bremen, NYC)",
            storageClass = "Bonded Climate-Regulated Green Coffee Warehouses",
            specification = CommoditySpecification(
                grade = "Strictly Soft Fine Cup",
                moisturePct = 11.5,
                qualityTolerance = "Max defect count 15 per 300g sample; screen size 16+",
                chemicalComposition = mapOf("Caffeine" to "1.25%", "Chlorogenic Acids" to "6.5%")
            )
        )
    )

    // 2. REAL-TIME SPOT QUOTES WITH METHODOLOGY & PROVENANCE
    val spotQuotes: List<SpotPriceQuote> = listOf(
        SpotPriceQuote("EN-BRENT", "BRENT", "Brent Crude Oil", 82.45, 1.25, 1.54, "USD", "bbl", MarketBasis.FOB, "Sullom Voe", "Prompt Cargo", currentTimeStr(), DataProvenance.EXCHANGE, 82.42, 82.48, 284500, 712000, 83.10, 81.30, Sector.ENERGY),
        SpotPriceQuote("EN-WTI", "WTI", "WTI Crude Oil", 78.60, 1.10, 1.42, "USD", "bbl", MarketBasis.FOB, "Cushing OK", "Pipeline Batch", currentTimeStr(), DataProvenance.EXCHANGE, 78.58, 78.62, 342000, 895000, 79.20, 77.40, Sector.ENERGY),
        SpotPriceQuote("EN-HH", "HENRY-HUB", "Henry Hub Gas", 2.68, -0.05, -1.83, "USD", "MMBtu", MarketBasis.FOB, "Erath LA", "Pipeline Day-Ahead", currentTimeStr(), DataProvenance.EXCHANGE, 2.67, 2.69, 142000, 520000, 2.74, 2.64, Sector.ENERGY),
        SpotPriceQuote("EN-TTF", "TTF-GAS", "Dutch TTF Gas", 33.80, 0.40, 1.20, "EUR", "MWh", MarketBasis.BENCHMARK, "Netherlands VTP", "Prompt Month", currentTimeStr(), DataProvenance.LICENSED, 33.75, 33.85, 98000, 310000, 34.50, 33.10, Sector.ENERGY),
        SpotPriceQuote("EN-LNG", "LNG-ASIA", "JKM LNG Spot", 13.95, 0.45, 3.33, "USD", "MMBtu", MarketBasis.DES, "Tokyo Bay", "Prompt Ex-Ship", currentTimeStr(), DataProvenance.ASSESSED, 13.90, 14.00, 48000, 115000, 14.20, 13.40, Sector.ENERGY),
        SpotPriceQuote("EN-DIESEL", "DIESEL-ULSD", "ULSD Diesel 10ppm", 2.54, 0.04, 1.60, "USD", "gal", MarketBasis.FOB, "New York Harbor", "Barge Tender", currentTimeStr(), DataProvenance.EXCHANGE, 2.535, 2.545, 112000, 290000, 2.58, 2.49, Sector.ENERGY),
        SpotPriceQuote("MT-GOLD", "XAU", "Gold Spot 999.9", 2748.50, 18.20, 0.67, "USD", "oz t", MarketBasis.BENCHMARK, "Loco London", "T+2 Unallocated", currentTimeStr(), DataProvenance.OFFICIAL, 2748.20, 2748.80, 420000, 1180000, 2755.00, 2728.00, Sector.PRECIOUS_METALS),
        SpotPriceQuote("MT-SILVER", "XAG", "Silver Spot 999", 33.85, 0.62, 1.87, "USD", "oz t", MarketBasis.BENCHMARK, "Loco London", "T+2 Allocated", currentTimeStr(), DataProvenance.OFFICIAL, 33.82, 33.88, 280000, 620000, 34.20, 33.15, Sector.PRECIOUS_METALS),
        SpotPriceQuote("BM-COPPER", "HG-COPPER", "Copper Grade A Cathode", 9680.00, 45.00, 0.47, "USD", "mt", MarketBasis.CIF, "Rotterdam", "LME Cash Official", currentTimeStr(), DataProvenance.EXCHANGE, 9675.00, 9685.00, 185000, 490000, 9750.00, 9610.00, Sector.BASE_METALS),
        SpotPriceQuote("BM-ALUM", "ALUMINIUM", "High Grade Aluminium", 2620.00, -15.00, -0.57, "USD", "mt", MarketBasis.FOB, "LME Warehouse", "LME Warrant", currentTimeStr(), DataProvenance.EXCHANGE, 2618.00, 2622.00, 145000, 380000, 2645.00, 2605.00, Sector.BASE_METALS),
        SpotPriceQuote("FR-IRON", "IRON-ORE-62", "Iron Ore 62% Fe Fines", 108.50, 0.75, 0.70, "USD", "dmt", MarketBasis.CFR, "Qingdao Port", "Discharge Vessel", currentTimeStr(), DataProvenance.ASSESSED, 108.25, 108.75, 210000, 540000, 110.00, 107.00, Sector.FERROUS),
        SpotPriceQuote("CR-LITHIUM", "LITHIUM-LCE", "Lithium Carbonate 99.5%", 12850.00, 250.00, 1.98, "USD", "mt", MarketBasis.DAP, "East China Warehouse", "Spot Cargo", currentTimeStr(), DataProvenance.ASSESSED, 12800.00, 12900.00, 32000, 85000, 13100.00, 12500.00, Sector.BATTERY_CRITICAL),
        SpotPriceQuote("AG-CORN", "CORN", "Corn No. 2 Yellow", 4.38, 0.06, 1.39, "USD", "bu", MarketBasis.FOB, "Illinois River", "Barge Load", currentTimeStr(), DataProvenance.EXCHANGE, 4.375, 4.385, 290000, 780000, 4.44, 4.31, Sector.AGRICULTURE),
        SpotPriceQuote("AG-WHEAT", "WHEAT-SRW", "Wheat SRW No. 2", 5.82, -0.02, -0.34, "USD", "bu", MarketBasis.FOB, "US Gulf Elevator", "Vessel Cargo", currentTimeStr(), DataProvenance.EXCHANGE, 5.815, 5.825, 165000, 410000, 5.91, 5.76, Sector.AGRICULTURE),
        SpotPriceQuote("AG-SOY", "SOYBEANS", "Soybeans No. 2 Yellow", 10.45, -0.12, -1.14, "USD", "bu", MarketBasis.FOB, "Santos Terminal", "Export Cargo", currentTimeStr(), DataProvenance.EXCHANGE, 10.44, 10.46, 240000, 690000, 10.62, 10.38, Sector.AGRICULTURE),
        SpotPriceQuote("SF-COFFEE", "COFFEE-C", "Coffee Arabica 'C'", 2.82, 0.05, 1.81, "USD", "lb", MarketBasis.FOB, "Santos / Antwerp", "Warehouse Lot", currentTimeStr(), DataProvenance.EXCHANGE, 2.815, 2.825, 88000, 220000, 2.86, 2.75, Sector.SOFT_COMMODITIES)
    )

    // 3. PHYSICAL LOTS (Real inventory tracked by Lot Engine)
    val physicalLots: List<CommodityLot> = listOf(
        CommodityLot("LOT-BFOET-9921", "EN-BRENT", "BRENT", "38.4° API, 0.38% S, Low TAN", 600000.0, "bbl", "North Sea Hound Point", "BP Exploration", "2026-09-15", "WH-ROTTERDAM-VOPAK", "Vopak Europoort Tank Farm", "Glencore Energy UK", "CERT-BFOET-8841", LotStatus.IN_STORAGE),
        CommodityLot("LOT-WTI-4412", "EN-WTI", "WTI", "40.6° API, 0.22% S, Midland Sweet", 450000.0, "bbl", "Permian Basin Midland", "Pioneer Natural Resources", "2026-10-01", "WH-CUSHING-HUB", "Enterprise Cushing Hub Terminal", "Trafigura Trading LLC", "CERT-WTI-3319", LotStatus.AVAILABLE),
        CommodityLot("LOT-JKM-1094", "EN-LNG", "LNG-ASIA", "1,058 Btu/scf, 92.1% Methane Cryo", 160000.0, "m3", "Ras Laffan Terminal 4", "QatarEnergy", "2026-09-28", "WH-FUTTSU-LNG", "Futtsu Cryogenic Storage Terminal", "JERA Energy Trading", "CERT-LNG-5512", LotStatus.IN_TRANSIT),
        CommodityLot("LOT-CU-7731", "BM-COPPER", "HG-COPPER", "Grade A Cathode Cu 99.9938%", 5000.0, "mt", "Antofagasta Los Pelambres", "Antofagasta Minerals", "2026-08-20", "WH-LME-ROTTERDAM", "C. Steinweg LME Shed 4", "Freepoint Commodities", "CERT-LME-CU-9912", LotStatus.IN_STORAGE),
        CommodityLot("LOT-CU-8842", "BM-COPPER", "HG-COPPER", "Grade A Cathode Cu 99.9942%", 3500.0, "mt", "Escondida Open Pit", "BHP Billiton Chile", "2026-09-10", "WH-SHFE-SHANGHAI", "Qingdao Bonded Logistics Shed", "China Minmetals", "CERT-SHFE-CU-1120", LotStatus.CONTRACTED),
        CommodityLot("LOT-AU-3301", "MT-GOLD", "XAU", "400 oz Good Delivery Bar 99.99%", 12500.0, "oz t", "Valcambi Balerna Refinery", "Valcambi SA", "2026-07-14", "WH-LBMA-HSBC", "HSBC Vault London Loco", "J.P. Morgan Precious Bullion", "CERT-LBMA-AU-4411", LotStatus.AVAILABLE),
        CommodityLot("LOT-FE-5509", "FR-IRON", "IRON-ORE-62", "Pilbara 62.1% Fe, 4.1% SiO2 Fines", 175000.0, "wmt", "Pilbara Dampier Terminal", "Rio Tinto Iron Ore", "2026-09-22", "WH-QINGDAO-PORT", "Qingdao Qianwan Bulk Ore Wharf", "Baowu Steel Group", "CERT-SGS-FE-8812", LotStatus.IN_TRANSIT),
        CommodityLot("LOT-LCE-2290", "CR-LITHIUM", "LITHIUM-LCE", "Battery Grade Li2CO3 99.58%", 850.0, "mt", "Salar de Atacama Brine", "SQM Salar", "2026-08-30", "WH-CHANGZHOU-CLEAN", "Sinopec Specialized Chemical Store", "CATL Cell Logistics", "CERT-BV-LCE-3329", LotStatus.QUALITY_HOLD),
        CommodityLot("LOT-CRN-6610", "AG-CORN", "CORN", "US No. 2 Yellow Corn 14.2% H2O", 250000.0, "bu", "Peoria Elevator Grain", "Archer Daniels Midland", "2026-09-18", "WH-PEORIA-SILO", "ADM Peoria Central Silos", "ADM Agri-Trading", "CERT-USDA-FGIS-449", LotStatus.AVAILABLE)
    )

    // 4. GLOBAL WAREHOUSE & TERMINAL FACILITIES
    val warehouses: List<WarehouseFacility> = listOf(
        WarehouseFacility("WH-ROTTERDAM-VOPAK", "Vopak Europoort Crude Terminal", FacilityType.TERMINAL, "Europoort, Rotterdam", "Netherlands", "Royal Vopak NV", 3800000.0, 3120000.0, 380000.0, 240000.0, 0.0, "bbl", 0.014, 4200000.0, "INS-LLOYDS-VOP-8821"),
        WarehouseFacility("WH-CUSHING-HUB", "Enterprise Cushing Crude Hub", FacilityType.STORAGE_TANK, "Cushing, Oklahoma", "United States", "Enterprise Products Partners", 14500000.0, 11800000.0, 1200000.0, 950000.0, 0.0, "bbl", 0.012, 18500000.0, "INS-AIG-CUSH-9912"),
        WarehouseFacility("WH-LME-ROTTERDAM", "C. Steinweg LME Metals Terminal", FacilityType.DEPOT, "Rotterdam Port Area", "Netherlands", "C. Steinweg Handelsveem", 250000.0, 168000.0, 24000.0, 18000.0, 2500.0, "mt", 0.185, 320000.0, "INS-SWISSRE-CS-3341"),
        WarehouseFacility("WH-QINGDAO-PORT", "Qingdao Qianwan Bulk Mineral Terminal", FacilityType.PORT, "Qingdao, Shandong", "China", "Qingdao Port Group", 8500000.0, 6900000.0, 920000.0, 680000.0, 0.0, "wmt", 0.045, 12000000.0, "INS-PICC-QDG-7712"),
        WarehouseFacility("WH-PEORIA-SILO", "ADM Peoria Grain Terminal Elevator", FacilityType.SILO, "Peoria, Illinois", "United States", "Archer Daniels Midland", 12000000.0, 8400000.0, 1100000.0, 950000.0, 0.0, "bu", 0.003, 14000000.0, "INS-TRAVELERS-ADM-221"),
        WarehouseFacility("WH-LBMA-HSBC", "HSBC Loco London Bullion Vault", FacilityType.DEPOT, "London City", "United Kingdom", "HSBC Bank plc", 2500000.0, 1940000.0, 180000.0, 120000.0, 0.0, "oz t", 0.008, 3800000.0, "INS-LLOYDS-GOLD-0012")
    )

    // 5. LOGISTICS SHIPMENTS & FREIGHT
    val shipments: List<LogisticsShipment> = listOf(
        LogisticsShipment("SHP-VLCC-9941", "2.0M bbl Arab Light Crude", "BRENT", LogisticsCarrierType.TANKER_VLCC, "Front Altair (IMO 9745300)", "Ras Tanura", "Ningbo Zhoushan", "2026-10-24", 2000000.0, "bbl", 58.50, "Worldscale (WS)", 65000.0, ShipmentStatus.CHOKEPOINT_TRANSIT, "Strait of Malacca", 4250.0),
        LogisticsShipment("SHP-CAPE-1120", "175,000 mt 62% Fe Fines", "IRON-ORE-62", LogisticsCarrierType.BULK_CARRIER_CAPESIZE, "Berge Bulk Peak (IMO 9821330)", "Port Hedland", "Qingdao Port", "2026-10-22", 175000.0, "wmt", 9.45, "USD/wmt", 28000.0, ShipmentStatus.IN_TRANSIT, "Lombok Strait", 1840.0),
        LogisticsShipment("SHP-LNG-8841", "160,000 m3 Cryo LNG", "LNG-ASIA", LogisticsCarrierType.LNG_CARRIER, "Rasheeda Q-Max (IMO 9443413)", "Ras Laffan", "Tokyo Bay", "2026-10-28", 160000.0, "m3", 85000.0, "USD/day Charter", 45000.0, ShipmentStatus.IN_TRANSIT, "Indian Ocean Passage", 2100.0),
        LogisticsShipment("SHP-PIPE-3310", "450,000 bpd Light Sweet Crude", "WTI", LogisticsCarrierType.PIPELINE, "Seaway Pipeline System", "Cushing OK", "Freeport TX", "Continuous", 450000.0, "bpd", 2.85, "USD/bbl Tariff", 0.0, ShipmentStatus.IN_TRANSIT, "US Gulf Pipeline Corridor", 120.0),
        LogisticsShipment("SHP-RAIL-7721", "110-Car Unit Grain Train", "CORN", LogisticsCarrierType.RAIL_CONSIST, "BNSF Unit Train 9920", "Des Moines IA", "Tacoma WA Port", "2026-10-21", 440000.0, "bu", 1.45, "USD/bu Freight", 5500.0, ShipmentStatus.IN_TRANSIT, "Stevens Pass Corridor", 480.0)
    )

    // 6. FORWARD CURVES
    fun getForwardCurve(symbol: String): ForwardCurve {
        val spot = spotQuotes.firstOrNull { it.symbol == symbol }?.price ?: 80.0
        return when (symbol) {
            "BRENT" -> PricingAndBasisEngine.constructForwardCurve("EN-BRENT", "BRENT", spot, 0.052, 0.088) // In backwardation (convenience yield > carry)
            "WTI" -> PricingAndBasisEngine.constructForwardCurve("EN-WTI", "WTI", spot, 0.054, 0.082)     // In backwardation
            "HG-COPPER" -> PricingAndBasisEngine.constructForwardCurve("BM-COPPER", "HG-COPPER", spot, 0.048, 0.032) // In contango
            "XAU" -> PricingAndBasisEngine.constructForwardCurve("MT-GOLD", "XAU", spot, 0.045, 0.005)           // Pure financial contango
            "CORN" -> PricingAndBasisEngine.constructForwardCurve("AG-CORN", "CORN", spot, 0.065, 0.042)         // Contango
            "HENRY-HUB" -> PricingAndBasisEngine.constructForwardCurve("EN-HH", "HENRY-HUB", spot, 0.075, 0.030)  // Seasonal contango
            "LITHIUM-LCE" -> PricingAndBasisEngine.constructForwardCurve("CR-LITHIUM", "LITHIUM-LCE", spot, 0.050, 0.075) // Backwardation
            else -> PricingAndBasisEngine.constructForwardCurve("GENERIC", symbol, spot, 0.050, 0.050)
        }
    }

    // 7. CRACK, CRUSH & SPARK SPREADS
    val crackCrushSpreads: List<CrackCrushSpread> = listOf(
        PricingAndBasisEngine.calculateCrack321(
            crudePricePerBbl = 82.45,
            gasolinePricePerBbl = 104.20,
            dieselPricePerBbl = 106.68 // 2.54 $/gal * 42 gal/bbl
        ),
        PricingAndBasisEngine.calculateSoybeanCrush(
            soybeanPricePerBu = 10.45,
            soyMealPricePerTon = 328.00,
            soyOilPriceCentsPerLb = 44.80
        ),
        PricingAndBasisEngine.calculateSparkSpread(
            powerPriceMwh = 48.50,
            gasPriceMmbtu = 2.68,
            heatRateMmbtuPerMwh = 7.2
        ),
        CrackCrushSpread(
            type = SpreadType.GOLD_SILVER_RATIO,
            name = "Gold / Silver Valuation Ratio",
            inputDescription = "Spot Gold (XAU) $2,748.50/oz t",
            outputDescription = "Spot Silver (XAG) $33.85/oz t",
            formula = "Gold Price ÷ Silver Price",
            value = 2748.50 / 33.85,
            unit = "Ratio (x)",
            historicalMean = 68.50,
            economicSignal = "Ratio at 81.2x: Silver historically undervalued relative to gold bullion monetary premium."
        ),
        CrackCrushSpread(
            type = SpreadType.BRENT_WTI_ARBITRAGE,
            name = "Brent / WTI Quality & Location Spread",
            inputDescription = "FOB Sullom Voe Brent ($82.45)",
            outputDescription = "FOB Cushing WTI ($78.60)",
            formula = "Brent Price - WTI Price",
            value = 82.45 - 78.60,
            unit = "USD/bbl",
            historicalMean = 4.20,
            economicSignal = "Spread at $3.85: Supports US crude export arbitrage via Gulf Coast to European refiners."
        )
    )

    // 8. TRADING BOOK POSITIONS & RISK
    val tradingBookPositions: List<TradingBookPosition> = listOf(
        TradingBookPosition("POS-BRENT-P1", "BRENT", PositionType.PHYSICAL_LONG, 600000.0, "bbl", 80.50, 82.45, (82.45 - 80.50) * 600000.0, 600000.0, 0.0, 1.85, "Rotterdam Vopak Europoort"),
        TradingBookPosition("POS-BRENT-F1", "BRENT", PositionType.FUTURES_SHORT, 550000.0, "bbl", 81.20, 82.45, (81.20 - 82.45) * 550000.0, -550000.0, 0.0, 0.0, "ICE Europe Clearing"),
        TradingBookPosition("POS-CU-P1", "HG-COPPER", PositionType.PHYSICAL_LONG, 5000.0, "mt", 9420.00, 9680.00, (9680.00 - 9420.00) * 5000.0, 5000.0, 0.0, 85.00, "C. Steinweg Rotterdam"),
        TradingBookPosition("POS-CU-F1", "HG-COPPER", PositionType.FUTURES_SHORT, 4500.0, "mt", 9550.00, 9680.00, (9550.00 - 9680.00) * 4500.0, -4500.0, 0.0, 0.0, "LME Clear London"),
        TradingBookPosition("POS-AU-P1", "XAU", PositionType.PHYSICAL_LONG, 12500.0, "oz t", 2680.00, 2748.50, (2748.50 - 2680.00) * 12500.0, 12500.0, 0.0, 0.0, "HSBC Loco London"),
        TradingBookPosition("POS-CRN-P1", "CORN", PositionType.PHYSICAL_LONG, 250000.0, "bu", 4.25, 4.38, (4.38 - 4.25) * 250000.0, 250000.0, 0.0, 0.22, "ADM Peoria Silo"),
        TradingBookPosition("POS-BRENT-OPT", "BRENT", PositionType.CALL_LONG, 100000.0, "bbl", 2.40, 3.85, (3.85 - 2.40) * 100000.0, 52000.0, 1850.0, 0.0, "ICE Clear Europe")
    )

    // 9. STRESS SCENARIOS
    val stressScenarios: List<StressScenario> = listOf(
        StressScenario(
            id = "SCEN-OIL-30",
            name = "Crude Oil Macro Collapse (-30%)",
            description = "Global recessionary demand contraction + sudden OPEC supply war release.",
            shocks = mapOf("BRENT" to -30.0, "WTI" to -30.0, "DIESEL-ULSD" to -26.0),
            estimatedPnlImpact = -4850000.0,
            marginCallImpact = 3200000.0,
            criticalBottleneckNotice = "Severe physical long inventory devaluation; inventory carrying loans trigger margin pledges.",
            probabilityRating = "Medium (Tail Risk 12%)"
        ),
        StressScenario(
            id = "SCEN-GAS-50",
            name = "European Gas Supply Disruption (+50%)",
            description = "Subsea pipeline rupture in North Sea + severe winter cold snap across Northwest Europe.",
            shocks = mapOf("TTF-GAS" to 50.0, "LNG-ASIA" to 38.0, "HENRY-HUB" to 15.0),
            estimatedPnlImpact = 2450000.0,
            marginCallImpact = 1800000.0,
            criticalBottleneckNotice = "Cryogenic LNG export liquefaction capacity running at 102% max nameplate capacity.",
            probabilityRating = "Low-Medium (18%)"
        ),
        StressScenario(
            id = "SCEN-CU-20",
            name = "Copper Smelter & Mine Outage (+20%)",
            description = "Chilean pit failure coupled with Chinese smelter emissions curtailments.",
            shocks = mapOf("HG-COPPER" to 20.0, "ALUMINIUM" to 12.0),
            estimatedPnlImpact = 1250000.0,
            marginCallImpact = 850000.0,
            criticalBottleneckNotice = "LME registered warrant stocks deplete to under 3 days of global consumption.",
            probabilityRating = "Medium (24%)"
        ),
        StressScenario(
            id = "SCEN-DROUGHT",
            name = "Global Agricultural Heatwave (+25%)",
            description = "Synchronous flash drought across US Midwest and Brazil Cerrado corn/soy zones.",
            shocks = mapOf("CORN" to 25.0, "SOYBEANS" to 22.0, "WHEAT-SRW" to 18.0),
            estimatedPnlImpact = 950000.0,
            marginCallImpact = 620000.0,
            criticalBottleneckNotice = "Mississippi River draft restricted to 8 feet; export barge queues exceed 400 tows.",
            probabilityRating = "Medium-High (30%)"
        )
    )

    // 10. DIGITAL TWIN SUPPLY CHAIN NODES
    val digitalTwinNodes: List<DigitalTwinNode> = listOf(
        DigitalTwinNode("NODE-ESCONDIDA", "Escondida Copper Mine", NodeType.MINE, "Atacama, Chile", "HG-COPPER", 3200.0, 94.5, 14200.0, "mt conc", NodeHealth.OPTIMAL, 0.12, emptyList()),
        DigitalTwinNode("NODE-ANTOFAGASTA", "Antofagasta Port Terminal", NodeType.EXPORT_PORT, "Antofagasta, Chile", "HG-COPPER", 4500.0, 88.0, 38000.0, "mt conc", NodeHealth.OPTIMAL, 0.08, listOf("NODE-ESCONDIDA")),
        DigitalTwinNode("NODE-ROTTERDAM-SMELTER", "Aurubis Smelter Complex", NodeType.SMELTER, "Hamburg/Rotterdam", "HG-COPPER", 1800.0, 91.2, 8500.0, "mt cath", NodeHealth.OPTIMAL, 0.15, listOf("NODE-ANTOFAGASTA")),
        DigitalTwinNode("NODE-SULLOM-VOE", "Sullom Voe Terminal", NodeType.EXPORT_PORT, "Shetland, UK", "BRENT", 250000.0, 82.0, 1850000.0, "bbl", NodeHealth.OPTIMAL, 0.06, emptyList()),
        DigitalTwinNode("NODE-PERNIS-REF", "Shell Pernis Refinery", NodeType.REFINERY, "Rotterdam, Netherlands", "BRENT", 400000.0, 96.0, 2400000.0, "bbl", NodeHealth.ELEVATED_LOAD, 0.22, listOf("NODE-SULLOM-VOE")),
        DigitalTwinNode("NODE-RAS-LAFFAN", "Ras Laffan LNG Complex", NodeType.GAS_WELL, "Al Khawr, Qatar", "LNG-ASIA", 77000000.0, 98.2, 450000.0, "m3 cryo", NodeHealth.OPTIMAL, 0.05, emptyList()),
        DigitalTwinNode("NODE-SUEZ-CANAL", "Suez Maritime Chokepoint", NodeType.SHIP_ROUTER, "Egypt", "BRENT", 5000000.0, 74.0, 0.0, "bpd", NodeHealth.CONSTRAINED_BOTTLENECK, 0.45, emptyList()),
        DigitalTwinNode("NODE-CUSHING", "Cushing Storage & Pipeline Junction", NodeType.PIPELINE, "Oklahoma, USA", "WTI", 650000.0, 81.4, 11800000.0, "bbl", NodeHealth.OPTIMAL, 0.09, emptyList())
    )

    // 11. SUPPLY-DEMAND GLOBAL BALANCES
    val supplyDemandBalances: List<SupplyDemandBalance> = listOf(
        SupplyDemandBalance("BRENT", 102.8, 103.4, 46.5, 46.2, -0.6, -0.6, 27.2, 99, 1.2),
        SupplyDemandBalance("HG-COPPER", 26.4, 26.8, 11.2, 11.1, -0.4, -0.4, 7.8, 28, 2.8),
        SupplyDemandBalance("XAU", 3650.0, 4820.0, 1800.0, 1800.0, 220.0, 0.0, 85.0, 310, 3.4),
        SupplyDemandBalance("CORN", 1235.0, 1228.0, 204.0, 204.0, 7.0, 7.0, 25.4, 93, 1.8),
        SupplyDemandBalance("SOYBEANS", 421.0, 426.0, 178.0, 178.0, -5.0, -5.0, 22.8, 83, 2.1),
        SupplyDemandBalance("LITHIUM-LCE", 1.15, 1.19, 0.85, 0.85, -0.04, -0.04, 14.2, 52, 18.5)
    )

    // 12. NATURAL LANGUAGE & CLI EXECUTABLE QUERY PARSER
    data class TerminalCliResponse(
        val query: String,
        val commandType: String,
        val provenance: String,
        val date: String,
        val methodology: String,
        val assumptions: String,
        val primaryDataBlock: String,
        val metrics: List<Pair<String, String>>
    )

    fun executeTerminalCommand(input: String): TerminalCliResponse {
        val trimmed = input.trim()
        val lower = trimmed.lowercase()

        return when {
            lower.contains("quote") || lower.contains("price") -> {
                val symbol = spotQuotes.firstOrNull { lower.contains(it.symbol.lowercase()) }?.symbol ?: "BRENT"
                val quote = spotQuotes.first { it.symbol == symbol }
                TerminalCliResponse(
                    query = trimmed,
                    commandType = "SPOT_QUOTE_QUERY",
                    provenance = quote.provenance.label,
                    date = currentTimeStr(),
                    methodology = "Real-time exchange trade matching & institutional assessment. Clean incoterms basis: ${quote.basis.code} (${quote.location}).",
                    assumptions = "Continuous auction liquidity. 24h volume: ${quote.volume24h} contracts. Open interest: ${quote.openInterest}.",
                    primaryDataBlock = "${quote.symbol} (${quote.name})\nPrice: ${quote.price} ${quote.currency}/${quote.unit} [${if (quote.change24h >= 0) "+" else ""}${quote.change24h} / ${quote.change24hPct}%]\nBid: ${quote.bid} | Ask: ${quote.ask} | Spread: ${String.format("%.3f", quote.ask - quote.bid)}",
                    metrics = listOf(
                        "Market Basis" to "${quote.basis.code} (${quote.deliveryTerm})",
                        "24h Range" to "${quote.low24h} - ${quote.high24h} ${quote.currency}",
                        "Volume" to "${quote.volume24h} units",
                        "Open Interest" to "${quote.openInterest}"
                    )
                )
            }
            lower.contains("curve") || lower.contains("backwardation") || lower.contains("contango") -> {
                val symbol = spotQuotes.firstOrNull { lower.contains(it.symbol.lowercase()) }?.symbol ?: "BRENT"
                val curve = getForwardCurve(symbol)
                TerminalCliResponse(
                    query = trimmed,
                    commandType = "FORWARD_CURVE_QUERY",
                    provenance = "MODELLED (Cost-of-Carry + Convenience Yield)",
                    date = currentTimeStr(),
                    methodology = "F(T) = S_0 * exp((r + u - y) * T). Evaluated across 10 prompt and back-month tenors.",
                    assumptions = "Short-term SOFR/EURIBOR risk-free rate 4.85%. Physical storage & tank demurrage based on prevailing regional leases.",
                    primaryDataBlock = "${curve.symbol} FORWARD CURVE: ${curve.overallStructure.label}\nPrompt Spot: $${curve.spotPrice} -> 12M Tenor: $${String.format("%.2f", curve.tenors.first { it.months == 12 }.price)}\nCalendar Spread (Dec/Jan): $${String.format("%.2f", curve.calendarSpreadDecJan)}\nAnnualized Carry: ${String.format("%.2f", curve.annualizedCarryPct)}%",
                    metrics = curve.tenors.map { "${it.label} (${it.months}M)" to "$${String.format("%.2f", it.price)} [${it.structure.name.take(4)}]" }
                )
            }
            lower.contains("inventory") || lower.contains("stock") -> {
                val symbol = spotQuotes.firstOrNull { lower.contains(it.symbol.lowercase()) }?.symbol ?: "HG-COPPER"
                val matchedLots = physicalLots.filter { it.symbol == symbol }
                val totalOnHand = matchedLots.sumOf { it.quantity }
                val available = matchedLots.filter { it.status == LotStatus.AVAILABLE || it.status == LotStatus.IN_STORAGE }.sumOf { it.quantity }
                val unit = matchedLots.firstOrNull()?.unit ?: "units"
                TerminalCliResponse(
                    query = trimmed,
                    commandType = "PHYSICAL_INVENTORY_AUDIT",
                    provenance = "VERIFIED (Double-Entry Physical Lot Engine)",
                    date = currentTimeStr(),
                    methodology = "On-Hand physical lot verification across licensed terminal network. Prevents double-selling through immutable lot state transitions.",
                    assumptions = "Quarantine and quality holds deducted from deliverable balances. Quality certificates verified.",
                    primaryDataBlock = "$symbol PHYSICAL INVENTORY AUDIT:\nTotal On-Hand: $totalOnHand $unit\nAvailable Deliverable: $available $unit across ${matchedLots.size} lots.",
                    metrics = matchedLots.map { lot -> "${lot.lotId} (${lot.warehouseName.take(18)})" to "${lot.quantity} ${lot.unit} [${lot.status.name}]" }
                )
            }
            lower.contains("stress") || lower.contains("scenario") -> {
                val scenario = stressScenarios.firstOrNull { lower.contains("oil") && it.id.contains("OIL") }
                    ?: stressScenarios.firstOrNull { lower.contains("gas") && it.id.contains("GAS") }
                    ?: stressScenarios.firstOrNull { lower.contains("copper") && it.id.contains("CU") }
                    ?: stressScenarios.first()

                TerminalCliResponse(
                    query = trimmed,
                    commandType = "PORTFOLIO_STRESS_TEST",
                    provenance = "SCENARIO (Full-Revaluation Non-Linear Shock)",
                    date = currentTimeStr(),
                    methodology = "Propagates instantaneous price and volatility shocks through physical positions, futures hedges, and Black-76 option Greeks.",
                    assumptions = scenario.description,
                    primaryDataBlock = "SCENARIO: ${scenario.name}\nEstimated Portfolio Impact: -$${String.format("%,.0f", kotlin.math.abs(scenario.estimatedPnlImpact))}\nAdditional Margin Call: $${String.format("%,.0f", scenario.marginCallImpact)}\nSeverity: ${scenario.probabilityRating}",
                    metrics = scenario.shocks.map { (sym, pct) -> "Shock $sym" to "${if (pct > 0) "+" else ""}$pct%" } +
                            listOf("Critical Bottleneck" to scenario.criticalBottleneckNotice)
                )
            }
            lower.contains("risk") || lower.contains("var") || lower.contains("exposure") -> {
                val risk = HedgeAndRiskEngine.computePortfolioRisk(tradingBookPositions)
                TerminalCliResponse(
                    query = trimmed,
                    commandType = "PORTFOLIO_RISK_METRICS",
                    provenance = "CALCULATED (Parametric VaR & CVaR 1-Day Horizon)",
                    date = currentTimeStr(),
                    methodology = "Multi-asset covariance matrix with Black-76 delta-normal aggregation and physical inventory marked-to-market.",
                    assumptions = "1-day holding horizon, 95% & 99% confidence level, 1.85% daily weighted volatility, SPAN margin rules.",
                    primaryDataBlock = "PORTFOLIO RISK PROFILE:\nGross Exposure: $${String.format("%,.0f", risk.grossExposure)}\nNet Exposure: $${String.format("%,.0f", risk.netExposure)}\n1-Day VaR (95%): $${String.format("%,.0f", risk.var95_1Day)}\n1-Day Expected Shortfall (CVaR): $${String.format("%,.0f", risk.expectedShortfall95)}",
                    metrics = listOf(
                        "1-Day VaR (99%)" to "$${String.format("%,.0f", risk.var99_1Day)}",
                        "Stress Worst-Case Loss" to "$${String.format("%,.0f", risk.stressWorstCaseLoss)}",
                        "Initial Margin Req." to "$${String.format("%,.0f", risk.initialMarginRequired)}",
                        "Free Pledged Collateral" to "$${String.format("%,.0f", risk.freeCollateral)}"
                    )
                )
            }
            lower.contains("hedge") -> {
                val hedge = HedgeAndRiskEngine.calculateMinimumVarianceHedge(
                    spotQuantity = 500000.0,
                    spotVol = 0.28,
                    futuresVol = 0.27,
                    correlation = 0.94,
                    futuresContractSize = 1000.0,
                    spotPrice = 82.45
                )
                TerminalCliResponse(
                    query = trimmed,
                    commandType = "OPTIMAL_HEDGE_CALCULATION",
                    provenance = "CALCULATED (Minimum Variance Hedge Ratio)",
                    date = currentTimeStr(),
                    methodology = "h* = rho * (sigma_S / sigma_F). Contracts N* = h* * (Q_A / Q_F).",
                    assumptions = "Underlying spot crude 500,000 bbl. 1,000 bbl/contract ICE Brent futures. Historical 60-day log-return covariance.",
                    primaryDataBlock = "OPTIMAL PHYSICAL COMMODITY HEDGE:\nOptimal Hedge Ratio (h*): ${String.format("%.3f", hedge.hedgeRatio)}\nRecommended Short Futures: ${hedge.recommendedFuturesContracts} contracts\nHedge Effectiveness (R²): ${String.format("%.1f", hedge.hedgeEffectivenessPct)}%\nResidual Basis Risk: ${String.format("%.1f", hedge.residualRiskPct)}%",
                    metrics = listOf(
                        "Spot Exposure" to "$${String.format("%,.0f", hedge.physicalRiskExposureUsd)}",
                        "Variance Reduction" to "${String.format("%.1f", hedge.varianceReductionPct)}%",
                        "Recommendation" to hedge.strategySummary
                    )
                )
            }
            else -> {
                // General market status summary
                val contangoCount = spotQuotes.count { getForwardCurve(it.symbol).overallStructure == CurveStructure.CONTANGO }
                val backwardationCount = spotQuotes.count { getForwardCurve(it.symbol).overallStructure == CurveStructure.BACKWARDATION }
                TerminalCliResponse(
                    query = trimmed,
                    commandType = "COMMAND_CENTRE_STATUS",
                    provenance = "CALCULATED (Global Commodities OS Core Engine)",
                    date = currentTimeStr(),
                    methodology = "Aggregated cross-sector terminal surveillance across 16 primary benchmark complexes.",
                    assumptions = "Active trading sessions in London, New York, Singapore & Chicago.",
                    primaryDataBlock = "GLOBAL COMMODITIES OS STATUS: SYSTEM ACTIVE\nTracking 16 Primary Benchmark Complexes | 9 Physical Commodity Sectors\nMarket Structure: Contango = $contangoCount | Backwardation = $backwardationCount\nSupply Chain Health: 8 Active Nodes, 1 Chokepoint Alert (Suez/Bab el-Mandeb)",
                    metrics = listOf(
                        "Energy Pulse" to "Brent $82.45 (↑), WTI $78.60 (↑), JKM $13.95 (↑)",
                        "Metals Pulse" to "Gold $2,748.50 (↑), Copper $9,680 (↑), Iron Ore $108.50 (→)",
                        "Ag Pulse" to "Corn $4.38 (↑), Soybeans $10.45 (↓), Wheat $5.82 (→)",
                        "Critical Pulse" to "Lithium $12,850/t (↑), Battery Grade"
                    )
                )
            }
        }
    }
}
