package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.components.TerminalTopBar
import com.example.ui.screens.*
import com.example.ui.theme.*

enum class TerminalWorkspace(val title: String, val icon: ImageVector) {
    COMMAND_CENTRE("Command", Icons.Default.Dashboard),
    MARKETS("Markets", Icons.Default.ShowChart),
    CURVES("Curves", Icons.Default.Timeline),
    SUPPLY_CHAIN("Supply Twin", Icons.Default.Hub),
    TRADING_RISK("Risk Book", Icons.Default.Security),
    CLI("CLI", Icons.Default.Terminal)
}

@Composable
fun MainApp() {
    var activeWorkspace by remember { mutableStateOf(TerminalWorkspace.COMMAND_CENTRE) }
    var selectedCommodityDetail by remember { mutableStateOf<String?>(null) }

    // Android Hardware Back button handling
    BackHandler(enabled = selectedCommodityDetail != null || activeWorkspace != TerminalWorkspace.COMMAND_CENTRE) {
        if (selectedCommodityDetail != null) {
            selectedCommodityDetail = null
        } else {
            activeWorkspace = TerminalWorkspace.COMMAND_CENTRE
        }
    }

    Scaffold(
        topBar = {
            TerminalTopBar(
                activeScreenName = if (selectedCommodityDetail != null) {
                    "DETAIL: $selectedCommodityDetail"
                } else {
                    activeWorkspace.title
                }
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = TerminalSurface,
                tonalElevation = 0.dp,
                modifier = Modifier
                    .border(width = 0.5.dp, color = TerminalBorder)
                    .testTag("terminal_navigation_bar")
            ) {
                TerminalWorkspace.values().forEach { tab ->
                    val isSelected = activeWorkspace == tab && selectedCommodityDetail == null
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = {
                            selectedCommodityDetail = null
                            activeWorkspace = tab
                        },
                        icon = {
                            Icon(
                                tab.icon,
                                contentDescription = tab.title,
                                tint = if (isSelected) MarketBlue else TextMuted
                            )
                        },
                        label = {
                            Text(
                                text = tab.title,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isSelected) MarketBlue else TextMuted
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = TerminalSurfaceElevated
                        ),
                        modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                    )
                }
            }
        },
        containerColor = TerminalBackground
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (selectedCommodityDetail != null) {
                CommodityDetailScreen(
                    symbol = selectedCommodityDetail!!,
                    onBack = { selectedCommodityDetail = null }
                )
            } else {
                when (activeWorkspace) {
                    TerminalWorkspace.COMMAND_CENTRE -> CommandCentreScreen(
                        onSelectCommodity = { sym -> selectedCommodityDetail = sym },
                        onNavigateToCurves = { activeWorkspace = TerminalWorkspace.CURVES },
                        onNavigateToRisk = { activeWorkspace = TerminalWorkspace.TRADING_RISK },
                        onNavigateToSupplyChain = { activeWorkspace = TerminalWorkspace.SUPPLY_CHAIN },
                        onNavigateToCli = { activeWorkspace = TerminalWorkspace.CLI }
                    )
                    TerminalWorkspace.MARKETS -> MarketsScreen(
                        onSelectCommodity = { sym -> selectedCommodityDetail = sym }
                    )
                    TerminalWorkspace.CURVES -> CurvesAndSpreadsScreen(
                        onSelectCommodity = { sym -> selectedCommodityDetail = sym }
                    )
                    TerminalWorkspace.SUPPLY_CHAIN -> PhysicalSupplyChainScreen(
                        onSelectCommodity = { sym -> selectedCommodityDetail = sym }
                    )
                    TerminalWorkspace.TRADING_RISK -> TradingRiskScreen()
                    TerminalWorkspace.CLI -> CommandTerminalScreen()
                }
            }
        }
    }
}
