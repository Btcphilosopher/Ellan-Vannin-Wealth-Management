package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MasterCommodityRepository
import com.example.engine.DigitalTwinSimulationEngine
import com.example.model.*
import com.example.ui.theme.*

@Composable
fun PhysicalSupplyChainScreen(
    onSelectCommodity: (String) -> Unit
) {
    var activeSubTab by remember { mutableStateOf("SIMULATOR") } // SIMULATOR, LOTS, WAREHOUSES, LOGISTICS
    var selectedSimEvent by remember { mutableStateOf(DigitalTwinSimulationEngine.SimulatedEvent.MAJOR_MINE_OUTAGE) }
    var simulationResult by remember {
        mutableStateOf(DigitalTwinSimulationEngine.simulateShock(DigitalTwinSimulationEngine.SimulatedEvent.MAJOR_MINE_OUTAGE))
    }

    val warehouses = MasterCommodityRepository.warehouses
    val lots = MasterCommodityRepository.physicalLots
    val shipments = MasterCommodityRepository.shipments
    val twinNodes = MasterCommodityRepository.digitalTwinNodes

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "PHYSICAL SUPPLY CHAIN & DIGITAL TWIN",
                style = MaterialTheme.typography.titleLarge,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Text(
                text = "Global asset nodes, lot inventory verification, freight logistics & discrete shock simulation",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
        }

        // Sub-navigation bar
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurfaceElevated, RoundedCornerShape(4.dp))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                listOf(
                    "SIMULATOR" to "Shock Simulator",
                    "LOTS" to "Lot Engine (${lots.size})",
                    "WAREHOUSES" to "Terminals (${warehouses.size})",
                    "LOGISTICS" to "Vessels / Rail (${shipments.size})"
                ).forEach { (key, label) ->
                    val isSelected = activeSubTab == key
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(if (isSelected) MarketBlue else Color.Transparent, RoundedCornerShape(3.dp))
                            .clickable { activeSubTab = key }
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) TerminalBackground else TextSecondary,
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }

        when (activeSubTab) {
            "SIMULATOR" -> {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalBorder)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.FlashOn, contentDescription = "Sim", tint = MarketAmber, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "DISCRETE-EVENT SHOCK SIMULATOR",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Select an exogenous physical disruption to calculate deterministic propagation across supply, curves, basis, and downstream margins.",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextMuted
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            // Shock Selection Chips
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(DigitalTwinSimulationEngine.SimulatedEvent.values()) { event ->
                                    val isSelected = selectedSimEvent == event
                                    Box(
                                        modifier = Modifier
                                            .background(if (isSelected) MarketAmber else TerminalSurfaceVariant, RoundedCornerShape(4.dp))
                                            .border(1.dp, if (isSelected) MarketAmber else TerminalBorder, RoundedCornerShape(4.dp))
                                            .clickable {
                                                selectedSimEvent = event
                                                simulationResult = DigitalTwinSimulationEngine.simulateShock(event)
                                            }
                                            .padding(horizontal = 10.dp, vertical = 6.dp)
                                            .testTag("shock_chip_${event.name}")
                                    ) {
                                        Text(
                                            text = event.eventName.take(28) + if (event.eventName.length > 28) "..." else "",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            color = if (isSelected) TerminalBackground else TextSecondary
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))
                            HorizontalDivider(color = TerminalBorderSubtle)
                            Spacer(modifier = Modifier.height(10.dp))

                            // Simulation Result Header Metrics
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                DetailStatBox(label = "Price Shock Delta", value = "+${String.format("%.1f", simulationResult.finalPriceDeltaPct)}%", valueColor = MarketRed)
                                DetailStatBox(label = "Inventory Drawdown", value = "-${String.format("%.1f", simulationResult.finalInventoryDrawdownPct)}%", valueColor = MarketAmber)
                                DetailStatBox(label = "Downstream Cost Inflation", value = "+${String.format("%.1f", simulationResult.finalDownstreamCostInflationPct)}%", valueColor = MarketRed)
                                DetailStatBox(label = "Risk Level", value = simulationResult.physicalRiskLevel, valueColor = MarketAmber)
                            }
                        }
                    }
                }

                item {
                    Text(
                        text = "DETERMINISTIC CAUSAL PROPAGATION SEQUENCE (SPECIFICATION 75):",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }

                items(simulationResult.propagationSequence) { step ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalBorder)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .background(TerminalSurfaceElevated, RoundedCornerShape(14.dp))
                                    .border(1.dp, MarketBlue, RoundedCornerShape(14.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${step.stepNumber}",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MarketBlue
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "${step.domain} • ${step.nodeOrMetric}",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary
                                    )
                                    Text(
                                        text = step.quantitativeShift,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = if (step.quantitativeShift.startsWith("-")) MarketRed else MarketGreen
                                    )
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = step.changeDescription,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                        }
                    }
                }
            }

            "LOTS" -> {
                item {
                    Text(
                        text = "LOT REGISTER & DOUBLE-SELLING AUDIT TRAIL",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "Every physical parcel possesses an immutable lot ID, assay certification, warehouse title & state.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted
                    )
                }

                items(lots) { lot ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalBorder)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${lot.lotId} [${lot.symbol}]",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Box(
                                    modifier = Modifier
                                        .background(TerminalSurfaceElevated, RoundedCornerShape(3.dp))
                                        .border(1.dp, MarketGreen, RoundedCornerShape(3.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = lot.status.displayName,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MarketGreen,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Spec: ${lot.specificationSummary}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Volume: ${String.format("%,.0f", lot.quantity)} ${lot.unit} • Producer: ${lot.producer} (${lot.origin})",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextPrimary
                            )
                            Text(
                                text = "Warehouse: ${lot.warehouseName} • Title Owner: ${lot.owner}",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted
                            )
                            Text(
                                text = "Certificate: ${lot.qualityCertificateId} • Prod Date: ${lot.productionDate}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MarketBlue
                            )
                        }
                    }
                }
            }

            "WAREHOUSES" -> {
                item {
                    Text(
                        text = "GLOBAL LICENSED WAREHOUSE & TERMINAL NETWORK",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }

                items(warehouses) { wh ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalBorder)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = wh.name,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary
                                    )
                                    Text(
                                        text = "${wh.location}, ${wh.country} • Owner: ${wh.owner}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondary
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .background(TerminalSurfaceElevated, RoundedCornerShape(3.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = wh.type.name,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MarketBlue
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                DetailStatBox(label = "Total Capacity", value = "${String.format("%,.0f", wh.totalCapacity)} ${wh.unit}")
                                DetailStatBox(label = "On-Hand", value = "${String.format("%,.0f", wh.onHandQuantity)} ${wh.unit}")
                                DetailStatBox(label = "Available Space", value = "${String.format("%,.0f", wh.availableCapacity)} ${wh.unit}")
                                DetailStatBox(
                                    label = "Utilization",
                                    value = "${String.format("%.1f", wh.utilizationPct)}%",
                                    valueColor = if (wh.utilizationPct > 85.0) MarketAmber else MarketGreen
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Storage Cost: $${wh.storageCostPerDay}/${wh.unit}/day • Insurance: ${wh.insurancePolicyNo}",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted
                            )
                        }
                    }
                }
            }

            "LOGISTICS" -> {
                item {
                    Text(
                        text = "MARITIME FLEET, PIPELINE & FREIGHT LOGISTICS",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }

                items(shipments) { shp ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalBorder)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = shp.vesselOrId,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Box(
                                    modifier = Modifier
                                        .background(TerminalSurfaceElevated, RoundedCornerShape(3.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = shp.status.name,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (shp.status == ShipmentStatus.CHOKEPOINT_TRANSIT) MarketAmber else MarketGreen
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Cargo: ${shp.cargoDescription} (${String.format("%,.0f", shp.quantity)} ${shp.unit})",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextPrimary
                            )
                            Text(
                                text = "Voyage: ${shp.originPort} → ${shp.destinationPort} (ETA: ${shp.etaDate})",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                            Text(
                                text = "Chokepoint / Route: ${shp.routeChokepoint} • Freight: ${shp.freightRate} ${shp.freightUnit}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MarketBlue
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
