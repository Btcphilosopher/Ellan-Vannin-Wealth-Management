package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MasterCommodityRepository
import com.example.engine.HedgeAndRiskEngine
import com.example.model.PositionType
import com.example.model.StressScenario
import com.example.model.TradingBookPosition
import com.example.ui.theme.*

@Composable
fun TradingRiskScreen() {
    val positions = MasterCommodityRepository.tradingBookPositions
    val riskMetrics = remember(positions) {
        HedgeAndRiskEngine.computePortfolioRisk(positions)
    }

    var selectedScenario by remember { mutableStateOf<StressScenario?>(null) }
    var hedgeSpotQuantity by remember { mutableStateOf(500000.0) } // 500k bbl
    val hedgeResult = remember(hedgeSpotQuantity) {
        HedgeAndRiskEngine.calculateMinimumVarianceHedge(
            spotQuantity = hedgeSpotQuantity,
            spotVol = 0.28,
            futuresVol = 0.27,
            correlation = 0.94,
            futuresContractSize = 1000.0,
            spotPrice = 82.45
        )
    }

    val stressScenarios = MasterCommodityRepository.stressScenarios

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "TRADING BOOK & RISK ENGINE",
                style = MaterialTheme.typography.titleLarge,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Text(
                text = "Multi-commodity portfolio, SPAN margin, Parametric VaR, optimal MVHR hedging & stress tests",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
        }

        // Portfolio Risk & VaR Overview
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Security, contentDescription = "Risk", tint = MarketBlue, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "PORTFOLIO VALUE-AT-RISK & EXPOSURE",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }
                        Text(
                            text = "1-DAY HORIZON",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        DetailStatBox(label = "Gross Exposure", value = "$${String.format("%,.0f", riskMetrics.grossExposure)}")
                        DetailStatBox(label = "Net Exposure", value = "$${String.format("%,.0f", riskMetrics.netExposure)}")
                        DetailStatBox(label = "Unrealized PnL", value = "$${String.format("%,.0f", riskMetrics.totalPortfolioNav)}", valueColor = MarketGreen)
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = TerminalBorderSubtle)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        DetailStatBox(label = "1-Day VaR (95%)", value = "$${String.format("%,.0f", riskMetrics.var95_1Day)}", valueColor = MarketRed)
                        DetailStatBox(label = "1-Day VaR (99%)", value = "$${String.format("%,.0f", riskMetrics.var99_1Day)}", valueColor = MarketRed)
                        DetailStatBox(label = "Expected Shortfall (CVaR)", value = "$${String.format("%,.0f", riskMetrics.expectedShortfall95)}", valueColor = MarketAmber)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        DetailStatBox(label = "Initial Margin Req.", value = "$${String.format("%,.0f", riskMetrics.initialMarginRequired)}")
                        DetailStatBox(label = "Pledged Collateral", value = "$${String.format("%,.0f", riskMetrics.pledgedCollateral)}")
                        DetailStatBox(label = "Free Collateral", value = "$${String.format("%,.0f", riskMetrics.freeCollateral)}", valueColor = MarketGreen)
                    }
                }
            }
        }

        // Optimal Minimum Variance Hedging Calculator (Specification 34 & 35)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "OPTIMAL MINIMUM VARIANCE HEDGE ENGINE (MVHR)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Formula: h* = ρ × (σ_S ÷ σ_F). Contracts N* = h* × (Q_A ÷ Q_F)",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = MarketBlue
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        DetailStatBox(label = "Hedge Ratio (h*)", value = String.format("%.3f", hedgeResult.hedgeRatio), valueColor = MarketBlue)
                        DetailStatBox(label = "Short Contracts", value = "${hedgeResult.recommendedFuturesContracts} contracts", valueColor = TextPrimary)
                        DetailStatBox(label = "Effectiveness (R²)", value = "${String.format("%.1f", hedgeResult.hedgeEffectivenessPct)}%", valueColor = MarketGreen)
                        DetailStatBox(label = "Residual Risk", value = "${String.format("%.1f", hedgeResult.residualRiskPct)}%", valueColor = MarketAmber)
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(TerminalSurfaceElevated, RoundedCornerShape(4.dp))
                            .padding(8.dp)
                    ) {
                        Text(
                            text = hedgeResult.strategySummary,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            fontSize = 11.5.sp
                        )
                    }
                }
            }
        }

        // Stress Testing Scenarios (Specification 37)
        item {
            Text(
                text = "PORTFOLIO STRESS TESTING & MARGIN SPIKE SCENARIOS",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        items(stressScenarios) { scen ->
            val isSelected = selectedScenario == scen
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) TerminalSurfaceElevated else TerminalSurface
                ),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = androidx.compose.ui.graphics.SolidColor(if (isSelected) MarketAmber else TerminalBorder)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { selectedScenario = if (isSelected) null else scen }
                    .testTag("stress_scenario_${scen.id}")
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = scen.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "-$${String.format("%,.0f", kotlin.math.abs(scen.estimatedPnlImpact))}",
                            style = MaterialTheme.typography.titleMedium,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = MarketRed
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = scen.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Margin Spike: +$${String.format("%,.0f", scen.marginCallImpact)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MarketAmber
                        )
                        Text(
                            text = scen.probabilityRating,
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted
                        )
                    }

                    if (isSelected) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(TerminalSurfaceVariant, RoundedCornerShape(4.dp))
                                .padding(8.dp)
                        ) {
                            Text(
                                text = "Critical Bottleneck Impact: ${scen.criticalBottleneckNotice}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextPrimary
                            )
                        }
                    }
                }
            }
        }

        // Active Trading Book Positions (Specification 33)
        item {
            Text(
                text = "ACTIVE TRADING BOOK POSITIONS (${positions.size})",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        items(positions) { pos ->
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = pos.commoditySymbol,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .background(TerminalSurfaceElevated, RoundedCornerShape(3.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = pos.type.name,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (pos.type.name.contains("LONG")) MarketGreen else MarketAmber
                                    )
                                }
                            }
                            Text(
                                text = "Qty: ${String.format("%,.0f", pos.quantity)} ${pos.unit} • Loc: ${pos.location}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            val isPos = pos.unrealizedPnl >= 0
                            Text(
                                text = "${if (isPos) "+" else ""}$${String.format("%,.0f", pos.unrealizedPnl)}",
                                style = MaterialTheme.typography.titleMedium,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = if (isPos) MarketGreen else MarketRed
                            )
                            Text(
                                text = "Entry $${pos.entryPrice} -> Mkt $${pos.currentMarketPrice}",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
