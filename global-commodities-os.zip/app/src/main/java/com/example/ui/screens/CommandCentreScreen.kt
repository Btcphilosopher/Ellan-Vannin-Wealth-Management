package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MasterCommodityRepository
import com.example.model.CurveStructure
import com.example.model.Sector
import com.example.model.SpotPriceQuote
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun CommandCentreScreen(
    onSelectCommodity: (String) -> Unit,
    onNavigateToCurves: () -> Unit,
    onNavigateToRisk: () -> Unit,
    onNavigateToSupplyChain: () -> Unit,
    onNavigateToCli: () -> Unit
) {
    val quotes = MasterCommodityRepository.spotQuotes
    val energyQuotes = quotes.filter { it.category == Sector.ENERGY }.take(4)
    val metalsQuotes = quotes.filter { it.category == Sector.BASE_METALS || it.category == Sector.PRECIOUS_METALS || it.category == Sector.FERROUS }.take(4)
    val agQuotes = quotes.filter { it.category == Sector.AGRICULTURE || it.category == Sector.SOFT_COMMODITIES }.take(4)
    val criticalQuotes = quotes.filter { it.category == Sector.BATTERY_CRITICAL }.take(3)

    val contangoCount = quotes.count { MasterCommodityRepository.getForwardCurve(it.symbol).overallStructure == CurveStructure.CONTANGO }
    val backwardationCount = quotes.count { MasterCommodityRepository.getForwardCurve(it.symbol).overallStructure == CurveStructure.BACKWARDATION }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(6.dp))
            // Institutional Banner: Command Centre State
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalBorder)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("command_centre_summary_card")
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "GLOBAL COMMODITIES",
                                style = MaterialTheme.typography.titleLarge,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "Institutional Multi-Asset Computational State",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted
                            )
                        }

                        Button(
                            onClick = onNavigateToCli,
                            colors = ButtonDefaults.buttonColors(containerColor = TerminalSurfaceElevated),
                            shape = RoundedCornerShape(4.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("open_cli_btn")
                        ) {
                            Icon(
                                Icons.Default.Terminal,
                                contentDescription = "CLI",
                                tint = MarketBlue,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "COMOS CLI",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextPrimary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = TerminalBorderSubtle)
                    Spacer(modifier = Modifier.height(12.dp))

                    // Institutional System Indicators Grid (Specification 85)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        MacroMetricItem(
                            label = "CURVES",
                            value = "CT:$contangoCount / BW:$backwardationCount",
                            indicatorColor = MarketAmber,
                            onClick = onNavigateToCurves
                        )
                        MacroMetricItem(
                            label = "ENERGY STOCKS",
                            value = "AMBER (TIGHT)",
                            indicatorColor = MarketAmber,
                            onClick = onNavigateToSupplyChain
                        )
                        MacroMetricItem(
                            label = "METALS STOCKS",
                            value = "GREEN (BALANCED)",
                            indicatorColor = MarketGreen,
                            onClick = onNavigateToSupplyChain
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        MacroMetricItem(
                            label = "VLCC FREIGHT",
                            value = "WS 58.5 (↑ +3.2)",
                            indicatorColor = MarketGreen,
                            onClick = onNavigateToSupplyChain
                        )
                        MacroMetricItem(
                            label = "PHYSICAL BASIS",
                            value = "ACTIVE (PREMIUM)",
                            indicatorColor = MarketBlue,
                            onClick = onNavigateToCurves
                        )
                        MacroMetricItem(
                            label = "PORTFOLIO VaR 1D",
                            value = "$1.42M (95%)",
                            indicatorColor = MarketRed,
                            onClick = onNavigateToRisk
                        )
                    }
                }
            }
        }

        // Section: Energy Complex
        item {
            SectorHeaderRow(title = "ENERGY COMPLEX", count = energyQuotes.size, sectorColor = SectorEnergy)
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    energyQuotes.forEachIndexed { idx, quote ->
                        CommodityQuoteRow(
                            quote = quote,
                            onSelect = { onSelectCommodity(quote.symbol) }
                        )
                        if (idx < energyQuotes.size - 1) {
                            HorizontalDivider(color = TerminalBorderSubtle)
                        }
                    }
                }
            }
        }

        // Section: Metals Complex
        item {
            SectorHeaderRow(title = "METALS & FERROUS", count = metalsQuotes.size, sectorColor = SectorBaseMetals)
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    metalsQuotes.forEachIndexed { idx, quote ->
                        CommodityQuoteRow(
                            quote = quote,
                            onSelect = { onSelectCommodity(quote.symbol) }
                        )
                        if (idx < metalsQuotes.size - 1) {
                            HorizontalDivider(color = TerminalBorderSubtle)
                        }
                    }
                }
            }
        }

        // Section: Agriculture & Softs Complex
        item {
            SectorHeaderRow(title = "AGRICULTURE & SOFTS", count = agQuotes.size, sectorColor = SectorAgriculture)
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    agQuotes.forEachIndexed { idx, quote ->
                        CommodityQuoteRow(
                            quote = quote,
                            onSelect = { onSelectCommodity(quote.symbol) }
                        )
                        if (idx < agQuotes.size - 1) {
                            HorizontalDivider(color = TerminalBorderSubtle)
                        }
                    }
                }
            }
        }

        // Section: Battery & Critical Minerals
        item {
            SectorHeaderRow(title = "BATTERY & CRITICAL MINERALS", count = criticalQuotes.size, sectorColor = SectorCritical)
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    criticalQuotes.forEachIndexed { idx, quote ->
                        CommodityQuoteRow(
                            quote = quote,
                            onSelect = { onSelectCommodity(quote.symbol) }
                        )
                        if (idx < criticalQuotes.size - 1) {
                            HorizontalDivider(color = TerminalBorderSubtle)
                        }
                    }
                }
            }
        }

        // Featured Forward Curve: Brent Crude
        item {
            val brentCurve = MasterCommodityRepository.getForwardCurve("BRENT")
            ForwardCurveInteractiveChart(
                symbol = "BRENT",
                tenors = brentCurve.tenors,
                structure = brentCurve.overallStructure,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSelectCommodity("BRENT") }
            )
        }

        // Bottom padding
        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun SectorHeaderRow(title: String, count: Int, sectorColor: Color) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(width = 4.dp, height = 14.dp)
                    .background(sectorColor, RoundedCornerShape(1.dp))
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                letterSpacing = 0.5.sp
            )
        }
        Text(
            text = "$count BENCHMARKS",
            style = MaterialTheme.typography.labelSmall,
            color = TextMuted
        )
    }
}

@Composable
fun CommodityQuoteRow(
    quote: SpotPriceQuote,
    onSelect: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onSelect)
            .padding(horizontal = 12.dp, vertical = 10.dp)
            .testTag("quote_row_${quote.symbol}"),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = quote.symbol,
                    style = MaterialTheme.typography.titleMedium,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.width(6.dp))
                ProvenanceBadge(quote.provenance)
                Spacer(modifier = Modifier.width(4.dp))
                BasisBadge(quote.basis)
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "${quote.name} • ${quote.location}",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                maxLines = 1
            )
        }

        SimpleSparkline(
            isPositive = quote.change24h >= 0,
            modifier = Modifier.padding(horizontal = 8.dp)
        )

        PriceMetricBadge(
            price = quote.price,
            change24h = quote.change24h,
            change24hPct = quote.change24hPct,
            currency = quote.currency,
            unit = quote.unit
        )
    }
}

@Composable
fun MacroMetricItem(
    label: String,
    value: String,
    indicatorColor: Color,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .background(TerminalSurfaceVariant, RoundedCornerShape(4.dp))
            .border(0.5.dp, TerminalBorder, RoundedCornerShape(4.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        Column {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted,
                fontSize = 8.5.sp
            )
            Spacer(modifier = Modifier.height(2.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(5.dp)
                        .background(indicatorColor, RoundedCornerShape(2.dp))
                )
                Spacer(modifier = Modifier.width(5.dp))
                Text(
                    text = value,
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    fontSize = 10.sp
                )
            }
        }
    }
}
