package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MasterCommodityRepository
import com.example.ui.theme.*

@Composable
fun CommandTerminalScreen() {
    var commandInput by remember { mutableStateOf("") }
    var history by remember {
        mutableStateOf(
            listOf(
                MasterCommodityRepository.executeTerminalCommand("comos status"),
                MasterCommodityRepository.executeTerminalCommand("show me the Brent curve"),
                MasterCommodityRepository.executeTerminalCommand("comos inventory COPPER")
            )
        )
    }

    val quickCommands = listOf(
        "comos quote BRENT",
        "show me the Brent curve",
        "comos inventory COPPER",
        "comos risk portfolio",
        "comos hedge portfolio",
        "stress the book with oil down 30%",
        "what commodities are in backwardation?",
        "show energy spreads"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(horizontal = 14.dp)
    ) {
        Spacer(modifier = Modifier.height(6.dp))

        // Terminal Top Title
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Terminal, contentDescription = "Terminal", tint = MarketGreen, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "COMOS ANALYST & EXECUTABLE CLI",
                    style = MaterialTheme.typography.titleMedium,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = "Provable queries: QUERY • DATA • DATE • METHODOLOGY • ASSUMPTIONS",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextMuted
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Quick Command Suggestion Chips
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(quickCommands) { cmd ->
                Box(
                    modifier = Modifier
                        .background(TerminalSurfaceElevated, RoundedCornerShape(3.dp))
                        .border(0.5.dp, TerminalBorder, RoundedCornerShape(3.dp))
                        .clickable {
                            val resp = MasterCommodityRepository.executeTerminalCommand(cmd)
                            history = history + resp
                        }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = cmd,
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = MarketBlue,
                        fontSize = 10.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Input Box
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = commandInput,
                onValueChange = { commandInput = it },
                placeholder = {
                    Text("e.g., comos quote WTI, show copper inventory risk...", color = TextMuted, fontSize = 12.sp)
                },
                singleLine = true,
                textStyle = MaterialTheme.typography.bodyMedium.copy(
                    fontFamily = FontFamily.Monospace,
                    color = TextPrimary
                ),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = TerminalSurface,
                    unfocusedContainerColor = TerminalSurface,
                    focusedBorderColor = MarketGreen,
                    unfocusedBorderColor = TerminalBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier
                    .weight(1f)
                    .testTag("cli_text_input")
            )

            Spacer(modifier = Modifier.width(8.dp))

            Button(
                onClick = {
                    if (commandInput.isNotBlank()) {
                        val resp = MasterCommodityRepository.executeTerminalCommand(commandInput)
                        history = history + resp
                        commandInput = ""
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = MarketGreenMuted),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier
                    .height(52.dp)
                    .testTag("cli_execute_btn")
            ) {
                Icon(
                    Icons.AutoMirrored.Filled.Send,
                    contentDescription = "Execute",
                    tint = MarketGreen,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // History Output
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(history.reversed()) { item ->
                CliResponseCard(item = item)
            }
            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
fun CliResponseCard(item: MasterCommodityRepository.TerminalCliResponse) {
    Card(
        colors = CardDefaults.cardColors(containerColor = TerminalSurface),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalBorder)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Provenance & Query Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "> ${item.query}",
                    style = MaterialTheme.typography.titleSmall,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = MarketGreen
                )
                Box(
                    modifier = Modifier
                        .background(TerminalSurfaceElevated, RoundedCornerShape(3.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = item.provenance,
                        style = MaterialTheme.typography.labelSmall,
                        color = MarketAmber,
                        fontSize = 9.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Primary Output Block
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurfaceElevated, RoundedCornerShape(4.dp))
                    .padding(10.dp)
            ) {
                Text(
                    text = item.primaryDataBlock,
                    style = MaterialTheme.typography.bodySmall,
                    fontFamily = FontFamily.Monospace,
                    color = TextPrimary
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Metrics Table
            if (item.metrics.isNotEmpty()) {
                item.metrics.forEach { (lbl, valStr) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 1.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = lbl, style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 11.sp)
                        Text(text = valStr, style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 11.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = TerminalBorderSubtle)
            Spacer(modifier = Modifier.height(6.dp))

            // Provenance Transparency Footer
            Text(
                text = "DATE: ${item.date}",
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted,
                fontSize = 8.5.sp
            )
            Text(
                text = "METHODOLOGY: ${item.methodology}",
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted,
                fontSize = 8.5.sp
            )
            Text(
                text = "ASSUMPTIONS: ${item.assumptions}",
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted,
                fontSize = 8.5.sp
            )
        }
    }
}
