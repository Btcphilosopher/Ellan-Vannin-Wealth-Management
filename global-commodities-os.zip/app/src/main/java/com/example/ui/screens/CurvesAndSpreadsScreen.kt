package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MasterCommodityRepository
import com.example.model.CrackCrushSpread
import com.example.model.CurveStructure
import com.example.ui.components.ForwardCurveInteractiveChart
import com.example.ui.theme.*

@Composable
fun CurvesAndSpreadsScreen(
    onSelectCommodity: (String) -> Unit
) {
    val curveSymbols = listOf("BRENT", "WTI", "HG-COPPER", "XAU", "CORN", "HENRY-HUB", "LITHIUM-LCE")
    var selectedSymbol by remember { mutableStateOf("BRENT") }
    val currentCurve = remember(selectedSymbol) {
        MasterCommodityRepository.getForwardCurve(selectedSymbol)
    }

    val spreads = MasterCommodityRepository.crackCrushSpreads

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "FORWARD CURVE & PROCESSING ECONOMICS",
                style = MaterialTheme.typography.titleLarge,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Text(
                text = "Term structure analytics, cost of carry, convenience yields & industrial spreads",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
        }

        // Symbol selector row
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(curveSymbols) { sym ->
                    val isSelected = sym == selectedSymbol
                    Box(
                        modifier = Modifier
                            .background(if (isSelected) MarketBlue else TerminalSurfaceVariant, RoundedCornerShape(4.dp))
                            .border(1.dp, if (isSelected) MarketBlue else TerminalBorder, RoundedCornerShape(4.dp))
                            .clickable { selectedSymbol = sym }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                            .testTag("curve_tab_$sym")
                    ) {
                        Text(
                            text = sym,
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) TerminalBackground else TextSecondary
                        )
                    }
                }
            }
        }

        // Interactive Forward Curve Display
        item {
            ForwardCurveInteractiveChart(
                symbol = currentCurve.symbol,
                tenors = currentCurve.tenors,
                structure = currentCurve.overallStructure,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
            )
        }

        // Curve Structural Analytics Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "ECONOMIC CARRY & STRUCTURE DECOMPOSITION",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = currentCurve.structuralDriver,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        DetailStatBox(label = "Prompt Spot", value = "$${String.format("%.2f", currentCurve.spotPrice)}")
                        DetailStatBox(label = "12M Forward", value = "$${String.format("%.2f", currentCurve.tenors.first { it.months == 12 }.price)}")
                        DetailStatBox(label = "Dec/Jan Spread", value = "$${String.format("%.2f", currentCurve.calendarSpreadDecJan)}")
                        DetailStatBox(
                            label = "Annualized Carry",
                            value = "${String.format("%.2f", currentCurve.annualizedCarryPct)}%",
                            valueColor = if (currentCurve.overallStructure == CurveStructure.CONTANGO) MarketBlue else MarketAmber
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = TerminalBorderSubtle)
                    Spacer(modifier = Modifier.height(10.dp))

                    // Tenor Schedule Table
                    Text(
                        text = "TENOR PRICING & CARRY BREAKDOWN:",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    currentCurve.tenors.forEach { tenor ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "${tenor.label} (${tenor.months}M)", style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace, color = TextSecondary)
                            Text(text = "$${String.format("%.2f", tenor.price)}", style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = TextPrimary)
                            Text(
                                text = tenor.structure.name.take(4),
                                style = MaterialTheme.typography.labelSmall,
                                color = if (tenor.structure == CurveStructure.CONTANGO) MarketBlue else if (tenor.structure == CurveStructure.BACKWARDATION) MarketAmber else TextMuted
                            )
                        }
                    }
                }
            }
        }

        // Section: Industrial Processing Spreads (Crack, Crush, Spark)
        item {
            Text(
                text = "INTER-COMMODITY TRANSFORMATION & SPREADS",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "Processing economics for oil refineries, grain crushers, power utilities & arbitrage",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
        }

        items(spreads) { spread ->
            SpreadCard(spread = spread)
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun SpreadCard(spread: CrackCrushSpread) {
    Card(
        colors = CardDefaults.cardColors(containerColor = TerminalSurface),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalBorder)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = spread.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = "${String.format("%.2f", spread.value)} ${spread.unit}",
                    style = MaterialTheme.typography.titleMedium,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = MarketGreen
                )
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Formula: ${spread.formula}",
                style = MaterialTheme.typography.labelSmall,
                fontFamily = FontFamily.Monospace,
                color = MarketBlue
            )

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Inputs: ${spread.inputDescription}",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
            Text(
                text = "Outputs: ${spread.outputDescription}",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            Spacer(modifier = Modifier.height(8.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurfaceElevated, RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                Text(
                    text = "Signal: ${spread.economicSignal}",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextPrimary,
                    fontSize = 11.5.sp
                )
            }
        }
    }
}
