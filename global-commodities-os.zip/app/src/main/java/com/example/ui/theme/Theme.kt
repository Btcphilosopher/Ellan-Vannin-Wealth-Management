package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val ComosDarkColorScheme = darkColorScheme(
    primary = MarketBlue,
    onPrimary = TerminalBackground,
    primaryContainer = MarketBlueMuted,
    onPrimaryContainer = TextPrimary,
    secondary = MarketAmber,
    onSecondary = TerminalBackground,
    secondaryContainer = MarketAmberMuted,
    onSecondaryContainer = TextPrimary,
    tertiary = MarketGold,
    background = TerminalBackground,
    onBackground = TextPrimary,
    surface = TerminalSurface,
    onSurface = TextPrimary,
    surfaceVariant = TerminalSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = TerminalBorder,
    outlineVariant = TerminalBorderSubtle,
    error = MarketRed,
    onError = TextPrimary,
    errorContainer = MarketRedMuted,
    onErrorContainer = TextPrimary
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    // COMOS always enforces the dark institutional terminal environment
    val colorScheme = ComosDarkColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = TerminalBackground.toArgb()
            window.navigationBarColor = TerminalBackground.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
