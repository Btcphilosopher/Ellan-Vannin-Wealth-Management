package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Institutional Commodity House Palette
// London commodity house × Singapore trading desk × Rotterdam energy terminal × Chicago futures
val TerminalBackground = Color(0xFF090D16)      // Deepest Obsidian Navy
val TerminalSurface = Color(0xFF0F172A)         // Deep Slate Navy
val TerminalSurfaceVariant = Color(0xFF1E293B)  // Charcoal Steel
val TerminalSurfaceElevated = Color(0xFF26334D) // Elevated Panel
val TerminalBorder = Color(0xFF334155)          // Steel Border
val TerminalBorderSubtle = Color(0xFF1E293B)    // Subtle Divider

// Typography & Text
val TextPrimary = Color(0xFFF8FAFC)            // Paper White
val TextSecondary = Color(0xFF94A3B8)          // Graphite / Muted Slate
val TextMuted = Color(0xFF64748B)              // Deep Muted

// Market Status & Accents (Restrained institutional tones)
val MarketGreen = Color(0xFF10B981)            // Emerald Green (Up / Surplus)
val MarketGreenMuted = Color(0xFF064E3B)
val MarketRed = Color(0xFFF43F5E)              // Crimson Rose (Down / Deficit)
val MarketRedMuted = Color(0xFF881337)
val MarketAmber = Color(0xFFF59E0B)            // Warning / Alert / Backwardation
val MarketAmberMuted = Color(0xFF78350F)
val MarketBlue = Color(0xFF38BDF8)             // Cyan / Benchmark / Logistics
val MarketBlueMuted = Color(0xFF0369A1)
val MarketGold = Color(0xFFEAB308)             // Gold / Premium benchmark

// Sector Specific Accents
val SectorEnergy = Color(0xFFF97316)           // Flame Orange
val SectorPrecious = Color(0xFFFACC15)         // Gold
val SectorBaseMetals = Color(0xFF38BDF8)       // Copper/Steel Cyan
val SectorFerrous = Color(0xFF94A3B8)          // Raw Steel
val SectorCritical = Color(0xFFA855F7)         // Critical Minerals Violet
val SectorAgriculture = Color(0xFF84CC16)      // Crop Lime
val SectorLivestock = Color(0xFFEC4899)        // Cattle Rose
val SectorChemical = Color(0xFF06B6D4)         // Ammonia / Chemical Teal
val SectorEnvironmental = Color(0xFF10B981)    // Carbon / REC Emerald
