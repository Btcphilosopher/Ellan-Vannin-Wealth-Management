package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CurveStructure
import com.example.model.DataProvenance
import com.example.model.ForwardTenor
import com.example.model.MarketBasis
import com.example.ui.theme.*

@Composable
fun TerminalTopBar(
    activeScreenName: String,
    onQuickSearchClick: () -> Unit = {}
) {
    Surface(
        color = TerminalSurface,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(MarketGreen, RoundedCornerShape(2.dp))
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "COMOS",
                        style = MaterialTheme.typography.titleLarge,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "GLOBAL COMMODITIES OS",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted,
                        letterSpacing = 0.5.sp
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .background(TerminalSurfaceElevated, RoundedCornerShape(4.dp))
                            .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "UTC 08:00 | LDN / NYC / SGP",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Sub-header ticker with institutional macro alerts
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "ACTIVE TERMINAL: ",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted
                    )
                    Text(
                        text = activeScreenName.uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MarketBlue
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .background(MarketAmberMuted.copy(alpha = 0.5f), RoundedCornerShape(3.dp))
                            .padding(horizontal = 5.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "CHOKEPOINT: SUEZ ADVISORY",
                            style = MaterialTheme.typography.labelSmall,
                            color = MarketAmber,
                            fontSize = 8.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .background(TerminalSurfaceVariant, RoundedCornerShape(3.dp))
                            .padding(horizontal = 5.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "REV 3.7 EXEC",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted,
                            fontSize = 8.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ProvenanceBadge(provenance: DataProvenance) {
    val (bg, fg) = when (provenance) {
        DataProvenance.EXCHANGE, DataProvenance.OFFICIAL -> Pair(TerminalSurfaceElevated, MarketBlue)
        DataProvenance.LICENSED, DataProvenance.TRANSACTION -> Pair(TerminalSurfaceElevated, MarketGreen)
        DataProvenance.VERIFIED -> Pair(TerminalSurfaceElevated, MarketGold)
        DataProvenance.ASSESSED -> Pair(TerminalSurfaceElevated, MarketAmber)
        DataProvenance.MODELLED, DataProvenance.SIMULATED -> Pair(TerminalSurfaceElevated, TextSecondary)
        DataProvenance.SYNTHETIC -> Pair(TerminalSurfaceElevated, TextMuted)
        else -> Pair(TerminalSurfaceElevated, TextMuted)
    }

    Box(
        modifier = Modifier
            .background(bg, RoundedCornerShape(3.dp))
            .border(0.5.dp, fg.copy(alpha = 0.6f), RoundedCornerShape(3.dp))
            .padding(horizontal = 5.dp, vertical = 2.dp)
    ) {
        Text(
            text = provenance.code,
            style = MaterialTheme.typography.labelSmall,
            color = fg,
            fontWeight = FontWeight.Bold,
            fontSize = 9.sp
        )
    }
}

@Composable
fun BasisBadge(basis: MarketBasis) {
    Box(
        modifier = Modifier
            .background(TerminalSurfaceVariant, RoundedCornerShape(3.dp))
            .border(0.5.dp, TerminalBorder, RoundedCornerShape(3.dp))
            .padding(horizontal = 4.dp, vertical = 2.dp)
    ) {
        Text(
            text = basis.code,
            style = MaterialTheme.typography.labelSmall,
            color = TextSecondary,
            fontSize = 9.sp
        )
    }
}

@Composable
fun PriceMetricBadge(
    price: Double,
    change24h: Double,
    change24hPct: Double,
    currency: String,
    unit: String
) {
    val isUp = change24h > 0
    val isFlat = kotlin.math.abs(change24h) < 0.0001
    val color = if (isFlat) TextSecondary else if (isUp) MarketGreen else MarketRed
    val arrow = if (isFlat) "→" else if (isUp) "↑" else "↓"

    Column(horizontalAlignment = Alignment.End) {
        Text(
            text = "${if (currency == "USD") "$" else if (currency == "EUR") "€" else ""}${String.format(if (price >= 100) "%,.2f" else "%,.3f", price)}",
            style = MaterialTheme.typography.labelLarge,
            color = TextPrimary,
            fontWeight = FontWeight.Bold
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "$arrow ${if (change24h > 0) "+" else ""}${String.format("%.2f", change24h)} (${String.format("%.2f", change24hPct)}%)",
                style = MaterialTheme.typography.labelSmall,
                color = color,
                fontWeight = FontWeight.Medium
            )
        }
        Text(
            text = "$currency / $unit",
            style = MaterialTheme.typography.labelSmall,
            color = TextMuted,
            fontSize = 9.sp
        )
    }
}

@Composable
fun ForwardCurveInteractiveChart(
    symbol: String,
    tenors: List<ForwardTenor>,
    structure: CurveStructure,
    modifier: Modifier = Modifier
        .fillMaxWidth()
        .height(180.dp)
) {
    val curveColor = when (structure) {
        CurveStructure.CONTANGO -> MarketBlue
        CurveStructure.BACKWARDATION -> MarketAmber
        CurveStructure.FLAT -> TextSecondary
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = TerminalSurface),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalBorder)),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "$symbol FORWARD CURVE",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .background(curveColor.copy(alpha = 0.15f), RoundedCornerShape(3.dp))
                            .border(1.dp, curveColor.copy(alpha = 0.4f), RoundedCornerShape(3.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = structure.name,
                            style = MaterialTheme.typography.labelSmall,
                            color = curveColor,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                val minPrice = tenors.minOfOrNull { it.price } ?: 0.0
                val maxPrice = tenors.maxOfOrNull { it.price } ?: 100.0
                Text(
                    text = "Range: $${String.format("%.2f", minPrice)} - $${String.format("%.2f", maxPrice)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextMuted
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Canvas Forward Curve Plot
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    if (tenors.isEmpty()) return@Canvas

                    val w = size.width
                    val h = size.height
                    val paddingBottom = 22f
                    val paddingTop = 10f
                    val availableHeight = h - paddingBottom - paddingTop

                    val minP = (tenors.minOf { it.price } * 0.985).toFloat()
                    val maxP = (tenors.maxOf { it.price } * 1.015).toFloat()
                    val pRange = if (maxP - minP > 0.001f) maxP - minP else 1.0f

                    val stepX = w / (tenors.size - 1)
                    val points = mutableListOf<Offset>()

                    tenors.forEachIndexed { i, t ->
                        val x = i * stepX
                        val normY = (t.price.toFloat() - minP) / pRange
                        val y = paddingTop + (availableHeight * (1f - normY))
                        points.add(Offset(x, y))
                    }

                    // Draw grid reference lines
                    val gridLines = 3
                    for (g in 0..gridLines) {
                        val yGrid = paddingTop + (availableHeight * (g.toFloat() / gridLines))
                        drawLine(
                            color = Color(0xFF26334D),
                            start = Offset(0f, yGrid),
                            end = Offset(w, yGrid),
                            strokeWidth = 1f
                        )
                    }

                    // Fill curve area
                    val fillPath = Path().apply {
                        moveTo(points.first().x, points.first().y)
                        for (i in 1 until points.size) {
                            lineTo(points[i].x, points[i].y)
                        }
                        lineTo(points.last().x, h - paddingBottom)
                        lineTo(points.first().x, h - paddingBottom)
                        close()
                    }
                    drawPath(
                        path = fillPath,
                        color = curveColor.copy(alpha = 0.12f)
                    )

                    // Draw curve stroke
                    for (i in 0 until points.size - 1) {
                        drawLine(
                            color = curveColor,
                            start = points[i],
                            end = points[i + 1],
                            strokeWidth = 3f,
                            cap = StrokeCap.Round
                        )
                    }

                    // Draw point nodes
                    points.forEach { pt ->
                        drawCircle(
                            color = curveColor,
                            radius = 4.5f,
                            center = pt
                        )
                        drawCircle(
                            color = Color(0xFF090D16),
                            radius = 2.5f,
                            center = pt
                        )
                    }
                }
            }

            // X-Axis Tenor Labels Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                tenors.forEach { t ->
                    Text(
                        text = t.label,
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted,
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

@Composable
fun SimpleSparkline(
    isPositive: Boolean,
    modifier: Modifier = Modifier
        .width(55.dp)
        .height(24.dp)
) {
    val color = if (isPositive) MarketGreen else MarketRed
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val path = Path()

        // Deterministic stylized sparkline curve
        val samples = if (isPositive) {
            listOf(0.7f, 0.65f, 0.8f, 0.5f, 0.55f, 0.4f, 0.3f, 0.15f)
        } else {
            listOf(0.2f, 0.35f, 0.25f, 0.45f, 0.6f, 0.55f, 0.75f, 0.9f)
        }

        val stepX = w / (samples.size - 1)
        samples.forEachIndexed { i, s ->
            val x = i * stepX
            val y = h * s
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }

        drawPath(
            path = path,
            color = color,
            style = Stroke(width = 2.5f, cap = StrokeCap.Round)
        )
    }
}
