package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MasterCommodityRepository
import com.example.model.Sector
import com.example.model.SpotPriceQuote
import com.example.ui.components.BasisBadge
import com.example.ui.components.PriceMetricBadge
import com.example.ui.components.ProvenanceBadge
import com.example.ui.components.SimpleSparkline
import com.example.ui.theme.*

@Composable
fun MarketsScreen(
    onSelectCommodity: (String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedSector by remember { mutableStateOf<Sector?>(null) }

    val allQuotes = MasterCommodityRepository.spotQuotes
    val filteredQuotes = remember(searchQuery, selectedSector) {
        allQuotes.filter { quote ->
            val matchesSector = selectedSector == null || quote.category == selectedSector
            val matchesSearch = searchQuery.isBlank() ||
                    quote.symbol.contains(searchQuery, ignoreCase = true) ||
                    quote.name.contains(searchQuery, ignoreCase = true) ||
                    quote.location.contains(searchQuery, ignoreCase = true)
            matchesSector && matchesSearch
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(horizontal = 14.dp)
    ) {
        Spacer(modifier = Modifier.height(8.dp))

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search commodity, symbol, location...", color = TextMuted) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = TextSecondary) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(Icons.Default.Clear, contentDescription = "Clear", tint = TextMuted)
                    }
                }
            },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = TerminalSurface,
                unfocusedContainerColor = TerminalSurface,
                focusedBorderColor = MarketBlue,
                unfocusedBorderColor = TerminalBorder,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            ),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("markets_search_input")
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Sector Filter Chips
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            item {
                SectorFilterChip(
                    label = "ALL BENCHMARKS (${allQuotes.size})",
                    isSelected = selectedSector == null,
                    onClick = { selectedSector = null }
                )
            }
            items(Sector.values()) { sector ->
                val count = allQuotes.count { it.category == sector }
                if (count > 0) {
                    SectorFilterChip(
                        label = "${sector.displayName.uppercase()} ($count)",
                        isSelected = selectedSector == sector,
                        onClick = { selectedSector = sector }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Header Metrics Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurfaceElevated, RoundedCornerShape(4.dp))
                .padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "INSTRUMENT / BASIS",
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted
            )
            Text(
                text = "BID / ASK",
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted
            )
            Text(
                text = "SETTLEMENT / BASIS",
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Market Quotes List
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(filteredQuotes) { quote ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalBorder)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectCommodity(quote.symbol) }
                        .testTag("market_item_${quote.symbol}")
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1.2f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = quote.symbol,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    ProvenanceBadge(quote.provenance)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    BasisBadge(quote.basis)
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "${quote.name} • ${quote.location}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary,
                                    maxLines = 1
                                )
                            }

                            // Bid / Ask spread block
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .weight(0.9f)
                                    .padding(horizontal = 6.dp)
                            ) {
                                Text(
                                    text = "B: ${String.format("%.2f", quote.bid)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondary
                                )
                                Text(
                                    text = "A: ${String.format("%.2f", quote.ask)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondary
                                )
                                Text(
                                    text = "Sprd: ${String.format("%.3f", quote.ask - quote.bid)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextMuted,
                                    fontSize = 8.5.sp
                                )
                            }

                            // Price and Change Badge
                            PriceMetricBadge(
                                price = quote.price,
                                change24h = quote.change24h,
                                change24hPct = quote.change24hPct,
                                currency = quote.currency,
                                unit = quote.unit
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        HorizontalDivider(color = TerminalBorderSubtle)
                        Spacer(modifier = Modifier.height(6.dp))

                        // Extra execution stats: 24h Vol, Open Interest, Range
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "24h Vol: ${String.format("%,d", quote.volume24h)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted,
                                fontSize = 9.sp
                            )
                            Text(
                                text = "OI: ${String.format("%,d", quote.openInterest)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted,
                                fontSize = 9.sp
                            )
                            Text(
                                text = "Range: ${quote.low24h} - ${quote.high24h}",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted,
                                fontSize = 9.sp
                            )
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
fun SectorFilterChip(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val bg = if (isSelected) MarketBlue else TerminalSurfaceVariant
    val fg = if (isSelected) TerminalBackground else TextSecondary
    val border = if (isSelected) MarketBlue else TerminalBorder

    Box(
        modifier = Modifier
            .background(bg, RoundedCornerShape(4.dp))
            .border(1.dp, border, RoundedCornerShape(4.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = fg
        )
    }
}
