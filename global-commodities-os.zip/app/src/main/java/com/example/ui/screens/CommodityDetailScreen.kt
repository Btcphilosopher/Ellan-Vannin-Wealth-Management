package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MasterCommodityRepository
import com.example.engine.Black76OptionsEngine
import com.example.engine.PricingAndBasisEngine
import com.example.model.OptionType
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun CommodityDetailScreen(
    symbol: String,
    onBack: () -> Unit
) {
    val master = MasterCommodityRepository.commodities.firstOrNull { it.symbol == symbol }
        ?: MasterCommodityRepository.commodities.first()
    val quote = MasterCommodityRepository.spotQuotes.firstOrNull { it.symbol == symbol }
        ?: MasterCommodityRepository.spotQuotes.first()
    val curve = MasterCommodityRepository.getForwardCurve(symbol)
    val lots = MasterCommodityRepository.physicalLots.filter { it.symbol == symbol }
    val sdb = MasterCommodityRepository.supplyDemandBalances.firstOrNull { it.commoditySymbol == symbol }

    // State for interactive delivered basis calculator
    var locationBasisDelta by remember { mutableStateOf(2.50) }
    var freightRateDelta by remember { mutableStateOf(1.85) }
    var qualityPremiumDelta by remember { mutableStateOf(0.40) }

    val deliveredPrice = PricingAndBasisEngine.calculateDeliveredPrice(
        benchmarkPrice = quote.price,
        locationBasis = locationBasisDelta,
        qualityDifferential = qualityPremiumDelta,
        freight = freightRateDelta,
        storageCost = 0.45,
        insuranceCost = 0.12,
        financingTax = 0.28,
        destination = "East Asia / ARA Destination Port"
    )

    // State for Black-76 Option Calculator
    var optionStrikeMultiplier by remember { mutableStateOf(1.0) } // At The Money (100%)
    var optionExpiryMonths by remember { mutableStateOf(3.0) }
    var optionVolatilityPct by remember { mutableStateOf(28.0) }

    val forward3M = curve.tenors.firstOrNull { it.months == 3 }?.price ?: quote.price
    val strike = forward3M * optionStrikeMultiplier
    val greeksCall = Black76OptionsEngine.calculateGreeks(
        forwardPrice = forward3M,
        strike = strike,
        timeToExpiryYears = optionExpiryMonths / 12.0,
        riskFreeRate = 0.048,
        volatility = optionVolatilityPct / 100.0,
        type = OptionType.CALL
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(6.dp))
            // Back navigation & Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.testTag("commodity_detail_back_btn")
                ) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = TextPrimary
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = master.symbol,
                            style = MaterialTheme.typography.titleLarge,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        ProvenanceBadge(quote.provenance)
                        Spacer(modifier = Modifier.width(4.dp))
                        BasisBadge(quote.basis)
                    }
                    Text(
                        text = "${master.name} (${master.nameCn}) • ${master.category.displayName}",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        }

        // Spot & Execution Metrics Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "SPOT SETTLEMENT",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "${if (quote.currency == "USD") "$" else "€"}${String.format(if (quote.price >= 100) "%,.2f" else "%,.3f", quote.price)}",
                                style = MaterialTheme.typography.headlineMedium,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "${quote.currency} per ${quote.unit} • ${quote.deliveryTerm}",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondary
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            val isUp = quote.change24h >= 0
                            val col = if (isUp) MarketGreen else MarketRed
                            val sign = if (isUp) "+" else ""
                            Text(
                                text = "$sign${String.format("%.2f", quote.change24h)} ($sign${String.format("%.2f", quote.change24hPct)}%)",
                                style = MaterialTheme.typography.titleMedium,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = col
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Bid: ${quote.bid} | Ask: ${quote.ask}",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted
                            )
                            Text(
                                text = "Spread: ${String.format("%.3f", quote.ask - quote.bid)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MarketBlue
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = TerminalBorderSubtle)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        DetailStatBox(label = "24h Volume", value = "${String.format("%,d", quote.volume24h)}")
                        DetailStatBox(label = "Open Interest", value = "${String.format("%,d", quote.openInterest)}")
                        DetailStatBox(label = "24h Low", value = "${quote.low24h}")
                        DetailStatBox(label = "24h High", value = "${quote.high24h}")
                    }
                }
            }
        }

        // Forward Curve Canvas
        item {
            ForwardCurveInteractiveChart(
                symbol = master.symbol,
                tenors = curve.tenors,
                structure = curve.overallStructure
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Structure Driver: ${curve.structuralDriver}",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                fontSize = 11.5.sp
            )
        }

        // Physical Specification Engine Card (Specification 3)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Info,
                            contentDescription = "Spec",
                            tint = MarketGold,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "PHYSICAL SPECIFICATION & QUALITY STANDARDS",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Standard: ${master.qualityStandard}",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextPrimary
                    )
                    Text(
                        text = "Tolerance: ${master.specification.qualityTolerance}",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Chemical Composition Table
                    if (master.specification.chemicalComposition.isNotEmpty()) {
                        Text(
                            text = "ASSAY & CHEMICAL COMPOSITION LIMITS:",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        master.specification.chemicalComposition.forEach { (elem, limit) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 2.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = elem, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                                Text(text = limit, style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = TextPrimary)
                            }
                        }
                    }
                }
            }
        }

        // Location Basis & Delivered Price Engine (Specification 11)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Calculate, contentDescription = "Basis", tint = MarketBlue, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "LOCATION BASIS & DELIVERED PRICE",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }
                        Text(
                            text = "DELIVERED INCOTERM",
                            style = MaterialTheme.typography.labelSmall,
                            color = MarketGreen
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Delivered Price Calculation Breakdown
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(TerminalSurfaceElevated, RoundedCornerShape(4.dp))
                            .padding(10.dp)
                    ) {
                        BasisRow(label = "Benchmark Reference Price", value = "$${String.format("%.2f", deliveredPrice.benchmarkPrice)}")
                        BasisRow(label = "+ Location Basis Differential", value = "+$${String.format("%.2f", deliveredPrice.locationBasis)}")
                        BasisRow(label = "+ Ocean / Pipeline Freight", value = "+$${String.format("%.2f", deliveredPrice.freight)}")
                        BasisRow(label = "+ Quality Assay Differential", value = "+$${String.format("%.2f", deliveredPrice.qualityPremiumDiscount)}")
                        BasisRow(label = "+ Storage & Terminal Throughput", value = "+$${String.format("%.2f", deliveredPrice.storageCost)}")
                        BasisRow(label = "+ Cargo Insurance & Financing", value = "+$${String.format("%.2f", deliveredPrice.insurance + deliveredPrice.taxFinancing)}")
                        HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp), color = TerminalBorder)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "= Delivered CIF Price (${deliveredPrice.destination})",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "$${String.format("%.2f", deliveredPrice.deliveredPrice)} / ${quote.unit}",
                                style = MaterialTheme.typography.titleSmall,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = MarketBlue
                            )
                        }
                    }
                }
            }
        }

        // Physical Lots in Inventory (Lot Engine - Specification 4 & 5)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "PHYSICAL LOT INVENTORY (${lots.size} REGISTERED LOTS)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Double-selling prevention enforced through cryptographic lot status transitions.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    if (lots.isEmpty()) {
                        Text(
                            text = "No prompt warehouse lots allocated for this symbol. See global warehouse terminal for pipeline nominations.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    } else {
                        lots.forEach { lot ->
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp)
                                    .background(TerminalSurfaceElevated, RoundedCornerShape(4.dp))
                                    .padding(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = lot.lotId,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary
                                    )
                                    Box(
                                        modifier = Modifier
                                            .background(MarketGreen.copy(alpha = 0.2f), RoundedCornerShape(3.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = lot.status.name,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MarketGreen,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Quantity: ${String.format("%,.0f", lot.quantity)} ${lot.unit} • ${lot.producer}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                                Text(
                                    text = "Warehouse: ${lot.warehouseName} • Cert: ${lot.qualityCertificateId}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextMuted
                                )
                            }
                        }
                    }
                }
            }
        }

        // Supply & Demand Fundamentals (Specification 40)
        item {
            if (sdb != null) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalBorder)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "ANNUAL GLOBAL SUPPLY & DEMAND BALANCE",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            DetailStatBox(label = "Global Production", value = "${sdb.productionMmt} Mmt")
                            DetailStatBox(label = "Global Demand", value = "${sdb.consumptionMmt} Mmt")
                            DetailStatBox(
                                label = "Net Balance",
                                value = "${if (sdb.balanceMmt >= 0) "+" else ""}${sdb.balanceMmt} Mmt",
                                valueColor = if (sdb.balanceMmt >= 0) MarketGreen else MarketRed
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            DetailStatBox(label = "Stock-to-Use", value = "${sdb.stockToUseRatioPct}%")
                            DetailStatBox(label = "Days of Supply", value = "${sdb.daysOfSupply} days")
                            DetailStatBox(label = "Annual Growth", value = "+${sdb.annualGrowthPct}%")
                        }
                    }
                }
            }
        }

        // Quantitative Options & Greeks (Black-76 Engine - Specification 15)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "BLACK-76 OPTIONS & SENSITIVITY GREEKS",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "ATM 3-Month Call (F: $${String.format("%.2f", forward3M)} | K: $${String.format("%.2f", strike)} | IV: ${optionVolatilityPct}%)",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        DetailStatBox(label = "Premium", value = "$${String.format("%.3f", greeksCall.price)}", valueColor = MarketGreen)
                        DetailStatBox(label = "Delta (Δ)", value = String.format("%.3f", greeksCall.delta))
                        DetailStatBox(label = "Gamma (Γ)", value = String.format("%.4f", greeksCall.gamma))
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        DetailStatBox(label = "Vega (ν)", value = String.format("%.3f", greeksCall.vega))
                        DetailStatBox(label = "Theta (θ)", value = String.format("%.4f/d", greeksCall.theta))
                        DetailStatBox(label = "Rho (ρ)", value = String.format("%.4f", greeksCall.rho))
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun DetailStatBox(
    label: String,
    value: String,
    valueColor: Color = TextPrimary
) {
    Column {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = TextMuted,
            fontSize = 9.sp
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.labelMedium,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            color = valueColor
        )
    }
}

@Composable
fun BasisRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        Text(text = value, style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace, color = TextPrimary)
    }
}
