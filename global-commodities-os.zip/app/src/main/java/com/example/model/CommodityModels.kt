package com.example.model

enum class Sector(val displayName: String) {
    ENERGY("Energy"),
    PRECIOUS_METALS("Precious Metals"),
    BASE_METALS("Base Metals"),
    FERROUS("Ferrous & Steel"),
    BATTERY_CRITICAL("Battery & Critical"),
    AGRICULTURE("Agriculture"),
    LIVESTOCK("Livestock"),
    SOFT_COMMODITIES("Softs"),
    INDUSTRIAL_CHEMICAL("Chemicals & Ind."),
    ENVIRONMENTAL("Environmental")
}

enum class PhysicalForm(val displayName: String) {
    LIQUID_HYDROCARBON("Liquid Hydrocarbon"),
    COMPRESSED_GAS("Compressed Gas"),
    CRYOGENIC_LIQUID("Cryogenic Liquid"),
    SOLID_BULK("Solid Bulk"),
    REFINED_INGOT("Refined Ingot"),
    CATHODE("Cathode (Grade A)"),
    CONCENTRATE("Mineral Concentrate"),
    AGRICULTURAL_GRAIN("Bulk Grain"),
    BALED_FIBER("Baled Fiber"),
    LIVE_ANIMAL("Live Animals"),
    ENVIRONMENTAL_CREDIT("Registry Credit")
}

enum class DataProvenance(val code: String, val label: String) {
    OFFICIAL("OFF", "Official Standard"),
    LICENSED("LIC", "Licensed Benchmark"),
    EXCHANGE("EXCH", "Exchange Verified"),
    TRANSACTION("TXN", "Confirmed Trade"),
    VERIFIED("VRF", "Verified Physical"),
    OBSERVED("OBS", "Observed Bid/Offer"),
    DERIVED("DER", "Derived Basis"),
    ASSESSED("ASS", "Assessed Index"),
    MODELLED("MOD", "Engine Modelled"),
    SIMULATED("SIM", "Discrete-Event Simulation"),
    SYNTHETIC("SYN", "Synthetic Calibrated")
}

enum class MarketBasis(val code: String, val description: String) {
    FOB("FOB", "Free on Board"),
    CIF("CIF", "Cost, Insurance & Freight"),
    CFR("CFR", "Cost and Freight"),
    DES("DES", "Delivered Ex Ship"),
    DAP("DAP", "Delivered at Place"),
    EXW("EXW", "Ex Works"),
    BENCHMARK("BMK", "Terminal Benchmark Reference"),
    ASSESSED("ASS", "Institutional Methodology Assessment")
}

enum class CurveStructure(val label: String) {
    CONTANGO("Contango (Carry Premium)"),
    BACKWARDATION("Backwardation (Scarcity Premium)"),
    FLAT("Flat Curve")
}

enum class LotStatus(val displayName: String) {
    PRODUCED("Produced"),
    IN_STORAGE("In Storage"),
    AVAILABLE("Available for Trade"),
    RESERVED("Reserved"),
    CONTRACTED("Contracted"),
    IN_TRANSIT("In Transit"),
    DELIVERED("Delivered"),
    SETTLED("Settled"),
    QUALITY_HOLD("Quality Hold"),
    DISPUTED("Disputed")
}

data class CommoditySpecification(
    val grade: String,
    val purityPct: Double? = null,
    val apiGravity: Double? = null,
    val sulphurPct: Double? = null,
    val feContentPct: Double? = null,
    val cuContentPct: Double? = null,
    val proteinPct: Double? = null,
    val moisturePct: Double? = null,
    val energyContentBtu: Double? = null,
    val density: Double? = null,
    val qualityTolerance: String,
    val chemicalComposition: Map<String, String> = emptyMap()
)

data class CommodityMaster(
    val id: String,
    val symbol: String,
    val name: String,
    val nameEn: String,
    val nameCn: String,
    val category: Sector,
    val subCategory: String,
    val physicalForm: PhysicalForm,
    val unit: String,
    val currency: String,
    val benchmark: String,
    val exchange: String,
    val country: String,
    val region: String,
    val qualityStandard: String,
    val deliveryStandard: String,
    val storageClass: String,
    val specification: CommoditySpecification
)

data class SpotPriceQuote(
    val commodityId: String,
    val symbol: String,
    val name: String,
    val price: Double,
    val change24h: Double,
    val change24hPct: Double,
    val currency: String,
    val unit: String,
    val basis: MarketBasis,
    val location: String,
    val deliveryTerm: String,
    val timestamp: String,
    val provenance: DataProvenance,
    val bid: Double,
    val ask: Double,
    val volume24h: Long,
    val openInterest: Long,
    val high24h: Double,
    val low24h: Double,
    val category: Sector
)

data class LocationBasis(
    val benchmarkPrice: Double,
    val locationBasis: Double,
    val qualityPremiumDiscount: Double,
    val freight: Double,
    val storageCost: Double,
    val insurance: Double,
    val taxFinancing: Double,
    val deliveredPrice: Double,
    val destination: String
)

data class ForwardTenor(
    val label: String,
    val months: Int,
    val price: Double,
    val carryCost: Double,
    val convenienceYield: Double,
    val structure: CurveStructure
)

data class ForwardCurve(
    val commodityId: String,
    val symbol: String,
    val spotPrice: Double,
    val tenors: List<ForwardTenor>,
    val overallStructure: CurveStructure,
    val calendarSpreadDecJan: Double,
    val annualizedCarryPct: Double,
    val structuralDriver: String
)

enum class SpreadType {
    CRACK_321,
    CRUSH_SOYBEAN,
    SPARK_GAS_POWER,
    GOLD_SILVER_RATIO,
    COPPER_ALUMINIUM_RATIO,
    BRENT_WTI_ARBITRAGE
}

data class CrackCrushSpread(
    val type: SpreadType,
    val name: String,
    val inputDescription: String,
    val outputDescription: String,
    val formula: String,
    val value: Double,
    val unit: String,
    val historicalMean: Double,
    val economicSignal: String
)

enum class OptionType { CALL, PUT }
enum class OptionStyle { EUROPEAN, AMERICAN, ASIAN }

data class CommodityOptionQuote(
    val id: String,
    val commoditySymbol: String,
    val strikePrice: Double,
    val expiryMonths: Double,
    val optionType: OptionType,
    val optionStyle: OptionStyle,
    val underlyingPrice: Double,
    val impliedVol: Double,
    val premium: Double,
    val delta: Double,
    val gamma: Double,
    val vega: Double,
    val theta: Double,
    val rho: Double
)

data class CommodityLot(
    val lotId: String,
    val commodityId: String,
    val symbol: String,
    val specificationSummary: String,
    val quantity: Double,
    val unit: String,
    val origin: String,
    val producer: String,
    val productionDate: String,
    val warehouseId: String,
    val warehouseName: String,
    val owner: String,
    val qualityCertificateId: String,
    val status: LotStatus
)

enum class FacilityType {
    TERMINAL, STORAGE_TANK, SILO, MINE_STOCKPILE, REFINERY, SMELTER, PORT, PIPELINE, DEPOT
}

data class WarehouseFacility(
    val id: String,
    val name: String,
    val type: FacilityType,
    val location: String,
    val country: String,
    val owner: String,
    val totalCapacity: Double,
    val onHandQuantity: Double,
    val reservedQuantity: Double,
    val contractedQuantity: Double,
    val quarantinedQuantity: Double,
    val unit: String,
    val storageCostPerDay: Double,
    val throughputMtd: Double,
    val insurancePolicyNo: String
) {
    val availableCapacity: Double
        get() = (totalCapacity - onHandQuantity).coerceAtLeast(0.0)

    val availableDeliverableInventory: Double
        get() = (onHandQuantity - reservedQuantity - contractedQuantity - quarantinedQuantity).coerceAtLeast(0.0)

    val utilizationPct: Double
        get() = if (totalCapacity > 0) (onHandQuantity / totalCapacity) * 100.0 else 0.0
}

enum class LogisticsCarrierType {
    TANKER_VLCC, BULK_CARRIER_CAPESIZE, BULK_CARRIER_PANAMAX, LNG_CARRIER, PIPELINE, CONTAINER_SHIP, RAIL_CONSIST, TRUCK_CONVOY
}

enum class ShipmentStatus {
    LOADING, IN_TRANSIT, CHOKEPOINT_TRANSIT, ANCHORAGE, DISCHARGING, COMPLETED
}

data class LogisticsShipment(
    val shipmentId: String,
    val cargoDescription: String,
    val commoditySymbol: String,
    val carrierType: LogisticsCarrierType,
    val vesselOrId: String,
    val originPort: String,
    val destinationPort: String,
    val etaDate: String,
    val quantity: Double,
    val unit: String,
    val freightRate: Double,
    val freightUnit: String,
    val demurragePerDay: Double,
    val status: ShipmentStatus,
    val routeChokepoint: String,
    val carbonTonnage: Double
)

enum class PositionType {
    PHYSICAL_LONG, PHYSICAL_SHORT, FUTURES_LONG, FUTURES_SHORT, CALL_LONG, PUT_LONG
}

data class TradingBookPosition(
    val positionId: String,
    val commoditySymbol: String,
    val type: PositionType,
    val quantity: Double,
    val unit: String,
    val entryPrice: Double,
    val currentMarketPrice: Double,
    val unrealizedPnl: Double,
    val delta: Double,
    val vega: Double,
    val basisExposure: Double,
    val location: String
)

data class PortfolioRiskMetrics(
    val totalPortfolioNav: Double,
    val grossExposure: Double,
    val netExposure: Double,
    val netDelta: Double,
    val netGamma: Double,
    val netVega: Double,
    val var95_1Day: Double,
    val var99_1Day: Double,
    val expectedShortfall95: Double,
    val stressWorstCaseLoss: Double,
    val initialMarginRequired: Double,
    val variationMarginCall: Double,
    val pledgedCollateral: Double,
    val freeCollateral: Double
)

data class StressScenario(
    val id: String,
    val name: String,
    val description: String,
    val shocks: Map<String, Double>, // Symbol -> % price shock
    val estimatedPnlImpact: Double,
    val marginCallImpact: Double,
    val criticalBottleneckNotice: String,
    val probabilityRating: String
)

enum class NodeType {
    MINE, OIL_FIELD, GAS_WELL, PIPELINE, EXPORT_PORT, SHIP_ROUTER, IMPORT_TERMINAL, REFINERY, SMELTER, ELEVATOR_SILO, INDUSTRIAL_CONSUMER
}

enum class NodeHealth {
    OPTIMAL, ELEVATED_LOAD, CONSTRAINED_BOTTLENECK, SEVERE_OUTAGE
}

data class DigitalTwinNode(
    val id: String,
    val name: String,
    val nodeType: NodeType,
    val region: String,
    val commoditySymbol: String,
    val dailyThroughput: Double,
    val currentUtilizationPct: Double,
    val inventoryOnHand: Double,
    val unit: String,
    val health: NodeHealth,
    val outageRiskFactor: Double, // 0.0 to 1.0
    val upstreamDependencies: List<String>
)

data class SupplyDemandBalance(
    val commoditySymbol: String,
    val productionMmt: Double,
    val consumptionMmt: Double,
    val importsMmt: Double,
    val exportsMmt: Double,
    val inventoryChangeMmt: Double,
    val balanceMmt: Double, // Surplus(+) or Deficit(-)
    val stockToUseRatioPct: Double,
    val daysOfSupply: Int,
    val annualGrowthPct: Double
)

data class DeliveryDocument(
    val documentId: String,
    val docType: String, // Bill of Lading, Certificate of Analysis, Warehouse Receipt, Customs Entry, Inspection Cert
    val issuer: String,
    val timestamp: String,
    val hashSha256: String,
    val relatedLotId: String,
    val verifiedPurity: String,
    val status: String // VERIFIED, LODGED, TRANSFERRED
)
