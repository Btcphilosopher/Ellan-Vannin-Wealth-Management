package com.example.engine

import com.example.model.*

object DigitalTwinSimulationEngine {

    data class PropagationStep(
        val stepNumber: Int,
        val domain: String,
        val nodeOrMetric: String,
        val changeDescription: String,
        val quantitativeShift: String,
        val statusImpact: String
    )

    data class SimulationResult(
        val eventType: String,
        val shockSeverityPct: Double,
        val rootCause: String,
        val propagationSequence: List<PropagationStep>,
        val finalPriceDeltaPct: Double,
        val finalInventoryDrawdownPct: Double,
        val finalDownstreamCostInflationPct: Double,
        val physicalRiskLevel: String
    )

    enum class SimulatedEvent(val eventName: String, val affectedSymbol: String, val defaultSeverityPct: Double) {
        MAJOR_MINE_OUTAGE("Major Copper Mine Seismic Disruption (Escondida / Grasberg)", "HG-COPPER", 18.0),
        RED_SEA_SUEZ_CHOKEPOINT("Bab el-Mandeb / Suez Chokepoint Transit Blockade", "BRENT", 35.0),
        PANAMA_CANAL_DROUGHT("Panama Canal Draft Restriction & Transit Auction Spike", "LNG-ASIA", 40.0),
        MAJOR_REFINERY_EXPLOSION("Rotterdam Mega-Refinery FCC Catastrophic Outage", "DIESEL", 25.0),
        MIDWEST_EXTREME_DROUGHT("US Midwest Grain Belt Severe Heatwave & Flash Drought", "CORN", 22.0),
        OPEC_EMERGENCY_PRODUCTION_CUT("OPEC+ Unannounced 2.0 Mb/d Quota Curtailment", "WTI", 15.0),
        LITHIUM_SALT_FLAT_EXPORT_BAN("South American Lithium Triangle Export Quota Freeze", "LITHIUM", 30.0)
    }

    fun simulateShock(event: SimulatedEvent, customSeverity: Double? = null): SimulationResult {
        val severity = customSeverity ?: event.defaultSeverityPct

        return when (event) {
            SimulatedEvent.MAJOR_MINE_OUTAGE -> {
                val steps = listOf(
                    PropagationStep(1, "Upstream Production", "Escondida / Centinela Mine Pit", "Unplanned conveyor shutdown and rockfall containment", "-${String.format("%.1f", severity)}% Run-of-Mine Feed", "SEVERE_OUTAGE"),
                    PropagationStep(2, "Concentrate Supply", "Antofagasta Port Terminal", "Concentrate loading queues balloon; vessel demurrage rises", "-${String.format("%.1f", severity * 0.9)}% Export Throughput", "CONSTRAINED_BOTTLENECK"),
                    PropagationStep(3, "Smelter Stockpiles", "Asian & European Copper Smelters", "Treatment and Refining Charges (TC/RCs) collapse towards zero", "-${String.format("%.1f", severity * 1.1)}% Buffer Stock", "CONSTRAINED_BOTTLENECK"),
                    PropagationStep(4, "Exchange Inventory", "LME & SHFE Registered Warrants", "Rapid drawdown of Grade A cathode warrants in Asian sheds", "-${String.format("%.1f", severity * 1.4)}% Warrants on Warrant", "ELEVATED_LOAD"),
                    PropagationStep(5, "Futures Forward Curve", "LME Copper Cash-to-3M Spread", "Prompt scarcity flips curve into sharp backwardation", "+$145.00/t Backwardation Premium", "ELEVATED_LOAD"),
                    PropagationStep(6, "Spot Physical Basis", "CIF Shanghai / Rotterdam Cathode Premium", "Fabricators bid emergency spot premiums over benchmark", "+$85.00/t Physical Basis Premium", "ELEVATED_LOAD"),
                    PropagationStep(7, "Downstream Manufacturing", "Power Cable & EV Motor Wire Rod Plants", "Operating margins compress; delivery lead times extend by 4 weeks", "-12.4% Gross Conversion Margin", "CONSTRAINED_BOTTLENECK")
                )
                SimulationResult(
                    eventType = event.eventName,
                    shockSeverityPct = severity,
                    rootCause = "Top-tier open pit geomechanical instability halting primary crusher feed.",
                    propagationSequence = steps,
                    finalPriceDeltaPct = severity * 0.72,
                    finalInventoryDrawdownPct = severity * 1.35,
                    finalDownstreamCostInflationPct = severity * 0.88,
                    physicalRiskLevel = "CRITICAL (RED ALERT)"
                )
            }
            SimulatedEvent.RED_SEA_SUEZ_CHOKEPOINT -> {
                val steps = listOf(
                    PropagationStep(1, "Maritime Chokepoint", "Bab el-Mandeb / Red Sea Corridor", "Commercial maritime traffic rerouted around Cape of Good Hope", "Transit transit halted (0 vessels)", "SEVERE_OUTAGE"),
                    PropagationStep(2, "Logistics Ton-Miles", "Global VLCC & Suezmax Tanker Fleet", "Voyage duration extended by 14-18 days; fleet efficiency plummets", "+38.5% Global Ton-Mile Demand", "CONSTRAINED_BOTTLENECK"),
                    PropagationStep(3, "Freight Markets", "TD3C Arab Gulf to China / Europe", "Spot clean & dirty tanker charter rates spike above $120k/day", "+${String.format("%.1f", severity * 2.8)}% Worldscale Charter Index", "CONSTRAINED_BOTTLENECK"),
                    PropagationStep(4, "Refinery Feedstocks", "Northwest European & Mediterranean Refineries", "Crude delivery delays force crude inventory destocking", "-${String.format("%.1f", severity * 0.85)}% Feedstock Coverage", "ELEVATED_LOAD"),
                    PropagationStep(5, "Delivered Price Basis", "CIF Rotterdam vs FOB Ras Tanura Basis", "Freight and maritime war-risk insurance premiums expand", "+$4.85/bbl Delivered Location Basis", "ELEVATED_LOAD"),
                    PropagationStep(6, "Forward Curve Shift", "Brent 1M / 12M Calendar Structure", "Prompt prompt barrels command severe backwardation premium", "+$3.60/bbl Prompt Backwardation", "ELEVATED_LOAD"),
                    PropagationStep(7, "Downstream Industrial", "European Chemical & Transportation Diesel End-Users", "Finished fuel wholesale rack prices surge", "+${String.format("%.1f", severity * 0.75)}% Delivered Energy Cost", "ELEVATED_LOAD")
                )
                SimulationResult(
                    eventType = event.eventName,
                    shockSeverityPct = severity,
                    rootCause = "Geopolitical maritime interdiction enforcing Cape transit rerouting.",
                    propagationSequence = steps,
                    finalPriceDeltaPct = severity * 0.45,
                    finalInventoryDrawdownPct = severity * 0.90,
                    finalDownstreamCostInflationPct = severity * 1.15,
                    physicalRiskLevel = "HIGH (AMBER ALERT)"
                )
            }
            SimulatedEvent.PANAMA_CANAL_DROUGHT -> {
                val steps = listOf(
                    PropagationStep(1, "Canal Hydro Reservoir", "Gatun Lake Water Level", "Severe El Nino drought restricts maximum daily transits to 22 slots", "-42% Daily Vessel Transits", "SEVERE_OUTAGE"),
                    PropagationStep(2, "LNG Vessel Fleet", "US Gulf Coast to Asia LNG Carriers", "Vessels forced to transit Cape or Suez, adding 21 sailing days", "+55% Voyage Duration (USGC-Tokyo)", "CONSTRAINED_BOTTLENECK"),
                    PropagationStep(3, "Arbitrage Economics", "JKM - Henry Hub Spread", "Freight cost blowout widens Asian landed LNG spread requirements", "+$3.20/MMBtu Landed Asian Basis", "ELEVATED_LOAD"),
                    PropagationStep(4, "Regional Inventory", "Tokyo & Kansai Cryogenic LNG Tanks", "Utilities increase prompt LNG spot spot tender purchases", "-18.5% Days of Gas Sendout", "ELEVATED_LOAD"),
                    PropagationStep(5, "Power Sector Impact", "Japanese & South Korean Baseload Power", "Peak summer gas-to-power generation costs surge", "+24.0% Wholesale Spark Spread Cost", "ELEVATED_LOAD")
                )
                SimulationResult(
                    eventType = event.eventName,
                    shockSeverityPct = severity,
                    rootCause = "Climatic drought in watershed curtailing freshwater lockage capacity.",
                    propagationSequence = steps,
                    finalPriceDeltaPct = severity * 0.58,
                    finalInventoryDrawdownPct = severity * 0.80,
                    finalDownstreamCostInflationPct = severity * 0.92,
                    physicalRiskLevel = "HIGH (AMBER ALERT)"
                )
            }
            SimulatedEvent.MAJOR_REFINERY_EXPLOSION -> {
                val steps = listOf(
                    PropagationStep(1, "Refinery Asset", "Pernis / Europoort FCC Unit", "Catastrophic compressor fire forces total refinery complex shutdown", "-400,000 bpd Crude Processing", "SEVERE_OUTAGE"),
                    PropagationStep(2, "Middle Distillate Supply", "ARA Regional Storage Tank Hubs", "Immediate halt of ultra-low sulfur diesel pipeline injections", "-28% ARA Gasoil/Diesel Inflows", "CONSTRAINED_BOTTLENECK"),
                    PropagationStep(3, "Regional Crack Spread", "European 3:2:1 & Gasoil Cracks", "Refining margins spike violently to attract USGC import arbitrage", "+$18.50/bbl European Gasoil Crack", "ELEVATED_LOAD"),
                    PropagationStep(4, "Commercial Logistics", "Rhine Barge Low-Sulfur Diesel Shipments", "German and Swiss wholesale distribution hubs face acute product shortage", "-35% Up-River Barge Inflows", "CONSTRAINED_BOTTLENECK"),
                    PropagationStep(5, "Consumer Pricing", "Central European Freight & Agriculture Fuel", "Wholesale pump prices reflect immediate spot replacement cost", "+19.2% Bulk Diesel Delivery Cost", "CONSTRAINED_BOTTLENECK")
                )
                SimulationResult(
                    eventType = event.eventName,
                    shockSeverityPct = severity,
                    rootCause = "Major refinery catalytic cracking failure halting product yields.",
                    propagationSequence = steps,
                    finalPriceDeltaPct = severity * 0.84,
                    finalInventoryDrawdownPct = severity * 1.20,
                    finalDownstreamCostInflationPct = severity * 1.05,
                    physicalRiskLevel = "CRITICAL (RED ALERT)"
                )
            }
            SimulatedEvent.MIDWEST_EXTREME_DROUGHT -> {
                val steps = listOf(
                    PropagationStep(1, "Crop Agronomics", "Iowa & Illinois Corn Belt", "Growing degree days surge; soil moisture plunges to 8th percentile", "-${String.format("%.1f", severity)}% Bushels/Acre Yield", "SEVERE_OUTAGE"),
                    PropagationStep(2, "Harvest Production", "USDA Crop Progress Observation", "Production forecast downgraded by 38 million metric tonnes", "-${String.format("%.1f", severity * 0.95)}% Gross Harvest Output", "CONSTRAINED_BOTTLENECK"),
                    PropagationStep(3, "Barge Transportation", "Mississippi River Draft Curtailment", "Low river depth forces 30% reduction in barge tow tonnages", "+$22.00/t Illinois River Barge Freight", "CONSTRAINED_BOTTLENECK"),
                    PropagationStep(4, "Terminal Elevators", "US Gulf Export Elevators", "Vessel loading lineups stretch to 25 days; CIF bids surge", "+$0.85/bu Gulf Delivery Basis", "ELEVATED_LOAD"),
                    PropagationStep(5, "Forward Futures Curve", "CBOT Corn Dec/Mar Spreads", "Inverted front months reflect immediate commercial panic", "+$0.42/bu Backwardation", "ELEVATED_LOAD"),
                    PropagationStep(6, "Livestock Feedlots", "Great Plains Cattle & Hog Producers", "Ration feed costs surge, depressing livestock fattening margins", "-18.5% Feeder Cattle Operating Margin", "CONSTRAINED_BOTTLENECK")
                )
                SimulationResult(
                    eventType = event.eventName,
                    shockSeverityPct = severity,
                    rootCause = "High-pressure heat dome over corn belt during critical pollination window.",
                    propagationSequence = steps,
                    finalPriceDeltaPct = severity * 0.78,
                    finalInventoryDrawdownPct = severity * 1.10,
                    finalDownstreamCostInflationPct = severity * 0.95,
                    physicalRiskLevel = "HIGH (AMBER ALERT)"
                )
            }
            SimulatedEvent.OPEC_EMERGENCY_PRODUCTION_CUT -> {
                val steps = listOf(
                    PropagationStep(1, "Upstream Wellheads", "Gulf Cooperation Council Fields", "Saudi Aramco & ADNOC valve chokes applied across offshore complexes", "-2,000,000 bpd Daily Production", "SEVERE_OUTAGE"),
                    PropagationStep(2, "Export Terminals", "Ras Tanura & Ju'aymah Terminals", "Crude nominations trimmed for term lifters in Asia and Europe", "-18% Terminal Berth Throughput", "CONSTRAINED_BOTTLENECK"),
                    PropagationStep(3, "Global Crude Stocks", "OECD Commercial Crude Inventories", "Commercial inventories drawn at 2.4 Mb/d above seasonal average", "-3.2% OECD Commercial Stocks", "ELEVATED_LOAD"),
                    PropagationStep(4, "Benchmark Curves", "Brent & Dubai 1M-12M Calendar Spreads", "Backwardation steepens as prompt supply scarcity bites", "+$4.20/bbl 1M/12M Backwardation", "ELEVATED_LOAD"),
                    PropagationStep(5, "Refinery Acquisition Cost", "Global Refining Complex", "Crude Official Selling Prices (OSPs) raised across all sour grades", "+$2.80/bbl OSP Differential", "ELEVATED_LOAD")
                )
                SimulationResult(
                    eventType = event.eventName,
                    shockSeverityPct = severity,
                    rootCause = "Ministerial communique mandating immediate 2 Mb/d compliance cuts.",
                    propagationSequence = steps,
                    finalPriceDeltaPct = severity * 0.85,
                    finalInventoryDrawdownPct = severity * 0.95,
                    finalDownstreamCostInflationPct = severity * 0.75,
                    physicalRiskLevel = "HIGH (AMBER ALERT)"
                )
            }
            SimulatedEvent.LITHIUM_SALT_FLAT_EXPORT_BAN -> {
                val steps = listOf(
                    PropagationStep(1, "Salt Flat Evaporation", "Salar de Atacama Brine Pits", "Regulatory moratorium restricts lithium carbonate brine extraction quotas", "-${String.format("%.1f", severity)}% Battery Grade Extraction", "SEVERE_OUTAGE"),
                    PropagationStep(2, "Chemical Conversion", "Regional Lithium Hydroxide Refineries", "Technical conversion runs cut back due to feedstock rationing", "-22% Battery-Grade Refined Output", "CONSTRAINED_BOTTLENECK"),
                    PropagationStep(3, "Port of Antofagasta", "Pacific Container Loading Gates", "Containerized lithium drum exports halted pending inspection licenses", "9,500 tonnes quarantined", "CONSTRAINED_BOTTLENECK"),
                    PropagationStep(4, "Spot Assessment", "Platts / Fastmarkets Battery Grade LCE", "Spot auction bids gap upward as cell makers scramble for spot units", "+${String.format("%.1f", severity * 1.5)}% LCE Spot Index ($/t)", "ELEVATED_LOAD"),
                    PropagationStep(5, "Gigafactory Cell Production", "Global EV Battery Manufacturers", "Cell pack manufacturing unit costs escalate", "+8.4% EV Pack Production Cost", "CONSTRAINED_BOTTLENECK")
                )
                SimulationResult(
                    eventType = event.eventName,
                    shockSeverityPct = severity,
                    rootCause = "National strategic mineral resource decree imposing export ceilings.",
                    propagationSequence = steps,
                    finalPriceDeltaPct = severity * 1.25,
                    finalInventoryDrawdownPct = severity * 1.40,
                    finalDownstreamCostInflationPct = severity * 0.65,
                    physicalRiskLevel = "CRITICAL (RED ALERT)"
                )
            }
        }
    }
}
