package com.example.engine

import com.example.model.*
import kotlin.math.*

object PricingAndBasisEngine {

    /**
     * Compute full delivered physical price according to global trading house incoterms and basis differentials
     */
    fun calculateDeliveredPrice(
        benchmarkPrice: Double,
        locationBasis: Double,
        qualityDifferential: Double,
        freight: Double,
        storageCost: Double,
        insuranceCost: Double,
        financingTax: Double,
        destination: String
    ): LocationBasis {
        val delivered = benchmarkPrice + locationBasis + qualityDifferential + freight + storageCost + insuranceCost + financingTax
        return LocationBasis(
            benchmarkPrice = benchmarkPrice,
            locationBasis = locationBasis,
            qualityPremiumDiscount = qualityDifferential,
            freight = freight,
            storageCost = storageCost,
            insurance = insuranceCost,
            taxFinancing = financingTax,
            deliveredPrice = delivered,
            destination = destination
        )
    }

    /**
     * Construct forward curve given spot, cost of carry (storage + insurance + financing) and convenience yield
     * F_t = S_0 * exp((costOfCarry - convenienceYield) * t)
     */
    fun constructForwardCurve(
        commodityId: String,
        symbol: String,
        spotPrice: Double,
        annualCostOfCarryPct: Double,
        annualConvenienceYieldPct: Double,
        seasonalFactors: Map<Int, Double> = emptyMap()
    ): ForwardCurve {
        val tenorsSpec = listOf(
            Triple("SPOT", 0, 0.0),
            Triple("1M", 1, 1.0 / 12.0),
            Triple("2M", 2, 2.0 / 12.0),
            Triple("3M", 3, 3.0 / 12.0),
            Triple("6M", 6, 6.0 / 12.0),
            Triple("9M", 9, 9.0 / 12.0),
            Triple("12M", 12, 1.0),
            Triple("18M", 18, 1.5),
            Triple("24M", 24, 2.0),
            Triple("36M", 36, 3.0)
        )

        val netCarryRate = annualCostOfCarryPct - annualConvenienceYieldPct

        val tenors = tenorsSpec.map { (label, months, tYears) ->
            if (months == 0) {
                ForwardTenor(
                    label = label,
                    months = 0,
                    price = spotPrice,
                    carryCost = 0.0,
                    convenienceYield = 0.0,
                    structure = CurveStructure.FLAT
                )
            } else {
                val seasonalAdj = seasonalFactors[months] ?: 1.0
                val carryAccumulated = spotPrice * (exp(annualCostOfCarryPct * tYears) - 1.0)
                val convenienceDiscount = spotPrice * (exp(annualConvenienceYieldPct * tYears) - 1.0)
                val forwardPrice = (spotPrice * exp(netCarryRate * tYears)) * seasonalAdj

                val tenorStructure = if (forwardPrice > spotPrice * 1.002) CurveStructure.CONTANGO
                else if (forwardPrice < spotPrice * 0.998) CurveStructure.BACKWARDATION
                else CurveStructure.FLAT

                ForwardTenor(
                    label = label,
                    months = months,
                    price = forwardPrice,
                    carryCost = carryAccumulated,
                    convenienceYield = convenienceDiscount,
                    structure = tenorStructure
                )
            }
        }

        val frontPrice = tenors.first { it.months == 1 }.price
        val oneYearPrice = tenors.first { it.months == 12 }.price
        val overall = if (oneYearPrice > spotPrice * 1.01) {
            CurveStructure.CONTANGO
        } else if (oneYearPrice < spotPrice * 0.99) {
            CurveStructure.BACKWARDATION
        } else {
            CurveStructure.FLAT
        }

        val calendarSpreadDecJan = tenors.first { it.months == 12 }.price - tenors.first { it.months == 1 }.price
        val annualizedCarry = ((oneYearPrice - spotPrice) / spotPrice) * 100.0

        val driverExplanation = when (overall) {
            CurveStructure.CONTANGO -> "Ample prompt inventory; market offers carry premium to cover physical storage, financing & insurance."
            CurveStructure.BACKWARDATION -> "Severe prompt physical scarcity; high convenience yield exceeds carrying costs, incentivizing inventory liquidation."
            CurveStructure.FLAT -> "Balanced prompt and forward supply-demand equilibrium."
        }

        return ForwardCurve(
            commodityId = commodityId,
            symbol = symbol,
            spotPrice = spotPrice,
            tenors = tenors,
            overallStructure = overall,
            calendarSpreadDecJan = calendarSpreadDecJan,
            annualizedCarryPct = annualizedCarry,
            structuralDriver = driverExplanation
        )
    }

    /**
     * Compute 3:2:1 Oil Refinery Crack Spread
     * (2 bbl Gasoline + 1 bbl Ultra-Low Sulfur Diesel - 3 bbl Crude) / 3
     */
    fun calculateCrack321(
        crudePricePerBbl: Double,
        gasolinePricePerBbl: Double,
        dieselPricePerBbl: Double
    ): CrackCrushSpread {
        val spread = (2.0 * gasolinePricePerBbl + 1.0 * dieselPricePerBbl - 3.0 * crudePricePerBbl) / 3.0
        val signal = if (spread > 28.0) "Exceptional refining margins: Incentivizes maximum crude throughput & refinery run-rates."
        else if (spread > 15.0) "Healthy processing margin: Refineries operating at standard economic capacity."
        else "Sub-economic crack: Risk of economic run cuts and maintenance curtailments."

        return CrackCrushSpread(
            type = SpreadType.CRACK_321,
            name = "3:2:1 Refinery Crack Spread",
            inputDescription = "3 Barrels Crude Oil",
            outputDescription = "2 Barrels RBOB Gasoline + 1 Barrel Ultra-Low Sulphur Diesel",
            formula = "(2 × Gasoline + 1 × Diesel - 3 × Crude) ÷ 3",
            value = spread,
            unit = "USD/bbl",
            historicalMean = 19.50,
            economicSignal = signal
        )
    }

    /**
     * Compute Soybean Processing Crush Spread
     * 1 bu Soybeans (60 lbs) yields ~11 lbs Soybean Oil + 44 lbs Soybean Meal (and 5 lbs hull/waste)
     * Standard CBOT Crush formula: Meal ($/ton) * 0.022 + Oil (cents/lb) * 0.11 - Soybeans ($/bu)
     */
    fun calculateSoybeanCrush(
        soybeanPricePerBu: Double,
        soyMealPricePerTon: Double,
        soyOilPriceCentsPerLb: Double
    ): CrackCrushSpread {
        val mealRevenuePerBu = soyMealPricePerTon * 0.022 // 44 lbs / 2000 lbs
        val oilRevenuePerBu = (soyOilPriceCentsPerLb / 100.0) * 11.0
        val grossMargin = mealRevenuePerBu + oilRevenuePerBu - soybeanPricePerBu

        val signal = if (grossMargin > 2.00) "Strong crush margin: High processor demand for cash beans."
        else if (grossMargin > 0.90) "Normal seasonal processing economics."
        else "Depressed crush: Processing margins negative or breakeven; crushers idling lines."

        return CrackCrushSpread(
            type = SpreadType.CRUSH_SOYBEAN,
            name = "Soybean Processing Crush Margin",
            inputDescription = "1 Bushel Whole Soybeans (60 lbs)",
            outputDescription = "44 lbs High-Protein Meal + 11 lbs Refined Vegetable Oil",
            formula = "(Meal $/ton × 0.022) + (Oil ¢/lb × 0.11) - Bean $/bu",
            value = grossMargin,
            unit = "USD/bushel",
            historicalMean = 1.35,
            economicSignal = signal
        )
    }

    /**
     * Spark Spread: Electricity Price - (Heat Rate * Gas Price)
     */
    fun calculateSparkSpread(
        powerPriceMwh: Double,
        gasPriceMmbtu: Double,
        heatRateMmbtuPerMwh: Double = 7.2 // Typical CCGT heat rate
    ): CrackCrushSpread {
        val gasCost = heatRateMmbtuPerMwh * gasPriceMmbtu
        val spread = powerPriceMwh - gasCost
        val signal = if (spread > 25.0) "High gas-to-power arbitrage profitability: CCGTs dispatched at baseload."
        else if (spread > 10.0) "Marginal dispatch profitability."
        else "Spark spread squeezed: Coal or renewables dispatching ahead of gas."

        return CrackCrushSpread(
            type = SpreadType.SPARK_GAS_POWER,
            name = "Gas-to-Power Spark Spread",
            inputDescription = "Natural Gas (HH / TTF equivalent @ 7.2 MMBtu/MWh)",
            outputDescription = "Wholesale Baseload Power Output (MWh)",
            formula = "Power Price ($/MWh) - (7.2 × Gas Price $/MMBtu)",
            value = spread,
            unit = "USD/MWh",
            historicalMean = 18.20,
            economicSignal = signal
        )
    }
}
