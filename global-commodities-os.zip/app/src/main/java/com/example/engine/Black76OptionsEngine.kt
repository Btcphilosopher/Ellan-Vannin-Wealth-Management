package com.example.engine

import com.example.model.OptionType
import kotlin.math.*

object Black76OptionsEngine {

    // Standard normal cumulative distribution function (Abramowitz & Stegun approx)
    fun normCdf(x: Double): Double {
        if (x < -8.0) return 0.0
        if (x > 8.0) return 1.0

        val p = 0.2316419
        val b1 = 0.319381530
        val b2 = -0.356563782
        val b3 = 1.781477937
        val b4 = -1.821255978
        val b5 = 1.330274429

        val sign = if (x < 0) -1 else 1
        val absX = abs(x)
        val t = 1.0 / (1.0 + p * absX)
        val pdf = (1.0 / sqrt(2.0 * Math.PI)) * exp(-0.5 * absX * absX)
        val cdf = 1.0 - pdf * (b1 * t + b2 * t * t + b3 * t.pow(3) + b4 * t.pow(4) + b5 * t.pow(5))

        return if (sign == -1) 1.0 - cdf else cdf
    }

    fun normPdf(x: Double): Double {
        return (1.0 / sqrt(2.0 * Math.PI)) * exp(-0.5 * x * x)
    }

    data class Greeks(
        val price: Double,
        val delta: Double,
        val gamma: Double,
        val vega: Double,
        val theta: Double,
        val rho: Double
    )

    /**
     * Black-76 formula for options on commodity forward / futures contracts.
     * F: Forward price
     * K: Strike price
     * T: Time to expiry in years
     * r: Risk-free rate (annualized)
     * sigma: Volatility (annualized, e.g. 0.28 for 28%)
     */
    fun calculateGreeks(
        forwardPrice: Double,
        strike: Double,
        timeToExpiryYears: Double,
        riskFreeRate: Double,
        volatility: Double,
        type: OptionType
    ): Greeks {
        val F = max(0.001, forwardPrice)
        val K = max(0.001, strike)
        val T = max(0.001, timeToExpiryYears)
        val sigma = max(0.001, volatility)
        val r = riskFreeRate

        val d1 = (ln(F / K) + 0.5 * sigma * sigma * T) / (sigma * sqrt(T))
        val d2 = d1 - sigma * sqrt(T)
        val discountFactor = exp(-r * T)

        val price: Double
        val delta: Double

        if (type == OptionType.CALL) {
            price = discountFactor * (F * normCdf(d1) - K * normCdf(d2))
            delta = discountFactor * normCdf(d1)
        } else {
            price = discountFactor * (K * normCdf(-d2) - F * normCdf(-d1))
            delta = -discountFactor * normCdf(-d1)
        }

        val gamma = discountFactor * (normPdf(d1) / (F * sigma * sqrt(T)))
        val vega = discountFactor * F * sqrt(T) * normPdf(d1) / 100.0 // per 1% vol move
        val thetaAnnual = -(discountFactor * F * normPdf(d1) * sigma) / (2 * sqrt(T)) -
                (if (type == OptionType.CALL) -r * discountFactor * (F * normCdf(d1) - K * normCdf(d2))
                else -r * discountFactor * (K * normCdf(-d2) - F * normCdf(-d1)))
        val theta = thetaAnnual / 365.0 // per 1 day decay

        val rho = (if (type == OptionType.CALL) -T * price else -T * price) / 100.0

        return Greeks(
            price = max(0.001, price),
            delta = delta,
            gamma = gamma,
            vega = vega,
            theta = theta,
            rho = rho
        )
    }

    /**
     * Implied volatility inversion using Newton-Raphson with bisection fallback
     */
    fun solveImpliedVol(
        targetPrice: Double,
        forwardPrice: Double,
        strike: Double,
        timeToExpiryYears: Double,
        riskFreeRate: Double,
        type: OptionType
    ): Double {
        var sigma = 0.30 // Initial guess 30%
        val maxIterations = 25
        val tolerance = 0.0001

        for (i in 0 until maxIterations) {
            val greeks = calculateGreeks(forwardPrice, strike, timeToExpiryYears, riskFreeRate, sigma, type)
            val diff = greeks.price - targetPrice
            if (abs(diff) < tolerance) {
                return sigma
            }
            val vega = max(0.0001, greeks.vega * 100.0) // raw vega
            val newSigma = sigma - diff / vega
            sigma = newSigma.coerceIn(0.01, 3.0)
        }
        return sigma
    }
}
