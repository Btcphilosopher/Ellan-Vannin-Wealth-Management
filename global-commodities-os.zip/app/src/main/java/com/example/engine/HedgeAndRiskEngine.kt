package com.example.engine

import com.example.model.*
import kotlin.math.*

object HedgeAndRiskEngine {

    data class HedgeAnalysisResult(
        val hedgeRatio: Double,
        val recommendedFuturesContracts: Int,
        val hedgeEffectivenessPct: Double,
        val residualRiskPct: Double,
        val varianceReductionPct: Double,
        val physicalRiskExposureUsd: Double,
        val strategySummary: String
    )

    /**
     * Minimum Variance Hedge Ratio (MVHR)
     * h* = rho * (sigma_S / sigma_F)
     * contracts = h* * (Physical Quantity / Futures Contract Size)
     */
    fun calculateMinimumVarianceHedge(
        spotQuantity: Double,
        spotVol: Double,
        futuresVol: Double,
        correlation: Double,
        futuresContractSize: Double,
        spotPrice: Double
    ): HedgeAnalysisResult {
        val boundedCorr = correlation.coerceIn(-1.0, 1.0)
        val hStar = boundedCorr * (spotVol / max(0.001, futuresVol))
        val contractsFloat = (hStar * spotQuantity) / max(1.0, futuresContractSize)
        val contracts = round(contractsFloat).toInt()
        val effectiveness = (boundedCorr * boundedCorr) * 100.0
        val residualRisk = 100.0 - effectiveness
        val exposureUsd = spotQuantity * spotPrice

        val strategy = if (hStar > 0.85) {
            "High tracking efficiency: Standard linear short futures hedge provides >${String.format("%.1f", effectiveness)}% variance reduction."
        } else if (hStar > 0.60) {
            "Moderate basis risk: Basis volatility requires dynamic rebalancing and calendar spread adjustments."
        } else {
            "High basis / quality divergence: Cross-commodity hedge exhibits significant residual tracking error."
        }

        return HedgeAnalysisResult(
            hedgeRatio = hStar,
            recommendedFuturesContracts = contracts,
            hedgeEffectivenessPct = effectiveness,
            residualRiskPct = residualRisk,
            varianceReductionPct = effectiveness,
            physicalRiskExposureUsd = exposureUsd,
            strategySummary = strategy
        )
    }

    /**
     * Compute Portfolio Risk: VaR 95%, VaR 99%, Expected Shortfall (CVaR), and Margin requirements
     */
    fun computePortfolioRisk(
        positions: List<TradingBookPosition>,
        pledgedCollateral: Double = 14500000.0
    ): PortfolioRiskMetrics {
        var totalNav = 0.0
        var grossExposure = 0.0
        var netExposure = 0.0
        var netDelta = 0.0
        var netGamma = 0.0
        var netVega = 0.0

        for (pos in positions) {
            val positionNotional = pos.quantity * pos.currentMarketPrice
            totalNav += pos.unrealizedPnl
            grossExposure += abs(positionNotional)

            when (pos.type) {
                PositionType.PHYSICAL_LONG -> {
                    netExposure += positionNotional
                    netDelta += pos.quantity
                }
                PositionType.PHYSICAL_SHORT -> {
                    netExposure -= positionNotional
                    netDelta -= pos.quantity
                }
                PositionType.FUTURES_LONG -> {
                    netExposure += positionNotional
                    netDelta += pos.quantity
                }
                PositionType.FUTURES_SHORT -> {
                    netExposure -= positionNotional
                    netDelta -= pos.quantity
                }
                PositionType.CALL_LONG -> {
                    netExposure += positionNotional * pos.delta
                    netDelta += pos.quantity * pos.delta
                    netVega += pos.vega * pos.quantity
                }
                PositionType.PUT_LONG -> {
                    netExposure += positionNotional * pos.delta
                    netDelta += pos.quantity * pos.delta
                    netVega += pos.vega * pos.quantity
                }
            }
        }

        // Institutional standard: Parametric VaR with 1.65 (95%) and 2.33 (99%) z-scores
        // Weighted portfolio daily volatility ~ 1.85%
        val dailyVol = 0.0185
        val var95 = abs(netExposure) * dailyVol * 1.645
        val var99 = abs(netExposure) * dailyVol * 2.326
        // Expected Shortfall 95% = S_0 * dailyVol * (pdf(z) / (1 - alpha))
        val expectedShortfall = abs(netExposure) * dailyVol * 2.062

        // SPAN-style initial margin estimate: ~8% of gross futures + options exposure
        val initialMargin = grossExposure * 0.075
        val freeCollateral = (pledgedCollateral - initialMargin).coerceAtLeast(0.0)
        val variationMarginCall = if (pledgedCollateral < initialMargin) initialMargin - pledgedCollateral else 0.0
        val stressWorstLoss = var99 * 2.4

        return PortfolioRiskMetrics(
            totalPortfolioNav = totalNav,
            grossExposure = grossExposure,
            netExposure = netExposure,
            netDelta = netDelta,
            netGamma = netGamma,
            netVega = netVega,
            var95_1Day = var95,
            var99_1Day = var99,
            expectedShortfall95 = expectedShortfall,
            stressWorstCaseLoss = stressWorstLoss,
            initialMarginRequired = initialMargin,
            variationMarginCall = variationMarginCall,
            pledgedCollateral = pledgedCollateral,
            freeCollateral = freeCollateral
        )
    }

    /**
     * Evaluate stress scenario impact on trading book and physical assets
     */
    fun evaluateStressScenario(
        scenario: StressScenario,
        positions: List<TradingBookPosition>,
        lots: List<CommodityLot>,
        spotPrices: Map<String, Double>
    ): Pair<Double, Double> {
        var pnlLoss = 0.0
        var marginSpike = 0.0

        for (pos in positions) {
            val shockPct = scenario.shocks[pos.commoditySymbol] ?: (scenario.shocks["*"] ?: 0.0)
            val notional = pos.quantity * pos.currentMarketPrice
            val priceShift = notional * (shockPct / 100.0)

            val posImpact = when (pos.type) {
                PositionType.PHYSICAL_LONG, PositionType.FUTURES_LONG -> priceShift
                PositionType.PHYSICAL_SHORT, PositionType.FUTURES_SHORT -> -priceShift
                PositionType.CALL_LONG -> priceShift * pos.delta
                PositionType.PUT_LONG -> -priceShift * abs(pos.delta)
            }
            pnlLoss += posImpact
            marginSpike += abs(priceShift) * 0.20 // 20% margin buffer increase under stress
        }

        // Physical inventory value shock
        for (lot in lots) {
            val shockPct = scenario.shocks[lot.symbol] ?: 0.0
            val price = spotPrices[lot.symbol] ?: 0.0
            val lotValue = lot.quantity * price
            pnlLoss += lotValue * (shockPct / 100.0)
        }

        return Pair(pnlLoss, marginSpike)
    }
}
