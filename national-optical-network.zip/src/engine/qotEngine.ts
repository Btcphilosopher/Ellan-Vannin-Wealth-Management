/**
 * NATIONAL OPTICAL NETWORK - Quality of Transmission (QoT) & Optical Physics Engine
 * Implements ITU-T G.694.1 flex-grid, GN-model non-linearities, OSNR, GSNR, CD, PMD & BER
 */

import { ModulationFormat, FecType } from '../types/optical';

export interface QoTCalculationInput {
  launchPowerDbm: number;
  totalDistanceKm: number;
  spanLengthKm?: number;
  baudRateGbaud: number;
  modulation: ModulationFormat;
  fec: FecType;
  fibreType?: 'G.652.D' | 'G.654.E' | 'G.655_NZDSF' | 'G.657.A2_BEND_INSENSITIVE' | 'SUBSEA_LOW_LOSS';
  edfaNoiseFigureDb?: number;
  roadmPassCount?: number;
}

export interface QoTResult {
  osnrAseDb: number;
  snrNliDb: number;
  gsnrDb: number;
  qFactorDb: number;
  berPreFec: number;
  berPostFec: number;
  chromaticDispersionPsNm: number;
  pmdPs: number;
  nonlinearPhaseShiftRad: number;
  marginDb: number;
  isValid: boolean;
  maxEstimatedReachKm: number;
  spectralEfficiencyBpsHz: number;
}

// Physical Constants
const PLANCK_CONSTANT = 6.62607015e-34; // J*s
const C_LIGHT_SPEED = 2.99792458e8; // m/s
const REF_WAVELENGTH_M = 1550e-9; // 1550 nm C-Band
const OPTICAL_FREQ_HZ = C_LIGHT_SPEED / REF_WAVELENGTH_M; // ~193.41 THz
const REF_BANDWIDTH_HZ = 12.5e9; // 0.1 nm resolution @ 1550nm (~12.5 GHz)

export class QoTEngine {
  /**
   * Evaluates end-to-end Quality of Transmission across spans & ROADMs
   */
  public static calculateQoT(input: QoTCalculationInput): QoTResult {
    const spanLength = input.spanLengthKm || 80;
    const numSpans = Math.max(1, Math.ceil(input.totalDistanceKm / spanLength));
    const noiseFigureDb = input.edfaNoiseFigureDb || 5.0;
    const roadmCount = input.roadmPassCount || Math.max(2, Math.floor(input.totalDistanceKm / 220));

    // Fibre properties
    let alphaDbKm = 0.20; // Attenuation
    let dispersionParam = 16.7; // ps/(nm*km) for G.652.D
    let pmdCoeff = 0.04; // ps / sqrt(km)
    let nliGamma = 1.3e-3; // 1/(W*m)

    if (input.fibreType === 'G.654.E') {
      alphaDbKm = 0.165;
      dispersionParam = 20.5;
      nliGamma = 0.95e-3; // Lower non-linearity due to large effective area (130 um^2)
    } else if (input.fibreType === 'SUBSEA_LOW_LOSS') {
      alphaDbKm = 0.150;
      dispersionParam = 21.0;
      nliGamma = 0.85e-3;
    } else if (input.fibreType === 'G.655_NZDSF') {
      alphaDbKm = 0.22;
      dispersionParam = 4.2;
      nliGamma = 1.8e-3; // Higher NLI due to lower dispersion
    }

    // Power calculations
    const pTxWatts = Math.pow(10, (input.launchPowerDbm - 30) / 10);
    const spanGainLinear = Math.pow(10, (alphaDbKm * spanLength) / 10);
    const nfLinear = Math.pow(10, noiseFigureDb / 10);

    // ASE Noise per span (EDFA)
    const pAsePerSpan = (spanGainLinear - 1) * PLANCK_CONSTANT * OPTICAL_FREQ_HZ * (input.baudRateGbaud * 1e9) * nfLinear;
    const totalPAse = pAsePerSpan * numSpans + (roadmCount * 1.5e-8); // adding ROADM filter insertion noise

    // OSNR ASE
    const osnrAseLinear = pTxWatts / Math.max(1e-15, totalPAse);
    const osnrAseDb = 10 * Math.log10(osnrAseLinear);

    // Non-linear Interference (GN Model approximation)
    const spanLossLinearAlpha = (alphaDbKm / 4.343) * 1e-3; // 1/m
    const effectiveLengthM = (1 - Math.exp(-spanLossLinearAlpha * spanLength * 1e3)) / spanLossLinearAlpha;
    const etaNli = (nliGamma * nliGamma * effectiveLengthM * effectiveLengthM) / (Math.PI * Math.abs(dispersionParam * 1e-6) * Math.pow(input.baudRateGbaud * 1e9, 2));
    const pNli = numSpans * etaNli * Math.pow(pTxWatts, 3);
    const snrNliLinear = pTxWatts / Math.max(1e-16, pNli);
    const snrNliDb = 10 * Math.log10(snrNliLinear);

    // Generalized SNR (GSNR = 1 / (1/SNR_ASE + 1/SNR_NLI))
    const gsnrLinear = 1 / ((1 / osnrAseLinear) + (1 / snrNliLinear));
    const gsnrDb = 10 * Math.log10(Math.max(1, gsnrLinear));

    // Modulation & Bits Per Symbol
    let bitsPerSymbol = 2; // DP-QPSK
    let reqGsnrDb = 9.5; // for DP-QPSK w/ oFEC
    let maxReach = 3500; // km

    switch (input.modulation) {
      case 'BPSK':
        bitsPerSymbol = 1;
        reqGsnrDb = 6.2;
        maxReach = 6000;
        break;
      case 'DP-QPSK':
        bitsPerSymbol = 2;
        reqGsnrDb = 9.5;
        maxReach = 3200;
        break;
      case 'DP-8QAM':
        bitsPerSymbol = 3;
        reqGsnrDb = 13.0;
        maxReach = 1800;
        break;
      case 'DP-16QAM':
        bitsPerSymbol = 4;
        reqGsnrDb = 16.5;
        maxReach = 1200;
        break;
      case 'DP-32QAM':
        bitsPerSymbol = 5;
        reqGsnrDb = 19.8;
        maxReach = 600;
        break;
      case 'DP-64QAM':
        bitsPerSymbol = 6;
        reqGsnrDb = 23.2;
        maxReach = 350;
        break;
      case 'PROBABILISTIC_CONSTELLATION_SHAPED':
        bitsPerSymbol = 4.8;
        reqGsnrDb = 15.2;
        maxReach = 1500;
        break;
    }

    // FEC threshold adjustments
    let fecThreshold = 1.8e-2; // ~15% SD-FEC
    if (input.fec === 'OFEC_27%') {
      fecThreshold = 3.5e-2;
      reqGsnrDb -= 1.4; // Coding gain benefit
      maxReach *= 1.3;
    } else if (input.fec === 'HARD_DECISION_FEC') {
      fecThreshold = 3.8e-3;
      reqGsnrDb += 2.5;
      maxReach *= 0.65;
    }

    // Physical Dispersion calculations
    const chromaticDispersionPsNm = dispersionParam * input.totalDistanceKm;
    const pmdPs = pmdCoeff * Math.sqrt(input.totalDistanceKm);
    const nonlinearPhaseShiftRad = nliGamma * pTxWatts * effectiveLengthM * numSpans;

    // Q-factor and Bit Error Rate estimation
    const qFactorLinear = Math.sqrt(Math.max(0.1, gsnrLinear));
    const qFactorDb = 20 * Math.log10(qFactorLinear);

    // Pre-FEC BER using complementary error function approximation: Q(x) ~ 0.5 * erfc(x / sqrt(2))
    const xArg = qFactorLinear / 1.4142;
    const berPreFec = Math.max(1e-9, 0.5 * Math.exp(-xArg * xArg) / (Math.sqrt(Math.PI) * Math.max(0.8, xArg)));

    // Post-FEC BER
    let berPostFec = 1e-15;
    if (berPreFec > fecThreshold) {
      berPostFec = Math.min(1e-1, berPreFec * 0.15); // Uncorrectable frame errors
    } else {
      berPostFec = Math.max(1e-15, Math.pow(berPreFec / fecThreshold, 8) * 1e-12);
    }

    const marginDb = gsnrDb - reqGsnrDb;
    const isValid = marginDb >= 1.5 && berPreFec <= fecThreshold;
    const spectralEfficiencyBpsHz = (bitsPerSymbol * 2) * (1 - (input.fec === 'OFEC_27%' ? 0.27 : 0.15));

    return {
      osnrAseDb: Math.round(osnrAseDb * 100) / 100,
      snrNliDb: Math.round(snrNliDb * 100) / 100,
      gsnrDb: Math.round(gsnrDb * 100) / 100,
      qFactorDb: Math.round(qFactorDb * 100) / 100,
      berPreFec: parseFloat(berPreFec.toExponential(3)),
      berPostFec: parseFloat(berPostFec.toExponential(3)),
      chromaticDispersionPsNm: Math.round(chromaticDispersionPsNm * 10) / 10,
      pmdPs: Math.round(pmdPs * 100) / 100,
      nonlinearPhaseShiftRad: Math.round(nonlinearPhaseShiftRad * 1000) / 1000,
      marginDb: Math.round(marginDb * 100) / 100,
      isValid,
      maxEstimatedReachKm: Math.round(maxReach),
      spectralEfficiencyBpsHz: Math.round(spectralEfficiencyBpsHz * 100) / 100
    };
  }

  /**
   * Generates ITU-T G.694.1 50GHz / Flex-grid (37.5 / 75 / 100 GHz) spectrum grid
   */
  public static generateSpectrumGrid(startFreqThz = 191.30, endFreqThz = 196.10, stepGhz = 50.0) {
    const slots = [];
    let currentFreq = startFreqThz;
    let channelNum = 1;

    while (currentFreq <= endFreqThz) {
      const wavelengthNm = (C_LIGHT_SPEED / (currentFreq * 1e12)) * 1e9;
      slots.push({
        slotId: `SLOT-${channelNum.toString().padStart(3, '0')}`,
        frequencyThz: Math.round(currentFreq * 1000) / 1000,
        wavelengthNm: Math.round(wavelengthNm * 100) / 100,
        slotWidthGhz: stepGhz
      });
      currentFreq += stepGhz / 1000;
      channelNum++;
    }
    return slots;
  }
}
