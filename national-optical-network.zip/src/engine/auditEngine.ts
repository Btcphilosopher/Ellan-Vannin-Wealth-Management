/**
 * NATIONAL OPTICAL NETWORK - Immutable Audit Logger & Safe Automation Engine
 * Enforces Levels 0-5 Automation, Role-Based Access Control, and Change Approval Gates.
 */

import { UserRole, Permission, AutomationLevel, AuditEvent, ChangeRequest } from '../types/optical';

export class AuditEngine {
  private static auditLogs: AuditEvent[] = [
    {
      audit_id: 'AUD-20260917-001',
      timestamp: '2026-09-17T03:30:15Z',
      user: 'j.thompson@nat-optical.gov.uk',
      role: 'OPTICAL_ENGINEER',
      action: 'OPTIMIZE_EDFA_PUMP_POWER',
      target_object: 'NODE-SLO-DCI-01',
      details: 'Adjusted EDFA booster pump current to +18.5 dBm on Shelf 01 to mitigate ASE accumulation',
      ip_address: '10.240.12.88',
      digital_signature: 'SHA256:e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
    },
    {
      audit_id: 'AUD-20260917-002',
      timestamp: '2026-09-17T04:02:44Z',
      user: 'a.petrov@nat-optical.gov.uk',
      role: 'PLANNER',
      action: 'EXECUTE_SCENARIO_SIMULATION',
      target_object: 'SCENARIO-C',
      details: 'Ran 24-month high-traffic capacity forecast simulation for Slough Hyperscale DC Interconnect',
      ip_address: '10.240.14.102',
      digital_signature: 'SHA256:d41d8cd98f00b204e9800998ecf8427e998ecf8427e102983419082341234123'
    }
  ];

  private static changeRequests: ChangeRequest[] = [
    {
      request_id: 'CR-2026-0891',
      operator: 'j.thompson@nat-optical.gov.uk',
      role: 'OPTICAL_ENGINEER',
      automation_level: 'LEVEL_4_HUMAN_APPROVAL',
      reason: 'Proactive protection switch for degraded fiber segment prior to scheduled highway maintenance',
      target_object_ids: ['FIBRE-LON-BRS-01'],
      change_type: 'PROTECTION_SWITCH',
      before_state_summary: 'Primary route active via M4 Expressway. Protection standby via M3/Solent.',
      proposed_state_summary: 'Traffic shifted to secondary 1+1 optical line. Primary laser muted for splice work.',
      risk_score: 'LOW',
      blast_radius_services: 0,
      qot_impact_db: 0.2,
      validation_status: 'PASSED',
      approval_status: 'APPROVED',
      execution_status: 'COMMITTED',
      created_at: '2026-09-17T02:15:00Z',
      executed_at: '2026-09-17T02:22:18Z',
      rollback_snapshot_id: 'SNAP-20260917-0215'
    }
  ];

  public static getLogs(): AuditEvent[] {
    return this.auditLogs;
  }

  public static getChangeRequests(): ChangeRequest[] {
    return this.changeRequests;
  }

  public static logAction(user: string, role: UserRole, action: string, target: string, details: string): AuditEvent {
    const signature = `SHA256:${Math.random().toString(36).substring(2)}${Date.now().toString(16)}`;
    const event: AuditEvent = {
      audit_id: `AUD-${Date.now().toString().slice(-6)}`,
      timestamp: new Date().toISOString(),
      user,
      role,
      action,
      target_object: target,
      details,
      ip_address: '10.240.10.45',
      digital_signature: signature
    };
    this.auditLogs = [event, ...this.auditLogs];
    return event;
  }

  public static createChangeRequest(cr: Omit<ChangeRequest, 'request_id' | 'created_at' | 'rollback_snapshot_id'>): ChangeRequest {
    const newCr: ChangeRequest = {
      ...cr,
      request_id: `CR-${Date.now().toString().slice(-6)}`,
      created_at: new Date().toISOString(),
      rollback_snapshot_id: `SNAP-${Date.now().toString().slice(-8)}`
    };
    this.changeRequests = [newCr, ...this.changeRequests];
    return newCr;
  }

  public static checkPermission(role: UserRole, action: Permission): boolean {
    const rolePermissions: Record<UserRole, Permission[]> = {
      EXECUTIVE_VIEWER: ['READ'],
      AUDITOR: ['READ', 'ANALYSE'],
      FIELD_ENGINEER: ['READ', 'ANALYSE', 'PREPARE'],
      PLANNER: ['READ', 'ANALYSE', 'SIMULATE', 'PREPARE'],
      NOC_OPERATOR: ['READ', 'ANALYSE', 'SIMULATE', 'PREPARE', 'APPROVE'],
      OPTICAL_ENGINEER: ['READ', 'ANALYSE', 'SIMULATE', 'PREPARE', 'APPROVE', 'EXECUTE'],
      NETWORK_ENGINEER: ['READ', 'ANALYSE', 'SIMULATE', 'PREPARE', 'APPROVE', 'EXECUTE'],
      SECURITY: ['READ', 'ANALYSE', 'SIMULATE', 'PREPARE', 'APPROVE', 'EXECUTE'],
      ADMIN: ['READ', 'ANALYSE', 'SIMULATE', 'PREPARE', 'APPROVE', 'EXECUTE']
    };

    return rolePermissions[role]?.includes(action) || false;
  }
}
