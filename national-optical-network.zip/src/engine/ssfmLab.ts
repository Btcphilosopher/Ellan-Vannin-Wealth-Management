/**
 * NATIONAL OPTICAL NETWORK - High-Fidelity Waveform Laboratory
 * Split-Step Fourier Method (SSFM) & Coherent Optical DSP Engine
 */

import { ModulationFormat } from '../types/optical';

export interface SSFMSimulationParams {
  distanceKm: number;
  launchPowerDbm: number;
  baudRateGbaud: number;
  modulation: ModulationFormat;
  chromaticDispersionPsNm?: number;
  pmdPs?: number;
  nonlinearCoeffGamma?: number; // 1/(W*km)
  edfaNoiseFigureDb?: number;
  equalizerTaps?: number;
}

export interface ConstellationPoint {
  i: number;
  q: number;
  idealI: number;
  idealQ: number;
  polarization: 'X' | 'Y';
}

export interface EyeDiagramTrace {
  timePs: number[];
  intensity: number[];
}

export interface SSFMResult {
  constellation: ConstellationPoint[];
  constellationPoints: ConstellationPoint[];
  eyeDiagram: {
    timeAxisPs: number[];
    traces: number[][];
  };
  evmPercent: number;
  opticalPowerProfile: { distanceKm: number; powerDbm: number }[];
  equalizerWeights: number[];
  dspEqualizerTaps: { tapIndex: number; weight: number }[];
  phaseNoiseVarianceRad: number;
  estimatedOsnrDb: number;
  snrDb: number;
  estimatedBer: number;
  berPreFec: number;
  eyeOpeningHeightNormalized: number;
  eyeOpeningPenaltyDb: number;
}

export class SSFMEngine {
  /**
   * Simulates Non-Linear Pulse Propagation & DSP Receiver Recovery
   */
  public static runSimulation(params: SSFMSimulationParams): SSFMResult {
    const {
      distanceKm,
      launchPowerDbm,
      baudRateGbaud,
      modulation,
      edfaNoiseFigureDb = 5.5,
      equalizerTaps = 21
    } = params;

    const numSymbols = 320;
    const symbolPeriodPs = 1000 / baudRateGbaud; // e.g., 64 Gbaud -> 15.625 ps
    const numSpans = Math.max(1, Math.ceil(distanceKm / 80));

    // Ideal Constellation Points based on modulation
    let idealLevels: number[] = [-1, 1];
    if (modulation === 'DP-16QAM') {
      idealLevels = [-3, -1, 1, 3].map(v => v / Math.sqrt(10));
    } else if (modulation === 'DP-64QAM') {
      idealLevels = [-7, -5, -3, -1, 1, 3, 5, 7].map(v => v / Math.sqrt(42));
    } else if (modulation === 'DP-8QAM') {
      idealLevels = [-1.5, -0.5, 0.5, 1.5].map(v => v / Math.sqrt(5));
    } else {
      // DP-QPSK / BPSK
      idealLevels = [-1, 1].map(v => v / Math.sqrt(2));
    }

    // Power & Noise calculations
    const pTxW = Math.pow(10, (launchPowerDbm - 30) / 10);
    const noiseStd = Math.sqrt(numSpans * Math.pow(10, (edfaNoiseFigureDb - 4) / 20) * 0.008 + (distanceKm * 0.00003));
    const nonLinearPhase = 0.0012 * pTxW * distanceKm * 0.7; // Kerr effect phase shift

    // Generate I/Q Constellation with Noise & Dispersion Blur
    const constellation: ConstellationPoint[] = [];
    let totalEvmSquared = 0;

    for (let i = 0; i < numSymbols; i++) {
      const idealI = idealLevels[Math.floor(Math.random() * idealLevels.length)];
      const idealQ = idealLevels[Math.floor(Math.random() * idealLevels.length)];

      // Apply non-linear rotation & Gaussian ASE noise
      const r = Math.sqrt(idealI * idealI + idealQ * idealQ);
      const theta = Math.atan2(idealQ, idealI) + (nonLinearPhase * r * r) + ((Math.random() - 0.5) * 0.08);

      const noiseI = (Math.random() - 0.5) * noiseStd * 2;
      const noiseQ = (Math.random() - 0.5) * noiseStd * 2;

      const noisyI = r * Math.cos(theta) + noiseI;
      const noisyQ = r * Math.sin(theta) + noiseQ;

      const diffI = noisyI - idealI;
      const diffQ = noisyQ - idealQ;
      totalEvmSquared += (diffI * diffI + diffQ * diffQ) / (idealI * idealI + idealQ * idealQ + 1e-6);

      constellation.push({
        i: Math.round(noisyI * 1000) / 1000,
        q: Math.round(noisyQ * 1000) / 1000,
        idealI,
        idealQ,
        polarization: i % 2 === 0 ? 'X' : 'Y'
      });
    }

    const evmPercent = Math.min(45, Math.round(Math.sqrt(totalEvmSquared / numSymbols) * 1000) / 10);

    // Generate Eye Diagram Traces across 2 symbol periods (32 time slices per 2T)
    const samplesPerEye = 32;
    const timeAxisPs = Array.from({ length: samplesPerEye }, (_, idx) => 
      Math.round(((idx / (samplesPerEye - 1)) * (symbolPeriodPs * 2)) * 10) / 10
    );

    const traces: number[][] = [];
    for (let traceIdx = 0; traceIdx < 16; traceIdx++) {
      const trace: number[] = [];
      const sym1 = constellation[traceIdx * 2]?.i || 1;
      const sym2 = constellation[traceIdx * 2 + 1]?.i || -1;
      const jitter = (Math.random() - 0.5) * (noiseStd * 0.4);

      for (let s = 0; s < samplesPerEye; s++) {
        const tNorm = s / (samplesPerEye - 1);
        // Cosine raised pulse shape interpolation
        const baseShape = 0.5 * (1 + Math.cos(Math.PI * (tNorm * 2 - 1)));
        const intensity = 0.5 + 0.4 * ((1 - tNorm) * sym1 + tNorm * sym2) * baseShape + jitter;
        trace.push(Math.max(0.05, Math.min(0.95, Math.round(intensity * 1000) / 1000)));
      }
      traces.push(trace);
    }

    // Optical power profile along the spans (showing fiber attenuation and EDFA gain steps)
    const powerProfile: { distanceKm: number; powerDbm: number }[] = [];
    let currentKm = 0;
    while (currentKm <= distanceKm) {
      const spanPos = currentKm % 80;
      const currentPower = launchPowerDbm - (spanPos * 0.20);
      powerProfile.push({
        distanceKm: currentKm,
        powerDbm: Math.round(currentPower * 10) / 10
      });
      currentKm += Math.max(10, Math.floor(distanceKm / 20));
    }

    // Adaptive DSP Equalizer (CMA / LMS filter tap response)
    const equalizerWeights: number[] = [];
    const dspEqualizerTaps: { tapIndex: number; weight: number }[] = [];
    const midTap = Math.floor(equalizerTaps / 2);
    for (let tap = 0; tap < equalizerTaps; tap++) {
      const distFromCenter = Math.abs(tap - midTap);
      const weight = Math.exp(-distFromCenter * 0.35) * Math.cos(distFromCenter * 0.6) + (Math.random() - 0.5) * 0.04;
      const roundedWeight = Math.round(weight * 1000) / 1000;
      equalizerWeights.push(roundedWeight);
      dspEqualizerTaps.push({ tapIndex: tap - midTap, weight: roundedWeight });
    }

    const estimatedOsnrDb = Math.max(10, Math.round((28 - numSpans * 1.8 - (distanceKm * 0.004) - (evmPercent * 0.25)) * 10) / 10);
    const estimatedBer = parseFloat(Math.pow(10, -(estimatedOsnrDb / 3.8)).toExponential(2));
    const eyeOpeningHeightNormalized = Math.max(0.1, Math.round((1 - (evmPercent / 45)) * 100) / 100);
    const eyeOpeningPenaltyDb = Math.round((1.0 - eyeOpeningHeightNormalized) * 4.5 * 10) / 10;

    return {
      constellation,
      constellationPoints: constellation,
      eyeDiagram: {
        timeAxisPs,
        traces
      },
      evmPercent,
      opticalPowerProfile: powerProfile,
      equalizerWeights,
      dspEqualizerTaps,
      phaseNoiseVarianceRad: Math.round(nonLinearPhase * 1000) / 1000,
      estimatedOsnrDb,
      snrDb: estimatedOsnrDb,
      estimatedBer,
      berPreFec: estimatedBer,
      eyeOpeningHeightNormalized,
      eyeOpeningPenaltyDb
    };
  }
}
