import React, { useState } from 'react';
import { PlanningScenario } from '../types/optical';
import { CapacityEngine, TrafficForecastPoint, LinkExhaustionForecast } from '../engine/capacityEngine';
import { 
  TrendingUp, AlertTriangle, DollarSign, Calendar, 
  Layers, ArrowUpRight, BarChart3, CheckCircle2
} from 'lucide-react';

interface CapacityPlanningViewProps {
  scenarios: PlanningScenario[];
}

export const CapacityPlanningView: React.FC<CapacityPlanningViewProps> = ({ scenarios }) => {
  const [selectedScenarioId, setSelectedScenarioId] = useState<string>(scenarios[0]?.scenario_id || 'SCENARIO-A');
  const [trafficData] = useState<TrafficForecastPoint[]>(() => CapacityEngine.generateNationalTrafficForecast());
  const [exhaustionAlerts] = useState<LinkExhaustionForecast[]>(() => CapacityEngine.getExhaustionAlerts());

  const activeScenario = scenarios.find(s => s.scenario_id === selectedScenarioId) || scenarios[0];

  return (
    <div className="p-4 space-y-4 max-w-7xl mx-auto font-sans">
      {/* Top Banner */}
      <div className="bg-[#0e1422] p-4 rounded-md border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded bg-blue-950 border border-blue-700/60 text-blue-400">
            <TrendingUp className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold font-mono text-white">Capacity Planning & 24-Month Demand Forecasting</h2>
            <div className="text-xs font-mono text-slate-400">
              ARIMA / Holt-Winters Exponential Smoothing Model • Spectrum Exhaustion Predictor
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="px-2.5 py-1 rounded bg-slate-900 text-cyan-300 border border-slate-700">
            Current Core Utilization: <strong className="text-white">51.0%</strong>
          </span>
          <span className="px-2.5 py-1 rounded bg-slate-900 text-amber-300 border border-slate-700">
            Earliest Span Exhaustion: <strong className="text-amber-400">3 Months</strong>
          </span>
        </div>
      </div>

      {/* Traffic Growth Curve & Link Exhaustion Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left: 24-Month Projection Chart */}
        <div className="lg:col-span-8 bg-[#0e1422] rounded-md border border-slate-800 p-4 font-mono space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div>
              <span className="text-[10px] text-slate-500 uppercase">National Core Bandwidth Demand</span>
              <h3 className="text-sm font-bold text-white">24-Month Traffic Projection (Pb/s)</h3>
            </div>
            <div className="flex items-center gap-3 text-xs">
              <span className="flex items-center gap-1 text-cyan-400">
                <span className="w-3 h-0.5 bg-cyan-400" /> Projected
              </span>
              <span className="flex items-center gap-1 text-slate-400">
                <span className="w-3 h-0.5 bg-slate-400" /> Historical
              </span>
            </div>
          </div>

          {/* SVG Growth Chart */}
          <div className="w-full h-56 bg-slate-950 rounded border border-slate-800 p-2 flex flex-col justify-end">
            <svg className="w-full h-full" viewBox="0 0 600 180">
              {/* Grid Lines */}
              <line x1="40" y1="20" x2="580" y2="20" stroke="#1e293b" strokeDasharray="3,3" />
              <line x1="40" y1="60" x2="580" y2="60" stroke="#1e293b" strokeDasharray="3,3" />
              <line x1="40" y1="100" x2="580" y2="100" stroke="#1e293b" strokeDasharray="3,3" />
              <line x1="40" y1="140" x2="580" y2="140" stroke="#1e293b" strokeDasharray="3,3" />

              {/* Y Axis Labels */}
              <text x="5" y="24" fill="#64748b" fontSize="9" fontFamily="monospace">4.0 Pb/s</text>
              <text x="5" y="64" fill="#64748b" fontSize="9" fontFamily="monospace">3.0 Pb/s</text>
              <text x="5" y="104" fill="#64748b" fontSize="9" fontFamily="monospace">2.0 Pb/s</text>
              <text x="5" y="144" fill="#64748b" fontSize="9" fontFamily="monospace">1.0 Pb/s</text>

              {/* Area Confidence Band */}
              <path
                d="M 40 130 L 80 125 L 120 120 L 160 115 L 200 110 L 240 102 L 280 94 L 320 86 L 360 76 L 400 66 L 440 55 L 480 44 L 520 33 L 560 22 L 560 48 L 520 62 L 480 75 L 440 88 L 400 99 L 360 110 L 320 120 L 280 128 L 240 134 L 200 140 L 160 145 L 120 148 L 80 152 L 40 155 Z"
                fill="#06b6d4"
                opacity="0.1"
              />

              {/* Main Line */}
              <path
                d="M 40 142 L 80 138 L 120 134 L 160 130 L 200 124 L 240 118 L 280 110 L 320 102 L 360 92 L 400 82 L 440 70 L 480 58 L 520 46 L 560 34"
                fill="none"
                stroke="#06b6d4"
                strokeWidth="2.5"
              />

              {/* Historical Cutoff Marker */}
              <line x1="280" y1="10" x2="280" y2="160" stroke="#f59e0b" strokeWidth="1.5" strokeDasharray="4,4" />
              <text x="285" y="20" fill="#f59e0b" fontSize="9" fontFamily="monospace">TODAY (SEPT 2026)</text>
            </svg>
          </div>
        </div>

        {/* Right: Link Exhaustion Alert Box */}
        <div className="lg:col-span-4 bg-[#0e1422] rounded-md border border-slate-800 p-4 font-mono text-xs space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="font-bold text-amber-400 uppercase flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4" />
              <span>Spectrum Exhaustion Alerts</span>
            </span>
          </div>

          <div className="space-y-2">
            {exhaustionAlerts.map(alert => (
              <div key={alert.cableId} className="p-3 bg-slate-900 rounded border border-slate-800 space-y-1.5">
                <div className="flex justify-between font-bold">
                  <span className="text-white">{alert.cableId}</span>
                  <span className="text-amber-400">{alert.monthsRemaining} Mo. Left</span>
                </div>
                <div className="text-[11px] text-slate-400 font-sans">{alert.cableName}</div>
                <div className="text-[10px] text-cyan-300 bg-cyan-950/60 p-1.5 rounded border border-cyan-800/50">
                  Action: {alert.recommendedAction}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Scenarios A to F Comparison Table */}
      <div className="bg-[#0e1422] rounded-md border border-slate-800 p-4 font-mono text-xs space-y-3">
        <h3 className="text-sm font-bold text-white uppercase">
          National Planning Scenarios (A - F)
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {scenarios.map(sc => {
            const isSelected = sc.scenario_id === selectedScenarioId;
            return (
              <div
                key={sc.scenario_id}
                onClick={() => setSelectedScenarioId(sc.scenario_id)}
                className={`p-3 rounded-md border transition cursor-pointer space-y-2 ${
                  isSelected
                    ? 'bg-slate-800/90 border-cyan-500 shadow-md'
                    : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white">{sc.scenario_id}</span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-blue-950 text-blue-300 border border-blue-800">
                    +{sc.growth_rate_annual_percent}% YoY
                  </span>
                </div>

                <div className="text-cyan-300 font-bold">{sc.name}</div>
                <p className="text-[11px] text-slate-400 font-sans">{sc.description}</p>

                <div className="border-t border-slate-800 pt-2 flex justify-between text-[11px] text-slate-300">
                  <span>Est. CAPEX: <strong className="text-emerald-400">£{(sc.estimated_capex_gbp / 1e6).toFixed(1)}M</strong></span>
                  <span>Est. OPEX: <strong className="text-slate-200">£{(sc.estimated_opex_annual_gbp / 1e6).toFixed(1)}M/yr</strong></span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
