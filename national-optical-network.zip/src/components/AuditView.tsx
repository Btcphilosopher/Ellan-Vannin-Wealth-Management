import React, { useState } from 'react';
import { AuditEvent, UserRole } from '../types/optical';
import { AuditEngine } from '../engine/auditEngine';
import { 
  ShieldCheck, Lock, Download, CheckCircle, Search, 
  Key, FileText, Filter, Terminal
} from 'lucide-react';

interface AuditViewProps {
  currentRole: UserRole;
}

export const AuditView: React.FC<AuditViewProps> = ({ currentRole }) => {
  const [logs] = useState<AuditEvent[]>(() => AuditEngine.getLogs());
  const [searchQuery, setSearchQuery] = useState('');
  const [exportNotice, setExportNotice] = useState(false);

  const filteredLogs = logs.filter(l => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        l.audit_id.toLowerCase().includes(q) ||
        l.user.toLowerCase().includes(q) ||
        l.action.toLowerCase().includes(q) ||
        l.target_object.toLowerCase().includes(q) ||
        l.details.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleExportComplianceReport = () => {
    setExportNotice(true);
    setTimeout(() => setExportNotice(false), 3000);
  };

  return (
    <div className="p-4 space-y-4 max-w-7xl mx-auto font-sans">
      {/* Top Banner */}
      <div className="bg-[#0e1422] p-4 rounded-md border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded bg-emerald-950 border border-emerald-700/60 text-emerald-400">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold font-mono text-white">Cryptographic Audit Trail & Critical Infrastructure Compliance</h2>
            <div className="text-xs font-mono text-slate-400">
              Immutable SHA-256 Signed Audit Records • National Telecommunications Cyber Security Act Compliance
            </div>
          </div>
        </div>

        <button
          onClick={handleExportComplianceReport}
          className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-600 px-3 py-1.5 rounded text-xs font-mono font-bold transition cursor-pointer"
        >
          <Download className="w-3.5 h-3.5 text-cyan-400" />
          <span>Export Regulatory Compliance Bundle</span>
        </button>
      </div>

      {exportNotice && (
        <div className="bg-emerald-950/80 border border-emerald-800 text-emerald-200 p-3 rounded text-xs font-mono flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-emerald-400" />
          <span>Regulatory Compliance Pack generated with 1,482 verified digital signatures. Export ready.</span>
        </div>
      )}

      {/* Audit Log Table */}
      <div className="bg-[#0e1422] rounded-md border border-slate-800 p-4 font-mono text-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Terminal className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-bold text-white uppercase">Authoritative System Event Log</h3>
          </div>

          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2 top-2 text-slate-400" />
            <input
              type="text"
              placeholder="Search user, action, target..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-7 pr-2.5 py-1 bg-slate-900 border border-slate-700 rounded text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 bg-slate-900/50">
                <th className="p-2.5">Event ID</th>
                <th className="p-2.5">Timestamp</th>
                <th className="p-2.5">Operator & Role</th>
                <th className="p-2.5">Action Executed</th>
                <th className="p-2.5">Target Object</th>
                <th className="p-2.5">Digital Signature (SHA-256)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredLogs.map((log) => (
                <tr key={log.audit_id} className="hover:bg-slate-800/40 transition">
                  <td className="p-2.5 font-bold text-cyan-400">{log.audit_id}</td>
                  <td className="p-2.5 text-slate-400">{new Date(log.timestamp).toLocaleString()}</td>
                  <td className="p-2.5">
                    <div className="font-bold text-white">{log.user}</div>
                    <div className="text-[10px] text-slate-500">{log.role}</div>
                  </td>
                  <td className="p-2.5 font-bold text-slate-200">{log.action}</td>
                  <td className="p-2.5 text-slate-300">{log.target_object}</td>
                  <td className="p-2.5 text-[10px] text-slate-500 font-mono truncate max-w-xs">
                    {log.digital_signature}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
