import React, { useState, useMemo } from 'react';
import { 
  OpticalNode, FibreCable, LayerType, MapMode, ServiceCircuit, Alarm 
} from '../types/optical';
import { 
  Layers, Eye, AlertTriangle, Zap, Server, Activity, 
  Search, ZoomIn, ZoomOut, RotateCcw, Filter, Radio, ArrowRight
} from 'lucide-react';

interface NationalMapProps {
  nodes: OpticalNode[];
  cables: FibreCable[];
  services: ServiceCircuit[];
  alarms: Alarm[];
  selectedNodeId: string | null;
  selectedCableId: string | null;
  onSelectNode: (node: OpticalNode | null) => void;
  onSelectCable: (cable: FibreCable | null) => void;
  highlightedPathNodeIds?: string[];
}

export const NationalMap: React.FC<NationalMapProps> = ({
  nodes,
  cables,
  services,
  alarms,
  selectedNodeId,
  selectedCableId,
  onSelectNode,
  onSelectCable,
  highlightedPathNodeIds = []
}) => {
  const [mapMode, setMapMode] = useState<MapMode>('PHYSICAL');
  const [activeLayers, setActiveLayers] = useState<Record<LayerType, boolean>>({
    CORE: true,
    REGIONAL: true,
    METRO: true,
    FTTH: true,
    SUBSEA: true,
    MOBILE: true,
    DATACENTRE: true,
    DARK_FIBRE: true,
    FAULTS: true,
    MAINTENANCE: true,
    CONSTRUCTION: true
  });

  const [zoom, setZoom] = useState<number>(1);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [searchQuery, setSearchQuery] = useState('');

  // Map Bounds for UK projection: Lat 50.0 to 59.0, Lng -7.0 to +2.0
  const MAP_WIDTH = 900;
  const MAP_HEIGHT = 800;

  const projectCoord = (lat: number, lng: number): [number, number] => {
    const minLat = 50.2;
    const maxLat = 56.5;
    const minLng = -5.5;
    const maxLng = 1.0;

    const x = ((lng - minLng) / (maxLng - minLng)) * (MAP_WIDTH - 160) + 80;
    const y = ((maxLat - lat) / (maxLat - minLat)) * (MAP_HEIGHT - 160) + 80;
    return [x, y];
  };

  const toggleLayer = (layer: LayerType) => {
    setActiveLayers(prev => ({ ...prev, [layer]: !prev[layer] }));
  };

  const filteredNodes = useMemo(() => {
    return nodes.filter(node => {
      if (!activeLayers[node.layer]) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return (
          node.name.toLowerCase().includes(q) ||
          node.object_id.toLowerCase().includes(q) ||
          node.location.city.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [nodes, activeLayers, searchQuery]);

  const filteredCables = useMemo(() => {
    return cables.filter(cable => {
      const srcNode = nodes.find(n => n.object_id === cable.source_node_id);
      const tgtNode = nodes.find(n => n.object_id === cable.target_node_id);
      if (!srcNode || !tgtNode) return false;
      if (!activeLayers[srcNode.layer] && !activeLayers[tgtNode.layer]) return false;
      if (cable.health_status === 'SEVERED' && !activeLayers.FAULTS) return false;
      return true;
    });
  }, [cables, nodes, activeLayers]);

  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.button === 0) {
      setIsDragging(true);
      setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDragging) {
      setPan({
        x: e.clientX - dragStart.x,
        y: e.clientY - dragStart.y
      });
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  return (
    <div className="relative w-full h-[calc(100vh-145px)] bg-[#070b12] overflow-hidden flex">
      {/* Top Map Controls Overlay */}
      <div className="absolute top-3 left-3 z-30 flex flex-wrap items-center gap-2 bg-[#0e1422]/90 backdrop-blur border border-slate-700/80 p-2 rounded-md shadow-xl text-xs">
        {/* Mode Selector */}
        <div className="flex items-center gap-1.5 border-r border-slate-700 pr-2">
          <span className="font-mono text-slate-400 font-semibold uppercase text-[10px]">VIEW MODE:</span>
          <select
            value={mapMode}
            onChange={(e) => setMapMode(e.target.value as MapMode)}
            className="bg-slate-900 text-cyan-300 font-mono font-bold px-2 py-1 rounded border border-slate-700 focus:outline-none cursor-pointer"
          >
            <option value="PHYSICAL">PHYSICAL DUCT & FIBRE</option>
            <option value="OPTICAL">OPTICAL WDM & ROADM</option>
            <option value="IP">IP & ROUTING TOPOLOGY</option>
            <option value="SERVICE">ACTIVE SERVICES & SLA</option>
            <option value="CAPACITY">CAPACITY & UTILIZATION</option>
            <option value="FAULT">FAULTS & SEVERED LINKS</option>
            <option value="ENERGY">ENERGY DRAW (kW/POP)</option>
          </select>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="w-3.5 h-3.5 absolute left-2 top-2 text-slate-400" />
          <input
            type="text"
            placeholder="Search POP, City, Span ID..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-7 pr-2 py-1 w-48 bg-slate-900 border border-slate-700 rounded text-slate-200 font-mono placeholder:text-slate-500 focus:outline-none focus:border-cyan-500"
          />
        </div>

        {/* Zoom Controls */}
        <div className="flex items-center gap-1 border-l border-slate-700 pl-2">
          <button
            onClick={() => setZoom(z => Math.min(2.5, z + 0.25))}
            className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-600 cursor-pointer"
            title="Zoom In"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setZoom(z => Math.max(0.6, z - 0.25))}
            className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-600 cursor-pointer"
            title="Zoom Out"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => { setZoom(1); setPan({ x: 0, y: 0 }); }}
            className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-600 cursor-pointer"
            title="Reset Pan/Zoom"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Layer Filter Drawer (Left Overlay) */}
      <div className="absolute top-16 left-3 z-30 bg-[#0e1422]/90 backdrop-blur border border-slate-800 p-3 rounded-md shadow-xl text-xs w-52 font-mono">
        <div className="flex items-center justify-between font-bold text-slate-300 border-b border-slate-700/80 pb-1.5 mb-2 text-[11px]">
          <span className="flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5 text-cyan-400" />
            <span>OPTICAL LAYERS</span>
          </span>
          <span className="text-[10px] text-slate-500">11 ACTIVE</span>
        </div>

        <div className="space-y-1 max-h-[380px] overflow-y-auto pr-1">
          {(Object.keys(activeLayers) as LayerType[]).map((layer) => {
            const isActive = activeLayers[layer];
            return (
              <label
                key={layer}
                className={`flex items-center justify-between px-2 py-1 rounded cursor-pointer transition text-[11px] ${
                  isActive ? 'bg-slate-800/80 text-cyan-300 border border-slate-700' : 'text-slate-500 hover:bg-slate-900'
                }`}
              >
                <span>{layer.replace('_', ' ')}</span>
                <input
                  type="checkbox"
                  checked={isActive}
                  onChange={() => toggleLayer(layer)}
                  className="accent-cyan-500 cursor-pointer"
                />
              </label>
            );
          })}
        </div>
      </div>

      {/* Main Vector SVG Geographic Canvas */}
      <div
        className="w-full h-full cursor-grab active:cursor-grabbing flex items-center justify-center relative"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
      >
        <svg
          width={MAP_WIDTH}
          height={MAP_HEIGHT}
          viewBox={`0 0 ${MAP_WIDTH} ${MAP_HEIGHT}`}
          className="transition-transform duration-75 select-none"
          style={{
            transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
            transformOrigin: 'center center'
          }}
        >
          {/* Subtle Grid Background */}
          <defs>
            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#131e33" strokeWidth="0.75" />
            </pattern>
            {/* Pulsing Light Filters */}
            <filter id="glow-cyan" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="3" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
            <filter id="glow-red" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="4" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>

          <rect width={MAP_WIDTH} height={MAP_HEIGHT} fill="url(#grid)" />

          {/* Render Fibre Cable Spans */}
          {filteredCables.map((cable) => {
            const srcNode = nodes.find(n => n.object_id === cable.source_node_id);
            const tgtNode = nodes.find(n => n.object_id === cable.target_node_id);
            if (!srcNode || !tgtNode) return null;

            // Generate Path String from coordinates
            let pathString = '';
            if (cable.geo_coordinates && cable.geo_coordinates.length > 0) {
              const projectedPoints = cable.geo_coordinates.map(pt => projectCoord(pt[0], pt[1]));
              pathString = `M ${projectedPoints[0][0]} ${projectedPoints[0][1]} ` +
                projectedPoints.slice(1).map(p => `L ${p[0]} ${p[1]}`).join(' ');
            } else {
              const [x1, y1] = projectCoord(srcNode.location.lat, srcNode.location.lng);
              const [x2, y2] = projectCoord(tgtNode.location.lat, tgtNode.location.lng);
              pathString = `M ${x1} ${y1} L ${x2} ${y2}`;
            }

            const isSelected = selectedCableId === cable.object_id;
            const isSevered = cable.health_status === 'SEVERED';
            const isPathHighlighted = highlightedPathNodeIds.includes(cable.source_node_id) && 
                                      highlightedPathNodeIds.includes(cable.target_node_id);

            // Color based on mapMode
            let strokeColor = '#2563eb'; // Default Blue
            if (isSevered) strokeColor = '#ef4444'; // Red
            else if (isPathHighlighted) strokeColor = '#06b6d4'; // Cyan Highlight
            else if (mapMode === 'CAPACITY') {
              const util = (cable.used_capacity_gbps / (cable.total_capacity_gbps || 1)) * 100;
              strokeColor = util > 80 ? '#f59e0b' : util > 50 ? '#3b82f6' : '#10b981';
            } else if (mapMode === 'OPTICAL') {
              strokeColor = '#06b6d4';
            } else if (mapMode === 'PHYSICAL') {
              strokeColor = cable.fibre_type === 'G.654.E' ? '#8b5cf6' : '#3b82f6';
            }

            return (
              <g key={cable.object_id} className="cursor-pointer group" onClick={() => onSelectCable(cable)}>
                {/* Thick Transparent Hit Area */}
                <path
                  d={pathString}
                  stroke="transparent"
                  strokeWidth="16"
                  fill="none"
                />

                {/* Main Cable Line */}
                <path
                  d={pathString}
                  stroke={strokeColor}
                  strokeWidth={isSelected ? 4.5 : isPathHighlighted ? 3.5 : isSevered ? 3 : 2}
                  strokeDasharray={isSevered ? '6,4' : undefined}
                  filter={isSelected || isSevered || isPathHighlighted ? (isSevered ? 'url(#glow-red)' : 'url(#glow-cyan)') : undefined}
                  fill="none"
                  className="transition-all duration-150 group-hover:stroke-cyan-300"
                />

                {/* Active Light Pulse Animation for Live Cables */}
                {!isSevered && (
                  <circle r="2.5" fill="#a5f3fc">
                    <animateMotion path={pathString} dur={`${Math.max(2, cable.length_km / 50)}s`} repeatCount="indefinite" />
                  </circle>
                )}

                {/* Severed Fault Marker */}
                {isSevered && (
                  <g transform={`translate(${projectCoord(cable.geo_coordinates[1] ? cable.geo_coordinates[1][0] : srcNode.location.lat, cable.geo_coordinates[1] ? cable.geo_coordinates[1][1] : srcNode.location.lng).join(',')})`}>
                    <circle r="9" fill="#7f1d1d" opacity="0.8" className="animate-ping" />
                    <circle r="6" fill="#ef4444" />
                    <text x="8" y="3" fill="#fca5a5" fontSize="9" fontFamily="monospace" fontWeight="bold">
                      FIBRE SEVERED (km 48.2)
                    </text>
                  </g>
                )}
              </g>
            );
          })}

          {/* Render Optical Nodes */}
          {filteredNodes.map((node) => {
            const [x, y] = projectCoord(node.location.lat, node.location.lng);
            const isSelected = selectedNodeId === node.object_id;
            const isPathNode = highlightedPathNodeIds.includes(node.object_id);

            let nodeColor = '#38bdf8'; // sky blue
            let nodeRadius = 6;

            if (node.role === 'NATIONAL_CORE_POP') {
              nodeColor = '#38bdf8';
              nodeRadius = 8;
            } else if (node.role === 'DATA_CENTRE_HYPERSCALE') {
              nodeColor = '#a855f7'; // Purple
              nodeRadius = 9;
            } else if (node.role === 'SUBSEA_LANDING_STATION') {
              nodeColor = '#06b6d4'; // Cyan
              nodeRadius = 8;
            } else if (node.role === 'FTTH_CENTRAL_EXCHANGE') {
              nodeColor = '#10b981'; // Green
              nodeRadius = 5.5;
            } else if (node.role === 'MOBILE_CELL_HUB') {
              nodeColor = '#f59e0b'; // Amber
              nodeRadius = 5.5;
            }

            return (
              <g
                key={node.object_id}
                transform={`translate(${x}, ${y})`}
                className="cursor-pointer group"
                onClick={(e) => {
                  e.stopPropagation();
                  onSelectNode(node);
                }}
              >
                {/* Node Outer Selection Halo */}
                {isSelected && (
                  <circle r={nodeRadius + 6} fill="none" stroke="#22d3ee" strokeWidth="2" strokeDasharray="3,3" className="animate-spin" />
                )}

                {/* Node Base Circle */}
                <circle
                  r={nodeRadius}
                  fill="#0b1120"
                  stroke={nodeColor}
                  strokeWidth={isSelected || isPathNode ? 3 : 2}
                  className="transition-transform duration-150 group-hover:scale-125"
                />

                <circle r={nodeRadius - 2.5} fill={nodeColor} />

                {/* Node Text Label */}
                <text
                  x={nodeRadius + 6}
                  y="3.5"
                  fill={isSelected ? '#38bdf8' : '#cbd5e1'}
                  fontSize="10"
                  fontFamily="monospace"
                  fontWeight={node.role === 'NATIONAL_CORE_POP' ? 'bold' : 'normal'}
                  className="pointer-events-none drop-shadow-md select-none"
                >
                  {node.location.city}
                </text>
              </g>
            );
          })}
        </svg>
      </div>

      {/* Quick Map Legend (Bottom Right Overlay) */}
      <div className="absolute bottom-3 right-3 z-30 bg-[#0e1422]/90 backdrop-blur border border-slate-800 p-2.5 rounded-md shadow-xl text-[11px] font-mono text-slate-300">
        <div className="font-bold text-slate-400 border-b border-slate-700/80 pb-1 mb-1.5 flex items-center justify-between gap-4">
          <span>TOPOLOGY LEGEND</span>
          <span className="text-[10px] text-cyan-400">UK NATIONAL GRID</span>
        </div>
        <div className="grid grid-cols-2 gap-x-4 gap-y-1">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-[#38bdf8]" />
            <span>National Core POP</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-[#a855f7]" />
            <span>Hyperscale DC Hub</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-[#06b6d4]" />
            <span>Subsea Landing</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-[#10b981]" />
            <span>FTTH Exchange</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-0.5 bg-[#8b5cf6]" />
            <span>G.654.E Low-Loss</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-0.5 bg-[#ef4444]" />
            <span>Severed Cable (Fault)</span>
          </div>
        </div>
      </div>
    </div>
  );
};
