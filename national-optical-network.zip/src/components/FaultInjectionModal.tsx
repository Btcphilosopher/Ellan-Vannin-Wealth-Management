import React, { useState } from 'react';
import { FibreCable, OpticalNode } from '../types/optical';
import { 
  AlertTriangle, X, Zap, Activity, Waves, CheckCircle2, RefreshCw 
} from 'lucide-react';

interface FaultInjectionModalProps {
  cables: FibreCable[];
  isOpen: boolean;
  onClose: () => void;
  onInject: (cableId: string, faultType: string) => void;
}

export const FaultInjectionModal: React.FC<FaultInjectionModalProps> = ({
  cables,
  isOpen,
  onClose,
  onInject
}) => {
  const [selectedCableId, setSelectedCableId] = useState<string>(cables[0]?.object_id || '');
  const [faultType, setFaultType] = useState<string>('FIBRE_CUT');

  if (!isOpen) return null;

  const handleExecute = () => {
    onInject(selectedCableId, faultType);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4 font-mono text-xs">
      <div className="bg-[#0e1422] border border-slate-700 rounded-lg max-w-lg w-full p-5 space-y-4 shadow-2xl text-slate-200">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
            <AlertTriangle className="w-5 h-5" />
            <span>Simulate Optical Fault Injection</span>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Cable Target */}
        <div className="space-y-1.5">
          <label className="text-slate-400 uppercase text-[10px] font-bold">Target Fibre Cable Span:</label>
          <select
            value={selectedCableId}
            onChange={(e) => setSelectedCableId(e.target.value)}
            className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white focus:outline-none focus:border-cyan-500"
          >
            {cables.map(c => (
              <option key={c.object_id} value={c.object_id}>
                {c.name} ({c.length_km} km • {c.fibre_type})
              </option>
            ))}
          </select>
        </div>

        {/* Fault Type */}
        <div className="space-y-1.5">
          <label className="text-slate-400 uppercase text-[10px] font-bold">Fault Profile / Failure Mode:</label>
          <select
            value={faultType}
            onChange={(e) => setFaultType(e.target.value)}
            className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white focus:outline-none focus:border-cyan-500"
          >
            <option value="FIBRE_CUT">Physical Cable Sever / Backhoe Excavation (Total LOS)</option>
            <option value="DEGRADATION">Micro-bend High Attenuation (+12 dB Loss)</option>
            <option value="EDFA_PUMP_FAIL">EDFA Optical Pump Laser Failure (ASE Surge)</option>
            <option value="POLARIZATION_SCRAMBLE">Rapid Polarization Transient / PMD Spike</option>
          </select>
        </div>

        {/* Warning Notice */}
        <div className="bg-amber-950/30 border border-amber-800/60 p-3 rounded text-amber-200 text-[11px] font-sans">
          <strong>Digital Twin Simulation Note:</strong> Injecting this fault will trigger the real-time optical physics engine, fire correlated alarm bursts, update telemetry, and generate automated root-cause incidents with work orders.
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
          <button
            onClick={onClose}
            className="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
          >
            Cancel
          </button>
          <button
            onClick={handleExecute}
            className="px-4 py-1.5 rounded bg-red-600 hover:bg-red-500 text-white font-bold cursor-pointer transition shadow"
          >
            Inject Fault
          </button>
        </div>
      </div>
    </div>
  );
};
