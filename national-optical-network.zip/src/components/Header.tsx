import React from 'react';
import { 
  Radio, Shield, Activity, Clock, RefreshCw, AlertTriangle, 
  Layers, Server, Zap, UserCheck, Lock, Play, Pause, ChevronRight
} from 'lucide-react';
import { UserRole, Incident } from '../types/optical';

interface HeaderProps {
  currentRole: UserRole;
  onRoleChange: (role: UserRole) => void;
  activeIncidents: Incident[];
  timeMachineDate: string;
  isTimeMachineActive: boolean;
  onToggleTimeMachine: () => void;
  onResetTimeMachine: () => void;
  onInjectFaultClick: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentRole,
  onRoleChange,
  activeIncidents,
  timeMachineDate,
  isTimeMachineActive,
  onToggleTimeMachine,
  onResetTimeMachine,
  onInjectFaultClick
}) => {
  const criticalCount = activeIncidents.filter(i => i.status !== 'RESOLVED').length;

  return (
    <header className="bg-[#0e1420] border-b border-slate-800 text-slate-200 select-none sticky top-0 z-50">
      {/* Topmost Institutional Banner */}
      <div className="px-4 py-2 flex flex-wrap items-center justify-between gap-3 text-xs border-b border-slate-800/80 bg-[#090d16]">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="font-mono uppercase font-bold tracking-wider text-slate-300">
              NATIONAL OPTICAL NETWORK
            </span>
          </div>
          <span className="text-slate-600">|</span>
          <span className="font-mono text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/50">
            NATIONAL FIBRE DIGITAL TWIN
          </span>
          <span className="text-slate-600">|</span>
          <span className="font-mono text-slate-400">
            SYSTEM VERSION: <strong className="text-slate-200">v2026.09.17-RELEASE</strong>
          </span>
          <span className="text-slate-600">|</span>
          <span className="font-mono text-emerald-400">
            PHYSICAL TWIN SYNC: 100% RECONCILED
          </span>
        </div>

        <div className="flex items-center gap-4">
          {/* Time Machine status */}
          <div className="flex items-center gap-2 bg-slate-900 px-2.5 py-1 rounded border border-slate-700">
            <Clock className={`w-3.5 h-3.5 ${isTimeMachineActive ? 'text-amber-400 animate-spin' : 'text-slate-400'}`} />
            <span className="font-mono text-slate-300">
              {isTimeMachineActive ? `TIME TRAVEL: ${timeMachineDate}` : 'LIVE REAL-TIME TELEMETRY'}
            </span>
            <button
              onClick={onToggleTimeMachine}
              className="text-[11px] px-1.5 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-600 cursor-pointer"
            >
              {isTimeMachineActive ? 'Return to Live' : 'Time Travel'}
            </button>
          </div>

          {/* Role selector */}
          <div className="flex items-center gap-1.5 bg-slate-900 px-2 py-1 rounded border border-slate-700">
            <UserCheck className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-slate-400 font-mono text-[11px]">ROLE:</span>
            <select
              value={currentRole}
              onChange={(e) => onRoleChange(e.target.value as UserRole)}
              className="bg-transparent text-cyan-300 font-mono text-xs font-semibold focus:outline-none cursor-pointer"
            >
              <option value="NOC_OPERATOR" className="bg-slate-900 text-slate-100">NOC OPERATOR</option>
              <option value="OPTICAL_ENGINEER" className="bg-slate-900 text-slate-100">OPTICAL ENGINEER</option>
              <option value="NETWORK_ENGINEER" className="bg-slate-900 text-slate-100">NETWORK ENGINEER</option>
              <option value="PLANNER" className="bg-slate-900 text-slate-100">CAPACITY PLANNER</option>
              <option value="FIELD_ENGINEER" className="bg-slate-900 text-slate-100">FIELD ENGINEER</option>
              <option value="SECURITY" className="bg-slate-900 text-slate-100">SECURITY & CIP</option>
              <option value="ADMIN" className="bg-slate-900 text-slate-100">SYSTEM ADMIN</option>
              <option value="AUDITOR" className="bg-slate-900 text-slate-100">REGULATORY AUDITOR</option>
              <option value="EXECUTIVE_VIEWER" className="bg-slate-900 text-slate-100">EXECUTIVE VIEWER</option>
            </select>
          </div>
        </div>
      </div>

      {/* Main Bar with KPIs & Fault Injector */}
      <div className="px-4 py-2.5 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded bg-cyan-950 border border-cyan-700/60 text-cyan-400">
              <Radio className="w-4 h-4" />
            </div>
            <div>
              <div className="text-[10px] uppercase font-mono text-slate-400 leading-tight">National Backbone</div>
              <div className="text-sm font-bold font-mono tracking-tight text-white">2.14 Pb/s <span className="text-[11px] font-normal text-emerald-400">▲ +4.2%</span></div>
            </div>
          </div>

          <div className="hidden sm:flex items-center gap-2">
            <div className="p-1.5 rounded bg-blue-950 border border-blue-700/60 text-blue-400">
              <Layers className="w-4 h-4" />
            </div>
            <div>
              <div className="text-[10px] uppercase font-mono text-slate-400 leading-tight">Active Wavelengths</div>
              <div className="text-sm font-bold font-mono tracking-tight text-white">324 <span className="text-[11px] font-normal text-slate-400">/ 1,920 λ</span></div>
            </div>
          </div>

          <div className="hidden md:flex items-center gap-2">
            <div className="p-1.5 rounded bg-indigo-950 border border-indigo-700/60 text-indigo-400">
              <Zap className="w-4 h-4" />
            </div>
            <div>
              <div className="text-[10px] uppercase font-mono text-slate-400 leading-tight">Grid Power Draw</div>
              <div className="text-sm font-bold font-mono tracking-tight text-white">18.4 MW <span className="text-[11px] font-normal text-slate-400">(4.8 kWh/Tb)</span></div>
            </div>
          </div>

          <div className="hidden lg:flex items-center gap-2">
            <div className="p-1.5 rounded bg-emerald-950 border border-emerald-700/60 text-emerald-400">
              <Shield className="w-4 h-4" />
            </div>
            <div>
              <div className="text-[10px] uppercase font-mono text-slate-400 leading-tight">30-Day SLA Compliance</div>
              <div className="text-sm font-bold font-mono tracking-tight text-emerald-400">99.994%</div>
            </div>
          </div>
        </div>

        {/* Action Controls & Emergency Alert Button */}
        <div className="flex items-center gap-3">
          {criticalCount > 0 ? (
            <div className="flex items-center gap-2 bg-red-950/80 border border-red-700/80 text-red-200 px-3 py-1.5 rounded text-xs font-mono font-bold animate-pulse">
              <AlertTriangle className="w-4 h-4 text-red-400" />
              <span>{criticalCount} CRITICAL INCIDENT ACTIVE</span>
            </div>
          ) : (
            <div className="flex items-center gap-1.5 bg-emerald-950/40 border border-emerald-800/40 text-emerald-300 px-2.5 py-1 rounded text-xs font-mono">
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              <span>ALL NATIONAL SPANS NOMINAL</span>
            </div>
          )}

          <button
            onClick={onInjectFaultClick}
            className="flex items-center gap-1.5 bg-amber-600/20 hover:bg-amber-600/30 border border-amber-500/60 text-amber-300 hover:text-amber-200 px-3 py-1.5 rounded text-xs font-mono font-semibold transition cursor-pointer"
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Simulate Fibre Fault</span>
          </button>
        </div>
      </div>
    </header>
  );
};
