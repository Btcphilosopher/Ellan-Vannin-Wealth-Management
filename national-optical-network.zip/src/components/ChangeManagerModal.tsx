import React, { useState } from 'react';
import { ChangeRequest, AutomationLevel, UserRole } from '../types/optical';
import { AuditEngine } from '../engine/auditEngine';
import { 
  GitPullRequest, CheckCircle2, ShieldAlert, ArrowRight, 
  RotateCcw, Play, Check, AlertTriangle, FileCode2
} from 'lucide-react';

interface ChangeManagerModalProps {
  currentRole: UserRole;
  changeRequests: ChangeRequest[];
  onExecuteChange: (crId: string) => void;
  onApproveChange: (crId: string) => void;
}

export const ChangeManagerModal: React.FC<ChangeManagerModalProps> = ({
  currentRole,
  changeRequests,
  onExecuteChange,
  onApproveChange
}) => {
  const [selectedCrId, setSelectedCrId] = useState<string>(changeRequests[0]?.request_id || '');
  const [activeTab, setActiveTab] = useState<'SANDBOX_BUILDER' | 'ACTIVE_REQUESTS'>('ACTIVE_REQUESTS');

  // New Change Proposal State
  const [targetObject, setTargetObject] = useState('NODE-LON-CORE-01');
  const [changeType, setChangeType] = useState('PROVISION_WAVELENGTH');
  const [autoLevel, setAutoLevel] = useState<AutomationLevel>('LEVEL_4_HUMAN_APPROVAL');
  const [justification, setJustification] = useState('Light 800G line rate on London-Birmingham Route for Tier 1 Financial low-latency service');

  const selectedCr = changeRequests.find(c => c.request_id === selectedCrId) || changeRequests[0];

  const handleProposeChange = () => {
    AuditEngine.createChangeRequest({
      operator: 'current.user@nat-optical.gov.uk',
      role: currentRole,
      automation_level: autoLevel,
      reason: justification,
      target_object_ids: [targetObject],
      change_type: changeType as any,
      before_state_summary: 'Existing 400G DP-QPSK channel active. Margin 4.2 dB.',
      proposed_state_summary: 'Deploy 800G DP-16QAM flex-grid channel. Expected margin 3.1 dB.',
      risk_score: 'LOW',
      blast_radius_services: 0,
      qot_impact_db: 0.3,
      validation_status: 'PASSED',
      approval_status: autoLevel === 'LEVEL_5_AUTONOMOUS' ? 'APPROVED' : 'PENDING_APPROVAL',
      execution_status: autoLevel === 'LEVEL_5_AUTONOMOUS' ? 'COMMITTED' : 'READY_TO_EXECUTE'
    });
    setActiveTab('ACTIVE_REQUESTS');
  };

  return (
    <div className="p-4 space-y-4 max-w-7xl mx-auto font-sans">
      {/* Top Banner */}
      <div className="bg-[#0e1422] p-4 rounded-md border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded bg-indigo-950 border border-indigo-700/60 text-indigo-400">
            <GitPullRequest className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold font-mono text-white">Safe Automation Sandbox & Change Management</h2>
            <div className="text-xs font-mono text-slate-400">
              Zero-Downtime Verification • Rollback Snapshot Engine • Levels 0 to 5 Automation Gates
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('ACTIVE_REQUESTS')}
            className={`px-3 py-1.5 rounded text-xs font-mono transition cursor-pointer ${
              activeTab === 'ACTIVE_REQUESTS'
                ? 'bg-cyan-600 text-white font-bold'
                : 'bg-slate-900 text-slate-400 hover:text-slate-200'
            }`}
          >
            Change Queue ({changeRequests.length})
          </button>
          <button
            onClick={() => setActiveTab('SANDBOX_BUILDER')}
            className={`px-3 py-1.5 rounded text-xs font-mono transition cursor-pointer ${
              activeTab === 'SANDBOX_BUILDER'
                ? 'bg-cyan-600 text-white font-bold'
                : 'bg-slate-900 text-slate-400 hover:text-slate-200'
            }`}
          >
            + New Sandbox Change Proposal
          </button>
        </div>
      </div>

      {activeTab === 'ACTIVE_REQUESTS' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Left: Change Requests List */}
          <div className="lg:col-span-5 bg-[#0e1422] rounded-md border border-slate-800 p-3 space-y-2">
            <h3 className="font-mono text-xs font-bold text-slate-400 uppercase tracking-wider px-1">
              Active Digital Twin Change Proposals
            </h3>

            <div className="space-y-2 max-h-[520px] overflow-y-auto pr-1">
              {changeRequests.map((cr) => {
                const isSelected = cr.request_id === selectedCrId;
                return (
                  <div
                    key={cr.request_id}
                    onClick={() => setSelectedCrId(cr.request_id)}
                    className={`p-3 rounded-md border text-xs font-mono transition cursor-pointer ${
                      isSelected
                        ? 'bg-slate-800/90 border-cyan-500 shadow-md'
                        : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-bold text-white">{cr.request_id}</span>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        cr.execution_status === 'COMMITTED'
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                          : 'bg-amber-950 text-amber-400 border border-amber-800'
                      }`}>
                        {cr.execution_status}
                      </span>
                    </div>

                    <div className="text-slate-300 font-sans text-xs mb-1.5 font-medium">
                      {cr.reason}
                    </div>

                    <div className="flex items-center justify-between text-[10px] text-slate-400 border-t border-slate-800 pt-1.5">
                      <span>Level: {cr.automation_level.replace('LEVEL_', 'L')}</span>
                      <span className="text-emerald-400">Risk: {cr.risk_score}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right: Change Request Safety Inspection & Execution Console */}
          {selectedCr && (
            <div className="lg:col-span-7 bg-[#0e1422] rounded-md border border-slate-800 p-4 font-mono space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <div>
                  <span className="text-[10px] uppercase text-cyan-400 font-bold">Change Validation Pipeline</span>
                  <h3 className="text-sm font-bold text-white">{selectedCr.request_id} ({selectedCr.change_type})</h3>
                </div>
                <span className="text-xs px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
                  PASSED TWIN VALIDATION
                </span>
              </div>

              {/* 5-Step Safety Checklist */}
              <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-2 text-xs">
                <div className="flex items-center gap-2 text-emerald-400">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>1. Physical & Spectrum Feasibility: VALIDATED</span>
                </div>
                <div className="flex items-center gap-2 text-emerald-400">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>2. Optical QoT Simulation: MARGIN {selectedCr.qot_impact_db} dB (ACCEPTABLE)</span>
                </div>
                <div className="flex items-center gap-2 text-emerald-400">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>3. Blast Radius Assessment: ZERO CUSTOMER SERVICES IMPACTED</span>
                </div>
                <div className="flex items-center gap-2 text-emerald-400">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>4. Rollback Snapshot Generated: {selectedCr.rollback_snapshot_id}</span>
                </div>
              </div>

              {/* Before vs Proposed State Diff */}
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="bg-slate-900/60 p-2.5 rounded border border-slate-800 space-y-1">
                  <span className="text-[10px] text-slate-500 uppercase font-bold">Before (Live State)</span>
                  <p className="text-slate-300 font-sans text-xs">{selectedCr.before_state_summary}</p>
                </div>
                <div className="bg-slate-900/60 p-2.5 rounded border border-cyan-900/50 space-y-1">
                  <span className="text-[10px] text-cyan-400 uppercase font-bold">Proposed (Twin State)</span>
                  <p className="text-slate-200 font-sans text-xs">{selectedCr.proposed_state_summary}</p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="border-t border-slate-800 pt-3 flex items-center justify-between">
                <div className="text-[11px] text-slate-400">
                  Operator: <strong>{selectedCr.operator}</strong>
                </div>

                <div className="flex items-center gap-2">
                  {selectedCr.approval_status === 'PENDING_APPROVAL' && (
                    <button
                      onClick={() => onApproveChange(selectedCr.request_id)}
                      className="flex items-center gap-1 bg-blue-600 hover:bg-blue-500 text-white px-3 py-1.5 rounded text-xs font-bold cursor-pointer transition"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>Approve Request</span>
                    </button>
                  )}

                  {selectedCr.execution_status !== 'COMMITTED' ? (
                    <button
                      onClick={() => onExecuteChange(selectedCr.request_id)}
                      className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-1.5 rounded text-xs font-bold cursor-pointer transition shadow"
                    >
                      <Play className="w-3.5 h-3.5" />
                      <span>Commit to Production ROADMs</span>
                    </button>
                  ) : (
                    <span className="text-emerald-400 text-xs font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>COMMITTED & VERIFIED</span>
                    </span>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      ) : (
        /* Sandbox Change Builder */
        <div className="bg-[#0e1422] rounded-md border border-slate-800 p-6 font-mono text-xs max-w-2xl mx-auto space-y-4">
          <h3 className="text-sm font-bold text-white uppercase border-b border-slate-800 pb-2">
            Build Digital Twin Change Proposal
          </h3>

          <div className="space-y-1">
            <label className="text-slate-400">Target Node / Object:</label>
            <input
              type="text"
              value={targetObject}
              onChange={(e) => setTargetObject(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white"
            />
          </div>

          <div className="space-y-1">
            <label className="text-slate-400">Change Action:</label>
            <select
              value={changeType}
              onChange={(e) => setChangeType(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white"
            >
              <option value="PROVISION_WAVELENGTH">PROVISION NEW WAVELENGTH (800G)</option>
              <option value="PROTECTION_SWITCH">PROTECTION SWITCH (1+1 PATH)</option>
              <option value="EDFA_PUMP_TUNING">OPTIMIZE EDFA BOOSTER PUMP</option>
              <option value="DECOMMISSION_WAVELENGTH">DECOMMISSION IDLE CHANNEL</option>
            </select>
          </div>

          <div className="space-y-1">
            <label className="text-slate-400">Automation Policy Level:</label>
            <select
              value={autoLevel}
              onChange={(e) => setAutoLevel(e.target.value as AutomationLevel)}
              className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white"
            >
              <option value="LEVEL_3_PREPARED_GATED">Level 3: Prepared Plan, Multi-Party Gate</option>
              <option value="LEVEL_4_HUMAN_APPROVAL">Level 4: Automated Twin Validation + Human Approval</option>
              <option value="LEVEL_5_AUTONOMOUS">Level 5: Full Autonomous Self-Healing</option>
            </select>
          </div>

          <div className="space-y-1">
            <label className="text-slate-400">Engineering Justification:</label>
            <textarea
              rows={3}
              value={justification}
              onChange={(e) => setJustification(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white font-sans text-xs"
            />
          </div>

          <button
            onClick={handleProposeChange}
            className="w-full bg-cyan-600 hover:bg-cyan-500 text-white font-bold p-2.5 rounded text-xs transition cursor-pointer shadow"
          >
            Submit for Digital Twin Physics & SLA Verification
          </button>
        </div>
      )}
    </div>
  );
};
