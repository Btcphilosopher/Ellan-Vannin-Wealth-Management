import React, { useState } from 'react';
import { Incident, Alarm, ServiceCircuit, FibreCable, WorkOrder } from '../types/optical';
import { OpticalPathEngine, PathCandidate } from '../engine/pathEngine';
import { 
  AlertOctagon, AlertTriangle, CheckCircle2, RefreshCw, 
  ArrowRight, ShieldAlert, Cpu, Wrench, Clock, Activity, Zap
} from 'lucide-react';

interface NocIncidentCenterProps {
  incidents: Incident[];
  alarms: Alarm[];
  services: ServiceCircuit[];
  cables: FibreCable[];
  workOrders: WorkOrder[];
  onRestoreCable: (cableId: string) => void;
  onDispatchWorkOrder: (order: WorkOrder) => void;
}

export const NocIncidentCenter: React.FC<NocIncidentCenterProps> = ({
  incidents,
  alarms,
  services,
  cables,
  workOrders,
  onRestoreCable,
  onDispatchWorkOrder
}) => {
  const [selectedIncidentId, setSelectedIncidentId] = useState<string>(incidents[0]?.incident_id || '');
  const [restoringIncident, setRestoringIncident] = useState<boolean>(false);
  const [restorationSuccess, setRestorationSuccess] = useState<boolean>(false);

  const activeIncident = incidents.find(i => i.incident_id === selectedIncidentId) || incidents[0];
  const affectedCable = cables.find(c => c.object_id === activeIncident?.root_cause_object_id);
  const correlatedAlarms = alarms.filter(a => activeIncident?.correlated_alarm_ids.includes(a.alarm_id));
  const impactedServices = services.filter(s => activeIncident?.affected_service_ids.includes(s.service_id));

  const handleExecuteRestoration = () => {
    if (!affectedCable) return;
    setRestoringIncident(true);
    setTimeout(() => {
      onRestoreCable(affectedCable.object_id);
      setRestoringIncident(false);
      setRestorationSuccess(true);
    }, 1200);
  };

  return (
    <div className="p-4 space-y-4 max-w-7xl mx-auto font-sans">
      {/* Top Banner */}
      <div className="bg-[#0e1422] p-4 rounded-md border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded bg-red-950 border border-red-700/60 text-red-400">
            <AlertOctagon className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold font-mono text-white">NOC Incident Triage & Automated Root-Cause Engine</h2>
            <div className="text-xs font-mono text-slate-400">
              Active Root-Cause Incidents: <span className="text-red-400 font-bold">{incidents.filter(i => i.status !== 'RESOLVED').length}</span> • Raw Alarms Correlated: <span className="text-cyan-400 font-bold">{alarms.length}</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono">
          <span className="px-2.5 py-1 rounded bg-slate-900 text-slate-300 border border-slate-700">
            AI Correlation Engine: <strong className="text-emerald-400">ONLINE (Level 4 Auto)</strong>
          </span>
        </div>
      </div>

      {/* Main Grid: Incident List vs Incident Details / Automated Restoration */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left: Incident Roster */}
        <div className="lg:col-span-5 bg-[#0e1422] rounded-md border border-slate-800 p-3 space-y-2">
          <h3 className="font-mono text-xs font-bold text-slate-400 uppercase tracking-wider px-1">
            Active & Resolved Incidents
          </h3>

          <div className="space-y-2 max-h-[520px] overflow-y-auto pr-1">
            {incidents.map((inc) => {
              const isSelected = inc.incident_id === selectedIncidentId;
              const isCritical = inc.severity === 'CRITICAL';

              return (
                <div
                  key={inc.incident_id}
                  onClick={() => {
                    setSelectedIncidentId(inc.incident_id);
                    setRestorationSuccess(false);
                  }}
                  className={`p-3 rounded-md border text-xs font-mono transition cursor-pointer ${
                    isSelected
                      ? 'bg-slate-800/90 border-cyan-500 shadow-md'
                      : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-white">{inc.incident_id}</span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      inc.status === 'RESOLVED'
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                        : isCritical
                          ? 'bg-red-950 text-red-400 border border-red-800 animate-pulse'
                          : 'bg-amber-950 text-amber-400 border border-amber-800'
                    }`}>
                      {inc.status}
                    </span>
                  </div>

                  <div className="text-slate-300 font-sans text-xs mb-2 font-medium">
                    {inc.title}
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-400 border-t border-slate-800 pt-1.5">
                    <span>Root Cause: {inc.root_cause_object_id}</span>
                    <span className="text-red-400">{inc.affected_service_ids.length} Services Affected</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Detailed Blast Radius & Automated Restoration Console */}
        {activeIncident && (
          <div className="lg:col-span-7 bg-[#0e1422] rounded-md border border-slate-800 p-4 font-mono space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <span className="text-[10px] uppercase text-red-400 font-bold">Correlated Optical Outage</span>
                <h3 className="text-sm font-bold text-white">{activeIncident.title}</h3>
              </div>
              <div className="text-right text-xs">
                <span className="text-slate-500">Blast Radius:</span>
                <div className="text-red-400 font-bold">{activeIncident.affected_service_ids.length} Critical Circuits</div>
              </div>
            </div>

            {/* Root Cause Summary Card */}
            <div className="bg-red-950/20 border border-red-900/60 rounded p-3 text-xs space-y-1.5">
              <div className="flex items-center gap-2 text-red-300 font-bold">
                <AlertTriangle className="w-4 h-4" />
                <span>ROOT CAUSE IDENTIFIED: {activeIncident.root_cause_object_id}</span>
              </div>
              <p className="text-slate-300 font-sans">
                {activeIncident.description}
              </p>
              <div className="text-[11px] text-slate-400">
                OTDR Detected Fault: <strong>km 48.2</strong> from London Core Node. Reflection loss: <strong>&gt; 45 dB (Clean Cut)</strong>.
              </div>
            </div>

            {/* Impacted Services List */}
            <div className="space-y-1.5">
              <h4 className="text-xs uppercase font-bold text-slate-400">Impacted High-Value Services</h4>
              <div className="space-y-1 max-h-36 overflow-y-auto">
                {impactedServices.map(svc => (
                  <div key={svc.service_id} className="bg-slate-900 p-2 rounded border border-slate-800 flex items-center justify-between text-xs">
                    <div>
                      <span className="font-bold text-cyan-300">{svc.service_name}</span>
                      <span className="text-slate-400 text-[10px] ml-2">({svc.customer_name})</span>
                    </div>
                    <span className="px-1.5 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800 text-[10px]">
                      {svc.sla_tier} (Max Latency {svc.max_latency_ms}ms)
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Correlated Raw Alarms */}
            <div className="space-y-1.5">
              <h4 className="text-xs uppercase font-bold text-slate-400">Correlated Hardware Alarms ({correlatedAlarms.length})</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-1.5">
                {correlatedAlarms.map(al => (
                  <div key={al.alarm_id} className="bg-slate-900/80 p-2 rounded border border-slate-800 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-red-400">{al.alarm_type}</span>
                      <span className="text-[10px] text-slate-500">{new Date(al.timestamp).toLocaleTimeString()}</span>
                    </div>
                    <div className="text-[10px] text-slate-400 truncate">{al.object_id}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Automated Restoration & Reroute Control */}
            <div className="border-t border-slate-800 pt-3 flex flex-wrap items-center justify-between gap-3">
              <div>
                <div className="text-xs text-slate-300 font-bold">Autonomous Reroute & Line Restoration</div>
                <div className="text-[11px] text-slate-500">Calculates alternative lambda paths with QoT margin &gt; 2.5 dB</div>
              </div>

              {activeIncident.status !== 'RESOLVED' && !restorationSuccess ? (
                <button
                  onClick={handleExecuteRestoration}
                  disabled={restoringIncident}
                  className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white px-4 py-2 rounded text-xs font-bold font-mono transition cursor-pointer shadow-lg"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${restoringIncident ? 'animate-spin' : ''}`} />
                  <span>{restoringIncident ? 'Executing Dynamic Optical Reroute...' : 'Trigger Automated Optical Restoration'}</span>
                </button>
              ) : (
                <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>RESTORED & VERIFIED VIA ALTERNATIVE DIVERSE ROUTE</span>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
