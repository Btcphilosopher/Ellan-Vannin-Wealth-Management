import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OpticalNode, RackDetails, ShelfDetails, CardDetails } from '../types/optical';
import { 
  Box, Server, Zap, Radio, CheckCircle, AlertTriangle, 
  Layers, HardDrive, Cpu, Power, RefreshCw
} from 'lucide-react';

interface Rack3DViewProps {
  nodes: OpticalNode[];
  selectedNodeId: string;
  onSelectNode: (nodeId: string) => void;
  onDrilldownToLab: (card: CardDetails) => void;
}

export const Rack3DView: React.FC<Rack3DViewProps> = ({
  nodes,
  selectedNodeId,
  onSelectNode,
  onDrilldownToLab
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [selectedRackIndex, setSelectedRackIndex] = useState<number>(0);
  const [selectedShelfId, setSelectedShelfId] = useState<string | null>(null);
  const [selectedCardId, setSelectedCardId] = useState<string | null>(null);

  const activeNode = nodes.find(n => n.object_id === selectedNodeId) || nodes[0];
  const activeRack = activeNode.racks[selectedRackIndex] || activeNode.racks[0];

  useEffect(() => {
    if (!canvasRef.current) return;

    const width = canvasRef.current.clientWidth;
    const height = canvasRef.current.clientHeight;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0a0f18);

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.set(0, 3, 9);
    camera.lookAt(0, 0.5, 0);

    const renderer = new THREE.WebGLRenderer({
      canvas: canvasRef.current,
      antialias: true
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.8);
    scene.add(ambientLight);

    const directionalLight1 = new THREE.DirectionalLight(0x38bdf8, 1.5);
    directionalLight1.position.set(5, 10, 7);
    scene.add(directionalLight1);

    const directionalLight2 = new THREE.DirectionalLight(0x10b981, 0.6);
    directionalLight2.position.set(-5, -2, -5);
    scene.add(directionalLight2);

    // Build 3D Server Racks in Row
    const rackGroup = new THREE.Group();
    const totalRacks = Math.min(6, activeNode.total_racks || 4);

    for (let i = 0; i < totalRacks; i++) {
      const rackX = (i - (totalRacks - 1) / 2) * 1.6;
      const isCurrent = i === selectedRackIndex;

      // Outer Rack Frame (42U Server Rack)
      const frameGeometry = new THREE.BoxGeometry(1.2, 3.8, 1.4);
      const frameMaterial = new THREE.MeshStandardMaterial({
        color: isCurrent ? 0x1e293b : 0x0f172a,
        metalness: 0.8,
        roughness: 0.3,
        wireframe: false
      });
      const frame = new THREE.Mesh(frameGeometry, frameMaterial);
      frame.position.set(rackX, 0, 0);

      // Add Glass / Mesh Front Door with border
      const doorGeo = new THREE.PlaneGeometry(1.1, 3.7);
      const doorMat = new THREE.MeshStandardMaterial({
        color: isCurrent ? 0x06b6d4 : 0x334155,
        transparent: true,
        opacity: isCurrent ? 0.25 : 0.1,
        metalness: 0.9,
        roughness: 0.1
      });
      const door = new THREE.Mesh(doorGeo, doorMat);
      door.position.set(rackX, 0, 0.71);
      rackGroup.add(door);

      // Add Shelf units inside
      for (let s = 0; s < 4; s++) {
        const shelfGeo = new THREE.BoxGeometry(1.05, 0.6, 1.1);
        const shelfMat = new THREE.MeshStandardMaterial({
          color: 0x334155,
          metalness: 0.7,
          roughness: 0.4
        });
        const shelfMesh = new THREE.Mesh(shelfGeo, shelfMat);
        shelfMesh.position.set(rackX, 1.2 - s * 0.8, 0);
        rackGroup.add(shelfMesh);

        // Blinking LED Status Light
        const ledGeo = new THREE.SphereGeometry(0.04, 8, 8);
        const ledMat = new THREE.MeshBasicMaterial({
          color: isCurrent && s === 1 ? 0x06b6d4 : 0x10b981
        });
        const ledMesh = new THREE.Mesh(ledGeo, ledMat);
        ledMesh.position.set(rackX + 0.45, 1.2 - s * 0.8, 0.58);
        rackGroup.add(ledMesh);
      }

      rackGroup.add(frame);
    }

    scene.add(rackGroup);

    // Floor Grid
    const gridHelper = new THREE.GridHelper(16, 16, 0x06b6d4, 0x1e293b);
    gridHelper.position.y = -1.9;
    scene.add(gridHelper);

    let animationFrameId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      const elapsedTime = clock.getElapsedTime();

      // Subtle slow oscillating orbit
      camera.position.x = Math.sin(elapsedTime * 0.15) * 1.5;
      camera.lookAt(0, 0, 0);

      renderer.render(scene, camera);
    };

    animate();

    const handleResize = () => {
      if (!canvasRef.current) return;
      const w = canvasRef.current.clientWidth;
      const h = canvasRef.current.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
    };
  }, [activeNode, selectedRackIndex]);

  return (
    <div className="p-4 space-y-4 max-w-7xl mx-auto font-sans">
      {/* Node Selector & POP Header */}
      <div className="bg-[#0e1422] p-4 rounded-md border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded bg-cyan-950 border border-cyan-700/60 text-cyan-400">
            <Server className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold font-mono text-white">{activeNode.name}</h2>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800">
                {activeNode.role}
              </span>
            </div>
            <div className="text-xs font-mono text-slate-400">
              {activeNode.location.city}, {activeNode.location.region} • ROADM Degrees: {activeNode.roadm_degrees} • Total Switching: {activeNode.total_switching_capacity_tbps} Tb/s
            </div>
          </div>
        </div>

        {/* Node Switcher Dropdown */}
        <div className="flex items-center gap-2">
          <span className="text-xs font-mono text-slate-400">SELECT POP:</span>
          <select
            value={selectedNodeId}
            onChange={(e) => onSelectNode(e.target.value)}
            className="bg-slate-900 text-cyan-300 font-mono text-xs px-3 py-1.5 rounded border border-slate-700 focus:outline-none cursor-pointer"
          >
            {nodes.map(n => (
              <option key={n.object_id} value={n.object_id}>
                {n.location.city} ({n.object_id})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* 3D WebGL Canvas + Rack Bay Selector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left: 3D Interactive Room Preview */}
        <div className="lg:col-span-7 bg-[#0a0f18] rounded-md border border-slate-800 overflow-hidden relative h-[380px]">
          <div className="absolute top-3 left-3 z-10 bg-slate-900/80 backdrop-blur px-2.5 py-1 rounded border border-slate-700 text-xs font-mono text-slate-300">
            3D DIGITAL TWIN • SERVER ROW VIEW
          </div>

          <canvas ref={canvasRef} className="w-full h-full block" />

          {/* Bottom Rack Bay Switcher Pills */}
          <div className="absolute bottom-3 left-3 right-3 z-10 flex items-center justify-center gap-2 overflow-x-auto">
            {activeNode.racks.map((rack, idx) => (
              <button
                key={rack.rack_id}
                onClick={() => setSelectedRackIndex(idx)}
                className={`px-3 py-1 rounded font-mono text-xs transition cursor-pointer border ${
                  idx === selectedRackIndex
                    ? 'bg-cyan-600 text-white border-cyan-400 font-bold shadow-md'
                    : 'bg-slate-900/80 text-slate-300 border-slate-700 hover:bg-slate-800'
                }`}
              >
                Bay 0{idx + 1}
              </button>
            ))}
          </div>
        </div>

        {/* Right: 2D Chassis & Line Card Inspector */}
        <div className="lg:col-span-5 bg-[#0e1422] rounded-md border border-slate-800 p-4 font-mono space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div>
              <span className="text-[10px] text-slate-500 uppercase">Selected Equipment Rack</span>
              <h3 className="text-sm font-bold text-white">{activeRack?.rack_name || 'Optical Line Bay'}</h3>
            </div>
            <span className="text-xs px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800/60">
              42U ONLINE
            </span>
          </div>

          {/* Shelves & Cards List */}
          <div className="space-y-3 max-h-[280px] overflow-y-auto pr-1">
            {activeRack?.shelves.map((shelf) => (
              <div
                key={shelf.shelf_id}
                className="bg-slate-900/80 rounded border border-slate-800 p-2.5 space-y-2"
              >
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5">
                    <Layers className="w-3.5 h-3.5 text-cyan-400" />
                    <span className="font-bold text-slate-200">{shelf.shelf_name}</span>
                  </div>
                  <span className="text-[10px] text-slate-500">{shelf.shelf_type}</span>
                </div>

                {/* Cards in Shelf */}
                <div className="grid grid-cols-1 gap-1.5">
                  {shelf.cards.map((card) => (
                    <div
                      key={card.card_id}
                      onClick={() => setSelectedCardId(card.card_id)}
                      className={`p-2 rounded border text-xs transition cursor-pointer flex items-center justify-between ${
                        selectedCardId === card.card_id
                          ? 'bg-cyan-950/60 border-cyan-500 text-cyan-200'
                          : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <div>
                        <div className="font-bold text-[11px] text-white">{card.card_name}</div>
                        <div className="text-[10px] text-slate-400">
                          {card.vendor} • {card.power_w}W • {card.temperature}°C
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onDrilldownToLab(card);
                          }}
                          className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-cyan-300 text-[10px] border border-slate-700 cursor-pointer"
                        >
                          DSP Lab
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
