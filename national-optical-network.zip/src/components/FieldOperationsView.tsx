import React, { useState } from 'react';
import { WorkOrder, FibreCable } from '../types/optical';
import { 
  Wrench, Truck, MapPin, CheckCircle2, AlertTriangle, 
  Activity, ArrowRight, ShieldCheck, CheckSquare, Clock
} from 'lucide-react';

interface FieldOperationsViewProps {
  workOrders: WorkOrder[];
  cables: FibreCable[];
  onCompleteWorkOrder: (orderId: string) => void;
}

export const FieldOperationsView: React.FC<FieldOperationsViewProps> = ({
  workOrders,
  cables,
  onCompleteWorkOrder
}) => {
  const [selectedOrderId, setSelectedOrderId] = useState<string>(workOrders[0]?.order_id || '');
  const activeOrder = workOrders.find(w => w.order_id === selectedOrderId) || workOrders[0];
  const targetCable = cables.find(c => c.object_id === activeOrder?.target_object_id);

  const [completedSteps, setCompletedSteps] = useState<number[]>([1, 2]);

  const toggleStep = (stepNum: number) => {
    if (completedSteps.includes(stepNum)) {
      setCompletedSteps(completedSteps.filter(s => s !== stepNum));
    } else {
      setCompletedSteps([...completedSteps, stepNum]);
    }
  };

  return (
    <div className="p-4 space-y-4 max-w-7xl mx-auto font-sans">
      {/* Top Banner */}
      <div className="bg-[#0e1422] p-4 rounded-md border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded bg-emerald-950 border border-emerald-700/60 text-emerald-400">
            <Wrench className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold font-mono text-white">Field Operations & OTDR Optical Trace Analyzer</h2>
            <div className="text-xs font-mono text-slate-400">
              Dispatched Splice Crews • Rayleigh Backscatter & Fresnel Break Localization
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="px-2.5 py-1 rounded bg-slate-900 text-slate-300 border border-slate-700">
            Field Teams Active: <strong className="text-emerald-400">3 Crews Dispatched</strong>
          </span>
        </div>
      </div>

      {/* Main Grid: Work Orders List vs OTDR Trace & Repair Checklist */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left: Work Orders */}
        <div className="lg:col-span-5 bg-[#0e1422] rounded-md border border-slate-800 p-3 space-y-2">
          <h3 className="font-mono text-xs font-bold text-slate-400 uppercase tracking-wider px-1">
            Emergency & Scheduled Work Orders
          </h3>

          <div className="space-y-2 max-h-[520px] overflow-y-auto pr-1">
            {workOrders.map((wo) => {
              const isSelected = wo.order_id === selectedOrderId;
              return (
                <div
                  key={wo.order_id}
                  onClick={() => setSelectedOrderId(wo.order_id)}
                  className={`p-3 rounded-md border text-xs font-mono transition cursor-pointer ${
                    isSelected
                      ? 'bg-slate-800/90 border-cyan-500 shadow-md'
                      : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-white">{wo.order_id}</span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      wo.status === 'COMPLETED'
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                        : 'bg-amber-950 text-amber-400 border border-amber-800 animate-pulse'
                    }`}>
                      {wo.status}
                    </span>
                  </div>

                  <div className="text-slate-300 font-sans text-xs mb-1.5 font-medium">
                    {wo.title}
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-400 border-t border-slate-800 pt-1.5">
                    <span>Crew: {wo.assigned_technician}</span>
                    <span className="text-cyan-400">ETA: {wo.eta_hours}h</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: OTDR Trace Visualizer & Splice Checklist */}
        {activeOrder && (
          <div className="lg:col-span-7 bg-[#0e1422] rounded-md border border-slate-800 p-4 font-mono space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div>
                <span className="text-[10px] uppercase text-cyan-400 font-bold">Field Intervention Order</span>
                <h3 className="text-sm font-bold text-white">{activeOrder.title}</h3>
              </div>
              <div className="text-right text-xs">
                <span className="text-slate-500">Location:</span>
                <div className="text-slate-200">{activeOrder.gps_coordinates.join(', ')}</div>
              </div>
            </div>

            {/* Interactive OTDR Graph */}
            <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-300 font-bold flex items-center gap-1.5">
                  <Activity className="w-3.5 h-3.5 text-cyan-400" />
                  <span>OTDR Rayleigh Backscatter Trace (1550 nm / 20ns Pulse)</span>
                </span>
                <span className="text-red-400 font-bold">Fiber Break Detected @ km 48.24</span>
              </div>

              {/* OTDR SVG Curve */}
              <div className="w-full h-44 bg-[#070b12] rounded border border-slate-900 p-2">
                <svg className="w-full h-full" viewBox="0 0 500 140">
                  {/* Grid */}
                  <line x1="40" y1="20" x2="480" y2="20" stroke="#1e293b" strokeDasharray="3,3" />
                  <line x1="40" y1="60" x2="480" y2="60" stroke="#1e293b" strokeDasharray="3,3" />
                  <line x1="40" y1="100" x2="480" y2="100" stroke="#1e293b" strokeDasharray="3,3" />

                  {/* Y Axis DB Labels */}
                  <text x="5" y="24" fill="#64748b" fontSize="9" fontFamily="monospace">0 dB</text>
                  <text x="5" y="64" fill="#64748b" fontSize="9" fontFamily="monospace">-15 dB</text>
                  <text x="5" y="104" fill="#64748b" fontSize="9" fontFamily="monospace">-30 dB</text>

                  {/* Rayleigh Slope with Fresnel Reflection Spike & Cut Drop */}
                  <path
                    d="M 40 25 L 140 45 L 142 30 L 144 46 L 260 70 L 262 55 L 264 71 L 340 85 L 342 15 L 345 130 L 480 130"
                    fill="none"
                    stroke="#06b6d4"
                    strokeWidth="2"
                  />

                  {/* Event Markers */}
                  <text x="130" y="25" fill="#38bdf8" fontSize="8">Splice #1 (km 14.2)</text>
                  <text x="250" y="50" fill="#38bdf8" fontSize="8">Splice #2 (km 28.0)</text>
                  <circle cx="342" cy="15" r="4" fill="#ef4444" className="animate-ping" />
                  <text x="350" y="25" fill="#ef4444" fontSize="9" fontWeight="bold">FIBER CUT (km 48.2)</text>
                </svg>
              </div>
            </div>

            {/* Field Technician Splice Procedure Checklist */}
            <div className="space-y-2">
              <h4 className="text-xs uppercase font-bold text-slate-400">Standard Fusion Splice Restoration Protocol</h4>
              <div className="space-y-1.5 text-xs">
                {[
                  { id: 1, label: 'Safety barrier deployed & traffic management established on site' },
                  { id: 2, label: 'Fibre enclosure unsealed, loose tubes identified & cleaned with IPA' },
                  { id: 3, label: 'Precision cleaving executed (cleave angle < 0.5° on all 96 cores)' },
                  { id: 4, label: 'Core-alignment fusion splice executed (splice loss < 0.02 dB)' },
                  { id: 5, label: 'OTDR bi-directional verification test passed from Node A and Node B' }
                ].map(step => (
                  <label
                    key={step.id}
                    onClick={() => toggleStep(step.id)}
                    className={`flex items-center gap-2.5 p-2 rounded border cursor-pointer transition ${
                      completedSteps.includes(step.id)
                        ? 'bg-emerald-950/40 border-emerald-800/80 text-emerald-300'
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={completedSteps.includes(step.id)}
                      readOnly
                      className="accent-emerald-500"
                    />
                    <span>Step {step.id}: {step.label}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Complete Work Order */}
            <div className="border-t border-slate-800 pt-3 flex items-center justify-between">
              <div className="text-[11px] text-slate-400">
                Assigned Van: <strong>{activeOrder.assigned_technician}</strong>
              </div>

              {activeOrder.status !== 'COMPLETED' ? (
                <button
                  onClick={() => onCompleteWorkOrder(activeOrder.order_id)}
                  className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-1.5 rounded text-xs font-bold cursor-pointer transition shadow"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Verify OTDR & Sign-Off Work Order</span>
                </button>
              ) : (
                <span className="text-emerald-400 text-xs font-bold flex items-center gap-1">
                  <ShieldCheck className="w-4 h-4" />
                  <span>WORK ORDER VERIFIED & CLOSED</span>
                </span>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
