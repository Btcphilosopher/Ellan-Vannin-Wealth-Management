import React, { useState, useEffect } from 'react';
import { ModulationFormat } from '../types/optical';
import { SSFMEngine, SSFMResult } from '../engine/ssfmLab';
import { 
  Waves, Sliders, Play, RefreshCw, Cpu, Activity, 
  BarChart2, Zap, ArrowRight, Layers
} from 'lucide-react';

interface HighFidelityLabProps {
  initialDistanceKm?: number;
  initialLaunchPowerDbm?: number;
  initialBaudRateGbaud?: number;
  initialModulation?: ModulationFormat;
}

export const HighFidelityLab: React.FC<HighFidelityLabProps> = ({
  initialDistanceKm = 480,
  initialLaunchPowerDbm = 1.5,
  initialBaudRateGbaud = 64,
  initialModulation = 'DP-16QAM' as ModulationFormat
}) => {
  const [distanceKm, setDistanceKm] = useState<number>(initialDistanceKm);
  const [launchPowerDbm, setLaunchPowerDbm] = useState<number>(initialLaunchPowerDbm);
  const [baudRateGbaud, setBaudRateGbaud] = useState<number>(initialBaudRateGbaud);
  const [modulation, setModulation] = useState<ModulationFormat>(initialModulation as ModulationFormat);
  const [activeTab, setActiveTab] = useState<'CONSTELLATION' | 'EYE_DIAGRAM' | 'EQUALIZER_TAPS' | 'NONLINEAR_SWEEP'>('CONSTELLATION');

  const [simResult, setSimResult] = useState<SSFMResult>(() => {
    return SSFMEngine.runSimulation({
      distanceKm: initialDistanceKm,
      launchPowerDbm: initialLaunchPowerDbm,
      baudRateGbaud: initialBaudRateGbaud,
      modulation: initialModulation as ModulationFormat
    });
  });

  const [isSimulating, setIsSimulating] = useState(false);

  const handleRunSimulation = () => {
    setIsSimulating(true);
    setTimeout(() => {
      const res = SSFMEngine.runSimulation({
        distanceKm,
        launchPowerDbm,
        baudRateGbaud,
        modulation
      });
      setSimResult(res);
      setIsSimulating(false);
    }, 300);
  };

  useEffect(() => {
    handleRunSimulation();
  }, [distanceKm, launchPowerDbm, baudRateGbaud, modulation]);

  return (
    <div className="p-4 space-y-4 max-w-7xl mx-auto font-sans">
      {/* Top Banner */}
      <div className="bg-[#0e1422] p-4 rounded-md border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded bg-cyan-950 border border-cyan-700/60 text-cyan-400">
            <Waves className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold font-mono text-white">High-Fidelity Waveform & DSP Laboratory</h2>
            <div className="text-xs font-mono text-slate-400">
              Split-Step Fourier Method (SSFM) • Non-Linear Schrödinger Equation • Coherent Receiver DSP
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleRunSimulation}
            disabled={isSimulating}
            className="flex items-center gap-1.5 bg-cyan-600 hover:bg-cyan-500 text-white px-3 py-1.5 rounded text-xs font-mono font-bold cursor-pointer transition shadow"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSimulating ? 'animate-spin' : ''}`} />
            <span>Recalculate DSP</span>
          </button>
        </div>
      </div>

      {/* Physics Controls & Simulation Results Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left: Interactive Physics Controls */}
        <div className="lg:col-span-4 bg-[#0e1422] rounded-md border border-slate-800 p-4 font-mono text-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="font-bold text-slate-300 uppercase">Optical Channel Parameters</span>
            <Sliders className="w-4 h-4 text-cyan-400" />
          </div>

          {/* Distance Slider */}
          <div className="space-y-1">
            <div className="flex justify-between text-slate-300">
              <span>Fiber Span Distance:</span>
              <span className="text-cyan-400 font-bold">{distanceKm} km</span>
            </div>
            <input
              type="range"
              min="50"
              max="2400"
              step="50"
              value={distanceKm}
              onChange={(e) => setDistanceKm(Number(e.target.value))}
              className="w-full accent-cyan-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500">
              <span>50 km (Metro)</span>
              <span>1200 km (Regional)</span>
              <span>2400 km (Subsea)</span>
            </div>
          </div>

          {/* Launch Power */}
          <div className="space-y-1">
            <div className="flex justify-between text-slate-300">
              <span>Launch Power:</span>
              <span className="text-cyan-400 font-bold">{launchPowerDbm} dBm</span>
            </div>
            <input
              type="range"
              min="-4.0"
              max="6.0"
              step="0.5"
              value={launchPowerDbm}
              onChange={(e) => setLaunchPowerDbm(Number(e.target.value))}
              className="w-full accent-cyan-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500">
              <span>-4.0 dBm (ASE Limited)</span>
              <span>+1.5 dBm (Optimum)</span>
              <span>+6.0 dBm (Non-Linear)</span>
            </div>
          </div>

          {/* Baud Rate */}
          <div className="space-y-1">
            <div className="flex justify-between text-slate-300">
              <span>Symbol Rate:</span>
              <span className="text-cyan-400 font-bold">{baudRateGbaud} Gbaud</span>
            </div>
            <select
              value={baudRateGbaud}
              onChange={(e) => setBaudRateGbaud(Number(e.target.value))}
              className="w-full bg-slate-900 border border-slate-700 rounded p-1.5 text-slate-200 focus:outline-none cursor-pointer"
            >
              <option value="32">32 Gbaud (100G / 200G)</option>
              <option value="64">64 Gbaud (400G / 800G)</option>
              <option value="96">96 Gbaud (800G+ High-Rate)</option>
              <option value="128">128 Gbaud (1.2 Tbps Next-Gen)</option>
            </select>
          </div>

          {/* Modulation Format */}
          <div className="space-y-1">
            <div className="flex justify-between text-slate-300">
              <span>Modulation Format:</span>
              <span className="text-cyan-400 font-bold">{modulation}</span>
            </div>
            <div className="grid grid-cols-2 gap-1.5">
              {(['DP-QPSK', 'DP-16QAM', 'DP-64QAM', 'DP-256QAM'] as ModulationFormat[]).map(m => (
                <button
                  key={m}
                  onClick={() => setModulation(m)}
                  className={`p-1.5 rounded text-center transition cursor-pointer border ${
                    modulation === m
                      ? 'bg-cyan-900/60 border-cyan-400 text-cyan-200 font-bold'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  {m}
                </button>
              ))}
            </div>
          </div>

          {/* Real-Time Measured DSP Metrics */}
          <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-2">
            <div className="text-[10px] text-slate-400 uppercase font-bold">Measured Receiver Metrics</div>
            <div className="flex justify-between text-xs">
              <span className="text-slate-400">Error Vector Magnitude (EVM):</span>
              <span className="text-cyan-300 font-bold">{simResult.evmPercent.toFixed(2)} %</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-slate-400">Effective SNR:</span>
              <span className="text-emerald-400 font-bold">{simResult.snrDb.toFixed(2)} dB</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-slate-400">Estimated Pre-FEC BER:</span>
              <span className="text-slate-200 font-bold">{simResult.berPreFec.toExponential(2)}</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-slate-400">Eye Opening Penalty:</span>
              <span className="text-amber-400 font-bold">{simResult.eyeOpeningPenaltyDb.toFixed(2)} dB</span>
            </div>
          </div>
        </div>

        {/* Right: Interactive Waveform Visualizer */}
        <div className="lg:col-span-8 bg-[#0e1422] rounded-md border border-slate-800 p-4 flex flex-col space-y-3">
          {/* Visualizer Mode Switcher */}
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setActiveTab('CONSTELLATION')}
                className={`px-3 py-1 rounded text-xs font-mono transition cursor-pointer ${
                  activeTab === 'CONSTELLATION'
                    ? 'bg-cyan-600 text-white font-bold'
                    : 'bg-slate-900 text-slate-400 hover:text-slate-200'
                }`}
              >
                I/Q Constellation
              </button>
              <button
                onClick={() => setActiveTab('EYE_DIAGRAM')}
                className={`px-3 py-1 rounded text-xs font-mono transition cursor-pointer ${
                  activeTab === 'EYE_DIAGRAM'
                    ? 'bg-cyan-600 text-white font-bold'
                    : 'bg-slate-900 text-slate-400 hover:text-slate-200'
                }`}
              >
                Eye Diagram
              </button>
              <button
                onClick={() => setActiveTab('EQUALIZER_TAPS')}
                className={`px-3 py-1 rounded text-xs font-mono transition cursor-pointer ${
                  activeTab === 'EQUALIZER_TAPS'
                    ? 'bg-cyan-600 text-white font-bold'
                    : 'bg-slate-900 text-slate-400 hover:text-slate-200'
                }`}
              >
                DSP Adaptive Equalizer
              </button>
            </div>

            <span className="text-[11px] font-mono text-slate-500">
              512 SSFM Samples • 128 km Step
            </span>
          </div>

          {/* Visual Canvas Area */}
          <div className="flex-1 bg-slate-950 rounded border border-slate-800 p-4 min-h-[380px] flex items-center justify-center relative">
            {activeTab === 'CONSTELLATION' && (
              <div className="w-full max-w-[360px] aspect-square relative border border-slate-800 bg-[#070b12] rounded">
                {/* Axis Grid */}
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                  <div className="w-full h-[1px] bg-slate-800" />
                  <div className="h-full w-[1px] bg-slate-800 absolute" />
                  <div className="w-3/4 h-3/4 rounded-full border border-slate-900" />
                  <div className="w-1/2 h-1/2 rounded-full border border-slate-900" />
                </div>

                {/* Plot Recovered I/Q Constellation Symbols */}
                <svg className="w-full h-full" viewBox="-2 -2 4 4">
                  {simResult.constellationPoints.map((pt, i) => (
                    <circle
                      key={i}
                      cx={pt.i}
                      cy={pt.q}
                      r="0.04"
                      fill="#22d3ee"
                      opacity="0.8"
                    />
                  ))}
                </svg>

                <div className="absolute bottom-2 left-2 text-[10px] font-mono text-slate-500">In-Phase (I)</div>
                <div className="absolute top-2 left-2 text-[10px] font-mono text-slate-500">Quadrature (Q)</div>
              </div>
            )}

            {activeTab === 'EYE_DIAGRAM' && (
              <div className="w-full h-full flex flex-col items-center justify-center font-mono">
                <svg className="w-full h-64" viewBox="0 0 500 200">
                  {/* Eye Traces */}
                  <path
                    d="M 0 100 Q 125 10 250 100 T 500 100"
                    fill="none"
                    stroke="#06b6d4"
                    strokeWidth="2"
                    opacity="0.7"
                  />
                  <path
                    d="M 0 100 Q 125 190 250 100 T 500 100"
                    fill="none"
                    stroke="#06b6d4"
                    strokeWidth="2"
                    opacity="0.7"
                  />
                  <path
                    d="M 0 50 Q 125 150 250 50 T 500 50"
                    fill="none"
                    stroke="#3b82f6"
                    strokeWidth="1.5"
                    opacity="0.5"
                  />
                  <path
                    d="M 0 150 Q 125 50 250 150 T 500 150"
                    fill="none"
                    stroke="#3b82f6"
                    strokeWidth="1.5"
                    opacity="0.5"
                  />
                  {/* Threshold Lines */}
                  <line x1="0" y1="100" x2="500" y2="100" stroke="#334155" strokeDasharray="4,4" />
                </svg>
                <div className="text-xs text-slate-400 mt-2">
                  Eye Height: {(1 - simResult.eyeOpeningPenaltyDb / 10).toFixed(2)} • Timing Jitter: {(baudRateGbaud * 0.08).toFixed(1)} ps
                </div>
              </div>
            )}

            {activeTab === 'EQUALIZER_TAPS' && (
              <div className="w-full h-full p-4 flex flex-col justify-between font-mono">
                <div className="text-xs text-slate-400 mb-2">
                  21-Tap Finite Impulse Response (FIR) Adaptive MIMO Equalizer Weights
                </div>
                <div className="flex items-end justify-between h-48 gap-1 border-b border-slate-800 pb-2">
                  {simResult.dspEqualizerTaps.map((tap, idx) => {
                    const heightPercent = Math.min(100, Math.max(10, Math.abs(tap.weight) * 90));
                    return (
                      <div key={idx} className="flex-1 flex flex-col items-center gap-1">
                        <div
                          className="w-full bg-cyan-500 rounded-t transition-all"
                          style={{ height: `${heightPercent}%` }}
                        />
                        <span className="text-[9px] text-slate-500">{idx - 10}</span>
                      </div>
                    );
                  })}
                </div>
                <div className="text-[11px] text-slate-500 mt-2">
                  CMA/MMA Filter converged in 4,200 iterations • Residual PMD &lt; 0.4 ps
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
