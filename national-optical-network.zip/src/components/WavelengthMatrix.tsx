import React, { useState } from 'react';
import { WavelengthChannel, ModulationFormat, FecType } from '../types/optical';
import { QoTEngine } from '../engine/qotEngine';
import { 
  Activity, Zap, Sliders, Radio, Layers, Search, Filter, 
  CheckCircle2, AlertCircle, ArrowUpRight, Gauge
} from 'lucide-react';

interface WavelengthMatrixProps {
  wavelengths: WavelengthChannel[];
  onSelectWavelength: (channel: WavelengthChannel) => void;
  onLaunchLab: (params: any) => void;
}

export const WavelengthMatrix: React.FC<WavelengthMatrixProps> = ({
  wavelengths,
  onSelectWavelength,
  onLaunchLab
}) => {
  const [selectedChannelId, setSelectedChannelId] = useState<string>(wavelengths[0]?.channel_id || '');
  const [bandFilter, setBandFilter] = useState<'ALL' | 'C_BAND' | 'L_BAND'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  const spectrumSlots = QoTEngine.generateSpectrumGrid(191.30, 196.10, 50.0);

  const selectedChannel = wavelengths.find(w => w.channel_id === selectedChannelId) || wavelengths[0];

  const filteredChannels = wavelengths.filter(ch => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        ch.channel_id.toLowerCase().includes(q) ||
        ch.source_node_id.toLowerCase().includes(q) ||
        ch.target_node_id.toLowerCase().includes(q) ||
        ch.modulation.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="p-4 space-y-4 max-w-7xl mx-auto font-sans">
      {/* Top Banner & Summary KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3 font-mono text-xs">
        <div className="bg-[#0e1422] p-3 rounded-md border border-slate-800 flex items-center justify-between">
          <div>
            <div className="text-slate-500 uppercase text-[10px]">C-Band Grid Slots</div>
            <div className="text-lg font-bold text-slate-100">96 Channels</div>
            <div className="text-[10px] text-cyan-400">191.30 - 196.10 THz</div>
          </div>
          <Radio className="w-6 h-6 text-cyan-500" />
        </div>

        <div className="bg-[#0e1422] p-3 rounded-md border border-slate-800 flex items-center justify-between">
          <div>
            <div className="text-slate-500 uppercase text-[10px]">Active Line Rate Capacity</div>
            <div className="text-lg font-bold text-slate-100">2.4 Tbps (Active)</div>
            <div className="text-[10px] text-emerald-400">3x 800G / 400G Coherent</div>
          </div>
          <Zap className="w-6 h-6 text-emerald-500" />
        </div>

        <div className="bg-[#0e1422] p-3 rounded-md border border-slate-800 flex items-center justify-between">
          <div>
            <div className="text-slate-500 uppercase text-[10px]">Average Optical OSNR</div>
            <div className="text-lg font-bold text-slate-100">23.0 dB</div>
            <div className="text-[10px] text-cyan-400">+4.5 dB Margin above FEC</div>
          </div>
          <Gauge className="w-6 h-6 text-blue-500" />
        </div>

        <div className="bg-[#0e1422] p-3 rounded-md border border-slate-800 flex items-center justify-between">
          <div>
            <div className="text-slate-500 uppercase text-[10px]">Coherent DSP FEC Mode</div>
            <div className="text-lg font-bold text-slate-100">oFEC 27% OpenROADM</div>
            <div className="text-[10px] text-indigo-400">Pre-FEC BER &lt; 3.5e-2</div>
          </div>
          <Layers className="w-6 h-6 text-indigo-500" />
        </div>
      </div>

      {/* Spectrum Visualization Bar (ITU-T Grid) */}
      <div className="bg-[#0e1422] p-4 rounded-md border border-slate-800">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <Radio className="w-4 h-4 text-cyan-400" />
            <h3 className="font-mono text-sm font-bold text-slate-200">
              ITU-T G.694.1 C-Band Optical Spectrum (Flex-Grid / 50GHz)
            </h3>
          </div>
          <div className="flex items-center gap-2 text-xs font-mono">
            <span className="flex items-center gap-1 text-slate-400">
              <span className="w-2.5 h-2.5 bg-cyan-500 rounded-xs" /> 800G Coherent (DP-16QAM)
            </span>
            <span className="flex items-center gap-1 text-slate-400">
              <span className="w-2.5 h-2.5 bg-blue-500 rounded-xs" /> 400G Coherent (DP-QPSK)
            </span>
            <span className="flex items-center gap-1 text-slate-400">
              <span className="w-2.5 h-2.5 bg-slate-800 border border-slate-700 rounded-xs" /> Available Slot
            </span>
          </div>
        </div>

        {/* Optical Spectrum Slot Grid */}
        <div className="grid grid-cols-24 gap-1 p-2 bg-slate-950 rounded border border-slate-800 overflow-x-auto">
          {spectrumSlots.slice(0, 48).map((slot, index) => {
            const activeWdm = wavelengths.find(w => Math.abs(w.frequency_thz - slot.frequencyThz) < 0.02);
            const isSelected = activeWdm?.channel_id === selectedChannelId;

            return (
              <button
                key={slot.slotId}
                onClick={() => {
                  if (activeWdm) {
                    setSelectedChannelId(activeWdm.channel_id);
                    onSelectWavelength(activeWdm);
                  }
                }}
                className={`h-16 rounded flex flex-col items-center justify-between p-1 text-[9px] font-mono transition cursor-pointer border ${
                  activeWdm
                    ? isSelected
                      ? 'bg-cyan-900/80 border-cyan-400 text-cyan-200 ring-2 ring-cyan-400/40'
                      : activeWdm.line_rate_gbps === 800
                        ? 'bg-cyan-950/60 border-cyan-700 text-cyan-300 hover:bg-cyan-900/50'
                        : 'bg-blue-950/60 border-blue-700 text-blue-300 hover:bg-blue-900/50'
                    : 'bg-slate-900/40 border-slate-800/80 text-slate-600 hover:border-slate-700'
                }`}
              >
                <span className="opacity-70">{slot.frequencyThz.toFixed(2)}</span>
                {activeWdm ? (
                  <div className="text-center font-bold">
                    <div>{activeWdm.line_rate_gbps}G</div>
                    <div className="text-[8px] opacity-80">{activeWdm.modulation.replace('DP-', '')}</div>
                  </div>
                ) : (
                  <span className="text-[8px] text-slate-700">IDLE</span>
                )}
                <span className="text-[8px] opacity-60">#{index + 1}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Two-Column Detail View: Wavelength Table vs Channel Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Column: Channels Table */}
        <div className="lg:col-span-7 bg-[#0e1422] rounded-md border border-slate-800 p-4">
          <div className="flex items-center justify-between mb-3">
            <h4 className="font-mono text-sm font-bold text-slate-200">
              Provisioned Coherent Wavelength Channels
            </h4>
            <input
              type="text"
              placeholder="Filter by ID, Node, Modulation..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="px-2.5 py-1 bg-slate-900 border border-slate-700 rounded text-xs text-slate-200 font-mono placeholder:text-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 bg-slate-900/50">
                  <th className="p-2">Channel ID</th>
                  <th className="p-2">Freq / λ</th>
                  <th className="p-2">Line Rate</th>
                  <th className="p-2">Modulation</th>
                  <th className="p-2">OSNR (dB)</th>
                  <th className="p-2">Pre-FEC BER</th>
                  <th className="p-2">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredChannels.map((ch) => {
                  const isSelected = ch.channel_id === selectedChannelId;
                  return (
                    <tr
                      key={ch.channel_id}
                      onClick={() => {
                        setSelectedChannelId(ch.channel_id);
                        onSelectWavelength(ch);
                      }}
                      className={`hover:bg-slate-800/50 cursor-pointer transition ${
                        isSelected ? 'bg-slate-800/80 text-cyan-300' : 'text-slate-300'
                      }`}
                    >
                      <td className="p-2 font-bold">{ch.channel_id}</td>
                      <td className="p-2 text-slate-400">{ch.frequency_thz.toFixed(2)} THz ({ch.wavelength_nm.toFixed(1)} nm)</td>
                      <td className="p-2 font-bold text-white">{ch.line_rate_gbps} Gbps</td>
                      <td className="p-2">{ch.modulation}</td>
                      <td className="p-2 text-emerald-400 font-bold">{ch.current_osnr_db} dB</td>
                      <td className="p-2 text-slate-400">{ch.ber_pre_fec.toExponential(1)}</td>
                      <td className="p-2">
                        <span className="px-1.5 py-0.5 rounded text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-800/60">
                          {ch.status}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Column: Selected Channel Physics & Telemetry Inspector */}
        {selectedChannel && (
          <div className="lg:col-span-5 bg-[#0e1422] rounded-md border border-slate-800 p-4 font-mono space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div>
                <span className="text-[10px] uppercase text-cyan-400 font-bold">Wavelength Transponder State</span>
                <h3 className="text-base font-bold text-white">{selectedChannel.channel_id}</h3>
              </div>
              <button
                onClick={() => onLaunchLab({
                  distanceKm: selectedChannel.dispersion_accumulated_ps_nm / 17,
                  launchPowerDbm: selectedChannel.launch_power_dbm,
                  baudRateGbaud: selectedChannel.baud_rate_gbaud,
                  modulation: selectedChannel.modulation
                })}
                className="flex items-center gap-1.5 bg-cyan-600 hover:bg-cyan-500 text-white px-2.5 py-1.5 rounded text-xs font-semibold cursor-pointer shadow transition"
              >
                <span>Drill to Waveform Lab</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="bg-slate-900/60 p-2.5 rounded border border-slate-800">
                <span className="text-slate-500 text-[10px]">Launch Power</span>
                <div className="text-sm font-bold text-slate-100">{selectedChannel.launch_power_dbm} dBm</div>
              </div>
              <div className="bg-slate-900/60 p-2.5 rounded border border-slate-800">
                <span className="text-slate-500 text-[10px]">Baud Rate</span>
                <div className="text-sm font-bold text-slate-100">{selectedChannel.baud_rate_gbaud} Gbaud</div>
              </div>
              <div className="bg-slate-900/60 p-2.5 rounded border border-slate-800">
                <span className="text-slate-500 text-[10px]">Accumulated CD</span>
                <div className="text-sm font-bold text-slate-100">{selectedChannel.dispersion_accumulated_ps_nm} ps/nm</div>
              </div>
              <div className="bg-slate-900/60 p-2.5 rounded border border-slate-800">
                <span className="text-slate-500 text-[10px]">Q-Factor</span>
                <div className="text-sm font-bold text-emerald-400">{selectedChannel.q_factor_db} dB</div>
              </div>
            </div>

            {/* Carried Enterprise Services */}
            <div className="space-y-1.5">
              <span className="text-xs text-slate-400 font-bold uppercase">Carried Services & Circuits</span>
              {selectedChannel.service_ids.map(svcId => (
                <div key={svcId} className="bg-slate-900 p-2 rounded border border-slate-800 text-xs flex items-center justify-between text-slate-300">
                  <span className="text-cyan-400 font-bold">{svcId}</span>
                  <span className="text-slate-500 text-[11px]">Protected 1+1</span>
                </div>
              ))}
            </div>

            {/* Route Topology */}
            <div className="space-y-1 text-xs">
              <span className="text-slate-400 font-bold uppercase">Physical Route Spans</span>
              <div className="p-2 bg-slate-900 rounded border border-slate-800 text-slate-300 space-y-1">
                <div className="text-slate-400 text-[11px]">Source: {selectedChannel.source_node_id}</div>
                <div className="text-slate-400 text-[11px]">Target: {selectedChannel.target_node_id}</div>
                <div className="text-cyan-400 text-[11px]">Cables: {selectedChannel.route_cable_ids.join(' ➔ ')}</div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
