import React from 'react';
import { 
  Map, Activity, Box, AlertOctagon, Waves, TrendingUp, 
  GitPullRequest, Wrench, ShieldCheck, Terminal
} from 'lucide-react';

export type ActiveTab = 
  | 'MAP_GIS'
  | 'OPTICAL_MATRIX'
  | 'RACK_3D'
  | 'NOC_INCIDENTS'
  | 'WAVEFORM_LAB'
  | 'CAPACITY_PLANNER'
  | 'AUTOMATION_SANDBOX'
  | 'FIELD_OPS'
  | 'AUDIT_COMPLIANCE';

interface NavigationProps {
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  activeAlarmCount: number;
}

export const Navigation: React.FC<NavigationProps> = ({
  activeTab,
  onSelectTab,
  activeAlarmCount
}) => {
  const navItems: { id: ActiveTab; label: string; icon: React.ReactNode; badge?: number }[] = [
    { id: 'MAP_GIS', label: '1. National GIS Twin', icon: <Map className="w-4 h-4" /> },
    { id: 'OPTICAL_MATRIX', label: '2. Optical & λ Grid', icon: <Activity className="w-4 h-4" /> },
    { id: 'RACK_3D', label: '3. 3D POP & Rack Twin', icon: <Box className="w-4 h-4" /> },
    { id: 'NOC_INCIDENTS', label: '4. NOC Incidents', icon: <AlertOctagon className="w-4 h-4" />, badge: activeAlarmCount },
    { id: 'WAVEFORM_LAB', label: '5. High-Fidelity Lab', icon: <Waves className="w-4 h-4" /> },
    { id: 'CAPACITY_PLANNER', label: '6. Capacity Planning', icon: <TrendingUp className="w-4 h-4" /> },
    { id: 'AUTOMATION_SANDBOX', label: '7. Safe Automation (L0-L5)', icon: <GitPullRequest className="w-4 h-4" /> },
    { id: 'FIELD_OPS', label: '8. Field Ops & OTDR', icon: <Wrench className="w-4 h-4" /> },
    { id: 'AUDIT_COMPLIANCE', label: '9. Audit & Security', icon: <ShieldCheck className="w-4 h-4" /> }
  ];

  return (
    <nav className="bg-[#0b101b] border-b border-slate-800 px-4 flex items-center overflow-x-auto select-none no-scrollbar">
      <div className="flex items-center space-x-1 py-1.5 min-w-max">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSelectTab(item.id)}
              className={`flex items-center gap-2 px-3 py-1.5 rounded text-xs font-mono font-medium transition cursor-pointer ${
                isActive 
                  ? 'bg-slate-800 text-cyan-400 border border-cyan-500/40 shadow-sm' 
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900 border border-transparent'
              }`}
            >
              <span className={isActive ? 'text-cyan-400' : 'text-slate-400'}>
                {item.icon}
              </span>
              <span>{item.label}</span>
              {item.badge !== undefined && item.badge > 0 && (
                <span className="bg-red-600 text-white font-bold text-[10px] px-1.5 py-0.2 rounded-full">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
