import React from 'react';
import { OpticalNode, FibreCable, ServiceCircuit } from '../types/optical';
import { 
  X, Server, Radio, Zap, Shield, AlertTriangle, 
  Layers, ArrowRight, Gauge, Activity, Wrench, CheckCircle2
} from 'lucide-react';

interface DetailDrawerProps {
  selectedNode: OpticalNode | null;
  selectedCable: FibreCable | null;
  allServices: ServiceCircuit[];
  onClose: () => void;
  onDrilldownToPOP: (nodeId: string) => void;
  onInjectCutOnCable: (cableId: string) => void;
  onRestoreCable: (cableId: string) => void;
  onComputePaths: (srcNodeId: string) => void;
}

export const DetailDrawer: React.FC<DetailDrawerProps> = ({
  selectedNode,
  selectedCable,
  allServices,
  onClose,
  onDrilldownToPOP,
  onInjectCutOnCable,
  onRestoreCable,
  onComputePaths
}) => {
  if (!selectedNode && !selectedCable) return null;

  return (
    <div className="fixed top-0 right-0 h-full w-96 bg-[#0e1422] border-l border-slate-800 shadow-2xl z-50 flex flex-col font-mono text-xs text-slate-200">
      {/* Header */}
      <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-[#090d16]">
        <div className="flex items-center gap-2">
          {selectedNode ? (
            <Server className="w-4 h-4 text-cyan-400" />
          ) : (
            <Radio className="w-4 h-4 text-blue-400" />
          )}
          <h3 className="font-bold text-white text-sm">
            {selectedNode ? selectedNode.name : selectedCable?.name}
          </h3>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Content Scroll */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {selectedNode && (
          <>
            {/* POP Role Badge & Coordinates */}
            <div className="space-y-1">
              <span className="text-[10px] text-slate-500 uppercase">POP Role & Location</span>
              <div className="flex items-center justify-between bg-slate-900 p-2.5 rounded border border-slate-800">
                <span className="text-cyan-300 font-bold">{selectedNode.role}</span>
                <span className="text-slate-400 text-[11px]">{selectedNode.location.city} ({selectedNode.location.region})</span>
              </div>
            </div>

            {/* Hardware & Power Metrics */}
            <div className="grid grid-cols-2 gap-2">
              <div className="bg-slate-900/80 p-2 rounded border border-slate-800">
                <span className="text-slate-500 text-[10px]">ROADM Degrees</span>
                <div className="text-sm font-bold text-white">{selectedNode.roadm_degrees} Ways</div>
              </div>
              <div className="bg-slate-900/80 p-2 rounded border border-slate-800">
                <span className="text-slate-500 text-[10px]">Switching Capacity</span>
                <div className="text-sm font-bold text-emerald-400">{selectedNode.total_switching_capacity_tbps} Tb/s</div>
              </div>
              <div className="bg-slate-900/80 p-2 rounded border border-slate-800">
                <span className="text-slate-500 text-[10px]">Rack Bays</span>
                <div className="text-sm font-bold text-white">{selectedNode.total_racks} Racks (42U)</div>
              </div>
              <div className="bg-slate-900/80 p-2 rounded border border-slate-800">
                <span className="text-slate-500 text-[10px]">Facility Power Draw</span>
                <div className="text-sm font-bold text-amber-400">{selectedNode.power_draw_kw} kW</div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="space-y-2 pt-2">
              <button
                onClick={() => onDrilldownToPOP(selectedNode.object_id)}
                className="w-full flex items-center justify-center gap-2 bg-cyan-600 hover:bg-cyan-500 text-white font-bold py-2 rounded transition cursor-pointer shadow"
              >
                <span>Drill to 3D POP Physical Twin</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => onComputePaths(selectedNode.object_id)}
                className="w-full flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-700 text-cyan-300 font-bold py-2 rounded border border-slate-700 transition cursor-pointer"
              >
                <span>Compute Diverse Optical Paths</span>
                <Activity className="w-3.5 h-3.5" />
              </button>
            </div>
          </>
        )}

        {selectedCable && (
          <>
            {/* Fibre Health Status */}
            <div className="space-y-1">
              <span className="text-[10px] text-slate-500 uppercase">Optical Span Status</span>
              <div className={`p-2.5 rounded border flex items-center justify-between ${
                selectedCable.health_status === 'SEVERED'
                  ? 'bg-red-950/80 border-red-800 text-red-300 animate-pulse'
                  : 'bg-emerald-950/40 border-emerald-800 text-emerald-300'
              }`}>
                <span className="font-bold">{selectedCable.health_status}</span>
                <span className="text-[11px]">{selectedCable.fibre_type}</span>
              </div>
            </div>

            {/* Span Physics */}
            <div className="grid grid-cols-2 gap-2">
              <div className="bg-slate-900/80 p-2 rounded border border-slate-800">
                <span className="text-slate-500 text-[10px]">Total Distance</span>
                <div className="text-sm font-bold text-white">{selectedCable.length_km} km</div>
              </div>
              <div className="bg-slate-900/80 p-2 rounded border border-slate-800">
                <span className="text-slate-500 text-[10px]">Total Attenuation</span>
                <div className="text-sm font-bold text-white">{selectedCable.total_attenuation_db} dB</div>
              </div>
              <div className="bg-slate-900/80 p-2 rounded border border-slate-800">
                <span className="text-slate-500 text-[10px]">Total Fiber Cores</span>
                <div className="text-sm font-bold text-white">{selectedCable.total_cores} Cores ({selectedCable.lit_cores} Lit)</div>
              </div>
              <div className="bg-slate-900/80 p-2 rounded border border-slate-800">
                <span className="text-slate-500 text-[10px]">Utilization</span>
                <div className="text-sm font-bold text-cyan-400">
                  {Math.round((selectedCable.used_capacity_gbps / (selectedCable.total_capacity_gbps || 1)) * 100)}%
                </div>
              </div>
            </div>

            {/* Cable Actions */}
            <div className="space-y-2 pt-2">
              {selectedCable.health_status === 'SEVERED' ? (
                <button
                  onClick={() => onRestoreCable(selectedCable.object_id)}
                  className="w-full flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2 rounded transition cursor-pointer shadow"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Execute Splice Restoration</span>
                </button>
              ) : (
                <button
                  onClick={() => onInjectCutOnCable(selectedCable.object_id)}
                  className="w-full flex items-center justify-center gap-2 bg-red-600 hover:bg-red-500 text-white font-bold py-2 rounded transition cursor-pointer shadow"
                >
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>Simulate Physical Fibre Cut</span>
                </button>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
};
