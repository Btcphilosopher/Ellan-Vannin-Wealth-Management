import React, { useState, useEffect } from 'react';
import { 
  NetworkState, OpticalNode, FibreCable, WavelengthChannel, 
  ServiceCircuit, Alarm, Incident, WorkOrder, UserRole, CardDetails 
} from './types/optical';
import { NetworkInventoryRepository } from './engine/topologyData';
import { OpticalPathEngine, PathCandidate } from './engine/pathEngine';
import { AuditEngine } from './engine/auditEngine';

import { Header } from './components/Header';
import { Navigation, ActiveTab } from './components/Navigation';
import { NationalMap } from './components/NationalMap';
import { WavelengthMatrix } from './components/WavelengthMatrix';
import { Rack3DView } from './components/Rack3DView';
import { NocIncidentCenter } from './components/NocIncidentCenter';
import { HighFidelityLab } from './components/HighFidelityLab';
import { CapacityPlanningView } from './components/CapacityPlanningView';
import { ChangeManagerModal } from './components/ChangeManagerModal';
import { FieldOperationsView } from './components/FieldOperationsView';
import { AuditView } from './components/AuditView';
import { DetailDrawer } from './components/DetailDrawer';
import { FaultInjectionModal } from './components/FaultInjectionModal';

export const App: React.FC = () => {
  const [networkState, setNetworkState] = useState<NetworkState>(() => NetworkInventoryRepository.getState());
  const [activeTab, setActiveTab] = useState<ActiveTab>('MAP_GIS');
  const [currentRole, setCurrentRole] = useState<UserRole>('NOC_OPERATOR');

  // Selected entities for inspection & drilldown
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [selectedCableId, setSelectedCableId] = useState<string | null>(null);
  const [highlightedPathNodeIds, setHighlightedPathNodeIds] = useState<string[]>([]);

  // Waveform Lab initial parameters for drilldown
  const [labParams, setLabParams] = useState<{
    distanceKm: number;
    launchPowerDbm: number;
    baudRateGbaud: number;
    modulation: any;
  }>({
    distanceKm: 480,
    launchPowerDbm: 1.5,
    baudRateGbaud: 64,
    modulation: 'DP-16QAM'
  });

  // Time machine simulation state
  const [isTimeMachineActive, setIsTimeMachineActive] = useState(false);
  const [timeMachineDate, setTimeMachineDate] = useState('2026-09-17 04:00:00');

  // Fault injector modal
  const [isFaultModalOpen, setIsFaultModalOpen] = useState(false);

  // Sync state from authoritative repository
  const refreshState = () => {
    setNetworkState({ ...NetworkInventoryRepository.getState() });
  };

  const selectedNode = networkState.nodes.find(n => n.object_id === selectedNodeId) || null;
  const selectedCable = networkState.cables.find(c => c.object_id === selectedCableId) || null;

  const handleSelectNode = (node: OpticalNode | null) => {
    setSelectedNodeId(node ? node.object_id : null);
    setSelectedCableId(null);
  };

  const handleSelectCable = (cable: FibreCable | null) => {
    setSelectedCableId(cable ? cable.object_id : null);
    setSelectedNodeId(null);
  };

  const handleDrilldownToPOP = (nodeId: string) => {
    setSelectedNodeId(nodeId);
    setActiveTab('RACK_3D');
  };

  const handleDrilldownToLab = (card: CardDetails) => {
    setLabParams({
      distanceKm: 320,
      launchPowerDbm: 1.5,
      baudRateGbaud: 64,
      modulation: 'DP-16QAM'
    });
    setActiveTab('WAVEFORM_LAB');
  };

  const handleLaunchLabFromChannel = (params: any) => {
    setLabParams(params);
    setActiveTab('WAVEFORM_LAB');
  };

  const handleComputePaths = (srcNodeId: string) => {
    const targetNodeId = 'NODE-SLO-DCI-01'; // Default target DCI
    const candidates = OpticalPathEngine.computeCandidatePaths(
      srcNodeId,
      targetNodeId,
      networkState.nodes,
      networkState.cables
    );
    if (candidates.length > 0) {
      setHighlightedPathNodeIds(candidates[0].nodePath);
    }
  };

  const handleInjectFault = (cableId: string, faultType: string) => {
    try {
      NetworkInventoryRepository.injectFault(cableId, faultType as any);
      refreshState();
    } catch (e) {
      console.error(e);
    }
  };

  const handleRestoreCable = (cableId: string) => {
    NetworkInventoryRepository.restoreCable(cableId);
    refreshState();
  };

  const handleExecuteChange = (crId: string) => {
    AuditEngine.logAction('lead.engineer@nat-optical.gov.uk', 'OPTICAL_ENGINEER', 'EXECUTE_CHANGE', crId, 'Provisioned 800G flex-grid lambda channel in live network');
    refreshState();
  };

  const handleApproveChange = (crId: string) => {
    AuditEngine.logAction('lead.engineer@nat-optical.gov.uk', 'OPTICAL_ENGINEER', 'APPROVE_CHANGE', crId, 'Approved change with zero customer blast radius');
    refreshState();
  };

  const handleCompleteWorkOrder = (orderId: string) => {
    const wo = networkState.workOrders.find(w => w.order_id === orderId);
    if (wo) {
      wo.status = 'COMPLETED';
      handleRestoreCable(wo.target_object_id);
    }
  };

  return (
    <div className="min-h-screen bg-[#070b12] text-slate-200 flex flex-col font-sans select-none">
      {/* Topmost Institutional Header */}
      <Header
        currentRole={currentRole}
        onRoleChange={setCurrentRole}
        activeIncidents={networkState.incidents}
        timeMachineDate={timeMachineDate}
        isTimeMachineActive={isTimeMachineActive}
        onToggleTimeMachine={() => setIsTimeMachineActive(!isTimeMachineActive)}
        onResetTimeMachine={() => setIsTimeMachineActive(false)}
        onInjectFaultClick={() => setIsFaultModalOpen(true)}
      />

      {/* Main View Navigation Tabs */}
      <Navigation
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        activeAlarmCount={networkState.alarms.filter(a => !a.cleared).length}
      />

      {/* Active Workspace View */}
      <main className="flex-1 relative overflow-y-auto">
        {activeTab === 'MAP_GIS' && (
          <NationalMap
            nodes={networkState.nodes}
            cables={networkState.cables}
            services={networkState.services}
            alarms={networkState.alarms}
            selectedNodeId={selectedNodeId}
            selectedCableId={selectedCableId}
            onSelectNode={handleSelectNode}
            onSelectCable={handleSelectCable}
            highlightedPathNodeIds={highlightedPathNodeIds}
          />
        )}

        {activeTab === 'OPTICAL_MATRIX' && (
          <WavelengthMatrix
            wavelengths={networkState.wavelengths}
            onSelectWavelength={(ch) => setSelectedCableId(ch.route_cable_ids[0])}
            onLaunchLab={handleLaunchLabFromChannel}
          />
        )}

        {activeTab === 'RACK_3D' && (
          <Rack3DView
            nodes={networkState.nodes}
            selectedNodeId={selectedNodeId || networkState.nodes[0].object_id}
            onSelectNode={(id) => setSelectedNodeId(id)}
            onDrilldownToLab={handleDrilldownToLab}
          />
        )}

        {activeTab === 'NOC_INCIDENTS' && (
          <NocIncidentCenter
            incidents={networkState.incidents}
            alarms={networkState.alarms}
            services={networkState.services}
            cables={networkState.cables}
            workOrders={networkState.workOrders}
            onRestoreCable={handleRestoreCable}
            onDispatchWorkOrder={() => {}}
          />
        )}

        {activeTab === 'WAVEFORM_LAB' && (
          <HighFidelityLab
            initialDistanceKm={labParams.distanceKm}
            initialLaunchPowerDbm={labParams.launchPowerDbm}
            initialBaudRateGbaud={labParams.baudRateGbaud}
            initialModulation={labParams.modulation}
          />
        )}

        {activeTab === 'CAPACITY_PLANNER' && (
          <CapacityPlanningView
            scenarios={networkState.scenarios}
          />
        )}

        {activeTab === 'AUTOMATION_SANDBOX' && (
          <ChangeManagerModal
            currentRole={currentRole}
            changeRequests={AuditEngine.getChangeRequests()}
            onExecuteChange={handleExecuteChange}
            onApproveChange={handleApproveChange}
          />
        )}

        {activeTab === 'FIELD_OPS' && (
          <FieldOperationsView
            workOrders={networkState.workOrders}
            cables={networkState.cables}
            onCompleteWorkOrder={handleCompleteWorkOrder}
          />
        )}

        {activeTab === 'AUDIT_COMPLIANCE' && (
          <AuditView
            currentRole={currentRole}
          />
        )}
      </main>

      {/* Slide-over Detail Inspector */}
      <DetailDrawer
        selectedNode={selectedNode}
        selectedCable={selectedCable}
        allServices={networkState.services}
        onClose={() => {
          setSelectedNodeId(null);
          setSelectedCableId(null);
        }}
        onDrilldownToPOP={handleDrilldownToPOP}
        onInjectCutOnCable={(cableId) => handleInjectFault(cableId, 'FIBRE_CUT')}
        onRestoreCable={handleRestoreCable}
        onComputePaths={handleComputePaths}
      />

      {/* Optical Fault Injection Modal */}
      <FaultInjectionModal
        cables={networkState.cables}
        isOpen={isFaultModalOpen}
        onClose={() => setIsFaultModalOpen(false)}
        onInject={handleInjectFault}
      />
    </div>
  );
};

export default App;
