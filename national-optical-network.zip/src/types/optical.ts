/**
 * NATIONAL OPTICAL NETWORK - Enterprise Optical Transport Operating System
 * Digital Twin Logical & Physical Inventory Types
 */

export type NodeRole = 
  | 'NATIONAL_CORE_POP'
  | 'REGIONAL_POP'
  | 'METRO_HUB'
  | 'DATA_CENTRE_HYPERSCALE'
  | 'SUBSEA_LANDING_STATION'
  | 'FTTH_CENTRAL_EXCHANGE'
  | 'MOBILE_CELL_HUB'
  | 'ENTERPRISE_EDGE';

export type LayerType = 
  | 'CORE'
  | 'REGIONAL'
  | 'METRO'
  | 'FTTH'
  | 'SUBSEA'
  | 'MOBILE'
  | 'DATACENTRE'
  | 'DARK_FIBRE'
  | 'FAULTS'
  | 'MAINTENANCE'
  | 'CONSTRUCTION';

export type MapMode = 
  | 'PHYSICAL'
  | 'OPTICAL'
  | 'IP'
  | 'SERVICE'
  | 'CAPACITY'
  | 'FAULT'
  | 'ENERGY'
  | 'CONSTRUCTION'
  | 'MAINTENANCE';

export type UserRole = 
  | 'NOC_OPERATOR'
  | 'NETWORK_ENGINEER'
  | 'OPTICAL_ENGINEER'
  | 'PLANNER'
  | 'FIELD_ENGINEER'
  | 'SECURITY'
  | 'ADMIN'
  | 'AUDITOR'
  | 'EXECUTIVE_VIEWER';

export type Permission = 
  | 'READ'
  | 'ANALYSE'
  | 'SIMULATE'
  | 'PREPARE'
  | 'APPROVE'
  | 'EXECUTE';

export type AutomationLevel = 
  | 'LEVEL_0_OBSERVE'
  | 'LEVEL_1_RECOMMEND'
  | 'LEVEL_2_SIMULATE'
  | 'LEVEL_3_PREPARE_CONFIG'
  | 'LEVEL_4_HUMAN_APPROVAL'
  | 'LEVEL_5_CONTROLLED_EXECUTION';

export type AlarmSeverity = 'CRITICAL' | 'MAJOR' | 'WARNING' | 'INFO';

export type AssetStatus = 
  | 'PLANNED'
  | 'PROCURED'
  | 'INSTALLED'
  | 'COMMISSIONED'
  | 'ACTIVE'
  | 'MAINTENANCE'
  | 'DEGRADED'
  | 'FAULT'
  | 'UPGRADED'
  | 'RETIRED';

export type ModulationFormat = 
  | 'BPSK'
  | 'DP-QPSK'
  | 'DP-8QAM'
  | 'DP-16QAM'
  | 'DP-32QAM'
  | 'DP-64QAM'
  | 'PROBABILISTIC_CONSTELLATION_SHAPED';

export type FecType = 
  | 'HARD_DECISION_FEC'
  | 'G.975_RS_FEC'
  | 'SD_FEC_15%'
  | 'SD_FEC_20%'
  | 'OFEC_27%'
  | 'OFEC_CASCADE';

export interface GeoLocation {
  lat: number;
  lng: number;
  city: string;
  region: string;
  country: string;
  elevation_m?: number;
  address?: string;
}

export interface NetworkInventoryObject {
  object_id: string;
  object_type: string;
  name: string;
  manufacturer: string;
  model: string;
  serial_number: string;
  location: GeoLocation;
  status: AssetStatus;
  installation_date: string;
  software_version: string;
  configuration_version: string;
  owner: string;
  maintenance_state: 'IN_SERVICE' | 'MAINTENANCE_WINDOW' | 'STANDBY' | 'DECOMMISSIONED';
  data_quality_score: number; // 0.0 - 1.0
  last_seen: string;
}

export interface OpticalNode extends NetworkInventoryObject {
  object_type: 'OPTICAL_NODE';
  role: NodeRole;
  layer: LayerType;
  roadm_degrees: number;
  total_racks: number;
  active_transponders: number;
  total_switching_capacity_tbps: number;
  power_consumption_kw: number;
  cooling_status: 'NORMAL' | 'ELEVATED' | 'CRITICAL';
  temperature_celsius: number;
  is_subsea_landing: boolean;
  is_datacenter_interconnect: boolean;
  connected_customer_count: number;
  ftth_homes_passed?: number;
  ftth_homes_connected?: number;
  racks: RackDetails[];
}

export interface RackDetails {
  rack_id: string;
  rack_name: string;
  bay_number: number;
  total_ru: number;
  shelves: ShelfDetails[];
}

export interface ShelfDetails {
  shelf_id: string;
  shelf_name: string;
  shelf_type: 'ROADM_WSS' | 'EDFA_AMPLIFIER' | 'COHERENT_TRANSPONDER_CHASSIS' | 'ODF_FIBRE_DISTRIBUTION' | 'IP_CORE_ROUTER';
  slot_count: number;
  cards: CardDetails[];
}

export interface CardDetails {
  card_id: string;
  card_name: string;
  vendor: string;
  model: string;
  card_type: 'WSS_9X1' | 'WSS_20X1' | 'DUAL_EDFA_C_BAND' | 'RAMAN_PUMP' | 'TRANSPONDER_400G' | 'TRANSPONDER_800G' | 'TRANSPONDER_1.6T' | 'ODF_TRAY_96';
  status: 'ONLINE' | 'STANDBY' | 'ALARM' | 'OFFLINE';
  temperature: number;
  power_w: number;
  ports: PortDetails[];
}

export interface PortDetails {
  port_id: string;
  port_name: string;
  port_type: 'LC_APC' | 'MPO_12' | 'CFP2_DCO' | 'QSFP_DD' | 'OSFP' | 'LINE_IN' | 'LINE_OUT';
  rx_power_dbm: number;
  tx_power_dbm: number;
  is_connected: boolean;
  target_link_id?: string;
  status: 'ACTIVE' | 'DOWN' | 'UNPROVISIONED' | 'HIGH_BER';
}

export interface FibreCable extends NetworkInventoryObject {
  object_type: 'FIBRE_CABLE';
  cable_code: string;
  source_node_id: string;
  target_node_id: string;
  length_km: number;
  fibre_type: 'G.652.D' | 'G.654.E' | 'G.655_NZDSF' | 'G.657.A2_BEND_INSENSITIVE' | 'SUBSEA_LOW_LOSS';
  core_count: number;
  occupied_cores: number;
  available_cores: number;
  dark_fibre_cores: number;
  splice_count: number;
  attenuation_db_per_km: number;
  total_loss_db: number;
  chromatic_dispersion_ps_nm: number;
  pmd_ps: number;
  age_years: number;
  duct_id: string;
  is_aerial: boolean;
  is_buried: boolean;
  is_subsea: boolean;
  health_status: 'NOMINAL' | 'DEGRADED' | 'SEVERED' | 'MAINTENANCE';
  active_wavelengths_count: number;
  total_capacity_gbps: number;
  used_capacity_gbps: number;
  reserved_capacity_gbps: number;
  available_capacity_gbps: number;
  geo_coordinates: [number, number][]; // Polylines [lat, lng]
}

export interface WavelengthChannel {
  channel_id: string;
  itu_channel_number: number; // e.g., 193.10 THz
  frequency_thz: number;
  wavelength_nm: number;
  slot_width_ghz: number; // 50GHz fixed or 37.5 / 75 / 100 GHz flex-grid
  line_rate_gbps: number; // 100, 400, 800, 1600
  baud_rate_gbaud: number; // 32, 64, 96, 128
  modulation: ModulationFormat;
  fec: FecType;
  source_node_id: string;
  target_node_id: string;
  route_cable_ids: string[];
  launch_power_dbm: number;
  current_osnr_db: number;
  target_osnr_threshold_db: number;
  ber_pre_fec: number;
  ber_post_fec: number;
  q_factor_db: number;
  dispersion_accumulated_ps_nm: number;
  nonlinear_phase_shift_rad: number;
  service_ids: string[];
  status: 'ACTIVE' | 'DEGRADED' | 'DOWN' | 'PROVISIONING';
}

export interface ServiceCircuit {
  service_id: string;
  service_name: string;
  customer_id: string;
  customer_name: string;
  customer_tier: 'GOVERNMENT' | 'ENTERPRISE_FINANCE' | 'HYPERSCALER' | 'TELCO_WHOLESALE' | '5G_CARRIER' | 'RESIDENTIAL_FTTH';
  service_type: 'DCI_800G' | 'DCI_400G' | 'ENTERPRISE_PRIVATE_LINE' | 'MOBILE_5G_BACKHAUL' | 'MOBILE_FRONTHAUL_CPRI' | 'INTERNET_BACKBONE_TRANSIT' | 'GOV_ENCRYPTED_CIRCUIT' | 'LEASED_DARK_LAMBDA' | 'FTTH_10G_PON';
  bandwidth_gbps: number;
  source_node_id: string;
  target_node_id: string;
  primary_wavelength_ids: string[];
  protection_wavelength_ids: string[];
  protection_type: '1+1_OPTICAL_SNCP' | '1:1_RESTORED' | 'UNPROTECTED_BEST_EFFORT' | 'MESH_RESTORABLE';
  sla_availability_percent: number; // e.g. 99.999
  max_latency_ms: number;
  current_latency_ms: number;
  current_packet_loss: number;
  current_availability_30d: number;
  sla_state: 'COMPLIANT' | 'WARNING' | 'BREACHED';
  active_path_status: 'PRIMARY' | 'PROTECTION' | 'OUTAGE';
  creation_date: string;
}

export interface Alarm {
  alarm_id: string;
  timestamp: string;
  severity: AlarmSeverity;
  source_object_id: string;
  source_object_name: string;
  source_type: 'FIBRE_CABLE' | 'ROADM_NODE' | 'AMPLIFIER' | 'TRANSPONDER' | 'POWER_SYSTEM' | 'SUBSEA_REPEATER';
  alarm_code: string;
  description: string;
  root_cause_id?: string;
  is_root_cause: boolean;
  correlated_alarm_count: number;
  affected_service_ids: string[];
  otdr_distance_km?: number;
  acknowledged: boolean;
  cleared: boolean;
}

export interface Incident {
  incident_id: string;
  title: string;
  severity: AlarmSeverity;
  root_cause_object_id: string;
  root_cause_description?: string;
  description?: string;
  correlated_alarm_ids?: string[];
  affected_service_ids?: string[];
  affected_regions: string[];
  affected_services_count: number;
  affected_customers_count: number;
  start_time: string;
  estimated_recovery_time: string;
  status: 'INVESTIGATING' | 'AUTOMATED_RESTORATION_PENDING' | 'RESTORING' | 'RESOLVED';
  restoration_candidate_path?: string[];
  field_action_required: boolean;
  assigned_work_order_id?: string;
}

export interface WorkOrder {
  order_id?: string;
  title?: string;
  target_object_id?: string;
  assigned_technician?: string;
  gps_coordinates?: [number, number];
  status: 'DISPATCHED' | 'EN_ROUTE' | 'ON_SITE' | 'SPLICING' | 'TESTING_OTDR' | 'COMPLETED';
  eta_hours?: number;
  work_order_id?: string;
  incident_id?: string;
  site_id?: string;
  site_name?: string;
  gps_location?: GeoLocation;
  fault_type?: string;
  otdr_fault_distance_km?: number;
  technician_name?: string;
  technician_vehicle_id?: string;
  required_spares?: string[];
  created_at?: string;
  eta?: string;
  repair_procedure_checklist?: { step: string; completed: boolean }[];
}

export type FieldWorkOrder = WorkOrder;

export interface ChangeRequest {
  request_id: string;
  operator: string;
  role: UserRole;
  automation_level: AutomationLevel;
  reason: string;
  target_object_ids: string[];
  change_type: 'PROVISION_WAVELENGTH' | 'PROTECTION_SWITCH' | 'EDFA_PUMP_TUNING' | 'DECOMMISSION_WAVELENGTH' | 'WAVELENGTH_RE_ROUTE' | 'POWER_OPTIMISATION' | 'TRANSCEIVER_UPGRADE_800G' | 'ROADM_CROSS_CONNECT';
  before_state_summary: string;
  proposed_state_summary: string;
  risk_score: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  blast_radius_services: number;
  qot_impact_db: number;
  validation_status: 'PASSED' | 'WARNING' | 'FAILED';
  approval_status: 'PENDING' | 'APPROVED' | 'REJECTED' | 'AUTO_APPROVED' | 'PENDING_APPROVAL';
  execution_status: 'STAGED' | 'EXECUTING' | 'COMMITTED' | 'ROLLED_BACK' | 'READY_TO_EXECUTE';
  created_at: string;
  executed_at?: string;
  rollback_snapshot_id: string;
}

export interface PlanningScenario {
  scenario_id: string;
  name: string;
  description: string;
  growth_rate_annual_percent?: number;
  estimated_capex_gbp?: number;
  estimated_opex_annual_gbp?: number;
  forecast_horizon_months?: number;
  traffic_growth_annual_percent?: number;
  capex_usd?: number;
  opex_usd_per_year?: number;
  cost_per_tbps_usd?: number;
  exhausted_links_count?: number;
  required_transponders_count?: number;
  required_new_fibre_km?: number;
  feasibility_score?: number;
}

export type CapacityScenario = PlanningScenario;

export interface NetworkState {
  nodes: OpticalNode[];
  cables: FibreCable[];
  wavelengths: WavelengthChannel[];
  services: ServiceCircuit[];
  alarms: Alarm[];
  incidents: Incident[];
  workOrders: WorkOrder[];
  scenarios: PlanningScenario[];
  activeVersion: string;
  lastSyncTimestamp: string;
  totalFibreKm: number;
  totalThroughputPbps: number;
  totalNetworkPowerMw: number;
}

export interface AuditEvent {
  audit_id: string;
  timestamp: string;
  user: string;
  role: UserRole;
  action: string;
  target_object: string;
  details: string;
  ip_address: string;
  digital_signature: string;
}

export interface PhysicalTelemetryPoint {
  timestamp: string;
  total_optical_throughput_pbps: number;
  total_network_power_mw: number;
  active_wavelength_count: number;
  average_osnr_db: number;
  active_alarms_count: number;
  critical_incidents_count: number;
  sla_compliance_percent: number;
}
