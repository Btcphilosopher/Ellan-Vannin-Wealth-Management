import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { NetworkInventoryRepository } from './src/engine/topologyData';
import { QoTEngine } from './src/engine/qotEngine';
import { SSFMEngine } from './src/engine/ssfmLab';
import { OpticalPathEngine } from './src/engine/pathEngine';
import { CapacityEngine } from './src/engine/capacityEngine';
import { AuditEngine } from './src/engine/auditEngine';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Health Endpoint
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'HEALTHY',
      service: 'NATIONAL OPTICAL NETWORK - Enterprise Transport OS',
      version: 'v2026.09.17',
      digital_twin_sync_state: 'SYNCHRONIZED',
      timestamp: new Date().toISOString()
    });
  });

  // Network API Endpoints
  app.get('/api/network', (req, res) => {
    const state = NetworkInventoryRepository.getState();
    res.json(state);
  });

  app.get('/api/network/nodes', (req, res) => {
    const { nodes } = NetworkInventoryRepository.getState();
    res.json(nodes);
  });

  app.get('/api/network/links', (req, res) => {
    const { cables } = NetworkInventoryRepository.getState();
    res.json(cables);
  });

  app.get('/api/network/services', (req, res) => {
    const { services } = NetworkInventoryRepository.getState();
    res.json(services);
  });

  app.get('/api/network/capacity', (req, res) => {
    const forecast = CapacityEngine.generateNationalTrafficForecast();
    const alerts = CapacityEngine.getExhaustionAlerts();
    res.json({ forecast, alerts });
  });

  app.get('/api/network/faults', (req, res) => {
    const { alarms, incidents, workOrders } = NetworkInventoryRepository.getState();
    res.json({ alarms, incidents, workOrders });
  });

  // Digital Twin API Endpoints
  app.get('/api/twin/topology', (req, res) => {
    const state = NetworkInventoryRepository.getState();
    res.json({
      version: state.activeVersion,
      nodes_count: state.nodes.length,
      links_count: state.cables.length,
      wavelengths_count: state.wavelengths.length,
      services_count: state.services.length,
      nodes: state.nodes,
      links: state.cables
    });
  });

  app.get('/api/twin/assets', (req, res) => {
    const { nodes, cables } = NetworkInventoryRepository.getState();
    res.json({ nodes, cables });
  });

  app.get('/api/twin/services', (req, res) => {
    const { services } = NetworkInventoryRepository.getState();
    res.json(services);
  });

  app.get('/api/twin/optical-paths', (req, res) => {
    const { nodes, cables } = NetworkInventoryRepository.getState();
    const src = (req.query.src as string) || 'NODE-LON-CORE-01';
    const tgt = (req.query.tgt as string) || 'NODE-SLO-DCI-01';
    const paths = OpticalPathEngine.computeCandidatePaths(src, tgt, nodes, cables);
    res.json(paths);
  });

  app.get('/api/twin/telemetry', (req, res) => {
    const state = NetworkInventoryRepository.getState();
    res.json({
      timestamp: new Date().toISOString(),
      total_optical_throughput_pbps: state.totalThroughputPbps,
      total_network_power_mw: state.totalNetworkPowerMw,
      active_wavelengths: state.wavelengths.length,
      average_osnr_db: 23.4,
      sla_compliance_percent: 99.994,
      critical_incidents: state.incidents.filter(i => i.status !== 'RESOLVED').length,
      active_alarms: state.alarms.filter(a => !a.cleared).length
    });
  });

  app.post('/api/twin/snapshot', (req, res) => {
    const snapshotId = `SNAP-${Date.now().toString().slice(-8)}`;
    AuditEngine.logAction('system@nat-optical.gov.uk', 'ADMIN', 'CREATE_TWIN_SNAPSHOT', snapshotId, 'Automated state snapshot capture');
    res.json({
      snapshot_id: snapshotId,
      timestamp: new Date().toISOString(),
      status: 'COMMITTED',
      reconciled_objects: 1482
    });
  });

  // Optical Physics & QoT APIs
  app.post('/api/qot/calculate', (req, res) => {
    const result = QoTEngine.calculateQoT(req.body);
    res.json(result);
  });

  app.post('/api/lab/ssfm-simulate', (req, res) => {
    const result = SSFMEngine.runSimulation(req.body);
    res.json(result);
  });

  // Fault Engine APIs
  app.post('/api/fault/inject', (req, res) => {
    const { cableId, faultType } = req.body;
    try {
      const result = NetworkInventoryRepository.injectFault(cableId, faultType);
      AuditEngine.logAction('noc.operator@nat-optical.gov.uk', 'NOC_OPERATOR', 'SIMULATE_FIBRE_CUT', cableId, `Injected fault ${faultType} on ${cableId}`);
      res.json({ success: true, ...result });
    } catch (e: any) {
      res.status(400).json({ error: e.message });
    }
  });

  app.post('/api/fault/restore', (req, res) => {
    const { cableId } = req.body;
    const success = NetworkInventoryRepository.restoreCable(cableId);
    if (success) {
      AuditEngine.logAction('field.lead@nat-optical.gov.uk', 'FIELD_ENGINEER', 'RESTORE_FIBRE_SPAN', cableId, `Fibre splice restoration completed & verified via OTDR`);
      res.json({ success: true, message: `Cable ${cableId} successfully restored to nominal state.` });
    } else {
      res.status(404).json({ error: 'Cable not found' });
    }
  });

  // Change Management APIs
  app.post('/api/change', (req, res) => {
    const cr = AuditEngine.createChangeRequest(req.body);
    res.json(cr);
  });

  app.post('/api/change/:id/approve', (req, res) => {
    AuditEngine.logAction('lead.architect@nat-optical.gov.uk', 'OPTICAL_ENGINEER', 'APPROVE_CHANGE_REQUEST', req.params.id, 'Validated optical QoT margin > 2.0 dB and zero SLA breach');
    res.json({ status: 'APPROVED', change_id: req.params.id });
  });

  app.post('/api/change/:id/execute', (req, res) => {
    AuditEngine.logAction('lead.architect@nat-optical.gov.uk', 'OPTICAL_ENGINEER', 'EXECUTE_CHANGE_REQUEST', req.params.id, 'Configuration dispatched to target ROADMs/transponders');
    res.json({ status: 'COMMITTED', change_id: req.params.id, executed_at: new Date().toISOString() });
  });

  // Planning & Scenarios APIs
  app.get('/api/planning/results', (req, res) => {
    const state = NetworkInventoryRepository.getState();
    res.json(state.scenarios);
  });

  // Vite middleware for development vs static build for production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[NATIONAL OPTICAL NETWORK] Operating System server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
