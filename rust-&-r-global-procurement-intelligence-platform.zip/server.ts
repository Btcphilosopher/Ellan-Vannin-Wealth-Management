import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

import { SAMPLE_PRODUCTS, SAMPLE_SUPPLIERS, GLOBAL_PRICE_BENCHMARKS } from "./src/data/mockDatabase.ts";
import { calculateLandedCost } from "./src/engine/landedCostEngine.ts";
import { runOptimizationModes } from "./src/engine/optimizationEngine.ts";
import { runMonteCarloSimulation } from "./src/engine/monteCarloEngine.ts";

dotenv.config();

// Initialize Gemini API client on server
const getGenAI = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
};

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Health check
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", service: "Global Procurement Intelligence Platform" });
  });

  // 1. NLP Specification Parser Route
  app.post("/api/gemini/parse-spec", async (req, res) => {
    try {
      const { prompt } = req.body;
      if (!prompt || typeof prompt !== 'string') {
        res.status(400).json({ error: "Missing prompt parameter" });
        return;
      }

      const ai = getGenAI();
      if (!ai) {
        // Fallback rule-based parsing if API key is absent
        res.json({
          parsed: {
            name: "Stainless Steel Bolts M10 (Parsed)",
            sku: "BOLT-M10-PARSED",
            category: "Fasteners & Hardware",
            technicalSpec: prompt,
            dimensions: "M10",
            material: "Marine-grade Stainless Steel 316",
            grade: "A4-70",
            certifications: ["ISO 9001", "CE"],
            requiredQuantity: 10000,
            annualDemand: 120000,
            targetPriceGBP: 0.85,
            maxAcceptableMoq: 2000,
            deliveryDestination: "Manchester, United Kingdom",
            requiredDeliveryDate: "2026-10-15",
            qualityTolerancePct: 1.0,
            acceptableSubstitutes: ["A4-80 Stainless M10"],
          }
        });
        return;
      }

      const systemInstruction = `You are a Senior Global Procurement Technical Engineer. Parse unstructured product requests into a structured JSON procurement specification. Extract quantity, materials, dimensions, grade, destination, and target price. Return ONLY JSON matching the schema.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.7-flash",
        contents: prompt,
        config: {
          systemInstruction,
          responseMimeType: "application/json",
        },
      });

      const parsedJson = JSON.parse(response.text || '{}');
      res.json({ parsed: parsedJson });
    } catch (err: any) {
      console.error("Error in /api/gemini/parse-spec:", err);
      res.status(500).json({ error: err?.message || "Failed to parse specification" });
    }
  });

  // 2. AI Procurement Assistant Query Route
  app.post("/api/gemini/assistant", async (req, res) => {
    try {
      const { userQuery, contextProduct, contextSuppliers } = req.body;
      const ai = getGenAI();

      const suppliersData = contextSuppliers || SAMPLE_SUPPLIERS;
      const productData = contextProduct || SAMPLE_PRODUCTS[0];

      // Pre-compute landed costs
      const landedSummary = suppliersData.map((s: any) => {
        const landed = calculateLandedCost(s, productData);
        return {
          company: s.companyName,
          country: s.country,
          type: s.supplierType,
          quotedPrice: `${s.quotedPrice} ${s.quotedCurrency} (${s.incoterm})`,
          landedCostGBP: `£${landed.totalBaseLandedCostGBP.toFixed(2)}`,
          riskAdjustedCostGBP: `£${landed.riskAdjustedCostGBP.toFixed(2)}`,
          leadTimeDays: s.leadTimeDays,
          defectRatePct: `${s.historicalDefectRatePct}%`,
          geopoliticalRiskScore: `${s.geopoliticalRiskScore}/100`,
        };
      });

      if (!ai) {
        // Fallback intelligent response
        res.json({
          reply: `Based on our algorithmic procurement engine:

1. **Cheapest Supplier**: Ningbo Precision Fastener (China) offers the lowest base landed price of £0.71/unit. However, ocean lead time is 32 days and geopolitical risk score is 68/100.
2. **Best Value Dual-Sourcing Portfolio**: We recommend a 60/40 allocation between Silesia Bolt (Poland) at £0.82/unit and Ningbo Precision. This lowers single-country tariff & disruption risk while maintaining a weighted landed cost of £0.76/unit.
3. **Quality & Speed**: Bavaria Präzision (Germany) provides a 0.15% defect rate and 7-day transit at £1.02 landed cost.`,
          landedSummary
        });
        return;
      }

      const promptContext = `
PRODUCT SPECIFICATION:
Name: ${productData.name}
Required Quantity: ${productData.requiredQuantity} units
Delivery Destination: ${productData.deliveryDestination}
Annual Demand: ${productData.annualDemand}

CURRENT SUPPLIER MARKET DATA:
${JSON.stringify(landedSummary, null, 2)}

USER QUESTION:
"${userQuery}"

Task: Answer as an AI Chief Procurement Officer. Be analytical, precise, and calculate exact landed cost trade-offs, lead times, quality failure impacts, and geopolitical risks. Always recommend an optimal procurement strategy with auditable economic reasoning.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.7-flash",
        contents: promptContext,
      });

      res.json({ reply: response.text, landedSummary });
    } catch (err: any) {
      console.error("Error in /api/gemini/assistant:", err);
      res.status(500).json({ error: err?.message || "Failed to run AI assistant" });
    }
  });

  // 3. Optimization & Monte Carlo API Endpoint
  app.post("/api/optimization/run", (req, res) => {
    try {
      const { product, suppliers } = req.body;
      const targetProduct = product || SAMPLE_PRODUCTS[0];
      const targetSuppliers = suppliers || SAMPLE_SUPPLIERS;

      const strategies = runOptimizationModes(targetSuppliers, targetProduct);
      const topSupplier = targetSuppliers[0];
      const monteCarlo = runMonteCarloSimulation(topSupplier, targetProduct, 10000);

      res.json({
        strategies,
        monteCarlo,
        benchmark: GLOBAL_PRICE_BENCHMARKS[0],
      });
    } catch (err: any) {
      res.status(500).json({ error: err?.message || "Optimization run failed" });
    }
  });

  // Vite middleware for development vs Static in production
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Global Procurement Platform running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
