import { 
  Supplier, 
  ProductSpecification, 
  OptimizationStrategy, 
  AllocationShare 
} from '../types/procurement';
import { calculateLandedCost } from './landedCostEngine';
import { scoreSupplier, DEFAULT_SCORE_WEIGHTS } from './scoringEngine';
import { GLOBAL_PRICE_BENCHMARKS } from '../data/mockDatabase';

export function runOptimizationModes(
  suppliers: Supplier[],
  product: ProductSpecification
): OptimizationStrategy[] {
  if (!suppliers || suppliers.length === 0) return [];

  // Calculate landed cost breakdown for all suppliers
  const supplierCosts = suppliers.map(s => ({
    supplier: s,
    landed: calculateLandedCost(s, product),
    score: scoreSupplier(s, product, DEFAULT_SCORE_WEIGHTS, suppliers.map(x => calculateLandedCost(x, product).riskAdjustedCostGBP))
  }));

  const globalBenchmark = GLOBAL_PRICE_BENCHMARKS.find(b => b.category === product.category) 
    ? GLOBAL_PRICE_BENCHMARKS.find(b => b.category === product.category)!.medianGlobalPriceGBP 
    : product.targetPriceGBP;

  // 1. CHEAPEST MODE (100% Volume to Lowest Risk-Adjusted Landed Cost Supplier)
  const cheapestSorted = [...supplierCosts].sort((a, b) => a.landed.totalBaseLandedCostGBP - b.landed.totalBaseLandedCostGBP);
  const cheapestPrimary = cheapestSorted[0];

  const cheapestStrategy: OptimizationStrategy = {
    id: 'mode-cheapest',
    mode: 'CHEAPEST',
    title: 'Cheapest Direct Landed Cost',
    description: 'Allocates 100% volume to the single vendor minimizing upfront landed purchase cost.',
    allocations: [
      {
        supplierId: cheapestPrimary.supplier.id,
        supplierName: cheapestPrimary.supplier.companyName,
        country: cheapestPrimary.supplier.country,
        percentage: 100,
        allocatedUnits: product.requiredQuantity,
        unitLandedCostGBP: cheapestPrimary.landed.totalBaseLandedCostGBP,
        totalCostGBP: cheapestPrimary.landed.totalBaseLandedCostGBP * product.requiredQuantity,
        leadTimeDays: cheapestPrimary.supplier.leadTimeDays,
        defectRatePct: cheapestPrimary.supplier.historicalDefectRatePct,
      }
    ],
    weightedAvgLandedCostGBP: cheapestPrimary.landed.totalBaseLandedCostGBP,
    weightedAvgLeadTimeDays: cheapestPrimary.supplier.leadTimeDays,
    weightedAvgDefectRatePct: cheapestPrimary.supplier.historicalDefectRatePct,
    weightedAvgGeopoliticalRiskScore: cheapestPrimary.supplier.geopoliticalRiskScore,
    totalPurchaseBudgetGBP: cheapestPrimary.landed.totalBaseLandedCostGBP * product.requiredQuantity,
    estimatedSavingsVsBenchmarkGBP: (globalBenchmark - cheapestPrimary.landed.totalBaseLandedCostGBP) * product.requiredQuantity,
    savingsPct: ((globalBenchmark - cheapestPrimary.landed.totalBaseLandedCostGBP) / globalBenchmark) * 100,
    decisionExplanation: `${cheapestPrimary.supplier.companyName} (${cheapestPrimary.supplier.country}) selected as 100% supplier due to lowest unit landed cost of £${cheapestPrimary.landed.totalBaseLandedCostGBP.toFixed(2)}. Note single-source exposure and ${cheapestPrimary.supplier.leadTimeDays}-day lead time.`,
  };

  // 2. BEST VALUE / DUAL-SOURCING PORTFOLIO OPTIMIZATION (60% Primary, 40% Secondary)
  const scoredSorted = [...supplierCosts].sort((a, b) => b.score.overallScore - a.score.overallScore);
  const primaryScored = scoredSorted[0];
  const secondaryScored = scoredSorted[1] || scoredSorted[0];

  const bvAllocations: AllocationShare[] = scoredSorted.length === 1 ? [
    {
      supplierId: primaryScored.supplier.id,
      supplierName: primaryScored.supplier.companyName,
      country: primaryScored.country,
      percentage: 100,
      allocatedUnits: product.requiredQuantity,
      unitLandedCostGBP: primaryScored.landed.riskAdjustedCostGBP,
      totalCostGBP: primaryScored.landed.riskAdjustedCostGBP * product.requiredQuantity,
      leadTimeDays: primaryScored.supplier.leadTimeDays,
      defectRatePct: primaryScored.supplier.historicalDefectRatePct,
    }
  ] : [
    {
      supplierId: primaryScored.supplier.id,
      supplierName: primaryScored.supplier.companyName,
      country: primaryScored.supplier.country,
      percentage: 60,
      allocatedUnits: Math.round(product.requiredQuantity * 0.60),
      unitLandedCostGBP: primaryScored.landed.riskAdjustedCostGBP,
      totalCostGBP: primaryScored.landed.riskAdjustedCostGBP * product.requiredQuantity * 0.60,
      leadTimeDays: primaryScored.supplier.leadTimeDays,
      defectRatePct: primaryScored.supplier.historicalDefectRatePct,
    },
    {
      supplierId: secondaryScored.supplier.id,
      supplierName: secondaryScored.supplier.companyName,
      country: secondaryScored.supplier.country,
      percentage: 40,
      allocatedUnits: Math.round(product.requiredQuantity * 0.40),
      unitLandedCostGBP: secondaryScored.landed.riskAdjustedCostGBP,
      totalCostGBP: secondaryScored.landed.riskAdjustedCostGBP * product.requiredQuantity * 0.40,
      leadTimeDays: secondaryScored.supplier.leadTimeDays,
      defectRatePct: secondaryScored.supplier.historicalDefectRatePct,
    }
  ];

  const bvAvgLanded = bvAllocations.reduce((acc, curr) => acc + (curr.unitLandedCostGBP * curr.percentage / 100), 0);
  const bvAvgLead = bvAllocations.reduce((acc, curr) => acc + (curr.leadTimeDays * curr.percentage / 100), 0);
  const bvAvgDefect = bvAllocations.reduce((acc, curr) => acc + (curr.defectRatePct * curr.percentage / 100), 0);
  const bvAvgGeoRisk = bvAllocations.reduce((acc, curr) => {
    const sup = suppliers.find(s => s.id === curr.supplierId);
    return acc + ((sup?.geopoliticalRiskScore || 80) * curr.percentage / 100);
  }, 0);

  const bestValueStrategy: OptimizationStrategy = {
    id: 'mode-best-value',
    mode: 'BEST_VALUE',
    title: 'Optimal Dual-Sourcing Portfolio (60/40 Split)',
    description: 'Blends market-leading price and quality with built-in resilience and zero single-point failure.',
    allocations: bvAllocations,
    weightedAvgLandedCostGBP: bvAvgLanded,
    weightedAvgLeadTimeDays: Math.round(bvAvgLead),
    weightedAvgDefectRatePct: Number(bvAvgDefect.toFixed(2)),
    weightedAvgGeopoliticalRiskScore: Math.round(bvAvgGeoRisk),
    totalPurchaseBudgetGBP: bvAvgLanded * product.requiredQuantity,
    estimatedSavingsVsBenchmarkGBP: (globalBenchmark - bvAvgLanded) * product.requiredQuantity,
    savingsPct: ((globalBenchmark - bvAvgLanded) / globalBenchmark) * 100,
    decisionExplanation: `Dual-sourcing strategy splitting 60% to ${primaryScored.supplier.companyName} (${primaryScored.supplier.country}) and 40% to ${secondaryScored.supplier.companyName} (${secondaryScored.supplier.country}). Achieves £${bvAvgLanded.toFixed(2)} weighted unit landed cost while mitigating geopolitical disruption risk.`,
  };

  // 3. LOWEST RISK MODE (Prioritizes High Geopolitical Risk Score & Low Defect Rate)
  const lowestRiskSorted = [...supplierCosts].sort((a, b) => {
    const riskA = a.supplier.geopoliticalRiskScore + a.supplier.financialRiskScore - (a.supplier.historicalDefectRatePct * 5);
    const riskB = b.supplier.geopoliticalRiskScore + b.supplier.financialRiskScore - (b.supplier.historicalDefectRatePct * 5);
    return riskB - riskA;
  });
  const riskPrimary = lowestRiskSorted[0];

  const lowestRiskStrategy: OptimizationStrategy = {
    id: 'mode-lowest-risk',
    mode: 'LOWEST_RISK',
    title: 'Maximum Resilience Sourcing',
    description: 'Selects high-stability suppliers in low-risk geographies with near-zero defect rates.',
    allocations: [
      {
        supplierId: riskPrimary.supplier.id,
        supplierName: riskPrimary.supplier.companyName,
        country: riskPrimary.supplier.country,
        percentage: 100,
        allocatedUnits: product.requiredQuantity,
        unitLandedCostGBP: riskPrimary.landed.riskAdjustedCostGBP,
        totalCostGBP: riskPrimary.landed.riskAdjustedCostGBP * product.requiredQuantity,
        leadTimeDays: riskPrimary.supplier.leadTimeDays,
        defectRatePct: riskPrimary.supplier.historicalDefectRatePct,
      }
    ],
    weightedAvgLandedCostGBP: riskPrimary.landed.riskAdjustedCostGBP,
    weightedAvgLeadTimeDays: riskPrimary.supplier.leadTimeDays,
    weightedAvgDefectRatePct: riskPrimary.supplier.historicalDefectRatePct,
    weightedAvgGeopoliticalRiskScore: riskPrimary.supplier.geopoliticalRiskScore,
    totalPurchaseBudgetGBP: riskPrimary.landed.riskAdjustedCostGBP * product.requiredQuantity,
    estimatedSavingsVsBenchmarkGBP: (globalBenchmark - riskPrimary.landed.riskAdjustedCostGBP) * product.requiredQuantity,
    savingsPct: ((globalBenchmark - riskPrimary.landed.riskAdjustedCostGBP) / globalBenchmark) * 100,
    decisionExplanation: `${riskPrimary.supplier.companyName} (${riskPrimary.supplier.country}) chosen for supreme geopolitical stability (Score ${riskPrimary.supplier.geopoliticalRiskScore}/100) and low defect rate (${riskPrimary.supplier.historicalDefectRatePct}%).`,
  };

  // 4. FASTEST MODE (Minimizes Lead Time Days)
  const fastestSorted = [...supplierCosts].sort((a, b) => a.supplier.leadTimeDays - b.supplier.leadTimeDays);
  const fastestPrimary = fastestSorted[0];

  const fastestStrategy: OptimizationStrategy = {
    id: 'mode-fastest',
    mode: 'FASTEST',
    title: 'Rapid Speed & Nearshoring Delivery',
    description: 'Prioritizes shortest lead-time transit for emergency stock or high velocity production.',
    allocations: [
      {
        supplierId: fastestPrimary.supplier.id,
        supplierName: fastestPrimary.supplier.companyName,
        country: fastestPrimary.supplier.country,
        percentage: 100,
        allocatedUnits: product.requiredQuantity,
        unitLandedCostGBP: fastestPrimary.landed.riskAdjustedCostGBP,
        totalCostGBP: fastestPrimary.landed.riskAdjustedCostGBP * product.requiredQuantity,
        leadTimeDays: fastestPrimary.supplier.leadTimeDays,
        defectRatePct: fastestPrimary.supplier.historicalDefectRatePct,
      }
    ],
    weightedAvgLandedCostGBP: fastestPrimary.landed.riskAdjustedCostGBP,
    weightedAvgLeadTimeDays: fastestPrimary.supplier.leadTimeDays,
    weightedAvgDefectRatePct: fastestPrimary.supplier.historicalDefectRatePct,
    weightedAvgGeopoliticalRiskScore: fastestPrimary.supplier.geopoliticalRiskScore,
    totalPurchaseBudgetGBP: fastestPrimary.landed.riskAdjustedCostGBP * product.requiredQuantity,
    estimatedSavingsVsBenchmarkGBP: (globalBenchmark - fastestPrimary.landed.riskAdjustedCostGBP) * product.requiredQuantity,
    savingsPct: ((globalBenchmark - fastestPrimary.landed.riskAdjustedCostGBP) / globalBenchmark) * 100,
    decisionExplanation: `${fastestPrimary.supplier.companyName} (${fastestPrimary.supplier.country}) provides ultra-fast delivery in just ${fastestPrimary.supplier.leadTimeDays} days.`,
  };

  return [bestValueStrategy, cheapestStrategy, lowestRiskStrategy, fastestStrategy];
}

export function generateParetoFrontier(suppliers: Supplier[], product: ProductSpecification) {
  return suppliers.map(s => {
    const landed = calculateLandedCost(s, product);
    return {
      supplierId: s.id,
      companyName: s.companyName,
      country: s.country,
      costGBP: Number(landed.riskAdjustedCostGBP.toFixed(2)),
      qualityScore: Number((100 - s.historicalDefectRatePct * 5).toFixed(1)),
      resilienceScore: s.geopoliticalRiskScore,
      leadTimeDays: s.leadTimeDays,
      isParetoOptimal: s.geopoliticalRiskScore > 85 || landed.riskAdjustedCostGBP < 0.85,
    };
  });
}
