import { Supplier, ProductSpecification } from '../types/procurement';
import { calculateLandedCost } from './landedCostEngine';

export interface NegotiationMetrics {
  supplierId: string;
  companyName: string;
  quotedUnitPriceGBP: number;
  estimatedSupplierMarginPct: number;
  estimatedCostOfGoodsGBP: number;
  targetPriceGBP: number;
  acceptablePriceGBP: number;
  walkAwayPriceGBP: number;
  potentialNegotiationSavingsGBP: number;
  leveragePoints: string[];
}

export function calculateNegotiationStrategy(
  supplier: Supplier,
  product: ProductSpecification,
  alternativeSuppliersCount: number = 3
): NegotiationMetrics {
  const landed = calculateLandedCost(supplier, product);
  const quotedUnitPriceGBP = landed.purchasePriceGBP;

  // Estimate supplier gross margin based on type and geography
  let estimatedMarginPct = 22; // default
  if (supplier.supplierType === 'trading_company' || supplier.supplierType === 'broker') estimatedMarginPct = 28;
  if (supplier.supplierType === 'distributor') estimatedMarginPct = 32;
  if (supplier.country === 'China' || supplier.country === 'India') estimatedMarginPct = 20;

  const estimatedCostOfGoodsGBP = quotedUnitPriceGBP * (1 - estimatedMarginPct / 100);

  // Target Price: 10-14% below quoted price (targeting supplier margin compression while staying fair)
  const targetPriceGBP = Number((quotedUnitPriceGBP * 0.88).toFixed(2));
  
  // Acceptable Price: 5-7% discount
  const acceptablePriceGBP = Number((quotedUnitPriceGBP * 0.94).toFixed(2));

  // Walk-Away Price: 2% discount or target price of 2nd best alternative
  const walkAwayPriceGBP = Number((quotedUnitPriceGBP * 0.98).toFixed(2));

  const potentialSavingsPerUnit = quotedUnitPriceGBP - targetPriceGBP;
  const potentialNegotiationSavingsGBP = Number((potentialSavingsPerUnit * product.requiredQuantity).toFixed(2));

  const leveragePoints: string[] = [];

  if (product.requiredQuantity >= supplier.moq * 2) {
    leveragePoints.push(`High Order Volume: Requesting ${product.requiredQuantity.toLocaleString()} units vs supplier MOQ of ${supplier.moq.toLocaleString()} (2x+ volume leverage).`);
  }

  if (product.annualDemand > product.requiredQuantity) {
    leveragePoints.push(`Annual Demand Commitment: Offer 12-month framework agreement based on ${product.annualDemand.toLocaleString()} annual demand.`);
  }

  if (alternativeSuppliersCount > 1) {
    leveragePoints.push(`Competitive Dual-Sourcing Threat: Active quotes from ${alternativeSuppliersCount} alternative global manufacturers available.`);
  }

  if (supplier.paymentTerms.toLowerCase().includes('lc') || supplier.paymentTerms.toLowerCase().includes('deposit')) {
    leveragePoints.push(`Payment Term Concession: Offer faster 10-day TT payment in exchange for a 3.5% cash discount.`);
  }

  return {
    supplierId: supplier.id,
    companyName: supplier.companyName,
    quotedUnitPriceGBP,
    estimatedSupplierMarginPct: estimatedMarginPct,
    estimatedCostOfGoodsGBP: Number(estimatedCostOfGoodsGBP.toFixed(2)),
    targetPriceGBP,
    acceptablePriceGBP,
    walkAwayPriceGBP,
    potentialNegotiationSavingsGBP,
    leveragePoints,
  };
}
