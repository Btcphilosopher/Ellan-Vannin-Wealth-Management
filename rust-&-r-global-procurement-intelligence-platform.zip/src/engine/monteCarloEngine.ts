import { Supplier, ProductSpecification, MonteCarloSimulationResult } from '../types/procurement';
import { calculateLandedCost } from './landedCostEngine';

export function runMonteCarloSimulation(
  supplier: Supplier,
  product: ProductSpecification,
  simulationsCount: number = 10000
): MonteCarloSimulationResult {
  const baseLanded = calculateLandedCost(supplier, product).totalBaseLandedCostGBP;
  const results: number[] = new Array(simulationsCount);

  // Random normal distribution helper (Box-Muller transform)
  function randomNormal(mean = 0, stdev = 1) {
    const u1 = Math.max(1e-9, Math.random());
    const u2 = Math.random();
    const z0 = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
    return mean + z0 * stdev;
  }

  const fxVol = supplier.quotedCurrency === 'GBP' ? 0.005 : 0.045; // 4.5% standard FX volatility
  const freightVol = 0.12; // 12% freight rate surge risk
  const defectVol = supplier.historicalDefectRatePct / 100;
  const disruptionChance = (100 - supplier.geopoliticalRiskScore) / 1000;

  for (let i = 0; i < simulationsCount; i++) {
    // Randomize FX fluctuation
    const fxMultiplier = Math.max(0.7, 1 + randomNormal(0, fxVol));
    
    // Randomize freight spike (exponential tail)
    const freightMultiplier = Math.max(0.8, 1 + randomNormal(0, freightVol));

    // Randomize defect batch rate (beta-like)
    const defectSpike = Math.max(0, randomNormal(defectVol, defectVol * 0.5));

    // Randomize port disruption or tariff spike
    const isDisrupted = Math.random() < disruptionChance;
    const disruptionCost = isDisrupted ? baseLanded * (0.15 + Math.random() * 0.25) : 0;

    // Calculate simulated unit landed cost
    const simulatedCost = 
      (baseLanded * 0.75 * fxMultiplier) + 
      (baseLanded * 0.15 * freightMultiplier) + 
      (baseLanded * defectSpike * 3) + 
      disruptionCost;

    results[i] = Number(simulatedCost.toFixed(3));
  }

  // Sort results to calculate percentiles
  results.sort((a, b) => a - b);

  const sum = results.reduce((a, b) => a + b, 0);
  const meanLandedCostGBP = Number((sum / simulationsCount).toFixed(2));

  const p10GBP = results[Math.floor(simulationsCount * 0.10)];
  const p50GBP = results[Math.floor(simulationsCount * 0.50)];
  const p90GBP = results[Math.floor(simulationsCount * 0.90)];
  const worstCaseScenarioGBP = results[simulationsCount - 1];

  // Standard deviation
  const variance = results.reduce((acc, val) => acc + Math.pow(val - meanLandedCostGBP, 2), 0) / simulationsCount;
  const stdDevGBP = Number(Math.sqrt(variance).toFixed(2));

  // Construct distribution histogram bins
  const binCount = 10;
  const minCost = results[0];
  const maxCost = results[simulationsCount - 1];
  const binWidth = (maxCost - minCost) / binCount || 0.05;

  const histogramBins: { binRange: string; frequency: number; cumulativePct: number }[] = [];
  let cumulativeCount = 0;

  for (let i = 0; i < binCount; i++) {
    const binMin = minCost + i * binWidth;
    const binMax = binMin + binWidth;
    const count = results.filter(r => r >= binMin && (i === binCount - 1 ? r <= binMax : r < binMax)).length;
    cumulativeCount += count;

    histogramBins.push({
      binRange: `£${binMin.toFixed(2)} - £${binMax.toFixed(2)}`,
      frequency: count,
      cumulativePct: Number(((cumulativeCount / simulationsCount) * 100).toFixed(1)),
    });
  }

  return {
    simulationsCount,
    meanLandedCostGBP,
    p10GBP,
    p50GBP,
    p90GBP,
    stdDevGBP,
    worstCaseScenarioGBP,
    costDistribution: histogramBins,
    riskFactorImpacts: [
      { factor: 'FX Exchange Volatility', varianceContributionPct: 42 },
      { factor: 'Freight & Ocean Spot Rates', varianceContributionPct: 28 },
      { factor: 'Quality & Defect Rework', varianceContributionPct: 18 },
      { factor: 'Geopolitical & Tariff Spikes', varianceContributionPct: 12 },
    ],
  };
}
