import { Supplier, ProductSpecification, LandedCostBreakdown } from '../types/procurement';
import { FX_RATES_TO_GBP } from '../data/mockDatabase';

export function calculateLandedCost(
  supplier: Supplier,
  product: ProductSpecification,
  options?: {
    customFreightGBPPerUnit?: number;
    customTariffOverridePct?: number;
  }
): LandedCostBreakdown {
  // 1. Convert Quoted Unit Price to GBP
  const fxRate = FX_RATES_TO_GBP[supplier.quotedCurrency] || 1.0;
  const purchasePriceGBP = supplier.quotedPrice * fxRate;

  // 2. Base Freight & Insurance Estimates depending on country & transport mode
  let baseFreightGBP = options?.customFreightGBPPerUnit;
  if (baseFreightGBP === undefined) {
    if (supplier.country === 'United Kingdom') baseFreightGBP = 0.02;
    else if (['Germany', 'Poland', 'Turkey'].includes(supplier.country)) baseFreightGBP = 0.08;
    else if (['China', 'Vietnam', 'India'].includes(supplier.country)) baseFreightGBP = 0.14;
    else if (['South Korea', 'Japan', 'USA', 'Brazil'].includes(supplier.country)) baseFreightGBP = 0.18;
    else baseFreightGBP = 0.12;
  }

  // 3. Tariff rate calculation
  let tariffRatePct = options?.customTariffOverridePct;
  if (tariffRatePct === undefined) {
    // Check trade agreements with UK
    if (['United Kingdom', 'Vietnam', 'Turkey', 'Poland', 'Germany'].includes(supplier.country)) {
      tariffRatePct = 0.0;
    } else if (supplier.country === 'India') {
      tariffRatePct = 3.2;
    } else if (supplier.country === 'China') {
      tariffRatePct = 4.5;
    } else {
      tariffRatePct = 2.5;
    }
  }

  // 4. Calculate Incoterm adjustments (converting EXW/FOB/etc to DDP equivalent)
  let packagingGBP = 0.01;
  let domesticTransportGBP = 0.0;
  let exportCostsGBP = 0.0;
  let freightCostGBP = 0.0;
  let insuranceCostGBP = 0.0;
  let importDutyGBP = 0.0;
  let importVatGBP = 0.0; // Assume recoverable or standard tax
  let customsBrokerageGBP = 0.005;
  let portChargesGBP = 0.0;
  let warehousingGBP = 0.01;
  let inlandTransportGBP = 0.0;

  switch (supplier.incoterm) {
    case 'EXW':
      packagingGBP = 0.02;
      domesticTransportGBP = 0.04;
      exportCostsGBP = 0.02;
      freightCostGBP = baseFreightGBP;
      insuranceCostGBP = purchasePriceGBP * 0.005;
      importDutyGBP = purchasePriceGBP * (tariffRatePct / 100);
      portChargesGBP = 0.03;
      inlandTransportGBP = 0.03;
      break;

    case 'FCA':
      exportCostsGBP = 0.015;
      freightCostGBP = baseFreightGBP;
      insuranceCostGBP = purchasePriceGBP * 0.005;
      importDutyGBP = purchasePriceGBP * (tariffRatePct / 100);
      portChargesGBP = 0.03;
      inlandTransportGBP = 0.03;
      break;

    case 'FOB':
      freightCostGBP = baseFreightGBP;
      insuranceCostGBP = purchasePriceGBP * 0.005;
      importDutyGBP = purchasePriceGBP * (tariffRatePct / 100);
      portChargesGBP = 0.025;
      inlandTransportGBP = 0.03;
      break;

    case 'CIF':
    case 'CFR':
      // Freight & insurance already included in quote
      freightCostGBP = 0.0;
      insuranceCostGBP = supplier.incoterm === 'CFR' ? purchasePriceGBP * 0.005 : 0.0;
      importDutyGBP = purchasePriceGBP * (tariffRatePct / 100);
      portChargesGBP = 0.02;
      inlandTransportGBP = 0.025;
      break;

    case 'DAP':
      // Delivered at Place - duty and customs brokerage remain buyer side
      freightCostGBP = 0.0;
      insuranceCostGBP = 0.0;
      importDutyGBP = purchasePriceGBP * (tariffRatePct / 100);
      portChargesGBP = 0.0;
      inlandTransportGBP = 0.01;
      break;

    case 'DDP':
      // All duties, freight, insurance paid by supplier
      freightCostGBP = 0.0;
      insuranceCostGBP = 0.0;
      importDutyGBP = 0.0;
      portChargesGBP = 0.0;
      inlandTransportGBP = 0.0;
      break;
  }

  // 5. Working capital financing cost (Annual 8% WACC tied up over lead time)
  const annualCostOfCapital = 0.08;
  const financingCostGBP = purchasePriceGBP * annualCostOfCapital * (supplier.leadTimeDays / 365);

  // 6. Total Base Landed Cost before risk/quality
  const totalBaseLandedCostGBP = 
    purchasePriceGBP +
    packagingGBP +
    domesticTransportGBP +
    exportCostsGBP +
    freightCostGBP +
    insuranceCostGBP +
    importDutyGBP +
    customsBrokerageGBP +
    portChargesGBP +
    warehousingGBP +
    inlandTransportGBP +
    financingCostGBP;

  // 7. Expected Quality Losses
  // Formula: Defect rate * (Unit Replacement Cost + Inspection + Rework/Downtime factor)
  const defectProbability = supplier.historicalDefectRatePct / 100;
  const failureCostMultiplier = 3.5; // Replacement + testing + customer disruption
  const expectedQualityLossGBP = totalBaseLandedCostGBP * defectProbability * failureCostMultiplier;

  // 8. Expected Delay & Disruption Costs
  // Delay cost derived from on-time delivery probability
  const delayRiskProbability = (100 - supplier.historicalOnTimeDeliveryPct) / 100;
  const expectedDelayCostGBP = totalBaseLandedCostGBP * delayRiskProbability * 0.15;

  // Geopolitical & Financial bankruptcy risk premium
  const financialRiskFactor = (100 - supplier.financialRiskScore) / 100;
  const geopoliticalRiskFactor = (100 - supplier.geopoliticalRiskScore) / 100;
  const expectedDisruptionCostGBP = totalBaseLandedCostGBP * (financialRiskFactor * 0.02 + geopoliticalRiskFactor * 0.03);

  // 9. Summary Costs
  const qualityAdjustedCostGBP = totalBaseLandedCostGBP + expectedQualityLossGBP;
  const riskAdjustedCostGBP = qualityAdjustedCostGBP + expectedDelayCostGBP + expectedDisruptionCostGBP;

  return {
    supplierId: supplier.id,
    supplierName: supplier.companyName,
    country: supplier.country,
    quotedPriceOriginal: supplier.quotedPrice,
    quotedCurrency: supplier.quotedCurrency,
    quotedPriceGBP: purchasePriceGBP,
    incoterm: supplier.incoterm,
    purchasePriceGBP,
    packagingGBP,
    domesticTransportGBP,
    exportCostsGBP,
    freightCostGBP,
    insuranceCostGBP,
    importDutyGBP,
    importVatGBP,
    customsBrokerageGBP,
    portChargesGBP,
    warehousingGBP,
    inlandTransportGBP,
    financingCostGBP,
    expectedQualityLossGBP,
    expectedDelayCostGBP,
    expectedDisruptionCostGBP,
    totalBaseLandedCostGBP,
    qualityAdjustedCostGBP,
    riskAdjustedCostGBP,
  };
}
