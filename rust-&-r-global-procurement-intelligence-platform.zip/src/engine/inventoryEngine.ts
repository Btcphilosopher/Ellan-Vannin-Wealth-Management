import { ProductSpecification, Supplier } from '../types/procurement';

export interface InventoryMetrics {
  annualDemand: number;
  unitLandedCostGBP: number;
  holdingCostRatePct: number;
  holdingCostPerUnitGBP: number;
  orderCostGBP: number;
  eoqUnits: number;
  safetyStockUnits: number;
  reorderPointUnits: number;
  workingCapitalRequirementGBP: number;
  expectedStockoutRiskPct: number;
  turnsPerYear: number;
}

export function calculateInventoryEconomics(
  product: ProductSpecification,
  supplier: Supplier,
  unitLandedCostGBP: number
): InventoryMetrics {
  const annualDemand = product.annualDemand || product.requiredQuantity * 4;
  const holdingCostRatePct = 0.20; // 20% annual carrying cost (storage + capital + insurance + spoilage)
  const holdingCostPerUnitGBP = unitLandedCostGBP * holdingCostRatePct;
  const orderCostGBP = 250.0; // Fixed administrative PO cost

  // Economic Order Quantity (EOQ = sqrt(2 * D * S / H))
  const eoqUnits = Math.round(Math.sqrt((2 * annualDemand * orderCostGBP) / Math.max(0.01, holdingCostPerUnitGBP)));

  // Safety Stock = Z * sqrt(LeadTime * VarDemand + Demand^2 * VarLeadTime)
  // Assuming Z = 1.65 for 95% service level
  const dailyDemand = annualDemand / 365;
  const leadTimeStdDev = supplier.leadTimeDays * 0.15; // 15% lead time variability
  const safetyStockUnits = Math.round(1.65 * Math.sqrt(supplier.leadTimeDays * Math.pow(dailyDemand * 0.2, 2) + Math.pow(dailyDemand, 2) * Math.pow(leadTimeStdDev, 2)));

  // Reorder Point = (Daily Demand * Lead Time Days) + Safety Stock
  const reorderPointUnits = Math.round((dailyDemand * supplier.leadTimeDays) + safetyStockUnits);

  // Working Capital = (EOQ / 2 + Safety Stock) * Unit Landed Cost
  const workingCapitalRequirementGBP = Number(((eoqUnits / 2 + safetyStockUnits) * unitLandedCostGBP).toFixed(2));

  const expectedStockoutRiskPct = Number((100 - supplier.historicalOnTimeDeliveryPct).toFixed(1));
  const turnsPerYear = Number((annualDemand / Math.max(1, (eoqUnits / 2 + safetyStockUnits))).toFixed(1));

  return {
    annualDemand,
    unitLandedCostGBP,
    holdingCostRatePct,
    holdingCostPerUnitGBP,
    orderCostGBP,
    eoqUnits,
    safetyStockUnits,
    reorderPointUnits,
    workingCapitalRequirementGBP,
    expectedStockoutRiskPct,
    turnsPerYear,
  };
}
