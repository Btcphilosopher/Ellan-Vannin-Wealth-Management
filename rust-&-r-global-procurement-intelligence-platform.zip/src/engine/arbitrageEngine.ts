import { ArbitrageCountryMetric } from '../types/procurement';
import { ARBITRAGE_COUNTRY_METRICS } from '../data/mockDatabase';

export function getGlobalArbitrageMatrix(): ArbitrageCountryMetric[] {
  return ARBITRAGE_COUNTRY_METRICS.sort((a, b) => a.compositeCostIndex - b.compositeCostIndex);
}

export function findArbitrageOpportunities(productCategory: string) {
  const metrics = getGlobalArbitrageMatrix();
  const lowestCost = metrics[0];
  const highestCost = metrics[metrics.length - 1];

  const maxSavingsPct = Math.round(((highestCost.compositeCostIndex - lowestCost.compositeCostIndex) / highestCost.compositeCostIndex) * 100);

  return {
    category: productCategory,
    lowestCostCountry: lowestCost.country,
    highestCostCountry: highestCost.country,
    potentialArbitrageSavingsPct: maxSavingsPct,
    recommendation: `Transitioning non-critical volume from high-cost domestic production (${highestCost.country}) to low-cost hubs (${lowestCost.country} or ${metrics[1].country}) unlocks up to ${maxSavingsPct}% gross procurement arbitrage.`,
  };
}
