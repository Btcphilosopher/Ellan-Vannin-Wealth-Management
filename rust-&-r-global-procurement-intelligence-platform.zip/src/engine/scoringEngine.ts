import { Supplier, SupplierScorecard, SupplierScoreWeights, ProductSpecification } from '../types/procurement';
import { calculateLandedCost } from './landedCostEngine';

export const DEFAULT_SCORE_WEIGHTS: SupplierScoreWeights = {
  price: 25,
  quality: 20,
  delivery: 15,
  capacity: 10,
  financial: 10,
  leadTime: 5,
  geopolitical: 5,
  compliance: 5,
  communication: 5,
  innovation: 0,
};

export function scoreSupplier(
  supplier: Supplier,
  product: ProductSpecification,
  weights: SupplierScoreWeights = DEFAULT_SCORE_WEIGHTS,
  allSuppliersLandedCosts: number[] = []
): SupplierScorecard {
  const landedBreakdown = calculateLandedCost(supplier, product);
  const landedCost = landedBreakdown.riskAdjustedCostGBP;

  // Relative Price Score: 100 if equal or lower than lowest landed cost, scaled down for higher
  const minLanded = allSuppliersLandedCosts.length > 0 ? Math.min(...allSuppliersLandedCosts) : landedCost;
  const priceRatio = minLanded / Math.max(0.001, landedCost);
  const priceScore = Math.min(100, Math.max(10, Math.round(priceRatio * 100)));

  // Quality score: derived from historical defect rate (0% defect = 100 score)
  const qualityScore = Math.max(0, Math.min(100, Math.round((1 - supplier.historicalDefectRatePct / 5) * 100)));

  // Delivery reliability score
  const deliveryScore = Math.min(100, Math.round(supplier.historicalOnTimeDeliveryPct));

  // Capacity score: ratio of production capacity to required demand
  const requiredMonthly = product.requiredQuantity;
  const capacityRatio = supplier.productionCapacityMonthly / Math.max(1, requiredMonthly);
  const capacityScore = Math.min(100, Math.round(Math.min(2.0, capacityRatio) * 50));

  // Financial stability score
  const financialScore = Math.min(100, supplier.financialRiskScore);

  // Lead time score: 100 for <= 3 days, decreasing by 2 per day
  const leadTimeScore = Math.max(10, Math.min(100, Math.round(100 - (supplier.leadTimeDays - 3) * 2.2)));

  // Geopolitical risk score
  const geopoliticalScore = Math.min(100, supplier.geopoliticalRiskScore);

  // Compliance score based on certifications
  const requiredCerts = product.certifications;
  const matchedCerts = requiredCerts.filter(c => supplier.certifications.includes(c));
  const complianceScore = requiredCerts.length > 0 
    ? Math.round((matchedCerts.length / requiredCerts.length) * 100) 
    : 95;

  // Communication & Innovation
  const communicationScore = supplier.supplierType === 'distributor' ? 95 : 85;
  const innovationScore = supplier.capabilities.length >= 4 ? 90 : 75;

  // Calculate Weighted Overall Composite Score
  const totalWeight = Object.values(weights).reduce((a, b) => a + b, 0) || 100;

  const weightedSum = 
    priceScore * weights.price +
    qualityScore * weights.quality +
    deliveryScore * weights.delivery +
    capacityScore * weights.capacity +
    financialScore * weights.financial +
    leadTimeScore * weights.leadTime +
    geopoliticalScore * weights.geopolitical +
    complianceScore * weights.compliance +
    communicationScore * weights.communication +
    innovationScore * weights.innovation;

  const overallScore = Math.round(weightedSum / totalWeight);

  const explainableSummary = `${supplier.companyName} (${supplier.country}) achieved an overall score of ${overallScore}/100. Strengths include ${
    qualityScore > 90 ? 'exceptional quality (' + (100 - supplier.historicalDefectRatePct) + '% defect-free)' : 'solid pricing'
  } and ${deliveryScore}% on-time delivery rate. Risk-adjusted landed unit cost is £${landedCost.toFixed(2)}.`;

  return {
    supplierId: supplier.id,
    companyName: supplier.companyName,
    country: supplier.country,
    priceScore,
    qualityScore,
    deliveryScore,
    capacityScore,
    financialScore,
    leadTimeScore,
    geopoliticalScore,
    complianceScore,
    communicationScore,
    innovationScore,
    overallScore,
    rank: 1, // updated after sorting
    riskAdjustedLandedCostGBP: landedCost,
    explainableSummary,
  };
}
