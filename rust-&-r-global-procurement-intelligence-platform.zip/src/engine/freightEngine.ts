import { FreightOption, TransportMode, Supplier } from '../types/procurement';

export function compareFreightModes(
  supplier: Supplier,
  quantity: number,
  unitValueGBP: number
): FreightOption[] {
  // Economic cost of delay per day based on unit value (e.g. 0.05% of value per day in tied capital + stockout penalty)
  const economicCostPerDay = unitValueGBP * 0.0015;

  const options: FreightOption[] = [
    {
      mode: 'sea',
      name: 'Ocean FCL / LCL Container',
      costPerUnitGBP: 0.12,
      transitTimeDays: 28,
      co2KgPerUnit: 0.08,
      reliabilityPct: 92,
      insuranceRatePct: 0.35,
      economicDelayCostPerDayGBP: economicCostPerDay * 28,
      totalEconomicCostGBP: 0.12 + (economicCostPerDay * 28),
      isOptimal: true,
    },
    {
      mode: 'rail',
      name: 'Eurasia Express Rail (Silk Road Route)',
      costPerUnitGBP: 0.28,
      transitTimeDays: 14,
      co2KgPerUnit: 0.18,
      reliabilityPct: 95,
      insuranceRatePct: 0.45,
      economicDelayCostPerDayGBP: economicCostPerDay * 14,
      totalEconomicCostGBP: 0.28 + (economicCostPerDay * 14),
      isOptimal: false,
    },
    {
      mode: 'air',
      name: 'Air Cargo Freight',
      costPerUnitGBP: 1.25,
      transitTimeDays: 4,
      co2KgPerUnit: 1.85,
      reliabilityPct: 98,
      insuranceRatePct: 0.20,
      economicDelayCostPerDayGBP: economicCostPerDay * 4,
      totalEconomicCostGBP: 1.25 + (economicCostPerDay * 4),
      isOptimal: false,
    },
    {
      mode: 'road',
      name: 'Cross-Border Trucking (Europe/Turkey/UK)',
      costPerUnitGBP: 0.18,
      transitTimeDays: 7,
      co2KgPerUnit: 0.32,
      reliabilityPct: 96,
      insuranceRatePct: 0.30,
      economicDelayCostPerDayGBP: economicCostPerDay * 7,
      totalEconomicCostGBP: 0.18 + (economicCostPerDay * 7),
      isOptimal: supplier.country === 'Poland' || supplier.country === 'Germany' || supplier.country === 'Turkey',
    }
  ];

  // Pick optimal mode based on total economic cost
  let lowestCost = Infinity;
  let optimalIdx = 0;
  options.forEach((opt, idx) => {
    if (opt.totalEconomicCostGBP < lowestCost) {
      lowestCost = opt.totalEconomicCostGBP;
      optimalIdx = idx;
    }
  });

  options.forEach((opt, idx) => {
    opt.isOptimal = (idx === optimalIdx);
  });

  return options;
}
