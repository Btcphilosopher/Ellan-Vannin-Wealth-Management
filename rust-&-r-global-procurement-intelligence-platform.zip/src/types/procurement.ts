export type Incoterm = 'EXW' | 'FCA' | 'FOB' | 'CIF' | 'CFR' | 'DAP' | 'DDP';

export type SupplierType = 'manufacturer' | 'distributor' | 'wholesaler' | 'trading_company' | 'broker' | 'agent';

export type Currency = 'GBP' | 'USD' | 'EUR' | 'CNY' | 'JPY' | 'CHF' | 'INR' | 'KRW' | 'CAD' | 'AUD';

export type TransportMode = 'sea' | 'air' | 'rail' | 'road' | 'multimodal';

export interface ProductSpecification {
  id: string;
  name: string;
  sku: string;
  category: string;
  technicalSpec: string;
  dimensions: string;
  material: string;
  grade: string;
  certifications: string[];
  requiredQuantity: number;
  annualDemand: number;
  targetPriceGBP: number;
  maxAcceptableMoq: number;
  deliveryDestination: string;
  requiredDeliveryDate: string;
  qualityTolerancePct: number;
  acceptableSubstitutes: string[];
}

export interface Supplier {
  id: string;
  companyName: string;
  supplierType: SupplierType;
  country: string;
  city: string;
  factoryLocation: string;
  categories: string[];
  capabilities: string[];
  certifications: string[];
  productionCapacityMonthly: number;
  moq: number;
  quotedPrice: number;
  quotedCurrency: Currency;
  incoterm: Incoterm;
  leadTimeDays: number;
  paymentTerms: string; // e.g. "30% Deposit, 70% LC at sight"
  historicalDefectRatePct: number;
  historicalOnTimeDeliveryPct: number;
  financialRiskScore: number; // 0-100 (100 = safest)
  geopoliticalRiskScore: number; // 0-100 (100 = lowest risk)
  latitude: number;
  longitude: number;
  contactEmail: string;
  website: string;
  reliabilityScore: number; // 0-100
  carbonEmissionsKgPerUnit: number;
}

export interface LandedCostBreakdown {
  supplierId: string;
  supplierName: string;
  country: string;
  quotedPriceOriginal: number;
  quotedCurrency: Currency;
  quotedPriceGBP: number;
  incoterm: Incoterm;
  
  // Breakdown steps in GBP per unit
  purchasePriceGBP: number;
  packagingGBP: number;
  domesticTransportGBP: number;
  exportCostsGBP: number;
  freightCostGBP: number;
  insuranceCostGBP: number;
  importDutyGBP: number;
  importVatGBP: number;
  customsBrokerageGBP: number;
  portChargesGBP: number;
  warehousingGBP: number;
  inlandTransportGBP: number;
  financingCostGBP: number;
  
  // Risk & Quality adjustments
  expectedQualityLossGBP: number;
  expectedDelayCostGBP: number;
  expectedDisruptionCostGBP: number;
  
  totalBaseLandedCostGBP: number; // Before quality/risk
  qualityAdjustedCostGBP: number;
  riskAdjustedCostGBP: number; // Final economic comparison metric
}

export interface SupplierScoreWeights {
  price: number;        // default 25%
  quality: number;      // default 20%
  delivery: number;     // default 15%
  capacity: number;     // default 10%
  financial: number;    // default 10%
  leadTime: number;     // default 5%
  geopolitical: number; // default 5%
  compliance: number;   // default 5%
  communication: number; // default 5%
  innovation: number;   // default 5%
}

export interface SupplierScorecard {
  supplierId: string;
  companyName: string;
  country: string;
  priceScore: number;
  qualityScore: number;
  deliveryScore: number;
  capacityScore: number;
  financialScore: number;
  leadTimeScore: number;
  geopoliticalScore: number;
  complianceScore: number;
  communicationScore: number;
  innovationScore: number;
  overallScore: number; // 0 - 100
  rank: number;
  riskAdjustedLandedCostGBP: number;
  explainableSummary: string;
}

export interface AllocationShare {
  supplierId: string;
  supplierName: string;
  country: string;
  percentage: number;
  allocatedUnits: number;
  unitLandedCostGBP: number;
  totalCostGBP: number;
  leadTimeDays: number;
  defectRatePct: number;
}

export interface OptimizationStrategy {
  id: string;
  mode: 'CHEAPEST' | 'BEST_VALUE' | 'LOWEST_RISK' | 'FASTEST' | 'STRATEGIC' | 'GLOBAL_ARBITRAGE';
  title: string;
  description: string;
  allocations: AllocationShare[];
  weightedAvgLandedCostGBP: number;
  weightedAvgLeadTimeDays: number;
  weightedAvgDefectRatePct: number;
  weightedAvgGeopoliticalRiskScore: number;
  totalPurchaseBudgetGBP: number;
  estimatedSavingsVsBenchmarkGBP: number;
  savingsPct: number;
  decisionExplanation: string;
}

export interface RFQQuotationInput {
  id: string;
  supplierName: string;
  country: string;
  supplierType: SupplierType;
  currency: Currency;
  quotedUnitPrice: number;
  incoterm: Incoterm;
  leadTimeDays: number;
  moq: number;
  estimatedDefectPct: number;
  notes?: string;
}

export interface MonteCarloSimulationResult {
  simulationsCount: number;
  meanLandedCostGBP: number;
  p10GBP: number;
  p50GBP: number;
  p90GBP: number;
  stdDevGBP: number;
  worstCaseScenarioGBP: number;
  costDistribution: { binRange: string; frequency: number; cumulativePct: number }[];
  riskFactorImpacts: { factor: string; varianceContributionPct: number }[];
}

export interface GlobalPriceBenchmark {
  category: string;
  productName: string;
  unit: string;
  lowestObservedPriceGBP: number;
  p25PriceGBP: number;
  medianGlobalPriceGBP: number;
  p75PriceGBP: number;
  highestObservedPriceGBP: number;
  currentCompanyPriceGBP: number;
  companyDiscountPct: number; // negative if premium, positive if discount
  priceHistory: { date: string; medianGBP: number; chinaGBP: number; europeGBP: number; usGBP: number }[];
}

export interface ArbitrageCountryMetric {
  country: string;
  code: string;
  laborCostIndex: number; // 100 = UK baseline
  energyCostIndex: number;
  rawMaterialIndex: number;
  avgFreightToUKGBP: number;
  tariffRatePct: number;
  fxVolatilityPct: number;
  compositeCostIndex: number;
  keyAdvantage: string;
  primaryRisk: string;
}

export interface FreightOption {
  mode: TransportMode;
  name: string;
  costPerUnitGBP: number;
  transitTimeDays: number;
  co2KgPerUnit: number;
  reliabilityPct: number;
  insuranceRatePct: number;
  economicDelayCostPerDayGBP: number;
  totalEconomicCostGBP: number;
  isOptimal: boolean;
}

export interface DemandForecastPoint {
  month: string;
  projectedDemandUnits: number;
  lowerConfidenceBound: number;
  upperConfidenceBound: number;
  seasonalityFactor: number;
}
