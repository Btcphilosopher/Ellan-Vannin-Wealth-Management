import React, { useState } from 'react';
import { 
  Globe2, 
  Search, 
  Filter, 
  CheckCircle2, 
  AlertTriangle, 
  Building, 
  Award, 
  Clock, 
  DollarSign, 
  ChevronRight,
  ShieldCheck,
  Zap
} from 'lucide-react';
import { Supplier, ProductSpecification } from '../types/procurement';
import { scoreSupplier, DEFAULT_SCORE_WEIGHTS } from '../engine/scoringEngine';
import { calculateLandedCost } from '../engine/landedCostEngine';

interface SupplierDiscoveryProps {
  suppliers: Supplier[];
  product: ProductSpecification;
  onSelectSupplierForDetail: (supplier: Supplier) => void;
  onNavigateToLandedCost: () => void;
}

export const SupplierDiscovery: React.FC<SupplierDiscoveryProps> = ({
  suppliers,
  product,
  onSelectSupplierForDetail,
  onNavigateToLandedCost,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCountry, setSelectedCountry] = useState('ALL');
  const [selectedType, setSelectedType] = useState('ALL');
  const [selectedSupplierForModal, setSelectedSupplierForModal] = useState<Supplier | null>(null);

  const countries = ['ALL', 'China', 'Poland', 'Turkey', 'Germany', 'United Kingdom', 'India', 'Vietnam', 'South Korea'];
  const types = ['ALL', 'manufacturer', 'distributor', 'trading_company', 'broker'];

  const filteredSuppliers = suppliers.filter(s => {
    const matchesSearch = s.companyName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          s.country.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          s.capabilities.some(c => c.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesCountry = selectedCountry === 'ALL' || s.country === selectedCountry;
    const matchesType = selectedType === 'ALL' || s.supplierType === selectedType;
    return matchesSearch && matchesCountry && matchesType;
  });

  const allLandedCosts = suppliers.map(s => calculateLandedCost(s, product).riskAdjustedCostGBP);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-6 text-zinc-100 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-md">
        <div>
          <div className="flex items-center gap-2.5 mb-1.5">
            <span className="bg-amber-500/10 text-amber-300 text-xs px-2.5 py-0.5 rounded border border-amber-500/30 font-semibold uppercase font-mono">
              {filteredSuppliers.length} Global Vendors Discovered
            </span>
            <span className="text-zinc-400 text-xs">Category: {product.category}</span>
          </div>
          <h2 className="text-xl font-bold tracking-tight text-zinc-100 font-serif-title">Global Supplier Discovery & Intelligence Engine</h2>
          <p className="text-xs text-zinc-400">
            Distinguishes direct manufacturers from distributors, trading companies & brokers. Computes multi-dimensional scorecards.
          </p>
        </div>

        <button 
          onClick={onNavigateToLandedCost}
          className="bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-bold px-4 py-2.5 rounded-lg shadow-md transition-all flex items-center gap-2 shrink-0 cursor-pointer"
        >
          <Zap className="w-4 h-4 text-zinc-950" />
          <span>Compare Total Landed Costs</span>
        </button>
      </div>

      {/* Filters & Search */}
      <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-4 text-zinc-100 flex flex-col md:flex-row items-center justify-between gap-4 shadow-sm">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search vendor name, capabilities, location..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-[#050505] border border-zinc-700/80 rounded-lg pl-9 pr-3 py-2 text-xs text-zinc-100 placeholder-zinc-500 focus:outline-none focus:ring-1 focus:ring-amber-500/50"
          />
        </div>

        <div className="flex items-center gap-3 w-full md:w-auto">
          <div className="flex items-center gap-2 text-xs">
            <Filter className="w-4 h-4 text-amber-400" />
            <span className="text-zinc-400 font-medium">Country:</span>
            <select
              value={selectedCountry}
              onChange={(e) => setSelectedCountry(e.target.value)}
              className="bg-[#050505] border border-zinc-700/80 text-xs text-zinc-100 rounded px-2.5 py-1.5 focus:outline-none cursor-pointer"
            >
              {countries.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className="text-zinc-400 font-medium">Type:</span>
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
              className="bg-[#050505] border border-zinc-700/80 text-xs text-zinc-100 rounded px-2.5 py-1.5 focus:outline-none uppercase cursor-pointer"
            >
              {types.map(t => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>
        </div>
      </div>

      {/* Supplier Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredSuppliers.map(s => {
          const landed = calculateLandedCost(s, product);
          const scorecard = scoreSupplier(s, product, DEFAULT_SCORE_WEIGHTS, allLandedCosts);

          const isManufacturer = s.supplierType === 'manufacturer';

          return (
            <div 
              key={s.id}
              className="bg-[#0c0c0f] border border-zinc-800/80 hover:border-amber-500/30 rounded-xl p-5 text-zinc-100 flex flex-col justify-between transition-all shadow-md group relative overflow-hidden"
            >
              {/* Top Type Badge */}
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2">
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded font-mono uppercase ${
                      isManufacturer ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30' : 'bg-blue-500/15 text-blue-300 border border-blue-500/30'
                    }`}>
                      {s.supplierType}
                    </span>
                    <span className="text-xs font-semibold text-zinc-300">{s.country}</span>
                  </div>
                  <h3 className="text-sm font-bold text-zinc-100 mt-1.5 group-hover:text-amber-300 transition-colors line-clamp-1 font-serif-title">
                    {s.companyName}
                  </h3>
                  <p className="text-[11px] text-zinc-400">{s.factoryLocation}</p>
                </div>

                <div className="text-right shrink-0">
                  <div className="text-lg font-bold font-mono text-amber-400">
                    {scorecard.overallScore}<span className="text-xs text-zinc-500 font-normal">/100</span>
                  </div>
                  <span className="text-[10px] text-zinc-400 uppercase tracking-wider block font-semibold">Global Score</span>
                </div>
              </div>

              {/* Core Financial & Quality Specs */}
              <div className="my-4 pt-3 border-t border-zinc-800/80 grid grid-cols-2 gap-3 text-xs">
                <div>
                  <span className="text-zinc-400 block text-[10px]">Quoted Price</span>
                  <span className="font-mono font-bold text-zinc-100">
                    {s.quotedPrice} {s.quotedCurrency} <span className="text-zinc-500 font-normal">({s.incoterm})</span>
                  </span>
                </div>

                <div>
                  <span className="text-zinc-400 block text-[10px]">Risk-Adjusted Landed</span>
                  <span className="font-mono font-bold text-amber-400">
                    £{landed.riskAdjustedCostGBP.toFixed(2)} / unit
                  </span>
                </div>

                <div>
                  <span className="text-zinc-400 block text-[10px]">Lead Time</span>
                  <span className="font-mono text-zinc-100 flex items-center gap-1">
                    <Clock className="w-3 h-3 text-zinc-400" />
                    {s.leadTimeDays} days
                  </span>
                </div>

                <div>
                  <span className="text-zinc-400 block text-[10px]">Historical Defect Rate</span>
                  <span className={`font-mono font-semibold ${s.historicalDefectRatePct < 1.0 ? 'text-emerald-400' : 'text-amber-400'}`}>
                    {s.historicalDefectRatePct}%
                  </span>
                </div>
              </div>

              {/* Certifications & Capabilities */}
              <div className="space-y-2">
                <div className="flex flex-wrap gap-1">
                  {s.certifications.map(c => (
                    <span key={c} className="text-[10px] bg-[#050505] text-zinc-300 px-1.5 py-0.5 rounded border border-zinc-800">
                      {c}
                    </span>
                  ))}
                </div>

                <p className="text-[11px] text-zinc-400 italic line-clamp-1">
                  Capabilities: {s.capabilities.join(', ')}
                </p>
              </div>

              {/* Action Buttons */}
              <div className="mt-4 pt-3 border-t border-zinc-800 flex items-center justify-between text-xs">
                <span className="text-zinc-400 font-mono text-[11px]">MOQ: {s.moq.toLocaleString()}</span>
                <button
                  onClick={() => setSelectedSupplierForModal(s)}
                  className="text-amber-400 hover:text-amber-300 font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                >
                  <span>Scorecard Breakdown</span>
                  <ChevronRight className="w-3.5 h-3.5 text-amber-400" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Supplier Scorecard Modal */}
      {selectedSupplierForModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 text-white max-w-2xl w-full max-h-[90vh] overflow-y-auto space-y-5">
            <div className="flex items-start justify-between border-b border-slate-800 pb-3">
              <div>
                <span className="bg-emerald-500/20 text-emerald-400 text-xs px-2 py-0.5 rounded font-mono uppercase font-bold">
                  {selectedSupplierForModal.supplierType}
                </span>
                <h3 className="text-lg font-bold text-white mt-1">{selectedSupplierForModal.companyName}</h3>
                <p className="text-xs text-slate-400">{selectedSupplierForModal.factoryLocation}, {selectedSupplierForModal.country}</p>
              </div>
              <button 
                onClick={() => setSelectedSupplierForModal(null)}
                className="text-slate-400 hover:text-white text-sm font-mono font-bold"
              >
                ✕ CLOSE
              </button>
            </div>

            {/* Score Breakdown Radar Metrics */}
            {(() => {
              const sc = scoreSupplier(selectedSupplierForModal, product, DEFAULT_SCORE_WEIGHTS, allLandedCosts);
              const landed = calculateLandedCost(selectedSupplierForModal, product);

              return (
                <div className="space-y-4">
                  <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 text-xs text-slate-300">
                    <div className="font-semibold text-emerald-400 mb-1">CPO Explainable Audit Summary:</div>
                    <p>{sc.explainableSummary}</p>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                    <div className="bg-slate-800 p-3 rounded">
                      <span className="text-slate-400 block">Price Score (25%)</span>
                      <span className="text-base font-bold font-mono text-emerald-400">{sc.priceScore}/100</span>
                    </div>
                    <div className="bg-slate-800 p-3 rounded">
                      <span className="text-slate-400 block">Quality Score (20%)</span>
                      <span className="text-base font-bold font-mono text-emerald-400">{sc.qualityScore}/100</span>
                    </div>
                    <div className="bg-slate-800 p-3 rounded">
                      <span className="text-slate-400 block">Delivery Score (15%)</span>
                      <span className="text-base font-bold font-mono text-emerald-400">{sc.deliveryScore}/100</span>
                    </div>
                    <div className="bg-slate-800 p-3 rounded">
                      <span className="text-slate-400 block">Geopolitical Risk (5%)</span>
                      <span className="text-base font-bold font-mono text-purple-400">{sc.geopoliticalScore}/100</span>
                    </div>
                  </div>

                  <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-2 text-xs">
                    <div className="font-bold text-white mb-2">Total Landed Unit Cost Component Breakdown:</div>
                    <div className="flex justify-between text-slate-300">
                      <span>Quoted Price ({selectedSupplierForModal.quotedCurrency}):</span>
                      <span className="font-mono">{selectedSupplierForModal.quotedPrice} ({selectedSupplierForModal.incoterm})</span>
                    </div>
                    <div className="flex justify-between text-slate-300">
                      <span>Base Landed Cost in GBP:</span>
                      <span className="font-mono font-bold">£{landed.totalBaseLandedCostGBP.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-slate-300">
                      <span>Expected Cost of Quality Defect Failure:</span>
                      <span className="font-mono text-amber-400">+£{landed.expectedQualityLossGBP.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-slate-300">
                      <span>Expected Delay & Disruption Premium:</span>
                      <span className="font-mono text-purple-400">+£{landed.expectedDelayCostGBP.toFixed(2)}</span>
                    </div>
                    <div className="pt-2 border-t border-slate-800 flex justify-between font-bold text-sm text-emerald-400">
                      <span>Risk-Adjusted Procurement Unit Cost:</span>
                      <span className="font-mono">£{landed.riskAdjustedCostGBP.toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              );
            })()}
          </div>
        </div>
      )}
    </div>
  );
};
