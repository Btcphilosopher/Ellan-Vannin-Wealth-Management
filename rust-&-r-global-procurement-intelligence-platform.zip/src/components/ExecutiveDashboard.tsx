import React from 'react';
import { 
  TrendingDown, 
  ShieldCheck, 
  AlertTriangle, 
  ArrowUpRight, 
  DollarSign, 
  Globe, 
  Truck, 
  Zap, 
  Award, 
  Clock, 
  CheckCircle2 
} from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, PieChart, Pie, Cell } from 'recharts';
import { ProductSpecification, Supplier } from '../types/procurement';

interface DashboardProps {
  onSelectProduct: (product: ProductSpecification) => void;
  products: ProductSpecification[];
  suppliers: Supplier[];
  onNavigateTab: (tab: string) => void;
}

export const ExecutiveDashboard: React.FC<DashboardProps> = ({
  onSelectProduct,
  products,
  suppliers,
  onNavigateTab,
}) => {
  const countryDistribution = [
    { name: 'China', spend: 8.4, color: '#f97316' },
    { name: 'Poland', spend: 4.2, color: '#10b981' },
    { name: 'Germany', spend: 5.1, color: '#3b82f6' },
    { name: 'Turkey', spend: 2.8, color: '#8b5cf6' },
    { name: 'UK', spend: 2.5, color: '#06b6d4' },
    { name: 'Vietnam', spend: 1.8, color: '#ec4899' },
  ];

  const savingsByCategory = [
    { category: 'Fasteners & Hardware', current: 0.96, benchmark: 0.86, potentialSavings: 120000 },
    { category: 'Industrial Automation', current: 162.00, benchmark: 148.00, potentialSavings: 84000 },
    { category: 'Flow Control', current: 68.50, benchmark: 62.00, potentialSavings: 78000 },
    { category: 'Energy Storage', current: 78.00, benchmark: 72.00, potentialSavings: 144000 },
  ];

  return (
    <div className="space-y-6">
      {/* Top Header Banner */}
      <div className="bg-gradient-to-r from-[#0c0c0f] via-[#12121a] to-[#0c0c0f] border border-amber-500/20 rounded-xl p-6 text-zinc-100 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl pointer-events-none"></div>
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2.5 mb-2">
              <span className="bg-amber-500/10 text-amber-300 text-xs px-2.5 py-1 rounded-full border border-amber-500/30 font-semibold uppercase tracking-wider">
                Algorithmic Procurement Active
              </span>
              <span className="text-zinc-400 text-xs font-mono">Live Market Feeds: Updated 2 mins ago</span>
            </div>
            <h2 className="text-2xl font-bold tracking-tight text-zinc-100 font-serif-title">Global Procurement Executive Dashboard</h2>
            <p className="text-zinc-400 text-sm mt-1 max-w-3xl">
              Real-time cross-border price arbitrage, total landed cost calculations, and 10,000-simulation Monte Carlo risk optimization.
            </p>
          </div>
          <div className="flex items-center gap-3">
            <button 
              onClick={() => onNavigateTab('product-spec')}
              className="bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-bold px-4 py-2.5 rounded-lg shadow-lg shadow-amber-500/10 transition-all flex items-center gap-2 cursor-pointer"
            >
              <Zap className="w-4 h-4 text-zinc-950" />
              <span>New NLP Procurement Request</span>
            </button>
          </div>
        </div>
      </div>

      {/* Metric Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-5 text-zinc-100 shadow-sm hover:border-zinc-700 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-zinc-400 text-xs font-medium uppercase tracking-wider">Annual Procurement Spend</span>
            <div className="bg-amber-500/10 p-2 rounded-lg text-amber-400 border border-amber-500/20">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono text-zinc-100">£24,850,000</div>
            <div className="flex items-center gap-1 text-xs text-zinc-400 mt-1">
              <span className="text-emerald-400 font-medium flex items-center">
                <ArrowUpRight className="w-3.5 h-3.5" /> +4.2%
              </span>
              <span>vs prior fiscal year</span>
            </div>
          </div>
        </div>

        <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-5 text-zinc-100 shadow-sm hover:border-amber-500/30 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-zinc-400 text-xs font-medium uppercase tracking-wider">Identified Savings Potential</span>
            <div className="bg-emerald-500/10 p-2 rounded-lg text-emerald-400 border border-emerald-500/20">
              <TrendingDown className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono text-amber-400">£2,410,000 <span className="text-sm font-normal text-amber-300/80">(9.7%)</span></div>
            <div className="text-xs text-zinc-400 mt-1">
              Via arbitrage & quality loss reduction
            </div>
          </div>
        </div>

        <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-5 text-zinc-100 shadow-sm hover:border-zinc-700 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-zinc-400 text-xs font-medium uppercase tracking-wider">Dual Sourcing Coverage</span>
            <div className="bg-purple-500/10 p-2 rounded-lg text-purple-400 border border-purple-500/20">
              <ShieldCheck className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono text-zinc-100">68.4%</div>
            <div className="text-xs text-zinc-400 mt-1">
              Target &gt; 75% for critical categories
            </div>
          </div>
        </div>

        <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-5 text-zinc-100 shadow-sm hover:border-zinc-700 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-zinc-400 text-xs font-medium uppercase tracking-wider">On-Time & Quality Rate</span>
            <div className="bg-amber-500/10 p-2 rounded-lg text-amber-400 border border-amber-500/20">
              <Award className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono text-zinc-100">94.2% <span className="text-xs text-zinc-400 font-normal">Delivery</span></div>
            <div className="text-xs text-zinc-400 mt-1">
              Average defect rate: <span className="text-emerald-400 font-semibold">1.18%</span>
            </div>
          </div>
        </div>
      </div>

      {/* Active Procurement Requests Section */}
      <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-6 text-zinc-100 shadow-md">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-bold text-zinc-100 font-serif-title flex items-center gap-2">
              <Globe className="w-5 h-5 text-amber-400" />
              Active Global Procurement Requests
            </h3>
            <p className="text-xs text-zinc-400">Select a product to trigger real-time cross-border price optimization & supplier matching</p>
          </div>
          <span className="text-xs text-amber-400/90 bg-amber-500/10 border border-amber-500/20 px-2.5 py-1 rounded font-mono">{products.length} Products Configured</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {products.map((p) => (
            <div 
              key={p.id}
              onClick={() => {
                onSelectProduct(p);
                onNavigateTab('landed-cost');
              }}
              className="bg-[#0f0f15] hover:bg-[#14141e] border border-zinc-800 hover:border-amber-500/40 rounded-lg p-4 cursor-pointer transition-all group shadow-sm"
            >
              <div className="flex items-start justify-between">
                <span className="bg-zinc-800/80 text-amber-300 text-[10px] font-mono px-2 py-0.5 rounded font-semibold border border-amber-500/20">
                  {p.sku}
                </span>
                <span className="text-xs text-zinc-400 font-mono">Req: {p.requiredQuantity.toLocaleString()}</span>
              </div>

              <h4 className="text-sm font-semibold text-zinc-100 mt-2 group-hover:text-amber-300 transition-colors line-clamp-1">
                {p.name}
              </h4>
              <p className="text-xs text-zinc-400 mt-1 line-clamp-2">
                {p.technicalSpec}
              </p>

              <div className="mt-4 pt-3 border-t border-zinc-800/80 flex items-center justify-between text-xs">
                <div>
                  <span className="text-zinc-400">Target Unit:</span>
                  <span className="text-amber-400 font-mono font-semibold ml-1">£{p.targetPriceGBP.toFixed(2)}</span>
                </div>
                <div className="text-amber-400 font-medium group-hover:translate-x-0.5 transition-transform flex items-center gap-1">
                  <span>Analyze</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Middle Grid: Charts & Risk Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Country Spend Distribution */}
        <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-5 text-zinc-100 flex flex-col justify-between shadow-md">
          <div>
            <h3 className="text-sm font-bold text-zinc-100 font-serif-title flex items-center gap-2 mb-1">
              <Globe className="w-4 h-4 text-amber-400" />
              Global Sourcing Volume by Country (£M)
            </h3>
            <p className="text-xs text-zinc-400 mb-4">Direct manufacturing origin exposure</p>
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={countryDistribution}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    paddingAngle={4}
                    dataKey="spend"
                  >
                    {countryDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#0c0c0f', borderColor: '#27272a', color: '#f4f4f5', fontSize: '12px', borderRadius: '8px' }}
                    formatter={(val: any) => [`£${val}M`, 'Spend']}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-2 pt-2 border-t border-zinc-800 text-xs">
            {countryDistribution.map((item) => (
              <div key={item.name} className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }}></span>
                <span className="text-zinc-300 font-mono">{item.name}: £{item.spend}M</span>
              </div>
            ))}
          </div>
        </div>

        {/* Global Price Benchmark vs Current Cost */}
        <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-5 text-zinc-100 lg:col-span-2 shadow-md">
          <div className="flex items-center justify-between mb-2">
            <div>
              <h3 className="text-sm font-bold text-zinc-100 font-serif-title flex items-center gap-2">
                <TrendingDown className="w-4 h-4 text-amber-400" />
                Category Price vs Global Benchmark Index
              </h3>
              <p className="text-xs text-zinc-400">Comparing current company purchase price against global market median</p>
            </div>
            <button 
              onClick={() => onNavigateTab('arbitrage-map')}
              className="text-xs text-amber-400 hover:text-amber-300 flex items-center gap-1 font-medium transition-colors cursor-pointer"
            >
              <span>View Global Arbitrage</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="h-60 mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={savingsByCategory} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <XAxis dataKey="category" stroke="#71717a" fontSize={11} />
                <YAxis stroke="#71717a" fontSize={11} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0c0c0f', borderColor: '#27272a', color: '#f4f4f5', fontSize: '12px', borderRadius: '8px' }}
                  formatter={(val: any) => [`£${val}`, 'Price']}
                />
                <Bar dataKey="current" name="Company Paid Price" fill="#f59e0b" radius={[4, 4, 0, 0]} />
                <Bar dataKey="benchmark" name="Global Market Median" fill="#10b981" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-3 flex items-center justify-end gap-6 text-xs text-zinc-400">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 bg-amber-500 rounded"></span>
              <span>Company Paid Unit Price</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 bg-emerald-500 rounded"></span>
              <span>Global Market Benchmark</span>
            </div>
          </div>
        </div>
      </div>

      {/* Real-time Risk Alerts & Renewal Tracker */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-5 text-zinc-100 shadow-md">
          <h3 className="text-sm font-bold text-amber-400 font-serif-title flex items-center gap-2 mb-3">
            <AlertTriangle className="w-4 h-4 text-amber-400" />
            Real-Time Supply Chain & Geopolitical Risk Alerts
          </h3>
          <div className="space-y-3 text-xs">
            <div className="bg-amber-500/10 border border-amber-500/25 rounded-lg p-3 text-amber-200">
              <div className="flex items-center justify-between font-semibold">
                <span>Ocean Freight Rate Spike (Asia - Europe)</span>
                <span className="text-[10px] bg-amber-500/30 px-2 py-0.5 rounded font-mono text-amber-300">HIGH IMPACT</span>
              </div>
              <p className="mt-1 text-zinc-300">
                Suez Canal rerouting pushing Ningbo/Shanghai container spot rates up 8.4%. Landed cost impact +£0.02/unit for China shipments.
              </p>
            </div>

            <div className="bg-purple-500/10 border border-purple-500/25 rounded-lg p-3 text-purple-200">
              <div className="flex items-center justify-between font-semibold">
                <span>Turkish Lira Currency Volatility</span>
                <span className="text-[10px] bg-purple-500/30 px-2 py-0.5 rounded font-mono text-purple-300">OPPORTUNITY</span>
              </div>
              <p className="mt-1 text-zinc-300">
                USD/TRY expanded 3.2% this week. Unhedged USD contracts with Anatolia Fasteners show temporary 2.1% cost advantage.
              </p>
            </div>
          </div>
        </div>

        <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-5 text-zinc-100 shadow-md">
          <h3 className="text-sm font-bold text-zinc-100 font-serif-title flex items-center gap-2 mb-3">
            <Clock className="w-4 h-4 text-amber-400" />
            Upcoming Contract Renewals & Dual-Sourcing Tasks
          </h3>
          <div className="space-y-2 text-xs">
            <div className="bg-[#0f0f15] border border-zinc-800 rounded-lg p-3 flex items-center justify-between">
              <div>
                <div className="font-semibold text-zinc-100">Ningbo Fasteners (China) - Annual Framework</div>
                <div className="text-zinc-400">M10 Stainless Bolt Supply • Expires in 24 Days</div>
              </div>
              <button 
                onClick={() => onNavigateTab('negotiation')}
                className="bg-amber-500/15 hover:bg-amber-500 hover:text-zinc-950 text-amber-300 border border-amber-500/30 px-3 py-1.5 rounded text-xs font-medium transition-all cursor-pointer"
              >
                Model RFP
              </button>
            </div>

            <div className="bg-[#0f0f15] border border-zinc-800 rounded-lg p-3 flex items-center justify-between">
              <div>
                <div className="font-semibold text-zinc-100">Silesia Bolt & Screw (Poland) - DAP Agreement</div>
                <div className="text-zinc-400">Nearshoring Expansion • Dual-sourcing Review</div>
              </div>
              <button 
                onClick={() => onNavigateTab('optimization')}
                className="bg-amber-500/15 hover:bg-amber-500 hover:text-zinc-950 text-amber-300 border border-amber-500/30 px-3 py-1.5 rounded text-xs font-medium transition-all cursor-pointer"
              >
                Optimize 60/40
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
