import React, { useState } from 'react';
import { Compass, Globe2, TrendingDown, ShieldAlert, ArrowUpRight, BarChart2 } from 'lucide-react';
import { ARBITRAGE_COUNTRY_METRICS } from '../data/mockDatabase';

export const GlobalArbitrageMap: React.FC = () => {
  const [selectedMetric, setSelectedMetric] = useState<'compositeCostIndex' | 'laborCostIndex' | 'energyCostIndex' | 'tariffRatePct'>('compositeCostIndex');

  const sortedMetrics = [...ARBITRAGE_COUNTRY_METRICS].sort((a, b) => a[selectedMetric] - b[selectedMetric]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-6 text-zinc-100 shadow-md">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2.5 mb-1.5">
              <span className="bg-amber-500/10 text-amber-300 text-xs px-2.5 py-0.5 rounded font-mono font-semibold border border-amber-500/30 uppercase">
                Modules 28 & 35 Active
              </span>
              <span className="text-zinc-400 text-xs">Global Price Arbitrage & Sourcing Intelligence</span>
            </div>
            <h2 className="text-xl font-bold tracking-tight text-zinc-100 font-serif-title">Global Procurement Arbitrage & Map Intelligence</h2>
            <p className="text-xs text-zinc-400">
              Evaluates international cost differentials across Labor, Energy, Raw Materials, Shipping Routes, Trade Tariffs & Currency Volatility.
            </p>
          </div>
        </div>
      </div>

      {/* Metric Sort Selector */}
      <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-4 text-zinc-100 flex items-center justify-between gap-4 text-xs shadow-sm">
        <span className="font-semibold text-zinc-300 font-serif-title">Compare Global Cost Index By:</span>
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setSelectedMetric('compositeCostIndex')}
            className={`px-3 py-1.5 rounded font-semibold transition-all cursor-pointer ${
              selectedMetric === 'compositeCostIndex' ? 'bg-amber-500 text-zinc-950 font-bold' : 'bg-[#050505] text-zinc-400 hover:text-zinc-100 border border-zinc-800'
            }`}
          >
            Composite Cost Index
          </button>
          <button
            onClick={() => setSelectedMetric('laborCostIndex')}
            className={`px-3 py-1.5 rounded font-semibold transition-all cursor-pointer ${
              selectedMetric === 'laborCostIndex' ? 'bg-amber-500 text-zinc-950 font-bold' : 'bg-[#050505] text-zinc-400 hover:text-zinc-100 border border-zinc-800'
            }`}
          >
            Labor Cost
          </button>
          <button
            onClick={() => setSelectedMetric('energyCostIndex')}
            className={`px-3 py-1.5 rounded font-semibold transition-all cursor-pointer ${
              selectedMetric === 'energyCostIndex' ? 'bg-amber-500 text-zinc-950 font-bold' : 'bg-[#050505] text-zinc-400 hover:text-zinc-100 border border-zinc-800'
            }`}
          >
            Energy Cost
          </button>
          <button
            onClick={() => setSelectedMetric('tariffRatePct')}
            className={`px-3 py-1.5 rounded font-semibold transition-all cursor-pointer ${
              selectedMetric === 'tariffRatePct' ? 'bg-amber-500 text-zinc-950 font-bold' : 'bg-[#050505] text-zinc-400 hover:text-zinc-100 border border-zinc-800'
            }`}
          >
            Import Tariffs
          </button>
        </div>
      </div>

      {/* Country Arbitrage Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {sortedMetrics.map((cm, idx) => {
          const isTopArbitrage = idx < 2;
          return (
            <div
              key={cm.country}
              className={`bg-[#0c0c0f] border rounded-xl p-5 text-zinc-100 flex flex-col justify-between space-y-4 shadow-md ${
                isTopArbitrage ? 'border-amber-500/60 bg-[#0c0c0f]' : 'border-zinc-800/80'
              }`}
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="bg-[#050505] text-zinc-300 text-xs font-mono font-bold px-2 py-0.5 rounded border border-zinc-800">
                      {cm.code}
                    </span>
                    <h3 className="text-base font-bold text-zinc-100 font-serif-title">{cm.country}</h3>
                  </div>
                  {isTopArbitrage && (
                    <span className="inline-block mt-1 bg-amber-500/15 text-amber-300 text-[10px] font-bold px-2 py-0.5 rounded font-mono border border-amber-500/30 uppercase">
                      Top Arbitrage Opportunity
                    </span>
                  )}
                </div>

                <div className="text-right">
                  <div className="text-2xl font-bold font-mono text-amber-400">
                    {cm[selectedMetric]}
                  </div>
                  <span className="text-[10px] text-zinc-500 font-mono">Index Score</span>
                </div>
              </div>

              {/* Sub-Metrics Breakdown */}
              <div className="grid grid-cols-2 gap-2 text-xs bg-[#050505] p-3 rounded-lg border border-zinc-800/80">
                <div>
                  <span className="text-zinc-500 block text-[10px]">Labor Index (UK=100)</span>
                  <span className="font-mono font-bold text-zinc-100">{cm.laborCostIndex}</span>
                </div>

                <div>
                  <span className="text-zinc-500 block text-[10px]">Energy Index</span>
                  <span className="font-mono font-bold text-zinc-100">{cm.energyCostIndex}</span>
                </div>

                <div>
                  <span className="text-zinc-500 block text-[10px]">Avg Freight to UK</span>
                  <span className="font-mono font-bold text-blue-400">£{cm.avgFreightToUKGBP.toFixed(2)} / unit</span>
                </div>

                <div>
                  <span className="text-zinc-500 block text-[10px]">Tariff Rate</span>
                  <span className="font-mono font-bold text-amber-400">{cm.tariffRatePct}%</span>
                </div>
              </div>

              {/* Advantage & Risk Highlights */}
              <div className="space-y-1.5 text-xs">
                <div className="text-amber-300/90">
                  <span className="font-bold text-amber-400">Advantage:</span> {cm.keyAdvantage}
                </div>
                <div className="text-zinc-400">
                  <span className="font-bold text-zinc-300">Primary Risk:</span> {cm.primaryRisk}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
