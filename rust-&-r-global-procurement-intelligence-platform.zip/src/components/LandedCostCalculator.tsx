import React, { useState } from 'react';
import { DollarSign, ShieldAlert, Truck, RefreshCw, Layers, HelpCircle, CheckCircle2 } from 'lucide-react';
import { Supplier, ProductSpecification, Incoterm } from '../types/procurement';
import { calculateLandedCost } from '../engine/landedCostEngine';

interface LandedCostCalculatorProps {
  suppliers: Supplier[];
  product: ProductSpecification;
  onNavigateToOptimization: () => void;
}

export const LandedCostCalculator: React.FC<LandedCostCalculatorProps> = ({
  suppliers,
  product,
  onNavigateToOptimization,
}) => {
  const [selectedSupplierId, setSelectedSupplierId] = useState(suppliers[0]?.id || '');
  const [overrideIncoterm, setOverrideIncoterm] = useState<Incoterm | 'ORIGINAL'>('ORIGINAL');

  const selectedSupplier = suppliers.find(s => s.id === selectedSupplierId) || suppliers[0];

  const modifiedSupplier: Supplier = {
    ...selectedSupplier,
    incoterm: overrideIncoterm === 'ORIGINAL' ? selectedSupplier.incoterm : overrideIncoterm,
  };

  const landed = calculateLandedCost(modifiedSupplier, product);

  const incotermOptions: (Incoterm | 'ORIGINAL')[] = ['ORIGINAL', 'EXW', 'FCA', 'FOB', 'CIF', 'CFR', 'DAP', 'DDP'];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-6 text-zinc-100 shadow-md">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2.5 mb-1.5">
              <span className="bg-amber-500/10 text-amber-300 text-xs px-2.5 py-0.5 rounded font-mono font-semibold border border-amber-500/30 uppercase">
                Module 5 & 6 Active
              </span>
              <span className="text-zinc-400 text-xs">Destination: {product.deliveryDestination}</span>
            </div>
            <h2 className="text-xl font-bold tracking-tight text-zinc-100 font-serif-title">Total Landed Cost & Quality-Adjusted Price Engine</h2>
            <p className="text-xs text-zinc-400">
              Converts supplier quotes under any Incoterm into comparable landed unit costs including quality failure risks & delay costs.
            </p>
          </div>

          <button
            onClick={onNavigateToOptimization}
            className="bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-bold px-4 py-2.5 rounded-lg shadow transition-all flex items-center gap-2 cursor-pointer"
          >
            <Layers className="w-4 h-4 text-zinc-950" />
            <span>Proceed to Pareto Optimization</span>
          </button>
        </div>
      </div>

      {/* Supplier Selection & Incoterm Simulator Controls */}
      <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-5 text-zinc-100 grid grid-cols-1 md:grid-cols-2 gap-4 shadow-sm">
        <div>
          <label className="text-xs font-semibold text-zinc-300 block mb-1">Select Global Supplier to Analyze:</label>
          <select
            value={selectedSupplierId}
            onChange={(e) => setSelectedSupplierId(e.target.value)}
            className="w-full bg-[#050505] border border-zinc-700/80 rounded-lg p-2.5 text-xs text-zinc-100 font-medium focus:outline-none focus:ring-1 focus:ring-amber-500/50 cursor-pointer"
          >
            {suppliers.map(s => (
              <option key={s.id} value={s.id}>
                {s.companyName} ({s.country}) - {s.quotedPrice} {s.quotedCurrency} [{s.incoterm}]
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="text-xs font-semibold text-zinc-300 block mb-1">Simulate Incoterm Structure:</label>
          <div className="flex items-center gap-1.5 flex-wrap">
            {incotermOptions.map(ico => (
              <button
                key={ico}
                onClick={() => setOverrideIncoterm(ico)}
                className={`text-xs px-2.5 py-1.5 rounded font-mono font-bold transition-all cursor-pointer ${
                  overrideIncoterm === ico
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow'
                    : 'bg-[#050505] text-zinc-400 hover:text-zinc-100 border border-zinc-800'
                }`}
              >
                {ico}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Landed Cost Breakdown Waterfall & Detail Table */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Summary Cards */}
        <div className="space-y-4">
          <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-5 text-zinc-100 shadow-sm">
            <span className="text-xs text-zinc-400 uppercase tracking-wider block font-semibold mb-1">Quoted Unit Price (FX Converted)</span>
            <div className="text-2xl font-bold font-mono text-zinc-100">
              £{landed.purchasePriceGBP.toFixed(2)}
              <span className="text-xs text-zinc-400 font-normal ml-2">
                ({selectedSupplier.quotedPrice} {selectedSupplier.quotedCurrency})
              </span>
            </div>
            <div className="text-xs text-zinc-400 mt-2">Incoterm: <span className="text-amber-400 font-bold">{modifiedSupplier.incoterm}</span></div>
          </div>

          <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-5 text-zinc-100 shadow-sm">
            <span className="text-xs text-zinc-400 uppercase tracking-wider block font-semibold mb-1">Base Total Landed Cost</span>
            <div className="text-2xl font-bold font-mono text-blue-400">
              £{landed.totalBaseLandedCostGBP.toFixed(2)}
            </div>
            <div className="text-xs text-zinc-400 mt-2">
              Logistics, Duty, Taxes & Financing: <span className="text-blue-300 font-semibold">+£{(landed.totalBaseLandedCostGBP - landed.purchasePriceGBP).toFixed(2)}</span>
            </div>
          </div>

          <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-5 text-zinc-100 border-l-4 border-l-amber-500 shadow-md">
            <span className="text-xs text-zinc-400 uppercase tracking-wider block font-semibold mb-1">Risk-Adjusted Procurement Cost</span>
            <div className="text-3xl font-bold font-mono text-amber-400">
              £{landed.riskAdjustedCostGBP.toFixed(2)}
            </div>
            <div className="text-xs text-zinc-400 mt-2">
              Includes <span className="text-amber-400 font-semibold">£{landed.expectedQualityLossGBP.toFixed(2)}</span> defect risk + <span className="text-purple-400 font-semibold">£{landed.expectedDelayCostGBP.toFixed(2)}</span> delay risk.
            </div>
          </div>
        </div>

        {/* Right: Step-by-Step Itemized Cost Table */}
        <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-6 text-zinc-100 lg:col-span-2 shadow-md">
          <h3 className="text-base font-bold text-zinc-100 font-serif-title mb-4 border-b border-zinc-800 pb-2 flex items-center justify-between">
            <span>Itemized Landed Cost Calculation (per unit)</span>
            <span className="text-xs text-zinc-400 font-mono font-normal">GBP (£) Currency Basis</span>
          </h3>

          <div className="space-y-2 text-xs">
            <div className="flex justify-between py-1.5 border-b border-zinc-800/60">
              <span className="text-zinc-300 font-medium">1. Base Purchase Price ({selectedSupplier.quotedCurrency} converted to GBP):</span>
              <span className="font-mono font-bold text-zinc-100">£{landed.purchasePriceGBP.toFixed(3)}</span>
            </div>

            <div className="flex justify-between py-1.5 border-b border-zinc-800/60">
              <span className="text-zinc-400">2. Packaging & Export Crating:</span>
              <span className="font-mono text-zinc-300">+£{landed.packagingGBP.toFixed(3)}</span>
            </div>

            <div className="flex justify-between py-1.5 border-b border-zinc-800/60">
              <span className="text-zinc-400">3. Domestic Origin Trucking & Port Handling:</span>
              <span className="font-mono text-zinc-300">+£{landed.domesticTransportGBP.toFixed(3)}</span>
            </div>

            <div className="flex justify-between py-1.5 border-b border-zinc-800/60">
              <span className="text-zinc-400">4. Ocean / Air Freight Rate:</span>
              <span className="font-mono text-zinc-300">+£{landed.freightCostGBP.toFixed(3)}</span>
            </div>

            <div className="flex justify-between py-1.5 border-b border-zinc-800/60">
              <span className="text-zinc-400">5. Cargo Marine Insurance:</span>
              <span className="font-mono text-zinc-300">+£{landed.insuranceCostGBP.toFixed(3)}</span>
            </div>

            <div className="flex justify-between py-1.5 border-b border-zinc-800/60">
              <span className="text-zinc-400">6. Import Duty / Tariff Burden:</span>
              <span className="font-mono text-amber-400">+£{landed.importDutyGBP.toFixed(3)}</span>
            </div>

            <div className="flex justify-between py-1.5 border-b border-zinc-800/60">
              <span className="text-zinc-400">7. Customs Clearance & Port Terminal Fees:</span>
              <span className="font-mono text-zinc-300">+£{(landed.customsBrokerageGBP + landed.portChargesGBP).toFixed(3)}</span>
            </div>

            <div className="flex justify-between py-1.5 border-b border-zinc-800/60">
              <span className="text-zinc-400">8. Destination Warehousing & Inland Trucking:</span>
              <span className="font-mono text-zinc-300">+£{(landed.warehousingGBP + landed.inlandTransportGBP).toFixed(3)}</span>
            </div>

            <div className="flex justify-between py-1.5 border-b border-zinc-800/60">
              <span className="text-zinc-400">9. WACC Working Capital Lead Time Financing Cost:</span>
              <span className="font-mono text-zinc-300">+£{landed.financingCostGBP.toFixed(3)}</span>
            </div>

            <div className="flex justify-between py-2 bg-[#050505] font-bold px-3 rounded text-blue-400 my-2 border border-zinc-800">
              <span>BASE TOTAL LANDED UNIT COST:</span>
              <span className="font-mono text-sm">£{landed.totalBaseLandedCostGBP.toFixed(3)}</span>
            </div>

            {/* Quality & Risk Adjustments */}
            <div className="flex justify-between py-1.5 border-b border-zinc-800/60">
              <span className="text-amber-300 font-medium">10. Quality Failure Cost (Defect Rate {selectedSupplier.historicalDefectRatePct}% x Rework Multiplier):</span>
              <span className="font-mono text-amber-400">+£{landed.expectedQualityLossGBP.toFixed(3)}</span>
            </div>

            <div className="flex justify-between py-1.5 border-b border-zinc-800/60">
              <span className="text-purple-300 font-medium">11. Expected Delivery Delay & Geopolitical Disruption Premium:</span>
              <span className="font-mono text-purple-400">+£{(landed.expectedDelayCostGBP + landed.expectedDisruptionCostGBP).toFixed(3)}</span>
            </div>

            <div className="flex justify-between py-2 bg-amber-500/10 border border-amber-500/30 font-bold px-3 rounded text-amber-300 my-2 text-sm">
              <span>FINAL RISK-ADJUSTED PROCUREMENT UNIT COST:</span>
              <span className="font-mono text-base text-amber-400">£{landed.riskAdjustedCostGBP.toFixed(3)}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
