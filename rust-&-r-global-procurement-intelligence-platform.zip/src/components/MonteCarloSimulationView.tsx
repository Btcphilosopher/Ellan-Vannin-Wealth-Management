import React, { useState } from 'react';
import { ShieldAlert, Play, RefreshCw, AlertTriangle, TrendingUp, BarChart3, CheckCircle } from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip } from 'recharts';
import { Supplier, ProductSpecification, MonteCarloSimulationResult } from '../types/procurement';
import { runMonteCarloSimulation } from '../engine/monteCarloEngine';

interface MonteCarloSimulationViewProps {
  suppliers: Supplier[];
  product: ProductSpecification;
  onNavigateToRFQ: () => void;
}

export const MonteCarloSimulationView: React.FC<MonteCarloSimulationViewProps> = ({
  suppliers,
  product,
  onNavigateToRFQ,
}) => {
  const [selectedSupplierId, setSelectedSupplierId] = useState(suppliers[0]?.id || '');
  const [simCount, setSimCount] = useState(10000);
  const [isSimulating, setIsSimulating] = useState(false);
  const [stressTestMode, setStressTestMode] = useState<string | null>(null);

  const selectedSupplier = suppliers.find(s => s.id === selectedSupplierId) || suppliers[0];

  const [monteCarloResult, setMonteCarloResult] = useState<MonteCarloSimulationResult>(() => 
    runMonteCarloSimulation(selectedSupplier, product, simCount)
  );

  const handleRunSimulation = (supplier: Supplier, stress?: string) => {
    setIsSimulating(true);
    setTimeout(() => {
      let result = runMonteCarloSimulation(supplier, product, simCount);
      if (stress === 'PORT_CLOSURE') {
        result = {
          ...result,
          meanLandedCostGBP: Number((result.meanLandedCostGBP * 1.18).toFixed(2)),
          p90GBP: Number((result.p90GBP * 1.25).toFixed(2)),
          worstCaseScenarioGBP: Number((result.worstCaseScenarioGBP * 1.35).toFixed(2)),
        };
      } else if (stress === 'CURRENCY_CRISIS') {
        result = {
          ...result,
          meanLandedCostGBP: Number((result.meanLandedCostGBP * 1.12).toFixed(2)),
          p90GBP: Number((result.p90GBP * 1.19).toFixed(2)),
        };
      }
      setMonteCarloResult(result);
      setIsSimulating(false);
    }, 400);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-6 text-zinc-100 shadow-md">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2.5 mb-1.5">
              <span className="bg-amber-500/10 text-amber-300 text-xs px-2.5 py-0.5 rounded font-mono font-semibold border border-amber-500/30 uppercase">
                Modules 10 & 30 Active
              </span>
              <span className="text-zinc-400 text-xs">Stochastic Risk & Resilience Engine</span>
            </div>
            <h2 className="text-xl font-bold tracking-tight text-zinc-100 font-serif-title">Monte Carlo Risk Engine (10,000 Simulations)</h2>
            <p className="text-xs text-zinc-400">
              Randomizes FX volatility, freight surges, tariff changes, defect rates, and delivery delays to generate P10, P50, and P90 landed costs.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => handleRunSimulation(selectedSupplier)}
              disabled={isSimulating}
              className="bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-bold px-4 py-2.5 rounded-lg shadow transition-all flex items-center gap-2 disabled:opacity-50 cursor-pointer"
            >
              {isSimulating ? <RefreshCw className="w-4 h-4 animate-spin text-zinc-950" /> : <Play className="w-4 h-4 text-zinc-950" />}
              <span>{isSimulating ? "Running 10k Iterations..." : "Re-run 10,000 Simulations"}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Supplier & Stress Test Controls */}
      <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-5 text-zinc-100 flex flex-col md:flex-row items-center justify-between gap-4 shadow-sm">
        <div className="w-full md:w-80">
          <label className="text-xs text-zinc-400 font-medium block mb-1">Select Target Supplier for Monte Carlo Analysis:</label>
          <select
            value={selectedSupplierId}
            onChange={(e) => {
              setSelectedSupplierId(e.target.value);
              const sup = suppliers.find(s => s.id === e.target.value);
              if (sup) handleRunSimulation(sup);
            }}
            className="w-full bg-[#050505] border border-zinc-700/80 text-xs text-zinc-100 rounded-lg p-2 focus:outline-none cursor-pointer"
          >
            {suppliers.map(s => (
              <option key={s.id} value={s.id}>{s.companyName} ({s.country})</option>
            ))}
          </select>
        </div>

        {/* Stress Testing Trigger Buttons */}
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-xs text-zinc-400 font-semibold mr-1">Inject Stress Scenario:</span>
          <button
            onClick={() => {
              setStressTestMode('PORT_CLOSURE');
              handleRunSimulation(selectedSupplier, 'PORT_CLOSURE');
            }}
            className={`text-xs px-3 py-1.5 rounded font-medium border transition-all cursor-pointer ${
              stressTestMode === 'PORT_CLOSURE' 
                ? 'bg-amber-500/20 border-amber-500 text-amber-300 font-bold' 
                : 'bg-[#050505] border-zinc-800 text-zinc-300 hover:text-zinc-100'
            }`}
          >
            Red Sea Port Closure (+18%)
          </button>

          <button
            onClick={() => {
              setStressTestMode('CURRENCY_CRISIS');
              handleRunSimulation(selectedSupplier, 'CURRENCY_CRISIS');
            }}
            className={`text-xs px-3 py-1.5 rounded font-medium border transition-all cursor-pointer ${
              stressTestMode === 'CURRENCY_CRISIS' 
                ? 'bg-purple-500/20 border-purple-500 text-purple-300 font-bold' 
                : 'bg-[#050505] border-zinc-800 text-zinc-300 hover:text-zinc-100'
            }`}
          >
            FX Currency Crisis (+12%)
          </button>

          <button
            onClick={() => {
              setStressTestMode(null);
              handleRunSimulation(selectedSupplier);
            }}
            className="text-xs bg-[#050505] text-zinc-400 border border-zinc-800 hover:text-zinc-100 px-3 py-1.5 rounded cursor-pointer"
          >
            Reset Baseline
          </button>
        </div>
      </div>

      {/* Percentiles Display Metric Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-4 text-zinc-100 shadow-sm">
          <span className="text-zinc-400 text-[11px] font-semibold block uppercase">Simulated Mean Cost</span>
          <div className="text-2xl font-bold font-mono text-zinc-100 mt-1">£{monteCarloResult.meanLandedCostGBP.toFixed(2)}</div>
          <span className="text-[10px] text-zinc-500 mt-1 block">Expected Landed Average</span>
        </div>

        <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-4 text-zinc-100 border-l-4 border-l-amber-500 shadow-sm">
          <span className="text-zinc-400 text-[11px] font-semibold block uppercase">P10 Best Case (Optimistic)</span>
          <div className="text-2xl font-bold font-mono text-amber-400 mt-1">£{monteCarloResult.p10GBP.toFixed(2)}</div>
          <span className="text-[10px] text-zinc-500 mt-1 block">10% chance landed cost is lower</span>
        </div>

        <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-4 text-zinc-100 border-l-4 border-l-blue-500 shadow-sm">
          <span className="text-zinc-400 text-[11px] font-semibold block uppercase">P50 Median Expectation</span>
          <div className="text-2xl font-bold font-mono text-blue-400 mt-1">£{monteCarloResult.p50GBP.toFixed(2)}</div>
          <span className="text-[10px] text-zinc-500 mt-1 block">50th percentile confidence</span>
        </div>

        <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-4 text-zinc-100 border-l-4 border-l-orange-500 shadow-sm">
          <span className="text-zinc-400 text-[11px] font-semibold block uppercase">P90 Worst Case (Pessimistic)</span>
          <div className="text-2xl font-bold font-mono text-orange-400 mt-1">£{monteCarloResult.p90GBP.toFixed(2)}</div>
          <span className="text-[10px] text-zinc-500 mt-1 block">90% chance landed cost is lower</span>
        </div>

        <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-4 text-zinc-100 border-l-4 border-l-red-500 shadow-sm">
          <span className="text-zinc-400 text-[11px] font-semibold block uppercase">Tail Risk Worst Scenario</span>
          <div className="text-2xl font-bold font-mono text-red-400 mt-1">£{monteCarloResult.worstCaseScenarioGBP.toFixed(2)}</div>
          <span className="text-[10px] text-zinc-500 mt-1 block">1-in-10,000 catastrophic surge</span>
        </div>
      </div>

      {/* Cost Distribution Histogram & Risk Variance Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-6 text-zinc-100 lg:col-span-2 shadow-md">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-bold text-zinc-100 font-serif-title flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-amber-400" />
              10,000-Simulation Landed Cost Distribution Histogram
            </h3>
            <span className="text-xs font-mono text-amber-400 bg-amber-500/10 px-2.5 py-1 rounded border border-amber-500/30">
              Std Dev: ±£{monteCarloResult.stdDevGBP.toFixed(2)}
            </span>
          </div>

          <div className="h-64 mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monteCarloResult.costDistribution} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
                <XAxis dataKey="binRange" stroke="#71717a" fontSize={10} interval={1} angle={-15} textAnchor="end" />
                <YAxis stroke="#71717a" fontSize={10} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0c0c0f', borderColor: '#27272a', color: '#f4f4f5', fontSize: '11px' }}
                  formatter={(val: any) => [val, 'Occurrences (out of 10,000)']}
                />
                <Bar dataKey="frequency" fill="#d4af37" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Risk Factor Variance Breakdown */}
        <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-6 text-zinc-100 space-y-4 shadow-md">
          <h3 className="text-sm font-bold text-zinc-100 font-serif-title flex items-center gap-2 border-b border-zinc-800 pb-2">
            <ShieldAlert className="w-4 h-4 text-amber-400" />
            Risk Factor Variance Contribution
          </h3>

          <div className="space-y-3 text-xs">
            {monteCarloResult.riskFactorImpacts.map((rf) => (
              <div key={rf.factor}>
                <div className="flex justify-between text-zinc-300 mb-1">
                  <span>{rf.factor}</span>
                  <span className="font-mono font-bold text-amber-400">{rf.varianceContributionPct}%</span>
                </div>
                <div className="h-2 bg-[#050505] rounded-full overflow-hidden border border-zinc-800">
                  <div 
                    className="h-full bg-amber-500 rounded-full" 
                    style={{ width: `${rf.varianceContributionPct}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>

          <div className="pt-3 border-t border-zinc-800">
            <button
              onClick={onNavigateToRFQ}
              className="w-full bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-bold py-2.5 rounded-lg transition-all cursor-pointer"
            >
              Proceed to RFQ Quotation Normalizer
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
