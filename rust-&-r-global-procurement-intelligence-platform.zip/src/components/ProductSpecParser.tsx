import React, { useState } from 'react';
import { Sparkles, FileText, CheckCircle, ArrowRight, RefreshCw, AlertCircle } from 'lucide-react';
import { ProductSpecification } from '../types/procurement';

interface ProductSpecParserProps {
  currentSpec: ProductSpecification;
  onUpdateSpec: (spec: ProductSpecification) => void;
  onNavigateToNext: () => void;
}

export const ProductSpecParser: React.FC<ProductSpecParserProps> = ({
  currentSpec,
  onUpdateSpec,
  onNavigateToNext,
}) => {
  const [naturalPrompt, setNaturalPrompt] = useState(
    "We need 10,000 stainless steel bolts, M10, marine-grade, delivered to Manchester by October 15, target price £0.85"
  );
  const [isLoading, setIsLoading] = useState(false);
  const [parseStatus, setParseStatus] = useState<string | null>(null);

  const handleParseNLP = async () => {
    setIsLoading(true);
    setParseStatus("Calling server-side Gemini NLP Parser...");

    try {
      const res = await fetch("/api/gemini/parse-spec", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: naturalPrompt }),
      });

      const data = await res.json();
      if (data.parsed) {
        const p = data.parsed;
        const updated: ProductSpecification = {
          ...currentSpec,
          name: p.name || currentSpec.name,
          sku: p.sku || currentSpec.sku,
          category: p.category || currentSpec.category,
          technicalSpec: p.technicalSpec || naturalPrompt,
          dimensions: p.dimensions || currentSpec.dimensions,
          material: p.material || currentSpec.material,
          grade: p.grade || currentSpec.grade,
          requiredQuantity: p.requiredQuantity || currentSpec.requiredQuantity,
          targetPriceGBP: p.targetPriceGBP || currentSpec.targetPriceGBP,
          deliveryDestination: p.deliveryDestination || currentSpec.deliveryDestination,
          requiredDeliveryDate: p.requiredDeliveryDate || currentSpec.requiredDeliveryDate,
        };

        onUpdateSpec(updated);
        setParseStatus("Successfully parsed specification using Gemini AI!");
      }
    } catch (err: any) {
      console.error(err);
      setParseStatus("Notice: Server Gemini parsing used structured fallback.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-6 text-zinc-100 shadow-md">
        <div className="flex items-center gap-3 mb-1">
          <div className="bg-amber-500/10 p-2 rounded-lg text-amber-400 border border-amber-500/30">
            <Sparkles className="w-6 h-6 text-amber-400" />
          </div>
          <div>
            <h2 className="text-xl font-bold tracking-tight text-zinc-100 font-serif-title">Product Requirement Engine</h2>
            <p className="text-xs text-zinc-400">
              Transform unstructured procurement text into a normalized technical specification using Gemini AI.
            </p>
          </div>
        </div>
      </div>

      {/* NLP Prompt Section */}
      <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-6 text-zinc-100 space-y-4 shadow-md">
        <div className="flex items-center justify-between">
          <label className="text-sm font-semibold text-zinc-100 font-serif-title flex items-center gap-2">
            <FileText className="w-4 h-4 text-amber-400" />
            Natural Language Requirement Input
          </label>
          <span className="text-xs text-amber-400/90 font-mono bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 rounded">NLP Parser Active</span>
        </div>

        <div className="relative">
          <textarea
            value={naturalPrompt}
            onChange={(e) => setNaturalPrompt(e.target.value)}
            rows={3}
            placeholder="e.g. We need 500 planetary gearboxes, ratio 10:1, backlash under 3 arcmin delivered to Birmingham..."
            className="w-full bg-[#050505] border border-zinc-700/80 rounded-lg p-3 text-sm text-zinc-100 placeholder-zinc-500 focus:outline-none focus:ring-1 focus:ring-amber-500/50 font-sans"
          />
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={handleParseNLP}
              disabled={isLoading}
              className="bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-bold px-4 py-2.5 rounded-lg shadow-md transition-all flex items-center gap-2 disabled:opacity-50 cursor-pointer"
            >
              {isLoading ? <RefreshCw className="w-4 h-4 animate-spin text-zinc-950" /> : <Sparkles className="w-4 h-4 text-zinc-950" />}
              <span>{isLoading ? "Parsing Spec with Gemini..." : "Parse with Gemini AI"}</span>
            </button>

            <button
              onClick={() => {
                setNaturalPrompt("We need 500 planetary gearboxes, helical design, 120Nm torque, delivered to Birmingham by November 1st");
              }}
              className="text-xs text-zinc-400 hover:text-amber-300 underline px-2 py-1 transition-colors cursor-pointer"
            >
              Load Gearbox Prompt
            </button>
          </div>

          {parseStatus && (
            <span className="text-xs text-amber-300 font-mono flex items-center gap-1.5 bg-amber-500/10 px-3 py-1 rounded border border-amber-500/30">
              <CheckCircle className="w-3.5 h-3.5 text-amber-400" />
              {parseStatus}
            </span>
          )}
        </div>
      </div>

      {/* Structured Specification Editor Form */}
      <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-6 text-zinc-100 shadow-md">
        <h3 className="text-base font-bold text-zinc-100 font-serif-title mb-4 border-b border-zinc-800 pb-2">
          Structured Procurement Specification
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
          <div>
            <label className="text-zinc-400 font-medium block mb-1">Product Name</label>
            <input
              type="text"
              value={currentSpec.name}
              onChange={(e) => onUpdateSpec({ ...currentSpec, name: e.target.value })}
              className="w-full bg-[#050505] border border-zinc-700/80 rounded p-2 text-zinc-100 font-medium focus:outline-none focus:border-amber-500/50"
            />
          </div>

          <div>
            <label className="text-zinc-400 font-medium block mb-1">SKU</label>
            <input
              type="text"
              value={currentSpec.sku}
              onChange={(e) => onUpdateSpec({ ...currentSpec, sku: e.target.value })}
              className="w-full bg-[#050505] border border-zinc-700/80 rounded p-2 text-amber-400 font-mono font-semibold focus:outline-none focus:border-amber-500/50"
            />
          </div>

          <div>
            <label className="text-zinc-400 font-medium block mb-1">Category</label>
            <input
              type="text"
              value={currentSpec.category}
              onChange={(e) => onUpdateSpec({ ...currentSpec, category: e.target.value })}
              className="w-full bg-[#050505] border border-zinc-700/80 rounded p-2 text-zinc-100 focus:outline-none focus:border-amber-500/50"
            />
          </div>

          <div>
            <label className="text-zinc-400 font-medium block mb-1">Material & Grade</label>
            <input
              type="text"
              value={`${currentSpec.material} (${currentSpec.grade})`}
              onChange={(e) => onUpdateSpec({ ...currentSpec, material: e.target.value })}
              className="w-full bg-[#050505] border border-zinc-700/80 rounded p-2 text-zinc-100 focus:outline-none focus:border-amber-500/50"
            />
          </div>

          <div>
            <label className="text-zinc-400 font-medium block mb-1">Dimensions</label>
            <input
              type="text"
              value={currentSpec.dimensions}
              onChange={(e) => onUpdateSpec({ ...currentSpec, dimensions: e.target.value })}
              className="w-full bg-[#050505] border border-zinc-700/80 rounded p-2 text-zinc-100 focus:outline-none focus:border-amber-500/50"
            />
          </div>

          <div>
            <label className="text-zinc-400 font-medium block mb-1">Required Quantity</label>
            <input
              type="number"
              value={currentSpec.requiredQuantity}
              onChange={(e) => onUpdateSpec({ ...currentSpec, requiredQuantity: Number(e.target.value) })}
              className="w-full bg-[#050505] border border-zinc-700/80 rounded p-2 text-amber-400 font-mono font-bold focus:outline-none focus:border-amber-500/50"
            />
          </div>

          <div>
            <label className="text-zinc-400 font-medium block mb-1">Target Unit Price (£ GBP)</label>
            <input
              type="number"
              step="0.01"
              value={currentSpec.targetPriceGBP}
              onChange={(e) => onUpdateSpec({ ...currentSpec, targetPriceGBP: Number(e.target.value) })}
              className="w-full bg-[#050505] border border-zinc-700/80 rounded p-2 text-amber-400 font-mono font-bold focus:outline-none focus:border-amber-500/50"
            />
          </div>

          <div>
            <label className="text-zinc-400 font-medium block mb-1">Delivery Destination</label>
            <input
              type="text"
              value={currentSpec.deliveryDestination}
              onChange={(e) => onUpdateSpec({ ...currentSpec, deliveryDestination: e.target.value })}
              className="w-full bg-[#050505] border border-zinc-700/80 rounded p-2 text-zinc-100 focus:outline-none focus:border-amber-500/50"
            />
          </div>

          <div>
            <label className="text-zinc-400 font-medium block mb-1">Required Delivery Date</label>
            <input
              type="date"
              value={currentSpec.requiredDeliveryDate}
              onChange={(e) => onUpdateSpec({ ...currentSpec, requiredDeliveryDate: e.target.value })}
              className="w-full bg-[#050505] border border-zinc-700/80 rounded p-2 text-zinc-100 font-mono focus:outline-none focus:border-amber-500/50"
            />
          </div>
        </div>

        <div className="mt-4 pt-4 border-t border-zinc-800 flex items-center justify-between">
          <div className="text-xs text-zinc-400">
            Total Target Order Value: <span className="text-amber-400 font-mono font-bold text-sm ml-1">£{(currentSpec.requiredQuantity * currentSpec.targetPriceGBP).toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
          </div>

          <button
            onClick={onNavigateToNext}
            className="bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-bold px-5 py-2.5 rounded-lg shadow transition-all flex items-center gap-2 cursor-pointer"
          >
            <span>Proceed to Global Supplier Discovery</span>
            <ArrowRight className="w-4 h-4 text-zinc-950" />
          </button>
        </div>
      </div>
    </div>
  );
};
