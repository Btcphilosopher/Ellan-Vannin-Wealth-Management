import React, { useState } from 'react';
import { Layers, ShieldCheck, CheckCircle2, ArrowRight, Zap, RefreshCw, BarChart2 } from 'lucide-react';
import { ResponsiveContainer, ScatterChart, Scatter, XAxis, YAxis, Tooltip, Cell } from 'recharts';
import { Supplier, ProductSpecification, OptimizationStrategy } from '../types/procurement';
import { runOptimizationModes, generateParetoFrontier } from '../engine/optimizationEngine';

interface ParetoOptimizationProps {
  suppliers: Supplier[];
  product: ProductSpecification;
  onNavigateToMonteCarlo: () => void;
}

export const ParetoOptimization: React.FC<ParetoOptimizationProps> = ({
  suppliers,
  product,
  onNavigateToMonteCarlo,
}) => {
  const [selectedModeId, setSelectedModeId] = useState('mode-best-value');
  const [primaryShare, setPrimaryShare] = useState(60);

  const strategies = runOptimizationModes(suppliers, product);
  const paretoPoints = generateParetoFrontier(suppliers, product);

  const activeStrategy = strategies.find(s => s.id === selectedModeId) || strategies[0];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-6 text-zinc-100 shadow-md">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2.5 mb-1.5">
              <span className="bg-amber-500/10 text-amber-300 text-xs px-2.5 py-0.5 rounded font-mono font-semibold border border-amber-500/30 uppercase">
                Modules 8 & 9 Active
              </span>
              <span className="text-zinc-400 text-xs">Multi-Objective Pareto & Portfolio Optimizer</span>
            </div>
            <h2 className="text-xl font-bold tracking-tight text-zinc-100 font-serif-title">Multi-Objective & Portfolio Optimization</h2>
            <p className="text-xs text-zinc-400">
              Balances Price, Quality, Delivery Speed & Geopolitical Resilience. Avoids single-source vulnerability via dual-sourcing volume allocation.
            </p>
          </div>

          <button
            onClick={onNavigateToMonteCarlo}
            className="bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-bold px-4 py-2.5 rounded-lg shadow transition-all flex items-center gap-2 cursor-pointer"
          >
            <ShieldCheck className="w-4 h-4 text-zinc-950" />
            <span>Run 10,000-Run Monte Carlo Simulation</span>
          </button>
        </div>
      </div>

      {/* Optimization Mode Selector Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {strategies.map((st) => {
          const isSelected = st.id === selectedModeId;
          return (
            <div
              key={st.id}
              onClick={() => setSelectedModeId(st.id)}
              className={`p-4 rounded-xl border cursor-pointer transition-all ${
                isSelected
                  ? 'bg-[#121218] border-amber-500 shadow-lg text-zinc-100'
                  : 'bg-[#0c0c0f] border-zinc-800 text-zinc-300 hover:border-zinc-700'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded font-mono uppercase ${
                  isSelected ? 'bg-amber-500 text-zinc-950 font-extrabold' : 'bg-[#050505] text-zinc-400'
                }`}>
                  {st.mode}
                </span>
                <span className="text-xs font-mono text-amber-400 font-bold">
                  £{st.weightedAvgLandedCostGBP.toFixed(2)}/u
                </span>
              </div>

              <h4 className="text-sm font-bold text-zinc-100 mb-1 font-serif-title">{st.title}</h4>
              <p className="text-[11px] text-zinc-400 line-clamp-2">{st.description}</p>

              <div className="mt-3 pt-2 border-t border-zinc-800/80 flex items-center justify-between text-[11px] text-zinc-300">
                <span>Est. Savings:</span>
                <span className="font-mono text-amber-400 font-bold">+£{st.estimatedSavingsVsBenchmarkGBP.toLocaleString(undefined, { maximumFractionDigits: 0 })} ({st.savingsPct.toFixed(1)}%)</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Active Strategy Detail & Portfolio Split Controls */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Active Portfolio Strategy Details */}
        <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-6 text-zinc-100 lg:col-span-2 space-y-4 shadow-md">
          <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
            <div>
              <span className="text-xs text-zinc-400">Selected Procurement Strategy</span>
              <h3 className="text-lg font-bold text-zinc-100 font-serif-title">{activeStrategy.title}</h3>
            </div>
            <div className="text-right">
              <span className="text-xs text-zinc-400 block">Total Budget Required</span>
              <span className="text-xl font-bold font-mono text-amber-400">
                £{activeStrategy.totalPurchaseBudgetGBP.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
          </div>

          {/* Allocation Share Bar */}
          <div>
            <div className="flex justify-between text-xs font-medium text-zinc-300 mb-1.5">
              <span>Volume Allocation Breakdown</span>
              <span className="font-mono">{product.requiredQuantity.toLocaleString()} Total Units</span>
            </div>

            <div className="h-4 bg-[#050505] rounded-full overflow-hidden flex border border-zinc-800">
              {activeStrategy.allocations.map((a, idx) => (
                <div
                  key={a.supplierId}
                  style={{ width: `${a.percentage}%` }}
                  className={`${idx === 0 ? 'bg-amber-500' : 'bg-blue-500'} h-full flex items-center justify-center text-[10px] font-bold text-zinc-950 font-mono`}
                  title={`${a.supplierName}: ${a.percentage}%`}
                >
                  {a.percentage}%
                </div>
              ))}
            </div>
          </div>

          {/* Supplier Volume Allocation Table */}
          <div className="space-y-2 text-xs pt-2">
            <h4 className="font-bold text-zinc-300 font-serif-title">Allocated Vendor Split:</h4>
            {activeStrategy.allocations.map((a) => (
              <div key={a.supplierId} className="bg-[#050505] border border-zinc-800 p-3 rounded-lg flex items-center justify-between">
                <div>
                  <div className="font-bold text-zinc-100">{a.supplierName} ({a.country})</div>
                  <div className="text-zinc-400 text-[11px]">
                    Volume: <span className="text-zinc-200 font-mono font-semibold">{a.allocatedUnits.toLocaleString()} units</span> ({a.percentage}%) • Lead Time: {a.leadTimeDays}d
                  </div>
                </div>

                <div className="text-right">
                  <div className="font-mono font-bold text-amber-400">£{a.unitLandedCostGBP.toFixed(2)} / unit</div>
                  <div className="text-zinc-400 text-[11px] font-mono">Total: £{a.totalCostGBP.toLocaleString(undefined, { maximumFractionDigits: 0 })}</div>
                </div>
              </div>
            ))}
          </div>

          {/* Human Auditable Decision Explanation */}
          <div className="bg-[#050505] border border-zinc-800 rounded-lg p-4 text-xs">
            <div className="text-amber-400 font-bold mb-1 flex items-center gap-1.5 font-serif-title">
              <CheckCircle2 className="w-4 h-4 text-amber-400" />
              Human-Auditable CPO Strategy Justification
            </div>
            <p className="text-zinc-300 leading-relaxed">{activeStrategy.decisionExplanation}</p>
          </div>
        </div>

        {/* Right: Pareto Frontier Scatter Graph */}
        <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-6 text-zinc-100 space-y-3 shadow-md">
          <h3 className="text-sm font-bold text-zinc-100 font-serif-title flex items-center gap-2">
            <BarChart2 className="w-4 h-4 text-amber-400" />
            Pareto Frontier (Cost vs Quality Score)
          </h3>
          <p className="text-xs text-zinc-400">
            Gold points indicate Pareto-optimal non-dominated supplier choices balancing low cost & high quality.
          </p>

          <div className="h-64 mt-2">
            <ResponsiveContainer width="100%" height="100%">
              <ScatterChart margin={{ top: 10, right: 10, bottom: 10, left: -10 }}>
                <XAxis 
                  type="number" 
                  dataKey="costGBP" 
                  name="Unit Landed Cost (£)" 
                  unit="£" 
                  stroke="#71717a" 
                  fontSize={10} 
                />
                <YAxis 
                  type="number" 
                  dataKey="qualityScore" 
                  name="Quality Score" 
                  stroke="#71717a" 
                  fontSize={10} 
                  domain={[70, 100]}
                />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0c0c0f', borderColor: '#27272a', color: '#f4f4f5', fontSize: '11px' }}
                  formatter={(value: any, name: any) => [value, name]}
                />
                <Scatter name="Suppliers" data={paretoPoints}>
                  {paretoPoints.map((entry, index) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={entry.isParetoOptimal ? '#f59e0b' : '#f97316'} 
                      r={entry.isParetoOptimal ? 6 : 4}
                    />
                  ))}
                </Scatter>
              </ScatterChart>
            </ResponsiveContainer>
          </div>

          <div className="flex items-center justify-between text-[11px] text-zinc-400 border-t border-zinc-800 pt-3">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
              <span>Pareto-Optimal Choice</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-orange-500"></span>
              <span>Sub-Optimal Choice</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
