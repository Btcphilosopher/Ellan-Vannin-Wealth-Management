import React, { useState } from 'react';
import { Building2, Target, TrendingDown, DollarSign, Play, CheckCircle2, Award } from 'lucide-react';
import { Supplier, ProductSpecification } from '../types/procurement';
import { calculateNegotiationStrategy } from '../engine/negotiationEngine';

interface NegotiationAuctionEngineProps {
  suppliers: Supplier[];
  product: ProductSpecification;
  onNavigateToArbitrage: () => void;
}

export const NegotiationAuctionEngine: React.FC<NegotiationAuctionEngineProps> = ({
  suppliers,
  product,
  onNavigateToArbitrage,
}) => {
  const [selectedSupplierId, setSelectedSupplierId] = useState(suppliers[0]?.id || '');
  const [auctionRunning, setAuctionRunning] = useState(false);
  const [auctionRound, setAuctionRound] = useState(1);

  const selectedSupplier = suppliers.find(s => s.id === selectedSupplierId) || suppliers[0];
  const negotiation = calculateNegotiationStrategy(selectedSupplier, product, suppliers.length);

  // Reverse Auction Bids State
  const [auctionBids, setAuctionBids] = useState(() => 
    suppliers.map(s => ({
      supplierId: s.id,
      companyName: s.companyName,
      country: s.country,
      currentBidGBP: s.quotedPrice * 0.98,
      leadTimeDays: s.leadTimeDays,
      defectRatePct: s.historicalDefectRatePct,
    }))
  );

  const handleRunAuctionRound = () => {
    setAuctionRunning(true);
    setTimeout(() => {
      setAuctionBids(prev => 
        prev.map(b => ({
          ...b,
          currentBidGBP: Number((b.currentBidGBP * (0.97 + Math.random() * 0.02)).toFixed(2)),
        }))
      );
      setAuctionRound(r => r + 1);
      setAuctionRunning(false);
    }, 500);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-6 text-zinc-100 shadow-md">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2.5 mb-1.5">
              <span className="bg-amber-500/10 text-amber-300 text-xs px-2.5 py-0.5 rounded font-mono font-semibold border border-amber-500/30 uppercase">
                Modules 18 & 19 Active
              </span>
              <span className="text-zinc-400 text-xs">Negotiation Target Engine & Reverse Auction Simulator</span>
            </div>
            <h2 className="text-xl font-bold tracking-tight text-zinc-100 font-serif-title">Negotiation Analytics & Reverse Auction</h2>
            <p className="text-xs text-zinc-400">
              Calculates supplier margins, target prices, walk-away prices & leverage. Evaluates reverse-auction bids on a risk-adjusted basis.
            </p>
          </div>

          <button
            onClick={onNavigateToArbitrage}
            className="bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-bold px-4 py-2.5 rounded-lg shadow transition-all flex items-center gap-2 cursor-pointer"
          >
            <span>Explore Global Price Arbitrage Map</span>
          </button>
        </div>
      </div>

      {/* Target Price Calculator Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-6 text-zinc-100 space-y-4 shadow-md">
          <div>
            <label className="text-xs text-zinc-400 font-medium block mb-1">Select Supplier for Negotiation Strategy:</label>
            <select
              value={selectedSupplierId}
              onChange={(e) => setSelectedSupplierId(e.target.value)}
              className="w-full bg-[#050505] border border-zinc-700/80 text-xs text-zinc-100 rounded p-2 focus:outline-none cursor-pointer"
            >
              {suppliers.map(s => <option key={s.id} value={s.id}>{s.companyName} ({s.country})</option>)}
            </select>
          </div>

          <div className="bg-[#050505] border border-zinc-800 p-4 rounded-lg space-y-3 text-xs">
            <div className="flex justify-between items-center">
              <span className="text-zinc-400">Quoted Unit Price (GBP):</span>
              <span className="font-mono font-bold text-zinc-100 text-sm">£{negotiation.quotedUnitPriceGBP.toFixed(2)}</span>
            </div>

            <div className="flex justify-between items-center text-amber-400">
              <span>Est. Supplier Margin:</span>
              <span className="font-mono font-bold">{negotiation.estimatedSupplierMarginPct}%</span>
            </div>

            <div className="flex justify-between items-center border-t border-zinc-800 pt-2 text-amber-400 font-bold">
              <span>TARGET PRICE (-12%):</span>
              <span className="font-mono text-base text-amber-300">£{negotiation.targetPriceGBP.toFixed(2)}</span>
            </div>

            <div className="flex justify-between items-center text-blue-400 font-semibold">
              <span>Acceptable Price (-6%):</span>
              <span className="font-mono">£{negotiation.acceptablePriceGBP.toFixed(2)}</span>
            </div>

            <div className="flex justify-between items-center text-zinc-400">
              <span>Walk-Away Threshold (-2%):</span>
              <span className="font-mono text-zinc-300">£{negotiation.walkAwayPriceGBP.toFixed(2)}</span>
            </div>
          </div>

          <div className="bg-amber-500/10 border border-amber-500/30 p-3 rounded text-xs text-amber-300">
            Total Order Savings at Target: <span className="font-mono font-bold text-amber-400">£{negotiation.potentialNegotiationSavingsGBP.toLocaleString()}</span>
          </div>
        </div>

        {/* Leverage Advice Box */}
        <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-6 text-zinc-100 lg:col-span-2 space-y-4 shadow-md">
          <h3 className="text-sm font-bold text-zinc-100 font-serif-title flex items-center gap-2 border-b border-zinc-800 pb-2">
            <Target className="w-4 h-4 text-amber-400" />
            Strategic Negotiation Leverage Points
          </h3>

          <div className="space-y-2.5 text-xs">
            {negotiation.leveragePoints.map((lp, idx) => (
              <div key={idx} className="bg-[#050505] border border-zinc-800 p-3 rounded-lg flex items-start gap-3">
                <span className="bg-amber-500/15 text-amber-300 font-mono font-bold text-[10px] px-2 py-0.5 rounded border border-amber-500/30 shrink-0">
                  LEVERAGE #{idx + 1}
                </span>
                <p className="text-zinc-300 leading-relaxed">{lp}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Reverse Auction Simulator */}
      <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-6 text-zinc-100 space-y-4 shadow-md">
        <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
          <div>
            <h3 className="text-base font-bold text-zinc-100 font-serif-title flex items-center gap-2">
              <Award className="w-5 h-5 text-amber-400" />
              Live Reverse Auction Simulator (Round #{auctionRound})
            </h3>
            <p className="text-xs text-zinc-400">Suppliers compete live. The optimiser automatically evaluates risk-adjusted winning bids.</p>
          </div>

          <button
            onClick={handleRunAuctionRound}
            disabled={auctionRunning}
            className="bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-bold px-4 py-2 rounded-lg shadow transition-all flex items-center gap-2 disabled:opacity-50 cursor-pointer"
          >
            <Play className="w-3.5 h-3.5 text-zinc-950" />
            <span>{auctionRunning ? "Simulating Bids..." : "Trigger Next Auction Round"}</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
          {auctionBids.map((b) => (
            <div key={b.supplierId} className="bg-[#050505] border border-zinc-800 rounded-lg p-4 space-y-2">
              <div className="flex justify-between items-center font-bold text-zinc-100">
                <span className="line-clamp-1">{b.companyName}</span>
                <span className="text-[10px] text-zinc-400 font-mono">{b.country}</span>
              </div>

              <div className="text-2xl font-bold font-mono text-amber-400">
                £{b.currentBidGBP.toFixed(2)}
              </div>

              <div className="text-[11px] text-zinc-400 space-y-0.5 font-mono">
                <div>Lead Time: {b.leadTimeDays}d</div>
                <div>Defect Rate: {b.defectRatePct}%</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
