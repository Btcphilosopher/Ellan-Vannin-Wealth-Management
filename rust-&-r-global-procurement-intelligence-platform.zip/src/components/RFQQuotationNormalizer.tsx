import React, { useState } from 'react';
import { FileCheck, Upload, Plus, Trash2, ArrowRight, CheckCircle2, DollarSign } from 'lucide-react';
import { Supplier, ProductSpecification, RFQQuotationInput, Incoterm, Currency } from '../types/procurement';
import { calculateLandedCost } from '../engine/landedCostEngine';

interface RFQQuotationNormalizerProps {
  product: ProductSpecification;
  onNavigateToNegotiation: () => void;
}

export const RFQQuotationNormalizer: React.FC<RFQQuotationNormalizerProps> = ({
  product,
  onNavigateToNegotiation,
}) => {
  const [quotes, setQuotes] = useState<RFQQuotationInput[]>([
    {
      id: 'rfq-1',
      supplierName: 'Ningbo Precision Fasteners Co.',
      country: 'China',
      supplierType: 'manufacturer',
      currency: 'CNY',
      quotedUnitPrice: 5.20,
      incoterm: 'FOB',
      leadTimeDays: 32,
      moq: 5000,
      estimatedDefectPct: 2.1,
    },
    {
      id: 'rfq-2',
      supplierName: 'Silesia Bolt Sp. z o.o.',
      country: 'Poland',
      supplierType: 'manufacturer',
      currency: 'EUR',
      quotedUnitPrice: 0.88,
      incoterm: 'DAP',
      leadTimeDays: 12,
      moq: 1000,
      estimatedDefectPct: 0.6,
    },
    {
      id: 'rfq-3',
      supplierName: 'Anatolia Fasteners Inc.',
      country: 'Turkey',
      supplierType: 'manufacturer',
      currency: 'USD',
      quotedUnitPrice: 0.92,
      incoterm: 'FCA',
      leadTimeDays: 18,
      moq: 2000,
      estimatedDefectPct: 1.2,
    },
    {
      id: 'rfq-4',
      supplierName: 'Pennine Fasteners Components',
      country: 'United Kingdom',
      supplierType: 'distributor',
      currency: 'GBP',
      quotedUnitPrice: 0.98,
      incoterm: 'DDP',
      leadTimeDays: 2,
      moq: 100,
      estimatedDefectPct: 0.2,
    }
  ]);

  const [newQuoteName, setNewQuoteName] = useState('');
  const [newQuoteCountry, setNewQuoteCountry] = useState('China');
  const [newQuoteCurrency, setNewQuoteCurrency] = useState<Currency>('USD');
  const [newQuotePrice, setNewQuotePrice] = useState(0.85);
  const [newQuoteIncoterm, setNewQuoteIncoterm] = useState<Incoterm>('FOB');

  const handleAddQuote = () => {
    if (!newQuoteName) return;
    const q: RFQQuotationInput = {
      id: `rfq-${Date.now()}`,
      supplierName: newQuoteName,
      country: newQuoteCountry,
      supplierType: 'manufacturer',
      currency: newQuoteCurrency,
      quotedUnitPrice: newQuotePrice,
      incoterm: newQuoteIncoterm,
      leadTimeDays: 20,
      moq: 1000,
      estimatedDefectPct: 1.0,
    };
    setQuotes([...quotes, q]);
    setNewQuoteName('');
  };

  const handleRemoveQuote = (id: string) => {
    setQuotes(quotes.filter(q => q.id !== id));
  };

  // Compute normalized GBP landed cost for each quote
  const normalizedResults = quotes.map(q => {
    const tempSupplier: Supplier = {
      id: q.id,
      companyName: q.supplierName,
      supplierType: q.supplierType,
      country: q.country,
      city: 'Unknown',
      factoryLocation: `${q.country} Industrial Hub`,
      categories: [product.category],
      capabilities: ['General Fabrication'],
      certifications: ['ISO 9001'],
      productionCapacityMonthly: 100000,
      moq: q.moq,
      quotedPrice: q.quotedUnitPrice,
      quotedCurrency: q.currency,
      incoterm: q.incoterm,
      leadTimeDays: q.leadTimeDays,
      paymentTerms: 'Standard 30 Days',
      historicalDefectRatePct: q.estimatedDefectPct,
      historicalOnTimeDeliveryPct: 95.0,
      financialRiskScore: 85,
      geopoliticalRiskScore: q.country === 'China' ? 68 : 88,
      latitude: 0,
      longitude: 0,
      contactEmail: 'sales@rfq.com',
      website: 'https://rfq.example.com',
      reliabilityScore: 90,
      carbonEmissionsKgPerUnit: 0.3,
    };

    const landed = calculateLandedCost(tempSupplier, product);
    return {
      rfq: q,
      baseLandedGBP: landed.totalBaseLandedCostGBP,
      riskAdjustedGBP: landed.riskAdjustedCostGBP,
    };
  });

  // Sort by risk-adjusted landed cost
  normalizedResults.sort((a, b) => a.riskAdjustedGBP - b.riskAdjustedGBP);
  const winner = normalizedResults[0];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-6 text-zinc-100 shadow-md">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2.5 mb-1.5">
              <span className="bg-amber-500/10 text-amber-300 text-xs px-2.5 py-0.5 rounded font-mono font-semibold border border-amber-500/30 uppercase">
                Module 17 Active
              </span>
              <span className="text-zinc-400 text-xs">RFQ Quotation Normalizer & Currency Converter</span>
            </div>
            <h2 className="text-xl font-bold tracking-tight text-zinc-100 font-serif-title">Supplier RFQ Quotation Comparison</h2>
            <p className="text-xs text-zinc-400">
              Converts raw quotations in any currency (USD, EUR, CNY, INR, JPY, GBP) and Incoterms (FOB, EXW, CIF, DAP, DDP) into normalized GBP landed cost.
            </p>
          </div>

          <button
            onClick={onNavigateToNegotiation}
            className="bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-bold px-4 py-2.5 rounded-lg shadow transition-all flex items-center gap-2 cursor-pointer"
          >
            <span>Proceed to Negotiation Engine</span>
            <ArrowRight className="w-4 h-4 text-zinc-950" />
          </button>
        </div>
      </div>

      {/* Add New Quote Form */}
      <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-5 text-zinc-100 shadow-sm">
        <h3 className="text-xs font-bold text-zinc-300 font-serif-title uppercase tracking-wider mb-3 flex items-center gap-2">
          <Plus className="w-4 h-4 text-amber-400" />
          Import or Add Manual RFQ Quotation
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-6 gap-3 text-xs">
          <div className="md:col-span-2">
            <input
              type="text"
              placeholder="Supplier Company Name"
              value={newQuoteName}
              onChange={(e) => setNewQuoteName(e.target.value)}
              className="w-full bg-[#050505] border border-zinc-700/80 rounded p-2 text-zinc-100 focus:outline-none focus:border-amber-500/50"
            />
          </div>

          <div>
            <select
              value={newQuoteCountry}
              onChange={(e) => setNewQuoteCountry(e.target.value)}
              className="w-full bg-[#050505] border border-zinc-700/80 rounded p-2 text-zinc-100 focus:outline-none focus:border-amber-500/50 cursor-pointer"
            >
              <option value="China">China</option>
              <option value="Poland">Poland</option>
              <option value="Turkey">Turkey</option>
              <option value="Germany">Germany</option>
              <option value="United Kingdom">United Kingdom</option>
              <option value="India">India</option>
              <option value="Vietnam">Vietnam</option>
            </select>
          </div>

          <div>
            <select
              value={newQuoteCurrency}
              onChange={(e) => setNewQuoteCurrency(e.target.value as Currency)}
              className="w-full bg-[#050505] border border-zinc-700/80 rounded p-2 text-zinc-100 font-mono focus:outline-none focus:border-amber-500/50 cursor-pointer"
            >
              <option value="USD">USD ($)</option>
              <option value="EUR">EUR (€)</option>
              <option value="CNY">CNY (¥)</option>
              <option value="GBP">GBP (£)</option>
            </select>
          </div>

          <div>
            <input
              type="number"
              step="0.01"
              placeholder="Quoted Unit Price"
              value={newQuotePrice}
              onChange={(e) => setNewQuotePrice(Number(e.target.value))}
              className="w-full bg-[#050505] border border-zinc-700/80 rounded p-2 text-amber-400 font-mono font-bold focus:outline-none focus:border-amber-500/50"
            />
          </div>

          <div>
            <button
              onClick={handleAddQuote}
              className="w-full bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold p-2 rounded transition-all cursor-pointer"
            >
              Add Quote
            </button>
          </div>
        </div>
      </div>

      {/* Normalized Comparison Table */}
      <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-6 text-zinc-100 overflow-x-auto shadow-md">
        <h3 className="text-sm font-bold text-zinc-100 font-serif-title mb-4 flex items-center justify-between">
          <span>Normalized Unit Landed Cost Ranking (£ GBP)</span>
          <span className="text-xs text-amber-400 font-mono flex items-center gap-1 bg-amber-500/10 px-2.5 py-1 rounded border border-amber-500/20">
            <CheckCircle2 className="w-3.5 h-3.5 text-amber-400" />
            Fair Cross-Currency Comparison
          </span>
        </h3>

        <table className="w-full text-left border-collapse text-xs">
          <thead>
            <tr className="border-b border-zinc-800 text-zinc-400 font-mono text-[11px] uppercase">
              <th className="py-2.5 px-3">Rank</th>
              <th className="py-2.5 px-3">Supplier Name</th>
              <th className="py-2.5 px-3">Country</th>
              <th className="py-2.5 px-3">Raw Quotation</th>
              <th className="py-2.5 px-3">Incoterm</th>
              <th className="py-2.5 px-3">Base Landed (GBP)</th>
              <th className="py-2.5 px-3">Risk-Adjusted (GBP)</th>
              <th className="py-2.5 px-3 text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-zinc-800/80">
            {normalizedResults.map((res, index) => {
              const isWinning = index === 0;
              return (
                <tr 
                  key={res.rfq.id}
                  className={`hover:bg-zinc-800/40 transition-colors ${
                    isWinning ? 'bg-amber-500/10 font-semibold' : ''
                  }`}
                >
                  <td className="py-3 px-3 font-mono font-bold">
                    {isWinning ? (
                      <span className="bg-amber-500 text-zinc-950 text-[10px] font-bold px-2 py-0.5 rounded font-mono">
                        #1 WINNER
                      </span>
                    ) : (
                      <span className="text-zinc-500">#{index + 1}</span>
                    )}
                  </td>
                  <td className="py-3 px-3 font-semibold text-zinc-100">
                    {res.rfq.supplierName}
                  </td>
                  <td className="py-3 px-3 text-zinc-300">{res.rfq.country}</td>
                  <td className="py-3 px-3 font-mono text-zinc-200">
                    {res.rfq.quotedUnitPrice} {res.rfq.currency}
                  </td>
                  <td className="py-3 px-3 font-mono text-amber-400 font-bold">{res.rfq.incoterm}</td>
                  <td className="py-3 px-3 font-mono text-blue-400">£{res.baseLandedGBP.toFixed(2)}</td>
                  <td className="py-3 px-3 font-mono font-bold text-amber-400 text-sm">
                    £{res.riskAdjustedGBP.toFixed(2)}
                  </td>
                  <td className="py-3 px-3 text-right">
                    <button
                      onClick={() => handleRemoveQuote(res.rfq.id)}
                      className="text-zinc-500 hover:text-red-400 p-1 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
