import React from 'react';
import { 
  Building2, 
  Cpu, 
  BarChart3, 
  Globe2, 
  Layers, 
  Bot, 
  ShieldAlert, 
  Terminal, 
  DollarSign, 
  Calculator,
  Compass,
  FileCheck
} from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  selectedCurrency: string;
  setSelectedCurrency: (curr: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  selectedCurrency,
  setSelectedCurrency,
}) => {
  const navItems = [
    { id: 'dashboard', label: 'Executive Dashboard', icon: BarChart3 },
    { id: 'product-spec', label: 'NLP Product Spec', icon: Calculator },
    { id: 'discovery', label: 'Supplier Discovery', icon: Globe2 },
    { id: 'landed-cost', label: 'Landed Cost Engine', icon: DollarSign },
    { id: 'optimization', label: 'Pareto & Portfolio', icon: Layers },
    { id: 'monte-carlo', label: 'Monte Carlo 10k', icon: ShieldAlert },
    { id: 'rfq-normalizer', label: 'RFQ Comparison', icon: FileCheck },
    { id: 'negotiation', label: 'Negotiation & Auction', icon: Building2 },
    { id: 'arbitrage-map', label: 'Global Arbitrage Map', icon: Compass },
    { id: 'ai-assistant', label: 'AI CPO Assistant', icon: Bot },
    { id: 'rust-r-engine', label: 'Rust + R Architecture', icon: Cpu },
  ];

  return (
    <header className="bg-[#09090c] border-b border-zinc-800/80 text-zinc-100 sticky top-0 z-50 shadow-lg shadow-black/40 backdrop-blur-md">
      {/* Top Banner */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="bg-amber-500/10 border border-amber-500/30 text-amber-400 p-2.5 rounded-lg flex items-center justify-center shadow-inner">
            <Cpu className="w-5 h-5 text-amber-400" />
          </div>
          <div>
            <div className="flex items-center gap-2.5">
              <h1 className="text-lg font-bold tracking-tight text-zinc-100 font-serif-title">Rust + R Procurement Intelligence</h1>
              <span className="bg-amber-500/10 text-amber-300 text-[11px] px-2 py-0.5 rounded border border-amber-500/25 font-mono">
                Rust WASM + R v4.4
              </span>
            </div>
            <p className="text-xs text-zinc-400">
              Global Supplier Optimization, Total Landed Cost & Stochastic Risk Engine
            </p>
          </div>
        </div>

        {/* Currency & System Status */}
        <div className="flex items-center gap-4">
          <div className="hidden md:flex items-center gap-2 text-xs text-zinc-300 bg-zinc-900/90 px-3 py-1.5 rounded-md border border-zinc-800 font-mono shadow-inner">
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <span className="text-zinc-200">Rust Engine: <span className="text-amber-400 font-semibold">1.4ms</span></span>
            <span className="text-zinc-700">|</span>
            <span className="text-zinc-200">R Analytics: <span className="text-emerald-400 font-semibold">Synced</span></span>
          </div>

          <div className="flex items-center gap-2">
            <label className="text-xs text-zinc-400 font-medium">Display FX:</label>
            <select
              value={selectedCurrency}
              onChange={(e) => setSelectedCurrency(e.target.value)}
              className="bg-zinc-900 border border-zinc-700/80 text-xs font-semibold text-amber-400 rounded-md px-2.5 py-1 focus:outline-none focus:ring-1 focus:ring-amber-500/50 cursor-pointer"
            >
              <option value="GBP">GBP (£)</option>
              <option value="USD">USD ($)</option>
              <option value="EUR">EUR (€)</option>
              <option value="CNY">CNY (¥)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-[#050505]/95 border-t border-zinc-800/60 overflow-x-auto no-scrollbar">
        <div className="max-w-7xl mx-auto px-4 flex space-x-1.5 py-1.5">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs transition-all whitespace-nowrap ${
                  isActive
                    ? 'bg-amber-500/15 text-amber-300 border border-amber-500/40 shadow-[0_0_12px_rgba(212,175,55,0.12)] font-semibold'
                    : 'text-zinc-400 hover:text-zinc-100 hover:bg-zinc-900/70 border border-transparent'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-amber-400' : 'text-zinc-500'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
