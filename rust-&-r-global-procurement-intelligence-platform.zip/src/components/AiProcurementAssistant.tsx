import React, { useState } from 'react';
import { Bot, Send, Sparkles, User, RefreshCw, CheckCircle2, MessageSquare } from 'lucide-react';
import { Supplier, ProductSpecification } from '../types/procurement';

interface AiProcurementAssistantProps {
  product: ProductSpecification;
  suppliers: Supplier[];
}

interface Message {
  sender: 'user' | 'ai';
  text: string;
  landedSummary?: any[];
}

export const AiProcurementAssistant: React.FC<AiProcurementAssistantProps> = ({
  product,
  suppliers,
}) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      sender: 'ai',
      text: `Hello! I am your AI Chief Procurement Officer Assistant powered by server-side Gemini. I have loaded real-time landed cost metrics, supplier scorecards, and geopolitical risk profiles for "${product.name}". How can I optimize your global purchasing strategy today?`,
    }
  ]);

  const [inputQuery, setInputQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const sampleQuestions = [
    "Find me the cheapest qualified supplier for 100,000 units delivered to Manchester by 1 June",
    "What happens if we move 40% of our procurement volume from China to Poland and Turkey?",
    "Evaluate the geopolitical risk trade-off between Ningbo Precision (China) and Silesia Bolt (Poland)",
    "Calculate the landed cost impact if ocean container freight rates surge by 25%",
  ];

  const handleSendMessage = async (queryText?: string) => {
    const q = queryText || inputQuery;
    if (!q.trim()) return;

    const userMsg: Message = { sender: 'user', text: q };
    setMessages(prev => [...prev, userMsg]);
    if (!queryText) setInputQuery('');
    setIsLoading(true);

    try {
      const res = await fetch("/api/gemini/assistant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userQuery: q,
          contextProduct: product,
          contextSuppliers: suppliers,
        }),
      });

      const data = await res.json();
      const aiMsg: Message = {
        sender: 'ai',
        text: data.reply || "Analysed procurement database.",
        landedSummary: data.landedSummary,
      };

      setMessages(prev => [...prev, aiMsg]);
    } catch (err) {
      console.error(err);
      setMessages(prev => [...prev, {
        sender: 'ai',
        text: "Apologies, I encountered an error communicating with the Gemini server route. Please try again.",
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-6 text-zinc-100 shadow-md">
        <div className="flex items-center gap-3">
          <div className="bg-amber-500/10 p-2.5 rounded-lg text-amber-400 border border-amber-500/30">
            <Bot className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold tracking-tight text-zinc-100 font-serif-title">AI Chief Procurement Officer Assistant</h2>
            <p className="text-xs text-zinc-400">
              Conversational Gemini AI interface for real-time scenario modeling, trade-off calculations, and audit-ready procurement strategies.
            </p>
          </div>
        </div>
      </div>

      {/* Suggested Quick Questions */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar">
        <span className="text-xs text-zinc-400 font-semibold shrink-0">Sample Questions:</span>
        {sampleQuestions.map((sq, i) => (
          <button
            key={i}
            onClick={() => handleSendMessage(sq)}
            className="text-xs bg-[#0c0c0f] hover:bg-zinc-800/60 border border-zinc-800 text-zinc-300 hover:text-zinc-100 px-3 py-1.5 rounded-full transition-all shrink-0 font-sans cursor-pointer"
          >
            "{sq}"
          </button>
        ))}
      </div>

      {/* Conversation Thread Window */}
      <div className="bg-[#0c0c0f] border border-zinc-800/80 rounded-xl p-6 text-zinc-100 space-y-4 min-h-[400px] max-h-[600px] overflow-y-auto flex flex-col justify-between shadow-md">
        <div className="space-y-4">
          {messages.map((m, idx) => (
            <div
              key={idx}
              className={`flex gap-3 text-xs ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {m.sender === 'ai' && (
                <div className="w-7 h-7 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center shrink-0">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div className={`max-w-2xl rounded-xl p-4 leading-relaxed whitespace-pre-wrap ${
                m.sender === 'user'
                  ? 'bg-amber-500 text-zinc-950 font-semibold rounded-tr-none'
                  : 'bg-[#050505] border border-zinc-800/80 text-zinc-200 rounded-tl-none shadow'
              }`}>
                {m.text}

                {/* Optional Landed Summary Table in AI responses */}
                {m.landedSummary && m.landedSummary.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-zinc-800 space-y-2">
                    <div className="font-bold text-amber-400 text-[11px] font-serif-title">Real-Time Calculated Landed Cost Matrix:</div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
                      {m.landedSummary.map((s, i) => (
                        <div key={i} className="bg-[#0c0c0f] p-2.5 rounded border border-zinc-800/80">
                          <div className="font-bold text-zinc-100">{s.company} ({s.country})</div>
                          <div className="text-amber-400 font-mono font-semibold">Risk-Adjusted: {s.riskAdjustedCostGBP}</div>
                          <div className="text-zinc-400 text-[10px]">Lead Time: {s.leadTimeDays}d • Geopolitical Risk: {s.geopoliticalRiskScore}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {m.sender === 'user' && (
                <div className="w-7 h-7 rounded-full bg-blue-600/20 border border-blue-500/40 text-blue-400 flex items-center justify-center shrink-0">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          ))}

          {isLoading && (
            <div className="flex gap-3 text-xs items-center text-amber-400 font-mono animate-pulse">
              <Bot className="w-4 h-4" />
              <span>Gemini AI is analyzing landed costs, FX rates & risk factors...</span>
            </div>
          )}
        </div>

        {/* Input Bar */}
        <div className="pt-4 border-t border-zinc-800 flex items-center gap-3">
          <input
            type="text"
            value={inputQuery}
            onChange={(e) => setInputQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
            placeholder="Ask AI CPO any question about suppliers, landed costs, tariffs, dual sourcing..."
            className="flex-1 bg-[#050505] border border-zinc-700/80 rounded-lg px-4 py-3 text-xs text-zinc-100 placeholder-zinc-500 focus:outline-none focus:border-amber-500/50 font-sans"
          />
          <button
            onClick={() => handleSendMessage()}
            disabled={isLoading || !inputQuery.trim()}
            className="bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold px-5 py-3 rounded-lg text-xs shadow transition-all flex items-center gap-2 disabled:opacity-50 shrink-0 cursor-pointer"
          >
            <span>Ask AI</span>
            <Send className="w-3.5 h-3.5 text-zinc-950" />
          </button>
        </div>
      </div>
    </div>
  );
};
