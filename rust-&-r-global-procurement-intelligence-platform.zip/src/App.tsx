import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { ExecutiveDashboard } from './components/ExecutiveDashboard';
import { ProductSpecParser } from './components/ProductSpecParser';
import { SupplierDiscovery } from './components/SupplierDiscovery';
import { LandedCostCalculator } from './components/LandedCostCalculator';
import { ParetoOptimization } from './components/ParetoOptimization';
import { MonteCarloSimulationView } from './components/MonteCarloSimulationView';
import { RFQQuotationNormalizer } from './components/RFQQuotationNormalizer';
import { NegotiationAuctionEngine } from './components/NegotiationAuctionEngine';
import { GlobalArbitrageMap } from './components/GlobalArbitrageMap';
import { AiProcurementAssistant } from './components/AiProcurementAssistant';
import { RustREngineViewer } from './components/RustREngineViewer';

import { SAMPLE_PRODUCTS, SAMPLE_SUPPLIERS } from './data/mockDatabase';
import { ProductSpecification, Supplier } from './types/procurement';

export function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [selectedCurrency, setSelectedCurrency] = useState('GBP');
  const [products, setProducts] = useState<ProductSpecification[]>(SAMPLE_PRODUCTS);
  const [suppliers, setSuppliers] = useState<Supplier[]>(SAMPLE_SUPPLIERS);
  const [selectedProduct, setSelectedProduct] = useState<ProductSpecification>(SAMPLE_PRODUCTS[0]);

  const handleUpdateProductSpec = (updatedSpec: ProductSpecification) => {
    setSelectedProduct(updatedSpec);
    setProducts(prev => prev.map(p => p.id === updatedSpec.id ? updatedSpec : p));
  };

  return (
    <div className="min-h-screen bg-[#050505] text-[#f4f4f5] font-sans antialiased selection:bg-amber-500/30 selection:text-amber-200">
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        selectedCurrency={selectedCurrency}
        setSelectedCurrency={setSelectedCurrency}
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'dashboard' && (
          <ExecutiveDashboard
            products={products}
            suppliers={suppliers}
            onSelectProduct={(p) => {
              setSelectedProduct(p);
              setActiveTab('landed-cost');
            }}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'product-spec' && (
          <ProductSpecParser
            currentSpec={selectedProduct}
            onUpdateSpec={handleUpdateProductSpec}
            onNavigateToNext={() => setActiveTab('discovery')}
          />
        )}

        {activeTab === 'discovery' && (
          <SupplierDiscovery
            suppliers={suppliers}
            product={selectedProduct}
            onSelectSupplierForDetail={(s) => {}}
            onNavigateToLandedCost={() => setActiveTab('landed-cost')}
          />
        )}

        {activeTab === 'landed-cost' && (
          <LandedCostCalculator
            suppliers={suppliers}
            product={selectedProduct}
            onNavigateToOptimization={() => setActiveTab('optimization')}
          />
        )}

        {activeTab === 'optimization' && (
          <ParetoOptimization
            suppliers={suppliers}
            product={selectedProduct}
            onNavigateToMonteCarlo={() => setActiveTab('monte-carlo')}
          />
        )}

        {activeTab === 'monte-carlo' && (
          <MonteCarloSimulationView
            suppliers={suppliers}
            product={selectedProduct}
            onNavigateToRFQ={() => setActiveTab('rfq-normalizer')}
          />
        )}

        {activeTab === 'rfq-normalizer' && (
          <RFQQuotationNormalizer
            product={selectedProduct}
            onNavigateToNegotiation={() => setActiveTab('negotiation')}
          />
        )}

        {activeTab === 'negotiation' && (
          <NegotiationAuctionEngine
            suppliers={suppliers}
            product={selectedProduct}
            onNavigateToArbitrage={() => setActiveTab('arbitrage-map')}
          />
        )}

        {activeTab === 'arbitrage-map' && (
          <GlobalArbitrageMap />
        )}

        {activeTab === 'ai-assistant' && (
          <AiProcurementAssistant
            product={selectedProduct}
            suppliers={suppliers}
          />
        )}

        {activeTab === 'rust-r-engine' && (
          <RustREngineViewer />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-zinc-800/80 bg-[#08080b] py-6 text-center text-xs text-zinc-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div>
            Rust + R Global Procurement Intelligence Platform • Reproducible Algorithmic Procurement
          </div>
          <div className="font-mono text-amber-400/90 flex items-center gap-1.5">
            <span className="inline-block w-1.5 h-1.5 rounded-full bg-amber-400"></span>
            Powered by Rust Core + R Statistical Models + Gemini AI
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
