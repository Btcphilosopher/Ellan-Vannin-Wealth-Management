import React, { useState } from 'react';
import { useFinancialStore } from '../../store/useFinancialStore';
import { Droplets, ShieldCheck, CheckCircle2, AlertCircle, RefreshCw, Zap } from 'lucide-react';

export const LiquidityControlView: React.FC = () => {
  const { liquidityQueues, resolveLiquidityQueue, institutions } = useFinancialStore();
  const [resolveMessage, setResolveMessage] = useState<string | null>(null);

  const handleResolve = (queueId: string) => {
    resolveLiquidityQueue(queueId);
    setResolveMessage(`[유동성 해소] 중앙은행 일중 담보대출 적격 연계로 유동성 부족 대기열 즉시 해소 완결!`);
    setTimeout(() => setResolveMessage(null), 4000);
  };

  return (
    <div className="p-6 space-y-6 text-slate-100">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <Droplets className="w-6 h-6 text-sky-400" />
            <h2 className="text-xl font-extrabold text-white tracking-tight">
              일중 유동성 관제센터 (Intraday Liquidity Control Center)
            </h2>
            <span className="bg-sky-950 text-sky-300 text-xs font-mono font-bold px-2 py-0.5 rounded border border-sky-800">
              SETTLEMENT QUEUE MANAGEMENT
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            참여 금융기관별 일중 결제 대기열, 담보 연계 유동성 및 중앙은행 차입금 자동 해소 관제
          </p>
        </div>
      </div>

      {resolveMessage && (
        <div className="bg-emerald-950/90 border border-emerald-700 text-emerald-200 px-4 py-2.5 rounded-md text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{resolveMessage}</span>
        </div>
      )}

      {/* Liquidity Queue Resolution Panel */}
      <div className="bg-slate-950 border border-slate-800 p-5 rounded-lg space-y-4">
        <h3 className="text-sm font-bold text-slate-200 border-b border-slate-800 pb-2 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-amber-400" />
          일중 결제 대기열 및 유동성 부족 건 (Settlement Deficit Queue)
        </h3>

        {liquidityQueues.length === 0 ? (
          <div className="p-6 text-center text-xs text-slate-400 font-mono">
            현재 대기 중인 유동성 부족 또는 결제 교착 건이 없습니다.
          </div>
        ) : (
          <div className="space-y-3">
            {liquidityQueues.map((item) => (
              <div
                key={item.id}
                className={`p-4 rounded-lg border flex flex-wrap items-center justify-between gap-4 ${
                  item.queueStatus === 'QUEUED'
                    ? 'bg-amber-950/40 border-amber-800 text-amber-100'
                    : 'bg-slate-900 border-slate-800 text-slate-300'
                }`}
              >
                <div className="space-y-1 text-xs font-mono">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white text-sm">{item.bankName} 유동성 부족 발생</span>
                    <span className="bg-amber-900/80 text-amber-200 text-[10px] px-2 py-0.5 rounded border border-amber-700">
                      부족액: ₩{(item.deficitAmount / 100000000).toLocaleString()}억원
                    </span>
                  </div>
                  <div className="text-slate-400 text-[11px]">
                    필요 유동성: ₩{(item.requiredLiquidity / 100000000).toLocaleString()}억원 / 가용 유동성: ₩{(item.availableLiquidity / 100000000).toLocaleString()}억원
                  </div>
                  <div className="text-slate-500 text-[10px]">{item.reason}</div>
                </div>

                {item.queueStatus === 'QUEUED' ? (
                  <button
                    onClick={() => handleResolve(item.id)}
                    className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2 px-4 rounded text-xs shadow-md flex items-center gap-1.5"
                  >
                    <Zap className="w-4 h-4" />
                    중앙은행 담보연계 대출 승인 (대기열 해소)
                  </button>
                ) : (
                  <span className="bg-emerald-950 text-emerald-400 font-bold px-3 py-1 rounded border border-emerald-800 text-xs">
                    ✓ 정상 해소 완료
                  </span>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
