import React from 'react';
import { useFinancialStore } from '../../store/useFinancialStore';
import { Sliders, RefreshCw, CheckCircle2, TrendingUp, DollarSign } from 'lucide-react';

export const EconomicSimulatorView: React.FC = () => {
  const { economicVariables, setEconomicVariable } = useFinancialStore();

  return (
    <div className="p-6 space-y-6 text-slate-100">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <Sliders className="w-6 h-6 text-indigo-400" />
            <h2 className="text-xl font-extrabold text-white tracking-tight">
              디지털 통화 거시경제 시뮬레이터 (Macroeconomic Parameter Engine)
            </h2>
            <span className="bg-indigo-950 text-indigo-300 text-xs font-mono font-bold px-2 py-0.5 rounded border border-indigo-800">
              POLICY PARAMETER LAB
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            한국은행 기준금리, 예금 토큰 수수료, 지급준비율 및 바우처 예산 파라미터가 디지털 통화 유통 속도에 미치는 영향 분석
          </p>
        </div>
      </div>

      {/* Parameter Sliders Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Base Rate Slider */}
        <div className="bg-slate-950 border border-slate-800 p-4 rounded-lg space-y-2">
          <div className="flex justify-between items-center">
            <label className="text-xs font-bold text-white">한국은행 기준금리 (%)</label>
            <span className="text-sm font-mono font-bold text-indigo-400">{economicVariables.baseInterestRate ?? 3.5}%</span>
          </div>
          <input
            type="range"
            min="1.0"
            max="6.0"
            step="0.25"
            value={economicVariables.baseInterestRate ?? 3.5}
            onChange={(e) => setEconomicVariable('baseInterestRate', Number(e.target.value))}
            className="w-full accent-indigo-500"
          />
          <p className="text-[11px] text-slate-400">기관용 CBDC 지불 이자율 및 시중은행 자금조달 비용에 직접 연동</p>
        </div>

        {/* Token Transaction Fee Slider */}
        <div className="bg-slate-950 border border-slate-800 p-4 rounded-lg space-y-2">
          <div className="flex justify-between items-center">
            <label className="text-xs font-bold text-white">예금 토큰 이체 수수료율 (%)</label>
            <span className="text-sm font-mono font-bold text-indigo-400">{economicVariables.depositTokenFeeRate ?? 0.05}%</span>
          </div>
          <input
            type="range"
            min="0.00"
            max="0.50"
            step="0.01"
            value={economicVariables.depositTokenFeeRate ?? 0.05}
            onChange={(e) => setEconomicVariable('depositTokenFeeRate', Number(e.target.value))}
            className="w-full accent-indigo-500"
          />
          <p className="text-[11px] text-slate-400">가맹점 및 소비자 사용 유인에 영향을 미치는 정산 수수료율</p>
        </div>

        {/* Reserve Ratio Slider */}
        <div className="bg-slate-950 border border-slate-800 p-4 rounded-lg space-y-2">
          <div className="flex justify-between items-center">
            <label className="text-xs font-bold text-white">시중은행 지급준비율 (%)</label>
            <span className="text-sm font-mono font-bold text-indigo-400">{economicVariables.reserveRequirementRatio ?? 7.0}%</span>
          </div>
          <input
            type="range"
            min="3.0"
            max="15.0"
            step="0.5"
            value={economicVariables.reserveRequirementRatio ?? 7.0}
            onChange={(e) => setEconomicVariable('reserveRequirementRatio', Number(e.target.value))}
            className="w-full accent-indigo-500"
          />
          <p className="text-[11px] text-slate-400">예금 토큰 발행 시 한국은행에 의무 예치해야 하는 법정 지급준비율</p>
        </div>

        {/* Daily Spend Limit Slider */}
        <div className="bg-slate-950 border border-slate-800 p-4 rounded-lg space-y-2">
          <div className="flex justify-between items-center">
            <label className="text-xs font-bold text-white">일반 개인 일일 결제 한도 (KRW)</label>
            <span className="text-sm font-mono font-bold text-indigo-400">
              ₩{((economicVariables.dailyTransactionLimit ?? 10000000) / 10000).toLocaleString()}만원
            </span>
          </div>
          <input
            type="range"
            min="1000000"
            max="20000000"
            step="1000000"
            value={economicVariables.dailyTransactionLimit ?? 10000000}
            onChange={(e) => setEconomicVariable('dailyTransactionLimit', Number(e.target.value))}
            className="w-full accent-indigo-500"
          />
          <p className="text-[11px] text-slate-400">금융안정성 유지를 위한 개인 지갑 1일 최대 사용 한도</p>
        </div>
      </div>
    </div>
  );
};
