import React, { useState } from 'react';
import { useFinancialStore } from '../../store/useFinancialStore';
import { Coins, ArrowRightLeft, Users, Store, ShieldCheck, CheckCircle2, TrendingUp, Wallet as WalletIcon } from 'lucide-react';

export const TokenizedDepositsView: React.FC = () => {
  const { wallets, balanceSheets, convertDepositToToken, convertTokenToDeposit } = useFinancialStore();

  const [selectedWalletId, setSelectedWalletId] = useState<string>('WAL-USER-001');
  const [amount, setAmount] = useState<number>(500000); // ₩50만
  const [activeNotice, setActiveNotice] = useState<string | null>(null);

  const activeWallet = wallets.find((w) => w.id === selectedWalletId);

  const handleConvertToToken = () => {
    if (!activeWallet) return;
    convertDepositToToken(selectedWalletId, amount);
    setActiveNotice(`은행 예금 ₩${amount.toLocaleString()}원 → 예금 토큰 전환 완결! (지갑: ${activeWallet.ownerName})`);
    setTimeout(() => setActiveNotice(null), 4000);
  };

  const handleConvertDeposit = () => {
    if (!activeWallet || activeWallet.depositTokenBalance < amount) {
      setActiveNotice('예금 토큰 잔액이 부족합니다.');
      setTimeout(() => setActiveNotice(null), 4000);
      return;
    }
    convertTokenToDeposit(selectedWalletId, amount);
    setActiveNotice(`예금 토큰 ₩${amount.toLocaleString()}원 → 은행 예금 환원 완결! (지갑: ${activeWallet.ownerName})`);
    setTimeout(() => setActiveNotice(null), 4000);
  };

  return (
    <div className="p-6 space-y-6 text-slate-100">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <Coins className="w-6 h-6 text-indigo-400" />
            <h2 className="text-xl font-extrabold text-white tracking-tight">
              예금 토큰 플랫폼 (Tokenized Deposit Platform)
            </h2>
            <span className="bg-indigo-950 text-indigo-300 text-xs font-mono font-bold px-2 py-0.5 rounded border border-indigo-800">
              COMMERCIAL BANK TOKENIZATION
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            시중은행의 예금을 분산 허가형 원장 기반 1:1 토큰화하여 안전한 디지털 화폐 유통 환경 제공
          </p>
        </div>
      </div>

      {activeNotice && (
        <div className="bg-emerald-950/90 border border-emerald-700 text-emerald-200 px-4 py-2.5 rounded-md text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{activeNotice}</span>
        </div>
      )}

      {/* Convert Interactive Card */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-slate-950 border border-slate-800 p-5 rounded-lg space-y-4">
          <h3 className="text-sm font-bold text-slate-200 border-b border-slate-800 pb-2 flex items-center gap-2">
            <ArrowRightLeft className="w-4 h-4 text-indigo-400" />
            예금 ↔ 예금 토큰 전환 실행
          </h3>

          <div className="space-y-3 text-xs">
            <div>
              <label className="block text-slate-400 font-medium mb-1">대상 사용자 지갑 선택</label>
              <select
                value={selectedWalletId}
                onChange={(e) => setSelectedWalletId(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-white rounded p-2 text-xs focus:ring-1 focus:ring-indigo-500"
              >
                {wallets.map((w) => (
                  <option key={w.id} value={w.id}>
                    {w.ownerName} ({w.bankName}) — 토큰 잔액: ₩{w.depositTokenBalance.toLocaleString()}
                  </option>
                ))}
              </select>
            </div>

            {activeWallet && (
              <div className="bg-slate-900/80 p-3 rounded border border-slate-800 space-y-1 font-mono text-[11px]">
                <div className="flex justify-between">
                  <span className="text-slate-400">발행 은행:</span>
                  <span className="text-white font-bold">{activeWallet.bankName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">예금 토큰 보유액:</span>
                  <span className="text-indigo-400 font-bold">₩{activeWallet.depositTokenBalance.toLocaleString()}</span>
                </div>
              </div>
            )}

            <div>
              <label className="block text-slate-400 font-medium mb-1">전환 금액 (KRW)</label>
              <input
                type="number"
                step="100000"
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value))}
                className="w-full bg-slate-900 border border-slate-700 text-white rounded p-2 text-xs font-mono focus:ring-1 focus:ring-indigo-500"
              />
              <div className="flex gap-1.5 mt-1.5">
                {[100000, 500000, 1000000, 5000000].map((preset) => (
                  <button
                    key={preset}
                    onClick={() => setAmount(preset)}
                    className="bg-slate-900 hover:bg-slate-800 text-slate-300 text-[10px] px-2 py-1 rounded border border-slate-800 font-mono"
                  >
                    +₩{(preset / 10000).toLocaleString()}만원
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                onClick={handleConvertToToken}
                className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-2 px-3 rounded text-xs shadow-sm flex items-center justify-center gap-1"
              >
                예금 → 예금 토큰
              </button>
              <button
                onClick={handleConvertDeposit}
                className="bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold py-2 px-3 rounded text-xs border border-slate-700 flex items-center justify-center gap-1"
              >
                예금 토큰 → 예금
              </button>
            </div>
          </div>
        </div>

        {/* 7 Banks Overview Grid */}
        <div className="lg:col-span-2 bg-slate-950 border border-slate-800 p-5 rounded-lg space-y-3">
          <h3 className="text-sm font-bold text-slate-200 border-b border-slate-800 pb-2">
            참여 시중은행 7개사 예금 토큰 발행 및 유통 현황
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 bg-slate-900/50">
                  <th className="py-2 px-3">은행명</th>
                  <th className="py-2 px-3 text-right">고객 예금 (조)</th>
                  <th className="py-2 px-3 text-right">토큰화 발행액 (조)</th>
                  <th className="py-2 px-3 text-right">BIS 비율 (%)</th>
                  <th className="py-2 px-3 text-right">LCR 유동성 (%)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-900">
                {balanceSheets.map((bs) => (
                  <tr key={bs.bankId} className="hover:bg-slate-900/50">
                    <td className="py-2.5 px-3 font-semibold text-slate-200">{bs.bankName}</td>
                    <td className="py-2.5 px-3 text-right text-slate-300 font-mono-num">
                      ₩{(bs.liabilities.customerDeposits / 1000000000000).toFixed(2)}조
                    </td>
                    <td className="py-2.5 px-3 text-right font-bold text-indigo-400 font-mono-num">
                      ₩{(bs.liabilities.tokenizedDepositsIssued / 1000000000000).toFixed(2)}조
                    </td>
                    <td className="py-2.5 px-3 text-right text-emerald-400 font-mono-num font-bold">
                      {bs.capitalAdequacyRatio}%
                    </td>
                    <td className="py-2.5 px-3 text-right text-sky-400 font-mono-num font-bold">
                      {bs.liquidityCoverageRatio}%
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
