import React, { useState } from 'react';
import { useFinancialStore } from '../../store/useFinancialStore';
import { Ticket, Plus, CheckCircle2, ShieldCheck, Filter, Calendar, Store } from 'lucide-react';

export const DigitalVouchersView: React.FC = () => {
  const { vouchers, issueVoucher } = useFinancialStore();

  const [title, setTitle] = useState<string>('지역경제 활성화 바우처');
  const [agency, setAgency] = useState<string>('행정안전부');
  const [amount, setAmount] = useState<number>(10000000000); // ₩100억
  const [categories, setCategories] = useState<string>('전통시장, 소상공인, 동네식당');
  const [desc, setDesc] = useState<string>('대형마트 및 백화점 결제 자동 차단 스마트계약 적용');
  const [notice, setNotice] = useState<string | null>(null);

  const handleIssueNewVoucher = () => {
    issueVoucher({
      title,
      issuingAgency: agency,
      totalIssuedAmount: amount,
      remainingAmount: amount,
      allowedCategories: categories.split(',').map((s) => s.trim()),
      validFrom: '2026.09.01',
      validUntil: '2026.12.31',
      restrictionDescription: desc,
      eligibleMerchantsCount: 18500,
      status: 'ACTIVE'
    });

    setNotice(`프로그래머블 디지털 바우처 [${title}] 발행 완결! (발행액: ₩${(amount / 100000000).toLocaleString()}억원)`);
    setTimeout(() => setNotice(null), 4000);
  };

  return (
    <div className="p-6 space-y-6 text-slate-100">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <Ticket className="w-6 h-6 text-amber-400" />
            <h2 className="text-xl font-extrabold text-white tracking-tight">
              디지털 바우처 관리 (Digital Voucher Management)
            </h2>
            <span className="bg-amber-950 text-amber-300 text-xs font-mono font-bold px-2 py-0.5 rounded border border-amber-800">
              PROGRAMMABLE MONEY
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            정부 및 지자체 목적성 보조금을 프로그래머블 조건(사용업종, 유효기간, 가맹점 조건)에 맞춰 자동 실행
          </p>
        </div>
      </div>

      {notice && (
        <div className="bg-emerald-950/90 border border-emerald-700 text-emerald-200 px-4 py-2.5 rounded-md text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{notice}</span>
        </div>
      )}

      {/* Creation and List */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Issue Voucher Form */}
        <div className="bg-slate-950 border border-slate-800 p-5 rounded-lg space-y-4">
          <h3 className="text-sm font-bold text-slate-200 border-b border-slate-800 pb-2 flex items-center gap-2">
            <Plus className="w-4 h-4 text-amber-400" />
            신규 프로그래머블 바우처 발행
          </h3>

          <div className="space-y-3 text-xs">
            <div>
              <label className="block text-slate-400 font-medium mb-1">바우처 명칭</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-white rounded p-2 text-xs"
              />
            </div>

            <div>
              <label className="block text-slate-400 font-medium mb-1">발행 기관</label>
              <input
                type="text"
                value={agency}
                onChange={(e) => setAgency(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-white rounded p-2 text-xs"
              />
            </div>

            <div>
              <label className="block text-slate-400 font-medium mb-1">총 발행액 (KRW)</label>
              <input
                type="number"
                step="1000000000"
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value))}
                className="w-full bg-slate-900 border border-slate-700 text-white rounded p-2 text-xs font-mono font-bold text-amber-300"
              />
            </div>

            <div>
              <label className="block text-slate-400 font-medium mb-1">사용 허용 업종 (쉼표 구분)</label>
              <input
                type="text"
                value={categories}
                onChange={(e) => setCategories(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-white rounded p-2 text-xs"
              />
            </div>

            <div>
              <label className="block text-slate-400 font-medium mb-1">스마트계약 통제 정책</label>
              <textarea
                rows={2}
                value={desc}
                onChange={(e) => setDesc(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-white rounded p-2 text-xs"
              />
            </div>

            <button
              onClick={handleIssueNewVoucher}
              className="w-full bg-amber-600 hover:bg-amber-500 text-white font-bold py-2.5 px-4 rounded text-xs shadow-md transition flex items-center justify-center gap-1.5"
            >
              <Ticket className="w-4 h-4" />
              스마트 바우처 발행 및 원장 배포
            </button>
          </div>
        </div>

        {/* Existing Vouchers List */}
        <div className="lg:col-span-2 bg-slate-950 border border-slate-800 p-5 rounded-lg space-y-4">
          <h3 className="text-sm font-bold text-slate-200 border-b border-slate-800 pb-2">
            발행 및 사용 중인 목적성 바우처 리스트
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {vouchers.map((vc) => (
              <div key={vc.id} className="bg-slate-900/80 border border-slate-800 p-4 rounded-lg space-y-3">
                <div className="flex justify-between items-start">
                  <div>
                    <span className="bg-amber-950 text-amber-300 text-[10px] font-mono font-bold px-2 py-0.5 rounded border border-amber-800">
                      {vc.id}
                    </span>
                    <h4 className="text-sm font-bold text-white mt-1">{vc.title}</h4>
                    <p className="text-[11px] text-slate-400">{vc.issuingAgency}</p>
                  </div>
                  <span className="bg-emerald-950 text-emerald-400 text-[10px] font-bold px-2 py-0.5 rounded border border-emerald-800">
                    {vc.status}
                  </span>
                </div>

                <div className="space-y-1 text-xs font-mono">
                  <div className="flex justify-between">
                    <span className="text-slate-400">총 발행액:</span>
                    <span className="text-white font-bold">₩{(vc.totalIssuedAmount / 100000000).toLocaleString()}억원</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">잔여액:</span>
                    <span className="text-amber-400 font-bold">₩{(vc.remainingAmount / 100000000).toLocaleString()}억원</span>
                  </div>
                </div>

                <div className="bg-slate-950 p-2.5 rounded border border-slate-800 text-[11px] space-y-1">
                  <div className="text-slate-400 font-medium">허용 업종:</div>
                  <div className="flex flex-wrap gap-1">
                    {vc.allowedCategories.map((cat) => (
                      <span key={cat} className="bg-slate-800 text-slate-300 px-1.5 py-0.5 rounded text-[10px]">
                        {cat}
                      </span>
                    ))}
                  </div>
                  <div className="text-slate-500 text-[10px] pt-1 border-t border-slate-900 mt-1">
                    정책: {vc.restrictionDescription}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
