import React, { useState } from 'react';
import { useFinancialStore } from '../../store/useFinancialStore';
import { WifiOff, Wifi, Smartphone, CheckCircle2, RefreshCw, ShieldCheck, Lock, AlertTriangle } from 'lucide-react';

export const OfflinePaymentsView: React.FC = () => {
  const { isOffline, toggleOfflineMode, processOfflineSync } = useFinancialStore();

  const [offlineBalance, setOfflineBalance] = useState<number>(350000);
  const [payAmount, setPayAmount] = useState<number>(15000);
  const [offlineTxsCount, setOfflineTxsCount] = useState<number>(0);
  const [syncNotice, setSyncNotice] = useState<string | null>(null);

  const handleOfflinePay = () => {
    if (offlineBalance < payAmount) {
      setSyncNotice('오프라인 지갑 잔액이 부족합니다.');
      setTimeout(() => setSyncNotice(null), 3000);
      return;
    }
    setOfflineBalance((prev) => prev - payAmount);
    setOfflineTxsCount((prev) => prev + 1);
    setSyncNotice(`[오프라인 결제 완료] NFC 단말 간 차감 완료! (남은 오프라인 한도: ₩${(offlineBalance - payAmount).toLocaleString()}원)`);
    setTimeout(() => setSyncNotice(null), 4000);
  };

  const handleOnlineSync = () => {
    processOfflineSync('WAL-USER-001', payAmount * offlineTxsCount);
    setOfflineTxsCount(0);
    setSyncNotice(`[온라인 원장 재동기화 완료] 오프라인 거래 ${offlineTxsCount}건이 중앙 통합원장에 즉시 반영되었습니다.`);
    setTimeout(() => setSyncNotice(null), 5000);
  };

  return (
    <div className="p-6 space-y-6 text-slate-100">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <WifiOff className="w-6 h-6 text-emerald-400" />
            <h2 className="text-xl font-extrabold text-white tracking-tight">
              오프라인 결제 연구실 (Offline Payment Lab)
            </h2>
            <span className="bg-emerald-950 text-emerald-300 text-xs font-mono font-bold px-2 py-0.5 rounded border border-emerald-800">
              SECURE ENCLAVE D2D
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            통신 망 장애 시에도 기기 간(Device-to-Device) 하드웨어 보안 영역(TEE/SE) 기반 이중지급 방지 결제 및 재동기화
          </p>
        </div>

        {/* Connectivity Toggle */}
        <button
          onClick={toggleOfflineMode}
          className={`px-4 py-2 rounded-lg font-bold text-xs font-mono flex items-center gap-2 border transition ${
            isOffline
              ? 'bg-amber-950 text-amber-300 border-amber-700 shadow-sm'
              : 'bg-emerald-950 text-emerald-300 border-emerald-700'
          }`}
        >
          {isOffline ? <WifiOff className="w-4 h-4 text-amber-400" /> : <Wifi className="w-4 h-4 text-emerald-400" />}
          <span>네트워크 상태: {isOffline ? 'OFFLINE (통신 단절)' : 'ONLINE (원장 연결)'}</span>
        </button>
      </div>

      {syncNotice && (
        <div className="bg-emerald-950/90 border border-emerald-700 text-emerald-200 px-4 py-2.5 rounded-md text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{syncNotice}</span>
        </div>
      )}

      {/* Simulator Interface */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Device A (Payer) */}
        <div className="bg-slate-950 border border-slate-800 p-5 rounded-lg space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div className="flex items-center gap-2">
              <Smartphone className="w-5 h-5 text-emerald-400" />
              <h3 className="text-sm font-bold text-white">구매자 스마트폰 (Secure Element)</h3>
            </div>
            <span className="text-[10px] font-mono text-slate-400">SE HW-LOCK</span>
          </div>

          <div className="bg-slate-900 p-4 rounded border border-slate-800 space-y-2 text-xs font-mono">
            <div className="flex justify-between">
              <span className="text-slate-400">오프라인 가용 잔액:</span>
              <span className="text-emerald-400 font-bold">₩{offlineBalance.toLocaleString()}원</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">미동기화 오프라인 결제:</span>
              <span className="text-amber-400 font-bold">{offlineTxsCount} 건</span>
            </div>
          </div>

          <div className="space-y-2 text-xs">
            <label className="block text-slate-400">오프라인 시뮬레이션 결제액</label>
            <input
              type="number"
              value={payAmount}
              onChange={(e) => setPayAmount(Number(e.target.value))}
              className="w-full bg-slate-900 border border-slate-700 text-white rounded p-2 text-xs font-mono font-bold"
            />

            <button
              onClick={handleOfflinePay}
              className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2.5 px-4 rounded text-xs shadow-md transition flex items-center justify-center gap-1.5"
            >
              <WifiOff className="w-4 h-4" />
              기기 간 NFC 오프라인 결제 실행 (₩{payAmount.toLocaleString()})
            </button>
          </div>
        </div>

        {/* Resync Engine Status */}
        <div className="bg-slate-950 border border-slate-800 p-5 rounded-lg space-y-4">
          <h3 className="text-sm font-bold text-slate-200 border-b border-slate-800 pb-2 flex items-center gap-2">
            <RefreshCw className="w-4 h-4 text-blue-400" />
            온라인 복귀 시 통합원장 자동 재동기화 엔진
          </h3>

          <div className="bg-slate-900 p-4 rounded border border-slate-800 space-y-2 text-xs font-mono text-slate-300">
            <div className="flex justify-between">
              <span className="text-slate-400">네트워크 수신 상태:</span>
              <span className={isOffline ? 'text-amber-400 font-bold' : 'text-emerald-400 font-bold'}>
                {isOffline ? '대기 중 (OFFLINE)' : '연결됨 (ONLINE)'}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">이중지급 검증 암호 서명:</span>
              <span className="text-indigo-400 font-bold">HMAC-SHA256 OK</span>
            </div>
          </div>

          <button
            disabled={isOffline || offlineTxsCount === 0}
            onClick={handleOnlineSync}
            className={`w-full font-bold py-2.5 px-4 rounded text-xs shadow-md transition flex items-center justify-center gap-1.5 ${
              isOffline || offlineTxsCount === 0
                ? 'bg-slate-900 text-slate-600 border border-slate-800 cursor-not-allowed'
                : 'bg-blue-600 hover:bg-blue-500 text-white'
            }`}
          >
            <RefreshCw className="w-4 h-4" />
            원장 재동기화 및 서명 검증 실행
          </button>
        </div>
      </div>
    </div>
  );
};
