import React, { useState } from 'react';
import { useFinancialStore } from '../../store/useFinancialStore';
import { FlaskConical, Play, CheckCircle2, Copy, ArrowRight, Activity, Zap } from 'lucide-react';

export const ResearchLabView: React.FC = () => {
  const { stepSimulation, simTime } = useFinancialStore();
  const [labStatus, setLabStatus] = useState<string | null>(null);

  const handleRunSandboxExperiment = () => {
    stepSimulation();
    setLabStatus(`[연구실 실험 완료] 디지털 통화 유통 가상 시뮬레이션 24시간 가속 완료! (${simTime})`);
    setTimeout(() => setLabStatus(null), 4000);
  };

  return (
    <div className="p-6 space-y-6 text-slate-100">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <FlaskConical className="w-6 h-6 text-blue-400" />
            <h2 className="text-xl font-extrabold text-white tracking-tight">
              디지털 원 연구실 및 샌드박스 (Digital Won Research Lab)
            </h2>
            <span className="bg-blue-950 text-blue-300 text-xs font-mono font-bold px-2 py-0.5 rounded border border-blue-800">
              SYNTHETIC SANDBOX
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            가상 화폐 경제 모델을 복제하여 가상 정책 충격(Policy Shock) 실험 및 사전 영향 검증
          </p>
        </div>
      </div>

      {labStatus && (
        <div className="bg-emerald-950/90 border border-emerald-700 text-emerald-200 px-4 py-2.5 rounded-md text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{labStatus}</span>
        </div>
      )}

      <div className="bg-slate-950 border border-slate-800 p-5 rounded-lg space-y-4">
        <div className="flex justify-between items-center border-b border-slate-800 pb-2">
          <h3 className="text-sm font-bold text-white">가상 화폐 경제 복제 및 24시간 가속 실험</h3>
          <button
            onClick={handleRunSandboxExperiment}
            className="bg-blue-600 hover:bg-blue-500 text-white font-bold px-4 py-2 rounded text-xs flex items-center gap-1.5 shadow-md"
          >
            <Play className="w-4 h-4" />
            시뮬레이션 가속 가동
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
          <div className="bg-slate-900 p-4 rounded border border-slate-800 space-y-2">
            <h4 className="text-slate-300 font-bold border-b border-slate-800 pb-1">실험 전 베이스라인 (BEFORE)</h4>
            <div className="flex justify-between">
              <span className="text-slate-400">기관 CBDC 발행액:</span>
              <span className="text-white">₩8.42조</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">예금 토큰 유통액:</span>
              <span className="text-white">₩5.71조</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">평균 결제 완결성:</span>
              <span className="text-white">0.38초</span>
            </div>
          </div>

          <div className="bg-slate-900 p-4 rounded border border-slate-800 space-y-2">
            <h4 className="text-indigo-400 font-bold border-b border-slate-800 pb-1">실험 후 시뮬레이션 결과 (AFTER)</h4>
            <div className="flex justify-between">
              <span className="text-slate-400">예측 유통 총량:</span>
              <span className="text-emerald-400 font-bold">₩14.28조 (+0.15조)</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">예상 TPS 처리량:</span>
              <span className="text-emerald-400 font-bold">4,950 TPS</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">시스템 연쇄 교착 위험:</span>
              <span className="text-emerald-400 font-bold">0.00% (정상)</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
