import React, { useState } from 'react';
import { useFinancialStore } from '../../store/useFinancialStore';
import { Globe2, ArrowRightLeft, CheckCircle2, ShieldCheck, RefreshCw } from 'lucide-react';

export const CrossBorderView: React.FC = () => {
  const { executePayment, simTime } = useFinancialStore();

  const [fromCurrency, setFromCurrency] = useState<string>('KRW');
  const [toCurrency, setToCurrency] = useState<string>('USD');
  const [amountKrw, setAmountKrw] = useState<number>(1000000000); // ₩10억
  const [crossNotice, setCrossNotice] = useState<string | null>(null);

  const fxRates: Record<string, number> = {
    USD: 1335.50,
    EUR: 1480.20,
    JPY: 9.25,
    SGD: 1020.10
  };

  const convertedForeign = (amountKrw / (fxRates[toCurrency] || 1335.50)).toFixed(2);

  const handleExecuteCrossBorder = () => {
    executePayment({
      senderWalletId: 'WAL-BANK-001',
      receiverWalletId: 'WAL-BANK-002',
      amount: amountKrw,
      paymentMethod: 'CROSS_BORDER',
      memo: `국가간 mCBDC 결제: KRW → ${toCurrency}`
    });

    setCrossNotice(`[국가간 mCBDC 정산 완료] ₩${(amountKrw / 100000000).toLocaleString()}억원 → ${toCurrency} ${Number(convertedForeign).toLocaleString()} 환전 정산 완결! (${simTime})`);
    setTimeout(() => setCrossNotice(null), 5000);
  };

  return (
    <div className="p-6 space-y-6 text-slate-100">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <Globe2 className="w-6 h-6 text-sky-400" />
            <h2 className="text-xl font-extrabold text-white tracking-tight">
              국가간 디지털화폐 결제망 (mCBDC Cross-Border FX Engine)
            </h2>
            <span className="bg-sky-950 text-sky-300 text-xs font-mono font-bold px-2 py-0.5 rounded border border-sky-800">
              MULTI-CBDC BRIDGE
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            한국은행, 미국 연준(Fed), ECB, BOJ, MAS 간의 다자간 디지털화폐(mCBDC) 실시간 외환 동시결제(PVP)
          </p>
        </div>
      </div>

      {crossNotice && (
        <div className="bg-emerald-950/90 border border-emerald-700 text-emerald-200 px-4 py-2.5 rounded-md text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{crossNotice}</span>
        </div>
      )}

      {/* FX Rates Ticker */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
        <div className="bg-slate-950 border border-slate-800 p-3 rounded-lg">
          <span className="text-slate-400 block">USD / KRW</span>
          <span className="text-white font-bold text-sm">₩1,335.50</span>
        </div>
        <div className="bg-slate-950 border border-slate-800 p-3 rounded-lg">
          <span className="text-slate-400 block">EUR / KRW</span>
          <span className="text-white font-bold text-sm">₩1,480.20</span>
        </div>
        <div className="bg-slate-950 border border-slate-800 p-3 rounded-lg">
          <span className="text-slate-400 block">JPY / KRW (100엔)</span>
          <span className="text-white font-bold text-sm">₩925.00</span>
        </div>
        <div className="bg-slate-950 border border-slate-800 p-3 rounded-lg">
          <span className="text-slate-400 block">SGD / KRW</span>
          <span className="text-white font-bold text-sm">₩1,020.10</span>
        </div>
      </div>

      {/* Cross-border FX Execution */}
      <div className="bg-slate-950 border border-slate-800 p-5 rounded-lg space-y-4 max-w-2xl">
        <h3 className="text-sm font-bold text-slate-200 border-b border-slate-800 pb-2 flex items-center gap-2">
          <ArrowRightLeft className="w-4 h-4 text-sky-400" />
          mCBDC 외환 즉시 정산 (PVP) 실행
        </h3>

        <div className="space-y-3 text-xs">
          <div>
            <label className="block text-slate-400 font-medium mb-1">송금 원화 금액 (KRW)</label>
            <input
              type="number"
              step="100000000"
              value={amountKrw}
              onChange={(e) => setAmountKrw(Number(e.target.value))}
              className="w-full bg-slate-900 border border-slate-700 text-white rounded p-2 text-xs font-mono font-bold text-sky-300"
            />
          </div>

          <div>
            <label className="block text-slate-400 font-medium mb-1">수취 통화 (Foreign Currency)</label>
            <select
              value={toCurrency}
              onChange={(e) => setToCurrency(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 text-white rounded p-2 text-xs font-bold"
            >
              <option value="USD">USD (미국 달러 CBDC)</option>
              <option value="EUR">EUR (유럽 중앙은행 CBDC)</option>
              <option value="JPY">JPY (일본은행 CBDC)</option>
              <option value="SGD">SGD (싱가포르 통화청 CBDC)</option>
            </select>
          </div>

          <div className="bg-slate-900 p-3 rounded border border-slate-800 space-y-1 font-mono text-[11px]">
            <div className="flex justify-between">
              <span className="text-slate-400">적용 환율:</span>
              <span className="text-slate-200">1 {toCurrency} = ₩{fxRates[toCurrency]?.toLocaleString()} KRW</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">수취 예상 통화액:</span>
              <span className="text-emerald-400 font-bold text-sm">{toCurrency} ${Number(convertedForeign).toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">결제 방식:</span>
              <span className="text-sky-300">mBridge PVP 원자적 동시 정산 (0.42초)</span>
            </div>
          </div>

          <button
            onClick={handleExecuteCrossBorder}
            className="w-full bg-sky-600 hover:bg-sky-500 text-white font-bold py-2.5 px-4 rounded text-xs shadow-md transition flex items-center justify-center gap-1.5"
          >
            <Globe2 className="w-4 h-4" />
            mCBDC 국가간 외환 동시 정산 실행
          </button>
        </div>
      </div>
    </div>
  );
};
