import React, { useState } from 'react';
import { useFinancialStore } from '../../store/useFinancialStore';
import { Layers, Search, CheckCircle2, ShieldCheck, Lock, Cpu, Server, Key } from 'lucide-react';
import { TokenType } from '../../types';

export const UnifiedLedgerView: React.FC = () => {
  const { transactions, blockHeight, infraNodes, auditRecords } = useFinancialStore();
  const [filterType, setFilterType] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filteredTxs = transactions.filter((tx) => {
    if (filterType !== 'ALL' && tx.tokenType !== filterType) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return (
        tx.txId.toLowerCase().includes(q) ||
        tx.senderName.toLowerCase().includes(q) ||
        tx.receiverName.toLowerCase().includes(q) ||
        tx.auditHash.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="p-6 space-y-6 text-slate-100">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <Layers className="w-6 h-6 text-blue-400" />
            <h2 className="text-xl font-extrabold text-white tracking-tight">
              통합원장 (Unified Ledger Platform)
            </h2>
            <span className="bg-blue-950 text-blue-300 text-xs font-mono font-bold px-2 py-0.5 rounded border border-blue-800">
              PERMISSIONED DLT
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            중앙은행 디지털화폐, 예금 토큰, 디지털 바우처 및 토큰화 증권을 단일 분산 허가형 원장에서 통합 정산
          </p>
        </div>

        <div className="flex items-center gap-2 bg-slate-950 border border-slate-800 px-3 py-1.5 rounded-md text-xs font-mono">
          <Server className="w-4 h-4 text-emerald-400" />
          <span className="text-slate-400">참여 검증노드:</span>
          <span className="text-emerald-400 font-bold">9개 기관 합의 완료</span>
        </div>
      </div>

      {/* Consensus & Ledger Summary Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
        <div className="bg-slate-950 border border-slate-800 p-3.5 rounded-lg">
          <div className="text-slate-400 font-medium">현재 블록 높이</div>
          <div className="text-xl font-extrabold font-mono text-blue-400 mt-0.5">#{blockHeight}</div>
        </div>

        <div className="bg-slate-950 border border-slate-800 p-3.5 rounded-lg">
          <div className="text-slate-400 font-medium">원장 합의 메커니즘</div>
          <div className="text-sm font-bold text-slate-200 mt-1">BFT-DPoS (허가형)</div>
        </div>

        <div className="bg-slate-950 border border-slate-800 p-3.5 rounded-lg">
          <div className="text-slate-400 font-medium">평균 원자적 결제 완결성</div>
          <div className="text-xl font-extrabold font-mono text-emerald-400 mt-0.5">0.38초</div>
        </div>

        <div className="bg-slate-950 border border-slate-800 p-3.5 rounded-lg">
          <div className="text-slate-400 font-medium">암호화 검증 표준</div>
          <div className="text-sm font-bold text-indigo-400 mt-1 font-mono">Ed25519 / ISO 20022</div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-950 border border-slate-800 p-3 rounded-lg text-xs">
        <div className="flex items-center gap-2 overflow-x-auto">
          <span className="text-slate-400 font-semibold shrink-0">토큰 유형 필터:</span>
          {['ALL', 'INSTITUTIONAL_CBDC', 'TOKENIZED_DEPOSIT', 'DIGITAL_VOUCHER', 'TOKENIZED_ASSET'].map((type) => (
            <button
              key={type}
              onClick={() => setFilterType(type)}
              className={`px-2.5 py-1 rounded font-medium transition shrink-0 ${
                filterType === type
                  ? 'bg-blue-600 text-white font-bold'
                  : 'bg-slate-900 text-slate-400 hover:text-white'
              }`}
            >
              {type === 'ALL'
                ? '전체'
                : type === 'INSTITUTIONAL_CBDC'
                ? '기관 CBDC'
                : type === 'TOKENIZED_DEPOSIT'
                ? '예금 토큰'
                : type === 'DIGITAL_VOUCHER'
                ? '디지털 바우처'
                : '토큰자산'}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-2.5" />
          <input
            type="text"
            placeholder="거래 ID, 지갑, 해시 검색..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 text-slate-200 pl-8 pr-3 py-1.5 rounded text-xs focus:ring-1 focus:ring-blue-500"
          />
        </div>
      </div>

      {/* Unified Ledger Explorer Table */}
      <div className="bg-slate-950 border border-slate-800 rounded-lg p-4 space-y-3">
        <h3 className="text-sm font-bold text-slate-200 border-b border-slate-900 pb-2">
          통합원장 원자적 블록 및 거래 기록 (Unified Ledger Transaction Explorer)
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 bg-slate-900/60">
                <th className="py-2.5 px-3">거래 ID</th>
                <th className="py-2.5 px-3">블록</th>
                <th className="py-2.5 px-3">시각</th>
                <th className="py-2.5 px-3">송신자</th>
                <th className="py-2.5 px-3">수취인</th>
                <th className="py-2.5 px-3">토큰 유형</th>
                <th className="py-2.5 px-3 text-right">금액 (KRW)</th>
                <th className="py-2.5 px-3">결제완결성</th>
                <th className="py-2.5 px-3">감사 해시</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-900">
              {filteredTxs.map((tx) => (
                <tr key={tx.txId} className="hover:bg-slate-900/50 transition">
                  <td className="py-3 px-3 font-semibold text-blue-400">{tx.txId}</td>
                  <td className="py-3 px-3 text-slate-400">#{tx.blockHeight}</td>
                  <td className="py-3 px-3 text-slate-400">{tx.timestamp.split(' ')[1]}</td>
                  <td className="py-3 px-3 text-slate-200">{tx.senderName}</td>
                  <td className="py-3 px-3 text-slate-200">{tx.receiverName}</td>
                  <td className="py-3 px-3">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-sans font-bold ${
                      tx.tokenType === 'INSTITUTIONAL_CBDC'
                        ? 'bg-blue-950 text-blue-300 border border-blue-800'
                        : tx.tokenType === 'TOKENIZED_DEPOSIT'
                        ? 'bg-indigo-950 text-indigo-300 border border-indigo-800'
                        : tx.tokenType === 'DIGITAL_VOUCHER'
                        ? 'bg-amber-950 text-amber-300 border border-amber-800'
                        : 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                    }`}>
                      {tx.tokenType === 'INSTITUTIONAL_CBDC'
                        ? '기관 CBDC'
                        : tx.tokenType === 'TOKENIZED_DEPOSIT'
                        ? '예금 토큰'
                        : tx.tokenType === 'DIGITAL_VOUCHER'
                        ? '디지털 바우처'
                        : '토큰자산'}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-right font-bold text-white font-mono-num">
                    ₩{tx.amount.toLocaleString()}
                  </td>
                  <td className="py-3 px-3">
                    <span className="inline-flex items-center gap-1 text-emerald-400 font-sans text-[11px] font-bold">
                      <CheckCircle2 className="w-3.5 h-3.5" /> 완결 ({tx.finalityDurationSec}s)
                    </span>
                  </td>
                  <td className="py-3 px-3 text-slate-500 font-mono text-[10px] truncate max-w-[120px]">
                    {tx.auditHash}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
