import React, { useState } from 'react';
import { useFinancialStore } from '../../store/useFinancialStore';
import { Scale, AlertTriangle, ShieldCheck, TrendingDown, ArrowRightLeft } from 'lucide-react';

export const BankingSystemView: React.FC = () => {
  const { balanceSheets, injectLiquidityShock } = useFinancialStore();
  const [selectedBankId, setSelectedBankId] = useState<string>('BANK-HANKANG');
  const [shockMessage, setShockMessage] = useState<string | null>(null);

  const bankBs = balanceSheets.find((bs) => bs.bankId === selectedBankId) || balanceSheets[0];

  const handleTriggerStressScenario = () => {
    injectLiquidityShock(selectedBankId, 39000000000); // ₩390억 부족
    setShockMessage(`[스트레스 테스트] ${bankBs.bankName} 유동성 충격 시나리오 주입 완료! (유동성 부족 ₩390억원 발생)`);
    setTimeout(() => setShockMessage(null), 5000);
  };

  return (
    <div className="p-6 space-y-6 text-slate-100">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <Scale className="w-6 h-6 text-indigo-400" />
            <h2 className="text-xl font-extrabold text-white tracking-tight">
              시중은행 재무상태표 및 대차대조표 (Bank Balance Sheet Engine)
            </h2>
            <span className="bg-indigo-950 text-indigo-300 text-xs font-mono font-bold px-2 py-0.5 rounded border border-indigo-800">
              DOUBLE ENTRY ACCOUNTING
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            예금 토큰 전환에 따른 시중은행 자산-부채 재구성, BIS 자기자본비율 및 유동성커버리지비율(LCR) 실시간 모니터링
          </p>
        </div>
      </div>

      {shockMessage && (
        <div className="bg-amber-950/90 border border-amber-700 text-amber-200 px-4 py-2.5 rounded-md text-xs font-bold flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
          <span>{shockMessage}</span>
        </div>
      )}

      {/* Bank Selector & Stress Control */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-950 border border-slate-800 p-4 rounded-lg">
        <div className="flex items-center gap-3">
          <span className="text-xs font-bold text-slate-300">분석 대상 은행:</span>
          <select
            value={selectedBankId}
            onChange={(e) => setSelectedBankId(e.target.value)}
            className="bg-slate-900 border border-slate-700 text-white rounded p-2 text-xs font-bold"
          >
            {balanceSheets.map((bs) => (
              <option key={bs.bankId} value={bs.bankId}>
                {bs.bankName}
              </option>
            ))}
          </select>
        </div>

        <button
          onClick={handleTriggerStressScenario}
          className="bg-amber-600 hover:bg-amber-500 text-white font-bold px-3 py-2 rounded text-xs flex items-center gap-1.5 shadow-sm"
        >
          <AlertTriangle className="w-3.5 h-3.5" />
          유동성 스트레스 시나리오 주입
        </button>
      </div>

      {/* Double Entry Balance Sheet Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Assets Panel */}
        <div className="bg-slate-950 border border-slate-800 p-5 rounded-lg space-y-3">
          <div className="flex justify-between items-center border-b border-slate-800 pb-2">
            <h3 className="text-sm font-bold text-blue-400">자산 (ASSETS)</h3>
            <span className="text-xs font-mono font-bold text-white">
              총 자산: ₩{(bankBs.assets.totalAssets / 1000000000000).toFixed(2)}조
            </span>
          </div>

          <div className="space-y-2 text-xs font-mono">
            <div className="flex justify-between p-2 rounded bg-slate-900">
              <span className="text-slate-300">중앙은행 CBDC 지급준비금:</span>
              <span className="font-bold text-blue-300">₩{(bankBs.assets.cbdcReserves / 1000000000000).toFixed(2)}조</span>
            </div>
            <div className="flex justify-between p-2 rounded bg-slate-900">
              <span className="text-slate-300">한은 당좌예치금:</span>
              <span className="font-bold text-slate-200">₩{(bankBs.assets.commercialDepositsAtBok / 1000000000000).toFixed(2)}조</span>
            </div>
            <div className="flex justify-between p-2 rounded bg-slate-900">
              <span className="text-slate-300">원화 대출금:</span>
              <span className="font-bold text-slate-200">₩{(bankBs.assets.loans / 1000000000000).toFixed(2)}조</span>
            </div>
            <div className="flex justify-between p-2 rounded bg-slate-900">
              <span className="text-slate-300">유가증권 (국채/통안채):</span>
              <span className="font-bold text-slate-200">₩{(bankBs.assets.securities / 1000000000000).toFixed(2)}조</span>
            </div>
            <div className="flex justify-between p-2 rounded bg-slate-900">
              <span className="text-slate-300">기타 자산:</span>
              <span className="font-bold text-slate-200">₩{(bankBs.assets.otherAssets / 1000000000000).toFixed(2)}조</span>
            </div>
          </div>
        </div>

        {/* Liabilities & Equity Panel */}
        <div className="bg-slate-950 border border-slate-800 p-5 rounded-lg space-y-3">
          <div className="flex justify-between items-center border-b border-slate-800 pb-2">
            <h3 className="text-sm font-bold text-indigo-400">부채 및 자기자본 (LIABILITIES & EQUITY)</h3>
            <span className="text-xs font-mono font-bold text-white">
              총합: ₩{((bankBs.liabilities.totalLiabilities + bankBs.equity.totalEquity) / 1000000000000).toFixed(2)}조
            </span>
          </div>

          <div className="space-y-2 text-xs font-mono">
            <div className="flex justify-between p-2 rounded bg-slate-900">
              <span className="text-slate-300">고객 원화예금:</span>
              <span className="font-bold text-slate-200">₩{(bankBs.liabilities.customerDeposits / 1000000000000).toFixed(2)}조</span>
            </div>
            <div className="flex justify-between p-2 rounded bg-slate-900 border border-indigo-800/60">
              <span className="text-indigo-300 font-bold">발행 예금 토큰:</span>
              <span className="font-bold text-indigo-400">₩{(bankBs.liabilities.tokenizedDepositsIssued / 1000000000000).toFixed(2)}조</span>
            </div>
            <div className="flex justify-between p-2 rounded bg-slate-900">
              <span className="text-slate-300">중앙은행 차입금:</span>
              <span className="font-bold text-slate-200">₩{(bankBs.liabilities.centralBankBorrowings / 1000000000000).toFixed(2)}조</span>
            </div>
            <div className="flex justify-between p-2 rounded bg-slate-900">
              <span className="text-slate-300">자기자본 (BIS 반영):</span>
              <span className="font-bold text-emerald-400">₩{(bankBs.equity.totalEquity / 1000000000000).toFixed(2)}조</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
