import React from 'react';
import { useFinancialStore } from '../../store/useFinancialStore';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import {
  Activity,
  CheckCircle2,
  TrendingUp,
  CreditCard,
  Building2,
  Layers,
  Clock,
  ShieldCheck,
  Zap,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';

export const DashboardView: React.FC = () => {
  const {
    institutions,
    transactions,
    simTime,
    blockHeight,
    infraNodes,
    wallets,
    balanceSheets
  } = useFinancialStore();

  // Synthetic time-series chart data derived from state
  const timeSeriesData = [
    { time: '09:00', cbdc: 8.20, depositToken: 5.20, volume: 1820, tps: 4200 },
    { time: '09:10', cbdc: 8.25, depositToken: 5.35, volume: 2100, tps: 4450 },
    { time: '09:20', cbdc: 8.30, depositToken: 5.48, volume: 2280, tps: 4610 },
    { time: '09:30', cbdc: 8.38, depositToken: 5.60, volume: 2390, tps: 4720 },
    { time: '09:40', cbdc: 8.42, depositToken: 5.71, volume: 2481, tps: 4820 }
  ];

  const bankDepositDistribution = [
    { name: '한강은행', value: 1.75, color: '#3b82f6' },
    { name: '서울국민은행', value: 1.82, color: '#6366f1' },
    { name: '대한민국상업', value: 1.05, color: '#8b5cf6' },
    { name: '기타 4개 은행', value: 1.09, color: '#0ea5e9' }
  ];

  const totalCbdcTrillion = (
    institutions.reduce((acc, i) => acc + i.cbdcBalance, 0) / 1000000000000
  ).toFixed(2);

  return (
    <div className="p-6 space-y-6 text-slate-100">
      {/* Header Section */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-extrabold text-white tracking-tight">
              디지털 원 통합 관제센터
            </h2>
            <span className="bg-emerald-950 text-emerald-400 text-xs font-mono font-bold px-2 py-0.5 rounded border border-emerald-800">
              LIVE SYSTEM
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            한국형 디지털화폐·토큰화 금융 인프라 실시간 통합 모니터링
          </p>
        </div>

        {/* Top Status Strip */}
        <div className="flex flex-wrap items-center gap-3 bg-slate-950 border border-slate-800 px-3.5 py-2 rounded-lg text-xs font-mono">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span className="text-slate-400">시스템:</span>
            <span className="font-bold text-emerald-400">정상</span>
          </div>
          <span className="text-slate-700">|</span>
          <div className="flex items-center gap-1.5">
            <span className="text-slate-400">통합원장:</span>
            <span className="font-bold text-blue-400">동기화 완료</span>
          </div>
          <span className="text-slate-700">|</span>
          <div className="flex items-center gap-1.5">
            <span className="text-slate-400">결제망:</span>
            <span className="font-bold text-emerald-400">정상</span>
          </div>
          <span className="text-slate-700">|</span>
          <div className="flex items-center gap-1.5">
            <span className="text-slate-400">유동성:</span>
            <span className="font-bold text-sky-400">안정</span>
          </div>
          <span className="text-slate-700">|</span>
          <div className="flex items-center gap-1.5">
            <span className="text-slate-400">보안:</span>
            <span className="font-bold text-indigo-400">정상</span>
          </div>
        </div>
      </div>

      {/* Main Metric Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-950 border border-slate-800 p-4 rounded-lg shadow-sm">
          <div className="flex items-center justify-between text-xs text-slate-400 font-medium mb-1">
            <span>기관용 디지털화폐</span>
            <Building2 className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl font-extrabold font-mono-num text-white tracking-tight">
            ₩8.42조
          </div>
          <div className="flex items-center gap-1.5 text-[11px] text-emerald-400 mt-2">
            <ArrowUpRight className="w-3.5 h-3.5" />
            <span>전일 대비 +₩1,200억원 (발행 연계)</span>
          </div>
        </div>

        <div className="bg-slate-950 border border-slate-800 p-4 rounded-lg shadow-sm">
          <div className="flex items-center justify-between text-xs text-slate-400 font-medium mb-1">
            <span>예금 토큰 유통량</span>
            <CreditCard className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="text-2xl font-extrabold font-mono-num text-white tracking-tight">
            ₩5.71조
          </div>
          <div className="flex items-center gap-1.5 text-[11px] text-emerald-400 mt-2">
            <ArrowUpRight className="w-3.5 h-3.5" />
            <span>시중은행 7개사 예금 전환 가속</span>
          </div>
        </div>

        <div className="bg-slate-950 border border-slate-800 p-4 rounded-lg shadow-sm">
          <div className="flex items-center justify-between text-xs text-slate-400 font-medium mb-1">
            <span>통합원장 처리속도 / 완결성</span>
            <Zap className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-extrabold font-mono-num text-white tracking-tight">
            4,820 TPS
          </div>
          <div className="flex items-center gap-1.5 text-[11px] text-sky-400 mt-2">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>평균 결제완결성: 0.38초</span>
          </div>
        </div>

        <div className="bg-slate-950 border border-slate-800 p-4 rounded-lg shadow-sm">
          <div className="flex items-center justify-between text-xs text-slate-400 font-medium mb-1">
            <span>일일 총 결제금액</span>
            <Activity className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-extrabold font-mono-num text-white tracking-tight">
            ₩18.7조
          </div>
          <div className="flex items-center gap-1.5 text-[11px] text-slate-400 mt-2">
            <span>일일 거래건수: 2,481만 건</span>
          </div>
        </div>
      </div>

      {/* Main Analytical Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chart 1: Digital Money Circulation Trend */}
        <div className="lg:col-span-2 bg-slate-950 border border-slate-800 p-4 rounded-lg space-y-3">
          <div className="flex items-center justify-between border-b border-slate-900 pb-2">
            <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-blue-400" />
              기관용 디지털화폐 및 예금 토큰 유통 추이 (조 원)
            </h3>
            <span className="text-[11px] font-mono text-slate-500">실시간 스냅샷</span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={timeSeriesData}>
                <defs>
                  <linearGradient id="cbdcGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="depositGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="time" stroke="#64748b" fontSize={11} />
                <YAxis stroke="#64748b" fontSize={11} domain={[4, 10]} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '6px', fontSize: '12px' }}
                />
                <Area type="monotone" dataKey="cbdc" name="기관용 디지털화폐 (조)" stroke="#3b82f6" fillOpacity={1} fill="url(#cbdcGrad)" />
                <Area type="monotone" dataKey="depositToken" name="예금 토큰 (조)" stroke="#6366f1" fillOpacity={1} fill="url(#depositGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Bank Deposit Token Distribution */}
        <div className="bg-slate-950 border border-slate-800 p-4 rounded-lg space-y-3">
          <div className="border-b border-slate-900 pb-2">
            <h3 className="text-sm font-bold text-slate-200">은행별 예금 토큰 점유율</h3>
            <p className="text-[11px] text-slate-400">발행 예금 토큰 총 ₩5.71조</p>
          </div>

          <div className="h-48 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={bankDepositDistribution}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={75}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {bankDepositDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '12px' }}
                  formatter={(value) => [`₩${value}조`, '발행량']}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            {bankDepositDistribution.map((item) => (
              <div key={item.name} className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }}></span>
                <span className="text-slate-300 truncate">{item.name}:</span>
                <span className="font-mono-num font-bold text-white">₩{item.value}조</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Live Transaction Ledger Stream Table */}
      <div className="bg-slate-950 border border-slate-800 rounded-lg p-4 space-y-3">
        <div className="flex items-center justify-between border-b border-slate-900 pb-3">
          <div>
            <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
              <Layers className="w-4 h-4 text-blue-400" />
              통합원장 실시간 결제 스트림
            </h3>
            <p className="text-[11px] text-slate-400">
              분산 허가형 노드 기반 실시간 검증 및 원자적 완결성 반영
            </p>
          </div>
          <span className="text-xs font-mono text-slate-400">
            블록 높이: <strong className="text-blue-400">#{blockHeight}</strong>
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 bg-slate-900/60">
                <th className="py-2 px-3">거래 ID</th>
                <th className="py-2 px-3">시각</th>
                <th className="py-2 px-3">송신자</th>
                <th className="py-2 px-3">수취인</th>
                <th className="py-2 px-3">토큰 유형</th>
                <th className="py-2 px-3 text-right">금액 (KRW)</th>
                <th className="py-2 px-3">결제 방식</th>
                <th className="py-2 px-3">상태</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-900">
              {transactions.slice(0, 6).map((tx) => (
                <tr key={tx.txId} className="hover:bg-slate-900/50 transition">
                  <td className="py-2.5 px-3 font-semibold text-blue-400">{tx.txId}</td>
                  <td className="py-2.5 px-3 text-slate-400">{tx.timestamp.split(' ')[1]}</td>
                  <td className="py-2.5 px-3 text-slate-200">{tx.senderName}</td>
                  <td className="py-2.5 px-3 text-slate-200">{tx.receiverName}</td>
                  <td className="py-2.5 px-3">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-sans font-bold ${
                      tx.tokenType === 'INSTITUTIONAL_CBDC'
                        ? 'bg-blue-950 text-blue-300 border border-blue-800'
                        : tx.tokenType === 'TOKENIZED_DEPOSIT'
                        ? 'bg-indigo-950 text-indigo-300 border border-indigo-800'
                        : tx.tokenType === 'DIGITAL_VOUCHER'
                        ? 'bg-amber-950 text-amber-300 border border-amber-800'
                        : 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                    }`}>
                      {tx.tokenType === 'INSTITUTIONAL_CBDC'
                        ? '기관 CBDC'
                        : tx.tokenType === 'TOKENIZED_DEPOSIT'
                        ? '예금 토큰'
                        : tx.tokenType === 'DIGITAL_VOUCHER'
                        ? '디지털 바우처'
                        : '토큰자산'}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-right font-bold text-white font-mono-num">
                    ₩{tx.amount.toLocaleString()}
                  </td>
                  <td className="py-2.5 px-3 text-slate-300 font-sans">{tx.paymentMethod}</td>
                  <td className="py-2.5 px-3">
                    <span className="inline-flex items-center gap-1 text-emerald-400 font-sans text-[11px] font-bold">
                      <CheckCircle2 className="w-3.5 h-3.5" /> 승인완결 ({tx.finalityDurationSec}초)
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
