import React, { useState } from 'react';
import { useFinancialStore } from '../../store/useFinancialStore';
import { FileCode, Play, CheckCircle2, Clock, ShieldCheck, ArrowRight, Activity, Terminal } from 'lucide-react';

export const SmartContractsView: React.FC = () => {
  const { smartContracts, triggerSmartContract, simTime } = useFinancialStore();
  const [activeContractId, setActiveContractId] = useState<string>('SC-DVP-BOND-2026');
  const [logNotice, setLogNotice] = useState<string | null>(null);

  const contract = smartContracts.find((sc) => sc.id === activeContractId) || smartContracts[0];

  const handleTriggerContract = () => {
    triggerSmartContract(activeContractId);
    setLogNotice(`스마트계약 [${contract?.title}] 자동 실행 조건 충족 → 원자적 정산 완료! (${simTime})`);
    setTimeout(() => setLogNotice(null), 4000);
  };

  return (
    <div className="p-6 space-y-6 text-slate-100">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <FileCode className="w-6 h-6 text-indigo-400" />
            <h2 className="text-xl font-extrabold text-white tracking-tight">
              스마트계약 실행환경 (Smart Contract Execution Engine)
            </h2>
            <span className="bg-indigo-950 text-indigo-300 text-xs font-mono font-bold px-2 py-0.5 rounded border border-indigo-800">
              DETERMINISTIC VM
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            엔터프라이즈 통합원장 상의 자동 정산, 에스크로, DVP, 조건부 정책 지급 스마트계약 가상머신
          </p>
        </div>
      </div>

      {logNotice && (
        <div className="bg-emerald-950/90 border border-emerald-700 text-emerald-200 px-4 py-2.5 rounded-md text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{logNotice}</span>
        </div>
      )}

      {/* Contract Selector & Execution Tracer */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Contracts List */}
        <div className="bg-slate-950 border border-slate-800 p-5 rounded-lg space-y-4">
          <h3 className="text-sm font-bold text-slate-200 border-b border-slate-800 pb-2">
            배포된 스마트계약 목록
          </h3>

          <div className="space-y-2">
            {smartContracts.map((sc) => (
              <button
                key={sc.id}
                onClick={() => setActiveContractId(sc.id)}
                className={`w-full text-left p-3 rounded border text-xs transition ${
                  activeContractId === sc.id
                    ? 'bg-indigo-950/80 border-indigo-500 text-white font-bold'
                    : 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <div className="flex justify-between items-center mb-1">
                  <span className="font-mono text-[10px] text-indigo-300">{sc.id}</span>
                  <span className={`px-1.5 py-0.5 rounded text-[9px] ${
                    sc.status === 'COMPLETED' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-blue-950 text-blue-400'
                  }`}>
                    {sc.status}
                  </span>
                </div>
                <div className="text-xs font-bold text-slate-100">{sc.title}</div>
                <div className="text-[11px] text-slate-400 mt-1 truncate">{sc.conditionDescription}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Right: Step-by-Step Execution Pipeline Tracer */}
        {contract && (
          <div className="lg:col-span-2 bg-slate-950 border border-slate-800 p-5 rounded-lg space-y-4">
            <div className="flex justify-between items-center border-b border-slate-800 pb-2">
              <div>
                <h3 className="text-sm font-bold text-white">{contract.title}</h3>
                <p className="text-[11px] text-slate-400 font-mono">생성주체: {contract.creatorName}</p>
              </div>

              <button
                onClick={handleTriggerContract}
                className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold px-3 py-1.5 rounded text-xs flex items-center gap-1.5 shadow-sm"
              >
                <Play className="w-3.5 h-3.5" />
                계약 조건 충족 수동 실행
              </button>
            </div>

            {/* Condition Description Banner */}
            <div className="bg-slate-900 p-3 rounded border border-slate-800 text-xs font-mono text-slate-300">
              <strong className="text-indigo-400">계약 조건 정의:</strong> {contract.conditionDescription}
            </div>

            {/* Step-by-step Pipeline */}
            <div className="space-y-3 pt-2">
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                실행 파이프라인 단계별 추적 (Execution Pipeline Tracer)
              </h4>

              <div className="space-y-2 font-mono text-xs">
                {contract.executionSteps.map((step, idx) => (
                  <div
                    key={idx}
                    className={`p-3 rounded border flex items-center justify-between ${
                      step.status === 'COMPLETED'
                        ? 'bg-emerald-950/40 border-emerald-800/80 text-emerald-200'
                        : step.status === 'IN_PROGRESS'
                        ? 'bg-blue-950/40 border-blue-800/80 text-blue-200'
                        : 'bg-slate-900 border-slate-800 text-slate-500'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className={`w-4 h-4 ${step.status === 'COMPLETED' ? 'text-emerald-400' : 'text-slate-600'}`} />
                      <span className="font-bold">{step.stepName}</span>
                    </div>
                    <span className="text-[11px] font-mono">
                      {step.timestamp || '대기 중'}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
