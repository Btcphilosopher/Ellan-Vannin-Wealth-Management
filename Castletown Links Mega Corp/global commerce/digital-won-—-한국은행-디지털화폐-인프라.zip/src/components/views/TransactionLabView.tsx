import React, { useState } from 'react';
import { useFinancialStore } from '../../store/useFinancialStore';
import { Play, CheckCircle2, ArrowRight, Activity, Zap, ShieldCheck } from 'lucide-react';
import { TokenType, PaymentMethod } from '../../types';

export const TransactionLabView: React.FC = () => {
  const { wallets, executePayment, simTime } = useFinancialStore();

  const [senderId, setSenderId] = useState<string>('WAL-USER-001');
  const [receiverId, setReceiverId] = useState<string>('WAL-MERCHANT-001');
  const [tokenType, setTokenType] = useState<TokenType>('TOKENIZED_DEPOSIT');
  const [method, setMethod] = useState<PaymentMethod>('QR');
  const [amount, setAmount] = useState<number>(125000);
  const [memo, setMemo] = useState<string>('거래 시뮬레이터 실험 결제');
  const [resNotice, setResNotice] = useState<string | null>(null);

  const handleRunLabTx = () => {
    const result = executePayment({
      senderWalletId: senderId,
      receiverWalletId: receiverId,
      amount,
      tokenType,
      paymentMethod: method,
      memo
    });

    if (result.success) {
      setResNotice(`[시뮬레이터 성공] 거래 ID: ${result.txId} 생성 및 원자적 정산 완료! (${simTime})`);
    } else {
      setResNotice(`[오류] ${result.message}`);
    }
    setTimeout(() => setResNotice(null), 5000);
  };

  return (
    <div className="p-6 space-y-6 text-slate-100">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <Activity className="w-6 h-6 text-blue-400" />
            <h2 className="text-xl font-extrabold text-white tracking-tight">
              통합 거래 시뮬레이터 (Universal Transaction Lab)
            </h2>
            <span className="bg-blue-950 text-blue-300 text-xs font-mono font-bold px-2 py-0.5 rounded border border-blue-800">
              TRANSACTION GENERATOR
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            임의의 송수신 주체, 토큰 유형 및 결제 수단을 조합하여 통합원장 정산 동작 테스트
          </p>
        </div>
      </div>

      {resNotice && (
        <div className="bg-emerald-950/90 border border-emerald-700 text-emerald-200 px-4 py-2.5 rounded-md text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{resNotice}</span>
        </div>
      )}

      {/* Lab Generator Form */}
      <div className="bg-slate-950 border border-slate-800 p-5 rounded-lg space-y-4 max-w-3xl">
        <h3 className="text-sm font-bold text-slate-200 border-b border-slate-800 pb-2 flex items-center gap-2">
          <Play className="w-4 h-4 text-blue-400" />
          가상 거래 파라미터 주입
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <div>
            <label className="block text-slate-400 mb-1">송신 지갑 (Sender)</label>
            <select
              value={senderId}
              onChange={(e) => setSenderId(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 text-white rounded p-2 text-xs"
            >
              {wallets.map((w) => (
                <option key={w.id} value={w.id}>
                  {w.ownerName} ({w.ownerType})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-slate-400 mb-1">수취 지갑 (Receiver)</label>
            <select
              value={receiverId}
              onChange={(e) => setReceiverId(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 text-white rounded p-2 text-xs"
            >
              {wallets.map((w) => (
                <option key={w.id} value={w.id}>
                  {w.ownerName} ({w.ownerType})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-slate-400 mb-1">토큰 유형 (Token Type)</label>
            <select
              value={tokenType}
              onChange={(e) => setTokenType(e.target.value as TokenType)}
              className="w-full bg-slate-900 border border-slate-700 text-white rounded p-2 text-xs"
            >
              <option value="TOKENIZED_DEPOSIT">예금 토큰 (Tokenized Deposit)</option>
              <option value="INSTITUTIONAL_CBDC">기관용 CBDC (Institutional CBDC)</option>
              <option value="DIGITAL_VOUCHER">디지털 바우처 (Digital Voucher)</option>
              <option value="TOKENIZED_ASSET">토큰화 자산 (Tokenized Asset)</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-400 mb-1">결제 수단 (Payment Method)</label>
            <select
              value={method}
              onChange={(e) => setMethod(e.target.value as PaymentMethod)}
              className="w-full bg-slate-900 border border-slate-700 text-white rounded p-2 text-xs"
            >
              <option value="QR">가맹점 QR 스캔</option>
              <option value="NFC">NFC 비접촉 터치</option>
              <option value="MOBILE">모바일 뱅킹 송금</option>
              <option value="ONLINE">온라인 1-Click</option>
              <option value="AI_AGENT">AI 에이전트 자율</option>
              <option value="CROSS_BORDER">mCBDC 국가간</option>
            </select>
          </div>

          <div className="md:col-span-2">
            <label className="block text-slate-400 mb-1">거래 금액 (KRW)</label>
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(Number(e.target.value))}
              className="w-full bg-slate-900 border border-slate-700 text-white rounded p-2 text-xs font-mono font-bold text-blue-300"
            />
          </div>

          <div className="md:col-span-2">
            <label className="block text-slate-400 mb-1">거래 메모 / 내역적요</label>
            <input
              type="text"
              value={memo}
              onChange={(e) => setMemo(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 text-white rounded p-2 text-xs"
            />
          </div>
        </div>

        <button
          onClick={handleRunLabTx}
          className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-2.5 px-4 rounded text-xs shadow-md transition flex items-center justify-center gap-1.5 mt-2"
        >
          <Play className="w-4 h-4" />
          가상 거래 생성 및 통합원장 즉시 정산
        </button>
      </div>
    </div>
  );
};
