import React, { useState } from 'react';
import { useFinancialStore } from '../../store/useFinancialStore';
import { QrCode, Smartphone, Wifi, Store, Globe, Calendar, Repeat, CheckCircle2, ShieldCheck } from 'lucide-react';

export const KoreanPaymentUxView: React.FC = () => {
  const { wallets, executePayment, simTime } = useFinancialStore();

  const [activeUxMode, setActiveUxMode] = useState<string>('QR');
  const [selectedWalletId, setSelectedWalletId] = useState<string>('WAL-USER-001');
  const [amount, setAmount] = useState<number>(48500);
  const [merchantName, setMerchantName] = useState<string>('서울 디지털 마켓');
  const [scheduledDate, setScheduledDate] = useState<string>('2026-09-25');
  const [notification, setNotification] = useState<string | null>(null);

  const activeWallet = wallets.find((w) => w.id === selectedWalletId);

  const paymentModes = [
    { id: 'QR', label: '가맹점 QR 결제', icon: QrCode, desc: '소상공인 및 가맹점 정적/동적 QR 스캔' },
    { id: 'NFC', label: 'NFC 터치 결제', icon: Wifi, desc: '단말기 비접촉 근거리 무선 통신 결제' },
    { id: 'MOBILE', label: '모바일 뱅킹 송금', icon: Smartphone, desc: '실무 시중은행 앱 연동 즉시 송금' },
    { id: 'ONLINE', label: '온라인 결제창', icon: Globe, desc: '전자상거래 PG 연동 1-Click 승인' },
    { id: 'SCHEDULED', label: '예약 정기 결제', icon: Calendar, desc: '스마트계약 지정일 자동 실행 결제' },
    { id: 'RECURRING', label: '자동 이체 결제', icon: Repeat, desc: '구독 서비스 및 공공요금 주기적 정산' }
  ];

  const handleExecutePayment = () => {
    const result = executePayment({
      senderWalletId: selectedWalletId,
      receiverWalletId: 'WAL-MERCHANT-001',
      amount,
      paymentMethod: activeUxMode as any,
      memo: `한국형 ${activeUxMode} 결제 - ${merchantName}`
    });

    if (result.success) {
      setNotification(`[${activeUxMode}] 결제 완결! ₩${amount.toLocaleString()}원 → ${merchantName} (${simTime})`);
    } else {
      setNotification(`결제 오류: ${result.message}`);
    }
    setTimeout(() => setNotification(null), 5000);
  };

  return (
    <div className="p-6 space-y-6 text-slate-100">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <QrCode className="w-6 h-6 text-blue-400" />
            <h2 className="text-xl font-extrabold text-white tracking-tight">
              한국형 결제 UX (Korean Payment UX Engine)
            </h2>
            <span className="bg-blue-950 text-blue-300 text-xs font-mono font-bold px-2 py-0.5 rounded border border-blue-800">
              K-PAYMENT PROTOCOL
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            대한민국 금융 소비자 및 가맹점 익숙한 결제 경험(QR, NFC, 앱간 송금, 정기이체)을 예금 토큰 인프라에 결합
          </p>
        </div>
      </div>

      {notification && (
        <div className="bg-emerald-950/90 border border-emerald-700 text-emerald-200 px-4 py-2.5 rounded-md text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{notification}</span>
        </div>
      )}

      {/* Payment Modes Grid Selector */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {paymentModes.map((mode) => {
          const Icon = mode.icon;
          const isActive = activeUxMode === mode.id;
          return (
            <button
              key={mode.id}
              onClick={() => setActiveUxMode(mode.id)}
              className={`p-3 rounded-lg border text-left transition ${
                isActive
                  ? 'bg-blue-600/90 border-blue-400 text-white shadow-sm font-bold'
                  : 'bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-900'
              }`}
            >
              <Icon className={`w-5 h-5 mb-2 ${isActive ? 'text-white' : 'text-blue-400'}`} />
              <div className="text-xs font-bold">{mode.label}</div>
              <div className="text-[10px] text-slate-400 mt-1 leading-tight line-clamp-2">{mode.desc}</div>
            </button>
          );
        })}
      </div>

      {/* Mode Execution Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-slate-950 border border-slate-800 p-5 rounded-lg space-y-4">
          <h3 className="text-sm font-bold text-slate-200 border-b border-slate-800 pb-2">
            {activeUxMode} 결제 파라미터 입력
          </h3>

          <div className="space-y-3 text-xs">
            <div>
              <label className="block text-slate-400 font-medium mb-1">결제자 지갑</label>
              <select
                value={selectedWalletId}
                onChange={(e) => setSelectedWalletId(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-white rounded p-2 text-xs"
              >
                {wallets.map((w) => (
                  <option key={w.id} value={w.id}>
                    {w.ownerName} — 가용: ₩{w.availableBalance.toLocaleString()}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-400 font-medium mb-1">가맹점 / 수취인 명칭</label>
              <input
                type="text"
                value={merchantName}
                onChange={(e) => setMerchantName(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-white rounded p-2 text-xs font-bold"
              />
            </div>

            <div>
              <label className="block text-slate-400 font-medium mb-1">결제 금액 (KRW)</label>
              <input
                type="number"
                step="1000"
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value))}
                className="w-full bg-slate-900 border border-slate-700 text-white rounded p-2 text-xs font-mono font-bold text-blue-300"
              />
              <div className="flex gap-1.5 mt-1.5">
                {[1250, 48500, 1280000, 12840000].map((preset) => (
                  <button
                    key={preset}
                    onClick={() => setAmount(preset)}
                    className="bg-slate-900 hover:bg-slate-800 text-slate-300 text-[10px] px-2 py-1 rounded border border-slate-800 font-mono"
                  >
                    ₩{preset.toLocaleString()}원
                  </button>
                ))}
              </div>
            </div>

            {(activeUxMode === 'SCHEDULED' || activeUxMode === 'RECURRING') && (
              <div>
                <label className="block text-slate-400 font-medium mb-1">실행 지정일</label>
                <input
                  type="date"
                  value={scheduledDate}
                  onChange={(e) => setScheduledDate(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 text-white rounded p-2 text-xs font-mono"
                />
              </div>
            )}

            <button
              onClick={handleExecutePayment}
              className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-2.5 px-4 rounded text-xs shadow-md transition flex items-center justify-center gap-1.5 mt-2"
            >
              <CheckCircle2 className="w-4 h-4" />
              {activeUxMode} 결제 실행 및 원장 반영
            </button>
          </div>
        </div>

        {/* Korean Formatting & Receipt Preview */}
        <div className="lg:col-span-2 bg-slate-950 border border-slate-800 p-5 rounded-lg space-y-4">
          <h3 className="text-sm font-bold text-slate-200 border-b border-slate-800 pb-2">
            한국 표준 표기법 및 영수증 승인서 (Korean Financial Standards Format)
          </h3>

          <div className="bg-slate-900/90 p-4 rounded border border-slate-800 space-y-3 font-mono text-xs">
            <div className="flex justify-between items-center border-b border-slate-800 pb-2">
              <span className="font-bold text-white">전자 영수증 (DIGITAL RECEIPT)</span>
              <span className="text-emerald-400 font-bold">정상 승인완결</span>
            </div>

            <div className="space-y-1 text-slate-300">
              <div className="flex justify-between">
                <span className="text-slate-500">결제일시:</span>
                <span className="text-slate-200 font-bold">{simTime}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">결제 수단:</span>
                <span className="text-blue-400 font-bold">예금 토큰 ({activeUxMode})</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">가맹점:</span>
                <span className="text-white font-bold">{merchantName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">승인 금액:</span>
                <span className="text-indigo-300 font-bold text-sm">₩{amount.toLocaleString()}원</span>
              </div>
              <div className="flex justify-between text-[11px]">
                <span className="text-slate-500">단위 표기 (조/억):</span>
                <span className="text-slate-400">
                  {amount >= 100000000 ? `₩${(amount / 100000000).toFixed(2)}억원` : `₩${amount.toLocaleString()}원`}
                </span>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-800 text-[11px] text-slate-500">
              본 결제는 한국은행 통합원장 모듈에 의하여 0.38초 이내에 원자적으로 차감 정산되었습니다.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
