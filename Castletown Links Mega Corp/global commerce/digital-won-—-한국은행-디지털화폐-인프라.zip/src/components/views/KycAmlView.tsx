import React, { useState } from 'react';
import { useFinancialStore } from '../../store/useFinancialStore';
import { ShieldAlert, AlertTriangle, CheckCircle2, Search, Filter, Lock } from 'lucide-react';

export const KycAmlView: React.FC = () => {
  const { amlAlerts } = useFinancialStore();
  const [selectedAlertId, setSelectedAlertId] = useState<string | null>(null);
  const [actionNotice, setActionNotice] = useState<string | null>(null);

  const handleResolveAlert = (alertId: string) => {
    setActionNotice(`[AML 조사 완료] 경보 ${alertId} 조사 보고서 금융정보분석원(FIU) 송부 처리 완료!`);
    setTimeout(() => setActionNotice(null), 4000);
  };

  return (
    <div className="p-6 space-y-6 text-slate-100">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-6 h-6 text-red-400" />
            <h2 className="text-xl font-extrabold text-white tracking-tight">
              고객확인 및 이상거래 탐지 레이더 (KYC / AML Radar)
            </h2>
            <span className="bg-red-950 text-red-300 text-xs font-mono font-bold px-2 py-0.5 rounded border border-red-800">
              ANTI-MONEY LAUNDERING
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            분할 분선 거래(Structuring), 급격한 속도 스파이크 및 특이 오프라인 재동기화 실시간 탐지
          </p>
        </div>
      </div>

      {actionNotice && (
        <div className="bg-emerald-950/90 border border-emerald-700 text-emerald-200 px-4 py-2.5 rounded-md text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{actionNotice}</span>
        </div>
      )}

      {/* AML Alerts List Table */}
      <div className="bg-slate-950 border border-slate-800 rounded-lg p-5 space-y-4">
        <h3 className="text-sm font-bold text-slate-200 border-b border-slate-800 pb-2">
          실시간 의심거래 경보 목록 (FIU 보고 대기열)
        </h3>

        <div className="space-y-3">
          {amlAlerts.map((alert) => (
            <div
              key={alert.id}
              className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-wrap items-center justify-between gap-4"
            >
              <div className="space-y-1 text-xs font-mono">
                <div className="flex items-center gap-2">
                  <span className="bg-red-950 text-red-300 font-bold px-2 py-0.5 rounded border border-red-800 text-[10px]">
                    {alert.alertType || alert.detectionType}
                  </span>
                  <span className="font-bold text-white text-sm">위험 점수: {alert.riskScore || 85} / 100</span>
                  <span className="text-slate-400 text-[11px]">({alert.timestamp})</span>
                </div>
                <div className="text-slate-300 font-sans">{alert.description || alert.reason}</div>
                <div className="text-slate-500 text-[11px]">
                  대상 지갑: <strong className="text-slate-300">{alert.walletId}</strong> ({alert.userName || alert.walletName}) | 의심 금액: <strong className="text-red-400">₩{(alert.flaggedAmount || alert.amount).toLocaleString()}원</strong>
                </div>
              </div>

              <button
                onClick={() => handleResolveAlert(alert.id)}
                className="bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold py-1.5 px-3 rounded text-xs border border-slate-700"
              >
                FIU 보고 및 정밀 조사
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
