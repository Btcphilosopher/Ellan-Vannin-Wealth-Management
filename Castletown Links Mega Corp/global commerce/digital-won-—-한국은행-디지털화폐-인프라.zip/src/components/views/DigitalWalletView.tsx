import React, { useState } from 'react';
import { useFinancialStore } from '../../store/useFinancialStore';
import { Wallet as WalletIcon, QrCode, ShieldCheck, CheckCircle2, ArrowRight, Smartphone, Building, Store, CreditCard, Lock } from 'lucide-react';

export const DigitalWalletView: React.FC = () => {
  const { wallets, executePayment, transactions } = useFinancialStore();

  const [selectedWalletId, setSelectedWalletId] = useState<string>('WAL-USER-001');
  const [qrStep, setQrStep] = useState<'IDLE' | 'AUTH_WAIT' | 'APPROVING' | 'COMPLETED'>('IDLE');
  const [qrAmount, setQrAmount] = useState<number>(48500);
  const [merchantWalletId, setMerchantWalletId] = useState<string>('WAL-MERCHANT-001');
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const activeWallet = wallets.find((w) => w.id === selectedWalletId);
  const merchantWallet = wallets.find((w) => w.id === merchantWalletId);

  const handleStartQrPayment = () => {
    setQrStep('AUTH_WAIT');
  };

  const handleAuthorizeAndPay = () => {
    setQrStep('APPROVING');
    setTimeout(() => {
      const result = executePayment({
        senderWalletId: selectedWalletId,
        receiverWalletId: merchantWalletId,
        amount: qrAmount,
        paymentMethod: 'QR',
        memo: 'QR 현장 간편 결제'
      });

      if (result.success) {
        setQrStep('COMPLETED');
        setStatusMessage(result.message);
      } else {
        setQrStep('IDLE');
        setStatusMessage(`결제 실패: ${result.message}`);
      }
    }, 1200);
  };

  const handleResetQr = () => {
    setQrStep('IDLE');
    setStatusMessage(null);
  };

  return (
    <div className="p-6 space-y-6 text-slate-100">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <WalletIcon className="w-6 h-6 text-indigo-400" />
            <h2 className="text-xl font-extrabold text-white tracking-tight">
              디지털 지갑 (Digital Money Wallet)
            </h2>
            <span className="bg-indigo-950 text-indigo-300 text-xs font-mono font-bold px-2 py-0.5 rounded border border-indigo-800">
              SECURE ELEMENT WALLET
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            예금 토큰, 디지털 바우처, 오프라인 화폐 통합 관리 및 본인확인(KYC) 연동 보안 지갑
          </p>
        </div>
      </div>

      {statusMessage && (
        <div className="bg-emerald-950/90 border border-emerald-700 text-emerald-200 px-4 py-2.5 rounded-md text-xs font-bold flex items-center justify-between">
          <span>{statusMessage}</span>
          <button onClick={handleResetQr} className="underline text-emerald-300 text-[11px]">확인</button>
        </div>
      )}

      {/* Wallet Switcher & Main Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Wallet Selection & Balance Info */}
        <div className="bg-slate-950 border border-slate-800 p-5 rounded-lg space-y-4">
          <h3 className="text-sm font-bold text-slate-200 border-b border-slate-800 pb-2">
            지갑 선택 및 본인인증 상태
          </h3>

          <div className="space-y-3 text-xs">
            <div>
              <label className="block text-slate-400 font-medium mb-1">지갑 계정</label>
              <select
                value={selectedWalletId}
                onChange={(e) => {
                  setSelectedWalletId(e.target.value);
                  handleResetQr();
                }}
                className="w-full bg-slate-900 border border-slate-700 text-white rounded p-2 text-xs focus:ring-1 focus:ring-indigo-500"
              >
                {wallets.map((w) => (
                  <option key={w.id} value={w.id}>
                    {w.ownerName} [{w.ownerType}] — {w.bankName}
                  </option>
                ))}
              </select>
            </div>

            {activeWallet && (
              <div className="bg-gradient-to-br from-slate-900 to-indigo-950 p-4 rounded-lg border border-indigo-800/60 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-mono text-indigo-300 font-bold">
                    {activeWallet.ownerType} WALLET
                  </span>
                  <span className="bg-emerald-950 text-emerald-300 text-[10px] font-bold px-2 py-0.5 rounded border border-emerald-800 flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3" /> KYC Lv.{activeWallet.kycLevel} 인증완료
                  </span>
                </div>

                <div>
                  <div className="text-xs text-slate-400">사용 가능 총 잔액</div>
                  <div className="text-2xl font-extrabold font-mono-num text-white mt-0.5">
                    ₩{activeWallet.availableBalance.toLocaleString()}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[11px] pt-2 border-t border-indigo-900/60 font-mono">
                  <div>
                    <span className="text-slate-400 block">예금 토큰:</span>
                    <span className="text-indigo-300 font-bold">₩{activeWallet.depositTokenBalance.toLocaleString()}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">디지털 바우처:</span>
                    <span className="text-amber-300 font-bold">₩{activeWallet.voucherBalance.toLocaleString()}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">오프라인 잔액:</span>
                    <span className="text-emerald-300 font-bold">₩{activeWallet.offlineBalance.toLocaleString()}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">일일 한도:</span>
                    <span className="text-slate-300">₩{activeWallet.dailySpendLimit.toLocaleString()}</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* QR Payment Simulator */}
        <div className="lg:col-span-2 bg-slate-950 border border-slate-800 p-5 rounded-lg space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
              <QrCode className="w-4 h-4 text-indigo-400" />
              실시간 한국형 QR 결제 시뮬레이터
            </h3>
            <span className="text-[11px] font-mono text-slate-400">원자적 결제 완결성 프로세스</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* QR Payment Details Form */}
            <div className="bg-slate-900/70 p-4 rounded border border-slate-800 space-y-3 text-xs">
              <div className="font-bold text-slate-200 border-b border-slate-800 pb-1">
                1. 결제 가맹점 및 금액 설정
              </div>

              <div>
                <label className="block text-slate-400 mb-1">결제 대상 가맹점</label>
                <select
                  value={merchantWalletId}
                  onChange={(e) => setMerchantWalletId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 text-white rounded p-2 text-xs"
                >
                  {wallets.filter(w => w.ownerType === 'MERCHANT' || w.id !== selectedWalletId).map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.ownerName}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">결제 금액 (KRW)</label>
                <input
                  type="number"
                  value={qrAmount}
                  onChange={(e) => setQrAmount(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 text-white rounded p-2 text-xs font-mono font-bold text-indigo-300"
                />
              </div>

              {qrStep === 'IDLE' && (
                <button
                  onClick={handleStartQrPayment}
                  className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-2.5 px-4 rounded text-xs shadow-md transition flex items-center justify-center gap-1.5"
                >
                  <QrCode className="w-4 h-4" />
                  QR 결제 요청 생성 (₩{qrAmount.toLocaleString()})
                </button>
              )}
            </div>

            {/* QR Payment Execution Pipeline Visualization */}
            <div className="bg-slate-900/70 p-4 rounded border border-slate-800 flex flex-col justify-between space-y-3">
              <div className="font-bold text-slate-200 border-b border-slate-800 pb-1 text-xs">
                2. 결제 파이프라인 진행 상태
              </div>

              {qrStep === 'IDLE' && (
                <div className="text-center py-6 text-slate-500 text-xs">
                  좌측에서 금액 입력 후 QR 결제 요청을 생성하세요.
                </div>
              )}

              {qrStep === 'AUTH_WAIT' && (
                <div className="space-y-3 text-xs">
                  <div className="bg-amber-950/60 border border-amber-800/60 p-3 rounded text-amber-200">
                    <div className="font-bold">결제 승인 대기 중</div>
                    <div className="text-[11px] mt-1 text-slate-300">
                      가맹점: <strong className="text-white">{merchantWallet?.ownerName}</strong>
                      <br />
                      금액: <strong className="text-indigo-300 font-mono font-bold">₩{qrAmount.toLocaleString()}</strong>
                    </div>
                  </div>

                  <button
                    onClick={handleAuthorizeAndPay}
                    className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2.5 px-4 rounded text-xs shadow-md flex items-center justify-center gap-1.5"
                  >
                    <Lock className="w-3.5 h-3.5" />
                    본인 인증 및 결제 승인 (생체인증)
                  </button>
                </div>
              )}

              {qrStep === 'APPROVING' && (
                <div className="text-center py-8 text-xs font-mono text-blue-400 font-bold space-y-2">
                  <div className="inline-block w-6 h-6 border-2 border-blue-400 border-t-transparent rounded-full animate-spin"></div>
                  <div>통합원장 분산 검증 및 실시간 정산 중...</div>
                </div>
              )}

              {qrStep === 'COMPLETED' && (
                <div className="space-y-3 text-xs text-center">
                  <div className="bg-emerald-950/80 border border-emerald-700/80 p-3 rounded text-emerald-200 space-y-1">
                    <CheckCircle2 className="w-6 h-6 text-emerald-400 mx-auto" />
                    <div className="font-bold text-sm text-white">결제 정산 완료!</div>
                    <div className="text-[11px] text-slate-300 font-mono">
                      원장 수신 반영 완료 (0.38초 완결)
                    </div>
                  </div>

                  <button
                    onClick={handleResetQr}
                    className="bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold py-1.5 px-3 rounded text-xs"
                  >
                    새로운 결제
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
