import React, { useState } from 'react';
import { useFinancialStore } from '../../store/useFinancialStore';
import { ShieldAlert, Activity, AlertTriangle, CheckCircle2, TrendingDown, Gauge } from 'lucide-react';

export const FinancialStabilityView: React.FC = () => {
  const { financialStability, injectLiquidityShock, balanceSheets } = useFinancialStore();
  const [activeScenario, setActiveScenario] = useState<string | null>(null);

  const handleRunStressScenario = (scenarioName: string) => {
    injectLiquidityShock('BANK-HANKANG', 80000000000);
    setActiveScenario(`[스트레스 시뮬레이션] ${scenarioName} 실행 완료! 금융안정 지수 88.5 → 82.1 변동.`);
    setTimeout(() => setActiveScenario(null), 5000);
  };

  return (
    <div className="p-6 space-y-6 text-slate-100">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-6 h-6 text-amber-400" />
            <h2 className="text-xl font-extrabold text-white tracking-tight">
              금융안정성 및 뱅크런 예방 모니터링 (Financial Stability Radar)
            </h2>
            <span className="bg-amber-950 text-amber-300 text-xs font-mono font-bold px-2 py-0.5 rounded border border-amber-800">
              MACROPRUDENTIAL MONITOR
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            디지털 예금 이탈 속도, 은행 간 전염 위험(Contagion Risk) 및 시스템 리스크 모니터링
          </p>
        </div>
      </div>

      {activeScenario && (
        <div className="bg-amber-950/90 border border-amber-700 text-amber-200 px-4 py-2.5 rounded-md text-xs font-bold flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
          <span>{activeScenario}</span>
        </div>
      )}

      {/* Stability Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-950 border border-slate-800 p-4 rounded-lg">
          <div className="text-xs text-slate-400 font-medium">통합 금융안정 지수</div>
          <div className="text-2xl font-extrabold font-mono text-emerald-400 mt-1">
            {financialStability.systemicRiskIndex} / 100
          </div>
          <div className="text-[11px] text-emerald-400 mt-1">안정적 수준 유지</div>
        </div>

        <div className="bg-slate-950 border border-slate-800 p-4 rounded-lg">
          <div className="text-xs text-slate-400 font-medium">예금 토큰 전환 민감도</div>
          <div className="text-2xl font-extrabold font-mono text-blue-400 mt-1">
            {financialStability.depositMigrationVelocity}% / 시간
          </div>
          <div className="text-[11px] text-slate-400 mt-1">한도 이내 정상 분산</div>
        </div>

        <div className="bg-slate-950 border border-slate-800 p-4 rounded-lg">
          <div className="text-xs text-slate-400 font-medium">은행 간 전염 노출액</div>
          <div className="text-2xl font-extrabold font-mono text-indigo-400 mt-1">
            ₩{(financialStability.interbankContagionExposure / 1000000000000).toFixed(2)}조
          </div>
          <div className="text-[11px] text-slate-400 mt-1">담보 연계율 120% 충족</div>
        </div>

        <div className="bg-slate-950 border border-slate-800 p-4 rounded-lg">
          <div className="text-xs text-slate-400 font-medium">뱅크런 위기경보 단계</div>
          <div className="text-xl font-extrabold font-mono text-emerald-400 mt-1">
            정상 (GREEN)
          </div>
          <div className="text-[11px] text-slate-400 mt-1">자동 중단 트립와이어 미작동</div>
        </div>
      </div>

      {/* Stress Scenarios Execution Cards */}
      <div className="bg-slate-950 border border-slate-800 p-5 rounded-lg space-y-4">
        <h3 className="text-sm font-bold text-slate-200 border-b border-slate-800 pb-2">
          금융시스템 스트레스 테스트 시나리오 실행
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-slate-900 p-4 rounded border border-slate-800 space-y-2">
            <h4 className="text-xs font-bold text-white">시나리오 1: 예금 토큰 이탈 속도 급증</h4>
            <p className="text-[11px] text-slate-400">시중 2개 은행 예금의 15%가 1시간 내 예금 토큰으로 급격히 전환되는 가상 뱅크런 상정</p>
            <button
              onClick={() => handleRunStressScenario('예금 토큰 이탈 속도 급증')}
              className="bg-amber-600 hover:bg-amber-500 text-white font-bold py-1.5 px-3 rounded text-xs w-full mt-2"
            >
              시나리오 실행
            </button>
          </div>

          <div className="bg-slate-900 p-4 rounded border border-slate-800 space-y-2">
            <h4 className="text-xs font-bold text-white">시나리오 2: 일중 결제 교착 발생</h4>
            <p className="text-[11px] text-slate-400">대형 증권사의 DVP 결제 미이행으로 인한 참가 은행 간 결제 사슬 교착 상정</p>
            <button
              onClick={() => handleRunStressScenario('일중 결제 교착 발생')}
              className="bg-amber-600 hover:bg-amber-500 text-white font-bold py-1.5 px-3 rounded text-xs w-full mt-2"
            >
              시나리오 실행
            </button>
          </div>

          <div className="bg-slate-900 p-4 rounded border border-slate-800 space-y-2">
            <h4 className="text-xs font-bold text-white">시나리오 3: 담보 가치 급락 충격</h4>
            <p className="text-[11px] text-slate-400">국채 및 통안채 가격 5% 급등락에 따른 참가 은행 적격 담보 비율 평가절하</p>
            <button
              onClick={() => handleRunStressScenario('담보 가치 급락 충격')}
              className="bg-amber-600 hover:bg-amber-500 text-white font-bold py-1.5 px-3 rounded text-xs w-full mt-2"
            >
              시나리오 실행
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
