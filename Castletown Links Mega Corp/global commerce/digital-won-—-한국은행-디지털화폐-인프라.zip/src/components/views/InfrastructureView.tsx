import React from 'react';
import { useFinancialStore } from '../../store/useFinancialStore';
import { Server, Cpu, HardDrive, Zap, CheckCircle2, ShieldCheck, Activity } from 'lucide-react';

export const InfrastructureView: React.FC = () => {
  const { infraNodes } = useFinancialStore();

  return (
    <div className="p-6 space-y-6 text-slate-100">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <Server className="w-6 h-6 text-blue-400" />
            <h2 className="text-xl font-extrabold text-white tracking-tight">
              분산 원장 인프라 관제센터 (Distributed Infrastructure Control)
            </h2>
            <span className="bg-blue-950 text-blue-300 text-xs font-mono font-bold px-2 py-0.5 rounded border border-blue-800">
              9 NODES CLUSTER
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            한국은행, 시중은행, 감독기관 및 재해복구(DR) 센터 합의 검증 노드 실시간 텔레메트리
          </p>
        </div>
      </div>

      {/* 9 Nodes Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {infraNodes.map((node) => (
          <div key={node.id} className="bg-slate-950 border border-slate-800 p-4 rounded-lg space-y-3">
            <div className="flex justify-between items-center border-b border-slate-800 pb-2">
              <span className="text-xs font-bold text-white font-mono">{node.name}</span>
              <span className="bg-emerald-950 text-emerald-400 text-[10px] font-bold px-2 py-0.5 rounded border border-emerald-800">
                {node.status}
              </span>
            </div>

            <div className="space-y-2 text-xs font-mono">
              <div>
                <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                  <span>CPU 사용률:</span>
                  <span className="text-white font-bold">{node.cpuUsagePercent}%</span>
                </div>
                <div className="w-full bg-slate-900 rounded-full h-1.5 overflow-hidden">
                  <div
                    className="bg-blue-500 h-full rounded-full"
                    style={{ width: `${node.cpuUsagePercent}%` }}
                  ></div>
                </div>
              </div>

              <div>
                <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                  <span>RAM 사용률:</span>
                  <span className="text-white font-bold">{node.memUsagePercent}%</span>
                </div>
                <div className="w-full bg-slate-900 rounded-full h-1.5 overflow-hidden">
                  <div
                    className="bg-indigo-500 h-full rounded-full"
                    style={{ width: `${node.memUsagePercent}%` }}
                  ></div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-900 text-[11px]">
                <div>
                  <span className="text-slate-500 block">처리속도:</span>
                  <span className="text-emerald-400 font-bold">{node.tps} TPS</span>
                </div>
                <div>
                  <span className="text-slate-500 block">응답지연:</span>
                  <span className="text-slate-300 font-bold">{node.latencyMs} ms</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
