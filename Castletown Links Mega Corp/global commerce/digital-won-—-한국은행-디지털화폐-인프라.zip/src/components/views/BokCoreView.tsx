import React, { useState } from 'react';
import { useFinancialStore } from '../../store/useFinancialStore';
import { Landmark, ArrowUpRight, ArrowDownLeft, RefreshCw, CheckCircle, Database, Server, ShieldCheck } from 'lucide-react';

export const BokCoreView: React.FC = () => {
  const { institutions, issueCBDC, redeemCBDC, auditRecords, simTime } = useFinancialStore();

  const [selectedInstId, setSelectedInstId] = useState<string>('BANK-HANKANG');
  const [amount, setAmount] = useState<number>(100000000000); // 1000억원 default
  const [activeMessage, setActiveMessage] = useState<string | null>(null);

  const totalIssuedCbdc = institutions.reduce((acc, i) => acc + i.cbdcBalance, 0);
  const totalCollateral = institutions.reduce((acc, i) => acc + i.collateralBalance, 0);
  const totalIntradayLiquidity = institutions.reduce((acc, i) => acc + i.intradayLiquidity, 0);

  const handleIssue = () => {
    issueCBDC(selectedInstId, amount);
    const targetInst = institutions.find((i) => i.id === selectedInstId);
    setActiveMessage(`한국은행 → ${targetInst?.name} 기관용 디지털화폐 ₩${(amount / 100000000).toLocaleString()}억원 발행 완료!`);
    setTimeout(() => setActiveMessage(null), 4000);
  };

  const handleRedeem = () => {
    const targetInst = institutions.find((i) => i.id === selectedInstId);
    if (!targetInst || targetInst.cbdcBalance < amount) {
      setActiveMessage('상환 가능 잔액이 부족합니다.');
      setTimeout(() => setActiveMessage(null), 4000);
      return;
    }
    redeemCBDC(selectedInstId, amount);
    setActiveMessage(`${targetInst.name} → 한국은행 기관용 디지털화폐 ₩${(amount / 100000000).toLocaleString()}억원 상환 완료!`);
    setTimeout(() => setActiveMessage(null), 4000);
  };

  return (
    <div className="p-6 space-y-6 text-slate-100">
      {/* View Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <Landmark className="w-6 h-6 text-blue-400" />
            <h2 className="text-xl font-extrabold text-white tracking-tight">
              한국은행 디지털화폐 코어 시스템
            </h2>
            <span className="bg-blue-950 text-blue-300 text-xs font-mono font-bold px-2 py-0.5 rounded border border-blue-800">
              BOK CENTRAL CORE
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            중앙은행 단독 발행 자산으로서 기관용 디지털화폐 총량 관리 및 원자적 정산 통제
          </p>
        </div>

        <div className="flex items-center gap-2 bg-slate-950 border border-slate-800 px-3 py-1.5 rounded-md text-xs font-mono">
          <Database className="w-4 h-4 text-emerald-400" />
          <span className="text-slate-400">원장태그:</span>
          <span className="text-emerald-400 font-bold">BOK-GENESIS-LEDGER-V1</span>
        </div>
      </div>

      {activeMessage && (
        <div className="bg-emerald-950/90 border border-emerald-700 text-emerald-200 px-4 py-2.5 rounded-md text-xs font-bold flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{activeMessage}</span>
        </div>
      )}

      {/* Top Reserve Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-950 border border-slate-800 p-4 rounded-lg">
          <div className="text-xs text-slate-400 font-medium">총 기관용 디지털화폐 발행량</div>
          <div className="text-2xl font-extrabold font-mono-num text-white mt-1">
            ₩{(totalIssuedCbdc / 1000000000000).toFixed(2)}조
          </div>
          <div className="text-[11px] text-slate-400 mt-1">한국은행 대차대조표 부채 반영</div>
        </div>

        <div className="bg-slate-950 border border-slate-800 p-4 rounded-lg">
          <div className="text-xs text-slate-400 font-medium">담보 연계 총액</div>
          <div className="text-2xl font-extrabold font-mono-num text-blue-400 mt-1">
            ₩{(totalCollateral / 1000000000000).toFixed(2)}조
          </div>
          <div className="text-[11px] text-slate-400 mt-1">적격 금융기관 국채/통안채 담보</div>
        </div>

        <div className="bg-slate-950 border border-slate-800 p-4 rounded-lg">
          <div className="text-xs text-slate-400 font-medium">가용 일중 결제 유동성</div>
          <div className="text-2xl font-extrabold font-mono-num text-emerald-400 mt-1">
            ₩{(totalIntradayLiquidity / 1000000000000).toFixed(2)}조
          </div>
          <div className="text-[11px] text-slate-400 mt-1">참여 은행 한도 대기 liquidity</div>
        </div>

        <div className="bg-slate-950 border border-slate-800 p-4 rounded-lg">
          <div className="text-xs text-slate-400 font-medium">중앙은행 미유통 예비 잔액</div>
          <div className="text-2xl font-extrabold font-mono-num text-slate-300 mt-1">
            ₩16.58조
          </div>
          <div className="text-[11px] text-slate-400 mt-1">비상 유동성 준비금</div>
        </div>
      </div>

      {/* Operational Controls & Ledger Table */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: BOK Currency Execution Controls */}
        <div className="bg-slate-950 border border-slate-800 p-5 rounded-lg space-y-4">
          <h3 className="text-sm font-bold text-slate-200 border-b border-slate-800 pb-2 flex items-center gap-2">
            <Landmark className="w-4 h-4 text-blue-400" />
            디지털화폐 발행 및 상환 실행
          </h3>

          <div className="space-y-3 text-xs">
            <div>
              <label className="block text-slate-400 font-medium mb-1">대상 금융기관 선택</label>
              <select
                value={selectedInstId}
                onChange={(e) => setSelectedInstId(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-white rounded p-2 text-xs focus:ring-1 focus:ring-blue-500"
              >
                {institutions.filter(i => i.code !== 'BOK').map((inst) => (
                  <option key={inst.id} value={inst.id}>
                    {inst.name} ({inst.code}) — 현재 보유: ₩{(inst.cbdcBalance / 100000000).toLocaleString()}억원
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-400 font-medium mb-1">발행/상환 금액 (KRW)</label>
              <input
                type="number"
                step="10000000000"
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value))}
                className="w-full bg-slate-900 border border-slate-700 text-white rounded p-2 text-xs font-mono focus:ring-1 focus:ring-blue-500"
              />
              <div className="flex gap-1.5 mt-1.5">
                {[50000000000, 100000000000, 500000000000].map((preset) => (
                  <button
                    key={preset}
                    onClick={() => setAmount(preset)}
                    className="bg-slate-900 hover:bg-slate-800 text-slate-300 text-[10px] px-2 py-1 rounded border border-slate-800 font-mono"
                  >
                    +₩{(preset / 100000000).toLocaleString()}억
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                onClick={handleIssue}
                className="bg-blue-600 hover:bg-blue-500 text-white font-bold py-2 px-3 rounded flex items-center justify-center gap-1 text-xs shadow-sm"
              >
                <ArrowUpRight className="w-3.5 h-3.5" />
                디지털화폐 발행
              </button>
              <button
                onClick={handleRedeem}
                className="bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold py-2 px-3 rounded flex items-center justify-center gap-1 text-xs border border-slate-700"
              >
                <ArrowDownLeft className="w-3.5 h-3.5" />
                디지털화폐 상환
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Institutions CBDC Reserves Table */}
        <div className="lg:col-span-2 bg-slate-950 border border-slate-800 p-5 rounded-lg space-y-3">
          <h3 className="text-sm font-bold text-slate-200 border-b border-slate-800 pb-2">
            금융기관별 기관용 디지털화폐 잔액 및 담보 현황
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 bg-slate-900/50">
                  <th className="py-2 px-3">기관명</th>
                  <th className="py-2 px-3">유형</th>
                  <th className="py-2 px-3 text-right">CBDC 잔액</th>
                  <th className="py-2 px-3 text-right">설정 담보액</th>
                  <th className="py-2 px-3">위험 상태</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-900">
                {institutions.map((inst) => (
                  <tr key={inst.id} className="hover:bg-slate-900/50">
                    <td className="py-2.5 px-3 font-semibold text-slate-200">{inst.name}</td>
                    <td className="py-2.5 px-3 text-slate-400 text-[11px] font-sans">
                      {inst.type === 'CENTRAL_BANK' ? '중앙은행' : inst.type === 'COMMERCIAL_BANK' ? '시중은행' : '증권사'}
                    </td>
                    <td className="py-2.5 px-3 text-right font-bold text-blue-400 font-mono-num">
                      ₩{(inst.cbdcBalance / 100000000).toLocaleString()}억원
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-300 font-mono-num">
                      ₩{(inst.collateralBalance / 100000000).toLocaleString()}억원
                    </td>
                    <td className="py-2.5 px-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-sans font-bold ${
                        inst.riskStatus === 'STABLE'
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                          : 'bg-amber-950 text-amber-400 border border-amber-800'
                      }`}>
                        {inst.riskStatus === 'STABLE' ? '정상' : '주의'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
