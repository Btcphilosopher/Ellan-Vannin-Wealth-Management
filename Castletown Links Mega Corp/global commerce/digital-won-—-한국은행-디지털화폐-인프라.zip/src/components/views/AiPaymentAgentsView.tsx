import React, { useState } from 'react';
import { useFinancialStore } from '../../store/useFinancialStore';
import { Bot, Play, CheckCircle2, ShieldCheck, Zap, Cpu } from 'lucide-react';

export const AiPaymentAgentsView: React.FC = () => {
  const { executePayment, simTime } = useFinancialStore();
  const [aiNotice, setAiNotice] = useState<string | null>(null);

  const handleAiAutonomousExecute = (taskName: string, amount: number) => {
    executePayment({
      senderWalletId: 'WAL-CORP-001',
      receiverWalletId: 'WAL-MERCHANT-001',
      amount,
      paymentMethod: 'AI_AGENT',
      memo: `AI 자율 승인 결제 - ${taskName}`
    });

    setAiNotice(`[AI 에이전트 자율 결제 승인] 사전 위임 조건 검증 완료 → ${taskName} (₩${amount.toLocaleString()}원) 원장 차감 완결!`);
    setTimeout(() => setAiNotice(null), 4000);
  };

  return (
    <div className="p-6 space-y-6 text-slate-100">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <Bot className="w-6 h-6 text-indigo-400" />
            <h2 className="text-xl font-extrabold text-white tracking-tight">
              AI 에이전트 자율 결제 연구실 (AI Autonomous Agent Payment Lab)
            </h2>
            <span className="bg-indigo-950 text-indigo-300 text-xs font-mono font-bold px-2 py-0.5 rounded border border-indigo-800">
              AUTONOMOUS EXECUTION
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            사전 위임된 한도 및 조건 내에서 인공지능 에이전트가 사람의 개입 없이 자율적으로 판단하여 예금 토큰 정산
          </p>
        </div>
      </div>

      {aiNotice && (
        <div className="bg-emerald-950/90 border border-emerald-700 text-emerald-200 px-4 py-2.5 rounded-md text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{aiNotice}</span>
        </div>
      )}

      {/* Agents List & Tasks */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-slate-950 border border-slate-800 p-4 rounded-lg space-y-3">
          <div className="flex justify-between items-center border-b border-slate-800 pb-2">
            <h3 className="text-sm font-bold text-white">AI 에이전트 #1: EV 충전 자율 정산</h3>
            <span className="bg-indigo-950 text-indigo-300 text-[10px] font-mono font-bold px-2 py-0.5 rounded">
              한도 ₩10만
            </span>
          </div>
          <p className="text-xs text-slate-400">자율주행 전기차 단말이 초고속 충전기 접속 시 오프라인/스마트계약 기반 자동 결제</p>
          <button
            onClick={() => handleAiAutonomousExecute('전기차 급속 충전비', 38000)}
            className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-2 px-3 rounded text-xs flex items-center justify-center gap-1"
          >
            <Play className="w-3.5 h-3.5" />
            자율 결제 시뮬레이션 (₩38,000)
          </button>
        </div>

        <div className="bg-slate-950 border border-slate-800 p-4 rounded-lg space-y-3">
          <div className="flex justify-between items-center border-b border-slate-800 pb-2">
            <h3 className="text-sm font-bold text-white">AI 에이전트 #2: 클라우드 서버 자동 정산</h3>
            <span className="bg-indigo-950 text-indigo-300 text-[10px] font-mono font-bold px-2 py-0.5 rounded">
              한도 ₩50만
            </span>
          </div>
          <p className="text-xs text-slate-400">서버 트래픽 부하 급증 시 가상서버 컴퓨팅 인프라 자율 확장 및 시간당 실시간 청구</p>
          <button
            onClick={() => handleAiAutonomousExecute('클라우드 GPU 인프라 요금', 185000)}
            className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-2 px-3 rounded text-xs flex items-center justify-center gap-1"
          >
            <Play className="w-3.5 h-3.5" />
            자율 결제 시뮬레이션 (₩185,000)
          </button>
        </div>

        <div className="bg-slate-950 border border-slate-800 p-4 rounded-lg space-y-3">
          <div className="flex justify-between items-center border-b border-slate-800 pb-2">
            <h3 className="text-sm font-bold text-white">AI 에이전트 #3: 원자재 자동 재고 발주</h3>
            <span className="bg-indigo-950 text-indigo-300 text-[10px] font-mono font-bold px-2 py-0.5 rounded">
              한도 ₩5,000만
            </span>
          </div>
          <p className="text-xs text-slate-400">스마트 공장 센서 재고 소진 감지 시 공급업체에 에스크로 예금 토큰 자동 결제</p>
          <button
            onClick={() => handleAiAutonomousExecute('스마트공장 부품 자동 발주', 12500000)}
            className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-2 px-3 rounded text-xs flex items-center justify-center gap-1"
          >
            <Play className="w-3.5 h-3.5" />
            자율 결제 시뮬레이션 (₩12,500,000)
          </button>
        </div>
      </div>
    </div>
  );
};
