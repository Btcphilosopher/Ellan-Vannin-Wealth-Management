import React, { useState } from 'react';
import { MapPin, Activity, CheckCircle2, ShieldCheck, Zap, Building2 } from 'lucide-react';

export const FinancialMapView: React.FC = () => {
  const [selectedCity, setSelectedCity] = useState<string>('SEOUL');

  const cities = [
    { id: 'SEOUL', name: '서울특별시', role: '한국은행 본점 & 시중은행 메인 원장', x: 120, y: 80, tps: 2450, vol: '₩12.4조' },
    { id: 'BUSAN', name: '부산광역시', role: '해양 금융 중심지 & 증권 DVP 노드', x: 260, y: 260, tps: 820, vol: '₩3.2조' },
    { id: 'SEJONG', name: '세종특별자치시', role: '정부 바우처 및 재정 집행 노드', x: 130, y: 150, tps: 380, vol: '₩1.8조' },
    { id: 'INCHEON', name: '인천광역시', role: '물류 및 무역 결제 노드', x: 80, y: 90, tps: 410, vol: '₩1.2조' },
    { id: 'DAEJEON', name: '대전광역시', role: 'R&D 특구 바우처 노드', x: 140, y: 170, tps: 290, vol: '₩0.8조' },
    { id: 'DAEGU', name: '대구광역시', role: '산업 결제 노드', x: 220, y: 200, tps: 310, vol: '₩0.9조' },
    { id: 'GWANGJU', name: '광주광역시', role: '호남권 지역화폐 노드', x: 100, y: 250, tps: 210, vol: '₩0.5조' },
    { id: 'ULSAN', name: '울산광역시', role: '중공업 기업 결제 노드', x: 270, y: 230, tps: 240, vol: '₩0.7조' },
    { id: 'JEJU', name: '제주특별자치도', role: '관광 및 오프라인 바우처 노드', x: 80, y: 340, tps: 150, vol: '₩0.3조' }
  ];

  const activeNode = cities.find((c) => c.id === selectedCity) || cities[0];

  return (
    <div className="p-6 space-y-6 text-slate-100">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <MapPin className="w-6 h-6 text-blue-400" />
            <h2 className="text-xl font-extrabold text-white tracking-tight">
              대한민국 디지털 화폐 금융 지도 (South Korea Financial Infrastructure Map)
            </h2>
            <span className="bg-blue-950 text-blue-300 text-xs font-mono font-bold px-2 py-0.5 rounded border border-blue-800">
              NATIONAL NETWORK MAP
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            전국 9대 거점 지역 노드 간 실시간 예금 토큰 및 바우처 유통 망 분산 연결 현황
          </p>
        </div>
      </div>

      {/* SVG Map and City Detail Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* SVG South Korea Map Visualizer */}
        <div className="lg:col-span-2 bg-slate-950 border border-slate-800 p-6 rounded-lg flex flex-col items-center justify-center relative min-h-[420px]">
          <svg className="w-full max-w-md h-[380px]" viewBox="0 0 350 400">
            {/* Korea Map Outline Visualizer */}
            <path
              d="M 90,40 L 170,30 L 220,50 L 260,110 L 290,190 L 280,270 L 230,300 L 150,300 L 80,280 L 50,200 L 60,100 Z"
              fill="#0f172a"
              stroke="#334155"
              strokeWidth="2"
              strokeDasharray="4 4"
            />

            {/* City Nodes */}
            {cities.map((city) => {
              const isSelected = selectedCity === city.id;
              return (
                <g key={city.id} className="cursor-pointer" onClick={() => setSelectedCity(city.id)}>
                  {/* Pulse ring for active or seoul */}
                  {isSelected && (
                    <circle cx={city.x} cy={city.y} r="16" className="fill-blue-500/20 stroke-blue-400 animate-ping" />
                  )}
                  <circle
                    cx={city.x}
                    cy={city.y}
                    r={isSelected ? "9" : "6"}
                    className={isSelected ? "fill-blue-500 stroke-white stroke-2" : "fill-slate-700 stroke-slate-400"}
                  />
                  <text
                    x={city.x + 12}
                    y={city.y + 4}
                    fill={isSelected ? "#38bdf8" : "#94a3b8"}
                    fontSize="11"
                    fontWeight={isSelected ? "bold" : "normal"}
                    fontFamily="mono"
                  >
                    {city.name}
                  </text>
                </g>
              );
            })}
          </svg>

          <div className="absolute bottom-4 left-4 bg-slate-900/90 border border-slate-800 p-2.5 rounded text-[11px] font-mono text-slate-400">
            * 지도 상 도시 노드를 클릭하면 거점 노드 상태를 확인하실 수 있습니다.
          </div>
        </div>

        {/* Selected City Info Panel */}
        <div className="bg-slate-950 border border-slate-800 p-5 rounded-lg space-y-4">
          <div className="border-b border-slate-800 pb-2">
            <span className="text-[10px] font-mono text-blue-400 font-bold">NODE ID: {activeNode.id}</span>
            <h3 className="text-base font-extrabold text-white mt-0.5">{activeNode.name} 거점 노드</h3>
            <p className="text-xs text-slate-400 mt-1">{activeNode.role}</p>
          </div>

          <div className="space-y-3 font-mono text-xs">
            <div className="bg-slate-900 p-3 rounded border border-slate-800 space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-400">실시간 처리속도:</span>
                <span className="text-emerald-400 font-bold">{activeNode.tps} TPS</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">일일 유통 거래액:</span>
                <span className="text-blue-400 font-bold">{activeNode.vol}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">동기화 상태:</span>
                <span className="text-emerald-400 font-bold">정상 (0.38초 완결)</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
