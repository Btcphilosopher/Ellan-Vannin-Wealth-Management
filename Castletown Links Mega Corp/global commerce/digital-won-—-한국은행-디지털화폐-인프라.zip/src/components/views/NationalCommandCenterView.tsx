import React from 'react';
import { useFinancialStore } from '../../store/useFinancialStore';
import { Landmark, Coins, Ticket, ArrowLeftRight, Zap, ShieldAlert, Wifi, Globe2, Server, CheckCircle2 } from 'lucide-react';

export const NationalCommandCenterView: React.FC = () => {
  const { institutions, balanceSheets, vouchers, transactions, blockHeight, isOffline } = useFinancialStore();

  const totalCbdcTrillion = (institutions.reduce((acc, i) => acc + i.cbdcBalance, 0) / 1000000000000).toFixed(2);
  const totalDepositTokenTrillion = (balanceSheets.reduce((acc, b) => acc + b.liabilities.tokenizedDepositsIssued, 0) / 1000000000000).toFixed(2);

  return (
    <div className="p-6 space-y-6 text-slate-100">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <Landmark className="w-6 h-6 text-emerald-400" />
            <h2 className="text-xl font-extrabold text-white tracking-tight">
              디지털 원 국가 금융 인프라 관제센터 (National Financial Command Center)
            </h2>
            <span className="bg-emerald-950 text-emerald-300 text-xs font-mono font-bold px-2 py-0.5 rounded border border-emerald-800">
              NATIONAL GRAND DASHBOARD
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            한국은행 기관용 CBDC, 시중은행 예금 토큰, 디지털 바우처, 토큰화 증권 및 통합원장 통합 총괄 관제
          </p>
        </div>
      </div>

      {/* Grid of Core Infrastructure Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 font-mono">
        <div className="bg-slate-950 border border-slate-800 p-4 rounded-lg">
          <div className="flex justify-between items-center text-xs text-slate-400 mb-1">
            <span>기관용 CBDC 총 발행</span>
            <Landmark className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl font-extrabold text-white">₩{totalCbdcTrillion}조</div>
          <div className="text-[11px] text-emerald-400 mt-1">한국은행 본점 직접 발행</div>
        </div>

        <div className="bg-slate-950 border border-slate-800 p-4 rounded-lg">
          <div className="flex justify-between items-center text-xs text-slate-400 mb-1">
            <span>예금 토큰 유통 총량</span>
            <Coins className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="text-2xl font-extrabold text-white">₩{totalDepositTokenTrillion}조</div>
          <div className="text-[11px] text-indigo-300 mt-1">7개 시중은행 원자적 정산</div>
        </div>

        <div className="bg-slate-950 border border-slate-800 p-4 rounded-lg">
          <div className="flex justify-between items-center text-xs text-slate-400 mb-1">
            <span>통합원장 블록 높이</span>
            <Zap className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-extrabold text-amber-400">#{blockHeight}</div>
          <div className="text-[11px] text-slate-400 mt-1">9개 노드 BFT 합의 완결</div>
        </div>

        <div className="bg-slate-950 border border-slate-800 p-4 rounded-lg">
          <div className="flex justify-between items-center text-xs text-slate-400 mb-1">
            <span>금융안정 / 네트워크</span>
            <ShieldAlert className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-xl font-extrabold text-emerald-400">NORMAL</div>
          <div className="text-[11px] text-slate-400 mt-1">뱅크런 위기경보: 정상 (GREEN)</div>
        </div>
      </div>

      {/* Cross-System Component Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="bg-slate-950 border border-slate-800 p-4 rounded-lg space-y-2">
          <h3 className="text-sm font-bold text-white border-b border-slate-800 pb-1">1. 중앙은행 CBDC 및 담보</h3>
          <p className="text-xs text-slate-400">한국은행 단독 발행 기관용 CBDC 총 ₩{totalCbdcTrillion}조 원이 시중은행 및 증권사에 배분 정산되고 있습니다.</p>
        </div>

        <div className="bg-slate-950 border border-slate-800 p-4 rounded-lg space-y-2">
          <h3 className="text-sm font-bold text-white border-b border-slate-800 pb-1">2. 시중은행 예금 토큰</h3>
          <p className="text-xs text-slate-400">한강은행, 서울국민은행 등 7개 참여 은행이 예금 1:1 토큰화로 안전한 유통을 보장합니다.</p>
        </div>

        <div className="bg-slate-950 border border-slate-800 p-4 rounded-lg space-y-2">
          <h3 className="text-sm font-bold text-white border-b border-slate-800 pb-1">3. 목적성 디지털 바우처</h3>
          <p className="text-xs text-slate-400">청년지원, 지역화폐, 소상공인 등 {vouchers.length}개 프로그래머블 바우처가 스마트계약 통제 하에 집행 중입니다.</p>
        </div>
      </div>
    </div>
  );
};
