import React, { useState } from 'react';
import { useFinancialStore } from '../../store/useFinancialStore';
import { ArrowLeftRight, ShieldCheck, CheckCircle2, TrendingUp, Building2, Coins, ArrowRight } from 'lucide-react';

export const DigitalAssetsView: React.FC = () => {
  const { institutions, digitalAssets, executeBondDVP, simTime } = useFinancialStore();

  const [buyerId, setBuyerId] = useState<string>('BANK-HANKANG');
  const [sellerId, setSellerId] = useState<string>('SEC-KOREA-INV');
  const [assetId, setAssetId] = useState<string>('ASSET-BOND-KR26');
  const [quantity, setQuantity] = useState<number>(1000000); // 1,000,000주 = ₩100억
  const [dvpNotice, setDvpNotice] = useState<string | null>(null);

  const selectedAsset = digitalAssets.find((a) => a.id === assetId);
  const totalAmountKRW = quantity * (selectedAsset?.unitPrice || 10000);

  const handleExecuteDVP = () => {
    const result = executeBondDVP({
      buyerInstitutionId: buyerId,
      sellerInstitutionId: sellerId,
      assetId,
      quantity,
      amountKRW: totalAmountKRW
    });

    setDvpNotice(result.message);
    setTimeout(() => setDvpNotice(null), 5000);
  };

  return (
    <div className="p-6 space-y-6 text-slate-100">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <ArrowLeftRight className="w-6 h-6 text-blue-400" />
            <h2 className="text-xl font-extrabold text-white tracking-tight">
              디지털자산 결제 (Digital Asset DVP Settlement Engine)
            </h2>
            <span className="bg-blue-950 text-blue-300 text-xs font-mono font-bold px-2 py-0.5 rounded border border-blue-800">
              ATOMIC DVP PROTOCOL
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            토큰화 증권(국채, 회사채, 펀드)과 예금 토큰/기관용 CBDC 간의 양방향 원자적 동시 결제(Delivery Versus Payment)
          </p>
        </div>
      </div>

      {dvpNotice && (
        <div className="bg-emerald-950/90 border border-emerald-700 text-emerald-200 px-4 py-2.5 rounded-md text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{dvpNotice}</span>
        </div>
      )}

      {/* DVP Execution Diagram & Form */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-slate-950 border border-slate-800 p-5 rounded-lg space-y-4">
          <h3 className="text-sm font-bold text-slate-200 border-b border-slate-800 pb-2 flex items-center gap-2">
            <ArrowLeftRight className="w-4 h-4 text-blue-400" />
            원자적 DVP 결제 파라미터
          </h3>

          <div className="space-y-3 text-xs">
            <div>
              <label className="block text-slate-400 font-medium mb-1">매수 기관 (자금 지급)</label>
              <select
                value={buyerId}
                onChange={(e) => setBuyerId(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-white rounded p-2 text-xs"
              >
                {institutions.filter(i => i.id !== sellerId).map((inst) => (
                  <option key={inst.id} value={inst.id}>
                    {inst.name} — 가용 CBDC: ₩{(inst.cbdcBalance / 100000000).toLocaleString()}억원
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-400 font-medium mb-1">매도 기관 (증권 인도)</label>
              <select
                value={sellerId}
                onChange={(e) => setSellerId(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-white rounded p-2 text-xs"
              >
                {institutions.filter(i => i.id !== buyerId).map((inst) => (
                  <option key={inst.id} value={inst.id}>
                    {inst.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-400 font-medium mb-1">토큰화 디지털 자산</label>
              <select
                value={assetId}
                onChange={(e) => setAssetId(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-white rounded p-2 text-xs"
              >
                {digitalAssets.map((asset) => (
                  <option key={asset.id} value={asset.id}>
                    {asset.name} ({asset.code})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-400 font-medium mb-1">거래 수량 (주)</label>
              <input
                type="number"
                value={quantity}
                onChange={(e) => setQuantity(Number(e.target.value))}
                className="w-full bg-slate-900 border border-slate-700 text-white rounded p-2 text-xs font-mono font-bold text-blue-300"
              />
            </div>

            <div className="bg-slate-900 p-3 rounded border border-slate-800 text-[11px] font-mono space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-400">총 결제 대금:</span>
                <span className="text-emerald-400 font-bold">₩{(totalAmountKRW / 100000000).toLocaleString()}억원</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">결제 방식:</span>
                <span className="text-blue-400 font-bold">원자적 DVP (동시 완결)</span>
              </div>
            </div>

            <button
              onClick={handleExecuteDVP}
              className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-2.5 px-4 rounded text-xs shadow-md transition flex items-center justify-center gap-1.5"
            >
              <ArrowLeftRight className="w-4 h-4" />
              ATOMIC DVP 동시 결제 실행
            </button>
          </div>
        </div>

        {/* DVP Two Legs Diagram Visualizer */}
        <div className="lg:col-span-2 bg-slate-950 border border-slate-800 p-5 rounded-lg space-y-4">
          <h3 className="text-sm font-bold text-slate-200 border-b border-slate-800 pb-2">
            원자적 DVP 결제 메커니즘 도식화 (Two-Leg Atomic Settlement Flow)
          </h3>

          <div className="bg-slate-900/80 p-5 rounded-lg border border-slate-800 space-y-6">
            <div className="grid grid-cols-3 items-center text-center gap-4">
              <div className="bg-slate-950 p-3 rounded border border-blue-800/80">
                <div className="text-[10px] text-blue-400 font-mono font-bold">LEG 1: 자산 이전</div>
                <div className="text-xs font-bold text-white mt-1">{selectedAsset?.name}</div>
                <div className="text-[11px] text-slate-400 mt-1">{quantity.toLocaleString()} 주</div>
              </div>

              <div className="flex flex-col items-center justify-center">
                <div className="w-full border-t-2 border-dashed border-blue-500 relative my-2">
                  <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-blue-900 text-blue-200 text-[9px] font-mono font-bold px-2 py-0.5 rounded border border-blue-700">
                    원자적 동시 교환 (ATOMIC SWAP)
                  </span>
                </div>
              </div>

              <div className="bg-slate-950 p-3 rounded border border-emerald-800/80">
                <div className="text-[10px] text-emerald-400 font-mono font-bold">LEG 2: 결제 이전</div>
                <div className="text-xs font-bold text-white mt-1">예금 토큰 / 기관 CBDC</div>
                <div className="text-[11px] text-slate-400 mt-1">₩{(totalAmountKRW / 100000000).toLocaleString()} 억원</div>
              </div>
            </div>

            <div className="bg-slate-950 p-3 rounded text-[11px] font-mono text-slate-400 space-y-1 border border-slate-800">
              <div className="text-emerald-400 font-bold">✓ 결제 신용 리스크 원천 제거:</div>
              <div>자산 이전과 자금 결제 중 하나라도 실패할 경우 원장 상태는 자동으로 Rollback되어 반대 반제 위험(Counterparty Risk)이 발생하지 않습니다.</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
