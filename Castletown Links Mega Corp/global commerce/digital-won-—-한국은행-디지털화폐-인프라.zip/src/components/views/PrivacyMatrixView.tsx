import React from 'react';
import { useFinancialStore } from '../../store/useFinancialStore';
import { ShieldCheck, Eye, EyeOff, Lock, Key, Users } from 'lucide-react';
import { PrivacyRole } from '../../types';

export const PrivacyMatrixView: React.FC = () => {
  const { activePrivacyRole, setPrivacyRole } = useFinancialStore();

  const rolesList: { id: PrivacyRole; title: string; desc: string }[] = [
    { id: 'BOK_ADMIN', title: '한국은행 (중앙은행)', desc: '거시 통계 및 기관간 결제 내역 조회 (개인 신원 영무차단)' },
    { id: 'COMMERCIAL_BANK', title: '참여 시중은행', desc: '자사 고객 예금 및 토큰 거래 내역에 한하여 조회' },
    { id: 'REGULATOR_FSS', title: '금융감독원 (감독기관)', desc: '이상거래 탐지, 자금세탁방지 및 감독 목적 접근' },
    { id: 'LAW_ENFORCEMENT', title: '수사기관 (법원 영장)', desc: '법원 정식 영장 발부 시 한정적 신원 복호화' },
    { id: 'INDIVIDUAL_USER', title: '일반 개인 사용자', desc: '본인 지갑 거래 및 바우처 사용 내역만 조회 가능' },
    { id: 'MERCHANT', title: '가맹점', desc: '자사 입금 및 매출 내역 조회 (구매자 신원 가명 처리)' }
  ];

  const privacyMatrix = [
    { field: '고객 실명 / 성명', BOK: '가명/마스킹', BANK: '자사고객만', REGULATOR: '마스킹', LAW: '영장 복호화', USER: '본인만', MERCHANT: '가명 처리' },
    { field: '지갑 식별자 (ID)', BOK: '해시화', BANK: '원문 조회', REGULATOR: '해시화', LAW: '원문 조회', USER: '본인만', MERCHANT: '해시화' },
    { field: '거래 금액 (KRW)', BOK: '원문 조회', BANK: '자사거래만', REGULATOR: '원문 조회', LAW: '원문 조회', USER: '본인만', MERCHANT: '입금액만' },
    { field: '가맹점 업종 정보', BOK: '통계만', BANK: '자사거래만', REGULATOR: '원문 조회', LAW: '원문 조회', USER: '원문 조회', MERCHANT: '자사만' },
    { field: '세부 영수증 항목', BOK: '비공개', BANK: '비공개', REGULATOR: '비공개', LAW: '영장 복호화', USER: '원문 조회', MERCHANT: '자사만' },
    { field: '자금 출처 / 계좌', BOK: '비공개', BANK: '자사고객만', REGULATOR: '의심거래만', LAW: '원문 조회', USER: '본인만', MERCHANT: '비공개' }
  ];

  return (
    <div className="p-6 space-y-6 text-slate-100">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <Lock className="w-6 h-6 text-indigo-400" />
            <h2 className="text-xl font-extrabold text-white tracking-tight">
              개인정보 보호 및 역할별 접근 권한 매트릭스 (Privacy Matrix)
            </h2>
            <span className="bg-indigo-950 text-indigo-300 text-xs font-mono font-bold px-2 py-0.5 rounded border border-indigo-800">
              ZERO-KNOWLEDGE PRIVACY
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            영지식 증명(Zero-Knowledge Proof) 및 차분 프라이버시 기반 6대 사용자 주체별 원장 정보 마스킹 통제
          </p>
        </div>
      </div>

      {/* Role Switcher Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {rolesList.map((r) => {
          const isActive = activePrivacyRole === r.id;
          return (
            <button
              key={r.id}
              onClick={() => setPrivacyRole(r.id)}
              className={`p-3.5 rounded-lg border text-left transition ${
                isActive
                  ? 'bg-indigo-950/90 border-indigo-400 text-white shadow-sm font-bold'
                  : 'bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-900'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-bold text-white">{r.title}</span>
                {isActive && (
                  <span className="bg-indigo-600 text-white text-[9px] font-mono px-1.5 py-0.5 rounded">
                    CURRENT ROLE
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-400 leading-snug">{r.desc}</p>
            </button>
          );
        })}
      </div>

      {/* Matrix Table */}
      <div className="bg-slate-950 border border-slate-800 rounded-lg p-5 space-y-3">
        <h3 className="text-sm font-bold text-slate-200 border-b border-slate-800 pb-2 flex items-center gap-2">
          <Eye className="w-4 h-4 text-indigo-400" />
          데이터 필드별 접근 및 복호화 통제권 매트릭스
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 bg-slate-900/60">
                <th className="py-2.5 px-3">데이터 필드</th>
                <th className="py-2.5 px-3">한국은행</th>
                <th className="py-2.5 px-3">시중은행</th>
                <th className="py-2.5 px-3">금감원</th>
                <th className="py-2.5 px-3">수사기관</th>
                <th className="py-2.5 px-3">개인사용자</th>
                <th className="py-2.5 px-3">가맹점</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-900">
              {privacyMatrix.map((row, idx) => (
                <tr key={idx} className="hover:bg-slate-900/50">
                  <td className="py-2.5 px-3 font-semibold text-white font-sans">{row.field}</td>
                  <td className="py-2.5 px-3 text-slate-300">{row.BOK}</td>
                  <td className="py-2.5 px-3 text-slate-300">{row.BANK}</td>
                  <td className="py-2.5 px-3 text-slate-300">{row.REGULATOR}</td>
                  <td className="py-2.5 px-3 text-amber-300 font-bold">{row.LAW}</td>
                  <td className="py-2.5 px-3 text-emerald-400">{row.USER}</td>
                  <td className="py-2.5 px-3 text-slate-400">{row.MERCHANT}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
