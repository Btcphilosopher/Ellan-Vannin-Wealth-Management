import React from 'react';
import { useFinancialStore } from '../../store/useFinancialStore';
import { Store, ShoppingBag, Coffee, Utensils, CheckCircle2, TrendingUp } from 'lucide-react';

export const MerchantNetworkView: React.FC = () => {
  const merchantCategories = [
    { name: '소상공인 및 골목상권', count: '1,280,000 곳', vol: '₩4.2조', fee: '0.05%' },
    { name: '대형마트 및 편의점', count: '52,000 곳', vol: '₩3.8조', fee: '0.08%' },
    { name: '온라인 이커머스', count: '185,000 곳', vol: '₩6.4조', fee: '0.10%' },
    { name: '대중교통 및 유류', count: '34,000 곳', vol: '₩1.5조', fee: '0.05%' },
    { name: '공공기관 및 세금정산', count: '12,000 곳', vol: '₩2.8조', fee: '0.00% (면제)' }
  ];

  return (
    <div className="p-6 space-y-6 text-slate-100">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <Store className="w-6 h-6 text-indigo-400" />
            <h2 className="text-xl font-extrabold text-white tracking-tight">
              가맹점 결제 네트워크 (Merchant Payment Network)
            </h2>
            <span className="bg-indigo-950 text-indigo-300 text-xs font-mono font-bold px-2 py-0.5 rounded border border-indigo-800">
              ZERO-SETTLEMENT-DELAY
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            전국 150만+ 결제 가맹점 수수료 절감 및 예금 토큰 실시간 입금(D+0 수수료 대폭 인하)
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {merchantCategories.map((cat, idx) => (
          <div key={idx} className="bg-slate-950 border border-slate-800 p-4 rounded-lg space-y-2">
            <div className="flex justify-between items-center border-b border-slate-800 pb-2">
              <h3 className="text-sm font-bold text-white">{cat.name}</h3>
              <span className="bg-emerald-950 text-emerald-400 text-[10px] font-mono px-2 py-0.5 rounded border border-emerald-800">
                수수료 {cat.fee}
              </span>
            </div>
            <div className="space-y-1 text-xs font-mono">
              <div className="flex justify-between">
                <span className="text-slate-400">가맹점 수:</span>
                <span className="text-slate-200">{cat.count}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">일일 결제액:</span>
                <span className="text-indigo-400 font-bold">{cat.vol}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">정산 주기:</span>
                <span className="text-emerald-400 font-bold">즉시 입금 (D+0)</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
