import React from 'react';
import { useFinancialStore } from '../../store/useFinancialStore';
import { ShieldCheck, FileText, CheckCircle2, Lock, Key } from 'lucide-react';

export const AuditLogView: React.FC = () => {
  const { auditRecords } = useFinancialStore();

  return (
    <div className="p-6 space-y-6 text-slate-100">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-6 h-6 text-emerald-400" />
            <h2 className="text-xl font-extrabold text-white tracking-tight">
              감사 및 위변조 방지 추적 기록 (Immutable Audit Trail)
            </h2>
            <span className="bg-emerald-950 text-emerald-300 text-xs font-mono font-bold px-2 py-0.5 rounded border border-emerald-800">
              SHA-256 HASH CHAIN
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            한국은행 및 참여 금융기관 시스템 동작 변경, 발행/상환, 규제 검증 및 정산 내역의 위변조 불가 감사 체인
          </p>
        </div>
      </div>

      {/* Audit Logs Table */}
      <div className="bg-slate-950 border border-slate-800 rounded-lg p-5 space-y-4">
        <h3 className="text-sm font-bold text-slate-200 border-b border-slate-800 pb-2">
          원장 감사 이벤트 체인 로그
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 bg-slate-900/60">
                <th className="py-2.5 px-3">감사 ID</th>
                <th className="py-2.5 px-3">시각</th>
                <th className="py-2.5 px-3">이벤트 카테고리</th>
                <th className="py-2.5 px-3">주체</th>
                <th className="py-2.5 px-3">이벤트 내용</th>
                <th className="py-2.5 px-3">검증 해시 (SHA-256)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-900">
              {auditRecords.map((log) => (
                <tr key={log.id} className="hover:bg-slate-900/50">
                  <td className="py-3 px-3 font-semibold text-blue-400">{log.id}</td>
                  <td className="py-3 px-3 text-slate-400">{log.timestamp}</td>
                  <td className="py-3 px-3">
                    <span className="bg-slate-900 text-slate-300 px-2 py-0.5 rounded text-[10px] font-bold border border-slate-800">
                      {log.eventType}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-slate-200">{log.actor}</td>
                  <td className="py-3 px-3 text-slate-300 font-sans">{log.details}</td>
                  <td className="py-3 px-3 text-slate-500 text-[10px] truncate max-w-[150px]">
                    {log.hash}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
