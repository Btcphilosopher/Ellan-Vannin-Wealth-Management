import React, { useState } from 'react';
import { useFinancialStore } from '../../store/useFinancialStore';
import { TrendingUp, ShoppingCart, CheckCircle2, ShieldCheck, DollarSign, Activity } from 'lucide-react';

export const SecuritiesView: React.FC = () => {
  const { digitalAssets, executeBondDVP, simTime } = useFinancialStore();

  const [selectedAssetId, setSelectedAssetId] = useState<string>('ASSET-BOND-KR26');
  const [orderQuantity, setOrderQuantity] = useState<number>(1000000); // ₩100억
  const [tradeNotice, setTradeNotice] = useState<string | null>(null);

  const selectedAsset = digitalAssets.find((a) => a.id === selectedAssetId);
  const totalTradeKRW = orderQuantity * (selectedAsset?.unitPrice || 10000);

  const handleExecuteBondOrder = () => {
    const result = executeBondDVP({
      buyerInstitutionId: 'BANK-HANKANG',
      sellerInstitutionId: 'SEC-KOREA-INV',
      assetId: selectedAssetId,
      quantity: orderQuantity,
      amountKRW: totalTradeKRW
    });

    setTradeNotice(`[증권 체결 완료] 매수: ${selectedAsset?.name} ₩${(totalTradeKRW / 100000000).toLocaleString()}억원 / 결제수단: 예금 토큰 / 결제방식: 원자적 DVP (${simTime})`);
    setTimeout(() => setTradeNotice(null), 5000);
  };

  return (
    <div className="p-6 space-y-6 text-slate-100">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <TrendingUp className="w-6 h-6 text-emerald-400" />
            <h2 className="text-xl font-extrabold text-white tracking-tight">
              토큰화 증권시장 (Tokenized Securities Market)
            </h2>
            <span className="bg-emerald-950 text-emerald-300 text-xs font-mono font-bold px-2 py-0.5 rounded border border-emerald-800">
              STO / TOKENIZED BONDS
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            국채, 회사채, MMF, 단기금융상품 토큰의 실시간 발행, 원자적 청산 결제 및 통합 보관
          </p>
        </div>
      </div>

      {tradeNotice && (
        <div className="bg-emerald-950/90 border border-emerald-700 text-emerald-200 px-4 py-2.5 rounded-md text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{tradeNotice}</span>
        </div>
      )}

      {/* Bond Order Panel and Assets Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Order execution card */}
        <div className="bg-slate-950 border border-slate-800 p-5 rounded-lg space-y-4">
          <h3 className="text-sm font-bold text-slate-200 border-b border-slate-800 pb-2 flex items-center gap-2">
            <ShoppingCart className="w-4 h-4 text-emerald-400" />
            토큰화 채권 매수 주문 (DVP)
          </h3>

          <div className="space-y-3 text-xs">
            <div>
              <label className="block text-slate-400 font-medium mb-1">매수 채권 자산</label>
              <select
                value={selectedAssetId}
                onChange={(e) => setSelectedAssetId(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-white rounded p-2 text-xs"
              >
                {digitalAssets.map((asset) => (
                  <option key={asset.id} value={asset.id}>
                    {asset.name} (표면금리: {asset.couponRate}%)
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-400 font-medium mb-1">매수 주문 수량 (주)</label>
              <input
                type="number"
                step="100000"
                value={orderQuantity}
                onChange={(e) => setOrderQuantity(Number(e.target.value))}
                className="w-full bg-slate-900 border border-slate-700 text-white rounded p-2 text-xs font-mono font-bold text-emerald-400"
              />
              <div className="flex gap-1.5 mt-1.5">
                {[100000, 500000, 1000000, 5000000].map((preset) => (
                  <button
                    key={preset}
                    onClick={() => setOrderQuantity(preset)}
                    className="bg-slate-900 hover:bg-slate-800 text-slate-300 text-[10px] px-2 py-1 rounded border border-slate-800 font-mono"
                  >
                    ₩{(preset * 10000 / 100000000).toLocaleString()}억원
                  </button>
                ))}
              </div>
            </div>

            <div className="bg-slate-900 p-3 rounded border border-slate-800 text-[11px] font-mono space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-400">결제 수단:</span>
                <span className="text-indigo-400 font-bold">예금 토큰</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">총 결제 대금:</span>
                <span className="text-emerald-400 font-bold">₩{(totalTradeKRW / 100000000).toLocaleString()}억원</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">결제 방식:</span>
                <span className="text-white font-bold">원자적 DVP</span>
              </div>
            </div>

            <button
              onClick={handleExecuteBondOrder}
              className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2.5 px-4 rounded text-xs shadow-md transition flex items-center justify-center gap-1.5"
            >
              <ShoppingCart className="w-4 h-4" />
              채권 매수 주문 및 DVP 체결
            </button>
          </div>
        </div>

        {/* Digital Asset Market Catalog */}
        <div className="lg:col-span-2 bg-slate-950 border border-slate-800 p-5 rounded-lg space-y-4">
          <h3 className="text-sm font-bold text-slate-200 border-b border-slate-800 pb-2">
            상장 토큰화 증권 및 단기금융상품 목록
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {digitalAssets.map((asset) => (
              <div key={asset.id} className="bg-slate-900/80 border border-slate-800 p-4 rounded-lg space-y-2">
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-[10px] font-mono text-emerald-400 font-bold">{asset.code}</span>
                    <h4 className="text-sm font-bold text-white mt-0.5">{asset.name}</h4>
                    <p className="text-[11px] text-slate-400">{asset.issuerName}</p>
                  </div>
                  <span className="bg-blue-950 text-blue-300 text-[10px] font-bold px-2 py-0.5 rounded border border-blue-800">
                    금리 {asset.couponRate}%
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs font-mono pt-2 border-t border-slate-800">
                  <div>
                    <span className="text-slate-400 block text-[10px]">총 액면가:</span>
                    <span className="text-white font-bold">₩{(asset.totalFaceValue / 100000000).toLocaleString()}억원</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">만기일:</span>
                    <span className="text-slate-300">{asset.maturityDate}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
