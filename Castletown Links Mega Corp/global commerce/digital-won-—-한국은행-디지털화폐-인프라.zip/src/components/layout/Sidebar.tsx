import React from 'react';
import { useFinancialStore } from '../../store/useFinancialStore';
import {
  LayoutDashboard,
  Building2,
  Landmark,
  Coins,
  Layers,
  Wallet,
  QrCode,
  Ticket,
  FileCode,
  ArrowLeftRight,
  TrendingUp,
  Scale,
  Droplets,
  ShieldCheck,
  Lock,
  UserCheck,
  WifiOff,
  Bot,
  Globe2,
  BarChart3,
  FlaskConical,
  MapPin,
  Store,
  Send,
  History,
  Server,
  MonitorCheck
} from 'lucide-react';

export const Sidebar: React.FC = () => {
  const { activeTab, setActiveTab } = useFinancialStore();

  const navGroups = [
    {
      groupName: '관제 및 코어',
      items: [
        { id: 'dashboard', label: '통합 관제센터', icon: LayoutDashboard },
        { id: 'national-command', label: '국가 금융 인프라 관제센터', icon: MonitorCheck },
        { id: 'bok', label: '한국은행 디지털화폐', icon: Landmark },
        { id: 'institutional-cbdc', label: '기관용 디지털화폐', icon: Building2 }
      ]
    },
    {
      groupName: '통화 및 결제',
      items: [
        { id: 'tokenized-deposits', label: '예금 토큰 플랫폼', icon: Coins },
        { id: 'unified-ledger', label: '통합원장', icon: Layers },
        { id: 'wallets', label: '디지털 지갑', icon: Wallet },
        { id: 'payments', label: '한국형 결제 UX', icon: QrCode },
        { id: 'vouchers', label: '디지털 바우처 관리', icon: Ticket }
      ]
    },
    {
      groupName: '시장 및 스마트계약',
      items: [
        { id: 'smart-contracts', label: '스마트계약 실행환경', icon: FileCode },
        { id: 'digital-assets', label: '디지털자산 결제 (DVP)', icon: ArrowLeftRight },
        { id: 'securities', label: '토큰화 증권시장', icon: TrendingUp }
      ]
    },
    {
      groupName: '은행 및 유동성',
      items: [
        { id: 'banking-system', label: '은행 재무상태표', icon: Scale },
        { id: 'liquidity', label: '유동성 관제', icon: Droplets },
        { id: 'financial-stability', label: '금융안정성 모니터링', icon: ShieldCheck }
      ]
    },
    {
      groupName: '보안 및 첨단 연구',
      items: [
        { id: 'privacy', label: '개인정보 보호', icon: Lock },
        { id: 'kyc-aml', label: 'KYC / AML 이상거래', icon: UserCheck },
        { id: 'offline', label: '오프라인 결제 연구실', icon: WifiOff },
        { id: 'ai-agents', label: 'AI 에이전트 결제', icon: Bot },
        { id: 'cross-border', label: '국가간 디지털화폐', icon: Globe2 }
      ]
    },
    {
      groupName: '분석 및 인프라',
      items: [
        { id: 'economic-simulation', label: '통화 경제 시뮬레이터', icon: BarChart3 },
        { id: 'research-lab', label: '디지털 원 연구실', icon: FlaskConical },
        { id: 'map', label: '대한민국 금융 지도', icon: MapPin },
        { id: 'merchants', label: '가맹점 네트워크', icon: Store },
        { id: 'transaction-lab', label: '거래 시뮬레이터', icon: Send },
        { id: 'audit', label: '감사 및 추적', icon: History },
        { id: 'infrastructure', label: '인프라 관제센터', icon: Server }
      ]
    }
  ];

  return (
    <aside className="w-64 bg-slate-950 border-r border-slate-800 shrink-0 flex flex-col h-full overflow-y-auto select-none">
      <div className="p-3 text-[11px] font-mono text-slate-500 uppercase tracking-widest font-semibold border-b border-slate-900 flex justify-between items-center">
        <span>시스템 서브시스템</span>
        <span className="text-blue-400 font-bold">27 MODULES</span>
      </div>

      <nav className="p-2 space-y-4">
        {navGroups.map((group) => (
          <div key={group.groupName} className="space-y-1">
            <div className="px-2 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              {group.groupName}
            </div>
            {group.items.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded text-xs font-medium transition ${
                    isActive
                      ? 'bg-blue-600/90 text-white font-bold shadow-sm border border-blue-400/30'
                      : 'text-slate-300 hover:text-white hover:bg-slate-900'
                  }`}
                >
                  <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                  <span className="truncate">{item.label}</span>
                </button>
              );
            })}
          </div>
        ))}
      </nav>
    </aside>
  );
};
