import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-950 border-t border-slate-900 px-5 py-2.5 text-[11px] text-slate-400 shrink-0 flex flex-wrap items-center justify-between gap-2 z-30">
      <div className="flex items-center gap-2">
        <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0"></span>
        <span>
          본 시스템은 디지털화폐 및 토큰화 금융 인프라에 대한 연구·교육 목적의 가상 시뮬레이션입니다. 실제 한국은행 시스템, 금융기관, 지급결제망 또는 고객정보와 연결되어 있지 않습니다.
        </span>
      </div>
      <div className="text-slate-400 font-mono text-[10px]">
        DIGITAL WON PLATFORM v3.6.0 · SYNTHETIC MONETARY SYSTEM DIGITAL TWIN
      </div>
    </footer>
  );
};
