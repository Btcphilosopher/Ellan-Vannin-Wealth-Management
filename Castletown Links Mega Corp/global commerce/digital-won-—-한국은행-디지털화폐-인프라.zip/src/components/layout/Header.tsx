import React from 'react';
import { useFinancialStore } from '../../store/useFinancialStore';
import { Play, Pause, RotateCcw, FastForward, ShieldAlert, Cpu, Eye } from 'lucide-react';
import { PrivacyRole } from '../../types';

export const Header: React.FC = () => {
  const {
    simTime,
    speedMultiplier,
    isPaused,
    setSpeedMultiplier,
    togglePause,
    resetSimulation,
    activePrivacyRole,
    setActivePrivacyRole,
    accountingInvariantsMet,
    invariantErrorMessage
  } = useFinancialStore();

  const privacyRoles: { role: PrivacyRole; label: string }[] = [
    { role: 'USER', label: '개인' },
    { role: 'BANK', label: '은행' },
    { role: 'BOK', label: '한국은행' },
    { role: 'SUPERVISOR', label: '감독기관' },
    { role: 'AUDITOR', label: '감사기관' },
    { role: 'LAW_ENFORCEMENT', label: '법집행기관' }
  ];

  return (
    <header className="bg-slate-950 border-b border-slate-800 text-slate-100 flex flex-col shrink-0 sticky top-0 z-40">
      {/* Persistent System Banner */}
      <div className="bg-blue-950/80 border-b border-blue-800/50 px-4 py-1 text-center text-xs font-mono font-medium text-blue-200 tracking-wider flex items-center justify-center gap-2">
        <span className="inline-block w-2 h-2 rounded-full bg-blue-400 animate-pulse"></span>
        <span>시뮬레이션 환경 · 합성 데이터 · 연구용 프로토타입</span>
        <span className="text-slate-500">|</span>
        <span className="text-slate-400">SIMULATION ENVIRONMENT · SYNTHETIC DATA · RESEARCH PROTOTYPE</span>
      </div>

      {/* Accounting Invariant Warning if violated */}
      {!accountingInvariantsMet && (
        <div className="bg-rose-950 border-b border-rose-800 px-4 py-1.5 text-xs text-rose-200 font-bold flex items-center justify-center gap-2">
          <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0" />
          <span>{invariantErrorMessage || '회계 불변식 위반: 자산 ≠ 부채 + 자본'}</span>
        </div>
      )}

      {/* Main Top Control Strip */}
      <div className="px-5 py-2.5 flex flex-wrap items-center justify-between gap-4">
        {/* Brand / Logo */}
        <div className="flex items-center gap-3">
          <div className="bg-gradient-to-br from-blue-700 to-indigo-900 border border-blue-500/40 w-9 h-9 rounded flex items-center justify-center shadow-inner">
            <span className="text-white font-extrabold text-lg tracking-tighter">₩</span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base font-bold text-slate-50 tracking-tight leading-none">
                DIGITAL WON
              </h1>
              <span className="bg-blue-900/60 text-blue-300 text-[10px] font-mono font-semibold px-1.5 py-0.5 rounded border border-blue-700/50">
                BOK-SIM 2026
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-medium">
              한국은행 디지털화폐·토큰화 금융 인프라 시뮬레이터
            </p>
          </div>
        </div>

        {/* Time Engine & Controls */}
        <div className="flex items-center gap-3 bg-slate-900/90 border border-slate-800 px-3 py-1.5 rounded-md">
          <div className="flex items-center gap-2 border-r border-slate-800 pr-3">
            <span className="text-[11px] text-slate-400 font-semibold uppercase tracking-wider">
              시뮬레이션 시간
            </span>
            <span className="font-mono-num text-xs font-bold text-emerald-400 bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
              {simTime}
            </span>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={togglePause}
              className={`px-2 py-1 rounded text-xs font-bold flex items-center gap-1 transition ${
                isPaused
                  ? 'bg-amber-600 hover:bg-amber-500 text-white'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
              }`}
              title={isPaused ? '재개' : '일시정지'}
            >
              {isPaused ? <Play className="w-3.5 h-3.5 fill-current" /> : <Pause className="w-3.5 h-3.5" />}
              <span className="text-[11px]">{isPaused ? '일시정지됨' : '실행중'}</span>
            </button>

            <div className="flex bg-slate-950 p-0.5 rounded border border-slate-800 text-[11px] font-mono">
              {[1, 10, 100, 1000].map((multiplier) => (
                <button
                  key={multiplier}
                  onClick={() => setSpeedMultiplier(multiplier)}
                  className={`px-2 py-0.5 rounded ${
                    speedMultiplier === multiplier
                      ? 'bg-blue-600 font-bold text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {multiplier}x
                </button>
              ))}
            </div>

            <button
              onClick={resetSimulation}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded transition"
              title="초기 상태로 리셋"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Privacy Role Matrix Switcher */}
        <div className="flex items-center gap-2 bg-slate-900/90 border border-slate-800 px-3 py-1.5 rounded-md">
          <Eye className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          <span className="text-[11px] text-slate-400 font-semibold">시각 권한:</span>
          <div className="flex bg-slate-950 p-0.5 rounded border border-slate-800 text-xs">
            {privacyRoles.map((item) => (
              <button
                key={item.role}
                onClick={() => setActivePrivacyRole(item.role)}
                className={`px-2 py-0.5 rounded text-[11px] font-medium transition ${
                  activePrivacyRole === item.role
                    ? 'bg-indigo-600 font-bold text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>
      </div>
    </header>
  );
};
