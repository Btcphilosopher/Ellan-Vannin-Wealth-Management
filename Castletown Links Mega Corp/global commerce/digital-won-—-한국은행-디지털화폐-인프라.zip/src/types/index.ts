export type TokenType = 
  | 'INSTITUTIONAL_CBDC' 
  | 'TOKENIZED_DEPOSIT' 
  | 'E_MONEY_TOKEN' 
  | 'SPECIAL_PAYMENT_TOKEN' 
  | 'DIGITAL_VOUCHER' 
  | 'TOKENIZED_ASSET';

export type WalletType = 'PERSONAL' | 'MERCHANT' | 'CORPORATE' | 'FINANCIAL' | 'GOVT';

export type PaymentMethod = 
  | 'QR' 
  | 'NFC' 
  | 'MOBILE' 
  | 'DVP' 
  | 'AI_AGENT' 
  | 'OFFLINE_SYNC' 
  | 'BATCH' 
  | 'ONLINE'
  | 'CROSS_BORDER'
  | 'SCHEDULED'
  | 'RECURRING';

export type TransactionStatus = 'SUCCESS' | 'PENDING' | 'REJECTED' | 'SETTLING';

export interface Institution {
  id: string;
  name: string;
  code: string;
  type: 'CENTRAL_BANK' | 'COMMERCIAL_BANK' | 'SECURITIES_FIRM' | 'OTHER_FINANCIAL';
  cbdcBalance: number; // KRW
  collateralBalance: number;
  intradayLiquidity: number;
  intradaySettlementVolume: number;
  pendingTxCount: number;
  riskStatus: 'STABLE' | 'WARNING' | 'CRITICAL';
  nodeHealth: 'NORMAL' | 'DEGRADED' | 'OFFLINE';
}

export interface BankBalanceSheet {
  bankId: string;
  bankName: string;
  assets: {
    cbdcReserves: number;
    commercialDepositsAtBok: number;
    loans: number;
    securities: number;
    otherAssets: number;
    totalAssets: number;
  };
  liabilities: {
    customerDeposits: number;
    tokenizedDepositsIssued: number;
    centralBankBorrowings: number;
    otherLiabilities: number;
    totalLiabilities: number;
  };
  equity: {
    capitalStock: number;
    retainedEarnings: number;
    totalEquity: number;
  };
  capitalAdequacyRatio: number; // BIS %
  liquidityCoverageRatio: number; // LCR %
}

export interface Wallet {
  id: string;
  ownerName: string;
  ownerType: WalletType;
  bankId: string;
  bankName: string;
  depositTokenBalance: number;
  voucherBalance: number;
  availableBalance: number;
  offlineBalance: number;
  dailySpendLimit: number;
  spentToday: number;
  kycStatus: 'VERIFIED' | 'PENDING' | 'FLAGGED';
  kycLevel: 1 | 2 | 3;
  privacyAddress: string;
  updatedAt: string;
}

export interface Transaction {
  txId: string;
  timestamp: string;
  blockHeight: number;
  senderId: string;
  senderName: string;
  receiverId: string;
  receiverName: string;
  issuingInstitutionId: string;
  issuingInstitutionName: string;
  tokenType: TokenType;
  amount: number;
  fee: number;
  status: TransactionStatus;
  paymentMethod: PaymentMethod;
  consensusVerified: boolean;
  finalityDurationSec: number;
  smartContractId?: string;
  auditHash: string;
  memo?: string;
}

export interface Voucher {
  id: string;
  title: string;
  issuingAgency: string;
  totalIssuedAmount: number;
  remainingAmount: number;
  allowedCategories: string[];
  validFrom: string;
  validUntil: string;
  restrictionDescription: string;
  eligibleMerchantsCount: number;
  status: 'ACTIVE' | 'EXPIRED' | 'PAUSED';
}

export interface SmartContractStep {
  stepName: string;
  status: 'PENDING' | 'IN_PROGRESS' | 'COMPLETED' | 'FAILED';
  timestamp?: string;
  detail?: string;
}

export interface SmartContract {
  id: string;
  title: string;
  type: 'CONDITIONAL_PAYMENT' | 'VOUCHER_RULE' | 'ESCROW' | 'AUTO_SETTLEMENT' | 'SCHEDULED' | 'M2M' | 'GOVT_DISBURSEMENT' | 'ASSET_DVP';
  creatorName: string;
  conditionDescription: string;
  targetAmount: number;
  status: 'ACTIVE' | 'EXECUTING' | 'COMPLETED' | 'PAUSED';
  currentStepIndex: number;
  executionSteps: SmartContractStep[];
  updatedAt: string;
}

export interface DigitalAsset {
  id: string;
  code: string;
  name: string;
  assetType: 'TREASURY_BOND' | 'CORPORATE_BOND' | 'MUTUAL_FUND' | 'MMF' | 'REAL_ESTATE_CERT';
  issuerName: string;
  totalFaceValue: number;
  couponRate: number; // %
  maturityDate: string;
  unitPrice: number; // KRW
  totalQuantity: number;
  availableQuantity: number;
}

export interface LiquidityQueueItem {
  id: string;
  bankId: string;
  bankName: string;
  requiredLiquidity: number;
  availableLiquidity: number;
  deficitAmount: number;
  queueStatus: 'RESOLVED' | 'PENDING_COLLATERAL' | 'QUEUED';
  queuedTime: string;
  reason: string;
}

export interface AmlAlert {
  id: string;
  timestamp: string;
  riskLevel: 'HIGH' | 'MEDIUM' | 'LOW';
  txId: string;
  amount: number;
  walletId: string;
  walletName: string;
  userName?: string;
  reason: string;
  detectionType: 'VELOCITY_SPIKE' | 'STRUCTURING' | 'RAPID_MOVEMENT' | 'SANCTION_MATCH' | 'IDENTITY_ANOMALY';
  status: 'INVESTIGATING' | 'FLAGGED' | 'CLEARED' | 'BLOCKED';
  alertType?: string;
  riskScore?: number;
  description?: string;
  flaggedAmount?: number;
}

export interface OfflineSession {
  id: string;
  deviceA: string;
  deviceB: string;
  amount: number;
  txHash: string;
  timestamp: string;
  status: 'OFFLINE_PAIRED' | 'SYNCED_TO_LEDGER' | 'DOUBLE_SPEND_PREVENTED';
}

export interface AiAgent {
  id: string;
  agentName: string;
  ownerWalletId: string;
  ownerName: string;
  authorizedCategories: string[];
  maxPerTxLimit: number;
  maxDailyLimit: number;
  currentSpentToday: number;
  status: 'AUTHORIZED' | 'PAUSED' | 'REVOKED';
  lastAction: string;
}

export interface CrossBorderCorridor {
  id: string;
  countryCode: string;
  countryName: string;
  currencyCode: string;
  systemName: string;
  fxRateKRW: number;
  dailySettlementVolumeKRW: number;
  avgSettlementTimeSec: number;
  status: 'ACTIVE' | 'MAINTENANCE';
}

export interface EconomicVariables {
  cbdcAdoptionRatePct: number;
  depositTokenSupplyTrillion: number;
  bankDepositTrillion: number;
  moneyVelocity: number;
  consumptionIndex: number;
  investmentIndex: number;
  gdpGrowthRatePct: number;
  inflationRatePct: number;
  baseInterestRatePct: number;
  baseInterestRate?: number;
  depositTokenFeeRate?: number;
  reserveRequirementRatio?: number;
  dailyTransactionLimit?: number;
}

export interface FinancialStability {
  systemicRiskIndex: number;
  depositMigrationVelocity: number;
  interbankContagionExposure: number;
  bankRunWarningLevel: string;
}

export interface InfraNode {
  id: string;
  name: string;
  role: string;
  city: string;
  cpuUsagePct: number;
  cpuUsagePercent?: number;
  memoryUsagePct: number;
  memUsagePercent?: number;
  networkBandwidthGbps: number;
  syncStatus: 'SYNCED' | 'CATCHING_UP' | 'OFFLINE';
  status?: string;
  tps: number;
  latencyMs: number;
  queuedTxCount: number;
  failedTxCount: number;
  dbStatus: 'HEALTHY' | 'WARNING' | 'ERROR';
}

export interface CityMapNode {
  id: string;
  name: string;
  lat: number;
  lng: number;
  txVolumePerSec: number;
  activeWallets: number;
  cityType: 'METROPOLIS' | 'PROVINCIAL' | 'SPECIAL_CITY';
}

export interface Merchant {
  id: string;
  name: string;
  category: string;
  city: string;
  dailyVolumeKRW: number;
  avgTxValueKRW: number;
  depositTokenRatioPct: number;
  voucherRatioPct: number;
  settlementLatencySec: number;
}

export interface AuditRecord {
  id: string;
  timestamp: string;
  entityType: string;
  entityId: string;
  action: string;
  previousStateSummary: string;
  newStateSummary: string;
  authorizedBy: string;
  consensusNodes: string[];
  blockHash: string;
  eventType?: string;
  actor?: string;
  details?: string;
  hash?: string;
}

export type PrivacyRole =
  | 'BOK_ADMIN'
  | 'COMMERCIAL_BANK'
  | 'REGULATOR_FSS'
  | 'LAW_ENFORCEMENT'
  | 'INDIVIDUAL_USER'
  | 'MERCHANT'
  | 'USER'
  | 'BANK'
  | 'BOK'
  | 'SUPERVISOR'
  | 'AUDITOR';

export interface PrivacyPermissionRule {
  actor: PrivacyRole;
  canViewIdentity: boolean;
  canViewBalance: boolean;
  canViewCounterparty: boolean;
  canViewAmount: boolean;
  canViewHistory: boolean;
  requiresWarrant: boolean;
}
