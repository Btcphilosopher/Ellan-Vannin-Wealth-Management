import React from 'react';
import { useFinancialStore } from './store/useFinancialStore';
import { Header } from './components/layout/Header';
import { Sidebar } from './components/layout/Sidebar';
import { Footer } from './components/layout/Footer';

// Views
import { DashboardView } from './components/views/DashboardView';
import { BokCoreView } from './components/views/BokCoreView';
import { TokenizedDepositsView } from './components/views/TokenizedDepositsView';
import { UnifiedLedgerView } from './components/views/UnifiedLedgerView';
import { DigitalWalletView } from './components/views/DigitalWalletView';
import { KoreanPaymentUxView } from './components/views/KoreanPaymentUxView';
import { DigitalVouchersView } from './components/views/DigitalVouchersView';
import { SmartContractsView } from './components/views/SmartContractsView';
import { DigitalAssetsView } from './components/views/DigitalAssetsView';
import { SecuritiesView } from './components/views/SecuritiesView';
import { BankingSystemView } from './components/views/BankingSystemView';
import { LiquidityControlView } from './components/views/LiquidityControlView';
import { FinancialStabilityView } from './components/views/FinancialStabilityView';
import { PrivacyMatrixView } from './components/views/PrivacyMatrixView';
import { KycAmlView } from './components/views/KycAmlView';
import { OfflinePaymentsView } from './components/views/OfflinePaymentsView';
import { AiPaymentAgentsView } from './components/views/AiPaymentAgentsView';
import { CrossBorderView } from './components/views/CrossBorderView';
import { EconomicSimulatorView } from './components/views/EconomicSimulatorView';
import { ResearchLabView } from './components/views/ResearchLabView';
import { FinancialMapView } from './components/views/FinancialMapView';
import { MerchantNetworkView } from './components/views/MerchantNetworkView';
import { TransactionLabView } from './components/views/TransactionLabView';
import { AuditLogView } from './components/views/AuditLogView';
import { InfrastructureView } from './components/views/InfrastructureView';
import { NationalCommandCenterView } from './components/views/NationalCommandCenterView';

export function App() {
  const { currentView } = useFinancialStore();

  const renderActiveView = () => {
    switch (currentView) {
      case 'dashboard':
        return <DashboardView />;
      case 'bok_core':
        return <BokCoreView />;
      case 'tokenized_deposits':
        return <TokenizedDepositsView />;
      case 'unified_ledger':
        return <UnifiedLedgerView />;
      case 'digital_wallets':
        return <DigitalWalletView />;
      case 'korean_payment_ux':
        return <KoreanPaymentUxView />;
      case 'digital_vouchers':
        return <DigitalVouchersView />;
      case 'smart_contracts':
        return <SmartContractsView />;
      case 'digital_assets':
        return <DigitalAssetsView />;
      case 'securities':
        return <SecuritiesView />;
      case 'banking_system':
        return <BankingSystemView />;
      case 'liquidity_control':
        return <LiquidityControlView />;
      case 'financial_stability':
        return <FinancialStabilityView />;
      case 'privacy_matrix':
        return <PrivacyMatrixView />;
      case 'kyc_aml':
        return <KycAmlView />;
      case 'offline_payments':
        return <OfflinePaymentsView />;
      case 'ai_payment_agents':
        return <AiPaymentAgentsView />;
      case 'cross_border':
        return <CrossBorderView />;
      case 'economic_simulator':
        return <EconomicSimulatorView />;
      case 'research_lab':
        return <ResearchLabView />;
      case 'financial_map':
        return <FinancialMapView />;
      case 'merchant_network':
        return <MerchantNetworkView />;
      case 'transaction_lab':
        return <TransactionLabView />;
      case 'audit_log':
        return <AuditLogView />;
      case 'infrastructure':
        return <InfrastructureView />;
      case 'national_command_center':
        return <NationalCommandCenterView />;
      default:
        return <DashboardView />;
    }
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-slate-950 text-slate-100 overflow-hidden font-sans select-none">
      {/* Header Bar */}
      <Header />

      {/* Main Container */}
      <div className="flex flex-1 overflow-hidden relative">
        {/* Navigation Sidebar */}
        <Sidebar />

        {/* Dynamic Main Workspace View */}
        <main className="flex-1 overflow-y-auto bg-slate-900/60 custom-scrollbar">
          {renderActiveView()}
        </main>
      </div>

      {/* Persistent Disclaimer Footer */}
      <Footer />
    </div>
  );
}

export default App;
