import {
  Institution,
  BankBalanceSheet,
  Wallet,
  Transaction,
  Voucher,
  SmartContract,
  DigitalAsset,
  LiquidityQueueItem,
  AmlAlert,
  OfflineSession,
  AiAgent,
  CrossBorderCorridor,
  EconomicVariables,
  InfraNode,
  CityMapNode,
  Merchant,
  AuditRecord,
  PrivacyPermissionRule
} from '../types';

export const INITIAL_INSTITUTIONS: Institution[] = [
  {
    id: 'BOK-001',
    name: '한국은행',
    code: 'BOK',
    type: 'CENTRAL_BANK',
    cbdcBalance: 8420000000000, // ₩8.42조
    collateralBalance: 12500000000000,
    intradayLiquidity: 25000000000000,
    intradaySettlementVolume: 18700000000000,
    pendingTxCount: 12,
    riskStatus: 'STABLE',
    nodeHealth: 'NORMAL'
  },
  {
    id: 'BANK-HANKANG',
    name: '한강은행',
    code: 'HKB',
    type: 'COMMERCIAL_BANK',
    cbdcBalance: 1850000000000,
    collateralBalance: 2400000000000,
    intradayLiquidity: 3200000000000,
    intradaySettlementVolume: 4200000000000,
    pendingTxCount: 4,
    riskStatus: 'STABLE',
    nodeHealth: 'NORMAL'
  },
  {
    id: 'BANK-KB-SEOUL',
    name: '서울국민은행',
    code: 'SKB',
    type: 'COMMERCIAL_BANK',
    cbdcBalance: 1920000000000,
    collateralBalance: 2600000000000,
    intradayLiquidity: 3500000000000,
    intradaySettlementVolume: 4800000000000,
    pendingTxCount: 2,
    riskStatus: 'STABLE',
    nodeHealth: 'NORMAL'
  },
  {
    id: 'BANK-KOREA-COMM',
    name: '대한민국상업은행',
    code: 'KCB',
    type: 'COMMERCIAL_BANK',
    cbdcBalance: 1450000000000,
    collateralBalance: 1900000000000,
    intradayLiquidity: 2800000000000,
    intradaySettlementVolume: 3100000000000,
    pendingTxCount: 5,
    riskStatus: 'STABLE',
    nodeHealth: 'NORMAL'
  },
  {
    id: 'BANK-DONGA',
    name: '동아은행',
    code: 'DAB',
    type: 'COMMERCIAL_BANK',
    cbdcBalance: 1120000000000,
    collateralBalance: 1500000000000,
    intradayLiquidity: 2100000000000,
    intradaySettlementVolume: 2400000000000,
    pendingTxCount: 1,
    riskStatus: 'STABLE',
    nodeHealth: 'NORMAL'
  },
  {
    id: 'BANK-BUSAN-FIN',
    name: '부산금융은행',
    code: 'BFB',
    type: 'COMMERCIAL_BANK',
    cbdcBalance: 880000000000,
    collateralBalance: 1200000000000,
    intradayLiquidity: 1600000000000,
    intradaySettlementVolume: 1800000000000,
    pendingTxCount: 0,
    riskStatus: 'STABLE',
    nodeHealth: 'NORMAL'
  },
  {
    id: 'BANK-MIRAE',
    name: '미래은행',
    code: 'MRB',
    type: 'COMMERCIAL_BANK',
    cbdcBalance: 720000000000,
    collateralBalance: 950000000000,
    intradayLiquidity: 1300000000000,
    intradaySettlementVolume: 1400000000000,
    pendingTxCount: 3,
    riskStatus: 'STABLE',
    nodeHealth: 'NORMAL'
  },
  {
    id: 'BANK-HANSEONG',
    name: '한성은행',
    code: 'HSB',
    type: 'COMMERCIAL_BANK',
    cbdcBalance: 480000000000,
    collateralBalance: 700000000000,
    intradayLiquidity: 900000000000,
    intradaySettlementVolume: 1000000000000,
    pendingTxCount: 1,
    riskStatus: 'STABLE',
    nodeHealth: 'NORMAL'
  },
  {
    id: 'SEC-KOREA-INV',
    name: '한국투자증권',
    code: 'KIS',
    type: 'SECURITIES_FIRM',
    cbdcBalance: 650000000000,
    collateralBalance: 1800000000000,
    intradayLiquidity: 2200000000000,
    intradaySettlementVolume: 2900000000000,
    pendingTxCount: 3,
    riskStatus: 'STABLE',
    nodeHealth: 'NORMAL'
  }
];

export const INITIAL_BANK_BALANCE_SHEETS: BankBalanceSheet[] = [
  {
    bankId: 'BANK-HANKANG',
    bankName: '한강은행',
    assets: {
      cbdcReserves: 1850000000000,
      commercialDepositsAtBok: 2100000000000,
      loans: 42000000000000,
      securities: 11000000000000,
      otherAssets: 3050000000000,
      totalAssets: 60000000000000
    },
    liabilities: {
      customerDeposits: 51200000000000,
      tokenizedDepositsIssued: 1750000000000,
      centralBankBorrowings: 1200000000000,
      otherLiabilities: 1850000000000,
      totalLiabilities: 56000000000000
    },
    equity: {
      capitalStock: 2500000000000,
      retainedEarnings: 1500000000000,
      totalEquity: 4000000000000
    },
    capitalAdequacyRatio: 16.42,
    liquidityCoverageRatio: 142.8
  },
  {
    bankId: 'BANK-KB-SEOUL',
    bankName: '서울국민은행',
    assets: {
      cbdcReserves: 1920000000000,
      commercialDepositsAtBok: 2300000000000,
      loans: 45000000000000,
      securities: 12500000000000,
      otherAssets: 3280000000000,
      totalAssets: 65000000000000
    },
    liabilities: {
      customerDeposits: 55400000000000,
      tokenizedDepositsIssued: 1820000000000,
      centralBankBorrowings: 1100000000000,
      otherLiabilities: 2280000000000,
      totalLiabilities: 60600000000000
    },
    equity: {
      capitalStock: 2800000000000,
      retainedEarnings: 1600000000000,
      totalEquity: 4400000000000
    },
    capitalAdequacyRatio: 16.85,
    liquidityCoverageRatio: 148.2
  },
  {
    bankId: 'BANK-KOREA-COMM',
    bankName: '대한민국상업은행',
    assets: {
      cbdcReserves: 1450000000000,
      commercialDepositsAtBok: 1600000000000,
      loans: 32000000000000,
      securities: 8500000000000,
      otherAssets: 1450000000000,
      totalAssets: 45000000000000
    },
    liabilities: {
      customerDeposits: 38800000000000,
      tokenizedDepositsIssued: 1050000000000,
      centralBankBorrowings: 900000000000,
      otherLiabilities: 1250000000000,
      totalLiabilities: 42000000000000
    },
    equity: {
      capitalStock: 1800000000000,
      retainedEarnings: 1200000000000,
      totalEquity: 3000000000000
    },
    capitalAdequacyRatio: 15.92,
    liquidityCoverageRatio: 135.4
  }
];

export const INITIAL_WALLETS: Wallet[] = [
  {
    id: 'WAL-USER-001',
    ownerName: '김철수 (개인)',
    ownerType: 'PERSONAL',
    bankId: 'BANK-HANKANG',
    bankName: '한강은행',
    depositTokenBalance: 3450000,
    voucherBalance: 200000,
    availableBalance: 3650000,
    offlineBalance: 100000,
    dailySpendLimit: 10000000,
    spentToday: 48500,
    kycStatus: 'VERIFIED',
    kycLevel: 3,
    privacyAddress: '0x8f3c...b4a1',
    updatedAt: '2026-09-18 09:40:12'
  },
  {
    id: 'WAL-MERCHANT-001',
    ownerName: '서울 디지털 마켓 (가맹점)',
    ownerType: 'MERCHANT',
    bankId: 'BANK-KB-SEOUL',
    bankName: '서울국민은행',
    depositTokenBalance: 128400000,
    voucherBalance: 15200000,
    availableBalance: 143600000,
    offlineBalance: 500000,
    dailySpendLimit: 500000000,
    spentToday: 12500000,
    kycStatus: 'VERIFIED',
    kycLevel: 3,
    privacyAddress: '0x12a9...ef88',
    updatedAt: '2026-09-18 09:41:05'
  },
  {
    id: 'WAL-CORP-HYUNDAI',
    ownerName: '(주)한국모빌리티 (기업)',
    ownerType: 'CORPORATE',
    bankId: 'BANK-KOREA-COMM',
    bankName: '대한민국상업은행',
    depositTokenBalance: 15200000000,
    voucherBalance: 0,
    availableBalance: 15200000000,
    offlineBalance: 0,
    dailySpendLimit: 100000000000,
    spentToday: 2400000000,
    kycStatus: 'VERIFIED',
    kycLevel: 3,
    privacyAddress: '0x44d1...99bc',
    updatedAt: '2026-09-18 09:35:00'
  },
  {
    id: 'WAL-GOVT-SEOUL',
    ownerName: '서울특별시청 재정담당 (정부)',
    ownerType: 'GOVT',
    bankId: 'BANK-HANKANG',
    bankName: '한강은행',
    depositTokenBalance: 850000000000,
    voucherBalance: 50000000000,
    availableBalance: 900000000000,
    offlineBalance: 0,
    dailySpendLimit: 500000000000,
    spentToday: 12000000000,
    kycStatus: 'VERIFIED',
    kycLevel: 3,
    privacyAddress: '0x9900...11aa',
    updatedAt: '2026-09-18 09:00:00'
  }
];

export const INITIAL_TRANSACTIONS: Transaction[] = [
  {
    txId: 'TX-20260918-094201-9812',
    timestamp: '2026-09-18 09:42:01',
    blockHeight: 1482093,
    senderId: 'WAL-USER-001',
    senderName: '김철수 (개인)',
    receiverId: 'WAL-MERCHANT-001',
    receiverName: '서울 디지털 마켓',
    issuingInstitutionId: 'BANK-HANKANG',
    issuingInstitutionName: '한강은행',
    tokenType: 'TOKENIZED_DEPOSIT',
    amount: 48500,
    fee: 0,
    status: 'SUCCESS',
    paymentMethod: 'QR',
    consensusVerified: true,
    finalityDurationSec: 0.35,
    auditHash: '0x7e12f84a9101c43d9a1b8c2e',
    memo: '서울 디지털 마켓 결제'
  },
  {
    txId: 'TX-20260918-094145-4421',
    timestamp: '2026-09-18 09:41:45',
    blockHeight: 1482092,
    senderId: 'BANK-HANKANG',
    senderName: '한강은행',
    receiverId: 'BANK-KB-SEOUL',
    receiverName: '서울국민은행',
    issuingInstitutionId: 'BOK-001',
    issuingInstitutionName: '한국은행',
    tokenType: 'INSTITUTIONAL_CBDC',
    amount: 25000000000,
    fee: 0,
    status: 'SUCCESS',
    paymentMethod: 'BATCH',
    consensusVerified: true,
    finalityDurationSec: 0.42,
    auditHash: '0x22ab89c104f91d8e33f110c7',
    memo: '일중 청산 차액 정산'
  },
  {
    txId: 'TX-20260918-094030-1109',
    timestamp: '2026-09-18 09:40:30',
    blockHeight: 1482090,
    senderId: 'WAL-GOVT-SEOUL',
    senderName: '서울특별시청',
    receiverId: 'WAL-USER-001',
    receiverName: '김철수 (개인)',
    issuingInstitutionId: 'BANK-HANKANG',
    issuingInstitutionName: '한강은행',
    tokenType: 'DIGITAL_VOUCHER',
    amount: 200000,
    fee: 0,
    status: 'SUCCESS',
    paymentMethod: 'ONLINE',
    consensusVerified: true,
    finalityDurationSec: 0.31,
    smartContractId: 'SC-VOUCHER-CULTURE-01',
    auditHash: '0x10d8e29a00bb21a9f0e1',
    memo: '2026 3분기 서울 문화지원 바우처 지급'
  },
  {
    txId: 'TX-20260918-093812-7731',
    timestamp: '2026-09-18 09:38:12',
    blockHeight: 1482088,
    senderId: 'SEC-KOREA-INV',
    senderName: '한국투자증권',
    receiverId: 'BANK-HANKANG',
    receiverName: '한강은행',
    issuingInstitutionId: 'BOK-001',
    issuingInstitutionName: '한국은행',
    tokenType: 'TOKENIZED_ASSET',
    amount: 100000000000,
    fee: 500000,
    status: 'SUCCESS',
    paymentMethod: 'DVP',
    consensusVerified: true,
    finalityDurationSec: 0.29,
    smartContractId: 'SC-DVP-BOND-2026',
    auditHash: '0x88f910023a1005ec34b',
    memo: '토큰화 국채 26-1호 매매 원자적 DVP 동시 결제'
  }
];

export const INITIAL_VOUCHERS: Voucher[] = [
  {
    id: 'VC-001',
    title: '서울 청년지원 바우처',
    issuingAgency: '서울특별시청',
    totalIssuedAmount: 100000000000, // 1000억원
    remainingAmount: 42100000000,
    allowedCategories: ['교육', '서점', '문화시설', '대중교통'],
    validFrom: '2026.01.01',
    validUntil: '2026.12.31',
    restrictionDescription: '만 19~34세 서울시 주민 대상, 지정 학원 및 문화 가맹점 전용',
    eligibleMerchantsCount: 14200,
    status: 'ACTIVE'
  },
  {
    id: 'VC-002',
    title: '서울 문화지원 바우처',
    issuingAgency: '문화체육관광부 / 서울시',
    totalIssuedAmount: 50000000000,
    remainingAmount: 18500000000,
    allowedCategories: ['공연', '박물관', '서점', '영화관'],
    validFrom: '2026.09.01',
    validUntil: '2026.12.31',
    restrictionDescription: '공연장, 박물관, 서점 가맹점에서만 자동 소진, 기타 업종 승인 거절',
    eligibleMerchantsCount: 8900,
    status: 'ACTIVE'
  },
  {
    id: 'VC-003',
    title: '소상공인 지원 바우처',
    issuingAgency: '중소벤처기업부',
    totalIssuedAmount: 200000000000,
    remainingAmount: 89000000000,
    allowedCategories: ['전통시장', '동네마트', '식당', '카페'],
    validFrom: '2026.03.01',
    validUntil: '2026.11.30',
    restrictionDescription: '대형마트, 백화점, 유흥업종 사용 불가 스마트계약 규칙 적용',
    eligibleMerchantsCount: 65000,
    status: 'ACTIVE'
  }
];

export const INITIAL_SMART_CONTRACTS: SmartContract[] = [
  {
    id: 'SC-DVP-BOND-2026',
    title: '토큰화 국채 DVP 동시결제 계약',
    type: 'ASSET_DVP',
    creatorName: '한국은행 결제국',
    conditionDescription: '자산 이전(국채 ₩100억)과 결제 이전(예금토큰 ₩100억)이 원자적으로 동시 성립할 때만 최종 결제 승인',
    targetAmount: 10000000000,
    status: 'COMPLETED',
    currentStepIndex: 5,
    executionSteps: [
      { stepName: '1. 계약조건 및 서명 검증', status: 'COMPLETED', timestamp: '09:38:10.102' },
      { stepName: '2. 자산 증권계좌 락업(Lock-up)', status: 'COMPLETED', timestamp: '09:38:10.215' },
      { stepName: '3. 자금 예금토큰 에스크로', status: 'COMPLETED', timestamp: '09:38:10.301' },
      { stepName: '4. 통합원장 원자적 크로스-체인 교환 실행', status: 'COMPLETED', timestamp: '09:38:10.410' },
      { stepName: '5. 최종 결제 완결성(Finality) 부여 및 감사 기록', status: 'COMPLETED', timestamp: '09:38:10.510' }
    ],
    updatedAt: '2026-09-18 09:38:12'
  },
  {
    id: 'SC-VOUCHER-CULTURE-01',
    title: '디지털 바우처 조건부 소진 계약',
    type: 'VOUCHER_RULE',
    creatorName: '서울특별시 청년지원단',
    conditionDescription: '가맹점 업종코드(MCC)가 5942(서점), 7922(공연장)인 경우에만 예금토큰 1:1 차감 차등 적용',
    targetAmount: 200000,
    status: 'ACTIVE',
    currentStepIndex: 2,
    executionSteps: [
      { stepName: '1. 바우처 잔액 검증', status: 'COMPLETED', timestamp: '09:40:28.011' },
      { stepName: '2. 가맹점 MCC 코드 정책 검증 (7922 OK)', status: 'COMPLETED', timestamp: '09:40:28.115' },
      { stepName: '3. 가맹점 원장 차감 및 영수증 승인', status: 'IN_PROGRESS', timestamp: '09:40:28.201' },
      { stepName: '4. 원장 정산 반영', status: 'PENDING' }
    ],
    updatedAt: '2026-09-18 09:40:30'
  }
];

export const INITIAL_DIGITAL_ASSETS: DigitalAsset[] = [
  {
    id: 'ASSET-BOND-KR26',
    code: 'KR103502G9C1',
    name: '토큰화 국고채권 26-1호',
    assetType: 'TREASURY_BOND',
    issuerName: '대한민국 기획재정부',
    totalFaceValue: 1000000000000, // ₩1조
    couponRate: 3.25,
    maturityDate: '2029.03.10',
    unitPrice: 10000,
    totalQuantity: 100000000,
    availableQuantity: 42000000
  },
  {
    id: 'ASSET-CORP-SEC26',
    code: 'KR6005931G92',
    name: '삼성전자 토큰화 회사채 2026-A',
    assetType: 'CORPORATE_BOND',
    issuerName: '삼성전자 (주)',
    totalFaceValue: 500000000000,
    couponRate: 3.85,
    maturityDate: '2028.09.15',
    unitPrice: 10000,
    totalQuantity: 50000000,
    availableQuantity: 18000000
  },
  {
    id: 'ASSET-FUND-HOUSING',
    code: 'KR7800100F12',
    name: '한국주택금융 토큰화 펀드',
    assetType: 'MUTUAL_FUND',
    issuerName: '한국주택금융공사',
    totalFaceValue: 300000000000,
    couponRate: 4.10,
    maturityDate: '2027.12.31',
    unitPrice: 10000,
    totalQuantity: 30000000,
    availableQuantity: 12500000
  }
];

export const INITIAL_LIQUIDITY_QUEUES: LiquidityQueueItem[] = [
  {
    id: 'LQ-001',
    bankId: 'BANK-DONGA',
    bankName: '동아은행',
    requiredLiquidity: 280000000000, // ₩2,800억
    availableLiquidity: 241000000000, // ₩2,410억
    deficitAmount: 39000000000, // ₩390억
    queueStatus: 'QUEUED',
    queuedTime: '09:41:12',
    reason: '일중 대규모 법인결제 요청에 따른 콜 자금 정산 대기'
  }
];

export const INITIAL_AML_ALERTS: AmlAlert[] = [
  {
    id: 'AML-20260918-001',
    timestamp: '2026-09-18 09:32:11',
    riskLevel: 'HIGH',
    txId: 'TX-SUSPICIOUS-9912',
    amount: 980000000, // ₩9.8억
    walletId: 'WAL-ANON-7789',
    walletName: '미상 확인 지갑 (수출입상사)',
    reason: '10분 이내 ₩9.8천만원 단위 분할 송금 10회 연속 실행 (Structuring 패턴)',
    detectionType: 'STRUCTURING',
    status: 'FLAGGED'
  },
  {
    id: 'AML-20260918-002',
    timestamp: '2026-09-18 09:15:40',
    riskLevel: 'MEDIUM',
    txId: 'TX-VELOCITY-3312',
    amount: 150000000,
    walletId: 'WAL-USER-8812',
    walletName: '박영희 (개인)',
    reason: '평소 평균 결제금액(₩5만) 대비 3,000배 급증한 단일 결제 시도',
    detectionType: 'VELOCITY_SPIKE',
    status: 'INVESTIGATING'
  }
];

export const INITIAL_OFFLINE_SESSIONS: OfflineSession[] = [
  {
    id: 'OFF-SESS-102',
    deviceA: '스마트폰 A (삼성 Galaxy S26 Ultra / Secure Element)',
    deviceB: '가맹점 단말기 B (NFC 터치 패드)',
    amount: 25000,
    txHash: '0xoff_99182a0b',
    timestamp: '2026-09-18 08:50:11',
    status: 'OFFLINE_PAIRED'
  }
];

export const INITIAL_AI_AGENTS: AiAgent[] = [
  {
    id: 'AI-AGENT-EV-01',
    agentName: '전기차 자동충전 결제 에이전트',
    ownerWalletId: 'WAL-USER-001',
    ownerName: '김철수',
    authorizedCategories: ['전기차충전소', '주차장'],
    maxPerTxLimit: 80000,
    maxDailyLimit: 200000,
    currentSpentToday: 32000,
    status: 'AUTHORIZED',
    lastAction: '서울 강남 EV충전소 ₩32,000 자동결제 완료 (09:15)'
  }
];

export const INITIAL_CROSS_BORDER_CORRIDORS: CrossBorderCorridor[] = [
  {
    id: 'CB-USD',
    countryCode: 'US',
    countryName: '미국 (FedNow / US CBDC)',
    currencyCode: 'USD',
    systemName: 'Federal Reserve mCBDC Network',
    fxRateKRW: 1335.50,
    dailySettlementVolumeKRW: 420000000000,
    avgSettlementTimeSec: 0.85,
    status: 'ACTIVE'
  },
  {
    id: 'CB-EUR',
    countryCode: 'EU',
    countryName: '유럽연합 (Digital Euro)',
    currencyCode: 'EUR',
    systemName: 'ECB Institutional Bridge',
    fxRateKRW: 1485.20,
    dailySettlementVolumeKRW: 280000000000,
    avgSettlementTimeSec: 0.92,
    status: 'ACTIVE'
  },
  {
    id: 'CB-JPY',
    countryCode: 'JP',
    countryName: '일본 (Digital Yen)',
    currencyCode: 'JPY',
    systemName: 'Bank of Japan DLT Hub',
    fxRateKRW: 9.12,
    dailySettlementVolumeKRW: 310000000000,
    avgSettlementTimeSec: 0.65,
    status: 'ACTIVE'
  },
  {
    id: 'CB-SGD',
    countryCode: 'SG',
    countryName: '싱가포르 (Project Dunbar / MAS)',
    currencyCode: 'SGD',
    systemName: 'MAS Multi-CBDC Corridor',
    fxRateKRW: 1015.80,
    dailySettlementVolumeKRW: 190000000000,
    avgSettlementTimeSec: 0.45,
    status: 'ACTIVE'
  }
];

export const INITIAL_ECONOMIC_VARIABLES: EconomicVariables = {
  cbdcAdoptionRatePct: 24.5,
  depositTokenSupplyTrillion: 5.71,
  bankDepositTrillion: 215.4,
  moneyVelocity: 1.48,
  consumptionIndex: 108.2,
  investmentIndex: 102.5,
  gdpGrowthRatePct: 2.35,
  inflationRatePct: 2.10,
  baseInterestRatePct: 3.25
};

export const INITIAL_INFRA_NODES: InfraNode[] = [
  { id: 'NODE-BOK-MAIN', name: '한국은행 본원 주노드', role: '합의 및 최종 완결성 주관', city: '서울', cpuUsagePct: 24, memoryUsagePct: 38, networkBandwidthGbps: 98.2, syncStatus: 'SYNCED', tps: 4820, latencyMs: 12, queuedTxCount: 14, failedTxCount: 0, dbStatus: 'HEALTHY' },
  { id: 'NODE-KFTC-BACKBONE', name: '금융결제원 백본 노드', role: '참여기관 상호연동 인터페이스', city: '서울', cpuUsagePct: 31, memoryUsagePct: 45, networkBandwidthGbps: 84.5, syncStatus: 'SYNCED', tps: 4820, latencyMs: 14, queuedTxCount: 18, failedTxCount: 0, dbStatus: 'HEALTHY' },
  { id: 'NODE-BANK-A', name: '한강은행 검증 노드 (A)', role: '예금 토큰 검증 및 스마트계약', city: '서울', cpuUsagePct: 28, memoryUsagePct: 41, networkBandwidthGbps: 62.1, syncStatus: 'SYNCED', tps: 1200, latencyMs: 18, queuedTxCount: 4, failedTxCount: 0, dbStatus: 'HEALTHY' },
  { id: 'NODE-BANK-B', name: '서울국민은행 검증 노드 (B)', role: '예금 토큰 검증 및 스마트계약', city: '서울', cpuUsagePct: 30, memoryUsagePct: 44, networkBandwidthGbps: 65.4, syncStatus: 'SYNCED', tps: 1350, latencyMs: 16, queuedTxCount: 2, failedTxCount: 0, dbStatus: 'HEALTHY' },
  { id: 'NODE-BANK-C', name: '대한민국상업은행 검증 노드 (C)', role: '예금 토큰 검증', city: '대전', cpuUsagePct: 22, memoryUsagePct: 36, networkBandwidthGbps: 45.0, syncStatus: 'SYNCED', tps: 890, latencyMs: 21, queuedTxCount: 5, failedTxCount: 0, dbStatus: 'HEALTHY' },
  { id: 'NODE-BANK-D', name: '동아은행 검증 노드 (D)', role: '예금 토큰 검증', city: '광주', cpuUsagePct: 25, memoryUsagePct: 39, networkBandwidthGbps: 42.1, syncStatus: 'SYNCED', tps: 710, latencyMs: 24, queuedTxCount: 1, failedTxCount: 0, dbStatus: 'HEALTHY' },
  { id: 'NODE-BANK-E', name: '부산금융은행 검증 노드 (E)', role: '영남권 정산 노드', city: '부산', cpuUsagePct: 29, memoryUsagePct: 42, networkBandwidthGbps: 58.0, syncStatus: 'SYNCED', tps: 980, latencyMs: 22, queuedTxCount: 0, failedTxCount: 0, dbStatus: 'HEALTHY' },
  { id: 'NODE-BANK-F', name: '미래은행 검증 노드 (F)', role: '예금 토큰 검증', city: '대구', cpuUsagePct: 19, memoryUsagePct: 32, networkBandwidthGbps: 38.5, syncStatus: 'SYNCED', tps: 540, latencyMs: 25, queuedTxCount: 3, failedTxCount: 0, dbStatus: 'HEALTHY' },
  { id: 'NODE-BANK-G', name: '한성은행 검증 노드 (G)', role: '예금 토큰 검증', city: '인천', cpuUsagePct: 18, memoryUsagePct: 30, networkBandwidthGbps: 34.0, syncStatus: 'SYNCED', tps: 410, latencyMs: 27, queuedTxCount: 1, failedTxCount: 0, dbStatus: 'HEALTHY' }
];

export const INITIAL_CITY_NODES: CityMapNode[] = [
  { id: 'CITY-SEOUL', name: '서울특별시', lat: 37.5665, lng: 126.9780, txVolumePerSec: 2150, activeWallets: 4250000, cityType: 'METROPOLIS' },
  { id: 'CITY-BUSAN', name: '부산광역시', lat: 35.1796, lng: 129.0756, txVolumePerSec: 620, activeWallets: 1280000, cityType: 'METROPOLIS' },
  { id: 'CITY-INCHEON', name: '인천광역시', lat: 37.4563, lng: 126.7052, txVolumePerSec: 480, activeWallets: 980000, cityType: 'METROPOLIS' },
  { id: 'CITY-DAEGU', name: '대구광역시', lat: 35.8714, lng: 128.6014, txVolumePerSec: 390, activeWallets: 780000, cityType: 'METROPOLIS' },
  { id: 'CITY-DAEJEON', name: '대전광역시', lat: 36.3510, lng: 127.3850, txVolumePerSec: 310, activeWallets: 610000, cityType: 'METROPOLIS' },
  { id: 'CITY-GWANGJU', name: '광주광역시', lat: 35.1595, lng: 126.8526, txVolumePerSec: 280, activeWallets: 540000, cityType: 'METROPOLIS' },
  { id: 'CITY-ULSAN', name: '울산광역시', lat: 35.5384, lng: 129.3114, txVolumePerSec: 220, activeWallets: 420000, cityType: 'METROPOLIS' },
  { id: 'CITY-SEJONG', name: '세종특별자치시', lat: 36.4800, lng: 127.2890, txVolumePerSec: 190, activeWallets: 280000, cityType: 'SPECIAL_CITY' },
  { id: 'CITY-JEJU', name: '제주특별자치도', lat: 33.4996, lng: 126.5312, txVolumePerSec: 180, activeWallets: 310000, cityType: 'SPECIAL_CITY' }
];

export const INITIAL_MERCHANTS: Merchant[] = [
  { id: 'MCH-001', name: 'CU 편의점 테헤란로점', category: '편의점', city: '서울특별시', dailyVolumeKRW: 4200000, avgTxValueKRW: 8500, depositTokenRatioPct: 88, voucherRatioPct: 12, settlementLatencySec: 0.28 },
  { id: 'MCH-002', name: '이마트 여의도점', category: '대형마트', city: '서울특별시', dailyVolumeKRW: 89000000, avgTxValueKRW: 68000, depositTokenRatioPct: 92, voucherRatioPct: 8, settlementLatencySec: 0.31 },
  { id: 'MCH-003', name: '스타벅스 광화문점', category: '카페', city: '서울특별시', dailyVolumeKRW: 12500000, avgTxValueKRW: 12400, depositTokenRatioPct: 95, voucherRatioPct: 5, settlementLatencySec: 0.25 },
  { id: 'MCH-004', name: '교보문고 종로본점', category: '서점', city: '서울특별시', dailyVolumeKRW: 34000000, avgTxValueKRW: 28500, depositTokenRatioPct: 65, voucherRatioPct: 35, settlementLatencySec: 0.29 },
  { id: 'MCH-005', name: '카카오T 교통결제', category: '교통', city: '서울특별시', dailyVolumeKRW: 154000000, avgTxValueKRW: 4200, depositTokenRatioPct: 98, voucherRatioPct: 2, settlementLatencySec: 0.22 },
  { id: 'MCH-006', name: '배달의민족 스마트주문', category: '배달', city: '전국', dailyVolumeKRW: 240000000, avgTxValueKRW: 24500, depositTokenRatioPct: 91, voucherRatioPct: 9, settlementLatencySec: 0.35 }
];

export const INITIAL_AUDIT_RECORDS: AuditRecord[] = [
  {
    id: 'AUDIT-20260918-0001',
    timestamp: '2026-09-18 09:42:01',
    entityType: 'TRANSACTION',
    entityId: 'TX-20260918-094201-9812',
    action: 'TRANSFER_DEPOSIT_TOKEN',
    previousStateSummary: '김철수 잔액: ₩3,498,500 / 가맹점 잔액: ₩128,351,500',
    newStateSummary: '김철수 잔액: ₩3,450,000 / 가맹점 잔액: ₩128,400,000',
    authorizedBy: 'K-CERT-AUTH-0912',
    consensusNodes: ['NODE-BOK-MAIN', 'NODE-KFTC-BACKBONE', 'NODE-BANK-A', 'NODE-BANK-B'],
    blockHash: '0x99a12e84c9012f45880a'
  },
  {
    id: 'AUDIT-20260918-0002',
    timestamp: '2026-09-18 09:38:12',
    entityType: 'SMART_CONTRACT',
    entityId: 'SC-DVP-BOND-2026',
    action: 'EXECUTE_ATOMIC_DVP',
    previousStateSummary: '한국투자증권 국채보유: 100만주 / 한강은행 CBDC잔액: ₩1.85조',
    newStateSummary: '한국투자증권 국채보유: 0주 / 한강은행 CBDC잔액: ₩1.75조',
    authorizedBy: 'BOK-DVP-ENGINE-01',
    consensusNodes: ['NODE-BOK-MAIN', 'NODE-KFTC-BACKBONE', 'NODE-BANK-A'],
    blockHash: '0x10d8a4f912b774cc019a'
  }
];

export const PRIVACY_PERMISSION_MATRIX: PrivacyPermissionRule[] = [
  { actor: 'USER', canViewIdentity: true, canViewBalance: true, canViewCounterparty: true, canViewAmount: true, canViewHistory: true, requiresWarrant: false },
  { actor: 'BANK', canViewIdentity: true, canViewBalance: true, canViewCounterparty: false, canViewAmount: true, canViewHistory: true, requiresWarrant: false },
  { actor: 'BOK', canViewIdentity: false, canViewBalance: false, canViewCounterparty: false, canViewAmount: true, canViewHistory: false, requiresWarrant: false },
  { actor: 'SUPERVISOR', canViewIdentity: false, canViewBalance: false, canViewCounterparty: false, canViewAmount: true, canViewHistory: false, requiresWarrant: true },
  { actor: 'AUDITOR', canViewIdentity: false, canViewBalance: false, canViewCounterparty: false, canViewAmount: true, canViewHistory: true, requiresWarrant: false },
  { actor: 'LAW_ENFORCEMENT', canViewIdentity: true, canViewBalance: true, canViewCounterparty: true, canViewAmount: true, canViewHistory: true, requiresWarrant: true }
];
