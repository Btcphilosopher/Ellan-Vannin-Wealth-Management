import { create } from 'zustand';
import {
  Institution,
  BankBalanceSheet,
  Wallet,
  Transaction,
  Voucher,
  SmartContract,
  DigitalAsset,
  LiquidityQueueItem,
  AmlAlert,
  OfflineSession,
  AiAgent,
  CrossBorderCorridor,
  EconomicVariables,
  FinancialStability,
  InfraNode,
  CityMapNode,
  Merchant,
  AuditRecord,
  PrivacyRole,
  PaymentMethod,
  TokenType
} from '../types';
import {
  INITIAL_INSTITUTIONS,
  INITIAL_BANK_BALANCE_SHEETS,
  INITIAL_WALLETS,
  INITIAL_TRANSACTIONS,
  INITIAL_VOUCHERS,
  INITIAL_SMART_CONTRACTS,
  INITIAL_DIGITAL_ASSETS,
  INITIAL_LIQUIDITY_QUEUES,
  INITIAL_AML_ALERTS,
  INITIAL_OFFLINE_SESSIONS,
  INITIAL_AI_AGENTS,
  INITIAL_CROSS_BORDER_CORRIDORS,
  INITIAL_ECONOMIC_VARIABLES,
  INITIAL_INFRA_NODES,
  INITIAL_CITY_NODES,
  INITIAL_MERCHANTS,
  INITIAL_AUDIT_RECORDS
} from '../data/initialData';

interface FinancialStore {
  // Navigation & Controls
  activeTab: string;
  currentView: string;
  activePrivacyRole: PrivacyRole;
  simTime: string;
  speedMultiplier: number;
  isPaused: boolean;
  isOffline: boolean;
  blockHeight: number;

  // Domain Entities
  institutions: Institution[];
  balanceSheets: BankBalanceSheet[];
  wallets: Wallet[];
  transactions: Transaction[];
  vouchers: Voucher[];
  smartContracts: SmartContract[];
  digitalAssets: DigitalAsset[];
  liquidityQueues: LiquidityQueueItem[];
  amlAlerts: AmlAlert[];
  offlineSessions: OfflineSession[];
  aiAgents: AiAgent[];
  crossBorderCorridors: CrossBorderCorridor[];
  economicVariables: EconomicVariables;
  financialStability: FinancialStability;
  infraNodes: InfraNode[];
  cityNodes: CityMapNode[];
  merchants: Merchant[];
  auditRecords: AuditRecord[];

  // Accounting Integrity
  accountingInvariantsMet: boolean;
  invariantErrorMessage: string | null;

  // Actions
  setActiveTab: (tab: string) => void;
  setCurrentView: (view: string) => void;
  setActivePrivacyRole: (role: PrivacyRole) => void;
  setPrivacyRole: (role: PrivacyRole) => void;
  setSpeedMultiplier: (speed: number) => void;
  togglePause: () => void;
  toggleOfflineMode: () => void;
  processOfflineSync: (walletId: string, amount: number) => void;
  stepSimulation: () => void;

  // Business Transactions
  issueCBDC: (institutionId: string, amount: number) => void;
  redeemCBDC: (institutionId: string, amount: number) => void;
  convertDepositToToken: (walletId: string, amount: number) => void;
  convertTokenToDeposit: (walletId: string, amount: number) => void;
  executePayment: (params: {
    senderWalletId: string;
    receiverWalletId: string;
    amount: number;
    paymentMethod: PaymentMethod;
    tokenType?: TokenType;
    voucherId?: string;
    memo?: string;
  }) => { success: boolean; txId?: string; message: string };

  issueVoucher: (newVoucher: Omit<Voucher, 'id'>) => void;
  triggerSmartContract: (contractId: string) => void;
  executeBondDVP: (params: {
    buyerInstitutionId: string;
    sellerInstitutionId: string;
    assetId: string;
    quantity: number;
    amountKRW: number;
  }) => { success: boolean; message: string };

  resolveLiquidityQueue: (queueId: string) => void;
  injectLiquidityShock: (bankId: string, deficitAmount: number) => void;
  resolveAmlAlert: (alertId: string, action: 'CLEAR' | 'BLOCK') => void;
  executeOfflinePayment: (params: { deviceA: string; deviceB: string; amount: number }) => void;
  syncOfflineSessions: () => void;
  executeAiAgentPayment: (agentId: string, merchantName: string, amount: number) => { success: boolean; message: string };
  executeCrossBorderFx: (corridorId: string, amountKRW: number) => { success: boolean; message: string };
  updateEconomicVariable: (key: keyof EconomicVariables, value: number) => void;
  setEconomicVariable: (key: keyof EconomicVariables, value: number) => void;
  resetSimulation: () => void;
  checkAccountingInvariants: () => boolean;
}

export const useFinancialStore = create<FinancialStore>((set, get) => ({
  activeTab: 'dashboard',
  currentView: 'dashboard',
  activePrivacyRole: 'INDIVIDUAL_USER',
  simTime: '2026-09-18 09:42:17',
  speedMultiplier: 1,
  isPaused: false,
  isOffline: false,
  blockHeight: 1482093,

  institutions: INITIAL_INSTITUTIONS,
  balanceSheets: INITIAL_BANK_BALANCE_SHEETS,
  wallets: INITIAL_WALLETS,
  transactions: INITIAL_TRANSACTIONS,
  vouchers: INITIAL_VOUCHERS,
  smartContracts: INITIAL_SMART_CONTRACTS,
  digitalAssets: INITIAL_DIGITAL_ASSETS,
  liquidityQueues: INITIAL_LIQUIDITY_QUEUES,
  amlAlerts: INITIAL_AML_ALERTS,
  offlineSessions: INITIAL_OFFLINE_SESSIONS,
  aiAgents: INITIAL_AI_AGENTS,
  crossBorderCorridors: INITIAL_CROSS_BORDER_CORRIDORS,
  economicVariables: {
    ...INITIAL_ECONOMIC_VARIABLES,
    baseInterestRate: 3.50,
    depositTokenFeeRate: 0.05,
    reserveRequirementRatio: 7.00,
    dailyTransactionLimit: 10000000
  },
  financialStability: {
    systemicRiskIndex: 88.5,
    depositMigrationVelocity: 2.4,
    interbankContagionExposure: 1820000000000,
    bankRunWarningLevel: 'NORMAL'
  },
  infraNodes: INITIAL_INFRA_NODES.map((node) => ({
    ...node,
    status: 'NORMAL',
    cpuUsagePercent: node.cpuUsagePct,
    memUsagePercent: node.memoryUsagePct
  })),
  cityNodes: INITIAL_CITY_NODES,
  merchants: INITIAL_MERCHANTS,
  auditRecords: INITIAL_AUDIT_RECORDS.map((log) => ({
    ...log,
    eventType: log.action,
    actor: log.authorizedBy,
    details: `${log.previousStateSummary} → ${log.newStateSummary}`,
    hash: log.blockHash
  })),

  accountingInvariantsMet: true,
  invariantErrorMessage: null,

  setActiveTab: (tab) => set({ activeTab: tab, currentView: tab }),
  setCurrentView: (view) => set({ currentView: view, activeTab: view }),
  setActivePrivacyRole: (role) => set({ activePrivacyRole: role }),
  setPrivacyRole: (role) => set({ activePrivacyRole: role }),
  setSpeedMultiplier: (speed) => set({ speedMultiplier: speed }),
  togglePause: () => set((state) => ({ isPaused: !state.isPaused })),
  toggleOfflineMode: () => set((state) => ({ isOffline: !state.isOffline })),

  processOfflineSync: (walletId, amount) => {
    const state = get();
    // Reflect synced transaction into central ledger
    state.executePayment({
      senderWalletId: walletId,
      receiverWalletId: 'WAL-MERCHANT-001',
      amount,
      paymentMethod: 'OFFLINE_SYNC',
      memo: '오프라인 결제 원장 재동기화 반영'
    });
  },

  stepSimulation: () => {
    const state = get();
    if (state.isPaused) return;

    // Advance time
    const prevDate = new Date(state.simTime.replace(/\./g, '-'));
    const secondsToAdd = state.speedMultiplier;
    prevDate.setSeconds(prevDate.getSeconds() + secondsToAdd);

    const year = prevDate.getFullYear();
    const month = String(prevDate.getMonth() + 1).padStart(2, '0');
    const day = String(prevDate.getDate()).padStart(2, '0');
    const hours = String(prevDate.getHours()).padStart(2, '0');
    const minutes = String(prevDate.getMinutes()).padStart(2, '0');
    const seconds = String(prevDate.getSeconds()).padStart(2, '0');
    const newSimTime = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;

    // Randomize node metrics slightly
    const updatedNodes = state.infraNodes.map((node) => {
      const cpu = Math.min(99, Math.max(10, Math.floor(node.cpuUsagePct + (Math.random() * 6 - 3))));
      const mem = Math.min(99, Math.max(10, Math.floor(node.memoryUsagePct + (Math.random() * 4 - 2))));
      return {
        ...node,
        cpuUsagePct: cpu,
        cpuUsagePercent: cpu,
        memoryUsagePct: mem,
        memUsagePercent: mem,
        tps: Math.min(8000, Math.max(100, Math.floor(node.tps + (Math.random() * 40 - 20)))),
        latencyMs: Math.min(50, Math.max(5, Math.floor(node.latencyMs + (Math.random() * 2 - 1))))
      };
    });

    // Random synthetic transaction generation occasionally
    let newTransactions = state.transactions;
    let newBlockHeight = state.blockHeight;

    if (Math.random() > 0.4) {
      newBlockHeight += 1;
      const randomAmount = Math.floor(Math.random() * 85000) + 1500;
      const txId = `TX-${year}${month}${day}-${hours}${minutes}${seconds}-${Math.floor(1000 + Math.random() * 9000)}`;

      const newTx: Transaction = {
        txId,
        timestamp: newSimTime,
        blockHeight: newBlockHeight,
        senderId: 'WAL-USER-001',
        senderName: '김철수 (개인)',
        receiverId: 'WAL-MERCHANT-001',
        receiverName: 'CU 편의점 테헤란로점',
        issuingInstitutionId: 'BANK-HANKANG',
        issuingInstitutionName: '한강은행',
        tokenType: 'TOKENIZED_DEPOSIT',
        amount: randomAmount,
        fee: 0,
        status: 'SUCCESS',
        paymentMethod: 'QR',
        consensusVerified: true,
        finalityDurationSec: Number((0.2 + Math.random() * 0.3).toFixed(2)),
        auditHash: `0x${Math.random().toString(16).substring(2, 10)}${Math.random().toString(16).substring(2, 10)}`,
        memo: '자동 생성 실시간 결제'
      };

      newTransactions = [newTx, ...state.transactions.slice(0, 49)];
    }

    set({
      simTime: newSimTime,
      blockHeight: newBlockHeight,
      infraNodes: updatedNodes,
      transactions: newTransactions
    });

    state.checkAccountingInvariants();
  },

  issueCBDC: (institutionId, amount) => {
    const state = get();
    const targetInst = state.institutions.find((i) => i.id === institutionId);

    if (!targetInst) return;

    const updatedInstitutions = state.institutions.map((inst) => {
      if (inst.id === institutionId) {
        return { ...inst, cbdcBalance: inst.cbdcBalance + amount };
      }
      return inst;
    });

    const audit: AuditRecord = {
      id: `AUDIT-${Date.now()}`,
      timestamp: state.simTime,
      entityType: 'INSTITUTIONAL_CBDC',
      entityId: institutionId,
      action: 'ISSUE_CBDC',
      eventType: 'ISSUE_CBDC',
      actor: '한국은행 총재/발행국',
      details: `${targetInst.name} CBDC: ₩${targetInst.cbdcBalance.toLocaleString()} → ₩${(targetInst.cbdcBalance + amount).toLocaleString()}`,
      previousStateSummary: `${targetInst.name} CBDC: ₩${targetInst.cbdcBalance.toLocaleString()}`,
      newStateSummary: `${targetInst.name} CBDC: ₩${(targetInst.cbdcBalance + amount).toLocaleString()}`,
      authorizedBy: '한국은행 총재/발행국',
      consensusNodes: ['NODE-BOK-MAIN', 'NODE-KFTC-BACKBONE'],
      blockHash: `0xbok_iss_${Math.random().toString(16).substring(2, 10)}`,
      hash: `0xbok_iss_${Math.random().toString(16).substring(2, 10)}`
    };

    set({
      institutions: updatedInstitutions,
      auditRecords: [audit, ...state.auditRecords]
    });
  },

  redeemCBDC: (institutionId, amount) => {
    const state = get();
    const targetInst = state.institutions.find((i) => i.id === institutionId);
    if (!targetInst || targetInst.cbdcBalance < amount) return;

    const updatedInstitutions = state.institutions.map((inst) => {
      if (inst.id === institutionId) {
        return { ...inst, cbdcBalance: inst.cbdcBalance - amount };
      }
      return inst;
    });

    const audit: AuditRecord = {
      id: `AUDIT-${Date.now()}`,
      timestamp: state.simTime,
      entityType: 'INSTITUTIONAL_CBDC',
      entityId: institutionId,
      action: 'REDEEM_CBDC',
      eventType: 'REDEEM_CBDC',
      actor: `${targetInst.name} 자금부`,
      details: `${targetInst.name} CBDC 상환: ₩${amount.toLocaleString()}`,
      previousStateSummary: `${targetInst.name} CBDC: ₩${targetInst.cbdcBalance.toLocaleString()}`,
      newStateSummary: `${targetInst.name} CBDC: ₩${(targetInst.cbdcBalance - amount).toLocaleString()}`,
      authorizedBy: `${targetInst.name} 자금부`,
      consensusNodes: ['NODE-BOK-MAIN', 'NODE-KFTC-BACKBONE'],
      blockHash: `0xbok_red_${Math.random().toString(16).substring(2, 10)}`,
      hash: `0xbok_red_${Math.random().toString(16).substring(2, 10)}`
    };

    set({
      institutions: updatedInstitutions,
      auditRecords: [audit, ...state.auditRecords]
    });
  },

  convertDepositToToken: (walletId, amount) => {
    const state = get();
    const targetWallet = state.wallets.find((w) => w.id === walletId);
    if (!targetWallet) return;

    const updatedWallets = state.wallets.map((w) => {
      if (w.id === walletId) {
        const newDepToken = w.depositTokenBalance + amount;
        return {
          ...w,
          depositTokenBalance: newDepToken,
          availableBalance: newDepToken + w.voucherBalance,
          updatedAt: state.simTime
        };
      }
      return w;
    });

    const updatedBalanceSheets = state.balanceSheets.map((bs) => {
      if (bs.bankId === targetWallet.bankId) {
        return {
          ...bs,
          liabilities: {
            ...bs.liabilities,
            customerDeposits: Math.max(0, bs.liabilities.customerDeposits - amount),
            tokenizedDepositsIssued: bs.liabilities.tokenizedDepositsIssued + amount
          }
        };
      }
      return bs;
    });

    set({
      wallets: updatedWallets,
      balanceSheets: updatedBalanceSheets
    });
  },

  convertTokenToDeposit: (walletId, amount) => {
    const state = get();
    const targetWallet = state.wallets.find((w) => w.id === walletId);
    if (!targetWallet || targetWallet.depositTokenBalance < amount) return;

    const updatedWallets = state.wallets.map((w) => {
      if (w.id === walletId) {
        const newDepToken = w.depositTokenBalance - amount;
        return {
          ...w,
          depositTokenBalance: newDepToken,
          availableBalance: newDepToken + w.voucherBalance,
          updatedAt: state.simTime
        };
      }
      return w;
    });

    const updatedBalanceSheets = state.balanceSheets.map((bs) => {
      if (bs.bankId === targetWallet.bankId) {
        return {
          ...bs,
          liabilities: {
            ...bs.liabilities,
            customerDeposits: bs.liabilities.customerDeposits + amount,
            tokenizedDepositsIssued: Math.max(0, bs.liabilities.tokenizedDepositsIssued - amount)
          }
        };
      }
      return bs;
    });

    set({
      wallets: updatedWallets,
      balanceSheets: updatedBalanceSheets
    });
  },

  executePayment: ({ senderWalletId, receiverWalletId, amount, paymentMethod, tokenType, voucherId, memo }) => {
    const state = get();
    const sender = state.wallets.find((w) => w.id === senderWalletId);
    const receiver = state.wallets.find((w) => w.id === receiverWalletId);

    if (!sender) return { success: false, message: '송금자 지갑을 찾을 수 없습니다.' };
    if (!receiver) return { success: false, message: '수취인 지갑을 찾을 수 없습니다.' };

    const useVoucher = Boolean(voucherId) || tokenType === 'DIGITAL_VOUCHER';
    if (useVoucher) {
      if (sender.voucherBalance < amount) {
        return { success: false, message: '바우처 잔액이 부족합니다.' };
      }
    } else {
      if (sender.depositTokenBalance < amount) {
        return { success: false, message: '예금 토큰 잔액이 부족합니다.' };
      }
    }

    const txId = `TX-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;
    const newBlockHeight = state.blockHeight + 1;

    const updatedWallets = state.wallets.map((w) => {
      if (w.id === senderWalletId) {
        const newDepToken = useVoucher ? w.depositTokenBalance : w.depositTokenBalance - amount;
        const newVoucherBal = useVoucher ? w.voucherBalance - amount : w.voucherBalance;
        return {
          ...w,
          depositTokenBalance: newDepToken,
          voucherBalance: newVoucherBal,
          availableBalance: newDepToken + newVoucherBal,
          spentToday: w.spentToday + amount,
          updatedAt: state.simTime
        };
      }
      if (w.id === receiverWalletId) {
        const newDepToken = w.depositTokenBalance + amount;
        return {
          ...w,
          depositTokenBalance: newDepToken,
          availableBalance: newDepToken + w.voucherBalance,
          updatedAt: state.simTime
        };
      }
      return w;
    });

    const newTx: Transaction = {
      txId,
      timestamp: state.simTime,
      blockHeight: newBlockHeight,
      senderId: sender.id,
      senderName: sender.ownerName,
      receiverId: receiver.id,
      receiverName: receiver.ownerName,
      issuingInstitutionId: sender.bankId,
      issuingInstitutionName: sender.bankName,
      tokenType: tokenType || (useVoucher ? 'DIGITAL_VOUCHER' : 'TOKENIZED_DEPOSIT'),
      amount,
      fee: 0,
      status: 'SUCCESS',
      paymentMethod,
      consensusVerified: true,
      finalityDurationSec: 0.38,
      auditHash: `0x${Math.random().toString(16).substring(2, 12)}`,
      memo: memo || `${sender.ownerName} → ${receiver.ownerName} 결제`
    };

    const auditRecord: AuditRecord = {
      id: `AUDIT-${Date.now()}`,
      timestamp: state.simTime,
      entityType: 'TRANSACTION',
      entityId: txId,
      action: 'PAYMENT_SETTLEMENT',
      eventType: 'PAYMENT_SETTLEMENT',
      actor: 'K-CERT-AUTH-0912',
      details: `${sender.ownerName} → ${receiver.ownerName} ₩${amount.toLocaleString()}`,
      previousStateSummary: `${sender.ownerName} (₩${sender.depositTokenBalance.toLocaleString()}) → ${receiver.ownerName}`,
      newStateSummary: `완결 (금액: ₩${amount.toLocaleString()})`,
      authorizedBy: 'K-CERT-AUTH-0912',
      consensusNodes: ['NODE-BOK-MAIN', 'NODE-KFTC-BACKBONE', 'NODE-BANK-A'],
      blockHash: newTx.auditHash,
      hash: newTx.auditHash
    };

    set({
      wallets: updatedWallets,
      transactions: [newTx, ...state.transactions],
      blockHeight: newBlockHeight,
      auditRecords: [auditRecord, ...state.auditRecords]
    });

    return { success: true, txId, message: '결제가 성공적으로 완료되어 통합원장에 정산되었습니다.' };
  },

  issueVoucher: (newVoucher) => {
    const state = get();
    const id = `VC-00${state.vouchers.length + 1}`;
    const voucher: Voucher = { ...newVoucher, id };

    set({ vouchers: [voucher, ...state.vouchers] });
  },

  triggerSmartContract: (contractId) => {
    const state = get();
    const updated = state.smartContracts.map((sc) => {
      if (sc.id === contractId) {
        return {
          ...sc,
          status: 'COMPLETED' as const,
          currentStepIndex: sc.executionSteps.length,
          executionSteps: sc.executionSteps.map((step) => ({ ...step, status: 'COMPLETED' as const })),
          updatedAt: state.simTime
        };
      }
      return sc;
    });
    set({ smartContracts: updated });
  },

  executeBondDVP: ({ buyerInstitutionId, sellerInstitutionId, assetId, quantity, amountKRW }) => {
    const state = get();
    const buyer = state.institutions.find((i) => i.id === buyerInstitutionId);
    const seller = state.institutions.find((i) => i.id === sellerInstitutionId);
    const asset = state.digitalAssets.find((a) => a.id === assetId);

    if (!buyer || !seller || !asset) {
      return { success: false, message: '기관 또는 증권 자산을 찾을 수 없습니다.' };
    }

    if (buyer.cbdcBalance < amountKRW) {
      return { success: false, message: '매수 기관의 결제용 CBDC 잔액이 부족합니다.' };
    }

    const updatedInstitutions = state.institutions.map((i) => {
      if (i.id === buyerInstitutionId) {
        return { ...i, cbdcBalance: i.cbdcBalance - amountKRW };
      }
      if (i.id === sellerInstitutionId) {
        return { ...i, cbdcBalance: i.cbdcBalance + amountKRW };
      }
      return i;
    });

    const updatedAssets = state.digitalAssets.map((a) => {
      if (a.id === assetId) {
        return { ...a, availableQuantity: Math.max(0, a.availableQuantity - quantity) };
      }
      return a;
    });

    const audit: AuditRecord = {
      id: `AUDIT-DVP-${Date.now()}`,
      timestamp: state.simTime,
      entityType: 'DIGITAL_ASSET_DVP',
      entityId: assetId,
      action: 'ATOMIC_DVP_SETTLEMENT',
      eventType: 'ATOMIC_DVP_SETTLEMENT',
      actor: 'BOK-DVP-ENGINE-01',
      details: `DVP: ${buyer.name} ↔ ${seller.name} ₩${amountKRW.toLocaleString()}`,
      previousStateSummary: `매수: ${buyer.name} / 매도: ${seller.name} / 금액: ₩${amountKRW.toLocaleString()}`,
      newStateSummary: `원자적 DVP 완결 (자산 이전 & 결제 동시 완료)`,
      authorizedBy: 'BOK-DVP-ENGINE-01',
      consensusNodes: ['NODE-BOK-MAIN', 'NODE-KFTC-BACKBONE', 'NODE-BANK-A'],
      blockHash: `0xdvp_${Math.random().toString(16).substring(2, 10)}`,
      hash: `0xdvp_${Math.random().toString(16).substring(2, 10)}`
    };

    set({
      institutions: updatedInstitutions,
      digitalAssets: updatedAssets,
      auditRecords: [audit, ...state.auditRecords]
    });

    return { success: true, message: `원자적 DVP 결제 완결! (자산: ${asset.name}, 금액: ₩${amountKRW.toLocaleString()})` };
  },

  resolveLiquidityQueue: (queueId) => {
    const state = get();
    const queueItem = state.liquidityQueues.find((q) => q.id === queueId);
    if (!queueItem) return;

    const updatedQueues = state.liquidityQueues.map((q) => {
      if (q.id === queueId) {
        return { ...q, queueStatus: 'RESOLVED' as const };
      }
      return q;
    });

    const updatedInsts = state.institutions.map((inst) => {
      if (inst.id === queueItem.bankId) {
        return {
          ...inst,
          cbdcBalance: inst.cbdcBalance + queueItem.deficitAmount,
          intradayLiquidity: inst.intradayLiquidity + queueItem.deficitAmount,
          riskStatus: 'STABLE' as const
        };
      }
      return inst;
    });

    set({
      liquidityQueues: updatedQueues,
      institutions: updatedInsts
    });
  },

  injectLiquidityShock: (bankId, deficitAmount) => {
    const state = get();
    const bank = state.institutions.find((i) => i.id === bankId);
    if (!bank) return;

    const newQueue: LiquidityQueueItem = {
      id: `LQ-${Date.now()}`,
      bankId,
      bankName: bank.name,
      requiredLiquidity: deficitAmount + 100000000000,
      availableLiquidity: 100000000000,
      deficitAmount,
      queueStatus: 'QUEUED',
      queuedTime: state.simTime.split(' ')[1] || '09:45:00',
      reason: '일중 급격한 예금인출 및 타행 결제집중으로 인한 유동성 부족 충격'
    };

    const updatedInsts = state.institutions.map((i) => {
      if (i.id === bankId) {
        return { ...i, riskStatus: 'WARNING' as const };
      }
      return i;
    });

    set({
      liquidityQueues: [newQueue, ...state.liquidityQueues],
      institutions: updatedInsts
    });
  },

  resolveAmlAlert: (alertId, action) => {
    const state = get();
    const updatedAlerts = state.amlAlerts.map((alert) => {
      if (alert.id === alertId) {
        return { ...alert, status: action === 'CLEAR' ? ('CLEARED' as const) : ('BLOCKED' as const) };
      }
      return alert;
    });
    set({ amlAlerts: updatedAlerts });
  },

  executeOfflinePayment: ({ deviceA, deviceB, amount }) => {
    const state = get();
    const newSession: OfflineSession = {
      id: `OFF-${Date.now()}`,
      deviceA,
      deviceB,
      amount,
      txHash: `0xoff_${Math.random().toString(16).substring(2, 10)}`,
      timestamp: state.simTime,
      status: 'OFFLINE_PAIRED'
    };
    set({ offlineSessions: [newSession, ...state.offlineSessions] });
  },

  syncOfflineSessions: () => {
    const state = get();
    const updatedSessions = state.offlineSessions.map((sess) => ({
      ...sess,
      status: 'SYNCED_TO_LEDGER' as const
    }));
    set({ offlineSessions: updatedSessions });
  },

  executeAiAgentPayment: (agentId, merchantName, amount) => {
    const state = get();
    const agent = state.aiAgents.find((a) => a.id === agentId);
    if (!agent) return { success: false, message: 'AI 에이전트를 찾을 수 없습니다.' };

    if (agent.status !== 'AUTHORIZED') {
      return { success: false, message: '에이전트 권한이 비활성화 상태입니다.' };
    }

    if (amount > agent.maxPerTxLimit) {
      return { success: false, message: `1회 한도 초과 (설정 한도: ₩${agent.maxPerTxLimit.toLocaleString()})` };
    }

    const updatedAgents = state.aiAgents.map((a) => {
      if (a.id === agentId) {
        return {
          ...a,
          currentSpentToday: a.currentSpentToday + amount,
          lastAction: `${merchantName} ₩${amount.toLocaleString()} 자율결제 승인 및 정산 완료 (${state.simTime.split(' ')[1]})`
        };
      }
      return a;
    });

    set({ aiAgents: updatedAgents });
    return { success: true, message: `AI 에이전트 자율결제 완료: ${merchantName} ₩${amount.toLocaleString()}` };
  },

  executeCrossBorderFx: (corridorId, amountKRW) => {
    const state = get();
    const corridor = state.crossBorderCorridors.find((c) => c.id === corridorId);
    if (!corridor) return { success: false, message: '국가간 결제 회선을 찾을 수 없습니다.' };

    const foreignAmount = (amountKRW / corridor.fxRateKRW).toFixed(2);
    return {
      success: true,
      message: `${corridor.countryName} 회선 결제 완료! ₩${amountKRW.toLocaleString()} → ${foreignAmount} ${corridor.currencyCode} (정산시간: ${corridor.avgSettlementTimeSec}초)`
    };
  },

  updateEconomicVariable: (key, value) => {
    const state = get();
    set({
      economicVariables: {
        ...state.economicVariables,
        [key]: value
      }
    });
  },

  setEconomicVariable: (key, value) => {
    const state = get();
    set({
      economicVariables: {
        ...state.economicVariables,
        [key]: value
      }
    });
  },

  resetSimulation: () => {
    set({
      simTime: '2026-09-18 09:42:17',
      blockHeight: 1482093,
      institutions: INITIAL_INSTITUTIONS,
      balanceSheets: INITIAL_BANK_BALANCE_SHEETS,
      wallets: INITIAL_WALLETS,
      transactions: INITIAL_TRANSACTIONS,
      vouchers: INITIAL_VOUCHERS,
      smartContracts: INITIAL_SMART_CONTRACTS,
      digitalAssets: INITIAL_DIGITAL_ASSETS,
      liquidityQueues: INITIAL_LIQUIDITY_QUEUES,
      amlAlerts: INITIAL_AML_ALERTS,
      offlineSessions: INITIAL_OFFLINE_SESSIONS,
      aiAgents: INITIAL_AI_AGENTS,
      crossBorderCorridors: INITIAL_CROSS_BORDER_CORRIDORS,
      economicVariables: INITIAL_ECONOMIC_VARIABLES,
      infraNodes: INITIAL_INFRA_NODES,
      cityNodes: INITIAL_CITY_NODES,
      merchants: INITIAL_MERCHANTS,
      auditRecords: INITIAL_AUDIT_RECORDS,
      accountingInvariantsMet: true,
      invariantErrorMessage: null
    });
  },

  checkAccountingInvariants: () => {
    const state = get();
    let valid = true;
    let errorMsg: string | null = null;

    for (const bs of state.balanceSheets) {
      const calculatedAssets =
        bs.assets.cbdcReserves +
        bs.assets.commercialDepositsAtBok +
        bs.assets.loans +
        bs.assets.securities +
        bs.assets.otherAssets;

      const calculatedLiabEq =
        bs.liabilities.customerDeposits +
        bs.liabilities.tokenizedDepositsIssued +
        bs.liabilities.centralBankBorrowings +
        bs.liabilities.otherLiabilities +
        bs.equity.capitalStock +
        bs.equity.retainedEarnings;

      if (Math.abs(calculatedAssets - (bs.liabilities.totalLiabilities + bs.equity.totalEquity)) > 100) {
        valid = false;
        errorMsg = `${bs.bankName} 재무상태표 회계 불변식 위반: 자산 ≠ 부채 + 자본`;
        break;
      }
    }

    set({
      accountingInvariantsMet: valid,
      invariantErrorMessage: errorMsg
    });

    return valid;
  }
}));
