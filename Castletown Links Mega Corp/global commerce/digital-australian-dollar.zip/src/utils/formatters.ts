/**
 * Australian Formatting Utilities
 * DIGITAL AUSTRALIAN DOLLAR Infrastructure
 */

import { MoneyType } from '../types';

/**
 * Format currency in standard Australian notation:
 * e.g., A$1,284,580.00 or A$18.49 billion / A$18.49 trillion
 */
export function formatAUD(
  amount: number, 
  options: { compact?: boolean; precision?: number } = {}
): string {
  const { compact = false, precision = 2 } = options;

  if (compact) {
    if (Math.abs(amount) >= 1e12) {
      return `A$${(amount / 1e12).toFixed(precision)} trillion`;
    }
    if (Math.abs(amount) >= 1e9) {
      return `A$${(amount / 1e9).toFixed(precision)} billion`;
    }
    if (Math.abs(amount) >= 1e6) {
      return `A$${(amount / 1e6).toFixed(precision)} million`;
    }
  }

  return new Intl.NumberFormat('en-AU', {
    style: 'currency',
    currency: 'AUD',
    minimumFractionDigits: precision,
    maximumFractionDigits: precision,
  })
    .format(amount)
    .replace('AUD', 'A$');
}

/**
 * Format Australian date and time e.g., "18 Sep 2026, 14:42:08"
 */
export function formatAUDate(dateStrOrObj: string | Date = new Date()): string {
  const date = typeof dateStrOrObj === 'string' ? new Date(dateStrOrObj) : dateStrOrObj;
  
  const day = date.getDate();
  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const month = monthNames[date.getMonth()];
  const year = date.getFullYear();

  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  const seconds = String(date.getSeconds()).padStart(2, '0');

  return `${day} ${month} ${year}, ${hours}:${minutes}:${seconds}`;
}

/**
 * Format timestamp into Australian short date e.g. "18 Sep 2026"
 */
export function formatAUShortDate(dateStrOrObj: string | Date = new Date()): string {
  const date = typeof dateStrOrObj === 'string' ? new Date(dateStrOrObj) : dateStrOrObj;
  const day = date.getDate();
  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const month = monthNames[date.getMonth()];
  const year = date.getFullYear();
  return `${day} ${month} ${year}`;
}

/**
 * Money type designation meta for visual distinction
 */
export function getMoneyTypeMeta(moneyType: MoneyType): {
  label: string;
  shortCode: string;
  description: string;
  bgColor: string;
  textColor: string;
  borderColor: string;
} {
  switch (moneyType) {
    case 'CENTRAL_BANK_CBDC':
      return {
        label: 'Central Bank Money (Digital AUD)',
        shortCode: 'CBDC-AUD',
        description: 'Sovereign liability of the Reserve Bank of Australia. Zero credit/liquidity risk.',
        bgColor: 'bg-[#2e5a44]/10',
        textColor: 'text-[#2e5a44]',
        borderColor: 'border-[#2e5a44]/30',
      };
    case 'COMMERCIAL_BANK_MONEY':
      return {
        label: 'Commercial Bank Money',
        shortCode: 'BANK-AUD',
        description: 'Liability of authorised deposit-taking institution (ADI). Subject to ADI capital controls.',
        bgColor: 'bg-[#0a192f]/10',
        textColor: 'text-[#0a192f]',
        borderColor: 'border-[#0a192f]/30',
      };
    case 'TOKENISED_DEPOSIT':
      return {
        label: 'Tokenised Bank Deposit',
        shortCode: 'TOK-DEP',
        description: 'Programmable, tokenised claim on a commercial bank deposit with atomic settlement.',
        bgColor: 'bg-[#b85c18]/10',
        textColor: 'text-[#b85c18]',
        borderColor: 'border-[#b85c18]/30',
      };
    case 'TOKENISED_ASSET':
      return {
        label: 'Tokenised Financial Asset',
        shortCode: 'TOK-ASSET',
        description: 'Dematerialised digital security or instrument settled DvP via Digital AUD.',
        bgColor: 'bg-[#4a5568]/10',
        textColor: 'text-[#4a5568]',
        borderColor: 'border-[#4a5568]/30',
      };
  }
}
