import React, { useState } from 'react';
import { SimulationProvider } from './simulation/simulationEngine';
import { ViewMode } from './types';
import { Header } from './components/Header';
import { NavigationRail } from './components/NavigationRail';

// Views
import { NationalOverviewView } from './views/NationalOverviewView';
import { DigitalAUDIssuanceView } from './views/DigitalAUDIssuanceView';
import { WholesaleCBDCView } from './views/WholesaleCBDCView';
import { TokenisedDepositsView } from './views/TokenisedDepositsView';
import { TokenisedAssetMarketView } from './views/TokenisedAssetMarketView';
import { ProgrammableMoneyView } from './views/ProgrammableMoneyView';
import { RetailCBDCView } from './views/RetailCBDCView';
import { PaymentsInfrastructureView } from './views/PaymentsInfrastructureView';
import { SettlementView } from './views/SettlementView';
import { BankNetworkView } from './views/BankNetworkView';
import { CorporateTreasuryView } from './views/CorporateTreasuryView';
import { CrossBorderView } from './views/CrossBorderView';
import { LiquidityManagementView } from './views/LiquidityManagementView';
import { RiskComplianceView } from './views/RiskComplianceView';
import { CentralLedgerView } from './views/CentralLedgerView';
import { AustralianFinancialMapView } from './views/AustralianFinancialMapView';
import { EconomicSimulationLabView } from './views/EconomicSimulationLabView';
import { CBDCArchitectureView } from './views/CBDCArchitectureView';
import { APIMonitorView } from './views/APIMonitorView';
import { AuditSystemView } from './views/AuditSystemView';
import { SystemOperationsView } from './views/SystemOperationsView';

export function MainLayout() {
  const [activeView, setActiveView] = useState<ViewMode>('national-overview');

  const renderCurrentView = () => {
    switch (activeView) {
      case 'national-overview':
        return <NationalOverviewView />;
      case 'digital-aud-issuance':
        return <DigitalAUDIssuanceView />;
      case 'wholesale-cbdc':
        return <WholesaleCBDCView />;
      case 'retail-cbdc':
        return <RetailCBDCView />;
      case 'tokenised-deposits':
        return <TokenisedDepositsView />;
      case 'banks-institutions':
        return <BankNetworkView />;
      case 'payments-infrastructure':
        return <PaymentsInfrastructureView />;
      case 'settlement':
        return <SettlementView />;
      case 'tokenised-assets':
        return <TokenisedAssetMarketView />;
      case 'programmable-money':
        return <ProgrammableMoneyView />;
      case 'cross-border':
        return <CrossBorderView />;
      case 'liquidity-management':
        return <LiquidityManagementView />;
      case 'risk-compliance':
        return <RiskComplianceView />;
      case 'market-infrastructure':
        return <AustralianFinancialMapView />;
      case 'corporate-treasury':
        return <CorporateTreasuryView />;
      case 'audit-trail':
        return <AuditSystemView />;
      case 'system-operations':
        return <SystemOperationsView />;
      case 'research-lab':
        return <EconomicSimulationLabView />;
      default:
        return <NationalOverviewView />;
    }
  };

  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-900 flex flex-col font-sans antialiased">
      {/* Institutional Top Navigation Header */}
      <Header />

      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar Rail */}
        <NavigationRail currentView={activeView} onSelectView={setActiveView} />

        {/* Main Content Body */}
        <main className="flex-1 p-6 overflow-y-auto max-w-7xl mx-auto w-full">
          {renderCurrentView()}
        </main>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <SimulationProvider>
      <MainLayout />
    </SimulationProvider>
  );
}
