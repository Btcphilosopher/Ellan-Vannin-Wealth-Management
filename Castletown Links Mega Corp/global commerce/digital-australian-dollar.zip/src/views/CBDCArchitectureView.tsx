/**
 * CBDC ARCHITECTURE VIEW MODULE
 */

import React from 'react';
import { Layers, Cpu, ShieldCheck, Server, KeyRound, Network } from 'lucide-react';

export const CBDCArchitectureView: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2 py-0.5 rounded bg-[#0a192f] text-white text-[10px] font-bold uppercase tracking-wider">
              TECHNICAL BLUEPRINT
            </span>
            <span className="text-xs text-slate-500 font-mono">SYSTEM SPECIFICATION</span>
          </div>
          <h2 className="text-2xl font-extrabold text-[#1e232a] tracking-tight">
            DIGITAL AUD ARCHITECTURE BLUEPRINT
          </h2>
          <p className="text-xs text-slate-600 mt-1 max-w-2xl">
            Two-tier institutional architecture separating central-bank ledger minting from commercial ADI distribution, smart contract programming, and payment gateways.
          </p>
        </div>
      </div>

      {/* Layer Stack Diagram */}
      <div className="space-y-3 font-mono text-xs">
        <div className="bg-[#0f1c2e] text-white p-5 rounded-xl border border-[#1e2e42]">
          <div className="text-emerald-400 font-bold uppercase text-[10px] mb-2 flex items-center gap-2">
            <Server className="w-4 h-4" />
            TIER 1: CENTRAL BANK CORE SOVEREIGN LEDGER
          </div>
          <p className="text-slate-300 text-[11px] mb-3">
            Authoritative state ledger maintained by the Reserve Bank. Executes double-entry minting, burning, and interbank RTGS atomic settlement.
          </p>
          <div className="grid grid-cols-3 gap-2 text-[10px] text-center">
            <div className="p-2 bg-[#18283e] rounded border border-[#2c405c]">Consensus: BFT Distributed Ledger</div>
            <div className="p-2 bg-[#18283e] rounded border border-[#2c405c]">Crypto: Dilithium Post-Quantum</div>
            <div className="p-2 bg-[#18283e] rounded border border-[#2c405c]">Throughput: 10,000+ TPS</div>
          </div>
        </div>

        <div className="bg-[#18283e] text-white p-5 rounded-xl border border-[#2c405c]">
          <div className="text-amber-400 font-bold uppercase text-[10px] mb-2 flex items-center gap-2">
            <Network className="w-4 h-4" />
            TIER 2: ADI COMMERCIAL BANK DISTRIBUTION & PROGRAMMABLE LOGIC
          </div>
          <p className="text-slate-300 text-[11px] mb-3">
            Authorised Deposit-taking Institutions host customer wallets, tokenised deposit minting, programmable smart contract rules, and merchant POS gateways.
          </p>
          <div className="grid grid-cols-3 gap-2 text-[10px] text-center">
            <div className="p-2 bg-[#0f1c2e] rounded border border-[#2c405c]">API: ISO 20022 REST / gRPC</div>
            <div className="p-2 bg-[#0f1c2e] rounded border border-[#2c405c]">Logic: Deterministic WASM Sandbox</div>
            <div className="p-2 bg-[#0f1c2e] rounded border border-[#2c405c]">Offline: Hardware Enclave (Secure Element)</div>
          </div>
        </div>
      </div>
    </div>
  );
};
