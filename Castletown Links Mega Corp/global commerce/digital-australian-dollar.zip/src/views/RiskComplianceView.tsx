/**
 * RISK & COMPLIANCE CENTRE MODULE
 * APRA / AUSTRAC Simulation
 */

import React, { useState } from 'react';
import { useSimulation } from '../simulation/simulationEngine';
import { formatAUD } from '../utils/formatters';
import { ShieldAlert, AlertTriangle, CheckCircle2, Lock, FileSpreadsheet, Eye } from 'lucide-react';

export const RiskComplianceView: React.FC = () => {
  const {
    riskAlerts,
    updateRiskAlertStatus,
    institutions
  } = useSimulation();

  const [selectedAlertId, setSelectedAlertId] = useState<string | null>(null);

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2 py-0.5 rounded bg-rose-800 text-white text-[10px] font-bold uppercase tracking-wider">
                PRUDENTIAL & FINANCIAL CRIME MONITOR
              </span>
              <span className="text-xs text-slate-500 font-mono">APRA / AUSTRAC SIMULATION GATEWAY</span>
            </div>
            <h2 className="text-2xl font-extrabold text-[#1e232a] tracking-tight">
              RISK & COMPLIANCE CONTROL CENTRE
            </h2>
            <p className="text-xs text-slate-600 mt-1 max-w-2xl">
              Automated AML/CTF transaction surveillance, sanctions screening, large-value transfer reporting, and regulatory risk scoring across all digital AUD participants.
            </p>
          </div>

          <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-right font-mono text-xs">
            <div className="text-[10px] text-rose-800 uppercase font-bold">Active Risk Alerts</div>
            <div className="text-lg font-extrabold text-rose-900 mt-0.5">
              {riskAlerts.filter(r => r.status === 'NEW' || r.status === 'FLAGGED').length} Pending Review
            </div>
          </div>
        </div>
      </div>

      {/* Surveillance Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 font-mono">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="text-[10px] font-bold text-slate-500 uppercase font-sans">Large Value Threshold</div>
          <div className="text-xl font-extrabold text-slate-900 mt-1">&gt; A$10,000,000</div>
          <div className="text-[10px] text-slate-500 mt-1">AUSTRAC Real-Time Sweep</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="text-[10px] font-bold text-slate-500 uppercase font-sans">Sanctions Screening</div>
          <div className="text-xl font-extrabold text-emerald-700 mt-1">100% CLEARED</div>
          <div className="text-[10px] text-slate-500 mt-1">DFAT / UN Sanctions Lists</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="text-[10px] font-bold text-slate-500 uppercase font-sans">Anomaly Detection Score</div>
          <div className="text-xl font-extrabold text-emerald-700 mt-1">LOW (0.02%)</div>
          <div className="text-[10px] text-slate-500 mt-1">AI Velocity Model</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="text-[10px] font-bold text-slate-500 uppercase font-sans">APRA Liquidity Buffer</div>
          <div className="text-xl font-extrabold text-[#2e5a44] mt-1">COMPLIANT</div>
          <div className="text-[10px] text-slate-500 mt-1">CPS 234 / LCR Matrix</div>
        </div>
      </div>

      {/* AML/CTF Alerts Table as specified in Prompt */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
        <h3 className="text-sm font-bold text-[#1e232a] uppercase tracking-wide mb-3 pb-2 border-b border-slate-100 flex items-center justify-between">
          <span>AML / CTF SURVEILLANCE ALERT QUEUE</span>
          <span className="text-xs text-slate-400 font-mono">REAL-TIME MONITORING</span>
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 font-bold uppercase tracking-wider text-[10px] border-b border-slate-200 font-mono">
              <tr>
                <th className="p-3">Alert ID</th>
                <th className="p-3">Tx Reference</th>
                <th className="p-3">Entity Involved</th>
                <th className="p-3 text-right">Amount</th>
                <th className="p-3">Flag Category</th>
                <th className="p-3 text-center">Risk Level</th>
                <th className="p-3 text-center">Status</th>
                <th className="p-3 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono">
              {riskAlerts.map(alert => (
                <tr key={alert.id} className="hover:bg-slate-50">
                  <td className="p-3 font-bold text-slate-800">{alert.id}</td>
                  <td className="p-3 text-slate-600">{alert.txId}</td>
                  <td className="p-3 font-sans font-semibold text-slate-800">{alert.entityName}</td>
                  <td className="p-3 text-right font-bold text-slate-900">{formatAUD(alert.amount)}</td>
                  <td className="p-3 text-[11px] font-sans font-medium text-slate-700">{alert.category}</td>
                  <td className="p-3 text-center font-sans">
                    <span
                      className={`px-2 py-0.5 rounded font-bold text-[10px] ${
                        alert.riskLevel === 'HIGH'
                          ? 'bg-rose-100 text-rose-800 border border-rose-300'
                          : alert.riskLevel === 'MEDIUM'
                          ? 'bg-amber-100 text-amber-800 border border-amber-300'
                          : 'bg-emerald-100 text-emerald-800'
                      }`}
                    >
                      {alert.riskLevel} RISK
                    </span>
                  </td>
                  <td className="p-3 text-center font-sans font-bold text-[10px]">
                    {alert.status}
                  </td>
                  <td className="p-3 text-center font-sans">
                    <div className="flex justify-center gap-1">
                      <button
                        onClick={() => updateRiskAlertStatus(alert.id, 'APPROVED')}
                        className="px-2 py-1 bg-emerald-700 hover:bg-emerald-800 text-white text-[10px] font-bold rounded transition"
                      >
                        Approve
                      </button>
                      <button
                        onClick={() => updateRiskAlertStatus(alert.id, 'FLAGGED')}
                        className="px-2 py-1 bg-rose-700 hover:bg-rose-800 text-white text-[10px] font-bold rounded transition"
                      >
                        Hold / Flag
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
