/**
 * AUSTRALIAN FINANCIAL MAP & INFRASTRUCTURE NODE MODULE
 */

import React, { useState } from 'react';
import { formatAUD } from '../utils/formatters';
import { MapPin, Landmark, Server, Activity, ShieldCheck, ArrowRight } from 'lucide-react';

interface FinancialNode {
  id: string;
  cityName: string;
  state: string;
  nodeType: string;
  keyEntities: string[];
  settlementVolume: number;
  latencyMs: number;
  status: string;
  xPct: number; // For SVG map overlay coordinates
  yPct: number;
}

const NODES: FinancialNode[] = [
  {
    id: 'syd',
    cityName: 'Sydney',
    state: 'NSW',
    nodeType: 'RBA Core Primary & ASX Settlement Hub',
    keyEntities: ['Reserve Bank Primary Data Centre', 'ASX Settlement Node', 'Southern Cross Bank HQ', 'Commonwealth Financial Sim HQ'],
    settlementVolume: 425000000000,
    latencyMs: 1.2,
    status: 'OPTIMAL (PRIMARY)',
    xPct: 83,
    yPct: 71,
  },
  {
    id: 'mel',
    cityName: 'Melbourne',
    state: 'VIC',
    nodeType: 'Secondary Treasury & Commercial Banking Hub',
    keyEntities: ['RBA Secondary Disaster Recovery Node', 'Pacific National Bank HQ', 'Corporate Treasury Hub'],
    settlementVolume: 280000000000,
    latencyMs: 3.4,
    status: 'OPTIMAL (ACTIVE REPLICA)',
    xPct: 75,
    yPct: 82,
  },
  {
    id: 'bne',
    cityName: 'Brisbane',
    state: 'QLD',
    nodeType: 'Regional Liquidity & Agriculture Trade Node',
    keyEntities: ['Australian Metropolitan Bank North', 'Agri-Trade Settlement Clearing'],
    settlementVolume: 95000000000,
    latencyMs: 4.8,
    status: 'OPERATIONAL',
    xPct: 86,
    yPct: 54,
  },
  {
    id: 'per',
    cityName: 'Perth',
    state: 'WA',
    nodeType: 'Commodities & Trade Settlement Hub',
    keyEntities: ['Resources & Mining Trade Settlement Gateway', 'Southern Capital WA Node'],
    settlementVolume: 140000000000,
    latencyMs: 18.2,
    status: 'OPERATIONAL',
    xPct: 22,
    yPct: 68,
  },
  {
    id: 'adl',
    cityName: 'Adelaide',
    state: 'SA',
    nodeType: 'Regional Settlement Node',
    keyEntities: ['Defense & Regional Business Clearing'],
    settlementVolume: 48000000000,
    latencyMs: 8.5,
    status: 'OPERATIONAL',
    xPct: 63,
    yPct: 74,
  },
  {
    id: 'cbr',
    cityName: 'Canberra',
    state: 'ACT',
    nodeType: 'Commonwealth Treasury & Policy Command',
    keyEntities: ['Australian Department of the Treasury Policy Node', 'APRA / AUSTRAC Regulatory Link'],
    settlementVolume: 12000000000,
    latencyMs: 2.1,
    status: 'OPERATIONAL',
    xPct: 81,
    yPct: 75,
  },
];

export const AustralianFinancialMapView: React.FC = () => {
  const [selectedNode, setSelectedNode] = useState<FinancialNode>(NODES[0]);

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2 py-0.5 rounded bg-[#2e5a44] text-white text-[10px] font-bold uppercase tracking-wider">
                NATIONAL INFRASTRUCTURE TOPOLOGY
              </span>
              <span className="text-xs text-slate-500 font-mono">CONTINENTAL CLEARING MAP</span>
            </div>
            <h2 className="text-2xl font-extrabold text-[#1e232a] tracking-tight">
              AUSTRALIAN FINANCIAL INFRASTRUCTURE MAP
            </h2>
            <p className="text-xs text-slate-600 mt-1 max-w-2xl">
              Geographic topology of the simulated Digital AUD core ledger nodes, primary data centers, and regional commercial banking clearing gateways across Australia.
            </p>
          </div>
        </div>
      </div>

      {/* Map + Detail Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Interactive Australia Map Representation */}
        <div className="lg:col-span-2 bg-[#0f1c2e] text-white rounded-xl border border-[#1e2e42] p-6 relative overflow-hidden min-h-[420px] flex flex-col justify-between">
          <div className="flex justify-between items-center z-10">
            <div className="text-xs font-bold text-emerald-400 uppercase tracking-widest font-mono">
              CONTINENTAL CLEARING NODES
            </div>
            <span className="px-2.5 py-1 bg-[#18283e] rounded border border-[#2c405c] text-[10px] font-mono text-slate-300">
              ● 6 Primary Nodes Active
            </span>
          </div>

          {/* SVG Map Container */}
          <div className="relative w-full h-[320px] my-4 bg-[#142338]/60 rounded-xl border border-[#1e2e42] overflow-hidden">
            {/* Map Decorative Grid Lines */}
            <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e2e42_1px,transparent_1px),linear-gradient(to_bottom,#1e2e42_1px,transparent_1px)] bg-[size:32px_32px] opacity-30"></div>

            {/* City Nodes */}
            {NODES.map(node => {
              const isSelected = node.id === selectedNode.id;
              return (
                <button
                  key={node.id}
                  onClick={() => setSelectedNode(node)}
                  style={{ left: `${node.xPct}%`, top: `${node.yPct}%` }}
                  className="absolute -translate-x-1/2 -translate-y-1/2 group focus:outline-none"
                >
                  <div className="relative flex items-center justify-center">
                    <span className={`absolute w-6 h-6 rounded-full animate-ping ${isSelected ? 'bg-emerald-400/50' : 'bg-slate-400/20'}`}></span>
                    <div className={`w-3.5 h-3.5 rounded-full border-2 transition ${isSelected ? 'bg-emerald-400 border-white shadow-lg shadow-emerald-400/50 scale-125' : 'bg-slate-300 border-slate-600'}`}></div>
                    <span className={`absolute top-4 whitespace-nowrap text-[10px] font-bold font-mono px-1.5 py-0.5 rounded shadow ${isSelected ? 'bg-emerald-500 text-white' : 'bg-[#0a192f] text-slate-300'}`}>
                      {node.cityName} ({node.state})
                    </span>
                  </div>
                </button>
              );
            })}
          </div>

          <div className="text-[10px] font-mono text-slate-400 text-center">
            Click any financial node marker to inspect regional clearing topology and live metrics.
          </div>
        </div>

        {/* Selected Node Details Card */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-3 pb-2 border-b border-slate-100">
              <MapPin className="w-5 h-5 text-[#2e5a44]" />
              <div>
                <h3 className="text-base font-extrabold text-[#1e232a]">
                  {selectedNode.cityName}, {selectedNode.state}
                </h3>
                <span className="text-[10px] font-mono text-slate-500 uppercase">{selectedNode.nodeType}</span>
              </div>
            </div>

            <div className="space-y-4 text-xs">
              <div>
                <span className="text-[10px] text-slate-500 font-bold uppercase block mb-1">Key Entities Hosted</span>
                <div className="space-y-1">
                  {selectedNode.keyEntities.map((ent, idx) => (
                    <div key={idx} className="p-2 bg-slate-50 border border-slate-200 rounded font-semibold text-slate-800 text-[11px]">
                      • {ent}
                    </div>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 font-mono">
                <div className="p-2.5 bg-slate-50 border border-slate-200 rounded">
                  <span className="text-[10px] text-slate-500 block uppercase font-sans">Settlement Volume</span>
                  <span className="font-extrabold text-[#2e5a44]">{formatAUD(selectedNode.settlementVolume, { compact: true })}</span>
                </div>

                <div className="p-2.5 bg-slate-50 border border-slate-200 rounded">
                  <span className="text-[10px] text-slate-500 block uppercase font-sans">Network Latency</span>
                  <span className="font-extrabold text-slate-900">{selectedNode.latencyMs} ms</span>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-4 p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-xs font-mono font-bold text-emerald-900 flex justify-between items-center">
            <span>STATUS: {selectedNode.status}</span>
            <span className="text-[10px] text-emerald-700">100% HEALTHY</span>
          </div>
        </div>
      </div>
    </div>
  );
};
