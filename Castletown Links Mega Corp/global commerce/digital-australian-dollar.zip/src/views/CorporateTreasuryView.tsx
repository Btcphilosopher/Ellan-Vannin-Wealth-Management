/**
 * CORPORATE TREASURY MODULE
 */

import React, { useState } from 'react';
import { useSimulation } from '../simulation/simulationEngine';
import { formatAUD } from '../utils/formatters';
import { Building2, TrendingUp, RefreshCw, ArrowRight, ShieldCheck, CheckCircle2 } from 'lucide-react';

export const CorporateTreasuryView: React.FC = () => {
  const { institutions } = useSimulation();

  const [operatingBal, setOperatingBal] = useState<number>(145000000);
  const [targetOperatingBal, setTargetOperatingBal] = useState<number>(50000000);
  const [sweptTokenised, setSweptTokenised] = useState<number>(95000000);
  const [sweepExecuted, setSweepExecuted] = useState<boolean>(false);

  const executeSweep = () => {
    if (operatingBal > targetOperatingBal) {
      const excess = operatingBal - targetOperatingBal;
      setOperatingBal(targetOperatingBal);
      setSweptTokenised(prev => prev + excess);
      setSweepExecuted(true);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2 py-0.5 rounded bg-[#0a192f] text-white text-[10px] font-bold uppercase tracking-wider">
                ENTERPRISE CASH MANAGEMENT
              </span>
              <span className="text-xs text-slate-500 font-mono">AUTOMATED LIQUIDITY SWEEP</span>
            </div>
            <h2 className="text-2xl font-extrabold text-[#1e232a] tracking-tight">
              CORPORATE TREASURY & LIQUIDITY
            </h2>
            <p className="text-xs text-slate-600 mt-1 max-w-2xl">
              24/7 programmable working capital optimization for Australian enterprise treasuries, enabling zero-balance accounts (ZBA) and automated tokenised deposit yields.
            </p>
          </div>

          <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-right font-mono">
            <div className="text-[10px] text-slate-500 uppercase font-bold">Treasury Portfolio Yield</div>
            <div className="text-lg font-bold text-[#2e5a44] mt-0.5">4.35% p.a. (RBA Cash Rate Linked)</div>
          </div>
        </div>
      </div>

      {/* Corporate Treasury Flow Diagram as specified in Prompt */}
      <div className="bg-[#0f1c2e] text-white p-4 rounded-xl border border-[#1e2e42]">
        <div className="text-[10px] font-bold text-amber-400 uppercase tracking-widest mb-2">
          PROGRAMMABLE TREASURY SWEEP FLOW
        </div>
        <div className="flex flex-col sm:flex-row items-center justify-between gap-2 text-center text-xs font-semibold">
          <div className="bg-[#18283e] p-2.5 rounded border border-[#2c405c] w-full">1. Operating Account Balance</div>
          <ArrowRight className="w-4 h-4 text-amber-400 shrink-0 hidden sm:block" />
          <div className="bg-[#18283e] p-2.5 rounded border border-[#2c405c] w-full">2. Treasury Sweep Rule</div>
          <ArrowRight className="w-4 h-4 text-amber-400 shrink-0 hidden sm:block" />
          <div className="bg-[#18283e] p-2.5 rounded border border-[#2c405c] w-full">3. Automated Tokenisation</div>
          <ArrowRight className="w-4 h-4 text-amber-400 shrink-0 hidden sm:block" />
          <div className="bg-[#2e5a44] p-2.5 rounded border border-emerald-500 w-full font-bold">4. Yield Optimisation</div>
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 font-mono">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="text-[10px] font-bold text-slate-500 uppercase font-sans">Operating Cash Balance</div>
          <div className="text-xl font-extrabold text-[#0a192f] mt-1">{formatAUD(operatingBal)}</div>
          <div className="text-[10px] text-slate-500 mt-1">Target Buffer: {formatAUD(targetOperatingBal)}</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="text-[10px] font-bold text-slate-500 uppercase font-sans">Tokenised Yield Deposits</div>
          <div className="text-xl font-extrabold text-[#b85c18] mt-1">{formatAUD(sweptTokenised)}</div>
          <div className="text-[10px] text-emerald-700 font-bold mt-1">+A$11,301 daily yield accrual</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="text-[10px] font-bold text-slate-500 uppercase font-sans">Digital AUD Liquidity Reserve</div>
          <div className="text-xl font-extrabold text-[#2e5a44] mt-1">{formatAUD(82000000)}</div>
          <div className="text-[10px] text-slate-500 mt-1">Central Bank Instant Cash</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="text-[10px] font-bold text-slate-500 uppercase font-sans">Foreign Exchange Exposure</div>
          <div className="text-xl font-extrabold text-slate-800 mt-1">USD $12.5M</div>
          <div className="text-[10px] text-slate-500 mt-1">Hedged via mCBDC Corridor</div>
        </div>
      </div>

      {/* Interactive Treasury Sweep Simulator */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <h3 className="text-sm font-bold text-[#1e232a] uppercase tracking-wide mb-4 pb-2 border-b border-slate-100 flex items-center gap-2">
          <RefreshCw className="w-4 h-4 text-[#2e5a44]" />
          AUTOMATED WORKING CAPITAL SWEEP DEMONSTRATOR
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
          <div className="space-y-3 text-xs">
            <p className="text-slate-600 leading-relaxed">
              When corporate operating balances exceed the target liquidity threshold of <strong>{formatAUD(targetOperatingBal)}</strong>, the automated sweep rule instantly tokenises excess cash into high-yield ADI deposits.
            </p>

            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 font-mono">
              <div className="flex justify-between py-1">
                <span className="text-slate-500">Current Operating Account:</span>
                <span className="font-bold text-slate-900">{formatAUD(operatingBal)}</span>
              </div>
              <div className="flex justify-between py-1 border-t border-slate-200">
                <span className="text-slate-500">Target Operational Cap:</span>
                <span className="font-bold text-slate-900">{formatAUD(targetOperatingBal)}</span>
              </div>
              <div className="flex justify-between py-1 border-t border-slate-200">
                <span className="text-slate-500">Available Excess to Sweep:</span>
                <span className="font-bold text-[#b85c18]">
                  {formatAUD(Math.max(0, operatingBal - targetOperatingBal))}
                </span>
              </div>
            </div>

            <button
              onClick={executeSweep}
              disabled={operatingBal <= targetOperatingBal}
              className="w-full py-2.5 px-4 bg-[#2e5a44] hover:bg-[#234635] disabled:bg-slate-300 text-white font-bold text-xs rounded-lg transition flex items-center justify-center gap-2"
            >
              <RefreshCw className="w-4 h-4" />
              TRIGGER PROGRAMMABLE TREASURY SWEEP
            </button>
          </div>

          <div className="p-4 bg-slate-900 text-white rounded-xl font-mono text-xs space-y-3">
            <div className="text-[10px] font-bold text-emerald-400 uppercase">TREASURY SWEEP LOG TELEMETRY</div>

            {sweepExecuted ? (
              <div className="space-y-2 text-emerald-300">
                <div className="flex items-center gap-2 font-bold">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>SWEEP EXECUTION SUCCESSFUL</span>
                </div>
                <p className="text-[11px] text-slate-300">
                  Excess A$95,000,000 swept from Operating Cash into Tokenised Bank Deposit (ID: DEP-SCB-992014). Accruing 4.35% p.a. interest immediately.
                </p>
              </div>
            ) : (
              <p className="text-slate-400 italic">
                Awaiting manual trigger or scheduled automated 17:00 AEST treasury sweep cycle...
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
