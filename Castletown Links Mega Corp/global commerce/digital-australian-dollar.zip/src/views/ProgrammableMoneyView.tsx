/**
 * PROGRAMMABLE MONEY & SMART CONTRACT ENGINE MODULE
 */

import React, { useState } from 'react';
import { useSimulation } from '../simulation/simulationEngine';
import { formatAUD } from '../utils/formatters';
import { InstitutionId, ProgrammableRule } from '../types';
import { Code2, Play, Plus, Clock, CheckCircle2, ShieldCheck } from 'lucide-react';

export const ProgrammableMoneyView: React.FC = () => {
  const {
    programmableRules,
    addProgrammableRule,
    triggerProgrammableRule,
    institutions
  } = useSimulation();

  // Rule Builder Form State
  const [title, setTitle] = useState<string>('BOND DELIVERY-VERSUS-PAYMENT');
  const [useCase, setUseCase] = useState<ProgrammableRule['useCase']>('BOND_DVP');
  const [payerId, setPayerId] = useState<InstitutionId>('cfs');
  const [recipientId, setRecipientId] = useState<InstitutionId>('scb');
  const [amountInput, setAmountInput] = useState<string>('10000000');
  const [assetCode, setAssetCode] = useState<string>('Australian Government Bond — SIMULATION');
  const [condition, setCondition] = useState<string>('SECURITIES DELIVERY CONFIRMED via ASX Registry');
  const [executionDate, setExecutionDate] = useState<string>('2026-09-25');
  const [expiryDate, setExpiryDate] = useState<string>('2026-10-15');

  const [ruleMsg, setRuleMsg] = useState<{ success: boolean; message: string } | null>(null);

  const handleCreateRule = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(amountInput);
    if (isNaN(amount) || amount <= 0) return;

    const payer = institutions.find(i => i.id === payerId);
    const recipient = institutions.find(i => i.id === recipientId);

    if (!payer || !recipient) return;

    addProgrammableRule({
      title,
      useCase,
      payerName: payer.name,
      payerId,
      recipientName: recipient.name,
      recipientId,
      amount,
      assetCode,
      condition,
      executionDate,
      expiryDate,
    });

    setRuleMsg({ success: true, message: `Created Programmable Payment Rule '${title}' successfully!` });
  };

  const handleTrigger = (ruleId: string) => {
    const res = triggerProgrammableRule(ruleId);
    setRuleMsg(res);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2 py-0.5 rounded bg-[#2e5a44] text-white text-[10px] font-bold uppercase tracking-wider">
                PROGRAMMABLE LOGIC LAYER
              </span>
              <span className="text-xs text-slate-500 font-mono">CONDITIONAL ESCROW & AUTOMATION</span>
            </div>
            <h2 className="text-2xl font-extrabold text-[#1e232a] tracking-tight">
              PROGRAMMABLE DIGITAL MONEY
            </h2>
            <p className="text-xs text-slate-600 mt-1 max-w-2xl">
              Deterministic conditional settlement smart contracts for corporate treasury automation, supply chain milestones, escrow, trade finance, and bond delivery-versus-payment.
            </p>
          </div>
        </div>
      </div>

      {/* Rule Builder & Active Rules Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Rule Builder Form */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="flex items-center gap-2 mb-4 pb-2 border-b border-slate-100">
            <Code2 className="w-4 h-4 text-[#2e5a44]" />
            <h3 className="text-sm font-bold text-[#1e232a] uppercase tracking-wide">
              PROGRAMMABLE RULE BUILDER
            </h3>
          </div>

          <form onSubmit={handleCreateRule} className="space-y-3">
            <div>
              <label className="block text-[11px] font-bold text-slate-700 uppercase mb-0.5">Rule Title</label>
              <input
                type="text"
                value={title}
                onChange={e => setTitle(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-xs font-semibold text-slate-800"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 uppercase mb-0.5">Use Case</label>
              <select
                value={useCase}
                onChange={e => setUseCase(e.target.value as ProgrammableRule['useCase'])}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-xs font-semibold text-slate-800"
              >
                <option value="BOND_DVP">Bond Delivery-Versus-Payment</option>
                <option value="CORPORATE_TREASURY">Corporate Treasury Sweep</option>
                <option value="TRADE_FINANCE">Trade Finance Letter of Credit</option>
                <option value="CONDITIONAL_ESCROW">Conditional Escrow</option>
                <option value="INFRASTRUCTURE">Infrastructure Milestone Payment</option>
                <option value="AUTOMATED_TREASURY">Automated Treasury</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 uppercase mb-0.5">Payer</label>
                <select
                  value={payerId}
                  onChange={e => setPayerId(e.target.value as InstitutionId)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-xs font-semibold text-slate-800"
                >
                  {institutions.map(inst => (
                    <option key={inst.id} value={inst.id}>{inst.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 uppercase mb-0.5">Recipient</label>
                <select
                  value={recipientId}
                  onChange={e => setRecipientId(e.target.value as InstitutionId)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-xs font-semibold text-slate-800"
                >
                  {institutions.map(inst => (
                    <option key={inst.id} value={inst.id}>{inst.name}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 uppercase mb-0.5">Payment Value (A$)</label>
                <input
                  type="number"
                  value={amountInput}
                  onChange={e => setAmountInput(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-xs font-mono font-bold text-slate-800"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 uppercase mb-0.5">Asset Code</label>
                <input
                  type="text"
                  value={assetCode}
                  onChange={e => setAssetCode(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-xs font-mono text-slate-800"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 uppercase mb-0.5">Trigger Condition</label>
              <textarea
                rows={2}
                value={condition}
                onChange={e => setCondition(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-xs text-slate-800"
              />
            </div>

            {ruleMsg && (
              <div
                className={`p-2.5 rounded text-xs font-semibold ${
                  ruleMsg.success ? 'bg-emerald-50 text-emerald-900 border border-emerald-200' : 'bg-rose-50 text-rose-900 border border-rose-200'
                }`}
              >
                {ruleMsg.message}
              </div>
            )}

            <button
              type="submit"
              className="w-full py-2 px-4 bg-[#2e5a44] hover:bg-[#234635] text-white font-bold text-xs rounded-lg transition shadow-xs flex items-center justify-center gap-2"
            >
              <Plus className="w-4 h-4" />
              DEPLOY PROGRAMMABLE RULE
            </button>
          </form>
        </div>

        {/* Active Rules List */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
            <h3 className="text-sm font-bold text-[#1e232a] uppercase tracking-wide mb-3 pb-2 border-b border-slate-100">
              ACTIVE PROGRAMMABLE RULES REGISTER
            </h3>

            <div className="space-y-3">
              {programmableRules.map(rule => (
                <div key={rule.id} className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200 pb-2">
                    <div className="flex items-center gap-2">
                      <span className="font-extrabold text-xs text-slate-900">{rule.title}</span>
                      <span className="px-2 py-0.2 rounded bg-slate-200 text-slate-700 font-mono text-[10px] font-bold">
                        {rule.id}
                      </span>
                    </div>

                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
                        rule.status === 'EXECUTED'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-900 border border-amber-300'
                      }`}
                    >
                      {rule.status}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs font-mono">
                    <div>
                      <span className="text-[10px] text-slate-500 block uppercase font-sans">Payer</span>
                      <span className="font-bold text-slate-800">{rule.payerName}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 block uppercase font-sans">Recipient</span>
                      <span className="font-bold text-slate-800">{rule.recipientName}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 block uppercase font-sans">Value</span>
                      <span className="font-bold text-[#2e5a44]">{formatAUD(rule.amount)}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 block uppercase font-sans">Asset</span>
                      <span className="text-slate-700">{rule.assetCode || 'DIGITAL_AUD'}</span>
                    </div>
                  </div>

                  <div className="p-2.5 bg-white rounded border border-slate-200 text-xs">
                    <span className="font-bold text-slate-800 font-sans">CONDITION: </span>
                    <span className="text-slate-700 font-mono">{rule.condition}</span>
                  </div>

                  {rule.status !== 'EXECUTED' && (
                    <div className="pt-2 flex justify-end">
                      <button
                        onClick={() => handleTrigger(rule.id)}
                        className="px-3 py-1.5 bg-[#2e5a44] hover:bg-[#234635] text-white text-xs font-bold rounded flex items-center gap-1.5 transition"
                      >
                        <Play className="w-3.5 h-3.5 fill-current" />
                        TRIGGER CONDITION & SETTLE
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
