/**
 * CROSS-BORDER DIGITAL SETTLEMENT MODULE
 */

import React, { useState } from 'react';
import { useSimulation } from '../simulation/simulationEngine';
import { formatAUD } from '../utils/formatters';
import { Globe, ArrowRight, RefreshCw, CheckCircle2, ShieldCheck } from 'lucide-react';

export const CrossBorderView: React.FC = () => {
  const {
    crossBorderTransfers,
    executeCrossBorderFx
  } = useSimulation();

  const [corridor, setCorridor] = useState<'AUD/USD' | 'AUD/EUR' | 'AUD/JPY' | 'AUD/SGD'>('AUD/USD');
  const [originInst, setOriginInst] = useState<string>('Southern Cross Bank (Sydney)');
  const [foreignInst, setForeignInst] = useState<string>('JPMorgan Chase Sim (New York)');
  const [audAmountInput, setAudAmountInput] = useState<string>('25000000');

  const [resMsg, setResMsg] = useState<{ success: boolean; message: string } | null>(null);

  const handleExecuteFx = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(audAmountInput);
    if (isNaN(amount) || amount <= 0) return;

    const res = executeCrossBorderFx(corridor, originInst, foreignInst, amount);
    setResMsg(res);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2 py-0.5 rounded bg-[#0a192f] text-white text-[10px] font-bold uppercase tracking-wider">
                PAYMENT-VERSUS-PAYMENT (PvP)
              </span>
              <span className="text-xs text-slate-500 font-mono">MULTI-CURRENCY CBDC CORRIDOR</span>
            </div>
            <h2 className="text-2xl font-extrabold text-[#1e232a] tracking-tight">
              CROSS-BORDER DIGITAL SETTLEMENT
            </h2>
            <p className="text-xs text-slate-600 mt-1 max-w-2xl">
              Synchronised multi-central-bank digital currency settlement (mCBDC) delivering atomic Payment-versus-Payment (PvP) FX execution with zero Herstatt settlement risk.
            </p>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-right font-mono text-xs">
            <div className="text-[10px] text-slate-500 uppercase font-bold">Supported FX Corridors</div>
            <div className="font-extrabold text-[#0a192f] mt-0.5">AUD / USD • EUR • JPY • SGD</div>
          </div>
        </div>
      </div>

      {/* Architecture Diagram as specified in Prompt */}
      <div className="bg-[#0f1c2e] text-white p-4 rounded-xl border border-[#1e2e42]">
        <div className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest mb-2">
          CROSS-BORDER MCBDC ARCHITECTURE
        </div>
        <div className="flex flex-col md:flex-row items-center justify-between gap-2 text-center text-xs font-semibold">
          <div className="bg-[#18283e] p-2.5 rounded border border-[#2c405c] w-full">Australian Institution</div>
          <ArrowRight className="w-4 h-4 text-emerald-400 shrink-0 hidden md:block" />
          <div className="bg-[#18283e] p-2.5 rounded border border-[#2c405c] w-full">Digital AUD</div>
          <ArrowRight className="w-4 h-4 text-emerald-400 shrink-0 hidden md:block" />
          <div className="bg-[#2e5a44] p-2.5 rounded border border-emerald-500 w-full font-bold">Cross-Border Settlement Layer</div>
          <ArrowRight className="w-4 h-4 text-emerald-400 shrink-0 hidden md:block" />
          <div className="bg-[#18283e] p-2.5 rounded border border-[#2c405c] w-full">Foreign Institution</div>
          <ArrowRight className="w-4 h-4 text-emerald-400 shrink-0 hidden md:block" />
          <div className="bg-[#18283e] p-2.5 rounded border border-[#2c405c] w-full">Foreign Currency</div>
        </div>
      </div>

      {/* Execution Form & Corridor Log */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* FX Swap Form */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <h3 className="text-sm font-bold text-[#1e232a] uppercase tracking-wide mb-4 pb-2 border-b border-slate-100 flex items-center gap-2">
            <Globe className="w-4 h-4 text-[#0a192f]" />
            EXECUTE ATOMIC PVP FX SWAP
          </h3>

          <form onSubmit={handleExecuteFx} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Currency Corridor</label>
              <select
                value={corridor}
                onChange={e => setCorridor(e.target.value as any)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-xs font-bold text-slate-800"
              >
                <option value="AUD/USD">AUD / USD (Rate: 0.6650)</option>
                <option value="AUD/EUR">AUD / EUR (Rate: 0.6100)</option>
                <option value="AUD/JPY">AUD / JPY (Rate: 98.40)</option>
                <option value="AUD/SGD">AUD / SGD (Rate: 0.8700)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Origin Australian Institution</label>
              <input
                type="text"
                value={originInst}
                onChange={e => setOriginInst(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-xs font-semibold text-slate-800"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Foreign Counterparty Institution</label>
              <input
                type="text"
                value={foreignInst}
                onChange={e => setForeignInst(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-xs font-semibold text-slate-800"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">AUD Amount (A$)</label>
              <input
                type="number"
                value={audAmountInput}
                onChange={e => setAudAmountInput(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-xs font-mono font-bold text-slate-800"
              />
            </div>

            {resMsg && (
              <div
                className={`p-3 rounded-lg text-xs font-semibold ${
                  resMsg.success ? 'bg-emerald-50 text-emerald-900 border border-emerald-200' : 'bg-rose-50 text-rose-900 border border-rose-200'
                }`}
              >
                {resMsg.message}
              </div>
            )}

            <button
              type="submit"
              className="w-full py-2.5 px-4 bg-[#0a192f] hover:bg-[#061224] text-white font-bold text-xs rounded-lg transition shadow-xs flex items-center justify-center gap-2"
            >
              <Globe className="w-4 h-4" />
              SWAP FX ATOMIC PVP
            </button>
          </form>
        </div>

        {/* Cross Border Log Table */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <h3 className="text-sm font-bold text-[#1e232a] uppercase tracking-wide mb-3 pb-2 border-b border-slate-100">
            CROSS-BORDER SETTLEMENT LOG (PVP)
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 font-bold uppercase tracking-wider text-[10px] border-b border-slate-200">
                <tr>
                  <th className="p-3">Transfer ID</th>
                  <th className="p-3">Corridor & Institutions</th>
                  <th className="p-3 text-right">AUD Amount</th>
                  <th className="p-3 text-right">Foreign Currency Value</th>
                  <th className="p-3 text-center">Settlement Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono">
                {crossBorderTransfers.map(xb => (
                  <tr key={xb.id} className="hover:bg-slate-50">
                    <td className="p-3 font-bold text-slate-800">{xb.id}</td>
                    <td className="p-3 font-sans">
                      <div className="font-bold text-[#0a192f]">{xb.corridor}</div>
                      <div className="text-[10px] text-slate-500 font-mono">
                        {xb.originInstitution} → {xb.foreignInstitution}
                      </div>
                    </td>
                    <td className="p-3 text-right font-bold text-[#2e5a44]">
                      {formatAUD(xb.audAmount)}
                    </td>
                    <td className="p-3 text-right font-bold text-slate-800">
                      {xb.foreignCurrency} {xb.foreignAmount.toLocaleString('en-AU', { maximumFractionDigits: 2 })}
                    </td>
                    <td className="p-3 text-center font-sans">
                      <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-bold text-[10px]">
                        {xb.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
