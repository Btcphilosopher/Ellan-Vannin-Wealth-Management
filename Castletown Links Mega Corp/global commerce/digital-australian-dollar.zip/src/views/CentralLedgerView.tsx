/**
 * CENTRAL LEDGER & RTGS EXPLORER MODULE
 */

import React, { useState } from 'react';
import { useSimulation } from '../simulation/simulationEngine';
import { formatAUD } from '../utils/formatters';
import { Database, Search, ShieldCheck, CheckCircle2, Lock, FileCode2 } from 'lucide-react';

export const CentralLedgerView: React.FC = () => {
  const {
    transactions,
    institutions,
    verifyTransactionHash
  } = useSimulation();

  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedTxId, setSelectedTxId] = useState<string | null>(null);
  const [proofVerificationResult, setProofVerificationResult] = useState<string | null>(null);

  const filteredTx = transactions.filter(t =>
    t.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.originName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.destinationName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.purpose.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleVerify = (txId: string) => {
    setSelectedTxId(txId);
    const proof = verifyTransactionHash(txId);
    setProofVerificationResult(proof);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2 py-0.5 rounded bg-[#0a192f] text-white text-[10px] font-bold uppercase tracking-wider">
                RBA CORE STATE ENGINE
              </span>
              <span className="text-xs text-slate-500 font-mono">CRYPTOGRAPHIC PROOF EXPLORER</span>
            </div>
            <h2 className="text-2xl font-extrabold text-[#1e232a] tracking-tight">
              RESERVE BANK CENTRAL LEDGER
            </h2>
            <p className="text-xs text-slate-600 mt-1 max-w-2xl">
              Authoritative, double-entry sovereign state ledger recording all digital AUD minting, interbank RTGS settlements, and atomic DvP finality states.
            </p>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-right font-mono text-xs">
            <div className="text-[10px] text-slate-500 uppercase font-bold">Ledger State Integrity</div>
            <div className="font-extrabold text-emerald-700 mt-0.5">100% IMMUTABLE / VERIFIED</div>
          </div>
        </div>
      </div>

      {/* Ledger Search & Filter Bar */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs flex flex-col md:flex-row gap-3 justify-between items-center">
        <div className="relative w-full md:w-96">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            placeholder="Search by Tx ID, Institution, Purpose..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full bg-slate-50 border border-slate-300 rounded-lg pl-9 pr-3 py-2 text-xs font-mono text-slate-800 focus:outline-none focus:border-[#0a192f]"
          />
        </div>

        <div className="text-xs text-slate-500 font-mono">
          Total Recorded State Mutations: <strong>{transactions.length}</strong>
        </div>
      </div>

      {/* Main Central Ledger Table as specified in Prompt */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
        <h3 className="text-sm font-bold text-[#1e232a] uppercase tracking-wide mb-3 pb-2 border-b border-slate-100">
          IMMUTABLE LEDGER STATE TRANSACTIONS
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 font-bold uppercase tracking-wider text-[10px] border-b border-slate-200 font-mono">
              <tr>
                <th className="p-3">Transaction ID</th>
                <th className="p-3">Timestamp</th>
                <th className="p-3">Origin (Payer)</th>
                <th className="p-3">Destination (Payee)</th>
                <th className="p-3 text-right">Amount</th>
                <th className="p-3">Type</th>
                <th className="p-3">Cryptographic State Hash</th>
                <th className="p-3 text-center">Finality</th>
                <th className="p-3 text-center">Proof Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono">
              {filteredTx.map(tx => (
                <tr key={tx.id} className="hover:bg-slate-50">
                  <td className="p-3 font-bold text-slate-800">{tx.id}</td>
                  <td className="p-3 text-slate-500 text-[11px]">{tx.timestamp}</td>
                  <td className="p-3 font-sans font-semibold text-slate-800">{tx.originName}</td>
                  <td className="p-3 font-sans font-semibold text-slate-800">{tx.destinationName}</td>
                  <td className="p-3 text-right font-bold text-[#2e5a44]">{formatAUD(tx.amount)}</td>
                  <td className="p-3 text-[10px] font-bold text-slate-600">{tx.moneyType.replace(/_/g, ' ')}</td>
                  <td className="p-3 text-[10px] text-slate-400 truncate max-w-[120px]">{tx.stateHash}</td>
                  <td className="p-3 text-center font-sans">
                    <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-bold text-[10px]">
                      {tx.finalityStatus}
                    </span>
                  </td>
                  <td className="p-3 text-center">
                    <button
                      onClick={() => handleVerify(tx.id)}
                      className="px-2 py-1 bg-[#0a192f] hover:bg-slate-800 text-white text-[10px] font-bold rounded transition"
                    >
                      Verify Proof
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Cryptographic Verification Proof Panel */}
      {selectedTxId && proofVerificationResult && (
        <div className="bg-[#0f1c2e] text-white p-5 rounded-xl border border-[#1e2e42] font-mono text-xs space-y-3">
          <div className="flex items-center justify-between border-b border-slate-700 pb-2">
            <div className="flex items-center gap-2 font-bold text-emerald-400">
              <ShieldCheck className="w-5 h-5" />
              <span>CRYPTOGRAPHIC STATE PROOF VERIFICATION — {selectedTxId}</span>
            </div>
            <span className="text-[10px] text-slate-400">RBA Cryptographic Root</span>
          </div>

          <div className="p-3 bg-[#18283e] rounded border border-[#2c405c] text-emerald-300 font-mono text-[11px] whitespace-pre-wrap">
            {proofVerificationResult}
          </div>
        </div>
      )}
    </div>
  );
};
