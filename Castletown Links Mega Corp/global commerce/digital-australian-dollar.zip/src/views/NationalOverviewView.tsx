/**
 * NATIONAL OVERVIEW & RBA COMMAND DASHBOARD
 */

import React from 'react';
import { useSimulation } from '../simulation/simulationEngine';
import { formatAUD, formatAUDate } from '../utils/formatters';
import { Landmark, TrendingUp, ShieldCheck, Activity, Building2, Zap, ArrowUpRight, CheckCircle2 } from 'lucide-react';
import { MoneyTypeLegend } from '../components/MoneyTypeLegend';

export const NationalOverviewView: React.FC = () => {
  const {
    digitalAudTotalOutstanding,
    wholesaleSettlementToday,
    transactionsTodayCount,
    systemMetrics,
    transactions,
    institutions
  } = useSimulation();

  return (
    <div className="space-y-6">
      {/* Top Banner Disclaimer & Title */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded bg-[#2e5a44] text-white text-[10px] font-bold uppercase tracking-wider">
                RESERVE BANK OF AUSTRALIA (SIMULATION)
              </span>
              <span className="text-xs text-slate-500 font-mono">NATIONAL DIGITAL MONEY INFRASTRUCTURE</span>
            </div>
            <h1 className="text-2xl font-extrabold text-[#1e232a] tracking-tight">
              AUSTRALIAN DIGITAL MONEY COMMAND CENTER
            </h1>
            <p className="text-xs text-slate-600 mt-1 max-w-3xl">
              Centralised simulation and research architecture for sovereign central-bank digital currency (Digital AUD), wholesale RTGS settlement, tokenised bank deposits, and dematerialised financial market infrastructure.
            </p>
          </div>

          <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs font-sans text-amber-900 max-w-sm">
            <div className="font-bold flex items-center gap-1.5 text-amber-950 mb-0.5">
              <ShieldCheck className="w-4 h-4 text-amber-700 shrink-0" />
              <span>RESEARCH & SIMULATION ENVIRONMENT</span>
            </div>
            <p className="text-[11px] leading-snug">
              Fictional research environment. Not an actual Reserve Bank of Australia production platform or commercial offering.
            </p>
          </div>
        </div>
      </div>

      {/* Distinction Conceptual Legend Component */}
      <MoneyTypeLegend />

      {/* KPI Metrics Dashboard as specified in Prompt */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Digital AUD Issued</span>
            <Landmark className="w-4 h-4 text-[#2e5a44]" />
          </div>
          <div className="text-2xl font-extrabold font-mono text-[#2e5a44]">
            {formatAUD(digitalAudTotalOutstanding, { compact: true })}
          </div>
          <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-1 font-mono">
            <span className="text-emerald-700 font-bold">100% Backed</span> by RBA Liabilities
          </div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Wholesale Settled Today</span>
            <TrendingUp className="w-4 h-4 text-[#0a192f]" />
          </div>
          <div className="text-2xl font-extrabold font-mono text-[#0a192f]">
            {formatAUD(wholesaleSettlementToday, { compact: true })}
          </div>
          <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-1 font-mono">
            <span className="text-emerald-700 font-bold">{transactionsTodayCount}</span> interbank transfers
          </div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Ledger Throughput</span>
            <Activity className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-extrabold font-mono text-slate-900">
            {systemMetrics.ledgerTPS} <span className="text-sm font-normal text-slate-500">TPS</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-1 font-mono">
            Latency: <span className="font-bold text-slate-800">{systemMetrics.settlementEngineLatency}ms</span>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Connected ADI Banks</span>
            <Building2 className="w-4 h-4 text-[#b85c18]" />
          </div>
          <div className="text-2xl font-extrabold font-mono text-slate-900">
            5 <span className="text-sm font-normal text-slate-500">Participants</span>
          </div>
          <div className="text-[11px] text-emerald-700 font-bold mt-1 font-mono">
            ● 100% API Gateways Online
          </div>
        </div>
      </div>

      {/* Live Activity Stream & System Status */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Real-time Settlement Activity Stream */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4 text-[#2e5a44]" />
              <h3 className="text-sm font-bold text-[#1e232a] uppercase tracking-wide">
                LIVE INTERBANK SETTLEMENT ACTIVITY STREAM
              </h3>
            </div>
            <span className="text-xs font-mono text-slate-500">AUTO-REFRESHING</span>
          </div>

          <div className="space-y-3">
            {transactions.slice(0, 6).map(tx => (
              <div key={tx.id} className="p-3 bg-slate-50 rounded-lg border border-slate-200 flex items-center justify-between hover:bg-slate-100/80 transition">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-xs text-slate-800">{tx.originName}</span>
                    <ArrowUpRight className="w-3.5 h-3.5 text-slate-400" />
                    <span className="font-bold text-xs text-slate-800">{tx.destinationName}</span>
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5 font-mono">
                    {tx.purpose} • <span className="font-semibold text-slate-700">{tx.channel}</span> • {tx.timestamp}
                  </div>
                </div>

                <div className="text-right font-mono">
                  <div className="font-extrabold text-sm text-[#2e5a44]">
                    {formatAUD(tx.amount)}
                  </div>
                  <span className="text-[10px] font-bold bg-emerald-100 text-emerald-800 px-1.5 py-0.2 rounded">
                    {tx.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* System Operations Summary */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-4">
          <h3 className="text-sm font-bold text-[#1e232a] uppercase tracking-wide pb-2 border-b border-slate-100">
            SYSTEM HEALTH & RISK SUMMARY
          </h3>

          <div className="space-y-3 font-mono text-xs">
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
              <div className="text-[10px] text-slate-500 uppercase font-bold">RBA Core Ledger</div>
              <div className="font-bold text-emerald-700 flex items-center gap-1 mt-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                ONLINE / OPERATIONAL
              </div>
            </div>

            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
              <div className="text-[10px] text-slate-500 uppercase font-bold">Pending Queue</div>
              <div className="font-bold text-slate-900 mt-1">0 Transactions Queued</div>
            </div>

            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
              <div className="text-[10px] text-slate-500 uppercase font-bold">AML / CTF Real-time Alerts</div>
              <div className="font-bold text-emerald-700 mt-1">0 High Risk Anomalies</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
