/**
 * WHOLESALE DIGITAL AUD TERMINAL MODULE
 */

import React, { useState } from 'react';
import { useSimulation } from '../simulation/simulationEngine';
import { formatAUD } from '../utils/formatters';
import { InstitutionId, MoneyType } from '../types';
import { Building2, ArrowRightLeft, Send, CheckCircle2, ShieldCheck, Zap } from 'lucide-react';

export const WholesaleCBDCView: React.FC = () => {
  const {
    institutions,
    executeWholesaleTransfer,
    transactions
  } = useSimulation();

  const [originId, setOriginId] = useState<InstitutionId>('scb');
  const [destId, setDestId] = useState<InstitutionId>('cfs');
  const [transferAmount, setTransferAmount] = useState<string>('15000000');
  const [transferPurpose, setTransferPurpose] = useState<string>('Intraday Interbank Liquidity Swap');
  const [moneyType, setMoneyType] = useState<MoneyType>('CENTRAL_BANK_CBDC');

  const [lastTxMsg, setLastTxMsg] = useState<{ success: boolean; message: string } | null>(null);

  const handleTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(transferAmount);
    if (isNaN(amount) || amount <= 0) return;

    const res = executeWholesaleTransfer(originId, destId, amount, transferPurpose, moneyType);
    setLastTxMsg(res);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-[#0f1c2e] text-white rounded-xl p-6 border border-[#1e2e42]">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2 py-0.5 rounded bg-[#2e5a44] text-emerald-200 text-[10px] font-bold uppercase tracking-wider">
                FLAGSHIP WHOLESALE TERMINAL
              </span>
              <span className="text-xs text-slate-400 font-mono">24/7 ATOMIC RTGS EQUIVALENT</span>
            </div>
            <h2 className="text-2xl font-extrabold text-white tracking-tight">
              WHOLESALE DIGITAL AUD SETTLEMENT
            </h2>
            <p className="text-xs text-slate-300 mt-1 max-w-2xl">
              Interbank gross settlement terminal operating on sovereign central-bank money, enabling instant, atomic interbank transfers and collateralised liquidity management.
            </p>
          </div>

          <div className="bg-[#18283e] border border-[#2c405c] p-3 rounded-lg text-right font-mono">
            <div className="text-[10px] text-slate-400 uppercase font-bold">Interbank Queue</div>
            <div className="text-lg font-bold text-emerald-400">0 PENDING / 100% CLEARED</div>
            <div className="text-[10px] text-slate-400">Avg Settlement: 11.4ms</div>
          </div>
        </div>
      </div>

      {/* Main Wholesale Table as Specified in Prompt */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
        <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-100">
          <h3 className="text-sm font-bold text-[#1e232a] uppercase tracking-wide">
            PARTICIPATING ADI INSTITUTION WHOLESALE POSITIONS
          </h3>
          <span className="text-xs text-slate-500 font-mono">
            SYNTHETIC DATA · REAL-TIME STATE
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 font-bold uppercase tracking-wider text-[10px] border-b border-slate-200">
              <tr>
                <th className="p-3">Institution</th>
                <th className="p-3 text-right">Digital AUD Balance</th>
                <th className="p-3 text-right">Pending Settlement</th>
                <th className="p-3 text-right">Intraday Liquidity</th>
                <th className="p-3 text-right">Tokenised Assets</th>
                <th className="p-3 text-right">Settlement Position</th>
                <th className="p-3 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono">
              {institutions.map(inst => (
                <tr key={inst.id} className="hover:bg-slate-50">
                  <td className="p-3 font-bold font-sans text-slate-800">
                    {inst.name}
                    <div className="text-[10px] text-slate-400 font-mono">Code: {inst.code}</div>
                  </td>
                  <td className="p-3 text-right font-bold text-[#2e5a44]">
                    {formatAUD(inst.digitalAudBalance)}
                  </td>
                  <td className="p-3 text-right text-slate-600">
                    {formatAUD(inst.pendingSettlement)}
                  </td>
                  <td className="p-3 text-right text-slate-700">
                    {formatAUD(inst.intradayLiquidity)}
                  </td>
                  <td className="p-3 text-right text-[#4a5568]">
                    {formatAUD(inst.tokenisedAssetValue)}
                  </td>
                  <td className="p-3 text-right font-bold text-[#0a192f]">
                    +{formatAUD(inst.intradayLiquidity + inst.digitalAudBalance, { compact: true })}
                  </td>
                  <td className="p-3 text-center">
                    <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-bold text-[10px]">
                      {inst.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Interbank Transfer Terminal */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="flex items-center gap-2 mb-4 pb-2 border-b border-slate-100">
            <div className="p-1.5 rounded bg-[#2e5a44] text-white">
              <Zap className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-[#1e232a] uppercase tracking-wide">
              EXECUTE INTERBANK WHOLESALE DIGITAL AUD SETTLEMENT
            </h3>
          </div>

          <form onSubmit={handleTransfer} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Origin Institution (Payer)
                </label>
                <select
                  value={originId}
                  onChange={e => setOriginId(e.target.value as InstitutionId)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-xs font-semibold text-slate-800 focus:outline-none focus:border-[#2e5a44]"
                >
                  {institutions.map(inst => (
                    <option key={inst.id} value={inst.id}>
                      {inst.name} — Avail: {formatAUD(inst.digitalAudBalance)}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Destination Institution (Payee)
                </label>
                <select
                  value={destId}
                  onChange={e => setDestId(e.target.value as InstitutionId)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-xs font-semibold text-slate-800 focus:outline-none focus:border-[#2e5a44]"
                >
                  {institutions.map(inst => (
                    <option key={inst.id} value={inst.id}>
                      {inst.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Settlement Money Classification
                </label>
                <select
                  value={moneyType}
                  onChange={e => setMoneyType(e.target.value as MoneyType)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-xs font-semibold text-slate-800 focus:outline-none focus:border-[#2e5a44]"
                >
                  <option value="CENTRAL_BANK_CBDC">Central Bank Money (Digital AUD)</option>
                  <option value="COMMERCIAL_BANK_MONEY">Commercial Bank Money</option>
                  <option value="TOKENISED_DEPOSIT">Tokenised Bank Deposit</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Transfer Amount (A$)
                </label>
                <input
                  type="number"
                  value={transferAmount}
                  onChange={e => setTransferAmount(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-xs font-mono font-bold text-slate-800 focus:outline-none focus:border-[#2e5a44]"
                  placeholder="e.g. 15000000"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Settlement Purpose / Payment Instructions
              </label>
              <input
                type="text"
                value={transferPurpose}
                onChange={e => setTransferPurpose(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-xs text-slate-800 focus:outline-none focus:border-[#2e5a44]"
              />
            </div>

            {lastTxMsg && (
              <div
                className={`p-3 rounded-lg text-xs font-semibold ${
                  lastTxMsg.success ? 'bg-emerald-50 text-emerald-900 border border-emerald-200' : 'bg-rose-50 text-rose-900 border border-rose-200'
                }`}
              >
                {lastTxMsg.message}
              </div>
            )}

            <button
              type="submit"
              className="w-full py-2.5 px-4 bg-[#2e5a44] hover:bg-[#234635] text-white font-bold text-xs rounded-lg transition shadow-xs flex items-center justify-center gap-2"
            >
              <Send className="w-4 h-4" />
              EXECUTE REAL-TIME INTERBANK SETTLEMENT
            </button>
          </form>
        </div>

        {/* Live Wholesale Activity Stream */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-[#1e232a] uppercase tracking-wide mb-3 pb-2 border-b border-slate-100">
              WHOLESALE SETTLEMENT LOG
            </h3>
            <div className="space-y-3 max-h-[300px] overflow-y-auto pr-1">
              {transactions.filter(t => t.channel === 'WHOLESALE_CBDC').slice(0, 5).map(tx => (
                <div key={tx.id} className="p-2.5 rounded bg-slate-50 border border-slate-200 text-xs">
                  <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                    <span>{tx.id}</span>
                    <span>{tx.timestamp}</span>
                  </div>
                  <div className="font-bold text-slate-800 my-0.5">
                    {tx.originName} → {tx.destinationName}
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-mono font-bold text-[#2e5a44]">{formatAUD(tx.amount)}</span>
                    <span className="text-[10px] font-mono bg-emerald-100 text-emerald-800 px-1.5 py-0.2 rounded font-bold">
                      {tx.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 p-3 bg-[#0f1c2e] text-white rounded-lg text-[11px]">
            <div className="font-bold text-emerald-400 uppercase">INTRADAY LIQUIDITY FACILITY</div>
            <p className="text-slate-300 mt-0.5">
              RBA Standing Liquidity Facility automatically collateralises eligible Australian Government Securities (AGS).
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
