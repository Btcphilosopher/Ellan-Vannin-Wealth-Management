/**
 * API & SYSTEM MONITOR MODULE
 */

import React from 'react';
import { useSimulation } from '../simulation/simulationEngine';
import { Terminal, Activity, CheckCircle2, Server, Globe } from 'lucide-react';

export const APIMonitorView: React.FC = () => {
  const { institutions, systemMetrics } = useSimulation();

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2 py-0.5 rounded bg-[#2e5a44] text-white text-[10px] font-bold uppercase tracking-wider">
              GATEWAY TELEMETRY
            </span>
            <span className="text-xs text-slate-500 font-mono">ISO 20022 REST & gRPC API</span>
          </div>
          <h2 className="text-2xl font-extrabold text-[#1e232a] tracking-tight">
            API MONITOR & DEVELOPER PORTAL
          </h2>
          <p className="text-xs text-slate-600 mt-1 max-w-2xl">
            Real-time latency, uptime, request volume, and endpoint health across participating ADI institutional API gateways.
          </p>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
        <h3 className="text-sm font-bold text-[#1e232a] uppercase tracking-wide mb-3 pb-2 border-b border-slate-100">
          INSTITUTIONAL API GATEWAY HEALTH
        </h3>

        <div className="overflow-x-auto font-mono text-xs">
          <table className="w-full text-left">
            <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px] border-b border-slate-200">
              <tr>
                <th className="p-3">Institution</th>
                <th className="p-3">API Endpoint Base</th>
                <th className="p-3 text-right">Avg Response</th>
                <th className="p-3 text-right">Health Score</th>
                <th className="p-3 text-center">Protocol</th>
                <th className="p-3 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {institutions.map(inst => (
                <tr key={inst.id} className="hover:bg-slate-50">
                  <td className="p-3 font-bold text-slate-800 font-sans">{inst.name}</td>
                  <td className="p-3 text-slate-500 font-mono text-[11px]">https://api.{inst.code.toLowerCase()}.sim.rba.gov.au/v1</td>
                  <td className="p-3 text-right font-bold text-slate-800">{(10 + Math.random() * 5).toFixed(1)} ms</td>
                  <td className="p-3 text-right font-bold text-emerald-700">{inst.apiHealth}%</td>
                  <td className="p-3 text-center font-sans">
                    <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-800 font-bold text-[10px]">gRPC / REST</span>
                  </td>
                  <td className="p-3 text-center font-sans">
                    <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-bold text-[10px]">
                      {inst.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
