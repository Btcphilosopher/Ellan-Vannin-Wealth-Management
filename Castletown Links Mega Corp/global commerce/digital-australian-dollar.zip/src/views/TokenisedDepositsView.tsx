/**
 * TOKENISED BANK DEPOSITS MODULE
 */

import React, { useState } from 'react';
import { useSimulation } from '../simulation/simulationEngine';
import { formatAUD } from '../utils/formatters';
import { InstitutionId } from '../types';
import { Coins, Landmark, Building2, ArrowRight, CheckCircle2, RefreshCw } from 'lucide-react';

export const TokenisedDepositsView: React.FC = () => {
  const {
    institutions,
    tokenisedDeposits,
    mintTokenisedDeposit,
    redeemTokenisedDeposit
  } = useSimulation();

  // Mint Form State
  const [issuerId, setIssuerId] = useState<InstitutionId>('scb');
  const [holderName, setHolderName] = useState<string>('Rio Tinto Corporate Treasury');
  const [depositRef, setDepositRef] = useState<string>('DEP-SCB-992014');
  const [tokenAmountInput, setTokenAmountInput] = useState<string>('50000000');
  const [interestRateInput, setInterestRateInput] = useState<string>('4.35');

  const [msg, setMsg] = useState<{ success: boolean; message: string } | null>(null);

  const handleMint = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(tokenAmountInput);
    const rate = parseFloat(interestRateInput);
    if (isNaN(amount) || amount <= 0) return;

    const res = mintTokenisedDeposit(issuerId, holderName, depositRef, amount, rate);
    setMsg(res);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2 py-0.5 rounded bg-[#b85c18] text-white text-[10px] font-bold uppercase tracking-wider">
                COMMERCIAL BANK DIGITAL MONEY
              </span>
              <span className="text-xs text-slate-500 font-mono">PROGRAMMABLE ADI TOKENS</span>
            </div>
            <h2 className="text-2xl font-extrabold text-[#1e232a] tracking-tight">
              TOKENISED BANK DEPOSITS
            </h2>
            <p className="text-xs text-slate-600 mt-1 max-w-2xl">
              Programmable, tokenised claims on commercial bank deposits issued by authorised deposit-taking institutions (ADIs), designed for 24/7 automated corporate payment flows.
            </p>
          </div>

          <div className="bg-[#fef6f0] border border-[#b85c18]/30 rounded-xl p-4 text-right">
            <div className="text-[10px] font-bold uppercase tracking-wider text-[#b85c18]">
              Total Tokenised Deposits
            </div>
            <div className="text-xl font-extrabold font-mono text-[#b85c18] mt-0.5">
              {formatAUD(tokenisedDeposits.reduce((acc, d) => acc + d.tokenAmount, 0), { compact: true })}
            </div>
            <div className="text-[10px] text-slate-500">Issued by Participating ADI Commercial Banks</div>
          </div>
        </div>
      </div>

      {/* Conceptual Distinction Banner */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-sans">
        <div className="p-4 bg-[#f0f7f3] border border-[#2e5a44]/30 rounded-xl">
          <div className="flex items-center gap-2 font-bold text-[#2e5a44] mb-1">
            <Landmark className="w-4 h-4" />
            <span>CENTRAL BANK MONEY</span>
          </div>
          <p className="text-slate-700 leading-relaxed text-[11px]">
            Sovereign liability of RBA (Digital AUD). Final settlement asset for all interbank obligations.
          </p>
        </div>

        <div className="p-4 bg-[#f0f4f8] border border-[#0a192f]/20 rounded-xl">
          <div className="flex items-center gap-2 font-bold text-[#0a192f] mb-1">
            <Building2 className="w-4 h-4" />
            <span>COMMERCIAL BANK MONEY</span>
          </div>
          <p className="text-slate-700 leading-relaxed text-[11px]">
            Standard ADI bank balance claim. Limited to bank operating hours and standard ledger cycles.
          </p>
        </div>

        <div className="p-4 bg-[#fef6f0] border border-[#b85c18]/40 rounded-xl">
          <div className="flex items-center gap-2 font-bold text-[#b85c18] mb-1">
            <Coins className="w-4 h-4" />
            <span>TOKENISED DEPOSITS</span>
          </div>
          <p className="text-slate-700 leading-relaxed text-[11px]">
            Programmable tokenised claim on ADI deposits. Settles 24/7 atomically with programmable logic.
          </p>
        </div>
      </div>

      {/* Flow Diagram as specified in Prompt */}
      <div className="bg-[#0f1c2e] text-white p-4 rounded-xl border border-[#1e2e42]">
        <div className="text-[10px] font-bold text-amber-400 uppercase tracking-widest mb-2">
          TOKENISED DEPOSIT LIFECYCLE FLOW
        </div>
        <div className="flex flex-col sm:flex-row items-center justify-between gap-2 text-center text-xs font-semibold">
          <div className="bg-[#18283e] p-2.5 rounded border border-[#2c405c] w-full">1. Bank Deposit</div>
          <ArrowRight className="w-4 h-4 text-amber-400 shrink-0 hidden sm:block" />
          <div className="bg-[#18283e] p-2.5 rounded border border-[#2c405c] w-full">2. Tokenisation</div>
          <ArrowRight className="w-4 h-4 text-amber-400 shrink-0 hidden sm:block" />
          <div className="bg-[#18283e] p-2.5 rounded border border-[#2c405c] w-full">3. Tokenised Deposit</div>
          <ArrowRight className="w-4 h-4 text-amber-400 shrink-0 hidden sm:block" />
          <div className="bg-[#18283e] p-2.5 rounded border border-[#2c405c] w-full">4. Payment</div>
          <ArrowRight className="w-4 h-4 text-amber-400 shrink-0 hidden sm:block" />
          <div className="bg-[#18283e] p-2.5 rounded border border-[#2c405c] w-full">5. Settlement</div>
          <ArrowRight className="w-4 h-4 text-amber-400 shrink-0 hidden sm:block" />
          <div className="bg-[#18283e] p-2.5 rounded border border-[#2c405c] w-full">6. Redemption</div>
        </div>
      </div>

      {/* Mint Form & Active Ledger Table */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Tokenisation Mint Form */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <h3 className="text-sm font-bold text-[#1e232a] uppercase tracking-wide mb-4 pb-2 border-b border-slate-100 flex items-center gap-2">
            <Coins className="w-4 h-4 text-[#b85c18]" />
            MINT TOKENISED BANK DEPOSIT
          </h3>

          <form onSubmit={handleMint} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Issuing ADI Commercial Bank
              </label>
              <select
                value={issuerId}
                onChange={e => setIssuerId(e.target.value as InstitutionId)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-xs font-semibold text-slate-800"
              >
                {institutions.filter(i => i.type !== 'CENTRAL_BANK').map(inst => (
                  <option key={inst.id} value={inst.id}>
                    {inst.name} ({inst.code})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Corporate Holder Name
              </label>
              <input
                type="text"
                value={holderName}
                onChange={e => setHolderName(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-xs font-semibold text-slate-800"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Token Amount (A$)
                </label>
                <input
                  type="number"
                  value={tokenAmountInput}
                  onChange={e => setTokenAmountInput(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-xs font-mono font-bold text-slate-800"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Yield Interest (%)
                </label>
                <input
                  type="number"
                  step="0.05"
                  value={interestRateInput}
                  onChange={e => setInterestRateInput(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-xs font-mono text-slate-800"
                />
              </div>
            </div>

            {msg && (
              <div
                className={`p-3 rounded-lg text-xs font-semibold ${
                  msg.success ? 'bg-emerald-50 text-emerald-900 border border-emerald-200' : 'bg-rose-50 text-rose-900 border border-rose-200'
                }`}
              >
                {msg.message}
              </div>
            )}

            <button
              type="submit"
              className="w-full py-2.5 px-4 bg-[#b85c18] hover:bg-[#a24e12] text-white font-bold text-xs rounded-lg transition shadow-xs flex items-center justify-center gap-2"
            >
              <Coins className="w-4 h-4" />
              TOKENISE COMMERCIAL DEPOSIT
            </button>
          </form>
        </div>

        {/* Tokenised Deposits Ledger Table */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <h3 className="text-sm font-bold text-[#1e232a] uppercase tracking-wide mb-3 pb-2 border-b border-slate-100">
            ACTIVE TOKENISED BANK DEPOSITS REGISTER
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 font-bold uppercase tracking-wider text-[10px] border-b border-slate-200">
                <tr>
                  <th className="p-3">Deposit ID</th>
                  <th className="p-3">Issuer / Holder</th>
                  <th className="p-3 text-right">Token Balance</th>
                  <th className="p-3 text-center">Interest</th>
                  <th className="p-3 text-center">Settlement Status</th>
                  <th className="p-3 text-center">Redemption Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono">
                {tokenisedDeposits.map(dep => (
                  <tr key={dep.id} className="hover:bg-slate-50">
                    <td className="p-3 font-bold text-slate-800">{dep.id}</td>
                    <td className="p-3 font-sans">
                      <div className="font-bold text-slate-800">{dep.holderName}</div>
                      <div className="text-[10px] text-slate-500 font-mono">Issuer ID: {dep.issuerId.toUpperCase()}</div>
                    </td>
                    <td className="p-3 text-right font-bold text-[#b85c18]">
                      {formatAUD(dep.tokenAmount)}
                    </td>
                    <td className="p-3 text-center text-slate-700 font-bold">{dep.interestRate}%</td>
                    <td className="p-3 text-center">
                      <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-bold text-[10px]">
                        {dep.settlementStatus}
                      </span>
                    </td>
                    <td className="p-3 text-center">
                      {dep.redemptionStatus === 'ACTIVE' ? (
                        <button
                          onClick={() => redeemTokenisedDeposit(dep.id)}
                          className="px-2.5 py-1 bg-[#0a192f] hover:bg-slate-800 text-white text-[10px] font-bold rounded transition"
                        >
                          Redeem
                        </button>
                      ) : (
                        <span className="text-[10px] text-slate-400 italic">REDEEMED</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
