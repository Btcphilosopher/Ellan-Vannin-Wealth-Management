/**
 * RETAIL DIGITAL AUD CONSUMER WALLET MODULE
 */

import React, { useState } from 'react';
import { useSimulation } from '../simulation/simulationEngine';
import { formatAUD } from '../utils/formatters';
import { Wallet, CreditCard, QrCode, ArrowUpRight, ArrowDownLeft, Store, ShoppingBag, Bus, Utensils, CheckCircle2, Send } from 'lucide-react';
import { RetailTransaction } from '../types';

export const RetailCBDCView: React.FC = () => {
  const {
    retailBalance,
    retailTransactions,
    executeRetailPayment
  } = useSimulation();

  // POS Payment Simulator State
  const [merchantInput, setMerchantInput] = useState<string>('Woolworths Metro Sydney CBD');
  const [categoryInput, setCategoryInput] = useState<RetailTransaction['category']>('Supermarket');
  const [amountInput, setAmountInput] = useState<string>('48.50');
  const [channelInput, setChannelInput] = useState<RetailTransaction['channel']>('NFC');

  const [paymentMsg, setPaymentMsg] = useState<{ success: boolean; message: string } | null>(null);

  const handlePay = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(amountInput);
    if (isNaN(amount) || amount <= 0) return;

    const res = executeRetailPayment(merchantInput, categoryInput, amount, channelInput);
    setPaymentMsg(res);
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Supermarket': return <ShoppingBag className="w-4 h-4 text-emerald-600" />;
      case 'Transport': return <Bus className="w-4 h-4 text-blue-600" />;
      case 'Restaurant': return <Utensils className="w-4 h-4 text-amber-600" />;
      default: return <CreditCard className="w-4 h-4 text-slate-600" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2 py-0.5 rounded bg-[#2e5a44] text-white text-[10px] font-bold uppercase tracking-wider">
                RETAIL PAYMENT LAYER
              </span>
              <span className="text-xs text-slate-500 font-mono">SOVEREIGN DIGITAL WALLET</span>
            </div>
            <h2 className="text-2xl font-extrabold text-[#1e232a] tracking-tight">
              RETAIL DIGITAL AUD WALLET
            </h2>
            <p className="text-xs text-slate-600 mt-1 max-w-2xl">
              Direct central-bank digital currency holding for citizens and merchants, providing offline-capable, instant retail payment settlement with zero merchant fees.
            </p>
          </div>

          <span className="px-3 py-1.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200 w-fit">
            ● Retail Account Active (ID: AU-WAL-88102)
          </span>
        </div>
      </div>

      {/* Main Consumer Wallet Interface as specified in Prompt */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Wallet Digital Pass & Actions */}
        <div className="bg-gradient-to-br from-[#0f1c2e] to-[#1a2d47] text-white rounded-2xl p-6 shadow-md border border-[#243852] flex flex-col justify-between min-h-[320px] relative overflow-hidden">
          <div className="absolute -bottom-10 -right-10 w-48 h-48 bg-[#2e5a44]/30 rounded-full blur-2xl pointer-events-none"></div>

          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Wallet className="w-5 h-5 text-emerald-400" />
                <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                  RETAIL DIGITAL AUD BALANCE
                </span>
              </div>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
                AUD (A$)
              </span>
            </div>

            {/* Balance Display as Prompt Example: A$4,820.50 */}
            <div className="text-3xl font-extrabold font-mono tracking-tight text-white my-2">
              {formatAUD(retailBalance)}
            </div>

            <p className="text-xs text-slate-300 font-medium">
              Sovereign Central Bank Money · Reserve Bank Liability
            </p>
          </div>

          {/* Action Quick Buttons */}
          <div className="grid grid-cols-4 gap-2 pt-4 border-t border-slate-700/60 mt-4">
            <button className="flex flex-col items-center p-2 rounded-lg bg-emerald-700/80 hover:bg-emerald-600 text-white transition text-xs font-bold">
              <ArrowUpRight className="w-4 h-4 mb-1" />
              Pay
            </button>
            <button className="flex flex-col items-center p-2 rounded-lg bg-[#243852] hover:bg-[#2e4666] text-white transition text-xs font-bold">
              <Send className="w-4 h-4 mb-1" />
              Send
            </button>
            <button className="flex flex-col items-center p-2 rounded-lg bg-[#243852] hover:bg-[#2e4666] text-white transition text-xs font-bold">
              <ArrowDownLeft className="w-4 h-4 mb-1" />
              Receive
            </button>
            <button className="flex flex-col items-center p-2 rounded-lg bg-[#243852] hover:bg-[#2e4666] text-white transition text-xs font-bold">
              <QrCode className="w-4 h-4 mb-1" />
              QR Tap
            </button>
          </div>
        </div>

        {/* Merchant POS Simulator */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
          <div className="flex items-center gap-2 mb-4 pb-2 border-b border-slate-100">
            <div className="p-1.5 rounded bg-[#2e5a44] text-white">
              <Store className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-[#1e232a] uppercase tracking-wide">
              SIMULATE MERCHANT POS RETAIL PAYMENT
            </h3>
          </div>

          <form onSubmit={handlePay} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Merchant Name
                </label>
                <input
                  type="text"
                  value={merchantInput}
                  onChange={e => setMerchantInput(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-xs font-semibold text-slate-800 focus:outline-none focus:border-[#2e5a44]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Merchant Category
                </label>
                <select
                  value={categoryInput}
                  onChange={e => setCategoryInput(e.target.value as RetailTransaction['category'])}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-xs font-semibold text-slate-800 focus:outline-none focus:border-[#2e5a44]"
                >
                  <option value="Supermarket">Supermarket</option>
                  <option value="Transport">Transport</option>
                  <option value="Restaurant">Restaurant</option>
                  <option value="Online Purchase">Online Purchase</option>
                  <option value="Utilities">Utilities</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Amount (A$)
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={amountInput}
                  onChange={e => setAmountInput(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-xs font-mono font-bold text-slate-800 focus:outline-none focus:border-[#2e5a44]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Payment Channel
                </label>
                <select
                  value={channelInput}
                  onChange={e => setChannelInput(e.target.value as RetailTransaction['channel'])}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-xs font-semibold text-slate-800 focus:outline-none focus:border-[#2e5a44]"
                >
                  <option value="NFC">NFC Contactless Tap</option>
                  <option value="QR">QR Dynamic Code</option>
                  <option value="CARD">Digital AUD Pass</option>
                  <option value="ONLINE">Online Checkout API</option>
                </select>
              </div>
            </div>

            {paymentMsg && (
              <div
                className={`p-3 rounded-lg text-xs font-semibold flex items-center gap-2 ${
                  paymentMsg.success ? 'bg-emerald-50 text-emerald-900 border border-emerald-200' : 'bg-rose-50 text-rose-900 border border-rose-200'
                }`}
              >
                {paymentMsg.success && <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />}
                <span>{paymentMsg.message}</span>
              </div>
            )}

            <button
              type="submit"
              className="w-full py-2.5 px-4 bg-[#2e5a44] hover:bg-[#234635] text-white font-bold text-xs rounded-lg transition shadow-xs flex items-center justify-center gap-2"
            >
              <CreditCard className="w-4 h-4" />
              TAP TO PAY (INSTANT SETTLEMENT)
            </button>
          </form>
        </div>
      </div>

      {/* Retail Transaction History as specified in Prompt */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
        <h3 className="text-sm font-bold text-[#1e232a] uppercase tracking-wide mb-3 pb-2 border-b border-slate-100">
          RETAIL TRANSACTION HISTORY (SYNTHETIC)
        </h3>

        <div className="divide-y divide-slate-100">
          {retailTransactions.map(tx => (
            <div key={tx.id} className="py-3 flex items-center justify-between hover:bg-slate-50 px-2 rounded-lg transition">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-full bg-slate-100">
                  {getCategoryIcon(tx.category)}
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-800">{tx.merchantName}</div>
                  <div className="text-[10px] text-slate-500 font-mono">
                    {tx.category} • {tx.channel} Channel • {tx.timestamp}
                  </div>
                </div>
              </div>

              <div className="text-right">
                <div className="text-xs font-extrabold font-mono text-slate-900">
                  -{formatAUD(tx.amount)}
                </div>
                <div className="text-[10px] font-bold text-emerald-700">SETTLED</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
