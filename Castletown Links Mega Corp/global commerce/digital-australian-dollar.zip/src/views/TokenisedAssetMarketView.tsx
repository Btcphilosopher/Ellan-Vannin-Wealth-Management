/**
 * TOKENISED ASSET SETTLEMENT MARKET MODULE
 */

import React, { useState } from 'react';
import { useSimulation } from '../simulation/simulationEngine';
import { formatAUD } from '../utils/formatters';
import { InstitutionId } from '../types';
import { TrendingUp, ArrowRight, ShieldAlert, CheckCircle2, RefreshCw } from 'lucide-react';

export const TokenisedAssetMarketView: React.FC = () => {
  const {
    tokenisedAssets,
    institutions,
    executeDvPSettlement,
    dvpSettlements
  } = useSimulation();

  const [selectedAssetId, setSelectedAssetId] = useState<string>('AST-AGB-2032');
  const [buyerId, setBuyerId] = useState<InstitutionId>('cfs');
  const [tradeAmountInput, setTradeAmountInput] = useState<string>('10250000');

  const [dvpMsg, setDvpMsg] = useState<{ success: boolean; message: string } | null>(null);

  const selectedAsset = tokenisedAssets.find(a => a.id === selectedAssetId) || tokenisedAssets[0];

  const handleExecuteDvP = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(tradeAmountInput);
    if (isNaN(amount) || amount <= 0) return;

    const res = executeDvPSettlement(selectedAssetId, selectedAsset.ownerId, buyerId, amount);
    setDvpMsg(res);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2 py-0.5 rounded bg-[#4a5568] text-white text-[10px] font-bold uppercase tracking-wider">
                FINANCIAL MARKET SETTLEMENT
              </span>
              <span className="text-xs text-slate-500 font-mono">ATOMIC DELIVERY-VERSUS-PAYMENT</span>
            </div>
            <h2 className="text-2xl font-extrabold text-[#1e232a] tracking-tight">
              TOKENISED ASSET SETTLEMENT MARKET
            </h2>
            <p className="text-xs text-slate-600 mt-1 max-w-2xl">
              Dematerialised securities registry enabling atomic Delivery-versus-Payment (DvP) settlement using central-bank Digital AUD as the final cash settlement leg.
            </p>
          </div>

          <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-lg text-right">
            <div className="text-[10px] font-bold text-amber-800 uppercase">SIMULATED SECURITIES ONLY</div>
            <div className="text-xs font-medium text-amber-900 mt-0.5">Not real Australian financial instruments or ASX listings.</div>
          </div>
        </div>
      </div>

      {/* Atomic DvP Workflow Diagram as specified in Prompt */}
      <div className="bg-[#0f1c2e] text-white p-4 rounded-xl border border-[#1e2e42]">
        <div className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest mb-2">
          ATOMIC DVP SETTLEMENT WORKFLOW
        </div>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 text-center text-xs font-semibold py-2">
          <div className="bg-[#18283e] px-4 py-2.5 rounded border border-[#2c405c] w-full sm:w-auto">
            1. ASSET TRANSFER (Dematerialised Registry)
          </div>
          <span className="text-emerald-400 font-bold text-base">+</span>
          <div className="bg-[#18283e] px-4 py-2.5 rounded border border-[#2c405c] w-full sm:w-auto">
            2. DIGITAL AUD PAYMENT (Reserve Bank Cash Leg)
          </div>
          <ArrowRight className="w-5 h-5 text-emerald-400 shrink-0 hidden sm:block" />
          <div className="bg-[#2e5a44] px-4 py-2.5 rounded border border-emerald-500 w-full sm:w-auto font-bold">
            3. SETTLEMENT COMPLETE (Atomic Finality)
          </div>
        </div>
      </div>

      {/* Tokenised Assets Registry Table as specified in Prompt */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
        <h3 className="text-sm font-bold text-[#1e232a] uppercase tracking-wide mb-3 pb-2 border-b border-slate-100">
          TOKENISED ASSETS REGISTER
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 font-bold uppercase tracking-wider text-[10px] border-b border-slate-200">
              <tr>
                <th className="p-3">Asset Code & Name</th>
                <th className="p-3">Category</th>
                <th className="p-3">Issuer</th>
                <th className="p-3">Current Owner</th>
                <th className="p-3 text-right">Quantity</th>
                <th className="p-3 text-right">Total Value</th>
                <th className="p-3 text-center">Settlement Currency</th>
                <th className="p-3 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono">
              {tokenisedAssets.map(asset => (
                <tr key={asset.id} className="hover:bg-slate-50">
                  <td className="p-3 font-sans">
                    <div className="font-bold text-slate-800">{asset.name}</div>
                    <div className="text-[10px] text-slate-500 font-mono">{asset.assetCode} • ISIN: {asset.isrcCode}</div>
                  </td>
                  <td className="p-3 font-sans text-slate-600 font-semibold">{asset.category.replace(/_/g, ' ')}</td>
                  <td className="p-3 font-sans text-slate-700">{asset.issuer}</td>
                  <td className="p-3 font-sans font-bold text-[#0a192f]">{asset.ownerName}</td>
                  <td className="p-3 text-right text-slate-700">{asset.quantity.toLocaleString('en-AU')}</td>
                  <td className="p-3 text-right font-bold text-[#2e5a44]">{formatAUD(asset.totalValue)}</td>
                  <td className="p-3 text-center font-sans">
                    <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-bold text-[10px]">
                      {asset.settlementCurrency}
                    </span>
                  </td>
                  <td className="p-3 text-center font-sans">
                    <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-800 font-bold text-[10px]">
                      {asset.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Atomic DvP Settlement Terminal Form */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <h3 className="text-sm font-bold text-[#1e232a] uppercase tracking-wide mb-4 pb-2 border-b border-slate-100">
            EXECUTE ATOMIC DVP SETTLEMENT (ASSET vs DIGITAL AUD)
          </h3>

          <form onSubmit={handleExecuteDvP} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Select Tokenised Asset to Trade
              </label>
              <select
                value={selectedAssetId}
                onChange={e => setSelectedAssetId(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-xs font-semibold text-slate-800"
              >
                {tokenisedAssets.map(asset => (
                  <option key={asset.id} value={asset.id}>
                    {asset.name} — Owner: {asset.ownerName} (Val: {formatAUD(asset.totalValue)})
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Asset Seller (Current Owner)
                </label>
                <input
                  type="text"
                  disabled
                  value={selectedAsset.ownerName}
                  className="w-full bg-slate-100 border border-slate-300 rounded-lg p-2.5 text-xs font-bold text-slate-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Asset Buyer (Digital AUD Payer)
                </label>
                <select
                  value={buyerId}
                  onChange={e => setBuyerId(e.target.value as InstitutionId)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-xs font-semibold text-slate-800"
                >
                  {institutions.filter(i => i.id !== selectedAsset.ownerId && i.type !== 'CENTRAL_BANK').map(inst => (
                    <option key={inst.id} value={inst.id}>
                      {inst.name} — Digital AUD Bal: {formatAUD(inst.digitalAudBalance)}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Settlement Payment Amount (Digital AUD)
              </label>
              <input
                type="number"
                value={tradeAmountInput}
                onChange={e => setTradeAmountInput(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-xs font-mono font-bold text-slate-800"
              />
            </div>

            {dvpMsg && (
              <div
                className={`p-3 rounded-lg text-xs font-semibold ${
                  dvpMsg.success ? 'bg-emerald-50 text-emerald-900 border border-emerald-200' : 'bg-rose-50 text-rose-900 border border-rose-200'
                }`}
              >
                {dvpMsg.message}
              </div>
            )}

            <button
              type="submit"
              className="w-full py-2.5 px-4 bg-[#2e5a44] hover:bg-[#234635] text-white font-bold text-xs rounded-lg transition shadow-xs flex items-center justify-center gap-2"
            >
              <TrendingUp className="w-4 h-4" />
              EXECUTE ATOMIC DVP SWAP
            </button>
          </form>
        </div>

        {/* DvP Executed History */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <h3 className="text-sm font-bold text-[#1e232a] uppercase tracking-wide mb-3 pb-2 border-b border-slate-100">
            RECENT DVP SETTLEMENT LOG
          </h3>

          <div className="space-y-3">
            {dvpSettlements.map(dvp => (
              <div key={dvp.id} className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs font-mono">
                <div className="flex justify-between text-[10px] text-slate-500">
                  <span>{dvp.tradeReference}</span>
                  <span>{dvp.executionTime}</span>
                </div>
                <div className="font-bold text-slate-800 my-1 font-sans">{dvp.assetName}</div>
                <div className="text-[11px] text-slate-600">
                  Seller: {dvp.sellerName} → Buyer: {dvp.buyerName}
                </div>
                <div className="flex justify-between items-center mt-2 pt-1 border-t border-slate-200">
                  <span className="font-bold text-[#2e5a44]">{formatAUD(dvp.paymentAmount)}</span>
                  <span className="px-2 py-0.2 rounded bg-emerald-100 text-emerald-800 text-[10px] font-bold font-sans">
                    {dvp.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
