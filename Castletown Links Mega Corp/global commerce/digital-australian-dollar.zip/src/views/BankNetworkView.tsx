/**
 * BANKS & INSTITUTIONS MODULE
 * Fictional ADI Financial Institutions Network
 */

import React, { useState } from 'react';
import { useSimulation } from '../simulation/simulationEngine';
import { formatAUD } from '../utils/formatters';
import { Building, ShieldAlert, Activity, Server, ArrowUpRight, CheckCircle2 } from 'lucide-react';
import { InstitutionId } from '../types';

export const BankNetworkView: React.FC = () => {
  const {
    institutions,
    riskAlerts
  } = useSimulation();

  const [selectedInstId, setSelectedInstId] = useState<InstitutionId>('scb');

  const selectedInst = institutions.find(i => i.id === selectedInstId) || institutions[1];

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded bg-amber-600 text-white text-[10px] font-bold uppercase tracking-wider">
                FICTIONAL SIMULATION INSTITUTIONS
              </span>
              <span className="text-xs text-slate-500 font-mono">SYNTHETIC ADI PARTICIPANT NETWORK</span>
            </div>
            <h2 className="text-2xl font-extrabold text-[#1e232a] tracking-tight">
              AUSTRALIAN ADI BANK NETWORK
            </h2>
            <p className="text-xs text-slate-600 mt-1 max-w-2xl">
              Fictional participant institutions connected to the Reserve Bank Digital AUD Core, maintaining exchange accounts, tokenised deposit ledgers, and API gateways.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-amber-800 bg-amber-50 px-3 py-1.5 rounded-lg border border-amber-200">
              ⚠ ALL INSTITUTIONS ARE SYNTHETIC RESEARCH ENTITIES
            </span>
          </div>
        </div>
      </div>

      {/* Institution Selector Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
        {institutions.filter(i => i.type !== 'CENTRAL_BANK').map(inst => {
          const isSelected = inst.id === selectedInstId;

          return (
            <button
              key={inst.id}
              onClick={() => setSelectedInstId(inst.id)}
              className={`p-4 rounded-xl text-left border transition relative overflow-hidden ${
                isSelected
                  ? 'bg-[#0a192f] text-white border-[#0a192f] shadow-md'
                  : 'bg-white text-slate-800 border-slate-200 hover:border-slate-300'
              }`}
            >
              <div className="text-[10px] font-mono uppercase tracking-wider text-amber-400 font-bold mb-1">
                FICTIONAL SIMULATION INSTITUTION
              </div>
              <div className="font-extrabold text-sm truncate">{inst.name}</div>
              <div className={`text-[11px] font-mono mt-2 font-bold ${isSelected ? 'text-emerald-300' : 'text-[#2e5a44]'}`}>
                {formatAUD(inst.digitalAudBalance, { compact: true })}
              </div>
              <div className="flex justify-between items-center text-[10px] mt-2 pt-2 border-t border-slate-200/20 font-mono text-slate-400">
                <span>Code: {inst.code}</span>
                <span className="text-emerald-400">API: {inst.apiHealth}%</span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Detailed Dashboard for Selected Fictional Institution */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-extrabold text-[#1e232a]">
                {selectedInst.name}
              </h3>
              <span className="px-2 py-0.5 rounded bg-amber-100 text-amber-900 border border-amber-300 text-[10px] font-bold">
                FICTIONAL SIMULATION INSTITUTION
              </span>
            </div>
            <p className="text-xs text-slate-500 font-mono">
              ADI Registration: {selectedInst.code} • Status: {selectedInst.status}
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-right">
              <div className="text-[10px] text-slate-500 font-bold uppercase">API Health Score</div>
              <div className="text-sm font-extrabold font-mono text-emerald-700">{selectedInst.apiHealth}%</div>
            </div>
          </div>
        </div>

        {/* Institution Metrics Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 font-mono">
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
            <div className="text-[10px] font-bold text-slate-500 uppercase font-sans">Digital AUD Balance</div>
            <div className="text-lg font-extrabold text-[#2e5a44] mt-1">
              {formatAUD(selectedInst.digitalAudBalance)}
            </div>
          </div>

          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
            <div className="text-[10px] font-bold text-slate-500 uppercase font-sans">Tokenised Deposits</div>
            <div className="text-lg font-extrabold text-[#b85c18] mt-1">
              {formatAUD(selectedInst.tokenisedDepositBalance)}
            </div>
          </div>

          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
            <div className="text-[10px] font-bold text-slate-500 uppercase font-sans">Commercial Bank Deposits</div>
            <div className="text-lg font-extrabold text-[#0a192f] mt-1">
              {formatAUD(selectedInst.commercialBankBalance)}
            </div>
          </div>

          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
            <div className="text-[10px] font-bold text-slate-500 uppercase font-sans">Tokenised Assets Value</div>
            <div className="text-lg font-extrabold text-[#4a5568] mt-1">
              {formatAUD(selectedInst.tokenisedAssetValue)}
            </div>
          </div>
        </div>

        {/* Operational Telemetry Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-sans">
          <div className="p-4 rounded-xl border border-slate-200 bg-[#f8fafc]">
            <div className="font-bold text-slate-800 uppercase text-[11px] mb-2">Account Metrics</div>
            <div className="space-y-1 font-mono text-slate-600">
              <div className="flex justify-between">
                <span>Active Accounts:</span>
                <span className="font-bold text-slate-900">{selectedInst.activeAccounts.toLocaleString('en-AU')}</span>
              </div>
              <div className="flex justify-between">
                <span>Corporate Accounts:</span>
                <span className="font-bold text-slate-900">{Math.floor(selectedInst.activeAccounts * 0.18)}</span>
              </div>
              <div className="flex justify-between">
                <span>Retail Accounts:</span>
                <span className="font-bold text-slate-900">{Math.floor(selectedInst.activeAccounts * 0.82)}</span>
              </div>
            </div>
          </div>

          <div className="p-4 rounded-xl border border-slate-200 bg-[#f8fafc]">
            <div className="font-bold text-slate-800 uppercase text-[11px] mb-2">Liquidity Posture</div>
            <div className="space-y-1 font-mono text-slate-600">
              <div className="flex justify-between">
                <span>Intraday Liquidity:</span>
                <span className="font-bold text-[#2e5a44]">{formatAUD(selectedInst.intradayLiquidity, { compact: true })}</span>
              </div>
              <div className="flex justify-between">
                <span>Collateral Allocated:</span>
                <span className="font-bold text-slate-900">{formatAUD(selectedInst.collateralAllocated, { compact: true })}</span>
              </div>
              <div className="flex justify-between">
                <span>Liquidity Buffer:</span>
                <span className="font-bold text-slate-900">{formatAUD(selectedInst.liquidityBuffer, { compact: true })}</span>
              </div>
            </div>
          </div>

          <div className="p-4 rounded-xl border border-slate-200 bg-[#f8fafc]">
            <div className="font-bold text-slate-800 uppercase text-[11px] mb-2">Risk & API Gateway</div>
            <div className="space-y-1 font-mono text-slate-600">
              <div className="flex justify-between">
                <span>Risk Score Rating:</span>
                <span className="font-bold text-emerald-700">{selectedInst.riskScore}</span>
              </div>
              <div className="flex justify-between">
                <span>API Health:</span>
                <span className="font-bold text-emerald-700">{selectedInst.apiHealth}%</span>
              </div>
              <div className="flex justify-between">
                <span>Pending Settlement:</span>
                <span className="font-bold text-slate-900">{formatAUD(selectedInst.pendingSettlement, { compact: true })}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
