/**
 * AUDIT SYSTEM MODULE
 */

import React from 'react';
import { useSimulation } from '../simulation/simulationEngine';
import { ShieldCheck, FileCheck, Search, Database } from 'lucide-react';

export const AuditSystemView: React.FC = () => {
  const { auditEvents } = useSimulation();

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2 py-0.5 rounded bg-[#0a192f] text-white text-[10px] font-bold uppercase tracking-wider">
              PRUDENTIAL AUDIT ENGINE
            </span>
            <span className="text-xs text-slate-500 font-mono">APPEND-ONLY COMPLIANCE LOG</span>
          </div>
          <h2 className="text-2xl font-extrabold text-[#1e232a] tracking-tight">
            SYSTEM AUDIT & REGULATORY TRAIL
          </h2>
          <p className="text-xs text-slate-600 mt-1 max-w-2xl">
            Append-only, tamper-proof audit log capturing all issuance, interbank settlement, tokenisation, and policy mutation events.
          </p>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
        <h3 className="text-sm font-bold text-[#1e232a] uppercase tracking-wide mb-3 pb-2 border-b border-slate-100 flex items-center justify-between">
          <span>AUDIT EVENT RECORD REGISTER</span>
          <span className="text-xs text-slate-400 font-mono">{auditEvents.length} RECORDED EVENTS</span>
        </h3>

        <div className="overflow-x-auto font-mono text-xs">
          <table className="w-full text-left">
            <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px] border-b border-slate-200">
              <tr>
                <th className="p-3">Audit ID</th>
                <th className="p-3">Timestamp</th>
                <th className="p-3">Event Type</th>
                <th className="p-3">Actor / Entity</th>
                <th className="p-3">Details / Reference</th>
                <th className="p-3">Cryptographic Signature</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {auditEvents.map(evt => (
                <tr key={evt.id} className="hover:bg-slate-50">
                  <td className="p-3 font-bold text-slate-800">{evt.id}</td>
                  <td className="p-3 text-slate-500 text-[11px]">{evt.timestamp}</td>
                  <td className="p-3 text-[11px] font-bold text-[#2e5a44]">{evt.eventType}</td>
                  <td className="p-3 font-sans font-semibold text-slate-800">{evt.actor}</td>
                  <td className="p-3 font-sans text-slate-700">{evt.details}</td>
                  <td className="p-3 text-[10px] text-slate-400 truncate max-w-[140px]">{evt.cryptoSignature}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
