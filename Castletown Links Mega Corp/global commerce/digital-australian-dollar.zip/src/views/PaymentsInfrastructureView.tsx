/**
 * PAYMENTS INFRASTRUCTURE MODULE
 */

import React, { useState } from 'react';
import { CreditCard, QrCode, Smartphone, Zap, ArrowRight, ShieldCheck, CheckCircle2, Server } from 'lucide-react';
import { formatAUD } from '../utils/formatters';

export const PaymentsInfrastructureView: React.FC = () => {
  const [selectedChannel, setSelectedChannel] = useState<string>('DIGITAL_AUD');
  const [testAmount, setTestAmount] = useState<string>('250.00');
  const [testRef, setTestRef] = useState<string>('PAY-AU-991024');
  const [simulationStep, setSimulationStep] = useState<number>(0);

  const runPaymentSimulation = () => {
    setSimulationStep(1);
    setTimeout(() => setSimulationStep(2), 600);
    setTimeout(() => setSimulationStep(3), 1200);
    setTimeout(() => setSimulationStep(4), 1800);
  };

  const CHANNELS = [
    { id: 'DIGITAL_AUD', title: 'Digital AUD Core', desc: 'Direct central-bank digital currency settlement (24/7/365 atomic)', speed: '< 15 ms' },
    { id: 'BANK_TRANSFER', title: 'Bank Transfer (BECS/DE)', desc: 'Standard electronic batch bank credit transfer', speed: 'End of Day' },
    { id: 'INSTANT_PAYMENT', title: 'Instant Payment (NPP-Sim)', desc: 'New Payments Platform simulation with PayID routing', speed: '< 2.5 sec' },
    { id: 'CARD_SIM', title: 'Card Payment (Simulation)', desc: 'Tokenised Australian debit card network abstraction', speed: '< 500 ms' },
    { id: 'QR_PAYMENT', title: 'QR Payment Code', desc: 'EMVCo-compliant dynamic Australian merchant QR token', speed: '< 20 ms' },
    { id: 'NFC_TAP', title: 'NFC Contactless', desc: 'Proximity secure element ISO 14443 payment channel', speed: '< 10 ms' },
    { id: 'API_GATEWAY', title: 'Corporate Payment API', desc: 'REST / gRPC direct enterprise payment gateway', speed: '< 8 ms' },
  ];

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2 py-0.5 rounded bg-[#2e5a44] text-white text-[10px] font-bold uppercase tracking-wider">
                PAYMENTS ABSTRACTION LAYER
              </span>
              <span className="text-xs text-slate-500 font-mono">MULTI-CHANNEL ROUTING</span>
            </div>
            <h2 className="text-2xl font-extrabold text-[#1e232a] tracking-tight">
              AUSTRALIAN PAYMENT INFRASTRUCTURE
            </h2>
            <p className="text-xs text-slate-600 mt-1 max-w-2xl">
              Abstraction layer uniting central-bank digital currency with legacy and next-generation Australian payment channels.
            </p>
          </div>
        </div>
      </div>

      {/* Architecture Diagram as specified in Prompt */}
      <div className="bg-[#0f1c2e] text-white p-5 rounded-xl border border-[#1e2e42]">
        <h3 className="text-xs font-bold uppercase tracking-widest text-emerald-400 mb-3">
          AUSTRALIAN PAYMENT INFRASTRUCTURE ARCHITECTURE
        </h3>
        <div className="flex flex-col md:flex-row items-center justify-between gap-2 text-center text-xs font-semibold">
          <div className="bg-[#18283e] p-3 rounded border border-[#2c405c] w-full">Customer / Payer</div>
          <ArrowRight className="w-4 h-4 text-emerald-400 shrink-0 hidden md:block" />
          <div className="bg-[#18283e] p-3 rounded border border-[#2c405c] w-full">Payment Interface</div>
          <ArrowRight className="w-4 h-4 text-emerald-400 shrink-0 hidden md:block" />
          <div className="bg-[#18283e] p-3 rounded border border-[#2c405c] w-full">Payment Gateway</div>
          <ArrowRight className="w-4 h-4 text-emerald-400 shrink-0 hidden md:block" />
          <div className="bg-[#18283e] p-3 rounded border border-[#2c405c] w-full">Digital Money Layer</div>
          <ArrowRight className="w-4 h-4 text-emerald-400 shrink-0 hidden md:block" />
          <div className="bg-[#18283e] p-3 rounded border border-[#2c405c] w-full">Final Settlement</div>
        </div>
      </div>

      {/* Payment Channel Selection Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
        {CHANNELS.map(ch => {
          const isSelected = ch.id === selectedChannel;

          return (
            <button
              key={ch.id}
              onClick={() => { setSelectedChannel(ch.id); setSimulationStep(0); }}
              className={`p-4 rounded-xl text-left border transition ${
                isSelected
                  ? 'bg-[#2e5a44] text-white border-[#2e5a44] shadow-md'
                  : 'bg-white text-slate-800 border-slate-200 hover:border-slate-300'
              }`}
            >
              <div className="font-bold text-sm">{ch.title}</div>
              <p className={`text-[11px] mt-1 leading-snug ${isSelected ? 'text-emerald-100' : 'text-slate-500'}`}>
                {ch.desc}
              </p>
              <div className="mt-3 flex justify-between items-center text-[10px] font-mono">
                <span className={isSelected ? 'text-emerald-200' : 'text-slate-400'}>Avg Latency:</span>
                <span className={`font-bold ${isSelected ? 'text-white' : 'text-[#2e5a44]'}`}>{ch.speed}</span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Interactive Gateway Tester */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
        <h3 className="text-sm font-bold text-[#1e232a] uppercase tracking-wide mb-4 pb-2 border-b border-slate-100">
          PAYMENT CHANNEL GATEWAY TESTER — {selectedChannel}
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Payment Amount (A$)</label>
              <input
                type="number"
                value={testAmount}
                onChange={e => setTestAmount(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-xs font-mono font-bold text-slate-800"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Transaction Ref</label>
              <input
                type="text"
                value={testRef}
                onChange={e => setTestRef(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-xs font-mono text-slate-800"
              />
            </div>

            <button
              onClick={runPaymentSimulation}
              className="w-full py-2.5 px-4 bg-[#2e5a44] hover:bg-[#234635] text-white font-bold text-xs rounded-lg transition shadow-xs flex items-center justify-center gap-2"
            >
              <Zap className="w-4 h-4" />
              SIMULATE PAYMENT PIPELINE
            </button>
          </div>

          <div className="md:col-span-2 bg-slate-50 rounded-xl p-4 border border-slate-200 flex flex-col justify-between">
            <div className="text-xs font-bold uppercase text-slate-600 mb-3">ROUTING PIPELINE STATUS</div>

            <div className="space-y-2 text-xs font-mono">
              <div className={`p-2 rounded flex items-center justify-between ${simulationStep >= 1 ? 'bg-emerald-100 text-emerald-900 border border-emerald-300' : 'bg-slate-200 text-slate-500'}`}>
                <span>1. Customer Validation & Gateway Handshake</span>
                <span>{simulationStep >= 1 ? 'PASSED (0.2ms)' : 'WAITING'}</span>
              </div>

              <div className={`p-2 rounded flex items-center justify-between ${simulationStep >= 2 ? 'bg-emerald-100 text-emerald-900 border border-emerald-300' : 'bg-slate-200 text-slate-500'}`}>
                <span>2. AML/CTF Real-Time Risk Inspection</span>
                <span>{simulationStep >= 2 ? 'CLEARED (1.1ms)' : 'WAITING'}</span>
              </div>

              <div className={`p-2 rounded flex items-center justify-between ${simulationStep >= 3 ? 'bg-emerald-100 text-emerald-900 border border-emerald-300' : 'bg-slate-200 text-slate-500'}`}>
                <span>3. Digital Money Layer Debit / Credit</span>
                <span>{simulationStep >= 3 ? 'SETTLED (8.4ms)' : 'WAITING'}</span>
              </div>

              <div className={`p-2 rounded flex items-center justify-between ${simulationStep >= 4 ? 'bg-emerald-800 text-white font-bold' : 'bg-slate-200 text-slate-500'}`}>
                <span>4. Reserve Bank Finality Confirmation</span>
                <span>{simulationStep >= 4 ? 'FINALIZED' : 'WAITING'}</span>
              </div>
            </div>

            {simulationStep === 4 && (
              <div className="mt-4 p-2.5 bg-emerald-50 border border-emerald-300 text-emerald-900 text-xs rounded font-bold flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  PAYMENT COMPLETE: {formatAUD(parseFloat(testAmount))}
                </span>
                <span className="font-mono text-[10px] text-emerald-700">Audit Ref: AUD-PAY-{Math.floor(Math.random() * 8999) + 1000}</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
