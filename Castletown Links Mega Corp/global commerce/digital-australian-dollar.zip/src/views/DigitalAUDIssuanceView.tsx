/**
 * DIGITAL AUD ISSUANCE ENGINE MODULE
 */

import React, { useState } from 'react';
import { useSimulation } from '../simulation/simulationEngine';
import { formatAUD, formatAUDate } from '../utils/formatters';
import { InstitutionId } from '../types';
import { Landmark, ArrowRight, ShieldCheck, CheckCircle2, RotateCcw, AlertCircle, FileText } from 'lucide-react';

export const DigitalAUDIssuanceView: React.FC = () => {
  const {
    institutions,
    digitalAudTotalOutstanding,
    issueDigitalAUD,
    redeemDigitalAUD,
    auditEvents
  } = useSimulation();

  // Form State for Issuance
  const [selectedInstId, setSelectedInstId] = useState<InstitutionId>('scb');
  const [amountInput, setAmountInput] = useState<string>('50000000'); // A$50M default
  const [purposeInput, setPurposeInput] = useState<string>('Intraday Liquidity Provisioning');
  const [refInput, setRefInput] = useState<string>('RBA-ISS-2026-904');

  // Form State for Redemption
  const [redeemInstId, setRedeemInstId] = useState<InstitutionId>('scb');
  const [redeemAmountInput, setRedeemAmountInput] = useState<string>('20000000');
  const [redeemPurposeInput, setRedeemPurposeInput] = useState<string>('Overnight Reserve Rebalancing');

  // Simulator Result
  const [lastResult, setLastResult] = useState<{
    success: boolean;
    message: string;
    prevBalance?: number;
    amount?: number;
    newBalance?: number;
    instName?: string;
    timestamp?: string;
    ref?: string;
  } | null>(null);

  const handleIssue = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(amountInput);
    if (isNaN(amount) || amount <= 0) return;

    const inst = institutions.find(i => i.id === selectedInstId);
    const prevBalance = inst?.digitalAudBalance || 0;

    const res = issueDigitalAUD(selectedInstId, amount, purposeInput, refInput);

    if (res.success && inst) {
      setLastResult({
        success: true,
        message: res.message,
        prevBalance,
        amount,
        newBalance: prevBalance + amount,
        instName: inst.name,
        timestamp: formatAUDate(),
        ref: `AUD-REF-${Math.floor(Math.random() * 89999) + 10000}`,
      });
    } else {
      setLastResult({
        success: false,
        message: res.message,
      });
    }
  };

  const handleRedeem = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(redeemAmountInput);
    if (isNaN(amount) || amount <= 0) return;

    const inst = institutions.find(i => i.id === redeemInstId);
    const prevBalance = inst?.digitalAudBalance || 0;

    const res = redeemDigitalAUD(redeemInstId, amount, redeemPurposeInput);

    if (res.success && inst) {
      setLastResult({
        success: true,
        message: res.message,
        prevBalance,
        amount: -amount,
        newBalance: Math.max(0, prevBalance - amount),
        instName: inst.name,
        timestamp: formatAUDate(),
        ref: `RED-REF-${Math.floor(Math.random() * 89999) + 10000}`,
      });
    } else {
      setLastResult({
        success: false,
        message: res.message,
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2 py-0.5 rounded bg-[#2e5a44] text-white text-[10px] font-bold uppercase tracking-wider">
                RESERVE BANK MONETARY AUTHORITY
              </span>
              <span className="text-xs text-slate-500 font-mono">SIMULATION ISSUANCE ENGINE</span>
            </div>
            <h2 className="text-2xl font-extrabold text-[#1e232a] tracking-tight">
              DIGITAL AUD ISSUANCE & REDEMPTION
            </h2>
            <p className="text-xs text-slate-600 mt-1 max-w-2xl">
              Central-bank digital currency issuance, outstanding supply management, and authorised deposit-taking institution (ADI) reserve claims.
            </p>
          </div>

          <div className="bg-[#f0f7f3] border border-[#2e5a44]/30 rounded-xl p-4 text-right">
            <div className="text-[10px] font-bold uppercase tracking-wider text-[#2e5a44]">
              Total Digital AUD Supply Outstanding
            </div>
            <div className="text-xl font-extrabold font-mono text-[#2e5a44] mt-0.5">
              {formatAUD(digitalAudTotalOutstanding, { compact: true })}
            </div>
            <div className="text-[10px] text-slate-500">100% Backed by RBA Central Reserve Liabilities</div>
          </div>
        </div>
      </div>

      {/* Lifecycle Flow Architecture */}
      <div className="bg-[#0f1c2e] text-white rounded-xl p-5 border border-[#1e2e42]">
        <h3 className="text-xs font-bold uppercase tracking-widest text-emerald-400 mb-3">
          DIGITAL AUD ISSUANCE LIFECYCLE ARCHITECTURE
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-6 gap-2 text-center text-xs">
          <div className="bg-[#18283e] p-2.5 rounded border border-[#2c405c]">
            <div className="font-bold text-emerald-300">1. RESERVE BANK</div>
            <div className="text-[10px] text-slate-400 mt-0.5">Sovereign Authorization</div>
          </div>
          <div className="bg-[#18283e] p-2.5 rounded border border-[#2c405c]">
            <div className="font-bold text-emerald-300">2. DIGITAL AUD ISSUANCE</div>
            <div className="text-[10px] text-slate-400 mt-0.5">Ledger Minting</div>
          </div>
          <div className="bg-[#18283e] p-2.5 rounded border border-[#2c405c]">
            <div className="font-bold text-emerald-300">3. WHOLESALE SETTLEMENT</div>
            <div className="text-[10px] text-slate-400 mt-0.5">Exchange Account</div>
          </div>
          <div className="bg-[#18283e] p-2.5 rounded border border-[#2c405c]">
            <div className="font-bold text-emerald-300">4. FINANCIAL INSTITUTION</div>
            <div className="text-[10px] text-slate-400 mt-0.5">ADI Allocation</div>
          </div>
          <div className="bg-[#18283e] p-2.5 rounded border border-[#2c405c]">
            <div className="font-bold text-emerald-300">5. TRANSACTION</div>
            <div className="text-[10px] text-slate-400 mt-0.5">Economic Velocity</div>
          </div>
          <div className="bg-[#18283e] p-2.5 rounded border border-[#2c405c]">
            <div className="font-bold text-emerald-300">6. REDEMPTION</div>
            <div className="text-[10px] text-slate-400 mt-0.5">Reserve Extinction</div>
          </div>
        </div>
      </div>

      {/* Simulator Forms Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Issuance Form */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="flex items-center gap-2 mb-4 pb-2 border-b border-slate-100">
            <div className="p-1.5 rounded bg-[#2e5a44] text-white">
              <Landmark className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-[#1e232a] uppercase tracking-wide">
              ISSUE DIGITAL AUD TO ADI INSTITUTION
            </h3>
          </div>

          <form onSubmit={handleIssue} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Recipient Financial Institution
              </label>
              <select
                value={selectedInstId}
                onChange={e => setSelectedInstId(e.target.value as InstitutionId)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-xs font-semibold text-slate-800 focus:outline-none focus:border-[#2e5a44]"
              >
                {institutions.filter(i => i.type !== 'CENTRAL_BANK').map(inst => (
                  <option key={inst.id} value={inst.id}>
                    {inst.name} ({inst.code}) — Current Bal: {formatAUD(inst.digitalAudBalance)}
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Issuance Amount (A$)
                </label>
                <input
                  type="number"
                  value={amountInput}
                  onChange={e => setAmountInput(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-xs font-mono font-bold text-slate-800 focus:outline-none focus:border-[#2e5a44]"
                  placeholder="e.g. 50000000"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Reference ID
                </label>
                <input
                  type="text"
                  value={refInput}
                  onChange={e => setRefInput(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-xs font-mono text-slate-800 focus:outline-none focus:border-[#2e5a44]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Issuance Purpose
              </label>
              <input
                type="text"
                value={purposeInput}
                onChange={e => setPurposeInput(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-xs text-slate-800 focus:outline-none focus:border-[#2e5a44]"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 px-4 bg-[#2e5a44] hover:bg-[#234635] text-white font-bold text-xs rounded-lg transition shadow-xs flex items-center justify-center gap-2"
            >
              <ShieldCheck className="w-4 h-4" />
              AUTHORISE & ISSUE DIGITAL AUD
            </button>
          </form>
        </div>

        {/* Redemption Form */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="flex items-center gap-2 mb-4 pb-2 border-b border-slate-100">
            <div className="p-1.5 rounded bg-[#0a192f] text-white">
              <RotateCcw className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-[#1e232a] uppercase tracking-wide">
              REDEEM DIGITAL AUD BACK TO RESERVE
            </h3>
          </div>

          <form onSubmit={handleRedeem} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Redeeming Financial Institution
              </label>
              <select
                value={redeemInstId}
                onChange={e => setRedeemInstId(e.target.value as InstitutionId)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-xs font-semibold text-slate-800 focus:outline-none focus:border-[#0a192f]"
              >
                {institutions.filter(i => i.type !== 'CENTRAL_BANK').map(inst => (
                  <option key={inst.id} value={inst.id}>
                    {inst.name} ({inst.code}) — Available: {formatAUD(inst.digitalAudBalance)}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Redemption Amount (A$)
              </label>
              <input
                type="number"
                value={redeemAmountInput}
                onChange={e => setRedeemAmountInput(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-xs font-mono font-bold text-slate-800 focus:outline-none focus:border-[#0a192f]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Redemption Purpose
              </label>
              <input
                type="text"
                value={redeemPurposeInput}
                onChange={e => setRedeemPurposeInput(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-xs text-slate-800 focus:outline-none focus:border-[#0a192f]"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 px-4 bg-[#0a192f] hover:bg-[#071324] text-white font-bold text-xs rounded-lg transition shadow-xs flex items-center justify-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              PROCESS REDEMPTION TO RESERVE
            </button>
          </form>
        </div>
      </div>

      {/* Real-time Output Telemetry Box */}
      {lastResult && (
        <div
          className={`p-5 rounded-xl border ${
            lastResult.success ? 'bg-emerald-50 border-emerald-300 text-emerald-900' : 'bg-rose-50 border-rose-300 text-rose-900'
          }`}
        >
          <div className="flex items-center gap-2 font-bold text-sm mb-2">
            {lastResult.success ? <CheckCircle2 className="w-5 h-5 text-emerald-600" /> : <AlertCircle className="w-5 h-5 text-rose-600" />}
            <span>ISSUANCE ENGINE TELEMETRY RESULT</span>
          </div>

          <p className="text-xs mb-3 font-medium">{lastResult.message}</p>

          {lastResult.success && (
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3 bg-white/80 p-3 rounded-lg border border-emerald-200 text-xs font-mono">
              <div>
                <span className="text-[10px] text-slate-500 block uppercase">Institution</span>
                <span className="font-bold text-slate-800">{lastResult.instName}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 block uppercase">Previous Balance</span>
                <span className="text-slate-700">{formatAUD(lastResult.prevBalance || 0)}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 block uppercase">Adjustment</span>
                <span className={`font-bold ${(lastResult.amount || 0) >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
                  {(lastResult.amount || 0) >= 0 ? '+' : ''}{formatAUD(lastResult.amount || 0)}
                </span>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 block uppercase">New Balance</span>
                <span className="font-bold text-emerald-800">{formatAUD(lastResult.newBalance || 0)}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 block uppercase">Audit Reference</span>
                <span className="text-slate-800 font-bold">{lastResult.ref}</span>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Institutional Holdings Table */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
        <h3 className="text-sm font-bold text-[#1e232a] uppercase tracking-wide mb-3">
          INSTITUTIONAL DIGITAL AUD HOLDINGS & RESERVE POSITION
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px] border-b border-slate-200">
              <tr>
                <th className="p-3">Institution Name</th>
                <th className="p-3">Type</th>
                <th className="p-3 text-right">Digital AUD Balance</th>
                <th className="p-3 text-right">Intraday Liquidity</th>
                <th className="p-3 text-right">Collateral Allocated</th>
                <th className="p-3 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono">
              {institutions.map(inst => (
                <tr key={inst.id} className="hover:bg-slate-50">
                  <td className="p-3 font-bold font-sans text-slate-800">
                    {inst.name} <span className="text-slate-400 text-[10px]">({inst.code})</span>
                  </td>
                  <td className="p-3 font-sans text-slate-600">{inst.type}</td>
                  <td className="p-3 text-right font-bold text-[#2e5a44]">
                    {formatAUD(inst.digitalAudBalance)}
                  </td>
                  <td className="p-3 text-right text-slate-700">
                    {formatAUD(inst.intradayLiquidity)}
                  </td>
                  <td className="p-3 text-right text-slate-700">
                    {formatAUD(inst.collateralAllocated)}
                  </td>
                  <td className="p-3 text-center">
                    <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-bold text-[10px]">
                      {inst.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
