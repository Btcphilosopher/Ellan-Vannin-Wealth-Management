/**
 * ECONOMIC SIMULATION LAB MODULE
 */

import React, { useState } from 'react';
import { formatAUD } from '../utils/formatters';
import { Sliders, Activity, TrendingUp, RefreshCw, Landmark } from 'lucide-react';

export const EconomicSimulationLabView: React.FC = () => {
  const [cashRate, setCashRate] = useState<number>(4.35);
  const [cbdcRemuneration, setCbdcRemuneration] = useState<number>(3.85);
  const [substitutionRate, setSubstitutionRate] = useState<number>(12.5);
  const [bankMarginImpact, setBankMarginImpact] = useState<number>(-0.18);

  const recalculateLab = () => {
    // Dynamic recalculation simulation
    const newMargin = -0.05 * (cbdcRemuneration - 2.0);
    setBankMarginImpact(parseFloat(newMargin.toFixed(2)));
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2 py-0.5 rounded bg-[#0a192f] text-white text-[10px] font-bold uppercase tracking-wider">
                MONETARY POLICY RESEARCH
              </span>
              <span className="text-xs text-slate-500 font-mono">MACROECONOMIC SIMULATOR</span>
            </div>
            <h2 className="text-2xl font-extrabold text-[#1e232a] tracking-tight">
              ECONOMIC SIMULATION LAB
            </h2>
            <p className="text-xs text-slate-600 mt-1 max-w-2xl">
              Model the macroeconomic impact of digital AUD issuance on commercial bank disintermediation, lending margins, transmission velocity, and RBA policy pass-through.
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-4">
          <h3 className="text-sm font-bold text-[#1e232a] uppercase tracking-wide pb-2 border-b border-slate-100 flex items-center gap-2">
            <Sliders className="w-4 h-4 text-[#2e5a44]" />
            MACRO PARAMETER CONTROLS
          </h3>

          <div>
            <div className="flex justify-between text-xs font-bold mb-1">
              <span>RBA Cash Rate Target:</span>
              <span className="font-mono text-[#2e5a44]">{cashRate.toFixed(2)}%</span>
            </div>
            <input
              type="range"
              min="1.0"
              max="7.0"
              step="0.05"
              value={cashRate}
              onChange={e => { setCashRate(parseFloat(e.target.value)); recalculateLab(); }}
              className="w-full accent-[#2e5a44]"
            />
          </div>

          <div>
            <div className="flex justify-between text-xs font-bold mb-1">
              <span>Digital AUD Yield Remuneration:</span>
              <span className="font-mono text-[#0a192f]">{cbdcRemuneration.toFixed(2)}%</span>
            </div>
            <input
              type="range"
              min="0.0"
              max="5.0"
              step="0.05"
              value={cbdcRemuneration}
              onChange={e => { setCbdcRemuneration(parseFloat(e.target.value)); recalculateLab(); }}
              className="w-full accent-[#0a192f]"
            />
          </div>

          <div>
            <div className="flex justify-between text-xs font-bold mb-1">
              <span>Deposit Substitution Rate:</span>
              <span className="font-mono text-[#b85c18]">{substitutionRate.toFixed(1)}%</span>
            </div>
            <input
              type="range"
              min="0.0"
              max="30.0"
              step="0.5"
              value={substitutionRate}
              onChange={e => { setSubstitutionRate(parseFloat(e.target.value)); recalculateLab(); }}
              className="w-full accent-[#b85c18]"
            />
          </div>
        </div>

        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-4">
          <h3 className="text-sm font-bold text-[#1e232a] uppercase tracking-wide pb-2 border-b border-slate-100">
            SIMULATION IMPACT MODEL OUTPUTS
          </h3>

          <div className="grid grid-cols-2 gap-4 font-mono">
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl">
              <span className="text-[10px] font-bold text-slate-500 uppercase font-sans">Commercial Net Interest Margin (NIM)</span>
              <div className="text-xl font-extrabold text-rose-700 mt-1">{bankMarginImpact}%</div>
              <p className="text-[10px] text-slate-500 font-sans mt-1">Impact of deposit flight to central bank money</p>
            </div>

            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl">
              <span className="text-[10px] font-bold text-slate-500 uppercase font-sans">Policy Pass-Through Speed</span>
              <div className="text-xl font-extrabold text-emerald-700 mt-1">Immediate (100%)</div>
              <p className="text-[10px] text-slate-500 font-sans mt-1">Direct interest adjustment on digital AUD accounts</p>
            </div>
          </div>

          <div className="p-4 bg-slate-900 text-white rounded-xl font-mono text-xs space-y-2">
            <div className="font-bold text-emerald-400">RESEARCH MODEL SUMMARY</div>
            <p className="text-slate-300 leading-relaxed">
              At an RBA Cash Rate of {cashRate}% and Digital AUD remuneration of {cbdcRemuneration}%, commercial bank deposit substitution is projected at {substitutionRate}%, reducing average ADI net interest margin by {Math.abs(bankMarginImpact)}%.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
