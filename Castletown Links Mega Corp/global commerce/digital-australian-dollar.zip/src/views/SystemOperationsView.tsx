/**
 * SYSTEM OPERATIONS CENTRE MODULE
 */

import React, { useState } from 'react';
import { useSimulation } from '../simulation/simulationEngine';
import { Server, Activity, RefreshCw, Cpu, Database, HardDrive, ShieldCheck } from 'lucide-react';

export const SystemOperationsView: React.FC = () => {
  const { systemMetrics, triggerLiquidityFluctuation } = useSimulation();

  const [opsMsg, setOpsMsg] = useState<string | null>(null);

  const handlePulse = () => {
    triggerLiquidityFluctuation();
    setOpsMsg('Manual liquidity pulse & state synchronization triggered successfully.');
    setTimeout(() => setOpsMsg(null), 3000);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2 py-0.5 rounded bg-[#2e5a44] text-white text-[10px] font-bold uppercase tracking-wider">
              RBA SOC COMMAND
            </span>
            <span className="text-xs text-slate-500 font-mono">INFRASTRUCTURE CONTROLS</span>
          </div>
          <h2 className="text-2xl font-extrabold text-[#1e232a] tracking-tight">
            SYSTEM OPERATIONS CENTRE (SOC)
          </h2>
          <p className="text-xs text-slate-600 mt-1 max-w-2xl">
            Sovereign cloud operations terminal for node health, memory allocation, queue management, and simulation speed controls.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 font-mono">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-[10px] font-bold text-slate-500 uppercase font-sans">Primary Node Cluster</span>
          <div className="text-lg font-extrabold text-emerald-700 mt-1">syd-rba-core-01</div>
          <div className="text-[10px] text-slate-500 font-sans mt-1">Sydney Primary DC</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-[10px] font-bold text-slate-500 uppercase font-sans">Disaster Recovery Standby</span>
          <div className="text-lg font-extrabold text-emerald-700 mt-1">mel-rba-dr-02</div>
          <div className="text-[10px] text-slate-500 font-sans mt-1">Melbourne Active Replica</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-[10px] font-bold text-slate-500 uppercase font-sans">Ledger TPS Capacity</span>
          <div className="text-lg font-extrabold text-slate-900 mt-1">{systemMetrics.ledgerTPS} / 10,000</div>
          <div className="text-[10px] text-slate-500 font-sans mt-1">Peak Throughput Limit</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-[10px] font-bold text-slate-500 uppercase font-sans">Consensus Latency</span>
          <div className="text-lg font-extrabold text-slate-900 mt-1">{systemMetrics.settlementEngineLatency} ms</div>
          <div className="text-[10px] text-slate-500 font-sans mt-1">BFT Round-trip</div>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-4">
        <h3 className="text-sm font-bold text-[#1e232a] uppercase tracking-wide pb-2 border-b border-slate-100 flex items-center gap-2">
          <Server className="w-4 h-4 text-[#2e5a44]" />
          SIMULATION OPERATIONAL CONTROLS
        </h3>

        <div className="flex flex-col sm:flex-row gap-3">
          <button
            onClick={handlePulse}
            className="py-2.5 px-4 bg-[#2e5a44] hover:bg-[#234635] text-white text-xs font-bold rounded-lg transition flex items-center gap-2"
          >
            <RefreshCw className="w-4 h-4" />
            TRIGGER INTERBANK LIQUIDITY PULSE
          </button>
        </div>

        {opsMsg && (
          <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-mono font-bold rounded-lg">
            {opsMsg}
          </div>
        )}
      </div>
    </div>
  );
};
