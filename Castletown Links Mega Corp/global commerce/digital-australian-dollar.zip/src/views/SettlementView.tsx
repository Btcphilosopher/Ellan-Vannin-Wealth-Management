/**
 * INSTANT PAYMENT NETWORK MODULE
 */

import React, { useState } from 'react';
import { useSimulation } from '../simulation/simulationEngine';
import { formatAUD } from '../utils/formatters';
import { Zap, CheckCircle2, Activity, Clock, ShieldCheck, ArrowRight } from 'lucide-react';

export const SettlementView: React.FC = () => {
  const { systemMetrics, wholesaleSettlementToday, transactionsTodayCount } = useSimulation();

  const [simStep, setSimStep] = useState<number>(0);

  const startPaymentFlow = () => {
    setSimStep(1); // Payment Initiated
    setTimeout(() => setSimStep(2), 500); // Validation
    setTimeout(() => setSimStep(3), 1000); // Risk Check
    setTimeout(() => setSimStep(4), 1500); // Authorisation
    setTimeout(() => setSimStep(5), 2000); // Settlement
    setTimeout(() => setSimStep(6), 2500); // Confirmation
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2 py-0.5 rounded bg-[#2e5a44] text-white text-[10px] font-bold uppercase tracking-wider">
                REAL-TIME GROSS SETTLEMENT
              </span>
              <span className="text-xs text-slate-500 font-mono">24/7 INSTANT NETWORK</span>
            </div>
            <h2 className="text-2xl font-extrabold text-[#1e232a] tracking-tight">
              INSTANT PAYMENT NETWORK
            </h2>
            <p className="text-xs text-slate-600 mt-1 max-w-2xl">
              High-throughput, ultra-low latency settlement protocol delivering immediate finality for retail and wholesale transactions across Australia.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="px-3 py-1.5 rounded-md bg-emerald-50 text-emerald-800 border border-emerald-200 font-mono font-bold text-xs">
              ● NETWORK STATUS: OPERATIONAL
            </span>
          </div>
        </div>
      </div>

      {/* Dashboard KPI Grid as specified in Prompt */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 font-mono">
        <div className="bg-white p-3.5 rounded-xl border border-slate-200 text-center">
          <div className="text-[10px] font-bold text-slate-500 uppercase font-sans">Transactions / Sec</div>
          <div className="text-base font-extrabold text-[#2e5a44] mt-0.5">{systemMetrics.ledgerTPS} TPS</div>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-slate-200 text-center">
          <div className="text-[10px] font-bold text-slate-500 uppercase font-sans">Average Latency</div>
          <div className="text-base font-extrabold text-slate-800 mt-0.5">{systemMetrics.settlementEngineLatency} ms</div>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-slate-200 text-center">
          <div className="text-[10px] font-bold text-slate-500 uppercase font-sans">Success Rate</div>
          <div className="text-base font-extrabold text-emerald-700 mt-0.5">99.98%</div>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-slate-200 text-center">
          <div className="text-[10px] font-bold text-slate-500 uppercase font-sans">Pending Queue</div>
          <div className="text-base font-extrabold text-slate-800 mt-0.5">{systemMetrics.paymentEngineQueue} txs</div>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-slate-200 text-center">
          <div className="text-[10px] font-bold text-slate-500 uppercase font-sans">Settlement Value</div>
          <div className="text-base font-extrabold text-[#0a192f] mt-0.5">{formatAUD(wholesaleSettlementToday, { compact: true })}</div>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-slate-200 text-center">
          <div className="text-[10px] font-bold text-slate-500 uppercase font-sans">Network Status</div>
          <div className="text-base font-extrabold text-emerald-700 mt-0.5">HEALTHY</div>
        </div>
      </div>

      {/* Instant Settlement Flow Simulator as specified in Prompt */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-6">
        <div className="flex justify-between items-center pb-3 border-b border-slate-100">
          <div>
            <h3 className="text-sm font-bold text-[#1e232a] uppercase tracking-wide">
              INSTANT SETTLEMENT FLOW EXECUTION DEMONSTRATOR
            </h3>
            <p className="text-xs text-slate-500">Live 6-stage instant settlement verification</p>
          </div>
          <button
            onClick={startPaymentFlow}
            className="px-4 py-2 bg-[#2e5a44] hover:bg-[#234635] text-white font-bold text-xs rounded-lg transition"
          >
            TRIGGER A$850.00 SETTLEMENT
          </button>
        </div>

        {/* 6 Stage Flow Graphic */}
        <div className="grid grid-cols-2 md:grid-cols-6 gap-2 text-center text-xs font-semibold font-mono">
          <div className={`p-3 rounded-lg border transition ${simStep >= 1 ? 'bg-emerald-50 border-emerald-400 text-emerald-900' : 'bg-slate-50 border-slate-200 text-slate-400'}`}>
            <div className="text-[10px] font-bold">STAGE 1</div>
            <div className="mt-1">Payment Initiated</div>
          </div>

          <div className={`p-3 rounded-lg border transition ${simStep >= 2 ? 'bg-emerald-50 border-emerald-400 text-emerald-900' : 'bg-slate-50 border-slate-200 text-slate-400'}`}>
            <div className="text-[10px] font-bold">STAGE 2</div>
            <div className="mt-1">Validation</div>
          </div>

          <div className={`p-3 rounded-lg border transition ${simStep >= 3 ? 'bg-emerald-50 border-emerald-400 text-emerald-900' : 'bg-slate-50 border-slate-200 text-slate-400'}`}>
            <div className="text-[10px] font-bold">STAGE 3</div>
            <div className="mt-1">Risk Check</div>
          </div>

          <div className={`p-3 rounded-lg border transition ${simStep >= 4 ? 'bg-emerald-50 border-emerald-400 text-emerald-900' : 'bg-slate-50 border-slate-200 text-slate-400'}`}>
            <div className="text-[10px] font-bold">STAGE 4</div>
            <div className="mt-1">Authorisation</div>
          </div>

          <div className={`p-3 rounded-lg border transition ${simStep >= 5 ? 'bg-emerald-50 border-emerald-400 text-emerald-900' : 'bg-slate-50 border-slate-200 text-slate-400'}`}>
            <div className="text-[10px] font-bold">STAGE 5</div>
            <div className="mt-1">Settlement</div>
          </div>

          <div className={`p-3 rounded-lg border transition ${simStep >= 6 ? 'bg-[#2e5a44] text-white border-[#2e5a44]' : 'bg-slate-50 border-slate-200 text-slate-400'}`}>
            <div className="text-[10px] font-bold">STAGE 6</div>
            <div className="mt-1">Confirmation</div>
          </div>
        </div>

        {/* Live Example Box as specified in Prompt */}
        {simStep > 0 && (
          <div className="p-4 bg-slate-900 text-white rounded-xl font-mono text-xs flex flex-col sm:flex-row items-center justify-between gap-4">
            <div>
              <span className="text-slate-400">TRANSFER VALUE: </span>
              <span className="text-lg font-bold text-amber-400">A$850.00 DIGITAL AUD</span>
            </div>

            <div className="flex items-center gap-3">
              {simStep < 6 ? (
                <div className="flex items-center gap-2 text-amber-300 font-bold animate-pulse">
                  <Activity className="w-4 h-4" />
                  <span>PAYMENT PROCESSING (STAGE {simStep}/6)...</span>
                </div>
              ) : (
                <div className="flex items-center gap-2 text-emerald-400 font-bold">
                  <Zap className="w-4 h-4" />
                  <span>PAYMENT COMPLETE (FINALITY FINALIZED)</span>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
