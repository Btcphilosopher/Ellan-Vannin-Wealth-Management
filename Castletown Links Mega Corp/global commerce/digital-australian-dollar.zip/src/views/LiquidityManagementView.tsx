/**
 * LIQUIDITY MANAGEMENT & STRESS TESTING MODULE
 */

import React, { useState } from 'react';
import { useSimulation } from '../simulation/simulationEngine';
import { formatAUD } from '../utils/formatters';
import { ShieldAlert, Activity, CheckCircle2, RefreshCw, Zap } from 'lucide-react';

export const LiquidityManagementView: React.FC = () => {
  const {
    institutions,
    systemMetrics
  } = useSimulation();

  const [stressScenario, setStressScenario] = useState<'NONE' | 'LIQUIDITY_SHOCK' | 'INTERBANK_DELAY' | 'SETTLEMENT_SURGE'>('NONE');
  const [liquidityRatio, setLiquidityRatio] = useState<number>(142.5);
  const [standingFacilityActive, setStandingFacilityActive] = useState<boolean>(false);

  const runStressTest = (scenario: typeof stressScenario) => {
    setStressScenario(scenario);
    if (scenario === 'LIQUIDITY_SHOCK') {
      setLiquidityRatio(108.2);
      setStandingFacilityActive(true);
    } else if (scenario === 'INTERBANK_DELAY') {
      setLiquidityRatio(124.0);
      setStandingFacilityActive(false);
    } else if (scenario === 'SETTLEMENT_SURGE') {
      setLiquidityRatio(115.8);
      setStandingFacilityActive(true);
    } else {
      setLiquidityRatio(142.5);
      setStandingFacilityActive(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2 py-0.5 rounded bg-[#2e5a44] text-white text-[10px] font-bold uppercase tracking-wider">
                PRUDENTIAL LIQUIDITY MONITOR
              </span>
              <span className="text-xs text-slate-500 font-mono">INTRA-DAY RESERVE COVERAGE</span>
            </div>
            <h2 className="text-2xl font-extrabold text-[#1e232a] tracking-tight">
              LIQUIDITY MANAGEMENT & STRESS LAB
            </h2>
            <p className="text-xs text-slate-600 mt-1 max-w-2xl">
              Real-time monitoring of systemic intraday liquidity, collateral pledging, Reserve Bank standing facilities, and prudential stress scenario modelling.
            </p>
          </div>

          <div className="bg-[#f0f7f3] border border-[#2e5a44]/30 rounded-xl p-4 text-right font-mono">
            <div className="text-[10px] font-bold uppercase tracking-wider text-[#2e5a44]">
              Systemic Liquidity Ratio
            </div>
            <div className="text-2xl font-extrabold text-[#2e5a44] mt-0.5">
              {liquidityRatio.toFixed(1)}%
            </div>
            <div className="text-[10px] text-slate-500">Prudential Minimum: 100.0%</div>
          </div>
        </div>
      </div>

      {/* Liquidity Positions Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 font-mono">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="text-[10px] font-bold text-slate-500 uppercase font-sans">Central Bank Exchange Reserves</div>
          <div className="text-xl font-extrabold text-[#2e5a44] mt-1">{formatAUD(14200000000, { compact: true })}</div>
          <div className="text-[10px] text-slate-500 mt-1">Direct RBA Deposit Claims</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="text-[10px] font-bold text-slate-500 uppercase font-sans">Intraday Liquidity Facilities</div>
          <div className="text-xl font-extrabold text-slate-800 mt-1">{formatAUD(8500000000, { compact: true })}</div>
          <div className="text-[10px] text-slate-500 mt-1">Repo-backed intraday limit</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="text-[10px] font-bold text-slate-500 uppercase font-sans">Pledged AGS Collateral Buffer</div>
          <div className="text-xl font-extrabold text-slate-800 mt-1">{formatAUD(12800000000, { compact: true })}</div>
          <div className="text-[10px] text-slate-500 mt-1">Australian Govt Securities</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="text-[10px] font-bold text-slate-500 uppercase font-sans">RBA Standing Facility Status</div>
          <div className={`text-sm font-extrabold mt-1 uppercase ${standingFacilityActive ? 'text-amber-600' : 'text-emerald-700'}`}>
            {standingFacilityActive ? '● ACTIVATED (AUTO REPO)' : '● STANDBY (PASSIVE)'}
          </div>
          <div className="text-[10px] text-slate-500 mt-1">Automated overnight liquidity</div>
        </div>
      </div>

      {/* Stress Testing Simulator as specified in Prompt */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
        <h3 className="text-sm font-bold text-[#1e232a] uppercase tracking-wide mb-4 pb-2 border-b border-slate-100 flex items-center gap-2">
          <ShieldAlert className="w-4 h-4 text-amber-600" />
          SYSTEMIC LIQUIDITY STRESS SCENARIO LAB
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 mb-6">
          <button
            onClick={() => runStressTest('NONE')}
            className={`p-3 rounded-lg border text-left transition text-xs ${
              stressScenario === 'NONE'
                ? 'bg-[#2e5a44] text-white border-[#2e5a44] font-bold'
                : 'bg-slate-50 text-slate-800 border-slate-200 hover:bg-slate-100'
            }`}
          >
            <div className="font-bold">Baseline Conditions</div>
            <p className="text-[10px] opacity-80 mt-1">Standard market liquidity & settlement velocity</p>
          </button>

          <button
            onClick={() => runStressTest('LIQUIDITY_SHOCK')}
            className={`p-3 rounded-lg border text-left transition text-xs ${
              stressScenario === 'LIQUIDITY_SHOCK'
                ? 'bg-rose-800 text-white border-rose-800 font-bold'
                : 'bg-slate-50 text-slate-800 border-slate-200 hover:bg-slate-100'
            }`}
          >
            <div className="font-bold">Liquidity Shock</div>
            <p className="text-[10px] opacity-80 mt-1">Simulates 40% sudden outflow in commercial deposits</p>
          </button>

          <button
            onClick={() => runStressTest('INTERBANK_DELAY')}
            className={`p-3 rounded-lg border text-left transition text-xs ${
              stressScenario === 'INTERBANK_DELAY'
                ? 'bg-amber-800 text-white border-amber-800 font-bold'
                : 'bg-slate-50 text-slate-800 border-slate-200 hover:bg-slate-100'
            }`}
          >
            <div className="font-bold">Interbank Gridlock</div>
            <p className="text-[10px] opacity-80 mt-1">Simulates queue buildup in interbank RTGS clearing</p>
          </button>

          <button
            onClick={() => runStressTest('SETTLEMENT_SURGE')}
            className={`p-3 rounded-lg border text-left transition text-xs ${
              stressScenario === 'SETTLEMENT_SURGE'
                ? 'bg-[#0a192f] text-white border-[#0a192f] font-bold'
                : 'bg-slate-50 text-slate-800 border-slate-200 hover:bg-slate-100'
            }`}
          >
            <div className="font-bold">Settlement Volume Surge</div>
            <p className="text-[10px] opacity-80 mt-1">Simulates 500% spike in DvP asset settlement traffic</p>
          </button>
        </div>

        {/* Telemetry Output */}
        <div className="p-4 bg-slate-900 text-white rounded-xl font-mono text-xs space-y-2">
          <div className="flex items-center justify-between text-amber-400 font-bold text-[11px]">
            <span>SCENARIO TELEMETRY MODEL OUTPUT</span>
            <span>RATIO: {liquidityRatio.toFixed(1)}%</span>
          </div>

          <div className="text-slate-300">
            {stressScenario === 'NONE' && 'Baseline conditions operational. Systemic liquidity buffer exceeds regulatory APRA requirements by +42.5%.'}
            {stressScenario === 'LIQUIDITY_SHOCK' && 'CRITICAL SCENARIO: RBA Standing Liquidity Facility automatically triggered repo allocation of A$1.2B to prevent interbank shortfall.'}
            {stressScenario === 'INTERBANK_DELAY' && 'WARNING: Queue algorithm engaged. Intraday netting active to clear A$450M pending interbank transfers.'}
            {stressScenario === 'SETTLEMENT_SURGE' && 'HIGH THROUGHPUT: Settlement engine processed 4,890 DvP atomic swaps in 12 seconds with zero queuing.'}
          </div>
        </div>
      </div>
    </div>
  );
};
