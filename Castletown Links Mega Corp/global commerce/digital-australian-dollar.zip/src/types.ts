/**
 * DIGITAL AUSTRALIAN DOLLAR (Digital AUD)
 * Australian CBDC & Digital Money Infrastructure
 * Type Definitions
 */

export type MoneyType = 
  | 'CENTRAL_BANK_CBDC' 
  | 'COMMERCIAL_BANK_MONEY' 
  | 'TOKENISED_DEPOSIT' 
  | 'TOKENISED_ASSET';

export type InstitutionId = 
  | 'rba' 
  | 'scb' 
  | 'cfs' 
  | 'pnb' 
  | 'scap' 
  | 'amb';

export interface Institution {
  id: InstitutionId;
  name: string;
  code: string;
  type: 'CENTRAL_BANK' | 'COMMERCIAL_BANK' | 'MARKET_INFRASTRUCTURE' | 'INVESTMENT_BANK';
  digitalAudBalance: number;
  commercialBankBalance: number;
  tokenisedDepositBalance: number;
  tokenisedAssetValue: number;
  pendingSettlement: number;
  intradayLiquidity: number;
  collateralAllocated: number;
  liquidityBuffer: number;
  status: 'OPERATIONAL' | 'DEGRADED' | 'MAINTENANCE';
  apiHealth: number; // 0 - 100
  riskScore: 'LOW' | 'MEDIUM' | 'HIGH';
  activeAccounts: number;
}

export interface DigitalAUDAccount {
  id: string;
  accountNumber: string;
  institutionId: InstitutionId;
  holderName: string;
  holderType: 'INSTITUTION' | 'CORPORATE' | 'RETAIL' | 'MERCHANT';
  moneyType: MoneyType;
  balance: number;
  currency: 'AUD';
  status: 'ACTIVE' | 'SUSPENDED' | 'FROZEN';
  createdAt: string;
}

export interface TokenisedDeposit {
  id: string;
  issuerId: InstitutionId;
  holderName: string;
  underlyingDepositRef: string;
  tokenAmount: number;
  interestRate: number; // e.g. 4.35
  maturityDate: string;
  settlementStatus: 'SETTLED' | 'PENDING' | 'LOCKED';
  redemptionStatus: 'ACTIVE' | 'REQUESTED' | 'REDEEMED';
  createdAt: string;
}

export type AssetCategory = 
  | 'GOVERNMENT_BOND' 
  | 'CORPORATE_BOND' 
  | 'MONEY_MARKET' 
  | 'EQUITIES_SIM' 
  | 'REAL_ESTATE_SIM' 
  | 'CARBON_ASSET';

export interface TokenisedAsset {
  id: string;
  assetCode: string;
  name: string;
  category: AssetCategory;
  issuer: string;
  ownerId: InstitutionId;
  ownerName: string;
  quantity: number;
  unitValue: number; // in AUD
  totalValue: number; // in AUD
  settlementCurrency: 'DIGITAL_AUD';
  status: 'FREE' | 'PLEDGED' | 'IN_SETTLEMENT';
  isrcCode: string;
}

export interface Transaction {
  id: string;
  ledgerId: string;
  timestamp: string;
  originId: string;
  originName: string;
  destinationId: string;
  destinationName: string;
  amount: number;
  moneyType: MoneyType;
  assetReference?: string;
  channel: 'WHOLESALE_CBDC' | 'RETAIL_WALLET' | 'TOKENISED_DEPOSIT' | 'INSTANT_NPP' | 'CROSS_BORDER' | 'DVP_SETTLEMENT';
  purpose: string;
  status: 'COMPLETED' | 'PENDING' | 'REJECTED' | 'RISK_HOLD';
  latencyMs: number;
  stateHash?: string;
  finalityStatus?: string;
}

export interface DvPSettlement {
  id: string;
  tradeReference: string;
  assetId: string;
  assetName: string;
  sellerId: InstitutionId;
  sellerName: string;
  buyerId: InstitutionId;
  buyerName: string;
  assetQuantity: number;
  paymentAmount: number;
  status: 'MATCHING' | 'CLEARING' | 'ASSET_DELIVERY' | 'PAYMENT_PENDING' | 'SETTLED' | 'FAILED';
  executionTime: string;
}

export interface ProgrammableRule {
  id: string;
  title: string;
  useCase: 'CORPORATE_TREASURY' | 'TRADE_FINANCE' | 'BOND_DVP' | 'CONDITIONAL_ESCROW' | 'INFRASTRUCTURE' | 'AUTOMATED_TREASURY';
  payerName: string;
  payerId: InstitutionId;
  recipientName: string;
  recipientId: InstitutionId;
  amount: number;
  assetCode?: string;
  condition: string;
  executionDate: string;
  expiryDate: string;
  status: 'ACTIVE' | 'WAITING_FOR_CONDITION' | 'EXECUTED' | 'EXPIRED' | 'CANCELLED';
  createdAt: string;
}

export interface CrossBorderTransfer {
  id: string;
  corridor: 'AUD/USD' | 'AUD/EUR' | 'AUD/JPY' | 'AUD/SGD';
  originInstitution: string;
  foreignInstitution: string;
  audAmount: number;
  foreignAmount: number;
  fxRate: number;
  foreignCurrency: 'USD' | 'EUR' | 'JPY' | 'SGD';
  settlementAsset: 'DIGITAL_AUD_PvP';
  status: 'PENDING' | 'LOCKING' | 'SWAPPING' | 'SETTLED';
  timestamp: string;
}

export interface RiskAlert {
  id: string;
  transactionId: string;
  txId?: string;
  institutionName: string;
  entityName?: string;
  amount: number;
  ruleViolated: string;
  category?: string;
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  riskLevel?: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  status: 'REVIEW_REQUIRED' | 'INVESTIGATING' | 'RESOLVED' | 'FROZEN' | 'NEW' | 'FLAGGED' | 'APPROVED';
  timestamp: string;
  description: string;
}

export interface AuditEvent {
  id: string;
  timestamp: string;
  institution: string;
  operation: string;
  eventType?: string;
  actor?: string;
  details?: string;
  cryptoSignature?: string;
  assetOrCurrency: string;
  amount: number;
  result: 'SUCCESS' | 'BLOCKED' | 'FLAGGED';
  riskLevel: 'INFORMATIONAL' | 'LOW' | 'MEDIUM' | 'HIGH';
  operator: string;
}

export interface RegionMetric {
  code: 'NSW' | 'VIC' | 'QLD' | 'WA' | 'SA' | 'TAS' | 'ACT' | 'NT';
  name: string;
  hubCity: string;
  transactionValueToday: number;
  settlementValueToday: number;
  activeInstitutionsCount: number;
  merchantVolume: number;
  digitalMoneyAdoptionRate: number; // percentage
}

export interface ServiceHealth {
  name: string;
  code: string;
  requestsPerSec: number;
  latencyMs: number;
  errorRate: number; // percentage e.g. 0.02
  queueDepth: number;
  availability: number; // percentage e.g. 99.99
  status: 'OPERATIONAL' | 'DEGRADED' | 'MAINTENANCE' | 'OFFLINE';
}

export interface SystemMetrics {
  cpuUsage: number; // %
  memoryUsage: number; // %
  dbLoad: number; // %
  ledgerTPS: number;
  settlementEngineLatency: number; // ms
  paymentEngineQueue: number;
  activeNodes: number;
}

export interface RetailTransaction {
  id: string;
  merchantName: string;
  category: 'Supermarket' | 'Transport' | 'Restaurant' | 'Online Purchase' | 'Utilities' | 'Services';
  amount: number;
  timestamp: string;
  status: 'COMPLETED';
  channel: 'NFC' | 'QR' | 'CARD' | 'ONLINE';
}

export type ViewMode = 
  | 'national-overview'
  | 'digital-aud-issuance'
  | 'wholesale-cbdc'
  | 'retail-cbdc'
  | 'tokenised-deposits'
  | 'banks-institutions'
  | 'payments-infrastructure'
  | 'settlement'
  | 'tokenised-assets'
  | 'programmable-money'
  | 'cross-border'
  | 'liquidity-management'
  | 'risk-compliance'
  | 'market-infrastructure'
  | 'corporate-treasury'
  | 'audit-trail'
  | 'system-operations'
  | 'research-lab';
