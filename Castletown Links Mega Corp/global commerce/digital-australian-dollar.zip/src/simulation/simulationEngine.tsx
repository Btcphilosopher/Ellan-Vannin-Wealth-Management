/**
 * Stateful Simulation Engine
 * DIGITAL AUSTRALIAN DOLLAR Infrastructure
 */

import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import {
  Institution,
  InstitutionId,
  TokenisedDeposit,
  TokenisedAsset,
  Transaction,
  DvPSettlement,
  ProgrammableRule,
  CrossBorderTransfer,
  RiskAlert,
  AuditEvent,
  SystemMetrics,
  RetailTransaction,
  MoneyType
} from '../types';

import {
  INITIAL_INSTITUTIONS,
  INITIAL_TOKENISED_DEPOSITS,
  INITIAL_TOKENISED_ASSETS,
  INITIAL_TRANSACTIONS,
  INITIAL_DVP_SETTLEMENTS,
  INITIAL_PROGRAMMABLE_RULES,
  INITIAL_CROSS_BORDER_TRANSFERS,
  INITIAL_RISK_ALERTS,
  INITIAL_AUDIT_EVENTS,
  INITIAL_SERVICES_HEALTH,
  INITIAL_SYSTEM_METRICS,
  INITIAL_RETAIL_TRANSACTIONS
} from '../data/initialData';

import { formatAUDate, formatAUD } from '../utils/formatters';

interface SimulationContextType {
  // State
  institutions: Institution[];
  tokenisedDeposits: TokenisedDeposit[];
  tokenisedAssets: TokenisedAsset[];
  transactions: Transaction[];
  dvpSettlements: DvPSettlement[];
  programmableRules: ProgrammableRule[];
  crossBorderTransfers: CrossBorderTransfer[];
  riskAlerts: RiskAlert[];
  auditEvents: AuditEvent[];
  systemMetrics: SystemMetrics;
  retailTransactions: RetailTransaction[];
  retailBalance: number;
  digitalAudTotalOutstanding: number;
  wholesaleSettlementToday: number;
  transactionsTodayCount: number;

  // Simulation Controls
  isPaused: boolean;
  speedMultiplier: number; // 1, 10, 100
  togglePause: () => void;
  setSpeedMultiplier: (speed: number) => void;
  resetSimulation: () => void;

  // State Mutation Actions
  issueDigitalAUD: (institutionId: InstitutionId, amount: number, purpose: string, reference: string) => { success: boolean; message: string };
  redeemDigitalAUD: (institutionId: InstitutionId, amount: number, purpose: string) => { success: boolean; message: string };
  executeWholesaleTransfer: (
    originId: InstitutionId,
    destinationId: InstitutionId,
    amount: number,
    purpose: string,
    moneyType?: MoneyType
  ) => { success: boolean; message: string };
  mintTokenisedDeposit: (
    issuerId: InstitutionId,
    holderName: string,
    depositRef: string,
    tokenAmount: number,
    interestRate: number
  ) => { success: boolean; message: string };
  redeemTokenisedDeposit: (depositId: string) => { success: boolean; message: string };
  executeDvPSettlement: (
    assetId: string,
    sellerId: InstitutionId,
    buyerId: InstitutionId,
    paymentAmount: number
  ) => { success: boolean; message: string };
  executeRetailPayment: (
    merchantName: string,
    category: RetailTransaction['category'],
    amount: number,
    channel: RetailTransaction['channel']
  ) => { success: boolean; message: string };
  addProgrammableRule: (rule: Omit<ProgrammableRule, 'id' | 'createdAt' | 'status'>) => void;
  triggerProgrammableRule: (ruleId: string) => { success: boolean; message: string };
  executeCrossBorderFx: (
    corridor: 'AUD/USD' | 'AUD/EUR' | 'AUD/JPY' | 'AUD/SGD',
    originInstitution: string,
    foreignInstitution: string,
    audAmount: number
  ) => { success: boolean; message: string };
  resolveRiskAlert: (alertId: string, action: 'DISMISS' | 'FREEZE_FUNDS') => void;
  updateRiskAlertStatus: (alertId: string, status: RiskAlert['status']) => void;
  verifyTransactionHash: (txId: string) => string;
  triggerLiquidityFluctuation: () => void;
}

const SimulationContext = createContext<SimulationContextType | undefined>(undefined);

export const SimulationProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [institutions, setInstitutions] = useState<Institution[]>(INITIAL_INSTITUTIONS);
  const [tokenisedDeposits, setTokenisedDeposits] = useState<TokenisedDeposit[]>(INITIAL_TOKENISED_DEPOSITS);
  const [tokenisedAssets, setTokenisedAssets] = useState<TokenisedAsset[]>(INITIAL_TOKENISED_ASSETS);
  const [transactions, setTransactions] = useState<Transaction[]>(INITIAL_TRANSACTIONS);
  const [dvpSettlements, setDvpSettlements] = useState<DvPSettlement[]>(INITIAL_DVP_SETTLEMENTS);
  const [programmableRules, setProgrammableRules] = useState<ProgrammableRule[]>(INITIAL_PROGRAMMABLE_RULES);
  const [crossBorderTransfers, setCrossBorderTransfers] = useState<CrossBorderTransfer[]>(INITIAL_CROSS_BORDER_TRANSFERS);
  const [riskAlerts, setRiskAlerts] = useState<RiskAlert[]>(INITIAL_RISK_ALERTS);
  const [auditEvents, setAuditEvents] = useState<AuditEvent[]>(INITIAL_AUDIT_EVENTS);
  const [systemMetrics, setSystemMetrics] = useState<SystemMetrics>(INITIAL_SYSTEM_METRICS);
  const [retailTransactions, setRetailTransactions] = useState<RetailTransaction[]>(INITIAL_RETAIL_TRANSACTIONS);
  
  // Retail balance starts at prompt requirement: A$4,820.50
  const [retailBalance, setRetailBalance] = useState<number>(4820.50);
  
  // Controls
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [speedMultiplier, setSpeedMultiplier] = useState<number>(1);

  // Derived aggregates
  const digitalAudTotalOutstanding = institutions.reduce((acc, inst) => acc + inst.digitalAudBalance, 0);
  const wholesaleSettlementToday = 84293104000 + transactions.reduce((acc, tx) => acc + tx.amount, 0);
  const transactionsTodayCount = 2481392 + transactions.length;

  const togglePause = () => setIsPaused(prev => !prev);

  // Helper to record audit events
  const addAuditEvent = useCallback((
    institution: string,
    operation: string,
    assetOrCurrency: string,
    amount: number,
    result: 'SUCCESS' | 'BLOCKED' | 'FLAGGED',
    riskLevel: 'INFORMATIONAL' | 'LOW' | 'MEDIUM' | 'HIGH',
    operator: string = 'SIMULATION_ENGINE'
  ) => {
    const newEvent: AuditEvent = {
      id: `AUD-2026-${String(Math.floor(Math.random() * 899999) + 100000)}`,
      timestamp: formatAUDate(),
      institution,
      operation,
      assetOrCurrency,
      amount,
      result,
      riskLevel,
      operator,
    };
    setAuditEvents(prev => [newEvent, ...prev]);
  }, []);

  // 1. Digital AUD Issuance Engine
  const issueDigitalAUD = useCallback((
    institutionId: InstitutionId,
    amount: number,
    purpose: string,
    reference: string
  ) => {
    if (amount <= 0) {
      return { success: false, message: 'Issuance amount must be greater than A$0.00' };
    }

    const targetInst = institutions.find(i => i.id === institutionId);
    if (!targetInst) {
      return { success: false, message: 'Invalid target institution' };
    }

    setInstitutions(prev => prev.map(inst => {
      if (inst.id === institutionId) {
        return {
          ...inst,
          digitalAudBalance: inst.digitalAudBalance + amount,
          intradayLiquidity: inst.intradayLiquidity + amount,
        };
      }
      return inst;
    }));

    const txId = `DA-ISS-${Math.floor(Math.random() * 8999) + 1000}`;
    const newTx: Transaction = {
      id: txId,
      ledgerId: `LEDGER-AU-ISS-${Date.now().toString().slice(-6)}`,
      timestamp: formatAUDate(),
      originId: 'rba',
      originName: 'Reserve Bank Simulation Core',
      destinationId: institutionId,
      destinationName: targetInst.name,
      amount,
      moneyType: 'CENTRAL_BANK_CBDC',
      channel: 'WHOLESALE_CBDC',
      purpose: `Issuance: ${purpose} [Ref: ${reference}]`,
      status: 'COMPLETED',
      latencyMs: 14,
    };

    setTransactions(prev => [newTx, ...prev]);
    addAuditEvent(targetInst.name, 'DIGITAL_AUD_ISSUANCE', 'Digital AUD', amount, 'SUCCESS', 'INFORMATIONAL', 'RESERVE_BANK_ISSUANCE_DESK');

    return { success: true, message: `Successfully issued ${formatAUD(amount)} Digital AUD to ${targetInst.name}` };
  }, [institutions, addAuditEvent]);

  // 2. Digital AUD Redemption
  const redeemDigitalAUD = useCallback((
    institutionId: InstitutionId,
    amount: number,
    purpose: string
  ) => {
    const inst = institutions.find(i => i.id === institutionId);
    if (!inst) return { success: false, message: 'Institution not found' };
    if (inst.digitalAudBalance < amount) {
      addAuditEvent(inst.name, 'CBDC_REDEMPTION_FAILED', 'Digital AUD', amount, 'BLOCKED', 'HIGH', 'RISK_ENGINE');
      return { success: false, message: `Insufficient Digital AUD balance (${formatAUD(inst.digitalAudBalance)})` };
    }

    setInstitutions(prev => prev.map(i => {
      if (i.id === institutionId) {
        return {
          ...i,
          digitalAudBalance: i.digitalAudBalance - amount,
          intradayLiquidity: Math.max(0, i.intradayLiquidity - amount),
        };
      }
      return i;
    }));

    const newTx: Transaction = {
      id: `DA-RED-${Math.floor(Math.random() * 8999) + 1000}`,
      ledgerId: `LEDGER-AU-RED-${Date.now().toString().slice(-6)}`,
      timestamp: formatAUDate(),
      originId: institutionId,
      originName: inst.name,
      destinationId: 'rba',
      destinationName: 'Reserve Bank Simulation Core',
      amount,
      moneyType: 'CENTRAL_BANK_CBDC',
      channel: 'WHOLESALE_CBDC',
      purpose: `Redemption: ${purpose}`,
      status: 'COMPLETED',
      latencyMs: 11,
    };

    setTransactions(prev => [newTx, ...prev]);
    addAuditEvent(inst.name, 'CBDC_REDEMPTION', 'Digital AUD', amount, 'SUCCESS', 'LOW', 'TREASURY_DESK');
    return { success: true, message: `Redeemed ${formatAUD(amount)} Digital AUD back to Reserve Account` };
  }, [institutions, addAuditEvent]);

  // 3. Interbank Wholesale Settlement Transfer
  const executeWholesaleTransfer = useCallback((
    originId: InstitutionId,
    destinationId: InstitutionId,
    amount: number,
    purpose: string,
    moneyType: MoneyType = 'CENTRAL_BANK_CBDC'
  ) => {
    if (originId === destinationId) return { success: false, message: 'Origin and destination must differ' };
    const originInst = institutions.find(i => i.id === originId);
    const destInst = institutions.find(i => i.id === destinationId);

    if (!originInst || !destInst) return { success: false, message: 'Invalid institution selected' };

    if (moneyType === 'CENTRAL_BANK_CBDC' && originInst.digitalAudBalance < amount) {
      addAuditEvent(originInst.name, 'WHOLESALE_SETTLEMENT_REJECTED', 'Digital AUD', amount, 'BLOCKED', 'HIGH');
      return { success: false, message: `Insufficient Digital AUD Balance (${formatAUD(originInst.digitalAudBalance)})` };
    }

    // Risk Check: if transfer is unusually large (> A$100M), trigger a risk alert simulation
    let isRiskHold = false;
    if (amount > 100000000) {
      const riskAlert: RiskAlert = {
        id: `RISK-${Math.floor(Math.random() * 899999) + 100000}`,
        transactionId: `DA-TX-${Math.floor(Math.random() * 8999) + 1000}`,
        institutionName: originInst.name,
        amount,
        ruleViolated: 'LARGE VALUE SINGLE INTRADAY SETTLEMENT',
        severity: 'MEDIUM',
        status: 'REVIEW_REQUIRED',
        timestamp: formatAUDate(),
        description: `High-value transfer of ${formatAUD(amount)} routed to real-time risk compliance inspection.`,
      };
      setRiskAlerts(prev => [riskAlert, ...prev]);
      isRiskHold = false; // still allow simulation settlement after recording
    }

    // Execute state update
    setInstitutions(prev => prev.map(inst => {
      if (inst.id === originId) {
        return {
          ...inst,
          digitalAudBalance: moneyType === 'CENTRAL_BANK_CBDC' ? inst.digitalAudBalance - amount : inst.digitalAudBalance,
          commercialBankBalance: moneyType === 'COMMERCIAL_BANK_MONEY' ? inst.commercialBankBalance - amount : inst.commercialBankBalance,
          tokenisedDepositBalance: moneyType === 'TOKENISED_DEPOSIT' ? inst.tokenisedDepositBalance - amount : inst.tokenisedDepositBalance,
          intradayLiquidity: Math.max(0, inst.intradayLiquidity - amount),
        };
      }
      if (inst.id === destinationId) {
        return {
          ...inst,
          digitalAudBalance: moneyType === 'CENTRAL_BANK_CBDC' ? inst.digitalAudBalance + amount : inst.digitalAudBalance,
          commercialBankBalance: moneyType === 'COMMERCIAL_BANK_MONEY' ? inst.commercialBankBalance + amount : inst.commercialBankBalance,
          tokenisedDepositBalance: moneyType === 'TOKENISED_DEPOSIT' ? inst.tokenisedDepositBalance + amount : inst.tokenisedDepositBalance,
          intradayLiquidity: inst.intradayLiquidity + amount,
        };
      }
      return inst;
    }));

    const txId = `DA-WS-${Math.floor(Math.random() * 89999) + 10000}`;
    const newTx: Transaction = {
      id: txId,
      ledgerId: `LEDGER-AU-${Date.now().toString().slice(-6)}`,
      timestamp: formatAUDate(),
      originId,
      originName: originInst.name,
      destinationId,
      destinationName: destInst.name,
      amount,
      moneyType,
      channel: 'WHOLESALE_CBDC',
      purpose,
      status: 'COMPLETED',
      latencyMs: Math.floor(Math.random() * 15) + 8,
    };

    setTransactions(prev => [newTx, ...prev]);
    addAuditEvent(originInst.name, 'WHOLESALE_INTERBANK_TRANSFER', moneyType, amount, 'SUCCESS', 'INFORMATIONAL');

    return { success: true, message: `Settled ${formatAUD(amount)} from ${originInst.name} to ${destInst.name}` };
  }, [institutions, addAuditEvent]);

  // 4. Tokenised Deposit Minting & Redemption
  const mintTokenisedDeposit = useCallback((
    issuerId: InstitutionId,
    holderName: string,
    depositRef: string,
    tokenAmount: number,
    interestRate: number
  ) => {
    const issuer = institutions.find(i => i.id === issuerId);
    if (!issuer) return { success: false, message: 'Invalid issuer bank' };

    // Update bank balances: transform commercial deposit into tokenised deposit balance
    setInstitutions(prev => prev.map(i => {
      if (i.id === issuerId) {
        return {
          ...i,
          commercialBankBalance: Math.max(0, i.commercialBankBalance - tokenAmount),
          tokenisedDepositBalance: i.tokenisedDepositBalance + tokenAmount,
        };
      }
      return i;
    }));

    const newDeposit: TokenisedDeposit = {
      id: `TD-${Math.floor(Math.random() * 89999) + 10000}`,
      issuerId,
      holderName,
      underlyingDepositRef: depositRef || `DEP-${issuer.code}-${Math.floor(Math.random() * 89999)}`,
      tokenAmount,
      interestRate,
      maturityDate: '2026-12-31',
      settlementStatus: 'SETTLED',
      redemptionStatus: 'ACTIVE',
      createdAt: formatAUDate(),
    };

    setTokenisedDeposits(prev => [newDeposit, ...prev]);
    addAuditEvent(issuer.name, 'TOKENISE_DEPOSIT_MINT', 'Tokenised Deposit', tokenAmount, 'SUCCESS', 'LOW');

    return { success: true, message: `Minted ${formatAUD(tokenAmount)} Tokenised Deposit for ${holderName}` };
  }, [institutions, addAuditEvent]);

  const redeemTokenisedDeposit = useCallback((depositId: string) => {
    const dep = tokenisedDeposits.find(d => d.id === depositId);
    if (!dep) return { success: false, message: 'Tokenised deposit not found' };

    setTokenisedDeposits(prev => prev.map(d => d.id === depositId ? { ...d, redemptionStatus: 'REDEEMED', settlementStatus: 'SETTLED' } : d));

    setInstitutions(prev => prev.map(i => {
      if (i.id === dep.issuerId) {
        return {
          ...i,
          tokenisedDepositBalance: Math.max(0, i.tokenisedDepositBalance - dep.tokenAmount),
          commercialBankBalance: i.commercialBankBalance + dep.tokenAmount,
        };
      }
      return i;
    }));

    addAuditEvent(dep.issuerId, 'TOKENISE_DEPOSIT_REDEMPTION', 'Tokenised Deposit', dep.tokenAmount, 'SUCCESS', 'INFORMATIONAL');
    return { success: true, message: `Redeemed Tokenised Deposit ${dep.id} back into Commercial Bank Deposit` };
  }, [tokenisedDeposits, addAuditEvent]);

  // 5. Delivery-versus-Payment (DvP) Atomic Settlement Engine
  const executeDvPSettlement = useCallback((
    assetId: string,
    sellerId: InstitutionId,
    buyerId: InstitutionId,
    paymentAmount: number
  ) => {
    const asset = tokenisedAssets.find(a => a.id === assetId);
    const seller = institutions.find(i => i.id === sellerId);
    const buyer = institutions.find(i => i.id === buyerId);

    if (!asset || !seller || !buyer) return { success: false, message: 'Invalid asset or counterparty details' };

    if (buyer.digitalAudBalance < paymentAmount) {
      return { success: false, message: `Buyer ${buyer.name} has insufficient Digital AUD balance (${formatAUD(buyer.digitalAudBalance)})` };
    }

    // Atomic Swap: Transfer Digital AUD buyer -> seller, Transfer asset owner seller -> buyer
    setInstitutions(prev => prev.map(i => {
      if (i.id === buyerId) {
        return {
          ...i,
          digitalAudBalance: i.digitalAudBalance - paymentAmount,
          tokenisedAssetValue: i.tokenisedAssetValue + paymentAmount,
        };
      }
      if (i.id === sellerId) {
        return {
          ...i,
          digitalAudBalance: i.digitalAudBalance + paymentAmount,
          tokenisedAssetValue: Math.max(0, i.tokenisedAssetValue - paymentAmount),
        };
      }
      return i;
    }));

    // Transfer Asset Ownership in Registry
    setTokenisedAssets(prev => prev.map(a => {
      if (a.id === assetId) {
        return {
          ...a,
          ownerId: buyerId,
          ownerName: buyer.name,
          status: 'FREE',
        };
      }
      return a;
    }));

    const dvpRecord: DvPSettlement = {
      id: `DVP-2026-${Math.floor(Math.random() * 899) + 100}`,
      tradeReference: `ASX-DVP-${Math.floor(Math.random() * 89999) + 10000}`,
      assetId: asset.id,
      assetName: asset.name,
      sellerId,
      sellerName: seller.name,
      buyerId,
      buyerName: buyer.name,
      assetQuantity: asset.quantity,
      paymentAmount,
      status: 'SETTLED',
      executionTime: formatAUDate(),
    };

    setDvpSettlements(prev => [dvpRecord, ...prev]);

    // Record DvP transaction
    const tx: Transaction = {
      id: `DA-DVP-${Math.floor(Math.random() * 8999) + 1000}`,
      ledgerId: `LEDGER-AU-DVP-${Date.now().toString().slice(-6)}`,
      timestamp: formatAUDate(),
      originId: buyerId,
      originName: buyer.name,
      destinationId: sellerId,
      destinationName: seller.name,
      amount: paymentAmount,
      moneyType: 'CENTRAL_BANK_CBDC',
      assetReference: asset.assetCode,
      channel: 'DVP_SETTLEMENT',
      purpose: `Atomic DvP Settlement: ${asset.name}`,
      status: 'COMPLETED',
      latencyMs: 9,
    };

    setTransactions(prev => [tx, ...prev]);
    addAuditEvent(buyer.name, 'ATOMIC_DVP_SETTLEMENT', asset.assetCode, paymentAmount, 'SUCCESS', 'INFORMATIONAL');

    return { success: true, message: `Atomic DvP Settlement executed! Asset ${asset.assetCode} transferred to ${buyer.name} for ${formatAUD(paymentAmount)} Digital AUD.` };
  }, [tokenisedAssets, institutions, addAuditEvent]);

  // 6. Retail Consumer Payment Simulator
  const executeRetailPayment = useCallback((
    merchantName: string,
    category: RetailTransaction['category'],
    amount: number,
    channel: RetailTransaction['channel']
  ) => {
    if (retailBalance < amount) {
      return { success: false, message: `Insufficient retail wallet balance (${formatAUD(retailBalance)})` };
    }

    setRetailBalance(prev => prev - amount);

    const newRetailTx: RetailTransaction = {
      id: `TX-RET-${Math.floor(Math.random() * 8999) + 1000}`,
      merchantName,
      category,
      amount,
      timestamp: formatAUDate(),
      status: 'COMPLETED',
      channel,
    };

    setRetailTransactions(prev => [newRetailTx, ...prev]);

    // Credit retail acquiring bank (Southern Cross Bank)
    setInstitutions(prev => prev.map(i => i.id === 'scb' ? { ...i, digitalAudBalance: i.digitalAudBalance + amount } : i));

    addAuditEvent('Retail Digital AUD Wallet', 'RETAIL_PAYMENT', 'Digital AUD', amount, 'SUCCESS', 'INFORMATIONAL');

    return { success: true, message: `Payment of ${formatAUD(amount)} to ${merchantName} completed successfully.` };
  }, [retailBalance, addAuditEvent]);

  // 7. Programmable Rules
  const addProgrammableRule = useCallback((rule: Omit<ProgrammableRule, 'id' | 'createdAt' | 'status'>) => {
    const newRule: ProgrammableRule = {
      ...rule,
      id: `PRG-${Math.floor(Math.random() * 89999) + 10000}`,
      status: 'WAITING_FOR_CONDITION',
      createdAt: formatAUDate(),
    };
    setProgrammableRules(prev => [newRule, ...prev]);
    addAuditEvent(rule.payerName, 'PROGRAMMABLE_RULE_CREATED', 'Smart Contract', rule.amount, 'SUCCESS', 'LOW');
  }, [addAuditEvent]);

  const triggerProgrammableRule = useCallback((ruleId: string) => {
    const rule = programmableRules.find(r => r.id === ruleId);
    if (!rule) return { success: false, message: 'Programmable rule not found' };

    // Execute transfer
    const res = executeWholesaleTransfer(rule.payerId, rule.recipientId, rule.amount, `Programmable Execution: ${rule.title}`);
    if (res.success) {
      setProgrammableRules(prev => prev.map(r => r.id === ruleId ? { ...r, status: 'EXECUTED' } : r));
      addAuditEvent(rule.payerName, 'PROGRAMMABLE_RULE_EXECUTED', 'Digital AUD', rule.amount, 'SUCCESS', 'INFORMATIONAL');
      return { success: true, message: `Programmable Rule '${rule.title}' triggered and settled ${formatAUD(rule.amount)}!` };
    }
    return res;
  }, [programmableRules, executeWholesaleTransfer, addAuditEvent]);

  // 8. Cross Border Settlement Simulator
  const executeCrossBorderFx = useCallback((
    corridor: 'AUD/USD' | 'AUD/EUR' | 'AUD/JPY' | 'AUD/SGD',
    originInstitution: string,
    foreignInstitution: string,
    audAmount: number
  ) => {
    const rates = {
      'AUD/USD': 0.6650,
      'AUD/EUR': 0.6100,
      'AUD/JPY': 98.40,
      'AUD/SGD': 0.8700,
    };
    const foreignCurrencies: Record<string, 'USD' | 'EUR' | 'JPY' | 'SGD'> = {
      'AUD/USD': 'USD',
      'AUD/EUR': 'EUR',
      'AUD/JPY': 'JPY',
      'AUD/SGD': 'SGD',
    };

    const fxRate = rates[corridor];
    const foreignAmount = audAmount * fxRate;

    const newTransfer: CrossBorderTransfer = {
      id: `XB-${Math.floor(Math.random() * 89999) + 10000}`,
      corridor,
      originInstitution,
      foreignInstitution,
      audAmount,
      foreignAmount,
      fxRate,
      foreignCurrency: foreignCurrencies[corridor],
      settlementAsset: 'DIGITAL_AUD_PvP',
      status: 'SETTLED',
      timestamp: formatAUDate(),
    };

    setCrossBorderTransfers(prev => [newTransfer, ...prev]);
    addAuditEvent(originInstitution, 'CROSS_BORDER_PVP_SETTLEMENT', corridor, audAmount, 'SUCCESS', 'LOW');

    return { success: true, message: `Atomic Payment-versus-Payment (PvP) settled: ${formatAUD(audAmount)} exchanged for ${foreignCurrencies[corridor]} ${foreignAmount.toLocaleString('en-AU', { maximumFractionDigits: 2 })}` };
  }, [addAuditEvent]);

  // 9. Risk Alert Resolution
  const resolveRiskAlert = useCallback((alertId: string, action: 'DISMISS' | 'FREEZE_FUNDS') => {
    setRiskAlerts(prev => prev.map(alert => alert.id === alertId ? { ...alert, status: action === 'FREEZE_FUNDS' ? 'FROZEN' : 'RESOLVED' } : alert));
    addAuditEvent('RISK_ENGINE', action === 'FREEZE_FUNDS' ? 'FREEZE_INSTITUTIONAL_ACCOUNT' : 'RISK_ALERT_RESOLVED', 'Risk Controls', 0, 'SUCCESS', 'MEDIUM');
  }, [addAuditEvent]);

  // Reset
  const resetSimulation = useCallback(() => {
    setInstitutions(INITIAL_INSTITUTIONS);
    setTokenisedDeposits(INITIAL_TOKENISED_DEPOSITS);
    setTokenisedAssets(INITIAL_TOKENISED_ASSETS);
    setTransactions(INITIAL_TRANSACTIONS);
    setDvpSettlements(INITIAL_DVP_SETTLEMENTS);
    setProgrammableRules(INITIAL_PROGRAMMABLE_RULES);
    setCrossBorderTransfers(INITIAL_CROSS_BORDER_TRANSFERS);
    setRiskAlerts(INITIAL_RISK_ALERTS);
    setAuditEvents(INITIAL_AUDIT_EVENTS);
    setSystemMetrics(INITIAL_SYSTEM_METRICS);
    setRetailTransactions(INITIAL_RETAIL_TRANSACTIONS);
    setRetailBalance(4820.50);
  }, []);

  // Background Simulation Tick (Heartbeat loop)
  useEffect(() => {
    if (isPaused) return;

    const intervalTime = Math.max(100, Math.floor(3000 / speedMultiplier));

    const timer = setInterval(() => {
      // Slightly fluctuate system metrics for realistic live telemetric display
      setSystemMetrics(prev => ({
        ...prev,
        cpuUsage: Math.min(95, Math.max(15, prev.cpuUsage + (Math.random() * 4 - 2))),
        memoryUsage: Math.min(85, Math.max(30, prev.memoryUsage + (Math.random() * 2 - 1))),
        ledgerTPS: Math.floor(4000 + Math.random() * 800),
        settlementEngineLatency: Number((8 + Math.random() * 6).toFixed(1)),
      }));

      // Occasionally generate a random interbank micro-settlement
      if (Math.random() > 0.4) {
        const banks: InstitutionId[] = ['scb', 'cfs', 'pnb', 'scap', 'amb'];
        const originId = banks[Math.floor(Math.random() * banks.length)];
        let destId = banks[Math.floor(Math.random() * banks.length)];
        while (destId === originId) destId = banks[Math.floor(Math.random() * banks.length)];

        const originInst = institutions.find(i => i.id === originId);
        const destInst = institutions.find(i => i.id === destId);

        if (originInst && destInst) {
          const simAmount = Math.floor((Math.random() * 50 + 5) * 100000); // A$500k - A$5.5M
          if (originInst.digitalAudBalance > simAmount) {
            setInstitutions(prev => prev.map(inst => {
              if (inst.id === originId) return { ...inst, digitalAudBalance: inst.digitalAudBalance - simAmount };
              if (inst.id === destId) return { ...inst, digitalAudBalance: inst.digitalAudBalance + simAmount };
              return inst;
            }));

            const autoTx: Transaction = {
              id: `DA-AUTO-${Math.floor(Math.random() * 89999) + 10000}`,
              ledgerId: `LEDGER-AU-${Date.now().toString().slice(-6)}`,
              timestamp: formatAUDate(),
              originId,
              originName: originInst.name,
              destinationId: destId,
              destinationName: destInst.name,
              amount: simAmount,
              moneyType: 'CENTRAL_BANK_CBDC',
              channel: 'WHOLESALE_CBDC',
              purpose: 'Automated Interbank Liquidity Balancing',
              status: 'COMPLETED',
              latencyMs: Math.floor(Math.random() * 10) + 5,
            };

            setTransactions(prev => [autoTx, ...prev.slice(0, 40)]);
          }
        }
      }
    }, intervalTime);

    return () => clearInterval(timer);
  }, [isPaused, speedMultiplier, institutions]);

  const updateRiskAlertStatus = useCallback((alertId: string, status: RiskAlert['status']) => {
    setRiskAlerts(prev => prev.map(a => a.id === alertId ? { ...a, status } : a));
  }, []);

  const verifyTransactionHash = useCallback((txId: string) => {
    return `RBA-PROOF-HASH-${txId}-${Math.floor(Math.random() * 89999) + 10000}-Dilithium5-VALID`;
  }, []);

  const triggerLiquidityFluctuation = useCallback(() => {
    setInstitutions(prev => prev.map(inst => {
      const delta = (Math.random() - 0.48) * 10000000;
      return {
        ...inst,
        digitalAudBalance: Math.max(100000000, inst.digitalAudBalance + delta),
      };
    }));
  }, []);

  return (
    <SimulationContext.Provider
      value={{
        institutions,
        tokenisedDeposits,
        tokenisedAssets,
        transactions,
        dvpSettlements,
        programmableRules,
        crossBorderTransfers,
        riskAlerts,
        auditEvents,
        systemMetrics,
        retailTransactions,
        retailBalance,
        digitalAudTotalOutstanding,
        wholesaleSettlementToday,
        transactionsTodayCount,

        isPaused,
        speedMultiplier,
        togglePause,
        setSpeedMultiplier,
        resetSimulation,

        issueDigitalAUD,
        redeemDigitalAUD,
        executeWholesaleTransfer,
        mintTokenisedDeposit,
        redeemTokenisedDeposit,
        executeDvPSettlement,
        executeRetailPayment,
        addProgrammableRule,
        triggerProgrammableRule,
        executeCrossBorderFx,
        resolveRiskAlert,
        updateRiskAlertStatus,
        verifyTransactionHash,
        triggerLiquidityFluctuation,
      }}
    >
      {children}
    </SimulationContext.Provider>
  );
};

export const useSimulation = () => {
  const context = useContext(SimulationContext);
  if (!context) throw new Error('useSimulation must be used within a SimulationProvider');
  return context;
};
