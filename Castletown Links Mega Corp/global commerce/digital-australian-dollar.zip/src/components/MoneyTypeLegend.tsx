/**
 * Core Distinction Visualizer Legend Component
 * CENTRAL BANK MONEY vs COMMERCIAL BANK MONEY vs TOKENISED DEPOSITS vs TOKENISED ASSETS
 */

import React from 'react';
import { Landmark, Building2, Coins, LandmarkIcon } from 'lucide-react';

export const MoneyTypeLegend: React.FC = () => {
  return (
    <div className="bg-white border border-[#e2e8f0] rounded-xl p-4 shadow-xs mb-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3 mb-3">
        <div>
          <h3 className="text-xs font-bold uppercase tracking-wider text-[#4a5568]">
            AUSTRALIAN MONETARY ARCHITECTURE — FORMAL DISTINCTION LAYER
          </h3>
          <p className="text-xs text-slate-500">
            Explicit segregation of sovereign liabilities vs commercial claims vs tokenised instruments.
          </p>
        </div>
        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-[#2e5a44]/10 text-[#2e5a44] border border-[#2e5a44]/20 w-fit">
          <span className="w-1.5 h-1.5 rounded-full bg-[#2e5a44] animate-pulse"></span>
          RESERVE BANK SETTLEMENT CORE
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
        {/* 1. Central Bank Money */}
        <div className="p-3 rounded-lg bg-[#f0f7f3] border border-[#2e5a44]/30 relative overflow-hidden group">
          <div className="flex items-center gap-2 mb-1">
            <div className="p-1.5 rounded bg-[#2e5a44] text-white">
              <Landmark className="w-4 h-4" />
            </div>
            <span className="text-xs font-bold text-[#1e232a]">CENTRAL BANK MONEY</span>
          </div>
          <p className="text-[11px] text-[#2e5a44] font-semibold">Wholesale & Retail Digital AUD</p>
          <p className="text-[10px] text-slate-600 mt-1 leading-snug">
            Sovereign liability of the Reserve Bank of Australia. Zero credit & liquidity risk.
          </p>
        </div>

        {/* 2. Commercial Bank Money */}
        <div className="p-3 rounded-lg bg-[#f0f4f8] border border-[#0a192f]/20">
          <div className="flex items-center gap-2 mb-1">
            <div className="p-1.5 rounded bg-[#0a192f] text-white">
              <Building2 className="w-4 h-4" />
            </div>
            <span className="text-xs font-bold text-[#1e232a]">COMMERCIAL BANK MONEY</span>
          </div>
          <p className="text-[11px] text-[#0a192f] font-semibold">ADI Ledger Deposits</p>
          <p className="text-[10px] text-slate-600 mt-1 leading-snug">
            Liability of authorized deposit-taking institutions (ADIs). Covered by FCS guarantees up to cap.
          </p>
        </div>

        {/* 3. Tokenised Deposits */}
        <div className="p-3 rounded-lg bg-[#fef6f0] border border-[#b85c18]/30">
          <div className="flex items-center gap-2 mb-1">
            <div className="p-1.5 rounded bg-[#b85c18] text-white">
              <Coins className="w-4 h-4" />
            </div>
            <span className="text-xs font-bold text-[#1e232a]">TOKENISED DEPOSITS</span>
          </div>
          <p className="text-[11px] text-[#b85c18] font-semibold">Programmable ADI Tokens</p>
          <p className="text-[10px] text-slate-600 mt-1 leading-snug">
            Programmable claims on commercial deposits for intraday, 24/7 corporate smart-contract execution.
          </p>
        </div>

        {/* 4. Tokenised Assets */}
        <div className="p-3 rounded-lg bg-[#f8fafc] border border-slate-300">
          <div className="flex items-center gap-2 mb-1">
            <div className="p-1.5 rounded bg-[#4a5568] text-white">
              <LandmarkIcon className="w-4 h-4" />
            </div>
            <span className="text-xs font-bold text-[#1e232a]">TOKENISED ASSETS</span>
          </div>
          <p className="text-[11px] text-[#4a5568] font-semibold">Govt Bonds & Securities</p>
          <p className="text-[10px] text-slate-600 mt-1 leading-snug">
            Dematerialised financial securities settled atomically Delivery-versus-Payment (DvP) in Digital AUD.
          </p>
        </div>
      </div>
    </div>
  );
};
