/**
 * Permanent Enterprise Navigation Rail
 * DIGITAL AUSTRALIAN DOLLAR Infrastructure
 */

import React from 'react';
import { ViewMode } from '../types';
import {
  LayoutDashboard,
  Coins,
  Building2,
  Wallet,
  Landmark,
  Building,
  CreditCard,
  Zap,
  TrendingUp,
  Code2,
  Globe,
  Droplets,
  ShieldCheck,
  Layers,
  Briefcase,
  FileCheck2,
  Activity,
  Microscope,
  ChevronRight
} from 'lucide-react';

interface NavigationRailProps {
  currentView: ViewMode;
  onSelectView: (view: ViewMode) => void;
}

interface NavItem {
  id: ViewMode;
  label: string;
  icon: React.FC<{ className?: string }>;
  group: 'CORE' | 'PAYMENTS_ASSETS' | 'OPERATIONS';
}

const NAV_ITEMS: NavItem[] = [
  // CORE
  { id: 'national-overview', label: 'National Overview', icon: LayoutDashboard, group: 'CORE' },
  { id: 'digital-aud-issuance', label: 'Digital AUD', icon: Coins, group: 'CORE' },
  { id: 'wholesale-cbdc', label: 'Wholesale CBDC', icon: Building2, group: 'CORE' },
  { id: 'retail-cbdc', label: 'Retail CBDC', icon: Wallet, group: 'CORE' },
  { id: 'tokenised-deposits', label: 'Tokenised Deposits', icon: Landmark, group: 'CORE' },
  { id: 'banks-institutions', label: 'Banks & Institutions', icon: Building, group: 'CORE' },

  // PAYMENTS & ASSETS
  { id: 'payments-infrastructure', label: 'Payments', icon: CreditCard, group: 'PAYMENTS_ASSETS' },
  { id: 'settlement', label: 'Settlement', icon: Zap, group: 'PAYMENTS_ASSETS' },
  { id: 'tokenised-assets', label: 'Tokenised Assets', icon: TrendingUp, group: 'PAYMENTS_ASSETS' },
  { id: 'programmable-money', label: 'Programmable Money', icon: Code2, group: 'PAYMENTS_ASSETS' },
  { id: 'cross-border', label: 'Cross-Border', icon: Globe, group: 'PAYMENTS_ASSETS' },

  // OPERATIONS & GOVERNANCE
  { id: 'liquidity-management', label: 'Liquidity', icon: Droplets, group: 'OPERATIONS' },
  { id: 'risk-compliance', label: 'Risk & Compliance', icon: ShieldCheck, group: 'OPERATIONS' },
  { id: 'market-infrastructure', label: 'Market Infrastructure', icon: Layers, group: 'OPERATIONS' },
  { id: 'corporate-treasury', label: 'Corporate Treasury', icon: Briefcase, group: 'OPERATIONS' },
  { id: 'audit-trail', label: 'Audit', icon: FileCheck2, group: 'OPERATIONS' },
  { id: 'system-operations', label: 'System Operations', icon: Activity, group: 'OPERATIONS' },
  { id: 'research-lab', label: 'Research Lab', icon: Microscope, group: 'OPERATIONS' },
];

export const NavigationRail: React.FC<NavigationRailProps> = ({ currentView, onSelectView }) => {
  const renderGroup = (groupName: 'CORE' | 'PAYMENTS_ASSETS' | 'OPERATIONS', title: string) => {
    const items = NAV_ITEMS.filter(item => item.group === groupName);

    return (
      <div className="mb-4">
        <h2 className="px-3 text-[10px] font-extrabold uppercase tracking-widest text-[#8492a6] mb-1">
          {title}
        </h2>
        <nav className="space-y-0.5">
          {items.map(item => {
            const Icon = item.icon;
            const isActive = currentView === item.id;

            return (
              <button
                key={item.id}
                onClick={() => onSelectView(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-semibold transition-all group ${
                  isActive
                    ? 'bg-[#2e5a44] text-white shadow-xs'
                    : 'text-slate-300 hover:bg-[#18283e] hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2.5 truncate">
                  <Icon
                    className={`w-4 h-4 shrink-0 transition-colors ${
                      isActive ? 'text-emerald-300' : 'text-slate-400 group-hover:text-slate-200'
                    }`}
                  />
                  <span className="truncate">{item.label}</span>
                </div>
                {isActive && <ChevronRight className="w-3.5 h-3.5 text-emerald-300 shrink-0" />}
              </button>
            );
          })}
        </nav>
      </div>
    );
  };

  return (
    <aside className="w-64 bg-[#0a192f] text-slate-200 flex flex-col shrink-0 border-r border-[#1e2e42] min-h-[calc(100vh-100px)] p-3">
      {/* Search / Filter Quick Switcher */}
      <div className="mb-4 px-1">
        <div className="text-[10px] font-bold text-emerald-400/90 tracking-wide uppercase mb-1">
          RESERVE BANK ARCHITECTURE
        </div>
        <div className="text-xs text-slate-400 font-mono bg-[#122238] p-2 rounded border border-[#1e3048]">
          LEDGER: <span className="text-white font-semibold">DAUD-SYS-01</span>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto pr-1 custom-scrollbar space-y-2">
        {renderGroup('CORE', 'Core Money Infrastructure')}
        {renderGroup('PAYMENTS_ASSETS', 'Markets & Settlement')}
        {renderGroup('OPERATIONS', 'Operations & Risk')}
      </div>

      {/* Footer info box */}
      <div className="mt-4 p-2.5 rounded bg-[#122238] border border-[#1e3048] text-[10px] text-slate-400">
        <div className="font-bold text-slate-200 uppercase mb-0.5">RBA CBDC RESEARCH</div>
        <p className="leading-tight text-slate-400">
          Synthetic institutional digital AUD simulation environment.
        </p>
      </div>
    </aside>
  );
};
