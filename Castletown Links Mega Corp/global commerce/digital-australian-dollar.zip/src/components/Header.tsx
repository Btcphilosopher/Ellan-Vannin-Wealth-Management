/**
 * Enterprise Header Component
 * DIGITAL AUSTRALIAN DOLLAR
 */

import React from 'react';
import { ShieldAlert, Play, Pause, RotateCcw, Activity, Server } from 'lucide-react';
import { useSimulation } from '../simulation/simulationEngine';

export const Header: React.FC = () => {
  const {
    isPaused,
    speedMultiplier,
    togglePause,
    setSpeedMultiplier,
    resetSimulation
  } = useSimulation();

  return (
    <header className="bg-[#0f1c2e] text-white border-b border-[#1e2e42] sticky top-0 z-40 shadow-sm">
      {/* Top Disclaimer Banner */}
      <div className="bg-[#18283e] border-b border-[#243852] px-4 py-1 flex items-center justify-between text-[11px] tracking-wide text-slate-300">
        <div className="flex items-center gap-2">
          <span className="px-1.5 py-0.5 rounded bg-[#b85c18] text-white font-bold text-[10px] uppercase tracking-wider">
            RESEARCH PROTOTYPE
          </span>
          <span className="font-semibold text-amber-200/90 flex items-center gap-1">
            <ShieldAlert className="w-3.5 h-3.5 text-amber-400 inline" />
            SIMULATION ENVIRONMENT · SYNTHETIC DATA ONLY
          </span>
          <span className="hidden lg:inline text-slate-400">| Fictional research environment — Not a live Reserve Bank system</span>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-slate-300 font-mono">Currency: AUD (A$)</span>
          <span className="text-emerald-400 font-medium hidden sm:inline">AEST 14:42:08</span>
        </div>
      </div>

      {/* Main Header Bar */}
      <div className="px-4 py-3.5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Title Block */}
        <div className="flex items-center gap-3">
          {/* Emblem / Badge */}
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#2e5a44] to-[#1e3e2e] border border-emerald-500/30 flex items-center justify-center font-bold text-lg text-emerald-100 shadow-inner">
            A$
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-extrabold tracking-tight text-white leading-none">
                DIGITAL AUSTRALIAN DOLLAR
              </h1>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800/50 uppercase font-bold">
                DIGITAL AUD
              </span>
            </div>
            <p className="text-xs text-slate-300 font-medium mt-0.5">
              Australian CBDC & Digital Money Infrastructure
            </p>
            <p className="text-[11px] text-slate-400 hidden xl:block">
              Wholesale Settlement · Digital Money · Tokenised Assets · Payments
            </p>
          </div>
        </div>

        {/* Status, Simulation Controls & Telemetry */}
        <div className="flex items-center justify-between md:justify-end gap-3 flex-wrap">
          {/* Simulation Time Speed Controller */}
          <div className="flex items-center bg-[#18283e] border border-[#2c405c] rounded-lg p-1 text-xs">
            <button
              onClick={togglePause}
              className={`px-2 py-1 rounded flex items-center gap-1 font-medium transition ${
                isPaused ? 'bg-amber-600 text-white' : 'bg-[#243852] text-slate-200 hover:text-white'
              }`}
              title={isPaused ? 'Resume Simulation' : 'Pause Simulation'}
            >
              {isPaused ? <Play className="w-3.5 h-3.5 fill-current" /> : <Pause className="w-3.5 h-3.5 fill-current" />}
              <span className="text-[11px] font-mono">{isPaused ? 'PAUSED' : 'RUNNING'}</span>
            </button>

            <div className="h-4 w-[1px] bg-slate-700 mx-1"></div>

            {[1, 10, 100].map(multiplier => (
              <button
                key={multiplier}
                onClick={() => setSpeedMultiplier(multiplier)}
                className={`px-2 py-0.5 rounded font-mono text-[11px] transition ${
                  speedMultiplier === multiplier
                    ? 'bg-[#2e5a44] text-white font-bold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                ×{multiplier}
              </button>
            ))}

            <button
              onClick={resetSimulation}
              className="ml-1 p-1 text-slate-400 hover:text-amber-300 transition"
              title="Reset Simulation State"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* System Operational Badge */}
          <div className="flex flex-col items-end text-right">
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-emerald-950/80 border border-emerald-800/60 text-emerald-400 text-xs font-semibold">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span>SYSTEM OPERATIONAL</span>
            </div>
            <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-1 font-mono">
              <span className="flex items-center gap-1"><Server className="w-3 h-3 text-slate-500" /> RES-AU-99</span>
              <span>•</span>
              <span className="text-slate-300">SYNTHETIC DATA</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
