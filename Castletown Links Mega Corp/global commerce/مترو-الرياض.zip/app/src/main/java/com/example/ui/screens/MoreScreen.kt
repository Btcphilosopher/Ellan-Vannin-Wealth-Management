package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.models.Artwork
import com.example.domain.models.DemoAlert
import com.example.domain.models.MetroLine
import com.example.domain.models.MetroStation
import com.example.ui.theme.LuxuryGold
import com.example.ui.theme.MetroBlue
import com.example.ui.theme.RiyadhCharcoal
import com.example.ui.viewmodel.MetroViewModel

@Composable
fun MoreScreen(viewModel: MetroViewModel) {
    var activeSubSection by remember { mutableStateOf<String?>("stations") } // stations, lines, favorites, history, art, alerts, settings

    Box(
        modifier = Modifier
            .fillMaxSize()
            .testTag("more_screen_root")
            .background(MaterialTheme.colorScheme.background)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(top = 24.dp, bottom = 120.dp, start = 20.dp, end = 20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header
            item {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "المزيد من الخدمات",
                        style = MaterialTheme.typography.headlineLarge,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "استكشف خدمات ومرافق المحطات، شبكة الخطوط، الأعمال الفنية، والتنبيهات التشغيلية",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                    )
                }
            }

            // Quick expandable hubs cards
            val hubs = listOf(
                "stations" to Pair("دليل ومرافق المحطات", Icons.Default.Storefront),
                "lines" to Pair("شبكة الخطوط الستة", Icons.Default.Route),
                "favorites" to Pair("المحطات والوجهات المفضلة", Icons.Default.Favorite),
                "history" to Pair("سجل الرحلات السابقة", Icons.Default.History),
                "art" to Pair("برنامج فنون قطار الرياض", Icons.Default.Palette),
                "alerts" to Pair("مركز التنبيهات التشغيلية", Icons.Default.Notifications),
                "settings" to Pair("الإعدادات ومعلومات التطبيق", Icons.Default.Settings)
            )

            hubs.forEach { (key, info) ->
                val (label, icon) = info
                val isExpanded = activeSubSection == key

                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                width = if (isExpanded) 1.5.dp else 1.dp,
                                color = if (isExpanded) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(
                                    alpha = 0.08f
                                ),
                                shape = RoundedCornerShape(12.dp)
                            ),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isExpanded) MaterialTheme.colorScheme.primary.copy(alpha = 0.01f) else MaterialTheme.colorScheme.surface
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            // Expandable Header Row
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { activeSubSection = if (isExpanded) null else key }
                                    .padding(18.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = null,
                                        tint = if (isExpanded) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(
                                            alpha = 0.6f
                                        ),
                                        modifier = Modifier.size(22.dp)
                                    )
                                    Spacer(modifier = Modifier.width(14.dp))
                                    Text(
                                        text = label,
                                        style = MaterialTheme.typography.bodyLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isExpanded) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                    )
                                }

                                Icon(
                                    imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }

                            // Dynamic Expanded Area
                            AnimatedVisibility(
                                visible = isExpanded,
                                enter = expandVertically(),
                                exit = shrinkVertically()
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.4f))
                                        .padding(horizontal = 18.dp, vertical = 14.dp)
                                ) {
                                    HorizontalDivider(
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f),
                                        modifier = Modifier.padding(bottom = 12.dp)
                                    )

                                    when (key) {
                                        "stations" -> StationsSubSection(viewModel = viewModel)
                                        "lines" -> LinesSubSection(viewModel = viewModel)
                                        "favorites" -> FavoritesSubSection(viewModel = viewModel)
                                        "history" -> HistorySubSection(viewModel = viewModel)
                                        "art" -> ArtSubSection(viewModel = viewModel)
                                        "alerts" -> AlertsSubSection(viewModel = viewModel)
                                        "settings" -> SettingsSubSection(viewModel = viewModel)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 1. STATIONS SUB SECTION
@Composable
fun StationsSubSection(viewModel: MetroViewModel) {
    val stations = viewModel.getStations()
    val lines = viewModel.getLines()

    var expandedStationId by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        stations.forEach { station ->
            val isStationExpanded = expandedStationId == station.id
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expandedStationId = if (isStationExpanded) null else station.id },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = station.nameArabic,
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.Bold
                                )
                                if (station.interchange) {
                                    Box(
                                        modifier = Modifier
                                            .padding(start = 6.dp)
                                            .background(LuxuryGold.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "تحويل",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontSize = 9.sp,
                                            color = MaterialTheme.colorScheme.primary,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                            Text(
                                text = "الرمز الكودي: ${station.code ?: "--"}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                            )
                        }

                        // Colored lines circles
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            station.lines.forEach { lineId ->
                                val line = lines.find { it.id == lineId }
                                if (line != null) {
                                    val cl = Color(android.graphics.Color.parseColor(line.color))
                                    Box(
                                        modifier = Modifier
                                            .size(24.dp)
                                            .background(cl, CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = line.number,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = if (lineId == "yellow") Color.Black else Color.White
                                        )
                                    }
                                }
                            }
                        }
                    }

                    AnimatedVisibility(visible = isStationExpanded) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 12.dp)
                        ) {
                            HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = "مرافق الرصيف والمحطة المتاحة:",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(6.dp))

                            val facMapping = mapOf(
                                "parking" to "مواقف مجانية واسعة للسيارات",
                                "elevator" to "مصاعد كهربائية بانورامية",
                                "escalator" to "سلالم متحركة حديثة ومبردة",
                                "toilet" to "دورات مياه مخصصة ومكيفة",
                                "wifi" to "شبكة واي فاي مجانية فائقة السرعة",
                                "accessibility" to "تسهيلات متكاملة وممرات للكراسي المتحركة",
                                "shops" to "محلات تجارية ومقاهي ومطاعم",
                                "luggage" to "تسهيلات وأحزمة مخصصة للحقائب والأمتعة"
                            )

                            station.facilities.forEach { key ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(vertical = 2.dp)
                                ) {
                                    Box(modifier = Modifier.size(6.dp).background(LuxuryGold, CircleShape))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = facMapping[key] ?: key,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Button(
                                onClick = {
                                    viewModel.selectedStationDetails = station
                                    viewModel.selectedTab = "map"
                                },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(6.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                            ) {
                                Text("استعراض وتحديد على الخريطة")
                            }
                        }
                    }
                }
            }
        }
    }
}

// 2. LINES SUB SECTION
@Composable
fun LinesSubSection(viewModel: MetroViewModel) {
    val lines = viewModel.getLines()
    val stations = viewModel.getStations()

    // Sequences mapping
    val lineSequences = mapOf(
        "blue" to listOf("kafd", "olaya", "moi", "qasr_al_hukm", "batha"),
        "red" to listOf("ksu", "olaya", "exhibition"),
        "orange" to listOf("west_riyadh", "qasr_al_hukm", "east_riyadh"),
        "yellow" to listOf("kafd", "pnu", "kkia"),
        "green" to listOf("moi", "finance", "national_museum"),
        "purple" to listOf("kafd", "pnu", "yarmouk")
    )

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        lines.forEach { line ->
            val cl = Color(android.graphics.Color.parseColor(line.color))
            val seq = lineSequences[line.id] ?: emptyList()

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, cl.copy(alpha = 0.25f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .background(cl, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = line.number,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (line.id == "yellow") Color.Black else Color.White
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = line.name,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = cl
                            )
                        }

                        Text(
                            text = line.code,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "المسار: ${line.route}  •  زمن الرحلة التقريبي: ${line.durationMinutes} دقيقة",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "محطات الخط بالترتيب:",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // horizontal scroll or flow row of stations in Arabic
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        seq.forEachIndexed { idx, stId ->
                            val stName = stations.find { it.id == stId }?.nameArabic ?: stId
                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.background
                                ),
                                shape = RoundedCornerShape(6.dp),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f))
                            ) {
                                Text(
                                    text = stName,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                                )
                            }

                            if (idx < seq.size - 1) {
                                Icon(
                                    imageVector = Icons.Default.ArrowLeft,
                                    contentDescription = null,
                                    tint = cl,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// 3. FAVORITES SUB SECTION
@Composable
fun FavoritesSubSection(viewModel: MetroViewModel) {
    val favorites by viewModel.favorites.collectAsState()
    val stations = viewModel.getStations()

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (favorites.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 30.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "لم تقم بإضافة أي محطات مفضلة حالياً.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                )
            }
        } else {
            favorites.forEach { fav ->
                val station = stations.find { it.id == fav.stationId }
                if (station != null) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .background(
                                            color = if (fav.isHome) Color(0xFF12B76A).copy(alpha = 0.15f) else if (fav.isWork) LuxuryGold.copy(alpha = 0.15f) else MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                                            shape = CircleShape
                                        )
                                        .padding(8.dp)
                                ) {
                                    Icon(
                                        imageVector = if (fav.isHome) Icons.Default.Home else if (fav.isWork) Icons.Default.Work else Icons.Default.Star,
                                        contentDescription = null,
                                        tint = if (fav.isHome) Color(0xFF12B76A) else if (fav.isWork) DeepDesertGreen else MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = station.nameArabic,
                                        style = MaterialTheme.typography.bodyLarge,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = fav.labelArabic,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                                    )
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                TextButton(
                                    onClick = {
                                        viewModel.searchFromStation = station
                                        viewModel.selectedTab = "home"
                                    }
                                ) {
                                    Text("تحديد كموقع انطلاق", fontSize = 12.sp)
                                }

                                IconButton(onClick = { viewModel.removeFavoriteStation(station.id) }) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "حذف",
                                        tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 4. HISTORY SUB SECTION
@Composable
fun HistorySubSection(viewModel: MetroViewModel) {
    val history by viewModel.journeyHistory.collectAsState()

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (history.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 30.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "سجل الرحلات فارغ حالياً.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                )
            }
        } else {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "الرحلات السابقة المخزنة بالشبكة:",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )
                TextButton(onClick = { viewModel.clearAllHistory() }) {
                    Text("حذف السجل بالكامل", color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
                }
            }

            history.forEach { item ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "${item.originName} ← ${item.destinationName}",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "المدة: ${item.durationMinutes} دقيقة  •  التحويلات: ${if (item.interchangeCount == 0) "مباشر" else "${item.interchangeCount} تحويل"}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                            )
                        }

                        IconButton(
                            onClick = {
                                val from = viewModel.getStations().find { it.id == item.originId }
                                val to = viewModel.getStations().find { it.id == item.destinationId }
                                if (from != null && to != null) {
                                    viewModel.searchFromStation = from
                                    viewModel.searchToStation = to
                                    viewModel.triggerRouteSearch()
                                    viewModel.selectedTab = "home"
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.DirectionsTransit,
                                contentDescription = "إعادة استخدام",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        }
    }
}

// 5. ART SUB SECTION (Sections 25 & 26)
@Composable
fun ArtSubSection(viewModel: MetroViewModel) {
    val artworks = viewModel.getArtworks()

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        artworks.forEach { art ->
            val stName = viewModel.getStationName(art.stationId)
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = art.titleArabic,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "بواسطة الفنان: ${art.artistArabic}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                            )
                        }

                        Box(
                            modifier = Modifier
                                .background(LuxuryGold.copy(alpha = 0.12f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = stName,
                                style = MaterialTheme.typography.labelSmall,
                                color = DeepDesertGreen,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = art.descriptionArabic,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f),
                        lineHeight = 20.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = null,
                            tint = LuxuryGold,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "الموقع داخل المحطة: ${art.locationArabic}",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = LuxuryGold
                        )
                    }
                }
            }
        }
    }
}

// 6. ALERTS SUB SECTION (Section 24)
@Composable
fun AlertsSubSection(viewModel: MetroViewModel) {
    val alerts = viewModel.getAlerts()

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (alerts.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 30.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "لا توجد أي تنبيهات أو إشعارات حالياً.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                )
            }
        } else {
            alerts.forEach { alert ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = if (alert.isCritical) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.1f) else MaterialTheme.colorScheme.primary.copy(
                            alpha = 0.03f
                        )
                    ),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(
                        width = 1.dp,
                        color = if (alert.isCritical) MaterialTheme.colorScheme.error.copy(alpha = 0.3f) else MaterialTheme.colorScheme.primary.copy(
                            alpha = 0.12f
                        )
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .background(
                                            if (alert.isCritical) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                                            CircleShape
                                        )
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = alert.titleArabic,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (alert.isCritical) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                                )
                            }

                            Text(
                                text = alert.dateArabic,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = alert.contentArabic,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                            lineHeight = 16.sp
                        )

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "مصدر التنبيه: ${alert.typeArabic} • بيانات محاكاة",
                            style = MaterialTheme.typography.labelSmall,
                            color = LuxuryGold,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

// 7. SETTINGS SUB SECTION (Section 42)
@Composable
fun SettingsSubSection(viewModel: MetroViewModel) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Offline Mode Switch (Section 38)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "الوضع التجريبي دون اتصال",
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "محاكاة توفر الوظائف الرئيسية دون إنترنت وتدفق البيانات الحية",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )
            }

            Switch(
                checked = viewModel.isOfflineMode,
                onCheckedChange = { viewModel.isOfflineMode = it },
                colors = SwitchDefaults.colors(checkedThumbColor = MaterialTheme.colorScheme.primary)
            )
        }

        HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))

        // Demo Disclaimer Card (Section 42 & 43)
        Card(
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.05f)
            ),
            shape = RoundedCornerShape(10.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Gavel,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "إشلاء مسؤولية وبيان مستقل:",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "هذا تطبيق نموذج تجريبي مستقل ترويجي مبني لأغراض التصميم والتطوير البرمجي وعرض الإمكانات الرقمية، وليس تطبيقاً رسمياً صادراً عن الهيئة الملكية لمدينة الرياض أو مشغلي مترو الرياض.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f),
                    lineHeight = 20.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "مصدر البيانات: معايير الهيئة الملكية لمدينة الرياض المفتوحة لبيانات شبكة النقل العام، تمت تهيئتها ودمجها برمجياً لضمان الدقة الجغرافية والمسارات الهندسية.",
                    style = MaterialTheme.typography.bodySmall,
                    color = LuxuryGold,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
