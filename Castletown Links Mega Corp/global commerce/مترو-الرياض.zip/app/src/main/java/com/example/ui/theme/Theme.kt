package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = SandAccent,
    onPrimary = RiyadhCharcoal,
    secondary = SandDark,
    onSecondary = Color.White,
    tertiary = LuxuryGold,
    background = RiyadhDarkBackground,
    onBackground = Color.White,
    surface = RiyadhDarkSurface,
    onSurface = Color.White,
    surfaceVariant = RiyadhDarkSurfaceVariant,
    onSurfaceVariant = Color.LightGray
)

private val LightColorScheme = lightColorScheme(
    primary = DeepDesertGreen,
    onPrimary = Color.White,
    secondary = SandAccent,
    onSecondary = RiyadhCharcoal,
    tertiary = LuxuryGold,
    background = WarmSandLight,
    onBackground = RiyadhCharcoal,
    surface = SoftCream,
    onSurface = RiyadhCharcoal,
    surfaceVariant = Color(0xFFECE5DD),
    onSurfaceVariant = RiyadhCharcoal
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    // Enforce our custom theme branding
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
