package com.example.data.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface MetroDao {

    // --- Tickets ---
    @Query("SELECT * FROM tickets ORDER BY purchaseTime DESC")
    fun getAllTicketsFlow(): Flow<List<TicketEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTicket(ticket: TicketEntity)

    @Query("UPDATE tickets SET status = :status WHERE id = :id")
    suspend fun updateTicketStatus(id: String, status: String)

    // --- Journey History ---
    @Query("SELECT * FROM journey_history ORDER BY timestamp DESC")
    fun getAllJourneysFlow(): Flow<List<JourneyHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJourney(journey: JourneyHistoryEntity)

    @Query("DELETE FROM journey_history")
    suspend fun clearAllJourneys()

    // --- Favorite Stations ---
    @Query("SELECT * FROM favorite_stations")
    fun getAllFavoritesFlow(): Flow<List<FavoriteStationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavorite(favorite: FavoriteStationEntity)

    @Query("DELETE FROM favorite_stations WHERE stationId = :stationId")
    suspend fun deleteFavorite(stationId: String)
}
