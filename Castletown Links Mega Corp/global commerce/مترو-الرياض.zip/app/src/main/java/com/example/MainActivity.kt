package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.DirectionsTransit
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.ViewModelProvider
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MapScreen
import com.example.ui.screens.MoreScreen
import com.example.ui.screens.TicketsScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.MetroViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel = ViewModelProvider(this)[MetroViewModel::class.java]

            MyApplicationTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Scaffold(
                        modifier = Modifier.fillMaxSize(),
                        bottomBar = {
                            NavigationBar {
                                NavigationBarItem(
                                    selected = viewModel.selectedTab == "home",
                                    onClick = { viewModel.selectedTab = "home" },
                                    icon = { Icon(Icons.Default.DirectionsTransit, contentDescription = "الرئيسية") },
                                    label = { Text("الرئيسية") }
                                )
                                NavigationBarItem(
                                    selected = viewModel.selectedTab == "map",
                                    onClick = { viewModel.selectedTab = "map" },
                                    icon = { Icon(Icons.Default.Map, contentDescription = "الخريطة") },
                                    label = { Text("الخريطة") }
                                )
                                NavigationBarItem(
                                    selected = viewModel.selectedTab == "tickets",
                                    onClick = { viewModel.selectedTab = "tickets" },
                                    icon = { Icon(Icons.Default.ConfirmationNumber, contentDescription = "التذاكر") },
                                    label = { Text("التذاكر") }
                                )
                                NavigationBarItem(
                                    selected = viewModel.selectedTab == "more",
                                    onClick = { viewModel.selectedTab = "more" },
                                    icon = { Icon(Icons.Default.MoreHoriz, contentDescription = "المزيد") },
                                    label = { Text("المزيد") }
                                )
                            }
                        }
                    ) { innerPadding ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        ) {
                            when (viewModel.selectedTab) {
                                "home" -> HomeScreen(viewModel = viewModel)
                                "map" -> MapScreen(viewModel = viewModel)
                                "tickets" -> TicketsScreen(viewModel = viewModel)
                                "more" -> MoreScreen(viewModel = viewModel)
                            }
                        }
                    }
                }
            }
        }
    }
}
