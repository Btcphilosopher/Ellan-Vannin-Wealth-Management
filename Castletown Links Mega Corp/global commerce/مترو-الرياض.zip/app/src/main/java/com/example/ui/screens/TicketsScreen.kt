package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.database.TicketEntity
import com.example.domain.models.FareProduct
import com.example.ui.theme.LuxuryGold
import com.example.ui.theme.MetroBlue
import com.example.ui.theme.RiyadhCharcoal
import com.example.ui.viewmodel.MetroViewModel
import com.example.ui.viewmodel.PaymentUiState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun TicketsScreen(viewModel: MetroViewModel) {
    val fares = viewModel.getFares()
    val tickets by viewModel.tickets.collectAsState()
    val paymentState by viewModel.paymentState.collectAsState()

    var selectedProductForBuy by remember { mutableStateOf<FareProduct?>(null) }
    var selectedTicketForDetails by remember { mutableStateOf<TicketEntity?>(null) }

    var selectedTicketTab by remember { mutableStateOf("active") } // active, history

    val activeTicketsList = tickets.filter { it.status == "ACTIVE" || it.status == "UPCOMING" }
    val expiredTicketsList = tickets.filter { it.status == "EXPIRED" || it.status == "CANCELLED" }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .testTag("tickets_screen_root")
            .background(MaterialTheme.colorScheme.background)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(top = 24.dp, bottom = 120.dp, start = 20.dp, end = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Screen Title
            item {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "التذاكر والاشتراكات",
                        style = MaterialTheme.typography.headlineLarge,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "اشتر تذكرتك التجريبية واستعرض اشتراكاتك الفعالة والسابقة",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                    )
                }
            }

            // Tabs Selector: Buy vs My Tickets
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            RoundedCornerShape(8.dp)
                        )
                        .padding(4.dp)
                ) {
                    listOf("buy" to "شراء تذكرة", "my" to "تذاكري").forEach { (tabKey, tabLabel) ->
                        val isTabSelected = if (tabKey == "buy") selectedTicketTab == "buy" else selectedTicketTab != "buy"
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(
                                    if (isTabSelected) MaterialTheme.colorScheme.primary else Color.Transparent
                                )
                                .clickable {
                                    selectedTicketTab = if (tabKey == "buy") "buy" else "active"
                                }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = tabLabel,
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = if (isTabSelected) Color.White else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            if (selectedTicketTab == "buy") {
                // FARE PRODUCTS DIRECTORY
                item {
                    Text(
                        text = "اختر فئة التذكرة المناسبة:",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }

                items(fares) { fare ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                1.dp,
                                MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f),
                                RoundedCornerShape(12.dp)
                            ),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(18.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = fare.nameArabic,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = "${String.format(Locale.ENGLISH, "%.2f", fare.price)} ر.س",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = LuxuryGold
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = fare.descriptionArabic,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                                lineHeight = 20.sp
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            Button(
                                onClick = { selectedProductForBuy = fare },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                            ) {
                                Text(
                                    text = "شراء تذكرة تجريبية",
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            } else {
                // MY TICKETS CATEGORIES (Active vs Expired)
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        listOf("active" to "النشطة (${activeTicketsList.size})", "history" to "المستعملة والسابقة (${expiredTicketsList.size})").forEach { (subTabKey, subTabLabel) ->
                            val isSubSelected = selectedTicketTab == subTabKey
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(
                                        if (isSubSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f) else Color.Transparent
                                    )
                                    .border(
                                        width = 1.dp,
                                        color = if (isSubSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(
                                            alpha = 0.15f
                                        ),
                                        shape = RoundedCornerShape(20.dp)
                                    )
                                    .clickable { selectedTicketTab = subTabKey }
                                    .padding(horizontal = 14.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = subTabLabel,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSubSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }

                val listToRender = if (selectedTicketTab == "active") activeTicketsList else expiredTicketsList

                if (listToRender.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 80.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Default.ConfirmationNumber,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f),
                                    modifier = Modifier.size(64.dp)
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                Text(
                                    text = if (selectedTicketTab == "active") "لا توجد أي تذاكر فعالة حالياً." else "لا توجد تذاكر منتهية الصلاحية سابقاً.",
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "بإمكانك التوجه لعلامة تبويب 'شراء تذكرة' لإصدار تذكرة تجريبية جديدة والمضي قدماً في رحلتك.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(horizontal = 24.dp)
                                )
                            }
                        }
                    }
                } else {
                    items(listToRender) { ticket ->
                        TicketListItem(
                            ticket = ticket,
                            onClick = { selectedTicketForDetails = ticket }
                        )
                    }
                }
            }
        }

        // 1. DEMO PURCHASE BANK PAYMENTS SHEET
        if (selectedProductForBuy != null) {
            val product = selectedProductForBuy!!
            Dialog(
                onDismissRequest = {
                    if (paymentState !is PaymentUiState.Processing) {
                        selectedProductForBuy = null
                        viewModel.resetPaymentState()
                    }
                },
                properties = DialogProperties(dismissOnBackPress = true, dismissOnClickOutside = false)
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "بوابة الدفع التجريبية",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "نموذج مستقل لأغراض التصميم والدراسة فقط",
                            style = MaterialTheme.typography.labelSmall,
                            color = LuxuryGold,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "المنتج المحدد:",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                            Text(
                                text = product.nameArabic,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "المبلغ الإجمالي:",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                            Text(
                                text = "${String.format(Locale.ENGLISH, "%.2f", product.price)} ر.س",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        when (paymentState) {
                            is PaymentUiState.Idle -> {
                                // Render simple payment methods
                                Text(
                                    text = "اختر وسيلة دفع تجريبية:",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.align(Alignment.Start)
                                )
                                Spacer(modifier = Modifier.height(12.dp))

                                // Apple Pay Mock
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { viewModel.executePurchase(product) },
                                    colors = CardDefaults.cardColors(containerColor = Color.Black),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        horizontalArrangement = Arrangement.Center,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.TouchApp,
                                            contentDescription = null,
                                            tint = Color.White
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "الدفع بواسطة المحفظة الرقمية",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                // Bank Card Mock
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { viewModel.executePurchase(product) },
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.05f)
                                    ),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        horizontalArrangement = Arrangement.Center,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.CreditCard,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "الدفع ببطاقة مدى / فيزا تجريبية",
                                            color = MaterialTheme.colorScheme.primary,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(16.dp))

                                Text(
                                    text = "تنبيه: لن يتم خصم أي مبالغ مالية حقيقية. هذه واجهة دفع تحاكي آلية الربط البرمجي لتطبيقات النقل.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                                    textAlign = TextAlign.Center
                                )
                            }

                            is PaymentUiState.Processing -> {
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    CircularProgressIndicator(
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(48.dp)
                                    )
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Text(
                                        text = "جاري مراجعة طلب الدفع التجريبي...",
                                        style = MaterialTheme.typography.bodyLarge,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "الربط الآمن بقنوات السداد قيد المزامنة للبطاقة المحاكاة",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }

                            is PaymentUiState.Success -> {
                                val ticket = (paymentState as PaymentUiState.Success).ticket
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = Color(0xFF12B76A),
                                        modifier = Modifier.size(56.dp)
                                    )
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Text(
                                        text = "تمت عملية الشراء التجريبية بنجاح!",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = Color(0xFF12B76A),
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "تم توليد وإصدار بطاقة صعود المترو الرقمية ورقمها هو: ${ticket.id}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                                        textAlign = TextAlign.Center
                                    )
                                    Spacer(modifier = Modifier.height(24.dp))
                                    Button(
                                        onClick = {
                                            selectedProductForBuy = null
                                            viewModel.resetPaymentState()
                                            selectedTicketForDetails = ticket
                                        },
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                    ) {
                                        Text("استعراض التذكرة ومسح الرمز")
                                    }
                                }
                            }

                            is PaymentUiState.Error -> {
                                val msg = (paymentState as PaymentUiState.Error).messageArabic
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Error,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.error,
                                        modifier = Modifier.size(56.dp)
                                    )
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Text(
                                        text = "تعذر إتمام عملية الدفع",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = MaterialTheme.colorScheme.error,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = msg,
                                        style = MaterialTheme.typography.bodyMedium,
                                        textAlign = TextAlign.Center
                                    )
                                    Spacer(modifier = Modifier.height(24.dp))
                                    Button(
                                        onClick = { viewModel.resetPaymentState() },
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text("إعادة المحاولة")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 2. HIGH FIDELITY SECURE DIGITAL TICKET OVERLAY (Section 18)
        if (selectedTicketForDetails != null) {
            val ticket = selectedTicketForDetails!!

            Dialog(
                onDismissRequest = { selectedTicketForDetails = null },
                properties = DialogProperties(usePlatformDefaultWidth = false)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.8f))
                        .clickable { selectedTicketForDetails = null },
                    contentAlignment = Alignment.Center
                ) {
                    // Physical-style ticket card (Secure Najdi Architecture layout)
                    Card(
                        modifier = Modifier
                            .widthIn(max = 380.dp)
                            .fillMaxWidth()
                            .padding(24.dp)
                            .clickable(enabled = false) {}, // prevent closing when clicking inside
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            // Border Najd Header geometric pattern
                            RiyadhTicketGeometricPattern()

                            Spacer(modifier = Modifier.height(16.dp))

                            // Ticket Status Pill
                            Box(
                                modifier = Modifier
                                    .background(
                                        color = if (ticket.status == "ACTIVE") Color(0xFF12B76A).copy(alpha = 0.15f) else Color.LightGray,
                                        shape = RoundedCornerShape(20.dp)
                                    )
                                    .padding(horizontal = 16.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = if (ticket.status == "ACTIVE") "تذكرة فعالة نشطة" else "منتهية الصلاحية",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (ticket.status == "ACTIVE") Color(0xFF027A48) else Color.DarkGray
                                )
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            // Route
                            Text(
                                text = "${ticket.origin}  ←  ${ticket.destination}",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = RiyadhCharcoal,
                                textAlign = TextAlign.Center
                            )

                            Text(
                                text = "مسار قطار الرياض الحضري",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.Gray,
                                textAlign = TextAlign.Center
                            )

                            Spacer(modifier = Modifier.height(20.dp))

                            // Simulated QR Code Frame (Section 17)
                            Box(
                                modifier = Modifier
                                    .size(180.dp)
                                    .background(Color(0xFFFAF7F0), RoundedCornerShape(8.dp))
                                    .border(1.dp, Color.LightGray, RoundedCornerShape(8.dp))
                                    .padding(12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                // Interactive geometric QR Code
                                TicketMockQrCode(payload = ticket.qrPayload)
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "تذكرة تجريبية  •  دعم غير متصل بالإنترنت",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = LuxuryGold
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            // Printing Info
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(horizontalAlignment = Alignment.Start) {
                                    Text("رقم التذكرة", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                    Text(ticket.id, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold, color = RiyadhCharcoal)
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text("تاريخ الشراء", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                    Text(
                                        text = SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH).format(Date(ticket.purchaseTime)),
                                        style = MaterialTheme.typography.bodyLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = RiyadhCharcoal
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))
                            HorizontalDivider(color = Color.LightGray.copy(alpha = 0.5f))
                            Spacer(modifier = Modifier.height(12.dp))

                            // Disclaimer
                            Text(
                                text = "هذا نموذج تذكرة محاكاة مستقل للدراسة، ولا يعطي صاحبه الحق في العبور الفعلي داخل بوابات قطار الرياض الحقيقية.",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.Gray,
                                textAlign = TextAlign.Center,
                                lineHeight = 16.sp
                            )

                            Spacer(modifier = Modifier.height(24.dp))

                            Button(
                                onClick = { selectedTicketForDetails = null },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = RiyadhCharcoal)
                            ) {
                                Text("إغلاق التفاصيل", color = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TicketListItem(ticket: TicketEntity, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .background(
                            if (ticket.status == "ACTIVE") Color(0xFF12B76A).copy(alpha = 0.1f) else Color.LightGray.copy(
                                alpha = 0.3f
                            ),
                            CircleShape
                        )
                        .padding(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.QrCode,
                        contentDescription = null,
                        tint = if (ticket.status == "ACTIVE") Color(0xFF12B76A) else Color.DarkGray,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(16.dp))

                Column {
                    Text(
                        text = "${ticket.origin} ← ${ticket.destination}",
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "رقم التذكرة: ${ticket.id}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    )
                }
            }

            Box(
                modifier = Modifier
                    .background(
                        color = if (ticket.status == "ACTIVE") Color(0xFF12B76A).copy(alpha = 0.12f) else Color.LightGray.copy(
                            alpha = 0.2f
                        ),
                        shape = RoundedCornerShape(4.dp)
                    )
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = if (ticket.status == "ACTIVE") "فعالة" else "سابقة",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (ticket.status == "ACTIVE") Color(0xFF027A48) else Color.DarkGray,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

// Custom security pattern representing security printing on physical tickets (Section 18)
@Composable
fun RiyadhTicketGeometricPattern() {
    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(24.dp)
    ) {
        val w = size.width
        val h = size.height

        val path = Path()
        val amplitude = 8f
        val period = 30f

        path.moveTo(0f, h / 2)
        var x = 0f
        while (x < w) {
            path.lineTo(x, (h / 2) + Math.sin((x / period).toDouble()).toFloat() * amplitude)
            x += 5f
        }

        drawPath(
            path = path,
            color = LuxuryGold,
            style = Stroke(width = 2f, cap = StrokeCap.Round)
        )

        // Draw small decorative triangles
        val triCount = (w / 40f).toInt()
        for (i in 0..triCount) {
            val cx = i * 40f
            drawCircle(
                color = DeepDesertGreen,
                radius = 3f,
                center = Offset(cx, h / 2 - 6f)
            )
        }
    }
}

// Custom client-side vector generator representing an offline secure QR code (Section 17)
@Composable
fun TicketMockQrCode(payload: String) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height

        // Fill background
        drawRect(Color.White)

        // Draw mock QR position finders at corners
        val boxSize = 36f
        val innerBoxSize = 16f

        // Top Left finder
        drawRect(Color.Black, topLeft = Offset(0f, 0f), size = androidx.compose.ui.geometry.Size(boxSize, boxSize))
        drawRect(Color.White, topLeft = Offset(6f, 6f), size = androidx.compose.ui.geometry.Size(boxSize - 12f, boxSize - 12f))
        drawRect(Color.Black, topLeft = Offset(10f, 10f), size = androidx.compose.ui.geometry.Size(innerBoxSize, innerBoxSize))

        // Top Right finder
        drawRect(Color.Black, topLeft = Offset(w - boxSize, 0f), size = androidx.compose.ui.geometry.Size(boxSize, boxSize))
        drawRect(Color.White, topLeft = Offset(w - boxSize + 6f, 6f), size = androidx.compose.ui.geometry.Size(boxSize - 12f, boxSize - 12f))
        drawRect(Color.Black, topLeft = Offset(w - boxSize + 10f, 10f), size = androidx.compose.ui.geometry.Size(innerBoxSize, innerBoxSize))

        // Bottom Left finder
        drawRect(Color.Black, topLeft = Offset(0f, h - boxSize), size = androidx.compose.ui.geometry.Size(boxSize, boxSize))
        drawRect(Color.White, topLeft = Offset(6f, h - boxSize + 6f), size = androidx.compose.ui.geometry.Size(boxSize - 12f, boxSize - 12f))
        drawRect(Color.Black, topLeft = Offset(10f, h - boxSize + 10f), size = androidx.compose.ui.geometry.Size(innerBoxSize, innerBoxSize))

        // Fill middle with algorithmic, stable QR data dots using hashCode of the payload
        val rows = 18
        val cols = 18
        val dotW = w / cols
        val dotH = h / rows

        val codeHash = payload.hashCode()

        for (r in 0 until rows) {
            for (c in 0 until cols) {
                // Skip finder corners
                if (r < 5 && c < 5) continue
                if (r < 5 && c >= cols - 5) continue
                if (r >= rows - 5 && c < 5) continue

                // Pseudo-random state deterministic by payload hash
                val state = (codeHash xor (r * 1234) xor (c * 5678)) % 2 == 0
                if (state) {
                    drawRect(
                        color = Color.Black,
                        topLeft = Offset(c * dotW, r * dotH),
                        size = androidx.compose.ui.geometry.Size(dotW - 1f, dotH - 1f)
                    )
                }
            }
        }
    }
}
