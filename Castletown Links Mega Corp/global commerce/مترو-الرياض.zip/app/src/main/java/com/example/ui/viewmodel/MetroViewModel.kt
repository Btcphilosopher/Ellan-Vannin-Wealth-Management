package com.example.ui.viewmodel

import android.annotation.SuppressLint
import android.app.Application
import android.location.Location
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.FavoriteStationEntity
import com.example.data.database.JourneyHistoryEntity
import com.example.data.database.MetroDatabase
import com.example.data.database.TicketEntity
import com.example.data.repository.MetroRepository
import com.example.domain.models.*
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed interface LocationUiState {
    object Idle : LocationUiState
    object Loading : LocationUiState
    data class Success(val station: MetroStation, val lat: Double, val lng: Double) : LocationUiState
    object Error : LocationUiState
    object PermissionDenied : LocationUiState
}

sealed interface PaymentUiState {
    object Idle : PaymentUiState
    object Processing : PaymentUiState
    data class Success(val ticket: TicketEntity) : PaymentUiState
    data class Error(val messageArabic: String) : PaymentUiState
}

class MetroViewModel(application: Application) : AndroidViewModel(application) {

    private val db = MetroDatabase.getDatabase(application)
    private val repository = MetroRepository(application, db.metroDao())

    // --- State Flows ---
    private val _isLoaded = MutableStateFlow(false)
    val isLoaded: StateFlow<Boolean> = _isLoaded.asStateFlow()

    private val _locationState = MutableStateFlow<LocationUiState>(LocationUiState.Idle)
    val locationState: StateFlow<LocationUiState> = _locationState.asStateFlow()

    private val _paymentState = MutableStateFlow<PaymentUiState>(PaymentUiState.Idle)
    val paymentState: StateFlow<PaymentUiState> = _paymentState.asStateFlow()

    // Persistent Room States
    val tickets: StateFlow<List<TicketEntity>> = repository.getAllTickets()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val journeyHistory: StateFlow<List<JourneyHistoryEntity>> = repository.getJourneyHistory()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favorites: StateFlow<List<FavoriteStationEntity>> = repository.getFavoriteStations()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- In-Memory State variables ---
    var selectedTab by mutableStateOf("home") // home, map, tickets, more

    // Route search inputs
    var searchFromStation by mutableStateOf<MetroStation?>(null)
    var searchToStation by mutableStateOf<MetroStation?>(null)

    // Route planning results
    var routeOptions by mutableStateOf<List<RouteOption>>(emptyList())
    var selectedRouteOption by mutableStateOf<RouteOption?>(null)

    // Active Journey Simulation
    var isJourneyActive by mutableStateOf(false)
    var activeStationIndex by mutableStateOf(0)
    var simulationSpeedMs by mutableStateOf(4000L) // 4 seconds per hop in demo
    var activeSegmentIndex by mutableStateOf(0)
    var currentSegmentHopIndex by mutableStateOf(0)

    // Interactive details view states
    var selectedStationDetails by mutableStateOf<MetroStation?>(null)
    var selectedLineDetails by mutableStateOf<MetroLine?>(null)

    // Offline mode simulation
    var isOfflineMode by mutableStateOf(false)

    init {
        initData()
    }

    private fun initData() {
        viewModelScope.launch {
            repository.loadStaticData()
            _isLoaded.value = true

            // Inject default favorite if empty (just to give a beautiful pre-populated experience)
            // Section 22: favorites KAFD
            launch(Dispatchers.IO) {
                if (repository.getStations().isNotEmpty()) {
                    val kafd = repository.getStationById("kafd")
                    if (kafd != null) {
                        repository.toggleFavorite("kafd", "مقر العمل", isWork = true)
                    }
                    val olaya = repository.getStationById("olaya")
                    if (olaya != null) {
                        repository.toggleFavorite("olaya", "المنزل", isHome = true)
                    }
                }
            }
        }
    }

    // --- Static data getters ---
    fun getLines(): List<MetroLine> = repository.getLines()
    fun getStations(): List<MetroStation> = repository.getStations()
    fun getFares(): List<FareProduct> = repository.getFares()
    fun getArtworks(): List<Artwork> = repository.getArtworks()
    fun getAlerts(): List<DemoAlert> = repository.getAlerts()

    fun getStationName(id: String): String {
        return repository.getStationById(id)?.nameArabic ?: id
    }

    // --- Location Services ---
    @SuppressLint("MissingPermission")
    fun requestDeviceLocation(hasPermission: Boolean) {
        if (!hasPermission) {
            _locationState.value = LocationUiState.PermissionDenied
            return
        }

        _locationState.value = LocationUiState.Loading

        viewModelScope.launch {
            try {
                val fusedLocationClient = LocationServices.getFusedLocationProviderClient(getApplication<Application>())
                val cts = CancellationTokenSource()

                fusedLocationClient.getCurrentLocation(
                    Priority.PRIORITY_BALANCED_POWER_ACCURACY,
                    cts.token
                ).addOnSuccessListener { location: Location? ->
                    if (location != null) {
                        findNearestStation(location.latitude, location.longitude)
                    } else {
                        // Attempt last location
                        fusedLocationClient.lastLocation.addOnSuccessListener { lastLoc: Location? ->
                            if (lastLoc != null) {
                                findNearestStation(lastLoc.latitude, lastLoc.longitude)
                            } else {
                                // Simulate GPS coordinates of Riyadh center for demonstration
                                // so the user gets a working success state, but marked as simulation
                                simulateRiyadhLocation()
                            }
                        }.addOnFailureListener {
                            _locationState.value = LocationUiState.Error
                        }
                    }
                }.addOnFailureListener {
                    _locationState.value = LocationUiState.Error
                }
            } catch (e: Exception) {
                _locationState.value = LocationUiState.Error
            }
        }
    }

    private fun findNearestStation(lat: Double, lng: Double) {
        val allStations = getStations()
        if (allStations.isEmpty()) {
            _locationState.value = LocationUiState.Error
            return
        }

        // Find station with minimum coordinate distance
        val nearest = allStations.minByOrNull { station ->
            val dLat = station.latitude - lat
            val dLng = station.longitude - lng
            dLat * dLat + dLng * dLng
        }

        if (nearest != null) {
            searchFromStation = nearest
            _locationState.value = LocationUiState.Success(nearest, lat, lng)
        } else {
            _locationState.value = LocationUiState.Error
        }
    }

    private fun simulateRiyadhLocation() {
        viewModelScope.launch {
            delay(1000) // fake reading delay
            // Simulate coordinates of Ministry of Interior (وزارة الداخلية)
            val simulatedLat = 24.685
            val simulatedLng = 46.691
            findNearestStation(simulatedLat, simulatedLng)
        }
    }

    fun clearLocationState() {
        _locationState.value = LocationUiState.Idle
    }

    // --- Search & Routing Flows ---
    fun selectFromStation(station: MetroStation) {
        searchFromStation = station
        clearLocationState()
        triggerRouteSearch()
    }

    fun selectToStation(station: MetroStation) {
        searchToStation = station
        triggerRouteSearch()
    }

    fun swapStations() {
        val temp = searchFromStation
        searchFromStation = searchToStation
        searchToStation = temp
        triggerRouteSearch()
    }

    fun triggerRouteSearch() {
        val from = searchFromStation ?: return
        val to = searchToStation ?: return

        if (from.id == to.id) {
            routeOptions = emptyList()
            selectedRouteOption = null
            return
        }

        routeOptions = repository.planRoute(from.id, to.id)
        selectedRouteOption = routeOptions.firstOrNull()
    }

    // --- Simulation ---
    fun startSimulation(option: RouteOption) {
        selectedRouteOption = option
        isJourneyActive = true
        activeStationIndex = 0
        activeSegmentIndex = 0
        currentSegmentHopIndex = 0

        viewModelScope.launch {
            // Save to previous journeys history
            repository.addJourneyToHistory(
                originId = option.stations.first().id,
                destinationId = option.stations.last().id,
                duration = option.totalDurationMinutes,
                interchanges = option.transferCount
            )

            // Let's run a loop step by step representing the passenger journey on the line
            while (isJourneyActive && activeStationIndex < option.stations.size - 1) {
                delay(simulationSpeedMs)

                if (!isJourneyActive) break

                activeStationIndex++

                // Pulse effects can be checked inside the UI
                // Update active segment tracking
                val currentSegment = option.pathSegments.getOrNull(activeSegmentIndex)
                if (currentSegment != null) {
                    val currentStation = option.stations[activeStationIndex]
                    // If we reached the end of the current segment, and there are more segments, transition
                    if (currentStation.id == currentSegment.toStationId && activeSegmentIndex < option.pathSegments.size - 1) {
                        activeSegmentIndex++
                        currentSegmentHopIndex = 0
                    } else {
                        currentSegmentHopIndex++
                    }
                }
            }

            // Arrived at final destination!
            if (isJourneyActive) {
                delay(2000)
                isJourneyActive = false
            }
        }
    }

    fun cancelSimulation() {
        isJourneyActive = false
    }

    // --- Ticket & Purchases ---
    fun executePurchase(product: FareProduct) {
        val from = searchFromStation ?: getStations().find { it.id == "olaya" } ?: return
        val to = searchToStation ?: getStations().find { it.id == "kafd" } ?: return
        val primaryLine = selectedRouteOption?.pathSegments?.firstOrNull()?.lineId ?: from.lines.firstOrNull()

        _paymentState.value = PaymentUiState.Processing

        viewModelScope.launch {
            delay(1800) // Simulating bank / Saudi Payment engine response time

            if (isOfflineMode) {
                // Should still work if cached, but for buying let's demonstrate
            }

            try {
                val ticket = repository.buyTicket(
                    productId = product.id,
                    originId = from.id,
                    destinationId = to.id,
                    lineId = primaryLine,
                    price = product.price
                )
                _paymentState.value = PaymentUiState.Success(ticket)
            } catch (e: Exception) {
                _paymentState.value = PaymentUiState.Error("فشلت عملية الدفع التجريبية. يرجى التحقق من اتصال الشبكة.")
            }
        }
    }

    fun resetPaymentState() {
        _paymentState.value = PaymentUiState.Idle
    }

    // --- Favorites ---
    fun toggleFavoriteStation(stationId: String, isHome: Boolean = false, isWork: Boolean = false) {
        viewModelScope.launch(Dispatchers.IO) {
            val exists = favorites.value.any { it.stationId == stationId }
            if (exists) {
                repository.removeFavorite(stationId)
            } else {
                val label = if (isHome) "المنزل" else if (isWork) "العمل" else "مفضلة"
                repository.toggleFavorite(stationId, label, isHome, isWork)
            }
        }
    }

    fun removeFavoriteStation(stationId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.removeFavorite(stationId)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearJourneyHistory()
        }
    }
}
