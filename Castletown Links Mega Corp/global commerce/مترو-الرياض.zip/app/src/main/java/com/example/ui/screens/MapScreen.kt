package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.models.MetroStation
import com.example.domain.models.MetroLine
import com.example.ui.theme.*
import com.example.ui.viewmodel.MetroViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MapScreen(viewModel: MetroViewModel) {
    val stations = viewModel.getStations()
    val lines = viewModel.getLines()
    val artworks = viewModel.getArtworks()

    var scale by remember { mutableStateOf(1.0f) }
    var offset by remember { mutableStateOf(Offset(0f, -100f)) }

    val textMeasurer = rememberTextMeasurer()

    // Map limits for projecting coordinates to Canvas
    val minLat = 24.58
    val maxLat = 24.98
    val minLng = 46.56
    val maxLng = 46.84

    var selectedStation by remember { mutableStateOf<MetroStation?>(null) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .testTag("map_screen_root")
    ) {
        // Map Canvas Area
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        scale = (scale * zoom).coerceIn(0.6f, 4.0f)
                        offset = Offset(
                            x = (offset.x + pan.x).coerceIn(-1200f * scale, 1200f * scale),
                            y = (offset.y + pan.y).coerceIn(-1200f * scale, 1200f * scale)
                        )
                    }
                }
                .pointerInput(stations) {
                    detectTapGestures { tapOffset ->
                        // Reverse project canvas click to locate nearest station
                        val w = size.width.toFloat()
                        val h = size.height.toFloat()

                        // Compensate for panning and scale
                        val relativeX = (tapOffset.x - w / 2 - offset.x) / scale + w / 2
                        val relativeY = (tapOffset.y - h / 2 - offset.y) / scale + h / 2

                        var closestStation: MetroStation? = null
                        var minDistance = 150f // Tap tolerance threshold in pixels

                        stations.forEach { station ->
                            // Project station coordinates to canvas pixels
                            val pctX = (station.longitude - minLng) / (maxLng - minLng)
                            val pctY = 1.0 - (station.latitude - minLat) / (maxLat - minLat)

                            // Apply local bounds
                            val padX = w * 0.1f
                            val padY = h * 0.1f
                            val stationX = padX + pctX.toFloat() * (w - 2 * padX)
                            val stationY = padY + pctY.toFloat() * (h - 2 * padY)

                            val dist = Math.sqrt(
                                Math.pow((relativeX - stationX).toDouble(), 2.0) +
                                        Math.pow((relativeY - stationY).toDouble(), 2.0)
                            ).toFloat()

                            if (dist < minDistance) {
                                minDistance = dist
                                closestStation = station
                            }
                        }

                        selectedStation = closestStation
                    }
                }
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer(
                        scaleX = scale,
                        scaleY = scale,
                        translationX = offset.x,
                        translationY = offset.y
                    )
            ) {
                val canvasW = size.width
                val canvasH = size.height

                val padX = canvasW * 0.1f
                val padY = canvasH * 0.1f

                fun getProjectedOffset(lat: Double, lng: Double): Offset {
                    val pctX = (lng - minLng) / (maxLng - minLng)
                    val pctY = 1.0 - (lat - minLat) / (maxLat - minLat)

                    val x = padX + pctX * (canvasW - 2 * padX)
                    val y = padY + pctY * (canvasH - 2 * padY)
                    return Offset(x.toFloat(), y.toFloat())
                }

                // 1. Draw Geometric Metro Lines Paths
                val lineSequences = mapOf(
                    "blue" to listOf("kafd", "olaya", "moi", "qasr_al_hukm", "batha"),
                    "red" to listOf("ksu", "olaya", "exhibition"),
                    "orange" to listOf("west_riyadh", "qasr_al_hukm", "east_riyadh"),
                    "yellow" to listOf("kafd", "pnu", "kkia"),
                    "green" to listOf("moi", "finance", "national_museum"),
                    "purple" to listOf("kafd", "pnu", "yarmouk")
                )

                lineSequences.forEach { (lineId, sequence) ->
                    val metroLine = lines.find { it.id == lineId } ?: return@forEach
                    val lineRawColor = Color(android.graphics.Color.parseColor(metroLine.color))

                    val path = Path()
                    var isFirst = true

                    sequence.forEach { stationId ->
                        val station = stations.find { it.id == stationId } ?: return@forEach
                        val pt = getProjectedOffset(station.latitude, station.longitude)
                        if (isFirst) {
                            path.moveTo(pt.x, pt.y)
                            isFirst = false
                        } else {
                            path.lineTo(pt.x, pt.y)
                        }
                    }

                    drawPath(
                        path = path,
                        color = lineRawColor,
                        style = Stroke(
                            width = 12f,
                            cap = StrokeCap.Round,
                            join = StrokeJoin.Round
                        )
                    )
                }

                // 2. Draw Stations Circles & Text Labels
                stations.forEach { station ->
                    val pt = getProjectedOffset(station.latitude, station.longitude)

                    // Draw station node circle
                    val primaryLineId = station.lines.firstOrNull() ?: "blue"
                    val line = lines.find { it.id == primaryLineId }
                    val lineRawColor = Color(android.graphics.Color.parseColor(line?.color ?: "#0056B3"))

                    if (station.interchange) {
                        // Concentric circle for interchange nodes
                        drawCircle(
                            color = Color.White,
                            radius = 24f,
                            center = pt
                        )
                        drawCircle(
                            color = RiyadhCharcoal,
                            radius = 24f,
                            center = pt,
                            style = Stroke(width = 4f)
                        )
                        drawCircle(
                            color = lineRawColor,
                            radius = 12f,
                            center = pt
                        )
                    } else {
                        drawCircle(
                            color = Color.White,
                            radius = 18f,
                            center = pt
                        )
                        drawCircle(
                            color = lineRawColor,
                            radius = 18f,
                            center = pt,
                            style = Stroke(width = 5f)
                        )
                    }

                    // Tapped feedback indicator
                    if (selectedStation?.id == station.id) {
                        drawCircle(
                            color = LuxuryGold.copy(alpha = 0.4f),
                            radius = 42f,
                            center = pt,
                            style = Stroke(width = 6f)
                        )
                    }

                    // Draw station Arabic text label (small and neat)
                    val textLayoutResult = textMeasurer.measure(
                        text = station.nameArabic,
                        style = TextStyle(
                            color = if (selectedStation?.id == station.id) DeepDesertGreen else RiyadhCharcoal,
                            fontWeight = if (selectedStation?.id == station.id) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 11.sp
                        )
                    )

                    // Draw label offset slightly above/below the circle to keep the screen uncluttered
                    val labelYOffset = if (station.id == "olaya" || station.id == "pnu") 28f else -45f
                    drawText(
                        textLayoutResult = textLayoutResult,
                        topLeft = Offset(
                            x = pt.x - textLayoutResult.size.width / 2,
                            y = pt.y + labelYOffset
                        )
                    )
                }
            }
        }

        // Title Header overlay (Modern geometric box matching Riyadh's architectural style)
        Card(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 16.dp, start = 16.dp, end = 16.dp)
                .widthIn(max = 500.dp)
                .fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f)
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
            shape = RoundedCornerShape(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(horizontal = 16.dp, vertical = 12.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "خريطة شبكة المترو",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "خريطة جغرافية تفاعلية للخطوط الستة. اسحب للتحريك واقرص للتكبير.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                    textAlign = TextAlign.Center
                )
            }
        }

        // Manual Zoom Controls overlay on bottom right
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(bottom = 120.dp, start = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FloatingActionButton(
                onClick = { scale = (scale + 0.3f).coerceAtMost(4.0f) },
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(44.dp)
            ) {
                Icon(Icons.Default.ZoomIn, contentDescription = "تكبير")
            }
            FloatingActionButton(
                onClick = { scale = (scale - 0.3f).coerceAtLeast(0.6f) },
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(44.dp)
            ) {
                Icon(Icons.Default.ZoomOut, contentDescription = "تصغير")
            }
        }

        // Station Details Bottom Drawer (Section 19 & 20)
        AnimatedVisibility(
            visible = selectedStation != null,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 80.dp),
            enter = slideInVertically(initialOffsetY = { it }),
            exit = slideOutVertically(targetOffsetY = { it })
        ) {
            selectedStation?.let { station ->
                val matchingArtwork = artworks.find { it.stationId == station.id }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 600.dp)
                        .padding(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 12.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        // Drawer Header
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = station.nameArabic,
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    if (station.interchange) {
                                        Box(
                                            modifier = Modifier
                                                .padding(start = 8.dp)
                                                .background(
                                                    color = LuxuryGold.copy(alpha = 0.15f),
                                                    shape = RoundedCornerShape(4.dp)
                                                )
                                                .border(
                                                    width = 1.dp,
                                                    color = LuxuryGold,
                                                    shape = RoundedCornerShape(4.dp)
                                                )
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = "محطة تحويل",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = DeepDesertGreen,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                                Text(
                                    text = "رمز المحطة: ${station.code ?: "--"}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                )
                            }

                            IconButton(
                                onClick = { selectedStation = null },
                                modifier = Modifier
                                    .background(
                                        MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f),
                                        CircleShape
                                    )
                                    .size(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "إغلاق التفاصيل",
                                    tint = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Serviced Lines
                        Text(
                            text = "الخطوط المشغلة للمحطة:",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(station.lines) { lineId ->
                                val line = lines.find { it.id == lineId }
                                if (line != null) {
                                    val colorValue = Color(android.graphics.Color.parseColor(line.color))
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = colorValue),
                                        shape = RoundedCornerShape(4.dp),
                                        modifier = Modifier.padding(vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = line.name,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = if (line.id == "yellow") Color.Black else Color.White,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))
                        Spacer(modifier = Modifier.height(12.dp))

                        // Facilities & Services
                        Text(
                            text = "مرافق وخدمات الركاب:",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        // Grid layout for facilities
                        val facilityMapping = mapOf(
                            "parking" to "مواقف سيارات واسعة",
                            "elevator" to "مصاعد كهربائية سريعة",
                            "escalator" to "سلالم متحركة مبردة",
                            "toilet" to "دورات مياه مجهزة",
                            "wifi" to "شبكة واي فاي مجانية فائقة السرعة",
                            "accessibility" to "تسهيلات متكاملة لذوي الإعاقة",
                            "shops" to "محلات تجارية ومقاهي سعودية",
                            "luggage" to "تسهيلات وأحزمة للأمتعة"
                        )

                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            station.facilities.forEach { facKey ->
                                val label = facilityMapping[facKey] ?: facKey
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .background(MaterialTheme.colorScheme.primary, CircleShape)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(
                                        text = label,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }

                        // Station Integrated Artworks (Section 25 & 26)
                        if (matchingArtwork != null) {
                            Spacer(modifier = Modifier.height(16.dp))
                            HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))
                            Spacer(modifier = Modifier.height(12.dp))

                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.05f)
                                ),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .background(MaterialTheme.colorScheme.primary, CircleShape)
                                                .padding(6.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Info,
                                                contentDescription = null,
                                                tint = Color.White,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "برنامج فنون قطار الرياض بالمحطة",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = "العمل: ${matchingArtwork.titleArabic}",
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "الفنان: ${matchingArtwork.artistArabic}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = matchingArtwork.descriptionArabic,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f),
                                        lineHeight = 20.sp
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "الموقع: ${matchingArtwork.locationArabic}",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = LuxuryGold
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Action button
                        Button(
                            onClick = {
                                viewModel.selectToStation(station)
                                viewModel.selectedTab = "home"
                                selectedStation = null
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "تحديد كوجهة للرحلة",
                                style = MaterialTheme.typography.labelLarge,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}
