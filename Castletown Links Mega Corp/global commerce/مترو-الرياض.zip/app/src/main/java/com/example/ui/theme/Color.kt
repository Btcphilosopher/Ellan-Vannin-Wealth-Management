package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Saudi Contemporary / Desert Architecture Vibe
val DeepDesertGreen = Color(0xFF0D3E2F)      // Primary Saudi Green
val WarmSandLight = Color(0xFFFAF7F0)        // Clean desert sand beige
val SandAccent = Color(0xFFC5A880)           // Camel gold/sand secondary
val RiyadhCharcoal = Color(0xFF1E2220)       // Ground / asphalt dark neutral
val SoftCream = Color(0xFFF5EFEB)            // Card background light
val LuxuryGold = Color(0xFFD4AF37)           // Gold details

// Line Colors (Riyadh Metro Official Wayfinding Palettes)
val MetroBlue = Color(0xFF0056B3)
val MetroRed = Color(0xFFD92D20)
val MetroOrange = Color(0xFFF79009)
val MetroYellow = Color(0xFFEAAA08)
val MetroGreen = Color(0xFF12B76A)
val MetroPurple = Color(0xFF7A5AF8)

// Dark Theme Palette
val RiyadhDarkBackground = Color(0xFF121413) // Deep eye-safe black
val RiyadhDarkSurface = Color(0xFF1C1F1D)    // Dark card background
val RiyadhDarkSurfaceVariant = Color(0xFF282C29)
val SandDark = Color(0xFFA68D6A)
