package com.example.domain.models

data class MetroLine(
    val id: String, // blue, red, orange, yellow, green, purple
    val name: String, // "الخط الأزرق"
    val number: String, // "1"
    val code: String, // "L1"
    val color: String, // Hex string e.g. "#0056B3"
    val route: String, // "العليا - البطحاء"
    val durationMinutes: Int
)

data class MetroStation(
    val id: String, // "kafd"
    val nameArabic: String, // "مركز الملك عبدالله المالي"
    val code: String?, // "KAFD"
    val lines: List<String>, // IDs of served lines: ["blue", "yellow", "purple"]
    val interchange: Boolean,
    val latitude: Double,
    val longitude: Double,
    val facilities: List<String>
)

data class FareProduct(
    val id: String,
    val nameArabic: String,
    val price: Double,
    val descriptionArabic: String
)

data class StationFacilityInfo(
    val id: String,
    val nameArabic: String,
    val icon: String
)

data class Artwork(
    val stationId: String,
    val titleArabic: String,
    val artistArabic: String,
    val descriptionArabic: String,
    val locationArabic: String
)

data class DemoAlert(
    val id: String,
    val titleArabic: String,
    val typeArabic: String,
    val type: String,
    val contentArabic: String,
    val dateArabic: String,
    val isCritical: Boolean
)
