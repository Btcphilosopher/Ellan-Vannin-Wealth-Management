package com.example.ui.screens

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.domain.models.MetroStation
import com.example.domain.models.RouteOption
import com.example.ui.theme.LuxuryGold
import com.example.ui.theme.MetroBlue
import com.example.ui.theme.RiyadhCharcoal
import com.example.ui.viewmodel.LocationUiState
import com.example.ui.viewmodel.MetroViewModel
import com.example.ui.viewmodel.RouteType
import kotlinx.coroutines.delay

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun HomeScreen(viewModel: MetroViewModel) {
    val context = LocalContext.current
    val isLoaded by viewModel.isLoaded.collectAsState()
    val locationState by viewModel.locationState.collectAsState()
    val journeyHistory by viewModel.journeyHistory.collectAsState()
    val activeTickets by viewModel.tickets.collectAsState()

    var showFromSearch by remember { mutableStateOf(false) }
    var showToSearch by remember { mutableStateOf(false) }

    // Runtime location permission launcher
    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        viewModel.requestDeviceLocation(isGranted)
    }

    if (!isLoaded) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
        }
        return
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("home_screen_root")
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 20.dp),
        contentPadding = PaddingValues(top = 24.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // Top Header Section (Saudi Contemporary Branding)
        item {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "مترو الرياض",
                    style = MaterialTheme.typography.displayLarge,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "بوابتك لتنقل حضري ذكي وسلس في العاصمة",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                    thickness = 1.dp,
                    modifier = Modifier.width(120.dp)
                )
            }
        }

        // Active Simulation Display (Rides Mode)
        if (viewModel.isJourneyActive && viewModel.selectedRouteOption != null) {
            item {
                ActiveJourneyCard(viewModel = viewModel)
            }
        } else {
            // Standard Trip Planner Form
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp)
                    ) {
                        Text(
                            text = "إلى أين تريد الذهاب؟",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // From-To Form Layout
                        Box(modifier = Modifier.fillMaxWidth()) {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                // FROM Card
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { showFromSearch = true },
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.background
                                    ),
                                    border = BorderStroke(
                                        1.dp,
                                        MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)
                                    ),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(14.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.MyLocation,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column {
                                            Text(
                                                text = "من (محطة البداية)",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                                            )
                                            Text(
                                                text = viewModel.searchFromStation?.nameArabic ?: "حدد موقعك أو اختر محطة",
                                                style = MaterialTheme.typography.bodyLarge,
                                                fontWeight = FontWeight.SemiBold,
                                                color = if (viewModel.searchFromStation == null) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f) else MaterialTheme.colorScheme.onSurface
                                            )
                                        }
                                    }
                                }

                                // TO Card
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { showToSearch = true },
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.background
                                    ),
                                    border = BorderStroke(
                                        1.dp,
                                        MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)
                                    ),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(14.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Place,
                                            contentDescription = null,
                                            tint = LuxuryGold,
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column {
                                            Text(
                                                text = "إلى (الوجهة)",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                                            )
                                            Text(
                                                text = viewModel.searchToStation?.nameArabic ?: "اختر وجهتك المقصودة",
                                                style = MaterialTheme.typography.bodyLarge,
                                                fontWeight = FontWeight.SemiBold,
                                                color = if (viewModel.searchToStation == null) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f) else MaterialTheme.colorScheme.onSurface
                                            )
                                        }
                                    }
                                }
                            }

                            // Swap Button
                            Box(
                                modifier = Modifier
                                    .align(Alignment.CenterEnd)
                                    .padding(end = 16.dp)
                                    .size(36.dp)
                                    .background(MaterialTheme.colorScheme.primary, CircleShape)
                                    .border(2.dp, Color.White, CircleShape)
                                    .clickable { viewModel.swapStations() },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.SwapVert,
                                    contentDescription = "تبديل المحطات",
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // GPS Location Action Button (Section 5)
                        Button(
                            onClick = {
                                locationPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = LuxuryGold.copy(alpha = 0.12f),
                                contentColor = DeepDesertGreen
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.GpsFixed,
                                    contentDescription = null,
                                    tint = LuxuryGold,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = when (locationState) {
                                        is LocationUiState.Loading -> "جاري تحديد موقعك الحالي..."
                                        is LocationUiState.Success -> "تم تحديد موقعك الحالي بنجاح"
                                        is LocationUiState.Error -> "تعذر تحديد الموقع. اختر محطة يدوياً"
                                        is LocationUiState.PermissionDenied -> "تم رفض إذن الموقع. اختر يدوياً"
                                        else -> "استخدام موقعي الحالي"
                                    },
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Primary Search Action
                        Button(
                            onClick = { viewModel.triggerRouteSearch() },
                            enabled = viewModel.searchFromStation != null && viewModel.searchToStation != null,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                disabledContainerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)
                            ),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "البحث عن الرحلة",
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            // Route search result option board (Sections 10 & 11)
            if (viewModel.routeOptions.isNotEmpty()) {
                item {
                    Text(
                        text = "خيارات المسار المتاحة:",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                items(viewModel.routeOptions) { option ->
                    val isSelected = viewModel.selectedRouteOption?.type == option.type
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(
                                    alpha = 0.1f
                                ),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable { viewModel.selectedRouteOption = option },
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.03f) else MaterialTheme.colorScheme.surface
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Route badge type
                                Box(
                                    modifier = Modifier
                                        .background(
                                            color = when (option.type) {
                                                RouteType.FASTEST -> MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                                                RouteType.LEAST_TRANSFERS -> LuxuryGold.copy(alpha = 0.15f)
                                                RouteType.LEAST_WALKING -> Color(0xFF12B76A).copy(alpha = 0.15f)
                                            },
                                            shape = RoundedCornerShape(4.dp)
                                        )
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = when (option.type) {
                                            RouteType.FASTEST -> "الأسرع"
                                            RouteType.LEAST_TRANSFERS -> "أقل عدد تحويلات"
                                            RouteType.LEAST_WALKING -> "أقل مشي"
                                        },
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = when (option.type) {
                                            RouteType.FASTEST -> MaterialTheme.colorScheme.primary
                                            RouteType.LEAST_TRANSFERS -> DeepDesertGreen
                                            RouteType.LEAST_WALKING -> Color(0xFF027A48)
                                        }
                                    )
                                }

                                // Travel time statistics
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "${option.totalDurationMinutes} دقيقة",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Stats bullets
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                Text(
                                    text = "• ${option.stationCount} محطات",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                )
                                Text(
                                    text = "• ${if (option.transferCount == 0) "مباشر" else if (option.transferCount == 1) "تحويل واحد" else "${option.transferCount} تحويلات"}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                )
                            }

                            Spacer(modifier = Modifier.height(16.dp))
                            HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                            Spacer(modifier = Modifier.height(12.dp))

                            // Best route path steps
                            Text(
                                text = "أفضل مسار للرحلة:",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            // Pathway timeline view
                            Column(
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.padding(start = 4.dp)
                            ) {
                                option.pathSegments.forEachIndexed { idx, segment ->
                                    val line = viewModel.getLines().find { it.id == segment.lineId }
                                    val lineColor = Color(android.graphics.Color.parseColor(line?.color ?: "#0056B3"))

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        // Colored line bullet
                                        Box(
                                            modifier = Modifier
                                                .size(10.dp)
                                                .background(lineColor, CircleShape)
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Text(
                                            text = "${viewModel.getStationName(segment.fromStationId)} ← ${line?.name ?: segment.lineId} ← ${viewModel.getStationName(segment.toStationId)}",
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                }
                            }

                            // Simulated Action triggers
                            if (isSelected) {
                                Spacer(modifier = Modifier.height(20.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Button(
                                        onClick = { viewModel.startSimulation(option) },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.DirectionsTransit, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("ابدأ الرحلة", color = Color.White, fontWeight = FontWeight.Bold)
                                        }
                                    }

                                    OutlinedButton(
                                        onClick = {
                                            viewModel.selectedTab = "tickets"
                                        },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(8.dp),
                                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.ConfirmationNumber, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("شراء تذكرة", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Recent Journeys Section (Section 23)
            if (journeyHistory.isNotEmpty()) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "رحلاتك الأخيرة",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        TextButton(onClick = { viewModel.clearAllHistory() }) {
                            Text("مسح السجل", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f), fontSize = 12.sp)
                        }
                    }
                }

                items(journeyHistory.take(3)) { history ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                val from = viewModel.getStations().find { it.id == history.originId }
                                val to = viewModel.getStations().find { it.id == history.destinationId }
                                if (from != null && to != null) {
                                    viewModel.searchFromStation = from
                                    viewModel.searchToStation = to
                                    viewModel.triggerRouteSearch()
                                }
                            },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.History,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "${history.originName} ← ${history.destinationName}",
                                        style = MaterialTheme.typography.bodyLarge,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "${history.durationMinutes} دقيقة  •  ${if (history.interchangeCount == 0) "مباشر" else "${history.interchangeCount} تحويل"}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                                    )
                                }
                            }
                            Icon(
                                imageVector = Icons.Default.ChevronLeft,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
                            )
                        }
                    }
                }
            }

            // Current Active Tickets Showcase (Section 4)
            val currentActiveTickets = activeTickets.filter { it.status == "ACTIVE" }
            if (currentActiveTickets.isNotEmpty()) {
                item {
                    Text(
                        text = "التذاكر الحالية الفعالة",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                items(currentActiveTickets.take(1)) { activeTicket ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, LuxuryGold, RoundedCornerShape(12.dp))
                            .clickable { viewModel.selectedTab = "tickets" },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .background(LuxuryGold.copy(alpha = 0.15f), CircleShape)
                                        .padding(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.QrCode,
                                        contentDescription = null,
                                        tint = LuxuryGold,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "${activeTicket.origin} ← ${activeTicket.destination}",
                                        style = MaterialTheme.typography.bodyLarge,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "صالحة حتى: ٢ ساعة  •  تذكرة تجريبية نشطة",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                                    )
                                }
                            }
                            Text(
                                text = "عرض التذكرة",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        }
    }

    // FROM STATION SEARCH MODAL DIALOG (Section 6)
    if (showFromSearch) {
        StationSearchDialog(
            viewModel = viewModel,
            title = "اختر محطة البداية",
            onDismiss = { showFromSearch = false },
            onSelect = { station ->
                viewModel.selectFromStation(station)
                showFromSearch = false
            }
        )
    }

    // TO STATION SEARCH MODAL DIALOG (Section 6)
    if (showToSearch) {
        StationSearchDialog(
            viewModel = viewModel,
            title = "اختر محطة الوصول",
            onDismiss = { showToSearch = false },
            onSelect = { station ->
                viewModel.selectToStation(station)
                showToSearch = false
            }
        )
    }
}

// Station list selection Dialog in complete Arabic
@Composable
fun StationSearchDialog(
    viewModel: MetroViewModel,
    title: String,
    onDismiss: () -> Unit,
    onSelect: (MetroStation) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val allStations = viewModel.getStations()
    val lines = viewModel.getLines()
    val favorites by viewModel.favorites.collectAsState()

    // Filtered list based on Arabic input
    val filteredStations = allStations.filter {
        it.nameArabic.contains(searchQuery, ignoreCase = true) ||
                (it.code?.contains(searchQuery, ignoreCase = true) == true)
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background),
            shape = RoundedCornerShape(0.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "إغلاق")
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Search field (Section 6)
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("ابحث عن محطة...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("station_search_input"),
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    shape = RoundedCornerShape(8.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.15f)
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(20.dp))

                LazyColumn(
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Show favorites if query empty (Section 22)
                    if (searchQuery.isEmpty() && favorites.isNotEmpty()) {
                        item {
                            Text(
                                text = "المحطات المفضلة والمواقع:",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                            )
                        }

                        items(favorites) { fav ->
                            val station = allStations.find { it.id == fav.stationId }
                            if (station != null) {
                                StationSearchItem(
                                    station = station,
                                    lines = lines,
                                    label = fav.labelArabic,
                                    onClick = { onSelect(station) }
                                )
                            }
                        }

                        item { Spacer(modifier = Modifier.height(12.dp)) }
                    }

                    // Main Stations list
                    item {
                        Text(
                            text = if (searchQuery.isEmpty()) "كل محطات المترو:" else "نتائج البحث:",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                        )
                    }

                    if (filteredStations.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 40.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "عذراً، لم يتم العثور على أي محطة مطابقة.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    } else {
                        items(filteredStations) { station ->
                            val isFavorite = favorites.any { it.stationId == station.id }
                            val label = favorites.find { it.stationId == station.id }?.labelArabic
                            StationSearchItem(
                                station = station,
                                lines = lines,
                                label = label,
                                onClick = { onSelect(station) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StationSearchItem(
    station: MetroStation,
    lines: List<MetroLine>,
    label: String?,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = station.nameArabic,
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Bold
                    )
                    if (label != null) {
                        Box(
                            modifier = Modifier
                                .padding(start = 8.dp)
                                .background(LuxuryGold.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelSmall,
                                color = DeepDesertGreen,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
                Text(
                    text = "رمز المحطة: ${station.code ?: "--"}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )
            }

            // Colored lines pills serving this station
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                station.lines.forEach { lineId ->
                    val line = lines.find { it.id == lineId }
                    if (line != null) {
                        val colorVal = Color(android.graphics.Color.parseColor(line.color))
                        Box(
                            modifier = Modifier
                                .size(height = 16.dp, width = 36.dp)
                                .background(colorVal, RoundedCornerShape(3.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = line.code,
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (lineId == "yellow") Color.Black else Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}

// Active Simulation Board (Section 12 & 13)
@Composable
fun ActiveJourneyCard(viewModel: MetroViewModel) {
    val option = viewModel.selectedRouteOption ?: return
    val currentStationIndex = viewModel.activeStationIndex

    val totalStations = option.stations.size
    val remainingStations = (totalStations - 1) - currentStationIndex

    val currentStation = option.stations.getOrNull(currentStationIndex)
    val nextStation = option.stations.getOrNull(currentStationIndex + 1)

    // Pulse effect scale
    var pulseScale by remember { mutableStateOf(1.0f) }
    LaunchedEffect(currentStationIndex) {
        pulseScale = 1.6f
        delay(150)
        pulseScale = 1.0f
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = RiyadhCharcoal),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(Color(0xFF12B76A), CircleShape)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "رحلتك نشطة الآن",
                        style = MaterialTheme.typography.labelLarge,
                        color = Color(0xFF12B76A),
                        fontWeight = FontWeight.Bold
                    )
                }

                IconButton(
                    onClick = { viewModel.cancelSimulation() },
                    modifier = Modifier
                        .size(32.dp)
                        .background(Color.White.copy(alpha = 0.1f), CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "إنهاء الرحلة",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (remainingStations > 0) {
                // Next Station (Section 12)
                Text(
                    text = "المحطة التالية",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White.copy(alpha = 0.5f),
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = nextStation?.nameArabic ?: "--",
                    style = MaterialTheme.typography.headlineLarge,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Column {
                        Text(
                            text = "المحطة الحالية",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White.copy(alpha = 0.5f)
                        )
                        Text(
                            text = currentStation?.nameArabic ?: "--",
                            style = MaterialTheme.typography.bodyLarge,
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Column {
                        Text(
                            text = "المتبقي للوجهة",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White.copy(alpha = 0.5f)
                        )
                        Text(
                            text = if (remainingStations == 1) "محطة واحدة متبقية" else "$remainingStations محطات متبقية",
                            style = MaterialTheme.typography.bodyLarge,
                            color = LuxuryGold,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            } else {
                // Arrived state
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = Color(0xFF12B76A),
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "لقد وصلت إلى وجهتك بسلام!",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "شكراً لاستخدامك مترو الرياض.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White.copy(alpha = 0.7f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Train track geometric simulation (Section 13)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(40.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxWidth().height(30.dp)) {
                    val w = size.width
                    val h = size.height

                    val startX = 30f
                    val endX = w - 30f

                    // Draw track line
                    drawLine(
                        color = Color.White.copy(alpha = 0.2f),
                        start = Offset(startX, h / 2),
                        end = Offset(endX, h / 2),
                        strokeWidth = 6f,
                        cap = StrokeCap.Round
                    )

                    // Draw station node circles
                    val gap = (endX - startX) / (totalStations - 1).coerceAtLeast(1)

                    for (i in 0 until totalStations) {
                        val cx = startX + i * gap
                        val isPassed = i < currentStationIndex
                        val isCurrent = i == currentStationIndex

                        drawCircle(
                            color = if (isCurrent) LuxuryGold else if (isPassed) Color(0xFF12B76A) else Color.White.copy(alpha = 0.6f),
                            radius = if (isCurrent) 10f else 6f,
                            center = Offset(cx, h / 2)
                        )

                        if (isCurrent) {
                            // Pulsing outer ring
                            drawCircle(
                                color = LuxuryGold.copy(alpha = 0.3f),
                                radius = 10f * pulseScale,
                                center = Offset(cx, h / 2),
                                style = Stroke(width = 3f)
                            )
                        }
                    }
                }
            }
        }
    }
}
