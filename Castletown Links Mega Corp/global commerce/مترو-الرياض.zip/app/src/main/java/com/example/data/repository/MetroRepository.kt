package com.example.data.repository

import android.content.Context
import com.example.data.database.FavoriteStationEntity
import com.example.data.database.JourneyHistoryEntity
import com.example.data.database.MetroDao
import com.example.data.database.TicketEntity
import com.example.domain.models.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream
import java.util.UUID

class MetroRepository(
    private val context: Context,
    private val metroDao: MetroDao
) {
    private var lines: List<MetroLine> = emptyList()
    private var stations: List<MetroStation> = emptyList()
    private var fares: List<FareProduct> = emptyList()
    private var artworks: List<Artwork> = emptyList()
    private var alerts: List<DemoAlert> = emptyList()

    // Define adjacency lists and sequences of lines
    private val lineSequences = mapOf(
        "blue" to listOf("kafd", "olaya", "moi", "qasr_al_hukm", "batha"),
        "red" to listOf("ksu", "olaya", "exhibition"),
        "orange" to listOf("west_riyadh", "qasr_al_hukm", "east_riyadh"),
        "yellow" to listOf("kafd", "pnu", "kkia"),
        "green" to listOf("moi", "finance", "national_museum"),
        "purple" to listOf("kafd", "pnu", "yarmouk")
    )

    // Hop travel times in minutes
    private val hopTimes = mapOf(
        "kafd-olaya" to 8, "olaya-kafd" to 8,
        "olaya-moi" to 5, "moi-olaya" to 5,
        "moi-qasr_al_hukm" to 7, "qasr_al_hukm-moi" to 7,
        "qasr_al_hukm-batha" to 5, "batha-qasr_al_hukm" to 5,
        "ksu-olaya" to 7, "olaya-ksu" to 7,
        "olaya-exhibition" to 6, "exhibition-olaya" to 6,
        "west_riyadh-qasr_al_hukm" to 9, "qasr_al_hukm-west_riyadh" to 9,
        "qasr_al_hukm-east_riyadh" to 10, "east_riyadh-qasr_al_hukm" to 10,
        "kafd-pnu" to 12, "pnu-kafd" to 12,
        "pnu-kkia" to 10, "kkia-pnu" to 10,
        "moi-finance" to 4, "finance-moi" to 4,
        "finance-national_museum" to 4, "national_museum-finance" to 4,
        "pnu-yarmouk" to 8, "yarmouk-pnu" to 8
    )

    init {
        // Synchronously trigger loading, but normally we'll load asynchronously
    }

    suspend fun loadStaticData() = withContext(Dispatchers.IO) {
        try {
            lines = parseLinesJson()
            stations = parseStationsJson()
            fares = parseFaresJson()
            artworks = parseArtworksJson()
            alerts = parseAlertsJson()
        } catch (e: Exception) {
            e.printStackTrace()
            // Fallbacks in case of JSON error
            loadFallbacks()
        }
    }

    private fun parseLinesJson(): List<MetroLine> {
        val jsonStr = readAssetString("metro_lines.json") ?: return emptyList()
        val arr = JSONArray(jsonStr)
        val list = mutableListOf<MetroLine>()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            list.add(
                MetroLine(
                    id = obj.getString("id"),
                    name = obj.getString("name"),
                    number = obj.getString("number"),
                    code = obj.getString("code"),
                    color = obj.getString("color"),
                    route = obj.getString("route"),
                    durationMinutes = obj.getInt("durationMinutes")
                )
            )
        }
        return list
    }

    private fun parseStationsJson(): List<MetroStation> {
        val jsonStr = readAssetString("metro_stations.json") ?: return emptyList()
        val arr = JSONArray(jsonStr)
        val list = mutableListOf<MetroStation>()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            val linesArr = obj.getJSONArray("lines")
            val linesList = mutableListOf<String>()
            for (j in 0 until linesArr.length()) {
                linesList.add(linesArr.getString(j))
            }
            val facArr = obj.getJSONArray("facilities")
            val facList = mutableListOf<String>()
            for (j in 0 until facArr.length()) {
                facList.add(facArr.getString(j))
            }
            list.add(
                MetroStation(
                    id = obj.getString("id"),
                    nameArabic = obj.getString("nameArabic"),
                    code = obj.optString("code", null),
                    lines = linesList,
                    interchange = obj.getBoolean("interchange"),
                    latitude = obj.getDouble("latitude"),
                    longitude = obj.getDouble("longitude"),
                    facilities = facList
                )
            )
        }
        return list
    }

    private fun parseFaresJson(): List<FareProduct> {
        val jsonStr = readAssetString("fares.json") ?: readAssetString("fare_products.json") ?: return emptyList()
        val arr = JSONArray(jsonStr)
        val list = mutableListOf<FareProduct>()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            list.add(
                FareProduct(
                    id = obj.getString("id"),
                    nameArabic = obj.getString("nameArabic"),
                    price = obj.getString("price").toDoubleOrNull() ?: 0.0,
                    descriptionArabic = obj.getString("descriptionArabic")
                )
            )
        }
        return list
    }

    private fun parseArtworksJson(): List<Artwork> {
        val jsonStr = readAssetString("artworks.json") ?: return emptyList()
        val arr = JSONArray(jsonStr)
        val list = mutableListOf<Artwork>()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            list.add(
                Artwork(
                    stationId = obj.getString("stationId"),
                    titleArabic = obj.getString("titleArabic"),
                    artistArabic = obj.getString("artistArabic"),
                    descriptionArabic = obj.getString("descriptionArabic"),
                    locationArabic = obj.getString("locationArabic")
                )
            )
        }
        return list
    }

    private fun parseAlertsJson(): List<DemoAlert> {
        val jsonStr = readAssetString("demo_alerts.json") ?: return emptyList()
        val arr = JSONArray(jsonStr)
        val list = mutableListOf<DemoAlert>()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            list.add(
                DemoAlert(
                    id = obj.getString("id"),
                    titleArabic = obj.getString("titleArabic"),
                    typeArabic = obj.getString("typeArabic"),
                    type = obj.getString("type"),
                    contentArabic = obj.getString("contentArabic"),
                    dateArabic = obj.getString("dateArabic"),
                    isCritical = obj.getBoolean("isCritical")
                )
            )
        }
        return list
    }

    private fun readAssetString(fileName: String): String? {
        return try {
            val inputStream: InputStream = context.assets.open(fileName)
            val size: Int = inputStream.available()
            val buffer = ByteArray(size)
            inputStream.read(buffer)
            inputStream.close()
            String(buffer, Charsets.UTF_8)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun loadFallbacks() {
        lines = listOf(
            MetroLine("blue", "الخط الأزرق", "1", "L1", "#0056B3", "العليا - البطحاء", 35),
            MetroLine("red", "الخط الأحمر", "2", "L2", "#D92D20", "طريق الملك عبدالله", 25),
            MetroLine("orange", "الخط البرتقالي", "3", "L3", "#F79009", "طريق المدينة المنورة", 40),
            MetroLine("yellow", "الخط الأصفر", "4", "L4", "#EAAA08", "طريق مطار الملك خالد الدولي", 30),
            MetroLine("green", "الخط الأخضر", "5", "L5", "#12B76A", "طريق الملك عبدالعزيز", 15),
            MetroLine("purple", "الخط البنفسجي", "6", "L6", "#7A5AF8", "طريق عبد الرحمن بن عوف", 28)
        )
    }

    // --- Getters ---
    fun getLines(): List<MetroLine> = lines.ifEmpty { loadFallbacks(); lines }
    fun getStations(): List<MetroStation> = stations
    fun getFares(): List<FareProduct> = fares
    fun getArtworks(): List<Artwork> = artworks
    fun getAlerts(): List<DemoAlert> = alerts

    fun getStationById(id: String): MetroStation? = getStations().find { it.id == id }
    fun getLineById(id: String): MetroLine? = getLines().find { it.id == id }

    // --- Local DB Bridges ---
    fun getAllTickets(): Flow<List<TicketEntity>> = metroDao.getAllTicketsFlow()
    suspend fun buyTicket(productId: String, originId: String, destinationId: String, lineId: String?, price: Double): TicketEntity {
        val id = "RMT-" + UUID.randomUUID().toString().take(8).uppercase()
        val now = System.currentTimeMillis()
        val ticket = TicketEntity(
            id = id,
            productId = productId,
            origin = getStationById(originId)?.nameArabic ?: originId,
            destination = getStationById(destinationId)?.nameArabic ?: destinationId,
            lineId = lineId,
            purchaseTime = now,
            validFrom = now,
            validUntil = now + (2 * 3600 * 1000), // 2 hours valid
            price = price,
            status = "ACTIVE",
            qrPayload = "RIYADH_METRO_TICKET:$id:$originId:$destinationId"
        )
        metroDao.insertTicket(ticket)
        return ticket
    }

    suspend fun updateTicketStatus(id: String, status: String) {
        metroDao.updateTicketStatus(id, status)
    }

    fun getJourneyHistory(): Flow<List<JourneyHistoryEntity>> = metroDao.getAllJourneysFlow()
    suspend fun addJourneyToHistory(originId: String, destinationId: String, duration: Int, interchanges: Int) {
        val originName = getStationById(originId)?.nameArabic ?: originId
        val destinationName = getStationById(destinationId)?.nameArabic ?: destinationId
        val journey = JourneyHistoryEntity(
            originId = originId,
            originName = originName,
            destinationId = destinationId,
            destinationName = destinationName,
            durationMinutes = duration,
            interchangeCount = interchanges,
            timestamp = System.currentTimeMillis()
        )
        metroDao.insertJourney(journey)
    }

    suspend fun clearJourneyHistory() = metroDao.clearAllJourneys()

    fun getFavoriteStations(): Flow<List<FavoriteStationEntity>> = metroDao.getAllFavoritesFlow()
    suspend fun toggleFavorite(stationId: String, label: String = "مفضلة", isHome: Boolean = false, isWork: Boolean = false) {
        val currentFavs = metroDao.getAllFavoritesFlow()
        // Simple write
        val fav = FavoriteStationEntity(stationId, label, isHome, isWork)
        metroDao.insertFavorite(fav)
    }

    suspend fun removeFavorite(stationId: String) {
        metroDao.deleteFavorite(stationId)
    }

    // --- Graph Routing Engine ---
    // Finds paths and produces FASTEST, LEAST_TRANSFERS, LEAST_WALKING
    fun planRoute(startId: String, endId: String): List<RouteOption> {
        if (startId == endId) return emptyList()

        // Gather all paths between A and B in our small graph to find optimal ones
        val allPaths = mutableListOf<List<PathNode>>()
        findPathsDfs(startId, endId, mutableListOf(), mutableSetOf(), allPaths)

        if (allPaths.isEmpty()) return emptyList()

        // Map paths to RouteOptions
        val options = allPaths.map { pathNodes ->
            buildRouteOption(pathNodes)
        }

        // Distinct by station IDs to remove exact duplicate station paths
        val uniqueOptions = options.distinctBy { opt -> opt.stations.map { it.id } }

        // Compile standard options:
        // 1. FASTEST: sort by duration asc
        val fastest = uniqueOptions.minByOrNull { it.totalDurationMinutes } ?: return emptyList()

        // 2. LEAST_TRANSFERS: sort by transfer count asc, then duration asc
        val leastTransfers = uniqueOptions.minByOrNull { it.transferCount * 1000 + it.totalDurationMinutes } ?: fastest

        // 3. LEAST_WALKING: defined as fewest hops and transfers
        val leastWalking = uniqueOptions.minByOrNull { it.stationCount * 10 + it.transferCount * 15 } ?: fastest

        val result = mutableListOf<RouteOption>()
        result.add(fastest.copy(type = RouteType.FASTEST))

        if (leastTransfers.stations.map { it.id } != fastest.stations.map { it.id }) {
            result.add(leastTransfers.copy(type = RouteType.LEAST_TRANSFERS))
        } else {
            // Add a logical alternative if they are identical
            val alternative = uniqueOptions.filter { it.stations.map { it.id } != fastest.stations.map { it.id } }
                .minByOrNull { it.totalDurationMinutes }
            if (alternative != null) {
                result.add(alternative.copy(type = RouteType.LEAST_TRANSFERS))
            }
        }

        if (leastWalking.stations.map { it.id } != fastest.stations.map { it.id } &&
            leastWalking.stations.map { it.id } != leastTransfers.stations.map { it.id }) {
            result.add(leastWalking.copy(type = RouteType.LEAST_WALKING))
        }

        return result
    }

    private data class PathNode(val stationId: String, val lineId: String)

    private fun findPathsDfs(
        current: String,
        target: String,
        currentPath: MutableList<PathNode>,
        visited: MutableSet<String>,
        allPaths: MutableList<List<PathNode>>
    ) {
        if (current == target) {
            allPaths.add(currentPath.toList())
            return
        }

        visited.add(current)

        // Find neighbors
        val currentStation = getStationById(current) ?: return
        for (lineId in currentStation.lines) {
            val seq = lineSequences[lineId] ?: continue
            val index = seq.indexOf(current)
            if (index == -1) continue

            // Neighbors on this line are at index - 1 and index + 1
            val neighbors = mutableListOf<String>()
            if (index > 0) neighbors.add(seq[index - 1])
            if (index < seq.size - 1) neighbors.add(seq[index + 1])

            for (neighbor in neighbors) {
                if (neighbor !in visited) {
                    currentPath.add(PathNode(neighbor, lineId))
                    findPathsDfs(neighbor, target, currentPath, visited, allPaths)
                    currentPath.removeAt(currentPath.size - 1)
                }
            }
        }

        visited.remove(current)
    }

    private fun buildRouteOption(pathNodes: List<PathNode>): RouteOption {
        // PathNodes has nodes: (stationId, lineId used to get there)
        // Let's build the stations list. It starts with the origin, which isn't in pathNodes directly!
        // Wait, how do we get the origin?
        // We know the first hop node's line. The origin has to be a station serving that line!
        // To be absolutely precise: let's backtrack or find origin station.
        // Let's trace it.
        // Let's determine the starting station. If we have a path of hops, the origin connects to pathNodes[0].stationId
        // Let's find what is adjacent to pathNodes[0].stationId on pathNodes[0].lineId in the sequence
        val firstLineId = pathNodes[0].lineId
        val seq = lineSequences[firstLineId] ?: emptyList()
        val nextIdx = seq.indexOf(pathNodes[0].stationId)
        // Origin must be seq[nextIdx - 1] or seq[nextIdx + 1]
        // Let's look at the remaining path nodes to find the start!
        // Actually, we can just find which neighbor of pathNodes[0] serves firstLineId and wasn't visited.
        // Let's make it simpler: we can represent a path of stations instead.
        // Let's rebuild the station list.
        val stationsList = mutableListOf<MetroStation>()

        // Let's reconstruct the path station IDs.
        // The path starts with the origin of the search. Wait, how do we find the origin of the search?
        // If we know the destination is the last node in pathNodes, we can find the origin!
        // Let's find the origin ID.
        // Let's deduce the origin ID: It's the station adjacent to pathNodes[0].stationId on pathNodes[0].lineId that is NOT in the rest of pathNodes.
        var originId = ""
        val firstNeighborId = pathNodes[0].stationId
        val firstSeq = lineSequences[pathNodes[0].lineId] ?: emptyList()
        val firstNeighborIdx = firstSeq.indexOf(firstNeighborId)
        if (firstNeighborIdx > 0) {
            val possibleOrigin = firstSeq[firstNeighborIdx - 1]
            if (pathNodes.none { it.stationId == possibleOrigin }) {
                originId = possibleOrigin
            }
        }
        if (originId.isEmpty() && firstNeighborIdx < firstSeq.size - 1) {
            val possibleOrigin = firstSeq[firstNeighborIdx + 1]
            if (pathNodes.none { it.stationId == possibleOrigin }) {
                originId = possibleOrigin
            }
        }
        // If still empty (very rare), just pick first neighbor's other neighbor
        if (originId.isEmpty()) {
            originId = if (firstNeighborIdx > 0) firstSeq[firstNeighborIdx - 1] else firstSeq[firstNeighborIdx + 1]
        }

        getStationById(originId)?.let { stationsList.add(it) }
        for (node in pathNodes) {
            getStationById(node.stationId)?.let { stationsList.add(it) }
        }

        // Now build segments and compute duration
        val segments = mutableListOf<RouteSegment>()
        var currentLineId = pathNodes[0].lineId
        var segmentStartId = originId
        val intermediate = mutableListOf<String>()

        var totalTime = 0
        var transfers = 0

        // Calculate hop by hop
        for (i in 0 until pathNodes.size) {
            val node = pathNodes[i]
            val prevStationId = if (i == 0) originId else pathNodes[i - 1].stationId
            val currentStationId = node.stationId

            // Add hop time
            val hopKey1 = "$prevStationId-$currentStationId"
            val hopKey2 = "$currentStationId-$prevStationId"
            val hopTime = hopTimes[hopKey1] ?: hopTimes[hopKey2] ?: 5
            totalTime += hopTime

            if (node.lineId != currentLineId) {
                // Line changed! Finish old segment
                segments.add(
                    RouteSegment(
                        lineId = currentLineId,
                        fromStationId = segmentStartId,
                        toStationId = prevStationId,
                        intermediateStationIds = intermediate.toList()
                    )
                )
                transfers++
                currentLineId = node.lineId
                segmentStartId = prevStationId
                intermediate.clear()
            }

            if (i > 0 && node.lineId == currentLineId) {
                intermediate.add(prevStationId)
            }
        }

        // Add final segment
        segments.add(
            RouteSegment(
                lineId = currentLineId,
                fromStationId = segmentStartId,
                toStationId = pathNodes.last().stationId,
                intermediateStationIds = intermediate.toList()
            )
        )

        // Add transfer penalty (e.g. 4 minutes per transfer)
        totalTime += transfers * 4

        return RouteOption(
            type = RouteType.FASTEST,
            stations = stationsList,
            pathSegments = segments,
            totalDurationMinutes = totalTime,
            transferCount = transfers,
            stationCount = stationsList.size
        )
    }
}
