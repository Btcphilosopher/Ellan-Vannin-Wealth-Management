package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tickets")
data class TicketEntity(
    @PrimaryKey val id: String,
    val productId: String,
    val origin: String,
    val destination: String,
    val lineId: String?,
    val purchaseTime: Long,
    val validFrom: Long,
    val validUntil: Long?,
    val price: Double,
    val status: String, // ACTIVE, UPCOMING, EXPIRED, CANCELLED
    val qrPayload: String
)

@Entity(tableName = "journey_history")
data class JourneyHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val originId: String,
    val originName: String,
    val destinationId: String,
    val destinationName: String,
    val durationMinutes: Int,
    val interchangeCount: Int,
    val timestamp: Long
)

@Entity(tableName = "favorite_stations")
data class FavoriteStationEntity(
    @PrimaryKey val stationId: String,
    val labelArabic: String, // "المنزل"، "العمل"، "مفضلة"
    val isHome: Boolean = false,
    val isWork: Boolean = false
)
