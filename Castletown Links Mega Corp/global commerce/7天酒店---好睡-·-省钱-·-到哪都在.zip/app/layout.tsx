import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: '7天酒店 - 好睡 · 省钱 · 到哪都在',
  description: '7天酒店官方预订平台。提供全国500+分店经济大床房、标准双床房、家庭房实时房态查询、快捷在线预订与会员专享优惠。',
  openGraph: {
    title: '7天酒店 - 好睡 · 省钱 · 到哪都在',
    description: '7天酒店官方预订平台。提供全国500+分店经济大床房、标准双床房、家庭房实时房态查询、快捷在线预订与会员专享优惠。',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: '7天酒店 - 好睡 · 省钱 · 到哪都在',
    description: '7天酒店官方预订平台。提供全国500+分店经济大床房、标准双床房、家庭房实时房态查询、快捷在线预订与会员专享优惠。',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="zh-CN">
      <head>
        <link rel="icon" href="/images/hotel_hero.jpg" />
        <meta name="theme-color" content="#111827" />
      </head>
      <body suppressHydrationWarning className="antialiased bg-slate-50 text-slate-900">
        {children}
      </body>
    </html>
  );
}
