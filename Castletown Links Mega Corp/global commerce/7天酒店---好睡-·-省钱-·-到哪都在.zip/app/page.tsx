'use client';

import React, { useState, useEffect } from 'react';
import { Header } from '../components/Header';
import { Hero } from '../components/Hero';
import { ValueBar } from '../components/ValueBar';
import { FeaturedRooms } from '../components/FeaturedRooms';
import { PromoCards } from '../components/PromoCards';
import { Footer } from '../components/Footer';
import { HotelListingView } from '../components/HotelListingView';
import { BookingModal } from '../components/BookingModal';
import { BookingLookupModal } from '../components/BookingLookupModal';
import { AdminPortal } from '../components/AdminPortal';
import { MemberModal } from '../components/MemberModal';
import { InfoModals } from '../components/InfoModals';
import { Language } from '../lib/i18n';
import { Hotel, RoomType, Reservation, UserRole } from '../lib/types';
import { bookingEngine } from '../lib/store';

export default function HomePage() {
  const [currentLang, setCurrentLang] = useState<Language>('zh');
  const [activeNav, setActiveNav] = useState('home');
  const [userRole, setUserRole] = useState<UserRole>('GUEST');

  // Search Parameters
  const [destination, setDestination] = useState('上海');
  const [checkInDate, setCheckInDate] = useState('2026-10-13');
  const [checkOutDate, setCheckOutDate] = useState('2026-10-14');
  const [roomsCount, setRoomsCount] = useState(1);
  const [adultsCount, setAdultsCount] = useState(1);

  // Modals & Navigation Views
  const [showListingView, setShowListingView] = useState(false);
  const [bookingModalState, setBookingModalState] = useState<{
    isOpen: boolean;
    hotel: Hotel | null;
    room: RoomType | null;
  }>({
    isOpen: false,
    hotel: null,
    room: null,
  });

  const [showLookupModal, setShowLookupModal] = useState(false);
  const [showMemberModal, setShowMemberModal] = useState(false);
  const [infoModalType, setInfoModalType] = useState<'ABOUT' | 'HELP' | 'APP' | 'TERMS' | null>(null);

  const hotels = bookingEngine.getHotels();
  const primaryHotel = hotels[0]; // Shanghai Bund & Nanjing Road branch matching hero view

  // Handle Search click
  const handleSearch = () => {
    setShowListingView(true);
    setActiveNav('reservation');
  };

  // Open booking modal for a specific room
  const handleStartBooking = (room: RoomType, hotelOverride?: Hotel) => {
    const targetHotel = hotelOverride || primaryHotel;
    setBookingModalState({
      isOpen: true,
      hotel: targetHotel,
      room,
    });
  };

  // Navigation click
  const handleNavClick = (navKey: string) => {
    setActiveNav(navKey);
    if (navKey === 'home') {
      setShowListingView(false);
    } else if (navKey === 'reservation') {
      setShowListingView(true);
    } else if (navKey === 'about') {
      setInfoModalType('ABOUT');
    } else if (navKey === 'help') {
      setInfoModalType('HELP');
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 font-sans selection:bg-[#FACC15] selection:text-slate-950">
      {/* Hotel Administration PMS Mode (Full-screen for staff) */}
      {userRole !== 'GUEST' && activeNav === 'admin' ? (
        <AdminPortal
          currentLang={currentLang}
          userRole={userRole}
          onRoleChange={setUserRole}
          onExitAdmin={() => {
            setActiveNav('home');
            setShowListingView(false);
          }}
        />
      ) : (
        <>
          {/* Main Top Header matching design */}
          <Header
            currentLang={currentLang}
            onLanguageChange={setCurrentLang}
            activeNav={activeNav}
            onNavClick={handleNavClick}
            userRole={userRole}
            onRoleChange={setUserRole}
            onOpenLookup={() => setShowLookupModal(true)}
            onOpenMemberModal={() => setShowMemberModal(true)}
          />

          {/* Conditional View: Home Page or Hotel Search Results Listing */}
          <main className="flex-1">
            {showListingView ? (
              <HotelListingView
                currentLang={currentLang}
                hotels={hotels}
                searchCity={destination}
                checkInDate={checkInDate}
                checkOutDate={checkOutDate}
                roomsCount={roomsCount}
                adultsCount={adultsCount}
                onSelectRoom={(hotel, room) => handleStartBooking(room, hotel)}
                onBackToHome={() => {
                  setShowListingView(false);
                  setActiveNav('home');
                }}
              />
            ) : (
              <>
                {/* 1. Hero Section with Background Bedroom & Floating Search Bar */}
                <Hero
                  currentLang={currentLang}
                  destination={destination}
                  setDestination={setDestination}
                  checkInDate={checkInDate}
                  setCheckInDate={setCheckInDate}
                  checkOutDate={checkOutDate}
                  setCheckOutDate={setCheckOutDate}
                  roomsCount={roomsCount}
                  setRoomsCount={setRoomsCount}
                  adultsCount={adultsCount}
                  setAdultsCount={setAdultsCount}
                  onSearch={handleSearch}
                />

                {/* 2. Value Proposition Strip (5 Trust Propositions) */}
                <ValueBar currentLang={currentLang} />

                {/* 3. Featured Room Types (3 Cards + 1 Tall Nationwide 500+ Branch Banner) */}
                <FeaturedRooms
                  currentLang={currentLang}
                  hotel={primaryHotel}
                  onBookRoom={(room) => handleStartBooking(room, primaryHotel)}
                  onViewAllRooms={handleSearch}
                />

                {/* 4. Bottom Promotional Cards Row (Member Exclusive, Popular Cities Map, App Download) */}
                <PromoCards
                  currentLang={currentLang}
                  onJoinMember={() => setShowMemberModal(true)}
                  onSelectCity={(city) => {
                    setDestination(city);
                    setShowListingView(true);
                  }}
                  onOpenAppModal={() => setInfoModalType('APP')}
                />
              </>
            )}
          </main>

          {/* Footer matching design */}
          <Footer
            currentLang={currentLang}
            onOpenAbout={() => setInfoModalType('ABOUT')}
            onOpenHelp={() => setInfoModalType('HELP')}
            onOpenTerms={() => setInfoModalType('TERMS')}
          />
        </>
      )}

      {/* Interactive Booking Modal with Concurrency-safe Hold and Payment Simulator */}
      {bookingModalState.isOpen && bookingModalState.hotel && bookingModalState.room && (
        <BookingModal
          currentLang={currentLang}
          hotel={bookingModalState.hotel}
          room={bookingModalState.room}
          checkInDate={checkInDate}
          checkOutDate={checkOutDate}
          roomsCount={roomsCount}
          adultsCount={adultsCount}
          onClose={() => setBookingModalState({ isOpen: false, hotel: null, room: null })}
          onBookingConfirmed={(res) => {
            console.log('Confirmed reservation:', res);
          }}
        />
      )}

      {/* Self-Service Booking Lookup Modal */}
      {showLookupModal && (
        <BookingLookupModal
          currentLang={currentLang}
          onClose={() => setShowLookupModal(false)}
        />
      )}

      {/* Member Center Loyalty Modal */}
      {showMemberModal && (
        <MemberModal
          currentLang={currentLang}
          onClose={() => setShowMemberModal(false)}
        />
      )}

      {/* Informational & Policy Modals */}
      <InfoModals
        type={infoModalType}
        currentLang={currentLang}
        onClose={() => setInfoModalType(null)}
      />
    </div>
  );
}
