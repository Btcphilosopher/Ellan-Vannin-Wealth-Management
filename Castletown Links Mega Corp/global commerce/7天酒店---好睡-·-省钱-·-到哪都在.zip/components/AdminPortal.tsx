'use client';

import React, { useState } from 'react';
import { Language, translations } from '../lib/i18n';
import { UserRole, Reservation, Hotel } from '../lib/types';
import { bookingEngine } from '../lib/store';
import { 
  Building2, Users, BedDouble, DollarSign, CalendarCheck, 
  Search, Shield, CheckCircle2, LogOut, ArrowRight, Wrench, 
  FileText, TrendingUp, AlertTriangle, KeyRound, Sparkles
} from 'lucide-react';

interface AdminPortalProps {
  currentLang: Language;
  userRole: UserRole;
  onRoleChange: (role: UserRole) => void;
  onExitAdmin: () => void;
}

export function AdminPortal({
  currentLang,
  userRole,
  onRoleChange,
  onExitAdmin,
}: AdminPortalProps) {
  const t = translations[currentLang];
  const hotels = bookingEngine.getHotels();
  const [selectedHotelId, setSelectedHotelId] = useState<string>(hotels[0]?.id || '');
  const [activeTab, setActiveTab] = useState<'RESERVATIONS' | 'RACK_PMS' | 'RATES' | 'AUDIT'>('RESERVATIONS');
  
  // Search and filter for reservations
  const [resSearch, setResSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  
  // State for room assignment modal
  const [checkInModalRes, setCheckInModalRes] = useState<Reservation | null>(null);
  const [assignedRoomNumber, setAssignedRoomNumber] = useState('302');

  // Pricing update state
  const [editingPriceRoomId, setEditingPriceRoomId] = useState<string | null>(null);
  const [newPriceInput, setNewPriceInput] = useState<number>(148);

  // Operational metrics
  const metrics = bookingEngine.getOperationalMetrics(selectedHotelId);
  const allReservations = bookingEngine.getAllReservations();
  const auditLogs = bookingEngine.getAuditLogs();

  // Filter reservations by selected hotel and query
  const filteredReservations = allReservations.filter((res) => {
    if (selectedHotelId && res.hotelId !== selectedHotelId) return false;
    if (statusFilter !== 'ALL' && res.status !== statusFilter) return false;
    if (resSearch) {
      const q = resSearch.toLowerCase();
      return (
        res.id.toLowerCase().includes(q) ||
        res.guestName.toLowerCase().includes(q) ||
        res.guestPhone.includes(q) ||
        (res.assignedRoomNumber && res.assignedRoomNumber.includes(q))
      );
    }
    return true;
  });

  const handleExecuteCheckIn = () => {
    if (!checkInModalRes) return;
    bookingEngine.checkInGuest(checkInModalRes.id, assignedRoomNumber, `${userRole}_STAFF`);
    setCheckInModalRes(null);
  };

  const handleExecuteCheckOut = (resId: string) => {
    bookingEngine.checkOutGuest(resId, `${userRole}_STAFF`);
  };

  const handleSavePrice = (roomTypeId: string) => {
    bookingEngine.updateRoomPrice(selectedHotelId, roomTypeId, newPriceInput, `${userRole}_STAFF`);
    setEditingPriceRoomId(null);
  };

  const currentHotel = hotels.find(h => h.id === selectedHotelId) || hotels[0];

  return (
    <div className="bg-slate-100 min-h-screen text-slate-800 pb-16">
      {/* Admin Top Header */}
      <div className="bg-[#111827] text-white border-b border-slate-800 px-4 sm:px-6 py-3">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-[#FACC15] text-slate-950 font-black text-lg flex items-center justify-center">
              7
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-sm tracking-tight text-white">
                  7天酒店 · 智慧酒店运营管理系统 (PMS)
                </span>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-semibold px-2 py-0.5 rounded-full">
                  实时在线
                </span>
              </div>
              <span className="text-xs text-slate-400">
                当前角色: {userRole} · 门店: {currentHotel?.name}
              </span>
            </div>
          </div>

          {/* Quick Role & Exit Switcher */}
          <div className="flex items-center gap-3">
            <div className="flex items-center bg-slate-800 rounded-lg p-1 border border-slate-700 text-xs">
              <span className="text-slate-400 px-2 font-medium">权限:</span>
              {(['FRONT_DESK', 'HOTEL_MANAGER', 'ADMIN'] as UserRole[]).map((role) => (
                <button
                  key={role}
                  onClick={() => onRoleChange(role)}
                  className={`px-2.5 py-1 rounded-md font-medium transition cursor-pointer ${
                    userRole === role
                      ? 'bg-[#FACC15] text-slate-950 font-bold shadow-xs'
                      : 'text-slate-300 hover:text-white'
                  }`}
                >
                  {role === 'FRONT_DESK' ? '前台' : role === 'HOTEL_MANAGER' ? '店长' : '系统管理员'}
                </button>
              ))}
            </div>

            <button
              onClick={onExitAdmin}
              className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs px-3 py-1.5 rounded-lg border border-slate-700 flex items-center gap-1.5 cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>返回前台网站</span>
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6">
        {/* Branch Selector & Overview KPI Cards */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div className="flex items-center gap-2">
            <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">切换管理门店:</label>
            <select
              value={selectedHotelId}
              onChange={(e) => setSelectedHotelId(e.target.value)}
              className="text-xs font-semibold bg-white border border-slate-300 rounded-lg px-3 py-2 text-slate-900 cursor-pointer shadow-2xs focus:outline-none"
            >
              {hotels.map((h) => (
                <option key={h.id} value={h.id}>{h.name} ({h.city})</option>
              ))}
            </select>
          </div>

          <div className="text-xs text-slate-500">
            营业日: <span className="font-semibold text-slate-900">2026-10-13 (今日)</span>
          </div>
        </div>

        {/* 4 Primary Operational Metrics KPIs */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-2xs">
            <div className="flex items-center justify-between text-slate-500 text-xs">
              <span>今日实时入住率</span>
              <BedDouble className="w-4 h-4 text-amber-500" />
            </div>
            <div className="text-2xl font-black text-slate-900 mt-2 tabular-nums">
              {metrics.occupancyRate}%
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              在住 {metrics.occupiedRooms} 间 / 总房量 {metrics.totalPhysicalRooms} 间
            </div>
          </div>

          <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-2xs">
            <div className="flex items-center justify-between text-slate-500 text-xs">
              <span>今日预计到店 / 离店</span>
              <CalendarCheck className="w-4 h-4 text-emerald-500" />
            </div>
            <div className="text-2xl font-black text-slate-900 mt-2 tabular-nums">
              {metrics.todayArrivalsCount} / {metrics.todayDeparturesCount}
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              待办理预订已在列表中标出
            </div>
          </div>

          <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-2xs">
            <div className="flex items-center justify-between text-slate-500 text-xs">
              <span>平均每日房价 (ADR)</span>
              <DollarSign className="w-4 h-4 text-blue-500" />
            </div>
            <div className="text-2xl font-black text-slate-900 mt-2 tabular-nums">
              ¥{metrics.adr}
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              RevPAR (每房收益): ¥{metrics.revpar}
            </div>
          </div>

          <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-2xs">
            <div className="flex items-center justify-between text-slate-500 text-xs">
              <span>今日累计客房收入</span>
              <TrendingUp className="w-4 h-4 text-purple-500" />
            </div>
            <div className="text-2xl font-black text-slate-900 mt-2 tabular-nums">
              ¥{metrics.totalRevenue}
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              含已收微信/支付宝/银联款项
            </div>
          </div>
        </div>

        {/* Administration Navigation Tabs */}
        <div className="bg-white rounded-xl shadow-2xs border border-slate-200 mb-6">
          <div className="flex border-b border-slate-200 px-4">
            <button
              onClick={() => setActiveTab('RESERVATIONS')}
              className={`py-3 px-4 text-xs font-bold border-b-2 transition cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'RESERVATIONS'
                  ? 'border-amber-500 text-amber-600'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>预订与在住订单管理 ({filteredReservations.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('RACK_PMS')}
              className={`py-3 px-4 text-xs font-bold border-b-2 transition cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'RACK_PMS'
                  ? 'border-amber-500 text-amber-600'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <BedDouble className="w-4 h-4" />
              <span>前台物理房态看板 (PMS)</span>
            </button>

            <button
              onClick={() => setActiveTab('RATES')}
              className={`py-3 px-4 text-xs font-bold border-b-2 transition cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'RATES'
                  ? 'border-amber-500 text-amber-600'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <DollarSign className="w-4 h-4" />
              <span>房型库存与基准房价维护</span>
            </button>

            <button
              onClick={() => setActiveTab('AUDIT')}
              className={`py-3 px-4 text-xs font-bold border-b-2 transition cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'AUDIT'
                  ? 'border-amber-500 text-amber-600'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <FileText className="w-4 h-4" />
              <span>合规审计操作日志 ({auditLogs.length})</span>
            </button>
          </div>

          {/* TAB 1: Reservations Table */}
          {activeTab === 'RESERVATIONS' && (
            <div className="p-4 sm:p-6">
              {/* Filter controls */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
                <div className="flex items-center gap-2">
                  <div className="relative">
                    <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      placeholder="搜索姓名 / 手机号 / 订单号 / 房号..."
                      value={resSearch}
                      onChange={(e) => setResSearch(e.target.value)}
                      className="text-xs bg-slate-50 border border-slate-200 rounded-lg pl-8 pr-3 py-1.5 text-slate-800 focus:outline-none w-64"
                    />
                  </div>

                  <select
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                    className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-700 cursor-pointer"
                  >
                    <option value="ALL">全部状态</option>
                    <option value="CONFIRMED">已确认 (待到店)</option>
                    <option value="CHECKED_IN">在住中</option>
                    <option value="CHECKED_OUT">已离店</option>
                    <option value="CANCELLED">已取消</option>
                  </select>
                </div>
              </div>

              {/* Table */}
              <div className="overflow-x-auto border border-slate-200 rounded-xl">
                <table className="w-full text-xs text-left">
                  <thead className="bg-slate-50 text-slate-500 border-b border-slate-200">
                    <tr>
                      <th className="px-4 py-3 font-semibold">预订编号</th>
                      <th className="px-4 py-3 font-semibold">住客姓名 / 电话</th>
                      <th className="px-4 py-3 font-semibold">预订房型</th>
                      <th className="px-4 py-3 font-semibold">入住 / 离店日期</th>
                      <th className="px-4 py-3 font-semibold">房号</th>
                      <th className="px-4 py-3 font-semibold">金额 / 支付</th>
                      <th className="px-4 py-3 font-semibold">状态</th>
                      <th className="px-4 py-3 font-semibold text-right">前台操作</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {filteredReservations.length === 0 ? (
                      <tr>
                        <td colSpan={8} className="text-center py-8 text-slate-400">
                          暂无符合条件的预订记录
                        </td>
                      </tr>
                    ) : (
                      filteredReservations.map((res) => (
                        <tr key={res.id} className="hover:bg-slate-50/80">
                          <td className="px-4 py-3 font-mono font-bold text-slate-900">
                            {res.id}
                          </td>
                          <td className="px-4 py-3">
                            <div className="font-semibold text-slate-900">{res.guestName}</div>
                            <div className="text-[11px] text-slate-500">{res.guestPhone}</div>
                          </td>
                          <td className="px-4 py-3">
                            <span className="font-medium text-slate-800">{res.roomTypeName}</span>
                            <span className="text-[11px] text-slate-400 block">{res.ratePlanName}</span>
                          </td>
                          <td className="px-4 py-3">
                            <div className="text-slate-800 font-medium">{res.checkInDate} 至 {res.checkOutDate}</div>
                            <div className="text-[11px] text-slate-400">{res.nights}晚 · {res.roomsCount}间</div>
                          </td>
                          <td className="px-4 py-3">
                            {res.assignedRoomNumber ? (
                              <span className="bg-amber-100 text-amber-900 font-bold px-2 py-0.5 rounded text-[11px]">
                                #{res.assignedRoomNumber}
                              </span>
                            ) : (
                              <span className="text-slate-400 text-[11px]">未分房</span>
                            )}
                          </td>
                          <td className="px-4 py-3">
                            <div className="font-bold text-slate-900 tabular-nums">¥{res.totalAmount}</div>
                            <div className="text-[10px] text-emerald-600 font-medium">{res.paymentStatus} · {res.paymentMethod || '微信'}</div>
                          </td>
                          <td className="px-4 py-3">
                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              res.status === 'CONFIRMED'
                                ? 'bg-amber-100 text-amber-800'
                                : res.status === 'CHECKED_IN'
                                ? 'bg-emerald-100 text-emerald-800'
                                : res.status === 'CHECKED_OUT'
                                ? 'bg-slate-100 text-slate-600'
                                : 'bg-rose-100 text-rose-700'
                            }`}>
                              {res.status === 'CONFIRMED' && '待到店'}
                              {res.status === 'CHECKED_IN' && '已入住'}
                              {res.status === 'CHECKED_OUT' && '已退房'}
                              {res.status === 'CANCELLED' && '已取消'}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-right">
                            {res.status === 'CONFIRMED' && (
                              <button
                                onClick={() => {
                                  setCheckInModalRes(res);
                                  setAssignedRoomNumber('302');
                                }}
                                className="bg-[#FACC15] hover:bg-[#EAB308] text-slate-950 font-bold px-2.5 py-1 rounded text-xs cursor-pointer shadow-2xs"
                              >
                                办理入住
                              </button>
                            )}
                            {res.status === 'CHECKED_IN' && (
                              <button
                                onClick={() => handleExecuteCheckOut(res.id)}
                                className="bg-slate-800 hover:bg-slate-700 text-white px-2.5 py-1 rounded text-xs cursor-pointer"
                              >
                                快速退房
                              </button>
                            )}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 2: Physical Room Rack PMS */}
          {activeTab === 'RACK_PMS' && (
            <div className="p-4 sm:p-6">
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-bold text-slate-600">物理客房状态矩阵 (楼层 2F - 5F)</span>
                <div className="flex items-center gap-3 text-xs">
                  <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded bg-emerald-500"></span> 空房干净</span>
                  <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded bg-amber-500"></span> 在住占用</span>
                  <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded bg-slate-300"></span> 维修工程</span>
                </div>
              </div>

              {/* Sample 20 Rooms Rack Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 gap-3">
                {[
                  { num: '201', type: '经济大床', status: 'CLEAN' },
                  { num: '202', type: '经济大床', status: 'OCCUPIED', guest: '张建国' },
                  { num: '203', type: '经济大床', status: 'CLEAN' },
                  { num: '205', type: '标准双床', status: 'MAINTENANCE' },
                  { num: '301', type: '标准双床', status: 'CLEAN' },
                  { num: '302', type: '标准双床', status: 'CLEAN' },
                  { num: '305', type: '标准双床', status: 'OCCUPIED', guest: '李明伟' },
                  { num: '308', type: '家庭房', status: 'CLEAN' },
                  { num: '401', type: '家庭房', status: 'CLEAN' },
                  { num: '402', type: '商务大床', status: 'CLEAN' },
                ].map((room) => (
                  <div
                    key={room.num}
                    className={`p-3 rounded-xl border flex flex-col justify-between min-h-[90px] ${
                      room.status === 'OCCUPIED'
                        ? 'border-amber-400 bg-amber-50/50'
                        : room.status === 'MAINTENANCE'
                        ? 'border-slate-300 bg-slate-100 text-slate-400'
                        : 'border-emerald-300 bg-emerald-50/30'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-sm text-slate-900">#{room.num}</span>
                      <span className="text-[10px] text-slate-500">{room.type}</span>
                    </div>

                    <div className="text-xs mt-2">
                      {room.status === 'OCCUPIED' && (
                        <span className="text-amber-800 font-semibold">在住: {room.guest}</span>
                      )}
                      {room.status === 'CLEAN' && (
                        <span className="text-emerald-700 font-medium">空房可分配</span>
                      )}
                      {room.status === 'MAINTENANCE' && (
                        <span className="text-slate-500">水管检修中</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: Rates and Inventory Maintenance */}
          {activeTab === 'RATES' && (
            <div className="p-4 sm:p-6 space-y-6">
              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <table className="w-full text-xs text-left">
                  <thead className="bg-slate-50 text-slate-500 border-b border-slate-200">
                    <tr>
                      <th className="px-4 py-3 font-semibold">房型名称</th>
                      <th className="px-4 py-3 font-semibold">物理总间数</th>
                      <th className="px-4 py-3 font-semibold">今日可用库存</th>
                      <th className="px-4 py-3 font-semibold">基准直销单价</th>
                      <th className="px-4 py-3 font-semibold text-right">调价与维护</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {currentHotel.roomTypes.map((r) => {
                      const avail = bookingEngine.getAvailableRooms(
                        currentHotel.id,
                        r.id,
                        '2026-10-13',
                        '2026-10-14'
                      );
                      const isEditing = editingPriceRoomId === r.id;

                      return (
                        <tr key={r.id} className="hover:bg-slate-50/60">
                          <td className="px-4 py-3 font-bold text-slate-900">
                            {r.name}
                            <span className="text-[11px] text-slate-400 block font-normal">{r.bedInfo}</span>
                          </td>
                          <td className="px-4 py-3 font-semibold text-slate-700">{r.totalRooms} 间</td>
                          <td className="px-4 py-3">
                            <span className="bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded text-[11px]">
                              {avail} 间可订
                            </span>
                          </td>
                          <td className="px-4 py-3">
                            {isEditing ? (
                              <div className="flex items-center gap-1.5">
                                <span className="font-bold">¥</span>
                                <input
                                  type="number"
                                  value={newPriceInput}
                                  onChange={(e) => setNewPriceInput(Number(e.target.value))}
                                  className="w-20 bg-white border border-slate-300 rounded px-2 py-1 text-xs font-bold"
                                />
                              </div>
                            ) : (
                              <span className="font-bold text-base text-amber-500 tabular-nums">
                                ¥{r.basePrice}
                              </span>
                            )}
                          </td>
                          <td className="px-4 py-3 text-right">
                            {isEditing ? (
                              <div className="flex items-center justify-end gap-1.5">
                                <button
                                  onClick={() => handleSavePrice(r.id)}
                                  className="bg-emerald-600 hover:bg-emerald-700 text-white px-2.5 py-1 rounded text-xs font-bold cursor-pointer"
                                >
                                  保存
                                </button>
                                <button
                                  onClick={() => setEditingPriceRoomId(null)}
                                  className="bg-slate-200 text-slate-700 px-2.5 py-1 rounded text-xs cursor-pointer"
                                >
                                  取消
                                </button>
                              </div>
                            ) : (
                              <button
                                onClick={() => {
                                  setEditingPriceRoomId(r.id);
                                  setNewPriceInput(r.basePrice);
                                }}
                                className="text-xs bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold px-2.5 py-1 rounded cursor-pointer"
                              >
                                调整售价
                              </button>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 4: Audit Logs */}
          {activeTab === 'AUDIT' && (
            <div className="p-4 sm:p-6">
              <div className="space-y-2">
                {auditLogs.map((log) => (
                  <div
                    key={log.id}
                    className="p-3 rounded-lg border border-slate-200 bg-slate-50 flex items-start justify-between text-xs gap-3"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-800 font-mono">{log.action}</span>
                        <span className="text-[10px] bg-slate-200 text-slate-600 px-1.5 py-0.2 rounded font-medium">
                          操作人: {log.actor}
                        </span>
                      </div>
                      <p className="text-slate-600 mt-1">{log.details}</p>
                    </div>

                    <span className="text-[11px] text-slate-400 font-mono shrink-0">
                      {new Date(log.timestamp).toLocaleTimeString()}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Front Desk Check-in Physical Room Modal */}
      {checkInModalRes && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl p-6 w-full max-w-md border border-slate-200">
            <h3 className="text-base font-bold text-slate-900 mb-1">办理前台入住与发卡</h3>
            <p className="text-xs text-slate-500 mb-4">
              订单号: {checkInModalRes.id} · 住客: {checkInModalRes.guestName}
            </p>

            <div className="space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  分配物理房间号:
                </label>
                <input
                  type="text"
                  value={assignedRoomNumber}
                  onChange={(e) => setAssignedRoomNumber(e.target.value)}
                  placeholder="如: 302, 508"
                  className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-900 font-bold focus:outline-none focus:border-[#FACC15]"
                />
              </div>

              <div className="bg-amber-50 p-3 rounded-lg border border-amber-200 text-xs text-amber-800">
                核对住客二代身份证原件并已录入公安旅馆业信息系统。
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  onClick={handleExecuteCheckIn}
                  className="flex-1 bg-[#FACC15] hover:bg-[#EAB308] text-slate-950 font-bold py-2 rounded-lg text-xs cursor-pointer"
                >
                  确认入住并制卡
                </button>
                <button
                  onClick={() => setCheckInModalRes(null)}
                  className="bg-slate-200 text-slate-700 px-4 py-2 rounded-lg text-xs cursor-pointer"
                >
                  取消
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
