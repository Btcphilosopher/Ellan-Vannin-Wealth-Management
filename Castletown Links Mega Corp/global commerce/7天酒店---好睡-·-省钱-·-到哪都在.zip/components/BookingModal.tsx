'use client';

import React, { useState, useEffect } from 'react';
import { Language, translations } from '../lib/i18n';
import { Hotel, RoomType, RatePlan, Reservation, PaymentMethod } from '../lib/types';
import { bookingEngine } from '../lib/store';
import { 
  X, Check, AlertCircle, Clock, ShieldCheck, CreditCard, 
  QrCode, Printer, CheckCircle, ArrowRight, Sparkles 
} from 'lucide-react';

interface BookingModalProps {
  currentLang: Language;
  hotel: Hotel;
  room: RoomType;
  checkInDate: string;
  checkOutDate: string;
  roomsCount: number;
  adultsCount: number;
  onClose: () => void;
  onBookingConfirmed: (reservation: Reservation) => void;
}

export function BookingModal({
  currentLang,
  hotel,
  room,
  checkInDate,
  checkOutDate,
  roomsCount,
  adultsCount,
  onClose,
  onBookingConfirmed,
}: BookingModalProps) {
  const t = translations[currentLang];

  // Steps: 1: Rate & Guest Details, 2: Payment & Hold, 3: Confirmation
  const [step, setStep] = useState<1 | 2 | 3>(1);

  // Selected rate plan
  const [selectedRatePlan, setSelectedRatePlan] = useState<RatePlan>(room.ratePlans[0]);

  // Guest inputs
  const [guestName, setGuestName] = useState('王小明');
  const [guestPhone, setGuestPhone] = useState('13800138000');
  const [guestIdCard, setGuestIdCard] = useState('310101199508182345');
  const [specialRequests, setSpecialRequests] = useState('尽量高楼层无烟房');
  const [formError, setFormError] = useState<string | null>(null);

  // Temporary Hold & Reservation State
  const [heldReservation, setHeldReservation] = useState<Reservation | null>(null);
  const [holdTimeLeftSeconds, setHoldTimeLeftSeconds] = useState(300); // 5 minutes
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<PaymentMethod>('WECHAT');
  const [paymentLoading, setPaymentLoading] = useState(false);
  const [confirmedReservation, setConfirmedReservation] = useState<Reservation | null>(null);

  // Calculate nights
  const dIn = new Date(checkInDate);
  const dOut = new Date(checkOutDate);
  const diffTime = Math.max(1, Math.round((dOut.getTime() - dIn.getTime()) / (1000 * 60 * 60 * 24)));
  const nights = isNaN(diffTime) ? 1 : diffTime;

  // Live price calculation
  const priceCalc = bookingEngine.calculateStayPrice(
    room.basePrice,
    selectedRatePlan.priceDiscountMultiplier,
    selectedRatePlan.fixedDiscount,
    nights,
    roomsCount
  );

  // Timer countdown for temporary hold
  useEffect(() => {
    if (step !== 2) return;
    const interval = setInterval(() => {
      setHoldTimeLeftSeconds((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          setFormError('支付超时，房间临时保留已释放。请重新提交预订。');
          setStep(1);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [step]);

  // Handle proceeding from Step 1 to Step 2 (Create Hold)
  const handleProceedToPayment = () => {
    setFormError(null);

    if (!guestName.trim()) {
      setFormError('请输入入住人姓名');
      return;
    }
    if (!guestPhone.trim() || guestPhone.length < 8) {
      setFormError('请输入有效的联系手机号码');
      return;
    }
    if (!guestIdCard.trim()) {
      setFormError('请输入身份证或护照号');
      return;
    }

    // Create temporary inventory hold
    const holdResult = bookingEngine.createRoomHold({
      hotelId: hotel.id,
      roomTypeId: room.id,
      ratePlanId: selectedRatePlan.id,
      checkInDate,
      checkOutDate,
      nights,
      roomsCount,
      adultsCount,
      guestName: guestName.trim(),
      guestPhone: guestPhone.trim(),
      guestIdCard: guestIdCard.trim(),
      specialRequests: specialRequests.trim(),
    });

    if (!holdResult.success || !holdResult.reservation) {
      setFormError(holdResult.message || '房间库存不足，请选择其他房型');
      return;
    }

    setHeldReservation(holdResult.reservation);
    setHoldTimeLeftSeconds(300); // 5 mins
    setStep(2);
  };

  // Handle Payment Callback Simulation
  const handleSimulatePayment = (success: boolean) => {
    if (!heldReservation) return;
    setPaymentLoading(true);

    setTimeout(() => {
      setPaymentLoading(false);
      if (!success) {
        setFormError('支付遇到异常或用户取消。房间仍处于5分钟保留期内，您可更换支付方式重新支付。');
        return;
      }

      const confirmResult = bookingEngine.confirmReservation(
        heldReservation.id,
        selectedPaymentMethod
      );

      if (confirmResult.success && confirmResult.reservation) {
        setConfirmedReservation(confirmResult.reservation);
        setStep(3);
        onBookingConfirmed(confirmResult.reservation);
      } else {
        setFormError(confirmResult.message || '确认失败');
      }
    }, 800);
  };

  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden my-auto">
        {/* Modal Header */}
        <div className="bg-[#111827] text-white px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-6 h-6 rounded bg-[#FACC15] text-slate-950 flex items-center justify-center font-black text-sm">
              7
            </div>
            <div>
              <h3 className="text-base font-bold text-white tracking-tight">
                {step === 1 && (currentLang === 'zh' ? '预订确认 · 填写住客信息' : 'Book Room · Guest Info')}
                {step === 2 && (currentLang === 'zh' ? '安全支付 · 锁定房态' : 'Secure Payment & Hold')}
                {step === 3 && (currentLang === 'zh' ? '预订成功 · 凭证生成' : 'Booking Confirmed')}
              </h3>
              <p className="text-[11px] text-slate-400">
                {hotel.name} · {room.name}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6">
          {formError && (
            <div className="mb-4 bg-rose-50 border border-rose-200 text-rose-700 px-4 py-3 rounded-lg text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{formError}</span>
            </div>
          )}

          {/* STEP 1: Room rate plan & Guest details */}
          {step === 1 && (
            <div className="space-y-6">
              {/* Hotel & Stay Summary Card */}
              <div className="bg-slate-50 rounded-xl p-4 border border-slate-200/80 flex items-start gap-4">
                <img
                  src={room.image}
                  alt={room.name}
                  className="w-20 h-16 rounded-lg object-cover bg-slate-200 shrink-0"
                  referrerPolicy="no-referrer"
                />
                <div className="flex-1 min-w-0">
                  <h4 className="text-sm font-bold text-slate-900">{room.name}</h4>
                  <div className="text-xs text-slate-500 mt-0.5">
                    {checkInDate} 至 {checkOutDate} (共 {nights} 晚) · {roomsCount} 间房
                  </div>
                  <div className="text-[11px] text-slate-400 mt-1">
                    {room.bedInfo} · {room.area} · {room.window}
                  </div>
                </div>
              </div>

              {/* Rate Plan Selector */}
              <div>
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-2">
                  {t.ratePlan}
                </label>
                <div className="space-y-2">
                  {room.ratePlans.map((plan) => {
                    const isSelected = selectedRatePlan.id === plan.id;
                    const calculated = bookingEngine.calculateStayPrice(
                      room.basePrice,
                      plan.priceDiscountMultiplier,
                      plan.fixedDiscount,
                      nights,
                      roomsCount
                    );

                    return (
                      <div
                        key={plan.id}
                        onClick={() => setSelectedRatePlan(plan)}
                        className={`p-3.5 rounded-xl border transition cursor-pointer flex items-center justify-between ${
                          isSelected
                            ? 'border-[#FACC15] bg-amber-50/30 ring-2 ring-[#FACC15]/40'
                            : 'border-slate-200 hover:border-slate-300 bg-white'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                            isSelected ? 'border-amber-500 bg-amber-500' : 'border-slate-300'
                          }`}>
                            {isSelected && <Check className="w-2.5 h-2.5 text-white stroke-[3]" />}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-bold text-slate-900">{plan.name}</span>
                              {plan.isMemberOnly && (
                                <span className="text-[10px] bg-amber-100 text-amber-900 font-bold px-1.5 py-0.5 rounded">
                                  会员95折
                                </span>
                              )}
                            </div>
                            <div className="text-xs text-slate-500 mt-0.5">
                              {plan.cancellationPolicy}
                            </div>
                          </div>
                        </div>

                        <div className="text-right">
                          <div className="text-base font-black text-amber-500 tabular-nums">
                            ¥{calculated.nightlyPrice}
                            <span className="text-xs text-slate-400 font-normal">/晚</span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Guest Form Inputs */}
              <div className="space-y-4 pt-2 border-t border-slate-100">
                <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                  {t.stepGuestInfo}
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-medium text-slate-700 block mb-1">
                      {t.guestName} <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={guestName}
                      onChange={(e) => setGuestName(e.target.value)}
                      placeholder={t.guestNamePlaceholder}
                      className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-900 focus:outline-none focus:border-[#FACC15]"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-medium text-slate-700 block mb-1">
                      {t.guestPhone} <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="tel"
                      value={guestPhone}
                      onChange={(e) => setGuestPhone(e.target.value)}
                      placeholder={t.guestPhonePlaceholder}
                      className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-900 focus:outline-none focus:border-[#FACC15]"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-medium text-slate-700 block mb-1">
                    {t.guestIdCard} <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={guestIdCard}
                    onChange={(e) => setGuestIdCard(e.target.value)}
                    placeholder={t.guestIdCardPlaceholder}
                    className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-900 focus:outline-none focus:border-[#FACC15]"
                  />
                </div>

                <div>
                  <label className="text-xs font-medium text-slate-700 block mb-1">
                    {t.specialRequests}
                  </label>
                  <input
                    type="text"
                    value={specialRequests}
                    onChange={(e) => setSpecialRequests(e.target.value)}
                    placeholder={t.specialRequestsPlaceholder}
                    className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-900 focus:outline-none focus:border-[#FACC15]"
                  />
                </div>
              </div>

              {/* Price Breakdown Footer */}
              <div className="bg-slate-50 rounded-xl p-4 border border-slate-200">
                <div className="flex items-center justify-between text-xs text-slate-600 mb-1">
                  <span>房费小计 ({nights}晚 × {roomsCount}间):</span>
                  <span className="font-medium text-slate-900">¥{priceCalc.subtotal}</span>
                </div>
                <div className="flex items-center justify-between text-xs text-slate-600 mb-1">
                  <span>服务费与法定增值税 (9%):</span>
                  <span className="font-medium text-slate-900">¥{priceCalc.taxAndService}</span>
                </div>
                <div className="flex items-center justify-between text-sm font-bold text-slate-900 pt-2 border-t border-slate-200 mt-2">
                  <span>应付总额:</span>
                  <div className="text-xl font-black text-amber-500 tabular-nums">
                    ¥{priceCalc.total}
                  </div>
                </div>
              </div>

              {/* Proceed Button */}
              <button
                type="button"
                onClick={handleProceedToPayment}
                className="w-full bg-[#FACC15] hover:bg-[#EAB308] text-slate-950 font-bold py-3.5 px-4 rounded-xl flex items-center justify-center gap-2 transition cursor-pointer text-sm shadow-md"
              >
                <span>下一步：锁定房源并前往支付</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* STEP 2: Temporary Room Hold & Payment Gateway */}
          {step === 2 && heldReservation && (
            <div className="space-y-6">
              {/* 5-minute Hold Countdown Notice */}
              <div className="bg-amber-50 border border-amber-300 rounded-xl p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Clock className="w-5 h-5 text-amber-600 animate-pulse shrink-0" />
                  <div>
                    <div className="text-xs font-bold text-amber-900">
                      {t.holdingTimer} (预订号: {heldReservation.id})
                    </div>
                    <div className="text-[11px] text-amber-700">
                      {t.holdingTimerDesc}
                    </div>
                  </div>
                </div>

                <div className="text-lg font-black text-amber-600 font-mono tracking-wider tabular-nums bg-white px-2.5 py-1 rounded-lg border border-amber-200 shadow-2xs">
                  {formatTimer(holdTimeLeftSeconds)}
                </div>
              </div>

              {/* Payment Methods */}
              <div>
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-2">
                  {t.paymentMethod}
                </label>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  <button
                    type="button"
                    onClick={() => setSelectedPaymentMethod('WECHAT')}
                    className={`p-3 rounded-xl border text-center transition cursor-pointer flex flex-col items-center justify-center gap-1.5 ${
                      selectedPaymentMethod === 'WECHAT'
                        ? 'border-emerald-500 bg-emerald-50/40 text-emerald-800 ring-2 ring-emerald-500/20 font-bold'
                        : 'border-slate-200 hover:border-slate-300 text-slate-700'
                    }`}
                  >
                    <span className="text-lg">💬</span>
                    <span className="text-xs">{t.wechatPay}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setSelectedPaymentMethod('ALIPAY')}
                    className={`p-3 rounded-xl border text-center transition cursor-pointer flex flex-col items-center justify-center gap-1.5 ${
                      selectedPaymentMethod === 'ALIPAY'
                        ? 'border-sky-500 bg-sky-50/40 text-sky-800 ring-2 ring-sky-500/20 font-bold'
                        : 'border-slate-200 hover:border-slate-300 text-slate-700'
                    }`}
                  >
                    <span className="text-lg">💳</span>
                    <span className="text-xs">{t.alipay}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setSelectedPaymentMethod('UNIONPAY')}
                    className={`p-3 rounded-xl border text-center transition cursor-pointer flex flex-col items-center justify-center gap-1.5 ${
                      selectedPaymentMethod === 'UNIONPAY'
                        ? 'border-red-500 bg-red-50/40 text-red-800 ring-2 ring-red-500/20 font-bold'
                        : 'border-slate-200 hover:border-slate-300 text-slate-700'
                    }`}
                  >
                    <span className="text-lg">🏦</span>
                    <span className="text-xs">{t.unionPay}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setSelectedPaymentMethod('HOTEL_FRONT')}
                    className={`p-3 rounded-xl border text-center transition cursor-pointer flex flex-col items-center justify-center gap-1.5 ${
                      selectedPaymentMethod === 'HOTEL_FRONT'
                        ? 'border-amber-500 bg-amber-50/40 text-amber-800 ring-2 ring-amber-500/20 font-bold'
                        : 'border-slate-200 hover:border-slate-300 text-slate-700'
                    }`}
                  >
                    <span className="text-lg">🏨</span>
                    <span className="text-xs">{t.payAtHotel}</span>
                  </button>
                </div>
              </div>

              {/* Dynamic QR code payment simulation box */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 text-center flex flex-col items-center justify-center">
                <div className="text-xs text-slate-600 mb-3">
                  {selectedPaymentMethod === 'WECHAT' && '请使用微信 App 扫描二维码支付'}
                  {selectedPaymentMethod === 'ALIPAY' && '请使用支付宝 App 扫描二维码支付'}
                  {selectedPaymentMethod === 'UNIONPAY' && '银联在线极速支付网关'}
                  {selectedPaymentMethod === 'HOTEL_FRONT' && '前台信用卡担保预订（到店后现付）'}
                </div>

                {/* QR Code graphic */}
                <div className="w-40 h-40 bg-white p-3 rounded-xl border border-slate-200 shadow-xs flex items-center justify-center relative">
                  <div className="w-full h-full bg-slate-900 rounded-lg p-2 flex flex-col items-center justify-center text-white text-center">
                    <QrCode className="w-20 h-20 text-[#FACC15]" />
                    <span className="text-[10px] font-mono mt-1 text-slate-300">
                      ¥{heldReservation.totalAmount}
                    </span>
                  </div>
                  {paymentLoading && (
                    <div className="absolute inset-0 bg-white/90 rounded-xl flex items-center justify-center">
                      <div className="animate-spin w-6 h-6 border-2 border-amber-500 border-t-transparent rounded-full" />
                    </div>
                  )}
                </div>

                <div className="mt-4 text-xs font-bold text-slate-800">
                  支付金额: <span className="text-amber-600 text-base tabular-nums">¥{heldReservation.totalAmount}</span>
                </div>

                {/* Test Payment Simulation Action Buttons */}
                <div className="mt-4 flex items-center gap-3 w-full max-w-sm">
                  <button
                    type="button"
                    disabled={paymentLoading}
                    onClick={() => handleSimulatePayment(true)}
                    className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2.5 px-3 rounded-lg text-xs shadow-xs transition cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>{t.simulatePaySuccess}</span>
                  </button>

                  <button
                    type="button"
                    disabled={paymentLoading}
                    onClick={() => handleSimulatePayment(false)}
                    className="bg-slate-200 hover:bg-slate-300 text-slate-700 font-medium py-2.5 px-3 rounded-lg text-xs transition cursor-pointer"
                  >
                    {t.simulatePayFail}
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* STEP 3: Booking Confirmation Voucher */}
          {step === 3 && confirmedReservation && (
            <div className="space-y-6 text-center">
              <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
                <CheckCircle className="w-10 h-10" />
              </div>

              <div>
                <h3 className="text-xl font-black text-slate-900">
                  {t.bookingSuccess}
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  {t.keepRefSafe}
                </p>
              </div>

              {/* Printable Voucher Card */}
              <div className="bg-slate-50 rounded-xl p-5 border border-slate-200 text-left space-y-3">
                <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                  <div>
                    <span className="text-[11px] text-slate-400 block">{t.bookingRef}</span>
                    <span className="text-lg font-black text-slate-900 font-mono tracking-wider">
                      {confirmedReservation.id}
                    </span>
                  </div>
                  <span className="bg-emerald-500 text-white text-[11px] font-bold px-2 py-0.5 rounded-full">
                    已支付确认
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div>
                    <span className="text-slate-400 block">酒店分店:</span>
                    <span className="font-semibold text-slate-800">{confirmedReservation.hotelName}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">预订房型:</span>
                    <span className="font-semibold text-slate-800">{confirmedReservation.roomTypeName} ({confirmedReservation.roomsCount}间)</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">入住日期:</span>
                    <span className="font-semibold text-slate-800">{confirmedReservation.checkInDate} (14:00后)</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">离店日期:</span>
                    <span className="font-semibold text-slate-800">{confirmedReservation.checkOutDate} (12:00前)</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">入住住客:</span>
                    <span className="font-semibold text-slate-800">{confirmedReservation.guestName} ({confirmedReservation.guestPhone})</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">支付金额:</span>
                    <span className="font-bold text-amber-600">¥{confirmedReservation.totalAmount} ({confirmedReservation.paymentMethod})</span>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-200 text-[11px] text-slate-500">
                  📍 酒店地址: {confirmedReservation.hotelAddress} · 电话: {confirmedReservation.hotelPhone}
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex items-center gap-3 justify-center">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold py-2.5 px-4 rounded-xl text-xs transition cursor-pointer flex items-center gap-1.5"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>{t.printVoucher}</span>
                </button>

                <button
                  type="button"
                  onClick={onClose}
                  className="bg-[#FACC15] hover:bg-[#EAB308] text-slate-950 font-bold py-2.5 px-6 rounded-xl text-xs transition cursor-pointer shadow-xs"
                >
                  {t.backToHome}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
