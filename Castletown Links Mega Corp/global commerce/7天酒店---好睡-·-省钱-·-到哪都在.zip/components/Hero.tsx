'use client';

import React, { useState } from 'react';
import { Language, translations } from '../lib/i18n';
import { MapPin, Calendar, Users, Search, ArrowRight, ChevronDown, Check } from 'lucide-react';
import { POPULAR_CITIES } from '../lib/hotel-data';

interface HeroProps {
  currentLang: Language;
  destination: string;
  setDestination: (val: string) => void;
  checkInDate: string;
  setCheckInDate: (val: string) => void;
  checkOutDate: string;
  setCheckOutDate: (val: string) => void;
  roomsCount: number;
  setRoomsCount: (val: number) => void;
  adultsCount: number;
  setAdultsCount: (val: number) => void;
  onSearch: () => void;
}

export function Hero({
  currentLang,
  destination,
  setDestination,
  checkInDate,
  setCheckInDate,
  checkOutDate,
  setCheckOutDate,
  roomsCount,
  setRoomsCount,
  adultsCount,
  setAdultsCount,
  onSearch,
}: HeroProps) {
  const [showCityPicker, setShowCityPicker] = useState(false);
  const [showOccupancyPicker, setShowOccupancyPicker] = useState(false);
  const t = translations[currentLang];

  // Calculate nights
  const dIn = new Date(checkInDate);
  const dOut = new Date(checkOutDate);
  const diffTime = Math.max(1, Math.round((dOut.getTime() - dIn.getTime()) / (1000 * 60 * 60 * 24)));
  const nightsCount = isNaN(diffTime) ? 1 : diffTime;

  return (
    <section className="relative w-full">
      {/* Hero Visual Container */}
      <div className="relative w-full h-[520px] sm:h-[560px] lg:h-[600px] overflow-hidden bg-slate-900">
        {/* Real background hotel bedroom image */}
        <img
          src="/images/hotel_hero.jpg"
          alt="7 Days Inn Modern Room"
          className="w-full h-full object-cover object-center filter brightness-[0.92]"
          referrerPolicy="no-referrer"
        />

        {/* Cinematic gradient scrim on left to ensure high text contrast */}
        <div className="absolute inset-0 bg-gradient-to-r from-slate-950/85 via-slate-950/45 to-transparent pointer-events-none" />

        {/* Hero Copy (Left-aligned as in reference image) */}
        <div className="absolute inset-0 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col justify-center">
          <div className="max-w-xl pb-16">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-white tracking-tight leading-[1.15] drop-shadow-md">
              <span className="block">{t.heroTitleLine1}</span>
              <span className="block mt-1 text-[#FACC15]">{t.heroTitleLine2}</span>
            </h1>

            <p className="mt-4 text-base sm:text-lg text-slate-200 font-medium tracking-wide drop-shadow">
              {t.brandTagline}
            </p>

            <div className="mt-7">
              <button
                onClick={onSearch}
                className="inline-flex items-center gap-2.5 bg-[#FACC15] hover:bg-[#EAB308] text-slate-950 font-bold px-7 py-3 rounded-md shadow-lg transition-all transform hover:-translate-y-0.5 cursor-pointer text-base"
              >
                <span>{t.bookNow}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Floating Search Bar (Anchored at the bottom of the hero) */}
        <div className="absolute bottom-6 left-0 right-0 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 z-20">
          <div className="bg-[#18212F]/95 backdrop-blur-md text-white rounded-xl shadow-2xl border border-slate-700/80 p-2 sm:p-3">
            <div className="grid grid-cols-1 md:grid-cols-12 gap-2 sm:gap-3 items-center">
              {/* Col 1: Destination (4 cols) */}
              <div className="relative md:col-span-4 p-2.5 rounded-lg hover:bg-slate-800/60 transition border border-transparent hover:border-slate-700">
                <div 
                  className="flex items-center gap-3 cursor-pointer"
                  onClick={() => {
                    setShowCityPicker(!showCityPicker);
                    setShowOccupancyPicker(false);
                  }}
                >
                  <MapPin className="w-5 h-5 text-[#FACC15] shrink-0" />
                  <div className="flex-1 min-w-0">
                    <div className="text-[11px] text-slate-400 font-medium">
                      {t.destination}
                    </div>
                    <div className="text-sm font-semibold text-white truncate mt-0.5">
                      {destination || (currentLang === 'zh' ? '上海 (全部56家分店)' : 'Shanghai')}
                    </div>
                  </div>
                  <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                </div>

                {/* City Picker Dropdown */}
                {showCityPicker && (
                  <div className="absolute top-full left-0 mt-2 w-80 sm:w-96 bg-[#1E293B] border border-slate-700 rounded-xl shadow-2xl p-4 z-50 text-xs">
                    <div className="flex items-center justify-between pb-2 border-b border-slate-700 text-slate-300 font-medium">
                      <span>{currentLang === 'zh' ? '热门目的地' : 'Popular Cities'}</span>
                      <span className="text-[10px] text-slate-400">{currentLang === 'zh' ? '覆盖全国500+分店' : '500+ Hotels'}</span>
                    </div>

                    <div className="grid grid-cols-4 gap-2 mt-3">
                      {POPULAR_CITIES.map((city) => (
                        <button
                          key={city.name}
                          onClick={() => {
                            setDestination(currentLang === 'zh' ? city.name : city.nameEn);
                            setShowCityPicker(false);
                          }}
                          className={`p-2 rounded-lg text-center transition cursor-pointer ${
                            destination.includes(city.name)
                              ? 'bg-[#FACC15] text-slate-950 font-bold'
                              : 'bg-slate-800 text-slate-200 hover:bg-slate-700'
                          }`}
                        >
                          <div className="font-medium text-xs">{currentLang === 'zh' ? city.name : city.nameEn}</div>
                          <div className="text-[10px] opacity-75 mt-0.5">{city.count}家</div>
                        </button>
                      ))}
                    </div>

                    <div className="mt-3 pt-2 border-t border-slate-700">
                      <input
                        type="text"
                        placeholder={t.destinationPlaceholder}
                        value={destination}
                        onChange={(e) => setDestination(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-md px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#FACC15]"
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Col 2: Check-in / Check-out Dates (4 cols) */}
              <div className="md:col-span-4 p-2.5 rounded-lg hover:bg-slate-800/60 transition border border-transparent hover:border-slate-700">
                <div className="flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-[#FACC15] shrink-0" />
                  
                  {/* Check-in input */}
                  <div className="flex-1">
                    <label className="text-[11px] text-slate-400 font-medium block">
                      {t.checkIn}
                    </label>
                    <input
                      type="date"
                      value={checkInDate}
                      onChange={(e) => {
                        setCheckInDate(e.target.value);
                        if (e.target.value >= checkOutDate) {
                          const nextD = new Date(e.target.value);
                          nextD.setDate(nextD.getDate() + 1);
                          setCheckOutDate(nextD.toISOString().split('T')[0]);
                        }
                      }}
                      className="bg-transparent text-sm font-semibold text-white focus:outline-none cursor-pointer w-full mt-0.5"
                    />
                  </div>

                  {/* Arrow and Night indicator */}
                  <div className="flex flex-col items-center px-1">
                    <span className="text-slate-400 text-xs">→</span>
                    <span className="text-[10px] text-[#FACC15] font-semibold whitespace-nowrap">
                      {nightsCount} {t.nights}
                    </span>
                  </div>

                  {/* Check-out input */}
                  <div className="flex-1">
                    <label className="text-[11px] text-slate-400 font-medium block">
                      {t.checkOut}
                    </label>
                    <input
                      type="date"
                      value={checkOutDate}
                      min={checkInDate}
                      onChange={(e) => setCheckOutDate(e.target.value)}
                      className="bg-transparent text-sm font-semibold text-white focus:outline-none cursor-pointer w-full mt-0.5"
                    />
                  </div>
                </div>
              </div>

              {/* Col 3: Room & Guest occupancy (2.5 cols) */}
              <div className="relative md:col-span-2 p-2.5 rounded-lg hover:bg-slate-800/60 transition border border-transparent hover:border-slate-700">
                <div
                  className="flex items-center gap-3 cursor-pointer"
                  onClick={() => {
                    setShowOccupancyPicker(!showOccupancyPicker);
                    setShowCityPicker(false);
                  }}
                >
                  <Users className="w-5 h-5 text-[#FACC15] shrink-0" />
                  <div className="flex-1 min-w-0">
                    <div className="text-[11px] text-slate-400 font-medium">
                      {t.roomsAndGuests}
                    </div>
                    <div className="text-sm font-semibold text-white truncate mt-0.5">
                      {roomsCount}间房 {adultsCount}位成人
                    </div>
                  </div>
                  <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                </div>

                {/* Occupancy Selector */}
                {showOccupancyPicker && (
                  <div className="absolute top-full left-0 mt-2 w-64 bg-[#1E293B] border border-slate-700 rounded-xl shadow-2xl p-4 z-50 text-xs">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-300 font-medium">{currentLang === 'zh' ? '房间数' : 'Rooms'}</span>
                        <div className="flex items-center gap-3">
                          <button
                            type="button"
                            onClick={() => setRoomsCount(Math.max(1, roomsCount - 1))}
                            className="w-7 h-7 rounded-md bg-slate-800 text-white font-bold hover:bg-slate-700 cursor-pointer flex items-center justify-center"
                          >
                            -
                          </button>
                          <span className="font-bold text-white text-sm w-4 text-center">{roomsCount}</span>
                          <button
                            type="button"
                            onClick={() => setRoomsCount(Math.min(5, roomsCount + 1))}
                            className="w-7 h-7 rounded-md bg-slate-800 text-white font-bold hover:bg-slate-700 cursor-pointer flex items-center justify-center"
                          >
                            +
                          </button>
                        </div>
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="text-slate-300 font-medium">{currentLang === 'zh' ? '成人数' : 'Adults'}</span>
                        <div className="flex items-center gap-3">
                          <button
                            type="button"
                            onClick={() => setAdultsCount(Math.max(1, adultsCount - 1))}
                            className="w-7 h-7 rounded-md bg-slate-800 text-white font-bold hover:bg-slate-700 cursor-pointer flex items-center justify-center"
                          >
                            -
                          </button>
                          <span className="font-bold text-white text-sm w-4 text-center">{adultsCount}</span>
                          <button
                            type="button"
                            onClick={() => setAdultsCount(Math.min(10, adultsCount + 1))}
                            className="w-7 h-7 rounded-md bg-slate-800 text-white font-bold hover:bg-slate-700 cursor-pointer flex items-center justify-center"
                          >
                            +
                          </button>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => setShowOccupancyPicker(false)}
                        className="w-full bg-[#FACC15] text-slate-950 font-bold py-1.5 rounded-md mt-2 cursor-pointer flex items-center justify-center gap-1"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>{currentLang === 'zh' ? '确定' : 'Confirm'}</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Col 4: Search Button (1.5 cols) */}
              <div className="md:col-span-2">
                <button
                  type="button"
                  onClick={onSearch}
                  className="w-full bg-[#FACC15] hover:bg-[#EAB308] text-slate-950 font-bold py-3.5 px-4 rounded-lg flex items-center justify-center gap-2 transition-all shadow-md cursor-pointer text-sm"
                >
                  <Search className="w-4 h-4 text-slate-950 stroke-[2.5]" />
                  <span>{t.searchHotels}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
