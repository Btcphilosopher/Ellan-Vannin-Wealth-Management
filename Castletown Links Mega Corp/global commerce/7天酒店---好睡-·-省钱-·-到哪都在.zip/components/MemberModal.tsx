'use client';

import React, { useState } from 'react';
import { Language, translations } from '../lib/i18n';
import { X, Sparkles, Award, Gift, Zap, ShieldCheck, CheckCircle2 } from 'lucide-react';

interface MemberModalProps {
  currentLang: Language;
  onClose: () => void;
}

export function MemberModal({ currentLang, onClose }: MemberModalProps) {
  const t = translations[currentLang];
  const [phone, setPhone] = useState('');
  const [name, setName] = useState('');
  const [joined, setJoined] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!phone) return;
    setJoined(true);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden my-auto">
        {/* Header with vibrant 7 Days brand yellow accent */}
        <div className="bg-gradient-to-r from-slate-900 to-slate-800 text-white p-6 relative">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-[#FACC15] text-slate-950 font-black text-lg flex items-center justify-center">
                7
              </div>
              <div>
                <h3 className="text-lg font-black text-white">
                  7天会 · 会员尊享计划
                </h3>
                <p className="text-xs text-[#FACC15]">
                  注册即享预订 95 折起 · 积分可抵扣房费
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center transition cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="p-6 space-y-6">
          {joined ? (
            <div className="text-center py-6 space-y-3">
              <div className="w-14 h-14 bg-amber-100 text-amber-600 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h4 className="text-base font-bold text-slate-900">欢迎加入 7天会！</h4>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                您的账号已成功开通银卡会员资格，订房时请使用该手机号直接立享 95 折优惠。
              </p>
              <button
                type="button"
                onClick={onClose}
                className="bg-[#FACC15] hover:bg-[#EAB308] text-slate-950 font-bold px-6 py-2 rounded-xl text-xs cursor-pointer shadow-xs"
              >
                开始享受会员价订房
              </button>
            </div>
          ) : (
            <>
              {/* Member Tiers & Benefits Grid */}
              <div className="grid grid-cols-3 gap-3">
                <div className="bg-amber-50/60 rounded-xl p-3 border border-amber-200/80 text-center">
                  <div className="text-xs font-bold text-amber-900">银卡会员</div>
                  <div className="text-lg font-black text-amber-600 mt-1">95折</div>
                  <div className="text-[10px] text-amber-700 mt-0.5">注册即可享受</div>
                </div>

                <div className="bg-slate-50 rounded-xl p-3 border border-slate-200 text-center">
                  <div className="text-xs font-bold text-slate-800">金卡会员</div>
                  <div className="text-lg font-black text-slate-900 mt-1">9折</div>
                  <div className="text-[10px] text-slate-500 mt-0.5">满 5 晚升级</div>
                </div>

                <div className="bg-slate-900 text-white rounded-xl p-3 text-center">
                  <div className="text-xs font-bold text-[#FACC15]">白金卡</div>
                  <div className="text-lg font-black text-[#FACC15] mt-1">88折</div>
                  <div className="text-[10px] text-slate-300 mt-0.5">免费含早+延迟退房</div>
                </div>
              </div>

              {/* 4 Core Perks */}
              <div className="space-y-2.5 text-xs text-slate-600">
                <div className="flex items-center gap-2.5">
                  <Sparkles className="w-4 h-4 text-amber-500 shrink-0" />
                  <span><strong>房价立减:</strong> 官网直接预订立享专属折扣，无隐藏溢价</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <Zap className="w-4 h-4 text-amber-500 shrink-0" />
                  <span><strong>零秒退房:</strong> 房卡直接放置前台免查房快速离店</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <Gift className="w-4 h-4 text-amber-500 shrink-0" />
                  <span><strong>积分当钱花:</strong> 每消费 1 元积 1 分，积分兑换免房礼券</span>
                </div>
              </div>

              {/* Instant Sign-up Form */}
              <form onSubmit={handleSubmit} className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                <div className="text-xs font-bold text-slate-800">快速注册 / 绑定手机号</div>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    placeholder="姓名 (选填)"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="text-xs bg-white border border-slate-200 rounded-lg px-3 py-2 text-slate-900 focus:outline-none focus:border-[#FACC15]"
                  />
                  <input
                    type="tel"
                    required
                    placeholder="手机号 (+86)"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="text-xs bg-white border border-slate-200 rounded-lg px-3 py-2 text-slate-900 focus:outline-none focus:border-[#FACC15]"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-[#FACC15] hover:bg-[#EAB308] text-slate-950 font-bold py-2.5 rounded-lg text-xs transition cursor-pointer shadow-xs"
                >
                  免费注册立享 95 折
                </button>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
