'use client';

import React from 'react';
import { Logo } from './Logo';
import { Language, translations } from '../lib/i18n';
import { MessageSquare, PhoneCall, ShieldAlert, Award } from 'lucide-react';

interface FooterProps {
  currentLang: Language;
  onOpenAbout: () => void;
  onOpenHelp: () => void;
  onOpenTerms: () => void;
}

export function Footer({ currentLang, onOpenAbout, onOpenHelp, onOpenTerms }: FooterProps) {
  const t = translations[currentLang];

  return (
    <footer className="bg-[#111827] text-slate-300 border-t border-slate-800 py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 pb-8 border-b border-slate-800/80">
          {/* Logo on Left */}
          <div>
            <Logo />
          </div>

          {/* Center Navigation Links */}
          <nav className="flex items-center flex-wrap justify-center gap-6 sm:gap-8 text-xs sm:text-sm text-slate-300">
            <button
              onClick={onOpenAbout}
              className="hover:text-[#FACC15] transition-colors cursor-pointer"
            >
              {t.aboutUs}
            </button>
            <button
              onClick={onOpenHelp}
              className="hover:text-[#FACC15] transition-colors cursor-pointer"
            >
              {t.contactUs}
            </button>
            <button
              onClick={onOpenTerms}
              className="hover:text-[#FACC15] transition-colors cursor-pointer"
            >
              {t.privacyPolicy}
            </button>
            <button
              onClick={onOpenTerms}
              className="hover:text-[#FACC15] transition-colors cursor-pointer"
            >
              {t.termsOfService}
            </button>
          </nav>

          {/* Social Icons & Hotline on Right */}
          <div className="flex items-center gap-4 text-xs">
            {/* WeChat Icon */}
            <div 
              title="微信客服公众号" 
              className="w-8 h-8 rounded-full bg-slate-800 hover:bg-emerald-600 hover:text-white flex items-center justify-center transition cursor-pointer"
            >
              <MessageSquare className="w-4 h-4 text-slate-300" />
            </div>

            {/* Weibo Icon */}
            <div 
              title="官方微博" 
              className="w-8 h-8 rounded-full bg-slate-800 hover:bg-rose-600 hover:text-white flex items-center justify-center transition cursor-pointer"
            >
              <span className="font-bold text-xs text-slate-300">微</span>
            </div>

            {/* 24h Customer Service Hotline */}
            <div className="hidden sm:flex items-center gap-1.5 text-slate-400 pl-2 border-l border-slate-800">
              <PhoneCall className="w-3.5 h-3.5 text-[#FACC15]" />
              <span className="tabular-nums font-medium text-slate-200">400-888-7777</span>
            </div>
          </div>
        </div>

        {/* Bottom copyright & ICP compliance */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-2">
          <div>
            <span>{t.copyright}</span>
            <span className="mx-2">·</span>
            <span>{t.icp}</span>
          </div>

          <div className="flex items-center gap-4 text-[11px] text-slate-500">
            <span>公安网安备 44010502000001号</span>
            <span>网信办网安认证</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
