'use client';

import React from 'react';
import { Language, translations } from '../lib/i18n';
import { POPULAR_CITIES } from '../lib/hotel-data';
import { ArrowRight, Smartphone, Apple, ShieldCheck, MapPin } from 'lucide-react';

interface PromoCardsProps {
  currentLang: Language;
  onJoinMember: () => void;
  onSelectCity: (city: string) => void;
  onOpenAppModal: () => void;
}

export function PromoCards({
  currentLang,
  onJoinMember,
  onSelectCity,
  onOpenAppModal,
}: PromoCardsProps) {
  const t = translations[currentLang];

  return (
    <section className="py-10 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card 1: Member Exclusive (Dark traveler backdrop) */}
          <div className="relative rounded-2xl overflow-hidden shadow-sm border border-slate-800 bg-[#111827] text-white p-6 flex flex-col justify-between min-h-[200px]">
            {/* Background texture */}
            <div className="absolute inset-0 z-0">
              <img
                src="/images/room_twin.jpg"
                alt="Member Exclusive"
                className="w-full h-full object-cover filter brightness-[0.28] contrast-125"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-950/80 to-slate-900/60" />
            </div>

            <div className="relative z-10">
              <span className="text-[11px] font-semibold text-[#FACC15] tracking-wider uppercase">
                7 DAYS CLUB
              </span>
              <h3 className="text-xl sm:text-2xl font-black text-white mt-1">
                {t.memberExclusive}
              </h3>
              <p className="text-xs text-slate-300 mt-1.5">
                {t.memberExclusiveDesc}
              </p>
            </div>

            <div className="relative z-10 pt-4">
              <button
                type="button"
                onClick={onJoinMember}
                className="inline-flex items-center gap-2 border border-slate-400 hover:border-white text-white hover:bg-white/10 text-xs font-semibold px-4 py-2 rounded-lg transition-colors cursor-pointer"
              >
                <span>{t.joinNow}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Card 2: Popular Cities with interactive China map pins */}
          <div className="relative rounded-2xl overflow-hidden shadow-sm border border-slate-800 bg-[#0F172A] text-white p-6 flex flex-col justify-between min-h-[200px]">
            {/* Ambient Map Grid */}
            <div className="absolute inset-0 opacity-20 pointer-events-none">
              <div className="w-full h-full bg-[radial-gradient(#FACC15_1px,transparent_1px)] [background-size:16px_16px]" />
            </div>

            <div className="relative z-10">
              <h3 className="text-lg sm:text-xl font-black text-white">
                {t.popularCities}
              </h3>

              {/* City quick chips */}
              <div className="grid grid-cols-4 gap-2 mt-3">
                {POPULAR_CITIES.map((city) => (
                  <button
                    key={city.name}
                    type="button"
                    onClick={() => onSelectCity(currentLang === 'zh' ? city.name : city.nameEn)}
                    className="text-xs py-1.5 px-2 bg-slate-800/80 hover:bg-[#FACC15] hover:text-slate-950 text-slate-200 rounded-md text-center transition-colors font-medium border border-slate-700/60 cursor-pointer"
                  >
                    {currentLang === 'zh' ? city.name : city.nameEn}
                  </button>
                ))}
              </div>
            </div>

            <div className="relative z-10 pt-3">
              <button
                type="button"
                onClick={() => onSelectCity('')}
                className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-[#FACC15] transition-colors cursor-pointer"
              >
                <span>{t.viewAllCities}</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          </div>

          {/* Card 3: Download 7 Days App (Yellow background + phone graphic) */}
          <div className="relative rounded-2xl overflow-hidden shadow-sm bg-[#FACC15] text-slate-950 p-6 flex flex-col justify-between min-h-[200px] border border-amber-300">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-xl sm:text-2xl font-black text-slate-950 tracking-tight">
                  {t.downloadApp}
                </h3>
                <p className="text-xs text-slate-800 font-medium mt-1">
                  {t.downloadAppDesc}
                </p>
              </div>

              {/* Phone App Icon */}
              <div className="w-12 h-12 bg-slate-950 text-[#FACC15] rounded-xl flex items-center justify-center font-black text-xl shadow-md shrink-0">
                <span>7</span>
              </div>
            </div>

            {/* App Store / Android Download Buttons */}
            <div className="flex items-center gap-2 pt-4">
              <button
                type="button"
                onClick={onOpenAppModal}
                className="flex-1 bg-slate-950 hover:bg-slate-900 text-white rounded-lg py-2 px-3 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-xs"
              >
                <Apple className="w-3.5 h-3.5 text-white" />
                <span>App Store</span>
              </button>
              <button
                type="button"
                onClick={onOpenAppModal}
                className="flex-1 bg-slate-950 hover:bg-slate-900 text-white rounded-lg py-2 px-3 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-xs"
              >
                <Smartphone className="w-3.5 h-3.5 text-white" />
                <span>Android</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
