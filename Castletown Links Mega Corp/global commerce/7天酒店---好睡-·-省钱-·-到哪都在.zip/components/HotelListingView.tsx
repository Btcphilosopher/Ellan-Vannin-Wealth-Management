'use client';

import React, { useState } from 'react';
import { Language, translations } from '../lib/i18n';
import { Hotel, RoomType } from '../lib/types';
import { bookingEngine } from '../lib/store';
import { 
  MapPin, Star, Wifi, ShieldCheck, Clock, CheckCircle2, 
  ChevronRight, Filter, ArrowUpDown, Coffee, Sparkles 
} from 'lucide-react';

interface HotelListingViewProps {
  currentLang: Language;
  hotels: Hotel[];
  searchCity: string;
  checkInDate: string;
  checkOutDate: string;
  roomsCount: number;
  adultsCount: number;
  onSelectRoom: (hotel: Hotel, room: RoomType) => void;
  onBackToHome: () => void;
}

export function HotelListingView({
  currentLang,
  hotels,
  searchCity,
  checkInDate,
  checkOutDate,
  roomsCount,
  adultsCount,
  onSelectRoom,
  onBackToHome,
}: HotelListingViewProps) {
  const [selectedCity, setSelectedCity] = useState<string>(searchCity || '全部');
  const [priceFilter, setPriceFilter] = useState<string>('ALL'); // ALL, UNDER_150, 150_200, OVER_200
  const [selectedAmenity, setSelectedAmenity] = useState<string>('ALL');
  const [sortBy, setSortBy] = useState<'RECOMMENDED' | 'PRICE_ASC' | 'PRICE_DESC' | 'RATING'>('RECOMMENDED');
  const [expandedHotelId, setExpandedHotelId] = useState<string | null>(hotels[0]?.id || null);

  const t = translations[currentLang];

  // Filter hotels
  const filteredHotels = hotels.filter((hotel) => {
    // City filter
    if (selectedCity !== '全部' && !hotel.city.includes(selectedCity) && !hotel.name.includes(selectedCity)) {
      return false;
    }

    // Price filter
    if (priceFilter === 'UNDER_150' && hotel.minPrice >= 150) return false;
    if (priceFilter === '150_200' && (hotel.minPrice < 150 || hotel.minPrice > 200)) return false;
    if (priceFilter === 'OVER_200' && hotel.minPrice <= 200) return false;

    // Amenity filter
    if (selectedAmenity !== 'ALL' && !hotel.amenities.some(a => a.includes(selectedAmenity))) {
      return false;
    }

    return true;
  });

  // Sort hotels
  const sortedHotels = [...filteredHotels].sort((a, b) => {
    if (sortBy === 'PRICE_ASC') return a.minPrice - b.minPrice;
    if (sortBy === 'PRICE_DESC') return b.minPrice - a.minPrice;
    if (sortBy === 'RATING') return b.rating - a.rating;
    return 0; // RECOMMENDED
  });

  const cityList = ['全部', '上海', '北京', '广州', '深圳', '成都', '杭州'];

  return (
    <div className="bg-slate-100 min-h-screen py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Navigation Breadcrumb */}
        <div className="flex items-center justify-between pb-5">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <button 
              onClick={onBackToHome}
              className="hover:text-slate-900 cursor-pointer font-medium"
            >
              {t.home}
            </button>
            <span>/</span>
            <span className="text-slate-900 font-semibold">{t.hotelReservation}</span>
          </div>

          <div className="text-xs text-slate-600 bg-white px-3 py-1.5 rounded-full border border-slate-200 shadow-2xs">
            <span>{checkInDate} 至 {checkOutDate}</span>
            <span className="mx-1.5">·</span>
            <span>{roomsCount}间房 {adultsCount}位成人</span>
          </div>
        </div>

        {/* Filters and Controls Bar */}
        <div className="bg-white rounded-xl shadow-xs border border-slate-200 p-4 mb-6">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            {/* City Segmented Filter */}
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-xs font-bold text-slate-400 mr-2 uppercase tracking-wider">
                {currentLang === 'zh' ? '城市' : 'City'}:
              </span>
              {cityList.map((city) => (
                <button
                  key={city}
                  onClick={() => setSelectedCity(city)}
                  className={`text-xs px-3 py-1.5 rounded-lg font-medium transition cursor-pointer ${
                    selectedCity === city
                      ? 'bg-slate-900 text-white font-bold shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {city}
                </button>
              ))}
            </div>

            {/* Price & Sort Controls */}
            <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-end">
              <select
                value={priceFilter}
                onChange={(e) => setPriceFilter(e.target.value)}
                className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-700 cursor-pointer focus:outline-none"
              >
                <option value="ALL">{currentLang === 'zh' ? '价格范围: 不限' : 'Price: All'}</option>
                <option value="UNDER_150">{currentLang === 'zh' ? '¥150 以下 (极高性价比)' : 'Under ¥150'}</option>
                <option value="150_200">{currentLang === 'zh' ? '¥150 - ¥200 (标准经济)' : '¥150 - ¥200'}</option>
                <option value="OVER_200">{currentLang === 'zh' ? '¥200 以上 (家庭/商务)' : 'Above ¥200'}</option>
              </select>

              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-700 cursor-pointer focus:outline-none"
              >
                <option value="RECOMMENDED">{currentLang === 'zh' ? '综合推荐' : 'Recommended'}</option>
                <option value="PRICE_ASC">{currentLang === 'zh' ? '价格: 低到高' : 'Price: Low to High'}</option>
                <option value="PRICE_DESC">{currentLang === 'zh' ? '价格: 高到低' : 'Price: High to Low'}</option>
                <option value="RATING">{currentLang === 'zh' ? '评分优先' : 'Highest Rated'}</option>
              </select>
            </div>
          </div>
        </div>

        {/* Search Results List */}
        <div className="space-y-6">
          {sortedHotels.length === 0 ? (
            <div className="bg-white rounded-xl p-12 text-center text-slate-500 border border-slate-200">
              <p className="text-base font-semibold">{currentLang === 'zh' ? '未找到符合条件的酒店分店' : 'No hotels found matching criteria'}</p>
              <button
                onClick={() => { setSelectedCity('全部'); setPriceFilter('ALL'); }}
                className="mt-4 text-xs bg-slate-900 text-white px-4 py-2 rounded-lg cursor-pointer font-medium"
              >
                {currentLang === 'zh' ? '重置筛选条件' : 'Reset Filters'}
              </button>
            </div>
          ) : (
            sortedHotels.map((hotel) => {
              const isExpanded = expandedHotelId === hotel.id;

              return (
                <div 
                  key={hotel.id}
                  className="bg-white rounded-xl shadow-xs border border-slate-200 overflow-hidden"
                >
                  {/* Hotel Header / Summary Row */}
                  <div className="p-5 flex flex-col md:flex-row gap-5 items-start">
                    {/* Hotel Main Thumbnail */}
                    <div className="w-full md:w-56 h-36 rounded-lg overflow-hidden bg-slate-100 shrink-0 relative">
                      <img
                        src={hotel.image}
                        alt={currentLang === 'zh' ? hotel.name : hotel.nameEn}
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute top-2 left-2 bg-[#FACC15] text-slate-950 text-[10px] font-black px-1.5 py-0.5 rounded">
                        7天连锁
                      </div>
                    </div>

                    {/* Hotel Details */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <h3 className="text-lg font-bold text-slate-900">
                            {currentLang === 'zh' ? hotel.name : hotel.nameEn}
                          </h3>
                          <div className="flex items-center gap-2 mt-1 text-xs text-slate-500">
                            <span className="flex items-center gap-1 font-semibold text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded">
                              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                              {hotel.rating} 分
                            </span>
                            <span>({hotel.reviewCount} 条住客真实点评)</span>
                          </div>
                        </div>

                        {/* Price summary */}
                        <div className="text-right shrink-0">
                          <div className="text-xs text-slate-400">起价</div>
                          <div className="flex items-baseline justify-end text-amber-600">
                            <span className="text-xs font-bold">¥</span>
                            <span className="text-2xl font-black tabular-nums">{hotel.minPrice}</span>
                            <span className="text-xs text-slate-400 ml-0.5">/晚</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 text-xs text-slate-500 mt-2">
                        <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="truncate">{currentLang === 'zh' ? hotel.address : hotel.addressEn}</span>
                      </div>

                      {/* Tags */}
                      <div className="flex flex-wrap gap-1.5 mt-3">
                        {hotel.tags.map((tag, idx) => (
                          <span
                            key={idx}
                            className="text-[11px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded"
                          >
                            {tag}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Room Inventory & Rate Plans List */}
                  <div className="border-t border-slate-100 bg-slate-50/60 p-4 sm:p-5">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-xs font-bold text-slate-700 tracking-wider">
                        {currentLang === 'zh' ? '实时可订房型与价格' : 'Available Rooms & Rate Plans'}
                      </span>
                      <span className="text-[11px] text-slate-400">
                        {currentLang === 'zh' ? '房态实时锁定 · 支持微信/支付宝/银联' : 'Live Inventory Locked'}
                      </span>
                    </div>

                    <div className="space-y-3">
                      {hotel.roomTypes.map((room) => {
                        // Calculate live bookable inventory
                        const availableCount = bookingEngine.getAvailableRooms(
                          hotel.id,
                          room.id,
                          checkInDate,
                          checkOutDate
                        );

                        const isSoldOut = availableCount < roomsCount;

                        return (
                          <div
                            key={room.id}
                            className="bg-white rounded-lg border border-slate-200 p-3 sm:p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 transition hover:border-slate-300 shadow-2xs"
                          >
                            {/* Room basic specs */}
                            <div className="flex items-center gap-3">
                              <img
                                src={room.image}
                                alt={room.name}
                                className="w-16 h-14 object-cover rounded-md bg-slate-100 shrink-0"
                                referrerPolicy="no-referrer"
                              />
                              <div>
                                <div className="flex items-center gap-2">
                                  <h4 className="text-sm font-bold text-slate-900">
                                    {currentLang === 'zh' ? room.name : room.nameEn}
                                  </h4>
                                  {availableCount <= 3 && availableCount > 0 && (
                                    <span className="text-[10px] bg-rose-50 text-rose-600 font-bold px-1.5 py-0.5 rounded border border-rose-100">
                                      仅剩 {availableCount} 间
                                    </span>
                                  )}
                                  {isSoldOut && (
                                    <span className="text-[10px] bg-slate-200 text-slate-600 font-bold px-1.5 py-0.5 rounded">
                                      已订满
                                    </span>
                                  )}
                                </div>
                                <div className="text-xs text-slate-500 mt-0.5 flex items-center gap-1.5 flex-wrap">
                                  <span>{currentLang === 'zh' ? room.bedInfo : room.bedInfoEn}</span>
                                  <span>·</span>
                                  <span>{room.area}</span>
                                  <span>·</span>
                                  <span>{room.occupancy}</span>
                                  <span>·</span>
                                  <span className="text-emerald-600">{room.window}</span>
                                </div>
                              </div>
                            </div>

                            {/* Rate selection & action */}
                            <div className="flex items-center justify-between w-full md:w-auto md:gap-6 pt-2 md:pt-0 border-t md:border-t-0 border-slate-100">
                              <div className="text-left md:text-right">
                                <div className="text-[11px] text-emerald-600 font-medium">
                                  入住当天18:00前可免费取消
                                </div>
                                <div className="flex items-baseline md:justify-end text-amber-500">
                                  <span className="text-xs font-bold">¥</span>
                                  <span className="text-xl font-black tabular-nums">{room.basePrice}</span>
                                  <span className="text-xs text-slate-400 ml-0.5">/晚</span>
                                </div>
                              </div>

                              <button
                                type="button"
                                disabled={isSoldOut}
                                onClick={() => onSelectRoom(hotel, room)}
                                className={`px-5 py-2 rounded-lg font-bold text-xs transition cursor-pointer shadow-xs ${
                                  isSoldOut
                                    ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                                    : 'bg-[#FACC15] hover:bg-[#EAB308] text-slate-950'
                                }`}
                              >
                                {isSoldOut ? '已订满' : t.book}
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
