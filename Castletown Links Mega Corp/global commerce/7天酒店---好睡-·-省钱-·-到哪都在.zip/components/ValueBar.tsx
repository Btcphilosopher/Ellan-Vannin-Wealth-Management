'use client';

import React from 'react';
import { Language, translations } from '../lib/i18n';
import { CircleDollarSign, ShieldCheck, Wifi, MapPin, Headphones } from 'lucide-react';

interface ValueBarProps {
  currentLang: Language;
}

export function ValueBar({ currentLang }: ValueBarProps) {
  const t = translations[currentLang];

  const features = [
    {
      icon: CircleDollarSign,
      title: t.affordablePrices,
      desc: t.affordablePricesDesc,
    },
    {
      icon: ShieldCheck,
      title: t.safeAssured,
      desc: t.safeAssuredDesc,
    },
    {
      icon: Wifi,
      title: t.freeWifi,
      desc: t.freeWifiDesc,
    },
    {
      icon: MapPin,
      title: t.convenientLocation,
      desc: t.convenientLocationDesc,
    },
    {
      icon: Headphones,
      title: t.caringService,
      desc: t.caringServiceDesc,
    },
  ];

  return (
    <section className="bg-white border-b border-slate-200/80 shadow-xs py-7">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-6 sm:gap-4 lg:gap-8">
          {features.map((item, idx) => {
            const Icon = item.icon;
            return (
              <div 
                key={idx} 
                className="flex items-center gap-3.5 group transition-transform hover:-translate-y-0.5 duration-200"
              >
                <div className="w-12 h-12 rounded-full bg-amber-50/60 border border-amber-200/60 flex items-center justify-center shrink-0 text-slate-900 group-hover:bg-[#FACC15]/20 transition-colors">
                  <Icon className="w-6 h-6 stroke-[1.75]" />
                </div>
                <div className="flex flex-col min-w-0">
                  <span className="text-sm sm:text-base font-bold text-slate-900 tracking-tight">
                    {item.title}
                  </span>
                  <span className="text-xs text-slate-500 truncate mt-0.5 font-normal">
                    {item.desc}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
