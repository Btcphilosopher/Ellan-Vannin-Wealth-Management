'use client';

import React, { useState } from 'react';
import { Language, translations } from '../lib/i18n';
import { Reservation } from '../lib/types';
import { bookingEngine } from '../lib/store';
import { X, Search, Calendar, Phone, AlertTriangle, CheckCircle2, RotateCcw } from 'lucide-react';

interface BookingLookupModalProps {
  currentLang: Language;
  onClose: () => void;
}

export function BookingLookupModal({ currentLang, onClose }: BookingLookupModalProps) {
  const t = translations[currentLang];
  const [refId, setRefId] = useState('7D-20261013-5821');
  const [phone, setPhone] = useState('13812345678');
  const [foundReservation, setFoundReservation] = useState<Reservation | null>(null);
  const [searched, setSearched] = useState(false);
  const [cancelPrompt, setCancelPrompt] = useState(false);
  const [cancelMessage, setCancelMessage] = useState<string | null>(null);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setCancelMessage(null);
    setCancelPrompt(false);
    const res = bookingEngine.lookupReservation(refId, phone);
    setFoundReservation(res || null);
    setSearched(true);
  };

  const handleConfirmCancel = () => {
    if (!foundReservation) return;
    const res = bookingEngine.cancelReservation(
      foundReservation.id,
      '旅客自助在线申请取消',
      'GUEST'
    );
    if (res.success) {
      setCancelMessage(res.message);
      setCancelPrompt(false);
      // Reload reservation state
      const updated = bookingEngine.lookupReservation(foundReservation.id, phone);
      setFoundReservation(updated || null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-xl overflow-hidden my-auto">
        {/* Header */}
        <div className="bg-[#111827] text-white px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-[#FACC15]" />
            <div>
              <h3 className="text-base font-bold text-white">
                {t.lookupTitle}
              </h3>
              <p className="text-[11px] text-slate-400">
                {t.lookupSubtitle}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Search Form */}
          <form onSubmit={handleSearch} className="space-y-3 bg-slate-50 p-4 rounded-xl border border-slate-200">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  {t.bookingRef}
                </label>
                <input
                  type="text"
                  value={refId}
                  onChange={(e) => setRefId(e.target.value)}
                  placeholder="例如: 7D-20261013-5821"
                  required
                  className="w-full text-xs bg-white border border-slate-200 rounded-lg px-3 py-2 text-slate-900 font-mono focus:outline-none focus:border-[#FACC15]"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  {t.guestPhone}
                </label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="预订时预留的手机号"
                  className="w-full text-xs bg-white border border-slate-200 rounded-lg px-3 py-2 text-slate-900 focus:outline-none focus:border-[#FACC15]"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-[#FACC15] hover:bg-[#EAB308] text-slate-950 font-bold py-2.5 px-4 rounded-lg text-xs flex items-center justify-center gap-2 transition cursor-pointer shadow-xs"
            >
              <Search className="w-3.5 h-3.5 stroke-[2.5]" />
              <span>{t.searchBookingBtn}</span>
            </button>
          </form>

          {cancelMessage && (
            <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-3 rounded-lg text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{cancelMessage}</span>
            </div>
          )}

          {/* Results Display */}
          {searched && (
            <div>
              {!foundReservation ? (
                <div className="text-center py-6 text-slate-500 text-xs">
                  {t.bookingNotFound}
                </div>
              ) : (
                <div className="bg-slate-50 rounded-xl p-5 border border-slate-200 space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                    <div>
                      <span className="text-xs font-mono font-bold text-slate-900">
                        {foundReservation.id}
                      </span>
                      <span className="text-[11px] text-slate-400 block mt-0.5">
                        创建时间: {new Date(foundReservation.createdAt).toLocaleDateString()}
                      </span>
                    </div>

                    <span className={`text-xs font-bold px-2.5 py-0.5 rounded-full ${
                      foundReservation.status === 'CONFIRMED'
                        ? 'bg-emerald-100 text-emerald-800'
                        : foundReservation.status === 'CHECKED_IN'
                        ? 'bg-blue-100 text-blue-800'
                        : foundReservation.status === 'CANCELLED'
                        ? 'bg-slate-200 text-slate-600'
                        : 'bg-amber-100 text-amber-800'
                    }`}>
                      {foundReservation.status === 'CONFIRMED' && '已确认预订'}
                      {foundReservation.status === 'CHECKED_IN' && '正在入住中'}
                      {foundReservation.status === 'CHECKED_OUT' && '已离店'}
                      {foundReservation.status === 'CANCELLED' && '已取消订单'}
                      {foundReservation.status === 'HOLD' && '待支付锁定中'}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div>
                      <span className="text-slate-400 block">酒店分店:</span>
                      <span className="font-semibold text-slate-900">{foundReservation.hotelName}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block">房型规格:</span>
                      <span className="font-semibold text-slate-900">{foundReservation.roomTypeName} ({foundReservation.roomsCount}间)</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block">入住日期:</span>
                      <span className="font-semibold text-slate-900">{foundReservation.checkInDate} 至 {foundReservation.checkOutDate}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block">住客姓名:</span>
                      <span className="font-semibold text-slate-900">{foundReservation.guestName}</span>
                    </div>
                    {foundReservation.assignedRoomNumber && (
                      <div>
                        <span className="text-slate-400 block">分配房号:</span>
                        <span className="font-bold text-amber-600">#{foundReservation.assignedRoomNumber} 房</span>
                      </div>
                    )}
                    <div>
                      <span className="text-slate-400 block">支付金额:</span>
                      <span className="font-bold text-slate-900">¥{foundReservation.totalAmount} ({foundReservation.paymentStatus === 'PAID' ? '已支付' : '待付/退款'})</span>
                    </div>
                  </div>

                  {/* Cancellation prompt or button */}
                  {foundReservation.status === 'CONFIRMED' && (
                    <div className="pt-3 border-t border-slate-200">
                      {!cancelPrompt ? (
                        <button
                          type="button"
                          onClick={() => setCancelPrompt(true)}
                          className="text-xs text-rose-600 hover:text-rose-700 font-semibold flex items-center gap-1 cursor-pointer"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                          <span>{t.cancelBooking}</span>
                        </button>
                      ) : (
                        <div className="bg-rose-50 p-3 rounded-lg border border-rose-200 text-xs space-y-2">
                          <p className="text-rose-800 font-medium">
                            {t.cancelConfirmPrompt}
                          </p>
                          <div className="flex items-center gap-2">
                            <button
                              type="button"
                              onClick={handleConfirmCancel}
                              className="bg-rose-600 hover:bg-rose-700 text-white font-bold px-3 py-1.5 rounded-md cursor-pointer"
                            >
                              确认退订并退款
                            </button>
                            <button
                              type="button"
                              onClick={() => setCancelPrompt(false)}
                              className="bg-slate-200 hover:bg-slate-300 text-slate-700 px-3 py-1.5 rounded-md cursor-pointer"
                            >
                              放弃取消
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
