'use client';

import React, { useState } from 'react';
import { Logo } from './Logo';
import { Language, translations } from '../lib/i18n';
import { UserRole } from '../lib/types';
import { Globe, User, ShieldCheck, ChevronDown, Calendar, Sparkles } from 'lucide-react';

interface HeaderProps {
  currentLang: Language;
  onLanguageChange: (lang: Language) => void;
  activeNav: string;
  onNavClick: (navKey: string) => void;
  userRole: UserRole;
  onRoleChange: (role: UserRole) => void;
  onOpenLookup: () => void;
  onOpenMemberModal: () => void;
}

export function Header({
  currentLang,
  onLanguageChange,
  activeNav,
  onNavClick,
  userRole,
  onRoleChange,
  onOpenLookup,
  onOpenMemberModal,
}: HeaderProps) {
  const [langDropdownOpen, setLangDropdownOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const t = translations[currentLang];

  const navItems = [
    { key: 'home', label: t.home },
    { key: 'reservation', label: t.hotelReservation },
    { key: 'member', label: t.memberCenter },
    { key: 'about', label: t.aboutUs },
    { key: 'help', label: t.helpCenter },
  ];

  const handleNavSelect = (key: string) => {
    if (key === 'member') {
      onOpenMemberModal();
    } else {
      onNavClick(key);
    }
  };

  return (
    <header className="sticky top-0 z-50 bg-[#111827] text-white border-b border-slate-800 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between">
        {/* Brand logo & tagline */}
        <div onClick={() => onNavClick('home')}>
          <Logo />
        </div>

        {/* Center navigation links */}
        <nav className="hidden md:flex items-center gap-8">
          {navItems.map((item) => {
            const isActive = activeNav === item.key;
            return (
              <button
                key={item.key}
                onClick={() => handleNavSelect(item.key)}
                className={`text-sm font-medium tracking-wide transition-colors py-2 relative cursor-pointer ${
                  isActive
                    ? 'text-[#FACC15] font-semibold'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                {item.label}
                {isActive && (
                  <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#FACC15] rounded-full" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Right controls: Language & User/Admin Portal */}
        <div className="flex items-center gap-3 sm:gap-4">
          {/* Quick Booking Lookup Button */}
          <button
            onClick={onOpenLookup}
            className="hidden sm:flex items-center gap-1.5 text-xs text-slate-300 hover:text-[#FACC15] bg-slate-800/80 hover:bg-slate-800 px-3 py-1.5 rounded-full border border-slate-700 transition cursor-pointer"
          >
            <Calendar className="w-3.5 h-3.5 text-[#FACC15]" />
            <span>{currentLang === 'zh' ? '预订查询' : 'Find Booking'}</span>
          </button>

          {/* Language Selector */}
          <div className="relative">
            <button
              onClick={() => {
                setLangDropdownOpen(!langDropdownOpen);
                setUserMenuOpen(false);
              }}
              className="flex items-center gap-1.5 text-xs text-slate-200 hover:text-white bg-slate-800/60 hover:bg-slate-800 px-2.5 py-1.5 rounded-md border border-slate-700/60 transition cursor-pointer"
            >
              <span className="text-sm">{currentLang === 'zh' ? '🇨🇳' : '🇬🇧'}</span>
              <span className="font-medium">{currentLang === 'zh' ? '中文' : 'EN'}</span>
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>

            {langDropdownOpen && (
              <div className="absolute right-0 mt-2 w-32 bg-[#1E293B] border border-slate-700 rounded-lg shadow-xl py-1 z-50 text-xs">
                <button
                  onClick={() => {
                    onLanguageChange('zh');
                    setLangDropdownOpen(false);
                  }}
                  className={`w-full text-left px-3 py-2 flex items-center justify-between hover:bg-slate-700 cursor-pointer ${
                    currentLang === 'zh' ? 'text-[#FACC15] font-bold' : 'text-slate-200'
                  }`}
                >
                  <span>🇨🇳 简体中文</span>
                  {currentLang === 'zh' && <span>✓</span>}
                </button>
                <button
                  onClick={() => {
                    onLanguageChange('en');
                    setLangDropdownOpen(false);
                  }}
                  className={`w-full text-left px-3 py-2 flex items-center justify-between hover:bg-slate-700 cursor-pointer ${
                    currentLang === 'en' ? 'text-[#FACC15] font-bold' : 'text-slate-200'
                  }`}
                >
                  <span>🇬🇧 English</span>
                  {currentLang === 'en' && <span>✓</span>}
                </button>
              </div>
            )}
          </div>

          {/* User & Hotel Admin Switcher */}
          <div className="relative">
            <button
              onClick={() => {
                setUserMenuOpen(!userMenuOpen);
                setLangDropdownOpen(false);
              }}
              className="flex items-center gap-2 text-xs font-medium text-slate-100 hover:text-white bg-transparent hover:bg-slate-800 px-3 py-1.5 rounded-full border border-slate-600 transition cursor-pointer"
            >
              <User className="w-3.5 h-3.5 text-slate-300" />
              <span>
                {userRole === 'GUEST'
                  ? t.loginRegister
                  : userRole === 'FRONT_DESK'
                  ? (currentLang === 'zh' ? '前台接待' : 'Front Desk')
                  : userRole === 'HOTEL_MANAGER'
                  ? (currentLang === 'zh' ? '酒店店长' : 'Manager')
                  : (currentLang === 'zh' ? '系统管理' : 'Admin')}
              </span>
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>

            {userMenuOpen && (
              <div className="absolute right-0 mt-2 w-64 bg-[#1E293B] border border-slate-700 rounded-xl shadow-2xl p-2 z-50 text-xs">
                <div className="px-3 py-2 border-b border-slate-700/80 mb-1">
                  <div className="text-[11px] text-slate-400 uppercase tracking-wider">
                    {currentLang === 'zh' ? '当前身份 / 权限' : 'Current Role & Permissions'}
                  </div>
                  <div className="font-semibold text-white mt-0.5 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                    {userRole === 'GUEST'
                      ? (currentLang === 'zh' ? '普通旅客 / 会员' : 'Guest / Member')
                      : (currentLang === 'zh' ? `已登录: ${userRole}` : `Signed in: ${userRole}`)}
                  </div>
                </div>

                <div className="space-y-0.5">
                  <button
                    onClick={() => {
                      onRoleChange('GUEST');
                      setUserMenuOpen(false);
                    }}
                    className={`w-full text-left px-3 py-2 rounded-lg flex items-center justify-between hover:bg-slate-700 cursor-pointer ${
                      userRole === 'GUEST' ? 'bg-slate-700/50 text-[#FACC15]' : 'text-slate-200'
                    }`}
                  >
                    <span className="flex items-center gap-2">
                      <User className="w-3.5 h-3.5 text-slate-400" />
                      {currentLang === 'zh' ? '旅客预订模式' : 'Guest Mode'}
                    </span>
                    {userRole === 'GUEST' && <span className="text-[10px] bg-[#FACC15]/20 text-[#FACC15] px-1.5 py-0.5 rounded">当前</span>}
                  </button>

                  <button
                    onClick={() => {
                      onOpenMemberModal();
                      setUserMenuOpen(false);
                    }}
                    className="w-full text-left px-3 py-2 rounded-lg flex items-center gap-2 hover:bg-slate-700 text-slate-200 cursor-pointer"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-[#FACC15]" />
                    <span>{currentLang === 'zh' ? '7天会会员中心' : '7 Days Club'}</span>
                  </button>

                  <div className="my-1 border-t border-slate-700/80" />
                  <div className="px-3 py-1 text-[10px] text-slate-400 font-medium">
                    {currentLang === 'zh' ? '酒店工作人员通道 (PMS系统)' : 'Hotel Staff PMS Access'}
                  </div>

                  <button
                    onClick={() => {
                      onRoleChange('FRONT_DESK');
                      onNavClick('admin');
                      setUserMenuOpen(false);
                    }}
                    className={`w-full text-left px-3 py-2 rounded-lg flex items-center justify-between hover:bg-slate-700 cursor-pointer ${
                      userRole === 'FRONT_DESK' ? 'bg-slate-700/50 text-[#FACC15]' : 'text-slate-200'
                    }`}
                  >
                    <span className="flex items-center gap-2">
                      <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                      {currentLang === 'zh' ? '前台接待 (快速办理入住/退房)' : 'Front Desk Reception'}
                    </span>
                    {userRole === 'FRONT_DESK' && <span className="text-[10px] bg-amber-400/20 text-amber-300 px-1.5 py-0.5 rounded">激活</span>}
                  </button>

                  <button
                    onClick={() => {
                      onRoleChange('HOTEL_MANAGER');
                      onNavClick('admin');
                      setUserMenuOpen(false);
                    }}
                    className={`w-full text-left px-3 py-2 rounded-lg flex items-center justify-between hover:bg-slate-700 cursor-pointer ${
                      userRole === 'HOTEL_MANAGER' ? 'bg-slate-700/50 text-[#FACC15]' : 'text-slate-200'
                    }`}
                  >
                    <span className="flex items-center gap-2">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                      {currentLang === 'zh' ? '酒店店长 (房价/房态/报表)' : 'Hotel General Manager'}
                    </span>
                    {userRole === 'HOTEL_MANAGER' && <span className="text-[10px] bg-emerald-400/20 text-emerald-300 px-1.5 py-0.5 rounded">激活</span>}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
