'use client';

import React from 'react';

interface LogoProps {
  lightMode?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

export function Logo({ lightMode = false, size = 'md' }: LogoProps) {
  const isSm = size === 'sm';
  const isLg = size === 'lg';

  return (
    <div className="flex items-center gap-2.5 select-none cursor-pointer">
      {/* Brand Icon: Yellow angled parallelogram with sharp 7 */}
      <div 
        className={`relative flex items-center justify-center font-black tracking-tighter shadow-sm transition-transform duration-200 hover:scale-105 ${
          isSm ? 'w-7 h-7 text-lg' : isLg ? 'w-11 h-11 text-2xl' : 'w-9 h-9 text-xl'
        } bg-[#FACC15] text-slate-950`}
        style={{
          clipPath: 'polygon(24% 0%, 100% 0%, 76% 100%, 0% 100%)',
          borderRadius: '2px',
        }}
      >
        <span className="italic font-extrabold translate-x-[-1px] font-sans">7</span>
      </div>

      {/* Brand Text & Slogan */}
      <div className="flex flex-col">
        <span 
          className={`font-black tracking-tight leading-none ${
            isSm ? 'text-base' : isLg ? 'text-2xl' : 'text-lg'
          } ${lightMode ? 'text-slate-900' : 'text-white'}`}
        >
          7天酒店
        </span>
        <span 
          className={`tracking-wider leading-tight mt-0.5 font-medium ${
            isSm ? 'text-[10px]' : 'text-xs'
          } ${lightMode ? 'text-slate-500' : 'text-[#FACC15]'}`}
        >
          好睡 · 省钱 · 到哪都在
        </span>
      </div>
    </div>
  );
}
