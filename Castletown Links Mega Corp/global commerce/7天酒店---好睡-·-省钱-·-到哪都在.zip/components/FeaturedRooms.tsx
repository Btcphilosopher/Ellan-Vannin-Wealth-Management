'use client';

import React from 'react';
import { Language, translations } from '../lib/i18n';
import { RoomType, Hotel } from '../lib/types';
import { ArrowRight, Bed, Maximize2, Users, Flame } from 'lucide-react';

interface FeaturedRoomsProps {
  currentLang: Language;
  hotel: Hotel;
  onBookRoom: (room: RoomType) => void;
  onViewAllRooms: () => void;
}

export function FeaturedRooms({
  currentLang,
  hotel,
  onBookRoom,
  onViewAllRooms,
}: FeaturedRoomsProps) {
  const t = translations[currentLang];

  // Pick the 3 primary rooms matching the screenshot:
  // 1. 经济大床房 (Economy King)
  // 2. 标准双床房 (Standard Twin)
  // 3. 家庭房 (Family Suite)
  const room1 = hotel.roomTypes.find(r => r.name.includes('经济大床') || r.id.includes('economy')) || hotel.roomTypes[0];
  const room2 = hotel.roomTypes.find(r => r.name.includes('标准双床') || r.id.includes('twin')) || hotel.roomTypes[1];
  const room3 = hotel.roomTypes.find(r => r.name.includes('家庭') || r.id.includes('family')) || hotel.roomTypes[2];

  const featuredList = [room1, room2, room3].filter(Boolean);

  return (
    <section className="py-12 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 pb-3 border-b border-slate-200/60">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                {t.featuredRooms}
              </h2>
              <span className="text-xs bg-amber-100 text-amber-800 font-medium px-2 py-0.5 rounded-full">
                热门热销
              </span>
            </div>
            <p className="text-sm text-slate-500 mt-1">
              {t.featuredRoomsDesc}
            </p>
          </div>

          <button
            onClick={onViewAllRooms}
            className="mt-3 sm:mt-0 flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-slate-600 hover:text-slate-900 transition-colors group cursor-pointer"
          >
            <span>{t.viewMoreRooms}</span>
            <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
          </button>
        </div>

        {/* 4-Item Grid matching screenshot: 3 room cards + 1 dark brand promotion card */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredList.map((room) => {
            return (
              <div
                key={room.id}
                className="bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow border border-slate-200 flex flex-col group"
              >
                {/* Room Image */}
                <div className="relative aspect-[4/3] w-full overflow-hidden bg-slate-100">
                  <img
                    src={room.image}
                    alt={currentLang === 'zh' ? room.name : room.nameEn}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute top-2.5 left-2.5 bg-slate-950/70 backdrop-blur-xs text-white text-[11px] font-medium px-2 py-0.5 rounded">
                    {room.window}
                  </div>
                </div>

                {/* Room Body */}
                <div className="p-4 flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="text-base font-bold text-slate-900 tracking-tight">
                      {currentLang === 'zh' ? room.name : room.nameEn}
                    </h3>

                    {/* Room Specs Line */}
                    <div className="text-xs text-slate-500 mt-1.5 flex items-center flex-wrap gap-1">
                      <span>{currentLang === 'zh' ? room.bedInfo : room.bedInfoEn}</span>
                      <span>·</span>
                      <span>{room.area}</span>
                      <span>·</span>
                      <span>{room.occupancy}</span>
                    </div>

                    {/* Feature tags */}
                    <div className="flex flex-wrap gap-1 mt-3">
                      {room.amenities.slice(0, 3).map((amenity, i) => (
                        <span
                          key={i}
                          className="text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded"
                        >
                          {amenity}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Price & Book CTA */}
                  <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between">
                    <div>
                      <div className="flex items-baseline">
                        <span className="text-sm font-bold text-amber-500">¥</span>
                        <span className="text-2xl font-black text-amber-500 tracking-tight ml-0.5 tabular-nums">
                          {room.basePrice}
                        </span>
                        <span className="text-xs text-slate-400 ml-1">
                          {t.perNightFrom}
                        </span>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => onBookRoom(room)}
                      className="bg-[#FACC15] hover:bg-[#EAB308] text-slate-950 font-bold px-5 py-2 rounded-lg text-xs shadow-xs transition-colors cursor-pointer"
                    >
                      {t.book}
                    </button>
                  </div>
                </div>
              </div>
            );
          })}

          {/* Card 4: Right Feature Promotion Card (Over 500 Hotels Nationwide) */}
          <div className="relative rounded-xl overflow-hidden shadow-sm border border-slate-800 bg-[#111827] flex flex-col justify-between p-6 text-white min-h-[340px]">
            {/* Background image: Shanghai skyline with traditional pagoda */}
            <div className="absolute inset-0 z-0">
              <img
                src="/images/shanghai_skyline.jpg"
                alt="7 Days Inn Nationwide Coverage"
                className="w-full h-full object-cover filter brightness-[0.45]"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/70 to-slate-900/60" />
            </div>

            {/* Content Overlay */}
            <div className="relative z-10">
              <div className="inline-flex items-center gap-1.5 bg-[#FACC15]/20 text-[#FACC15] text-[11px] font-semibold px-2 py-0.5 rounded-md mb-3 border border-[#FACC15]/30">
                <Flame className="w-3.5 h-3.5 text-[#FACC15]" />
                <span>全国连锁 · 值得信赖</span>
              </div>
              <h3 className="text-xl sm:text-2xl font-black tracking-tight text-white leading-tight">
                {t.over500Hotels}
              </h3>
              <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                {t.over500HotelsDesc}
              </p>
            </div>

            <div className="relative z-10 pt-6">
              <button
                type="button"
                onClick={onViewAllRooms}
                className="inline-flex items-center gap-2 border border-slate-300/80 hover:border-white text-white hover:bg-white/10 text-xs font-semibold px-4 py-2.5 rounded-lg transition-colors cursor-pointer backdrop-blur-xs"
              >
                <span>{t.viewBranches}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
