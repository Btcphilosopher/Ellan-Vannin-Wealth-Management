'use client';

import React from 'react';
import { Language, translations } from '../lib/i18n';
import { X, CheckCircle, HelpCircle, Smartphone, Apple, ShieldCheck, QrCode } from 'lucide-react';

interface InfoModalProps {
  type: 'ABOUT' | 'HELP' | 'APP' | 'TERMS' | null;
  currentLang: Language;
  onClose: () => void;
}

export function InfoModals({ type, currentLang, onClose }: InfoModalProps) {
  if (!type) return null;
  const t = translations[currentLang];

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden my-auto">
        {/* Header */}
        <div className="bg-[#111827] text-white px-6 py-4 flex items-center justify-between">
          <h3 className="text-base font-bold text-white">
            {type === 'ABOUT' && '关于 7天酒店品牌'}
            {type === 'HELP' && '帮助中心与住客常见问题 (FAQ)'}
            {type === 'APP' && '下载 7天酒店 APP'}
            {type === 'TERMS' && '服务条款与住客预订须知'}
          </h3>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body Content */}
        <div className="p-6 text-xs text-slate-600 space-y-4 max-h-[75vh] overflow-y-auto">
          {type === 'ABOUT' && (
            <div className="space-y-3">
              <p className="leading-relaxed">
                <strong>7天酒店</strong>是中国领先的经济型连锁酒店品牌，深耕国内商旅与大众出行市场，以「<strong>好睡 · 省钱 · 到哪都在</strong>」为核心价值主张。
              </p>
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-2">
                <div className="font-bold text-slate-900">核心品质标准:</div>
                <div className="flex items-center gap-2 text-slate-700">
                  <CheckCircle className="w-4 h-4 text-amber-500 shrink-0" />
                  <span><strong>一客一换:</strong> 严格封包洁净布草与高温灭菌洗涤</span>
                </div>
                <div className="flex items-center gap-2 text-slate-700">
                  <CheckCircle className="w-4 h-4 text-amber-500 shrink-0" />
                  <span><strong>10秒速热:</strong> 恒温恒压充沛淋浴喷淋系统</span>
                </div>
                <div className="flex items-center gap-2 text-slate-700">
                  <CheckCircle className="w-4 h-4 text-amber-500 shrink-0" />
                  <span><strong>深度好眠:</strong> 定制护脊床垫与静音隔音工艺</span>
                </div>
              </div>
              <p className="text-slate-500">
                目前已覆盖全国超过300座核心城市，累计运营超过500家标准化酒店，为超3亿人次出行旅客提供经济、安心、便捷的住宿体验。
              </p>
            </div>
          )}

          {type === 'HELP' && (
            <div className="space-y-3">
              <div>
                <h4 className="font-bold text-slate-900 mb-1">Q: 入住与退房的标准时间是？</h4>
                <p>A: 正常入住时间为每日 14:00 之后，退房时间为次日 12:00 之前。会员可享受延迟退房特权（金卡至14:00）。</p>
              </div>
              <div className="pt-2 border-t border-slate-100">
                <h4 className="font-bold text-slate-900 mb-1">Q: 订单如何取消与退款？</h4>
                <p>A: 标准灵活价订单在入住当天 18:00 前可通过本网站「预订查询」自助免费取消，房费将原路全额退款至微信/支付宝；早鸟特惠订单为不可退特价。</p>
              </div>
              <div className="pt-2 border-t border-slate-100">
                <h4 className="font-bold text-slate-900 mb-1">Q: 入住需要携带什么证件？</h4>
                <p>A: 根据公安旅馆业治安管理规定，所有同住人均须出示本人有效二代身份证或护照办理实名登记。</p>
              </div>
            </div>
          )}

          {type === 'APP' && (
            <div className="text-center space-y-4 py-2">
              <div className="w-40 h-40 bg-white p-3 rounded-xl border border-slate-200 mx-auto shadow-xs flex flex-col items-center justify-center">
                <QrCode className="w-24 h-24 text-slate-900" />
                <span className="text-[10px] text-slate-500 mt-2 font-mono">扫描快速下载 App</span>
              </div>
              <p className="font-bold text-slate-800 text-sm">
                订房更快 · 享APP专属立减红包
              </p>
              <div className="flex items-center gap-3 justify-center">
                <button
                  onClick={onClose}
                  className="bg-slate-900 hover:bg-slate-800 text-white px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-1.5"
                >
                  <Apple className="w-3.5 h-3.5" />
                  <span>App Store 下载</span>
                </button>
                <button
                  onClick={onClose}
                  className="bg-slate-900 hover:bg-slate-800 text-white px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-1.5"
                >
                  <Smartphone className="w-3.5 h-3.5" />
                  <span>Android APK 下载</span>
                </button>
              </div>
            </div>
          )}

          {type === 'TERMS' && (
            <div className="space-y-3">
              <p>
                欢迎使用 7天酒店官方在线客房预订服务。在确认预订前，请仔细阅读以下条款：
              </p>
              <ul className="list-disc pl-4 space-y-1 text-slate-500">
                <li>房间保留策略：临时锁房有效期为5分钟，超时未付将自动释放给其他旅客。</li>
                <li>发票开具：离店后可在前台开具增值税电子普通发票或专用发票。</li>
                <li>严禁在禁烟客房内吸烟或携带易燃易爆危险物品。</li>
              </ul>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
