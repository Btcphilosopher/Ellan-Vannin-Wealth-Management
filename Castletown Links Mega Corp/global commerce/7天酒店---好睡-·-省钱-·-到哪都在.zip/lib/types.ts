export type UserRole = 'GUEST' | 'FRONT_DESK' | 'HOTEL_MANAGER' | 'ADMIN';

export interface RatePlan {
  id: string;
  name: string;
  nameEn: string;
  priceDiscountMultiplier: number;
  fixedDiscount: number;
  cancellationPolicy: string;
  cancellationPolicyEn: string;
  breakfastIncluded: boolean;
  payNow: boolean;
  isMemberOnly?: boolean;
}

export interface RoomType {
  id: string;
  hotelId: string;
  name: string;
  nameEn: string;
  bedInfo: string;
  bedInfoEn: string;
  area: string;
  occupancy: string;
  occupancyMax: number;
  window: string;
  floor: string;
  image: string;
  basePrice: number;
  totalRooms: number;
  amenities: string[];
  description: string;
  descriptionEn: string;
  ratePlans: RatePlan[];
}

export interface Hotel {
  id: string;
  name: string;
  nameEn: string;
  city: string;
  cityEn: string;
  address: string;
  addressEn: string;
  rating: number;
  reviewCount: number;
  image: string;
  tags: string[];
  amenities: string[];
  checkInTime: string;
  checkOutTime: string;
  phone: string;
  minPrice: number;
  roomTypes: RoomType[];
}

export type ReservationStatus = 
  | 'PENDING'
  | 'HOLD'
  | 'CONFIRMED'
  | 'CHECKED_IN'
  | 'CHECKED_OUT'
  | 'CANCELLED'
  | 'REFUNDED'
  | 'NO_SHOW';

export type PaymentMethod = 'WECHAT' | 'ALIPAY' | 'UNIONPAY' | 'HOTEL_FRONT';

export interface Reservation {
  id: string;
  hotelId: string;
  hotelName: string;
  hotelAddress: string;
  hotelPhone: string;
  roomTypeId: string;
  roomTypeName: string;
  ratePlanId: string;
  ratePlanName: string;
  checkInDate: string;
  checkOutDate: string;
  nights: number;
  roomsCount: number;
  adultsCount: number;
  guestName: string;
  guestPhone: string;
  guestIdCard: string;
  specialRequests?: string;
  subtotalAmount: number;
  discountAmount: number;
  taxAmount: number;
  totalAmount: number;
  currency: 'CNY';
  status: ReservationStatus;
  paymentStatus: 'UNPAID' | 'PAID' | 'REFUNDED';
  paymentMethod?: PaymentMethod;
  assignedRoomNumber?: string;
  createdAt: string;
  holdExpiresAt?: string;
  notes?: string;
  cancelledAt?: string;
  cancellationReason?: string;
}

export interface SearchParams {
  destination: string;
  checkInDate: string;
  checkOutDate: string;
  rooms: number;
  adults: number;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  actor: string;
  action: string;
  targetId: string;
  details: string;
}
