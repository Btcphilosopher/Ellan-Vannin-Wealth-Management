import { Hotel, RoomType, Reservation, ReservationStatus, AuditLog, UserRole, PaymentMethod } from './types';
import { INITIAL_HOTELS } from './hotel-data';

const STORAGE_KEY_HOTELS = '7days_hotels_data';
const STORAGE_KEY_RESERVATIONS = '7days_reservations_data';
const STORAGE_KEY_AUDIT_LOGS = '7days_audit_logs';
const STORAGE_KEY_MAINTENANCE = '7days_maintenance_blocks';

export interface MaintenanceBlock {
  id: string;
  hotelId: string;
  roomTypeId: string;
  startDate: string;
  endDate: string;
  roomsCount: number;
  reason: string;
}

// Generate realistic initial reservations for demonstration & administration
const INITIAL_RESERVATIONS: Reservation[] = [
  {
    id: '7D-20261013-5821',
    hotelId: 'hotel-sh-bund',
    hotelName: '7天酒店·上海外滩南京东路步行街店',
    hotelAddress: '上海市黄浦区南京东路353号',
    hotelPhone: '021-63298888',
    roomTypeId: 'sh-economy-king',
    roomTypeName: '经济大床房',
    ratePlanId: 'plan-standard',
    ratePlanName: '标准灵活价',
    checkInDate: '2026-10-13',
    checkOutDate: '2026-10-14',
    nights: 1,
    roomsCount: 1,
    adultsCount: 1,
    guestName: '张建国',
    guestPhone: '13812345678',
    guestIdCard: '310101199003071234',
    specialRequests: '尽量安排高楼层无烟房',
    subtotalAmount: 148,
    discountAmount: 0,
    taxAmount: 13.32,
    totalAmount: 161.32,
    currency: 'CNY',
    status: 'CONFIRMED',
    paymentStatus: 'PAID',
    paymentMethod: 'WECHAT',
    assignedRoomNumber: '502',
    createdAt: '2026-10-12T14:20:00Z',
    notes: '常客，请提前准备洗漱备品'
  },
  {
    id: '7D-20261013-9142',
    hotelId: 'hotel-sh-bund',
    hotelName: '7天酒店·上海外滩南京东路步行街店',
    hotelAddress: '上海市黄浦区南京东路353号',
    hotelPhone: '021-63298888',
    roomTypeId: 'sh-standard-twin',
    roomTypeName: '标准双床房',
    ratePlanId: 'plan-member',
    ratePlanName: '会员专享95折',
    checkInDate: '2026-10-13',
    checkOutDate: '2026-10-15',
    nights: 2,
    roomsCount: 1,
    adultsCount: 2,
    guestName: '李明伟',
    guestPhone: '13987654321',
    guestIdCard: '110101198805123456',
    specialRequests: '需要两张房卡',
    subtotalAmount: 319.2,
    discountAmount: 16.8,
    taxAmount: 28.73,
    totalAmount: 347.93,
    currency: 'CNY',
    status: 'CHECKED_IN',
    paymentStatus: 'PAID',
    paymentMethod: 'ALIPAY',
    assignedRoomNumber: '308',
    createdAt: '2026-10-11T10:15:00Z',
    notes: '已办理入住，前台已发微信发票'
  }
];

class HotelBookingEngine {
  private hotels: Hotel[] = [];
  private reservations: Reservation[] = [];
  private auditLogs: AuditLog[] = [];
  private maintenanceBlocks: MaintenanceBlock[] = [];
  private isBrowser: boolean = typeof window !== 'undefined';

  constructor() {
    this.initData();
  }

  private initData() {
    if (!this.isBrowser) {
      this.hotels = INITIAL_HOTELS;
      this.reservations = INITIAL_RESERVATIONS;
      this.auditLogs = [];
      this.maintenanceBlocks = [];
      return;
    }

    try {
      const storedHotels = localStorage.getItem(STORAGE_KEY_HOTELS);
      this.hotels = storedHotels ? JSON.parse(storedHotels) : INITIAL_HOTELS;

      const storedRes = localStorage.getItem(STORAGE_KEY_RESERVATIONS);
      this.reservations = storedRes ? JSON.parse(storedRes) : INITIAL_RESERVATIONS;

      const storedLogs = localStorage.getItem(STORAGE_KEY_AUDIT_LOGS);
      this.auditLogs = storedLogs ? JSON.parse(storedLogs) : [];

      const storedMaint = localStorage.getItem(STORAGE_KEY_MAINTENANCE);
      this.maintenanceBlocks = storedMaint ? JSON.parse(storedMaint) : [];

      // Clean up expired holds on startup
      this.releaseExpiredHolds();
    } catch {
      this.hotels = INITIAL_HOTELS;
      this.reservations = INITIAL_RESERVATIONS;
      this.auditLogs = [];
      this.maintenanceBlocks = [];
    }
  }

  private persist() {
    if (!this.isBrowser) return;
    try {
      localStorage.setItem(STORAGE_KEY_HOTELS, JSON.stringify(this.hotels));
      localStorage.setItem(STORAGE_KEY_RESERVATIONS, JSON.stringify(this.reservations));
      localStorage.setItem(STORAGE_KEY_AUDIT_LOGS, JSON.stringify(this.auditLogs));
      localStorage.setItem(STORAGE_KEY_MAINTENANCE, JSON.stringify(this.maintenanceBlocks));
    } catch (err) {
      console.error('Storage persist error:', err);
    }
  }

  public releaseExpiredHolds(): number {
    const now = Date.now();
    let released = 0;
    this.reservations = this.reservations.map(res => {
      if (res.status === 'HOLD' && res.holdExpiresAt && new Date(res.holdExpiresAt).getTime() < now) {
        released++;
        this.logAudit('SYSTEM', 'HOLD_EXPIRED', res.id, `Temporary hold expired for reservation ${res.id}`);
        return { ...res, status: 'CANCELLED' as ReservationStatus, cancellationReason: 'Hold timer expired' };
      }
      return res;
    });
    if (released > 0) {
      this.persist();
    }
    return released;
  }

  public logAudit(actor: string, action: string, targetId: string, details: string) {
    const entry: AuditLog = {
      id: `LOG-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString(),
      actor,
      action,
      targetId,
      details,
    };
    this.auditLogs.unshift(entry);
    if (this.auditLogs.length > 200) {
      this.auditLogs = this.auditLogs.slice(0, 200);
    }
    this.persist();
  }

  public getHotels(): Hotel[] {
    return this.hotels;
  }

  public getHotelById(id: string): Hotel | undefined {
    return this.hotels.find(h => h.id === id);
  }

  public searchHotels(keyword: string): Hotel[] {
    if (!keyword || !keyword.trim()) return this.hotels;
    const term = keyword.trim().toLowerCase();
    return this.hotels.filter(h => 
      h.name.toLowerCase().includes(term) ||
      h.nameEn.toLowerCase().includes(term) ||
      h.city.toLowerCase().includes(term) ||
      h.cityEn.toLowerCase().includes(term) ||
      h.address.toLowerCase().includes(term) ||
      h.tags.some(tag => tag.toLowerCase().includes(term))
    );
  }

  public getAvailableRooms(hotelId: string, roomTypeId: string, checkIn: string, checkOut: string): number {
    this.releaseExpiredHolds();
    const hotel = this.getHotelById(hotelId);
    if (!hotel) return 0;
    const roomType = hotel.roomTypes.find(r => r.id === roomTypeId);
    if (!roomType) return 0;

    const totalPhysical = roomType.totalRooms;

    // Count conflicting reservations
    // Condition: res.checkInDate < checkOut && res.checkOutDate > checkIn
    const conflictingBookings = this.reservations.filter(res => {
      if (res.hotelId !== hotelId || res.roomTypeId !== roomTypeId) return false;
      if (res.status === 'CANCELLED' || res.status === 'REFUNDED') return false;
      return res.checkInDate < checkOut && res.checkOutDate > checkIn;
    }).reduce((sum, r) => sum + r.roomsCount, 0);

    // Count maintenance closures
    const maintenanceCount = this.maintenanceBlocks.filter(m => {
      if (m.hotelId !== hotelId || m.roomTypeId !== roomTypeId) return false;
      return m.startDate < checkOut && m.endDate > checkIn;
    }).reduce((sum, m) => sum + m.roomsCount, 0);

    const available = totalPhysical - conflictingBookings - maintenanceCount;
    return Math.max(0, available);
  }

  public calculateStayPrice(
    basePrice: number,
    multiplier: number,
    fixedDiscount: number,
    nights: number,
    roomsCount: number
  ) {
    const nightlyPrice = Math.max(50, Math.round(basePrice * multiplier - fixedDiscount));
    const subtotal = nightlyPrice * nights * roomsCount;
    const taxAndService = Math.round(subtotal * 0.09 * 100) / 100;
    const total = Math.round((subtotal + taxAndService) * 100) / 100;

    return {
      nightlyPrice,
      subtotal,
      taxAndService,
      total,
      currency: 'CNY' as const
    };
  }

  // Atomic hold creation with concurrency check
  public createRoomHold(params: {
    hotelId: string;
    roomTypeId: string;
    ratePlanId: string;
    checkInDate: string;
    checkOutDate: string;
    nights: number;
    roomsCount: number;
    adultsCount: number;
    guestName: string;
    guestPhone: string;
    guestIdCard: string;
    specialRequests?: string;
  }): { success: boolean; reservation?: Reservation; message?: string } {
    this.releaseExpiredHolds();

    const available = this.getAvailableRooms(
      params.hotelId,
      params.roomTypeId,
      params.checkInDate,
      params.checkOutDate
    );

    if (available < params.roomsCount) {
      return {
        success: false,
        message: '抱歉，所选日期该房型库存已被其他旅客订满，请选择其他房型或调整日期。'
      };
    }

    const hotel = this.getHotelById(params.hotelId);
    if (!hotel) return { success: false, message: '分店不存在' };
    const roomType = hotel.roomTypes.find(r => r.id === params.roomTypeId);
    if (!roomType) return { success: false, message: '房型不存在' };
    const ratePlan = roomType.ratePlans.find(p => p.id === params.ratePlanId) || roomType.ratePlans[0];

    const priceCalc = this.calculateStayPrice(
      roomType.basePrice,
      ratePlan.priceDiscountMultiplier,
      ratePlan.fixedDiscount,
      params.nights,
      params.roomsCount
    );

    const now = new Date();
    const expiry = new Date(now.getTime() + 5 * 60 * 1000); // 5 minute lock
    const refCode = `7D-${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}-${Math.floor(1000 + Math.random() * 9000)}`;

    const newReservation: Reservation = {
      id: refCode,
      hotelId: hotel.id,
      hotelName: hotel.name,
      hotelAddress: hotel.address,
      hotelPhone: hotel.phone,
      roomTypeId: roomType.id,
      roomTypeName: roomType.name,
      ratePlanId: ratePlan.id,
      ratePlanName: ratePlan.name,
      checkInDate: params.checkInDate,
      checkOutDate: params.checkOutDate,
      nights: params.nights,
      roomsCount: params.roomsCount,
      adultsCount: params.adultsCount,
      guestName: params.guestName,
      guestPhone: params.guestPhone,
      guestIdCard: params.guestIdCard,
      specialRequests: params.specialRequests,
      subtotalAmount: priceCalc.subtotal,
      discountAmount: Math.round((roomType.basePrice * params.nights * params.roomsCount - priceCalc.subtotal) * 100) / 100,
      taxAmount: priceCalc.taxAndService,
      totalAmount: priceCalc.total,
      currency: 'CNY',
      status: 'HOLD',
      paymentStatus: 'UNPAID',
      createdAt: now.toISOString(),
      holdExpiresAt: expiry.toISOString()
    };

    this.reservations.unshift(newReservation);
    this.logAudit(params.guestName || 'GUEST', 'CREATE_HOLD', newReservation.id, `Created 5-min temporary hold for ${params.roomsCount} room(s)`);
    this.persist();

    return { success: true, reservation: newReservation };
  }

  // Confirm booking after verified payment callback
  public confirmReservation(reservationId: string, paymentMethod: PaymentMethod): { success: boolean; reservation?: Reservation; message?: string } {
    this.releaseExpiredHolds();
    const idx = this.reservations.findIndex(r => r.id === reservationId);
    if (idx === -1) {
      return { success: false, message: '预订记录不存在' };
    }

    const res = this.reservations[idx];
    if (res.status === 'CANCELLED' || res.status === 'REFUNDED') {
      return { success: false, message: '预订已被取消或超时释放' };
    }

    const updated: Reservation = {
      ...res,
      status: 'CONFIRMED',
      paymentStatus: 'PAID',
      paymentMethod,
      holdExpiresAt: undefined,
    };

    this.reservations[idx] = updated;
    this.logAudit('PAYMENT_GATEWAY', 'CONFIRM_PAYMENT', reservationId, `Payment verified via ${paymentMethod}, reservation confirmed`);
    this.persist();

    return { success: true, reservation: updated };
  }

  // Lookup reservation by ID and Phone number
  public lookupReservation(id: string, phone: string): Reservation | undefined {
    const cleanId = id.trim().toUpperCase();
    const cleanPhone = phone.trim();
    return this.reservations.find(r => 
      r.id.toUpperCase() === cleanId && 
      (cleanPhone === '' || r.guestPhone.includes(cleanPhone))
    );
  }

  public getAllReservations(): Reservation[] {
    this.releaseExpiredHolds();
    return [...this.reservations];
  }

  public cancelReservation(reservationId: string, reason: string, actor: string = 'GUEST'): { success: boolean; message: string } {
    const idx = this.reservations.findIndex(r => r.id === reservationId);
    if (idx === -1) {
      return { success: false, message: '预订不存在' };
    }

    const res = this.reservations[idx];
    if (res.status === 'CHECKED_IN' || res.status === 'CHECKED_OUT') {
      return { success: false, message: '已入住或已离店订单不可取消' };
    }

    this.reservations[idx] = {
      ...res,
      status: 'CANCELLED',
      paymentStatus: res.paymentStatus === 'PAID' ? 'REFUNDED' : 'UNPAID',
      cancelledAt: new Date().toISOString(),
      cancellationReason: reason,
    };

    this.logAudit(actor, 'CANCEL_RESERVATION', reservationId, `Cancelled reservation. Reason: ${reason}. Inventory restored.`);
    this.persist();

    return { success: true, message: '预订已成功取消，房费已原路发起退款' };
  }

  // Admin PMS actions
  public checkInGuest(reservationId: string, assignedRoom: string, staffName: string): boolean {
    const idx = this.reservations.findIndex(r => r.id === reservationId);
    if (idx === -1) return false;

    this.reservations[idx] = {
      ...this.reservations[idx],
      status: 'CHECKED_IN',
      assignedRoomNumber: assignedRoom
    };
    this.logAudit(staffName, 'CHECK_IN', reservationId, `Guest checked in, allocated physical room #${assignedRoom}`);
    this.persist();
    return true;
  }

  public checkOutGuest(reservationId: string, staffName: string): boolean {
    const idx = this.reservations.findIndex(r => r.id === reservationId);
    if (idx === -1) return false;

    this.reservations[idx] = {
      ...this.reservations[idx],
      status: 'CHECKED_OUT'
    };
    this.logAudit(staffName, 'CHECK_OUT', reservationId, `Guest checked out from room #${this.reservations[idx].assignedRoomNumber || 'N/A'}`);
    this.persist();
    return true;
  }

  public updateRoomPrice(hotelId: string, roomTypeId: string, newBasePrice: number, staffName: string): boolean {
    const hotel = this.hotels.find(h => h.id === hotelId);
    if (!hotel) return false;
    const room = hotel.roomTypes.find(r => r.id === roomTypeId);
    if (!room) return false;

    const oldPrice = room.basePrice;
    room.basePrice = newBasePrice;
    hotel.minPrice = Math.min(...hotel.roomTypes.map(r => r.basePrice));

    this.logAudit(staffName, 'UPDATE_PRICE', roomTypeId, `Updated base rate from ¥${oldPrice} to ¥${newBasePrice}`);
    this.persist();
    return true;
  }

  public setMaintenanceBlock(block: Omit<MaintenanceBlock, 'id'>, staffName: string): boolean {
    const newBlock: MaintenanceBlock = {
      ...block,
      id: `MAINT-${Date.now()}`
    };
    this.maintenanceBlocks.push(newBlock);
    this.logAudit(staffName, 'SET_MAINTENANCE', block.roomTypeId, `Blocked ${block.roomsCount} room(s) for maintenance (${block.startDate} to ${block.endDate})`);
    this.persist();
    return true;
  }

  public getAuditLogs(): AuditLog[] {
    return [...this.auditLogs];
  }

  public getMaintenanceBlocks(): MaintenanceBlock[] {
    return [...this.maintenanceBlocks];
  }

  // Operational metrics for Hotel PMS Dashboard
  public getOperationalMetrics(hotelId?: string) {
    const all = hotelId ? this.reservations.filter(r => r.hotelId === hotelId) : this.reservations;
    const confirmed = all.filter(r => r.status === 'CONFIRMED' || r.status === 'CHECKED_IN');
    const today = new Date().toISOString().split('T')[0];

    const todayArrivals = all.filter(r => r.checkInDate === today && r.status !== 'CANCELLED');
    const todayDepartures = all.filter(r => r.checkOutDate === today && r.status !== 'CANCELLED');
    
    const totalPhysicalRooms = (hotelId 
      ? (this.getHotelById(hotelId)?.roomTypes.reduce((s, r) => s + r.totalRooms, 0) ?? 70)
      : this.hotels.reduce((s, h) => s + h.roomTypes.reduce((rs, r) => rs + r.totalRooms, 0), 0)
    ) || 120;

    const occupiedRooms = confirmed.reduce((s, r) => s + r.roomsCount, 0);
    const occupancyRate = Math.min(100, Math.round((occupiedRooms / totalPhysicalRooms) * 100));

    const totalRevenue = confirmed.reduce((s, r) => s + r.totalAmount, 0);
    const adr = occupiedRooms > 0 ? Math.round(totalRevenue / occupiedRooms) : 168;
    const revpar = Math.round(adr * (occupancyRate / 100));

    return {
      totalPhysicalRooms,
      occupiedRooms,
      occupancyRate,
      todayArrivalsCount: todayArrivals.length,
      todayDeparturesCount: todayDepartures.length,
      totalRevenue: Math.round(totalRevenue),
      adr,
      revpar
    };
  }
}

// Global singleton instance
export const bookingEngine = new HotelBookingEngine();
