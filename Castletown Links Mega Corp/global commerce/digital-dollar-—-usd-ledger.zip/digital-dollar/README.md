# DIGITAL DOLLAR — USD Ledger

A code-first, runnable digital-dollar prototype built with **Rust** (`axum`, `sqlx`, `utoipa`, `argon2`, `clap`), **PostgreSQL**, **Python** (`httpx`, `psycopg`, `pytest`), **Docker Compose**, and **OpenAPI**.

> **Scope Notice:** This is a local demonstration and research prototype. It does not claim high availability, national-scale capacity, real banking rail connectivity, or production certification. No blockchain, mining, or speculative token is used.

---

## 1. Repository Structure

```text
digital-dollar/
  Cargo.toml                 # Pinned Rust workspace dependencies
  rust-toolchain.toml        # Pinned Rust 1.85.0 toolchain
  crates/
    dollar_types/            # Validated Money (i64 cents), opaque IDs, roles, DomainError
    dollar_auth/             # Argon2id hashing, HMAC-SHA256 sessions, RBAC, rate limits, audit log
    dollar_ledger/           # Authoritative double-entry engine, reservations, idempotency, reconciliation
    dollar_issuer/           # Dual-control issuance (Requested -> Reviewed -> Approved -> Posted -> Reconciled)
    dollar_payments/         # Transfers, signed merchant requests, partial refunds, scheduled payments, conversions
    dollar_api/              # Axum 0.8 + utoipa OpenAPI server + background workers
    dollar_cli/              # Ergonomic CLI client (`dollar-cli`)
  migrations/
    0001_initial_schema.sql  # Immutable journal triggers, balance edit guard, constraints
  tests/
    ledger_invariants.rs     # Rust unit & monetary invariant tests
  python/
    dd_client.py             # Typed HTTP client
    demo.py                  # Complete 12-step demonstration
    reconcile.py             # Independent PostgreSQL + API invariant verifier
    test_acceptance.py       # 11-module pytest acceptance test suite
    benchmark.py             # Throughput & latency benchmark runner
  config/
    local-demo.toml          # Explicit local-demo settings
    openapi.yaml             # OpenAPI 3.1 specification
  deploy/
    Dockerfile               # Reproducible multi-stage build
    docker-compose.yml       # PostgreSQL 16.8 + dollar_api
    backup.sh                # pg_dump custom format + SHA-256 checksum
    restore.sh               # Checksum-verified database restore
```

---

## 2. Double-Entry Accounting & Monetary Invariants

All amounts are represented strictly as integer USD cents (`i64`, bounded by `MAX_MONEY_CENTS = 10_000_000_000_000`). Negative amounts, fractional cents beyond 2 decimal places, currency mismatches, and integer overflows are rejected at the type boundary (`dollar_types::Money`).

### Account Classes & Normal Balances

| Account Class | Normal Balance | Meaning |
| --- | --- | --- |
| `ISSUANCE_CONTROL` | `DEBIT` | Cumulative authorized test-unit issuance contra-account |
| `RETIREMENT_CONTROL` | `DEBIT` | Cumulative redeemed/retired units (credited upon retirement) |
| `ISSUER_TREASURY` | `CREDIT` | Unallocated issued supply held by the issuer |
| `CUSTOMER_WALLET` | `CREDIT` | Customer circulating claim |
| `MERCHANT_WALLET` | `CREDIT` | Merchant circulating claim |
| `CLEARING` | `CREDIT` | Internal clearing balance |

### Fundamental Invariants

1. **Zero-Sum Journals:** Every journal has `>= 2` lines and `SUM(DEBIT) == SUM(CREDIT)`. Enforced in Rust (`validate_balanced_lines`) **and** in PostgreSQL via a `DEFERRABLE INITIALLY DEFERRED` constraint trigger (`trg_verify_journal_balanced`).
2. **Strict Immutability:** `BEFORE UPDATE OR DELETE` triggers forbid any mutation of `journals`, `journal_lines`, and `audit_logs`.
3. **No Direct Balance Edits:** `accounts.posted_balance_cents` and `accounts.reserved_balance_cents` are read-only projections guarded by `trg_guard_account_balance_update` (requiring `SET LOCAL app.ledger_internal = 'on'`). Authoritative balances are derived from `journal_lines` and unexpired `ACTIVE` `reservations`.
4. **Supply Conservation:**
   $$\text{Issued} - \text{Retired} = \sum_{\text{circulating accounts}} \text{Posted Balance}$$
5. **No Arbitrary Expiry or Confiscation:** Money never expires automatically, and wallets with non-zero posted or reserved balances cannot be closed (`WALLET_HAS_OUTSTANDING_BALANCE`).

---

## 3. Isolation, Locking, and Idempotency

- **Deadlock-Free Deterministic Locking:** `post_journal_in_tx` sorts all distinct participating `account_id` UUIDs in ascending order and acquires `SELECT ... FROM accounts WHERE id = ANY($1) ORDER BY id ASC FOR UPDATE`. Concurrent opposing transfers never deadlock, and competing debits on the same account serialize strictly on the source row lock.
- **Idempotency & Lost-Response Recovery:** Mutating endpoints store `(principal_id, endpoint, idempotency_key, sha256(payload), response_status, response_body)` inside the committing database transaction. Replays with an identical payload return the original response; reuse with a modified payload fails with `409 IDEMPOTENCY_CONFLICT`. After a client timeout, callers query `GET /v1/transfers/{id}` or `GET /v1/conversions/{id}` before creating a new instruction.

---

## 4. Redemption & Simulated Bank Conversion Protocol

Redemptions (`REDEEM_TO_BANK`) never claim atomic cross-system settlement with external banks:

1. **Request:** Creates a time-bounded `Reservation` (`REDEMPTION_HOLD`) on the customer's wallet. Available balance drops; `posted_balance_cents` is **not** debited yet.
2. **External Processing:** Calls `SimulatedBankAdapter` outside the database lock window.
3. **Evidence & Outcome Handling:**
   - `SETTLED`: Records deduplicated `conversion_evidence`, consumes the reservation, and posts `REDEMPTION_RETIREMENT` (`DEBIT customer`, `CREDIT RETIREMENT_CONTROL`).
   - `FAILED`: Records failure evidence and **releases the reservation** (`FAILED_RELEASED`). The customer's digital-dollar claim remains intact.
   - `DELAYED` / `UNCERTAIN`: Leaves the reservation active in `UNCERTAIN_HOLD`; the background recovery worker (`recover_pending_conversions`) resolves it once bank evidence arrives.

---

## 5. Privacy, Security & Local-Demo Boundaries

- **PII Minimization:** Ledger accounts and journals store only opaque UUIDs (`account_id`, `owner_principal_id`) and standardized `description_code`s—never names, emails, or raw bank account numbers.
- **Authentication & RBAC:** Credentials use `Argon2id` password hashing; sessions use expiring, revocable `HMAC-SHA256` bearer tokens; issuer actions require `ISSUER_OPERATOR` (request) and a distinct `ISSUER_APPROVER` (approve).
- **Local-Demo Bootstrap:** Pre-seeded dev roles (`issuer_operator`, `issuer_approver`, `auditor`, `fraud_reviewer`, `system_admin`) are created **only** when `ENABLE_LOCAL_DEMO_BOOTSTRAP=true`.

---

## 6. Quickstart (Docker Compose + CLI + Python Verification)

### Start PostgreSQL and the Rust API

```bash
cd digital-dollar
cp .env.example .env
docker compose -f deploy/docker-compose.yml up --build -d
```

Verify health & live OpenAPI schema:

```bash
curl -fsS http://localhost:8080/health | jq
curl -fsS http://localhost:8080/openapi.json | jq '.paths | keys'
```

### Run the Rust Invariant Tests

```bash
cargo test --workspace
```

### Run the Python 12-Step Demonstration, Acceptance Suite, Reconciliation, and Benchmark

```bash
cd python
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

# 1. Run complete 12-step demo (issuance, transfers, merchant pay, refund, replay, race, failed/ok redemption, restart, reconcile)
python3 demo.py

# 2. Run independent PostgreSQL + API reconciliation check
python3 reconcile.py

# 3. Run full acceptance test suite
pytest -v test_acceptance.py

# 4. Run throughput & latency benchmark
python3 benchmark.py
```

### Using `dollar-cli`

```bash
# Login as local-demo issuer operator
export DOLLAR_TOKEN=$(cargo run -q -p dollar_cli -- login --username issuer_operator --password demo-issuer-op-secret-2026 | tail -n +2 | jq -r .token)

# Request $1000.00 issuance
cargo run -q -p dollar_cli -- request-issuance --amount 1000.00 --purpose "CLI test" --supporting-ref "CLI-001"
```

### Backup & Restore

```bash
./deploy/backup.sh
./deploy/restore.sh deploy/backups/digital_dollar_<TIMESTAMP>.dump
python3 python/reconcile.py
```
