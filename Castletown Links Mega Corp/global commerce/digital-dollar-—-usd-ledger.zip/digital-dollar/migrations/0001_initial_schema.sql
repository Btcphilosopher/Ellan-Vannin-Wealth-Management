-- DIGITAL DOLLAR — USD Ledger Initial PostgreSQL Schema
-- Enforces double-entry invariants, immutable journals, append-only audit logs,
-- and prevents direct ad-hoc balance edits outside verified ledger transactions.

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- 1. Principals & Authentication
CREATE TABLE principals (
    id UUID PRIMARY KEY,
    username TEXT NOT NULL UNIQUE,
    role TEXT NOT NULL CHECK (role IN (
        'CUSTOMER',
        'MERCHANT',
        'ISSUER_OPERATOR',
        'ISSUER_APPROVER',
        'AUDITOR',
        'FRAUD_REVIEWER',
        'SYSTEM_ADMIN'
    )),
    secret_hash TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'SUSPENDED', 'DISABLED')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE auth_sessions (
    id UUID PRIMARY KEY,
    principal_id UUID NOT NULL REFERENCES principals(id),
    token_hash TEXT NOT NULL UNIQUE,
    expires_at TIMESTAMPTZ NOT NULL,
    revoked_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_auth_sessions_principal ON auth_sessions(principal_id);

-- 2. Accounts & Wallets
-- Note: Personal information is intentionally excluded from ledger accounts and journals.
-- `posted_balance_cents` and `reserved_balance_cents` are read-only projections guarded by trigger
-- and verified against authoritative `journal_lines` and `reservations`.
CREATE TABLE accounts (
    id UUID PRIMARY KEY,
    owner_principal_id UUID NOT NULL REFERENCES principals(id),
    account_class TEXT NOT NULL CHECK (account_class IN (
        'CUSTOMER_WALLET',
        'MERCHANT_WALLET',
        'ISSUER_TREASURY',
        'ISSUANCE_CONTROL',
        'RETIREMENT_CONTROL',
        'CLEARING'
    )),
    normal_balance TEXT NOT NULL CHECK (normal_balance IN ('DEBIT', 'CREDIT')),
    currency CHAR(3) NOT NULL CHECK (currency = 'USD'),
    status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'SUSPENDED', 'CLOSED')),
    posted_balance_cents BIGINT NOT NULL DEFAULT 0 CHECK (posted_balance_cents >= 0 OR account_class IN ('ISSUANCE_CONTROL', 'RETIREMENT_CONTROL')),
    reserved_balance_cents BIGINT NOT NULL DEFAULT 0 CHECK (reserved_balance_cents >= 0),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    closed_at TIMESTAMPTZ
);

CREATE INDEX idx_accounts_owner ON accounts(owner_principal_id);
CREATE INDEX idx_accounts_class ON accounts(account_class);

-- Guard against direct manual balance tampering outside authorized ledger engine transactions.
CREATE OR REPLACE FUNCTION guard_account_balance_update()
RETURNS TRIGGER AS $$
BEGIN
    IF (NEW.posted_balance_cents IS DISTINCT FROM OLD.posted_balance_cents
        OR NEW.reserved_balance_cents IS DISTINCT FROM OLD.reserved_balance_cents)
       AND current_setting('app.ledger_internal', true) IS DISTINCT FROM 'on' THEN
        RAISE EXCEPTION 'Direct account balance edits are forbidden; balances must derive from posted journals and reservations';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_guard_account_balance_update
BEFORE UPDATE ON accounts
FOR EACH ROW
EXECUTE FUNCTION guard_account_balance_update();

-- 3. Authoritative Double-Entry Journals (Immutable)
CREATE TABLE journals (
    id UUID PRIMARY KEY,
    entry_type TEXT NOT NULL CHECK (entry_type IN (
        'ISSUANCE',
        'TREASURY_DISTRIBUTION',
        'TRANSFER',
        'MERCHANT_PAYMENT',
        'PAYMENT_REFUND',
        'CONVERSION_MINT',
        'REDEMPTION_RETIREMENT',
        'REVERSAL'
    )),
    transaction_ref TEXT NOT NULL UNIQUE,
    correlation_id UUID NOT NULL,
    reversal_of_journal_id UUID REFERENCES journals(id),
    created_by_principal_id UUID NOT NULL REFERENCES principals(id),
    description_code TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE journal_lines (
    id UUID PRIMARY KEY,
    journal_id UUID NOT NULL REFERENCES journals(id),
    account_id UUID NOT NULL REFERENCES accounts(id),
    direction TEXT NOT NULL CHECK (direction IN ('DEBIT', 'CREDIT')),
    amount_cents BIGINT NOT NULL CHECK (amount_cents > 0),
    currency CHAR(3) NOT NULL CHECK (currency = 'USD'),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_journal_lines_journal_id ON journal_lines(journal_id);
CREATE INDEX idx_journal_lines_account_id ON journal_lines(account_id);

-- Immutability triggers on journals and journal_lines
CREATE OR REPLACE FUNCTION forbid_journal_mutation()
RETURNS TRIGGER AS $$
BEGIN
    RAISE EXCEPTION 'Posted ledger journals and journal lines are strictly immutable';
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_immutable_journals
BEFORE UPDATE OR DELETE ON journals
FOR EACH ROW
EXECUTE FUNCTION forbid_journal_mutation();

CREATE TRIGGER trg_immutable_journal_lines
BEFORE UPDATE OR DELETE ON journal_lines
FOR EACH ROW
EXECUTE FUNCTION forbid_journal_mutation();

-- Deferred constraint trigger verifying every posted journal balances to zero (debits == credits)
-- and contains at least two lines.
CREATE OR REPLACE FUNCTION verify_journal_balanced()
RETURNS TRIGGER AS $$
DECLARE
    debit_sum BIGINT;
    credit_sum BIGINT;
    line_count BIGINT;
BEGIN
    SELECT
        COALESCE(SUM(CASE WHEN direction = 'DEBIT' THEN amount_cents ELSE 0 END), 0),
        COALESCE(SUM(CASE WHEN direction = 'CREDIT' THEN amount_cents ELSE 0 END), 0),
        COUNT(*)
    INTO debit_sum, credit_sum, line_count
    FROM journal_lines
    WHERE journal_id = NEW.journal_id;

    IF line_count < 2 THEN
        RAISE EXCEPTION 'Journal % must have at least 2 lines, got %', NEW.journal_id, line_count;
    END IF;

    IF debit_sum <> credit_sum THEN
        RAISE EXCEPTION 'Unbalanced journal %: debits (%) <> credits (%)', NEW.journal_id, debit_sum, credit_sum;
    END IF;

    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE CONSTRAINT TRIGGER trg_verify_journal_balanced
AFTER INSERT ON journal_lines
DEFERRABLE INITIALLY DEFERRED
FOR EACH ROW
EXECUTE FUNCTION verify_journal_balanced();

-- 4. Time-Bounded Fund Reservations
CREATE TABLE reservations (
    id UUID PRIMARY KEY,
    account_id UUID NOT NULL REFERENCES accounts(id),
    amount_cents BIGINT NOT NULL CHECK (amount_cents > 0),
    currency CHAR(3) NOT NULL CHECK (currency = 'USD'),
    purpose TEXT NOT NULL,
    reference_id UUID NOT NULL,
    status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'CONSUMED', 'RELEASED', 'EXPIRED')),
    expires_at TIMESTAMPTZ NOT NULL,
    journal_id UUID REFERENCES journals(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    finalized_at TIMESTAMPTZ
);

CREATE INDEX idx_reservations_account_status ON reservations(account_id, status);
CREATE INDEX idx_reservations_expires_at ON reservations(expires_at) WHERE status = 'ACTIVE';

-- 5. Idempotency Records
CREATE TABLE idempotency_records (
    principal_id UUID NOT NULL REFERENCES principals(id),
    endpoint TEXT NOT NULL,
    idempotency_key TEXT NOT NULL,
    request_hash TEXT NOT NULL,
    response_status INTEGER NOT NULL,
    response_body JSONB NOT NULL,
    resource_id UUID,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (principal_id, endpoint, idempotency_key)
);

-- 6. Issuance Workflow
CREATE TABLE issuance_requests (
    id UUID PRIMARY KEY,
    idempotency_key TEXT NOT NULL,
    funding_classification TEXT NOT NULL CHECK (funding_classification IN (
        'TEST_ALLOCATION',
        'SIMULATED_EXTERNAL_FUNDING'
    )),
    amount_cents BIGINT NOT NULL CHECK (amount_cents > 0),
    currency CHAR(3) NOT NULL CHECK (currency = 'USD'),
    purpose TEXT NOT NULL,
    supporting_reference TEXT NOT NULL,
    external_funding_reference TEXT,
    status TEXT NOT NULL CHECK (status IN (
        'REQUESTED',
        'REVIEWED',
        'APPROVED',
        'POSTED',
        'RECONCILED',
        'REJECTED'
    )),
    requested_by UUID NOT NULL REFERENCES principals(id),
    reviewed_by UUID REFERENCES principals(id),
    approved_by UUID REFERENCES principals(id),
    destination_account_id UUID NOT NULL REFERENCES accounts(id),
    journal_id UUID REFERENCES journals(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    reviewed_at TIMESTAMPTZ,
    approved_at TIMESTAMPTZ,
    posted_at TIMESTAMPTZ,
    reconciled_at TIMESTAMPTZ,
    UNIQUE (requested_by, idempotency_key)
);

-- 7. Transfers
CREATE TABLE transfer_instructions (
    id UUID PRIMARY KEY,
    idempotency_key TEXT NOT NULL,
    source_account_id UUID NOT NULL REFERENCES accounts(id),
    destination_account_id UUID NOT NULL REFERENCES accounts(id),
    amount_cents BIGINT NOT NULL CHECK (amount_cents > 0),
    currency CHAR(3) NOT NULL CHECK (currency = 'USD'),
    reference TEXT NOT NULL,
    expires_at TIMESTAMPTZ NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('AUTHORISED', 'POSTED', 'FAILED', 'EXPIRED')),
    authorised_by UUID NOT NULL REFERENCES principals(id),
    reservation_id UUID REFERENCES reservations(id),
    journal_id UUID REFERENCES journals(id),
    failure_code TEXT,
    failure_reason TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    posted_at TIMESTAMPTZ,
    CHECK (source_account_id <> destination_account_id)
);

CREATE INDEX idx_transfers_source ON transfer_instructions(source_account_id);
CREATE INDEX idx_transfers_dest ON transfer_instructions(destination_account_id);

-- 8. Merchant Payment Requests, Payments & Refunds
CREATE TABLE payment_requests (
    id UUID PRIMARY KEY,
    merchant_account_id UUID NOT NULL REFERENCES accounts(id),
    order_reference TEXT NOT NULL,
    amount_cents BIGINT NOT NULL CHECK (amount_cents > 0),
    currency CHAR(3) NOT NULL CHECK (currency = 'USD'),
    policy TEXT NOT NULL CHECK (policy IN ('SINGLE_USE', 'REUSABLE')),
    expires_at TIMESTAMPTZ NOT NULL,
    status TEXT NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN', 'PAID', 'EXPIRED', 'CANCELLED')),
    signature_hmac TEXT NOT NULL,
    created_by UUID NOT NULL REFERENCES principals(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE payments (
    id UUID PRIMARY KEY,
    payment_request_id UUID NOT NULL REFERENCES payment_requests(id),
    idempotency_key TEXT NOT NULL,
    payer_account_id UUID NOT NULL REFERENCES accounts(id),
    merchant_account_id UUID NOT NULL REFERENCES accounts(id),
    amount_cents BIGINT NOT NULL CHECK (amount_cents > 0),
    refunded_cents BIGINT NOT NULL DEFAULT 0 CHECK (refunded_cents >= 0 AND refunded_cents <= amount_cents),
    currency CHAR(3) NOT NULL CHECK (currency = 'USD'),
    journal_id UUID NOT NULL REFERENCES journals(id),
    status TEXT NOT NULL DEFAULT 'SETTLED' CHECK (status IN ('SETTLED', 'PARTIALLY_REFUNDED', 'FULLY_REFUNDED')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE refunds (
    id UUID PRIMARY KEY,
    payment_id UUID NOT NULL REFERENCES payments(id),
    idempotency_key TEXT NOT NULL,
    amount_cents BIGINT NOT NULL CHECK (amount_cents > 0),
    currency CHAR(3) NOT NULL CHECK (currency = 'USD'),
    reason_reference TEXT NOT NULL,
    journal_id UUID NOT NULL REFERENCES journals(id),
    created_by UUID NOT NULL REFERENCES principals(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 9. Scheduled Payments
CREATE TABLE scheduled_payments (
    id UUID PRIMARY KEY,
    idempotency_key TEXT NOT NULL,
    source_account_id UUID NOT NULL REFERENCES accounts(id),
    destination_account_id UUID NOT NULL REFERENCES accounts(id),
    amount_cents BIGINT NOT NULL CHECK (amount_cents > 0),
    currency CHAR(3) NOT NULL CHECK (currency = 'USD'),
    reference TEXT NOT NULL,
    execute_after TIMESTAMPTZ NOT NULL,
    max_retries INTEGER NOT NULL DEFAULT 3 CHECK (max_retries >= 0),
    attempt_count INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'SCHEDULED' CHECK (status IN ('SCHEDULED', 'EXECUTING', 'COMPLETED', 'FAILED')),
    last_error TEXT,
    resulting_transfer_id UUID REFERENCES transfer_instructions(id),
    created_by UUID NOT NULL REFERENCES principals(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    executed_at TIMESTAMPTZ
);

CREATE INDEX idx_scheduled_payments_due ON scheduled_payments(execute_after) WHERE status = 'SCHEDULED';

-- 10. Conversions & Simulated Bank Redemptions
CREATE TABLE conversion_requests (
    id UUID PRIMARY KEY,
    idempotency_key TEXT NOT NULL,
    direction TEXT NOT NULL CHECK (direction IN ('DEPOSIT_TO_DIGITAL', 'REDEEM_TO_BANK')),
    account_id UUID NOT NULL REFERENCES accounts(id),
    amount_cents BIGINT NOT NULL CHECK (amount_cents > 0),
    currency CHAR(3) NOT NULL CHECK (currency = 'USD'),
    bank_account_ref_token TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN (
        'REQUESTED',
        'EXTERNAL_PROCESSING',
        'EVIDENCE_RECEIVED',
        'LEDGER_POSTED',
        'RECONCILED',
        'FAILED_RELEASED',
        'UNCERTAIN_HOLD'
    )),
    reservation_id UUID REFERENCES reservations(id),
    journal_id UUID REFERENCES journals(id),
    external_reference TEXT,
    failure_reason TEXT,
    created_by UUID NOT NULL REFERENCES principals(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE conversion_evidence (
    id UUID PRIMARY KEY,
    conversion_id UUID NOT NULL REFERENCES conversion_requests(id),
    provider_name TEXT NOT NULL,
    external_tx_id TEXT NOT NULL,
    outcome TEXT NOT NULL CHECK (outcome IN ('SETTLED', 'FAILED', 'PENDING')),
    payload_json JSONB NOT NULL,
    received_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (provider_name, external_tx_id, outcome)
);

-- 11. Transactional Outbox
CREATE TABLE outbox_events (
    id UUID PRIMARY KEY,
    aggregate_type TEXT NOT NULL,
    aggregate_id UUID NOT NULL,
    event_type TEXT NOT NULL,
    payload_json JSONB NOT NULL,
    status TEXT NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'PUBLISHED', 'DEAD_LETTER')),
    attempts INTEGER NOT NULL DEFAULT 0,
    next_attempt_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    published_at TIMESTAMPTZ
);

CREATE INDEX idx_outbox_pending ON outbox_events(next_attempt_at) WHERE status = 'PENDING';

-- 12. Protected Append-Only Audit Log
CREATE TABLE audit_logs (
    id UUID PRIMARY KEY,
    actor_principal_id UUID REFERENCES principals(id),
    actor_role TEXT NOT NULL,
    action TEXT NOT NULL,
    target_type TEXT NOT NULL,
    target_id TEXT NOT NULL,
    correlation_id UUID NOT NULL,
    outcome TEXT NOT NULL,
    metadata_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TRIGGER trg_immutable_audit_logs
BEFORE UPDATE OR DELETE ON audit_logs
FOR EACH ROW
EXECUTE FUNCTION forbid_journal_mutation();

-- 13. Reconciliation Snapshots
CREATE TABLE reconciliation_runs (
    id UUID PRIMARY KEY,
    run_type TEXT NOT NULL,
    total_issued_cents BIGINT NOT NULL,
    total_retired_cents BIGINT NOT NULL,
    outstanding_supply_cents BIGINT NOT NULL,
    sum_wallet_posted_cents BIGINT NOT NULL,
    sum_wallet_reserved_cents BIGINT NOT NULL,
    unbalanced_journals_count BIGINT NOT NULL,
    balance_mismatches_count BIGINT NOT NULL,
    is_healthy BOOLEAN NOT NULL,
    report_json JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
