"""Independent PostgreSQL + API reconciliation verifier for DIGITAL DOLLAR — USD Ledger."""

from __future__ import annotations

import json
import os
import sys

import psycopg

from dd_client import DigitalDollarClient


def verify_postgres_invariants(database_url: str) -> dict:
    with psycopg.connect(database_url) as conn:
        with conn.cursor() as cur:
            # 1. Every journal must balance (SUM(DEBIT) == SUM(CREDIT) and >= 2 lines)
            cur.execute(
                """
                SELECT j.id,
                       COALESCE(SUM(CASE WHEN jl.direction = 'DEBIT' THEN jl.amount_cents ELSE 0 END), 0) AS debits,
                       COALESCE(SUM(CASE WHEN jl.direction = 'CREDIT' THEN jl.amount_cents ELSE 0 END), 0) AS credits,
                       COUNT(jl.id) AS line_count
                FROM journals j
                LEFT JOIN journal_lines jl ON jl.journal_id = j.id
                GROUP BY j.id
                HAVING COUNT(jl.id) < 2
                    OR COALESCE(SUM(CASE WHEN jl.direction = 'DEBIT' THEN jl.amount_cents ELSE 0 END), 0)
                       <> COALESCE(SUM(CASE WHEN jl.direction = 'CREDIT' THEN jl.amount_cents ELSE 0 END), 0)
                """
            )
            unbalanced = cur.fetchall()
            assert len(unbalanced) == 0, f"Unbalanced journals detected: {unbalanced}"

            # 2. Every account projection must match authoritative journal_lines and active reservations
            cur.execute(
                """
                SELECT a.id, a.account_class, a.normal_balance,
                       a.posted_balance_cents, a.reserved_balance_cents,
                       COALESCE(SUM(CASE WHEN jl.direction = 'DEBIT' THEN jl.amount_cents ELSE 0 END), 0) AS debits,
                       COALESCE(SUM(CASE WHEN jl.direction = 'CREDIT' THEN jl.amount_cents ELSE 0 END), 0) AS credits
                FROM accounts a
                LEFT JOIN journal_lines jl ON jl.account_id = a.id
                GROUP BY a.id
                """
            )
            rows = cur.fetchall()

            total_issued = 0
            total_retired = 0
            sum_circulating = 0
            for acct_id, acct_class, normal_bal, cached_posted, cached_res, debits, credits in rows:
                derived_posted = (credits - debits) if normal_bal == "CREDIT" else (debits - credits)
                assert cached_posted == derived_posted, (
                    f"Account {acct_id} posted mismatch: cached={cached_posted}, derived={derived_posted}"
                )

                cur.execute(
                    """
                    SELECT COALESCE(SUM(amount_cents), 0)
                    FROM reservations
                    WHERE account_id = %s AND status = 'ACTIVE' AND expires_at > NOW()
                    """,
                    (acct_id,),
                )
                derived_res = cur.fetchone()[0]
                assert cached_res == derived_res, (
                    f"Account {acct_id} reserved mismatch: cached={cached_res}, derived={derived_res}"
                )

                if acct_class == "ISSUANCE_CONTROL":
                    total_issued += derived_posted
                elif acct_class == "RETIREMENT_CONTROL":
                    total_retired += -derived_posted
                elif acct_class in ("CUSTOMER_WALLET", "MERCHANT_WALLET", "ISSUER_TREASURY", "CLEARING"):
                    sum_circulating += derived_posted

            outstanding_supply = total_issued - total_retired
            assert outstanding_supply == sum_circulating, (
                f"Supply conservation violated: issued({total_issued}) - retired({total_retired}) = "
                f"{outstanding_supply} != sum_circulating({sum_circulating})"
            )

            return {
                "total_issued_cents": total_issued,
                "total_retired_cents": total_retired,
                "outstanding_supply_cents": outstanding_supply,
                "sum_circulating_cents": sum_circulating,
                "accounts_checked": len(rows),
                "unbalanced_journals": 0,
            }


def main() -> None:
    api_url = os.getenv("DOLLAR_API_URL", "http://localhost:8080")
    db_url = os.getenv(
        "DATABASE_URL", "postgres://dollar:dollar_dev_password@localhost:5432/digital_dollar"
    )

    client = DigitalDollarClient(api_url)
    try:
        login = client.login("auditor", "demo-auditor-secret-2026")
        assert login.status_code == 200, f"Auditor login failed: {login}"
        token = login.data["token"]
        api_recon = client.reconcile(token)
        assert api_recon.status_code == 200, f"API reconcile failed: {api_recon}"
        assert api_recon.data["is_healthy"] is True, f"Unhealthy API report: {api_recon.data}"

        pg_report = verify_postgres_invariants(db_url)
        print(
            json.dumps(
                {"api_reconciliation": api_recon.data, "independent_pg_verification": pg_report},
                indent=2,
            )
        )
    finally:
        client.close()


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"Reconciliation verification failed: {exc}", file=sys.stderr)
        sys.exit(1)
