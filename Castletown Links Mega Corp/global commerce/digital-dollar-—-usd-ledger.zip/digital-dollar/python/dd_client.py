"""Typed HTTP client for DIGITAL DOLLAR — USD Ledger API."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from typing import Any, Optional

import httpx


@dataclass
class ApiResult:
    status_code: int
    data: Any
    correlation_id: Optional[str]


class DigitalDollarClient:
    def __init__(self, base_url: str = "http://localhost:8080", timeout: float = 10.0) -> None:
        self.base_url = base_url.rstrip("/")
        self.client = httpx.Client(base_url=self.base_url, timeout=timeout)

    def close(self) -> None:
        self.client.close()

    def _headers(
        self,
        token: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        correlation_id: Optional[str] = None,
    ) -> dict[str, str]:
        headers: dict[str, str] = {}
        if token:
            headers["Authorization"] = f"Bearer {token}"
        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key
        if correlation_id:
            headers["X-Correlation-Id"] = correlation_id
        return headers

    def _parse(self, resp: httpx.Response) -> ApiResult:
        try:
            body = resp.json()
        except Exception:
            body = resp.text
        return ApiResult(
            status_code=resp.status_code,
            data=body,
            correlation_id=resp.headers.get("x-correlation-id"),
        )

    def health(self) -> ApiResult:
        return self._parse(self.client.get("/health"))

    def register(self, username: str, password: str, role: str) -> ApiResult:
        return self._parse(
            self.client.post(
                "/v1/auth/register",
                json={"username": username, "password": password, "role": role},
            )
        )

    def login(self, username: str, password: str) -> ApiResult:
        return self._parse(
            self.client.post(
                "/v1/auth/login",
                json={"username": username, "password": password},
            )
        )

    def create_wallet(
        self, token: str, account_class: str = "CUSTOMER_WALLET", idempotency_key: Optional[str] = None
    ) -> ApiResult:
        idem = idempotency_key or f"wallet-{uuid.uuid4()}"
        return self._parse(
            self.client.post(
                "/v1/wallets",
                headers=self._headers(token=token, idempotency_key=idem),
                json={"account_class": account_class, "currency": "USD"},
            )
        )

    def get_balance(self, token: str, wallet_id: str) -> ApiResult:
        return self._parse(
            self.client.get(
                f"/v1/wallets/{wallet_id}/balance",
                headers=self._headers(token=token),
            )
        )

    def get_transactions(self, token: str, wallet_id: str, limit: int = 50) -> ApiResult:
        return self._parse(
            self.client.get(
                f"/v1/wallets/{wallet_id}/transactions",
                params={"limit": limit},
                headers=self._headers(token=token),
            )
        )

    def update_wallet_status(self, token: str, wallet_id: str, status: str) -> ApiResult:
        return self._parse(
            self.client.post(
                f"/v1/wallets/{wallet_id}/status",
                headers=self._headers(token=token),
                json={"status": status},
            )
        )

    def request_issuance(
        self,
        token: str,
        amount_cents: int,
        purpose: str,
        supporting_reference: str,
        classification: str = "TEST_ALLOCATION",
        external_funding_reference: Optional[str] = None,
        destination_account_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
    ) -> ApiResult:
        idem = idempotency_key or f"issuance-req-{uuid.uuid4()}"
        return self._parse(
            self.client.post(
                "/v1/issuer/issuance-requests",
                headers=self._headers(token=token, idempotency_key=idem),
                json={
                    "amount_cents": amount_cents,
                    "currency": "USD",
                    "funding_classification": classification,
                    "purpose": purpose,
                    "supporting_reference": supporting_reference,
                    "external_funding_reference": external_funding_reference,
                    "destination_account_id": destination_account_id,
                },
            )
        )

    def approve_issuance(
        self,
        token: str,
        issuance_id: str,
        review_note: Optional[str] = None,
        idempotency_key: Optional[str] = None,
    ) -> ApiResult:
        idem = idempotency_key or f"issuance-app-{uuid.uuid4()}"
        return self._parse(
            self.client.post(
                f"/v1/issuer/issuance-requests/{issuance_id}/approve",
                headers=self._headers(token=token, idempotency_key=idem),
                json={"review_note": review_note},
            )
        )

    def preview_transfer(
        self, token: str, source_id: str, dest_id: str, amount_cents: int, reference: str
    ) -> ApiResult:
        return self._parse(
            self.client.post(
                "/v1/transfers/preview",
                headers=self._headers(token=token),
                json={
                    "source_account_id": source_id,
                    "destination_account_id": dest_id,
                    "amount_cents": amount_cents,
                    "currency": "USD",
                    "reference": reference,
                },
            )
        )

    def submit_transfer(
        self,
        token: str,
        source_id: str,
        dest_id: str,
        amount_cents: int,
        reference: str,
        idempotency_key: Optional[str] = None,
    ) -> ApiResult:
        idem = idempotency_key or f"xfer-{uuid.uuid4()}"
        return self._parse(
            self.client.post(
                "/v1/transfers",
                headers=self._headers(token=token, idempotency_key=idem),
                json={
                    "source_account_id": source_id,
                    "destination_account_id": dest_id,
                    "amount_cents": amount_cents,
                    "currency": "USD",
                    "reference": reference,
                },
            )
        )

    def get_transfer(self, token: str, transfer_id: str) -> ApiResult:
        return self._parse(
            self.client.get(
                f"/v1/transfers/{transfer_id}",
                headers=self._headers(token=token),
            )
        )

    def create_payment_request(
        self,
        token: str,
        merchant_account_id: str,
        order_reference: str,
        amount_cents: int,
        policy: str = "SINGLE_USE",
        expires_in_secs: int = 900,
        idempotency_key: Optional[str] = None,
    ) -> ApiResult:
        idem = idempotency_key or f"pr-{uuid.uuid4()}"
        return self._parse(
            self.client.post(
                "/v1/payment-requests",
                headers=self._headers(token=token, idempotency_key=idem),
                json={
                    "merchant_account_id": merchant_account_id,
                    "order_reference": order_reference,
                    "amount_cents": amount_cents,
                    "currency": "USD",
                    "policy": policy,
                    "expires_in_secs": expires_in_secs,
                },
            )
        )

    def pay_payment_request(
        self,
        token: str,
        payment_request_id: str,
        payer_account_id: str,
        signature_hmac: str,
        idempotency_key: Optional[str] = None,
    ) -> ApiResult:
        idem = idempotency_key or f"pay-{uuid.uuid4()}"
        return self._parse(
            self.client.post(
                f"/v1/payment-requests/{payment_request_id}/pay",
                headers=self._headers(token=token, idempotency_key=idem),
                json={
                    "payer_account_id": payer_account_id,
                    "signature_hmac": signature_hmac,
                },
            )
        )

    def refund_payment(
        self,
        token: str,
        payment_id: str,
        amount_cents: int,
        reason_reference: str,
        idempotency_key: Optional[str] = None,
    ) -> ApiResult:
        idem = idempotency_key or f"refund-{uuid.uuid4()}"
        return self._parse(
            self.client.post(
                f"/v1/payments/{payment_id}/refunds",
                headers=self._headers(token=token, idempotency_key=idem),
                json={
                    "amount_cents": amount_cents,
                    "currency": "USD",
                    "reason_reference": reason_reference,
                },
            )
        )

    def schedule_payment(
        self,
        token: str,
        source_id: str,
        dest_id: str,
        amount_cents: int,
        reference: str,
        execute_after_iso: str,
        idempotency_key: Optional[str] = None,
    ) -> ApiResult:
        idem = idempotency_key or f"sched-{uuid.uuid4()}"
        return self._parse(
            self.client.post(
                "/v1/scheduled-payments",
                headers=self._headers(token=token, idempotency_key=idem),
                json={
                    "source_account_id": source_id,
                    "destination_account_id": dest_id,
                    "amount_cents": amount_cents,
                    "currency": "USD",
                    "reference": reference,
                    "execute_after": execute_after_iso,
                    "max_retries": 1,
                },
            )
        )

    def create_conversion(
        self,
        token: str,
        direction: str,
        account_id: str,
        amount_cents: int,
        bank_account_ref_token: str,
        simulate_outcome: Optional[str] = None,
        idempotency_key: Optional[str] = None,
    ) -> ApiResult:
        idem = idempotency_key or f"conv-{uuid.uuid4()}"
        return self._parse(
            self.client.post(
                "/v1/conversions",
                headers=self._headers(token=token, idempotency_key=idem),
                json={
                    "direction": direction,
                    "account_id": account_id,
                    "amount_cents": amount_cents,
                    "currency": "USD",
                    "bank_account_ref_token": bank_account_ref_token,
                    "simulate_outcome": simulate_outcome,
                },
            )
        )

    def get_conversion(self, token: str, conversion_id: str) -> ApiResult:
        return self._parse(
            self.client.get(
                f"/v1/conversions/{conversion_id}",
                headers=self._headers(token=token),
            )
        )

    def reconcile(self, token: str) -> ApiResult:
        return self._parse(
            self.client.get(
                "/v1/reconciliation",
                headers=self._headers(token=token),
            )
        )
