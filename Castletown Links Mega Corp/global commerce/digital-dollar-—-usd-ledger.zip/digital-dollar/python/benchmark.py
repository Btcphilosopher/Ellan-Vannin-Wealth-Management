"""Throughput and latency benchmark for DIGITAL DOLLAR — USD Ledger."""

from __future__ import annotations

import os
import statistics
import time
import uuid
from concurrent.futures import ThreadPoolExecutor

from dd_client import DigitalDollarClient
from reconcile import verify_postgres_invariants


def run_benchmark(total_transfers: int = 200, concurrency: int = 8) -> None:
    api_url = os.getenv("DOLLAR_API_URL", "http://localhost:8080")
    db_url = os.getenv(
        "DATABASE_URL", "postgres://dollar:dollar_dev_password@localhost:5432/digital_dollar"
    )
    c = DigitalDollarClient(api_url)
    try:
        op_tok = c.login("issuer_operator", "demo-issuer-op-secret-2026").data["token"]
        app_tok = c.login("issuer_approver", "demo-issuer-app-secret-2026").data["token"]

        suffix = uuid.uuid4().hex[:8]
        pw = "bench-pass-2026"
        c.register(f"bench_src_{suffix}", pw, "CUSTOMER")
        c.register(f"bench_dst_{suffix}", pw, "CUSTOMER")
        src_tok = c.login(f"bench_src_{suffix}", pw).data["token"]
        dst_tok = c.login(f"bench_dst_{suffix}", pw).data["token"]
        src_w = c.create_wallet(src_tok, "CUSTOMER_WALLET").data["account_id"]
        dst_w = c.create_wallet(dst_tok, "CUSTOMER_WALLET").data["account_id"]

        iss = c.request_issuance(op_tok, 1_000_000, "Benchmark allocation", f"BENCH-{suffix}").data
        c.approve_issuance(app_tok, iss["id"])
        c.submit_transfer(op_tok, iss["destination_account_id"], src_w, 1_000_000, "bench-seed")

        def send_one(i: int) -> float:
            local_c = DigitalDollarClient(api_url)
            try:
                t0 = time.perf_counter()
                r = local_c.submit_transfer(src_tok, src_w, dst_w, 100, f"bench-{i}")
                dt = (time.perf_counter() - t0) * 1000.0
                if r.status_code != 201:
                    raise RuntimeError(f"Benchmark transfer failed: {r}")
                return dt
            finally:
                local_c.close()

        t_start = time.perf_counter()
        with ThreadPoolExecutor(max_workers=concurrency) as pool:
            latencies_ms = list(pool.map(send_one, range(total_transfers)))
        elapsed = time.perf_counter() - t_start

        latencies_ms.sort()
        p50 = statistics.median(latencies_ms)
        p95 = latencies_ms[int(0.95 * len(latencies_ms)) - 1]
        p99 = latencies_ms[int(0.99 * len(latencies_ms)) - 1]
        tps = total_transfers / elapsed

        print("DIGITAL DOLLAR — USD Ledger Benchmark Results")
        print(f"Conditions: {total_transfers} sequential/concurrent $1.00 transfers, concurrency={concurrency}")
        print(f"Elapsed: {elapsed:.2f}s | Throughput: {tps:.2f} tx/s")
        print(f"Latency (ms): p50={p50:.2f}, p95={p95:.2f}, p99={p99:.2f}, max={latencies_ms[-1]:.2f}")
        print(f"Post-benchmark invariants: {verify_postgres_invariants(db_url)}")
    finally:
        c.close()


if __name__ == "__main__":
    n = int(os.getenv("BENCH_COUNT", "200"))
    conc = int(os.getenv("BENCH_CONCURRENCY", "8"))
    run_benchmark(n, conc)
