"""Complete 12-step demonstration for DIGITAL DOLLAR — USD Ledger (Requirement 15).

Steps:
1. Creates two customers (Alice, Bob) and one merchant.
2. Authorises issuance of $1,000 in test units.
3. Funds Alice with $600 and Bob with $400.
4. Transfers $75 from Alice to Bob.
5. Pays the merchant $25 from Bob.
6. Refunds $5.
7. Repeats a request without duplicating it.
8. Runs a competing-spend test.
9. Demonstrates a failed simulated redemption.
10. Completes a successful $100 redemption.
11. Restarts services.
12. Reconciles all journals, balances and outstanding supply.
"""

from __future__ import annotations

import os
import subprocess
import time
import uuid
from concurrent.futures import ThreadPoolExecutor

from dd_client import DigitalDollarClient
from reconcile import verify_postgres_invariants


def wait_for_health(api_url: str, timeout_secs: float = 30.0) -> None:
    deadline = time.time() + timeout_secs
    client = DigitalDollarClient(api_url, timeout=2.0)
    try:
        while time.time() < deadline:
            try:
                r = client.health()
                if r.status_code == 200:
                    return
            except Exception:
                pass
            time.sleep(0.5)
        raise RuntimeError(f"API at {api_url} did not become healthy within {timeout_secs}s")
    finally:
        client.close()


def restart_api_service(api_url: str) -> None:
    restart_cmd = os.getenv("DEMO_RESTART_CMD")
    if restart_cmd:
        subprocess.run(restart_cmd, shell=True, check=True)
        wait_for_health(api_url)
        return

    # Default: restart the docker compose container if running
    check = subprocess.run(
        ["docker", "ps", "--format", "{{.Names}}"],
        capture_output=True,
        text=True,
        check=False,
    )
    if check.returncode == 0 and "digital-dollar-api" in check.stdout:
        subprocess.run(["docker", "restart", "digital-dollar-api"], check=True)
        wait_for_health(api_url)
    else:
        print("[step 11] Skipping container restart (digital-dollar-api container not found; set DEMO_RESTART_CMD for local process restart)")


def main() -> None:
    api_url = os.getenv("DOLLAR_API_URL", "http://localhost:8080")
    db_url = os.getenv(
        "DATABASE_URL", "postgres://dollar:dollar_dev_password@localhost:5432/digital_dollar"
    )
    wait_for_health(api_url)
    c = DigitalDollarClient(api_url)
    suffix = uuid.uuid4().hex[:8]

    try:
        # Login explicit local-demo issuer & auditor roles
        issuer_op_tok = c.login("issuer_operator", "demo-issuer-op-secret-2026").data["token"]
        issuer_app_tok = c.login("issuer_approver", "demo-issuer-app-secret-2026").data["token"]
        auditor_tok = c.login("auditor", "demo-auditor-secret-2026").data["token"]

        baseline_recon = c.reconcile(auditor_tok).data
        base_issued = baseline_recon["total_issued_cents"]
        base_retired = baseline_recon["total_retired_cents"]

        # 1. Create two customers (Alice, Bob) and one merchant
        alice_u = f"alice_{suffix}"
        bob_u = f"bob_{suffix}"
        merch_u = f"merchant_{suffix}"
        pw = "demo-user-pass-2026"
        assert c.register(alice_u, pw, "CUSTOMER").status_code == 201
        assert c.register(bob_u, pw, "CUSTOMER").status_code == 201
        assert c.register(merch_u, pw, "MERCHANT").status_code == 201

        alice_tok = c.login(alice_u, pw).data["token"]
        bob_tok = c.login(bob_u, pw).data["token"]
        merch_tok = c.login(merch_u, pw).data["token"]

        alice_wallet = c.create_wallet(alice_tok, "CUSTOMER_WALLET").data["account_id"]
        bob_wallet = c.create_wallet(bob_tok, "CUSTOMER_WALLET").data["account_id"]
        merch_wallet = c.create_wallet(merch_tok, "MERCHANT_WALLET").data["account_id"]
        print(f"1. Created wallets: Alice={alice_wallet}, Bob={bob_wallet}, Merchant={merch_wallet}")

        # 2. Authorise issuance of $1,000 in test units (dual-control: operator requests, approver approves)
        iss_req = c.request_issuance(
            issuer_op_tok,
            amount_cents=100_000,
            purpose="Local demo supply allocation",
            supporting_reference=f"DEMO-ALLOC-{suffix}",
            classification="TEST_ALLOCATION",
        )
        assert iss_req.status_code == 201
        issuance_id = iss_req.data["id"]
        treasury_wallet = iss_req.data["destination_account_id"]

        iss_app = c.approve_issuance(
            issuer_app_tok, issuance_id, review_note="Verified allocation policy"
        )
        assert iss_app.status_code == 200
        assert iss_app.data["status"] == "RECONCILED"
        print(f"2. Issued $1,000.00 into Issuer Treasury {treasury_wallet} (issuance={issuance_id})")

        # 3. Fund Alice with $600 and Bob with $400
        assert (
            c.submit_transfer(
                issuer_op_tok, treasury_wallet, alice_wallet, 60_000, f"fund-alice-{suffix}"
            ).status_code
            == 201
        )
        assert (
            c.submit_transfer(
                issuer_op_tok, treasury_wallet, bob_wallet, 40_000, f"fund-bob-{suffix}"
            ).status_code
            == 201
        )
        print("3. Funded Alice $600.00 and Bob $400.00")

        # 4. Transfer $75 from Alice to Bob (preview + submit)
        prev = c.preview_transfer(alice_tok, alice_wallet, bob_wallet, 7_500, "dinner-split")
        assert prev.status_code == 200 and prev.data["executable"] is True
        idem_xfer = f"demo-xfer-{suffix}"
        xfer = c.submit_transfer(
            alice_tok, alice_wallet, bob_wallet, 7_500, "dinner-split", idempotency_key=idem_xfer
        )
        assert xfer.status_code == 201
        print("4. Transferred $75.00 from Alice to Bob (Alice=$525.00, Bob=$475.00)")

        # 5. Pay the merchant $25 from Bob via signed payment request
        pr = c.create_payment_request(
            merch_tok, merch_wallet, f"ORD-{suffix}", 2_500, policy="SINGLE_USE"
        )
        assert pr.status_code == 201
        pay = c.pay_payment_request(
            bob_tok, pr.data["id"], bob_wallet, pr.data["signature_hmac"]
        )
        assert pay.status_code == 201
        payment_id = pay.data["id"]
        print(f"5. Bob paid Merchant $25.00 (payment_id={payment_id}; Bob=$450.00, Merchant=$25.00)")

        # 6. Refund $5 from Merchant to Bob
        ref = c.refund_payment(merch_tok, payment_id, 500, "partial-item-return")
        assert ref.status_code == 201
        print("6. Merchant refunded $5.00 to Bob (Bob=$455.00, Merchant=$20.00)")

        # 7. Repeat a request without duplicating it (exact idempotent replay of step 4)
        replay = c.submit_transfer(
            alice_tok, alice_wallet, bob_wallet, 7_500, "dinner-split", idempotency_key=idem_xfer
        )
        assert replay.status_code == 201
        assert replay.data["id"] == xfer.data["id"]
        assert replay.data["journal_id"] == xfer.data["journal_id"]
        assert c.get_balance(alice_tok, alice_wallet).data["posted_balance_cents"] == 52_500
        print("7. Repeated $75.00 transfer with same Idempotency-Key returned original outcome without double-debit")

        # 8. Competing-spend test: Alice has $525.00; two concurrent $300.00 debits -> exactly 1 wins!
        def attempt_spend(tag: str) -> int:
            local_c = DigitalDollarClient(api_url)
            try:
                res = local_c.submit_transfer(
                    alice_tok,
                    alice_wallet,
                    bob_wallet,
                    30_000,
                    f"race-{tag}",
                    idempotency_key=f"race-{tag}-{suffix}",
                )
                return res.status_code
            finally:
                local_c.close()

        with ThreadPoolExecutor(max_workers=2) as pool:
            f1 = pool.submit(attempt_spend, "A")
            f2 = pool.submit(attempt_spend, "B")
            statuses = sorted([f1.result(), f2.result()])

        assert statuses == [201, 409], f"Expected [201, 409] in competing spend, got {statuses}"
        # Transfer $300 back from Bob to Alice so Alice returns to $525 and Bob to $455
        assert (
            c.submit_transfer(
                bob_tok, bob_wallet, alice_wallet, 30_000, "race-cleanup"
            ).status_code
            == 201
        )
        print(f"8. Competing-spend test passed (outcomes={statuses}; exactly one succeeded)")

        # 9. Demonstrate a failed simulated redemption (Bob tries $100, bank fails -> claim intact!)
        failed_red = c.create_conversion(
            bob_tok,
            direction="REDEEM_TO_BANK",
            account_id=bob_wallet,
            amount_cents=10_000,
            bank_account_ref_token="tok_bank_checking_001",
            simulate_outcome="FAILED",
        )
        assert failed_red.status_code == 201
        assert failed_red.data["status"] == "FAILED_RELEASED"
        bob_bal_after_fail = c.get_balance(bob_tok, bob_wallet).data
        assert bob_bal_after_fail["posted_balance_cents"] == 45_500
        assert bob_bal_after_fail["reserved_balance_cents"] == 0
        assert bob_bal_after_fail["available_balance_cents"] == 45_500
        print("9. Failed simulated $100.00 redemption released reservation; Bob retains full $455.00 claim")

        # 10. Complete a successful $100 redemption for Bob
        ok_red = c.create_conversion(
            bob_tok,
            direction="REDEEM_TO_BANK",
            account_id=bob_wallet,
            amount_cents=10_000,
            bank_account_ref_token="tok_bank_checking_001",
            simulate_outcome="SETTLED",
        )
        assert ok_red.status_code == 201
        assert ok_red.data["status"] == "RECONCILED"
        print("10. Completed $100.00 bank redemption (Bob=$355.00, Retired=+$100.00)")

        # 11. Restart services
        print("11. Restarting API service...")
        restart_api_service(api_url)

        # 12. Reconcile all journals, balances, and outstanding supply after restart
        alice_final = c.get_balance(alice_tok, alice_wallet).data
        bob_final = c.get_balance(bob_tok, bob_wallet).data
        merch_final = c.get_balance(merch_tok, merch_wallet).data

        assert alice_final["posted_balance_cents"] == 52_500, alice_final
        assert bob_final["posted_balance_cents"] == 35_500, bob_final
        assert merch_final["posted_balance_cents"] == 2_000, merch_final

        final_recon = c.reconcile(auditor_tok).data
        assert final_recon["is_healthy"] is True
        assert final_recon["unbalanced_journals_count"] == 0
        assert final_recon["balance_mismatches_count"] == 0
        assert final_recon["total_issued_cents"] == base_issued + 100_000
        assert final_recon["total_retired_cents"] == base_retired + 10_000
        assert final_recon["outstanding_supply_cents"] == (
            final_recon["total_issued_cents"] - final_recon["total_retired_cents"]
        )
        assert final_recon["outstanding_supply_cents"] == final_recon["sum_wallet_posted_cents"]

        pg_recon = verify_postgres_invariants(db_url)
        print("12. Post-restart reconciliation PASSED:")
        print(f"    Alice:    ${alice_final['posted_balance_cents'] / 100:.2f} (expected $525.00)")
        print(f"    Bob:      ${bob_final['posted_balance_cents'] / 100:.2f} (expected $355.00)")
        print(f"    Merchant: ${merch_final['posted_balance_cents'] / 100:.2f} (expected $20.00)")
        print(f"    Delta Issued:  +$1000.00 | Delta Retired: +$100.00 | Net Delta Supply: +$900.00")
        print(f"    DB Invariants: {pg_recon}")
    finally:
        c.close()


if __name__ == "__main__":
    main()
