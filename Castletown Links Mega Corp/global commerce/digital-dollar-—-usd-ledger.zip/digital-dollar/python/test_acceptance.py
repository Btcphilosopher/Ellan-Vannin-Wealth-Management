"""Comprehensive Acceptance Test Suite for DIGITAL DOLLAR — USD Ledger (Requirement 16)."""

from __future__ import annotations

import os
import subprocess
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone

import psycopg
import pytest

from dd_client import DigitalDollarClient
from reconcile import verify_postgres_invariants

API_URL = os.getenv("DOLLAR_API_URL", "http://localhost:8080")
DB_URL = os.getenv(
    "DATABASE_URL", "postgres://dollar:dollar_dev_password@localhost:5432/digital_dollar"
)


@pytest.fixture(scope="module")
def client() -> DigitalDollarClient:
    c = DigitalDollarClient(API_URL)
    yield c
    c.close()


def _new_customer_with_funds(client: DigitalDollarClient, amount_cents: int) -> tuple[str, str]:
    suffix = uuid.uuid4().hex[:8]
    u = f"cust_{suffix}"
    pw = "cust-pass-2026"
    assert client.register(u, pw, "CUSTOMER").status_code == 201
    tok = client.login(u, pw).data["token"]
    wid = client.create_wallet(tok, "CUSTOMER_WALLET").data["account_id"]

    if amount_cents > 0:
        op_tok = client.login("issuer_operator", "demo-issuer-op-secret-2026").data["token"]
        app_tok = client.login("issuer_approver", "demo-issuer-app-secret-2026").data["token"]
        iss = client.request_issuance(
            op_tok, amount_cents, "Test funding", f"TEST-{suffix}", "TEST_ALLOCATION"
        )
        assert iss.status_code == 201
        assert client.approve_issuance(app_tok, iss.data["id"]).status_code == 200
        treasury = iss.data["destination_account_id"]
        assert client.submit_transfer(op_tok, treasury, wid, amount_cents, f"fund-{suffix}").status_code == 201
    return tok, wid


def test_01_balanced_postings_and_monetary_conservation(client: DigitalDollarClient) -> None:
    report = verify_postgres_invariants(DB_URL)
    assert report["unbalanced_journals"] == 0
    assert report["outstanding_supply_cents"] == report["sum_circulating_cents"]


def test_02_overflow_and_negative_amount_rejection(client: DigitalDollarClient) -> None:
    tok, wid = _new_customer_with_funds(client, 0)
    _, dst = _new_customer_with_funds(client, 0)

    neg = client.submit_transfer(tok, wid, dst, -100, "negative")
    assert neg.status_code == 400
    assert neg.data["error_code"] == "NON_POSITIVE_AMOUNT"

    overflow = client.submit_transfer(tok, wid, dst, 10_000_000_000_001, "overflow")
    assert overflow.status_code == 400
    assert overflow.data["error_code"] == "AMOUNT_OVERFLOW"


def test_03_insufficient_funds_rejected(client: DigitalDollarClient) -> None:
    tok_a, wid_a = _new_customer_with_funds(client, 5_000)
    _, wid_b = _new_customer_with_funds(client, 0)

    res = client.submit_transfer(tok_a, wid_a, wid_b, 5_001, "overdraft")
    assert res.status_code == 409
    assert res.data["error_code"] == "INSUFFICIENT_FUNDS"


def test_04_concurrent_debits_prevent_double_spend(client: DigitalDollarClient) -> None:
    tok_a, wid_a = _new_customer_with_funds(client, 10_000)
    _, wid_b = _new_customer_with_funds(client, 0)

    def fire(idx: int) -> int:
        local = DigitalDollarClient(API_URL)
        try:
            return local.submit_transfer(tok_a, wid_a, wid_b, 6_000, f"conc-{idx}").status_code
        finally:
            local.close()

    with ThreadPoolExecutor(max_workers=4) as pool:
        outcomes = sorted([pool.submit(fire, i).result() for i in range(4)])

    assert outcomes.count(201) == 1
    assert outcomes.count(409) == 3
    assert client.get_balance(tok_a, wid_a).data["posted_balance_cents"] == 4_000


def test_05_duplicate_issuance_and_distinct_approver(client: DigitalDollarClient) -> None:
    op_tok = client.login("issuer_operator", "demo-issuer-op-secret-2026").data["token"]
    app_tok = client.login("issuer_approver", "demo-issuer-app-secret-2026").data["token"]
    idem = f"dup-iss-{uuid.uuid4()}"

    r1 = client.request_issuance(op_tok, 1_000, "Dup test", "REF-DUP", idempotency_key=idem)
    r2 = client.request_issuance(op_tok, 1_000, "Dup test", "REF-DUP", idempotency_key=idem)
    assert r1.status_code == 201 and r2.status_code == 201
    assert r1.data["id"] == r2.data["id"]

    # Approver approves once
    a1 = client.approve_issuance(app_tok, r1.data["id"], idempotency_key=f"app1-{uuid.uuid4()}")
    assert a1.status_code == 200
    # Re-approving with a new idempotency key must fail (already posted/reconciled)
    a2 = client.approve_issuance(app_tok, r1.data["id"], idempotency_key=f"app2-{uuid.uuid4()}")
    assert a2.status_code == 409


def test_06_idempotency_conflict_and_lost_response_recovery(client: DigitalDollarClient) -> None:
    tok_a, wid_a = _new_customer_with_funds(client, 5_000)
    _, wid_b = _new_customer_with_funds(client, 0)
    idem = f"idem-conflict-{uuid.uuid4()}"

    ok = client.submit_transfer(tok_a, wid_a, wid_b, 1_000, "orig", idempotency_key=idem)
    assert ok.status_code == 201
    tid = ok.data["id"]

    # Lost response recovery: query by ID returns same transfer
    fetched = client.get_transfer(tok_a, tid)
    assert fetched.status_code == 200
    assert fetched.data["journal_id"] == ok.data["journal_id"]

    # Conflicting payload with same idempotency key MUST fail with 409 IDEMPOTENCY_CONFLICT
    conflict = client.submit_transfer(tok_a, wid_a, wid_b, 2_000, "changed", idempotency_key=idem)
    assert conflict.status_code == 409
    assert conflict.data["error_code"] == "IDEMPOTENCY_CONFLICT"


def test_07_refund_cumulative_limits(client: DigitalDollarClient) -> None:
    tok_payer, payer_w = _new_customer_with_funds(client, 10_000)
    suffix = uuid.uuid4().hex[:8]
    assert client.register(f"merch_{suffix}", "merch-pass-2026", "MERCHANT").status_code == 201
    tok_m = client.login(f"merch_{suffix}", "merch-pass-2026").data["token"]
    merch_w = client.create_wallet(tok_m, "MERCHANT_WALLET").data["account_id"]

    pr = client.create_payment_request(tok_m, merch_w, f"ORD-{suffix}", 5_000).data
    pay = client.pay_payment_request(tok_payer, pr["id"], payer_w, pr["signature_hmac"]).data

    assert client.refund_payment(tok_m, pay["id"], 3_000, "partial-1").status_code == 201
    over = client.refund_payment(tok_m, pay["id"], 2_500, "over-limit")
    assert over.status_code == 409
    assert over.data["error_code"] == "REFUND_LIMIT_EXCEEDED"
    assert client.refund_payment(tok_m, pay["id"], 2_000, "partial-2").status_code == 201


def test_08_reservation_expiry_prevents_consumption(client: DigitalDollarClient) -> None:
    tok_a, wid_a = _new_customer_with_funds(client, 5_000)
    # Insert a short-lived 1-second reservation directly and let background worker expire it
    res_id = str(uuid.uuid4())
    with psycopg.connect(DB_URL) as conn:
        with conn.cursor() as cur:
            cur.execute("SET LOCAL app.ledger_internal = 'on'")
            cur.execute(
                """
                INSERT INTO reservations (id, account_id, amount_cents, currency, purpose, reference_id, status, expires_at)
                VALUES (%s, %s, 4000, 'USD', 'EXPIRY_TEST', %s, 'ACTIVE', NOW() + INTERVAL '1 second')
                """,
                (res_id, wid_a, str(uuid.uuid4())),
            )
            cur.execute(
                "UPDATE accounts SET reserved_balance_cents = 4000 WHERE id = %s",
                (wid_a,),
            )
        conn.commit()

    time.sleep(2.2)
    bal = client.get_balance(tok_a, wid_a).data
    # Available must be restored to full $50.00 after expiry
    assert bal["available_balance_cents"] == 5_000


def test_09_unauthorised_access_and_wallet_closure_policy(client: DigitalDollarClient) -> None:
    tok_a, wid_a = _new_customer_with_funds(client, 1_000)
    tok_b, _ = _new_customer_with_funds(client, 0)

    # Customer cannot request issuance
    assert (
        client.request_issuance(tok_a, 1_000, "hack", "NOPE").status_code == 403
    )
    # Customer B cannot read Customer A's wallet
    assert client.get_balance(tok_b, wid_a).status_code == 403
    # Closing a wallet with non-zero balance must be rejected
    close_res = client.update_wallet_status(tok_a, wid_a, "CLOSED")
    assert close_res.status_code == 409
    assert close_res.data["error_code"] == "WALLET_HAS_OUTSTANDING_BALANCE"


def test_10_scheduled_payment_and_redemption_recovery(client: DigitalDollarClient) -> None:
    tok_a, wid_a = _new_customer_with_funds(client, 8_000)
    _, wid_b = _new_customer_with_funds(client, 0)

    exec_time = (datetime.now(timezone.utc) + timedelta(seconds=1)).isoformat()
    sched = client.schedule_payment(tok_a, wid_a, wid_b, 2_000, "sched-test", exec_time)
    assert sched.status_code == 201

    # Delayed/uncertain redemption puts funds in UNCERTAIN_HOLD until recovery worker resolves
    conv = client.create_conversion(
        tok_a,
        "REDEEM_TO_BANK",
        wid_a,
        3_000,
        "tok_bank_002",
        simulate_outcome="DELAYED",
    )
    assert conv.status_code == 201
    assert conv.data["status"] == "UNCERTAIN_HOLD"

    # Wait for background workers to execute scheduled payment & recover pending conversion
    time.sleep(3.5)
    after_conv = client.get_conversion(tok_a, conv.data["id"]).data
    assert after_conv["status"] == "RECONCILED"
    # $80 - $20 scheduled - $30 redeemed = $30 remaining
    assert client.get_balance(tok_a, wid_a).data["posted_balance_cents"] == 3_000


def test_11_worker_restart_and_backup_restore_consistency(client: DigitalDollarClient) -> None:
    # Verify backup.sh produces a valid dump & checksum if pg_dump or docker is available
    backup_script = os.path.join(os.path.dirname(__file__), "..", "deploy", "backup.sh")
    if os.path.exists(backup_script):
        proc = subprocess.run(
            ["bash", backup_script],
            env={**os.environ, "DATABASE_URL": DB_URL},
            capture_output=True,
            text=True,
            check=False,
        )
        if proc.returncode == 0:
            assert "Backup created:" in proc.stdout

    # Final full reconciliation check
    auditor_tok = client.login("auditor", "demo-auditor-secret-2026").data["token"]
    recon = client.reconcile(auditor_tok)
    assert recon.status_code == 200
    assert recon.data["is_healthy"] is True
    verify_postgres_invariants(DB_URL)
