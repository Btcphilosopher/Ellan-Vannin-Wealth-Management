use argon2::{
    password_hash::{rand_core::OsRng, PasswordHash, PasswordHasher, PasswordVerifier, SaltString},
    Argon2,
};
use base64::{engine::general_purpose::URL_SAFE_NO_PAD, Engine};
use chrono::{DateTime, Duration, Utc};
use dollar_types::{CorrelationId, DomainError, PrincipalId, Role};
use hmac::{Hmac, Mac};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use sqlx::{PgPool, Postgres, Row, Transaction};
use std::collections::{HashMap, VecDeque};
use std::fmt;
use std::str::FromStr;
use std::time::Instant;
use subtle::ConstantTimeEq;
use tokio::sync::Mutex;
use uuid::Uuid;

type HmacSha256 = Hmac<Sha256>;

/// Wrapper preventing sensitive strings from ever leaking into Debug/Display logs.
#[derive(Clone)]
pub struct RedactedSecret(String);

impl RedactedSecret {
    pub fn new(value: impl Into<String>) -> Self {
        Self(value.into())
    }

    pub fn expose(&self) -> &str {
        &self.0
    }
}

impl fmt::Debug for RedactedSecret {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("[REDACTED]")
    }
}

impl fmt::Display for RedactedSecret {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("[REDACTED]")
    }
}

/// Authenticated caller context extracted from a verified session token.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AuthContext {
    pub session_id: Uuid,
    pub principal_id: PrincipalId,
    pub username: String,
    pub role: Role,
    pub expires_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct TokenClaims {
    sid: Uuid,
    sub: Uuid,
    role: String,
    exp: i64,
}

/// Manages Argon2id credential hashing, HMAC-SHA256 bearer tokens, and DB-backed session revocation/expiry.
#[derive(Clone)]
pub struct AuthService {
    token_secret: RedactedSecret,
    token_ttl_secs: i64,
}

impl AuthService {
    pub fn new(token_secret: impl Into<String>, token_ttl_secs: i64) -> Result<Self, DomainError> {
        let secret = token_secret.into();
        if secret.len() < 16 {
            return Err(DomainError::Validation(
                "Auth token HMAC secret must be at least 16 bytes".to_string(),
            ));
        }
        Ok(Self {
            token_secret: RedactedSecret::new(secret),
            token_ttl_secs,
        })
    }

    pub fn hash_password(password: &str) -> Result<String, DomainError> {
        if password.len() < 8 {
            return Err(DomainError::Validation(
                "Password/secret must be at least 8 characters".to_string(),
            ));
        }
        let salt = SaltString::generate(&mut OsRng);
        Argon2::default()
            .hash_password(password.as_bytes(), &salt)
            .map(|h| h.to_string())
            .map_err(|e| DomainError::Storage(format!("Password hashing failed: {e}")))
    }

    pub fn verify_password(password: &str, hash: &str) -> Result<bool, DomainError> {
        let parsed = PasswordHash::new(hash)
            .map_err(|_| DomainError::Unauthorized("Invalid stored credential".to_string()))?;
        Ok(Argon2::default()
            .verify_password(password.as_bytes(), &parsed)
            .is_ok())
    }

    /// Registers a principal with Argon2id hashed credentials.
    pub async fn create_principal(
        &self,
        pool: &PgPool,
        username: &str,
        password: &str,
        role: Role,
    ) -> Result<PrincipalId, DomainError> {
        let id = PrincipalId::new();
        let hash = Self::hash_password(password)?;
        sqlx::query(
            r#"
            INSERT INTO principals (id, username, role, secret_hash, status)
            VALUES ($1, $2, $3, $4, 'ACTIVE')
            "#,
        )
        .bind(id.as_uuid())
        .bind(username)
        .bind(role.as_str())
        .bind(hash)
        .execute(pool)
        .await
        .map_err(|e| DomainError::Storage(format!("Failed to create principal: {e}")))?;

        Ok(id)
    }

    /// Authenticates username + password and issues an expiring, revocable HMAC-signed bearer token.
    pub async fn login(
        &self,
        pool: &PgPool,
        username: &str,
        password: &str,
        correlation_id: CorrelationId,
    ) -> Result<(String, AuthContext), DomainError> {
        let row = sqlx::query(
            r#"
            SELECT id, username, role, secret_hash, status
            FROM principals
            WHERE username = $1
            "#,
        )
        .bind(username)
        .fetch_optional(pool)
        .await
        .map_err(|e| DomainError::Storage(e.to_string()))?;

        let Some(row) = row else {
            return Err(DomainError::Unauthorized("Invalid credentials".to_string()));
        };

        let status: String = row.get("status");
        if status != "ACTIVE" {
            return Err(DomainError::Unauthorized("Principal is not active".to_string()));
        }

        let secret_hash: String = row.get("secret_hash");
        if !Self::verify_password(password, &secret_hash)? {
            return Err(DomainError::Unauthorized("Invalid credentials".to_string()));
        }

        let principal_id = PrincipalId::from_uuid(row.get("id"));
        let role = Role::from_str(&row.get::<String, _>("role"))?;
        let session_id = Uuid::now_v7();
        let expires_at = Utc::now() + Duration::seconds(self.token_ttl_secs);

        let claims = TokenClaims {
            sid: session_id,
            sub: principal_id.as_uuid(),
            role: role.as_str().to_string(),
            exp: expires_at.timestamp(),
        };

        let payload_bytes =
            serde_json::to_vec(&claims).map_err(|e| DomainError::Storage(e.to_string()))?;
        let payload_b64 = URL_SAFE_NO_PAD.encode(&payload_bytes);
        let sig = self.sign_bytes(payload_b64.as_bytes())?;
        let sig_b64 = URL_SAFE_NO_PAD.encode(sig);
        let token = format!("{payload_b64}.{sig_b64}");

        let token_hash = sha256_hex(token.as_bytes());
        sqlx::query(
            r#"
            INSERT INTO auth_sessions (id, principal_id, token_hash, expires_at)
            VALUES ($1, $2, $3, $4)
            "#,
        )
        .bind(session_id)
        .bind(principal_id.as_uuid())
        .bind(token_hash)
        .bind(expires_at)
        .execute(pool)
        .await
        .map_err(|e| DomainError::Storage(e.to_string()))?;

        let ctx = AuthContext {
            session_id,
            principal_id,
            username: row.get("username"),
            role,
            expires_at,
        };

        let mut tx = pool.begin().await.map_err(|e| DomainError::Storage(e.to_string()))?;
        record_audit_event(
            &mut tx,
            Some(principal_id),
            role.as_str(),
            "AUTH_LOGIN",
            "SESSION",
            &session_id.to_string(),
            correlation_id,
            "SUCCESS",
            serde_json::json!({"username": ctx.username}),
        )
        .await?;
        tx.commit().await.map_err(|e| DomainError::Storage(e.to_string()))?;

        Ok((token, ctx))
    }

    /// Verifies signature, expiry, and non-revoked database session status.
    pub async fn authenticate_token(
        &self,
        pool: &PgPool,
        token: &str,
    ) -> Result<AuthContext, DomainError> {
        let mut parts = token.split('.');
        let payload_b64 = parts
            .next()
            .ok_or_else(|| DomainError::Unauthorized("Malformed token".to_string()))?;
        let sig_b64 = parts
            .next()
            .ok_or_else(|| DomainError::Unauthorized("Malformed token".to_string()))?;
        if parts.next().is_some() {
            return Err(DomainError::Unauthorized("Malformed token".to_string()));
        }

        let sig_bytes = URL_SAFE_NO_PAD
            .decode(sig_b64)
            .map_err(|_| DomainError::Unauthorized("Invalid token signature encoding".to_string()))?;
        let expected_sig = self.sign_bytes(payload_b64.as_bytes())?;
        if sig_bytes.ct_eq(&expected_sig).unwrap_u8() != 1 {
            return Err(DomainError::Unauthorized("Invalid token signature".to_string()));
        }

        let payload_bytes = URL_SAFE_NO_PAD
            .decode(payload_b64)
            .map_err(|_| DomainError::Unauthorized("Invalid token payload".to_string()))?;
        let claims: TokenClaims = serde_json::from_slice(&payload_bytes)
            .map_err(|_| DomainError::Unauthorized("Invalid token claims".to_string()))?;

        if Utc::now().timestamp() > claims.exp {
            return Err(DomainError::Unauthorized("Session token expired".to_string()));
        }

        let token_hash = sha256_hex(token.as_bytes());
        let row = sqlx::query(
            r#"
            SELECT s.id, s.expires_at, s.revoked_at, p.id AS principal_id, p.username, p.role, p.status
            FROM auth_sessions s
            JOIN principals p ON p.id = s.principal_id
            WHERE s.id = $1 AND s.token_hash = $2
            "#,
        )
        .bind(claims.sid)
        .bind(token_hash)
        .fetch_optional(pool)
        .await
        .map_err(|e| DomainError::Storage(e.to_string()))?;

        let Some(row) = row else {
            return Err(DomainError::Unauthorized("Unknown session".to_string()));
        };

        let revoked_at: Option<DateTime<Utc>> = row.get("revoked_at");
        if revoked_at.is_some() {
            return Err(DomainError::Unauthorized("Session revoked".to_string()));
        }

        let expires_at: DateTime<Utc> = row.get("expires_at");
        if Utc::now() > expires_at {
            return Err(DomainError::Unauthorized("Session expired".to_string()));
        }

        let status: String = row.get("status");
        if status != "ACTIVE" {
            return Err(DomainError::Unauthorized("Principal disabled".to_string()));
        }

        Ok(AuthContext {
            session_id: row.get("id"),
            principal_id: PrincipalId::from_uuid(row.get("principal_id")),
            username: row.get("username"),
            role: Role::from_str(&row.get::<String, _>("role"))?,
            expires_at,
        })
    }

    pub async fn revoke_session(&self, pool: &PgPool, session_id: Uuid) -> Result<(), DomainError> {
        sqlx::query("UPDATE auth_sessions SET revoked_at = NOW() WHERE id = $1")
            .bind(session_id)
            .execute(pool)
            .await
            .map_err(|e| DomainError::Storage(e.to_string()))?;
        Ok(())
    }

    fn sign_bytes(&self, payload: &[u8]) -> Result<Vec<u8>, DomainError> {
        let mut mac = HmacSha256::new_from_slice(self.token_secret.expose().as_bytes())
            .map_err(|e| DomainError::Storage(format!("HMAC init error: {e}")))?;
        mac.update(payload);
        Ok(mac.finalize().into_bytes().to_vec())
    }
}

pub fn require_role(ctx: &AuthContext, allowed: &[Role]) -> Result<(), DomainError> {
    if allowed.contains(&ctx.role) {
        Ok(())
    } else {
        Err(DomainError::Forbidden(format!(
            "Role {:?} is not permitted for this operation",
            ctx.role
        )))
    }
}

pub fn sha256_hex(data: &[u8]) -> String {
    let mut hasher = Sha256::new();
    hasher.update(data);
    hex::encode(hasher.finalize())
}

/// Redacts common secret keys before storing metadata in audit logs.
pub fn redact_json_secrets(value: serde_json::Value) -> serde_json::Value {
    match value {
        serde_json::Value::Object(map) => {
            let redacted = map
                .into_iter()
                .map(|(k, v)| {
                    let lower = k.to_ascii_lowercase();
                    if lower.contains("password")
                        || lower.contains("secret")
                        || lower.contains("token")
                        || lower.contains("authorization")
                        || lower.contains("api_key")
                    {
                        (k, serde_json::Value::String("[REDACTED]".to_string()))
                    } else {
                        (k, redact_json_secrets(v))
                    }
                })
                .collect();
            serde_json::Value::Object(redacted)
        }
        serde_json::Value::Array(arr) => {
            serde_json::Value::Array(arr.into_iter().map(redact_json_secrets).collect())
        }
        other => other,
    }
}

#[allow(clippy::too_many_arguments)]
pub async fn record_audit_event(
    tx: &mut Transaction<'_, Postgres>,
    actor_principal_id: Option<PrincipalId>,
    actor_role: &str,
    action: &str,
    target_type: &str,
    target_id: &str,
    correlation_id: CorrelationId,
    outcome: &str,
    metadata: serde_json::Value,
) -> Result<(), DomainError> {
    let safe_metadata = redact_json_secrets(metadata);
    sqlx::query(
        r#"
        INSERT INTO audit_logs (
            id, actor_principal_id, actor_role, action, target_type,
            target_id, correlation_id, outcome, metadata_json
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
        "#,
    )
    .bind(Uuid::now_v7())
    .bind(actor_principal_id.map(|p| p.as_uuid()))
    .bind(actor_role)
    .bind(action)
    .bind(target_type)
    .bind(target_id)
    .bind(correlation_id.as_uuid())
    .bind(outcome)
    .bind(safe_metadata)
    .execute(&mut **tx)
    .await
    .map_err(|e| DomainError::Storage(format!("Audit log insert failed: {e}")))?;

    Ok(())
}

/// Sliding-window rate limiter keyed by caller identity or IP.
pub struct RateLimiter {
    max_requests: usize,
    window: std::time::Duration,
    buckets: Mutex<HashMap<String, VecDeque<Instant>>>,
}

impl RateLimiter {
    pub fn new(max_requests: usize, window_secs: u64) -> Self {
        Self {
            max_requests,
            window: std::time::Duration::from_secs(window_secs),
            buckets: Mutex::new(HashMap::new()),
        }
    }

    pub async fn check_and_record(&self, key: &str) -> Result<(), DomainError> {
        let now = Instant::now();
        let mut guard = self.buckets.lock().await;
        let q = guard.entry(key.to_string()).or_default();
        while let Some(&front) = q.front() {
            if now.duration_since(front) > self.window {
                q.pop_front();
            } else {
                break;
            }
        }
        if q.len() >= self.max_requests {
            return Err(DomainError::RateLimited);
        }
        q.push_back(now);
        Ok(())
    }
}

/// Explicit local-demo credential bootstrapper. Only invoked when `ENABLE_LOCAL_DEMO_BOOTSTRAP=true`.
/// Creates distinct system roles and ensures control accounts exist.
pub async fn bootstrap_local_demo_credentials(
    pool: &PgPool,
    auth: &AuthService,
) -> Result<LocalDemoBootstrapInfo, DomainError> {
    let demo_users = [
        ("issuer_operator", "demo-issuer-op-secret-2026", Role::IssuerOperator),
        ("issuer_approver", "demo-issuer-app-secret-2026", Role::IssuerApprover),
        ("auditor", "demo-auditor-secret-2026", Role::Auditor),
        ("fraud_reviewer", "demo-fraud-secret-2026", Role::FraudReviewer),
        ("system_admin", "demo-sysadmin-secret-2026", Role::SystemAdmin),
    ];

    let mut principal_ids = HashMap::new();
    for (username, password, role) in demo_users {
        let existing = sqlx::query("SELECT id FROM principals WHERE username = $1")
            .bind(username)
            .fetch_optional(pool)
            .await
            .map_err(|e| DomainError::Storage(e.to_string()))?;

        let pid = if let Some(row) = existing {
            PrincipalId::from_uuid(row.get("id"))
        } else {
            auth.create_principal(pool, username, password, role).await?
        };
        principal_ids.insert(username.to_string(), pid);
    }

    Ok(LocalDemoBootstrapInfo {
        issuer_operator_id: principal_ids["issuer_operator"],
        issuer_approver_id: principal_ids["issuer_approver"],
        system_admin_id: principal_ids["system_admin"],
    })
}

#[derive(Debug, Clone)]
pub struct LocalDemoBootstrapInfo {
    pub issuer_operator_id: PrincipalId,
    pub issuer_approver_id: PrincipalId,
    pub system_admin_id: PrincipalId,
}
