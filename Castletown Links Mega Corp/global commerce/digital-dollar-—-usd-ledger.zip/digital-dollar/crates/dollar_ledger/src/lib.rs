use chrono::{DateTime, Utc};
use dollar_auth::{record_audit_event, sha256_hex, AuthContext};
use dollar_types::{
    AccountClass, AccountId, CorrelationId, Currency, DomainError, EntryDirection, IdempotencyKey,
    JournalId, Money, PrincipalId, ReservationId, Role, WalletStatus,
};
use serde::{Deserialize, Serialize};
use sqlx::{PgPool, Postgres, Row, Transaction};
use std::collections::{BTreeSet, HashMap};
use std::str::FromStr;
use utoipa::ToSchema;
use uuid::Uuid;

/// Deterministic UUIDs for singleton system control and treasury accounts.
pub const ISSUANCE_CONTROL_ACCOUNT_UUID: Uuid =
    Uuid::from_u128(0x0000_0000_0000_7000_8000_0000_0000_0001);
pub const RETIREMENT_CONTROL_ACCOUNT_UUID: Uuid =
    Uuid::from_u128(0x0000_0000_0000_7000_8000_0000_0000_0002);
pub const ISSUER_TREASURY_ACCOUNT_UUID: Uuid =
    Uuid::from_u128(0x0000_0000_0000_7000_8000_0000_0000_0003);

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, ToSchema)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum JournalEntryType {
    Issuance,
    TreasuryDistribution,
    Transfer,
    MerchantPayment,
    PaymentRefund,
    ConversionMint,
    RedemptionRetirement,
    Reversal,
}

impl JournalEntryType {
    pub fn as_str(self) -> &'static str {
        match self {
            JournalEntryType::Issuance => "ISSUANCE",
            JournalEntryType::TreasuryDistribution => "TREASURY_DISTRIBUTION",
            JournalEntryType::Transfer => "TRANSFER",
            JournalEntryType::MerchantPayment => "MERCHANT_PAYMENT",
            JournalEntryType::PaymentRefund => "PAYMENT_REFUND",
            JournalEntryType::ConversionMint => "CONVERSION_MINT",
            JournalEntryType::RedemptionRetirement => "REDEMPTION_RETIREMENT",
            JournalEntryType::Reversal => "REVERSAL",
        }
    }
}

#[derive(Debug, Clone)]
pub struct ProposedJournalLine {
    pub account_id: AccountId,
    pub direction: EntryDirection,
    pub amount: Money,
}

#[derive(Debug, Clone)]
pub struct PostJournalRequest {
    pub entry_type: JournalEntryType,
    pub transaction_ref: String,
    pub correlation_id: CorrelationId,
    pub reversal_of_journal_id: Option<JournalId>,
    pub created_by: PrincipalId,
    pub description_code: String,
    pub lines: Vec<ProposedJournalLine>,
    /// Optional reservation consumed atomically by this journal posting.
    pub consume_reservation_id: Option<ReservationId>,
    /// Optional outbox event emitted atomically inside the same transaction.
    pub outbox_event: Option<OutboxProposal>,
}

#[derive(Debug, Clone)]
pub struct OutboxProposal {
    pub aggregate_type: String,
    pub aggregate_id: Uuid,
    pub event_type: String,
    pub payload: serde_json::Value,
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct WalletRecord {
    pub account_id: AccountId,
    pub owner_principal_id: PrincipalId,
    pub account_class: AccountClass,
    pub status: WalletStatus,
    pub currency: Currency,
    pub posted_balance_cents: i64,
    pub reserved_balance_cents: i64,
    pub available_balance_cents: i64,
    pub created_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct WalletTransactionItem {
    pub journal_id: JournalId,
    pub entry_type: String,
    pub transaction_ref: String,
    pub direction: EntryDirection,
    pub amount_cents: i64,
    pub currency: Currency,
    pub description_code: String,
    pub reversal_of_journal_id: Option<JournalId>,
    pub created_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct ReservationRecord {
    pub id: ReservationId,
    pub account_id: AccountId,
    pub amount_cents: i64,
    pub currency: Currency,
    pub purpose: String,
    pub reference_id: Uuid,
    pub status: String,
    pub expires_at: DateTime<Utc>,
    pub created_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct ReconciliationReport {
    pub run_id: Uuid,
    pub total_issued_cents: i64,
    pub total_retired_cents: i64,
    pub outstanding_supply_cents: i64,
    pub sum_wallet_posted_cents: i64,
    pub sum_wallet_reserved_cents: i64,
    pub unbalanced_journals_count: i64,
    pub balance_mismatches_count: i64,
    pub is_healthy: bool,
    pub checked_at: DateTime<Utc>,
}

/// Ensures singleton system accounts (`ISSUANCE_CONTROL`, `RETIREMENT_CONTROL`, `ISSUER_TREASURY`) exist.
pub async fn ensure_system_accounts(
    pool: &PgPool,
    system_admin_id: PrincipalId,
) -> Result<(), DomainError> {
    let specs = [
        (
            ISSUANCE_CONTROL_ACCOUNT_UUID,
            AccountClass::IssuanceControl,
        ),
        (
            RETIREMENT_CONTROL_ACCOUNT_UUID,
            AccountClass::RetirementControl,
        ),
        (
            ISSUER_TREASURY_ACCOUNT_UUID,
            AccountClass::IssuerTreasury,
        ),
    ];

    for (acct_uuid, class) in specs {
        sqlx::query(
            r#"
            INSERT INTO accounts (
                id, owner_principal_id, account_class, normal_balance, currency, status
            ) VALUES ($1, $2, $3, $4, 'USD', 'ACTIVE')
            ON CONFLICT (id) DO NOTHING
            "#,
        )
        .bind(acct_uuid)
        .bind(system_admin_id.as_uuid())
        .bind(class.as_str())
        .bind(class.normal_balance().as_str())
        .execute(pool)
        .await
        .map_err(|e| DomainError::Storage(format!("Failed to initialize system account: {e}")))?;
    }

    Ok(())
}

/// Pure double-entry validation check independent of the database.
/// Enforces: >= 2 lines, single currency USD, strictly positive amounts, and SUM(debit) == SUM(credit).
pub fn validate_balanced_lines(lines: &[ProposedJournalLine]) -> Result<(), DomainError> {
    if lines.len() < 2 {
        return Err(DomainError::InsufficientJournalLines);
    }

    let mut debits: i128 = 0;
    let mut credits: i128 = 0;

    for line in lines {
        if line.amount.currency() != Currency::Usd {
            return Err(DomainError::UnsupportedCurrency(
                line.amount.currency().to_string(),
            ));
        }
        if line.amount.cents() <= 0 {
            return Err(DomainError::NonPositiveAmount(line.amount.cents()));
        }
        match line.direction {
            EntryDirection::Debit => debits += i128::from(line.amount.cents()),
            EntryDirection::Credit => credits += i128::from(line.amount.cents()),
        }
    }

    if debits != credits {
        return Err(DomainError::UnbalancedJournal {
            debits_cents: debits as i64,
            credits_cents: credits as i64,
        });
    }

    Ok(())
}

/// Creates a customer or merchant wallet with optional idempotency.
pub async fn create_wallet(
    pool: &PgPool,
    owner_principal_id: PrincipalId,
    account_class: AccountClass,
    currency: Currency,
    correlation_id: CorrelationId,
) -> Result<WalletRecord, DomainError> {
    if !account_class.is_wallet() {
        return Err(DomainError::Validation(
            "Public wallet creation only supports CUSTOMER_WALLET or MERCHANT_WALLET".to_string(),
        ));
    }
    if currency != Currency::Usd {
        return Err(DomainError::UnsupportedCurrency(currency.to_string()));
    }

    let account_id = AccountId::new();
    let mut tx = pool.begin().await.map_err(|e| DomainError::Storage(e.to_string()))?;

    let row = sqlx::query(
        r#"
        INSERT INTO accounts (
            id, owner_principal_id, account_class, normal_balance, currency, status
        ) VALUES ($1, $2, $3, $4, 'USD', 'ACTIVE')
        RETURNING created_at
        "#,
    )
    .bind(account_id.as_uuid())
    .bind(owner_principal_id.as_uuid())
    .bind(account_class.as_str())
    .bind(account_class.normal_balance().as_str())
    .fetch_one(&mut *tx)
    .await
    .map_err(|e| DomainError::Storage(format!("Failed to create wallet: {e}")))?;

    record_audit_event(
        &mut tx,
        Some(owner_principal_id),
        account_class.as_str(),
        "WALLET_CREATED",
        "ACCOUNT",
        &account_id.to_string(),
        correlation_id,
        "SUCCESS",
        serde_json::json!({"account_class": account_class.as_str(), "currency": "USD"}),
    )
    .await?;

    tx.commit().await.map_err(|e| DomainError::Storage(e.to_string()))?;

    Ok(WalletRecord {
        account_id,
        owner_principal_id,
        account_class,
        status: WalletStatus::Active,
        currency: Currency::Usd,
        posted_balance_cents: 0,
        reserved_balance_cents: 0,
        available_balance_cents: 0,
        created_at: row.get("created_at"),
    })
}

/// Authorizes ownership (or Auditor/FraudReviewer/SystemAdmin read access).
pub fn authorize_account_read(ctx: &AuthContext, owner_id: PrincipalId) -> Result<(), DomainError> {
    if ctx.principal_id == owner_id
        || matches!(
            ctx.role,
            Role::Auditor | Role::FraudReviewer | Role::SystemAdmin
        )
    {
        Ok(())
    } else {
        Err(DomainError::Forbidden(
            "Caller does not own this wallet".to_string(),
        ))
    }
}

pub fn authorize_account_spend(ctx: &AuthContext, owner_id: PrincipalId) -> Result<(), DomainError> {
    if ctx.principal_id == owner_id {
        Ok(())
    } else {
        Err(DomainError::Forbidden(
            "Only the wallet owner may initiate debits".to_string(),
        ))
    }
}

/// Computes authoritative posted balance directly from immutable `journal_lines`.
pub async fn compute_authoritative_posted_balance_in_tx(
    tx: &mut Transaction<'_, Postgres>,
    account_id: AccountId,
    normal_balance: EntryDirection,
) -> Result<i64, DomainError> {
    let row = sqlx::query(
        r#"
        SELECT
            COALESCE(SUM(CASE WHEN direction = 'DEBIT' THEN amount_cents ELSE 0 END), 0)::BIGINT AS debits,
            COALESCE(SUM(CASE WHEN direction = 'CREDIT' THEN amount_cents ELSE 0 END), 0)::BIGINT AS credits
        FROM journal_lines
        WHERE account_id = $1
        "#,
    )
    .bind(account_id.as_uuid())
    .fetch_one(&mut **tx)
    .await
    .map_err(|e| DomainError::Storage(e.to_string()))?;

    let debits: i64 = row.get("debits");
    let credits: i64 = row.get("credits");

    let balance = match normal_balance {
        EntryDirection::Credit => credits
            .checked_sub(debits)
            .ok_or(DomainError::AmountOverflow)?,
        EntryDirection::Debit => debits
            .checked_sub(credits)
            .ok_or(DomainError::AmountOverflow)?,
    };

    Ok(balance)
}

/// Computes authoritative active reserved funds from non-expired ACTIVE reservations.
pub async fn compute_authoritative_reserved_balance_in_tx(
    tx: &mut Transaction<'_, Postgres>,
    account_id: AccountId,
) -> Result<i64, DomainError> {
    let row = sqlx::query(
        r#"
        SELECT COALESCE(SUM(amount_cents), 0)::BIGINT AS reserved
        FROM reservations
        WHERE account_id = $1 AND status = 'ACTIVE' AND expires_at > NOW()
        "#,
    )
    .bind(account_id.as_uuid())
    .fetch_one(&mut **tx)
    .await
    .map_err(|e| DomainError::Storage(e.to_string()))?;

    Ok(row.get("reserved"))
}

/// Retrieves wallet balance derived directly from journal_lines and active reservations.
pub async fn get_wallet_balance(
    pool: &PgPool,
    ctx: &AuthContext,
    account_id: AccountId,
) -> Result<WalletRecord, DomainError> {
    let mut tx = pool.begin().await.map_err(|e| DomainError::Storage(e.to_string()))?;

    let row = sqlx::query(
        r#"
        SELECT id, owner_principal_id, account_class, normal_balance, currency, status, created_at
        FROM accounts
        WHERE id = $1
        "#,
    )
    .bind(account_id.as_uuid())
    .fetch_optional(&mut *tx)
    .await
    .map_err(|e| DomainError::Storage(e.to_string()))?;

    let Some(row) = row else {
        return Err(DomainError::NotFound(format!("Account {account_id}")));
    };

    let owner_principal_id = PrincipalId::from_uuid(row.get("owner_principal_id"));
    authorize_account_read(ctx, owner_principal_id)?;

    let account_class = AccountClass::from_str(&row.get::<String, _>("account_class"))?;
    let normal_balance = EntryDirection::from_str(&row.get::<String, _>("normal_balance"))?;
    let status = WalletStatus::from_str(&row.get::<String, _>("status"))?;

    let posted = compute_authoritative_posted_balance_in_tx(&mut tx, account_id, normal_balance).await?;
    let reserved = compute_authoritative_reserved_balance_in_tx(&mut tx, account_id).await?;
    let available = posted - reserved;

    tx.commit().await.map_err(|e| DomainError::Storage(e.to_string()))?;

    Ok(WalletRecord {
        account_id,
        owner_principal_id,
        account_class,
        status,
        currency: Currency::Usd,
        posted_balance_cents: posted,
        reserved_balance_cents: reserved,
        available_balance_cents: available,
        created_at: row.get("created_at"),
    })
}

/// Lists immutable transaction history for a wallet without exposing personal data.
pub async fn get_wallet_transactions(
    pool: &PgPool,
    ctx: &AuthContext,
    account_id: AccountId,
    limit: i64,
    offset: i64,
) -> Result<Vec<WalletTransactionItem>, DomainError> {
    let acct = sqlx::query("SELECT owner_principal_id FROM accounts WHERE id = $1")
        .bind(account_id.as_uuid())
        .fetch_optional(pool)
        .await
        .map_err(|e| DomainError::Storage(e.to_string()))?
        .ok_or_else(|| DomainError::NotFound(format!("Account {account_id}")))?;

    authorize_account_read(ctx, PrincipalId::from_uuid(acct.get("owner_principal_id")))?;

    let safe_limit = limit.clamp(1, 200);
    let safe_offset = offset.max(0);

    let rows = sqlx::query(
        r#"
        SELECT
            j.id AS journal_id,
            j.entry_type,
            j.transaction_ref,
            jl.direction,
            jl.amount_cents,
            j.description_code,
            j.reversal_of_journal_id,
            j.created_at
        FROM journal_lines jl
        JOIN journals j ON j.id = jl.journal_id
        WHERE jl.account_id = $1
        ORDER BY j.created_at DESC, jl.id DESC
        LIMIT $2 OFFSET $3
        "#,
    )
    .bind(account_id.as_uuid())
    .bind(safe_limit)
    .bind(safe_offset)
    .fetch_all(pool)
    .await
    .map_err(|e| DomainError::Storage(e.to_string()))?;

    let mut out = Vec::with_capacity(rows.len());
    for row in rows {
        out.push(WalletTransactionItem {
            journal_id: JournalId::from_uuid(row.get("journal_id")),
            entry_type: row.get("entry_type"),
            transaction_ref: row.get("transaction_ref"),
            direction: EntryDirection::from_str(&row.get::<String, _>("direction"))?,
            amount_cents: row.get("amount_cents"),
            currency: Currency::Usd,
            description_code: row.get("description_code"),
            reversal_of_journal_id: row
                .get::<Option<Uuid>, _>("reversal_of_journal_id")
                .map(JournalId::from_uuid),
            created_at: row.get("created_at"),
        });
    }
    Ok(out)
}

/// Suspends or closes a wallet under explicit policy checks.
/// Closing a wallet is forbidden if posted or reserved balance is non-zero.
pub async fn update_wallet_status(
    pool: &PgPool,
    ctx: &AuthContext,
    account_id: AccountId,
    new_status: WalletStatus,
    correlation_id: CorrelationId,
) -> Result<WalletRecord, DomainError> {
    let mut tx = pool.begin().await.map_err(|e| DomainError::Storage(e.to_string()))?;

    let row = sqlx::query(
        r#"
        SELECT id, owner_principal_id, account_class, normal_balance, status, created_at
        FROM accounts
        WHERE id = $1
        FOR UPDATE
        "#,
    )
    .bind(account_id.as_uuid())
    .fetch_optional(&mut *tx)
    .await
    .map_err(|e| DomainError::Storage(e.to_string()))?
    .ok_or_else(|| DomainError::NotFound(format!("Account {account_id}")))?;

    let owner_id = PrincipalId::from_uuid(row.get("owner_principal_id"));
    if ctx.principal_id != owner_id && !matches!(ctx.role, Role::SystemAdmin | Role::FraudReviewer) {
        return Err(DomainError::Forbidden(
            "Only the owner, fraud reviewer, or system admin may alter wallet status".to_string(),
        ));
    }

    let account_class = AccountClass::from_str(&row.get::<String, _>("account_class"))?;
    if !account_class.is_wallet() {
        return Err(DomainError::Forbidden(
            "System control accounts cannot be suspended or closed".to_string(),
        ));
    }

    let normal_balance = EntryDirection::from_str(&row.get::<String, _>("normal_balance"))?;
    let posted = compute_authoritative_posted_balance_in_tx(&mut tx, account_id, normal_balance).await?;
    let reserved = compute_authoritative_reserved_balance_in_tx(&mut tx, account_id).await?;

    if new_status == WalletStatus::Closed && (posted != 0 || reserved != 0) {
        return Err(DomainError::WalletClosureOutstandingObligations(
            account_id, posted, reserved,
        ));
    }

    sqlx::query(
        r#"
        UPDATE accounts
        SET status = $2,
            closed_at = CASE WHEN $2 = 'CLOSED' THEN NOW() ELSE closed_at END
        WHERE id = $1
        "#,
    )
    .bind(account_id.as_uuid())
    .bind(new_status.as_str())
    .execute(&mut *tx)
    .await
    .map_err(|e| DomainError::Storage(e.to_string()))?;

    record_audit_event(
        &mut tx,
        Some(ctx.principal_id),
        ctx.role.as_str(),
        "WALLET_STATUS_CHANGED",
        "ACCOUNT",
        &account_id.to_string(),
        correlation_id,
        "SUCCESS",
        serde_json::json!({"new_status": new_status.as_str()}),
    )
    .await?;

    tx.commit().await.map_err(|e| DomainError::Storage(e.to_string()))?;

    Ok(WalletRecord {
        account_id,
        owner_principal_id: owner_id,
        account_class,
        status: new_status,
        currency: Currency::Usd,
        posted_balance_cents: posted,
        reserved_balance_cents: reserved,
        available_balance_cents: posted - reserved,
        created_at: row.get("created_at"),
    })
}

/// Executes an atomic double-entry journal posting inside an existing SQL transaction.
///
/// Locking & Isolation Strategy:
/// - Acquires `FOR UPDATE` row locks on all participating accounts sorted in ascending UUID order,
///   preventing deadlocks across concurrent opposing transfers and serializing competing debits.
/// - Re-derives authoritative `posted` and `reserved` balances from `journal_lines` and `reservations`
///   inside the lock window rather than trusting any stale cached figure.
/// - Refreshes the read-only projection columns only after `SET LOCAL app.ledger_internal = 'on'`.
pub async fn post_journal_in_tx(
    tx: &mut Transaction<'_, Postgres>,
    req: PostJournalRequest,
) -> Result<JournalId, DomainError> {
    validate_balanced_lines(&req.lines)?;

    // Enable internal projection maintenance flag for this transaction only.
    sqlx::query("SET LOCAL app.ledger_internal = 'on'")
        .execute(&mut **tx)
        .await
        .map_err(|e| DomainError::Storage(e.to_string()))?;

    // Expire overdue reservations first so available funds reflect expired holds accurately.
    sqlx::query(
        r#"
        UPDATE reservations
        SET status = 'EXPIRED', finalized_at = NOW()
        WHERE status = 'ACTIVE' AND expires_at <= NOW()
        "#,
    )
    .execute(&mut **tx)
    .await
    .map_err(|e| DomainError::Storage(e.to_string()))?;

    // Collect distinct account IDs sorted deterministically to prevent deadlocks.
    let account_ids: Vec<Uuid> = req
        .lines
        .iter()
        .map(|l| l.account_id.as_uuid())
        .collect::<BTreeSet<_>>()
        .into_iter()
        .collect();

    let locked_rows = sqlx::query(
        r#"
        SELECT id, account_class, normal_balance, status
        FROM accounts
        WHERE id = ANY($1)
        ORDER BY id ASC
        FOR UPDATE
        "#,
    )
    .bind(&account_ids)
    .fetch_all(&mut **tx)
    .await
    .map_err(|e| DomainError::Storage(e.to_string()))?;

    if locked_rows.len() != account_ids.len() {
        return Err(DomainError::NotFound(
            "One or more accounts in journal posting do not exist".to_string(),
        ));
    }

    struct LockedAccount {
        class: AccountClass,
        normal_balance: EntryDirection,
        posted: i64,
        reserved: i64,
    }

    let mut accounts_map: HashMap<Uuid, LockedAccount> = HashMap::with_capacity(locked_rows.len());
    for row in locked_rows {
        let id: Uuid = row.get("id");
        let acct_id = AccountId::from_uuid(id);
        let class = AccountClass::from_str(&row.get::<String, _>("account_class"))?;
        let normal_balance = EntryDirection::from_str(&row.get::<String, _>("normal_balance"))?;
        let status = WalletStatus::from_str(&row.get::<String, _>("status"))?;

        if status != WalletStatus::Active {
            return Err(DomainError::AccountNotActive(
                acct_id,
                status.as_str().to_string(),
            ));
        }

        let posted =
            compute_authoritative_posted_balance_in_tx(tx, acct_id, normal_balance).await?;
        let reserved = compute_authoritative_reserved_balance_in_tx(tx, acct_id).await?;

        accounts_map.insert(
            id,
            LockedAccount {
                class,
                normal_balance,
                posted,
                reserved,
            },
        );
    }

    let journal_id = JournalId::new();

    // If consuming a reservation atomically, verify it is ACTIVE and unexpired, and credit its release
    // against the available funds check on its account.
    let mut consumed_res_account: Option<(Uuid, i64)> = None;
    if let Some(res_id) = req.consume_reservation_id {
        let res_row = sqlx::query(
            r#"
            SELECT account_id, amount_cents, status, expires_at
            FROM reservations
            WHERE id = $1
            FOR UPDATE
            "#,
        )
        .bind(res_id.as_uuid())
        .fetch_optional(&mut **tx)
        .await
        .map_err(|e| DomainError::Storage(e.to_string()))?
        .ok_or_else(|| DomainError::NotFound(format!("Reservation {res_id}")))?;

        let status: String = res_row.get("status");
        let expires_at: DateTime<Utc> = res_row.get("expires_at");
        if status != "ACTIVE" {
            return Err(DomainError::InvalidState(format!(
                "Reservation {res_id} is {status} and cannot be consumed"
            )));
        }
        if expires_at <= Utc::now() {
            return Err(DomainError::Expired(format!(
                "Reservation {res_id} has expired"
            )));
        }
        let res_acct: Uuid = res_row.get("account_id");
        let res_amt: i64 = res_row.get("amount_cents");

        sqlx::query(
            r#"
            UPDATE reservations
            SET status = 'CONSUMED', journal_id = $2, finalized_at = NOW()
            WHERE id = $1
            "#,
        )
        .bind(res_id.as_uuid())
        .bind(journal_id.as_uuid())
        .execute(&mut **tx)
        .await
        .map_err(|e| DomainError::Storage(e.to_string()))?;

        consumed_res_account = Some((res_acct, res_amt));
    }

    // Validate net effect on each account and enforce non-negative available funds for liability accounts.
    let mut net_deltas: HashMap<Uuid, i64> = HashMap::new();
    for line in &req.lines {
        let uid = line.account_id.as_uuid();
        let acct = accounts_map.get(&uid).expect("account locked");
        let signed = match (acct.normal_balance, line.direction) {
            (EntryDirection::Credit, EntryDirection::Credit)
            | (EntryDirection::Debit, EntryDirection::Debit) => line.amount.cents(),
            (EntryDirection::Credit, EntryDirection::Debit)
            | (EntryDirection::Debit, EntryDirection::Credit) => -line.amount.cents(),
        };
        let entry = net_deltas.entry(uid).or_insert(0);
        *entry = entry.checked_add(signed).ok_or(DomainError::AmountOverflow)?;
    }

    for (uid, delta) in &net_deltas {
        let acct = accounts_map.get(uid).expect("account locked");
        let new_posted = acct
            .posted
            .checked_add(*delta)
            .ok_or(DomainError::AmountOverflow)?;

        let released_res = match consumed_res_account {
            Some((r_uid, r_amt)) if r_uid == *uid => r_amt,
            _ => 0,
        };
        let remaining_reserved = (acct.reserved - released_res).max(0);

        if acct.class.is_circulating_liability() && new_posted < remaining_reserved {
            let available = acct.posted - remaining_reserved;
            return Err(DomainError::InsufficientFunds {
                available_cents: available.max(0),
                required_cents: -*delta,
            });
        }
    }

    // Insert immutable journal header.
    sqlx::query(
        r#"
        INSERT INTO journals (
            id, entry_type, transaction_ref, correlation_id,
            reversal_of_journal_id, created_by_principal_id, description_code
        ) VALUES ($1, $2, $3, $4, $5, $6, $7)
        "#,
    )
    .bind(journal_id.as_uuid())
    .bind(req.entry_type.as_str())
    .bind(&req.transaction_ref)
    .bind(req.correlation_id.as_uuid())
    .bind(req.reversal_of_journal_id.map(|j| j.as_uuid()))
    .bind(req.created_by.as_uuid())
    .bind(&req.description_code)
    .execute(&mut **tx)
    .await
    .map_err(|e| DomainError::Storage(format!("Failed to insert journal header: {e}")))?;

    // Insert immutable journal lines.
    for line in &req.lines {
        sqlx::query(
            r#"
            INSERT INTO journal_lines (
                id, journal_id, account_id, direction, amount_cents, currency
            ) VALUES ($1, $2, $3, $4, $5, 'USD')
            "#,
        )
        .bind(Uuid::now_v7())
        .bind(journal_id.as_uuid())
        .bind(line.account_id.as_uuid())
        .bind(line.direction.as_str())
        .bind(line.amount.cents())
        .execute(&mut **tx)
        .await
        .map_err(|e| DomainError::Storage(format!("Failed to insert journal line: {e}")))?;
    }

    // Refresh authoritative projections on affected accounts.
    for uid in account_ids {
        let acct = accounts_map.get(&uid).expect("account locked");
        let acct_id = AccountId::from_uuid(uid);
        let new_posted =
            compute_authoritative_posted_balance_in_tx(tx, acct_id, acct.normal_balance).await?;
        let new_reserved = compute_authoritative_reserved_balance_in_tx(tx, acct_id).await?;

        sqlx::query(
            r#"
            UPDATE accounts
            SET posted_balance_cents = $2,
                reserved_balance_cents = $3
            WHERE id = $1
            "#,
        )
        .bind(uid)
        .bind(new_posted)
        .bind(new_reserved)
        .execute(&mut **tx)
        .await
        .map_err(|e| DomainError::Storage(format!("Failed to refresh account projection: {e}")))?;
    }

    if let Some(event) = req.outbox_event {
        sqlx::query(
            r#"
            INSERT INTO outbox_events (id, aggregate_type, aggregate_id, event_type, payload_json)
            VALUES ($1, $2, $3, $4, $5)
            "#,
        )
        .bind(Uuid::now_v7())
        .bind(event.aggregate_type)
        .bind(event.aggregate_id)
        .bind(event.event_type)
        .bind(event.payload)
        .execute(&mut **tx)
        .await
        .map_err(|e| DomainError::Storage(format!("Failed to enqueue outbox event: {e}")))?;
    }

    Ok(journal_id)
}

/// Creates a time-bounded fund reservation inside an active DB transaction.
pub async fn create_reservation_in_tx(
    tx: &mut Transaction<'_, Postgres>,
    account_id: AccountId,
    amount: Money,
    purpose: &str,
    reference_id: Uuid,
    expires_at: DateTime<Utc>,
) -> Result<ReservationRecord, DomainError> {
    if expires_at <= Utc::now() {
        return Err(DomainError::Expired(
            "Reservation expiry must be in the future".to_string(),
        ));
    }

    sqlx::query("SET LOCAL app.ledger_internal = 'on'")
        .execute(&mut **tx)
        .await
        .map_err(|e| DomainError::Storage(e.to_string()))?;

    // Expire stale reservations on this account before evaluating available funds.
    sqlx::query(
        r#"
        UPDATE reservations
        SET status = 'EXPIRED', finalized_at = NOW()
        WHERE account_id = $1 AND status = 'ACTIVE' AND expires_at <= NOW()
        "#,
    )
    .bind(account_id.as_uuid())
    .execute(&mut **tx)
    .await
    .map_err(|e| DomainError::Storage(e.to_string()))?;

    let row = sqlx::query(
        r#"
        SELECT normal_balance, status
        FROM accounts
        WHERE id = $1
        FOR UPDATE
        "#,
    )
    .bind(account_id.as_uuid())
    .fetch_optional(&mut **tx)
    .await
    .map_err(|e| DomainError::Storage(e.to_string()))?
    .ok_or_else(|| DomainError::NotFound(format!("Account {account_id}")))?;

    let status = WalletStatus::from_str(&row.get::<String, _>("status"))?;
    if status != WalletStatus::Active {
        return Err(DomainError::AccountNotActive(
            account_id,
            status.as_str().to_string(),
        ));
    }
    let normal_balance = EntryDirection::from_str(&row.get::<String, _>("normal_balance"))?;
    let posted = compute_authoritative_posted_balance_in_tx(tx, account_id, normal_balance).await?;
    let reserved = compute_authoritative_reserved_balance_in_tx(tx, account_id).await?;
    let available = posted - reserved;

    if available < amount.cents() {
        return Err(DomainError::InsufficientFunds {
            available_cents: available.max(0),
            required_cents: amount.cents(),
        });
    }

    let res_id = ReservationId::new();
    let inserted = sqlx::query(
        r#"
        INSERT INTO reservations (id, account_id, amount_cents, currency, purpose, reference_id, status, expires_at)
        VALUES ($1, $2, $3, 'USD', $4, $5, 'ACTIVE', $6)
        RETURNING created_at
        "#,
    )
    .bind(res_id.as_uuid())
    .bind(account_id.as_uuid())
    .bind(amount.cents())
    .bind(purpose)
    .bind(reference_id)
    .bind(expires_at)
    .fetch_one(&mut **tx)
    .await
    .map_err(|e| DomainError::Storage(e.to_string()))?;

    let new_reserved = compute_authoritative_reserved_balance_in_tx(tx, account_id).await?;
    sqlx::query("UPDATE accounts SET reserved_balance_cents = $2 WHERE id = $1")
        .bind(account_id.as_uuid())
        .bind(new_reserved)
        .execute(&mut **tx)
        .await
        .map_err(|e| DomainError::Storage(e.to_string()))?;

    Ok(ReservationRecord {
        id: res_id,
        account_id,
        amount_cents: amount.cents(),
        currency: Currency::Usd,
        purpose: purpose.to_string(),
        reference_id,
        status: "ACTIVE".to_string(),
        expires_at,
        created_at: inserted.get("created_at"),
    })
}

/// Releases an active reservation without debiting the customer wallet (e.g. failed external payout).
pub async fn release_reservation_in_tx(
    tx: &mut Transaction<'_, Postgres>,
    reservation_id: ReservationId,
) -> Result<(), DomainError> {
    sqlx::query("SET LOCAL app.ledger_internal = 'on'")
        .execute(&mut **tx)
        .await
        .map_err(|e| DomainError::Storage(e.to_string()))?;

    let row = sqlx::query(
        r#"
        SELECT account_id, status
        FROM reservations
        WHERE id = $1
        FOR UPDATE
        "#,
    )
    .bind(reservation_id.as_uuid())
    .fetch_optional(&mut **tx)
    .await
    .map_err(|e| DomainError::Storage(e.to_string()))?
    .ok_or_else(|| DomainError::NotFound(format!("Reservation {reservation_id}")))?;

    let acct_id = AccountId::from_uuid(row.get("account_id"));
    let status: String = row.get("status");
    if status == "ACTIVE" {
        sqlx::query(
            "UPDATE reservations SET status = 'RELEASED', finalized_at = NOW() WHERE id = $1",
        )
        .bind(reservation_id.as_uuid())
        .execute(&mut **tx)
        .await
        .map_err(|e| DomainError::Storage(e.to_string()))?;

        let new_reserved = compute_authoritative_reserved_balance_in_tx(tx, acct_id).await?;
        sqlx::query("UPDATE accounts SET reserved_balance_cents = $2 WHERE id = $1")
            .bind(acct_id.as_uuid())
            .bind(new_reserved)
            .execute(&mut **tx)
            .await
            .map_err(|e| DomainError::Storage(e.to_string()))?;
    }

    Ok(())
}

/// Expires overdue reservations and refreshes affected account reservation projections.
pub async fn expire_overdue_reservations(pool: &PgPool) -> Result<u64, DomainError> {
    let mut tx = pool.begin().await.map_err(|e| DomainError::Storage(e.to_string()))?;
    sqlx::query("SET LOCAL app.ledger_internal = 'on'")
        .execute(&mut *tx)
        .await
        .map_err(|e| DomainError::Storage(e.to_string()))?;

    let expired_rows = sqlx::query(
        r#"
        UPDATE reservations
        SET status = 'EXPIRED', finalized_at = NOW()
        WHERE status = 'ACTIVE' AND expires_at <= NOW()
        RETURNING account_id
        "#,
    )
    .fetch_all(&mut *tx)
    .await
    .map_err(|e| DomainError::Storage(e.to_string()))?;

    let count = expired_rows.len() as u64;
    let unique_accts: BTreeSet<Uuid> = expired_rows.iter().map(|r| r.get("account_id")).collect();
    for uid in unique_accts {
        let acct_id = AccountId::from_uuid(uid);
        let new_reserved = compute_authoritative_reserved_balance_in_tx(&mut tx, acct_id).await?;
        sqlx::query("UPDATE accounts SET reserved_balance_cents = $2 WHERE id = $1")
            .bind(uid)
            .bind(new_reserved)
            .execute(&mut *tx)
            .await
            .map_err(|e| DomainError::Storage(e.to_string()))?;
    }

    tx.commit().await.map_err(|e| DomainError::Storage(e.to_string()))?;
    Ok(count)
}

/// Checks idempotency table inside an active DB transaction.
/// Returns `Some((status, body))` on exact replay, or `Err(IdempotencyConflict)` if payload differs.
pub async fn check_idempotency_in_tx(
    tx: &mut Transaction<'_, Postgres>,
    principal_id: PrincipalId,
    endpoint: &str,
    idempotency_key: &IdempotencyKey,
    canonical_payload_bytes: &[u8],
) -> Result<Option<(u16, serde_json::Value)>, DomainError> {
    let request_hash = sha256_hex(canonical_payload_bytes);
    let row = sqlx::query(
        r#"
        SELECT request_hash, response_status, response_body
        FROM idempotency_records
        WHERE principal_id = $1 AND endpoint = $2 AND idempotency_key = $3
        FOR UPDATE
        "#,
    )
    .bind(principal_id.as_uuid())
    .bind(endpoint)
    .bind(idempotency_key.as_str())
    .fetch_optional(&mut **tx)
    .await
    .map_err(|e| DomainError::Storage(e.to_string()))?;

    if let Some(row) = row {
        let existing_hash: String = row.get("request_hash");
        if existing_hash != request_hash {
            return Err(DomainError::IdempotencyConflict);
        }
        let status: i32 = row.get("response_status");
        let body: serde_json::Value = row.get("response_body");
        return Ok(Some((status as u16, body)));
    }

    Ok(None)
}

pub async fn store_idempotency_in_tx(
    tx: &mut Transaction<'_, Postgres>,
    principal_id: PrincipalId,
    endpoint: &str,
    idempotency_key: &IdempotencyKey,
    canonical_payload_bytes: &[u8],
    response_status: u16,
    response_body: &serde_json::Value,
    resource_id: Option<Uuid>,
) -> Result<(), DomainError> {
    let request_hash = sha256_hex(canonical_payload_bytes);
    sqlx::query(
        r#"
        INSERT INTO idempotency_records (
            principal_id, endpoint, idempotency_key, request_hash,
            response_status, response_body, resource_id
        ) VALUES ($1, $2, $3, $4, $5, $6, $7)
        "#,
    )
    .bind(principal_id.as_uuid())
    .bind(endpoint)
    .bind(idempotency_key.as_str())
    .bind(request_hash)
    .bind(i32::from(response_status))
    .bind(response_body)
    .bind(resource_id)
    .execute(&mut **tx)
    .await
    .map_err(|e| DomainError::Storage(format!("Failed to persist idempotency record: {e}")))?;

    Ok(())
}

/// Runs full monetary supply, double-entry balance, and projection reconciliation across the ledger.
pub async fn run_reconciliation(
    pool: &PgPool,
    run_type: &str,
) -> Result<ReconciliationReport, DomainError> {
    let mut tx = pool.begin().await.map_err(|e| DomainError::Storage(e.to_string()))?;

    // 1. Verify every journal has >= 2 lines and debits == credits.
    let unbalanced_row = sqlx::query(
        r#"
        SELECT COUNT(*)::BIGINT AS cnt
        FROM (
            SELECT
                j.id,
                COALESCE(SUM(CASE WHEN jl.direction = 'DEBIT' THEN jl.amount_cents ELSE 0 END), 0) AS debits,
                COALESCE(SUM(CASE WHEN jl.direction = 'CREDIT' THEN jl.amount_cents ELSE 0 END), 0) AS credits,
                COUNT(jl.id) AS lines
            FROM journals j
            LEFT JOIN journal_lines jl ON jl.journal_id = j.id
            GROUP BY j.id
            HAVING COUNT(jl.id) < 2
                OR COALESCE(SUM(CASE WHEN jl.direction = 'DEBIT' THEN jl.amount_cents ELSE 0 END), 0)
                   <> COALESCE(SUM(CASE WHEN jl.direction = 'CREDIT' THEN jl.amount_cents ELSE 0 END), 0)
        ) sub
        "#,
    )
    .fetch_one(&mut *tx)
    .await
    .map_err(|e| DomainError::Storage(e.to_string()))?;
    let unbalanced_journals_count: i64 = unbalanced_row.get("cnt");

    // 2. Compare each account's cached projection against authoritative journal_lines & reservations.
    let acct_rows = sqlx::query(
        r#"
        SELECT
            a.id,
            a.account_class,
            a.normal_balance,
            a.posted_balance_cents,
            a.reserved_balance_cents,
            COALESCE(SUM(CASE WHEN jl.direction = 'DEBIT' THEN jl.amount_cents ELSE 0 END), 0)::BIGINT AS debits,
            COALESCE(SUM(CASE WHEN jl.direction = 'CREDIT' THEN jl.amount_cents ELSE 0 END), 0)::BIGINT AS credits
        FROM accounts a
        LEFT JOIN journal_lines jl ON jl.account_id = a.id
        GROUP BY a.id
        "#,
    )
    .fetch_all(&mut *tx)
    .await
    .map_err(|e| DomainError::Storage(e.to_string()))?;

    let mut total_issued_cents: i64 = 0;
    let mut total_retired_cents: i64 = 0;
    let mut sum_wallet_posted_cents: i64 = 0;
    let mut sum_wallet_reserved_cents: i64 = 0;
    let mut balance_mismatches_count: i64 = 0;
    let mut mismatch_details = Vec::new();

    for row in acct_rows {
        let acct_id: Uuid = row.get("id");
        let class = AccountClass::from_str(&row.get::<String, _>("account_class"))?;
        let normal_balance = EntryDirection::from_str(&row.get::<String, _>("normal_balance"))?;
        let cached_posted: i64 = row.get("posted_balance_cents");
        let cached_reserved: i64 = row.get("reserved_balance_cents");
        let debits: i64 = row.get("debits");
        let credits: i64 = row.get("credits");

        let derived_posted = match normal_balance {
            EntryDirection::Credit => credits - debits,
            EntryDirection::Debit => debits - credits,
        };
        let derived_reserved =
            compute_authoritative_reserved_balance_in_tx(&mut tx, AccountId::from_uuid(acct_id))
                .await?;

        if cached_posted != derived_posted || cached_reserved != derived_reserved {
            balance_mismatches_count += 1;
            mismatch_details.push(serde_json::json!({
                "account_id": acct_id,
                "cached_posted": cached_posted,
                "derived_posted": derived_posted,
                "cached_reserved": cached_reserved,
                "derived_reserved": derived_reserved,
            }));
        }

        match class {
            AccountClass::IssuanceControl => {
                // Issuance debits ISSUANCE_CONTROL (normal DEBIT => positive = total issued).
                total_issued_cents += derived_posted;
            }
            AccountClass::RetirementControl => {
                // Redemption credits RETIREMENT_CONTROL (normal DEBIT => negative = -total retired).
                total_retired_cents += -derived_posted;
            }
            _ if class.is_circulating_liability() => {
                sum_wallet_posted_cents += derived_posted;
                sum_wallet_reserved_cents += derived_reserved;
            }
            _ => {}
        }
    }

    let outstanding_supply_cents = total_issued_cents - total_retired_cents;
    let supply_conserved = outstanding_supply_cents == sum_wallet_posted_cents;
    let is_healthy =
        unbalanced_journals_count == 0 && balance_mismatches_count == 0 && supply_conserved;

    let run_id = Uuid::now_v7();
    let report_json = serde_json::json!({
        "supply_conserved": supply_conserved,
        "mismatch_details": mismatch_details,
    });

    let inserted = sqlx::query(
        r#"
        INSERT INTO reconciliation_runs (
            id, run_type, total_issued_cents, total_retired_cents,
            outstanding_supply_cents, sum_wallet_posted_cents, sum_wallet_reserved_cents,
            unbalanced_journals_count, balance_mismatches_count, is_healthy, report_json
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
        RETURNING created_at
        "#,
    )
    .bind(run_id)
    .bind(run_type)
    .bind(total_issued_cents)
    .bind(total_retired_cents)
    .bind(outstanding_supply_cents)
    .bind(sum_wallet_posted_cents)
    .bind(sum_wallet_reserved_cents)
    .bind(unbalanced_journals_count)
    .bind(balance_mismatches_count)
    .bind(is_healthy)
    .bind(report_json)
    .fetch_one(&mut *tx)
    .await
    .map_err(|e| DomainError::Storage(e.to_string()))?;

    tx.commit().await.map_err(|e| DomainError::Storage(e.to_string()))?;

    Ok(ReconciliationReport {
        run_id,
        total_issued_cents,
        total_retired_cents,
        outstanding_supply_cents,
        sum_wallet_posted_cents,
        sum_wallet_reserved_cents,
        unbalanced_journals_count,
        balance_mismatches_count,
        is_healthy,
        checked_at: inserted.get("created_at"),
    })
}
