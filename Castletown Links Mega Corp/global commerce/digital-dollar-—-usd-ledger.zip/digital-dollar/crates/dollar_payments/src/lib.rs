use chrono::{DateTime, Duration, Utc};
use dollar_auth::{record_audit_event, AuthContext, RedactedSecret};
use dollar_ledger::{
    authorize_account_read, authorize_account_spend, check_idempotency_in_tx,
    compute_authoritative_posted_balance_in_tx, compute_authoritative_reserved_balance_in_tx,
    create_reservation_in_tx, post_journal_in_tx, release_reservation_in_tx,
    store_idempotency_in_tx, JournalEntryType, OutboxProposal, PostJournalRequest,
    ProposedJournalLine, ISSUANCE_CONTROL_ACCOUNT_UUID, ISSUER_TREASURY_ACCOUNT_UUID,
    RETIREMENT_CONTROL_ACCOUNT_UUID,
};
use dollar_types::{
    AccountClass, AccountId, ConversionId, CorrelationId, Currency, DomainError, EntryDirection,
    IdempotencyKey, JournalId, Money, PaymentId, PaymentRequestId, PrincipalId, RefundId,
    ReservationId, Role, ScheduledPaymentId, TransactionId, WalletStatus,
};
use hmac::{Hmac, Mac};
use serde::{Deserialize, Serialize};
use sha2::Sha256;
use sqlx::{PgPool, Postgres, Row, Transaction};
use std::str::FromStr;
use subtle::ConstantTimeEq;
use utoipa::ToSchema;
use uuid::Uuid;

type HmacSha256 = Hmac<Sha256>;

// ============================================================================
// 1. Transfers
// ============================================================================

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct TransferPreviewRequest {
    pub source_account_id: AccountId,
    pub destination_account_id: AccountId,
    pub amount_cents: i64,
    pub currency: Currency,
    pub reference: String,
    pub expires_in_secs: Option<i64>,
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct TransferPreviewResponse {
    pub source_account_id: AccountId,
    pub destination_account_id: AccountId,
    pub amount_cents: i64,
    pub currency: Currency,
    pub fee_cents: i64,
    pub source_available_before_cents: i64,
    pub source_available_after_cents: i64,
    pub expires_at: DateTime<Utc>,
    pub reference: String,
    pub executable: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct SubmitTransferRequest {
    pub source_account_id: AccountId,
    pub destination_account_id: AccountId,
    pub amount_cents: i64,
    pub currency: Currency,
    pub reference: String,
    pub expires_at: Option<DateTime<Utc>>,
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct TransferRecord {
    pub id: TransactionId,
    pub source_account_id: AccountId,
    pub destination_account_id: AccountId,
    pub amount_cents: i64,
    pub currency: Currency,
    pub reference: String,
    pub expires_at: DateTime<Utc>,
    pub status: String,
    pub authorised_by: PrincipalId,
    pub journal_id: Option<JournalId>,
    pub failure_code: Option<String>,
    pub failure_reason: Option<String>,
    pub created_at: DateTime<Utc>,
    pub posted_at: Option<DateTime<Utc>>,
}

fn authorize_transfer_source(
    ctx: &AuthContext,
    source_id: AccountId,
    source_owner: PrincipalId,
    source_class: AccountClass,
) -> Result<(), DomainError> {
    if source_id.as_uuid() == ISSUER_TREASURY_ACCOUNT_UUID
        || source_class == AccountClass::IssuerTreasury
    {
        if matches!(ctx.role, Role::IssuerOperator | Role::SystemAdmin) {
            return Ok(());
        }
        return Err(DomainError::Forbidden(
            "Only IssuerOperator or SystemAdmin may disburse from ISSUER_TREASURY".to_string(),
        ));
    }
    authorize_account_spend(ctx, source_owner)
}

pub async fn preview_transfer(
    pool: &PgPool,
    ctx: &AuthContext,
    req: &TransferPreviewRequest,
) -> Result<TransferPreviewResponse, DomainError> {
    if req.source_account_id == req.destination_account_id {
        return Err(DomainError::SelfTransferForbidden(req.source_account_id));
    }
    let money = Money::from_positive_cents(req.amount_cents, req.currency)?;
    if req.reference.trim().is_empty() {
        return Err(DomainError::Validation(
            "Transfer reference must not be empty".to_string(),
        ));
    }

    let mut tx = pool.begin().await.map_err(|e| DomainError::Storage(e.to_string()))?;

    let src_row = sqlx::query(
        "SELECT owner_principal_id, account_class, normal_balance, status FROM accounts WHERE id = $1",
    )
    .bind(req.source_account_id.as_uuid())
    .fetch_optional(&mut *tx)
    .await
    .map_err(|e| DomainError::Storage(e.to_string()))?
    .ok_or_else(|| DomainError::NotFound(format!("Source account {}", req.source_account_id)))?;

    let src_owner = PrincipalId::from_uuid(src_row.get("owner_principal_id"));
    let src_class = AccountClass::from_str(&src_row.get::<String, _>("account_class"))?;
    let src_norm = EntryDirection::from_str(&src_row.get::<String, _>("normal_balance"))?;
    let src_status = WalletStatus::from_str(&src_row.get::<String, _>("status"))?;

    authorize_transfer_source(ctx, req.source_account_id, src_owner, src_class)?;
    if src_status != WalletStatus::Active {
        return Err(DomainError::AccountNotActive(
            req.source_account_id,
            src_status.as_str().to_string(),
        ));
    }

    let dst_row = sqlx::query("SELECT status FROM accounts WHERE id = $1")
        .bind(req.destination_account_id.as_uuid())
        .fetch_optional(&mut *tx)
        .await
        .map_err(|e| DomainError::Storage(e.to_string()))?
        .ok_or_else(|| {
            DomainError::NotFound(format!("Destination account {}", req.destination_account_id))
        })?;
    let dst_status = WalletStatus::from_str(&dst_row.get::<String, _>("status"))?;
    if dst_status != WalletStatus::Active {
        return Err(DomainError::AccountNotActive(
            req.destination_account_id,
            dst_status.as_str().to_string(),
        ));
    }

    let posted =
        compute_authoritative_posted_balance_in_tx(&mut tx, req.source_account_id, src_norm)
            .await?;
    let reserved =
        compute_authoritative_reserved_balance_in_tx(&mut tx, req.source_account_id).await?;
    let available = posted - reserved;
    let executable = available >= money.cents();

    tx.commit().await.map_err(|e| DomainError::Storage(e.to_string()))?;

    let ttl = req.expires_in_secs.unwrap_or(300).clamp(10, 86_400);
    Ok(TransferPreviewResponse {
        source_account_id: req.source_account_id,
        destination_account_id: req.destination_account_id,
        amount_cents: money.cents(),
        currency: Currency::Usd,
        fee_cents: 0,
        source_available_before_cents: available,
        source_available_after_cents: available - money.cents(),
        expires_at: Utc::now() + Duration::seconds(ttl),
        reference: req.reference.trim().to_string(),
        executable,
    })
}

pub async fn submit_transfer(
    pool: &PgPool,
    ctx: &AuthContext,
    idempotency_key: &IdempotencyKey,
    req: &SubmitTransferRequest,
    correlation_id: CorrelationId,
) -> Result<(u16, TransferRecord), DomainError> {
    if req.source_account_id == req.destination_account_id {
        return Err(DomainError::SelfTransferForbidden(req.source_account_id));
    }
    let money = Money::from_positive_cents(req.amount_cents, req.currency)?;
    if req.reference.trim().is_empty() {
        return Err(DomainError::Validation(
            "Transfer reference is required".to_string(),
        ));
    }

    let expires_at = req.expires_at.unwrap_or_else(|| Utc::now() + Duration::minutes(15));
    if expires_at <= Utc::now() {
        return Err(DomainError::Expired(
            "Transfer instruction is already expired".to_string(),
        ));
    }

    let payload_bytes = serde_json::to_vec(req).map_err(|e| DomainError::Storage(e.to_string()))?;
    let mut tx = pool.begin().await.map_err(|e| DomainError::Storage(e.to_string()))?;

    if let Some((status, body)) = check_idempotency_in_tx(
        &mut tx,
        ctx.principal_id,
        "POST /v1/transfers",
        idempotency_key,
        &payload_bytes,
    )
    .await?
    {
        let rec: TransferRecord =
            serde_json::from_value(body).map_err(|e| DomainError::Storage(e.to_string()))?;
        tx.commit().await.map_err(|e| DomainError::Storage(e.to_string()))?;
        return Ok((status, rec));
    }

    let rec = execute_transfer_in_tx(
        &mut tx,
        ctx,
        idempotency_key,
        req.source_account_id,
        req.destination_account_id,
        money,
        req.reference.trim(),
        expires_at,
        correlation_id,
    )
    .await?;

    let body_json = serde_json::to_value(&rec).map_err(|e| DomainError::Storage(e.to_string()))?;
    store_idempotency_in_tx(
        &mut tx,
        ctx.principal_id,
        "POST /v1/transfers",
        idempotency_key,
        &payload_bytes,
        201,
        &body_json,
        Some(rec.id.as_uuid()),
    )
    .await?;

    tx.commit().await.map_err(|e| DomainError::Storage(e.to_string()))?;
    Ok((201, rec))
}

#[allow(clippy::too_many_arguments)]
async fn execute_transfer_in_tx(
    tx: &mut Transaction<'_, Postgres>,
    ctx: &AuthContext,
    idempotency_key: &IdempotencyKey,
    source_account_id: AccountId,
    destination_account_id: AccountId,
    money: Money,
    reference: &str,
    expires_at: DateTime<Utc>,
    correlation_id: CorrelationId,
) -> Result<TransferRecord, DomainError> {
    let src_row = sqlx::query(
        "SELECT owner_principal_id, account_class FROM accounts WHERE id = $1",
    )
    .bind(source_account_id.as_uuid())
    .fetch_optional(&mut **tx)
    .await
    .map_err(|e| DomainError::Storage(e.to_string()))?
    .ok_or_else(|| DomainError::NotFound(format!("Source account {source_account_id}")))?;

    let src_owner = PrincipalId::from_uuid(src_row.get("owner_principal_id"));
    let src_class = AccountClass::from_str(&src_row.get::<String, _>("account_class"))?;
    authorize_transfer_source(ctx, source_account_id, src_owner, src_class)?;

    let entry_type = if src_class == AccountClass::IssuerTreasury {
        JournalEntryType::TreasuryDistribution
    } else {
        JournalEntryType::Transfer
    };

    let transfer_id = TransactionId::new();
    let journal_id = post_journal_in_tx(
        tx,
        PostJournalRequest {
            entry_type,
            transaction_ref: format!("TRANSFER:{transfer_id}"),
            correlation_id,
            reversal_of_journal_id: None,
            created_by: ctx.principal_id,
            description_code: if entry_type == JournalEntryType::TreasuryDistribution {
                "TREASURY_FUNDING".to_string()
            } else {
                "P2P_TRANSFER".to_string()
            },
            lines: vec![
                ProposedJournalLine {
                    account_id: source_account_id,
                    direction: EntryDirection::Debit,
                    amount: money,
                },
                ProposedJournalLine {
                    account_id: destination_account_id,
                    direction: EntryDirection::Credit,
                    amount: money,
                },
            ],
            consume_reservation_id: None,
            outbox_event: Some(OutboxProposal {
                aggregate_type: "TRANSFER".to_string(),
                aggregate_id: transfer_id.as_uuid(),
                event_type: "TransferPosted".to_string(),
                payload: serde_json::json!({
                    "transfer_id": transfer_id,
                    "source_account_id": source_account_id,
                    "destination_account_id": destination_account_id,
                    "amount_cents": money.cents(),
                }),
            }),
        },
    )
    .await?;

    let now = Utc::now();
    let row = sqlx::query(
        r#"
        INSERT INTO transfer_instructions (
            id, idempotency_key, source_account_id, destination_account_id,
            amount_cents, currency, reference, expires_at, status,
            authorised_by, journal_id, posted_at
        ) VALUES ($1, $2, $3, $4, $5, 'USD', $6, $7, 'POSTED', $8, $9, $10)
        RETURNING created_at
        "#,
    )
    .bind(transfer_id.as_uuid())
    .bind(idempotency_key.as_str())
    .bind(source_account_id.as_uuid())
    .bind(destination_account_id.as_uuid())
    .bind(money.cents())
    .bind(reference)
    .bind(expires_at)
    .bind(ctx.principal_id.as_uuid())
    .bind(journal_id.as_uuid())
    .bind(now)
    .fetch_one(&mut **tx)
    .await
    .map_err(|e| DomainError::Storage(e.to_string()))?;

    record_audit_event(
        tx,
        Some(ctx.principal_id),
        ctx.role.as_str(),
        "TRANSFER_POSTED",
        "TRANSFER",
        &transfer_id.to_string(),
        correlation_id,
        "SUCCESS",
        serde_json::json!({
            "source_account_id": source_account_id,
            "destination_account_id": destination_account_id,
            "amount_cents": money.cents(),
            "journal_id": journal_id,
        }),
    )
    .await?;

    Ok(TransferRecord {
        id: transfer_id,
        source_account_id,
        destination_account_id,
        amount_cents: money.cents(),
        currency: Currency::Usd,
        reference: reference.to_string(),
        expires_at,
        status: "POSTED".to_string(),
        authorised_by: ctx.principal_id,
        journal_id: Some(journal_id),
        failure_code: None,
        failure_reason: None,
        created_at: row.get("created_at"),
        posted_at: Some(now),
    })
}

pub async fn get_transfer(
    pool: &PgPool,
    ctx: &AuthContext,
    transfer_id: TransactionId,
) -> Result<TransferRecord, DomainError> {
    let row = sqlx::query(
        r#"
        SELECT
            t.id, t.source_account_id, t.destination_account_id, t.amount_cents,
            t.reference, t.expires_at, t.status, t.authorised_by, t.journal_id,
            t.failure_code, t.failure_reason, t.created_at, t.posted_at,
            sa.owner_principal_id AS src_owner, da.owner_principal_id AS dst_owner
        FROM transfer_instructions t
        JOIN accounts sa ON sa.id = t.source_account_id
        JOIN accounts da ON da.id = t.destination_account_id
        WHERE t.id = $1
        "#,
    )
    .bind(transfer_id.as_uuid())
    .fetch_optional(pool)
    .await
    .map_err(|e| DomainError::Storage(e.to_string()))?
    .ok_or_else(|| DomainError::NotFound(format!("Transfer {transfer_id}")))?;

    let src_owner = PrincipalId::from_uuid(row.get("src_owner"));
    let dst_owner = PrincipalId::from_uuid(row.get("dst_owner"));
    if ctx.principal_id != src_owner
        && ctx.principal_id != dst_owner
        && !matches!(
            ctx.role,
            Role::Auditor | Role::FraudReviewer | Role::SystemAdmin | Role::IssuerOperator
        )
    {
        return Err(DomainError::Forbidden(
            "Caller does not have access to this transfer".to_string(),
        ));
    }

    Ok(TransferRecord {
        id: TransferRecord::parse_id(row.get("id")),
        source_account_id: AccountId::from_uuid(row.get("source_account_id")),
        destination_account_id: AccountId::from_uuid(row.get("destination_account_id")),
        amount_cents: row.get("amount_cents"),
        currency: Currency::Usd,
        reference: row.get("reference"),
        expires_at: row.get("expires_at"),
        status: row.get("status"),
        authorised_by: PrincipalId::from_uuid(row.get("authorised_by")),
        journal_id: row
            .get::<Option<Uuid>, _>("journal_id")
            .map(JournalId::from_uuid),
        failure_code: row.get("failure_code"),
        failure_reason: row.get("failure_reason"),
        created_at: row.get("created_at"),
        posted_at: row.get("posted_at"),
    })
}

impl TransferRecord {
    fn parse_id(id: Uuid) -> TransactionId {
        TransactionId::from_uuid(id)
    }
}

// ============================================================================
// 2. Merchant Payment Requests, Payments & Cumulative Refunds
// ============================================================================

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, ToSchema)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum PaymentRequestPolicy {
    SingleUse,
    Reusable,
}

impl PaymentRequestPolicy {
    pub fn as_str(self) -> &'static str {
        match self {
            PaymentRequestPolicy::SingleUse => "SINGLE_USE",
            PaymentRequestPolicy::Reusable => "REUSABLE",
        }
    }
}

impl FromStr for PaymentRequestPolicy {
    type Err = DomainError;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        match s {
            "SINGLE_USE" => Ok(PaymentRequestPolicy::SingleUse),
            "REUSABLE" => Ok(PaymentRequestPolicy::Reusable),
            other => Err(DomainError::Validation(format!(
                "Unknown payment request policy: {other}"
            ))),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct CreatePaymentRequestInput {
    pub merchant_account_id: AccountId,
    pub order_reference: String,
    pub amount_cents: i64,
    pub currency: Currency,
    pub policy: PaymentRequestPolicy,
    pub expires_in_secs: Option<i64>,
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct PaymentRequestRecord {
    pub id: PaymentRequestId,
    pub merchant_account_id: AccountId,
    pub order_reference: String,
    pub amount_cents: i64,
    pub currency: Currency,
    pub policy: PaymentRequestPolicy,
    pub expires_at: DateTime<Utc>,
    pub status: String,
    pub signature_hmac: String,
    pub settlement_note: String,
    pub created_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct PayPaymentRequestInput {
    pub payer_account_id: AccountId,
    pub signature_hmac: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct PaymentRecord {
    pub id: PaymentId,
    pub payment_request_id: PaymentRequestId,
    pub payer_account_id: AccountId,
    pub merchant_account_id: AccountId,
    pub amount_cents: i64,
    pub refunded_cents: i64,
    pub currency: Currency,
    pub journal_id: JournalId,
    pub status: String,
    pub created_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct CreateRefundInput {
    pub amount_cents: i64,
    pub currency: Currency,
    pub reason_reference: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct RefundRecord {
    pub id: RefundId,
    pub payment_id: PaymentId,
    pub amount_cents: i64,
    pub currency: Currency,
    pub reason_reference: String,
    pub journal_id: JournalId,
    pub created_at: DateTime<Utc>,
}

#[derive(Clone)]
pub struct PaymentRequestSigner {
    secret: RedactedSecret,
}

impl PaymentRequestSigner {
    pub fn new(secret: impl Into<String>) -> Result<Self, DomainError> {
        let s = secret.into();
        if s.len() < 16 {
            return Err(DomainError::Validation(
                "Payment request HMAC secret must be at least 16 bytes".to_string(),
            ));
        }
        Ok(Self {
            secret: RedactedSecret::new(s),
        })
    }

    pub fn sign(
        &self,
        id: PaymentRequestId,
        merchant_account_id: AccountId,
        order_reference: &str,
        amount_cents: i64,
        policy: PaymentRequestPolicy,
        expires_at: DateTime<Utc>,
    ) -> Result<String, DomainError> {
        let canonical = format!(
            "{id}|{merchant_account_id}|{order_reference}|{amount_cents}|USD|{}|{}",
            policy.as_str(),
            expires_at.timestamp()
        );
        let mut mac = HmacSha256::new_from_slice(self.secret.expose().as_bytes())
            .map_err(|e| DomainError::Storage(e.to_string()))?;
        mac.update(canonical.as_bytes());
        Ok(hex::encode(mac.finalize().into_bytes()))
    }

    pub fn verify(
        &self,
        id: PaymentRequestId,
        merchant_account_id: AccountId,
        order_reference: &str,
        amount_cents: i64,
        policy: PaymentRequestPolicy,
        expires_at: DateTime<Utc>,
        provided_hex: &str,
    ) -> Result<(), DomainError> {
        let expected_hex = self.sign(
            id,
            merchant_account_id,
            order_reference,
            amount_cents,
            policy,
            expires_at,
        )?;
        let expected_bytes =
            hex::decode(expected_hex).map_err(|_| DomainError::InvalidSignature)?;
        let provided_bytes =
            hex::decode(provided_hex.trim()).map_err(|_| DomainError::InvalidSignature)?;
        if expected_bytes.ct_eq(&provided_bytes).unwrap_u8() != 1 {
            return Err(DomainError::InvalidSignature);
        }
        Ok(())
    }
}

pub async fn create_payment_request(
    pool: &PgPool,
    ctx: &AuthContext,
    signer: &PaymentRequestSigner,
    idempotency_key: &IdempotencyKey,
    req: &CreatePaymentRequestInput,
    correlation_id: CorrelationId,
) -> Result<(u16, PaymentRequestRecord), DomainError> {
    let money = Money::from_positive_cents(req.amount_cents, req.currency)?;
    if req.order_reference.trim().is_empty() {
        return Err(DomainError::Validation(
            "order_reference is required".to_string(),
        ));
    }

    let payload_bytes = serde_json::to_vec(req).map_err(|e| DomainError::Storage(e.to_string()))?;
    let mut tx = pool.begin().await.map_err(|e| DomainError::Storage(e.to_string()))?;

    if let Some((status, body)) = check_idempotency_in_tx(
        &mut tx,
        ctx.principal_id,
        "POST /v1/payment-requests",
        idempotency_key,
        &payload_bytes,
    )
    .await?
    {
        let rec: PaymentRequestRecord =
            serde_json::from_value(body).map_err(|e| DomainError::Storage(e.to_string()))?;
        tx.commit().await.map_err(|e| DomainError::Storage(e.to_string()))?;
        return Ok((status, rec));
    }

    let acct_row = sqlx::query(
        "SELECT owner_principal_id, account_class, status FROM accounts WHERE id = $1",
    )
    .bind(req.merchant_account_id.as_uuid())
    .fetch_optional(&mut *tx)
    .await
    .map_err(|e| DomainError::Storage(e.to_string()))?
    .ok_or_else(|| {
        DomainError::NotFound(format!("Merchant account {}", req.merchant_account_id))
    })?;

    let owner = PrincipalId::from_uuid(acct_row.get("owner_principal_id"));
    let class = AccountClass::from_str(&acct_row.get::<String, _>("account_class"))?;
    let acct_status = WalletStatus::from_str(&acct_row.get::<String, _>("status"))?;

    if ctx.principal_id != owner && ctx.role != Role::SystemAdmin {
        return Err(DomainError::Forbidden(
            "Caller does not own this merchant wallet".to_string(),
        ));
    }
    if class != AccountClass::MerchantWallet {
        return Err(DomainError::Validation(
            "Destination account must be a MERCHANT_WALLET".to_string(),
        ));
    }
    if acct_status != WalletStatus::Active {
        return Err(DomainError::AccountNotActive(
            req.merchant_account_id,
            acct_status.as_str().to_string(),
        ));
    }

    let pr_id = PaymentRequestId::new();
    let ttl = req.expires_in_secs.unwrap_or(900).clamp(30, 86_400 * 7);
    let expires_at = DateTime::from_timestamp(Utc::now().timestamp() + ttl, 0)
        .unwrap_or_else(|| Utc::now() + Duration::seconds(ttl));

    let signature_hmac = signer.sign(
        pr_id,
        req.merchant_account_id,
        req.order_reference.trim(),
        money.cents(),
        req.policy,
        expires_at,
    )?;

    let row = sqlx::query(
        r#"
        INSERT INTO payment_requests (
            id, merchant_account_id, order_reference, amount_cents, currency,
            policy, expires_at, status, signature_hmac, created_by
        ) VALUES ($1, $2, $3, $4, 'USD', $5, $6, 'OPEN', $7, $8)
        RETURNING created_at
        "#,
    )
    .bind(pr_id.as_uuid())
    .bind(req.merchant_account_id.as_uuid())
    .bind(req.order_reference.trim())
    .bind(money.cents())
    .bind(req.policy.as_str())
    .bind(expires_at)
    .bind(&signature_hmac)
    .bind(ctx.principal_id.as_uuid())
    .fetch_one(&mut *tx)
    .await
    .map_err(|e| DomainError::Storage(e.to_string()))?;

    let record = PaymentRequestRecord {
        id: pr_id,
        merchant_account_id: req.merchant_account_id,
        order_reference: req.order_reference.trim().to_string(),
        amount_cents: money.cents(),
        currency: Currency::Usd,
        policy: req.policy,
        expires_at,
        status: "OPEN".to_string(),
        signature_hmac,
        settlement_note: "Payment request created; settlement occurs only upon committed ledger posting.".to_string(),
        created_at: row.get("created_at"),
    };

    record_audit_event(
        &mut tx,
        Some(ctx.principal_id),
        ctx.role.as_str(),
        "PAYMENT_REQUEST_CREATED",
        "PAYMENT_REQUEST",
        &pr_id.to_string(),
        correlation_id,
        "SUCCESS",
        serde_json::json!({
            "merchant_account_id": req.merchant_account_id,
            "amount_cents": money.cents(),
            "policy": req.policy.as_str(),
        }),
    )
    .await?;

    let body_json =
        serde_json::to_value(&record).map_err(|e| DomainError::Storage(e.to_string()))?;
    store_idempotency_in_tx(
        &mut tx,
        ctx.principal_id,
        "POST /v1/payment-requests",
        idempotency_key,
        &payload_bytes,
        201,
        &body_json,
        Some(pr_id.as_uuid()),
    )
    .await?;

    tx.commit().await.map_err(|e| DomainError::Storage(e.to_string()))?;
    Ok((201, record))
}

pub async fn pay_payment_request(
    pool: &PgPool,
    ctx: &AuthContext,
    signer: &PaymentRequestSigner,
    payment_request_id: PaymentRequestId,
    idempotency_key: &IdempotencyKey,
    req: &PayPaymentRequestInput,
    correlation_id: CorrelationId,
) -> Result<(u16, PaymentRecord), DomainError> {
    let endpoint = format!("POST /v1/payment-requests/{payment_request_id}/pay");
    let payload_bytes = serde_json::to_vec(req).map_err(|e| DomainError::Storage(e.to_string()))?;
    let mut tx = pool.begin().await.map_err(|e| DomainError::Storage(e.to_string()))?;

    if let Some((status, body)) = check_idempotency_in_tx(
        &mut tx,
        ctx.principal_id,
        &endpoint,
        idempotency_key,
        &payload_bytes,
    )
    .await?
    {
        let rec: PaymentRecord =
            serde_json::from_value(body).map_err(|e| DomainError::Storage(e.to_string()))?;
        tx.commit().await.map_err(|e| DomainError::Storage(e.to_string()))?;
        return Ok((status, rec));
    }

    let pr_row = sqlx::query(
        r#"
        SELECT merchant_account_id, order_reference, amount_cents, policy, expires_at, status, signature_hmac
        FROM payment_requests
        WHERE id = $1
        FOR UPDATE
        "#,
    )
    .bind(payment_request_id.as_uuid())
    .fetch_optional(&mut *tx)
    .await
    .map_err(|e| DomainError::Storage(e.to_string()))?
    .ok_or_else(|| DomainError::NotFound(format!("Payment request {payment_request_id}")))?;

    let merchant_account_id = AccountId::from_uuid(pr_row.get("merchant_account_id"));
    if req.payer_account_id == merchant_account_id {
        return Err(DomainError::SelfTransferForbidden(req.payer_account_id));
    }

    let order_reference: String = pr_row.get("order_reference");
    let amount_cents: i64 = pr_row.get("amount_cents");
    let policy = PaymentRequestPolicy::from_str(&pr_row.get::<String, _>("policy"))?;
    let expires_at: DateTime<Utc> = pr_row.get("expires_at");
    let status: String = pr_row.get("status");
    let stored_sig: String = pr_row.get("signature_hmac");

    // Verify signed request reference and stored HMAC.
    signer.verify(
        payment_request_id,
        merchant_account_id,
        &order_reference,
        amount_cents,
        policy,
        expires_at,
        &req.signature_hmac,
    )?;
    if stored_sig != req.signature_hmac.trim() {
        return Err(DomainError::InvalidSignature);
    }

    if Utc::now() > expires_at {
        sqlx::query("UPDATE payment_requests SET status = 'EXPIRED' WHERE id = $1")
            .bind(payment_request_id.as_uuid())
            .execute(&mut *tx)
            .await
            .map_err(|e| DomainError::Storage(e.to_string()))?;
        return Err(DomainError::Expired(format!(
            "Payment request {payment_request_id} expired"
        )));
    }

    if status != "OPEN" {
        return Err(DomainError::InvalidState(format!(
            "Payment request {payment_request_id} is {status}"
        )));
    }

    let payer_row = sqlx::query("SELECT owner_principal_id FROM accounts WHERE id = $1")
        .bind(req.payer_account_id.as_uuid())
        .fetch_optional(&mut *tx)
        .await
        .map_err(|e| DomainError::Storage(e.to_string()))?
        .ok_or_else(|| DomainError::NotFound(format!("Payer account {}", req.payer_account_id)))?;
    let payer_owner = PrincipalId::from_uuid(payer_row.get("owner_principal_id"));
    authorize_account_spend(ctx, payer_owner)?;

    let money = Money::from_positive_cents(amount_cents, Currency::Usd)?;
    let payment_id = PaymentId::new();

    let journal_id = post_journal_in_tx(
        &mut tx,
        PostJournalRequest {
            entry_type: JournalEntryType::MerchantPayment,
            transaction_ref: format!("PAYMENT:{payment_id}"),
            correlation_id,
            reversal_of_journal_id: None,
            created_by: ctx.principal_id,
            description_code: "MERCHANT_PAYMENT".to_string(),
            lines: vec![
                ProposedJournalLine {
                    account_id: req.payer_account_id,
                    direction: EntryDirection::Debit,
                    amount: money,
                },
                ProposedJournalLine {
                    account_id: merchant_account_id,
                    direction: EntryDirection::Credit,
                    amount: money,
                },
            ],
            consume_reservation_id: None,
            outbox_event: Some(OutboxProposal {
                aggregate_type: "PAYMENT".to_string(),
                aggregate_id: payment_id.as_uuid(),
                event_type: "MerchantPaymentSettled".to_string(),
                payload: serde_json::json!({
                    "payment_id": payment_id,
                    "payment_request_id": payment_request_id,
                    "payer_account_id": req.payer_account_id,
                    "merchant_account_id": merchant_account_id,
                    "amount_cents": amount_cents,
                    "order_reference": order_reference,
                }),
            }),
        },
    )
    .await?;

    let inserted = sqlx::query(
        r#"
        INSERT INTO payments (
            id, payment_request_id, idempotency_key, payer_account_id,
            merchant_account_id, amount_cents, refunded_cents, currency, journal_id, status
        ) VALUES ($1, $2, $3, $4, $5, $6, 0, 'USD', $7, 'SETTLED')
        RETURNING created_at
        "#,
    )
    .bind(payment_id.as_uuid())
    .bind(payment_request_id.as_uuid())
    .bind(idempotency_key.as_str())
    .bind(req.payer_account_id.as_uuid())
    .bind(merchant_account_id.as_uuid())
    .bind(amount_cents)
    .bind(journal_id.as_uuid())
    .fetch_one(&mut *tx)
    .await
    .map_err(|e| DomainError::Storage(e.to_string()))?;

    if policy == PaymentRequestPolicy::SingleUse {
        sqlx::query("UPDATE payment_requests SET status = 'PAID' WHERE id = $1")
            .bind(payment_request_id.as_uuid())
            .execute(&mut *tx)
            .await
            .map_err(|e| DomainError::Storage(e.to_string()))?;
    }

    let record = PaymentRecord {
        id: payment_id,
        payment_request_id,
        payer_account_id: req.payer_account_id,
        merchant_account_id,
        amount_cents,
        refunded_cents: 0,
        currency: Currency::Usd,
        journal_id,
        status: "SETTLED".to_string(),
        created_at: inserted.get("created_at"),
    };

    record_audit_event(
        &mut tx,
        Some(ctx.principal_id),
        ctx.role.as_str(),
        "MERCHANT_PAYMENT_SETTLED",
        "PAYMENT",
        &payment_id.to_string(),
        correlation_id,
        "SUCCESS",
        serde_json::json!({
            "payment_request_id": payment_request_id,
            "amount_cents": amount_cents,
            "journal_id": journal_id,
        }),
    )
    .await?;

    let body_json =
        serde_json::to_value(&record).map_err(|e| DomainError::Storage(e.to_string()))?;
    store_idempotency_in_tx(
        &mut tx,
        ctx.principal_id,
        &endpoint,
        idempotency_key,
        &payload_bytes,
        201,
        &body_json,
        Some(payment_id.as_uuid()),
    )
    .await?;

    tx.commit().await.map_err(|e| DomainError::Storage(e.to_string()))?;
    Ok((201, record))
}

pub async fn refund_payment(
    pool: &PgPool,
    ctx: &AuthContext,
    payment_id: PaymentId,
    idempotency_key: &IdempotencyKey,
    req: &CreateRefundInput,
    correlation_id: CorrelationId,
) -> Result<(u16, RefundRecord), DomainError> {
    let money = Money::from_positive_cents(req.amount_cents, req.currency)?;
    if req.reason_reference.trim().is_empty() {
        return Err(DomainError::Validation(
            "reason_reference is required for refund".to_string(),
        ));
    }

    let endpoint = format!("POST /v1/payments/{payment_id}/refunds");
    let payload_bytes = serde_json::to_vec(req).map_err(|e| DomainError::Storage(e.to_string()))?;
    let mut tx = pool.begin().await.map_err(|e| DomainError::Storage(e.to_string()))?;

    if let Some((status, body)) = check_idempotency_in_tx(
        &mut tx,
        ctx.principal_id,
        &endpoint,
        idempotency_key,
        &payload_bytes,
    )
    .await?
    {
        let rec: RefundRecord =
            serde_json::from_value(body).map_err(|e| DomainError::Storage(e.to_string()))?;
        tx.commit().await.map_err(|e| DomainError::Storage(e.to_string()))?;
        return Ok((status, rec));
    }

    let pay_row = sqlx::query(
        r#"
        SELECT
            p.payer_account_id, p.merchant_account_id, p.amount_cents,
            p.refunded_cents, p.journal_id, ma.owner_principal_id AS merchant_owner
        FROM payments p
        JOIN accounts ma ON ma.id = p.merchant_account_id
        WHERE p.id = $1
        FOR UPDATE OF p
        "#,
    )
    .bind(payment_id.as_uuid())
    .fetch_optional(&mut *tx)
    .await
    .map_err(|e| DomainError::Storage(e.to_string()))?
    .ok_or_else(|| DomainError::NotFound(format!("Payment {payment_id}")))?;

    let merchant_owner = PrincipalId::from_uuid(pay_row.get("merchant_owner"));
    if ctx.principal_id != merchant_owner && ctx.role != Role::SystemAdmin {
        return Err(DomainError::Forbidden(
            "Only the receiving merchant or SystemAdmin may initiate a refund".to_string(),
        ));
    }

    let payer_account_id = AccountId::from_uuid(pay_row.get("payer_account_id"));
    let merchant_account_id = AccountId::from_uuid(pay_row.get("merchant_account_id"));
    let original_amount: i64 = pay_row.get("amount_cents");
    let already_refunded: i64 = pay_row.get("refunded_cents");
    let original_journal_id = JournalId::from_uuid(pay_row.get("journal_id"));

    let remaining = original_amount - already_refunded;
    if money.cents() > remaining {
        return Err(DomainError::RefundLimitExceeded {
            remaining_cents: remaining,
            requested_cents: money.cents(),
        });
    }

    let refund_id = RefundId::new();
    let journal_id = post_journal_in_tx(
        &mut tx,
        PostJournalRequest {
            entry_type: JournalEntryType::PaymentRefund,
            transaction_ref: format!("REFUND:{refund_id}"),
            correlation_id,
            reversal_of_journal_id: Some(original_journal_id),
            created_by: ctx.principal_id,
            description_code: "MERCHANT_PAYMENT_REFUND".to_string(),
            lines: vec![
                ProposedJournalLine {
                    account_id: merchant_account_id,
                    direction: EntryDirection::Debit,
                    amount: money,
                },
                ProposedJournalLine {
                    account_id: payer_account_id,
                    direction: EntryDirection::Credit,
                    amount: money,
                },
            ],
            consume_reservation_id: None,
            outbox_event: Some(OutboxProposal {
                aggregate_type: "REFUND".to_string(),
                aggregate_id: refund_id.as_uuid(),
                event_type: "PaymentRefundPosted".to_string(),
                payload: serde_json::json!({
                    "refund_id": refund_id,
                    "payment_id": payment_id,
                    "amount_cents": money.cents(),
                    "reversal_of_journal_id": original_journal_id,
                }),
            }),
        },
    )
    .await?;

    let new_refunded = already_refunded + money.cents();
    let new_status = if new_refunded == original_amount {
        "FULLY_REFUNDED"
    } else {
        "PARTIALLY_REFUNDED"
    };

    sqlx::query("UPDATE payments SET refunded_cents = $2, status = $3 WHERE id = $1")
        .bind(payment_id.as_uuid())
        .bind(new_refunded)
        .bind(new_status)
        .execute(&mut *tx)
        .await
        .map_err(|e| DomainError::Storage(e.to_string()))?;

    let inserted = sqlx::query(
        r#"
        INSERT INTO refunds (
            id, payment_id, idempotency_key, amount_cents, currency,
            reason_reference, journal_id, created_by
        ) VALUES ($1, $2, $3, $4, 'USD', $5, $6, $7)
        RETURNING created_at
        "#,
    )
    .bind(refund_id.as_uuid())
    .bind(payment_id.as_uuid())
    .bind(idempotency_key.as_str())
    .bind(money.cents())
    .bind(req.reason_reference.trim())
    .bind(journal_id.as_uuid())
    .bind(ctx.principal_id.as_uuid())
    .fetch_one(&mut *tx)
    .await
    .map_err(|e| DomainError::Storage(e.to_string()))?;

    let record = RefundRecord {
        id: refund_id,
        payment_id,
        amount_cents: money.cents(),
        currency: Currency::Usd,
        reason_reference: req.reason_reference.trim().to_string(),
        journal_id,
        created_at: inserted.get("created_at"),
    };

    record_audit_event(
        &mut tx,
        Some(ctx.principal_id),
        ctx.role.as_str(),
        "PAYMENT_REFUND_POSTED",
        "REFUND",
        &refund_id.to_string(),
        correlation_id,
        "SUCCESS",
        serde_json::json!({
            "payment_id": payment_id,
            "amount_cents": money.cents(),
            "journal_id": journal_id,
            "reversal_of_journal_id": original_journal_id,
        }),
    )
    .await?;

    let body_json =
        serde_json::to_value(&record).map_err(|e| DomainError::Storage(e.to_string()))?;
    store_idempotency_in_tx(
        &mut tx,
        ctx.principal_id,
        &endpoint,
        idempotency_key,
        &payload_bytes,
        201,
        &body_json,
        Some(refund_id.as_uuid()),
    )
    .await?;

    tx.commit().await.map_err(|e| DomainError::Storage(e.to_string()))?;
    Ok((201, record))
}

// ============================================================================
// 3. Scheduled Payments (Instruction until execution succeeds)
// ============================================================================

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct SchedulePaymentInput {
    pub source_account_id: AccountId,
    pub destination_account_id: AccountId,
    pub amount_cents: i64,
    pub currency: Currency,
    pub reference: String,
    pub execute_after: DateTime<Utc>,
    pub max_retries: Option<i32>,
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct ScheduledPaymentRecord {
    pub id: ScheduledPaymentId,
    pub source_account_id: AccountId,
    pub destination_account_id: AccountId,
    pub amount_cents: i64,
    pub currency: Currency,
    pub reference: String,
    pub execute_after: DateTime<Utc>,
    pub status: String,
    pub attempt_count: i32,
    pub last_error: Option<String>,
    pub resulting_transfer_id: Option<TransactionId>,
}

pub async fn create_scheduled_payment(
    pool: &PgPool,
    ctx: &AuthContext,
    idempotency_key: &IdempotencyKey,
    req: &SchedulePaymentInput,
) -> Result<ScheduledPaymentRecord, DomainError> {
    if req.source_account_id == req.destination_account_id {
        return Err(DomainError::SelfTransferForbidden(req.source_account_id));
    }
    let money = Money::from_positive_cents(req.amount_cents, req.currency)?;

    let src_row = sqlx::query("SELECT owner_principal_id FROM accounts WHERE id = $1")
        .bind(req.source_account_id.as_uuid())
        .fetch_optional(pool)
        .await
        .map_err(|e| DomainError::Storage(e.to_string()))?
        .ok_or_else(|| DomainError::NotFound(format!("Account {}", req.source_account_id)))?;
    authorize_account_spend(ctx, PrincipalId::from_uuid(src_row.get("owner_principal_id")))?;

    let id = ScheduledPaymentId::new();
    let max_retries = req.max_retries.unwrap_or(2).clamp(0, 10);

    sqlx::query(
        r#"
        INSERT INTO scheduled_payments (
            id, idempotency_key, source_account_id, destination_account_id,
            amount_cents, currency, reference, execute_after, max_retries,
            status, created_by
        ) VALUES ($1, $2, $3, $4, $5, 'USD', $6, $7, $8, 'SCHEDULED', $9)
        "#,
    )
    .bind(id.as_uuid())
    .bind(idempotency_key.as_str())
    .bind(req.source_account_id.as_uuid())
    .bind(req.destination_account_id.as_uuid())
    .bind(money.cents())
    .bind(req.reference.trim())
    .bind(req.execute_after)
    .bind(max_retries)
    .bind(ctx.principal_id.as_uuid())
    .execute(pool)
    .await
    .map_err(|e| DomainError::Storage(e.to_string()))?;

    Ok(ScheduledPaymentRecord {
        id,
        source_account_id: req.source_account_id,
        destination_account_id: req.destination_account_id,
        amount_cents: money.cents(),
        currency: Currency::Usd,
        reference: req.reference.trim().to_string(),
        execute_after: req.execute_after,
        status: "SCHEDULED".to_string(),
        attempt_count: 0,
        last_error: None,
        resulting_transfer_id: None,
    })
}

/// Idempotent worker executing due scheduled payments. Rechecks funds, ownership, and account status.
pub async fn execute_due_scheduled_payments(pool: &PgPool) -> Result<u64, DomainError> {
    let mut tx = pool.begin().await.map_err(|e| DomainError::Storage(e.to_string()))?;
    let due_rows = sqlx::query(
        r#"
        SELECT
            sp.id, sp.idempotency_key, sp.source_account_id, sp.destination_account_id,
            sp.amount_cents, sp.reference, sp.attempt_count, sp.max_retries, sp.created_by,
            p.username, p.role
        FROM scheduled_payments sp
        JOIN principals p ON p.id = sp.created_by
        WHERE sp.status = 'SCHEDULED' AND sp.execute_after <= NOW()
        ORDER BY sp.execute_after ASC
        LIMIT 25
        FOR UPDATE OF sp SKIP LOCKED
        "#,
    )
    .fetch_all(&mut *tx)
    .await
    .map_err(|e| DomainError::Storage(e.to_string()))?;

    let mut processed = 0u64;
    for row in due_rows {
        let sp_id = ScheduledPaymentId::from_uuid(row.get("id"));
        let source_id = AccountId::from_uuid(row.get("source_account_id"));
        let dest_id = AccountId::from_uuid(row.get("destination_account_id"));
        let amount_cents: i64 = row.get("amount_cents");
        let reference: String = row.get("reference");
        let attempts: i32 = row.get("attempt_count");
        let max_retries: i32 = row.get("max_retries");
        let idem = IdempotencyKey::parse(&format!("sched-exec-{}", sp_id))?;
        let auth_ctx = AuthContext {
            session_id: Uuid::nil(),
            principal_id: PrincipalId::from_uuid(row.get("created_by")),
            username: row.get("username"),
            role: Role::from_str(&row.get::<String, _>("role"))?,
            expires_at: Utc::now() + Duration::minutes(5),
        };
        let money = Money::from_positive_cents(amount_cents, Currency::Usd)?;

        // Attempt execution inside a savepoint so individual failures don't abort the batch.
        sqlx::query("SAVEPOINT sp_exec")
            .execute(&mut *tx)
            .await
            .map_err(|e| DomainError::Storage(e.to_string()))?;

        let result = execute_transfer_in_tx(
            &mut tx,
            &auth_ctx,
            &idem,
            source_id,
            dest_id,
            money,
            &reference,
            Utc::now() + Duration::minutes(5),
            CorrelationId::new(),
        )
        .await;

        match result {
            Ok(transfer) => {
                sqlx::query("RELEASE SAVEPOINT sp_exec")
                    .execute(&mut *tx)
                    .await
                    .map_err(|e| DomainError::Storage(e.to_string()))?;
                sqlx::query(
                    r#"
                    UPDATE scheduled_payments
                    SET status = 'COMPLETED',
                        resulting_transfer_id = $2,
                        executed_at = NOW(),
                        attempt_count = attempt_count + 1
                    WHERE id = $1
                    "#,
                )
                .bind(sp_id.as_uuid())
                .bind(transfer.id.as_uuid())
                .execute(&mut *tx)
                .await
                .map_err(|e| DomainError::Storage(e.to_string()))?;
                processed += 1;
            }
            Err(err) => {
                sqlx::query("ROLLBACK TO SAVEPOINT sp_exec")
                    .execute(&mut *tx)
                    .await
                    .map_err(|e| DomainError::Storage(e.to_string()))?;
                let next_attempts = attempts + 1;
                let new_status = if next_attempts > max_retries {
                    "FAILED"
                } else {
                    "SCHEDULED"
                };
                sqlx::query(
                    r#"
                    UPDATE scheduled_payments
                    SET status = $2,
                        attempt_count = $3,
                        last_error = $4
                    WHERE id = $1
                    "#,
                )
                .bind(sp_id.as_uuid())
                .bind(new_status)
                .bind(next_attempts)
                .bind(err.to_string())
                .execute(&mut *tx)
                .await
                .map_err(|e| DomainError::Storage(e.to_string()))?;
            }
        }
    }

    tx.commit().await.map_err(|e| DomainError::Storage(e.to_string()))?;
    Ok(processed)
}

// ============================================================================
// 4. Redemption & Simulated Bank Conversion
// ============================================================================

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, ToSchema)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum ConversionDirection {
    DepositToDigital,
    RedeemToBank,
}

impl ConversionDirection {
    pub fn as_str(self) -> &'static str {
        match self {
            ConversionDirection::DepositToDigital => "DEPOSIT_TO_DIGITAL",
            ConversionDirection::RedeemToBank => "REDEEM_TO_BANK",
        }
    }
}

impl FromStr for ConversionDirection {
    type Err = DomainError;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        match s {
            "DEPOSIT_TO_DIGITAL" => Ok(ConversionDirection::DepositToDigital),
            "REDEEM_TO_BANK" => Ok(ConversionDirection::RedeemToBank),
            other => Err(DomainError::Validation(format!(
                "Unknown conversion direction: {other}"
            ))),
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, ToSchema)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum SimulatedBankOutcome {
    Settled,
    Failed,
    Pending,
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct CreateConversionRequest {
    pub direction: ConversionDirection,
    pub account_id: AccountId,
    pub amount_cents: i64,
    pub currency: Currency,
    /// Opaque tokenized external bank account reference (no raw PII/account numbers in ledger).
    pub bank_account_ref_token: String,
    /// Optional explicit simulation mode for deterministic testing (`SETTLED` | `FAILED` | `DELAYED`).
    pub simulate_outcome: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct ConversionRecord {
    pub id: ConversionId,
    pub direction: ConversionDirection,
    pub account_id: AccountId,
    pub amount_cents: i64,
    pub currency: Currency,
    pub bank_account_ref_token: String,
    pub status: String,
    pub reservation_id: Option<ReservationId>,
    pub journal_id: Option<JournalId>,
    pub external_reference: Option<String>,
    pub failure_reason: Option<String>,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
}

#[derive(Debug, Clone)]
pub struct SimulatedBankAdapter {
    pub default_mode: String,
}

impl SimulatedBankAdapter {
    pub fn new(default_mode: String) -> Self {
        Self { default_mode }
    }

    pub fn submit_payout_or_deposit(
        &self,
        conversion_id: ConversionId,
        direction: ConversionDirection,
        amount_cents: i64,
        simulate_override: Option<&str>,
    ) -> (String, SimulatedBankOutcome, Option<String>) {
        let mode = simulate_override
            .unwrap_or(&self.default_mode)
            .to_ascii_uppercase();
        let ext_ref = format!("SIMBANK-{}-{}", direction.as_str(), conversion_id);

        match mode.as_str() {
            "FAILED" | "FAIL_NEXT" => (
                ext_ref,
                SimulatedBankOutcome::Failed,
                Some("Simulated bank rail rejected payout (NSF/account-closed)".to_string()),
            ),
            "DELAYED" | "UNCERTAIN" | "PENDING" => (
                ext_ref,
                SimulatedBankOutcome::Pending,
                Some("Simulated bank rail response delayed; awaiting settlement evidence".to_string()),
            ),
            _ => (
                format!("{ext_ref}-AMT{amount_cents}"),
                SimulatedBankOutcome::Settled,
                None,
            ),
        }
    }
}

/// Initiates a simulated bank conversion (`DEPOSIT_TO_DIGITAL` or `REDEEM_TO_BANK`).
///
/// Protocol for Redemption (`REDEEM_TO_BANK`):
/// 1. Request: Validates ownership & available funds and creates a `Reservation` so the funds
///    cannot be double-spent while external processing runs. Posted balance is NOT debited yet.
/// 2. External Processing: Submits simulated payout to mock bank adapter outside the lock window.
/// 3. Evidence Received -> Ledger Posting -> Reconciliation:
///    - If bank evidence confirms `SETTLED`: atomically consumes reservation and posts
///      `REDEMPTION_RETIREMENT` (`DEBIT customer`, `CREDIT RETIREMENT_CONTROL`).
///    - If bank evidence reports `FAILED`: atomically releases reservation (`FAILED_RELEASED`)
///      so the customer's digital-dollar claim is completely preserved.
///    - If outcome is `PENDING`/`UNCERTAIN`: holds reservation in `UNCERTAIN_HOLD` for
///      background recovery polling (`recover_pending_conversions`).
pub async fn create_conversion(
    pool: &PgPool,
    ctx: &AuthContext,
    adapter: &SimulatedBankAdapter,
    idempotency_key: &IdempotencyKey,
    req: &CreateConversionRequest,
    correlation_id: CorrelationId,
) -> Result<(u16, ConversionRecord), DomainError> {
    let money = Money::from_positive_cents(req.amount_cents, req.currency)?;
    if req.bank_account_ref_token.trim().is_empty() {
        return Err(DomainError::Validation(
            "bank_account_ref_token is required".to_string(),
        ));
    }

    let payload_bytes = serde_json::to_vec(req).map_err(|e| DomainError::Storage(e.to_string()))?;

    // Phase 1: Idempotency check + Request + Reservation (for redemptions)
    let mut tx = pool.begin().await.map_err(|e| DomainError::Storage(e.to_string()))?;
    if let Some((status, body)) = check_idempotency_in_tx(
        &mut tx,
        ctx.principal_id,
        "POST /v1/conversions",
        idempotency_key,
        &payload_bytes,
    )
    .await?
    {
        let rec: ConversionRecord =
            serde_json::from_value(body).map_err(|e| DomainError::Storage(e.to_string()))?;
        tx.commit().await.map_err(|e| DomainError::Storage(e.to_string()))?;
        return Ok((status, rec));
    }

    let acct_row = sqlx::query("SELECT owner_principal_id, status FROM accounts WHERE id = $1")
        .bind(req.account_id.as_uuid())
        .fetch_optional(&mut *tx)
        .await
        .map_err(|e| DomainError::Storage(e.to_string()))?
        .ok_or_else(|| DomainError::NotFound(format!("Account {}", req.account_id)))?;

    let owner_id = PrincipalId::from_uuid(acct_row.get("owner_principal_id"));
    let acct_status = WalletStatus::from_str(&acct_row.get::<String, _>("status"))?;
    if req.direction == ConversionDirection::RedeemToBank {
        authorize_account_spend(ctx, owner_id)?;
    } else if ctx.principal_id != owner_id && ctx.role != Role::SystemAdmin {
        return Err(DomainError::Forbidden(
            "Caller cannot initiate deposit conversion for another principal".to_string(),
        ));
    }
    if acct_status != WalletStatus::Active {
        return Err(DomainError::AccountNotActive(
            req.account_id,
            acct_status.as_str().to_string(),
        ));
    }

    let conv_id = ConversionId::new();
    let reservation_id = if req.direction == ConversionDirection::RedeemToBank {
        let res = create_reservation_in_tx(
            &mut tx,
            req.account_id,
            money,
            "REDEMPTION_HOLD",
            conv_id.as_uuid(),
            Utc::now() + Duration::hours(24),
        )
        .await?;
        Some(res.id)
    } else {
        None
    };

    let inserted = sqlx::query(
        r#"
        INSERT INTO conversion_requests (
            id, idempotency_key, direction, account_id, amount_cents, currency,
            bank_account_ref_token, status, reservation_id, created_by
        ) VALUES ($1, $2, $3, $4, $5, 'USD', $6, 'EXTERNAL_PROCESSING', $7, $8)
        RETURNING created_at
        "#,
    )
    .bind(conv_id.as_uuid())
    .bind(idempotency_key.as_str())
    .bind(req.direction.as_str())
    .bind(req.account_id.as_uuid())
    .bind(money.cents())
    .bind(req.bank_account_ref_token.trim())
    .bind(reservation_id.map(|r| r.as_uuid()))
    .bind(ctx.principal_id.as_uuid())
    .fetch_one(&mut *tx)
    .await
    .map_err(|e| DomainError::Storage(e.to_string()))?;

    let created_at: DateTime<Utc> = inserted.get("created_at");
    tx.commit().await.map_err(|e| DomainError::Storage(e.to_string()))?;

    // Phase 2: Simulated External Bank Processing (outside DB lock)
    let (ext_ref, outcome, fail_msg) = adapter.submit_payout_or_deposit(
        conv_id,
        req.direction,
        money.cents(),
        req.simulate_outcome.as_deref(),
    );

    // Phase 3: Apply evidence + ledger posting or safe reservation release
    let final_record = apply_conversion_evidence(
        pool,
        ctx.principal_id,
        ctx.role.as_str(),
        conv_id,
        req.direction,
        req.account_id,
        money,
        req.bank_account_ref_token.trim(),
        reservation_id,
        &ext_ref,
        outcome,
        fail_msg.as_deref(),
        created_at,
        correlation_id,
    )
    .await?;

    // Persist idempotency response cleanly so client retries replay the settled/released outcome.
    let mut tx_idem = pool.begin().await.map_err(|e| DomainError::Storage(e.to_string()))?;
    let body_json =
        serde_json::to_value(&final_record).map_err(|e| DomainError::Storage(e.to_string()))?;
    let _ = sqlx::query(
        r#"
        INSERT INTO idempotency_records (
            principal_id, endpoint, idempotency_key, request_hash,
            response_status, response_body, resource_id
        ) VALUES ($1, $2, $3, $4, 201, $5, $6)
        ON CONFLICT (principal_id, endpoint, idempotency_key) DO NOTHING
        "#,
    )
    .bind(ctx.principal_id.as_uuid())
    .bind("POST /v1/conversions")
    .bind(idempotency_key.as_str())
    .bind(dollar_auth::sha256_hex(&payload_bytes))
    .bind(&body_json)
    .bind(conv_id.as_uuid())
    .execute(&mut *tx_idem)
    .await;
    tx_idem.commit().await.map_err(|e| DomainError::Storage(e.to_string()))?;

    Ok((201, final_record))
}

#[allow(clippy::too_many_arguments)]
pub async fn apply_conversion_evidence(
    pool: &PgPool,
    actor_id: PrincipalId,
    actor_role: &str,
    conv_id: ConversionId,
    direction: ConversionDirection,
    account_id: AccountId,
    money: Money,
    bank_account_ref_token: &str,
    reservation_id: Option<ReservationId>,
    external_reference: &str,
    outcome: SimulatedBankOutcome,
    failure_reason: Option<&str>,
    created_at: DateTime<Utc>,
    correlation_id: CorrelationId,
) -> Result<ConversionRecord, DomainError> {
    let mut tx = pool.begin().await.map_err(|e| DomainError::Storage(e.to_string()))?;

    let outcome_str = match outcome {
        SimulatedBankOutcome::Settled => "SETTLED",
        SimulatedBankOutcome::Failed => "FAILED",
        SimulatedBankOutcome::Pending => "PENDING",
    };

    // Lock conversion row to serialize duplicate evidence deliveries.
    let conv_row = sqlx::query("SELECT status, journal_id FROM conversion_requests WHERE id = $1 FOR UPDATE")
        .bind(conv_id.as_uuid())
        .fetch_one(&mut *tx)
        .await
        .map_err(|e| DomainError::Storage(e.to_string()))?;

    let current_status: String = conv_row.get("status");
    if matches!(current_status.as_str(), "RECONCILED" | "FAILED_RELEASED") {
        let existing = fetch_conversion_in_tx(&mut tx, conv_id).await?;
        tx.commit().await.map_err(|e| DomainError::Storage(e.to_string()))?;
        return Ok(existing);
    }

    // Record deduplicated evidence
    sqlx::query(
        r#"
        INSERT INTO conversion_evidence (id, conversion_id, provider_name, external_tx_id, outcome, payload_json)
        VALUES ($1, $2, 'SIMULATED_BANK_RAIL', $3, $4, $5)
        ON CONFLICT (provider_name, external_tx_id, outcome) DO NOTHING
        "#,
    )
    .bind(Uuid::now_v7())
    .bind(conv_id.as_uuid())
    .bind(external_reference)
    .bind(outcome_str)
    .bind(serde_json::json!({
        "direction": direction.as_str(),
        "amount_cents": money.cents(),
        "outcome": outcome_str,
        "failure_reason": failure_reason,
    }))
    .execute(&mut *tx)
    .await
    .map_err(|e| DomainError::Storage(e.to_string()))?;

    let (final_status, journal_id, final_reason) = match outcome {
        SimulatedBankOutcome::Settled => {
            let j_id = match direction {
                ConversionDirection::RedeemToBank => {
                    post_journal_in_tx(
                        &mut tx,
                        PostJournalRequest {
                            entry_type: JournalEntryType::RedemptionRetirement,
                            transaction_ref: format!("REDEEM:{conv_id}"),
                            correlation_id,
                            reversal_of_journal_id: None,
                            created_by: actor_id,
                            description_code: "BANK_REDEMPTION_RETIRED".to_string(),
                            lines: vec![
                                ProposedJournalLine {
                                    account_id,
                                    direction: EntryDirection::Debit,
                                    amount: money,
                                },
                                ProposedJournalLine {
                                    account_id: AccountId::from_uuid(RETIREMENT_CONTROL_ACCOUNT_UUID),
                                    direction: EntryDirection::Credit,
                                    amount: money,
                                },
                            ],
                            consume_reservation_id: reservation_id,
                            outbox_event: Some(OutboxProposal {
                                aggregate_type: "CONVERSION".to_string(),
                                aggregate_id: conv_id.as_uuid(),
                                event_type: "RedemptionReconciled".to_string(),
                                payload: serde_json::json!({
                                    "conversion_id": conv_id,
                                    "account_id": account_id,
                                    "amount_cents": money.cents(),
                                    "external_reference": external_reference,
                                }),
                            }),
                        },
                    )
                    .await?
                }
                ConversionDirection::DepositToDigital => {
                    post_journal_in_tx(
                        &mut tx,
                        PostJournalRequest {
                            entry_type: JournalEntryType::ConversionMint,
                            transaction_ref: format!("DEPOSIT:{conv_id}"),
                            correlation_id,
                            reversal_of_journal_id: None,
                            created_by: actor_id,
                            description_code: "SIMULATED_BANK_DEPOSIT_MINT".to_string(),
                            lines: vec![
                                ProposedJournalLine {
                                    account_id: AccountId::from_uuid(ISSUANCE_CONTROL_ACCOUNT_UUID),
                                    direction: EntryDirection::Debit,
                                    amount: money,
                                },
                                ProposedJournalLine {
                                    account_id,
                                    direction: EntryDirection::Credit,
                                    amount: money,
                                },
                            ],
                            consume_reservation_id: None,
                            outbox_event: Some(OutboxProposal {
                                aggregate_type: "CONVERSION".to_string(),
                                aggregate_id: conv_id.as_uuid(),
                                event_type: "DepositConversionReconciled".to_string(),
                                payload: serde_json::json!({
                                    "conversion_id": conv_id,
                                    "account_id": account_id,
                                    "amount_cents": money.cents(),
                                    "external_reference": external_reference,
                                }),
                            }),
                        },
                    )
                    .await?
                }
            };
            ("RECONCILED".to_string(), Some(j_id), None)
        }
        SimulatedBankOutcome::Failed => {
            if let Some(res_id) = reservation_id {
                release_reservation_in_tx(&mut tx, res_id).await?;
            }
            (
                "FAILED_RELEASED".to_string(),
                None,
                Some(
                    failure_reason
                        .unwrap_or("External bank conversion failed; customer funds released")
                        .to_string(),
                ),
            )
        }
        SimulatedBankOutcome::Pending => (
            "UNCERTAIN_HOLD".to_string(),
            None,
            Some(
                failure_reason
                    .unwrap_or("Awaiting external settlement confirmation")
                    .to_string(),
            ),
        ),
    };

    let updated = sqlx::query(
        r#"
        UPDATE conversion_requests
        SET status = $2,
            journal_id = $3,
            external_reference = $4,
            failure_reason = $5,
            updated_at = NOW()
        WHERE id = $1
        RETURNING updated_at
        "#,
    )
    .bind(conv_id.as_uuid())
    .bind(&final_status)
    .bind(journal_id.map(|j| j.as_uuid()))
    .bind(external_reference)
    .bind(final_reason.as_deref())
    .fetch_one(&mut *tx)
    .await
    .map_err(|e| DomainError::Storage(e.to_string()))?;

    record_audit_event(
        &mut tx,
        Some(actor_id),
        actor_role,
        &format!("CONVERSION_{final_status}"),
        "CONVERSION",
        &conv_id.to_string(),
        correlation_id,
        if final_status == "RECONCILED" {
            "SUCCESS"
        } else {
            "HOLD_OR_RELEASED"
        },
        serde_json::json!({
            "direction": direction.as_str(),
            "amount_cents": money.cents(),
            "status": final_status,
            "external_reference": external_reference,
        }),
    )
    .await?;

    tx.commit().await.map_err(|e| DomainError::Storage(e.to_string()))?;

    Ok(ConversionRecord {
        id: conv_id,
        direction,
        account_id,
        amount_cents: money.cents(),
        currency: Currency::Usd,
        bank_account_ref_token: bank_account_ref_token.to_string(),
        status: final_status,
        reservation_id,
        journal_id,
        external_reference: Some(external_reference.to_string()),
        failure_reason: final_reason,
        created_at,
        updated_at: updated.get("updated_at"),
    })
}

async fn fetch_conversion_in_tx(
    tx: &mut Transaction<'_, Postgres>,
    conv_id: ConversionId,
) -> Result<ConversionRecord, DomainError> {
    let row = sqlx::query(
        r#"
        SELECT id, direction, account_id, amount_cents, bank_account_ref_token,
               status, reservation_id, journal_id, external_reference, failure_reason,
               created_at, updated_at
        FROM conversion_requests
        WHERE id = $1
        "#,
    )
    .bind(conv_id.as_uuid())
    .fetch_optional(&mut **tx)
    .await
    .map_err(|e| DomainError::Storage(e.to_string()))?
    .ok_or_else(|| DomainError::NotFound(format!("Conversion {conv_id}")))?;

    Ok(ConversionRecord {
        id: ConversionId::from_uuid(row.get("id")),
        direction: ConversionDirection::from_str(&row.get::<String, _>("direction"))?,
        account_id: AccountId::from_uuid(row.get("account_id")),
        amount_cents: row.get("amount_cents"),
        currency: Currency::Usd,
        bank_account_ref_token: row.get("bank_account_ref_token"),
        status: row.get("status"),
        reservation_id: row
            .get::<Option<Uuid>, _>("reservation_id")
            .map(ReservationId::from_uuid),
        journal_id: row
            .get::<Option<Uuid>, _>("journal_id")
            .map(JournalId::from_uuid),
        external_reference: row.get("external_reference"),
        failure_reason: row.get("failure_reason"),
        created_at: row.get("created_at"),
        updated_at: row.get("updated_at"),
    })
}

pub async fn get_conversion(
    pool: &PgPool,
    ctx: &AuthContext,
    conv_id: ConversionId,
) -> Result<ConversionRecord, DomainError> {
    let row = sqlx::query(
        r#"
        SELECT c.id, c.direction, c.account_id, c.amount_cents, c.bank_account_ref_token,
               c.status, c.reservation_id, c.journal_id, c.external_reference, c.failure_reason,
               c.created_at, c.updated_at, a.owner_principal_id
        FROM conversion_requests c
        JOIN accounts a ON a.id = c.account_id
        WHERE c.id = $1
        "#,
    )
    .bind(conv_id.as_uuid())
    .fetch_optional(pool)
    .await
    .map_err(|e| DomainError::Storage(e.to_string()))?
    .ok_or_else(|| DomainError::NotFound(format!("Conversion {conv_id}")))?;

    authorize_account_read(ctx, PrincipalId::from_uuid(row.get("owner_principal_id")))?;

    Ok(ConversionRecord {
        id: ConversionId::from_uuid(row.get("id")),
        direction: ConversionDirection::from_str(&row.get::<String, _>("direction"))?,
        account_id: AccountId::from_uuid(row.get("account_id")),
        amount_cents: row.get("amount_cents"),
        currency: Currency::Usd,
        bank_account_ref_token: row.get("bank_account_ref_token"),
        status: row.get("status"),
        reservation_id: row
            .get::<Option<Uuid>, _>("reservation_id")
            .map(ReservationId::from_uuid),
        journal_id: row
            .get::<Option<Uuid>, _>("journal_id")
            .map(JournalId::from_uuid),
        external_reference: row.get("external_reference"),
        failure_reason: row.get("failure_reason"),
        created_at: row.get("created_at"),
        updated_at: row.get("updated_at"),
    })
}

/// Recovery worker resolving `UNCERTAIN_HOLD` / `EXTERNAL_PROCESSING` conversions on restart.
pub async fn recover_pending_conversions(
    pool: &PgPool,
    adapter: &SimulatedBankAdapter,
) -> Result<u64, DomainError> {
    let rows = sqlx::query(
        r#"
        SELECT id, direction, account_id, amount_cents, bank_account_ref_token,
               reservation_id, external_reference, created_by, created_at
        FROM conversion_requests
        WHERE status IN ('EXTERNAL_PROCESSING', 'UNCERTAIN_HOLD')
          AND updated_at < NOW() - INTERVAL '2 seconds'
        LIMIT 25
        "#,
    )
    .fetch_all(pool)
    .await
    .map_err(|e| DomainError::Storage(e.to_string()))?;

    let mut recovered = 0u64;
    for row in rows {
        let conv_id = ConversionId::from_uuid(row.get("id"));
        let direction = ConversionDirection::from_str(&row.get::<String, _>("direction"))?;
        let account_id = AccountId::from_uuid(row.get("account_id"));
        let amount_cents: i64 = row.get("amount_cents");
        let money = Money::from_positive_cents(amount_cents, Currency::Usd)?;
        let bank_token: String = row.get("bank_account_ref_token");
        let res_id = row
            .get::<Option<Uuid>, _>("reservation_id")
            .map(ReservationId::from_uuid);
        let created_by = PrincipalId::from_uuid(row.get("created_by"));
        let created_at: DateTime<Utc> = row.get("created_at");

        let (ext_ref, outcome, fail_msg) =
            adapter.submit_payout_or_deposit(conv_id, direction, amount_cents, None);
        if outcome != SimulatedBankOutcome::Pending {
            let ext = row
                .get::<Option<String>, _>("external_reference")
                .unwrap_or(ext_ref);
            apply_conversion_evidence(
                pool,
                created_by,
                "SYSTEM_RECOVERY_WORKER",
                conv_id,
                direction,
                account_id,
                money,
                &bank_token,
                res_id,
                &ext,
                outcome,
                fail_msg.as_deref(),
                created_at,
                CorrelationId::new(),
            )
            .await?;
            recovered += 1;
        }
    }

    Ok(recovered)
}
