use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use std::fmt;
use std::str::FromStr;
use thiserror::Error;
use utoipa::ToSchema;
use uuid::Uuid;

/// Maximum single monetary value permitted in cents ($100,000,000,000.00 = 10^13 cents),
/// leaving wide headroom below i64::MAX (9.22e18) to guard aggregate summation against overflow.
pub const MAX_MONEY_CENTS: i64 = 10_000_000_000_000;

/// Supported settlement currency. Only USD is supported in this ledger.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize, ToSchema)]
#[serde(rename_all = "UPPERCASE")]
pub enum Currency {
    Usd,
}

impl Currency {
    pub fn as_str(self) -> &'static str {
        "USD"
    }
}

impl fmt::Display for Currency {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("USD")
    }
}

impl FromStr for Currency {
    type Err = DomainError;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        if s.eq_ignore_ascii_case("USD") {
            Ok(Currency::Usd)
        } else {
            Err(DomainError::UnsupportedCurrency(s.to_string()))
        }
    }
}

/// Validated USD monetary amount stored strictly as integer cents.
/// Rejects negative values, overflow beyond `MAX_MONEY_CENTS`, and currency mismatches.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Serialize, Deserialize, ToSchema)]
pub struct Money {
    cents: i64,
    currency: Currency,
}

impl Money {
    /// Creates a non-negative `Money` value from integer cents.
    pub fn from_cents(cents: i64, currency: Currency) -> Result<Self, DomainError> {
        if cents < 0 {
            return Err(DomainError::NegativeAmount(cents));
        }
        if cents > MAX_MONEY_CENTS {
            return Err(DomainError::AmountOverflow);
        }
        Ok(Self { cents, currency })
    }

    /// Creates a strictly positive (`> 0`) `Money` value from integer cents.
    pub fn from_positive_cents(cents: i64, currency: Currency) -> Result<Self, DomainError> {
        if cents <= 0 {
            return Err(DomainError::NonPositiveAmount(cents));
        }
        Self::from_cents(cents, currency)
    }

    /// Parses a decimal USD string (e.g. `"12.34"`, `"100"`, `"0.05"`) into integer cents.
    /// Rejects negative signs, more than 2 fractional digits, whitespace/symbols, and overflow.
    pub fn from_decimal_str(input: &str, currency: Currency) -> Result<Self, DomainError> {
        let trimmed = input.trim();
        if trimmed.is_empty() || trimmed.starts_with('-') || trimmed.starts_with('+') {
            return Err(DomainError::InvalidMonetaryFormat(input.to_string()));
        }

        let mut parts = trimmed.split('.');
        let whole_str = parts.next().unwrap_or("");
        let frac_str = parts.next();
        if parts.next().is_some() || whole_str.is_empty() || !whole_str.bytes().all(|b| b.is_ascii_digit()) {
            return Err(DomainError::InvalidMonetaryFormat(input.to_string()));
        }

        let whole: i64 = whole_str
            .parse::<i64>()
            .map_err(|_| DomainError::AmountOverflow)?;

        let frac_cents: i64 = match frac_str {
            None => 0,
            Some(f) => {
                if f.is_empty() || f.len() > 2 || !f.bytes().all(|b| b.is_ascii_digit()) {
                    return Err(DomainError::InvalidPrecision(input.to_string()));
                }
                let parsed: i64 = f.parse::<i64>().map_err(|_| DomainError::InvalidPrecision(input.to_string()))?;
                if f.len() == 1 { parsed * 10 } else { parsed }
            }
        };

        let total = whole
            .checked_mul(100)
            .and_then(|v| v.checked_add(frac_cents))
            .ok_or(DomainError::AmountOverflow)?;

        Self::from_cents(total, currency)
    }

    pub fn zero(currency: Currency) -> Self {
        Self { cents: 0, currency }
    }

    pub fn cents(self) -> i64 {
        self.cents
    }

    pub fn currency(self) -> Currency {
        self.currency
    }

    pub fn checked_add(self, rhs: Self) -> Result<Self, DomainError> {
        if self.currency != rhs.currency {
            return Err(DomainError::CurrencyMismatch {
                expected: self.currency.to_string(),
                actual: rhs.currency.to_string(),
            });
        }
        let sum = self.cents.checked_add(rhs.cents).ok_or(DomainError::AmountOverflow)?;
        Self::from_cents(sum, self.currency)
    }

    pub fn checked_sub(self, rhs: Self) -> Result<Self, DomainError> {
        if self.currency != rhs.currency {
            return Err(DomainError::CurrencyMismatch {
                expected: self.currency.to_string(),
                actual: rhs.currency.to_string(),
            });
        }
        if self.cents < rhs.cents {
            return Err(DomainError::InsufficientFunds {
                available_cents: self.cents,
                required_cents: rhs.cents,
            });
        }
        Ok(Self {
            cents: self.cents - rhs.cents,
            currency: self.currency,
        })
    }

    pub fn format_usd(self) -> String {
        format!("${}.{:02}", self.cents / 100, self.cents % 100)
    }
}

impl fmt::Display for Money {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{} {}", self.format_usd(), self.currency)
    }
}

macro_rules! define_uuid_id {
    ($name:ident, $doc:literal) => {
        #[doc = $doc]
        #[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize, ToSchema)]
        #[serde(transparent)]
        pub struct $name(pub Uuid);

        impl $name {
            pub fn new() -> Self {
                Self(Uuid::now_v7())
            }

            pub fn from_uuid(id: Uuid) -> Self {
                Self(id)
            }

            pub fn as_uuid(&self) -> Uuid {
                self.0
            }
        }

        impl Default for $name {
            fn default() -> Self {
                Self::new()
            }
        }

        impl fmt::Display for $name {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                self.0.fmt(f)
            }
        }

        impl FromStr for $name {
            type Err = DomainError;

            fn from_str(s: &str) -> Result<Self, Self::Err> {
                Uuid::parse_str(s)
                    .map(Self)
                    .map_err(|_| DomainError::InvalidIdentifier(s.to_string()))
            }
        }
    };
}

define_uuid_id!(PrincipalId, "Opaque identifier for an authenticated principal.");
define_uuid_id!(AccountId, "Opaque identifier for a wallet or control account.");
define_uuid_id!(TransactionId, "Opaque identifier for a transfer or business transaction.");
define_uuid_id!(JournalId, "Immutable double-entry journal identifier.");
define_uuid_id!(PaymentRequestId, "Identifier for a merchant payment request.");
define_uuid_id!(PaymentId, "Identifier for a settled merchant payment.");
define_uuid_id!(RefundId, "Identifier for a linked payment refund.");
define_uuid_id!(IssuanceId, "Identifier for an issuance request/authorisation.");
define_uuid_id!(ConversionId, "Identifier for a bank conversion/redemption request.");
define_uuid_id!(ReservationId, "Identifier for a time-bounded fund reservation.");
define_uuid_id!(ScheduledPaymentId, "Identifier for a scheduled payment instruction.");
define_uuid_id!(CorrelationId, "Request correlation identifier for end-to-end tracing.");

/// Validated client-supplied idempotency key (ASCII printable, 8..=128 chars).
#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize, ToSchema)]
#[serde(transparent)]
pub struct IdempotencyKey(String);

impl IdempotencyKey {
    pub fn parse(raw: &str) -> Result<Self, DomainError> {
        let trimmed = raw.trim();
        if trimmed.len() < 8 || trimmed.len() > 128 {
            return Err(DomainError::InvalidIdempotencyKey(
                "Idempotency key must be between 8 and 128 characters".to_string(),
            ));
        }
        if !trimmed
            .bytes()
            .all(|b| b.is_ascii_alphanumeric() || matches!(b, b'-' | b'_' | b'.' | b':'))
        {
            return Err(DomainError::InvalidIdempotencyKey(
                "Idempotency key contains unsupported characters".to_string(),
            ));
        }
        Ok(Self(trimmed.to_string()))
    }

    pub fn as_str(&self) -> &str {
        &self.0
    }
}

impl fmt::Display for IdempotencyKey {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.0)
    }
}

impl FromStr for IdempotencyKey {
    type Err = DomainError;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        Self::parse(s)
    }
}

/// Validated issuance authorisation record returned upon approval.
#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct IssuanceAuthorisation {
    pub issuance_id: IssuanceId,
    pub approved_by: PrincipalId,
    pub requested_by: PrincipalId,
    pub amount_cents: i64,
    pub currency: Currency,
    pub approved_at: DateTime<Utc>,
}

/// Principal role controlling RBAC across APIs.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize, ToSchema)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum Role {
    Customer,
    Merchant,
    IssuerOperator,
    IssuerApprover,
    Auditor,
    FraudReviewer,
    SystemAdmin,
}

impl Role {
    pub fn as_str(self) -> &'static str {
        match self {
            Role::Customer => "CUSTOMER",
            Role::Merchant => "MERCHANT",
            Role::IssuerOperator => "ISSUER_OPERATOR",
            Role::IssuerApprover => "ISSUER_APPROVER",
            Role::Auditor => "AUDITOR",
            Role::FraudReviewer => "FRAUD_REVIEWER",
            Role::SystemAdmin => "SYSTEM_ADMIN",
        }
    }
}

impl FromStr for Role {
    type Err = DomainError;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        match s {
            "CUSTOMER" => Ok(Role::Customer),
            "MERCHANT" => Ok(Role::Merchant),
            "ISSUER_OPERATOR" => Ok(Role::IssuerOperator),
            "ISSUER_APPROVER" => Ok(Role::IssuerApprover),
            "AUDITOR" => Ok(Role::Auditor),
            "FRAUD_REVIEWER" => Ok(Role::FraudReviewer),
            "SYSTEM_ADMIN" => Ok(Role::SystemAdmin),
            other => Err(DomainError::InvalidRole(other.to_string())),
        }
    }
}

/// Account classification separating customer/merchant wallets from issuer control & clearing.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize, ToSchema)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum AccountClass {
    CustomerWallet,
    MerchantWallet,
    IssuerTreasury,
    IssuanceControl,
    RetirementControl,
    Clearing,
}

impl AccountClass {
    pub fn as_str(self) -> &'static str {
        match self {
            AccountClass::CustomerWallet => "CUSTOMER_WALLET",
            AccountClass::MerchantWallet => "MERCHANT_WALLET",
            AccountClass::IssuerTreasury => "ISSUER_TREASURY",
            AccountClass::IssuanceControl => "ISSUANCE_CONTROL",
            AccountClass::RetirementControl => "RETIREMENT_CONTROL",
            AccountClass::Clearing => "CLEARING",
        }
    }

    pub fn normal_balance(self) -> EntryDirection {
        match self {
            AccountClass::IssuanceControl | AccountClass::RetirementControl => EntryDirection::Debit,
            AccountClass::CustomerWallet
            | AccountClass::MerchantWallet
            | AccountClass::IssuerTreasury
            | AccountClass::Clearing => EntryDirection::Credit,
        }
    }

    pub fn is_wallet(self) -> bool {
        matches!(self, AccountClass::CustomerWallet | AccountClass::MerchantWallet)
    }

    pub fn is_circulating_liability(self) -> bool {
        matches!(
            self,
            AccountClass::CustomerWallet
                | AccountClass::MerchantWallet
                | AccountClass::IssuerTreasury
                | AccountClass::Clearing
        )
    }
}

impl FromStr for AccountClass {
    type Err = DomainError;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        match s {
            "CUSTOMER_WALLET" => Ok(AccountClass::CustomerWallet),
            "MERCHANT_WALLET" => Ok(AccountClass::MerchantWallet),
            "ISSUER_TREASURY" => Ok(AccountClass::IssuerTreasury),
            "ISSUANCE_CONTROL" => Ok(AccountClass::IssuanceControl),
            "RETIREMENT_CONTROL" => Ok(AccountClass::RetirementControl),
            "CLEARING" => Ok(AccountClass::Clearing),
            other => Err(DomainError::InvalidAccountClass(other.to_string())),
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize, ToSchema)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum WalletStatus {
    Active,
    Suspended,
    Closed,
}

impl WalletStatus {
    pub fn as_str(self) -> &'static str {
        match self {
            WalletStatus::Active => "ACTIVE",
            WalletStatus::Suspended => "SUSPENDED",
            WalletStatus::Closed => "CLOSED",
        }
    }
}

impl FromStr for WalletStatus {
    type Err = DomainError;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        match s {
            "ACTIVE" => Ok(WalletStatus::Active),
            "SUSPENDED" => Ok(WalletStatus::Suspended),
            "CLOSED" => Ok(WalletStatus::Closed),
            other => Err(DomainError::InvalidState(format!("Unknown wallet status: {other}"))),
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize, ToSchema)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum EntryDirection {
    Debit,
    Credit,
}

impl EntryDirection {
    pub fn as_str(self) -> &'static str {
        match self {
            EntryDirection::Debit => "DEBIT",
            EntryDirection::Credit => "CREDIT",
        }
    }
}

impl FromStr for EntryDirection {
    type Err = DomainError;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        match s {
            "DEBIT" => Ok(EntryDirection::Debit),
            "CREDIT" => Ok(EntryDirection::Credit),
            other => Err(DomainError::InvalidState(format!("Unknown entry direction: {other}"))),
        }
    }
}

/// Canonical structured domain errors mapped cleanly to HTTP error responses without leaking secrets.
#[derive(Debug, Error)]
pub enum DomainError {
    #[error("Negative amount is not permitted: {0} cents")]
    NegativeAmount(i64),

    #[error("Amount must be strictly positive: {0} cents")]
    NonPositiveAmount(i64),

    #[error("Monetary amount overflow")]
    AmountOverflow,

    #[error("Invalid monetary format: {0}")]
    InvalidMonetaryFormat(String),

    #[error("Invalid monetary precision (expected up to 2 decimal places): {0}")]
    InvalidPrecision(String),

    #[error("Unsupported currency: {0}")]
    UnsupportedCurrency(String),

    #[error("Currency mismatch: expected {expected}, got {actual}")]
    CurrencyMismatch { expected: String, actual: String },

    #[error("Invalid identifier: {0}")]
    InvalidIdentifier(String),

    #[error("Invalid idempotency key: {0}")]
    InvalidIdempotencyKey(String),

    #[error("Idempotency conflict: key was already used with a different request payload")]
    IdempotencyConflict,

    #[error("Invalid role: {0}")]
    InvalidRole(String),

    #[error("Invalid account class: {0}")]
    InvalidAccountClass(String),

    #[error("Unbalanced journal entry: debits {debits_cents} != credits {credits_cents}")]
    UnbalancedJournal {
        debits_cents: i64,
        credits_cents: i64,
    },

    #[error("Journal must have at least 2 entries")]
    InsufficientJournalLines,

    #[error("Insufficient available funds: available {available_cents} cents, required {required_cents} cents")]
    InsufficientFunds {
        available_cents: i64,
        required_cents: i64,
    },

    #[error("Account {0} is not active (status: {1})")]
    AccountNotActive(AccountId, String),

    #[error("Wallet closure rejected: account {0} has posted={1} cents or reserved={2} cents")]
    WalletClosureOutstandingObligations(AccountId, i64, i64),

    #[error("Self-transfer is not permitted on account {0}")]
    SelfTransferForbidden(AccountId),

    #[error("Resource not found: {0}")]
    NotFound(String),

    #[error("Unauthorized: {0}")]
    Unauthorized(String),

    #[error("Forbidden: {0}")]
    Forbidden(String),

    #[error("Rate limit exceeded")]
    RateLimited,

    #[error("Request expired: {0}")]
    Expired(String),

    #[error("Invalid state transition: {0}")]
    InvalidState(String),

    #[error("Refund limit exceeded: remaining refundable {remaining_cents} cents, requested {requested_cents} cents")]
    RefundLimitExceeded {
        remaining_cents: i64,
        requested_cents: i64,
    },

    #[error("Invalid signature on payment request")]
    InvalidSignature,

    #[error("Validation error: {0}")]
    Validation(String),

    #[error("Internal storage error")]
    Storage(String),
}

impl DomainError {
    pub fn error_code(&self) -> &'static str {
        match self {
            DomainError::NegativeAmount(_) => "NEGATIVE_AMOUNT",
            DomainError::NonPositiveAmount(_) => "NON_POSITIVE_AMOUNT",
            DomainError::AmountOverflow => "AMOUNT_OVERFLOW",
            DomainError::InvalidMonetaryFormat(_) => "INVALID_MONETARY_FORMAT",
            DomainError::InvalidPrecision(_) => "INVALID_PRECISION",
            DomainError::UnsupportedCurrency(_) => "UNSUPPORTED_CURRENCY",
            DomainError::CurrencyMismatch { .. } => "CURRENCY_MISMATCH",
            DomainError::InvalidIdentifier(_) => "INVALID_IDENTIFIER",
            DomainError::InvalidIdempotencyKey(_) => "INVALID_IDEMPOTENCY_KEY",
            DomainError::IdempotencyConflict => "IDEMPOTENCY_CONFLICT",
            DomainError::InvalidRole(_) => "INVALID_ROLE",
            DomainError::InvalidAccountClass(_) => "INVALID_ACCOUNT_CLASS",
            DomainError::UnbalancedJournal { .. } => "UNBALANCED_JOURNAL",
            DomainError::InsufficientJournalLines => "INSUFFICIENT_JOURNAL_LINES",
            DomainError::InsufficientFunds { .. } => "INSUFFICIENT_FUNDS",
            DomainError::AccountNotActive(_, _) => "ACCOUNT_NOT_ACTIVE",
            DomainError::WalletClosureOutstandingObligations(_, _, _) => "WALLET_HAS_OUTSTANDING_BALANCE",
            DomainError::SelfTransferForbidden(_) => "SELF_TRANSFER_FORBIDDEN",
            DomainError::NotFound(_) => "NOT_FOUND",
            DomainError::Unauthorized(_) => "UNAUTHORIZED",
            DomainError::Forbidden(_) => "FORBIDDEN",
            DomainError::RateLimited => "RATE_LIMITED",
            DomainError::Expired(_) => "EXPIRED",
            DomainError::InvalidState(_) => "INVALID_STATE",
            DomainError::RefundLimitExceeded { .. } => "REFUND_LIMIT_EXCEEDED",
            DomainError::InvalidSignature => "INVALID_SIGNATURE",
            DomainError::Validation(_) => "VALIDATION_ERROR",
            DomainError::Storage(_) => "INTERNAL_ERROR",
        }
    }

    pub fn http_status_code(&self) -> u16 {
        match self {
            DomainError::NegativeAmount(_)
            | DomainError::NonPositiveAmount(_)
            | DomainError::AmountOverflow
            | DomainError::InvalidMonetaryFormat(_)
            | DomainError::InvalidPrecision(_)
            | DomainError::UnsupportedCurrency(_)
            | DomainError::CurrencyMismatch { .. }
            | DomainError::InvalidIdentifier(_)
            | DomainError::InvalidIdempotencyKey(_)
            | DomainError::InvalidRole(_)
            | DomainError::InvalidAccountClass(_)
            | DomainError::InsufficientJournalLines
            | DomainError::SelfTransferForbidden(_)
            | DomainError::InvalidSignature
            | DomainError::Validation(_) => 400,
            DomainError::Unauthorized(_) => 401,
            DomainError::Forbidden(_) => 403,
            DomainError::NotFound(_) => 404,
            DomainError::IdempotencyConflict
            | DomainError::InsufficientFunds { .. }
            | DomainError::AccountNotActive(_, _)
            | DomainError::WalletClosureOutstandingObligations(_, _, _)
            | DomainError::InvalidState(_)
            | DomainError::RefundLimitExceeded { .. }
            | DomainError::UnbalancedJournal { .. } => 409,
            DomainError::Expired(_) => 410,
            DomainError::RateLimited => 429,
            DomainError::Storage(_) => 500,
        }
    }
}
