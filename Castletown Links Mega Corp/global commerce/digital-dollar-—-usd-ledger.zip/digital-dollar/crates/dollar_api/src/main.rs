use anyhow::Context;
use dollar_api::{build_router, run_background_tick, AppState};
use dollar_auth::{bootstrap_local_demo_credentials, AuthService, RateLimiter};
use dollar_ledger::{ensure_system_accounts, run_reconciliation};
use dollar_payments::{PaymentRequestSigner, SimulatedBankAdapter};
use sqlx::postgres::PgPoolOptions;
use std::sync::Arc;
use std::time::Duration;
use tracing_subscriber::EnvFilter;

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    tracing_subscriber::fmt()
        .with_env_filter(
            EnvFilter::try_from_default_env().unwrap_or_else(|_| EnvFilter::new("info")),
        )
        .json()
        .init();

    let database_url = std::env::var("DATABASE_URL")
        .context("DATABASE_URL environment variable must be set")?;
    let bind_addr =
        std::env::var("API_BIND_ADDR").unwrap_or_else(|_| "0.0.0.0:8080".to_string());
    let token_secret = std::env::var("AUTH_TOKEN_HMAC_SECRET")
        .context("AUTH_TOKEN_HMAC_SECRET environment variable must be set")?;
    let payment_secret = std::env::var("PAYMENT_REQUEST_HMAC_SECRET")
        .context("PAYMENT_REQUEST_HMAC_SECRET environment variable must be set")?;
    let enable_demo = std::env::var("ENABLE_LOCAL_DEMO_BOOTSTRAP")
        .map(|v| v == "true" || v == "1")
        .unwrap_or(false);
    let require_distinct_approver = std::env::var("REQUIRE_DISTINCT_ISSUANCE_APPROVER")
        .map(|v| v != "false" && v != "0")
        .unwrap_or(true);
    let rate_limit_max: usize = std::env::var("RATE_LIMIT_MAX_REQUESTS")
        .ok()
        .and_then(|v| v.parse().ok())
        .unwrap_or(600);
    let rate_limit_window: u64 = std::env::var("RATE_LIMIT_WINDOW_SECS")
        .ok()
        .and_then(|v| v.parse().ok())
        .unwrap_or(60);
    let bank_mode =
        std::env::var("BANK_ADAPTER_MODE").unwrap_or_else(|_| "normal".to_string());
    let worker_poll_ms: u64 = std::env::var("WORKER_POLL_INTERVAL_MS")
        .ok()
        .and_then(|v| v.parse().ok())
        .unwrap_or(500);
    let recon_secs: u64 = std::env::var("RECONCILIATION_INTERVAL_SECS")
        .ok()
        .and_then(|v| v.parse().ok())
        .unwrap_or(30);

    let pool = PgPoolOptions::new()
        .max_connections(32)
        .acquire_timeout(Duration::from_secs(5))
        .connect(&database_url)
        .await
        .context("Failed to connect to PostgreSQL")?;

    sqlx::migrate!("../../migrations")
        .run(&pool)
        .await
        .context("Failed to run PostgreSQL migrations")?;

    let auth = AuthService::new(token_secret, 3600 * 8)?;
    let payment_signer = PaymentRequestSigner::new(payment_secret)?;

    if enable_demo {
        tracing::warn!("ENABLE_LOCAL_DEMO_BOOTSTRAP=true: initializing local-demo credentials");
        let demo = bootstrap_local_demo_credentials(&pool, &auth).await?;
        ensure_system_accounts(&pool, demo.system_admin_id).await?;
    }

    let state = AppState {
        pool: pool.clone(),
        auth,
        payment_signer,
        bank_adapter: SimulatedBankAdapter::new(bank_mode),
        rate_limiter: Arc::new(RateLimiter::new(rate_limit_max, rate_limit_window)),
        require_distinct_issuance_approver: require_distinct_approver,
    };

    // Background worker loop (outbox, reservation expiry, scheduled payments, conversion recovery)
    let worker_state = state.clone();
    tokio::spawn(async move {
        let mut interval = tokio::time::interval(Duration::from_millis(worker_poll_ms));
        loop {
            interval.tick().await;
            if let Err(err) = run_background_tick(&worker_state).await {
                tracing::error!(error = %err, "Background worker tick failed");
            }
        }
    });

    // Periodic reconciliation loop
    let recon_pool = pool.clone();
    tokio::spawn(async move {
        let mut interval = tokio::time::interval(Duration::from_secs(recon_secs));
        loop {
            interval.tick().await;
            match run_reconciliation(&recon_pool, "PERIODIC_DAEMON").await {
                Ok(rep) if !rep.is_healthy => {
                    tracing::error!(run_id = %rep.run_id, "Reconciliation detected ledger anomaly");
                }
                Err(err) => {
                    tracing::error!(error = %err, "Periodic reconciliation failed");
                }
                _ => {}
            }
        }
    });

    let app = build_router(state);
    let listener = tokio::net::TcpListener::bind(&bind_addr)
        .await
        .with_context(|| format!("Failed to bind to {bind_addr}"))?;

    tracing::info!(bind_addr = %bind_addr, "DIGITAL DOLLAR — USD Ledger API listening");
    axum::serve(listener, app)
        .with_graceful_shutdown(shutdown_signal())
        .await
        .context("Server error")?;

    Ok(())
}

async fn shutdown_signal() {
    let _ = tokio::signal::ctrl_c().await;
    tracing::info!("Shutdown signal received");
}
