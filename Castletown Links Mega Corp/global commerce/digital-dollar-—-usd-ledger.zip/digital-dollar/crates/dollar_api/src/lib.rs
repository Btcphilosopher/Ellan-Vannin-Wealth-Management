use axum::{
    extract::{Path, Query, State},
    http::{HeaderMap, HeaderValue, StatusCode},
    response::{IntoResponse, Response},
    routing::{get, post},
    Json, Router,
};
use chrono::{DateTime, Utc};
use dollar_auth::{
    require_role, AuthContext, AuthService, RateLimiter,
};
use dollar_issuer::{
    approve_issuance, request_issuance, ApproveIssuanceRequest, CreateIssuanceRequest,
    IssuanceRecord,
};
use dollar_ledger::{
    check_idempotency_in_tx, create_wallet, expire_overdue_reservations, get_wallet_balance,
    get_wallet_transactions, run_reconciliation, store_idempotency_in_tx, update_wallet_status,
    ReconciliationReport, WalletRecord, WalletTransactionItem,
};
use dollar_payments::{
    create_conversion, create_payment_request, create_scheduled_payment,
    execute_due_scheduled_payments, get_conversion, get_transfer, pay_payment_request,
    preview_transfer, recover_pending_conversions, refund_payment, submit_transfer,
    ConversionRecord, CreateConversionRequest, CreatePaymentRequestInput, CreateRefundInput,
    PayPaymentRequestInput, PaymentRecord, PaymentRequestRecord, PaymentRequestSigner,
    RefundRecord, SchedulePaymentInput, ScheduledPaymentRecord, SimulatedBankAdapter,
    TransferPreviewRequest, TransferPreviewResponse, TransferRecord, SubmitTransferRequest,
};
use dollar_types::{
    AccountClass, AccountId, ConversionId, CorrelationId, Currency, DomainError, IdempotencyKey,
    IssuanceId, PaymentId, PaymentRequestId, PrincipalId, Role, TransactionId, WalletStatus,
};
use serde::{Deserialize, Serialize};
use sqlx::{PgPool, Row};
use std::sync::Arc;
use tower_http::cors::CorsLayer;
use tower_http::trace::TraceLayer;
use utoipa::{OpenApi, ToSchema};
use uuid::Uuid;

#[derive(Clone)]
pub struct AppState {
    pub pool: PgPool,
    pub auth: AuthService,
    pub payment_signer: PaymentRequestSigner,
    pub bank_adapter: SimulatedBankAdapter,
    pub rate_limiter: Arc<RateLimiter>,
    pub require_distinct_issuance_approver: bool,
}

#[derive(Debug, Serialize, Deserialize, ToSchema)]
pub struct ApiErrorResponse {
    pub error_code: String,
    pub message: String,
    pub correlation_id: CorrelationId,
}

pub struct ApiError {
    pub domain: DomainError,
    pub correlation_id: CorrelationId,
}

impl IntoResponse for ApiError {
    fn into_response(self) -> Response {
        let status = StatusCode::from_u16(self.domain.http_status_code())
            .unwrap_or(StatusCode::INTERNAL_SERVER_ERROR);
        let safe_message = match &self.domain {
            DomainError::Storage(_) => "Internal persistence error".to_string(),
            other => other.to_string(),
        };
        let body = Json(ApiErrorResponse {
            error_code: self.domain.error_code().to_string(),
            message: safe_message,
            correlation_id: self.correlation_id,
        });
        let mut resp = (status, body).into_response();
        if let Ok(hv) = HeaderValue::from_str(&self.correlation_id.to_string()) {
            resp.headers_mut().insert("x-correlation-id", hv);
        }
        resp
    }
}

fn extract_correlation_id(headers: &HeaderMap) -> CorrelationId {
    headers
        .get("x-correlation-id")
        .and_then(|v| v.to_str().ok())
        .and_then(|s| s.parse::<CorrelationId>().ok())
        .unwrap_or_default()
}

fn extract_idempotency_key(
    headers: &HeaderMap,
    corr: CorrelationId,
) -> Result<IdempotencyKey, ApiError> {
    let raw = headers
        .get("idempotency-key")
        .and_then(|v| v.to_str().ok())
        .ok_or_else(|| ApiError {
            domain: DomainError::InvalidIdempotencyKey(
                "Missing required Idempotency-Key header".to_string(),
            ),
            correlation_id: corr,
        })?;
    IdempotencyKey::parse(raw).map_err(|d| ApiError {
        domain: d,
        correlation_id: corr,
    })
}

async fn authenticate(
    state: &AppState,
    headers: &HeaderMap,
    corr: CorrelationId,
) -> Result<AuthContext, ApiError> {
    let auth_hdr = headers
        .get("authorization")
        .and_then(|v| v.to_str().ok())
        .ok_or_else(|| ApiError {
            domain: DomainError::Unauthorized("Missing Authorization Bearer token".to_string()),
            correlation_id: corr,
        })?;

    let token = auth_hdr
        .strip_prefix("Bearer ")
        .or_else(|| auth_hdr.strip_prefix("bearer "))
        .ok_or_else(|| ApiError {
            domain: DomainError::Unauthorized("Expected Bearer authentication scheme".to_string()),
            correlation_id: corr,
        })?;

    let ctx = state
        .auth
        .authenticate_token(&state.pool, token)
        .await
        .map_err(|d| ApiError {
            domain: d,
            correlation_id: corr,
        })?;

    state
        .rate_limiter
        .check_and_record(&ctx.principal_id.to_string())
        .await
        .map_err(|d| ApiError {
            domain: d,
            correlation_id: corr,
        })?;

    Ok(ctx)
}

fn with_corr_json<T: Serialize>(
    status: StatusCode,
    corr: CorrelationId,
    payload: T,
) -> Response {
    let mut resp = (status, Json(payload)).into_response();
    if let Ok(hv) = HeaderValue::from_str(&corr.to_string()) {
        resp.headers_mut().insert("x-correlation-id", hv);
    }
    resp
}

// ============================================================================
// Request / Response DTOs
// ============================================================================

#[derive(Debug, Serialize, Deserialize, ToSchema)]
pub struct RegisterPrincipalRequest {
    pub username: String,
    pub password: String,
    /// Only CUSTOMER or MERCHANT may self-register via public onboarding.
    pub role: Role,
}

#[derive(Debug, Serialize, Deserialize, ToSchema)]
pub struct RegisterPrincipalResponse {
    pub principal_id: PrincipalId,
    pub username: String,
    pub role: Role,
}

#[derive(Debug, Serialize, Deserialize, ToSchema)]
pub struct LoginRequest {
    pub username: String,
    pub password: String,
}

#[derive(Debug, Serialize, Deserialize, ToSchema)]
pub struct LoginResponse {
    pub token: String,
    pub principal_id: PrincipalId,
    pub username: String,
    pub role: Role,
    pub expires_at: DateTime<Utc>,
}

#[derive(Debug, Serialize, Deserialize, ToSchema)]
pub struct CreateWalletRequest {
    pub account_class: AccountClass,
    pub currency: Currency,
}

#[derive(Debug, Serialize, Deserialize, ToSchema)]
pub struct UpdateWalletStatusRequest {
    pub status: WalletStatus,
}

#[derive(Debug, Deserialize)]
pub struct PaginationQuery {
    pub limit: Option<i64>,
    pub offset: Option<i64>,
}

#[derive(Debug, Serialize, Deserialize, ToSchema)]
pub struct HealthResponse {
    pub status: String,
    pub database: String,
    pub service: String,
    pub issuer_treasury_account_id: AccountId,
    pub timestamp: DateTime<Utc>,
}

#[derive(Debug, Serialize, Deserialize, ToSchema)]
pub struct AuditLogEntry {
    pub id: Uuid,
    pub actor_principal_id: Option<Uuid>,
    pub actor_role: String,
    pub action: String,
    pub target_type: String,
    pub target_id: String,
    pub correlation_id: Uuid,
    pub outcome: String,
    pub metadata_json: serde_json::Value,
    pub created_at: DateTime<Utc>,
}

// ============================================================================
// Route Handlers
// ============================================================================

#[utoipa::path(
    get,
    path = "/health",
    responses(
        (status = 200, description = "Service and DB health check", body = HealthResponse),
        (status = 500, description = "Database unavailable", body = ApiErrorResponse)
    )
)]
pub async fn health_handler(
    State(state): State<AppState>,
    headers: HeaderMap,
) -> Result<Response, ApiError> {
    let corr = extract_correlation_id(&headers);
    sqlx::query("SELECT 1")
        .execute(&state.pool)
        .await
        .map_err(|e| ApiError {
            domain: DomainError::Storage(e.to_string()),
            correlation_id: corr,
        })?;

    Ok(with_corr_json(
        StatusCode::OK,
        corr,
        HealthResponse {
            status: "ok".to_string(),
            database: "connected".to_string(),
            service: "digital-dollar-ledger".to_string(),
            issuer_treasury_account_id: AccountId::from_uuid(
                dollar_ledger::ISSUER_TREASURY_ACCOUNT_UUID,
            ),
            timestamp: Utc::now(),
        },
    ))
}

#[utoipa::path(
    post,
    path = "/v1/auth/register",
    request_body = RegisterPrincipalRequest,
    responses(
        (status = 201, body = RegisterPrincipalResponse),
        (status = 403, body = ApiErrorResponse)
    )
)]
pub async fn register_handler(
    State(state): State<AppState>,
    headers: HeaderMap,
    Json(req): Json<RegisterPrincipalRequest>,
) -> Result<Response, ApiError> {
    let corr = extract_correlation_id(&headers);
    if !matches!(req.role, Role::Customer | Role::Merchant) {
        return Err(ApiError {
            domain: DomainError::Forbidden(
                "Only CUSTOMER or MERCHANT principals can self-register".to_string(),
            ),
            correlation_id: corr,
        });
    }
    if req.username.trim().len() < 3 {
        return Err(ApiError {
            domain: DomainError::Validation("Username must be at least 3 chars".to_string()),
            correlation_id: corr,
        });
    }

    let pid = state
        .auth
        .create_principal(&state.pool, req.username.trim(), &req.password, req.role)
        .await
        .map_err(|d| ApiError {
            domain: d,
            correlation_id: corr,
        })?;

    Ok(with_corr_json(
        StatusCode::CREATED,
        corr,
        RegisterPrincipalResponse {
            principal_id: pid,
            username: req.username.trim().to_string(),
            role: req.role,
        },
    ))
}

#[utoipa::path(
    post,
    path = "/v1/auth/login",
    request_body = LoginRequest,
    responses(
        (status = 200, body = LoginResponse),
        (status = 401, body = ApiErrorResponse)
    )
)]
pub async fn login_handler(
    State(state): State<AppState>,
    headers: HeaderMap,
    Json(req): Json<LoginRequest>,
) -> Result<Response, ApiError> {
    let corr = extract_correlation_id(&headers);
    let (token, ctx) = state
        .auth
        .login(&state.pool, req.username.trim(), &req.password, corr)
        .await
        .map_err(|d| ApiError {
            domain: d,
            correlation_id: corr,
        })?;

    Ok(with_corr_json(
        StatusCode::OK,
        corr,
        LoginResponse {
            token,
            principal_id: ctx.principal_id,
            username: ctx.username,
            role: ctx.role,
            expires_at: ctx.expires_at,
        },
    ))
}

#[utoipa::path(
    post,
    path = "/v1/wallets",
    request_body = CreateWalletRequest,
    responses(
        (status = 201, body = WalletRecord),
        (status = 400, body = ApiErrorResponse),
        (status = 409, body = ApiErrorResponse)
    )
)]
pub async fn create_wallet_handler(
    State(state): State<AppState>,
    headers: HeaderMap,
    Json(req): Json<CreateWalletRequest>,
) -> Result<Response, ApiError> {
    let corr = extract_correlation_id(&headers);
    let ctx = authenticate(&state, &headers, corr).await?;
    let idem = extract_idempotency_key(&headers, corr)?;
    let payload_bytes = serde_json::to_vec(&req).map_err(|e| ApiError {
        domain: DomainError::Storage(e.to_string()),
        correlation_id: corr,
    })?;

    let mut tx = state.pool.begin().await.map_err(|e| ApiError {
        domain: DomainError::Storage(e.to_string()),
        correlation_id: corr,
    })?;
    if let Some((status, body)) = check_idempotency_in_tx(
        &mut tx,
        ctx.principal_id,
        "POST /v1/wallets",
        &idem,
        &payload_bytes,
    )
    .await
    .map_err(|d| ApiError {
        domain: d,
        correlation_id: corr,
    })? {
        tx.commit().await.map_err(|e| ApiError {
            domain: DomainError::Storage(e.to_string()),
            correlation_id: corr,
        })?;
        return Ok(with_corr_json(
            StatusCode::from_u16(status).unwrap_or(StatusCode::CREATED),
            corr,
            body,
        ));
    }
    tx.commit().await.map_err(|e| ApiError {
        domain: DomainError::Storage(e.to_string()),
        correlation_id: corr,
    })?;

    let wallet = create_wallet(
        &state.pool,
        ctx.principal_id,
        req.account_class,
        req.currency,
        corr,
    )
    .await
    .map_err(|d| ApiError {
        domain: d,
        correlation_id: corr,
    })?;

    let mut tx2 = state.pool.begin().await.map_err(|e| ApiError {
        domain: DomainError::Storage(e.to_string()),
        correlation_id: corr,
    })?;
    let body_json = serde_json::to_value(&wallet).map_err(|e| ApiError {
        domain: DomainError::Storage(e.to_string()),
        correlation_id: corr,
    })?;
    store_idempotency_in_tx(
        &mut tx2,
        ctx.principal_id,
        "POST /v1/wallets",
        &idem,
        &payload_bytes,
        201,
        &body_json,
        Some(wallet.account_id.as_uuid()),
    )
    .await
    .map_err(|d| ApiError {
        domain: d,
        correlation_id: corr,
    })?;
    tx2.commit().await.map_err(|e| ApiError {
        domain: DomainError::Storage(e.to_string()),
        correlation_id: corr,
    })?;

    Ok(with_corr_json(StatusCode::CREATED, corr, wallet))
}

#[utoipa::path(
    get,
    path = "/v1/wallets/{id}/balance",
    params(("id" = Uuid, Path, description = "Wallet account UUID")),
    responses(
        (status = 200, body = WalletRecord),
        (status = 403, body = ApiErrorResponse),
        (status = 404, body = ApiErrorResponse)
    )
)]
pub async fn get_wallet_balance_handler(
    State(state): State<AppState>,
    headers: HeaderMap,
    Path(id): Path<Uuid>,
) -> Result<Response, ApiError> {
    let corr = extract_correlation_id(&headers);
    let ctx = authenticate(&state, &headers, corr).await?;
    let rec = get_wallet_balance(&state.pool, &ctx, AccountId::from_uuid(id))
        .await
        .map_err(|d| ApiError {
            domain: d,
            correlation_id: corr,
        })?;
    Ok(with_corr_json(StatusCode::OK, corr, rec))
}

#[utoipa::path(
    get,
    path = "/v1/wallets/{id}/transactions",
    params(("id" = Uuid, Path, description = "Wallet account UUID")),
    responses((status = 200, body = [WalletTransactionItem]))
)]
pub async fn get_wallet_transactions_handler(
    State(state): State<AppState>,
    headers: HeaderMap,
    Path(id): Path<Uuid>,
    Query(page): Query<PaginationQuery>,
) -> Result<Response, ApiError> {
    let corr = extract_correlation_id(&headers);
    let ctx = authenticate(&state, &headers, corr).await?;
    let items = get_wallet_transactions(
        &state.pool,
        &ctx,
        AccountId::from_uuid(id),
        page.limit.unwrap_or(50),
        page.offset.unwrap_or(0),
    )
    .await
    .map_err(|d| ApiError {
        domain: d,
        correlation_id: corr,
    })?;
    Ok(with_corr_json(StatusCode::OK, corr, items))
}

#[utoipa::path(
    post,
    path = "/v1/wallets/{id}/status",
    params(("id" = Uuid, Path, description = "Wallet account UUID")),
    request_body = UpdateWalletStatusRequest,
    responses((status = 200, body = WalletRecord))
)]
pub async fn update_wallet_status_handler(
    State(state): State<AppState>,
    headers: HeaderMap,
    Path(id): Path<Uuid>,
    Json(req): Json<UpdateWalletStatusRequest>,
) -> Result<Response, ApiError> {
    let corr = extract_correlation_id(&headers);
    let ctx = authenticate(&state, &headers, corr).await?;
    let rec = update_wallet_status(&state.pool, &ctx, AccountId::from_uuid(id), req.status, corr)
        .await
        .map_err(|d| ApiError {
            domain: d,
            correlation_id: corr,
        })?;
    Ok(with_corr_json(StatusCode::OK, corr, rec))
}

#[utoipa::path(
    post,
    path = "/v1/transfers/preview",
    request_body = TransferPreviewRequest,
    responses((status = 200, body = TransferPreviewResponse))
)]
pub async fn preview_transfer_handler(
    State(state): State<AppState>,
    headers: HeaderMap,
    Json(req): Json<TransferPreviewRequest>,
) -> Result<Response, ApiError> {
    let corr = extract_correlation_id(&headers);
    let ctx = authenticate(&state, &headers, corr).await?;
    let preview = preview_transfer(&state.pool, &ctx, &req)
        .await
        .map_err(|d| ApiError {
            domain: d,
            correlation_id: corr,
        })?;
    Ok(with_corr_json(StatusCode::OK, corr, preview))
}

#[utoipa::path(
    post,
    path = "/v1/transfers",
    request_body = SubmitTransferRequest,
    responses(
        (status = 201, body = TransferRecord),
        (status = 409, body = ApiErrorResponse)
    )
)]
pub async fn submit_transfer_handler(
    State(state): State<AppState>,
    headers: HeaderMap,
    Json(req): Json<SubmitTransferRequest>,
) -> Result<Response, ApiError> {
    let corr = extract_correlation_id(&headers);
    let ctx = authenticate(&state, &headers, corr).await?;
    let idem = extract_idempotency_key(&headers, corr)?;
    let (code, rec) = submit_transfer(&state.pool, &ctx, &idem, &req, corr)
        .await
        .map_err(|d| ApiError {
            domain: d,
            correlation_id: corr,
        })?;
    Ok(with_corr_json(
        StatusCode::from_u16(code).unwrap_or(StatusCode::CREATED),
        corr,
        rec,
    ))
}

#[utoipa::path(
    get,
    path = "/v1/transfers/{id}",
    params(("id" = Uuid, Path, description = "Transfer instruction UUID")),
    responses((status = 200, body = TransferRecord))
)]
pub async fn get_transfer_handler(
    State(state): State<AppState>,
    headers: HeaderMap,
    Path(id): Path<Uuid>,
) -> Result<Response, ApiError> {
    let corr = extract_correlation_id(&headers);
    let ctx = authenticate(&state, &headers, corr).await?;
    let rec = get_transfer(&state.pool, &ctx, TransactionId::from_uuid(id))
        .await
        .map_err(|d| ApiError {
            domain: d,
            correlation_id: corr,
        })?;
    Ok(with_corr_json(StatusCode::OK, corr, rec))
}

#[utoipa::path(
    post,
    path = "/v1/payment-requests",
    request_body = CreatePaymentRequestInput,
    responses((status = 201, body = PaymentRequestRecord))
)]
pub async fn create_payment_request_handler(
    State(state): State<AppState>,
    headers: HeaderMap,
    Json(req): Json<CreatePaymentRequestInput>,
) -> Result<Response, ApiError> {
    let corr = extract_correlation_id(&headers);
    let ctx = authenticate(&state, &headers, corr).await?;
    let idem = extract_idempotency_key(&headers, corr)?;
    let (code, rec) = create_payment_request(
        &state.pool,
        &ctx,
        &state.payment_signer,
        &idem,
        &req,
        corr,
    )
    .await
    .map_err(|d| ApiError {
        domain: d,
        correlation_id: corr,
    })?;
    Ok(with_corr_json(
        StatusCode::from_u16(code).unwrap_or(StatusCode::CREATED),
        corr,
        rec,
    ))
}

#[utoipa::path(
    post,
    path = "/v1/payment-requests/{id}/pay",
    params(("id" = Uuid, Path, description = "Payment request UUID")),
    request_body = PayPaymentRequestInput,
    responses((status = 201, body = PaymentRecord))
)]
pub async fn pay_payment_request_handler(
    State(state): State<AppState>,
    headers: HeaderMap,
    Path(id): Path<Uuid>,
    Json(req): Json<PayPaymentRequestInput>,
) -> Result<Response, ApiError> {
    let corr = extract_correlation_id(&headers);
    let ctx = authenticate(&state, &headers, corr).await?;
    let idem = extract_idempotency_key(&headers, corr)?;
    let (code, rec) = pay_payment_request(
        &state.pool,
        &ctx,
        &state.payment_signer,
        PaymentRequestId::from_uuid(id),
        &idem,
        &req,
        corr,
    )
    .await
    .map_err(|d| ApiError {
        domain: d,
        correlation_id: corr,
    })?;
    Ok(with_corr_json(
        StatusCode::from_u16(code).unwrap_or(StatusCode::CREATED),
        corr,
        rec,
    ))
}

#[utoipa::path(
    post,
    path = "/v1/payments/{id}/refunds",
    params(("id" = Uuid, Path, description = "Settled payment UUID")),
    request_body = CreateRefundInput,
    responses((status = 201, body = RefundRecord))
)]
pub async fn refund_payment_handler(
    State(state): State<AppState>,
    headers: HeaderMap,
    Path(id): Path<Uuid>,
    Json(req): Json<CreateRefundInput>,
) -> Result<Response, ApiError> {
    let corr = extract_correlation_id(&headers);
    let ctx = authenticate(&state, &headers, corr).await?;
    let idem = extract_idempotency_key(&headers, corr)?;
    let (code, rec) = refund_payment(
        &state.pool,
        &ctx,
        PaymentId::from_uuid(id),
        &idem,
        &req,
        corr,
    )
    .await
    .map_err(|d| ApiError {
        domain: d,
        correlation_id: corr,
    })?;
    Ok(with_corr_json(
        StatusCode::from_u16(code).unwrap_or(StatusCode::CREATED),
        corr,
        rec,
    ))
}

#[utoipa::path(
    post,
    path = "/v1/scheduled-payments",
    request_body = SchedulePaymentInput,
    responses((status = 201, body = ScheduledPaymentRecord))
)]
pub async fn create_scheduled_payment_handler(
    State(state): State<AppState>,
    headers: HeaderMap,
    Json(req): Json<SchedulePaymentInput>,
) -> Result<Response, ApiError> {
    let corr = extract_correlation_id(&headers);
    let ctx = authenticate(&state, &headers, corr).await?;
    let idem = extract_idempotency_key(&headers, corr)?;
    let rec = create_scheduled_payment(&state.pool, &ctx, &idem, &req)
        .await
        .map_err(|d| ApiError {
            domain: d,
            correlation_id: corr,
        })?;
    Ok(with_corr_json(StatusCode::CREATED, corr, rec))
}

#[utoipa::path(
    post,
    path = "/v1/conversions",
    request_body = CreateConversionRequest,
    responses((status = 201, body = ConversionRecord))
)]
pub async fn create_conversion_handler(
    State(state): State<AppState>,
    headers: HeaderMap,
    Json(req): Json<CreateConversionRequest>,
) -> Result<Response, ApiError> {
    let corr = extract_correlation_id(&headers);
    let ctx = authenticate(&state, &headers, corr).await?;
    let idem = extract_idempotency_key(&headers, corr)?;
    let (code, rec) = create_conversion(
        &state.pool,
        &ctx,
        &state.bank_adapter,
        &idem,
        &req,
        corr,
    )
    .await
    .map_err(|d| ApiError {
        domain: d,
        correlation_id: corr,
    })?;
    Ok(with_corr_json(
        StatusCode::from_u16(code).unwrap_or(StatusCode::CREATED),
        corr,
        rec,
    ))
}

#[utoipa::path(
    get,
    path = "/v1/conversions/{id}",
    params(("id" = Uuid, Path, description = "Conversion request UUID")),
    responses((status = 200, body = ConversionRecord))
)]
pub async fn get_conversion_handler(
    State(state): State<AppState>,
    headers: HeaderMap,
    Path(id): Path<Uuid>,
) -> Result<Response, ApiError> {
    let corr = extract_correlation_id(&headers);
    let ctx = authenticate(&state, &headers, corr).await?;
    let rec = get_conversion(&state.pool, &ctx, ConversionId::from_uuid(id))
        .await
        .map_err(|d| ApiError {
            domain: d,
            correlation_id: corr,
        })?;
    Ok(with_corr_json(StatusCode::OK, corr, rec))
}

#[utoipa::path(
    post,
    path = "/v1/issuer/issuance-requests",
    request_body = CreateIssuanceRequest,
    responses((status = 201, body = IssuanceRecord))
)]
pub async fn request_issuance_handler(
    State(state): State<AppState>,
    headers: HeaderMap,
    Json(req): Json<CreateIssuanceRequest>,
) -> Result<Response, ApiError> {
    let corr = extract_correlation_id(&headers);
    let ctx = authenticate(&state, &headers, corr).await?;
    let idem = extract_idempotency_key(&headers, corr)?;
    let (code, rec) = request_issuance(&state.pool, &ctx, &idem, &req, corr)
        .await
        .map_err(|d| ApiError {
            domain: d,
            correlation_id: corr,
        })?;
    Ok(with_corr_json(
        StatusCode::from_u16(code).unwrap_or(StatusCode::CREATED),
        corr,
        rec,
    ))
}

#[utoipa::path(
    post,
    path = "/v1/issuer/issuance-requests/{id}/approve",
    params(("id" = Uuid, Path, description = "Issuance request UUID")),
    request_body = ApproveIssuanceRequest,
    responses((status = 200, body = IssuanceRecord))
)]
pub async fn approve_issuance_handler(
    State(state): State<AppState>,
    headers: HeaderMap,
    Path(id): Path<Uuid>,
    Json(req): Json<ApproveIssuanceRequest>,
) -> Result<Response, ApiError> {
    let corr = extract_correlation_id(&headers);
    let ctx = authenticate(&state, &headers, corr).await?;
    let idem = extract_idempotency_key(&headers, corr)?;
    let (code, rec) = approve_issuance(
        &state.pool,
        &ctx,
        IssuanceId::from_uuid(id),
        &idem,
        &req,
        state.require_distinct_issuance_approver,
        corr,
    )
    .await
    .map_err(|d| ApiError {
        domain: d,
        correlation_id: corr,
    })?;
    Ok(with_corr_json(
        StatusCode::from_u16(code).unwrap_or(StatusCode::OK),
        corr,
        rec,
    ))
}

#[utoipa::path(
    get,
    path = "/v1/reconciliation",
    responses((status = 200, body = ReconciliationReport))
)]
pub async fn reconciliation_handler(
    State(state): State<AppState>,
    headers: HeaderMap,
) -> Result<Response, ApiError> {
    let corr = extract_correlation_id(&headers);
    let ctx = authenticate(&state, &headers, corr).await?;
    require_role(
        &ctx,
        &[
            Role::Auditor,
            Role::IssuerOperator,
            Role::IssuerApprover,
            Role::SystemAdmin,
        ],
    )
    .map_err(|d| ApiError {
        domain: d,
        correlation_id: corr,
    })?;

    let report = run_reconciliation(&state.pool, "API_ON_DEMAND")
        .await
        .map_err(|d| ApiError {
            domain: d,
            correlation_id: corr,
        })?;
    Ok(with_corr_json(StatusCode::OK, corr, report))
}

#[utoipa::path(
    get,
    path = "/v1/audit-logs",
    responses((status = 200, body = [AuditLogEntry]))
)]
pub async fn audit_logs_handler(
    State(state): State<AppState>,
    headers: HeaderMap,
    Query(page): Query<PaginationQuery>,
) -> Result<Response, ApiError> {
    let corr = extract_correlation_id(&headers);
    let ctx = authenticate(&state, &headers, corr).await?;
    require_role(
        &ctx,
        &[Role::Auditor, Role::FraudReviewer, Role::SystemAdmin],
    )
    .map_err(|d| ApiError {
        domain: d,
        correlation_id: corr,
    })?;

    let limit = page.limit.unwrap_or(50).clamp(1, 200);
    let offset = page.offset.unwrap_or(0).max(0);
    let rows = sqlx::query(
        r#"
        SELECT id, actor_principal_id, actor_role, action, target_type,
               target_id, correlation_id, outcome, metadata_json, created_at
        FROM audit_logs
        ORDER BY created_at DESC
        LIMIT $1 OFFSET $2
        "#,
    )
    .bind(limit)
    .bind(offset)
    .fetch_all(&state.pool)
    .await
    .map_err(|e| ApiError {
        domain: DomainError::Storage(e.to_string()),
        correlation_id: corr,
    })?;

    let entries: Vec<AuditLogEntry> = rows
        .into_iter()
        .map(|r| AuditLogEntry {
            id: r.get("id"),
            actor_principal_id: r.get("actor_principal_id"),
            actor_role: r.get("actor_role"),
            action: r.get("action"),
            target_type: r.get("target_type"),
            target_id: r.get("target_id"),
            correlation_id: r.get("correlation_id"),
            outcome: r.get("outcome"),
            metadata_json: r.get("metadata_json"),
            created_at: r.get("created_at"),
        })
        .collect();

    Ok(with_corr_json(StatusCode::OK, corr, entries))
}

#[derive(OpenApi)]
#[openapi(
    paths(
        health_handler,
        register_handler,
        login_handler,
        create_wallet_handler,
        get_wallet_balance_handler,
        get_wallet_transactions_handler,
        update_wallet_status_handler,
        preview_transfer_handler,
        submit_transfer_handler,
        get_transfer_handler,
        create_payment_request_handler,
        pay_payment_request_handler,
        refund_payment_handler,
        create_scheduled_payment_handler,
        create_conversion_handler,
        get_conversion_handler,
        request_issuance_handler,
        approve_issuance_handler,
        reconciliation_handler,
        audit_logs_handler,
    ),
    components(schemas(
        ApiErrorResponse,
        HealthResponse,
        RegisterPrincipalRequest,
        RegisterPrincipalResponse,
        LoginRequest,
        LoginResponse,
        CreateWalletRequest,
        UpdateWalletStatusRequest,
        WalletRecord,
        WalletTransactionItem,
        TransferPreviewRequest,
        TransferPreviewResponse,
        SubmitTransferRequest,
        TransferRecord,
        CreatePaymentRequestInput,
        PaymentRequestRecord,
        PayPaymentRequestInput,
        PaymentRecord,
        CreateRefundInput,
        RefundRecord,
        SchedulePaymentInput,
        ScheduledPaymentRecord,
        CreateConversionRequest,
        ConversionRecord,
        CreateIssuanceRequest,
        ApproveIssuanceRequest,
        IssuanceRecord,
        ReconciliationReport,
        AuditLogEntry,
    )),
    info(
        title = "DIGITAL DOLLAR — USD Ledger API",
        version = "0.1.0",
        description = "Authoritative double-entry digital-dollar ledger API with issuance dual-control, idempotent transfers, signed merchant payment requests, refunds, simulated bank conversions, and supply reconciliation."
    )
)]
pub struct ApiDoc;

pub async fn openapi_handler() -> Json<utoipa::openapi::OpenApi> {
    Json(ApiDoc::openapi())
}

pub fn build_router(state: AppState) -> Router {
    Router::new()
        .route("/health", get(health_handler))
        .route("/openapi.json", get(openapi_handler))
        .route("/v1/auth/register", post(register_handler))
        .route("/v1/auth/login", post(login_handler))
        .route("/v1/wallets", post(create_wallet_handler))
        .route("/v1/wallets/{id}/balance", get(get_wallet_balance_handler))
        .route(
            "/v1/wallets/{id}/transactions",
            get(get_wallet_transactions_handler),
        )
        .route("/v1/wallets/{id}/status", post(update_wallet_status_handler))
        .route("/v1/transfers/preview", post(preview_transfer_handler))
        .route("/v1/transfers", post(submit_transfer_handler))
        .route("/v1/transfers/{id}", get(get_transfer_handler))
        .route("/v1/payment-requests", post(create_payment_request_handler))
        .route(
            "/v1/payment-requests/{id}/pay",
            post(pay_payment_request_handler),
        )
        .route("/v1/payments/{id}/refunds", post(refund_payment_handler))
        .route(
            "/v1/scheduled-payments",
            post(create_scheduled_payment_handler),
        )
        .route("/v1/conversions", post(create_conversion_handler))
        .route("/v1/conversions/{id}", get(get_conversion_handler))
        .route(
            "/v1/issuer/issuance-requests",
            post(request_issuance_handler),
        )
        .route(
            "/v1/issuer/issuance-requests/{id}/approve",
            post(approve_issuance_handler),
        )
        .route("/v1/reconciliation", get(reconciliation_handler))
        .route("/v1/audit-logs", get(audit_logs_handler))
        .layer(TraceLayer::new_for_http())
        .layer(CorsLayer::permissive())
        .with_state(state)
}

/// Runs one tick of background outbox publishing, reservation expiry, scheduled payments,
/// and pending conversion recovery.
pub async fn run_background_tick(state: &AppState) -> Result<(), DomainError> {
    let _ = expire_overdue_reservations(&state.pool).await?;
    let _ = execute_due_scheduled_payments(&state.pool).await?;
    let _ = recover_pending_conversions(&state.pool, &state.bank_adapter).await?;
    publish_pending_outbox_events(&state.pool).await?;
    Ok(())
}

async fn publish_pending_outbox_events(pool: &PgPool) -> Result<u64, DomainError> {
    let mut tx = pool.begin().await.map_err(|e| DomainError::Storage(e.to_string()))?;
    let rows = sqlx::query(
        r#"
        SELECT id, event_type, aggregate_type, aggregate_id, attempts
        FROM outbox_events
        WHERE status = 'PENDING' AND next_attempt_at <= NOW()
        ORDER BY created_at ASC
        LIMIT 50
        FOR UPDATE SKIP LOCKED
        "#,
    )
    .fetch_all(&mut *tx)
    .await
    .map_err(|e| DomainError::Storage(e.to_string()))?;

    let mut published = 0u64;
    for row in rows {
        let id: Uuid = row.get("id");
        let event_type: String = row.get("event_type");
        let aggregate_id: Uuid = row.get("aggregate_id");
        tracing::info!(
            event_id = %id,
            event_type = %event_type,
            aggregate_id = %aggregate_id,
            "Outbox event published"
        );
        sqlx::query(
            "UPDATE outbox_events SET status = 'PUBLISHED', published_at = NOW(), attempts = attempts + 1 WHERE id = $1",
        )
        .bind(id)
        .execute(&mut *tx)
        .await
        .map_err(|e| DomainError::Storage(e.to_string()))?;
        published += 1;
    }

    tx.commit().await.map_err(|e| DomainError::Storage(e.to_string()))?;
    Ok(published)
}
