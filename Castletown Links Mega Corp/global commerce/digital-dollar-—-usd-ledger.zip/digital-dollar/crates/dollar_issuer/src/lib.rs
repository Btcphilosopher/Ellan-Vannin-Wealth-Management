use chrono::{DateTime, Utc};
use dollar_auth::{record_audit_event, require_role, AuthContext};
use dollar_ledger::{
    check_idempotency_in_tx, post_journal_in_tx, store_idempotency_in_tx, JournalEntryType,
    OutboxProposal, PostJournalRequest, ProposedJournalLine, ISSUANCE_CONTROL_ACCOUNT_UUID,
    ISSUER_TREASURY_ACCOUNT_UUID,
};
use dollar_types::{
    AccountId, CorrelationId, Currency, DomainError, EntryDirection, IdempotencyKey,
    IssuanceAuthorisation, IssuanceId, JournalId, Money, PrincipalId, Role,
};
use serde::{Deserialize, Serialize};
use sqlx::{PgPool, Row};
use std::str::FromStr;
use utoipa::ToSchema;
use uuid::Uuid;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, ToSchema)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum FundingClassification {
    /// Explicit research/testing unit allocation without external bank backing claims.
    TestAllocation,
    /// Issuance linked to a simulated external funding record (never a real bank settlement).
    SimulatedExternalFunding,
}

impl FundingClassification {
    pub fn as_str(self) -> &'static str {
        match self {
            FundingClassification::TestAllocation => "TEST_ALLOCATION",
            FundingClassification::SimulatedExternalFunding => "SIMULATED_EXTERNAL_FUNDING",
        }
    }
}

impl FromStr for FundingClassification {
    type Err = DomainError;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        match s {
            "TEST_ALLOCATION" => Ok(FundingClassification::TestAllocation),
            "SIMULATED_EXTERNAL_FUNDING" => Ok(FundingClassification::SimulatedExternalFunding),
            other => Err(DomainError::Validation(format!(
                "Unknown funding_classification: {other}"
            ))),
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, ToSchema)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum IssuanceStatus {
    Requested,
    Reviewed,
    Approved,
    Posted,
    Reconciled,
    Rejected,
}

impl IssuanceStatus {
    pub fn as_str(self) -> &'static str {
        match self {
            IssuanceStatus::Requested => "REQUESTED",
            IssuanceStatus::Reviewed => "REVIEWED",
            IssuanceStatus::Approved => "APPROVED",
            IssuanceStatus::Posted => "POSTED",
            IssuanceStatus::Reconciled => "RECONCILED",
            IssuanceStatus::Rejected => "REJECTED",
        }
    }
}

impl FromStr for IssuanceStatus {
    type Err = DomainError;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        match s {
            "REQUESTED" => Ok(IssuanceStatus::Requested),
            "REVIEWED" => Ok(IssuanceStatus::Reviewed),
            "APPROVED" => Ok(IssuanceStatus::Approved),
            "POSTED" => Ok(IssuanceStatus::Posted),
            "RECONCILED" => Ok(IssuanceStatus::Reconciled),
            "REJECTED" => Ok(IssuanceStatus::Rejected),
            other => Err(DomainError::InvalidState(format!(
                "Unknown issuance status: {other}"
            ))),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct CreateIssuanceRequest {
    pub amount_cents: i64,
    pub currency: Currency,
    pub funding_classification: FundingClassification,
    pub purpose: String,
    pub supporting_reference: String,
    pub external_funding_reference: Option<String>,
    /// Defaults to the system ISSUER_TREASURY account when omitted.
    pub destination_account_id: Option<AccountId>,
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct ApproveIssuanceRequest {
    /// Optional review note; if issuance is still REQUESTED, reviewer/approver advances it
    /// through REVIEWED -> APPROVED -> POSTED -> RECONCILED.
    pub review_note: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct IssuanceRecord {
    pub id: IssuanceId,
    pub funding_classification: FundingClassification,
    pub amount_cents: i64,
    pub currency: Currency,
    pub purpose: String,
    pub supporting_reference: String,
    pub external_funding_reference: Option<String>,
    pub status: IssuanceStatus,
    pub requested_by: PrincipalId,
    pub reviewed_by: Option<PrincipalId>,
    pub approved_by: Option<PrincipalId>,
    pub destination_account_id: AccountId,
    pub journal_id: Option<JournalId>,
    pub authorisation: Option<IssuanceAuthorisation>,
    pub created_at: DateTime<Utc>,
    pub reviewed_at: Option<DateTime<Utc>>,
    pub approved_at: Option<DateTime<Utc>>,
    pub posted_at: Option<DateTime<Utc>>,
    pub reconciled_at: Option<DateTime<Utc>>,
}

/// Requests creation of test USD units. Restricted to IssuerOperator or SystemAdmin.
pub async fn request_issuance(
    pool: &PgPool,
    ctx: &AuthContext,
    idempotency_key: &IdempotencyKey,
    req: &CreateIssuanceRequest,
    correlation_id: CorrelationId,
) -> Result<(u16, IssuanceRecord), DomainError> {
    require_role(ctx, &[Role::IssuerOperator, Role::SystemAdmin])?;

    let money = Money::from_positive_cents(req.amount_cents, req.currency)?;
    if req.purpose.trim().is_empty() || req.supporting_reference.trim().is_empty() {
        return Err(DomainError::Validation(
            "Issuance purpose and supporting_reference are required".to_string(),
        ));
    }

    if req.funding_classification == FundingClassification::SimulatedExternalFunding
        && req
            .external_funding_reference
            .as_deref()
            .unwrap_or("")
            .trim()
            .is_empty()
    {
        return Err(DomainError::Validation(
            "SIMULATED_EXTERNAL_FUNDING requires external_funding_reference (non-authoritative simulation ref)".to_string(),
        ));
    }

    let destination_account = req
        .destination_account_id
        .unwrap_or_else(|| AccountId::from_uuid(ISSUER_TREASURY_ACCOUNT_UUID));

    let payload_bytes = serde_json::to_vec(req).map_err(|e| DomainError::Storage(e.to_string()))?;
    let mut tx = pool.begin().await.map_err(|e| DomainError::Storage(e.to_string()))?;

    if let Some((status, body)) = check_idempotency_in_tx(
        &mut tx,
        ctx.principal_id,
        "POST /v1/issuer/issuance-requests",
        idempotency_key,
        &payload_bytes,
    )
    .await?
    {
        let rec: IssuanceRecord =
            serde_json::from_value(body).map_err(|e| DomainError::Storage(e.to_string()))?;
        tx.commit().await.map_err(|e| DomainError::Storage(e.to_string()))?;
        return Ok((status, rec));
    }

    let issuance_id = IssuanceId::new();
    let row = sqlx::query(
        r#"
        INSERT INTO issuance_requests (
            id, idempotency_key, funding_classification, amount_cents, currency,
            purpose, supporting_reference, external_funding_reference,
            status, requested_by, destination_account_id
        ) VALUES ($1, $2, $3, $4, 'USD', $5, $6, $7, 'REQUESTED', $8, $9)
        RETURNING created_at
        "#,
    )
    .bind(issuance_id.as_uuid())
    .bind(idempotency_key.as_str())
    .bind(req.funding_classification.as_str())
    .bind(money.cents())
    .bind(req.purpose.trim())
    .bind(req.supporting_reference.trim())
    .bind(req.external_funding_reference.as_deref().map(str::trim))
    .bind(ctx.principal_id.as_uuid())
    .bind(destination_account.as_uuid())
    .fetch_one(&mut *tx)
    .await
    .map_err(|e| DomainError::Storage(format!("Failed to insert issuance request: {e}")))?;

    let record = IssuanceRecord {
        id: issuance_id,
        funding_classification: req.funding_classification,
        amount_cents: money.cents(),
        currency: Currency::Usd,
        purpose: req.purpose.trim().to_string(),
        supporting_reference: req.supporting_reference.trim().to_string(),
        external_funding_reference: req.external_funding_reference.clone(),
        status: IssuanceStatus::Requested,
        requested_by: ctx.principal_id,
        reviewed_by: None,
        approved_by: None,
        destination_account_id: destination_account,
        journal_id: None,
        authorisation: None,
        created_at: row.get("created_at"),
        reviewed_at: None,
        approved_at: None,
        posted_at: None,
        reconciled_at: None,
    };

    record_audit_event(
        &mut tx,
        Some(ctx.principal_id),
        ctx.role.as_str(),
        "ISSUANCE_REQUESTED",
        "ISSUANCE_REQUEST",
        &issuance_id.to_string(),
        correlation_id,
        "SUCCESS",
        serde_json::json!({
            "amount_cents": money.cents(),
            "classification": req.funding_classification.as_str(),
            "supporting_reference": req.supporting_reference,
        }),
    )
    .await?;

    let body_json =
        serde_json::to_value(&record).map_err(|e| DomainError::Storage(e.to_string()))?;
    store_idempotency_in_tx(
        &mut tx,
        ctx.principal_id,
        "POST /v1/issuer/issuance-requests",
        idempotency_key,
        &payload_bytes,
        201,
        &body_json,
        Some(issuance_id.as_uuid()),
    )
    .await?;

    tx.commit().await.map_err(|e| DomainError::Storage(e.to_string()))?;
    Ok((201, record))
}

/// Approves, posts, and reconciles an issuance request.
/// Enforces `IssuerApprover` (or `SystemAdmin`) role and distinct approval authority
/// (`approved_by != requested_by`) when `require_distinct_approver` is true.
pub async fn approve_issuance(
    pool: &PgPool,
    ctx: &AuthContext,
    issuance_id: IssuanceId,
    idempotency_key: &IdempotencyKey,
    req: &ApproveIssuanceRequest,
    require_distinct_approver: bool,
    correlation_id: CorrelationId,
) -> Result<(u16, IssuanceRecord), DomainError> {
    require_role(ctx, &[Role::IssuerApprover, Role::SystemAdmin])?;

    let endpoint = format!("POST /v1/issuer/issuance-requests/{issuance_id}/approve");
    let payload_bytes = serde_json::to_vec(req).map_err(|e| DomainError::Storage(e.to_string()))?;

    let mut tx = pool.begin().await.map_err(|e| DomainError::Storage(e.to_string()))?;

    if let Some((status, body)) = check_idempotency_in_tx(
        &mut tx,
        ctx.principal_id,
        &endpoint,
        idempotency_key,
        &payload_bytes,
    )
    .await?
    {
        let rec: IssuanceRecord =
            serde_json::from_value(body).map_err(|e| DomainError::Storage(e.to_string()))?;
        tx.commit().await.map_err(|e| DomainError::Storage(e.to_string()))?;
        return Ok((status, rec));
    }

    let row = sqlx::query(
        r#"
        SELECT
            id, funding_classification, amount_cents, purpose, supporting_reference,
            external_funding_reference, status, requested_by, reviewed_by, approved_by,
            destination_account_id, journal_id, created_at, reviewed_at, approved_at,
            posted_at, reconciled_at
        FROM issuance_requests
        WHERE id = $1
        FOR UPDATE
        "#,
    )
    .bind(issuance_id.as_uuid())
    .fetch_optional(&mut *tx)
    .await
    .map_err(|e| DomainError::Storage(e.to_string()))?
    .ok_or_else(|| DomainError::NotFound(format!("Issuance request {issuance_id}")))?;

    let current_status = IssuanceStatus::from_str(&row.get::<String, _>("status"))?;
    let requested_by = PrincipalId::from_uuid(row.get("requested_by"));

    if require_distinct_approver && requested_by == ctx.principal_id {
        return Err(DomainError::Forbidden(
            "Distinct approval authority required: requester cannot approve their own issuance".to_string(),
        ));
    }

    // Prevent duplicate minting if already posted/reconciled.
    if matches!(
        current_status,
        IssuanceStatus::Posted | IssuanceStatus::Reconciled
    ) {
        return Err(DomainError::InvalidState(format!(
            "Issuance {issuance_id} is already {:?}",
            current_status
        )));
    }
    if current_status == IssuanceStatus::Rejected {
        return Err(DomainError::InvalidState(
            "Rejected issuance cannot be approved".to_string(),
        ));
    }

    let amount_cents: i64 = row.get("amount_cents");
    let money = Money::from_positive_cents(amount_cents, Currency::Usd)?;
    let destination_account_id = AccountId::from_uuid(row.get("destination_account_id"));
    let classification =
        FundingClassification::from_str(&row.get::<String, _>("funding_classification"))?;

    // Advance lifecycle: Requested -> Reviewed -> Approved -> Posted -> Reconciled
    let now = Utc::now();
    let reviewed_by = row
        .get::<Option<Uuid>, _>("reviewed_by")
        .map(PrincipalId::from_uuid)
        .unwrap_or(ctx.principal_id);
    let reviewed_at = row
        .get::<Option<DateTime<Utc>>, _>("reviewed_at")
        .unwrap_or(now);

    let journal_id = post_journal_in_tx(
        &mut tx,
        PostJournalRequest {
            entry_type: JournalEntryType::Issuance,
            transaction_ref: format!("ISSUANCE:{issuance_id}"),
            correlation_id,
            reversal_of_journal_id: None,
            created_by: ctx.principal_id,
            description_code: format!("ISSUANCE_{}", classification.as_str()),
            lines: vec![
                ProposedJournalLine {
                    account_id: AccountId::from_uuid(ISSUANCE_CONTROL_ACCOUNT_UUID),
                    direction: EntryDirection::Debit,
                    amount: money,
                },
                ProposedJournalLine {
                    account_id: destination_account_id,
                    direction: EntryDirection::Credit,
                    amount: money,
                },
            ],
            consume_reservation_id: None,
            outbox_event: Some(OutboxProposal {
                aggregate_type: "ISSUANCE".to_string(),
                aggregate_id: issuance_id.as_uuid(),
                event_type: "IssuancePosted".to_string(),
                payload: serde_json::json!({
                    "issuance_id": issuance_id,
                    "amount_cents": amount_cents,
                    "destination_account_id": destination_account_id,
                    "classification": classification.as_str(),
                }),
            }),
        },
    )
    .await?;

    sqlx::query(
        r#"
        UPDATE issuance_requests
        SET status = 'RECONCILED',
            reviewed_by = $2,
            reviewed_at = $3,
            approved_by = $4,
            approved_at = $5,
            posted_at = $5,
            reconciled_at = $5,
            journal_id = $6
        WHERE id = $1
        "#,
    )
    .bind(issuance_id.as_uuid())
    .bind(reviewed_by.as_uuid())
    .bind(reviewed_at)
    .bind(ctx.principal_id.as_uuid())
    .bind(now)
    .bind(journal_id.as_uuid())
    .execute(&mut *tx)
    .await
    .map_err(|e| DomainError::Storage(e.to_string()))?;

    let authorisation = IssuanceAuthorisation {
        issuance_id,
        approved_by: ctx.principal_id,
        requested_by,
        amount_cents,
        currency: Currency::Usd,
        approved_at: now,
    };

    let record = IssuanceRecord {
        id: issuance_id,
        funding_classification: classification,
        amount_cents,
        currency: Currency::Usd,
        purpose: row.get("purpose"),
        supporting_reference: row.get("supporting_reference"),
        external_funding_reference: row.get("external_funding_reference"),
        status: IssuanceStatus::Reconciled,
        requested_by,
        reviewed_by: Some(reviewed_by),
        approved_by: Some(ctx.principal_id),
        destination_account_id,
        journal_id: Some(journal_id),
        authorisation: Some(authorisation),
        created_at: row.get("created_at"),
        reviewed_at: Some(reviewed_at),
        approved_at: Some(now),
        posted_at: Some(now),
        reconciled_at: Some(now),
    };

    record_audit_event(
        &mut tx,
        Some(ctx.principal_id),
        ctx.role.as_str(),
        "ISSUANCE_APPROVED_AND_POSTED",
        "ISSUANCE_REQUEST",
        &issuance_id.to_string(),
        correlation_id,
        "SUCCESS",
        serde_json::json!({
            "amount_cents": amount_cents,
            "journal_id": journal_id,
            "requested_by": requested_by,
            "approved_by": ctx.principal_id,
        }),
    )
    .await?;

    let body_json =
        serde_json::to_value(&record).map_err(|e| DomainError::Storage(e.to_string()))?;
    store_idempotency_in_tx(
        &mut tx,
        ctx.principal_id,
        &endpoint,
        idempotency_key,
        &payload_bytes,
        200,
        &body_json,
        Some(issuance_id.as_uuid()),
    )
    .await?;

    tx.commit().await.map_err(|e| DomainError::Storage(e.to_string()))?;
    Ok((200, record))
}
