use anyhow::{bail, Context};
use clap::{Parser, Subcommand};
use dollar_types::{Currency, Money};
use reqwest::Client;
use serde_json::{json, Value};
use uuid::Uuid;

#[derive(Parser)]
#[command(
    name = "dollar-cli",
    about = "CLI client for DIGITAL DOLLAR — USD Ledger API"
)]
struct Cli {
    #[arg(long, env = "DOLLAR_API_URL", default_value = "http://localhost:8080")]
    api_url: String,

    #[arg(long, env = "DOLLAR_TOKEN")]
    token: Option<String>,

    #[command(subcommand)]
    command: Commands,
}

#[derive(Subcommand)]
enum Commands {
    Health,
    Register {
        #[arg(long)]
        username: String,
        #[arg(long)]
        password: String,
        #[arg(long, default_value = "CUSTOMER")]
        role: String,
    },
    Login {
        #[arg(long)]
        username: String,
        #[arg(long)]
        password: String,
    },
    CreateWallet {
        #[arg(long, default_value = "CUSTOMER_WALLET")]
        class: String,
        #[arg(long)]
        idempotency_key: Option<String>,
    },
    Balance {
        #[arg(long)]
        wallet_id: Uuid,
    },
    Transactions {
        #[arg(long)]
        wallet_id: Uuid,
        #[arg(long, default_value_t = 50)]
        limit: i64,
    },
    PreviewTransfer {
        #[arg(long)]
        from: Uuid,
        #[arg(long)]
        to: Uuid,
        #[arg(long)]
        amount: String,
        #[arg(long)]
        reference: String,
    },
    Transfer {
        #[arg(long)]
        from: Uuid,
        #[arg(long)]
        to: Uuid,
        #[arg(long)]
        amount: String,
        #[arg(long)]
        reference: String,
        #[arg(long)]
        idempotency_key: Option<String>,
    },
    GetTransfer {
        #[arg(long)]
        transfer_id: Uuid,
    },
    CreatePaymentRequest {
        #[arg(long)]
        merchant_wallet: Uuid,
        #[arg(long)]
        order_ref: String,
        #[arg(long)]
        amount: String,
        #[arg(long, default_value = "SINGLE_USE")]
        policy: String,
        #[arg(long)]
        idempotency_key: Option<String>,
    },
    PayRequest {
        #[arg(long)]
        request_id: Uuid,
        #[arg(long)]
        payer_wallet: Uuid,
        #[arg(long)]
        signature: String,
        #[arg(long)]
        idempotency_key: Option<String>,
    },
    Refund {
        #[arg(long)]
        payment_id: Uuid,
        #[arg(long)]
        amount: String,
        #[arg(long)]
        reason: String,
        #[arg(long)]
        idempotency_key: Option<String>,
    },
    Convert {
        #[arg(long)]
        direction: String,
        #[arg(long)]
        wallet_id: Uuid,
        #[arg(long)]
        amount: String,
        #[arg(long)]
        bank_token: String,
        #[arg(long)]
        simulate: Option<String>,
        #[arg(long)]
        idempotency_key: Option<String>,
    },
    GetConversion {
        #[arg(long)]
        conversion_id: Uuid,
    },
    RequestIssuance {
        #[arg(long)]
        amount: String,
        #[arg(long, default_value = "TEST_ALLOCATION")]
        classification: String,
        #[arg(long)]
        purpose: String,
        #[arg(long)]
        supporting_ref: String,
        #[arg(long)]
        external_ref: Option<String>,
        #[arg(long)]
        destination_wallet: Option<Uuid>,
        #[arg(long)]
        idempotency_key: Option<String>,
    },
    ApproveIssuance {
        #[arg(long)]
        issuance_id: Uuid,
        #[arg(long)]
        note: Option<String>,
        #[arg(long)]
        idempotency_key: Option<String>,
    },
    Reconcile,
}

fn parse_cents(amount_usd: &str) -> anyhow::Result<i64> {
    let m = Money::from_decimal_str(amount_usd, Currency::Usd)
        .map_err(|e| anyhow::anyhow!("Invalid USD amount '{amount_usd}': {e}"))?;
    Ok(m.cents())
}

fn idem_or_new(opt: Option<String>) -> String {
    opt.unwrap_or_else(|| format!("cli-{}", Uuid::now_v7()))
}

async fn print_response(resp: reqwest::Response) -> anyhow::Result<()> {
    let status = resp.status();
    let corr = resp
        .headers()
        .get("x-correlation-id")
        .and_then(|v| v.to_str().ok())
        .unwrap_or("-")
        .to_string();
    let body: Value = resp
        .json()
        .await
        .context("Failed to decode JSON response")?;
    println!("HTTP {status} (correlation_id: {corr})");
    println!("{}", serde_json::to_string_pretty(&body)?);
    if !status.is_success() {
        bail!("Request failed with status {status}");
    }
    Ok(())
}

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    let cli = Cli::parse();
    let client = Client::new();
    let base = cli.api_url.trim_end_matches('/');

    let auth_header = || -> anyhow::Result<String> {
        let tok = cli
            .token
            .as_deref()
            .context("--token or DOLLAR_TOKEN is required for authenticated commands")?;
        Ok(format!("Bearer {tok}"))
    };

    match cli.command {
        Commands::Health => {
            let resp = client.get(format!("{base}/health")).send().await?;
            print_response(resp).await?;
        }
        Commands::Register {
            username,
            password,
            role,
        } => {
            let resp = client
                .post(format!("{base}/v1/auth/register"))
                .json(&json!({"username": username, "password": password, "role": role}))
                .send()
                .await?;
            print_response(resp).await?;
        }
        Commands::Login { username, password } => {
            let resp = client
                .post(format!("{base}/v1/auth/login"))
                .json(&json!({"username": username, "password": password}))
                .send()
                .await?;
            print_response(resp).await?;
        }
        Commands::CreateWallet {
            class,
            idempotency_key,
        } => {
            let resp = client
                .post(format!("{base}/v1/wallets"))
                .header("Authorization", auth_header()?)
                .header("Idempotency-Key", idem_or_new(idempotency_key))
                .json(&json!({"account_class": class, "currency": "USD"}))
                .send()
                .await?;
            print_response(resp).await?;
        }
        Commands::Balance { wallet_id } => {
            let resp = client
                .get(format!("{base}/v1/wallets/{wallet_id}/balance"))
                .header("Authorization", auth_header()?)
                .send()
                .await?;
            print_response(resp).await?;
        }
        Commands::Transactions { wallet_id, limit } => {
            let resp = client
                .get(format!(
                    "{base}/v1/wallets/{wallet_id}/transactions?limit={limit}"
                ))
                .header("Authorization", auth_header()?)
                .send()
                .await?;
            print_response(resp).await?;
        }
        Commands::PreviewTransfer {
            from,
            to,
            amount,
            reference,
        } => {
            let cents = parse_cents(&amount)?;
            let resp = client
                .post(format!("{base}/v1/transfers/preview"))
                .header("Authorization", auth_header()?)
                .json(&json!({
                    "source_account_id": from,
                    "destination_account_id": to,
                    "amount_cents": cents,
                    "currency": "USD",
                    "reference": reference,
                }))
                .send()
                .await?;
            print_response(resp).await?;
        }
        Commands::Transfer {
            from,
            to,
            amount,
            reference,
            idempotency_key,
        } => {
            let cents = parse_cents(&amount)?;
            let resp = client
                .post(format!("{base}/v1/transfers"))
                .header("Authorization", auth_header()?)
                .header("Idempotency-Key", idem_or_new(idempotency_key))
                .json(&json!({
                    "source_account_id": from,
                    "destination_account_id": to,
                    "amount_cents": cents,
                    "currency": "USD",
                    "reference": reference,
                }))
                .send()
                .await?;
            print_response(resp).await?;
        }
        Commands::GetTransfer { transfer_id } => {
            let resp = client
                .get(format!("{base}/v1/transfers/{transfer_id}"))
                .header("Authorization", auth_header()?)
                .send()
                .await?;
            print_response(resp).await?;
        }
        Commands::CreatePaymentRequest {
            merchant_wallet,
            order_ref,
            amount,
            policy,
            idempotency_key,
        } => {
            let cents = parse_cents(&amount)?;
            let resp = client
                .post(format!("{base}/v1/payment-requests"))
                .header("Authorization", auth_header()?)
                .header("Idempotency-Key", idem_or_new(idempotency_key))
                .json(&json!({
                    "merchant_account_id": merchant_wallet,
                    "order_reference": order_ref,
                    "amount_cents": cents,
                    "currency": "USD",
                    "policy": policy,
                }))
                .send()
                .await?;
            print_response(resp).await?;
        }
        Commands::PayRequest {
            request_id,
            payer_wallet,
            signature,
            idempotency_key,
        } => {
            let resp = client
                .post(format!("{base}/v1/payment-requests/{request_id}/pay"))
                .header("Authorization", auth_header()?)
                .header("Idempotency-Key", idem_or_new(idempotency_key))
                .json(&json!({
                    "payer_account_id": payer_wallet,
                    "signature_hmac": signature,
                }))
                .send()
                .await?;
            print_response(resp).await?;
        }
        Commands::Refund {
            payment_id,
            amount,
            reason,
            idempotency_key,
        } => {
            let cents = parse_cents(&amount)?;
            let resp = client
                .post(format!("{base}/v1/payments/{payment_id}/refunds"))
                .header("Authorization", auth_header()?)
                .header("Idempotency-Key", idem_or_new(idempotency_key))
                .json(&json!({
                    "amount_cents": cents,
                    "currency": "USD",
                    "reason_reference": reason,
                }))
                .send()
                .await?;
            print_response(resp).await?;
        }
        Commands::Convert {
            direction,
            wallet_id,
            amount,
            bank_token,
            simulate,
            idempotency_key,
        } => {
            let cents = parse_cents(&amount)?;
            let resp = client
                .post(format!("{base}/v1/conversions"))
                .header("Authorization", auth_header()?)
                .header("Idempotency-Key", idem_or_new(idempotency_key))
                .json(&json!({
                    "direction": direction,
                    "account_id": wallet_id,
                    "amount_cents": cents,
                    "currency": "USD",
                    "bank_account_ref_token": bank_token,
                    "simulate_outcome": simulate,
                }))
                .send()
                .await?;
            print_response(resp).await?;
        }
        Commands::GetConversion { conversion_id } => {
            let resp = client
                .get(format!("{base}/v1/conversions/{conversion_id}"))
                .header("Authorization", auth_header()?)
                .send()
                .await?;
            print_response(resp).await?;
        }
        Commands::RequestIssuance {
            amount,
            classification,
            purpose,
            supporting_ref,
            external_ref,
            destination_wallet,
            idempotency_key,
        } => {
            let cents = parse_cents(&amount)?;
            let resp = client
                .post(format!("{base}/v1/issuer/issuance-requests"))
                .header("Authorization", auth_header()?)
                .header("Idempotency-Key", idem_or_new(idempotency_key))
                .json(&json!({
                    "amount_cents": cents,
                    "currency": "USD",
                    "funding_classification": classification,
                    "purpose": purpose,
                    "supporting_reference": supporting_ref,
                    "external_funding_reference": external_ref,
                    "destination_account_id": destination_wallet,
                }))
                .send()
                .await?;
            print_response(resp).await?;
        }
        Commands::ApproveIssuance {
            issuance_id,
            note,
            idempotency_key,
        } => {
            let resp = client
                .post(format!(
                    "{base}/v1/issuer/issuance-requests/{issuance_id}/approve"
                ))
                .header("Authorization", auth_header()?)
                .header("Idempotency-Key", idem_or_new(idempotency_key))
                .json(&json!({"review_note": note}))
                .send()
                .await?;
            print_response(resp).await?;
        }
        Commands::Reconcile => {
            let resp = client
                .get(format!("{base}/v1/reconciliation"))
                .header("Authorization", auth_header()?)
                .send()
                .await?;
            print_response(resp).await?;
        }
    }

    Ok(())
}
