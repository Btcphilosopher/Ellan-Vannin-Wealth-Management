use chrono::{Duration, Utc};
use dollar_auth::{redact_json_secrets, AuthService};
use dollar_ledger::{validate_balanced_lines, ProposedJournalLine};
use dollar_payments::{PaymentRequestPolicy, PaymentRequestSigner, SimulatedBankAdapter, SimulatedBankOutcome};
use dollar_types::{
    AccountId, Currency, DomainError, EntryDirection, IdempotencyKey, Money, PaymentRequestId,
    MAX_MONEY_CENTS,
};

#[test]
fn money_rejects_negative_overflow_and_bad_precision() {
    assert!(matches!(
        Money::from_cents(-1, Currency::Usd),
        Err(DomainError::NegativeAmount(-1))
    ));
    assert!(matches!(
        Money::from_positive_cents(0, Currency::Usd),
        Err(DomainError::NonPositiveAmount(0))
    ));
    assert!(matches!(
        Money::from_cents(MAX_MONEY_CENTS + 1, Currency::Usd),
        Err(DomainError::AmountOverflow)
    ));
    assert!(matches!(
        Money::from_decimal_str("10.123", Currency::Usd),
        Err(DomainError::InvalidPrecision(_))
    ));
    assert!(matches!(
        Money::from_decimal_str("-5.00", Currency::Usd),
        Err(DomainError::InvalidMonetaryFormat(_))
    ));

    let a = Money::from_decimal_str("100.50", Currency::Usd).unwrap();
    let b = Money::from_decimal_str("25.5", Currency::Usd).unwrap();
    assert_eq!(a.cents(), 10_050);
    assert_eq!(b.cents(), 2_550);
    assert_eq!(a.checked_add(b).unwrap().cents(), 12_600);
    assert_eq!(a.checked_sub(b).unwrap().cents(), 7_500);
    assert!(matches!(
        b.checked_sub(a),
        Err(DomainError::InsufficientFunds { .. })
    ));
}

#[test]
fn balanced_journal_invariant_rejects_single_line_and_imbalance() {
    let a = AccountId::new();
    let b = AccountId::new();
    let hundred = Money::from_positive_cents(10_000, Currency::Usd).unwrap();
    let fifty = Money::from_positive_cents(5_000, Currency::Usd).unwrap();

    // Single line must fail
    assert!(matches!(
        validate_balanced_lines(&[ProposedJournalLine {
            account_id: a,
            direction: EntryDirection::Debit,
            amount: hundred,
        }]),
        Err(DomainError::InsufficientJournalLines)
    ));

    // Unbalanced lines must fail
    assert!(matches!(
        validate_balanced_lines(&[
            ProposedJournalLine {
                account_id: a,
                direction: EntryDirection::Debit,
                amount: hundred,
            },
            ProposedJournalLine {
                account_id: b,
                direction: EntryDirection::Credit,
                amount: fifty,
            }
        ]),
        Err(DomainError::UnbalancedJournal {
            debits_cents: 10_000,
            credits_cents: 5_000
        })
    ));

    // Balanced multi-leg entry passes
    assert!(validate_balanced_lines(&[
        ProposedJournalLine {
            account_id: a,
            direction: EntryDirection::Debit,
            amount: hundred,
        },
        ProposedJournalLine {
            account_id: b,
            direction: EntryDirection::Credit,
            amount: fifty,
        },
        ProposedJournalLine {
            account_id: AccountId::new(),
            direction: EntryDirection::Credit,
            amount: fifty,
        }
    ])
    .is_ok());
}

#[test]
fn idempotency_key_validation_enforces_bounds() {
    assert!(IdempotencyKey::parse("short").is_err());
    assert!(IdempotencyKey::parse("valid-idem-key-0001").is_ok());
    assert!(IdempotencyKey::parse("bad key with spaces").is_err());
}

#[test]
fn signed_payment_request_detects_tampering() {
    let signer = PaymentRequestSigner::new("test-payment-hmac-secret-at-least-16b").unwrap();
    let pr_id = PaymentRequestId::new();
    let merchant = AccountId::new();
    let exp = Utc::now() + Duration::minutes(10);

    let sig = signer
        .sign(
            pr_id,
            merchant,
            "ORD-2026-001",
            2_500,
            PaymentRequestPolicy::SingleUse,
            exp,
        )
        .unwrap();

    assert!(signer
        .verify(
            pr_id,
            merchant,
            "ORD-2026-001",
            2_500,
            PaymentRequestPolicy::SingleUse,
            exp,
            &sig
        )
        .is_ok());

    // Tampering with amount must fail signature verification
    assert!(matches!(
        signer.verify(
            pr_id,
            merchant,
            "ORD-2026-001",
            2_600,
            PaymentRequestPolicy::SingleUse,
            exp,
            &sig
        ),
        Err(DomainError::InvalidSignature)
    ));
}

#[test]
fn secret_redaction_and_argon2_verification() {
    let hash = AuthService::hash_password("super-secret-passphrase").unwrap();
    assert!(AuthService::verify_password("super-secret-passphrase", &hash).unwrap());
    assert!(!AuthService::verify_password("wrong-passphrase", &hash).unwrap());

    let redacted = redact_json_secrets(serde_json::json!({
        "password": "leak",
        "token": "jwt-123",
        "amount_cents": 500
    }));
    assert_eq!(redacted["password"], "[REDACTED]");
    assert_eq!(redacted["token"], "[REDACTED]");
    assert_eq!(redacted["amount_cents"], 500);
}

#[test]
fn simulated_bank_adapter_outcomes_are_deterministic() {
    let adapter = SimulatedBankAdapter::new("normal".to_string());
    let cid = dollar_types::ConversionId::new();
    let (_, ok, _) = adapter.submit_payout_or_deposit(
        cid,
        dollar_payments::ConversionDirection::RedeemToBank,
        10_000,
        Some("SETTLED"),
    );
    assert_eq!(ok, SimulatedBankOutcome::Settled);

    let (_, fail, reason) = adapter.submit_payout_or_deposit(
        cid,
        dollar_payments::ConversionDirection::RedeemToBank,
        10_000,
        Some("FAILED"),
    );
    assert_eq!(fail, SimulatedBankOutcome::Failed);
    assert!(reason.is_some());
}
