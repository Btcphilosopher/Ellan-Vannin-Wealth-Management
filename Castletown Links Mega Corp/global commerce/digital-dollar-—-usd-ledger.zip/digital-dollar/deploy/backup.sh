#!/usr/bin/env bash
set -euo pipefail

# Consistent PostgreSQL backup for DIGITAL DOLLAR — USD Ledger.
# Uses pg_dump custom format (-Fc) which runs in a repeatable-read snapshot.

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKUP_DIR="${BACKUP_DIR:-${SCRIPT_DIR}/backups}"
TIMESTAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT_FILE="${BACKUP_DIR}/digital_dollar_${TIMESTAMP}.dump"

mkdir -p "${BACKUP_DIR}"

if command -v docker >/dev/null 2>&1 && docker ps --format '{{.Names}}' | grep -q '^digital-dollar-postgres$'; then
  docker exec digital-dollar-postgres pg_dump -U dollar -d digital_dollar -Fc > "${OUT_FILE}"
else
  : "${DATABASE_URL:?Set DATABASE_URL or run with digital-dollar-postgres container active}"
  pg_dump "${DATABASE_URL}" -Fc -f "${OUT_FILE}"
fi

sha256sum "${OUT_FILE}" > "${OUT_FILE}.sha256"
echo "Backup created: ${OUT_FILE}"
echo "Checksum: $(cat "${OUT_FILE}.sha256")"
