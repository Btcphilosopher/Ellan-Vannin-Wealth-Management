#!/usr/bin/env bash
set -euo pipefail

# Restores a DIGITAL DOLLAR — USD Ledger backup and verifies checksum integrity.

DUMP_FILE="${1:?Usage: restore.sh <path-to-dump-file>}"

if [[ -f "${DUMP_FILE}.sha256" ]]; then
  sha256sum -c "${DUMP_FILE}.sha256"
fi

if command -v docker >/dev/null 2>&1 && docker ps --format '{{.Names}}' | grep -q '^digital-dollar-postgres$'; then
  docker exec -i digital-dollar-postgres psql -U dollar -d postgres -c \
    "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = 'digital_dollar' AND pid <> pg_backend_pid();" >/dev/null
  docker exec -i digital-dollar-postgres dropdb -U dollar --if-exists digital_dollar
  docker exec -i digital-dollar-postgres createdb -U dollar digital_dollar
  docker exec -i digital-dollar-postgres pg_restore -U dollar -d digital_dollar --no-owner < "${DUMP_FILE}"
else
  : "${DATABASE_URL:?Set DATABASE_URL or run with digital-dollar-postgres container active}"
  pg_restore --clean --if-exists --no-owner -d "${DATABASE_URL}" "${DUMP_FILE}"
fi

echo "Restore completed from ${DUMP_FILE}."
echo "Run reconciliation check via: python3 python/reconcile.py"
