/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

const CRATES = [
  { name: 'dollar_types', summary: 'Validated USD Money (i64 cents), opaque IDs, roles, and structured DomainError.' },
  { name: 'dollar_auth', summary: 'Argon2id credential hashing, HMAC-SHA256 sessions, RBAC, sliding-window rate limits, audit log.' },
  { name: 'dollar_ledger', summary: 'Double-entry journal engine, deterministic FOR UPDATE locking, reservations, idempotency, reconciliation.' },
  { name: 'dollar_issuer', summary: 'Dual-control issuance lifecycle (Requested -> Reviewed -> Approved -> Posted -> Reconciled).' },
  { name: 'dollar_payments', summary: 'Transfers, HMAC-signed payment requests, partial refunds, scheduled workers, bank redemption recovery.' },
  { name: 'dollar_api', summary: 'Axum 0.8 + utoipa OpenAPI HTTP server and background outbox/reconciliation workers.' },
  { name: 'dollar_cli', summary: 'Clap CLI client for wallets, transfers, merchant payments, issuance, conversions, and reconciliation.' },
];

const ENDPOINTS = [
  'POST /v1/wallets',
  'GET  /v1/wallets/{id}/balance',
  'GET  /v1/wallets/{id}/transactions',
  'POST /v1/transfers/preview',
  'POST /v1/transfers',
  'GET  /v1/transfers/{id}',
  'POST /v1/payment-requests',
  'POST /v1/payment-requests/{id}/pay',
  'POST /v1/payments/{id}/refunds',
  'POST /v1/conversions',
  'GET  /v1/conversions/{id}',
  'POST /v1/issuer/issuance-requests',
  'POST /v1/issuer/issuance-requests/{id}/approve',
  'GET  /v1/reconciliation',
  'GET  /health',
];

export default function App() {
  return (
    <main className="min-h-screen bg-zinc-950 text-zinc-100 px-6 py-10 font-mono">
      <div className="max-w-4xl mx-auto space-y-8">
        <header className="border-b border-zinc-800 pb-6">
          <p className="text-xs uppercase tracking-widest text-emerald-400">
            Code-First Monetary Engine Reference
          </p>
          <h1 className="text-2xl font-bold mt-2 text-white">
            DIGITAL DOLLAR — USD Ledger
          </h1>
          <p className="text-sm text-zinc-400 mt-2 leading-relaxed">
            Workspace generated under <code className="text-zinc-200">/digital-dollar</code> using Rust,
            PostgreSQL, Python, Docker Compose, OpenAPI, and the <code className="text-zinc-200">dollar-cli</code> client.
          </p>
        </header>

        <section className="space-y-3">
          <h2 className="text-sm font-semibold uppercase tracking-wider text-zinc-300">
            1. Workspace Crates
          </h2>
          <div className="grid gap-2">
            {CRATES.map((c) => (
              <div
                key={c.name}
                className="border border-zinc-800 bg-zinc-900/60 rounded px-4 py-2.5 text-xs"
              >
                <span className="text-emerald-400 font-semibold">{c.name}</span>
                <span className="text-zinc-400 ml-3">{c.summary}</span>
              </div>
            ))}
          </div>
        </section>

        <section className="space-y-3">
          <h2 className="text-sm font-semibold uppercase tracking-wider text-zinc-300">
            2. Implemented HTTP API Surface
          </h2>
          <pre className="border border-zinc-800 bg-zinc-900/60 rounded p-4 text-xs text-zinc-300 overflow-x-auto">
            {ENDPOINTS.join('\n')}
          </pre>
        </section>

        <section className="space-y-3">
          <h2 className="text-sm font-semibold uppercase tracking-wider text-zinc-300">
            3. Local Execution & Verification Commands
          </h2>
          <pre className="border border-zinc-800 bg-zinc-900/60 rounded p-4 text-xs text-zinc-300 overflow-x-auto">
{`cd digital-dollar
cp .env.example .env
docker compose -f deploy/docker-compose.yml up --build -d

# Run Rust monetary invariant tests
cargo test --workspace

# Run 12-step end-to-end demo + restart + reconciliation
python3 python/demo.py

# Run pytest acceptance suite & benchmark
pytest -v python/test_acceptance.py
python3 python/benchmark.py`}
          </pre>
        </section>
      </div>
    </main>
  );
}
