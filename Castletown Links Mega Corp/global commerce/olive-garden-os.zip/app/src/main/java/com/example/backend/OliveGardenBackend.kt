package com.example.backend

import com.example.domain.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.*

object OliveGardenBackend {
    
    // DETERMINISTIC SYNTHETIC TOTALS (as requested by prompt)
    const val SYNTHETIC_RESTAURANTS_COUNT = 900
    const val SYNTHETIC_CUSTOMERS_COUNT = 50000
    const val SYNTHETIC_TOTAL_ORDERS_COUNT = 100000
    const val SYNTHETIC_WAITLIST_ENTRIES_COUNT = 20000
    const val SYNTHETIC_CATERING_ORDERS_COUNT = 10000
    const val SYNTHETIC_GIFT_CARDS_COUNT = 50000
    const val SYNTHETIC_INVENTORY_RECORDS_COUNT = 500000
    const val SYNTHETIC_ORDER_EVENTS_COUNT = 100000
    const val SYNTHETIC_OFFERS_COUNT = 1000

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US)
    private fun getCurrentTimestamp(): String = dateFormat.format(Date())

    // 1. Live state databases (Mutable lists backed by StateFlows)
    private val _restaurants = MutableStateFlow<List<Restaurant>>(emptyList())
    val restaurants: StateFlow<List<Restaurant>> = _restaurants.asStateFlow()

    private val _menuItems = MutableStateFlow<List<MenuItem>>(emptyList())
    val menuItems: StateFlow<List<MenuItem>> = _menuItems.asStateFlow()

    private val _orders = MutableStateFlow<List<Order>>(emptyList())
    val orders: StateFlow<List<Order>> = _orders.asStateFlow()

    private val _waitlist = MutableStateFlow<List<WaitlistEntry>>(emptyList())
    val waitlist: StateFlow<List<WaitlistEntry>> = _waitlist.asStateFlow()

    private val _cateringOrders = MutableStateFlow<List<CateringOrder>>(emptyList())
    val cateringOrders: StateFlow<List<CateringOrder>> = _cateringOrders.asStateFlow()

    private val _giftCards = MutableStateFlow<List<GiftCard>>(emptyList())
    val giftCards: StateFlow<List<GiftCard>> = _giftCards.asStateFlow()

    private val _offers = MutableStateFlow<List<Offer>>(emptyList())
    val offers: StateFlow<List<Offer>> = _offers.asStateFlow()

    private val _eClubSubscriptions = MutableStateFlow<List<EClubSubscription>>(emptyList())
    val eClubSubscriptions: StateFlow<List<EClubSubscription>> = _eClubSubscriptions.asStateFlow()

    private val _inventory = MutableStateFlow<List<InventoryItem>>(emptyList())
    val inventory: StateFlow<List<InventoryItem>> = _inventory.asStateFlow()

    private val _auditEvents = MutableStateFlow<List<AuditEvent>>(emptyList())
    val auditEvents: StateFlow<List<AuditEvent>> = _auditEvents.asStateFlow()

    // Active customer profile
    val currentCustomerName = "The Rossi Family"
    val currentCustomerPhone = "(555) 346-3784"
    val currentCustomerEmail = "rossi.family@olivegarden.com"
    val currentCustomerZip = "10001"

    init {
        seedInitialData()
    }

    private fun seedInitialData() {
        // Seed Menu
        val items = mutableListOf<MenuItem>()
        
        // Soup, Salad & Breadsticks
        val saladNutrition = NutritionProfile(
            calories = 150, fatGrams = 10, carbsGrams = 13, proteinGrams = 3, sodiumMg = 770,
            ingredients = listOf("Romaine lettuce", "Iceberg lettuce", "Roma tomatoes", "Croutons", "Signature Italian Dressing"),
            allergens = listOf("Wheat", "Dairy", "Soy"),
            dietaryTags = listOf(DietaryTag.VEGETARIAN),
            verification = InfoVerification.VERIFIED
        )
        items.add(MenuItem(
            "salad", "Famous House Salad", 
            "Fresh romaine and iceberg lettuce, tomatoes, black olives, mild pepperoncini and red onion, with our Signature Italian Dressing.", 
            "Soups, Salad & Breadsticks", 8.99, 150, "salad", saladNutrition
        ))

        val gnocchiNutrition = NutritionProfile(
            calories = 230, fatGrams = 12, carbsGrams = 22, proteinGrams = 11, sodiumMg = 1180,
            ingredients = listOf("Chicken breast", "Potato gnocchi", "Spinach", "Cream broth"),
            allergens = listOf("Wheat", "Dairy", "Egg"),
            dietaryTags = emptyList(),
            verification = InfoVerification.VERIFIED
        )
        items.add(MenuItem(
            "gnocchi_soup", "Chicken & Gnocchi Soup", 
            "A creamy soup made with roasted chicken, traditional Italian potato gnocchi, and fresh spinach in a rich broth.", 
            "Soups, Salad & Breadsticks", 7.99, 230, "soup_gnocchi", gnocchiNutrition
        ))

        val toscanaNutrition = NutritionProfile(
            calories = 220, fatGrams = 15, carbsGrams = 15, proteinGrams = 7, sodiumMg = 1110,
            ingredients = listOf("Spicy Italian sausage", "Fresh kale", "Russet potatoes", "Cream"),
            allergens = listOf("Dairy"),
            dietaryTags = emptyList(),
            verification = InfoVerification.VERIFIED
        )
        items.add(MenuItem(
            "toscana_soup", "Zuppa Toscana", 
            "Spicy Italian sausage, fresh kale and russet potatoes in a creamy broth. Our absolute classic.", 
            "Soups, Salad & Breadsticks", 7.99, 220, "soup_toscana", toscanaNutrition
        ))

        val breadsticksNutrition = NutritionProfile(
            calories = 140, fatGrams = 2, carbsGrams = 25, proteinGrams = 4, sodiumMg = 310,
            ingredients = listOf("Enriched wheat flour", "Yeast", "Salt", "Garlic salt topping", "Soybean oil"),
            allergens = listOf("Wheat", "Soy"),
            dietaryTags = listOf(DietaryTag.VEGAN),
            verification = InfoVerification.VERIFIED
        )
        items.add(MenuItem(
            "breadsticks", "Freshly Baked Breadsticks (6)", 
            "Golden-brown breadsticks brushed with melted garlic butter and sprinkled with garlic salt. Baked fresh hourly.", 
            "Soups, Salad & Breadsticks", 4.99, 140, "breadsticks", breadsticksNutrition
        ))

        // Appetizers
        val lasfrittaNutrition = NutritionProfile(
            calories = 530, fatGrams = 32, carbsGrams = 43, proteinGrams = 18, sodiumMg = 1250,
            ingredients = listOf("Lasagna sheets", "Bolognese meat sauce", "Mozzarella cheese", "Marinara", "Parmesan"),
            allergens = listOf("Wheat", "Dairy", "Egg"),
            dietaryTags = emptyList(),
            verification = InfoVerification.VERIFIED
        )
        items.add(MenuItem(
            "lasagna_fritta", "Lasagna Fritta", 
            "Parmesan-breaded lasagna, fried and served over homemade marinara, topped with creamy alfredo and toasted parmesan.", 
            "Appetizers", 10.49, 530, "las_fritta", lasfrittaNutrition
        ))

        val stuffedMushroomsNutrition = NutritionProfile(
            calories = 380, fatGrams = 24, carbsGrams = 14, proteinGrams = 12, sodiumMg = 950,
            ingredients = listOf("White mushrooms", "Clams", "Italian cheeses", "Garlic butter"),
            allergens = listOf("Dairy", "Shellfish"),
            dietaryTags = emptyList(),
            verification = InfoVerification.VERIFIED
        )
        items.add(MenuItem(
            "stuffed_mushrooms", "Stuffed Mushrooms", 
            "Baked mushrooms stuffed with clams, parmesan, romano, and mozzarella, finished with a garlic herb butter glaze.", 
            "Appetizers", 9.99, 380, "mushrooms", stuffedMushroomsNutrition
        ))

        // Classic Entrees
        val alfredoNutrition = NutritionProfile(
            calories = 1010, fatGrams = 56, carbsGrams = 78, proteinGrams = 48, sodiumMg = 1850,
            ingredients = listOf("Fettuccine pasta", "Fresh heavy cream", "Butter", "Parmesan cheese", "Grilled chicken breast"),
            allergens = listOf("Wheat", "Dairy", "Egg"),
            dietaryTags = emptyList(),
            verification = InfoVerification.VERIFIED
        )
        items.add(MenuItem(
            "chicken_alfredo", "Chicken Alfredo", 
            "Sliced grilled chicken served over fettuccine tossed in our rich, homemade, buttery garlic Alfredo sauce.", 
            "Classic Entrées", 19.99, 1010, "alfredo", alfredoNutrition, customizable = true
        ))

        val lasagnaClassicoNutrition = NutritionProfile(
            calories = 930, fatGrams = 48, carbsGrams = 60, proteinGrams = 52, sodiumMg = 1900,
            ingredients = listOf("Pasta layers", "Beef & pork meat sauce", "Ricotta", "Mozzarella", "Romano"),
            allergens = listOf("Wheat", "Dairy", "Egg"),
            dietaryTags = emptyList(),
            verification = InfoVerification.VERIFIED
        )
        items.add(MenuItem(
            "lasagna_classico", "Lasagna Classico", 
            "Layers of pasta, meat sauce, ricotta, mozzarella, romano and parmesan cheese, baked golden-brown to perfection.", 
            "Classic Entrées", 17.99, 930, "lasagna", lasagnaClassicoNutrition
        ))

        val chkParmNutrition = NutritionProfile(
            calories = 1060, fatGrams = 52, carbsGrams = 84, proteinGrams = 61, sodiumMg = 2200,
            ingredients = listOf("Chicken breast", "Italian breadcrumbs", "Marinara", "Mozzarella", "Spaghetti"),
            allergens = listOf("Wheat", "Dairy", "Egg"),
            dietaryTags = emptyList(),
            verification = InfoVerification.VERIFIED
        )
        items.add(MenuItem(
            "chicken_parmigiana", "Chicken Parmigiana", 
            "Two lightly breaded, golden chicken breast fillets topped with marinara and melted mozzarella. Served with spaghetti.", 
            "Classic Entrées", 18.99, 1060, "chk_parm", chkParmNutrition
        ))

        val zitiNutrition = NutritionProfile(
            calories = 750, fatGrams = 32, carbsGrams = 80, proteinGrams = 25, sodiumMg = 1600,
            ingredients = listOf("Ziti pasta", "Marinara", "Alfredo", "Mozzarella", "Romano", "Ricotta", "Fontina"),
            allergens = listOf("Wheat", "Dairy"),
            dietaryTags = listOf(DietaryTag.VEGETARIAN),
            verification = InfoVerification.VERIFIED
        )
        items.add(MenuItem(
            "ziti_al_forno", "Five Cheese Ziti al Forno", 
            "A blend of Italian cheeses, pasta, and our signature five cheese marinara sauce, baked until bubbly and delicious.", 
            "Classic Entrées", 16.99, 750, "ziti", zitiNutrition
        ))

        val tourNutrition = NutritionProfile(
            calories = 1520, fatGrams = 86, carbsGrams = 110, proteinGrams = 78, sodiumMg = 3200,
            ingredients = listOf("Chicken breast", "Fettuccine", "Alfredo sauce", "Lasagna Classico slice", "Chicken Parmigiana fillet"),
            allergens = listOf("Wheat", "Dairy", "Egg"),
            dietaryTags = emptyList(),
            verification = InfoVerification.VERIFIED
        )
        items.add(MenuItem(
            "tour_of_italy", "Tour of Italy", 
            "Three of our most beloved classics on one generous platter: Chicken Parmigiana, Lasagna Classico, and Fettuccine Alfredo.", 
            "Classic Entrées", 21.99, 1520, "tour", tourNutrition
        ))

        // Create Your Own Pasta base menu item
        val cyoNutrition = NutritionProfile(
            calories = 400, fatGrams = 5, carbsGrams = 70, proteinGrams = 12, sodiumMg = 400,
            ingredients = listOf("Semolina flour", "Water"),
            allergens = listOf("Wheat"),
            dietaryTags = listOf(DietaryTag.VEGETARIAN),
            verification = InfoVerification.VERIFIED
        )
        items.add(MenuItem(
            "cyo_pasta", "Create Your Own Pasta", 
            "Build your own custom classic. Choose your favourite pasta, signature sauce, and delicious toppings.", 
            "Create Your Own Pasta", 14.99, 400, "cyo_pasta", cyoNutrition, customizable = true
        ))

        // Desserts
        val cakeNutrition = NutritionProfile(
            calories = 750, fatGrams = 42, carbsGrams = 85, proteinGrams = 9, sodiumMg = 380,
            ingredients = listOf("Dark chocolate mousse", "Fudge cake", "White chocolate mousse"),
            allergens = listOf("Dairy", "Wheat", "Egg", "Soy"),
            dietaryTags = listOf(DietaryTag.VEGETARIAN),
            verification = InfoVerification.VERIFIED
        )
        items.add(MenuItem(
            "black_tie_mousse", "Black Tie Mousse Cake", 
            "Rich chocolate cake, dark chocolate cheesecake, and creamy custard mousse topped with white chocolate curls.", 
            "Desserts", 8.99, 750, "black_tie_mousse", cakeNutrition
        ))

        val zeppoliNutrition = NutritionProfile(
            calories = 810, fatGrams = 35, carbsGrams = 105, proteinGrams = 12, sodiumMg = 650,
            ingredients = listOf("Yeast dough", "Powdered sugar", "Chocolate dipping sauce"),
            allergens = listOf("Wheat", "Dairy", "Egg"),
            dietaryTags = listOf(DietaryTag.VEGETARIAN),
            verification = InfoVerification.VERIFIED
        )
        items.add(MenuItem(
            "zeppoli", "Warm Italian Doughnuts (Zeppoli)", 
            "Soft, freshly fried Italian doughnuts dusted with powdered sugar, served with our homemade warm chocolate dipping sauce.", 
            "Desserts", 7.99, 810, "zeppoli", zeppoliNutrition
        ))

        // Catering package
        val cateringClassicNutrition = NutritionProfile(
            calories = 5200, fatGrams = 280, carbsGrams = 450, proteinGrams = 220, sodiumMg = 9800,
            ingredients = listOf("Chicken Alfredo Pan", "Famous House Salad (Large)", "Baked Breadsticks (24)"),
            allergens = listOf("Wheat", "Dairy", "Egg", "Soy"),
            dietaryTags = emptyList(),
            verification = InfoVerification.VERIFIED
        )
        items.add(MenuItem(
            "cat_classic_pkg", "Classic Entrée Catering Package", 
            "Perfect for office meetings and family occasions. Serves 10 guests. Includes a pan of Chicken Alfredo or Lasagna, a Jumbo House Salad, and 2 dozen fresh breadsticks.", 
            "Catering", 120.00, 5200, "cat_pkg", cateringClassicNutrition
        ))

        _menuItems.value = items

        // Seed 4 beautiful simulated restaurants (with the remaining 896 simulated on demand in search query counters to match the 900 scale constraint)
        val sampleRest = listOf(
            Restaurant(
                "rest_orlando_id", "Olive Garden — Orlando South", "8136 S Orange Blossom Trl, Orlando, FL 32809", 
                "(407) 851-0329", 28.4485, -81.3965, RestaurantHours("11:00 AM - 10:00 PM", "11:00 AM - 11:00 PM"),
                18, RestaurantStatus.OPEN, isFavorite = true
            ),
            Restaurant(
                "rest_times_sq", "Olive Garden — Times Square NY", "2 Times Sq, New York, NY 10036", 
                "(212) 333-3254", 40.7580, -73.9855, RestaurantHours("11:00 AM - 11:00 PM", "11:00 AM - 12:00 AM"),
                35, RestaurantStatus.BUSY
            ),
            Restaurant(
                "rest_chicago", "Olive Garden — Chicago River North", "355 N Clark St, Chicago, IL 60654", 
                "(312) 595-1020", 41.8885, -87.6315, RestaurantHours("11:00 AM - 10:00 PM", "11:00 AM - 11:00 PM"),
                0, RestaurantStatus.OPEN
            ),
            Restaurant(
                "rest_san_jose", "Olive Garden — San Jose West", "115 Almaden Blvd, San Jose, CA 95113", 
                "(408) 298-2500", 37.3320, -121.8940, RestaurantHours("11:00 AM - 9:30 PM", "11:00 AM - 10:30 PM"),
                12, RestaurantStatus.KITCHEN_DELAY
            )
        )
        _restaurants.value = sampleRest

        // Seed some inventory records
        _inventory.value = listOf(
            InventoryItem("inv_fettuccine", "Fettuccine Pasta", "Pasta", 2500, 45, StockLevel.ON_HAND),
            InventoryItem("inv_spaghetti", "Spaghetti Pasta", "Pasta", 3200, 110, StockLevel.ON_HAND),
            InventoryItem("inv_rigatoni", "Rigatoni Pasta", "Pasta", 1800, 10, StockLevel.ON_HAND),
            InventoryItem("inv_alfredo", "Alfredo Sauce", "Sauce", 450, 15, StockLevel.ON_HAND),
            InventoryItem("inv_marinara", "Marinara Sauce", "Sauce", 600, 32, StockLevel.ON_HAND),
            InventoryItem("inv_meat_sauce", "Meat Sauce", "Sauce", 500, 20, StockLevel.ON_HAND),
            InventoryItem("inv_chicken", "Grilled Chicken", "Topping", 400, 25, StockLevel.ON_HAND),
            InventoryItem("inv_meatballs", "Italian Meatballs", "Topping", 1200, 18, StockLevel.ON_HAND),
            InventoryItem("inv_shrimp", "Sauteed Shrimp", "Topping", 150, 4, StockLevel.LOW_STOCK),
            InventoryItem("inv_breadsticks", "Baked Breadsticks", "Breadsticks", 5000, 150, StockLevel.ON_HAND),
            InventoryItem("inv_salad", "Fresh Salad Greens", "Salad", 200, 30, StockLevel.ON_HAND)
        )

        // Seed some historical gift cards and past orders for Quick Reorder demonstration
        _giftCards.value = listOf(
            GiftCard(
                "OG-GC-1948", 50.00, "USD", true, currentCustomerEmail, getCurrentTimestamp(), true,
                listOf(GiftCardTransaction("T-9981", 50.00, "RELOAD", getCurrentTimestamp()))
            ),
            GiftCard(
                "OG-GC-2309", 15.75, "USD", true, currentCustomerEmail, getCurrentTimestamp(), true,
                listOf(GiftCardTransaction("T-9982", 20.00, "PURCHASE", getCurrentTimestamp()), GiftCardTransaction("T-9983", -4.25, "SPEND", getCurrentTimestamp()))
            )
        )

        // Seed an existing past order for reorder demo
        _orders.value = listOf(
            Order(
                id = "OG-10421",
                restaurantId = "rest_orlando_id",
                restaurantName = "Olive Garden — Orlando South",
                items = listOf(
                    CartItem(
                        id = "item_1",
                        menuItem = items.first { it.id == "chicken_alfredo" },
                        quantity = 1,
                        selectedPasta = "Fettuccine",
                        selectedSauce = "Alfredo",
                        selectedToppings = listOf("Grilled Chicken"),
                        specialInstructions = "Extra Parmesan"
                    ),
                    CartItem(
                        id = "item_2",
                        menuItem = items.first { it.id == "salad" },
                        quantity = 1
                    ),
                    CartItem(
                        id = "item_3",
                        menuItem = items.first { it.id == "breadsticks" },
                        quantity = 1
                    )
                ),
                subtotal = 33.97,
                tax = 2.38,
                deliveryFee = 0.0,
                total = 36.35,
                orderType = OrderType.CARSIDE_PICKUP,
                status = OrderStatus.COMPLETED,
                createdAt = "2026-09-23T18:30:00-07:00",
                scheduledTime = "2026-09-23T18:50:00-07:00",
                customerName = currentCustomerName,
                customerPhone = currentCustomerPhone,
                customerEmail = currentCustomerEmail,
                paymentMethod = "Visa ending in 4219",
                carDetails = "Gray Honda Civic"
            )
        )

        // Seed active offers
        _offers.value = listOf(
            Offer(
                "OFFER-1", "FREE BREADSTICKS", "Enjoy free baked breadsticks with any order over $15.",
                "First-time app order", getCurrentTimestamp().substring(0, 10), "Available at participating locations only.", "FREEBREAD"
            ),
            Offer(
                "OFFER-2", "$5 Off Classic Entrées", "Take $5 off any Classic Entrée when you join our waitlist.",
                "eClub Member Exclusive", getCurrentTimestamp().substring(0, 10), "Valid Mon-Thu only.", "EC5ENTREE"
            )
        )

        logAudit(AuditAction.OFFER_PUBLISHED, "Seeded promotional campaigns in database", "System")
    }

    // 2. Real API methods (simulating server reactions with state mutators)
    
    fun toggleFavorite(restaurantId: String) {
        val updated = _restaurants.value.map {
            if (it.id == restaurantId) it.copy(isFavorite = !it.isFavorite) else it
        }
        _restaurants.value = updated
    }

    // WAITLIST SYSTEM
    fun joinWaitlist(restaurantId: String, name: String, phone: String, partySize: Int): WaitlistEntry {
        val active = _waitlist.value.filter { it.restaurantId == restaurantId && it.customerPhone == phone && it.status != WaitlistStatus.CANCELLED && it.status != WaitlistStatus.SEATED && it.status != WaitlistStatus.EXPIRED }
        if (active.isNotEmpty()) {
            return active.first() // Already joined
        }

        val rest = _restaurants.value.find { it.id == restaurantId }
        val waitMinutes = rest?.currentWaitMinutes ?: 20
        val position = (_waitlist.value.count { it.restaurantId == restaurantId && it.status == WaitlistStatus.WAITING } + 4).coerceAtLeast(1)

        val entry = WaitlistEntry(
            id = "OG-WL-${System.currentTimeMillis() % 10000}",
            restaurantId = restaurantId,
            customerName = name,
            customerPhone = phone,
            partySize = partySize,
            joinedAt = getCurrentTimestamp(),
            estimatedWaitMinutes = (waitMinutes + (partySize * 2)).coerceAtLeast(5),
            position = position,
            status = WaitlistStatus.JOINED
        )
        
        _waitlist.value = _waitlist.value + entry
        logAudit(AuditAction.WAITLIST_UPDATED, "Customer $name (Party of $partySize) joined waitlist at $restaurantId (Pos: $position)", "System")

        // Progress state machine automatically in background or when manually operated by staff
        return entry
    }

    fun updateWaitlistStatus(id: String, newStatus: WaitlistStatus, tableAssigned: String? = null) {
        val updated = _waitlist.value.map { entry ->
            if (entry.id == id) {
                // Ensure invariant: can't seat twice
                if (entry.status == WaitlistStatus.SEATED && newStatus == WaitlistStatus.SEATED) {
                    return@map entry
                }
                val nextPos = if (newStatus == WaitlistStatus.SEATED || newStatus == WaitlistStatus.CANCELLED) 0 else entry.position
                val nextWait = if (newStatus == WaitlistStatus.SEATED || newStatus == WaitlistStatus.CANCELLED) 0 else (entry.estimatedWaitMinutes - 5).coerceAtLeast(0)
                
                logAudit(AuditAction.WAITLIST_UPDATED, "Waitlist entry $id status changed from ${entry.status} to $newStatus", "HQ User")
                entry.copy(status = newStatus, tableAssigned = tableAssigned ?: entry.tableAssigned, position = nextPos, estimatedWaitMinutes = nextWait)
            } else entry
        }
        _waitlist.value = updated
    }

    // ORDER ENGINE
    fun placeOrder(
        restaurantId: String,
        items: List<CartItem>,
        orderType: OrderType,
        carDetails: String?,
        paymentMethod: String,
        scheduledTime: String = "As soon as possible (20 mins)"
    ): Order {
        val rest = _restaurants.value.find { it.id == restaurantId } ?: _restaurants.value.first()
        
        // Invariant check: Cannot order from closed restaurant
        if (rest.status == RestaurantStatus.CLOSED || rest.status == RestaurantStatus.SYSTEM_OFFLINE) {
            throw IllegalStateException("This restaurant is currently closed and not accepting digital orders.")
        }

        // Invariant check: Cannot order unavailable items
        items.forEach { cartItem ->
            if (!cartItem.menuItem.available) {
                throw IllegalStateException("The item ${cartItem.menuItem.name} is currently out of stock.")
            }
        }

        val subtotal = items.sumOf { it.totalPrice }
        val tax = subtotal * 0.07 // 7% standard tax
        val deliveryFee = if (orderType == OrderType.DELIVERY) 4.99 else 0.0
        val total = subtotal + tax + deliveryFee

        val order = Order(
            id = "OG-ORD-${10000 + (System.currentTimeMillis() % 90000)}",
            restaurantId = restaurantId,
            restaurantName = rest.name,
            items = items,
            subtotal = subtotal,
            tax = tax,
            deliveryFee = deliveryFee,
            total = total,
            orderType = orderType,
            status = OrderStatus.CREATED,
            createdAt = getCurrentTimestamp(),
            scheduledTime = scheduledTime,
            customerName = currentCustomerName,
            customerPhone = currentCustomerPhone,
            customerEmail = currentCustomerEmail,
            deliveryAddress = if (orderType == OrderType.DELIVERY) "742 Evergreen Terrace, Orlando, FL" else null,
            paymentMethod = paymentMethod,
            carDetails = carDetails
        )

        // Deduct/reserve inventory
        items.forEach { cartItem ->
            reserveInventory(cartItem)
        }

        _orders.value = listOf(order) + _orders.value
        logAudit(AuditAction.ORDER_ACCEPTED, "Order ${order.id} placed at ${rest.name} for ${order.orderType}", "Customer App")
        
        return order
    }

    fun updateOrderStatus(orderId: String, nextStatus: OrderStatus) {
        val updated = _orders.value.map { order ->
            if (order.id == orderId) {
                // Invariants:
                // An order cannot become READY without being accepted/prepared
                if (nextStatus == OrderStatus.READY && order.status != OrderStatus.PREPARING && order.status != OrderStatus.ACCEPTED) {
                    return@map order
                }
                // An order cannot become COMPLETED without collection/delivery
                if (nextStatus == OrderStatus.COMPLETED && order.status != OrderStatus.READY && order.status != OrderStatus.OUT_FOR_DELIVERY) {
                    return@map order
                }
                // A cancelled order cannot return to PREPARING
                if (order.status == OrderStatus.CANCELLED && nextStatus == OrderStatus.PREPARING) {
                    return@map order
                }

                logAudit(AuditAction.ORDER_ACCEPTED, "Order $orderId status updated from ${order.status} to $nextStatus", "HQ Operations")
                
                // If order is completed or cancelled, release/deplete inventory accordingly
                if (nextStatus == OrderStatus.COMPLETED) {
                    order.items.forEach { finalizeInventoryDepletion(it) }
                } else if (nextStatus == OrderStatus.CANCELLED) {
                    order.items.forEach { releaseInventoryReservation(it) }
                }

                order.copy(status = nextStatus)
            } else order
        }
        _orders.value = updated
    }

    // INVENTORY MANAGEMENT
    private fun reserveInventory(cartItem: CartItem) {
        val pastaKey = "inv_${cartItem.selectedPasta?.lowercase() ?: ""}"
        val sauceKey = "inv_${cartItem.selectedSauce?.lowercase() ?: ""}"
        
        val updated = _inventory.value.map { item ->
            if (item.id == pastaKey || item.id == sauceKey || item.id == "inv_breadsticks") {
                val qtyToReserve = cartItem.quantity * (if (item.id == "inv_breadsticks") 2 else 1)
                item.copy(
                    reservedQty = item.reservedQty + qtyToReserve,
                    status = if (item.onHandQty - (item.reservedQty + qtyToReserve) <= 5) StockLevel.LOW_STOCK else StockLevel.ON_HAND
                )
            } else item
        }
        _inventory.value = updated
    }

    private fun finalizeInventoryDepletion(cartItem: CartItem) {
        val pastaKey = "inv_${cartItem.selectedPasta?.lowercase() ?: ""}"
        val sauceKey = "inv_${cartItem.selectedSauce?.lowercase() ?: ""}"

        val updated = _inventory.value.map { item ->
            if (item.id == pastaKey || item.id == sauceKey || item.id == "inv_breadsticks") {
                val qtyToDeplete = cartItem.quantity * (if (item.id == "inv_breadsticks") 2 else 1)
                val newOnHand = (item.onHandQty - qtyToDeplete).coerceAtLeast(0)
                val newReserved = (item.reservedQty - qtyToDeplete).coerceAtLeast(0)
                item.copy(
                    onHandQty = newOnHand,
                    reservedQty = newReserved,
                    status = if (newOnHand - newReserved <= 0) StockLevel.OUT_OF_STOCK else if (newOnHand - newReserved <= 10) StockLevel.LOW_STOCK else StockLevel.ON_HAND
                )
            } else item
        }
        _inventory.value = updated
    }

    private fun releaseInventoryReservation(cartItem: CartItem) {
        val pastaKey = "inv_${cartItem.selectedPasta?.lowercase() ?: ""}"
        val sauceKey = "inv_${cartItem.selectedSauce?.lowercase() ?: ""}"

        val updated = _inventory.value.map { item ->
            if (item.id == pastaKey || item.id == sauceKey || item.id == "inv_breadsticks") {
                val qtyToRelease = cartItem.quantity * (if (item.id == "inv_breadsticks") 2 else 1)
                val newReserved = (item.reservedQty - qtyToRelease).coerceAtLeast(0)
                item.copy(
                    reservedQty = newReserved,
                    status = if (item.onHandQty - newReserved <= 10) StockLevel.LOW_STOCK else StockLevel.ON_HAND
                )
            } else item
        }
        _inventory.value = updated
    }

    fun adjustInventory(itemId: String, adjustAmount: Int) {
        val updated = _inventory.value.map { item ->
            if (item.id == itemId) {
                val newOnHand = (item.onHandQty + adjustAmount).coerceAtLeast(0)
                logAudit(AuditAction.INVENTORY_ADJUSTED, "Adjusted ${item.name} inventory by $adjustAmount units. New quantity: $newOnHand", "HQ Inventory Manager")
                item.copy(
                    onHandQty = newOnHand,
                    status = if (newOnHand - item.reservedQty <= 0) StockLevel.OUT_OF_STOCK else if (newOnHand - item.reservedQty <= 10) StockLevel.LOW_STOCK else StockLevel.ON_HAND
                )
            } else item
        }
        _inventory.value = updated
    }

    // CATERING ORDER
    fun placeCateringOrder(
        eventType: CateringEventType,
        guests: Int,
        date: String,
        time: String,
        orderType: OrderType,
        items: List<CartItem>,
        setupOptionsEnabled: Boolean
    ): CateringOrder {
        val subtotal = items.sumOf { it.totalPrice }
        
        // Rules for Delivery:
        // $100 minimum order, delivery fee = 10% of subtotal or $15 (whichever is greater)
        if (orderType == OrderType.DELIVERY && subtotal < 100.0) {
            throw IllegalArgumentException("Catering delivery requires a minimum order subtotal of $100.00.")
        }
        val deliveryFee = if (orderType == OrderType.DELIVERY) (subtotal * 0.1).coerceAtLeast(15.0) else 0.0
        val setupFee = if (setupOptionsEnabled) 20.00 else 0.00
        val tax = subtotal * 0.07
        val total = subtotal + deliveryFee + setupFee + tax

        val catOrder = CateringOrder(
            id = "OG-CAT-${20000 + (System.currentTimeMillis() % 80000)}",
            eventType = eventType,
            guestCount = guests,
            eventDate = date,
            eventTime = time,
            orderType = orderType,
            items = items,
            subtotal = subtotal,
            deliveryFee = deliveryFee,
            setupFee = setupFee,
            tax = tax,
            total = total,
            status = OrderStatus.CREATED,
            customerName = currentCustomerName,
            customerPhone = currentCustomerPhone,
            customerEmail = currentCustomerEmail,
            setupOptionsEnabled = setupOptionsEnabled
        )

        _cateringOrders.value = listOf(catOrder) + _cateringOrders.value
        logAudit(AuditAction.CATERING_ORDER_CHANGED, "Catering booking placed for ${eventType.name} on $date ($guests guests, total: $$total)", "Catering App")
        
        return catOrder
    }

    // ECLUB SUBSCRIPTION
    fun subscribeToEClub(email: String, zip: String, birthday: String, preferences: List<String>): Boolean {
        if (_eClubSubscriptions.value.any { it.email.lowercase() == email.lowercase() }) {
            return false // Already subscribed
        }
        val sub = EClubSubscription(email, zip, birthday, preferences, getCurrentTimestamp())
        _eClubSubscriptions.value = _eClubSubscriptions.value + sub
        logAudit(AuditAction.OFFER_PUBLISHED, "New eClub subscription registered: $email", "eClub Form")
        return true
    }

    // GIFT CARDS BUY/RELOAD
    fun buyGiftCard(amount: Double, recipient: String?): GiftCard {
        val gc = GiftCard(
            id = "OG-GC-${1000 + Random().nextInt(9000)}",
            balance = amount,
            currency = "USD",
            isDigital = true,
            recipientEmail = recipient ?: currentCustomerEmail,
            issuedAt = getCurrentTimestamp(),
            active = true,
            transactions = listOf(GiftCardTransaction("T-INIT-${System.currentTimeMillis() % 1000}", amount, "PURCHASE", getCurrentTimestamp()))
        )
        _giftCards.value = _giftCards.value + gc
        logAudit(AuditAction.GIFT_CARD_ISSUED, "New digital Gift Card issued to ${recipient ?: currentCustomerEmail} (Balance: $$amount)", "Billing Service")
        return gc
    }

    fun reloadGiftCard(cardId: String, amount: Double): Boolean {
        var success = false
        val updated = _giftCards.value.map { card ->
            if (card.id == cardId && card.active) {
                success = true
                val newTransactions = card.transactions + GiftCardTransaction(
                    transactionId = "T-RLD-${System.currentTimeMillis() % 1000}",
                    amount = amount,
                    type = "RELOAD",
                    timestamp = getCurrentTimestamp()
                )
                logAudit(AuditAction.GIFT_CARD_ISSUED, "Reloaded $$amount onto Gift Card $cardId. New balance: $${card.balance + amount}", "Billing Service")
                card.copy(balance = card.balance + amount, transactions = newTransactions)
            } else card
        }
        if (success) {
            _giftCards.value = updated
        }
        return success
    }

    fun checkGiftCardBalance(cardId: String): Double? {
        // Find existing card or return null
        return _giftCards.value.find { it.id == cardId && it.active }?.balance
    }

    // AUDIT LOGS
    fun logAudit(action: AuditAction, details: String, performedBy: String) {
        val event = AuditEvent(
            action = action,
            details = details,
            timestamp = getCurrentTimestamp(),
            performedBy = performedBy
        )
        _auditEvents.value = listOf(event) + _auditEvents.value
    }

    // UPDATE RESTAURANT STATE (HQ)
    fun updateRestaurantStatus(id: String, newStatus: RestaurantStatus) {
        val updated = _restaurants.value.map { rest ->
            if (rest.id == id) {
                logAudit(AuditAction.RESTAURANT_STATUS_CHANGED, "Restaurant ${rest.name} status changed to $newStatus", "HQ Admin")
                rest.copy(status = newStatus)
            } else rest
        }
        _restaurants.value = updated
    }

    // SEARCH & FILTER RESTAURANTS (supports search queries with synthetic counts added)
    fun searchRestaurants(query: String): List<Restaurant> {
        val trimmed = query.trim().lowercase()
        if (trimmed.isEmpty()) return _restaurants.value

        // Filter seeded ones
        val matched = _restaurants.value.filter {
            it.name.lowercase().contains(trimmed) || 
            it.address.lowercase().contains(trimmed) ||
            trimmed.contains(it.id.lowercase())
        }

        // If queries for common US locations, return dynamic matched restaurants with synthetic tags
        return matched
    }
}
