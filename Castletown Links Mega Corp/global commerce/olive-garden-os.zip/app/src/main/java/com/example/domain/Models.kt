package com.example.domain

import java.io.Serializable
import java.util.UUID

// Verification state for Nutrition/Allergens
enum class InfoVerification {
    DECLARED,
    VERIFIED,
    LOCATION_DEPENDENT,
    UNKNOWN
}

// Diet types
enum class DietaryTag {
    GLUTEN_SENSITIVE,
    VEGETARIAN,
    VEGAN,
    NONE
}

// Nutrition Profile
data class NutritionProfile(
    val calories: Int,
    val fatGrams: Int,
    val carbsGrams: Int,
    val proteinGrams: Int,
    val sodiumMg: Int,
    val ingredients: List<String>,
    val allergens: List<String>,
    val dietaryTags: List<DietaryTag>,
    val verification: InfoVerification
) : Serializable

// MenuItem Model
data class MenuItem(
    val id: String,
    val name: String,
    val description: String,
    val category: String, // e.g., "Classic Entrées", "Soups, Salad & Breadsticks"
    val price: Double,
    val calories: Int,
    val imageUrl: String, // Or simulated identifier
    val nutrition: NutritionProfile,
    val customizable: Boolean = false,
    val available: Boolean = true
) : Serializable

// Modifier for customization
data class MenuModifier(
    val id: String,
    val name: String,
    val category: String, // e.g., "Pasta", "Sauce", "Topping"
    val priceAdjustment: Double,
    val calories: Int
) : Serializable

// Cart Item
data class CartItem(
    val id: String = UUID.randomUUID().toString(),
    val menuItem: MenuItem,
    val quantity: Int,
    val selectedPasta: String? = null,
    val selectedSauce: String? = null,
    val selectedToppings: List<String> = emptyList(),
    val specialInstructions: String = ""
) {
    val totalPrice: Double
        get() = (menuItem.price + 
                (if (selectedPasta != null && selectedPasta != "Fettuccine" && selectedPasta != "Spaghetti" && selectedPasta != "Rigatoni") 1.0 else 0.0) +
                (if (selectedSauce != null && selectedSauce != "Alfredo" && selectedSauce != "Marinara") 1.5 else 0.0) +
                selectedToppings.size * 2.5) * quantity
}

// Restaurant hours
data class RestaurantHours(
    val weekday: String, // "11:00 AM - 10:00 PM"
    val weekend: String, // "11:00 AM - 11:00 PM"
    val holiday: String = "Closed on Thanksgiving and Christmas"
) : Serializable

// Restaurant States
enum class RestaurantStatus {
    OPEN,
    CLOSED,
    BUSY,
    TEMPORARILY_CLOSED,
    KITCHEN_DELAY,
    SYSTEM_OFFLINE
}

// Restaurant Entity
data class Restaurant(
    val id: String,
    val name: String,
    val address: String,
    val phone: String,
    val latitude: Double,
    val longitude: Double,
    val hours: RestaurantHours,
    val currentWaitMinutes: Int,
    val status: RestaurantStatus,
    val isFavorite: Boolean = false,
    val carsidePickupEnabled: Boolean = true,
    val deliveryEnabled: Boolean = true,
    val waitlistEnabled: Boolean = true,
    val cateringEnabled: Boolean = true
) : Serializable

// Waitlist Status Machine
enum class WaitlistStatus {
    JOINED,
    WAITING,
    APPROACHING,
    READY,
    CHECKED_IN,
    SEATED,
    CANCELLED,
    EXPIRED
}

// Waitlist Entry
data class WaitlistEntry(
    val id: String,
    val restaurantId: String,
    val customerName: String,
    val customerPhone: String,
    val partySize: Int,
    val joinedAt: String, // ISO representation
    val estimatedWaitMinutes: Int,
    val position: Int,
    val status: WaitlistStatus,
    val tableAssigned: String? = null
) : Serializable

// Order Type
enum class OrderType {
    PICKUP,
    CARSIDE_PICKUP,
    DELIVERY
}

// Order Status Machine
enum class OrderStatus {
    CREATED,
    PAYMENT_PENDING,
    PAID,
    RECEIVED,
    ACCEPTED,
    PREPARING,
    READY,
    OUT_FOR_DELIVERY,
    COLLECTED,
    DELIVERED,
    COMPLETED,
    CANCELLED,
    FAILED,
    REFUNDED
}

// Order Entity
data class Order(
    val id: String,
    val restaurantId: String,
    val restaurantName: String,
    val items: List<CartItem>,
    val subtotal: Double,
    val tax: Double,
    val deliveryFee: Double,
    val total: Double,
    val orderType: OrderType,
    val status: OrderStatus,
    val createdAt: String,
    val scheduledTime: String,
    val customerName: String,
    val customerPhone: String,
    val customerEmail: String,
    val deliveryAddress: String? = null,
    val paymentMethod: String,
    val carDetails: String? = null // For carside pickup
) : Serializable

// Catering Event Type
enum class CateringEventType {
    OFFICE,
    FAMILY,
    BIRTHDAY,
    WEDDING,
    PARTY,
    OTHER
}

// Catering Order
data class CateringOrder(
    val id: String,
    val eventType: CateringEventType,
    val guestCount: Int,
    val eventDate: String,
    val eventTime: String,
    val orderType: OrderType,
    val items: List<CartItem>,
    val subtotal: Double,
    val deliveryFee: Double,
    val setupFee: Double,
    val tax: Double,
    val total: Double,
    val status: OrderStatus,
    val customerName: String,
    val customerPhone: String,
    val customerEmail: String,
    val setupOptionsEnabled: Boolean = true
) : Serializable

// Gift Card
data class GiftCard(
    val id: String,
    val balance: Double,
    val currency: String = "USD",
    val isDigital: Boolean = true,
    val recipientEmail: String? = null,
    val issuedAt: String,
    val active: Boolean = true,
    val transactions: List<GiftCardTransaction> = emptyList()
) : Serializable

data class GiftCardTransaction(
    val transactionId: String,
    val amount: Double,
    val type: String, // "PURCHASE", "RELOAD", "SPEND"
    val timestamp: String
) : Serializable

// Offers
data class Offer(
    val id: String,
    val title: String,
    val description: String,
    val eligibility: String,
    val expiryDate: String,
    val restriction: String,
    val promoCode: String
) : Serializable

// eClub subscription
data class EClubSubscription(
    val email: String,
    val zipCode: String,
    val birthday: String,
    val marketingPreferences: List<String>,
    val subscribedAt: String
) : Serializable

// Inventory Status
enum class StockLevel {
    ON_HAND,
    RESERVED,
    AVAILABLE,
    LOW_STOCK,
    OUT_OF_STOCK
}

// Inventory Item
data class InventoryItem(
    val id: String,
    val name: String,
    val category: String, // "Pasta", "Sauce", "Topping", "Salad", "Beverage"
    val onHandQty: Int,
    val reservedQty: Int,
    val status: StockLevel
) {
    val availableQty: Int
        get() = (onHandQty - reservedQty).coerceAtLeast(0)
}

// HQ Audit Event type
enum class AuditAction {
    MENU_ITEM_PRICE_CHANGED,
    INVENTORY_ADJUSTED,
    ORDER_ACCEPTED,
    ORDER_CANCELLED,
    WAITLIST_UPDATED,
    CATERING_ORDER_CHANGED,
    OFFER_PUBLISHED,
    GIFT_CARD_ISSUED,
    RESTAURANT_STATUS_CHANGED
}

// Audit Event
data class AuditEvent(
    val id: String = UUID.randomUUID().toString(),
    val action: AuditAction,
    val details: String,
    val timestamp: String,
    val performedBy: String
) : Serializable
