package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.backend.OliveGardenBackend
import com.example.domain.*
import com.example.ui.*
import com.example.ui.theme.*

@Composable
fun OperationsHqScreen(viewModel: OliveGardenViewModel, modifier: Modifier = Modifier) {
    val currentTab by viewModel.selectedHQTab.collectAsState()

    Row(modifier = modifier.fillMaxSize()) {
        // Left rail navigation bar (Highly polished management mode as requested for Tablets/Large Screens)
        NavigationRail(
            containerColor = EspressoBrown,
            contentColor = WarmCream,
            header = {
                Icon(
                    Icons.Default.Settings,
                    contentDescription = null,
                    tint = GoldGlaze,
                    modifier = Modifier
                        .padding(vertical = 16.dp)
                        .size(32.dp)
                )
            }
        ) {
            NavigationRailItem(
                selected = currentTab == HQTab.DASHBOARD,
                onClick = { viewModel.selectHQTab(HQTab.DASHBOARD) },
                icon = { Icon(Icons.Default.Dashboard, contentDescription = "Dashboard") },
                label = { Text("HQ Home", fontSize = 10.sp) },
                colors = NavigationRailItemDefaults.colors(
                    selectedIconColor = EspressoBrown,
                    selectedTextColor = GoldGlaze,
                    indicatorColor = GoldGlaze,
                    unselectedIconColor = WarmCream,
                    unselectedTextColor = WarmCream
                )
            )
            NavigationRailItem(
                selected = currentTab == HQTab.WAITLIST_HQ,
                onClick = { viewModel.selectHQTab(HQTab.WAITLIST_HQ) },
                icon = { Icon(Icons.Default.People, contentDescription = "Waitlist") },
                label = { Text("Waitlist", fontSize = 10.sp) },
                colors = NavigationRailItemDefaults.colors(
                    selectedIconColor = EspressoBrown,
                    selectedTextColor = GoldGlaze,
                    indicatorColor = GoldGlaze,
                    unselectedIconColor = WarmCream,
                    unselectedTextColor = WarmCream
                )
            )
            NavigationRailItem(
                selected = currentTab == HQTab.KITCHEN_BOARD,
                onClick = { viewModel.selectHQTab(HQTab.KITCHEN_BOARD) },
                icon = { Icon(Icons.Default.SoupKitchen, contentDescription = "Kitchen") },
                label = { Text("Kitchen", fontSize = 10.sp) },
                colors = NavigationRailItemDefaults.colors(
                    selectedIconColor = EspressoBrown,
                    selectedTextColor = GoldGlaze,
                    indicatorColor = GoldGlaze,
                    unselectedIconColor = WarmCream,
                    unselectedTextColor = WarmCream
                )
            )
            NavigationRailItem(
                selected = currentTab == HQTab.INVENTORY,
                onClick = { viewModel.selectHQTab(HQTab.INVENTORY) },
                icon = { Icon(Icons.Default.Inventory, contentDescription = "Inventory") },
                label = { Text("Inventory", fontSize = 10.sp) },
                colors = NavigationRailItemDefaults.colors(
                    selectedIconColor = EspressoBrown,
                    selectedTextColor = GoldGlaze,
                    indicatorColor = GoldGlaze,
                    unselectedIconColor = WarmCream,
                    unselectedTextColor = WarmCream
                )
            )
            NavigationRailItem(
                selected = currentTab == HQTab.ANALYTICS_AUDITS,
                onClick = { viewModel.selectHQTab(HQTab.ANALYTICS_AUDITS) },
                icon = { Icon(Icons.Default.History, contentDescription = "Audits") },
                label = { Text("Audits", fontSize = 10.sp) },
                colors = NavigationRailItemDefaults.colors(
                    selectedIconColor = EspressoBrown,
                    selectedTextColor = GoldGlaze,
                    indicatorColor = GoldGlaze,
                    unselectedIconColor = WarmCream,
                    unselectedTextColor = WarmCream
                )
            )
        }

        // Main operation workspace panel
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(WarmCream)
                .padding(16.dp)
        ) {
            when (currentTab) {
                HQTab.DASHBOARD -> HqDashboardScreen(viewModel)
                HQTab.WAITLIST_HQ -> WaitlistHqScreen(viewModel)
                HQTab.KITCHEN_BOARD -> KitchenBoardScreen(viewModel)
                HQTab.INVENTORY -> InventoryControlScreen(viewModel)
                HQTab.ANALYTICS_AUDITS -> AnalyticsAndAuditsScreen(viewModel)
            }
        }
    }
}

// 1. HQ EXECUTIVE DASHBOARD
@Composable
fun HqDashboardScreen(viewModel: OliveGardenViewModel) {
    val orders by viewModel.orders.collectAsState()
    val waitlist by viewModel.waitlist.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("hq_dashboard_scroll"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "OLIVE GARDEN HQ OPERATIONS",
                        fontFamily = FontFamily.Serif,
                        style = MaterialTheme.typography.titleLarge,
                        color = EspressoBrown,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Real-time operating platform across connected kitchens and guest tables.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(GoldGlaze)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text("DETERMINISTIC SYNTHETIC ACTIVE", color = EspressoBrown, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Operational Overview metrics grids
        item {
            Column {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    MetricCard(
                        title = "Online Restaurants",
                        value = OliveGardenBackend.SYNTHETIC_RESTAURANTS_COUNT.toString(),
                        indicator = "Live Sync",
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "Total Active Orders",
                        value = orders.count { it.status != OrderStatus.COMPLETED && it.status != OrderStatus.CANCELLED }.toString(),
                        indicator = "Kitchen Board",
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(16.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    MetricCard(
                        title = "Waitlist Registries",
                        value = waitlist.count { it.status == WaitlistStatus.WAITING || it.status == WaitlistStatus.JOINED }.toString(),
                        indicator = "Host Station",
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "Daily Revenue (Sim)",
                        value = "$${String.format("%.2f", 42350.0 + orders.sumOf { it.total })}",
                        indicator = "Sales Engine",
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Live Operational Alerts
        item {
            Text(
                text = "OPERATING SYSTEM SIGNATURES",
                fontFamily = FontFamily.Serif,
                style = MaterialTheme.typography.titleMedium,
                color = OliveGardenGreen,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = WhiteNapkin)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Dine-In Signature Flow Indicator",
                        fontWeight = FontWeight.Bold,
                        color = EspressoBrown
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Customer Waitlist -> Seated -> Kitchen preparing -> Prepared -> Customer pickup loop is active.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { viewModel.selectHQTab(HQTab.WAITLIST_HQ) },
                            colors = ButtonDefaults.buttonColors(containerColor = OliveGardenGreen)
                        ) {
                            Text("GO TO HOST WAITLIST")
                        }
                        Button(
                            onClick = { viewModel.selectHQTab(HQTab.KITCHEN_BOARD) },
                            colors = ButtonDefaults.buttonColors(containerColor = DeepItalianRed)
                        ) {
                            Text("GO TO KITCHEN BOARD")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MetricCard(title: String, value: String, indicator: String, modifier: Modifier = Modifier) {
    Card(
        colors = CardDefaults.cardColors(containerColor = WhiteNapkin),
        modifier = modifier,
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(title, color = Color.Gray, style = MaterialTheme.typography.labelMedium)
                Icon(Icons.Default.TrendingUp, contentDescription = null, tint = OliveGardenGreen, modifier = Modifier.size(16.dp))
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(value, fontSize = 28.sp, fontWeight = FontWeight.Bold, color = EspressoBrown, fontFamily = FontFamily.Serif)
            Spacer(modifier = Modifier.height(4.dp))
            Text(indicator, color = OliveGardenGreen, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
        }
    }
}

// 2. WAITLIST OPERATIONS HQ
@Composable
fun WaitlistHqScreen(viewModel: OliveGardenViewModel) {
    val waitlist by viewModel.waitlist.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        Text(
            text = "HOST STAND WAITLIST BOARD",
            fontFamily = FontFamily.Serif,
            style = MaterialTheme.typography.titleLarge,
            color = EspressoBrown,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Manage incoming dining parties, record arrivals, and coordinate tables.",
            style = MaterialTheme.typography.bodySmall,
            color = Color.Gray
        )
        Spacer(modifier = Modifier.height(16.dp))

        if (waitlist.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("Waitlist is currently empty. No guests registered.", color = Color.Gray, style = MaterialTheme.typography.bodyLarge)
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("waitlist_hq_scroll")
            ) {
                items(waitlist) { entry ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = WhiteNapkin),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "${entry.customerName.uppercase()} • Party of ${entry.partySize}",
                                        fontFamily = FontFamily.Serif,
                                        fontWeight = FontWeight.Bold,
                                        color = EspressoBrown
                                    )
                                    Text("Phone: ${entry.customerPhone} • Joined: ${entry.joinedAt.substring(11, 16)}", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (entry.status == WaitlistStatus.READY) GoldGlaze else if (entry.status == WaitlistStatus.SEATED) OliveGardenGreen else Color.LightGray)
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(entry.status.name, fontSize = 10.sp, color = EspressoBrown, fontWeight = FontWeight.Bold)
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                when (entry.status) {
                                    WaitlistStatus.JOINED, WaitlistStatus.WAITING -> {
                                        Button(
                                            onClick = { viewModel.hqUpdateWaitlistStatus(entry.id, WaitlistStatus.READY) },
                                            colors = ButtonDefaults.buttonColors(containerColor = OliveGardenGreen)
                                        ) {
                                            Text("MARK TABLE READY")
                                        }
                                        OutlinedButton(
                                            onClick = { viewModel.hqUpdateWaitlistStatus(entry.id, WaitlistStatus.CANCELLED) },
                                            colors = ButtonDefaults.outlinedButtonColors(contentColor = DeepItalianRed)
                                        ) {
                                            Text("CANCEL")
                                        }
                                    }
                                    WaitlistStatus.READY, WaitlistStatus.CHECKED_IN -> {
                                        Button(
                                            onClick = { viewModel.hqUpdateWaitlistStatus(entry.id, WaitlistStatus.SEATED, "Table 14") },
                                            colors = ButtonDefaults.buttonColors(containerColor = OliveGardenGreen)
                                        ) {
                                            Text("SEAT GUESTS (TABLE 14)")
                                        }
                                    }
                                    WaitlistStatus.SEATED -> {
                                        Text("Guest is successfully seated at Table 14.", style = MaterialTheme.typography.bodyMedium, color = Color.Gray)
                                    }
                                    else -> {
                                        Text("No actions available for cancelled or expired entries.", style = MaterialTheme.typography.bodyMedium, color = Color.Gray)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 3. KITCHEN ORDER TICKETS BOARD
@Composable
fun KitchenBoardScreen(viewModel: OliveGardenViewModel) {
    val orders by viewModel.orders.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        Text(
            text = "KITCHEN ORDER TICKETS BOARD",
            fontFamily = FontFamily.Serif,
            style = MaterialTheme.typography.titleLarge,
            color = EspressoBrown,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Track incoming meal requests, accept tickets, and coordinate preparation pipelines.",
            style = MaterialTheme.typography.bodySmall,
            color = Color.Gray
        )
        Spacer(modifier = Modifier.height(16.dp))

        val activeOrders = orders.filter { it.status != OrderStatus.COMPLETED && it.status != OrderStatus.CANCELLED }

        if (activeOrders.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("Kitchen is clear! No active food orders in preparation.", color = Color.Gray, style = MaterialTheme.typography.bodyLarge)
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("kitchen_board_scroll")
            ) {
                items(activeOrders) { order ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = WhiteNapkin),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "TICKET: ${order.id} [${order.orderType.name}]",
                                        fontFamily = FontFamily.Serif,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = EspressoBrown
                                    )
                                    Text("Customer: ${order.customerName} • Placed: ${order.createdAt.substring(11, 16)}", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (order.status == OrderStatus.PREPARING) DeepItalianRed else OliveGardenGreen)
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(order.status.name, fontSize = 10.sp, color = PureWhite, fontWeight = FontWeight.Bold)
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))
                            Divider()
                            Spacer(modifier = Modifier.height(12.dp))

                            Text("Dishes Ordered:", fontWeight = FontWeight.Bold, color = EspressoBrown)
                            order.items.forEach { item ->
                                val modifierStr = if (item.selectedPasta != null) "(${item.selectedPasta} with ${item.selectedSauce} + ${item.selectedToppings.joinToString()})" else ""
                                Text(
                                    text = "• ${item.menuItem.name} x${item.quantity} $modifierStr",
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = EspressoBrown
                                )
                                if (item.specialInstructions.isNotEmpty()) {
                                    Text("  *Instructions: ${item.specialInstructions}", style = MaterialTheme.typography.bodyMedium, color = DeepItalianRed, fontWeight = FontWeight.SemiBold)
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                when (order.status) {
                                    OrderStatus.CREATED, OrderStatus.RECEIVED -> {
                                        Button(
                                            onClick = { viewModel.hqUpdateOrderStatus(order.id, OrderStatus.PREPARING) },
                                            colors = ButtonDefaults.buttonColors(containerColor = DeepItalianRed)
                                        ) {
                                            Text("START PREPARING")
                                        }
                                    }
                                    OrderStatus.ACCEPTED -> {
                                        Button(
                                            onClick = { viewModel.hqUpdateOrderStatus(order.id, OrderStatus.PREPARING) },
                                            colors = ButtonDefaults.buttonColors(containerColor = DeepItalianRed)
                                        ) {
                                            Text("START PREPARING")
                                        }
                                    }
                                    OrderStatus.PREPARING -> {
                                        Button(
                                            onClick = { viewModel.hqUpdateOrderStatus(order.id, OrderStatus.READY) },
                                            colors = ButtonDefaults.buttonColors(containerColor = OliveGardenGreen)
                                        ) {
                                            Text("MARK READY FOR PICKUP")
                                        }
                                    }
                                    OrderStatus.READY -> {
                                        Button(
                                            onClick = { viewModel.hqUpdateOrderStatus(order.id, OrderStatus.COMPLETED) },
                                            colors = ButtonDefaults.buttonColors(containerColor = OliveGardenGreen)
                                        ) {
                                            Text("MARK TICKET COLLECTED")
                                        }
                                    }
                                    else -> {}
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 4. INVENTORY CONTROL
@Composable
fun InventoryControlScreen(viewModel: OliveGardenViewModel) {
    val items by viewModel.inventory.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        Text(
            text = "RESTAURANT INGREDIENT INVENTORY",
            fontFamily = FontFamily.Serif,
            style = MaterialTheme.typography.titleLarge,
            color = EspressoBrown,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Monitor physical stock levels. Low or out of stock items will dynamically update user order parameters.",
            style = MaterialTheme.typography.bodySmall,
            color = Color.Gray
        )
        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier
                .fillMaxSize()
                .testTag("inventory_list_scroll")
        ) {
            items(items) { item ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = WhiteNapkin),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = item.name.uppercase(),
                                fontWeight = FontWeight.Bold,
                                color = EspressoBrown
                            )
                            Text("Category: ${item.category} • On Hand: ${item.onHandQty} Units", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                            Text("Reserved for Orders: ${item.reservedQty} Units", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (item.status == StockLevel.OUT_OF_STOCK) DeepItalianRed else if (item.status == StockLevel.LOW_STOCK) GoldGlaze else OliveGardenGreen)
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(item.status.name, fontSize = 9.sp, color = EspressoBrown, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                IconButton(
                                    onClick = { viewModel.hqAdjustInventory(item.id, -50) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(Icons.Default.RemoveCircle, contentDescription = "Reduce", tint = DeepItalianRed)
                                }
                                IconButton(
                                    onClick = { viewModel.hqAdjustInventory(item.id, 100) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(Icons.Default.AddCircle, contentDescription = "Add", tint = OliveGardenGreen)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 5. IMMUTABLE SECURITY AUDIT LOGS & ANALYTICS
@Composable
fun AnalyticsAndAuditsScreen(viewModel: OliveGardenViewModel) {
    val auditEvents by viewModel.auditEvents.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        Text(
            text = "IMMUTABLE SECURITY AUDIT LOGS",
            fontFamily = FontFamily.Serif,
            style = MaterialTheme.typography.titleLarge,
            color = EspressoBrown,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Real-time records of security, configuration, pricing and operational adjustments.",
            style = MaterialTheme.typography.bodySmall,
            color = Color.Gray
        )
        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier
                .fillMaxSize()
                .testTag("audits_scroll")
        ) {
            items(auditEvents) { event ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = WhiteNapkin),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = event.action.name,
                                fontWeight = FontWeight.Bold,
                                color = DeepItalianRed,
                                fontSize = 12.sp
                            )
                            Text(
                                text = event.timestamp.substring(11, 19),
                                color = Color.Gray,
                                fontSize = 11.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = event.details,
                            style = MaterialTheme.typography.bodyMedium,
                            color = EspressoBrown
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Performed by: ${event.performedBy}",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.Gray
                        )
                    }
                }
            }
        }
    }
}
