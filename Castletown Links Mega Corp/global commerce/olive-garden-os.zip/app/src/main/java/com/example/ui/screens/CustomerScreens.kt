package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.backend.OliveGardenBackend
import com.example.domain.*
import com.example.ui.*
import com.example.ui.theme.*

@Composable
fun CustomerAppScreen(viewModel: OliveGardenViewModel, modifier: Modifier = Modifier) {
    val currentTab by viewModel.selectedCustomerTab.collectAsState()

    Scaffold(
        modifier = modifier,
        bottomBar = {
            CustomerBottomNavigation(
                selectedTab = currentTab,
                onTabSelected = { viewModel.selectCustomerTab(it) }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
        ) {
            when (currentTab) {
                CustomerTab.HOME -> HomeScreen(viewModel)
                CustomerTab.MENU -> MenuScreen(viewModel)
                CustomerTab.LOCATIONS -> LocationsScreen(viewModel)
                CustomerTab.ACCOUNT -> AccountScreen(viewModel)
            }
        }
    }
}

@Composable
fun CustomerBottomNavigation(selectedTab: CustomerTab, onTabSelected: (CustomerTab) -> Unit) {
    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp
    ) {
        NavigationBarItem(
            selected = selectedTab == CustomerTab.HOME,
            onClick = { onTabSelected(CustomerTab.HOME) },
            icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
            label = { Text("Welcome", fontFamily = FontFamily.SansSerif) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = OliveGardenGreen,
                selectedTextColor = OliveGardenGreen,
                indicatorColor = WarmCream
            ),
            modifier = Modifier.testTag("nav_home")
        )
        NavigationBarItem(
            selected = selectedTab == CustomerTab.MENU,
            onClick = { onTabSelected(CustomerTab.MENU) },
            icon = { Icon(Icons.Default.RestaurantMenu, contentDescription = "Menu") },
            label = { Text("Our Menu", fontFamily = FontFamily.SansSerif) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = OliveGardenGreen,
                selectedTextColor = OliveGardenGreen,
                indicatorColor = WarmCream
            ),
            modifier = Modifier.testTag("nav_menu")
        )
        NavigationBarItem(
            selected = selectedTab == CustomerTab.LOCATIONS,
            onClick = { onTabSelected(CustomerTab.LOCATIONS) },
            icon = { Icon(Icons.Default.LocationOn, contentDescription = "Locations") },
            label = { Text("Locations", fontFamily = FontFamily.SansSerif) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = OliveGardenGreen,
                selectedTextColor = OliveGardenGreen,
                indicatorColor = WarmCream
            ),
            modifier = Modifier.testTag("nav_locations")
        )
        NavigationBarItem(
            selected = selectedTab == CustomerTab.ACCOUNT,
            onClick = { onTabSelected(CustomerTab.ACCOUNT) },
            icon = { Icon(Icons.Default.AccountCircle, contentDescription = "Account") },
            label = { Text("Your Table", fontFamily = FontFamily.SansSerif) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = OliveGardenGreen,
                selectedTextColor = OliveGardenGreen,
                indicatorColor = WarmCream
            ),
            modifier = Modifier.testTag("nav_account")
        )
    }
}

// 1. HOME SCREEN
@Composable
fun HomeScreen(viewModel: OliveGardenViewModel) {
    val selectedRest by viewModel.selectedRestaurant.collectAsState()
    val activeWaitlist by viewModel.myWaitlistEntry.collectAsState()
    val activeOrder by viewModel.myActiveOrder.collectAsState()
    val offers by viewModel.offers.collectAsState()
    val menuItems by viewModel.menuItems.collectAsState()

    var showQuickWaitlistDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("customer_home_scroll")
    ) {
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp)
            ) {
                Image(
                    painter = painterResource(id = com.example.R.drawable.img_olive_garden_table),
                    contentDescription = "Olive Garden Dining Table",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f))
                            )
                        )
                )
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(16.dp)
                ) {
                    Text(
                        text = "OLIVE GARDEN",
                        color = GoldGlaze,
                        style = MaterialTheme.typography.labelLarge,
                        letterSpacing = 3.sp
                    )
                    Text(
                        text = "WELCOME TO THE TABLE",
                        color = PureWhite,
                        style = MaterialTheme.typography.headlineLarge,
                        fontFamily = FontFamily.Serif
                    )
                }
            }
        }

        if (activeWaitlist != null || activeOrder != null) {
            item {
                Column(modifier = Modifier.padding(16.dp)) {
                    activeWaitlist?.let { entry ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = OliveGardenGreen),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 8.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "YOU'RE ON THE LIST • ${entry.status.name}",
                                        color = GoldGlaze,
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Position ${entry.position} • Est. Wait ${entry.estimatedWaitMinutes} mins",
                                        color = PureWhite,
                                        style = MaterialTheme.typography.bodyLarge
                                    )
                                }
                                Button(
                                    onClick = { viewModel.selectCustomerTab(CustomerTab.ACCOUNT) },
                                    colors = ButtonDefaults.buttonColors(containerColor = GoldGlaze, contentColor = EspressoBrown)
                                ) {
                                    Text("TRACK")
                                }
                            }
                        }
                    }

                    activeOrder?.let { order ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = DeepItalianRed),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "ACTIVE ORDER • ${order.status.name}",
                                        color = WarmCream,
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Total: $${String.format("%.2f", order.total)} • ${order.orderType}",
                                        color = PureWhite,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }
                                Button(
                                    onClick = { viewModel.selectCustomerTab(CustomerTab.ACCOUNT) },
                                    colors = ButtonDefaults.buttonColors(containerColor = WarmCream, contentColor = EspressoBrown)
                                ) {
                                    Text("VIEW")
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = { viewModel.selectCustomerTab(CustomerTab.MENU) },
                    colors = ButtonDefaults.buttonColors(containerColor = OliveGardenGreen),
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("action_order_to_go"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.ShoppingBag, contentDescription = null, modifier = Modifier.padding(end = 8.dp))
                    Text("ORDER TO GO", style = MaterialTheme.typography.labelLarge)
                }

                Button(
                    onClick = { showQuickWaitlistDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = DeepItalianRed),
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("action_join_waitlist"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.People, contentDescription = null, modifier = Modifier.padding(end = 8.dp))
                    Text("JOIN WAITLIST", style = MaterialTheme.typography.labelLarge)
                }
            }
        }

        item {
            selectedRest?.let { rest ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "YOUR OLIVE GARDEN",
                        fontFamily = FontFamily.Serif,
                        style = MaterialTheme.typography.titleMedium,
                        color = OliveGardenGreen,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    Card(
                        colors = CardDefaults.cardColors(containerColor = WhiteNapkin),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = rest.name,
                                    fontFamily = FontFamily.Serif,
                                    style = MaterialTheme.typography.titleLarge,
                                    color = EspressoBrown
                                )
                                Text(
                                    text = rest.status.name,
                                    color = if (rest.status == RestaurantStatus.OPEN) OliveGardenGreen else DeepItalianRed,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = rest.address,
                                color = Color.Gray,
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Timer, contentDescription = null, tint = OliveGardenGreen, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (rest.currentWaitMinutes > 0) "${rest.currentWaitMinutes} mins wait" else "No wait time",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        color = EspressoBrown
                                    )
                                }
                                TextButton(
                                    onClick = { viewModel.selectCustomerTab(CustomerTab.LOCATIONS) },
                                    colors = ButtonDefaults.textButtonColors(contentColor = DeepItalianRed)
                                ) {
                                    Text("Change Restaurant")
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Column(modifier = Modifier.padding(top = 8.dp, bottom = 16.dp)) {
                Text(
                    text = "POPULAR TONIGHT",
                    fontFamily = FontFamily.Serif,
                    style = MaterialTheme.typography.titleMedium,
                    color = OliveGardenGreen,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 12.dp)
                )
                val popularDishes = menuItems.filter { it.category != "Catering" && it.id != "cyo_pasta" }.take(5)
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(popularDishes) { menuItem ->
                        PopularFoodCard(menuItem = menuItem, onAdd = {
                            viewModel.addToCart(menuItem, 1)
                        })
                    }
                }
            }
        }

        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                Text(
                    text = "SPECIALS & OFFERS",
                    fontFamily = FontFamily.Serif,
                    style = MaterialTheme.typography.titleMedium,
                    color = OliveGardenGreen,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 12.dp)
                )
                offers.forEach { offer ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = WhiteNapkin),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = offer.title,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = DeepItalianRed
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = offer.description,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = EspressoBrown
                                )
                            }
                            IconButton(onClick = {}) {
                                Icon(Icons.Default.ContentCopy, contentDescription = "Copy code", tint = OliveGardenGreen)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showQuickWaitlistDialog) {
        var partySize by remember { mutableStateOf(2) }
        Dialog(onDismissRequest = { showQuickWaitlistDialog = false }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = WarmCream),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "JOIN THE WAITLIST",
                        fontFamily = FontFamily.Serif,
                        style = MaterialTheme.typography.titleLarge,
                        color = OliveGardenGreen,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        IconButton(
                            onClick = { if (partySize > 1) partySize-- },
                            enabled = partySize > 1
                        ) {
                            Icon(Icons.Default.RemoveCircleOutline, contentDescription = "Decrease", tint = OliveGardenGreen)
                        }
                        Text(
                            text = partySize.toString(),
                            style = MaterialTheme.typography.headlineLarge,
                            fontWeight = FontWeight.Bold,
                            color = EspressoBrown,
                            modifier = Modifier.padding(horizontal = 24.dp)
                        )
                        IconButton(onClick = { partySize++ }) {
                            Icon(Icons.Default.AddCircleOutline, contentDescription = "Increase", tint = OliveGardenGreen)
                        }
                    }
                    Spacer(modifier = Modifier.height(24.dp))
                    Button(
                        onClick = {
                            viewModel.joinWaitlist(partySize)
                            showQuickWaitlistDialog = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = OliveGardenGreen),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("submit_waitlist_btn")
                    ) {
                        Text("JOIN WAITLIST", color = PureWhite, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// 2. MENU SCREEN WITH CYO CONFIGURATOR
@Composable
fun MenuScreen(viewModel: OliveGardenViewModel) {
    val categories = listOf(
        "Soups, Salad & Breadsticks",
        "Appetizers",
        "Classic Entrées",
        "Create Your Own Pasta",
        "Desserts",
        "Catering"
    )
    var selectedCat by remember { mutableStateOf("Classic Entrées") }
    val menuItems by viewModel.menuItems.collectAsState()
    val cart by viewModel.cartItems.collectAsState()

    var showCyoDialog by remember { mutableStateOf(false) }
    var selectedMenuItemForCustomization by remember { mutableStateOf<MenuItem?>(null) }
    var showNutritionSheet by remember { mutableStateOf<MenuItem?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "OLIVE GARDEN MENU",
                    fontFamily = FontFamily.Serif,
                    style = MaterialTheme.typography.titleLarge,
                    color = EspressoBrown,
                    fontWeight = FontWeight.Bold
                )
            }

            Box {
                IconButton(onClick = { viewModel.selectCustomerTab(CustomerTab.ACCOUNT) }) {
                    Icon(Icons.Default.ShoppingBag, contentDescription = "Bag", tint = OliveGardenGreen, modifier = Modifier.size(28.dp))
                }
                if (cart.isNotEmpty()) {
                    Box(
                        modifier = Modifier
                            .size(18.dp)
                            .clip(RoundedCornerShape(9.dp))
                            .background(DeepItalianRed)
                            .align(Alignment.TopEnd),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = cart.sumOf { it.quantity }.toString(),
                            color = PureWhite,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        ScrollableTabRow(
            selectedTabIndex = categories.indexOf(selectedCat),
            containerColor = WarmCream,
            contentColor = OliveGardenGreen,
            edgePadding = 16.dp,
            divider = {}
        ) {
            categories.forEach { cat ->
                Tab(
                    selected = selectedCat == cat,
                    onClick = { selectedCat = cat },
                    text = {
                        Text(
                            text = cat.uppercase(),
                            fontWeight = FontWeight.SemiBold,
                            fontFamily = FontFamily.SansSerif,
                            fontSize = 12.sp
                        )
                    },
                    selectedContentColor = OliveGardenGreen,
                    unselectedContentColor = Color.Gray
                )
            }
        }

        val filteredList = menuItems.filter { it.category == selectedCat }
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .testTag("menu_items_scroll"),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (selectedCat == "Create Your Own Pasta") {
                item {
                    CateringOrCyoIntroCard(
                        title = "BUILD YOUR SIGNATURE BOWL",
                        desc = "Custom semolina pasta, savory rich sauces and handpicked toppings, cooked precisely.",
                        btnText = "START CREATING",
                        onAction = { showCyoDialog = true }
                    )
                }
            }

            items(filteredList) { menuItem ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = WhiteNapkin),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = menuItem.name,
                                fontFamily = FontFamily.Serif,
                                style = MaterialTheme.typography.titleMedium,
                                color = EspressoBrown,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "$${String.format("%.2f", menuItem.price)}",
                                style = MaterialTheme.typography.titleMedium,
                                color = DeepItalianRed,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = menuItem.description,
                            style = MaterialTheme.typography.bodyMedium,
                            color = EspressoBrown
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Outlined.Info, contentDescription = "Calories", tint = Color.Gray, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "${menuItem.calories} CAL",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.Gray
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                TextButton(onClick = { showNutritionSheet = menuItem }) {
                                    Text("Nutrition & Allergens", style = MaterialTheme.typography.labelSmall, color = OliveGardenGreen)
                                }
                            }

                            if (menuItem.customizable) {
                                Button(
                                    onClick = { selectedMenuItemForCustomization = menuItem },
                                    colors = ButtonDefaults.buttonColors(containerColor = OliveGardenGreen)
                                ) {
                                    Text("CUSTOMIZE")
                                }
                            } else {
                                Button(
                                    onClick = { viewModel.addToCart(menuItem, 1) },
                                    colors = ButtonDefaults.buttonColors(containerColor = OliveGardenGreen)
                                ) {
                                    Text("ADD TO BAG")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // CREATE YOUR OWN PASTA CONFIGURATOR DIALOG
    if (showCyoDialog) {
        val pastas = listOf("Fettuccine", "Spaghetti", "Rigatoni", "Angel Hair", "Gluten-Free Rotini")
        val sauces = listOf("Alfredo", "Marinara", "Meat Sauce", "Five Cheese Marinara")
        val toppings = listOf("Grilled Chicken", "Meatballs", "Sauteed Shrimp", "Garden Veggies")

        var step by remember { mutableStateOf(1) }
        var chosenPasta by remember { mutableStateOf("Fettuccine") }
        var chosenSauce by remember { mutableStateOf("Alfredo") }
        var chosenToppings by remember { mutableStateOf(emptyList<String>()) }
        var instructions by remember { mutableStateOf("") }

        Dialog(onDismissRequest = { showCyoDialog = false }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = WarmCream),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Text(
                        text = "CREATE YOUR OWN PASTA",
                        fontFamily = FontFamily.Serif,
                        style = MaterialTheme.typography.titleLarge,
                        color = OliveGardenGreen,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    when (step) {
                        1 -> {
                            Text("STEP 1: CHOOSE YOUR PASTA", fontWeight = FontWeight.Bold, color = EspressoBrown)
                            Spacer(modifier = Modifier.height(8.dp))
                            pastas.forEach { pasta ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { chosenPasta = pasta }
                                        .padding(vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(selected = chosenPasta == pasta, onClick = { chosenPasta = pasta })
                                    Text(pasta, color = EspressoBrown)
                                }
                            }
                        }
                        2 -> {
                            Text("STEP 2: CHOOSE YOUR SAUCE", fontWeight = FontWeight.Bold, color = EspressoBrown)
                            Spacer(modifier = Modifier.height(8.dp))
                            sauces.forEach { sauce ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { chosenSauce = sauce }
                                        .padding(vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(selected = chosenSauce == sauce, onClick = { chosenSauce = sauce })
                                    Text(sauce, color = EspressoBrown)
                                }
                            }
                        }
                        3 -> {
                            Text("STEP 3: ADD TOPPINGS (+$2.50 each)", fontWeight = FontWeight.Bold, color = EspressoBrown)
                            Spacer(modifier = Modifier.height(8.dp))
                            toppings.forEach { topping ->
                                val isChecked = chosenToppings.contains(topping)
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            chosenToppings = if (isChecked) chosenToppings - topping else chosenToppings + topping
                                        }
                                        .padding(vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Checkbox(checked = isChecked, onCheckedChange = {
                                        chosenToppings = if (isChecked) chosenToppings - topping else chosenToppings + topping
                                    })
                                    Text(topping, color = EspressoBrown)
                                }
                            }
                        }
                        4 -> {
                            Text("STEP 4: SPECIAL INSTRUCTIONS & REVIEW", fontWeight = FontWeight.Bold, color = EspressoBrown)
                            Spacer(modifier = Modifier.height(8.dp))
                            Card(
                                colors = CardDefaults.cardColors(containerColor = WhiteNapkin),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("• Pasta: $chosenPasta", color = EspressoBrown)
                                    Text("• Sauce: $chosenSauce", color = EspressoBrown)
                                    Text("• Toppings: ${if (chosenToppings.isEmpty()) "None" else chosenToppings.joinToString()}", color = EspressoBrown)
                                    Text("• Price: $${String.format("%.2f", 14.99 + (chosenToppings.size * 2.50))}", color = DeepItalianRed, fontWeight = FontWeight.Bold)
                                }
                            }
                            OutlinedTextField(
                                value = instructions,
                                onValueChange = { instructions = it },
                                label = { Text("Special instructions (e.g. extra cheese)") },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        if (step > 1) {
                            Button(
                                onClick = { step-- },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.Gray)
                            ) {
                                Text("BACK")
                            }
                        } else {
                            Spacer(modifier = Modifier.width(8.dp))
                        }

                        Button(
                            onClick = {
                                if (step < 4) {
                                    step++
                                } else {
                                    val freshCyo = menuItems.first { it.id == "cyo_pasta" }
                                    viewModel.addToCart(
                                        menuItem = freshCyo,
                                        quantity = 1,
                                        pasta = chosenPasta,
                                        sauce = chosenSauce,
                                        toppings = chosenToppings,
                                        instructions = instructions
                                    )
                                    showCyoDialog = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = OliveGardenGreen)
                        ) {
                            Text(if (step == 4) "ADD TO BAG" else "NEXT")
                        }
                    }
                }
            }
        }
    }

    // GENERAL CHICKEN ALFREDO CUSTOMIZE DIALOG
    selectedMenuItemForCustomization?.let { item ->
        var pastaOption by remember { mutableStateOf("Fettuccine") }
        var sauceOption by remember { mutableStateOf("Alfredo") }

        Dialog(onDismissRequest = { selectedMenuItemForCustomization = null }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = WarmCream),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Text(
                        text = "CUSTOMIZE ${item.name.uppercase()}",
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        color = OliveGardenGreen
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Pasta Options:", fontWeight = FontWeight.Bold, color = EspressoBrown)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Fettuccine", "Spaghetti").forEach { p ->
                            FilterChip(
                                selected = pastaOption == p,
                                onClick = { pastaOption = p },
                                label = { Text(p) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Sauce Options:", fontWeight = FontWeight.Bold, color = EspressoBrown)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Alfredo", "Marinara").forEach { s ->
                            FilterChip(
                                selected = sauceOption == s,
                                onClick = { sauceOption = s },
                                label = { Text(s) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))
                    Button(
                        onClick = {
                            viewModel.addToCart(
                                menuItem = item,
                                quantity = 1,
                                pasta = pastaOption,
                                sauce = sauceOption,
                                toppings = listOf("Grilled Chicken")
                            )
                            selectedMenuItemForCustomization = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = OliveGardenGreen),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("CONFIRM & ADD")
                    }
                }
            }
        }
    }

    // NUTRITION GUIDE SHEET
    showNutritionSheet?.let { menuItem ->
        val nut = menuItem.nutrition
        Dialog(onDismissRequest = { showNutritionSheet = null }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = WarmCream),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp)
                ) {
                    Text(
                        text = "${menuItem.name} NUTRITION GUIDE",
                        fontFamily = FontFamily.Serif,
                        style = MaterialTheme.typography.titleLarge,
                        color = OliveGardenGreen,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Status: ${nut.verification.name} BY OLIVE GARDEN DIETICIANS",
                        color = DeepItalianRed,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    Column(modifier = Modifier.fillMaxWidth()) {
                        NutritionRow("Calories", "${nut.calories} kcal")
                        NutritionRow("Fat", "${nut.fatGrams} g")
                        NutritionRow("Carbohydrates", "${nut.carbsGrams} g")
                        NutritionRow("Protein", "${nut.proteinGrams} g")
                        NutritionRow("Sodium", "${nut.sodiumMg} mg")
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Allergens Present:", fontWeight = FontWeight.Bold, color = EspressoBrown)
                    Text(
                        text = if (nut.allergens.isEmpty()) "None declared" else nut.allergens.joinToString(),
                        color = DeepItalianRed,
                        style = MaterialTheme.typography.bodyMedium
                    )

                    Spacer(modifier = Modifier.height(24.dp))
                    Button(
                        onClick = { showNutritionSheet = null },
                        colors = ButtonDefaults.buttonColors(containerColor = OliveGardenGreen),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("CLOSE")
                    }
                }
            }
        }
    }
}

// 3. RESTAURANT LOCATOR SCREEN
@Composable
fun LocationsScreen(viewModel: OliveGardenViewModel) {
    val list by viewModel.restaurants.collectAsState()
    val searchVal by viewModel.restaurantSearchQuery.collectAsState()

    val activeWaitlist by viewModel.myWaitlistEntry.collectAsState()
    var partySizeToJoin by remember { mutableStateOf(2) }
    var joiningRestId by remember { mutableStateOf<String?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            OutlinedTextField(
                value = searchVal,
                onValueChange = { viewModel.updateRestaurantSearch(it) },
                label = { Text("Find Olive Garden by ZIP/City...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("restaurant_search_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = OliveGardenGreen,
                    unfocusedBorderColor = Color.LightGray
                )
            )
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(120.dp)
                .background(Color(0xFFE4F0D4))
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.Map, contentDescription = null, tint = OliveGardenGreen, modifier = Modifier.size(32.dp))
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "SIMULATED MAP PROVIDER",
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold,
                    color = OliveGardenGreen
                )
            }
        }

        val filteredRestaurants = list.filter {
            it.name.contains(searchVal, ignoreCase = true) || it.address.contains(searchVal, ignoreCase = true)
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .testTag("locations_list"),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(filteredRestaurants) { rest ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = WhiteNapkin),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = rest.name.uppercase(),
                                    fontFamily = FontFamily.Serif,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = EspressoBrown,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(rest.address, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                            }
                            IconButton(onClick = { viewModel.toggleFavorite(rest.id) }) {
                                Icon(
                                    imageVector = if (rest.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                    contentDescription = "Favorite",
                                    tint = if (rest.isFavorite) DeepItalianRed else Color.LightGray
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(
                                text = "Today: ${rest.hours.weekday}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = EspressoBrown
                            )
                            Text(
                                text = "Wait Time: ${rest.currentWaitMinutes} mins",
                                color = if (rest.currentWaitMinutes > 15) DeepItalianRed else OliveGardenGreen,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    viewModel.selectRestaurant(rest)
                                    viewModel.selectCustomerTab(CustomerTab.MENU)
                                },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = OliveGardenGreen),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("VIEW MENU")
                            }

                            Button(
                                onClick = {
                                    viewModel.selectRestaurant(rest)
                                    joiningRestId = rest.id
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = DeepItalianRed),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("JOIN WAITLIST")
                            }
                        }
                    }
                }
            }
        }
    }

    joiningRestId?.let { id ->
        Dialog(onDismissRequest = { joiningRestId = null }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = WarmCream),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "JOIN THE WAITLIST",
                        fontFamily = FontFamily.Serif,
                        style = MaterialTheme.typography.titleLarge,
                        color = OliveGardenGreen,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        IconButton(onClick = { if (partySizeToJoin > 1) partySizeToJoin-- }) {
                            Icon(Icons.Default.RemoveCircleOutline, contentDescription = "Decrease", tint = OliveGardenGreen)
                        }
                        Text(
                            text = partySizeToJoin.toString(),
                            style = MaterialTheme.typography.headlineLarge,
                            fontWeight = FontWeight.Bold,
                            color = EspressoBrown,
                            modifier = Modifier.padding(horizontal = 24.dp)
                        )
                        IconButton(onClick = { partySizeToJoin++ }) {
                            Icon(Icons.Default.AddCircleOutline, contentDescription = "Increase", tint = OliveGardenGreen)
                        }
                    }
                    Spacer(modifier = Modifier.height(24.dp))
                    Button(
                        onClick = {
                            viewModel.joinWaitlist(partySizeToJoin)
                            joiningRestId = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = OliveGardenGreen),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("CONFIRM & JOIN WAITLIST")
                    }
                }
            }
        }
    }
}

// 4. YOUR TABLE (BAG / REORDERS / GIFT CARDS / ECLUB)
@Composable
fun AccountScreen(viewModel: OliveGardenViewModel) {
    val orders by viewModel.orders.collectAsState()
    val waitlistEntry by viewModel.myWaitlistEntry.collectAsState()
    val activeOrder by viewModel.myActiveOrder.collectAsState()
    val cart by viewModel.cartItems.collectAsState()

    var showGiftCardDialog by remember { mutableStateOf(false) }

    var eClubEmail by remember { mutableStateOf("") }
    var eClubZip by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("account_scroll"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = WhiteNapkin)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(22.dp))
                            .background(WarmCream),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Person, contentDescription = null, tint = OliveGardenGreen)
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(
                            text = "BENVENUTO, ${OliveGardenBackend.currentCustomerName.uppercase()}",
                            fontFamily = FontFamily.Serif,
                            style = MaterialTheme.typography.titleMedium,
                            color = EspressoBrown,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Family profile: ${OliveGardenBackend.currentCustomerEmail}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray
                        )
                    }
                }
            }
        }

        if (cart.isNotEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = WhiteNapkin),
                    border = BorderStroke(1.dp, GoldGlaze)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "YOUR TABLE BAG",
                            fontWeight = FontWeight.Bold,
                            color = OliveGardenGreen,
                            fontFamily = FontFamily.Serif,
                            style = MaterialTheme.typography.titleMedium
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        cart.forEach { item ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("• ${item.menuItem.name} x${item.quantity}", color = EspressoBrown)
                                    if (item.selectedPasta != null) {
                                        Text("  ${item.selectedPasta} with ${item.selectedSauce}", fontSize = 11.sp, color = Color.Gray)
                                    }
                                }
                                Text("$${String.format("%.2f", item.totalPrice)}", fontWeight = FontWeight.Bold, color = EspressoBrown)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Divider()
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Subtotal", color = EspressoBrown)
                            Text("$${String.format("%.2f", cart.sumOf { it.totalPrice })}", fontWeight = FontWeight.Bold, color = EspressoBrown)
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = {
                                viewModel.placeOrder(OrderType.CARSIDE_PICKUP, "Honda Civic Gray", "Visa ending in 4219")
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = DeepItalianRed),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("place_order_btn")
                        ) {
                            Text("PLACE CARSIDE ORDER ($${String.format("%.2f", cart.sumOf { it.totalPrice } * 1.07)})", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        activeOrder?.let { order ->
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = WhiteNapkin),
                    border = BorderStroke(1.5.dp, DeepItalianRed)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "LIVE TRACKING: ${order.id}",
                                fontWeight = FontWeight.Bold,
                                color = DeepItalianRed
                            )
                            Text(
                                text = order.status.name,
                                fontWeight = FontWeight.Bold,
                                color = OliveGardenGreen
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))

                        val steps = listOf(OrderStatus.CREATED, OrderStatus.ACCEPTED, OrderStatus.PREPARING, OrderStatus.READY, OrderStatus.COMPLETED)
                        val currentIdx = steps.indexOf(order.status).coerceAtLeast(0)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            steps.forEachIndexed { idx, step ->
                                val active = idx <= currentIdx
                                val color = if (active) DeepItalianRed else Color.LightGray
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Box(
                                        modifier = Modifier
                                            .size(24.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(color),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text((idx + 1).toString(), color = PureWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = step.name.substring(0, 3),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = color
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        Text("Assigned table / Carside: ${order.carDetails ?: "Wait for pickup notifications"}", style = MaterialTheme.typography.bodyMedium, color = EspressoBrown)

                        if (order.status == OrderStatus.CREATED || order.status == OrderStatus.ACCEPTED) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = { viewModel.cancelOrder(order.id) },
                                colors = ButtonDefaults.buttonColors(containerColor = DeepItalianRed)
                            ) {
                                Text("CANCEL ORDER")
                            }
                        }
                    }
                }
            }
        }

        waitlistEntry?.let { entry ->
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = WhiteNapkin),
                    border = BorderStroke(1.5.dp, OliveGardenGreen)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "WAITLIST POSITION: ${entry.id}",
                                fontWeight = FontWeight.Bold,
                                color = OliveGardenGreen
                            )
                            Text(
                                text = entry.status.name,
                                fontWeight = FontWeight.Bold,
                                color = DeepItalianRed
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "You are currently position ${entry.position} in line.",
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold,
                            color = EspressoBrown
                        )
                        Text(
                            text = "Estimated time remaining: ${entry.estimatedWaitMinutes} mins",
                            style = MaterialTheme.typography.bodyMedium,
                            color = EspressoBrown
                        )

                        Spacer(modifier = Modifier.height(16.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            if (entry.status == WaitlistStatus.READY) {
                                Button(
                                    onClick = { viewModel.checkInWaitlist() },
                                    colors = ButtonDefaults.buttonColors(containerColor = OliveGardenGreen)
                                ) {
                                    Text("CHECK IN NOW")
                                }
                            }
                            OutlinedButton(
                                onClick = { viewModel.cancelWaitlist() },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = DeepItalianRed)
                            ) {
                                Text("CANCEL LIST ENTRY")
                            }
                        }
                    }
                }
            }
        }

        item {
            Column {
                Text(
                    text = "SAVED & PAST ORDERS",
                    fontFamily = FontFamily.Serif,
                    style = MaterialTheme.typography.titleMedium,
                    color = OliveGardenGreen,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                if (orders.isEmpty()) {
                    Text("No past orders found. Fill your table soon!", color = Color.Gray, style = MaterialTheme.typography.bodyMedium)
                } else {
                    orders.forEach { pastOrder ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = WhiteNapkin),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 8.dp),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(pastOrder.id, fontWeight = FontWeight.Bold, color = EspressoBrown)
                                        Text(pastOrder.createdAt.substring(0, 10), fontSize = 11.sp, color = Color.Gray)
                                    }
                                    Text(
                                        text = "$${String.format("%.2f", pastOrder.total)}",
                                        fontWeight = FontWeight.Bold,
                                        color = DeepItalianRed
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                pastOrder.items.forEach { cartItem ->
                                    Text("• ${cartItem.menuItem.name} x${cartItem.quantity}", style = MaterialTheme.typography.bodyMedium, color = EspressoBrown)
                                }
                                Spacer(modifier = Modifier.height(12.dp))
                                Button(
                                    onClick = { viewModel.quickReorder(pastOrder) },
                                    colors = ButtonDefaults.buttonColors(containerColor = OliveGardenGreen)
                                ) {
                                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("QUICK REORDER")
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Column {
                Text(
                    text = "GIFT CARDS",
                    fontFamily = FontFamily.Serif,
                    style = MaterialTheme.typography.titleMedium,
                    color = OliveGardenGreen,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                Card(
                    colors = CardDefaults.cardColors(containerColor = WhiteNapkin)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Add or Reload physical and digital gift cards to your profile.", style = MaterialTheme.typography.bodyMedium, color = EspressoBrown)
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Button(
                                onClick = { showGiftCardDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = OliveGardenGreen),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("CHECK / RELOAD")
                            }
                        }
                    }
                }
            }
        }

        item {
            Column {
                Text(
                    text = "OLIVE GARDEN eCLUB",
                    fontFamily = FontFamily.Serif,
                    style = MaterialTheme.typography.titleMedium,
                    color = OliveGardenGreen,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                Card(
                    colors = CardDefaults.cardColors(containerColor = WhiteNapkin)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Join our signature eClub for official Olive Garden news, menu disclosures and special promo offers.", style = MaterialTheme.typography.bodyMedium, color = EspressoBrown)
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = eClubEmail,
                            onValueChange = { eClubEmail = it },
                            label = { Text("Your Email Address") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = eClubZip,
                            onValueChange = { eClubZip = it },
                            label = { Text("Your ZIP Code") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = {
                                if (eClubEmail.isNotEmpty() && eClubZip.isNotEmpty()) {
                                    viewModel.subscribeToEClub(eClubEmail, eClubZip, "2000-01-01")
                                    eClubEmail = ""
                                    eClubZip = ""
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = DeepItalianRed),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("SUBSCRIBE TO OFFERS")
                        }
                    }
                }
            }
        }
    }

    if (showGiftCardDialog) {
        var cardIdToCheck by remember { mutableStateOf("") }
        var reloadAmount by remember { mutableStateOf("15") }

        Dialog(onDismissRequest = { showGiftCardDialog = false }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = WarmCream),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp)
                ) {
                    Text(
                        text = "MANAGE GIFT CARDS",
                        fontFamily = FontFamily.Serif,
                        style = MaterialTheme.typography.titleLarge,
                        color = OliveGardenGreen,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    OutlinedTextField(
                        value = cardIdToCheck,
                        onValueChange = { cardIdToCheck = it },
                        label = { Text("Enter Card ID (e.g. OG-GC-1948)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = { viewModel.checkGiftCardBalance(cardIdToCheck) },
                        colors = ButtonDefaults.buttonColors(containerColor = OliveGardenGreen),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("CHECK BALANCE")
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Divider()
                    Spacer(modifier = Modifier.height(16.dp))

                    Text("RELOAD GIFT CARD", fontWeight = FontWeight.Bold, color = EspressoBrown)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = reloadAmount,
                        onValueChange = { reloadAmount = it },
                        label = { Text("Enter Amount ($)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = {
                            val amt = reloadAmount.toDoubleOrNull() ?: 10.0
                            viewModel.reloadGiftCard(cardIdToCheck, amt)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DeepItalianRed),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("RELOAD CARD")
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    TextButton(onClick = { showGiftCardDialog = false }) {
                        Text("Close", color = Color.Gray)
                    }
                }
            }
        }
    }
}

// Helper Composables for the Customer Screens
@Composable
fun PopularFoodCard(menuItem: MenuItem, onAdd: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = WhiteNapkin),
        modifier = Modifier
            .width(180.dp)
            .height(250.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(WarmCream),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .clip(RoundedCornerShape(30.dp))
                            .background(
                                if (menuItem.id == "chicken_alfredo") Color(0xFFFBF1C7)
                                else if (menuItem.id == "lasagna_classico") Color(0xFFE9B299)
                                else if (menuItem.id == "salad") Color(0xFF90B38B)
                                else Color(0xFFE9C46A)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Restaurant, contentDescription = null, tint = EspressoBrown)
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = menuItem.name,
                    maxLines = 1,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif,
                    style = MaterialTheme.typography.bodyLarge,
                    color = EspressoBrown
                )
                Text(
                    text = menuItem.description,
                    maxLines = 2,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "$${String.format("%.2f", menuItem.price)}",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.bodyLarge,
                    color = DeepItalianRed
                )
                IconButton(
                    onClick = onAdd,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(Icons.Default.AddCircle, contentDescription = "Add", tint = OliveGardenGreen, modifier = Modifier.size(32.dp))
                }
            }
        }
    }
}

@Composable
fun CateringOrCyoIntroCard(title: String, desc: String, btnText: String, onAction: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = OliveGardenGreen),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = title,
                fontFamily = FontFamily.Serif,
                style = MaterialTheme.typography.titleLarge,
                color = GoldGlaze,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = desc,
                color = PureWhite,
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = onAction,
                colors = ButtonDefaults.buttonColors(containerColor = GoldGlaze, contentColor = EspressoBrown),
                modifier = Modifier.testTag("action_cyo_pasta_launch")
            ) {
                Text(btnText, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun NutritionRow(label: String, valStr: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = EspressoBrown)
        Text(valStr, fontWeight = FontWeight.Bold, color = EspressoBrown)
    }
}
