package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = OliveGardenGreen,
    secondary = DeepItalianRed,
    tertiary = GoldGlaze,
    background = EspressoBrown,
    surface = Color(0xFF3A2B25),
    onPrimary = PureWhite,
    onSecondary = PureWhite,
    onTertiary = EspressoBrown,
    onBackground = WarmCream,
    onSurface = WarmCream
  )

private val LightColorScheme =
  lightColorScheme(
    primary = OliveGardenGreen,
    secondary = DeepItalianRed,
    tertiary = GoldGlaze,
    background = WarmCream,
    surface = WhiteNapkin,
    onPrimary = PureWhite,
    onSecondary = PureWhite,
    onTertiary = EspressoBrown,
    onBackground = EspressoBrown,
    onSurface = EspressoBrown
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Forcing custom branding experience to deliver the warm cream Olive Garden feel
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
