package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.backend.OliveGardenBackend
import com.example.domain.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

enum class AppMode {
    CUSTOMER_APP,
    RESTAURANT_HQ
}

enum class CustomerTab {
    HOME,
    MENU,
    LOCATIONS,
    ACCOUNT
}

enum class HQTab {
    DASHBOARD,
    WAITLIST_HQ,
    KITCHEN_BOARD,
    INVENTORY,
    ANALYTICS_AUDITS
}

class OliveGardenViewModel : ViewModel() {

    // 1. Navigation & Mode states
    private val _currentMode = MutableStateFlow(AppMode.CUSTOMER_APP)
    val currentMode: StateFlow<AppMode> = _currentMode.asStateFlow()

    private val _selectedCustomerTab = MutableStateFlow(CustomerTab.HOME)
    val selectedCustomerTab: StateFlow<CustomerTab> = _selectedCustomerTab.asStateFlow()

    private val _selectedHQTab = MutableStateFlow(HQTab.DASHBOARD)
    val selectedHQTab: StateFlow<HQTab> = _selectedHQTab.asStateFlow()

    // 2. Data streams from shared Backend
    val restaurants = OliveGardenBackend.restaurants
    val menuItems = OliveGardenBackend.menuItems
    val orders = OliveGardenBackend.orders
    val waitlist = OliveGardenBackend.waitlist
    val cateringOrders = OliveGardenBackend.cateringOrders
    val giftCards = OliveGardenBackend.giftCards
    val offers = OliveGardenBackend.offers
    val eClubSubscriptions = OliveGardenBackend.eClubSubscriptions
    val inventory = OliveGardenBackend.inventory
    val auditEvents = OliveGardenBackend.auditEvents

    // 3. Client-side Interaction States
    private val _selectedRestaurant = MutableStateFlow<Restaurant?>(null)
    val selectedRestaurant: StateFlow<Restaurant?> = _selectedRestaurant.asStateFlow()

    // Active customer cart/bag
    private val _cartItems = MutableStateFlow<List<CartItem>>(emptyList())
    val cartItems: StateFlow<List<CartItem>> = _cartItems.asStateFlow()

    // Active waitlist entry for the current user
    private val _myWaitlistEntry = MutableStateFlow<WaitlistEntry?>(null)
    val myWaitlistEntry: StateFlow<WaitlistEntry?> = _myWaitlistEntry.asStateFlow()

    // Active tracked order
    private val _myActiveOrder = MutableStateFlow<Order?>(null)
    val myActiveOrder: StateFlow<Order?> = _myActiveOrder.asStateFlow()

    // Catering Builder State
    private val _cateringGuests = MutableStateFlow(25)
    val cateringGuests: StateFlow<Int> = _cateringGuests.asStateFlow()

    private val _cateringType = MutableStateFlow(CateringEventType.OFFICE)
    val cateringType: StateFlow<CateringEventType> = _cateringType.asStateFlow()

    private val _cateringSetupOptions = MutableStateFlow(true)
    val cateringSetupOptions: StateFlow<Boolean> = _cateringSetupOptions.asStateFlow()

    private val _cateringCart = MutableStateFlow<List<CartItem>>(emptyList())
    val cateringCart: StateFlow<List<CartItem>> = _cateringCart.asStateFlow()

    // Active tracked catering order
    private val _myActiveCateringOrder = MutableStateFlow<CateringOrder?>(null)
    val myActiveCateringOrder: StateFlow<CateringOrder?> = _myActiveCateringOrder.asStateFlow()

    // UI Search Filter
    private val _restaurantSearchQuery = MutableStateFlow("")
    val restaurantSearchQuery: StateFlow<String> = _restaurantSearchQuery.asStateFlow()

    private val _menuSearchQuery = MutableStateFlow("")
    val menuSearchQuery: StateFlow<String> = _menuSearchQuery.asStateFlow()

    // Gift Card Checking / Purchase
    private val _checkedGiftCardBalance = MutableStateFlow<Double?>(null)
    val checkedGiftCardBalance: StateFlow<Double?> = _checkedGiftCardBalance.asStateFlow()

    // Feedback states
    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _successMessage = MutableStateFlow<String?>(null)
    val successMessage: StateFlow<String?> = _successMessage.asStateFlow()

    init {
        // Set Orlando as initial selected restaurant for a seamless first launch
        viewModelScope.launch {
            restaurants.collect { list ->
                if (_selectedRestaurant.value == null && list.isNotEmpty()) {
                    _selectedRestaurant.value = list.first { it.isFavorite } ?: list.first()
                }
            }
        }
    }

    fun switchMode(mode: AppMode) {
        _currentMode.value = mode
    }

    fun selectCustomerTab(tab: CustomerTab) {
        _selectedCustomerTab.value = tab
    }

    fun selectHQTab(tab: HQTab) {
        _selectedHQTab.value = tab
    }

    fun selectRestaurant(restaurant: Restaurant) {
        _selectedRestaurant.value = restaurant
    }

    fun updateRestaurantSearch(query: String) {
        _restaurantSearchQuery.value = query
    }

    fun updateMenuSearch(query: String) {
        _menuSearchQuery.value = query
    }

    // TOGGLE FAVORITE RESTAURANT
    fun toggleFavorite(restaurantId: String) {
        OliveGardenBackend.toggleFavorite(restaurantId)
    }

    // CART MANAGEMENT
    fun addToCart(menuItem: MenuItem, quantity: Int, pasta: String? = null, sauce: String? = null, toppings: List<String> = emptyList(), instructions: String = "") {
        val newItem = CartItem(
            menuItem = menuItem,
            quantity = quantity,
            selectedPasta = pasta,
            selectedSauce = sauce,
            selectedToppings = toppings,
            specialInstructions = instructions
        )
        _cartItems.value = _cartItems.value + newItem
        _successMessage.value = "Added to your Table"
        viewModelScope.launch {
            delay(2000)
            if (_successMessage.value == "Added to your Table") {
                _successMessage.value = null
            }
        }
    }

    fun removeFromCart(itemId: String) {
        _cartItems.value = _cartItems.value.filter { it.id != itemId }
    }

    fun updateCartQuantity(itemId: String, delta: Int) {
        _cartItems.value = _cartItems.value.map {
            if (it.id == itemId) {
                val newQty = (it.quantity + delta).coerceAtLeast(1)
                it.copy(quantity = newQty)
            } else it
        }
    }

    fun clearCart() {
        _cartItems.value = emptyList()
    }

    // WAITLIST ACTIONS
    fun joinWaitlist(partySize: Int) {
        val restId = _selectedRestaurant.value?.id ?: return
        try {
            val entry = OliveGardenBackend.joinWaitlist(
                restaurantId = restId,
                name = OliveGardenBackend.currentCustomerName,
                phone = OliveGardenBackend.currentCustomerPhone,
                partySize = partySize
            )
            _myWaitlistEntry.value = entry
            _successMessage.value = "Successfully joined the waitlist!"
            
            // Start automatic background waitlist simulator
            simulateWaitlistProgression(entry.id)
        } catch (e: Exception) {
            _errorMessage.value = e.message
        }
    }

    fun cancelWaitlist() {
        val entry = _myWaitlistEntry.value ?: return
        OliveGardenBackend.updateWaitlistStatus(entry.id, WaitlistStatus.CANCELLED)
        _myWaitlistEntry.value = null
        _successMessage.value = "Your waitlist entry has been cancelled."
    }

    fun checkInWaitlist() {
        val entry = _myWaitlistEntry.value ?: return
        OliveGardenBackend.updateWaitlistStatus(entry.id, WaitlistStatus.CHECKED_IN)
        _myWaitlistEntry.value = _myWaitlistEntry.value?.copy(status = WaitlistStatus.CHECKED_IN)
    }

    private fun simulateWaitlistProgression(entryId: String) {
        viewModelScope.launch {
            // Keep refreshing local reference from backend state flow
            waitlist.collect { list ->
                val current = list.find { it.id == entryId }
                if (current != null) {
                    _myWaitlistEntry.value = current
                }
            }
        }
    }

    // CHECKOUT & ORDERS
    fun placeOrder(orderType: OrderType, carDetails: String?, paymentMethod: String) {
        val restId = _selectedRestaurant.value?.id ?: return
        if (_cartItems.value.isEmpty()) return

        try {
            val order = OliveGardenBackend.placeOrder(
                restaurantId = restId,
                items = _cartItems.value,
                orderType = orderType,
                carDetails = carDetails,
                paymentMethod = paymentMethod
            )
            _myActiveOrder.value = order
            clearCart()
            _successMessage.value = "Order received!"

            // Watch for changes on active order from operations flow
            viewModelScope.launch {
                orders.collect { list ->
                    val updated = list.find { it.id == order.id }
                    if (updated != null) {
                        _myActiveOrder.value = updated
                    }
                }
            }
        } catch (e: Exception) {
            _errorMessage.value = e.message
        }
    }

    fun cancelOrder(orderId: String) {
        OliveGardenBackend.updateOrderStatus(orderId, OrderStatus.CANCELLED)
        _successMessage.value = "Order cancellation requested."
    }

    fun quickReorder(pastOrder: Order) {
        // Rebuild order safely
        val availableMenu = menuItems.value
        val itemsToAdd = pastOrder.items.mapNotNull { item ->
            val freshMenuItem = availableMenu.find { it.id == item.menuItem.id }
            if (freshMenuItem != null && freshMenuItem.available) {
                item.copy(menuItem = freshMenuItem)
            } else null
        }

        if (itemsToAdd.isEmpty()) {
            _errorMessage.value = "None of the items from your past order are currently available."
            return
        }

        _cartItems.value = itemsToAdd
        selectCustomerTab(CustomerTab.MENU)
        _successMessage.value = "Loaded past items into your table bag!"
    }

    // CATERING
    fun updateCateringGuests(guests: Int) {
        _cateringGuests.value = guests
    }

    fun updateCateringType(type: CateringEventType) {
        _cateringType.value = type
    }

    fun toggleCateringSetup(enabled: Boolean) {
        _cateringSetupOptions.value = enabled
    }

    fun addCateringItem(menuItem: MenuItem, quantity: Int) {
        val existing = _cateringCart.value.find { it.menuItem.id == menuItem.id }
        if (existing != null) {
            _cateringCart.value = _cateringCart.value.map {
                if (it.menuItem.id == menuItem.id) it.copy(quantity = it.quantity + quantity) else it
            }
        } else {
            val item = CartItem(menuItem = menuItem, quantity = quantity)
            _cateringCart.value = _cateringCart.value + item
        }
    }

    fun removeCateringItem(itemId: String) {
        _cateringCart.value = _cateringCart.value.filter { it.id != itemId }
    }

    fun placeCateringOrder() {
        if (_cateringCart.value.isEmpty()) return
        try {
            val order = OliveGardenBackend.placeCateringOrder(
                eventType = _cateringType.value,
                guests = _cateringGuests.value,
                date = "2026-09-30",
                time = "12:30 PM",
                orderType = OrderType.DELIVERY,
                items = _cateringCart.value,
                setupOptionsEnabled = _cateringSetupOptions.value
            )
            _myActiveCateringOrder.value = order
            _cateringCart.value = emptyList()
            _successMessage.value = "Catering Order booked successfully!"

            viewModelScope.launch {
                cateringOrders.collect { list ->
                    val updated = list.find { it.id == order.id }
                    if (updated != null) {
                        _myActiveCateringOrder.value = updated
                    }
                }
            }
        } catch (e: Exception) {
            _errorMessage.value = e.message
        }
    }

    // GIFT CARDS
    fun buyGiftCard(amount: Double, recipientEmail: String) {
        val gc = OliveGardenBackend.buyGiftCard(amount, recipientEmail)
        _successMessage.value = "Gift Card generated: ${gc.id}"
    }

    fun checkGiftCardBalance(cardId: String) {
        val balance = OliveGardenBackend.checkGiftCardBalance(cardId)
        if (balance != null) {
            _checkedGiftCardBalance.value = balance
            _successMessage.value = "Gift Card has a balance of $${String.format("%.2f", balance)}"
        } else {
            _checkedGiftCardBalance.value = null
            _errorMessage.value = "Gift Card not found or inactive."
        }
    }

    fun reloadGiftCard(cardId: String, amount: Double) {
        val success = OliveGardenBackend.reloadGiftCard(cardId, amount)
        if (success) {
            _successMessage.value = "Successfully reloaded $${String.format("%.2f", amount)}"
            checkGiftCardBalance(cardId)
        } else {
            _errorMessage.value = "Reload failed."
        }
    }

    // ECLUB NEWSLETTER
    fun subscribeToEClub(email: String, zip: String, birthday: String) {
        val success = OliveGardenBackend.subscribeToEClub(email, zip, birthday, listOf("News", "Coupons"))
        if (success) {
            _successMessage.value = "Welcome to the eClub table! We sent you news & offers."
        } else {
            _errorMessage.value = "Email is already subscribed."
        }
    }

    // HQ STAFF OPERATIONS METHODS
    fun hqUpdateWaitlistStatus(entryId: String, status: WaitlistStatus, tableAssigned: String? = null) {
        OliveGardenBackend.updateWaitlistStatus(entryId, status, tableAssigned)
    }

    fun hqUpdateOrderStatus(orderId: String, status: OrderStatus) {
        OliveGardenBackend.updateOrderStatus(orderId, status)
    }

    fun hqAdjustInventory(itemId: String, adjustment: Int) {
        OliveGardenBackend.adjustInventory(itemId, adjustment)
    }

    fun hqUpdateRestaurantState(restaurantId: String, status: RestaurantStatus) {
        OliveGardenBackend.updateRestaurantStatus(restaurantId, status)
    }

    fun clearMessages() {
        _errorMessage.value = null
        _successMessage.value = null
    }
}
