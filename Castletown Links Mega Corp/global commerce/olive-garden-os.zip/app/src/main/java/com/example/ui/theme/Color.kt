package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Olive Garden Signature Warm Italian Palette
val OliveGardenGreen = Color(0xFF2C5E3B)
val DeepItalianRed = Color(0xFF8B2222)
val WarmCream = Color(0xFFFAF6EE)
val WhiteNapkin = Color(0xFFFDFBF7)
val EspressoBrown = Color(0xFF2E201B)

// Accents
val MutedSage = Color(0xFF8CA390)
val Terracotta = Color(0xFFD36E4D)
val GoldGlaze = Color(0xFFC59B27)
val SoftStone = Color(0xFFEFECE5)
val PureWhite = Color(0xFFFFFFFF)

// Fallbacks for default template compatibility
val Purple80 = Color(0xFF2C5E3B)
val PurpleGrey80 = Color(0xFF8CA390)
val Pink80 = Color(0xFFC59B27)
val Purple40 = Color(0xFF2C5E3B)
val PurpleGrey40 = Color(0xFF8CA390)
val Pink40 = Color(0xFFC59B27)

