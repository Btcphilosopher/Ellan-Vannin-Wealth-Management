package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.AppMode
import com.example.ui.OliveGardenViewModel
import com.example.ui.screens.CustomerAppScreen
import com.example.ui.screens.OperationsHqScreen
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val viewModel: OliveGardenViewModel = viewModel()
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    topBar = { OliveGardenTopHeader(viewModel) }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        OliveGardenAppContent(viewModel)
                    }
                }
            }
        }
    }
}

@Composable
fun OliveGardenTopHeader(viewModel: OliveGardenViewModel) {
    val currentMode by viewModel.currentMode.collectAsState()

    Surface(
        color = OliveGardenGreen,
        tonalElevation = 4.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .statusBarsPadding()
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "OLIVE GARDEN",
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = GoldGlaze,
                    letterSpacing = 2.sp
                )
                Text(
                    text = "DIGITAL PLATFORM",
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 9.sp,
                    color = WarmCream,
                    letterSpacing = 1.sp
                )
            }

            // Mode Toggle Switch Button (Customer App vs restaurant HQ OS)
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(EspressoBrown)
                    .clickable {
                        val nextMode = if (currentMode == AppMode.CUSTOMER_APP) AppMode.RESTAURANT_HQ else AppMode.CUSTOMER_APP
                        viewModel.switchMode(nextMode)
                    }
                    .padding(horizontal = 12.dp, vertical = 6.dp)
                    .testTag("app_mode_toggle_switch")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.SwapHoriz,
                        contentDescription = "Switch Mode",
                        tint = GoldGlaze,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = if (currentMode == AppMode.CUSTOMER_APP) "GO TO HQ OPERATIONS" else "GO TO CUSTOMER APP",
                        color = PureWhite,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.SansSerif
                    )
                }
            }
        }
    }
}

@Composable
fun OliveGardenAppContent(viewModel: OliveGardenViewModel) {
    val currentMode by viewModel.currentMode.collectAsState()
    val successMessage by viewModel.successMessage.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()

    Box(modifier = Modifier.fillMaxSize()) {
        Crossfade(targetState = currentMode, label = "ModeTransition") { mode ->
            when (mode) {
                AppMode.CUSTOMER_APP -> CustomerAppScreen(viewModel = viewModel, modifier = Modifier.fillMaxSize())
                AppMode.RESTAURANT_HQ -> OperationsHqScreen(viewModel = viewModel, modifier = Modifier.fillMaxSize())
            }
        }

        // Notification overlays
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 80.dp, start = 16.dp, end = 16.dp)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            successMessage?.let { msg ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = OliveGardenGreen),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.clearMessages() }
                        .testTag("success_toast"),
                    elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("✓", color = PureWhite, fontWeight = FontWeight.Bold)
                        Text(msg, color = PureWhite, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }

            errorMessage?.let { msg ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = DeepItalianRed),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.clearMessages() }
                        .testTag("error_toast"),
                    elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("⚠", color = PureWhite, fontWeight = FontWeight.Bold)
                        Text(msg, color = PureWhite, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}
