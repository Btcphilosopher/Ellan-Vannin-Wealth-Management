// Aadhaar Trust Core
// High-performance cryptographic primitives and identity verification engine in Rust.

use sha2::{Sha256, Digest};
use std::collections::HashMap;
use std::time::{SystemTime, UNIX_EPOCH};

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct IdentityRecord {
    pub identity_id: String,
    pub status: String,
    pub created_at: u64,
    pub updated_at: u64,
    pub verification_level: String,
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct BiometricTemplate {
    pub biometric_id: String,
    pub identity_id: String,
    pub biometric_type: String, // "FINGERPRINT", "IRIS", "FACE"
    pub template_version: String,
    pub template_hash: String,
    pub encrypted_template_reference: String,
    pub quality_score: f64,
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct LedgerEvent {
    pub event_id: String,
    pub identity_reference_hash: String,
    pub event_type: String,
    pub timestamp: u64,
    pub authority: String,
    pub previous_hash: String,
    pub event_hash: String,
    pub signature: String,
    pub consent_reference: Option<String>,
    pub credential_reference: Option<String>,
}

#[derive(Debug, Clone)]
pub struct MerkleNode {
    pub hash: String,
    pub left: Option<Box<MerkleNode>>,
    pub right: Option<Box<MerkleNode>>,
}

pub struct MerkleTree {
    pub root_hash: String,
}

impl MerkleTree {
    /// Builds a Merkle Tree from a list of identity event hashes.
    pub fn build(hashes: &[String]) -> Self {
        if hashes.is_empty() {
            return MerkleTree {
                root_hash: Self::hash_data("EMPTY_BATCH"),
            };
        }

        let mut current_level: Vec<String> = hashes.to_vec();

        while current_level.len() > 1 {
            let mut next_level = Vec::new();
            for i in (0..current_level.len()).step_by(2) {
                let left = &current_level[i];
                let right = if i + 1 < current_level.len() {
                    &current_level[i + 1]
                } else {
                    left // Duplicate last node if odd number of items
                };
                let concatenated = format!("{}{}", left, right);
                next_level.push(Self::hash_data(&concatenated));
            }
            current_level = next_level;
        }

        MerkleTree {
            root_hash: current_level[0].clone(),
        }
    }

    pub fn hash_data(data: &str) -> String {
        let mut hasher = Sha256::new();
        hasher.update(data.as_bytes());
        format!("{:x}", hasher.finalize())
    }
}

/// Verification Policy Engine
pub struct PolicyEngine {
    pub policies: HashMap<String, String>,
}

impl PolicyEngine {
    pub fn new() -> Self {
        let mut policies = HashMap::new();
        policies.insert("BANK_ACCOUNT_OPENING".to_string(), "IDENTITY && CONSENT && (AUTHENTICATION_LEVEL == HIGH)".to_string());
        policies.insert("TELECOM_SIM_ACTIVATION".to_string(), "IDENTITY && CONSENT && (AUTHENTICATION_LEVEL >= MEDIUM)".to_string());
        policies.insert("GOVERNMENT_BENEFIT".to_string(), "IDENTITY && CONSENT && (BIOMETRIC_MATCH == TRUE)".to_string());
        Self { policies }
    }

    /// Evaluates if an institution request meets ABAC criteria.
    pub fn evaluate_policy(
        &self,
        institution_type: &str,
        purpose: &str,
        has_consent: bool,
        verification_level: &str,
    ) -> bool {
        if !has_consent {
            return false;
        }
        match purpose {
            "ACCOUNT_OPENING" => institution_type == "BANK" && verification_level == "HIGH",
            "SIM_ACTIVATION" => (institution_type == "TELECOM" || institution_type == "GOVERNMENT") && (verification_level == "HIGH" || verification_level == "MEDIUM"),
            "SUBSIDY_DISBURSAL" => institution_type == "GOVERNMENT" && verification_level == "HIGH",
            _ => false,
        }
    }
}

/// Zero-Knowledge Selector Simulation
/// Provides proofs like 'Age > 18' without disclosing exact date of birth.
pub struct ZkIdentityProof;

impl ZkIdentityProof {
    pub fn generate_age_proof(birth_timestamp: u64, target_age: u32) -> (bool, String) {
        let now_sec = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs();
        let age_in_seconds = now_sec.saturating_sub(birth_timestamp);
        let target_seconds = (target_age as u64) * 365 * 24 * 60 * 60; // Simplified
        let is_over_target = age_in_seconds >= target_seconds;

        // Generate a synthetic zk-SNARK proof hash
        let mut hasher = Sha256::new();
        hasher.update(format!("ZK-AGE-PROOF:{}:{}:{}", birth_timestamp, target_age, is_over_target).as_bytes());
        let proof_hash = format!("zk-proof-{:x}", hasher.finalize());

        (is_over_target, proof_hash)
    }

    pub fn generate_residency_proof(address_state: &str, expected_state: &str) -> (bool, String) {
        let matches = address_state == expected_state;
        let mut hasher = Sha256::new();
        hasher.update(format!("ZK-RESIDENCY-PROOF:{}:{}:{}", address_state, expected_state, matches).as_bytes());
        let proof_hash = format!("zk-proof-{:x}", hasher.finalize());

        (matches, proof_hash)
    }
}
