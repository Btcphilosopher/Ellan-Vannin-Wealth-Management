-- Aadhaar Trust Fabric - PostgreSQL Schema Design
-- Structured layout mapping identity records, demographic data classifications,
-- biometric vaults, event hashes, consents, verifiable credentials, and audit systems.

CREATE DATABASE aadhaar_trust_db;
\c aadhaar_trust_db;

-- 1. SCHEMAS
CREATE SCHEMA identity;
CREATE SCHEMA biometric;
CREATE SCHEMA credential;
CREATE SCHEMA consent;
CREATE SCHEMA authentication;
CREATE SCHEMA verification;
CREATE SCHEMA ledger;
CREATE SCHEMA audit;
CREATE SCHEMA administration;

-- 2. ENUMS
CREATE TYPE identity.identity_status AS ENUM ('APPLICATION', 'ENROLMENT', 'VALIDATION', 'ACTIVE', 'UPDATED', 'SUSPENDED', 'REVOKED');
CREATE TYPE biometric.biometric_category AS ENUM ('FINGERPRINT', 'IRIS', 'FACE');
CREATE TYPE credential.credential_status AS ENUM ('ACTIVE', 'EXPIRED', 'REVOKED', 'SUSPENDED', 'SUPERSEDED');
CREATE TYPE audit.audit_action AS ENUM ('LOGIN', 'IDENTITY_READ', 'IDENTITY_UPDATED', 'AUTHENTICATION', 'VERIFICATION', 'CONSENT', 'CREDENTIAL_ISSUED', 'CREDENTIAL_REVOKED', 'BIOMETRIC_ACCESS', 'ADMIN_ACTION', 'KEY_ROTATION', 'DATA_EXPORT');

-- 3. IDENTITY RECORDS
CREATE TABLE identity.identity_records (
    identity_id VARCHAR(32) PRIMARY KEY, -- Synthetically generated identifier (e.g. ID-DEMO-000000184)
    status identity.identity_status NOT NULL DEFAULT 'APPLICATION',
    verification_level VARCHAR(16) NOT NULL DEFAULT 'HIGH',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 4. DEMOGRAPHICS WITH CLASSIFICATION ATTRIBUTES
CREATE TABLE identity.identity_demographics (
    demographic_id SERIAL PRIMARY KEY,
    identity_id VARCHAR(32) REFERENCES identity.identity_records(identity_id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL, -- SENSITIVE_PERSONAL
    date_of_birth DATE NOT NULL, -- SENSITIVE_PERSONAL
    gender VARCHAR(16) NOT NULL, -- PERSONAL
    address TEXT NOT NULL, -- SENSITIVE_PERSONAL
    language VARCHAR(64) DEFAULT 'English', -- INTERNAL
    country VARCHAR(100) DEFAULT 'India', -- PUBLIC
    state VARCHAR(100) NOT NULL, -- PUBLIC
    district VARCHAR(100) NOT NULL, -- PUBLIC
    postcode VARCHAR(16) NOT NULL, -- PUBLIC
    access_classification VARCHAR(32) DEFAULT 'SENSITIVE_PERSONAL'
);

-- Index for geographic partitioning and lookups
CREATE INDEX idx_demographics_state_district ON identity.identity_demographics (state, district);

-- 5. BIOMETRIC VAULT (SEPARATE SECURE SCHEMA)
CREATE TABLE biometric.biometric_vault (
    biometric_id VARCHAR(64) PRIMARY KEY,
    identity_id VARCHAR(32) REFERENCES identity.identity_records(identity_id) ON DELETE CASCADE,
    biometric_type biometric.biometric_category NOT NULL,
    template_version VARCHAR(16) NOT NULL,
    template_hash VARCHAR(64) NOT NULL, -- SHA-256 hash of template, never store raw image
    encrypted_template_reference VARCHAR(255) NOT NULL, -- S3/Object Storage pointer with envelope encryption
    quality_score NUMERIC(5,2) CHECK (quality_score >= 0.00 AND quality_score <= 100.00),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(32) DEFAULT 'ACTIVE'
);

-- 6. VERIFIABLE CREDENTIALS STATUS REGISTRY
CREATE TABLE credential.credentials (
    credential_id VARCHAR(64) PRIMARY KEY,
    issuer VARCHAR(255) NOT NULL,
    subject_reference VARCHAR(32) REFERENCES identity.identity_records(identity_id) ON DELETE CASCADE,
    claim_type VARCHAR(64) NOT NULL, -- "AGE_OVER_18", "RESIDENCY", "IDENTITY"
    issued_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP WITH TIME ZONE,
    status credential.credential_status NOT NULL DEFAULT 'ACTIVE',
    signature TEXT NOT NULL
);

-- 7. CONSENT LEDGER RECORDS
CREATE TABLE consent.consents (
    consent_id VARCHAR(64) PRIMARY KEY,
    identity_id VARCHAR(32) REFERENCES identity.identity_records(identity_id) ON DELETE CASCADE,
    institution_id VARCHAR(128) NOT NULL,
    purpose TEXT NOT NULL,
    requested_claims TEXT[] NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    status VARCHAR(32) DEFAULT 'GRANTED'
);

-- 8. AUTHENTICATION & VERIFICATION STATS
CREATE TABLE authentication.events (
    event_id VARCHAR(64) PRIMARY KEY,
    identity_id VARCHAR(32) REFERENCES identity.identity_records(identity_id) ON DELETE CASCADE,
    method VARCHAR(32) NOT NULL, -- "BIOMETRIC", "OTP", "DEMOGRAPHIC"
    result BOOLEAN NOT NULL,
    authority VARCHAR(128) NOT NULL,
    audit_reference VARCHAR(64) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE verification.claims_verification (
    verification_id VARCHAR(64) PRIMARY KEY,
    consent_id VARCHAR(64) REFERENCES consent.consents(consent_id),
    institution_id VARCHAR(128) NOT NULL,
    result VARCHAR(32) NOT NULL, -- "VERIFIED", "REJECTED"
    assurance_level VARCHAR(32) NOT NULL, -- "HIGH", "MEDIUM"
    proof_reference VARCHAR(128) NOT NULL, -- ZK Proof hash or signature reference
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 9. DECENTRALIZED PERMISSIONED LEDGER (BLOCKCHAIN SIMULATOR INTERACTION LOG)
CREATE TABLE ledger.blocks (
    block_height BIGINT PRIMARY KEY,
    previous_hash VARCHAR(64) NOT NULL,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    event_count INT NOT NULL,
    merkle_root VARCHAR(64) NOT NULL,
    validator_signatures TEXT[] NOT NULL
);

CREATE TABLE ledger.transactions (
    tx_id VARCHAR(64) PRIMARY KEY,
    block_height BIGINT REFERENCES ledger.blocks(block_height) ON DELETE CASCADE,
    event_id VARCHAR(64) NOT NULL,
    identity_reference_hash VARCHAR(64) NOT NULL, -- SHA-256(identity_id) - privacy preservation
    event_type VARCHAR(64) NOT NULL,
    authority VARCHAR(128) NOT NULL,
    event_hash VARCHAR(64) NOT NULL,
    signature TEXT NOT NULL,
    consent_reference VARCHAR(64)
);

-- 10. IMMUTABLE SYSTEM AUDIT LOGS (PARTITIONED BY MONTH FOR PERFORMANCE)
CREATE TABLE audit.system_logs (
    log_id BIGINT GENERATED ALWAYS AS IDENTITY,
    operator_id VARCHAR(128) NOT NULL,
    role VARCHAR(64) NOT NULL,
    action audit.audit_action NOT NULL,
    resource_id VARCHAR(128),
    reason TEXT NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    payload_hash VARCHAR(64) NOT NULL, -- Verification of log integrity
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
) PARTITION BY RANGE (created_at);

-- 11. ADMINISTRATIVE DUAL-CONTROL (FOUR-EYES PRINCIPLE)
CREATE TABLE administration.dual_control_requests (
    request_id VARCHAR(64) PRIMARY KEY,
    requested_by VARCHAR(128) NOT NULL, -- Admin A
    approved_by VARCHAR(128), -- Admin B
    operation_type VARCHAR(64) NOT NULL, -- "KEY_ROTATION", "IDENTITY_REVOCATION"
    target_resource VARCHAR(128) NOT NULL,
    reason TEXT NOT NULL,
    payload TEXT NOT NULL,
    status VARCHAR(32) DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'APPROVED', 'REJECTED')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    resolved_at TIMESTAMP WITH TIME ZONE
);
