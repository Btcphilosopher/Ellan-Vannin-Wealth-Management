# Aadhaar Trust Fabric - Python National Scale Simulator
# Deterministic synthetic generators, demographic deduplication engine, and regional partition simulations.

import hashlib
import time
import random
from typing import Dict, List, Optional, Tuple

class SyntheticPopulationGenerator:
    """Generates millions-scale synthetic identity metadata deterministically."""
    
    def __init__(self, seed: int = 42):
        self.random = random.Random(seed)
        self.first_names = ["Rajesh", "Aarav", "Priya", "Sunita", "Ananya", "Amit", "Vikram", "Sneha", "Karan", "Meera"]
        self.last_names = ["Sharma", "Patel", "Kumar", "Iyer", "Singh", "Joshi", "Das", "Reddy", "Mehta", "Nair"]
        self.states = ["Maharashtra", "Karnataka", "Tamil Nadu", "Delhi", "Uttar Pradesh", "West Bengal", "Gujarat"]
        self.districts = {
            "Maharashtra": ["Mumbai", "Pune", "Nagpur"],
            "Karnataka": ["Bengaluru", "Mysuru", "Hubli"],
            "Tamil Nadu": ["Chennai", "Coimbatore", "Madurai"],
            "Delhi": ["New Delhi", "North Delhi", "South Delhi"],
            "Uttar Pradesh": ["Lucknow", "Noida", "Kanpur"],
            "West Bengal": ["Kolkata", "Darjeeling", "Howrah"],
            "Gujarat": ["Ahmedabad", "Surat", "Vadodara"]
        }

    def generate_resident(self, index: int) -> dict:
        """Generates a synthetic resident demographic and biometric record."""
        self.random.seed(1000000 + index) # Deterministic offset
        first = self.random.choice(self.first_names)
        last = self.random.choice(self.last_names)
        state = self.random.choice(self.states)
        district = self.random.choice(self.districts[state])
        
        dob_year = self.random.randint(1950, 2010)
        dob_month = self.random.randint(1, 12)
        dob_day = self.random.randint(1, 28)
        dob = f"{dob_year:04d}-{dob_month:02d}-{dob_day:02d}"
        
        postcode = f"{self.random.randint(110001, 850000)}"
        identity_id = f"ID-DEMO-{index:09d}"
        
        # Data classification tags
        demographic = {
            "identity_id": identity_id,
            "name": f"{first} {last}",
            "date_of_birth": dob,
            "gender": self.random.choice(["MALE", "FEMALE", "OTHER"]),
            "address": f"Flat {self.random.randint(1, 200)}, Block {self.random.choice(['A','B','C'])}, Sector {self.random.randint(1, 15)}, {district}, {state}",
            "state": state,
            "district": district,
            "postcode": postcode,
            "classification_policy": {
                "name": "PERSONAL",
                "date_of_birth": "SENSITIVE_PERSONAL",
                "biometrics": "BIOMETRIC",
            }
        }
        
        # Biometric synthetic templates
        biometrics = {
            "fingerprint_template": hashlib.sha256(f"{identity_id}:fingerprint".encode()).hexdigest()[:48],
            "iris_template": hashlib.sha256(f"{identity_id}:iris".encode()).hexdigest()[:48],
            "face_template": hashlib.sha256(f"{identity_id}:face".encode()).hexdigest()[:48],
            "quality_score": round(self.random.uniform(82.5, 99.8), 2)
        }
        
        return {
            "identity_id": identity_id,
            "status": "ACTIVE",
            "verification_level": "HIGH" if index % 5 != 0 else "MEDIUM",
            "demographic": demographic,
            "biometrics": biometrics,
            "region": self.random.choice(["NORTH", "SOUTH", "EAST", "WEST", "CENTRAL"])
        }


class DeduplicationEngine:
    """Conceptual identity deduplication engine evaluating demographic and biometric overlaps."""
    
    @staticmethod
    def calculate_demographic_similarity(res1: dict, res2: dict) -> float:
        """Calculates overlap between name, date of birth, state and postcode."""
        score = 0.0
        if res1["name"] == res2["name"]:
            score += 0.4
        if res1["date_of_birth"] == res2["date_of_birth"]:
            score += 0.3
        if res1["postcode"] == res2["postcode"]:
            score += 0.2
        if res1["state"] == res2["state"]:
            score += 0.1
        return score

    @staticmethod
    def evaluate_biometric_similarity(template1_hash: str, template2_hash: str) -> float:
        """Simulates biometric match comparison."""
        # Lev distance of hashes as proxy for visual similarity distance
        matches = sum(1 for a, b in zip(template1_hash, template2_hash) if a == b)
        return matches / len(template1_hash) if template1_hash else 0.0

    def check_fraud_signals(self, resident: dict, existing_records: List[dict]) -> dict:
        """Returns risk profile: LOW, MEDIUM, HIGH, or MANUAL_REVIEW."""
        highest_score = 0.0
        for existing in existing_records:
            score = self.calculate_demographic_similarity(resident["demographic"], existing["demographic"])
            if score > highest_score:
                highest_score = score
        
        if highest_score >= 0.8:
            return {"status": "SUSPICIOUS_DUPLICATE", "risk_level": "HIGH", "action": "HOLD_FOR_MANUAL_REVIEW"}
        elif highest_score >= 0.5:
            return {"status": "POTENTIAL_OVERLAP", "risk_level": "MEDIUM", "action": "AUDIT_REQUESTED"}
        else:
            return {"status": "CLEAN", "risk_level": "LOW", "action": "AUTO_ISSUE"}


class RegionalNetworkCoordinator:
    """Simulates high availability, region failures, and network partitions."""
    
    def __init__(self):
        self.regions = ["NORTH", "SOUTH", "EAST", "WEST", "CENTRAL"]
        self.active_regions = {r: True for r in self.regions}
        self.event_queues: Dict[str, List[dict]] = {r: [] for r in self.regions}
        self.national_ledger = []

    def toggle_region(self, region: str, active: bool):
        if region in self.active_regions:
            self.active_regions[region] = active

    def dispatch_event(self, event: dict, origin_region: str) -> Tuple[bool, str]:
        """Dispatches event, queuing it if the destination/national router is partitioned."""
        if not self.active_regions[origin_region]:
            return False, f"Origin Region {origin_region} is offline"
        
        # If active, queue or append directly to the permissioned ledger
        if all(self.active_regions.values()):
            self.national_ledger.append(event)
            return True, "Event successfully committed to National Ledger"
        else:
            # Under partition/failure, store in regional buffer queue
            self.event_queues[origin_region].append(event)
            return True, f"Network Partition active. Event queued locally in {origin_region} buffer"

    def reconcile_partitions(self) -> List[dict]:
        """Reconciles and plays back queued regional events into the national ledger on recovery."""
        reconciled_events = []
        for r in self.regions:
            if self.active_regions[r] and self.event_queues[r]:
                events_to_sync = self.event_queues[r]
                self.national_ledger.extend(events_to_sync)
                reconciled_events.extend(events_to_sync)
                self.event_queues[r] = []
        return reconciled_events
