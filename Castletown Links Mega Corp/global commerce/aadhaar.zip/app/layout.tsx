import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'Aadhaar Trust Fabric – National Digital Identity & Trust Platform',
  description: 'National identity verification & trust infrastructure platform simulator. Secure, auditable, and privacy-preserving digital public infrastructure.',
  openGraph: {
    title: 'Aadhaar Trust Fabric – National Digital Identity Platform',
    description: 'National identity verification & trust infrastructure platform simulator. Secure, auditable, and privacy-preserving digital public infrastructure.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Aadhaar Trust Fabric – National Digital Identity Platform',
    description: 'National identity verification & trust infrastructure platform simulator. Secure, auditable, and privacy-preserving digital public infrastructure.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
