'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { Shield, Key, Database, FileText, CheckCircle, RotateCw, BookOpen, AlertCircle, RefreshCw } from 'lucide-react';
import CitizenPortal from '../components/CitizenPortal';
import InstitutionPortal from '../components/InstitutionPortal';
import OperationsConsole from '../components/OperationsConsole';
import CodeExplorer from '../components/CodeExplorer';

interface Citizen {
  id: string;
  name: string;
  dob: string;
  gender: string;
  address: string;
  state: string;
  postcode: string;
  region: string;
  verificationLevel: string;
  fingerprintHash: string;
  irisHash: string;
  faceHash: string;
  qualityScore: number;
}

interface Consent {
  id: string;
  institution: string;
  purpose: string;
  claims: string[];
  expires: string;
  status: 'ACTIVE' | 'REVOKED';
}

interface AuditLog {
  id: string;
  timestamp: string;
  action: string;
  operator: string;
  reason: string;
  integrityVerified: boolean;
}

interface LedgerBlock {
  height: number;
  previousHash: string;
  merkleRoot: string;
  timestamp: string;
  eventsCount: number;
  validatorSignatures: string[];
  events: Array<{
    id: string;
    type: string;
    citizenId: string;
    authority: string;
    timestamp: string;
  }>;
}

interface KafkaEvent {
  id: string;
  timestamp: string;
  topic: string;
  payload: string;
}

export default function Home() {
  const [activePortal, setActivePortal] = useState<'citizen' | 'institution' | 'operations' | 'code'>('operations');

  // Synthetic Citizens base state
  const [citizens, setCitizens] = useState<Citizen[]>([
    {
      id: 'ID-DEMO-0010842',
      name: 'Rajiv Sharma',
      dob: '1978-08-14',
      gender: 'MALE',
      address: '74, Lodhi Estate, New Delhi, India',
      state: 'Delhi',
      postcode: '110003',
      region: 'NORTH',
      verificationLevel: 'HIGH',
      fingerprintHash: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
      irisHash: 'ca978112ca1bbdcafac231b39a23dc4da786eff8147c4e72b9807785afee48bb',
      faceHash: '3e23b2a26c4423010b9afc3c8e41bf1a2dcdfa970172e259b139bfb13f383e22',
      qualityScore: 96.4
    },
    {
      id: 'ID-DEMO-0020481',
      name: 'Priyanjali Nair',
      dob: '2002-11-23',
      gender: 'FEMALE',
      address: 'M-102, HSR Layout, Sector 4, Bengaluru, Karnataka, India',
      state: 'Karnataka',
      postcode: '560102',
      region: 'SOUTH',
      verificationLevel: 'HIGH',
      fingerprintHash: 'f4b36021481e28bbd91242bbdcdcfcf12bcaf0711aa12bcda238ef128abccfc9',
      irisHash: '2bc1bc49a71bda7bf1b142abdfda9e17cdbe8fa21e428abcdcdaef82782b1cda',
      faceHash: '9a92abdaef2cdaefdf1c72df89fba827aefcd7281bc7e2da0fcd98ab21cd871a',
      qualityScore: 98.1
    },
    {
      id: 'ID-DEMO-0030992',
      name: 'Vikram Sethi',
      dob: '2009-04-05',
      gender: 'MALE',
      address: 'Flat 4B, Salt Lake Sector 5, Kolkata, West Bengal, India',
      state: 'West Bengal',
      postcode: '700091',
      region: 'EAST',
      verificationLevel: 'MEDIUM',
      fingerprintHash: 'bcfa821eaedbcdafa72b7dacfdf7aefd28cbe0711bc32890ae728cbdae90acbd',
      irisHash: '8cbadae17c0932cdade007efda091cdefbc087fbc90812abcadef7823ab1cd7a',
      faceHash: '4392bcda78ec09aefbcd0a98fba012aefbcd8f67e1a0298decf82cbaef190acd',
      qualityScore: 91.8
    }
  ]);

  const [selectedCitizen, setSelectedCitizen] = useState<Citizen>(citizens[0]);

  // Consents base state
  const [consents, setConsents] = useState<Consent[]>([
    {
      id: 'CON-00108',
      institution: 'State Bank of India (SBI)',
      purpose: 'Opening Savings Account',
      claims: ['IDENTITY', 'AGE_OVER_18', 'STATE'],
      expires: '2027-12-31',
      status: 'ACTIVE'
    },
    {
      id: 'CON-00204',
      institution: 'Bharat Sanchar Nigam (BSNL)',
      purpose: 'Acquiring mobile SIM gateway',
      claims: ['IDENTITY', 'STATE'],
      expires: '2026-12-31',
      status: 'ACTIVE'
    },
    {
      id: 'CON-00309',
      institution: 'Max Life Insurance Corp',
      purpose: 'Securing life insurance policy',
      claims: ['IDENTITY', 'ELIGIBILITY'],
      expires: '2028-06-30',
      status: 'ACTIVE'
    }
  ]);

  // Audit Log list base state
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([
    {
      id: 'AUD-84012',
      timestamp: '08:01:10',
      action: 'LOGIN',
      operator: 'SYSTEM_ADMIN',
      reason: 'Console operator session established with mTLS certificate authentication.',
      integrityVerified: true
    },
    {
      id: 'AUD-84011',
      timestamp: '08:00:45',
      action: 'KEY_ROTATION',
      operator: 'SECURITY_ADMIN',
      reason: 'Rotated secondary KEK for demographic state cluster database storage.',
      integrityVerified: true
    }
  ]);

  // Shared state for Blockchain blocks and Kafka simulated events
  const [blocks, setBlocks] = useState<LedgerBlock[]>([
    {
      height: 18482,
      previousHash: '0x1A2B3C4D5E6F7A8B9C0D1E2F3A4B5C6D7E8F9A0B1C2D3E4F5A6B7C8D9E0F1A2B',
      merkleRoot: '0xF3A11B4C9D5E8A9B1C0D7E8F12A0D5C3E21FA87B9C0D3E4F5A6B7C8D9E0F1A2B',
      timestamp: '08:01:00',
      eventsCount: 3,
      validatorSignatures: ['SIG-VAL-NORTH', 'SIG-VAL-SOUTH', 'SIG-VAL-CENTRAL'],
      events: [
        { id: 'EVT-004812', type: 'IDENTITY_CREATED', citizenId: 'ID-DEMO-0010842', authority: 'DEL-HQ-CORE', timestamp: '08:00:15' },
        { id: 'EVT-004813', type: 'CONSENT_GRANTED', citizenId: 'ID-DEMO-0010842', authority: 'ND-NORTH-GW', timestamp: '08:00:30' },
        { id: 'EVT-004814', type: 'VERIFICATION_SUCCESS', citizenId: 'ID-DEMO-0010842', authority: 'BLR-SOUTH-GW', timestamp: '08:00:55' }
      ]
    },
    {
      height: 18481,
      previousHash: '0xFA87B9C0D3E4F5A6B7C8D9E0F1A2B3C4D5E6F7A8B9C0D1E2F3A4B5C6D7E8F9A0',
      merkleRoot: '0xBC83E9A4D391A23D8FBCE7F26ABDC84EDFC3E821AEBD98FA81BC7F6A24D3BEFC',
      timestamp: '07:55:00',
      eventsCount: 1,
      validatorSignatures: ['SIG-VAL-EAST', 'SIG-VAL-WEST', 'SIG-VAL-CENTRAL'],
      events: [
        { id: 'EVT-004791', type: 'IDENTITY_CREATED', citizenId: 'ID-DEMO-0020481', authority: 'DEL-HQ-CORE', timestamp: '07:54:12' }
      ]
    }
  ]);

  const [kafkaEvents, setKafkaEvents] = useState<KafkaEvent[]>([
    {
      id: 'EVT-004814',
      timestamp: '08:00:55',
      topic: 'verification.events',
      payload: '{"event_type":"VERIFICATION_SUCCESS","resident_ref":"HASH(0x0010842)","origin_gateway":"BLR-SOUTH-GW","status":"COMMITTED"}'
    },
    {
      id: 'EVT-004813',
      timestamp: '08:00:30',
      topic: 'consent.events',
      payload: '{"event_type":"CONSENT_GRANTED","resident_ref":"HASH(0x0010842)","consent_id":"CON-00108","status":"COMMITTED"}'
    },
    {
      id: 'EVT-004812',
      timestamp: '08:00:15',
      topic: 'identity.events',
      payload: '{"event_type":"IDENTITY_CREATED","resident_ref":"HASH(0x0010842)","origin_gateway":"DEL-HQ-CORE","status":"COMMITTED"}'
    }
  ]);

  const handleLogAudit = (action: string, reason: string) => {
    const newLog: AuditLog = {
      id: `AUD-${Math.floor(Math.random() * 90000 + 10000)}`,
      timestamp: new Date().toLocaleTimeString(),
      action,
      operator: activePortal === 'citizen' ? 'CITIZEN_USER' : activePortal === 'institution' ? 'INSTITUTION_OPERATOR' : 'SYSTEM_ADMIN',
      reason,
      integrityVerified: true
    };
    setAuditLogs(prev => [newLog, ...prev]);
  };

  const handleRevokeConsent = (consentId: string) => {
    setConsents(prev =>
      prev.map(c => c.id === consentId ? { ...c, status: 'REVOKED' } : c)
    );
    const target = consents.find(c => c.id === consentId);
    handleLogAudit('CONSENT_REVOKED', `Citizen revoked consent granted to ${target?.institution} for purpose '${target?.purpose}'`);
  };

  const handleLogVerification = (verificationId: string, result: string, assurance: string, proofRef: string) => {
    // Also push a block transaction into the ledger automatically to simulate consensus sync
    setBlocks(prev => {
      const nextHeight = prev[0].height + 1;
      const prevHash = prev[0].merkleRoot;
      const newBlock: LedgerBlock = {
        height: nextHeight,
        previousHash: prevHash,
        merkleRoot: `0x${Math.floor(Math.random() * 900000 + 100000).toString(16).toUpperCase()}7F21`,
        timestamp: new Date().toLocaleTimeString(),
        eventsCount: 1,
        validatorSignatures: ['SIG-VAL-CENTRAL', 'SIG-VAL-EAST'],
        events: [
          {
            id: verificationId,
            type: 'VERIFICATION_SUCCESS',
            citizenId: selectedCitizen.id,
            authority: 'BLR-SOUTH-GW',
            timestamp: new Date().toLocaleTimeString()
          }
        ]
      };
      return [newBlock, ...prev];
    });

    // Push into Kafka Bus simulator
    const newEvent: KafkaEvent = {
      id: verificationId,
      timestamp: new Date().toLocaleTimeString(),
      topic: 'verification.events',
      payload: JSON.stringify({
        event_type: 'VERIFICATION_SUCCESS',
        resident_ref: `HASH(0x${selectedCitizen.id.substring(8)})`,
        proof_reference: proofRef,
        assurance_level: assurance
      })
    };
    setKafkaEvents(prev => [newEvent, ...prev]);
  };

  return (
    <main className="min-h-screen bg-[#FAF9F6] text-slate-800 font-sans pb-16 antialiased selection:bg-[#C2410C]/20">
      {/* Dynamic Top Bar Contract - Exactly 3 zones */}
      <header className="sticky top-0 z-50 bg-white border-b border-[#E2E8F0] backdrop-blur px-6 py-4 flex items-center justify-between">
        {/* Zone 1: Wordmark - single text element */}
        <div className="text-lg font-bold tracking-tight text-[#111E38] font-serif uppercase">
          Aadhaar Trust Fabric
        </div>

        {/* Zone 2: Nav Links (interactive buttons) */}
        <nav className="hidden md:flex items-center gap-6">
          <button
            onClick={() => setActivePortal('operations')}
            className={`text-xs font-bold uppercase tracking-wider pb-1 transition-all ${activePortal === 'operations' ? 'text-[#C2410C] border-b-2 border-[#C2410C]' : 'text-slate-500 hover:text-slate-800'}`}
          >
            System Console
          </button>
          <button
            onClick={() => setActivePortal('citizen')}
            className={`text-xs font-bold uppercase tracking-wider pb-1 transition-all ${activePortal === 'citizen' ? 'text-[#C2410C] border-b-2 border-[#C2410C]' : 'text-slate-500 hover:text-slate-800'}`}
          >
            Citizen Portal
          </button>
          <button
            onClick={() => setActivePortal('institution')}
            className={`text-xs font-bold uppercase tracking-wider pb-1 transition-all ${activePortal === 'institution' ? 'text-[#C2410C] border-b-2 border-[#C2410C]' : 'text-slate-500 hover:text-slate-800'}`}
          >
            Institution Gateway
          </button>
          <button
            onClick={() => setActivePortal('code')}
            className={`text-xs font-bold uppercase tracking-wider pb-1 transition-all ${activePortal === 'code' ? 'text-[#C2410C] border-b-2 border-[#C2410C]' : 'text-slate-500 hover:text-slate-800'}`}
          >
            Repository Explorer
          </button>
        </nav>

        {/* Zone 3: Primary action/badge */}
        <div className="flex items-center gap-3">
          <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-amber-50 text-[#C2410C] border border-amber-200">
            SYNTHETIC DEMO Sandbox
          </span>
        </div>
      </header>

      {/* Main Content Area */}
      <div className="max-w-7xl mx-auto px-6 pt-8 grid grid-cols-1 xl:grid-cols-12 gap-8">
        
        {/* Portal Switchboard */}
        <div className="xl:col-span-9 space-y-8">
          
          {/* Header Title segment (no badges, clean) */}
          <div className="border-b border-[#E2E8F0] pb-6">
            <h1 className="text-3xl font-bold text-[#111E38] tracking-tight font-serif">
              {activePortal === 'operations' && "National Identity Operations Console"}
              {activePortal === 'citizen' && "My Identity Privacy & Consent Portal"}
              {activePortal === 'institution' && "Institutional Verification Services"}
              {activePortal === 'code' && "Architecture & Code Reference Repository"}
            </h1>
            <p className="text-slate-500 text-sm mt-1">
              {activePortal === 'operations' && "Monitor cryptographic ledger commitments, geographical replication status, and national-scale stress workloads."}
              {activePortal === 'citizen' && "Securely review held demographic credentials, verify biometric sensory references, and administer active third-party consents."}
              {activePortal === 'institution' && "Initiate high-assurance identity verification with zero raw profile disclosure, abiding by absolute ABAC policy rules."}
              {activePortal === 'code' && "Review standard physical implementations of high-performance components written in Rust, Python, R, and SQL."}
            </p>
          </div>

          {/* Active Portal Renderer */}
          {activePortal === 'operations' && (
            <OperationsConsole
              blocks={blocks}
              kafkaEvents={kafkaEvents}
              onLogAudit={handleLogAudit}
            />
          )}

          {activePortal === 'citizen' && (
            <CitizenPortal
              citizens={citizens}
              selectedCitizen={selectedCitizen}
              onCitizenChange={(c) => {
                setSelectedCitizen(c);
                handleLogAudit('IDENTITY_READ', `Citizen session switched to profile reference: ${c.id}`);
              }}
              consents={consents}
              onRevokeConsent={handleRevokeConsent}
              onLogAudit={handleLogAudit}
            />
          )}

          {activePortal === 'institution' && (
            <InstitutionPortal
              citizens={citizens}
              consents={consents}
              onLogVerification={handleLogVerification}
              onLogAudit={handleLogAudit}
            />
          )}

          {activePortal === 'code' && (
            <CodeExplorer />
          )}

        </div>

        {/* Right Sidebar: Immutable System Audit Logs */}
        <div className="xl:col-span-3 space-y-6">
          <div className="bg-white border border-[#E2E8F0] rounded-lg p-5 sticky top-24">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3 mb-4">
              <span className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Immutable System Audit Logs
              </span>
              <span className="text-[9px] font-mono text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded">
                VERIFIED
              </span>
            </div>
            <p className="text-[11px] text-slate-500 mb-4 leading-relaxed">
              Every sensitive operation generates an audit hash and payload seal, verified continuously against the ledger to enforce security compliance.
            </p>

            <div className="space-y-4 max-h-[420px] overflow-y-auto pr-1">
              {auditLogs.map((log) => (
                <div key={log.id} className="border-l-2 border-[#C2410C] pl-3 space-y-1">
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] font-mono text-slate-400 font-bold">[{log.timestamp}] {log.action}</span>
                    <span className="text-[9px] font-mono text-slate-500">{log.operator}</span>
                  </div>
                  <p className="text-xs text-slate-700 leading-relaxed font-sans">{log.reason}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

      </div>
    </main>
  );
}
