'use client';

import React, { useState, useEffect, useRef } from 'react';
import { Database, Cpu, Activity, RefreshCw, AlertCircle, Play, Server, Layers, HelpCircle, HardDrive } from 'lucide-react';

interface LedgerBlock {
  height: number;
  previousHash: string;
  merkleRoot: string;
  timestamp: string;
  eventsCount: number;
  validatorSignatures: string[];
  events: Array<{
    id: string;
    type: string;
    citizenId: string;
    authority: string;
    timestamp: string;
  }>;
}

interface KafkaEvent {
  id: string;
  timestamp: string;
  topic: string;
  payload: string;
}

interface OperationsConsoleProps {
  blocks: LedgerBlock[];
  kafkaEvents: KafkaEvent[];
  onLogAudit: (action: string, reason: string) => void;
}

export default function OperationsConsole({
  blocks: initialBlocks,
  kafkaEvents: initialKafkaEvents,
  onLogAudit
}: OperationsConsoleProps) {
  // Simulator State
  const [blocks, setBlocks] = useState<LedgerBlock[]>(initialBlocks);
  const [kafkaEvents, setKafkaEvents] = useState<KafkaEvent[]>(initialKafkaEvents);
  const [selectedBlock, setSelectedBlock] = useState<LedgerBlock | null>(null);
  const [scale, setScale] = useState<'10M' | '100M' | '500M' | '1B'>('100M');
  const [isRunningBench, setIsRunningBench] = useState(false);
  const [benchReport, setBenchReport] = useState<any | null>(null);

  // High-availability / Regional Resilience
  const [regions, setRegions] = useState<Record<string, 'ONLINE' | 'OFFLINE' | 'PARTITIONED'>>({
    'NORTH': 'ONLINE',
    'SOUTH': 'ONLINE',
    'EAST': 'ONLINE',
    'WEST': 'ONLINE',
    'CENTRAL': 'ONLINE'
  });
  const [regionalQueues, setRegionalQueues] = useState<Record<string, number>>({
    'NORTH': 0, 'SOUTH': 0, 'EAST': 0, 'WEST': 0, 'CENTRAL': 0
  });

  // Automated rolling logs inside the Kafka topic simulator
  useEffect(() => {
    const interval = setInterval(() => {
      // If a region is offline, queue events there. If network partition, queue generally.
      let someOffline = Object.values(regions).some(status => status !== 'ONLINE');
      
      const eventTypes = ['IDENTITY_UPDATED', 'CONSENT_GRANTED', 'VERIFICATION_SUCCESS', 'OTP_CHALLENGE', 'BIOMETRIC_ACCESS'];
      const topics = ['identity.events', 'consent.events', 'verification.events', 'audit.events', 'security.events'];
      const citizens = ['ID-DEMO-0010842', 'ID-DEMO-0020481', 'ID-DEMO-0030992'];
      const authorities = ['ND-NORTH-GW', 'BLR-SOUTH-GW', 'KOL-EAST-GW', 'MUM-WEST-GW', 'DEL-HQ-CORE'];

      const randomType = eventTypes[Math.floor(Math.random() * eventTypes.length)];
      const randomTopic = topics[Math.floor(Math.random() * topics.length)];
      const randomCitizen = citizens[Math.floor(Math.random() * citizens.length)];
      const randomAuth = authorities[Math.floor(Math.random() * authorities.length)];
      const eventId = `EVT-00${Math.floor(Math.random() * 90000 + 10000)}`;

      // Identify corresponding region for the authority
      const originRegion = randomAuth.includes('NORTH') ? 'NORTH' :
                           randomAuth.includes('SOUTH') ? 'SOUTH' :
                           randomAuth.includes('EAST') ? 'EAST' :
                           randomAuth.includes('WEST') ? 'WEST' : 'CENTRAL';

      if (regions[originRegion] === 'OFFLINE') {
        // Drop event, raise alert
        return;
      }

      if (regions[originRegion] === 'PARTITIONED') {
        // Queue locally
        setRegionalQueues(prev => ({
          ...prev,
          [originRegion]: prev[originRegion] + 1
        }));
        return;
      }

      const newEvent: KafkaEvent = {
        id: eventId,
        timestamp: new Date().toLocaleTimeString(),
        topic: randomTopic,
        payload: JSON.stringify({
          event_type: randomType,
          resident_ref: `HASH(0x${randomCitizen.substring(8)})`,
          origin_gateway: randomAuth,
          status: 'COMMITTED'
        })
      };

      setKafkaEvents(prev => [newEvent, ...prev.slice(0, 39)]);

      // Occasionally batch events to generate blocks
      if (Math.random() > 0.8) {
        setBlocks(prev => {
          const nextHeight = prev[0].height + 1;
          const prevHash = prev[0].merkleRoot;
          const blockEvents = [
            { id: eventId, type: randomType, citizenId: randomCitizen, authority: randomAuth, timestamp: new Date().toLocaleTimeString() }
          ];
          const newBlock: LedgerBlock = {
            height: nextHeight,
            previousHash: prevHash,
            merkleRoot: `0x${Math.floor(Math.random() * 900000 + 100000).toString(16).toUpperCase()}8A11B4`,
            timestamp: new Date().toLocaleTimeString(),
            eventsCount: blockEvents.length,
            validatorSignatures: ['SIG-VAL-NORTH', 'SIG-VAL-SOUTH', 'SIG-VAL-CENTRAL'],
            events: blockEvents
          };
          return [newBlock, ...prev];
        });
      }
    }, 3000);

    return () => clearInterval(interval);
  }, [regions]);

  const handleRunBenchmark = () => {
    setIsRunningBench(true);
    setBenchReport(null);

    setTimeout(() => {
      let multiplier = 1;
      if (scale === '10M') multiplier = 0.1;
      if (scale === '500M') multiplier = 5;
      if (scale === '1B') multiplier = 10;

      setBenchReport({
        storageDemographic: (1.4 * multiplier).toFixed(2), // Petabytes
        storageBiometrics: (4.2 * multiplier).toFixed(2), // Petabytes
        tpsAuthentication: Math.floor(18500 / (multiplier > 1 ? 1.5 : 1)), // Transactions per second
        tpsVerification: Math.floor(32000 / (multiplier > 1 ? 1.4 : 1)),
        avgQueryLatency: (22 + (multiplier * 1.5)).toFixed(1), // Milliseconds
        replicationLag: (110 + (multiplier * 12)).toFixed(0), // Milliseconds
        eerPercent: 0.0028 // Equal error rate percentage
      });

      setIsRunningBench(false);
      onLogAudit('ADMIN_ACTION', `Executed national scale stress benchmark simulator for scale: ${scale}`);
    }, 1200);
  };

  const handleToggleRegion = (region: string) => {
    const current = regions[region];
    let next: 'ONLINE' | 'OFFLINE' | 'PARTITIONED' = 'ONLINE';
    if (current === 'ONLINE') next = 'OFFLINE';
    else if (current === 'OFFLINE') next = 'PARTITIONED';

    setRegions(prev => ({ ...prev, [region]: next }));
    onLogAudit('ADMIN_ACTION', `Manual node operator action: Toggle status of region ${region} to ${next}`);
  };

  const handleReconcileQueues = (region: string) => {
    const queuedCount = regionalQueues[region];
    if (queuedCount === 0) return;

    // Simulate batch replay into Kafka & ledger
    setRegionalQueues(prev => ({ ...prev, [region]: 0 }));
    onLogAudit('ADMIN_ACTION', `Disaster recovery reconciliation: Flushed and replayed ${queuedCount} buffered identity audit records from regional node ${region}`);
  };

  return (
    <div className="space-y-6">
      {/* Infrastructure Availability Tracker */}
      <div className="bg-white border border-[#E2E8F0] rounded-lg">
        <div className="px-6 py-4 border-b border-[#E2E8F0] bg-[#FAF9F6] flex justify-between items-center">
          <h3 className="font-semibold text-slate-900 text-sm uppercase tracking-wider flex items-center gap-2">
            <Server className="text-[#111E38]" size={18} /> Regional Infrastructure Nodes (Disaster Recovery)
          </h3>
          <span className="text-[10px] font-mono text-slate-500">MULTIPLE ACTIVE REPLICAS</span>
        </div>
        <div className="p-6">
          <p className="text-xs text-slate-500 mb-6 leading-relaxed">
            The national identity database operates geographically partitioned clusters. Test system resilience by intentionally dropping or partitioning nodes. In a partition, write requests queue locally and reconcile once consensus quorum settles.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            {Object.entries(regions).map(([region, status]) => (
              <div key={region} className="border border-[#E2E8F0] rounded p-4 bg-slate-50 flex flex-col justify-between space-y-4">
                <div>
                  <span className="text-xs font-bold text-slate-900 font-mono block">{region} REGION</span>
                  <span className={`text-[10px] font-mono font-medium block mt-1 ${status === 'ONLINE' ? 'text-emerald-700' : status === 'OFFLINE' ? 'text-rose-700' : 'text-amber-700'}`}>
                    ● {status}
                  </span>
                </div>
                
                {regionalQueues[region] > 0 && (
                  <div className="bg-amber-50 p-2 rounded border border-amber-200 text-center">
                    <span className="text-[10px] text-amber-800 font-mono font-bold block">{regionalQueues[region]} EVENTS BUFFERED</span>
                  </div>
                )}

                <div className="space-y-2">
                  <button
                    onClick={() => handleToggleRegion(region)}
                    className="w-full text-[10px] bg-white border border-slate-300 py-1.5 rounded font-bold hover:bg-slate-100 transition-colors uppercase tracking-wider text-slate-700"
                  >
                    CYCLE STATUS
                  </button>
                  {regionalQueues[region] > 0 && (
                    <button
                      onClick={() => handleReconcileQueues(region)}
                      className="w-full text-[10px] bg-emerald-700 text-white py-1.5 rounded font-bold hover:bg-emerald-800 transition-colors uppercase tracking-wider"
                    >
                      RECONCILE QUEUE
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* National Scale Stress Simulator */}
        <div className="lg:col-span-6 space-y-6">
          <div className="bg-white border border-[#E2E8F0] rounded-lg">
            <div className="px-6 py-4 border-b border-[#E2E8F0] bg-[#FAF9F6]">
              <h3 className="font-semibold text-slate-900 text-sm uppercase tracking-wider flex items-center gap-2">
                <Cpu className="text-[#C2410C]" size={18} /> National Scale Stress Simulator
              </h3>
            </div>
            <div className="p-6 space-y-4">
              <p className="text-xs text-slate-500 leading-relaxed">
                Project systems resources, database capacities, lookup latency metrics, and cryptographic ledger throughput when scaling to millions or billions of active national identities.
              </p>
              
              <div className="flex gap-2 items-center">
                <span className="text-xs font-mono text-slate-500 uppercase shrink-0">TARGET POPULATION:</span>
                {['10M', '100M', '500M', '1B'].map(sz => (
                  <button
                    key={sz}
                    onClick={() => setScale(sz as any)}
                    className={`flex-1 py-1.5 text-xs font-mono font-bold border rounded transition-colors ${scale === sz ? 'bg-[#C2410C] text-white border-[#C2410C]' : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'}`}
                  >
                    {sz === '1B' ? '1.4 BILLION (INDIA)' : sz}
                  </button>
                ))}
              </div>

              <button
                onClick={handleRunBenchmark}
                disabled={isRunningBench}
                className="w-full bg-[#111E38] hover:bg-[#1C2C4E] text-white py-2 rounded text-xs font-semibold uppercase tracking-wider transition-colors flex items-center justify-center gap-2"
              >
                {isRunningBench ? <RefreshCw className="animate-spin" size={14} /> : "Compute scale parameters"}
              </button>

              {benchReport && (
                <div className="border border-[#E2E8F0] rounded p-4 bg-[#FAF9F6] space-y-3">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <span className="text-[10px] text-slate-400 block mb-0.5 uppercase font-mono">DEMOGRAPHIC DB SIZE</span>
                      <span className="font-mono text-sm font-bold text-slate-900">{benchReport.storageDemographic} PB</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block mb-0.5 uppercase font-mono">BIOMETRIC VAULT SIZE</span>
                      <span className="font-mono text-sm font-bold text-slate-900">{benchReport.storageBiometrics} PB</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block mb-0.5 uppercase font-mono">AUTH THROUGHPUT CAPACITY</span>
                      <span className="font-mono text-sm font-bold text-slate-900">{benchReport.tpsAuthentication.toLocaleString()} TPS</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block mb-0.5 uppercase font-mono">VERIFICATION RATE</span>
                      <span className="font-mono text-sm font-bold text-slate-900">{benchReport.tpsVerification.toLocaleString()} TPS</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block mb-0.5 uppercase font-mono">AVG API QUERY LATENCY</span>
                      <span className="font-mono text-sm font-bold text-slate-900">{benchReport.avgQueryLatency} ms</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block mb-0.5 uppercase font-mono">EQUAL ERROR RATE (EER)</span>
                      <span className="font-mono text-sm font-bold text-slate-900">0.0028% (PROVEN BOUND)</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Real-time event stream (Kafka style) */}
          <div className="bg-white border border-[#E2E8F0] rounded-lg">
            <div className="px-6 py-4 border-b border-[#E2E8F0] bg-[#FAF9F6]">
              <h3 className="font-semibold text-slate-900 text-sm uppercase tracking-wider">
                Event Log (Kafka Bus Topic simulation)
              </h3>
            </div>
            <div className="p-6">
              <div className="bg-[#22252A] p-4 rounded text-[11px] font-mono text-slate-300 h-64 overflow-y-auto space-y-1">
                {kafkaEvents.map((evt) => (
                  <div key={evt.id} className="flex gap-2 py-0.5">
                    <span className="text-slate-500">[{evt.timestamp}]</span>
                    <span className="text-amber-400 font-bold shrink-0">{evt.topic}:</span>
                    <span className="text-slate-300 break-all">{evt.payload}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Permissioned Ledger Browser */}
        <div className="lg:col-span-6 space-y-6">
          <div className="bg-white border border-[#E2E8F0] rounded-lg">
            <div className="px-6 py-4 border-b border-[#E2E8F0] bg-[#FAF9F6] flex justify-between items-center">
              <h3 className="font-semibold text-slate-900 text-sm uppercase tracking-wider flex items-center gap-2">
                <Layers className="text-[#111E38]" size={18} /> Permissioned Trust Ledger
              </h3>
              <span className="text-[10px] font-mono text-slate-500 font-bold">SHA-256 EVENT BLOCKCHAIN</span>
            </div>
            <div className="p-6 space-y-4">
              <p className="text-xs text-slate-500 leading-relaxed">
                Ledger blocks preserve event order, consensus signatures, and tamper-evident Merkle roots. It contains cryptographically bound zero-disclosure references, not actual database demographics or biometrics.
              </p>

              {/* Block chain rendering */}
              <div className="grid grid-cols-2 gap-3 h-52 overflow-y-auto pr-2">
                {blocks.map((block) => (
                  <div
                    key={block.height}
                    onClick={() => setSelectedBlock(block)}
                    className={`border rounded p-3 transition-all cursor-pointer ${selectedBlock?.height === block.height ? 'bg-[#111E38] text-white border-[#111E38]' : 'bg-white border-[#E2E8F0] hover:bg-slate-50'}`}
                  >
                    <div className="flex justify-between items-center">
                      <span className="text-xs font-bold font-mono">BLOCK #{block.height}</span>
                      <span className="text-[9px] font-mono opacity-80">{block.timestamp}</span>
                    </div>
                    <span className="text-[9px] font-mono block mt-2 opacity-60 truncate">MERKLE: {block.merkleRoot}</span>
                    <span className="text-[10px] block mt-1 font-sans">{block.eventsCount} SECURE TRANS.</span>
                  </div>
                ))}
              </div>

              {/* Selected Block details */}
              {selectedBlock && (
                <div className="border border-[#E2E8F0] rounded p-4 bg-[#FAF9F6] space-y-3">
                  <div className="flex justify-between items-center border-b border-slate-200 pb-2">
                    <span className="text-xs font-bold text-slate-900 font-mono">BLOCK #{selectedBlock.height} METADATA</span>
                    <button
                      onClick={() => setSelectedBlock(null)}
                      className="text-[10px] font-mono text-[#C2410C]"
                    >
                      DISMISS
                    </button>
                  </div>
                  <div className="space-y-1.5 text-xs text-slate-700">
                    <div>
                      <span className="text-[10px] font-mono text-slate-400 block">PREVIOUS BLOCK HASH</span>
                      <span className="font-mono text-[11px] truncate block text-[#111E38]">{selectedBlock.previousHash}</span>
                    </div>
                    <div>
                      <span className="text-[10px] font-mono text-slate-400 block">MERKLE TREE ROOT HASH</span>
                      <span className="font-mono text-[11px] truncate block text-[#111E38]">{selectedBlock.merkleRoot}</span>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <span className="text-[10px] font-mono text-slate-400 block">VALIDATOR QUORUM</span>
                        <span className="text-[10px] font-sans text-slate-800">3 Nodes Signed</span>
                      </div>
                      <div>
                        <span className="text-[10px] font-mono text-slate-400 block">CONSENSUS STATE</span>
                        <span className="text-[10px] font-bold text-emerald-800 uppercase font-mono">FINALIZED</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
