'use client';

import React, { useState } from 'react';
import { FileCode, Terminal, HelpCircle, HardDrive, Cpu, FileSpreadsheet } from 'lucide-react';

export default function CodeExplorer() {
  const [activeTab, setActiveTab] = useState<'rust' | 'python' | 'r' | 'sql'>('rust');

  const files = {
    rust: {
      path: '/rust/aadhaar-trust-core/src/lib.rs',
      lang: 'Rust',
      icon: Cpu,
      desc: 'High-performance cryptographic primitives, Merkle trees, zero-knowledge mathematical verification, and Attribute-Based Access Control logic.',
      code: `// Aadhaar Trust Core
// High-performance cryptographic primitives and identity verification engine in Rust.

use sha2::{Sha256, Digest};
use std::collections::HashMap;
use std::time::{SystemTime, UNIX_EPOCH};

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct IdentityRecord {
    pub identity_id: String,
    pub status: String,
    pub created_at: u64,
    pub updated_at: u64,
    pub verification_level: String,
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct BiometricTemplate {
    pub biometric_id: String,
    pub identity_id: String,
    pub biometric_type: String, // "FINGERPRINT", "IRIS", "FACE"
    pub template_version: String,
    pub template_hash: String,
    pub encrypted_template_reference: String,
    pub quality_score: f64,
}

impl MerkleTree {
    /// Builds a Merkle Tree from a list of identity event hashes.
    pub fn build(hashes: &[String]) -> Self {
        if hashes.is_empty() {
            return MerkleTree { root_hash: Self::hash_data("EMPTY_BATCH") };
        }
        let mut current_level: Vec<String> = hashes.to_vec();
        while current_level.len() > 1 {
            let mut next_level = Vec::new();
            for i in (0..current_level.len()).step_by(2) {
                let left = &current_level[i];
                let right = if i + 1 < current_level.len() { &current_level[i + 1] } else { left };
                let concatenated = format!("{}{}", left, right);
                next_level.push(Self::hash_data(&concatenated));
            }
            current_level = next_level;
        }
        MerkleTree { root_hash: current_level[0].clone() }
    }
}`
    },
    python: {
      path: '/python/aadhaar_sim/main.py',
      lang: 'Python',
      icon: Terminal,
      desc: 'Deterministic population scale simulator, demographic similarity checks, and regional failover/network partition handlers.',
      code: `# Aadhaar Trust Fabric - Python National Scale Simulator
# Deterministic synthetic generators, demographic deduplication engine, and regional partition simulations.

import hashlib
import time
import random
from typing import Dict, List, Optional, Tuple

class SyntheticPopulationGenerator:
    """Generates millions-scale synthetic identity metadata deterministically."""
    
    def __init__(self, seed: int = 42):
        self.random = random.Random(seed)
        self.first_names = ["Rajesh", "Aarav", "Priya", "Sunita", "Ananya"]
        self.last_names = ["Sharma", "Patel", "Kumar", "Iyer", "Singh"]

    def generate_resident(self, index: int) -> dict:
        self.random.seed(1000000 + index)
        first = self.random.choice(self.first_names)
        last = self.random.choice(self.last_names)
        state = self.random.choice(["Maharashtra", "Karnataka", "Tamil Nadu"])
        
        identity_id = f"ID-DEMO-{index:09d}"
        return {
            "identity_id": identity_id,
            "status": "ACTIVE",
            "demographic": {
                "name": f"{first} {last}",
                "state": state,
                "country": "INDIA"
            }
        }`
    },
    r: {
      path: '/r/analytics/reliability.R',
      lang: 'R Script',
      icon: FileSpreadsheet,
      desc: 'System throughput distributions, false-match cross-over curves, equal-error-rates, and population capacity planning parameters.',
      code: `# Aadhaar Trust Fabric - R Statistical Quality Control & Simulation Analytics
# Computes system throughput latency distributions, failure ratios, and synthetic population quality bounds.

library(data.table)

analyze_verification_latency <- function(sample_size = 100000) {
  set.seed(42)
  network_delay <- rgamma(sample_size, shape = 2, scale = 15)       # Mean 30ms
  matching_delay <- rlnorm(sample_size, meanlog = 3.2, sdlog = 0.45) # Mean ~28ms
  ledger_commit <- rweibull(sample_size, shape = 1.5, scale = 80)    # Mean ~72ms
  
  total_latency <- network_delay + matching_delay + ledger_commit
  return(list(
    mean_latency = mean(total_latency),
    p95_latency = quantile(total_latency, 0.95),
    p99_latency = quantile(total_latency, 0.99)
  ))
}`
    },
    sql: {
      path: '/database/schema.sql',
      lang: 'PostgreSQL SQL',
      icon: HardDrive,
      desc: 'Authoritative physical schemas partitioning biometric templates, credentials, audit registries, and administrative dual-control records.',
      code: `-- Aadhaar Trust Fabric - PostgreSQL Schema Design
-- Structured layout mapping identity records, demographic data classifications,
-- biometric vaults, event hashes, consents, verifiable credentials, and audit systems.

CREATE SCHEMA identity;
CREATE SCHEMA biometric;
CREATE SCHEMA ledger;
CREATE SCHEMA audit;

CREATE TABLE identity.identity_records (
    identity_id VARCHAR(32) PRIMARY KEY,
    status identity.identity_status NOT NULL DEFAULT 'APPLICATION',
    verification_level VARCHAR(16) NOT NULL DEFAULT 'HIGH',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE biometric.biometric_vault (
    biometric_id VARCHAR(64) PRIMARY KEY,
    identity_id VARCHAR(32) REFERENCES identity.identity_records(identity_id) ON DELETE CASCADE,
    biometric_type biometric.biometric_category NOT NULL,
    template_hash VARCHAR(64) NOT NULL
);`
    }
  };

  const active = files[activeTab];
  const Icon = active.icon;

  return (
    <div className="bg-white border border-[#E2E8F0] rounded-lg overflow-hidden">
      <div className="px-6 py-4 border-b border-[#E2E8F0] bg-[#FAF9F6] flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h3 className="font-semibold text-slate-900 text-sm uppercase tracking-wider flex items-center gap-2">
            <FileCode className="text-[#C2410C]" size={18} /> Architectural Code & Schema Registry
          </h3>
        </div>
        <div className="flex flex-wrap gap-1">
          {(Object.keys(files) as Array<keyof typeof files>).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-3 py-1 text-xs font-semibold rounded uppercase tracking-wider transition-all border ${activeTab === tab ? 'bg-[#111E38] text-white border-[#111E38]' : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'}`}
            >
              {files[tab].lang}
            </button>
          ))}
        </div>
      </div>

      <div className="p-6 space-y-4">
        <div className="flex gap-3 items-start bg-slate-50 p-4 rounded border border-slate-100">
          <Icon className="text-[#C2410C] shrink-0 mt-0.5" size={18} />
          <div>
            <span className="text-[10px] font-mono text-slate-400 block uppercase">PHYSICAL REPOSITORY PATH: {active.path}</span>
            <p className="text-xs text-slate-600 leading-relaxed mt-1 font-sans">{active.desc}</p>
          </div>
        </div>

        <div className="bg-[#22252A] rounded p-4 overflow-x-auto border border-slate-800">
          <pre className="text-slate-300 text-xs font-mono leading-relaxed h-80 overflow-y-auto">
            <code>{active.code}</code>
          </pre>
        </div>
      </div>
    </div>
  );
}
