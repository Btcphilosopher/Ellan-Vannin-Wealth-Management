'use client';

import React, { useState } from 'react';
import { Shield, Key, FileText, CheckCircle, Eye, EyeOff, RotateCw, AlertTriangle, ArrowDownToLine } from 'lucide-react';

interface Citizen {
  id: string;
  name: string;
  dob: string;
  gender: string;
  address: string;
  state: string;
  postcode: string;
  region: string;
  verificationLevel: string;
  fingerprintHash: string;
  irisHash: string;
  faceHash: string;
  qualityScore: number;
}

interface Consent {
  id: string;
  institution: string;
  purpose: string;
  claims: string[];
  expires: string;
  status: 'ACTIVE' | 'REVOKED';
}

interface CitizenPortalProps {
  citizens: Citizen[];
  selectedCitizen: Citizen;
  onCitizenChange: (citizen: Citizen) => void;
  consents: Consent[];
  onRevokeConsent: (consentId: string) => void;
  onLogAudit: (action: string, reason: string) => void;
}

export default function CitizenPortal({
  citizens,
  selectedCitizen,
  onCitizenChange,
  consents,
  onRevokeConsent,
  onLogAudit
}: CitizenPortalProps) {
  const [showSensitive, setShowSensitive] = useState(false);
  const [zkpType, setZkpType] = useState<'over18' | 'residency'>('over18');
  const [zkpTargetState, setZkpTargetState] = useState('Delhi');
  const [zkpResult, setZkpResult] = useState<{ verified: boolean; proof: string; claim: string } | null>(null);
  const [isGeneratingZkp, setIsGeneratingZkp] = useState(false);

  // Generate a ZK-SNARK simulated proof
  const handleGenerateZkp = () => {
    setIsGeneratingZkp(true);
    setTimeout(() => {
      let verified = false;
      let claim = '';

      if (zkpType === 'over18') {
        const birthYear = new Date(selectedCitizen.dob).getFullYear();
        const age = 2026 - birthYear;
        verified = age >= 18;
        claim = `Resident is OVER 18 years of age (Calculated age: ${age})`;
      } else {
        verified = selectedCitizen.state.toLowerCase() === zkpTargetState.toLowerCase();
        claim = `Resident is a certified resident of state: ${zkpTargetState}`;
      }

      // SHA-256 simulation hash
      const dummyProof = `zk-snark-proof-0x${Math.abs(
        selectedCitizen.id.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0) * (verified ? 71 : 13)
      ).toString(16).toUpperCase()}8F12A0D`;

      setZkpResult({ verified, proof: dummyProof, claim });
      setIsGeneratingZkp(false);
      onLogAudit('VERIFICATION', `ZKP generated for claim type: ${zkpType.toUpperCase()} (Result: ${verified})`);
    }, 600);
  };

  const handleDownloadPackage = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(
      JSON.stringify({
        title: "AADHAAR TRUST FABRIC - CITIZEN DATA EXPORT",
        timestamp: new Date().toISOString(),
        classification: "RESTRICTED-SENSITIVE-PERSONAL",
        citizen: selectedCitizen,
        active_consents: consents.filter(c => c.status === 'ACTIVE')
      }, null, 2)
    );
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `${selectedCitizen.id}_trust_package.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    onLogAudit('DATA_EXPORT', `Citizen downloaded entire signed identity data package`);
  };

  const activeCitizenConsents = consents;

  return (
    <div className="space-y-6">
      {/* Selector banner */}
      <div className="bg-white border border-[#E2E8F0] p-6 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-mono text-slate-500 uppercase tracking-wider block mb-1">Active Citizen Session</span>
          <div className="flex items-center gap-3">
            <select
              value={selectedCitizen.id}
              onChange={(e) => {
                const found = citizens.find(c => c.id === e.target.value);
                if (found) onCitizenChange(found);
              }}
              className="font-semibold text-lg text-[#111E38] bg-transparent border-b-2 border-slate-300 focus:border-[#C2410C] focus:outline-none pb-1 cursor-pointer"
            >
              {citizens.map(c => (
                <option key={c.id} value={c.id} className="text-base text-slate-900">{c.name} ({c.id})</option>
              ))}
            </select>
            <span className="text-xs bg-emerald-50 text-emerald-800 border border-emerald-200 px-2.5 py-0.5 rounded font-mono font-medium">
              {selectedCitizen.verificationLevel} ASSURANCE
            </span>
          </div>
        </div>
        <button
          onClick={handleDownloadPackage}
          className="flex items-center justify-center gap-2 px-4 py-2 text-xs font-semibold uppercase tracking-wider border border-[#111E38] text-[#111E38] hover:bg-slate-50 transition-colors rounded"
        >
          <ArrowDownToLine size={14} /> Download Secure Identity Package
        </button>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Demographics and Biometrics */}
        <div className="lg:col-span-7 space-y-6">
          {/* Demographic Vault */}
          <div className="bg-white border border-[#E2E8F0] rounded-lg">
            <div className="px-6 py-4 border-b border-[#E2E8F0] flex justify-between items-center bg-[#FAF9F6]">
              <div className="flex items-center gap-2">
                <Shield className="text-[#111E38]" size={18} />
                <h3 className="font-semibold text-slate-900 text-sm uppercase tracking-wider">Demographic Vault (PostgreSQL)</h3>
              </div>
              <button
                onClick={() => setShowSensitive(!showSensitive)}
                className="flex items-center gap-1.5 text-xs font-semibold text-[#C2410C] hover:text-[#9A3412]"
              >
                {showSensitive ? <EyeOff size={14} /> : <Eye size={14} />}
                {showSensitive ? "MASK SENSITIVE" : "DECRYPT SENSITIVE"}
              </button>
            </div>

            <div className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <span className="text-xs text-slate-400 block mb-0.5">PUBLIC / STATE</span>
                  <span className="font-semibold text-sm text-slate-900">{selectedCitizen.state}</span>
                </div>
                <div>
                  <span className="text-xs text-slate-400 block mb-0.5">PUBLIC / POSTCODE</span>
                  <span className="font-semibold text-sm text-slate-900 font-mono">{selectedCitizen.postcode}</span>
                </div>
                <div>
                  <span className="text-xs text-slate-400 block mb-0.5">INTERNAL / REGION</span>
                  <span className="font-semibold text-sm text-slate-900 font-mono">{selectedCitizen.region}</span>
                </div>
                <div>
                  <span className="text-xs text-slate-400 block mb-0.5">PUBLIC / COUNTRY</span>
                  <span className="font-semibold text-sm text-slate-900">INDIA</span>
                </div>
              </div>

              <hr className="border-[#E2E8F0]" />

              <div className="space-y-3">
                <div>
                  <div className="flex items-center justify-between mb-0.5">
                    <span className="text-xs text-slate-400">SENSITIVE PERSONAL / FULL NAME</span>
                    <span className="text-[10px] font-mono text-amber-700 bg-amber-50 px-1.5 rounded">RESTRICTED</span>
                  </div>
                  <span className={`text-sm font-semibold transition-all duration-300 ${showSensitive ? 'text-slate-900 blur-none' : 'text-slate-300 select-none blur-[4px]'}`}>
                    {selectedCitizen.name}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="flex items-center justify-between mb-0.5">
                      <span className="text-xs text-slate-400">SENSITIVE / DATE OF BIRTH</span>
                    </div>
                    <span className={`text-sm font-semibold transition-all duration-300 font-mono ${showSensitive ? 'text-slate-900 blur-none' : 'text-slate-300 select-none blur-[4px]'}`}>
                      {selectedCitizen.dob}
                    </span>
                  </div>
                  <div>
                    <span className="text-xs text-slate-400 block mb-0.5">PERSONAL / GENDER</span>
                    <span className="text-sm font-semibold text-slate-900">{selectedCitizen.gender}</span>
                  </div>
                </div>
                <div>
                  <div className="flex items-center justify-between mb-0.5">
                    <span className="text-xs text-slate-400">SENSITIVE PERSONAL / RESIDENTIAL ADDRESS</span>
                  </div>
                  <p className={`text-sm font-semibold leading-relaxed transition-all duration-300 ${showSensitive ? 'text-slate-900 blur-none' : 'text-slate-300 select-none blur-[4px]'}`}>
                    {selectedCitizen.address}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Biometric Vault (Zero raw storage) */}
          <div className="bg-white border border-[#E2E8F0] rounded-lg">
            <div className="px-6 py-4 border-b border-[#E2E8F0] bg-[#FAF9F6] flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Key className="text-[#111E38]" size={18} />
                <h3 className="font-semibold text-slate-900 text-sm uppercase tracking-wider">Secure Biometric Vault</h3>
              </div>
              <span className="text-[10px] font-mono text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 uppercase">
                ENVELOPE ENCRYPTED
              </span>
            </div>
            <div className="p-6 space-y-4">
              <p className="text-xs text-slate-500 leading-relaxed">
                Raw biometric sensory data is destroyed immediately after acquisition. Only high-dimension secure structural templates are persisted with key-encryption-keys (KEKs) inside dedicated HSM borders.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="border border-[#E2E8F0] p-4 rounded bg-slate-50 space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-semibold text-slate-700">FINGERPRINT</span>
                    <span className="text-[10px] font-mono text-slate-500 font-bold">{selectedCitizen.qualityScore}% Q</span>
                  </div>
                  <div className="font-mono text-[10px] text-[#C2410C] truncate bg-white p-2 rounded border border-[#E2E8F0]">
                    {selectedCitizen.fingerprintHash}
                  </div>
                </div>
                <div className="border border-[#E2E8F0] p-4 rounded bg-slate-50 space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-semibold text-slate-700">IRIS TEMPLATE</span>
                    <span className="text-[10px] font-mono text-slate-500 font-bold">98.4% Q</span>
                  </div>
                  <div className="font-mono text-[10px] text-[#C2410C] truncate bg-white p-2 rounded border border-[#E2E8F0]">
                    {selectedCitizen.irisHash}
                  </div>
                </div>
                <div className="border border-[#E2E8F0] p-4 rounded bg-slate-50 space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-semibold text-slate-700">FACIAL VEIN</span>
                    <span className="text-[10px] font-mono text-slate-500 font-bold">94.1% Q</span>
                  </div>
                  <div className="font-mono text-[10px] text-[#C2410C] truncate bg-white p-2 rounded border border-[#E2E8F0]">
                    {selectedCitizen.faceHash}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: ZK selectively disclosed proofs & Consent Manager */}
        <div className="lg:col-span-5 space-y-6">
          {/* Zero-Knowledge Proof Studio */}
          <div className="bg-white border border-[#E2E8F0] rounded-lg">
            <div className="px-6 py-4 border-b border-[#E2E8F0] bg-[#FAF9F6]">
              <h3 className="font-semibold text-slate-900 text-sm uppercase tracking-wider flex items-center gap-2">
                <CheckCircle className="text-[#C2410C]" size={18} /> Selective Attribute Disclosure (ZKP)
              </h3>
            </div>
            <div className="p-6 space-y-4">
              <p className="text-xs text-slate-500 leading-relaxed">
                Rather than disclosing your full Date of Birth or complete Address to third-party institutions, generate a cryptographically bound, mathematically documented selective proof.
              </p>
              
              <div className="space-y-3">
                <div className="flex gap-2">
                  <button
                    onClick={() => { setZkpType('over18'); setZkpResult(null); }}
                    className={`flex-1 py-1.5 px-3 text-xs font-medium rounded border transition-colors ${zkpType === 'over18' ? 'bg-[#111E38] text-white border-[#111E38]' : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'}`}
                  >
                    Age Over 18
                  </button>
                  <button
                    onClick={() => { setZkpType('residency'); setZkpResult(null); }}
                    className={`flex-1 py-1.5 px-3 text-xs font-medium rounded border transition-colors ${zkpType === 'residency' ? 'bg-[#111E38] text-white border-[#111E38]' : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'}`}
                  >
                    State Residence
                  </button>
                </div>

                {zkpType === 'residency' && (
                  <div>
                    <label className="text-[10px] font-mono text-slate-500 uppercase block mb-1">Target Residence State</label>
                    <select
                      value={zkpTargetState}
                      onChange={(e) => { setZkpTargetState(e.target.value); setZkpResult(null); }}
                      className="w-full text-xs bg-slate-50 border border-slate-200 rounded p-2 focus:outline-none focus:border-[#C2410C]"
                    >
                      <option value="Delhi">Delhi</option>
                      <option value="Karnataka">Karnataka</option>
                      <option value="Maharashtra">Maharashtra</option>
                      <option value="West Bengal">West Bengal</option>
                      <option value="Gujarat">Gujarat</option>
                    </select>
                  </div>
                )}

                <button
                  onClick={handleGenerateZkp}
                  disabled={isGeneratingZkp}
                  className="w-full bg-[#C2410C] hover:bg-[#9A3412] text-white py-2 rounded text-xs font-semibold uppercase tracking-wider transition-colors flex items-center justify-center gap-2"
                >
                  {isGeneratingZkp ? (
                    <>
                      <RotateCw className="animate-spin" size={14} /> Generating Mathematical Trust Proof...
                    </>
                  ) : "Generate Minimal Disclosure Proof"}
                </button>
              </div>

              {zkpResult && (
                <div className="border border-[#E2E8F0] rounded p-4 bg-[#FAF9F6] space-y-2.5">
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] font-mono text-slate-400">MATHEMATICAL PROOF STATEMENT</span>
                    <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border ${zkpResult.verified ? 'bg-emerald-50 text-emerald-800 border-emerald-200' : 'bg-rose-50 text-rose-800 border-rose-200'}`}>
                      {zkpResult.verified ? "VERIFIED" : "FAILED"}
                    </span>
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-slate-900">{zkpResult.claim}</p>
                    <div className="mt-2 p-2 bg-white rounded border border-[#E2E8F0]">
                      <span className="text-[10px] text-slate-400 block mb-0.5">ZK ROOT PROOF SIGNATURE</span>
                      <span className="text-[10px] font-mono text-[#111E38] block truncate">{zkpResult.proof}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Consent Ledger & Manager */}
          <div className="bg-white border border-[#E2E8F0] rounded-lg">
            <div className="px-6 py-4 border-b border-[#E2E8F0] bg-[#FAF9F6]">
              <h3 className="font-semibold text-slate-900 text-sm uppercase tracking-wider">
                Consent Authorization Ledger
              </h3>
            </div>
            <div className="p-6 space-y-4">
              <p className="text-xs text-slate-500 leading-relaxed">
                Active institutional access scopes granted by you. Revoking consent immediately seals the action on the distributed ledger and triggers absolute access lockouts.
              </p>
              
              <div className="space-y-3">
                {activeCitizenConsents.length === 0 ? (
                  <div className="text-center py-6 border border-dashed border-slate-200 rounded">
                    <span className="text-xs text-slate-400">No active consent structures authorized.</span>
                  </div>
                ) : (
                  activeCitizenConsents.map((consent) => (
                    <div key={consent.id} className={`border rounded p-4 space-y-2 transition-all ${consent.status === 'REVOKED' ? 'opacity-60 bg-slate-50 border-slate-200' : 'bg-white border-[#E2E8F0]'}`}>
                      <div className="flex justify-between items-start">
                        <div>
                          <span className="font-semibold text-xs text-slate-900 block">{consent.institution}</span>
                          <span className="text-[10px] text-slate-500 font-medium block mt-0.5">{consent.purpose}</span>
                        </div>
                        <span className={`text-[9px] font-mono px-2 py-0.5 rounded font-bold uppercase ${consent.status === 'REVOKED' ? 'bg-rose-50 text-rose-700 border border-rose-200' : 'bg-emerald-50 text-emerald-800 border border-emerald-200'}`}>
                          {consent.status}
                        </span>
                      </div>
                      
                      <div className="flex flex-wrap gap-1 items-center text-[10px] text-slate-500">
                        <span className="font-mono text-[9px] text-slate-400">SCOPES:</span>
                        {consent.claims.map((claim, idx) => (
                          <span key={idx} className="bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded text-[9px] font-mono uppercase">
                            {claim}
                          </span>
                        ))}
                      </div>

                      <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                        <span className="text-[10px] text-slate-400 font-mono">Expires: {consent.expires}</span>
                        {consent.status === 'ACTIVE' && (
                          <button
                            onClick={() => onRevokeConsent(consent.id)}
                            className="text-[10px] font-bold text-rose-600 hover:text-rose-800 uppercase tracking-wider"
                          >
                            Revoke Scopes
                          </button>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
