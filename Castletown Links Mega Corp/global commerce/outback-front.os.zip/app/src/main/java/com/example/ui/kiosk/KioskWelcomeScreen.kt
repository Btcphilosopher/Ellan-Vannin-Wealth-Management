package com.example.ui.kiosk

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DiningMode
import com.example.ui.theme.*

@Composable
fun KioskWelcomeScreen(
  onCheckInClicked: () -> Unit,
  onWaitlistClicked: () -> Unit,
  onOrderFoodClicked: (DiningMode) -> Unit,
  onCheckOrderStatusClicked: () -> Unit,
  onHelpClicked: () -> Unit
) {
  var showOrderModeDialog by remember { mutableStateOf(false) }

  if (showOrderModeDialog) {
    AlertDialog(
      onDismissRequest = { showOrderModeDialog = false },
      containerColor = Charcoal800,
      titleContentColor = OutbackAmber,
      title = {
        Text("Select Dining Preference", fontWeight = FontWeight.Bold, color = OutbackAmber)
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
          Text(
            "Are you joining us for a table dining experience or ordering food to takeaway?",
            color = Cream100,
            fontSize = 14.sp
          )
          OutlinedButton(
            onClick = {
              showOrderModeDialog = false
              onOrderFoodClicked(DiningMode.DINE_IN)
            },
            modifier = Modifier
              .fillMaxWidth()
              .height(56.dp)
              .testTag("dialog_dine_in_button"),
            colors = ButtonDefaults.outlinedButtonColors(
              containerColor = Charcoal700,
              contentColor = Cream50
            ),
            border = BorderStroke(1.5.dp, OutbackCrimson)
          ) {
            Icon(Icons.Default.Restaurant, contentDescription = null, tint = OutbackCrimsonLight)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Dine-In (Seated at Table)", fontWeight = FontWeight.Bold)
          }

          OutlinedButton(
            onClick = {
              showOrderModeDialog = false
              onOrderFoodClicked(DiningMode.TAKEAWAY)
            },
            modifier = Modifier
              .fillMaxWidth()
              .height(56.dp)
              .testTag("dialog_takeaway_button"),
            colors = ButtonDefaults.outlinedButtonColors(
              containerColor = Charcoal700,
              contentColor = Cream50
            ),
            border = BorderStroke(1.5.dp, OutbackAmber)
          ) {
            Icon(Icons.Default.TakeoutDining, contentDescription = null, tint = OutbackAmber)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Takeaway / Pick-Up", fontWeight = FontWeight.Bold)
          }
        }
      },
      confirmButton = {},
      dismissButton = {
        TextButton(onClick = { showOrderModeDialog = false }) {
          Text("Cancel", color = Cream200)
        }
      }
    )
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(
        Brush.verticalGradient(
          colors = listOf(Charcoal900, Charcoal800, Charcoal900)
        )
      )
      .verticalScroll(rememberScrollState())
      .padding(horizontal = 24.dp, vertical = 20.dp),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    Spacer(modifier = Modifier.height(8.dp))

    // Header badge
    Surface(
      color = Charcoal700,
      shape = RoundedCornerShape(20.dp),
      border = BorderStroke(1.dp, OutbackAmber.copy(alpha = 0.5f))
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
      ) {
        Icon(
          imageVector = Icons.Default.LocalFireDepartment,
          contentDescription = null,
          tint = OutbackAmber,
          modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = "GUEST TOUCHSCREEN KIOSK",
          color = Cream100,
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          letterSpacing = 1.sp
        )
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    Text(
      text = "WELCOME TO OUTBACK STEAKHOUSE",
      fontSize = 26.sp,
      fontWeight = FontWeight.Black,
      color = Cream50,
      textAlign = TextAlign.Center,
      letterSpacing = 1.sp
    )

    Spacer(modifier = Modifier.height(6.dp))

    Text(
      text = "How can we help you today?",
      fontSize = 16.sp,
      color = OutbackAmber,
      fontWeight = FontWeight.Medium
    )

    Spacer(modifier = Modifier.height(28.dp))

    // 4 Large Touchscreen Interactive Tiles
    KioskHeroTile(
      title = "CHECK IN",
      subtitle = "For guests with existing bookings & reservations",
      icon = Icons.Default.EventAvailable,
      badgeText = "Fast Pass",
      accentColor = OutbackCrimson,
      testTag = "kiosk_tile_checkin",
      onClick = onCheckInClicked
    )

    Spacer(modifier = Modifier.height(16.dp))

    KioskHeroTile(
      title = "JOIN THE WAITLIST",
      subtitle = "Walk-in seating, live queue position & wait estimates",
      icon = Icons.Default.GroupAdd,
      badgeText = "Walk-in Queue",
      accentColor = OutbackAmber,
      testTag = "kiosk_tile_waitlist",
      onClick = onWaitlistClicked
    )

    Spacer(modifier = Modifier.height(16.dp))

    KioskHeroTile(
      title = "ORDER FOOD",
      subtitle = "Explore steaks, appetizers, combos & sides for Dine-In or Takeaway",
      icon = Icons.Default.OutdoorGrill,
      badgeText = "Full Kitchen Menu",
      accentColor = OutbackCrimsonLight,
      testTag = "kiosk_tile_order",
      onClick = { showOrderModeDialog = true }
    )

    Spacer(modifier = Modifier.height(16.dp))

    KioskHeroTile(
      title = "CHECK ORDER STATUS",
      subtitle = "Track active kitchen tickets, cooking progress & readiness",
      icon = Icons.Default.AccessTimeFilled,
      badgeText = "Live Status",
      accentColor = OutbackBlue,
      testTag = "kiosk_tile_status",
      onClick = onCheckOrderStatusClicked
    )

    Spacer(modifier = Modifier.height(28.dp))

    // Footer actions: Language, Accessibility, Help
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          Icons.Default.Language,
          contentDescription = null,
          tint = Cream200,
          modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text("English (US)", color = Cream200, fontSize = 12.sp)
        Spacer(modifier = Modifier.width(16.dp))
        Icon(
          Icons.Default.AccessibilityNew,
          contentDescription = null,
          tint = Cream200,
          modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text("Accessible UI", color = Cream200, fontSize = 12.sp)
      }

      OutlinedButton(
        onClick = onHelpClicked,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, OutbackAmber),
        colors = ButtonDefaults.outlinedButtonColors(
          containerColor = Charcoal800,
          contentColor = OutbackAmber
        ),
        modifier = Modifier
          .height(44.dp)
          .testTag("kiosk_help_button")
      ) {
        Icon(Icons.Default.SupportAgent, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("Host Assistance", fontSize = 13.sp, fontWeight = FontWeight.Bold)
      }
    }
  }
}

@Composable
fun KioskHeroTile(
  title: String,
  subtitle: String,
  icon: ImageVector,
  badgeText: String,
  accentColor: Color,
  testTag: String,
  onClick: () -> Unit
) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .clickable { onClick() }
      .testTag(testTag),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(
      containerColor = Charcoal800
    ),
    border = BorderStroke(1.5.dp, accentColor.copy(alpha = 0.85f)),
    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(20.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Surface(
        color = accentColor.copy(alpha = 0.2f),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, accentColor),
        modifier = Modifier.size(60.dp)
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(
            imageVector = icon,
            contentDescription = null,
            tint = accentColor,
            modifier = Modifier.size(32.dp)
          )
        }
      }

      Spacer(modifier = Modifier.width(16.dp))

      Column(modifier = Modifier.weight(1f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = title,
            fontSize = 18.sp,
            fontWeight = FontWeight.Black,
            color = Cream50,
            letterSpacing = 1.sp
          )
          Spacer(modifier = Modifier.width(8.dp))
          Surface(
            color = Charcoal700,
            shape = RoundedCornerShape(6.dp)
          ) {
            Text(
              text = badgeText,
              color = accentColor,
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = subtitle,
          fontSize = 13.sp,
          color = Cream200,
          lineHeight = 18.sp
        )
      }

      Icon(
        imageVector = Icons.Default.ChevronRight,
        contentDescription = "Proceed",
        tint = accentColor,
        modifier = Modifier.size(28.dp)
      )
    }
  }
}
