package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AppRole
import com.example.model.DiningMode
import com.example.ui.theme.*

fun formatCents(cents: Long): String {
  val dollars = cents / 100
  val remainder = cents % 100
  return "$$dollars.%02d".format(remainder)
}

@Composable
fun AppHeader(
  currentRole: AppRole,
  onRoleSelected: (AppRole) -> Unit,
  diningMode: DiningMode,
  assignedTable: String?,
  onBackClicked: (() -> Unit)? = null,
  cartCount: Int = 0,
  onCartClicked: (() -> Unit)? = null,
  onHelpClicked: (() -> Unit)? = null
) {
  Surface(
    color = Charcoal800,
    tonalElevation = 6.dp,
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.fillMaxWidth()) {
      // Top bar with branding & quick role switcher
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          if (onBackClicked != null) {
            IconButton(
              onClick = onBackClicked,
              modifier = Modifier
                .testTag("nav_back_button")
                .size(48.dp)
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Back",
                tint = Cream50
              )
            }
          }

          Column(modifier = Modifier.padding(start = if (onBackClicked != null) 4.dp else 8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = "OUTBACK",
                fontSize = 18.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 2.sp,
                color = OutbackAmber
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "STEAKHOUSE",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                color = Cream50
              )
              Spacer(modifier = Modifier.width(8.dp))
              Surface(
                color = OutbackCrimson,
                shape = RoundedCornerShape(4.dp)
              ) {
                Text(
                  text = "FRONT.OS",
                  color = Cream50,
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
              }
            }
            Text(
              text = "Sydney Gateway Location #104 · System Live",
              fontSize = 11.sp,
              color = Cream200
            )
          }
        }

        // Right side indicators (Cart, Help, Mode)
        Row(verticalAlignment = Alignment.CenterVertically) {
          if (currentRole == AppRole.KIOSK) {
            Surface(
              color = if (diningMode == DiningMode.DINE_IN) OutbackCrimsonDark else OutbackAmberDark,
              shape = RoundedCornerShape(16.dp),
              modifier = Modifier.padding(end = 8.dp)
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
              ) {
                Icon(
                  imageVector = if (diningMode == DiningMode.DINE_IN) Icons.Default.Restaurant else Icons.Default.TakeoutDining,
                  contentDescription = null,
                  tint = Cream50,
                  modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = if (diningMode == DiningMode.DINE_IN) "Dine-In (${assignedTable ?: "T04"})" else "Takeaway",
                  fontSize = 12.sp,
                  fontWeight = FontWeight.SemiBold,
                  color = Cream50
                )
              }
            }

            if (onCartClicked != null && cartCount > 0) {
              BadgedBox(
                badge = {
                  Badge(
                    containerColor = OutbackAmber,
                    contentColor = Charcoal900
                  ) {
                    Text(cartCount.toString(), fontWeight = FontWeight.Bold)
                  }
                },
                modifier = Modifier.padding(end = 8.dp)
              ) {
                IconButton(
                  onClick = onCartClicked,
                  modifier = Modifier
                    .testTag("top_cart_button")
                    .size(48.dp)
                ) {
                  Icon(
                    imageVector = Icons.Default.ShoppingCart,
                    contentDescription = "View Cart",
                    tint = Cream50
                  )
                }
              }
            }

            if (onHelpClicked != null) {
              IconButton(
                onClick = onHelpClicked,
                modifier = Modifier
                  .testTag("top_help_button")
                  .size(48.dp)
              ) {
                Icon(
                  imageVector = Icons.Default.HelpOutline,
                  contentDescription = "Request Assistance",
                  tint = OutbackAmber
                )
              }
            }
          }
        }
      }

      // Operational Role Selector Bar (for cross-role testing)
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .background(Charcoal900)
          .horizontalScroll(rememberScrollState())
          .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "TERMINAL VIEW:",
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          color = OutbackAmber,
          modifier = Modifier.padding(end = 8.dp)
        )

        AppRole.values().forEach { role ->
          val isSelected = role == currentRole
          FilterChip(
            selected = isSelected,
            onClick = { onRoleSelected(role) },
            label = {
              Text(
                text = role.title,
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
              )
            },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = OutbackCrimson,
              selectedLabelColor = Cream50,
              containerColor = Charcoal700,
              labelColor = Cream200
            ),
            modifier = Modifier
              .padding(end = 6.dp)
              .testTag("role_chip_${role.name.lowercase()}")
          )
        }
      }
    }
  }
}

@Composable
fun StatusFeedbackBanner(
  message: String?,
  onDismiss: () -> Unit
) {
  AnimatedVisibility(visible = message != null) {
    if (message != null) {
      Surface(
        color = OutbackAmberDark,
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
          ) {
            Icon(
              imageVector = Icons.Default.NotificationsActive,
              contentDescription = null,
              tint = Cream50,
              modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = message,
              color = Cream50,
              fontSize = 13.sp,
              fontWeight = FontWeight.Medium
            )
          }
          IconButton(
            onClick = onDismiss,
            modifier = Modifier.size(36.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Close,
              contentDescription = "Dismiss",
              tint = Cream50,
              modifier = Modifier.size(16.dp)
            )
          }
        }
      }
    }
  }
}
