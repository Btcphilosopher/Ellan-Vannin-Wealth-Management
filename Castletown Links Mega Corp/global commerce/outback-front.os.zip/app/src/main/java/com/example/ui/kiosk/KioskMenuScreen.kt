package com.example.ui.kiosk

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CartItem
import com.example.model.MenuCategory
import com.example.model.MenuItem
import com.example.ui.components.formatCents
import com.example.ui.theme.*

@Composable
fun KioskMenuScreen(
  categories: List<MenuCategory>,
  selectedCategory: MenuCategory,
  onCategorySelected: (MenuCategory) -> Unit,
  menuItems: List<MenuItem>,
  onItemClicked: (MenuItem) -> Unit,
  cartItems: List<CartItem>,
  onViewCartClicked: () -> Unit
) {
  val filteredItems = menuItems.filter { it.category == selectedCategory }
  val totalCartCents = cartItems.sumOf { it.totalPriceCents }
  val cartCount = cartItems.sumOf { it.quantity }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(Charcoal900)
  ) {
    Column(modifier = Modifier.fillMaxSize()) {
      // Horizontal Category Tabs
      Surface(
        color = Charcoal800,
        tonalElevation = 2.dp,
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 10.dp),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          categories.forEach { cat ->
            val isSelected = cat == selectedCategory
            FilterChip(
              selected = isSelected,
              onClick = { onCategorySelected(cat) },
              label = {
                Text(
                  text = cat.displayName,
                  fontSize = 13.sp,
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                )
              },
              leadingIcon = if (isSelected) {
                {
                  Icon(
                    Icons.Default.Restaurant,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                    tint = Cream50
                  )
                }
              } else null,
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = OutbackCrimson,
                selectedLabelColor = Cream50,
                containerColor = Charcoal700,
                labelColor = Cream200
              ),
              modifier = Modifier.testTag("menu_category_${cat.name.lowercase()}")
            )
          }
        }
      }

      // Menu Items List
      LazyColumn(
        modifier = Modifier
          .fillMaxSize()
          .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = if (cartCount > 0) 100.dp else 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        item {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = selectedCategory.displayName.uppercase(),
              fontSize = 18.sp,
              fontWeight = FontWeight.Black,
              color = OutbackAmber,
              letterSpacing = 1.sp
            )
            Text(
              text = "${filteredItems.size} Selections",
              fontSize = 12.sp,
              color = Cream200
            )
          }
        }

        items(filteredItems) { item ->
          MenuItemCard(
            item = item,
            onClick = { onItemClicked(item) }
          )
        }
      }
    }

    // Sticky Bottom Cart Bar
    if (cartCount > 0) {
      Surface(
        color = Charcoal800,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
        border = BorderStroke(1.5.dp, OutbackAmber),
        tonalElevation = 8.dp,
        modifier = Modifier
          .align(Alignment.BottomCenter)
          .fillMaxWidth()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 14.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Badge(
              containerColor = OutbackAmber,
              contentColor = Charcoal900
            ) {
              Text(
                text = "$cartCount",
                fontWeight = FontWeight.Black,
                modifier = Modifier.padding(horizontal = 4.dp)
              )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
              Text("Current Order Subtotal", fontSize = 11.sp, color = Cream200)
              Text(
                formatCents(totalCartCents),
                fontSize = 18.sp,
                fontWeight = FontWeight.Black,
                color = Cream50
              )
            }
          }

          Button(
            onClick = onViewCartClicked,
            colors = ButtonDefaults.buttonColors(containerColor = OutbackCrimson),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
              .height(48.dp)
              .testTag("kiosk_view_cart_button")
          ) {
            Text("REVIEW & CHECKOUT", fontWeight = FontWeight.Bold, color = Cream50)
            Spacer(modifier = Modifier.width(6.dp))
            Icon(Icons.Default.ArrowForward, contentDescription = null, tint = Cream50)
          }
        }
      }
    }
  }
}

@Composable
fun MenuItemCard(
  item: MenuItem,
  onClick: () -> Unit
) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .clickable { onClick() }
      .testTag("menu_item_${item.id}"),
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = Charcoal800),
    border = BorderStroke(1.dp, Charcoal700)
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = item.name,
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            color = Cream50
          )
          if (item.calorieCount != null) {
            Text(
              text = "${item.calorieCount} Cal",
              fontSize = 11.sp,
              color = Cream200,
              modifier = Modifier.padding(top = 2.dp)
            )
          }
        }

        Spacer(modifier = Modifier.width(8.dp))

        Surface(
          color = OutbackCrimson.copy(alpha = 0.2f),
          shape = RoundedCornerShape(8.dp),
          border = BorderStroke(1.dp, OutbackCrimson.copy(alpha = 0.5f))
        ) {
          Text(
            text = formatCents(item.basePriceCents),
            color = Cream50,
            fontSize = 15.sp,
            fontWeight = FontWeight.Black,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      Text(
        text = item.description,
        fontSize = 13.sp,
        color = Cream200,
        maxLines = 3,
        overflow = TextOverflow.Ellipsis,
        lineHeight = 18.sp
      )

      if (item.allergens.isNotEmpty()) {
        Spacer(modifier = Modifier.height(10.dp))
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Text("Allergens:", fontSize = 11.sp, color = OutbackAmber, fontWeight = FontWeight.Bold)
          item.allergens.forEach { allergen ->
            Surface(
              color = Charcoal700,
              shape = RoundedCornerShape(4.dp)
            ) {
              Text(
                text = allergen,
                fontSize = 10.sp,
                color = Cream100,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.End
      ) {
        OutlinedButton(
          onClick = onClick,
          shape = RoundedCornerShape(8.dp),
          colors = ButtonDefaults.outlinedButtonColors(
            contentColor = OutbackAmber
          ),
          border = BorderStroke(1.dp, OutbackAmber),
          contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
          modifier = Modifier.height(36.dp)
        ) {
          Icon(Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            if (item.modifierGroups.isNotEmpty() || item.category == MenuCategory.STEAKS) "CUSTOMISE & ADD" else "ADD TO ORDER",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }
    }
  }
}
