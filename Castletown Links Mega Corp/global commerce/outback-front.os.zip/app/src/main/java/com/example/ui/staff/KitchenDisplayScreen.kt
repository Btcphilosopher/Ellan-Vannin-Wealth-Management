package com.example.ui.staff

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.KitchenStation
import com.example.model.KitchenTicket
import com.example.ui.theme.*

@Composable
fun KitchenDisplayScreen(
  tickets: List<KitchenTicket>,
  onToggleItemReady: (ticketId: String, itemId: String) -> Unit,
  onMarkTicketExpoReady: (ticketId: String) -> Unit
) {
  var selectedStation by remember { mutableStateOf<KitchenStation?>(null) }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Charcoal900)
  ) {
    // Station Filter Bar
    Surface(
      color = Charcoal800,
      tonalElevation = 2.dp,
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text("STATION:", fontWeight = FontWeight.Black, fontSize = 11.sp, color = OutbackAmber)

        FilterChip(
          selected = selectedStation == null,
          onClick = { selectedStation = null },
          label = { Text("All Stations", fontSize = 11.sp) },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = OutbackCrimson,
            selectedLabelColor = Cream50,
            containerColor = Charcoal700,
            labelColor = Cream200
          )
        )

        KitchenStation.values().forEach { station ->
          val isSel = selectedStation == station
          FilterChip(
            selected = isSel,
            onClick = { selectedStation = station },
            label = { Text(station.displayName, fontSize = 11.sp) },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = OutbackCrimson,
              selectedLabelColor = Cream50,
              containerColor = Charcoal700,
              labelColor = Cream200
            )
          )
        }
      }
    }

    // Active Tickets List
    val activeTickets = tickets.filter { !it.isDelivered }

    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      if (activeTickets.isEmpty()) {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = Charcoal800)
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Icon(Icons.Default.OutdoorGrill, contentDescription = null, tint = OutbackAmber, modifier = Modifier.size(44.dp))
            Spacer(modifier = Modifier.height(10.dp))
            Text("No active tickets on the line", fontWeight = FontWeight.Bold, color = Cream50)
            Text("Tickets fired from the Kiosk or Server POS appear here instantly.", fontSize = 12.sp, color = Cream200)
          }
        }
      } else {
        activeTickets.forEach { ticket ->
          val filteredItems = if (selectedStation != null) {
            ticket.items.filter { it.station == selectedStation }
          } else {
            ticket.items
          }

          if (filteredItems.isNotEmpty()) {
            Card(
              modifier = Modifier
                .fillMaxWidth()
                .testTag("kds_ticket_${ticket.ticketId}"),
              colors = CardDefaults.cardColors(containerColor = Charcoal800),
              shape = RoundedCornerShape(14.dp),
              border = BorderStroke(2.dp, if (ticket.isExpoReady) OutbackGreen else OutbackAmber)
            ) {
              Column(modifier = Modifier.padding(16.dp)) {
                // Ticket Header
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(ticket.ticketId, fontWeight = FontWeight.Black, fontSize = 17.sp, color = OutbackAmber)
                    Spacer(modifier = Modifier.width(8.dp))
                    Surface(
                      color = Charcoal700,
                      shape = RoundedCornerShape(6.dp)
                    ) {
                      Text(
                        ticket.tableOrPickupRef,
                        fontWeight = FontWeight.Bold,
                        color = Cream50,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                      )
                    }
                  }

                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Schedule, contentDescription = null, tint = Cream200, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(ticket.timeReceived, color = Cream200, fontSize = 12.sp)
                  }
                }

                Divider(modifier = Modifier.padding(vertical = 10.dp), color = Charcoal600)

                // Ticket Items with Cooking Temperatures & Customizations
                filteredItems.forEach { item ->
                  Row(
                    modifier = Modifier
                      .fillMaxWidth()
                      .padding(vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Column(modifier = Modifier.weight(1f)) {
                      Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                          color = if (item.isReady) OutbackGreenDark else Charcoal700,
                          shape = RoundedCornerShape(4.dp)
                        ) {
                          Text(
                            text = "${item.quantity}x",
                            fontWeight = FontWeight.Black,
                            color = Cream50,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                          )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                          text = item.name,
                          fontWeight = FontWeight.Bold,
                          color = if (item.isReady) OutbackGray else Cream50,
                          fontSize = 15.sp
                        )
                      }

                      if (!item.doneness.isNullOrBlank()) {
                        Text(
                          text = "TEMP: ${item.doneness.uppercase()}",
                          color = OutbackCrimsonLight,
                          fontWeight = FontWeight.Black,
                          fontSize = 12.sp,
                          modifier = Modifier.padding(top = 2.dp)
                        )
                      }

                      if (item.modifiersSummary.isNotBlank()) {
                        Text(
                          text = item.modifiersSummary,
                          color = Cream200,
                          fontSize = 11.sp,
                          modifier = Modifier.padding(top = 2.dp)
                        )
                      }

                      if (item.allergyFlags.isNotEmpty()) {
                        Text(
                          text = "⚠️ ALLERGY FLAG: ${item.allergyFlags.joinToString(", ")}",
                          color = OutbackAmber,
                          fontWeight = FontWeight.Bold,
                          fontSize = 11.sp,
                          modifier = Modifier.padding(top = 2.dp)
                        )
                      }
                    }

                    // Done Toggle Button
                    IconButton(
                      onClick = { onToggleItemReady(ticket.ticketId, item.itemId) },
                      modifier = Modifier.size(44.dp)
                    ) {
                      Icon(
                        imageVector = if (item.isReady) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                        contentDescription = "Toggle Item Ready",
                        tint = if (item.isReady) OutbackGreen else Cream200,
                        modifier = Modifier.size(28.dp)
                      )
                    }
                  }
                }

                Spacer(modifier = Modifier.height(10.dp))

                if (!ticket.isExpoReady) {
                  Button(
                    onClick = { onMarkTicketExpoReady(ticket.ticketId) },
                    colors = ButtonDefaults.buttonColors(containerColor = OutbackGreenDark),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().height(40.dp)
                  ) {
                    Text("BUMP / ALL READY FOR EXPO", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Cream50)
                  }
                } else {
                  Surface(
                    color = OutbackGreen.copy(alpha = 0.2f),
                    border = BorderStroke(1.dp, OutbackGreen),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth()
                  ) {
                    Text(
                      text = "READY AT EXPO PASS · AWAITING RUNNER",
                      color = OutbackGreen,
                      fontWeight = FontWeight.Bold,
                      fontSize = 12.sp,
                      modifier = Modifier.padding(8.dp)
                    )
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
