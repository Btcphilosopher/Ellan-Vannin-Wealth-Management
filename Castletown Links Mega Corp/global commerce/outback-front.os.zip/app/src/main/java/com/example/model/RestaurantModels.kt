package com.example.model

enum class DiningMode {
  DINE_IN,
  TAKEAWAY
}

enum class ReservationStatus {
  CONFIRMED,
  ARRIVED,
  WAITING,
  READY_TO_SEAT,
  SEATED,
  COMPLETED,
  CANCELLED,
  NO_SHOW
}

data class Reservation(
  val id: String,
  val confirmationCode: String,
  val guestName: String,
  val phone: String,
  val partySize: Int,
  val reservationTime: String,
  val status: ReservationStatus,
  val specialRequests: String? = null,
  val assignedTableId: String? = null,
  val seatingPreference: String = "Booth / Standard"
)

enum class WaitlistStatus {
  WAITING,
  TABLE_BEING_PREPARED,
  READY,
  SEATED,
  CANCELLED
}

data class WaitlistEntry(
  val id: String,
  val queueReference: String, // e.g. "WAITLIST A047"
  val guestName: String,
  val partySize: Int,
  val phone: String = "",
  val status: WaitlistStatus,
  val estimatedWaitRange: String, // e.g. "15–25 mins"
  val checkInTime: String,
  val highChairNeeded: Boolean = false,
  val accessibilityNeeded: Boolean = false,
  val seatingPreference: String = "Any",
  val assignedTableId: String? = null
)

enum class TableStatus {
  AVAILABLE,
  RESERVED,
  OCCUPIED,
  FOOD_IN_PROGRESS,
  DINING,
  BILL_REQUESTED,
  DIRTY,
  CLEANING
}

data class DiningTable(
  val id: String, // e.g. "T01", "B01"
  val name: String,
  val section: String, // "Main Dining", "Outback Booths", "Bar Deck"
  val capacity: Int,
  val status: TableStatus,
  val isAccessible: Boolean = false,
  val isBooth: Boolean = false,
  val currentPartyReference: String? = null,
  val currentGuestName: String? = null,
  val occupiedMinutesAgo: Int = 0
)

enum class MenuCategory(val displayName: String) {
  APPETIZERS("Appetizers"),
  STEAKS("Steaks & Cuts"),
  COMBOS("Steak Combinations"),
  CHICKEN_RIBS("Chicken & Ribs"),
  SEAFOOD("Seafood"),
  BURGERS("Burgers & Sandwiches"),
  SIDES("Steakhouse Sides"),
  DESSERTS("Desserts"),
  DRINKS("Beverages")
}

data class ModifierOption(
  val id: String,
  val name: String,
  val priceCents: Long = 0L // Integer minor units (cents) - no float arithmetic
)

data class ModifierGroup(
  val id: String,
  val title: String,
  val required: Boolean = false,
  val maxSelect: Int = 1,
  val options: List<ModifierOption>
)

data class MenuItem(
  val id: String,
  val category: MenuCategory,
  val name: String,
  val description: String,
  val basePriceCents: Long, // e.g. 2499 = $24.99
  val allergens: List<String> = emptyList(),
  val isAvailable: Boolean = true,
  val calorieCount: Int? = null,
  val modifierGroups: List<ModifierGroup> = emptyList()
)

data class SelectedModifier(
  val groupId: String,
  val groupTitle: String,
  val optionId: String,
  val optionName: String,
  val priceCents: Long
)

data class CartItem(
  val cartItemId: String,
  val menuItem: MenuItem,
  val quantity: Int = 1,
  val steakDoneness: String? = null, // "Rare", "Medium Rare", "Medium", "Medium Well", "Well Done"
  val selectedModifiers: List<SelectedModifier> = emptyList(),
  val specialInstructions: String = ""
) {
  val unitPriceCents: Long
    get() = menuItem.basePriceCents + selectedModifiers.sumOf { it.priceCents }

  val totalPriceCents: Long
    get() = unitPriceCents * quantity
}

enum class OrderStatus {
  RECEIVED,
  ACCEPTED,
  PREPARING,
  READY,
  SERVED,
  COMPLETED,
  CANCELLED
}

enum class PaymentState {
  PENDING,
  AUTHORISED,
  CAPTURED,
  FAILED,
  REFUNDED
}

data class Order(
  val orderId: String, // e.g. "ORD-8421"
  val diningMode: DiningMode,
  val tableId: String?,
  val guestReference: String, // "Table T04" or "Takeaway: Tom A."
  val items: List<CartItem>,
  val subtotalCents: Long,
  val taxCents: Long,
  val totalCents: Long,
  val paymentState: PaymentState,
  val paymentMethod: String = "Contactless EMV Chip",
  val status: OrderStatus,
  val timestamp: String,
  val estimatedPrepTime: String = "15-20 mins"
)

enum class KitchenStation(val displayName: String) {
  GRILL("Grill Station"),
  FRY("Fry & Sides"),
  COLD_PREP("Salad & Cold Prep"),
  EXPO("Expeditor Station")
}

data class KitchenTicketItem(
  val itemId: String,
  val name: String,
  val quantity: Int,
  val doneness: String?,
  val station: KitchenStation,
  val modifiersSummary: String,
  val allergyFlags: List<String>,
  val isReady: Boolean = false
)

data class KitchenTicket(
  val ticketId: String,
  val orderId: String,
  val tableOrPickupRef: String,
  val diningMode: DiningMode,
  val timeReceived: String,
  val items: List<KitchenTicketItem>,
  val isExpoReady: Boolean = false,
  val isDelivered: Boolean = false
)

data class AssistanceRequest(
  val id: String,
  val tableId: String,
  val reason: String,
  val timestamp: String,
  val isResolved: Boolean = false
)
