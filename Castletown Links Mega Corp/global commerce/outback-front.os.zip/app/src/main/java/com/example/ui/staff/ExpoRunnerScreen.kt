package com.example.ui.staff

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.KitchenTicket
import com.example.ui.theme.*

@Composable
fun ExpoRunnerScreen(
  tickets: List<KitchenTicket>,
  onDeliverOrder: (ticketId: String) -> Unit
) {
  val expoTickets = tickets.filter { !it.isDelivered }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Charcoal900)
      .verticalScroll(rememberScrollState())
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    Text(
      text = "EXPEDITOR & FOOD RUNNER PASS",
      fontWeight = FontWeight.Black,
      fontSize = 18.sp,
      color = OutbackAmber,
      letterSpacing = 1.sp
    )
    Text(
      text = "Ensure all items & sides match tickets before running to tables.",
      fontSize = 13.sp,
      color = Cream200
    )

    if (expoTickets.isEmpty()) {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Charcoal800)
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(32.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Icon(Icons.Default.DeliveryDining, contentDescription = null, tint = OutbackAmber, modifier = Modifier.size(48.dp))
          Spacer(modifier = Modifier.height(10.dp))
          Text("All orders delivered to guests", fontWeight = FontWeight.Bold, color = Cream50)
          Text("Tickets ready from the grill/fry stations will appear here.", fontSize = 12.sp, color = Cream200)
        }
      }
    } else {
      expoTickets.forEach { ticket ->
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .testTag("expo_ticket_${ticket.ticketId}"),
          colors = CardDefaults.cardColors(containerColor = Charcoal800),
          shape = RoundedCornerShape(14.dp),
          border = BorderStroke(2.dp, if (ticket.isExpoReady) OutbackGreen else OutbackAmber)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(
                  text = "DESTINATION: ${ticket.tableOrPickupRef}",
                  fontWeight = FontWeight.Black,
                  fontSize = 17.sp,
                  color = Cream50
                )
                Text(
                  text = "Ticket: ${ticket.ticketId} · Order: ${ticket.orderId}",
                  fontSize = 12.sp,
                  color = OutbackAmber
                )
              }

              Surface(
                color = if (ticket.isExpoReady) OutbackGreenDark else Charcoal700,
                shape = RoundedCornerShape(6.dp)
              ) {
                Text(
                  text = if (ticket.isExpoReady) "READY FOR RUNNER" else "IN COOKING",
                  color = Cream50,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
              }
            }

            Spacer(modifier = Modifier.height(12.dp))

            ticket.items.forEach { itm ->
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(vertical = 3.dp),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text(
                  text = "• ${itm.quantity}x ${itm.name}" + if (!itm.doneness.isNullOrBlank()) " [${itm.doneness}]" else "",
                  color = Cream100,
                  fontSize = 13.sp
                )
                if (itm.isReady) {
                  Text("✓ Ready", color = OutbackGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                } else {
                  Text("Cooking", color = OutbackAmber, fontSize = 11.sp)
                }
              }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
              onClick = { onDeliverOrder(ticket.ticketId) },
              modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("mark_delivered_button_${ticket.ticketId}"),
              colors = ButtonDefaults.buttonColors(containerColor = OutbackCrimson),
              shape = RoundedCornerShape(10.dp)
            ) {
              Icon(Icons.Default.DirectionsRun, contentDescription = null, tint = Cream50)
              Spacer(modifier = Modifier.width(8.dp))
              Text("RUN / DELIVER TO GUEST", fontWeight = FontWeight.Bold, color = Cream50)
            }
          }
        }
      }
    }
  }
}
