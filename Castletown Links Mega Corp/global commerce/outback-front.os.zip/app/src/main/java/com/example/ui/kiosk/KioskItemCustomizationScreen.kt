package com.example.ui.kiosk

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.MenuCategory
import com.example.model.MenuItem
import com.example.model.ModifierOption
import com.example.model.SelectedModifier
import com.example.ui.components.formatCents
import com.example.ui.theme.*

@Composable
fun KioskItemCustomizationScreen(
  item: MenuItem,
  onAddToCart: (
    item: MenuItem,
    quantity: Int,
    doneness: String?,
    selectedModifiers: List<SelectedModifier>,
    specialNotes: String
  ) -> Unit,
  onCancel: () -> Unit
) {
  var quantity by remember { mutableStateOf(1) }
  var doneness by remember {
    mutableStateOf(if (item.category == MenuCategory.STEAKS || item.category == MenuCategory.COMBOS) "Medium Rare" else null)
  }
  var specialInstructions by remember { mutableStateOf("") }

  // Map of groupId -> selected option
  val selectedModifiersMap = remember {
    mutableStateMapOf<String, ModifierOption>().apply {
      // Pre-select defaults for required groups
      item.modifierGroups.forEach { group ->
        if (group.required && group.options.isNotEmpty()) {
          put(group.id, group.options.first())
        }
      }
    }
  }

  val isSteak = item.category == MenuCategory.STEAKS || item.category == MenuCategory.COMBOS
  val donenessOptions = listOf("Rare", "Medium Rare", "Medium", "Medium Well", "Well Done")

  // Calculate live total price
  val basePrice = item.basePriceCents
  val modifiersExtra = selectedModifiersMap.values.sumOf { it.priceCents }
  val unitPrice = basePrice + modifiersExtra
  val totalPrice = unitPrice * quantity

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Charcoal900)
  ) {
    Column(
      modifier = Modifier
        .weight(1f)
        .verticalScroll(rememberScrollState())
        .padding(20.dp)
    ) {
      // Item Title & Description Header
      Text(
        text = item.name,
        fontSize = 22.sp,
        fontWeight = FontWeight.Black,
        color = Cream50
      )
      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = item.description,
        fontSize = 14.sp,
        color = Cream200,
        lineHeight = 20.sp
      )

      if (item.allergens.isNotEmpty()) {
        Spacer(modifier = Modifier.height(10.dp))
        Surface(
          color = Charcoal800,
          shape = RoundedCornerShape(8.dp),
          border = BorderStroke(1.dp, OutbackAmber.copy(alpha = 0.5f))
        ) {
          Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(Icons.Default.WarningAmber, contentDescription = null, tint = OutbackAmber, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              "Contains: ${item.allergens.joinToString(", ")}. Kitchen allergy protocols will be flagged.",
              fontSize = 11.sp,
              color = Cream100
            )
          }
        }
      }

      // Steak Doneness Temperature Picker (Crucial Steakhouse requirement)
      if (isSteak) {
        Spacer(modifier = Modifier.height(20.dp))
        Text(
          text = "STEAK DONENESS / COOKING TEMPERATURE *",
          fontSize = 13.sp,
          fontWeight = FontWeight.Bold,
          color = OutbackAmber,
          letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(8.dp))

        donenessOptions.forEach { temp ->
          val isSelected = doneness == temp
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 4.dp),
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(
              containerColor = if (isSelected) Charcoal700 else Charcoal800
            ),
            border = BorderStroke(1.5.dp, if (isSelected) OutbackCrimson else Charcoal600),
            onClick = { doneness = temp }
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(
                  selected = isSelected,
                  onClick = { doneness = temp },
                  colors = RadioButtonDefaults.colors(selectedColor = OutbackCrimson)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                  Text(text = temp, fontWeight = FontWeight.Bold, color = Cream50, fontSize = 15.sp)
                  Text(
                    text = when (temp) {
                      "Rare" -> "Cool red center, soft and juicy"
                      "Medium Rare" -> "Warm red center, optimal beef tenderness"
                      "Medium" -> "Warm pink center, juicy"
                      "Medium Well" -> "Slight hint of pink in center"
                      else -> "Cooked throughout, no pink"
                    },
                    fontSize = 12.sp,
                    color = Cream200
                  )
                }
              }
            }
          }
        }
      }

      // Configurable Modifier Groups (Sides, Sauces, Extras)
      item.modifierGroups.forEach { group ->
        Spacer(modifier = Modifier.height(20.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = group.title.uppercase(),
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = OutbackAmber,
            letterSpacing = 1.sp
          )
          if (group.required) {
            Text("Required", fontSize = 11.sp, color = OutbackCrimsonLight, fontWeight = FontWeight.Bold)
          }
        }
        Spacer(modifier = Modifier.height(8.dp))

        group.options.forEach { opt ->
          val isSelected = selectedModifiersMap[group.id]?.id == opt.id
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 4.dp),
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(
              containerColor = if (isSelected) Charcoal700 else Charcoal800
            ),
            border = BorderStroke(1.dp, if (isSelected) OutbackAmber else Charcoal600),
            onClick = {
              if (isSelected && !group.required) {
                selectedModifiersMap.remove(group.id)
              } else {
                selectedModifiersMap[group.id] = opt
              }
            }
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(
                  selected = isSelected,
                  onClick = { selectedModifiersMap[group.id] = opt },
                  colors = RadioButtonDefaults.colors(selectedColor = OutbackAmber)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = opt.name, color = Cream50, fontSize = 14.sp)
              }

              if (opt.priceCents > 0) {
                Text(
                  text = "+${formatCents(opt.priceCents)}",
                  color = OutbackAmber,
                  fontWeight = FontWeight.Bold,
                  fontSize = 13.sp
                )
              } else {
                Text("Included", color = Cream200, fontSize = 12.sp)
              }
            }
          }
        }
      }

      // Preparation Notes / Special Requests
      Spacer(modifier = Modifier.height(20.dp))
      Text("SPECIAL PREPARATION NOTES", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = OutbackAmber)
      Spacer(modifier = Modifier.height(6.dp))
      OutlinedTextField(
        value = specialInstructions,
        onValueChange = { specialInstructions = it },
        placeholder = { Text("e.g. Extra seasoning on sides, dressing on the side") },
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = OutbackAmber,
          unfocusedBorderColor = Charcoal600,
          focusedContainerColor = Charcoal800,
          unfocusedContainerColor = Charcoal800,
          focusedTextColor = Cream50,
          unfocusedTextColor = Cream50
        ),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
      )

      // Quantity Selector
      Spacer(modifier = Modifier.height(20.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text("Quantity", fontWeight = FontWeight.Bold, color = Cream50, fontSize = 16.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
          IconButton(
            onClick = { if (quantity > 1) quantity-- },
            modifier = Modifier.size(40.dp)
          ) {
            Icon(Icons.Default.RemoveCircleOutline, contentDescription = "Decrease", tint = Cream200)
          }
          Text(
            text = "$quantity",
            fontSize = 18.sp,
            fontWeight = FontWeight.Black,
            color = Cream50,
            modifier = Modifier.padding(horizontal = 12.dp)
          )
          IconButton(
            onClick = { quantity++ },
            modifier = Modifier.size(40.dp)
          ) {
            Icon(Icons.Default.AddCircleOutline, contentDescription = "Increase", tint = OutbackAmber)
          }
        }
      }

      Spacer(modifier = Modifier.height(24.dp))
    }

    // Bottom Sticky Actions Bar
    Surface(
      color = Charcoal800,
      tonalElevation = 6.dp,
      border = BorderStroke(1.dp, Charcoal700),
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        OutlinedButton(
          onClick = onCancel,
          modifier = Modifier
            .weight(1f)
            .height(52.dp),
          colors = ButtonDefaults.outlinedButtonColors(contentColor = Cream200),
          border = BorderStroke(1.dp, Charcoal600),
          shape = RoundedCornerShape(12.dp)
        ) {
          Text("Cancel")
        }

        Button(
          onClick = {
            val selectedMods = selectedModifiersMap.map { (groupId, option) ->
              val groupTitle = item.modifierGroups.find { it.id == groupId }?.title ?: ""
              SelectedModifier(
                groupId = groupId,
                groupTitle = groupTitle,
                optionId = option.id,
                optionName = option.name,
                priceCents = option.priceCents
              )
            }
            onAddToCart(item, quantity, doneness, selectedMods, specialInstructions)
          },
          modifier = Modifier
            .weight(2f)
            .height(52.dp)
            .testTag("add_customized_item_button"),
          colors = ButtonDefaults.buttonColors(containerColor = OutbackCrimson),
          shape = RoundedCornerShape(12.dp)
        ) {
          Text(
            text = "ADD TO ORDER · ${formatCents(totalPrice)}",
            fontWeight = FontWeight.Black,
            fontSize = 15.sp,
            color = Cream50
          )
        }
      }
    }
  }
}
