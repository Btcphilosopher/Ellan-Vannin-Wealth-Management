package com.example.ui.kiosk

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CartItem
import com.example.model.DiningMode
import com.example.ui.components.formatCents
import com.example.ui.theme.*

@Composable
fun KioskCheckoutScreen(
  cartItems: List<CartItem>,
  diningMode: DiningMode,
  assignedTableId: String?,
  onPayNowConfirmed: (guestName: String) -> Unit,
  onCancel: () -> Unit
) {
  var guestName by remember { mutableStateOf(if (diningMode == DiningMode.DINE_IN) "Table ${assignedTableId ?: "T04"}" else "") }
  var selectedTipPercent by remember { mutableStateOf(18) }
  var paymentProcessing by remember { mutableStateOf(false) }

  val subtotal = cartItems.sumOf { it.totalPriceCents }
  val tax = (subtotal * 0.0825).toLong()
  val tipCents = (subtotal * (selectedTipPercent / 100.0)).toLong()
  val finalTotal = subtotal + tax + tipCents

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Charcoal900)
      .verticalScroll(rememberScrollState())
      .padding(20.dp)
  ) {
    Text(
      text = "SECURE PAYMENT & CHECKOUT",
      fontSize = 22.sp,
      fontWeight = FontWeight.Black,
      color = Cream50,
      letterSpacing = 1.sp
    )
    Text(
      text = "Review your bill, add gratuity, and authorize payment on terminal.",
      fontSize = 14.sp,
      color = Cream200,
      modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
    )

    // Guest Identifier
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = Charcoal800),
      border = BorderStroke(1.dp, Charcoal700)
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Text(
          text = if (diningMode == DiningMode.DINE_IN) "Dine-In Table Assignment" else "Guest Name for Pick-Up Call",
          fontWeight = FontWeight.Bold,
          color = OutbackAmber,
          fontSize = 13.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
          value = guestName,
          onValueChange = { guestName = it },
          placeholder = { Text(if (diningMode == DiningMode.DINE_IN) "e.g. Table T04" else "e.g. Sarah Connor") },
          leadingIcon = {
            Icon(if (diningMode == DiningMode.DINE_IN) Icons.Default.TableBar else Icons.Default.Person, contentDescription = null, tint = Cream200)
          },
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = OutbackAmber,
            unfocusedBorderColor = Charcoal600,
            focusedContainerColor = Charcoal700,
            unfocusedContainerColor = Charcoal700,
            focusedTextColor = Cream50,
            unfocusedTextColor = Cream50
          ),
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("checkout_guest_name_input")
        )
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Gratuity / Tip Selection
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = Charcoal800),
      border = BorderStroke(1.dp, Charcoal700)
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("Staff Gratuity (Tip)", fontWeight = FontWeight.Bold, color = Cream50, fontSize = 14.sp)
          Text(formatCents(tipCents), fontWeight = FontWeight.Bold, color = OutbackAmber, fontSize = 15.sp)
        }
        Spacer(modifier = Modifier.height(10.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          listOf(15, 18, 20, 25, 0).forEach { percent ->
            val isSelected = selectedTipPercent == percent
            FilledTonalButton(
              onClick = { selectedTipPercent = percent },
              colors = ButtonDefaults.filledTonalButtonColors(
                containerColor = if (isSelected) OutbackAmber else Charcoal700,
                contentColor = if (isSelected) Charcoal900 else Cream200
              ),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.weight(1f).height(42.dp)
            ) {
              Text(if (percent == 0) "No Tip" else "$percent%", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Payment Terminal Card
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = Charcoal800),
      border = BorderStroke(1.5.dp, OutbackCrimson)
    ) {
      Column(modifier = Modifier.padding(20.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text("Integrated Payment Terminal", fontWeight = FontWeight.Bold, color = Cream50, fontSize = 16.sp)
            Text("Contactless NFC / EMV Chip Card", color = Cream200, fontSize = 12.sp)
          }
          Icon(Icons.Default.Contactless, contentDescription = null, tint = OutbackAmber, modifier = Modifier.size(32.dp))
        }

        Spacer(modifier = Modifier.height(16.dp))

        Surface(
          color = Charcoal700,
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Text("Subtotal", color = Cream200, fontSize = 13.sp)
              Text(formatCents(subtotal), color = Cream50, fontSize = 13.sp)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Text("Tax (8.25%)", color = Cream200, fontSize = 13.sp)
              Text(formatCents(tax), color = Cream50, fontSize = 13.sp)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Text("Gratuity ($selectedTipPercent%)", color = Cream200, fontSize = 13.sp)
              Text(formatCents(tipCents), color = Cream50, fontSize = 13.sp)
            }
            Divider(modifier = Modifier.padding(vertical = 8.dp), color = Charcoal600)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Text("TOTAL AUTHORIZED", fontWeight = FontWeight.Black, color = Cream50, fontSize = 15.sp)
              Text(formatCents(finalTotal), fontWeight = FontWeight.Black, color = OutbackAmber, fontSize = 18.sp)
            }
          }
        }

        Spacer(modifier = Modifier.height(20.dp))

        if (paymentProcessing) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
          ) {
            CircularProgressIndicator(color = OutbackAmber, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.width(12.dp))
            Text("Authorizing EMV Chip & Dispatching Tickets...", color = Cream100, fontSize = 13.sp)
          }
        } else {
          Button(
            onClick = {
              paymentProcessing = true
              val confirmedName = if (guestName.isBlank()) "Guest Party" else guestName
              onPayNowConfirmed(confirmedName)
            },
            modifier = Modifier
              .fillMaxWidth()
              .height(54.dp)
              .testTag("kiosk_confirm_pay_button"),
            colors = ButtonDefaults.buttonColors(containerColor = OutbackCrimson),
            shape = RoundedCornerShape(12.dp)
          ) {
            Icon(Icons.Default.Lock, contentDescription = null, tint = Cream50, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "TAP / INSERT CARD · ${formatCents(finalTotal)}",
              fontWeight = FontWeight.Black,
              fontSize = 15.sp,
              color = Cream50
            )
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    OutlinedButton(
      onClick = onCancel,
      modifier = Modifier.fillMaxWidth().height(48.dp),
      colors = ButtonDefaults.outlinedButtonColors(contentColor = Cream200),
      border = BorderStroke(1.dp, Charcoal600)
    ) {
      Text("Back to Cart")
    }
  }
}
