package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val SteakhouseColorScheme = darkColorScheme(
  primary = OutbackCrimson,
  onPrimary = Cream50,
  primaryContainer = OutbackCrimsonDark,
  onPrimaryContainer = Cream100,
  secondary = OutbackAmber,
  onSecondary = Charcoal900,
  secondaryContainer = OutbackAmberDark,
  onSecondaryContainer = Cream50,
  tertiary = OutbackAmberLight,
  onTertiary = Charcoal900,
  background = Charcoal900,
  onBackground = Cream50,
  surface = Charcoal800,
  onSurface = Cream50,
  surfaceVariant = Charcoal700,
  onSurfaceVariant = Cream200,
  outline = Charcoal600,
  outlineVariant = Charcoal700,
  error = OutbackCrimsonLight,
  onError = Cream50
)

@Composable
fun OutbackFrontOSTheme(
  content: @Composable () -> Unit,
) {
  MaterialTheme(
    colorScheme = SteakhouseColorScheme,
    typography = Typography,
    content = content
  )
}
