package com.example.ui.kiosk

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.WaitlistEntry
import com.example.model.WaitlistStatus
import com.example.ui.theme.*

@Composable
fun KioskWaitlistScreen(
  lastCreatedEntry: WaitlistEntry?,
  activeWaitlistEntries: List<WaitlistEntry>,
  onSubmitWaitlist: (
    guestName: String,
    partySize: Int,
    phone: String,
    seatingPref: String,
    highChair: Boolean,
    accessibility: Boolean
  ) -> Unit,
  onOrderAheadClicked: () -> Unit,
  onBackToHome: () -> Unit
) {
  var guestName by remember { mutableStateOf("") }
  var partySize by remember { mutableStateOf(2) }
  var phone by remember { mutableStateOf("") }
  var seatingPref by remember { mutableStateOf("Any Table") }
  var highChair by remember { mutableStateOf(false) }
  var accessibility by remember { mutableStateOf(false) }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Charcoal900)
      .verticalScroll(rememberScrollState())
      .padding(24.dp)
  ) {
    Text(
      text = "JOIN THE WALK-IN WAITLIST",
      fontSize = 22.sp,
      fontWeight = FontWeight.Black,
      color = Cream50,
      letterSpacing = 1.sp
    )
    Text(
      text = "Get in line digitally, receive SMS alerts, and track table readiness.",
      fontSize = 14.sp,
      color = Cream200,
      modifier = Modifier.padding(top = 4.dp, bottom = 20.dp)
    )

    if (lastCreatedEntry != null && lastCreatedEntry.status != WaitlistStatus.CANCELLED) {
      // Success Queue Card
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("waitlist_success_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Charcoal800),
        border = BorderStroke(2.dp, OutbackAmber)
      ) {
        Column(
          modifier = Modifier.padding(24.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Surface(
            color = OutbackAmber.copy(alpha = 0.2f),
            shape = RoundedCornerShape(12.dp)
          ) {
            Text(
              text = lastCreatedEntry.queueReference,
              fontSize = 28.sp,
              fontWeight = FontWeight.Black,
              color = OutbackAmber,
              modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
            )
          }

          Spacer(modifier = Modifier.height(16.dp))
          Text(
            text = "Welcome, ${lastCreatedEntry.guestName}!",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = Cream50
          )
          Text(
            text = "You are in line. Current estimated wait: ${lastCreatedEntry.estimatedWaitRange}",
            fontSize = 14.sp,
            color = Cream200,
            modifier = Modifier.padding(top = 4.dp)
          )

          Spacer(modifier = Modifier.height(20.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text("Party", fontSize = 11.sp, color = Cream200)
              Text("${lastCreatedEntry.partySize} Guests", fontWeight = FontWeight.Bold, color = Cream50)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text("Status", fontSize = 11.sp, color = Cream200)
              Text(lastCreatedEntry.status.name, fontWeight = FontWeight.Bold, color = OutbackAmber)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text("Checked In", fontSize = 11.sp, color = Cream200)
              Text(lastCreatedEntry.checkInTime, fontWeight = FontWeight.Bold, color = Cream50)
            }
          }

          Spacer(modifier = Modifier.height(24.dp))

          Button(
            onClick = onOrderAheadClicked,
            modifier = Modifier
              .fillMaxWidth()
              .height(52.dp)
              .testTag("waitlist_order_ahead_button"),
            colors = ButtonDefaults.buttonColors(containerColor = OutbackCrimson),
            shape = RoundedCornerShape(12.dp)
          ) {
            Icon(Icons.Default.RestaurantMenu, contentDescription = null, tint = Cream50)
            Spacer(modifier = Modifier.width(8.dp))
            Text("ORDER AHEAD WHILE YOU WAIT", fontWeight = FontWeight.Bold, color = Cream50)
          }
        }
      }
    } else {
      // Waitlist Form
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Charcoal800),
        border = BorderStroke(1.dp, Charcoal600)
      ) {
        Column(modifier = Modifier.padding(20.dp)) {
          // Guest Name
          OutlinedTextField(
            value = guestName,
            onValueChange = { guestName = it },
            label = { Text("Guest Name / Party Identifier") },
            placeholder = { Text("e.g. Alex Morgan") },
            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = OutbackAmber) },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = OutbackAmber,
              unfocusedBorderColor = Charcoal600,
              focusedContainerColor = Charcoal700,
              unfocusedContainerColor = Charcoal700,
              focusedTextColor = Cream50,
              unfocusedTextColor = Cream50
            ),
            singleLine = true,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("waitlist_name_input")
          )

          Spacer(modifier = Modifier.height(16.dp))

          // Party Size Selector
          Text("Party Size", fontWeight = FontWeight.Bold, color = Cream100, fontSize = 14.sp)
          Spacer(modifier = Modifier.height(8.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            listOf(1, 2, 3, 4, 5, 6, 8).forEach { size ->
              val isSelected = partySize == size
              FilledTonalButton(
                onClick = { partySize = size },
                colors = ButtonDefaults.filledTonalButtonColors(
                  containerColor = if (isSelected) OutbackCrimson else Charcoal700,
                  contentColor = if (isSelected) Cream50 else Cream200
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                  .weight(1f)
                  .height(44.dp)
                  .testTag("party_size_$size")
              ) {
                Text(text = "$size", fontWeight = FontWeight.Bold, fontSize = 14.sp)
              }
            }
          }

          Spacer(modifier = Modifier.height(16.dp))

          // Phone for notification
          OutlinedTextField(
            value = phone,
            onValueChange = { phone = it },
            label = { Text("Mobile Phone (For Table-Ready SMS)") },
            placeholder = { Text("e.g. (555) 234-5678") },
            leadingIcon = { Icon(Icons.Default.PhoneIphone, contentDescription = null, tint = OutbackAmber) },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = OutbackAmber,
              unfocusedBorderColor = Charcoal600,
              focusedContainerColor = Charcoal700,
              unfocusedContainerColor = Charcoal700,
              focusedTextColor = Cream50,
              unfocusedTextColor = Cream50
            ),
            singleLine = true,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("waitlist_phone_input")
          )

          Spacer(modifier = Modifier.height(16.dp))

          // Seating preferences
          Text("Seating Preference", fontWeight = FontWeight.Bold, color = Cream100, fontSize = 14.sp)
          Spacer(modifier = Modifier.height(6.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            listOf("Any Table", "Booth", "High Top", "Bar Deck").forEach { pref ->
              val isSel = seatingPref == pref
              FilterChip(
                selected = isSel,
                onClick = { seatingPref = pref },
                label = { Text(pref, fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(
                  selectedContainerColor = OutbackAmber,
                  selectedLabelColor = Charcoal900,
                  containerColor = Charcoal700,
                  labelColor = Cream200
                )
              )
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          // Checkboxes: Accessibility & High Chair
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Checkbox(
              checked = highChair,
              onCheckedChange = { highChair = it },
              colors = CheckboxDefaults.colors(checkedColor = OutbackAmber)
            )
            Text("High-chair required", color = Cream100, fontSize = 13.sp)

            Spacer(modifier = Modifier.width(16.dp))

            Checkbox(
              checked = accessibility,
              onCheckedChange = { accessibility = it },
              colors = CheckboxDefaults.colors(checkedColor = OutbackAmber)
            )
            Text("Accessible seating", color = Cream100, fontSize = 13.sp)
          }

          Spacer(modifier = Modifier.height(20.dp))

          // Estimated Wait Banner
          Surface(
            color = Charcoal700,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.padding(14.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(Icons.Default.HourglassTop, contentDescription = null, tint = OutbackAmber)
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text("Estimated Wait", fontSize = 11.sp, color = Cream200)
                Text(
                  text = if (partySize > 4) "25–35 minutes" else "15–25 minutes",
                  fontWeight = FontWeight.Bold,
                  fontSize = 15.sp,
                  color = Cream50
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(20.dp))

          // Confirm button
          Button(
            onClick = {
              val nameToUse = if (guestName.isBlank()) "Guest Party" else guestName
              onSubmitWaitlist(nameToUse, partySize, phone, seatingPref, highChair, accessibility)
            },
            modifier = Modifier
              .fillMaxWidth()
              .height(54.dp)
              .testTag("submit_waitlist_button"),
            colors = ButtonDefaults.buttonColors(containerColor = OutbackCrimson),
            shape = RoundedCornerShape(12.dp)
          ) {
            Icon(Icons.Default.PersonAdd, contentDescription = null, tint = Cream50)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "CONFIRM & JOIN WAITLIST",
              fontSize = 16.sp,
              fontWeight = FontWeight.Black,
              letterSpacing = 1.sp,
              color = Cream50
            )
          }
        }
      }
    }

    // Public Waitlist Board (Privacy safe)
    Spacer(modifier = Modifier.height(24.dp))
    Text(
      text = "DIGITAL QUEUE BOARD (LIVE)",
      fontSize = 16.sp,
      fontWeight = FontWeight.Bold,
      color = OutbackAmber,
      letterSpacing = 1.sp
    )
    Spacer(modifier = Modifier.height(8.dp))

    activeWaitlistEntries.take(5).forEach { entry ->
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = Charcoal800),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, Charcoal700)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = entry.queueReference,
              fontWeight = FontWeight.Bold,
              color = Cream50,
              fontSize = 15.sp
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
              text = "${entry.partySize} Guests",
              color = Cream200,
              fontSize = 13.sp
            )
          }

          Surface(
            color = when (entry.status) {
              WaitlistStatus.TABLE_BEING_PREPARED -> OutbackAmberDark
              WaitlistStatus.READY -> OutbackGreenDark
              WaitlistStatus.SEATED -> OutbackBlue
              else -> Charcoal700
            },
            shape = RoundedCornerShape(6.dp)
          ) {
            Text(
              text = entry.status.name.replace("_", " "),
              color = Cream50,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
            )
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(24.dp))
    OutlinedButton(
      onClick = onBackToHome,
      modifier = Modifier
        .fillMaxWidth()
        .height(48.dp),
      colors = ButtonDefaults.outlinedButtonColors(contentColor = Cream200),
      border = BorderStroke(1.dp, Charcoal600)
    ) {
      Text("Back to Welcome Screen")
    }
  }
}
