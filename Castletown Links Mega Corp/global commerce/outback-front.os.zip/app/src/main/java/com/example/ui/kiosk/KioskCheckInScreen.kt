package com.example.ui.kiosk

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Reservation
import com.example.model.ReservationStatus
import com.example.ui.theme.*

@Composable
fun KioskCheckInScreen(
  lookupCode: String,
  onCodeChanged: (String) -> Unit,
  foundReservation: Reservation?,
  checkInMessage: String?,
  onCheckInNow: (String) -> Unit,
  onBackToHome: () -> Unit
) {
  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Charcoal900)
      .verticalScroll(rememberScrollState())
      .padding(24.dp)
  ) {
    Text(
      text = "RESERVATION CHECK-IN",
      fontSize = 22.sp,
      fontWeight = FontWeight.Black,
      color = Cream50,
      letterSpacing = 1.sp
    )
    Text(
      text = "Enter your confirmation code, phone number, or select a booked party.",
      fontSize = 14.sp,
      color = Cream200,
      modifier = Modifier.padding(top = 4.dp, bottom = 20.dp)
    )

    // Lookup Input Bar
    OutlinedTextField(
      value = lookupCode,
      onValueChange = onCodeChanged,
      label = { Text("Confirmation Code / Phone / Name") },
      placeholder = { Text("e.g. OB-7842 or Vance") },
      leadingIcon = {
        Icon(Icons.Default.Search, contentDescription = null, tint = OutbackAmber)
      },
      trailingIcon = {
        if (lookupCode.isNotEmpty()) {
          IconButton(onClick = { onCodeChanged("") }) {
            Icon(Icons.Default.Close, contentDescription = "Clear", tint = Cream200)
          }
        }
      },
      colors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = OutbackAmber,
        unfocusedBorderColor = Charcoal600,
        focusedContainerColor = Charcoal800,
        unfocusedContainerColor = Charcoal800,
        focusedTextColor = Cream50,
        unfocusedTextColor = Cream50,
        focusedLabelColor = OutbackAmber,
        unfocusedLabelColor = Cream200
      ),
      shape = RoundedCornerShape(12.dp),
      singleLine = true,
      modifier = Modifier
        .fillMaxWidth()
        .testTag("checkin_search_input")
    )

    // Quick demo buttons
    Spacer(modifier = Modifier.height(12.dp))
    Text("Quick test codes:", color = Cream200, fontSize = 12.sp)
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(top = 6.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      listOf("OB-7842", "OB-9931", "OB-1120").forEach { sampleCode ->
        SuggestionChip(
          onClick = { onCodeChanged(sampleCode) },
          label = { Text(sampleCode, fontSize = 12.sp) },
          colors = SuggestionChipDefaults.suggestionChipColors(
            containerColor = Charcoal700,
            labelColor = OutbackAmber
          )
        )
      }
    }

    Spacer(modifier = Modifier.height(24.dp))

    // Matching Result Card
    if (foundReservation != null) {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("reservation_detail_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Charcoal800),
        border = BorderStroke(1.5.dp, OutbackCrimson)
      ) {
        Column(modifier = Modifier.padding(20.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = foundReservation.guestName,
              fontSize = 20.sp,
              fontWeight = FontWeight.Bold,
              color = Cream50
            )
            Surface(
              color = when (foundReservation.status) {
                ReservationStatus.ARRIVED -> OutbackGreenDark
                ReservationStatus.SEATED -> OutbackBlue
                else -> OutbackCrimsonDark
              },
              shape = RoundedCornerShape(8.dp)
            ) {
              Text(
                text = foundReservation.status.name,
                color = Cream50,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column {
              Text("Confirmation Code", fontSize = 11.sp, color = Cream200)
              Text(
                foundReservation.confirmationCode,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = OutbackAmber
              )
            }
            Column {
              Text("Scheduled Time", fontSize = 11.sp, color = Cream200)
              Text(
                foundReservation.reservationTime,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = Cream50
              )
            }
            Column {
              Text("Party Size", fontSize = 11.sp, color = Cream200)
              Text(
                "${foundReservation.partySize} Guests",
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = Cream50
              )
            }
          }

          if (!foundReservation.specialRequests.isNullOrBlank()) {
            Spacer(modifier = Modifier.height(12.dp))
            Surface(
              color = Charcoal700,
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(
                modifier = Modifier.padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(
                  Icons.Default.Info,
                  contentDescription = null,
                  tint = OutbackAmber,
                  modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = "Special Request: ${foundReservation.specialRequests}",
                  fontSize = 12.sp,
                  color = Cream100
                )
              }
            }
          }

          if (foundReservation.assignedTableId != null) {
            Spacer(modifier = Modifier.height(12.dp))
            Surface(
              color = OutbackBlue.copy(alpha = 0.2f),
              border = BorderStroke(1.dp, OutbackBlue),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Text(
                text = "Assigned Table: ${foundReservation.assignedTableId}",
                color = Cream50,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                modifier = Modifier.padding(10.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(20.dp))

          // Big Check In Now Action Button
          val canCheckIn = foundReservation.status == ReservationStatus.CONFIRMED ||
              foundReservation.status == ReservationStatus.WAITING

          Button(
            onClick = { onCheckInNow(foundReservation.id) },
            enabled = canCheckIn,
            modifier = Modifier
              .fillMaxWidth()
              .height(54.dp)
              .testTag("check_in_now_button"),
            colors = ButtonDefaults.buttonColors(
              containerColor = OutbackCrimson,
              disabledContainerColor = Charcoal600
            ),
            shape = RoundedCornerShape(12.dp)
          ) {
            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Cream50)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = if (canCheckIn) "CHECK IN NOW" else "ALREADY CHECKED IN",
              fontSize = 16.sp,
              fontWeight = FontWeight.Black,
              letterSpacing = 1.sp,
              color = Cream50
            )
          }
        }
      }
    } else if (lookupCode.isNotEmpty()) {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Charcoal800)
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(24.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Icon(Icons.Default.SearchOff, contentDescription = null, tint = OutbackAmber, modifier = Modifier.size(36.dp))
          Spacer(modifier = Modifier.height(8.dp))
          Text("No matching reservation found", fontWeight = FontWeight.Bold, color = Cream50)
          Text("Please check the code or speak with our friendly host stand.", fontSize = 12.sp, color = Cream200)
        }
      }
    }

    if (checkInMessage != null) {
      Spacer(modifier = Modifier.height(16.dp))
      Surface(
        color = OutbackGreenDark,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier.padding(16.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Cream50)
          Spacer(modifier = Modifier.width(10.dp))
          Text(checkInMessage, color = Cream50, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        }
      }
    }

    Spacer(modifier = Modifier.height(24.dp))
    OutlinedButton(
      onClick = onBackToHome,
      modifier = Modifier
        .fillMaxWidth()
        .height(48.dp),
      colors = ButtonDefaults.outlinedButtonColors(contentColor = Cream200),
      border = BorderStroke(1.dp, Charcoal600)
    ) {
      Text("Back to Welcome Screen")
    }
  }
}
