package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppRole
import com.example.data.RestaurantRepository
import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

enum class KioskSubScreen {
  WELCOME,
  CHECK_IN,
  WAITLIST,
  MENU,
  ITEM_CUSTOMIZATION,
  CART,
  CHECKOUT,
  ORDER_CONFIRMATION,
  ORDER_STATUS_TRACKER,
  ASSISTANCE_DIALOG
}

class RestaurantViewModel(
  private val repository: RestaurantRepository = RestaurantRepository()
) : ViewModel() {

  val currentRole: StateFlow<AppRole> = repository.currentAppRole
  val tables: StateFlow<List<DiningTable>> = repository.tables
  val reservations: StateFlow<List<Reservation>> = repository.reservations
  val waitlist: StateFlow<List<WaitlistEntry>> = repository.waitlist
  val menu: StateFlow<List<MenuItem>> = repository.menu
  val cartItems: StateFlow<List<CartItem>> = repository.cartItems
  val activeDiningMode: StateFlow<DiningMode> = repository.activeDiningMode
  val assignedTableId: StateFlow<String?> = repository.assignedTableId
  val orders: StateFlow<List<Order>> = repository.orders
  val kitchenTickets: StateFlow<List<KitchenTicket>> = repository.kitchenTickets
  val assistanceRequests: StateFlow<List<AssistanceRequest>> = repository.assistanceRequests
  val lastCompletedOrder: StateFlow<Order?> = repository.lastCompletedOrder

  // Kiosk internal navigation
  private val _kioskScreen = MutableStateFlow(KioskSubScreen.WELCOME)
  val kioskScreen: StateFlow<KioskSubScreen> = _kioskScreen.asStateFlow()

  // Item currently being customized
  private val _selectedMenuItem = MutableStateFlow<MenuItem?>(null)
  val selectedMenuItem: StateFlow<MenuItem?> = _selectedMenuItem.asStateFlow()

  // Selected category in menu
  private val _selectedMenuCategory = MutableStateFlow(MenuCategory.STEAKS)
  val selectedMenuCategory: StateFlow<MenuCategory> = _selectedMenuCategory.asStateFlow()

  // Reservation lookup state
  private val _lookupCode = MutableStateFlow("")
  val lookupCode: StateFlow<String> = _lookupCode.asStateFlow()

  private val _foundReservation = MutableStateFlow<Reservation?>(null)
  val foundReservation: StateFlow<Reservation?> = _foundReservation.asStateFlow()

  private val _checkInMessage = MutableStateFlow<String?>(null)
  val checkInMessage: StateFlow<String?> = _checkInMessage.asStateFlow()

  // Waitlist form state
  private val _lastCreatedWaitlistEntry = MutableStateFlow<WaitlistEntry?>(null)
  val lastCreatedWaitlistEntry: StateFlow<WaitlistEntry?> = _lastCreatedWaitlistEntry.asStateFlow()

  // Server POS active table selected
  private val _serverActiveTableId = MutableStateFlow<String?>("T01")
  val serverActiveTableId: StateFlow<String?> = _serverActiveTableId.asStateFlow()

  // Status feedback toast/snack message
  private val _feedbackMessage = MutableStateFlow<String?>(null)
  val feedbackMessage: StateFlow<String?> = _feedbackMessage.asStateFlow()

  fun navigateToRole(role: AppRole) {
    repository.setAppRole(role)
  }

  fun navigateKioskTo(screen: KioskSubScreen) {
    _kioskScreen.value = screen
    if (screen == KioskSubScreen.WELCOME) {
      _lookupCode.value = ""
      _foundReservation.value = null
      _checkInMessage.value = null
    }
  }

  fun selectCategory(category: MenuCategory) {
    _selectedMenuCategory.value = category
  }

  fun openItemCustomization(item: MenuItem) {
    _selectedMenuItem.value = item
    _kioskScreen.value = KioskSubScreen.ITEM_CUSTOMIZATION
  }

  fun setDiningMode(mode: DiningMode) {
    repository.setDiningMode(mode)
  }

  fun setAssignedTable(tableId: String?) {
    repository.setAssignedTable(tableId)
  }

  fun selectServerTable(tableId: String) {
    _serverActiveTableId.value = tableId
  }

  // --- WAITLIST ---
  fun submitWaitlist(
    guestName: String,
    partySize: Int,
    phone: String,
    seatingPreference: String,
    highChair: Boolean,
    accessibility: Boolean
  ) {
    viewModelScope.launch {
      val entry = repository.joinWaitlist(
        guestName = guestName,
        partySize = partySize,
        phone = phone,
        seatingPreference = seatingPreference,
        highChair = highChair,
        accessibility = accessibility
      )
      _lastCreatedWaitlistEntry.value = entry
      _feedbackMessage.value = "Joined waitlist! Queue reference: ${entry.queueReference}"
    }
  }

  // --- RESERVATION ---
  fun onLookupCodeChanged(code: String) {
    _lookupCode.value = code
    _foundReservation.value = repository.lookupReservation(code)
    _checkInMessage.value = null
  }

  fun confirmReservationCheckIn(resId: String) {
    val success = repository.checkInReservation(resId)
    if (success) {
      _foundReservation.value = repository.reservations.value.find { it.id == resId }
      _checkInMessage.value = "Check-in successful! Host notified. Please relax in the waiting lounge."
    } else {
      _checkInMessage.value = "Unable to check in reservation at this time."
    }
  }

  // --- HOST SEATING ---
  fun assignTableToWaitlist(waitlistId: String, tableId: String) {
    repository.assignTableToWaitlist(waitlistId, tableId)
    _feedbackMessage.value = "Table $tableId assigned to waitlist party"
  }

  fun assignTableToReservation(resId: String, tableId: String) {
    repository.assignTableToReservation(resId, tableId)
    _feedbackMessage.value = "Table $tableId assigned to reservation"
  }

  fun updateTableStatus(tableId: String, status: TableStatus) {
    repository.updateTableStatus(tableId, status)
  }

  // --- CART & ORDERING ---
  fun addItemToCart(
    item: MenuItem,
    quantity: Int,
    doneness: String?,
    selectedModifiers: List<SelectedModifier>,
    specialNotes: String
  ) {
    val cartItem = CartItem(
      cartItemId = UUID.randomUUID().toString(),
      menuItem = item,
      quantity = quantity,
      steakDoneness = doneness,
      selectedModifiers = selectedModifiers,
      specialInstructions = specialNotes
    )
    repository.addToCart(cartItem)
    _selectedMenuItem.value = null
    _feedbackMessage.value = "Added ${item.name} to order"
    _kioskScreen.value = KioskSubScreen.MENU
  }

  fun updateCartQty(cartItemId: String, newQty: Int) {
    repository.updateCartItemQuantity(cartItemId, newQty)
  }

  fun removeCartItem(cartItemId: String) {
    repository.removeCartItem(cartItemId)
  }

  fun clearCart() {
    repository.clearCart()
  }

  fun submitOrder(guestName: String = "Guest") {
    viewModelScope.launch {
      val mode = repository.activeDiningMode.value
      val table = if (mode == DiningMode.DINE_IN) repository.assignedTableId.value ?: "T04" else null
      val order = repository.submitOrder(
        diningMode = mode,
        tableId = table,
        guestName = guestName
      )
      _feedbackMessage.value = "Order ${order.orderId} placed & sent to kitchen!"
      _kioskScreen.value = KioskSubScreen.ORDER_CONFIRMATION
    }
  }

  // --- KITCHEN ACTIONS ---
  fun toggleKitchenItemReady(ticketId: String, itemId: String) {
    repository.toggleKitchenItemReady(ticketId, itemId)
  }

  fun markTicketExpoReady(ticketId: String) {
    repository.markTicketExpoReady(ticketId)
  }

  fun deliverTicketOrder(ticketId: String) {
    repository.deliverTicketOrder(ticketId)
    _feedbackMessage.value = "Order delivered to table!"
  }

  // --- ASSISTANCE ---
  fun requestAssistance(tableId: String, reason: String) {
    repository.requestAssistance(tableId, reason)
    _feedbackMessage.value = "Assistance requested. Staff dispatched to $tableId."
  }

  fun resolveAssistance(id: String) {
    repository.resolveAssistance(id)
  }

  fun clearFeedback() {
    _feedbackMessage.value = null
  }
}
