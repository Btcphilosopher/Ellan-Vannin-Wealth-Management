package com.example.ui.staff

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.*

@Composable
fun HostStandScreen(
  reservations: List<Reservation>,
  waitlist: List<WaitlistEntry>,
  tables: List<DiningTable>,
  onAssignWaitlistToTable: (waitlistId: String, tableId: String) -> Unit,
  onAssignReservationToTable: (resId: String, tableId: String) -> Unit,
  onUpdateTableStatus: (tableId: String, status: TableStatus) -> Unit
) {
  var selectedTab by remember { mutableStateOf(0) } // 0 = Waitlist, 1 = Reservations, 2 = Floor Plan
  var partyToSeatWaitlistId by remember { mutableStateOf<String?>(null) }
  var resToSeatId by remember { mutableStateOf<String?>(null) }

  // Modal Dialog to Select an Available Table for Seating
  if (partyToSeatWaitlistId != null || resToSeatId != null) {
    val availableTables = tables.filter { it.status == TableStatus.AVAILABLE }
    AlertDialog(
      onDismissRequest = {
        partyToSeatWaitlistId = null
        resToSeatId = null
      },
      containerColor = Charcoal800,
      title = {
        Text("Assign Table to Party", fontWeight = FontWeight.Bold, color = OutbackAmber)
      },
      text = {
        Column(modifier = Modifier.fillMaxWidth()) {
          Text(
            "Select an available dining table or booth to seat this party:",
            color = Cream200,
            fontSize = 13.sp
          )
          Spacer(modifier = Modifier.height(12.dp))

          if (availableTables.isEmpty()) {
            Text("No available tables at this moment. Please bus or flip a dirty table.", color = OutbackCrimsonLight, fontSize = 13.sp)
          } else {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 280.dp)
                .verticalScroll(rememberScrollState()),
              verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              availableTables.forEach { tbl ->
                Card(
                  modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                      if (partyToSeatWaitlistId != null) {
                        onAssignWaitlistToTable(partyToSeatWaitlistId!!, tbl.id)
                        partyToSeatWaitlistId = null
                      } else if (resToSeatId != null) {
                        onAssignReservationToTable(resToSeatId!!, tbl.id)
                        resToSeatId = null
                      }
                    }
                    .testTag("seat_table_${tbl.id}"),
                  colors = CardDefaults.cardColors(containerColor = Charcoal700),
                  border = BorderStroke(1.dp, OutbackGreen)
                ) {
                  Row(
                    modifier = Modifier
                      .fillMaxWidth()
                      .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Column {
                      Text("${tbl.id} · ${tbl.name}", fontWeight = FontWeight.Bold, color = Cream50, fontSize = 15.sp)
                      Text("${tbl.section} · Seats ${tbl.capacity}", color = Cream200, fontSize = 12.sp)
                    }
                    Icon(Icons.Default.AddCircle, contentDescription = "Seat", tint = OutbackGreen)
                  }
                }
              }
            }
          }
        }
      },
      confirmButton = {
        TextButton(onClick = {
          partyToSeatWaitlistId = null
          resToSeatId = null
        }) {
          Text("Cancel", color = Cream200)
        }
      }
    )
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Charcoal900)
  ) {
    // Host Tabs
    TabRow(
      selectedTabIndex = selectedTab,
      containerColor = Charcoal800,
      contentColor = OutbackAmber,
      divider = { Divider(color = Charcoal700) }
    ) {
      Tab(
        selected = selectedTab == 0,
        onClick = { selectedTab = 0 },
        text = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.People, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Waitlist (${waitlist.count { it.status == WaitlistStatus.WAITING }})", fontWeight = FontWeight.Bold)
          }
        }
      )
      Tab(
        selected = selectedTab == 1,
        onClick = { selectedTab = 1 },
        text = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.BookOnline, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Bookings (${reservations.size})", fontWeight = FontWeight.Bold)
          }
        }
      )
      Tab(
        selected = selectedTab == 2,
        onClick = { selectedTab = 2 },
        text = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.TableRestaurant, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Floor Plan (${tables.size})", fontWeight = FontWeight.Bold)
          }
        }
      )
    }

    when (selectedTab) {
      0 -> {
        // Waitlist Management
        Column(
          modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Text("LIVE WALK-IN GUESTS", fontWeight = FontWeight.Black, fontSize = 16.sp, color = OutbackAmber)

          if (waitlist.isEmpty()) {
            Text("Waitlist is currently empty.", color = Cream200)
          } else {
            waitlist.forEach { entry ->
              Card(
                modifier = Modifier.fillMaxWidth().testTag("host_waitlist_${entry.queueReference.replace(" ", "_")}"),
                colors = CardDefaults.cardColors(containerColor = Charcoal800),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, Charcoal700)
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                      Text(entry.queueReference, fontWeight = FontWeight.Black, color = OutbackAmber, fontSize = 16.sp)
                      Spacer(modifier = Modifier.width(8.dp))
                      Text(entry.guestName, fontWeight = FontWeight.Bold, color = Cream50, fontSize = 15.sp)
                    }
                    Text(
                      text = "${entry.partySize} Guests · In at ${entry.checkInTime} · Pref: ${entry.seatingPreference}",
                      fontSize = 12.sp,
                      color = Cream200,
                      modifier = Modifier.padding(top = 2.dp)
                    )
                    if (entry.highChairNeeded || entry.accessibilityNeeded) {
                      Text(
                        text = "Flags: " + listOfNotNull(
                          if (entry.highChairNeeded) "High Chair" else null,
                          if (entry.accessibilityNeeded) "Accessible" else null
                        ).joinToString(", "),
                        fontSize = 11.sp,
                        color = OutbackAmberLight
                      )
                    }
                  }

                  if (entry.status == WaitlistStatus.SEATED) {
                    Surface(color = OutbackBlue, shape = RoundedCornerShape(6.dp)) {
                      Text("SEATED (${entry.assignedTableId})", color = Cream50, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(8.dp, 4.dp))
                    }
                  } else {
                    Button(
                      onClick = { partyToSeatWaitlistId = entry.id },
                      colors = ButtonDefaults.buttonColors(containerColor = OutbackGreen),
                      shape = RoundedCornerShape(8.dp),
                      modifier = Modifier.height(38.dp).testTag("host_assign_table_button")
                    ) {
                      Text("ASSIGN TABLE", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Cream50)
                    }
                  }
                }
              }
            }
          }
        }
      }

      1 -> {
        // Reservations Management
        Column(
          modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Text("TODAY'S RESERVATIONS", fontWeight = FontWeight.Black, fontSize = 16.sp, color = OutbackAmber)

          reservations.forEach { res ->
            Card(
              modifier = Modifier.fillMaxWidth().testTag("host_res_${res.confirmationCode}"),
              colors = CardDefaults.cardColors(containerColor = Charcoal800),
              shape = RoundedCornerShape(12.dp),
              border = BorderStroke(1.dp, Charcoal700)
            ) {
              Column(modifier = Modifier.padding(16.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(res.confirmationCode, fontWeight = FontWeight.Black, color = OutbackAmber, fontSize = 15.sp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(res.guestName, fontWeight = FontWeight.Bold, color = Cream50, fontSize = 15.sp)
                  }
                  Surface(
                    color = when (res.status) {
                      ReservationStatus.ARRIVED -> OutbackGreenDark
                      ReservationStatus.SEATED -> OutbackBlue
                      else -> Charcoal700
                    },
                    shape = RoundedCornerShape(6.dp)
                  ) {
                    Text(
                      res.status.name,
                      color = Cream50,
                      fontSize = 11.sp,
                      fontWeight = FontWeight.Bold,
                      modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                  }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = "${res.partySize} Guests · Scheduled for ${res.reservationTime} · ${res.phone}",
                  fontSize = 12.sp,
                  color = Cream200
                )

                if (res.status == ReservationStatus.ARRIVED) {
                  Spacer(modifier = Modifier.height(10.dp))
                  Button(
                    onClick = { resToSeatId = res.id },
                    colors = ButtonDefaults.buttonColors(containerColor = OutbackCrimson),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.height(38.dp)
                  ) {
                    Text("SEAT GUEST AT TABLE", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Cream50)
                  }
                }
              }
            }
          }
        }
      }

      2 -> {
        // Interactive Dining Room Floor Plan
        Column(
          modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text("DINING ROOM FLOOR PLAN", fontWeight = FontWeight.Black, fontSize = 16.sp, color = OutbackAmber)
            Text("Tap table to toggle status", fontSize = 11.sp, color = Cream200)
          }

          Spacer(modifier = Modifier.height(12.dp))

          LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 100.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxSize()
          ) {
            items(tables) { table ->
              val statusColor = when (table.status) {
                TableStatus.AVAILABLE -> StatusAvailable
                TableStatus.OCCUPIED, TableStatus.FOOD_IN_PROGRESS, TableStatus.DINING -> StatusOccupied
                TableStatus.RESERVED -> StatusReserved
                TableStatus.DIRTY -> StatusDirty
                TableStatus.CLEANING -> StatusCleaning
                else -> Charcoal600
              }

              Card(
                modifier = Modifier
                  .height(96.dp)
                  .clickable {
                    val nextStatus = when (table.status) {
                      TableStatus.AVAILABLE -> TableStatus.OCCUPIED
                      TableStatus.OCCUPIED -> TableStatus.DIRTY
                      TableStatus.DIRTY -> TableStatus.CLEANING
                      TableStatus.CLEANING -> TableStatus.AVAILABLE
                      else -> TableStatus.AVAILABLE
                    }
                    onUpdateTableStatus(table.id, nextStatus)
                  }
                  .testTag("floor_table_${table.id}"),
                colors = CardDefaults.cardColors(containerColor = Charcoal800),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(2.dp, statusColor)
              ) {
                Column(
                  modifier = Modifier
                    .fillMaxSize()
                    .padding(8.dp),
                  verticalArrangement = Arrangement.SpaceBetween
                ) {
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                  ) {
                    Text(table.id, fontWeight = FontWeight.Black, color = Cream50, fontSize = 14.sp)
                    Text("${table.capacity}p", fontSize = 11.sp, color = Cream200)
                  }

                  Text(
                    text = table.currentGuestName ?: table.section,
                    fontSize = 10.sp,
                    color = Cream100,
                    maxLines = 1
                  )

                  Surface(
                    color = statusColor.copy(alpha = 0.25f),
                    shape = RoundedCornerShape(4.dp)
                  ) {
                    Text(
                      text = table.status.name.take(9),
                      fontSize = 9.sp,
                      fontWeight = FontWeight.Bold,
                      color = statusColor,
                      modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                    )
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
