package com.example.data

import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class RestaurantRepository {

  // Current session kiosk mode
  private val _currentAppRole = MutableStateFlow(AppRole.KIOSK)
  val currentAppRole: StateFlow<AppRole> = _currentAppRole.asStateFlow()

  // Tables
  private val _tables = MutableStateFlow<List<DiningTable>>(emptyList())
  val tables: StateFlow<List<DiningTable>> = _tables.asStateFlow()

  // Reservations
  private val _reservations = MutableStateFlow<List<Reservation>>(emptyList())
  val reservations: StateFlow<List<Reservation>> = _reservations.asStateFlow()

  // Waitlist
  private val _waitlist = MutableStateFlow<List<WaitlistEntry>>(emptyList())
  val waitlist: StateFlow<List<WaitlistEntry>> = _waitlist.asStateFlow()

  // Menu items
  private val _menu = MutableStateFlow<List<MenuItem>>(emptyList())
  val menu: StateFlow<List<MenuItem>> = _menu.asStateFlow()

  // Active Cart
  private val _cartItems = MutableStateFlow<List<CartItem>>(emptyList())
  val cartItems: StateFlow<List<CartItem>> = _cartItems.asStateFlow()

  // Current Kiosk Dining Mode
  private val _activeDiningMode = MutableStateFlow(DiningMode.DINE_IN)
  val activeDiningMode: StateFlow<DiningMode> = _activeDiningMode.asStateFlow()

  // Currently assigned / selected table for Dine-in kiosk order
  private val _assignedTableId = MutableStateFlow<String?>("T04")
  val assignedTableId: StateFlow<String?> = _assignedTableId.asStateFlow()

  // Active Orders
  private val _orders = MutableStateFlow<List<Order>>(emptyList())
  val orders: StateFlow<List<Order>> = _orders.asStateFlow()

  // Kitchen Tickets
  private val _kitchenTickets = MutableStateFlow<List<KitchenTicket>>(emptyList())
  val kitchenTickets: StateFlow<List<KitchenTicket>> = _kitchenTickets.asStateFlow()

  // Guest Assistance Requests
  private val _assistanceRequests = MutableStateFlow<List<AssistanceRequest>>(emptyList())
  val assistanceRequests: StateFlow<List<AssistanceRequest>> = _assistanceRequests.asStateFlow()

  // Last completed order (for confirmation screen)
  private val _lastCompletedOrder = MutableStateFlow<Order?>(null)
  val lastCompletedOrder: StateFlow<Order?> = _lastCompletedOrder.asStateFlow()

  private var waitlistCounter = 48
  private var orderCounter = 101

  init {
    seedDemonstrationRestaurant()
  }

  fun setAppRole(role: AppRole) {
    _currentAppRole.value = role
  }

  fun setDiningMode(mode: DiningMode) {
    _activeDiningMode.value = mode
  }

  fun setAssignedTable(tableId: String?) {
    _assignedTableId.value = tableId
  }

  // --- WAITLIST METHODS ---
  fun joinWaitlist(
    guestName: String,
    partySize: Int,
    phone: String,
    seatingPreference: String,
    highChair: Boolean,
    accessibility: Boolean
  ): WaitlistEntry {
    val refNumber = waitlistCounter++
    val queueRef = "WAITLIST A0$refNumber"
    val waitMinutes = calculateEstimatedWaitMinutes(partySize)
    val waitRange = "${waitMinutes - 5}–${waitMinutes + 5} mins"
    val currentTime = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())

    val entry = WaitlistEntry(
      id = UUID.randomUUID().toString(),
      queueReference = queueRef,
      guestName = guestName,
      partySize = partySize,
      phone = phone,
      status = WaitlistStatus.WAITING,
      estimatedWaitRange = waitRange,
      checkInTime = currentTime,
      highChairNeeded = highChair,
      accessibilityNeeded = accessibility,
      seatingPreference = seatingPreference
    )
    _waitlist.value = listOf(entry) + _waitlist.value
    return entry
  }

  private fun calculateEstimatedWaitMinutes(partySize: Int): Int {
    val occupiedCount = _tables.value.count { it.status == TableStatus.OCCUPIED || it.status == TableStatus.DINING }
    val baseTime = if (occupiedCount > 10) 25 else 15
    return if (partySize > 4) baseTime + 10 else baseTime
  }

  // --- RESERVATION METHODS ---
  fun lookupReservation(query: String): Reservation? {
    val clean = query.trim().uppercase(Locale.getDefault())
    return _reservations.value.find {
      it.confirmationCode.equals(clean, ignoreCase = true) ||
          it.phone.contains(clean) ||
          it.guestName.contains(clean, ignoreCase = true)
    }
  }

  fun checkInReservation(resId: String): Boolean {
    val list = _reservations.value.toMutableList()
    val index = list.indexOfFirst { it.id == resId }
    if (index != -1) {
      val r = list[index]
      if (r.status == ReservationStatus.CONFIRMED || r.status == ReservationStatus.WAITING) {
        list[index] = r.copy(status = ReservationStatus.ARRIVED)
        _reservations.value = list
        return true
      }
    }
    return false
  }

  // --- HOST SEATING & TABLE OPERATIONS ---
  fun assignTableToWaitlist(waitlistId: String, tableId: String) {
    val wList = _waitlist.value.toMutableList()
    val wIdx = wList.indexOfFirst { it.id == waitlistId }
    val tList = _tables.value.toMutableList()
    val tIdx = tList.indexOfFirst { it.id == tableId }

    if (wIdx != -1 && tIdx != -1) {
      val entry = wList[wIdx]
      val table = tList[tIdx]

      wList[wIdx] = entry.copy(
        status = WaitlistStatus.SEATED,
        assignedTableId = tableId
      )
      tList[tIdx] = table.copy(
        status = TableStatus.OCCUPIED,
        currentPartyReference = entry.queueReference,
        currentGuestName = entry.guestName,
        occupiedMinutesAgo = 1
      )
      _waitlist.value = wList
      _tables.value = tList
      _assignedTableId.value = tableId
    }
  }

  fun assignTableToReservation(resId: String, tableId: String) {
    val rList = _reservations.value.toMutableList()
    val rIdx = rList.indexOfFirst { it.id == resId }
    val tList = _tables.value.toMutableList()
    val tIdx = tList.indexOfFirst { it.id == tableId }

    if (rIdx != -1 && tIdx != -1) {
      val res = rList[rIdx]
      val table = tList[tIdx]

      rList[rIdx] = res.copy(
        status = ReservationStatus.SEATED,
        assignedTableId = tableId
      )
      tList[tIdx] = table.copy(
        status = TableStatus.OCCUPIED,
        currentPartyReference = res.confirmationCode,
        currentGuestName = res.guestName,
        occupiedMinutesAgo = 1
      )
      _reservations.value = rList
      _tables.value = tList
      _assignedTableId.value = tableId
    }
  }

  fun updateTableStatus(tableId: String, newStatus: TableStatus) {
    val list = _tables.value.toMutableList()
    val idx = list.indexOfFirst { it.id == tableId }
    if (idx != -1) {
      val t = list[idx]
      list[idx] = t.copy(
        status = newStatus,
        currentPartyReference = if (newStatus == TableStatus.AVAILABLE || newStatus == TableStatus.CLEANING) null else t.currentPartyReference,
        currentGuestName = if (newStatus == TableStatus.AVAILABLE || newStatus == TableStatus.CLEANING) null else t.currentGuestName
      )
      _tables.value = list
    }
  }

  // --- CART OPERATIONS ---
  fun addToCart(item: CartItem) {
    val current = _cartItems.value.toMutableList()
    val existingIndex = current.indexOfFirst {
      it.menuItem.id == item.menuItem.id &&
          it.steakDoneness == item.steakDoneness &&
          it.selectedModifiers == item.selectedModifiers &&
          it.specialInstructions == item.specialInstructions
    }
    if (existingIndex != -1) {
      val old = current[existingIndex]
      current[existingIndex] = old.copy(quantity = old.quantity + item.quantity)
    } else {
      current.add(item)
    }
    _cartItems.value = current
  }

  fun updateCartItemQuantity(cartItemId: String, newQty: Int) {
    if (newQty <= 0) {
      removeCartItem(cartItemId)
    } else {
      _cartItems.value = _cartItems.value.map {
        if (it.cartItemId == cartItemId) it.copy(quantity = newQty) else it
      }
    }
  }

  fun removeCartItem(cartItemId: String) {
    _cartItems.value = _cartItems.value.filter { it.cartItemId != cartItemId }
  }

  fun clearCart() {
    _cartItems.value = emptyList()
  }

  // --- ORDER SUBMISSION & PAYMENT ---
  fun submitOrder(
    diningMode: DiningMode,
    tableId: String?,
    guestName: String,
    paymentMethod: String = "Contactless EMV Chip"
  ): Order {
    val items = _cartItems.value
    require(items.isNotEmpty()) { "Cart is empty" }

    val subtotal = items.sumOf { it.totalPriceCents }
    val tax = (subtotal * 0.0825).toLong() // 8.25% state & local tax
    val total = subtotal + tax

    val orderId = "ORD-${orderCounter++}"
    val currentTime = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
    val guestRef = if (diningMode == DiningMode.DINE_IN) "Table ${tableId ?: "T04"}" else "Takeaway: $guestName"

    val order = Order(
      orderId = orderId,
      diningMode = diningMode,
      tableId = tableId,
      guestReference = guestRef,
      items = items,
      subtotalCents = subtotal,
      taxCents = tax,
      totalCents = total,
      paymentState = PaymentState.CAPTURED,
      paymentMethod = paymentMethod,
      status = OrderStatus.ACCEPTED,
      timestamp = currentTime,
      estimatedPrepTime = "15-20 mins"
    )

    // Route order items to kitchen ticket
    val ticketItems = items.map { cartItem ->
      val station = when (cartItem.menuItem.category) {
        MenuCategory.STEAKS, MenuCategory.COMBOS, MenuCategory.CHICKEN_RIBS -> KitchenStation.GRILL
        MenuCategory.SIDES, MenuCategory.APPETIZERS -> KitchenStation.FRY
        MenuCategory.BURGERS -> KitchenStation.GRILL
        else -> KitchenStation.COLD_PREP
      }

      val modDesc = buildString {
        if (!cartItem.steakDoneness.isNullOrBlank()) append("Temp: ${cartItem.steakDoneness}. ")
        if (cartItem.selectedModifiers.isNotEmpty()) {
          append(cartItem.selectedModifiers.joinToString(", ") { "${it.groupTitle}: ${it.optionName}" })
        }
        if (cartItem.specialInstructions.isNotBlank()) {
          append(" | Note: ${cartItem.specialInstructions}")
        }
      }

      KitchenTicketItem(
        itemId = UUID.randomUUID().toString(),
        name = cartItem.menuItem.name,
        quantity = cartItem.quantity,
        doneness = cartItem.steakDoneness,
        station = station,
        modifiersSummary = modDesc,
        allergyFlags = cartItem.menuItem.allergens,
        isReady = false
      )
    }

    val ticket = KitchenTicket(
      ticketId = "TKT-${UUID.randomUUID().toString().take(6).uppercase()}",
      orderId = orderId,
      tableOrPickupRef = guestRef,
      diningMode = diningMode,
      timeReceived = currentTime,
      items = ticketItems
    )

    // Update table status if dine in
    if (diningMode == DiningMode.DINE_IN && tableId != null) {
      updateTableStatus(tableId, TableStatus.FOOD_IN_PROGRESS)
    }

    _orders.value = listOf(order) + _orders.value
    _kitchenTickets.value = listOf(ticket) + _kitchenTickets.value
    _lastCompletedOrder.value = order
    clearCart()

    return order
  }

  // --- KITCHEN & EXPO METHODS ---
  fun toggleKitchenItemReady(ticketId: String, itemId: String) {
    _kitchenTickets.value = _kitchenTickets.value.map { ticket ->
      if (ticket.ticketId == ticketId) {
        val updatedItems = ticket.items.map { item ->
          if (item.itemId == itemId) item.copy(isReady = !item.isReady) else item
        }
        val allReady = updatedItems.all { it.isReady }
        ticket.copy(items = updatedItems, isExpoReady = allReady)
      } else ticket
    }
  }

  fun markTicketExpoReady(ticketId: String) {
    _kitchenTickets.value = _kitchenTickets.value.map { ticket ->
      if (ticket.ticketId == ticketId) {
        val itemsReady = ticket.items.map { it.copy(isReady = true) }
        ticket.copy(items = itemsReady, isExpoReady = true)
      } else ticket
    }
  }

  fun deliverTicketOrder(ticketId: String) {
    val ticket = _kitchenTickets.value.find { it.ticketId == ticketId } ?: return
    _kitchenTickets.value = _kitchenTickets.value.map {
      if (it.ticketId == ticketId) it.copy(isDelivered = true) else it
    }
    // Update order status to SERVED
    _orders.value = _orders.value.map {
      if (it.orderId == ticket.orderId) it.copy(status = OrderStatus.SERVED) else it
    }
  }

  // --- ASSISTANCE REQUESTS ---
  fun requestAssistance(tableId: String, reason: String) {
    val req = AssistanceRequest(
      id = UUID.randomUUID().toString(),
      tableId = tableId,
      reason = reason,
      timestamp = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
    )
    _assistanceRequests.value = listOf(req) + _assistanceRequests.value
  }

  fun resolveAssistance(id: String) {
    _assistanceRequests.value = _assistanceRequests.value.map {
      if (it.id == id) it.copy(isResolved = true) else it
    }
  }

  // --- SEED DEMO RESTAURANT ---
  private fun seedDemonstrationRestaurant() {
    // 1. Tables (28 tables across 3 zones)
    val demoTables = mutableListOf<DiningTable>()
    for (i in 1..12) {
      val cap = if (i % 3 == 0) 6 else 4
      val stat = when (i) {
        1 -> TableStatus.OCCUPIED
        2 -> TableStatus.FOOD_IN_PROGRESS
        3 -> TableStatus.DINING
        4 -> TableStatus.AVAILABLE // T04 is available default!
        5 -> TableStatus.DIRTY
        6 -> TableStatus.RESERVED
        else -> TableStatus.AVAILABLE
      }
      demoTables.add(
        DiningTable(
          id = String.format("T%02d", i),
          name = "Table $i",
          section = "Main Dining",
          capacity = cap,
          status = stat,
          isAccessible = (i == 1 || i == 4),
          isBooth = false,
          currentPartyReference = if (stat != TableStatus.AVAILABLE && stat != TableStatus.DIRTY) "Party #$i" else null,
          currentGuestName = if (stat == TableStatus.OCCUPIED) "Miller Family" else null,
          occupiedMinutesAgo = if (stat != TableStatus.AVAILABLE) i * 8 else 0
        )
      )
    }

    for (b in 1..8) {
      val stat = if (b == 2) TableStatus.OCCUPIED else TableStatus.AVAILABLE
      demoTables.add(
        DiningTable(
          id = String.format("B%02d", b),
          name = "Booth $b",
          section = "Outback Booths",
          capacity = 4,
          status = stat,
          isAccessible = false,
          isBooth = true,
          currentPartyReference = if (stat == TableStatus.OCCUPIED) "Booth Party" else null,
          currentGuestName = if (stat == TableStatus.OCCUPIED) "Sarah Jenkins" else null
        )
      )
    }

    for (d in 1..8) {
      demoTables.add(
        DiningTable(
          id = String.format("D%02d", d),
          name = "Deck $d",
          section = "Bar & Patio",
          capacity = 2,
          status = TableStatus.AVAILABLE,
          isAccessible = true,
          isBooth = false
        )
      )
    }
    _tables.value = demoTables

    // 2. Reservations
    _reservations.value = listOf(
      Reservation(
        id = "RES-001",
        confirmationCode = "OB-7842",
        guestName = "Marcus Vance",
        phone = "(555) 234-5678",
        partySize = 4,
        reservationTime = "6:30 PM",
        status = ReservationStatus.CONFIRMED,
        specialRequests = "High chair needed, booth preferred",
        seatingPreference = "Booth"
      ),
      Reservation(
        id = "RES-002",
        confirmationCode = "OB-9931",
        guestName = "Jessica Taylor",
        phone = "(555) 987-6543",
        partySize = 2,
        reservationTime = "7:00 PM",
        status = ReservationStatus.ARRIVED,
        specialRequests = "Anniversary celebration",
        seatingPreference = "Quiet corner"
      ),
      Reservation(
        id = "RES-003",
        confirmationCode = "OB-1120",
        guestName = "Robert Chen",
        phone = "(555) 432-1098",
        partySize = 6,
        reservationTime = "7:15 PM",
        status = ReservationStatus.CONFIRMED,
        specialRequests = "Accessible table requested",
        seatingPreference = "Accessible"
      )
    )

    // 3. Waitlist
    _waitlist.value = listOf(
      WaitlistEntry(
        id = "WL-001",
        queueReference = "WAITLIST A046",
        guestName = "David Kim",
        partySize = 2,
        phone = "(555) 321-7890",
        status = WaitlistStatus.WAITING,
        estimatedWaitRange = "10–15 mins",
        checkInTime = "6:15 PM"
      ),
      WaitlistEntry(
        id = "WL-002",
        queueReference = "WAITLIST A047",
        guestName = "Elena Gomez",
        partySize = 4,
        phone = "(555) 654-3210",
        status = WaitlistStatus.TABLE_BEING_PREPARED,
        estimatedWaitRange = "5–10 mins",
        checkInTime = "6:20 PM",
        highChairNeeded = true
      )
    )

    // 4. Detailed Steakhouse Menu
    val steakSides = listOf(
      ModifierOption("SD_FRIES", "Aussie Fries", 0),
      ModifierOption("SD_MASHED", "Homestyle Mashed Potatoes", 0),
      ModifierOption("SD_BAKED", "Loaded Baked Potato (+Chives, Bacon)", 150),
      ModifierOption("SD_VEG", "Steamed Fresh Mixed Veggies", 0),
      ModifierOption("SD_SALAD", "House Side Salad w/ Tangy Ranch", 199)
    )
    val steakSauces = listOf(
      ModifierOption("SC_NONE", "Natural Steak Drippings", 0),
      ModifierOption("SC_PEPPER", "Cracked Peppercorn Sauce", 199),
      ModifierOption("SC_MUSHROOM", "Creamy Garlic Herb Mushroom", 249),
      ModifierOption("SC_CABERNET", "Cabernet Wine Butter Jus", 249)
    )
    val steakToppers = listOf(
      ModifierOption("TP_NONE", "No Additional Topper", 0),
      ModifierOption("TP_SHRIMP", "Grilled Garlic Herb Shrimp (4 pcs)", 699),
      ModifierOption("TP_LOBSTER", "Steamed Lobster Tail (4 oz)", 1299),
      ModifierOption("TP_BLUECHEESE", "Melted Blue Cheese Crust", 299)
    )

    val steakModifierGroups = listOf(
      ModifierGroup("SIDE1", "Choose 1st Included Side", required = true, maxSelect = 1, options = steakSides),
      ModifierGroup("SIDE2", "Choose 2nd Included Side", required = true, maxSelect = 1, options = steakSides),
      ModifierGroup("SAUCE", "Signature Sauce Selection", required = false, maxSelect = 1, options = steakSauces),
      ModifierGroup("TOPPER", "Steak Topper Enhancement", required = false, maxSelect = 1, options = steakToppers)
    )

    val burgerSides = listOf(
      ModifierOption("BS_FRIES", "Crisp Aussie Fries", 0),
      ModifierOption("BS_ONION", "Bloomin' Onion Petals", 249),
      ModifierOption("BS_SWEET", "Sweet Potato Fries", 199)
    )
    val burgerExtras = listOf(
      ModifierOption("BX_BACON", "Thick-Cut Applewood Bacon", 199),
      ModifierOption("BX_EGG", "Fried Farm Egg", 149),
      ModifierOption("BX_CHEDDAR", "Extra Sharp White Cheddar", 129)
    )
    val burgerModifierGroups = listOf(
      ModifierGroup("BSIDE", "Choose Your Included Side", required = true, maxSelect = 1, options = burgerSides),
      ModifierGroup("BEXTRAS", "Custom Burger Extras", required = false, maxSelect = 3, options = burgerExtras)
    )

    _menu.value = listOf(
      // Appetizers
      MenuItem(
        id = "APP_01",
        category = MenuCategory.APPETIZERS,
        name = "Bloomin' Onion Classic",
        description = "A colossal Outback onion, carved into tender petals, hand-battered, golden-fried and served with signature spicy bloom dipping sauce.",
        basePriceCents = 1099,
        allergens = listOf("Gluten", "Dairy", "Soy"),
        calorieCount = 1680
      ),
      MenuItem(
        id = "APP_02",
        category = MenuCategory.APPETIZERS,
        name = "Aussie Cheese Fries",
        description = "Crispy potato wedges topped with melted Monterey Jack, mild Cheddar, and chopped applewood smoked bacon. Served with house ranch dressing.",
        basePriceCents = 1249,
        allergens = listOf("Dairy", "Pork"),
        calorieCount = 1320
      ),
      MenuItem(
        id = "APP_03",
        category = MenuCategory.APPETIZERS,
        name = "Grilled Shrimp on the Barbie",
        description = "Seasoned with an authentic blend of Australian bush spices, seared over open flame, served with artisan garlic toast and remoulade.",
        basePriceCents = 1399,
        allergens = listOf("Shellfish", "Gluten"),
        calorieCount = 560
      ),

      // Steaks
      MenuItem(
        id = "STK_01",
        category = MenuCategory.STEAKS,
        name = "Victoria's Filet Mignon (8 oz)",
        description = "The most tender and juicy thick-cut center tenderloin, hand-trimmed and seasoned with our bold Outback herb rub. Served with two freshly made sides.",
        basePriceCents = 3199,
        allergens = listOf(),
        calorieCount = 520,
        modifierGroups = steakModifierGroups
      ),
      MenuItem(
        id = "STK_02",
        category = MenuCategory.STEAKS,
        name = "Outback Center-Cut Sirloin (10 oz)",
        description = "Our classic lean center-cut sirloin, packed with full hearty beef flavor. Seared to perfection on our high-temperature grill with two fresh sides.",
        basePriceCents = 2499,
        allergens = listOf(),
        calorieCount = 680,
        modifierGroups = steakModifierGroups
      ),
      MenuItem(
        id = "STK_03",
        category = MenuCategory.STEAKS,
        name = "Bone-In Ribeye (18 oz)",
        description = "Extra marbled and bone-in for extraordinary succulence and rich savory flavor. Flame-kissed with signature Aussie char and two signature sides.",
        basePriceCents = 3799,
        allergens = listOf(),
        calorieCount = 1140,
        modifierGroups = steakModifierGroups
      ),
      MenuItem(
        id = "STK_04",
        category = MenuCategory.STEAKS,
        name = "Melbourne New York Strip (12 oz)",
        description = "Thick, flavorful New York strip steak with rich marbling throughout. Seared on the grill to lock in robust beef juices. With two sides.",
        basePriceCents = 2899,
        allergens = listOf(),
        calorieCount = 810,
        modifierGroups = steakModifierGroups
      ),

      // Combos
      MenuItem(
        id = "CMB_01",
        category = MenuCategory.COMBOS,
        name = "Sirloin & Grilled Lobster Tail",
        description = "Our 8 oz signature center-cut sirloin paired with a succulent 4 oz cold-water grilled lobster tail with drawn garlic herb butter.",
        basePriceCents = 3699,
        allergens = listOf("Shellfish", "Dairy"),
        calorieCount = 890,
        modifierGroups = steakModifierGroups
      ),
      MenuItem(
        id = "CMB_02",
        category = MenuCategory.COMBOS,
        name = "Filet Mignon & Coconut Shrimp",
        description = "Tender 6 oz filet mignon paired with golden crispy coconut shrimp and sweet creole marmalade dip.",
        basePriceCents = 3399,
        allergens = listOf("Shellfish", "Gluten", "Tree Nut"),
        calorieCount = 920,
        modifierGroups = steakModifierGroups
      ),

      // Chicken & Ribs
      MenuItem(
        id = "CHK_01",
        category = MenuCategory.CHICKEN_RIBS,
        name = "Alice Springs Chicken",
        description = "Plump grilled chicken breast smothered in sweet honey mustard sauce, crispy sautéed mushrooms, bacon strips and Monterey Jack cheese.",
        basePriceCents = 2249,
        allergens = listOf("Dairy", "Pork"),
        calorieCount = 840,
        modifierGroups = listOf(
          ModifierGroup("SIDE1", "Choose 1st Side", required = true, options = steakSides),
          ModifierGroup("SIDE2", "Choose 2nd Side", required = true, options = steakSides)
        )
      ),
      MenuItem(
        id = "RIB_01",
        category = MenuCategory.CHICKEN_RIBS,
        name = "Outback BBQ Baby Back Ribs (Full Rack)",
        description = "Smoked in-house low and slow, brushed with tangy smoky Australian BBQ glaze. Served with crispy fries and creamy coleslaw.",
        basePriceCents = 2799,
        allergens = listOf("Pork"),
        calorieCount = 1420
      ),

      // Seafood
      MenuItem(
        id = "SEA_01",
        category = MenuCategory.SEAFOOD,
        name = "Toowoomba Salmon",
        description = "Grilled North Atlantic salmon fillet topped with sautéed shrimp and button mushrooms tossed in a creamy creole sauce. With steamed veggies.",
        basePriceCents = 2699,
        allergens = listOf("Fish", "Shellfish", "Dairy"),
        calorieCount = 760
      ),

      // Burgers
      MenuItem(
        id = "BGR_01",
        category = MenuCategory.BURGERS,
        name = "The Bloomin' Burger",
        description = "Half-pound Angus beef patty topped with Bloomin' Onion petals, American cheese, crisp lettuce, tomato, pickles and spicy bloom sauce.",
        basePriceCents = 1649,
        allergens = listOf("Gluten", "Dairy", "Egg"),
        calorieCount = 1120,
        modifierGroups = burgerModifierGroups
      ),
      MenuItem(
        id = "BGR_02",
        category = MenuCategory.BURGERS,
        name = "Prime Rib Dip Sandwich",
        description = "Thinly shaved slow-roasted prime rib, grilled onions and melted Swiss cheese on a toasted baguette with hot au jus for dipping.",
        basePriceCents = 1799,
        allergens = listOf("Gluten", "Dairy"),
        calorieCount = 980,
        modifierGroups = burgerModifierGroups
      ),

      // Sides
      MenuItem(
        id = "SD_ALC_01",
        category = MenuCategory.SIDES,
        name = "Steakhouse Mac & Cheese",
        description = "Cavatappi pasta baked in a creamy 4-cheese blend with sharp cheddar crumb crust.",
        basePriceCents = 599,
        allergens = listOf("Dairy", "Gluten")
      ),
      MenuItem(
        id = "SD_ALC_02",
        category = MenuCategory.SIDES,
        name = "Loaded Sweet Potato w/ Honey Butter",
        description = "Baked sweet potato topped with melted brown sugar, toasted pecans and cinnamon honey butter.",
        basePriceCents = 549,
        allergens = listOf("Dairy", "Tree Nut")
      ),

      // Desserts
      MenuItem(
        id = "DES_01",
        category = MenuCategory.DESSERTS,
        name = "Chocolate Thunder from Down Under",
        description = "An extra-rich warm pecan chocolate brownie crowned with rich vanilla bean ice cream, warm chocolate fudge drizzle, whipped cream and chocolate shavings.",
        basePriceCents = 1049,
        allergens = listOf("Dairy", "Tree Nut", "Egg", "Gluten"),
        calorieCount = 1450
      ),
      MenuItem(
        id = "DES_02",
        category = MenuCategory.DESSERTS,
        name = "Sydney's Sinful Salted Caramel Cheesecake",
        description = "New York-style cheesecake swirling with dulce de leche, toasted coconut and warm caramel.",
        basePriceCents = 899,
        allergens = listOf("Dairy", "Egg", "Gluten")
      ),

      // Drinks
      MenuItem(
        id = "DRK_01",
        category = MenuCategory.DRINKS,
        name = "Aussie Strawberry Lemonade",
        description = "Freshly squeezed lemon juice, infused with wild Australian strawberries and pure cane sugar. Free refills.",
        basePriceCents = 429
      ),
      MenuItem(
        id = "DRK_02",
        category = MenuCategory.DRINKS,
        name = "Craft Root Beer & Ice Cream Float",
        description = "Draft style root beer served ice-cold in a frosted mug with a scoop of vanilla bean ice cream.",
        basePriceCents = 549,
        allergens = listOf("Dairy")
      ),
      MenuItem(
        id = "DRK_03",
        category = MenuCategory.DRINKS,
        name = "Fresh Brewed Iced Tea (Sweet / Unsweet)",
        description = "Signature black tea blend brewed continuously throughout service.",
        basePriceCents = 349
      )
    )
  }
}

enum class AppRole(val title: String) {
  KIOSK("Guest Touchscreen"),
  HOST("Host Stand & Tables"),
  SERVER("Server POS & Bills"),
  KITCHEN("Kitchen Display (KDS)"),
  EXPO("Expeditor / Runner"),
  MANAGER("Manager Console")
}
