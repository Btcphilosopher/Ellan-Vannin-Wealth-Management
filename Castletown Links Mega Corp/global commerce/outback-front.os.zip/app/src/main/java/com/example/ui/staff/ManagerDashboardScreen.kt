package com.example.ui.staff

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DiningTable
import com.example.model.Order
import com.example.model.TableStatus
import com.example.model.WaitlistEntry
import com.example.ui.components.formatCents
import com.example.ui.theme.*

@Composable
fun ManagerDashboardScreen(
  tables: List<DiningTable>,
  orders: List<Order>,
  waitlist: List<WaitlistEntry>
) {
  val totalSalesCents = orders.sumOf { it.totalCents }
  val activeGuests = tables.filter { it.status == TableStatus.OCCUPIED || it.status == TableStatus.DINING }.sumOf { it.capacity }
  val occupiedTables = tables.count { it.status == TableStatus.OCCUPIED || it.status == TableStatus.DINING || it.status == TableStatus.FOOD_IN_PROGRESS }
  val availableTables = tables.count { it.status == TableStatus.AVAILABLE }
  val waitlistCount = waitlist.size

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Charcoal900)
      .verticalScroll(rememberScrollState())
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    Text(
      text = "RESTAURANT EXECUTIVE PERFORMANCE",
      fontWeight = FontWeight.Black,
      fontSize = 18.sp,
      color = OutbackAmber,
      letterSpacing = 1.sp
    )
    Text(
      text = "Shift live telemetry, table occupancy, sales revenue and kitchen flow.",
      fontSize = 13.sp,
      color = Cream200
    )

    // Key Metric KPI Cards
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      ManagerKpiCard(
        title = "Shift Gross Sales",
        value = formatCents(totalSalesCents),
        sub = "${orders.size} orders placed",
        color = OutbackAmber,
        modifier = Modifier.weight(1f)
      )
      ManagerKpiCard(
        title = "Active Guests",
        value = "$activeGuests",
        sub = "$occupiedTables / ${tables.size} tables filled",
        color = OutbackCrimsonLight,
        modifier = Modifier.weight(1f)
      )
    }

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      ManagerKpiCard(
        title = "Walk-in Queue",
        value = "$waitlistCount parties",
        sub = "Est. 15–25 mins turnaround",
        color = OutbackBlue,
        modifier = Modifier.weight(1f)
      )
      ManagerKpiCard(
        title = "Available Tables",
        value = "$availableTables",
        sub = "Ready for immediate seating",
        color = OutbackGreen,
        modifier = Modifier.weight(1f)
      )
    }

    // Recent Transactions
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = Charcoal800),
      border = BorderStroke(1.dp, Charcoal700)
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Text("RECENT SHIFT ORDERS & AUDIT TRAIL", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = OutbackAmber)
        Spacer(modifier = Modifier.height(10.dp))

        if (orders.isEmpty()) {
          Text("No orders completed yet in this session.", color = Cream200, fontSize = 12.sp)
        } else {
          orders.forEach { ord ->
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text("${ord.orderId} · ${ord.guestReference}", fontWeight = FontWeight.Bold, color = Cream50, fontSize = 13.sp)
                Text("Paid via ${ord.paymentMethod} at ${ord.timestamp}", color = Cream200, fontSize = 11.sp)
              }
              Text(formatCents(ord.totalCents), fontWeight = FontWeight.Black, color = OutbackAmber, fontSize = 14.sp)
            }
          }
        }
      }
    }
  }
}

@Composable
fun ManagerKpiCard(
  title: String,
  value: String,
  sub: String,
  color: Color,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier,
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = Charcoal800),
    border = BorderStroke(1.dp, color.copy(alpha = 0.6f))
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Text(title, fontSize = 11.sp, color = Cream200, fontWeight = FontWeight.Medium)
      Spacer(modifier = Modifier.height(6.dp))
      Text(value, fontSize = 18.sp, fontWeight = FontWeight.Black, color = color)
      Spacer(modifier = Modifier.height(4.dp))
      Text(sub, fontSize = 10.sp, color = Cream100)
    }
  }
}
