package com.example.ui.staff

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AssistanceRequest
import com.example.model.DiningTable
import com.example.model.MenuItem
import com.example.model.Order
import com.example.ui.components.formatCents
import com.example.ui.theme.*

@Composable
fun ServerPosScreen(
  tables: List<DiningTable>,
  selectedTableId: String?,
  onSelectTable: (String) -> Unit,
  orders: List<Order>,
  menu: List<MenuItem>,
  onQuickAddItemToTable: (tableId: String, item: MenuItem) -> Unit,
  assistanceRequests: List<AssistanceRequest>,
  onResolveAssistance: (String) -> Unit
) {
  val currentTable = tables.find { it.id == selectedTableId }
  val activeTableOrders = orders.filter { it.tableId == selectedTableId }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Charcoal900)
  ) {
    // Top Table Selector Bar
    Surface(
      color = Charcoal800,
      tonalElevation = 2.dp,
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .horizontalScroll(rememberScrollState())
          .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text("SELECT TABLE:", fontWeight = FontWeight.Bold, color = OutbackAmber, fontSize = 11.sp)
        tables.take(12).forEach { tbl ->
          val isSel = tbl.id == selectedTableId
          FilterChip(
            selected = isSel,
            onClick = { onSelectTable(tbl.id) },
            label = { Text("${tbl.id} (${tbl.status.name.take(3)})", fontSize = 11.sp) },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = OutbackCrimson,
              selectedLabelColor = Cream50,
              containerColor = Charcoal700,
              labelColor = Cream200
            ),
            modifier = Modifier.testTag("server_pos_table_${tbl.id}")
          )
        }
      }
    }

    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      // Assistance Requests Alert
      val unresolvedHelp = assistanceRequests.filter { !it.isResolved }
      if (unresolvedHelp.isNotEmpty()) {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = OutbackCrimsonDark),
          border = BorderStroke(1.dp, OutbackAmber)
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = OutbackAmber)
              Spacer(modifier = Modifier.width(8.dp))
              Text("GUEST ASSISTANCE DISPATCH", fontWeight = FontWeight.Bold, color = Cream50, fontSize = 14.sp)
            }
            unresolvedHelp.forEach { req ->
              Spacer(modifier = Modifier.height(8.dp))
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text("Table ${req.tableId}: ${req.reason} (${req.timestamp})", color = Cream100, fontSize = 12.sp)
                Button(
                  onClick = { onResolveAssistance(req.id) },
                  colors = ButtonDefaults.buttonColors(containerColor = Charcoal700),
                  contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                  modifier = Modifier.height(32.dp)
                ) {
                  Text("Resolve", fontSize = 11.sp, color = Cream50)
                }
              }
            }
          }
        }
      }

      // Active Table Overview
      if (currentTable != null) {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = Charcoal800),
          border = BorderStroke(1.dp, Charcoal700)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text("${currentTable.id} · ${currentTable.name}", fontWeight = FontWeight.Black, fontSize = 18.sp, color = Cream50)
                Text("${currentTable.section} · Seats ${currentTable.capacity} Guests", color = Cream200, fontSize = 12.sp)
              }
              Surface(
                color = OutbackCrimson.copy(alpha = 0.3f),
                shape = RoundedCornerShape(6.dp)
              ) {
                Text(
                  currentTable.status.name,
                  fontWeight = FontWeight.Bold,
                  fontSize = 11.sp,
                  color = Cream50,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
              }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text("Current Table Bill & Orders:", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = OutbackAmber)
            if (activeTableOrders.isEmpty()) {
              Text("No active round of orders submitted yet.", color = Cream200, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
            } else {
              activeTableOrders.forEach { ord ->
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Text("Order ${ord.orderId} (${ord.status.name})", fontSize = 13.sp, color = Cream100, fontWeight = FontWeight.Medium)
                  Text(formatCents(ord.totalCents), fontSize = 13.sp, color = Cream50, fontWeight = FontWeight.Bold)
                }
                ord.items.forEach { itm ->
                  Text("  • ${itm.quantity}x ${itm.menuItem.name}", fontSize = 11.sp, color = Cream200)
                }
              }
            }
          }
        }

        // Quick Firing Bar (Server can add rounds of drinks / sides directly)
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = Charcoal800),
          border = BorderStroke(1.dp, Charcoal700)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Text("SERVER QUICK ADD / RE-ORDER ROUNDS", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = OutbackAmber)
            Text("Fire additional drinks or sides directly to kitchen for this table:", fontSize = 12.sp, color = Cream200)

            Spacer(modifier = Modifier.height(12.dp))

            menu.take(6).forEach { itm ->
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(itm.name, color = Cream50, fontSize = 13.sp)
                OutlinedButton(
                  onClick = { onQuickAddItemToTable(currentTable.id, itm) },
                  colors = ButtonDefaults.outlinedButtonColors(contentColor = OutbackAmber),
                  border = BorderStroke(1.dp, OutbackAmber),
                  modifier = Modifier.height(34.dp)
                ) {
                  Text("+ Add (${formatCents(itm.basePriceCents)})", fontSize = 11.sp)
                }
              }
            }
          }
        }
      }
    }
  }
}
