package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Outback FRONT.OS Luxury Outback Steakhouse Palette
val Charcoal900 = Color(0xFF121010) // App deep background
val Charcoal800 = Color(0xFF1C1918) // Surface container / Card background
val Charcoal700 = Color(0xFF262220) // Elevated cards / TopBars
val Charcoal600 = Color(0xFF383230) // Borders, dividers

val Cream50 = Color(0xFFFAF7F2)     // Primary text on dark surfaces
val Cream100 = Color(0xFFF3ECE1)    // Secondary text
val Cream200 = Color(0xFFDFD3C3)    // Muted / tertiary text

val OutbackCrimson = Color(0xFFB32624)      // Primary steakhouse crimson
val OutbackCrimsonLight = Color(0xFFD63B38) // Interactive hover/press crimson
val OutbackCrimsonDark = Color(0xFF8A1715)  // Dark crimson accent

val OutbackAmber = Color(0xFFE8982D)        // Warm amber gold highlight
val OutbackAmberLight = Color(0xFFFFB656)   // Bright amber
val OutbackAmberDark = Color(0xFFBA6F08)    // Deep bronze amber

val OutbackGreen = Color(0xFF2E8B57)        // Success / Ready badge
val OutbackGreenDark = Color(0xFF1E5D3A)
val OutbackBlue = Color(0xFF3874CB)         // Dine-in badge
val OutbackOrange = Color(0xFFD96E14)       // Waitlist badge
val OutbackGray = Color(0xFF827B75)         // Inactive / disabled

// Status colors
val StatusAvailable = Color(0xFF2E8B57)
val StatusOccupied = Color(0xFFB32624)
val StatusReserved = Color(0xFF3874CB)
val StatusDirty = Color(0xFFE8982D)
val StatusCleaning = Color(0xFF8E44AD)
