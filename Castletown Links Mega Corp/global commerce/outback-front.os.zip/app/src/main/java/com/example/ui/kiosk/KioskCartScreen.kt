package com.example.ui.kiosk

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CartItem
import com.example.model.DiningMode
import com.example.ui.components.formatCents
import com.example.ui.theme.*

@Composable
fun KioskCartScreen(
  cartItems: List<CartItem>,
  diningMode: DiningMode,
  assignedTableId: String?,
  onUpdateQty: (cartItemId: String, newQty: Int) -> Unit,
  onRemoveItem: (cartItemId: String) -> Unit,
  onClearCart: () -> Unit,
  onContinueShopping: () -> Unit,
  onProceedToCheckout: () -> Unit
) {
  val subtotal = cartItems.sumOf { it.totalPriceCents }
  val tax = (subtotal * 0.0825).toLong()
  val total = subtotal + tax

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Charcoal900)
  ) {
    // Content
    LazyColumn(
      modifier = Modifier
        .weight(1f)
        .padding(horizontal = 20.dp),
      contentPadding = PaddingValues(top = 20.dp, bottom = 20.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(
              text = "YOUR ORDER CART",
              fontSize = 22.sp,
              fontWeight = FontWeight.Black,
              color = Cream50,
              letterSpacing = 1.sp
            )
            Text(
              text = if (diningMode == DiningMode.DINE_IN) "Dine-In Seating (${assignedTableId ?: "T04"})" else "Takeaway Order",
              fontSize = 13.sp,
              color = OutbackAmber
            )
          }

          if (cartItems.isNotEmpty()) {
            TextButton(onClick = onClearCart) {
              Text("Clear All", color = Cream200, fontSize = 12.sp)
            }
          }
        }
      }

      if (cartItems.isEmpty()) {
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Charcoal800)
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Icon(Icons.Default.RemoveShoppingCart, contentDescription = null, tint = OutbackAmber, modifier = Modifier.size(48.dp))
              Spacer(modifier = Modifier.height(12.dp))
              Text("Your cart is currently empty", fontWeight = FontWeight.Bold, color = Cream50)
              Text("Browse the menu to add steaks, sides and drinks.", fontSize = 12.sp, color = Cream200)
              Spacer(modifier = Modifier.height(16.dp))
              Button(
                onClick = onContinueShopping,
                colors = ButtonDefaults.buttonColors(containerColor = OutbackCrimson)
              ) {
                Text("EXPLORE MENU")
              }
            }
          }
        }
      } else {
        items(cartItems) { cartItem ->
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Charcoal800),
            border = BorderStroke(1.dp, Charcoal700)
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = cartItem.menuItem.name,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = Cream50
                  )
                  if (!cartItem.steakDoneness.isNullOrBlank()) {
                    Text(
                      text = "Doneness: ${cartItem.steakDoneness}",
                      fontSize = 12.sp,
                      color = OutbackAmber,
                      fontWeight = FontWeight.SemiBold
                    )
                  }
                  if (cartItem.selectedModifiers.isNotEmpty()) {
                    cartItem.selectedModifiers.forEach { mod ->
                      Text(
                        text = "• ${mod.groupTitle}: ${mod.optionName}" + if (mod.priceCents > 0) " (+${formatCents(mod.priceCents)})" else "",
                        fontSize = 11.sp,
                        color = Cream200
                      )
                    }
                  }
                  if (cartItem.specialInstructions.isNotBlank()) {
                    Text(
                      text = "Note: ${cartItem.specialInstructions}",
                      fontSize = 11.sp,
                      color = Cream200
                    )
                  }
                }

                Text(
                  text = formatCents(cartItem.totalPriceCents),
                  fontWeight = FontWeight.Black,
                  fontSize = 16.sp,
                  color = Cream50
                )
              }

              Spacer(modifier = Modifier.height(12.dp))

              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                IconButton(
                  onClick = { onRemoveItem(cartItem.cartItemId) },
                  modifier = Modifier.size(36.dp)
                ) {
                  Icon(Icons.Default.DeleteOutline, contentDescription = "Remove", tint = Cream200)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                  IconButton(
                    onClick = { onUpdateQty(cartItem.cartItemId, cartItem.quantity - 1) },
                    modifier = Modifier.size(36.dp)
                  ) {
                    Icon(Icons.Default.Remove, contentDescription = "Minus", tint = Cream50)
                  }
                  Text(
                    text = "${cartItem.quantity}",
                    fontWeight = FontWeight.Bold,
                    color = Cream50,
                    modifier = Modifier.padding(horizontal = 8.dp)
                  )
                  IconButton(
                    onClick = { onUpdateQty(cartItem.cartItemId, cartItem.quantity + 1) },
                    modifier = Modifier.size(36.dp)
                  ) {
                    Icon(Icons.Default.Add, contentDescription = "Plus", tint = OutbackAmber)
                  }
                }
              }
            }
          }
        }

        // Financial Breakdown Card
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Charcoal800),
            border = BorderStroke(1.dp, Charcoal700)
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text("Item Subtotal", color = Cream200, fontSize = 14.sp)
                Text(formatCents(subtotal), color = Cream50, fontSize = 14.sp)
              }
              Spacer(modifier = Modifier.height(6.dp))
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text("Sales Tax (8.25%)", color = Cream200, fontSize = 14.sp)
                Text(formatCents(tax), color = Cream50, fontSize = 14.sp)
              }
              Divider(
                modifier = Modifier.padding(vertical = 10.dp),
                color = Charcoal600
              )
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text("Total Payable", fontWeight = FontWeight.Black, fontSize = 17.sp, color = Cream50)
                Text(
                  formatCents(total),
                  fontWeight = FontWeight.Black,
                  fontSize = 20.sp,
                  color = OutbackAmber
                )
              }
            }
          }
        }
      }
    }

    // Bottom Actions
    if (cartItems.isNotEmpty()) {
      Surface(
        color = Charcoal800,
        tonalElevation = 6.dp,
        border = BorderStroke(1.dp, Charcoal700),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          OutlinedButton(
            onClick = onContinueShopping,
            modifier = Modifier
              .weight(1f)
              .height(52.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Cream200),
            border = BorderStroke(1.dp, Charcoal600),
            shape = RoundedCornerShape(12.dp)
          ) {
            Text("Add More")
          }

          Button(
            onClick = onProceedToCheckout,
            modifier = Modifier
              .weight(2f)
              .height(52.dp)
              .testTag("kiosk_proceed_checkout_button"),
            colors = ButtonDefaults.buttonColors(containerColor = OutbackCrimson),
            shape = RoundedCornerShape(12.dp)
          ) {
            Text("PAY & PLACE ORDER", fontWeight = FontWeight.Bold, color = Cream50)
            Spacer(modifier = Modifier.width(6.dp))
            Icon(Icons.Default.Payment, contentDescription = null, tint = Cream50)
          }
        }
      }
    }
  }
}
