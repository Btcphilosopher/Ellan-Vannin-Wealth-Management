package com.example.ui.kiosk

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Order
import com.example.model.OrderStatus
import com.example.ui.components.formatCents
import com.example.ui.theme.*

@Composable
fun KioskOrderConfirmationScreen(
  order: Order?,
  onTrackOrder: () -> Unit,
  onDone: () -> Unit
) {
  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Charcoal900)
      .verticalScroll(rememberScrollState())
      .padding(24.dp),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    Surface(
      color = OutbackGreenDark,
      shape = RoundedCornerShape(20.dp),
      modifier = Modifier.size(72.dp)
    ) {
      Box(contentAlignment = Alignment.Center) {
        Icon(Icons.Default.Check, contentDescription = null, tint = Cream50, modifier = Modifier.size(44.dp))
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    Text(
      text = "ORDER CONFIRMED & FIRED!",
      fontSize = 24.sp,
      fontWeight = FontWeight.Black,
      color = Cream50,
      letterSpacing = 1.sp
    )

    Text(
      text = "Your order has been routed transactionally to the grill & kitchen stations.",
      fontSize = 14.sp,
      color = Cream200,
      modifier = Modifier.padding(top = 4.dp, bottom = 24.dp)
    )

    if (order != null) {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("order_confirmation_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Charcoal800),
        border = BorderStroke(1.5.dp, OutbackAmber)
      ) {
        Column(modifier = Modifier.padding(20.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text("Order Identifier", fontSize = 11.sp, color = Cream200)
              Text(
                order.orderId,
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                color = OutbackAmber
              )
            }
            Surface(
              color = Charcoal700,
              shape = RoundedCornerShape(8.dp)
            ) {
              Text(
                order.guestReference,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Cream50,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(16.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column {
              Text("Estimated Prep", fontSize = 11.sp, color = Cream200)
              Text(order.estimatedPrepTime, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Cream50)
            }
            Column {
              Text("Payment State", fontSize = 11.sp, color = Cream200)
              Text(order.paymentState.name, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = OutbackGreen)
            }
            Column {
              Text("Total Paid", fontSize = 11.sp, color = Cream200)
              Text(formatCents(order.totalCents), fontSize = 14.sp, fontWeight = FontWeight.Black, color = Cream50)
            }
          }

          Divider(modifier = Modifier.padding(vertical = 14.dp), color = Charcoal600)

          Text("Item Breakdown:", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = OutbackAmber)
          Spacer(modifier = Modifier.height(6.dp))
          order.items.forEach { itm ->
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 3.dp),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(
                text = "${itm.quantity}x ${itm.menuItem.name}" + if (!itm.steakDoneness.isNullOrBlank()) " (${itm.steakDoneness})" else "",
                fontSize = 13.sp,
                color = Cream100
              )
              Text(formatCents(itm.totalPriceCents), fontSize = 13.sp, color = Cream200)
            }
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(28.dp))

    Button(
      onClick = onTrackOrder,
      modifier = Modifier
        .fillMaxWidth()
        .height(52.dp)
        .testTag("track_order_button"),
      colors = ButtonDefaults.buttonColors(containerColor = OutbackCrimson),
      shape = RoundedCornerShape(12.dp)
    ) {
      Icon(Icons.Default.Timeline, contentDescription = null, tint = Cream50)
      Spacer(modifier = Modifier.width(8.dp))
      Text("TRACK KITCHEN PROGRESS", fontWeight = FontWeight.Bold, color = Cream50)
    }

    Spacer(modifier = Modifier.height(12.dp))

    OutlinedButton(
      onClick = onDone,
      modifier = Modifier
        .fillMaxWidth()
        .height(48.dp),
      colors = ButtonDefaults.outlinedButtonColors(contentColor = Cream200),
      border = BorderStroke(1.dp, Charcoal600),
      shape = RoundedCornerShape(12.dp)
    ) {
      Text("Back to Welcome Screen")
    }
  }
}

@Composable
fun KioskOrderStatusTrackerScreen(
  orders: List<Order>,
  onBackToHome: () -> Unit
) {
  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Charcoal900)
      .verticalScroll(rememberScrollState())
      .padding(20.dp)
  ) {
    Text(
      text = "LIVE ORDER TRACKER",
      fontSize = 22.sp,
      fontWeight = FontWeight.Black,
      color = Cream50,
      letterSpacing = 1.sp
    )
    Text(
      text = "Real-time kitchen status, ticket lifecycle and expediting tracking.",
      fontSize = 14.sp,
      color = Cream200,
      modifier = Modifier.padding(top = 4.dp, bottom = 20.dp)
    )

    if (orders.isEmpty()) {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Charcoal800)
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(32.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Icon(Icons.Default.HourglassEmpty, contentDescription = null, tint = OutbackAmber, modifier = Modifier.size(44.dp))
          Spacer(modifier = Modifier.height(8.dp))
          Text("No active orders found", fontWeight = FontWeight.Bold, color = Cream50)
          Text("Orders placed at the kiosk will appear here live.", fontSize = 12.sp, color = Cream200)
        }
      }
    } else {
      orders.forEach { ord ->
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = Charcoal800),
          border = BorderStroke(1.dp, Charcoal700)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(ord.orderId, fontWeight = FontWeight.Black, fontSize = 17.sp, color = OutbackAmber)
                Spacer(modifier = Modifier.width(8.dp))
                Text(ord.guestReference, fontSize = 13.sp, color = Cream50, fontWeight = FontWeight.Bold)
              }
              Surface(
                color = when (ord.status) {
                  OrderStatus.ACCEPTED, OrderStatus.PREPARING -> OutbackAmberDark
                  OrderStatus.READY -> OutbackGreenDark
                  OrderStatus.SERVED -> OutbackBlue
                  else -> Charcoal700
                },
                shape = RoundedCornerShape(6.dp)
              ) {
                Text(
                  ord.status.name,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = Cream50,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                )
              }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Step Progress Line
            Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically
            ) {
              val steps = listOf("Received", "Preparing", "Ready", "Served")
              val currentStepIndex = when (ord.status) {
                OrderStatus.RECEIVED -> 0
                OrderStatus.ACCEPTED, OrderStatus.PREPARING -> 1
                OrderStatus.READY -> 2
                OrderStatus.SERVED, OrderStatus.COMPLETED -> 3
                else -> 0
              }

              steps.forEachIndexed { idx, stp ->
                val isDoneOrCurrent = idx <= currentStepIndex
                Column(
                  modifier = Modifier.weight(1f),
                  horizontalAlignment = Alignment.CenterHorizontally
                ) {
                  Box(
                    modifier = Modifier
                      .size(20.dp)
                      .background(
                        color = if (isDoneOrCurrent) OutbackCrimson else Charcoal600,
                        shape = RoundedCornerShape(10.dp)
                      ),
                    contentAlignment = Alignment.Center
                  ) {
                    if (isDoneOrCurrent) {
                      Icon(Icons.Default.Check, contentDescription = null, tint = Cream50, modifier = Modifier.size(14.dp))
                    }
                  }
                  Text(
                    text = stp,
                    fontSize = 10.sp,
                    color = if (isDoneOrCurrent) Cream50 else Cream200,
                    fontWeight = if (isDoneOrCurrent) FontWeight.Bold else FontWeight.Normal,
                    modifier = Modifier.padding(top = 4.dp)
                  )
                }
              }
            }

            Spacer(modifier = Modifier.height(12.dp))

            ord.items.forEach { itm ->
              Text(
                "• ${itm.quantity}x ${itm.menuItem.name}" + if (!itm.steakDoneness.isNullOrBlank()) " (${itm.steakDoneness})" else "",
                fontSize = 12.sp,
                color = Cream200
              )
            }
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(24.dp))
    OutlinedButton(
      onClick = onBackToHome,
      modifier = Modifier.fillMaxWidth().height(48.dp),
      colors = ButtonDefaults.outlinedButtonColors(contentColor = Cream200),
      border = BorderStroke(1.dp, Charcoal600)
    ) {
      Text("Back to Welcome Screen")
    }
  }
}
