package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.AppRole
import com.example.model.DiningMode
import com.example.model.MenuCategory
import com.example.model.TableStatus
import com.example.ui.components.AppHeader
import com.example.ui.components.StatusFeedbackBanner
import com.example.ui.kiosk.*
import com.example.ui.staff.*
import com.example.ui.theme.Charcoal900
import com.example.ui.theme.OutbackFrontOSTheme
import com.example.viewmodel.KioskSubScreen
import com.example.viewmodel.RestaurantViewModel

class MainActivity : ComponentActivity() {

  private val viewModel: RestaurantViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    setContent {
      OutbackFrontOSTheme {
        val currentRole by viewModel.currentRole.collectAsStateWithLifecycle()
        val kioskScreen by viewModel.kioskScreen.collectAsStateWithLifecycle()
        val diningMode by viewModel.activeDiningMode.collectAsStateWithLifecycle()
        val assignedTable by viewModel.assignedTableId.collectAsStateWithLifecycle()
        val cartItems by viewModel.cartItems.collectAsStateWithLifecycle()
        val feedbackMessage by viewModel.feedbackMessage.collectAsStateWithLifecycle()

        // Assistance Dialog state
        var showAssistanceDialog by remember { mutableStateOf(false) }

        if (showAssistanceDialog) {
          AlertDialog(
            onDismissRequest = { showAssistanceDialog = false },
            containerColor = Charcoal900,
            title = { Text("Request Host / Server Assistance", color = MaterialTheme.colorScheme.secondary) },
            text = {
              Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Select your request for Table ${assignedTable ?: "T04"}:", color = MaterialTheme.colorScheme.onSurface)
                listOf(
                  "Assistance with ordering / questions",
                  "Extra napkins & cutlery",
                  "Refill water / iced tea",
                  "Speak with floor manager"
                ).forEach { reason ->
                  OutlinedButton(
                    onClick = {
                      viewModel.requestAssistance(assignedTable ?: "T04", reason)
                      showAssistanceDialog = false
                    },
                    modifier = Modifier.fillMaxWidth()
                  ) {
                    Text(reason)
                  }
                }
              }
            },
            confirmButton = {
              TextButton(onClick = { showAssistanceDialog = false }) {
                Text("Dismiss")
              }
            }
          )
        }

        // Handle hardware or system back button
        BackHandler(enabled = currentRole == AppRole.KIOSK && kioskScreen != KioskSubScreen.WELCOME) {
          when (kioskScreen) {
            KioskSubScreen.ITEM_CUSTOMIZATION -> viewModel.navigateKioskTo(KioskSubScreen.MENU)
            KioskSubScreen.CART -> viewModel.navigateKioskTo(KioskSubScreen.MENU)
            KioskSubScreen.CHECKOUT -> viewModel.navigateKioskTo(KioskSubScreen.CART)
            else -> viewModel.navigateKioskTo(KioskSubScreen.WELCOME)
          }
        }

        Scaffold(
          modifier = Modifier.fillMaxSize(),
          topBar = {
            Column(modifier = Modifier.statusBarsPadding()) {
              AppHeader(
                currentRole = currentRole,
                onRoleSelected = { viewModel.navigateToRole(it) },
                diningMode = diningMode,
                assignedTable = assignedTable,
                cartCount = cartItems.sumOf { it.quantity },
                onBackClicked = if (currentRole == AppRole.KIOSK && kioskScreen != KioskSubScreen.WELCOME) {
                  {
                    when (kioskScreen) {
                      KioskSubScreen.ITEM_CUSTOMIZATION -> viewModel.navigateKioskTo(KioskSubScreen.MENU)
                      KioskSubScreen.CART -> viewModel.navigateKioskTo(KioskSubScreen.MENU)
                      KioskSubScreen.CHECKOUT -> viewModel.navigateKioskTo(KioskSubScreen.CART)
                      else -> viewModel.navigateKioskTo(KioskSubScreen.WELCOME)
                    }
                  }
                } else null,
                onCartClicked = {
                  viewModel.navigateKioskTo(KioskSubScreen.CART)
                },
                onHelpClicked = {
                  showAssistanceDialog = true
                }
              )

              StatusFeedbackBanner(
                message = feedbackMessage,
                onDismiss = { viewModel.clearFeedback() }
              )
            }
          },
          contentWindowInsets = WindowInsets(0, 0, 0, 0)
        ) { innerPadding ->
          Box(
            modifier = Modifier
              .fillMaxSize()
              .padding(innerPadding)
              .navigationBarsPadding()
          ) {
            when (currentRole) {
              AppRole.KIOSK -> {
                when (kioskScreen) {
                  KioskSubScreen.WELCOME -> {
                    KioskWelcomeScreen(
                      onCheckInClicked = { viewModel.navigateKioskTo(KioskSubScreen.CHECK_IN) },
                      onWaitlistClicked = { viewModel.navigateKioskTo(KioskSubScreen.WAITLIST) },
                      onOrderFoodClicked = { mode ->
                        viewModel.setDiningMode(mode)
                        viewModel.navigateKioskTo(KioskSubScreen.MENU)
                      },
                      onCheckOrderStatusClicked = { viewModel.navigateKioskTo(KioskSubScreen.ORDER_STATUS_TRACKER) },
                      onHelpClicked = { showAssistanceDialog = true }
                    )
                  }

                  KioskSubScreen.CHECK_IN -> {
                    val code by viewModel.lookupCode.collectAsStateWithLifecycle()
                    val res by viewModel.foundReservation.collectAsStateWithLifecycle()
                    val msg by viewModel.checkInMessage.collectAsStateWithLifecycle()

                    KioskCheckInScreen(
                      lookupCode = code,
                      onCodeChanged = { viewModel.onLookupCodeChanged(it) },
                      foundReservation = res,
                      checkInMessage = msg,
                      onCheckInNow = { resId -> viewModel.confirmReservationCheckIn(resId) },
                      onBackToHome = { viewModel.navigateKioskTo(KioskSubScreen.WELCOME) }
                    )
                  }

                  KioskSubScreen.WAITLIST -> {
                    val lastEntry by viewModel.lastCreatedWaitlistEntry.collectAsStateWithLifecycle()
                    val allEntries by viewModel.waitlist.collectAsStateWithLifecycle()

                    KioskWaitlistScreen(
                      lastCreatedEntry = lastEntry,
                      activeWaitlistEntries = allEntries,
                      onSubmitWaitlist = { name, party, phone, pref, highChair, access ->
                        viewModel.submitWaitlist(name, party, phone, pref, highChair, access)
                      },
                      onOrderAheadClicked = {
                        viewModel.setDiningMode(DiningMode.DINE_IN)
                        viewModel.navigateKioskTo(KioskSubScreen.MENU)
                      },
                      onBackToHome = { viewModel.navigateKioskTo(KioskSubScreen.WELCOME) }
                    )
                  }

                  KioskSubScreen.MENU -> {
                    val menu by viewModel.menu.collectAsStateWithLifecycle()
                    val selectedCategory by viewModel.selectedMenuCategory.collectAsStateWithLifecycle()

                    KioskMenuScreen(
                      categories = MenuCategory.values().toList(),
                      selectedCategory = selectedCategory,
                      onCategorySelected = { viewModel.selectCategory(it) },
                      menuItems = menu,
                      onItemClicked = { item -> viewModel.openItemCustomization(item) },
                      cartItems = cartItems,
                      onViewCartClicked = { viewModel.navigateKioskTo(KioskSubScreen.CART) }
                    )
                  }

                  KioskSubScreen.ITEM_CUSTOMIZATION -> {
                    val selectedItem by viewModel.selectedMenuItem.collectAsStateWithLifecycle()
                    if (selectedItem != null) {
                      KioskItemCustomizationScreen(
                        item = selectedItem!!,
                        onAddToCart = { item, qty, doneness, mods, notes ->
                          viewModel.addItemToCart(item, qty, doneness, mods, notes)
                        },
                        onCancel = { viewModel.navigateKioskTo(KioskSubScreen.MENU) }
                      )
                    } else {
                      viewModel.navigateKioskTo(KioskSubScreen.MENU)
                    }
                  }

                  KioskSubScreen.CART -> {
                    KioskCartScreen(
                      cartItems = cartItems,
                      diningMode = diningMode,
                      assignedTableId = assignedTable,
                      onUpdateQty = { id, qty -> viewModel.updateCartQty(id, qty) },
                      onRemoveItem = { id -> viewModel.removeCartItem(id) },
                      onClearCart = { viewModel.clearCart() },
                      onContinueShopping = { viewModel.navigateKioskTo(KioskSubScreen.MENU) },
                      onProceedToCheckout = { viewModel.navigateKioskTo(KioskSubScreen.CHECKOUT) }
                    )
                  }

                  KioskSubScreen.CHECKOUT -> {
                    KioskCheckoutScreen(
                      cartItems = cartItems,
                      diningMode = diningMode,
                      assignedTableId = assignedTable,
                      onPayNowConfirmed = { guestName ->
                        viewModel.submitOrder(guestName)
                      },
                      onCancel = { viewModel.navigateKioskTo(KioskSubScreen.CART) }
                    )
                  }

                  KioskSubScreen.ORDER_CONFIRMATION -> {
                    val lastOrder by viewModel.lastCompletedOrder.collectAsStateWithLifecycle()

                    KioskOrderConfirmationScreen(
                      order = lastOrder,
                      onTrackOrder = { viewModel.navigateKioskTo(KioskSubScreen.ORDER_STATUS_TRACKER) },
                      onDone = { viewModel.navigateKioskTo(KioskSubScreen.WELCOME) }
                    )
                  }

                  KioskSubScreen.ORDER_STATUS_TRACKER -> {
                    val orders by viewModel.orders.collectAsStateWithLifecycle()

                    KioskOrderStatusTrackerScreen(
                      orders = orders,
                      onBackToHome = { viewModel.navigateKioskTo(KioskSubScreen.WELCOME) }
                    )
                  }

                  else -> {
                    viewModel.navigateKioskTo(KioskSubScreen.WELCOME)
                  }
                }
              }

              AppRole.HOST -> {
                val reservations by viewModel.reservations.collectAsStateWithLifecycle()
                val waitlist by viewModel.waitlist.collectAsStateWithLifecycle()
                val tables by viewModel.tables.collectAsStateWithLifecycle()

                HostStandScreen(
                  reservations = reservations,
                  waitlist = waitlist,
                  tables = tables,
                  onAssignWaitlistToTable = { wId, tId -> viewModel.assignTableToWaitlist(wId, tId) },
                  onAssignReservationToTable = { rId, tId -> viewModel.assignTableToReservation(rId, tId) },
                  onUpdateTableStatus = { tId, status -> viewModel.updateTableStatus(tId, status) }
                )
              }

              AppRole.KITCHEN -> {
                val tickets by viewModel.kitchenTickets.collectAsStateWithLifecycle()

                KitchenDisplayScreen(
                  tickets = tickets,
                  onToggleItemReady = { tId, iId -> viewModel.toggleKitchenItemReady(tId, iId) },
                  onMarkTicketExpoReady = { tId -> viewModel.markTicketExpoReady(tId) }
                )
              }

              AppRole.EXPO -> {
                val tickets by viewModel.kitchenTickets.collectAsStateWithLifecycle()

                ExpoRunnerScreen(
                  tickets = tickets,
                  onDeliverOrder = { tId -> viewModel.deliverTicketOrder(tId) }
                )
              }

              AppRole.SERVER -> {
                val tables by viewModel.tables.collectAsStateWithLifecycle()
                val activeTableId by viewModel.serverActiveTableId.collectAsStateWithLifecycle()
                val orders by viewModel.orders.collectAsStateWithLifecycle()
                val menu by viewModel.menu.collectAsStateWithLifecycle()
                val helpReqs by viewModel.assistanceRequests.collectAsStateWithLifecycle()

                ServerPosScreen(
                  tables = tables,
                  selectedTableId = activeTableId,
                  onSelectTable = { viewModel.selectServerTable(it) },
                  orders = orders,
                  menu = menu,
                  onQuickAddItemToTable = { tId, item ->
                    viewModel.addItemToCart(item, 1, null, emptyList(), "Server POS Round")
                    viewModel.submitOrder("Server POS for Table $tId")
                  },
                  assistanceRequests = helpReqs,
                  onResolveAssistance = { viewModel.resolveAssistance(it) }
                )
              }

              AppRole.MANAGER -> {
                val tables by viewModel.tables.collectAsStateWithLifecycle()
                val orders by viewModel.orders.collectAsStateWithLifecycle()
                val waitlist by viewModel.waitlist.collectAsStateWithLifecycle()

                ManagerDashboardScreen(
                  tables = tables,
                  orders = orders,
                  waitlist = waitlist
                )
              }
            }
          }
        }
      }
    }
  }
}
