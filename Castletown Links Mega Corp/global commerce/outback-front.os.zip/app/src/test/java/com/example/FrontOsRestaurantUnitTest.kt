package com.example

import com.example.data.RestaurantRepository
import com.example.model.*
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class FrontOsRestaurantUnitTest {

  private lateinit var repository: RestaurantRepository

  @Before
  fun setUp() {
    repository = RestaurantRepository()
  }

  @Test
  fun testSeedDataInitialization() {
    val tables = repository.tables.value
    assertTrue("Should have seeded 28 tables across 3 zones", tables.size >= 28)
    val menu = repository.menu.value
    assertTrue("Should have seeded full steakhouse menu items", menu.size >= 12)
    val reservations = repository.reservations.value
    assertTrue("Should have seeded sample reservations", reservations.isNotEmpty())
  }

  @Test
  fun testWaitlistCreationAndNumbering() {
    val entry1 = repository.joinWaitlist(
      guestName = "Taylor Swift",
      partySize = 4,
      phone = "(555) 123-4567",
      seatingPreference = "Booth",
      highChair = false,
      accessibility = false
    )
    assertTrue("Queue reference should follow A0xx pattern", entry1.queueReference.startsWith("WAITLIST A0"))
    assertEquals(WaitlistStatus.WAITING, entry1.status)
    assertEquals(4, entry1.partySize)

    val waitlist = repository.waitlist.value
    assertTrue("Waitlist should contain the newly created entry", waitlist.any { it.id == entry1.id })
  }

  @Test
  fun testReservationLookupAndCheckIn() {
    val res = repository.lookupReservation("OB-7842")
    assertNotNull("Should find Marcus Vance's reservation with code OB-7842", res)
    assertEquals("Marcus Vance", res?.guestName)

    val checkedIn = repository.checkInReservation(res!!.id)
    assertTrue("Check in should succeed", checkedIn)

    val updatedRes = repository.reservations.value.find { it.id == res.id }
    assertEquals(ReservationStatus.ARRIVED, updatedRes?.status)
  }

  @Test
  fun testTableAssignmentAndSeating() {
    val waitEntry = repository.joinWaitlist("Alice Wonder", 2, "", "Any", false, false)
    val targetTableId = "T07"

    repository.assignTableToWaitlist(waitEntry.id, targetTableId)

    val table = repository.tables.value.find { it.id == targetTableId }
    assertEquals(TableStatus.OCCUPIED, table?.status)
    assertEquals("Alice Wonder", table?.currentGuestName)

    val updatedWaitlist = repository.waitlist.value.find { it.id == waitEntry.id }
    assertEquals(WaitlistStatus.SEATED, updatedWaitlist?.status)
    assertEquals(targetTableId, updatedWaitlist?.assignedTableId)
  }

  @Test
  fun testOrderCalculationAndKitchenTicketDispatch() {
    val steak = repository.menu.value.first { it.id == "STK_01" } // Victoria's Filet Mignon ($31.99)
    val sideMod = SelectedModifier("SIDE1", "Side", "SD_BAKED", "Loaded Baked Potato", 150) // +$1.50

    val cartItem = CartItem(
      cartItemId = "item-1",
      menuItem = steak,
      quantity = 2,
      steakDoneness = "Medium Rare",
      selectedModifiers = listOf(sideMod)
    )

    repository.addToCart(cartItem)
    assertEquals(1, repository.cartItems.value.size)

    // Unit price: 3199 + 150 = 3349 cents. For 2 items: 6698 cents ($66.98)
    assertEquals(6698L, repository.cartItems.value.first().totalPriceCents)

    // Submit order
    val order = repository.submitOrder(
      diningMode = DiningMode.DINE_IN,
      tableId = "T04",
      guestName = "Guest Party"
    )

    assertEquals(OrderStatus.ACCEPTED, order.status)
    assertEquals(PaymentState.CAPTURED, order.paymentState)
    assertEquals(6698L, order.subtotalCents)
    assertTrue("Tax should be accurately calculated at 8.25%", order.taxCents > 0)
    assertEquals(order.subtotalCents + order.taxCents, order.totalCents)

    // Verify Kitchen Ticket created
    val tickets = repository.kitchenTickets.value
    val ticket = tickets.find { it.orderId == order.orderId }
    assertNotNull("Kitchen ticket must be created", ticket)
    assertEquals("Table T04", ticket?.tableOrPickupRef)
    assertEquals(KitchenStation.GRILL, ticket?.items?.first()?.station)
    assertEquals("Medium Rare", ticket?.items?.first()?.doneness)

    // Test Kitchen bump and Expo ready
    val ticketItem = ticket!!.items.first()
    repository.toggleKitchenItemReady(ticket.ticketId, ticketItem.itemId)
    val bumpedTicket = repository.kitchenTickets.value.find { it.ticketId == ticket.ticketId }
    assertTrue(bumpedTicket!!.items.first().isReady)
    assertTrue(bumpedTicket.isExpoReady)

    // Test delivery to table
    repository.deliverTicketOrder(ticket.ticketId)
    val deliveredTicket = repository.kitchenTickets.value.find { it.ticketId == ticket.ticketId }
    assertTrue(deliveredTicket!!.isDelivered)
  }
}
