package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary = UniqloRed,
    onPrimary = UniqloWhite,
    primaryContainer = UniqloSubtleGray,
    onPrimaryContainer = UniqloBlack,
    secondary = UniqloBlack,
    onSecondary = UniqloWhite,
    background = UniqloOffWhite,
    onBackground = UniqloBlack,
    surface = UniqloWhite,
    onSurface = UniqloBlack,
    surfaceVariant = UniqloSubtleGray,
    onSurfaceVariant = UniqloDarkGray,
    outline = UniqloLightGray,
    outlineVariant = UniqloSubtleGray,
    error = UniqloRed,
    onError = UniqloWhite
)

private val DarkColorScheme = darkColorScheme(
    primary = UniqloRed,
    onPrimary = UniqloWhite,
    primaryContainer = UniqloCharcoal,
    onPrimaryContainer = UniqloWhite,
    secondary = UniqloWhite,
    onSecondary = UniqloBlack,
    background = UniqloBlack,
    onBackground = UniqloWhite,
    surface = UniqloCharcoal,
    onSurface = UniqloWhite,
    surfaceVariant = Color(0xFF2C2C2C),
    onSurfaceVariant = UniqloLightGray,
    outline = UniqloDarkGray,
    outlineVariant = Color(0xFF333333),
    error = UniqloRed,
    onError = UniqloWhite
)

@Composable
fun LifeWearTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
