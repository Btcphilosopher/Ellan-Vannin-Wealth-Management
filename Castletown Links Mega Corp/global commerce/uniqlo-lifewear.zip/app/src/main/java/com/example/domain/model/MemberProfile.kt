package com.example.domain.model

data class MemberProfile(
    val memberId: String = "2600 8912 3456",
    val name: String = "LifeWear Member",
    val email: String = "lifewear.member@uniqlo.com",
    val pointsBalance: Int = 1250,
    val tier: String = "GOLD LIFEWEAR MEMBER",
    val availableCouponsCount: Int = 3,
    val favouriteStoreName: String = "Oxford Street Flagship",
    val savedSizesSummary: String = "M (Tops) / 31 inch (Trousers)",
    val recyclingContributionsCount: Int = 8
)
