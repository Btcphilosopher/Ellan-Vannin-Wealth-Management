package com.example.domain.model

data class StylePost(
    val id: String,
    val creatorName: String,
    val creatorTitle: String, // e.g. "UNIQLO Oxford Street Staff" or "Community Stylist"
    val userAvatarUrl: String,
    val imageUrl: String,
    val title: String,
    val likesCount: Int,
    val isLiked: Boolean = false,
    val isSaved: Boolean = false,
    val heightCm: Int,
    val taggedProducts: List<Product>
)
