package com.example.feature.stores

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Call
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.seed.SeedData
import com.example.domain.model.*
import com.example.ui.theme.*

@Composable
fun StoreLocatorScreen(
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    val stores = SeedData.stores.filter {
        searchQuery.isEmpty() || it.name.contains(searchQuery, true) || it.city.contains(searchQuery, true)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(UniqloWhite)
            .statusBarsPadding()
    ) {
        // Header
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "STORE LOCATOR & SERVICES",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp,
                color = UniqloBlack
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Find nearest UNIQLO stores, Click & Collect, RE.UNIQLO & Alterations.",
                style = MaterialTheme.typography.bodyMedium,
                color = UniqloDarkGray
            )
        }

        HorizontalDivider(color = UniqloLightGray)

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search city or store name (e.g. Oxford St, Ginza)...") },
            leadingIcon = { Icon(imageVector = Icons.Outlined.LocationOn, contentDescription = null, tint = UniqloRed) },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = UniqloRed,
                unfocusedBorderColor = UniqloLightGray
            )
        )

        // Store List
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(vertical = 12.dp)
        ) {
            items(stores) { store ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, UniqloLightGray)
                        .background(UniqloSubtleGray)
                        .padding(16.dp)
                ) {
                    Column {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = store.name,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = UniqloBlack,
                                modifier = Modifier.weight(1f)
                            )

                            Text(
                                text = "${store.distanceKm} km",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = UniqloRed
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = store.address,
                            style = MaterialTheme.typography.bodyMedium,
                            color = UniqloDarkGray
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Outlined.Schedule, contentDescription = null, tint = UniqloMidGray, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = store.openingHours,
                                style = MaterialTheme.typography.labelSmall,
                                color = UniqloBlack
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Services Tags
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(store.services) { service ->
                                Box(
                                    modifier = Modifier
                                        .background(UniqloWhite)
                                        .border(1.dp, UniqloLightGray)
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = service.label,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontSize = 9.sp,
                                        color = UniqloBlack
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
