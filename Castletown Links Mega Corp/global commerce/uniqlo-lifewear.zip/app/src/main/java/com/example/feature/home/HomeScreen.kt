package com.example.feature.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.outlined.Thermostat
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.designsystem.components.ProductCard
import com.example.domain.model.*
import com.example.feature.viewmodel.HomeUiState
import com.example.ui.theme.*

@Composable
fun HomeScreen(
    uiState: HomeUiState,
    onCategoryClick: (ProductCategory) -> Unit,
    onCollectionClick: (CollectionLine) -> Unit,
    onProductClick: (String) -> Unit,
    onWishlistToggle: (String) -> Unit,
    onExploreStyling: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(UniqloOffWhite)
            .verticalScroll(scrollState)
    ) {
        // Weather / LifeWear Banner
        WeatherLifeWearBanner(
            weather = uiState.weatherInfo,
            onCollectionClick = onCollectionClick
        )

        // Hero Banner Editorial
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(280.dp)
                .background(UniqloBlack)
                .clickable { onCollectionClick(CollectionLine.LIFEWEAR) }
        ) {
            Image(
                painter = painterResource(id = R.drawable.hero_winter_lifewear_1793052532533),
                contentDescription = "Winter LifeWear",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.25f))
            )

            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(20.dp)
            ) {
                Text(
                    text = "WINTER LifeWear".uppercase(),
                    color = UniqloWhite,
                    style = MaterialTheme.typography.labelSmall,
                    letterSpacing = 2.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Warmth Without Weight.",
                    color = UniqloWhite,
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Black
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "EXPLORE COLLECTION",
                        color = UniqloWhite,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = null,
                        tint = UniqloWhite,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // LifeWear Collection Quick Tabs
        Text(
            text = "LIFEWEAR ESSENTIALS",
            style = MaterialTheme.typography.labelLarge,
            color = UniqloBlack,
            letterSpacing = 1.5.sp,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
        )

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            val collections = listOf(
                CollectionLine.HEATTECH,
                CollectionLine.AIRism,
                CollectionLine.PUFFERTECH,
                CollectionLine.LINEN,
                CollectionLine.UNIQLO_U,
                CollectionLine.UT
            )
            items(collections) { col ->
                Box(
                    modifier = Modifier
                        .background(UniqloWhite)
                        .border(1.dp, UniqloLightGray, RoundedCornerShape(2.dp))
                        .clickable { onCollectionClick(col) }
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    Text(
                        text = col.label.uppercase(),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = UniqloBlack
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Featured Products Grid Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "NEW ARRIVALS",
                style = MaterialTheme.typography.headlineSmall,
                color = UniqloBlack,
                letterSpacing = 1.sp
            )

            Text(
                text = "SEE ALL",
                style = MaterialTheme.typography.labelMedium,
                color = UniqloRed,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable { onCategoryClick(ProductCategory.T_SHIRTS) }
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Product Cards Horizontal / Grid
        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
            uiState.featuredProducts.chunked(2).forEach { rowItems ->
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                ) {
                    rowItems.forEach { product ->
                        ProductCard(
                            product = product,
                            isWishlisted = false,
                            onProductClick = onProductClick,
                            onWishlistToggle = onWishlistToggle,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    if (rowItems.size == 1) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Second Editorial Card: AIRism Technology
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .padding(horizontal = 16.dp)
                .clip(RoundedCornerShape(2.dp))
                .clickable { onCollectionClick(CollectionLine.AIRism) }
        ) {
            Image(
                painter = painterResource(id = R.drawable.hero_airism_tech_1793052489590),
                contentDescription = "AIRism Technology",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.White.copy(alpha = 0.3f))
            )

            Column(
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .padding(20.dp)
            ) {
                Text(
                    text = "ENGINEERED COMFORT",
                    style = MaterialTheme.typography.labelSmall,
                    color = UniqloRed,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "AIRism Technology",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = UniqloBlack
                )
                Text(
                    text = "Silk-smooth, moisture-wicking daily basics.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = UniqloCharcoal
                )
            }
        }

        Spacer(modifier = Modifier.height(32.dp))
    }
}

@Composable
fun WeatherLifeWearBanner(
    weather: WeatherInfo,
    onCollectionClick: (CollectionLine) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(UniqloWhite)
            .border(1.dp, UniqloLightGray)
            .clickable { onCollectionClick(weather.recommendedTech) }
            .padding(16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(UniqloSubtleGray, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Thermostat,
                        contentDescription = null,
                        tint = UniqloRed
                    )
                }

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "${weather.tempCelsius}°C ${weather.locationName}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = UniqloBlack
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .background(UniqloRed)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = weather.recommendedTech.label,
                                color = UniqloWhite,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = weather.recommendedTip,
                        style = MaterialTheme.typography.bodyMedium,
                        color = UniqloDarkGray,
                        maxLines = 1
                    )
                }
            }
        }
    }
}
