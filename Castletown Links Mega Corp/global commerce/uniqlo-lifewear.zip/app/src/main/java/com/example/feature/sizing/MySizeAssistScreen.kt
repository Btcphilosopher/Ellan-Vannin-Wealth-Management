package com.example.feature.sizing

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.designsystem.components.UniqloRedButton
import com.example.domain.model.*
import com.example.ui.theme.*

@Composable
fun MySizeAssistScreen(
    currentProfile: SizeProfile,
    onSaveProfile: (SizeProfile) -> Unit,
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var height by remember { mutableStateOf(currentProfile.heightCm.toFloat()) }
    var weight by remember { mutableStateOf(currentProfile.weightKg.toFloat()) }
    var chest by remember { mutableStateOf(currentProfile.chestCm.toFloat()) }
    var waist by remember { mutableStateOf(currentProfile.waistCm.toFloat()) }
    var selectedFit by remember { mutableStateOf(currentProfile.preferredFit) }
    var activeTab by remember { mutableStateOf(0) } // 0: Manual Measurements, 1: Camera Scan Demo

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(UniqloWhite)
            .statusBarsPadding()
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBackClick) {
                Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = UniqloBlack)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "MYSIZE ASSIST ENGINE",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp
            )
        }

        HorizontalDivider(color = UniqloLightGray)

        // Mode Selector Tabs
        Row(modifier = Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clickable { activeTab = 0 }
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "MEASUREMENTS",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = if (activeTab == 0) FontWeight.Bold else FontWeight.Medium,
                    color = if (activeTab == 0) UniqloRed else UniqloMidGray
                )
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .clickable { activeTab = 1 }
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CameraAlt,
                        contentDescription = null,
                        tint = if (activeTab == 1) UniqloRed else UniqloMidGray,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "CAMERA SCAN (DEMO)",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = if (activeTab == 1) FontWeight.Bold else FontWeight.Medium,
                        color = if (activeTab == 1) UniqloRed else UniqloMidGray
                    )
                }
            }
        }

        HorizontalDivider(color = UniqloLightGray)

        if (activeTab == 0) {
            // Manual Measurements Form
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "ENTER YOUR BODY PARAMETERS",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = UniqloBlack
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Height Slider
                Text(text = "Height: ${height.toInt()} cm", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
                Slider(
                    value = height,
                    onValueChange = { height = it },
                    valueRange = 140f..210f,
                    colors = SliderDefaults.colors(thumbColor = UniqloRed, activeTrackColor = UniqloRed)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Weight Slider
                Text(text = "Weight: ${weight.toInt()} kg", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
                Slider(
                    value = weight,
                    onValueChange = { weight = it },
                    valueRange = 40f..140f,
                    colors = SliderDefaults.colors(thumbColor = UniqloRed, activeTrackColor = UniqloRed)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Chest Slider
                Text(text = "Chest Circumference: ${chest.toInt()} cm", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
                Slider(
                    value = chest,
                    onValueChange = { chest = it },
                    valueRange = 70f..140f,
                    colors = SliderDefaults.colors(thumbColor = UniqloRed, activeTrackColor = UniqloRed)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Waist Slider
                Text(text = "Waist Circumference: ${waist.toInt()} cm", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
                Slider(
                    value = waist,
                    onValueChange = { waist = it },
                    valueRange = 60f..130f,
                    colors = SliderDefaults.colors(thumbColor = UniqloRed, activeTrackColor = UniqloRed)
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Fit Preference Toggles
                Text(
                    text = "FIT PREFERENCE",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = UniqloBlack
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    PreferredFit.values().forEach { fit ->
                        val isSelected = fit == selectedFit
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp)
                                .background(if (isSelected) UniqloRed else UniqloSubtleGray)
                                .border(1.dp, if (isSelected) UniqloRed else UniqloLightGray)
                                .clickable { selectedFit = fit },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = fit.label.split(" ").first().uppercase(),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) UniqloWhite else UniqloBlack
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(32.dp))

                UniqloRedButton(
                    text = "CALCULATE & SAVE SIZE PROFILE",
                    onClick = {
                        val profile = SizeProfile(
                            heightCm = height.toInt(),
                            weightKg = weight.toInt(),
                            chestCm = chest.toInt(),
                            waistCm = waist.toInt(),
                            preferredFit = selectedFit
                        )
                        onSaveProfile(profile)
                        onBackClick()
                    },
                    testTag = "save_size_profile_btn"
                )
            }
        } else {
            // Camera Measurement Demo Mode
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(UniqloBlack)
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(0.75f)
                            .border(2.dp, UniqloRed, RoundedCornerShape(4.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "DEMO SCAN SURFACE\n[ALIGN BODY WITH FRAME]",
                            color = UniqloWhite,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Text(
                        text = "Camera Assisted Size Estimation",
                        color = UniqloWhite,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Clearly labeled demo mode. Uses computer vision pose framing to approximate body proportions.",
                        color = UniqloLightGray,
                        style = MaterialTheme.typography.bodyMedium
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    UniqloRedButton(
                        text = "CONFIRM ESTIMATED SIZE M",
                        onClick = {
                            onSaveProfile(SizeProfile(chestCm = 98, preferredFit = PreferredFit.REGULAR))
                            onBackClick()
                        }
                    )
                }
            }
        }
    }
}
