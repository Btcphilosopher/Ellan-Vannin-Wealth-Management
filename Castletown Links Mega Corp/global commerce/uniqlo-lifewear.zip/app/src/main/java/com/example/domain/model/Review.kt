package com.example.domain.model

enum class FitFeedback(val label: String) {
    RUNS_SMALL("Runs Small"),
    TRUE_TO_SIZE("True to Size"),
    RUNS_LARGE("Runs Large")
}

data class Review(
    val id: String,
    val productId: String,
    val authorName: String,
    val rating: Int,
    val title: String,
    val comment: String,
    val sizePurchased: String,
    val heightCm: Int? = null,
    val fitFeedback: FitFeedback,
    val dateText: String,
    val isVerifiedPurchase: Boolean = true
)

data class ReviewSummary(
    val productId: String,
    val averageRating: Double,
    val totalReviews: Int,
    val trueToSizePercent: Int, // e.g. 74
    val runsSmallPercent: Int,  // e.g. 8
    val runsLargePercent: Int   // e.g. 18
)
