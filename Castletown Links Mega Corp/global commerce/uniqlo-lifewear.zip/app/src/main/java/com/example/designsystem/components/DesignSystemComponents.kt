package com.example.designsystem.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.domain.model.*
import com.example.ui.theme.*

@Composable
fun UniqloMainHeader(
    selectedGender: TargetGender,
    onGenderSelected: (TargetGender) -> Unit,
    cartItemCount: Int,
    onSearchClick: () -> Unit,
    onCartClick: () -> Unit,
    onQrClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(UniqloWhite)
    ) {
        // Top Brand Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterAlignment
        ) {
            // UNIQLO Red Logo Square
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(UniqloRed)
                        .padding(4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "UQ",
                        color = UniqloWhite,
                        fontWeight = FontWeight.Black,
                        fontSize = 16.sp,
                        letterSpacing = (-1).sp
                    )
                }

                Column {
                    Text(
                        text = "UNIQLO",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.5.sp,
                        color = UniqloBlack
                    )
                    Text(
                        text = "LifeWear",
                        style = MaterialTheme.typography.labelSmall,
                        color = UniqloDarkGray,
                        letterSpacing = 1.sp
                    )
                }
            }

            // Action Icons
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(
                    onClick = onSearchClick,
                    modifier = Modifier.testTag("top_bar_search_btn")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Search,
                        contentDescription = "Search",
                        tint = UniqloBlack
                    )
                }

                IconButton(
                    onClick = onQrClick,
                    modifier = Modifier.testTag("top_bar_qr_btn")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.QrCodeScanner,
                        contentDescription = "Member Barcode",
                        tint = UniqloBlack
                    )
                }

                Box {
                    IconButton(
                        onClick = onCartClick,
                        modifier = Modifier.testTag("top_bar_cart_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.ShoppingBag,
                            contentDescription = "Shopping Bag",
                            tint = UniqloBlack
                        )
                    }
                    if (cartItemCount > 0) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .offset(x = (-4).dp, y = 4.dp)
                                .size(18.dp)
                                .background(UniqloRed, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = cartItemCount.toString(),
                                color = UniqloWhite,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Gender Tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            TargetGender.values().forEach { gender ->
                val isSelected = gender == selectedGender
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onGenderSelected(gender) }
                        .padding(vertical = 10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = gender.label,
                        style = MaterialTheme.typography.labelLarge,
                        color = if (isSelected) UniqloRed else UniqloDarkGray,
                        fontWeight = if (isSelected) FontWeight.Black else FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.8f)
                            .height(2.dp)
                            .background(if (isSelected) UniqloRed else Color.Transparent)
                    )
                }
            }
        }

        HorizontalDivider(color = UniqloLightGray, thickness = 1.dp)
    }
}

@Composable
fun UniqloRedButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    icon: ImageVector? = null,
    testTag: String = "uniqlo_red_button"
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier
            .fillMaxWidth()
            .height(52.dp)
            .testTag(testTag),
        colors = ButtonDefaults.buttonColors(
            containerColor = UniqloRed,
            contentColor = UniqloWhite,
            disabledContainerColor = UniqloLightGray,
            disabledContentColor = UniqloMidGray
        ),
        shape = RoundedCornerShape(2.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            if (icon != null) {
                Icon(imageVector = icon, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
            }
            Text(
                text = text.uppercase(),
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp
            )
        }
    }
}

@Composable
fun UniqloOutlinedButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    testTag: String = "uniqlo_outlined_button"
) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier
            .fillMaxWidth()
            .height(50.dp)
            .testTag(testTag),
        border = androidx.compose.foundation.BorderStroke(1.dp, UniqloBlack),
        colors = ButtonDefaults.outlinedButtonColors(
            contentColor = UniqloBlack
        ),
        shape = RoundedCornerShape(2.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            if (icon != null) {
                Icon(imageVector = icon, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
            }
            Text(
                text = text.uppercase(),
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp
            )
        }
    }
}

@Composable
fun ProductCard(
    product: Product,
    isWishlisted: Boolean,
    onProductClick: (String) -> Unit,
    onWishlistToggle: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onProductClick(product.id) }
            .testTag("product_card_${product.id}"),
        colors = CardDefaults.cardColors(containerColor = UniqloWhite),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        shape = RoundedCornerShape(0.dp)
    ) {
        Column {
            // Image Container
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(0.85f)
                    .background(UniqloSubtleGray)
            ) {
                AsyncImage(
                    model = product.mainImageUrl,
                    contentDescription = product.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Status tag
                if (product.isNew) {
                    Box(
                        modifier = Modifier
                            .padding(8.dp)
                            .background(UniqloRed)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                            .align(Alignment.TopStart)
                    ) {
                        Text(
                            text = "NEW",
                            color = UniqloWhite,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else if (product.isSale) {
                    Box(
                        modifier = Modifier
                            .padding(8.dp)
                            .background(TagSaleRed)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                            .align(Alignment.TopStart)
                    ) {
                        Text(
                            text = "SALE",
                            color = UniqloWhite,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Wishlist Heart Icon
                IconButton(
                    onClick = { onWishlistToggle(product.id) },
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(4.dp)
                        .testTag("wishlist_btn_${product.id}")
                ) {
                    Icon(
                        imageVector = if (isWishlisted) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                        contentDescription = "Favourite",
                        tint = if (isWishlisted) UniqloRed else UniqloBlack
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Text Info
            Column(modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)) {
                Text(
                    text = product.collection.label.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = UniqloMidGray,
                    letterSpacing = 0.5.sp
                )

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = product.name,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    color = UniqloBlack
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "${product.currency}${String.format("%.2f", product.price)}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (product.isSale) UniqloRed else UniqloBlack
                    )

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.Star,
                            contentDescription = null,
                            tint = Color(0xFFFFB400),
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(
                            text = String.format("%.1f", product.rating),
                            style = MaterialTheme.typography.labelSmall,
                            color = UniqloDarkGray
                        )
                    }
                }

                // Color swatches indicator
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    product.colors.take(4).forEach { color ->
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(
                                    try {
                                        Color(android.graphics.Color.parseColor(color.hexValue))
                                    } catch (e: Exception) {
                                        UniqloDarkGray
                                    }
                                )
                                .border(0.5.dp, UniqloLightGray, CircleShape)
                        )
                    }
                    if (product.colors.size > 4) {
                        Text(
                            text = "+${product.colors.size - 4}",
                            style = MaterialTheme.typography.labelSmall,
                            color = UniqloMidGray
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun StockStatusBadge(level: StockLevel, modifier: Modifier = Modifier) {
    val (color, text) = when (level) {
        StockLevel.IN_STOCK -> TagLimitedGreen to "IN STOCK"
        StockLevel.LOW_STOCK -> Color(0xFFD97706) to "LOW STOCK"
        StockLevel.OUT_OF_STOCK -> UniqloRed to "OUT OF STOCK"
        StockLevel.ONLINE_ONLY -> TagNewBlue to "ONLINE ONLY"
    }

    Box(
        modifier = modifier
            .border(1.dp, color, RoundedCornerShape(2.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            text = text,
            color = color,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold
        )
    }
}
