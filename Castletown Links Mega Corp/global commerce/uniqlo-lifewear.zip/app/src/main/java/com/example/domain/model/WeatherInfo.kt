package com.example.domain.model

enum class WeatherCondition(val label: String) {
    SUNNY("Sunny & Warm"),
    CHILLY("Chilly & Breezy"),
    RAINY("Rainy & Wet"),
    FREEZING("Cold & Freezing"),
    MILD("Mild & Gentle")
}

data class WeatherInfo(
    val locationName: String = "London, UK",
    val tempCelsius: Int = 8,
    val condition: WeatherCondition = WeatherCondition.CHILLY,
    val recommendedTech: CollectionLine = CollectionLine.HEATTECH,
    val recommendedTip: String = "Layer HEATTECH Extra Warm under your outerwear today for optimal thermal regulation."
)
