package com.example.domain.model

data class AlterationChoice(
    val isRequested: Boolean = false,
    val desiredInseamCm: Int = 74,
    val stitchType: String = "Normal Stitch (£3.00)",
    val fee: Double = 3.00
)

data class CartItem(
    val id: String,
    val product: Product,
    val selectedColor: ProductColor,
    val selectedSize: String,
    val quantity: Int = 1,
    val alteration: AlterationChoice? = null
)
