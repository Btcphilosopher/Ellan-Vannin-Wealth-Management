package com.example.feature.styling

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.seed.SeedData
import com.example.designsystem.components.UniqloRedButton
import com.example.domain.model.*
import com.example.ui.theme.*

@Composable
fun StylingHubScreen(
    onProductClick: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedOccasion by remember { mutableStateOf<OutfitOccasion?>(null) }
    var activeTab by remember { mutableStateOf(0) } // 0: LifeWear Outfits, 1: StyleHint Community

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(UniqloWhite)
            .statusBarsPadding()
    ) {
        // Top Header
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "STYLE & LOOKS",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp,
                color = UniqloBlack
            )
            Text(
                text = "Curated LifeWear outfit combinations and staff styling looks",
                style = MaterialTheme.typography.bodyMedium,
                color = UniqloDarkGray
            )
        }

        HorizontalDivider(color = UniqloLightGray)

        // Subtabs
        Row(modifier = Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clickable { activeTab = 0 }
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "OUTFIT GENERATOR",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = if (activeTab == 0) FontWeight.Bold else FontWeight.Medium,
                    color = if (activeTab == 0) UniqloRed else UniqloMidGray
                )
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .clickable { activeTab = 1 }
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "STYLEHINT COMMUNITY",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = if (activeTab == 1) FontWeight.Bold else FontWeight.Medium,
                    color = if (activeTab == 1) UniqloRed else UniqloMidGray
                )
            }
        }

        HorizontalDivider(color = UniqloLightGray)

        if (activeTab == 0) {
            // Occasion Filter Bar
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(
                        selected = selectedOccasion == null,
                        onClick = { selectedOccasion = null },
                        label = { Text("ALL OCCASIONS") },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = UniqloBlack, selectedLabelColor = UniqloWhite)
                    )
                }
                items(OutfitOccasion.values()) { occ ->
                    val isSel = occ == selectedOccasion
                    FilterChip(
                        selected = isSel,
                        onClick = { selectedOccasion = if (isSel) null else occ },
                        label = { Text(occ.label.uppercase()) },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = UniqloRed, selectedLabelColor = UniqloWhite)
                    )
                }
            }

            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                val outfits = SeedData.outfits.filter { selectedOccasion == null || it.occasion == selectedOccasion }
                items(outfits) { outfit ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, UniqloLightGray)
                            .background(UniqloSubtleGray)
                            .padding(16.dp)
                    ) {
                        Column {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(200.dp)
                                    .clip(RoundedCornerShape(2.dp))
                            ) {
                                AsyncImage(
                                    model = outfit.imageUrl,
                                    contentDescription = outfit.title,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Text(
                                text = outfit.occasion.label.uppercase(),
                                style = MaterialTheme.typography.labelSmall,
                                color = UniqloRed,
                                fontWeight = FontWeight.Bold
                            )

                            Text(
                                text = outfit.title,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = UniqloBlack
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = outfit.description,
                                style = MaterialTheme.typography.bodyMedium,
                                color = UniqloDarkGray
                            )

                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "GARMENTS IN THIS LOOK",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = UniqloBlack
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                outfit.products.forEach { prod ->
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(UniqloWhite)
                                            .clickable { onProductClick(prod.id) }
                                            .padding(8.dp)
                                    ) {
                                        AsyncImage(
                                            model = prod.mainImageUrl,
                                            contentDescription = prod.name,
                                            modifier = Modifier
                                                .size(40.dp)
                                                .clip(RoundedCornerShape(2.dp))
                                        )

                                        Spacer(modifier = Modifier.width(10.dp))

                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = prod.name,
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = UniqloBlack
                                            )
                                            Text(
                                                text = "${prod.currency}${String.format("%.2f", prod.price)}",
                                                style = MaterialTheme.typography.labelMedium,
                                                color = UniqloRed,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // StyleHint Feed Grid
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(SeedData.stylePosts) { post ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, UniqloLightGray)
                            .background(UniqloWhite)
                    ) {
                        Column {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .aspectRatio(0.8f)
                            ) {
                                AsyncImage(
                                    model = post.imageUrl,
                                    contentDescription = post.title,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )

                                Box(
                                    modifier = Modifier
                                        .align(Alignment.TopStart)
                                        .padding(8.dp)
                                        .background(UniqloBlack.copy(alpha = 0.7f))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "${post.heightCm} cm",
                                        color = UniqloWhite,
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                }
                            }

                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = post.creatorTitle,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = UniqloRed,
                                    fontWeight = FontWeight.Bold
                                )

                                Text(
                                    text = post.title,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = UniqloBlack,
                                    maxLines = 2
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = "♡ ${post.likesCount}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = UniqloMidGray
                                    )

                                    Text(
                                        text = "SHOP LOOK",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = UniqloBlack,
                                        modifier = Modifier.clickable {
                                            post.taggedProducts.firstOrNull()?.let { onProductClick(it.id) }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
