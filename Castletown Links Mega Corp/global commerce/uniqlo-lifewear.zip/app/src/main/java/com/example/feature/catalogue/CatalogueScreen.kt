package com.example.feature.catalogue

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.designsystem.components.ProductCard
import com.example.domain.model.*
import com.example.data.repository.SortOption
import com.example.feature.viewmodel.CatalogueUiState
import com.example.ui.theme.*

@Composable
fun CatalogueScreen(
    uiState: CatalogueUiState,
    onSearchQueryChange: (String) -> Unit,
    onCategorySelect: (ProductCategory?) -> Unit,
    onSortSelect: (SortOption) -> Unit,
    onProductClick: (String) -> Unit,
    onWishlistToggle: (String) -> Unit,
    wishlistSet: Set<String>,
    modifier: Modifier = Modifier
) {
    var showSortSheet by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(UniqloOffWhite)
    ) {
        // Search Input Bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .background(UniqloWhite)
                .border(1.dp, UniqloLightGray, RoundedCornerShape(2.dp))
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = null,
                    tint = UniqloMidGray
                )
                Spacer(modifier = Modifier.width(8.dp))
                TextField(
                    value = uiState.searchQuery,
                    onValueChange = onSearchQueryChange,
                    placeholder = {
                        Text(
                            text = "Search by item, barcode (e.g. 465187), fabric...",
                            style = MaterialTheme.typography.bodyMedium,
                            color = UniqloMidGray
                        )
                    },
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent
                    ),
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("catalogue_search_input")
                )
                if (uiState.searchQuery.isNotEmpty()) {
                    IconButton(onClick = { onSearchQueryChange("") }) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Clear search", tint = UniqloDarkGray)
                    }
                }
            }
        }

        // Category Filter Chips Row
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(vertical = 4.dp)
        ) {
            item {
                FilterChip(
                    selected = uiState.selectedCategory == null,
                    onClick = { onCategorySelect(null) },
                    label = { Text("ALL ITEMS", fontWeight = FontWeight.Bold) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = UniqloBlack,
                        selectedLabelColor = UniqloWhite
                    )
                )
            }
            items(ProductCategory.values()) { category ->
                val isSelected = uiState.selectedCategory == category
                FilterChip(
                    selected = isSelected,
                    onClick = { onCategorySelect(if (isSelected) null else category) },
                    label = { Text(category.label.uppercase()) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = UniqloRed,
                        selectedLabelColor = UniqloWhite
                    )
                )
            }
        }

        // Filter Controls Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${uiState.products.size} ITEMS FOUND",
                style = MaterialTheme.typography.labelMedium,
                color = UniqloDarkGray,
                letterSpacing = 1.sp
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.clickable { showSortSheet = true }
            ) {
                Icon(
                    imageVector = Icons.Default.FilterList,
                    contentDescription = "Sort",
                    tint = UniqloBlack,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "SORT: ${uiState.selectedSort.label.uppercase()}",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = UniqloBlack
                )
            }
        }

        HorizontalDivider(color = UniqloLightGray, thickness = 1.dp)

        // Products Grid
        if (uiState.products.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "NO ITEMS FOUND",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = UniqloBlack
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Try searching for 'AIRism', 'HEATTECH', or clearance SKU codes.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = UniqloDarkGray
                    )
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(uiState.products, key = { it.id }) { product ->
                    ProductCard(
                        product = product,
                        isWishlisted = wishlistSet.contains(product.id),
                        onProductClick = onProductClick,
                        onWishlistToggle = onWishlistToggle
                    )
                }
            }
        }
    }

    // Sort Selection Dialog / Sheet
    if (showSortSheet) {
        AlertDialog(
            onDismissRequest = { showSortSheet = false },
            title = {
                Text(
                    text = "SORT PRODUCTS",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column {
                    SortOption.values().forEach { option ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onSortSelect(option)
                                    showSortSheet = false
                                }
                                .padding(vertical = 12.dp)
                        ) {
                            RadioButton(
                                selected = uiState.selectedSort == option,
                                onClick = {
                                    onSortSelect(option)
                                    showSortSheet = false
                                }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = option.label,
                                style = MaterialTheme.typography.bodyLarge,
                                color = UniqloBlack
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSortSheet = false }) {
                    Text("CLOSE", color = UniqloRed, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = UniqloWhite,
            shape = RoundedCornerShape(2.dp)
        )
    }
}
