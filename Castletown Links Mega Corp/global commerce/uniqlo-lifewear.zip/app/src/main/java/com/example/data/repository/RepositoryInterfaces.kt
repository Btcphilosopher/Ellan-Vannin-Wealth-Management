package com.example.data.repository

import com.example.domain.model.*
import kotlinx.coroutines.flow.Flow

interface ProductRepository {
    suspend fun getProducts(
        gender: TargetGender? = null,
        category: ProductCategory? = null,
        collection: CollectionLine? = null,
        searchQuery: String? = null,
        sortBy: SortOption = SortOption.RECOMMENDED
    ): List<Product>

    suspend fun getProductById(id: String): Product?
    suspend fun getProductByBarcode(barcode: String): Product?
    suspend fun getFeaturedProducts(): List<Product>
    suspend fun getRecommendations(
        gender: TargetGender = TargetGender.MEN,
        currentCollection: CollectionLine? = null
    ): List<Product>
}

enum class SortOption(val label: String) {
    RECOMMENDED("Recommended"),
    NEWEST("Newest Arrivals"),
    PRICE_LOW_HIGH("Price: Low to High"),
    PRICE_HIGH_LOW("Price: High to Low"),
    BEST_RATED("Best Rated"),
    MOST_POPULAR("Most Popular")
}

interface StoreRepository {
    suspend fun getAllStores(): List<Store>
    suspend fun getStoreById(id: String): Store?
    suspend fun getStoreStock(productId: String, storeId: String, sizeCode: String): StockLevel
    suspend fun findNearbyStoresWithStock(productId: String, sizeCode: String): List<Pair<Store, StockLevel>>
}

interface CartRepository {
    val cartItems: Flow<List<CartItem>>
    suspend fun addToCart(
        product: Product,
        color: ProductColor,
        size: String,
        quantity: Int = 1,
        alteration: AlterationChoice? = null
    )
    suspend fun updateQuantity(cartItemId: String, quantity: Int)
    suspend fun removeCartItem(cartItemId: String)
    suspend fun clearCart()
}

interface WishlistRepository {
    val wishlistProductIds: Flow<Set<String>>
    suspend fun toggleWishlist(productId: String)
    suspend fun isWishlisted(productId: String): Boolean
}

interface OrderRepository {
    val orders: Flow<List<Order>>
    suspend fun placeOrder(
        items: List<CartItem>,
        subtotal: Double,
        deliveryCost: Double,
        deliveryMethod: DeliveryMethod,
        storePickupName: String?
    ): Order
    suspend fun getOrderById(orderId: String): Order?
}

interface SizingRepository {
    val sizeProfile: Flow<SizeProfile>
    suspend fun saveSizeProfile(profile: SizeProfile)
    fun calculateRecommendation(profile: SizeProfile, product: Product): SizeRecommendation
}

interface StylingRepository {
    suspend fun getOutfits(occasion: OutfitOccasion? = null, tempC: Int? = null): List<Outfit>
    suspend fun getStylePosts(): List<StylePost>
}

interface WeatherRepository {
    val currentWeather: Flow<WeatherInfo>
    suspend fun updateSimulatedTemp(tempC: Int)
}

interface AnalyticsRepository {
    suspend fun logEvent(eventName: String, params: Map<String, String> = emptyMap())
}
