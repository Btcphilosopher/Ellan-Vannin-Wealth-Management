package com.example.domain.model

enum class OrderStatus(val label: String, val stepIndex: Int) {
    PAID("Paid", 0),
    PROCESSING("Processing", 1),
    DISPATCHED("Dispatched", 2),
    READY_FOR_COLLECTION("Ready for Collection", 3),
    DELIVERED("Delivered", 4),
    RETURNED("Returned", 5)
}

enum class DeliveryMethod(val label: String, val price: Double, val estimatedDays: String) {
    HOME_DELIVERY("Home Delivery", 3.95, "2-3 Working Days"),
    CLICK_AND_COLLECT("Click & Collect (Store)", 0.00, "Ready in 2 Hours"),
    EXPRESS_DELIVERY("Express Next Day", 6.95, "Next Working Day")
}

data class Order(
    val id: String,
    val orderNumber: String,
    val items: List<CartItem>,
    val subtotal: Double,
    val deliveryCost: Double,
    val total: Double,
    val status: OrderStatus,
    val deliveryMethod: DeliveryMethod,
    val storePickupName: String? = null,
    val createdDateTimestamp: Long,
    val trackingCode: String,
    val estimatedArrivalDate: String
)
