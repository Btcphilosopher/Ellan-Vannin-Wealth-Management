package com.example.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cart_items")
data class CartItemEntity(
    @PrimaryKey val id: String,
    val productId: String,
    val selectedColorCode: String,
    val selectedSizeCode: String,
    val quantity: Int,
    val hasAlteration: Boolean,
    val alterationInseamCm: Int,
    val alterationStitchType: String,
    val alterationFee: Double
)

@Entity(tableName = "wishlist_items")
data class WishlistItemEntity(
    @PrimaryKey val productId: String,
    val addedTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey val id: String,
    val orderNumber: String,
    val itemsJson: String, // serialized cart items summary
    val subtotal: Double,
    val deliveryCost: Double,
    val total: Double,
    val statusName: String,
    val deliveryMethodName: String,
    val storePickupName: String?,
    val createdDateTimestamp: Long,
    val trackingCode: String,
    val estimatedArrivalDate: String
)

@Entity(tableName = "size_profile")
data class SizeProfileEntity(
    @PrimaryKey val id: Int = 1,
    val heightCm: Int,
    val weightKg: Int,
    val chestCm: Int,
    val waistCm: Int,
    val hipCm: Int,
    val shoulderCm: Int,
    val inseamCm: Int,
    val preferredFitName: String
)
