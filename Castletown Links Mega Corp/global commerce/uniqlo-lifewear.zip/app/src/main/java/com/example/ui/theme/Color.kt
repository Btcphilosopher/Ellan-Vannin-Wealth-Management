package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val UniqloRed = Color(0xFFE60012)
val UniqloRedDark = Color(0xFFC0000F)
val UniqloBlack = Color(0xFF111111)
val UniqloCharcoal = Color(0xFF222222)
val UniqloDarkGray = Color(0xFF555555)
val UniqloMidGray = Color(0xFF888888)
val UniqloLightGray = Color(0xFFE5E5E0)
val UniqloSubtleGray = Color(0xFFF4F4F1)
val UniqloOffWhite = Color(0xFFFBFBF9)
val UniqloWhite = Color(0xFFFFFFFF)

// Accent tags
val TagSaleRed = Color(0xFFE60012)
val TagNewBlue = Color(0xFF005A9C)
val TagLimitedGreen = Color(0xFF1E6B3C)
