package com.example.domain.model

enum class OutfitOccasion(val label: String) {
    WORK("Work & Office"),
    WEEKEND("Weekend Casual"),
    TRAVEL("Travel & Commute"),
    RAINY_DAY("Rainy Day Utility"),
    WINTER_COLD("Winter Layers"),
    SUMMER_HEAT("Summer Heat"),
    MINIMAL("Minimal Essential"),
    SMART_CASUAL("Smart Casual"),
    OUTDOOR("Outdoor Active")
}

data class Outfit(
    val id: String,
    val title: String,
    val occasion: OutfitOccasion,
    val minTempC: Int,
    val maxTempC: Int,
    val description: String,
    val imageUrl: String,
    val products: List<Product>
)
