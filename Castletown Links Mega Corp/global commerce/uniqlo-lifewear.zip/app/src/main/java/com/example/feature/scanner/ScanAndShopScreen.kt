package com.example.feature.scanner

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.outlined.ShoppingBag
import androidx.compose.material.icons.outlined.Storefront
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.designsystem.components.StockStatusBadge
import com.example.designsystem.components.UniqloOutlinedButton
import com.example.designsystem.components.UniqloRedButton
import com.example.domain.model.*
import com.example.ui.theme.*

@Composable
fun ScanAndShopScreen(
    scannedProduct: Product?,
    onSimulateScanBarcode: (String) -> Unit,
    onAddToCart: (Product) -> Unit,
    onOpenProductPage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(UniqloWhite)
            .statusBarsPadding()
    ) {
        // Title Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column {
                Text(
                    text = "SCAN & SHOP",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp,
                    color = UniqloBlack
                )
                Text(
                    text = "Point camera at tag barcode or enter SKU number",
                    style = MaterialTheme.typography.bodyMedium,
                    color = UniqloDarkGray
                )
            }
        }

        HorizontalDivider(color = UniqloLightGray)

        // Camera Scanner Surface Overlay Box
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(240.dp)
                .background(UniqloBlack),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier
                        .size(160.dp)
                        .border(2.dp, UniqloRed, RoundedCornerShape(4.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.QrCodeScanner,
                        contentDescription = null,
                        tint = UniqloWhite,
                        modifier = Modifier.size(48.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "ALIGN BARCODE IN FRAME",
                    color = UniqloWhite,
                    style = MaterialTheme.typography.labelSmall,
                    letterSpacing = 1.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Demo Quick Barcode Buttons
        Text(
            text = "DEMO TAG TRIGGERS",
            style = MaterialTheme.typography.labelSmall,
            color = UniqloMidGray,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(horizontal = 16.dp, top = 12.dp)
        )

        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp)
        ) {
            OutlinedButton(
                onClick = { onSimulateScanBarcode("465187") },
                modifier = Modifier
                    .weight(1f)
                    .testTag("scan_demo_465187_btn")
            ) {
                Text("SCAN AIRism (465187)", fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }

            OutlinedButton(
                onClick = { onSimulateScanBarcode("461523") },
                modifier = Modifier
                    .weight(1f)
                    .testTag("scan_demo_461523_btn")
            ) {
                Text("SCAN HEATTECH (461523)", fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        HorizontalDivider(color = UniqloLightGray)

        // Scanned Product Details
        if (scannedProduct != null) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Text(
                        text = "PRODUCT FOUND",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = UniqloRed,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(UniqloSubtleGray)
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AsyncImage(
                            model = scannedProduct.mainImageUrl,
                            contentDescription = scannedProduct.name,
                            modifier = Modifier
                                .size(80.dp)
                                .clip(RoundedCornerShape(2.dp))
                        )

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = scannedProduct.name,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = UniqloBlack
                            )
                            Text(
                                text = "SKU: ${scannedProduct.sku} / BARCODE: ${scannedProduct.eanBarcode}",
                                style = MaterialTheme.typography.labelSmall,
                                color = UniqloMidGray
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "${scannedProduct.currency}${String.format("%.2f", scannedProduct.price)}",
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Black,
                                color = UniqloRed
                            )
                        }
                    }
                }

                // Inventory Breakdown across stores
                item {
                    Text(
                        text = "OMNICHANNEL INVENTORY LOOKUP",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = UniqloBlack,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, UniqloLightGray)
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Oxford Street Flagship (Current)",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold
                            )
                            StockStatusBadge(StockLevel.LOW_STOCK)
                        }

                        HorizontalDivider(color = UniqloLightGray)

                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Regent Street & Theory",
                                style = MaterialTheme.typography.bodyMedium
                            )
                            StockStatusBadge(StockLevel.IN_STOCK)
                        }

                        HorizontalDivider(color = UniqloLightGray)

                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Online Warehouse Distribution",
                                style = MaterialTheme.typography.bodyMedium
                            )
                            StockStatusBadge(StockLevel.IN_STOCK)
                        }
                    }
                }

                item {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        UniqloOutlinedButton(
                            text = "VIEW PRODUCT PAGE",
                            onClick = { onOpenProductPage(scannedProduct.id) },
                            modifier = Modifier.weight(1f)
                        )

                        UniqloRedButton(
                            text = "ADD TO BAG",
                            onClick = { onAddToCart(scannedProduct) },
                            modifier = Modifier.weight(1f),
                            icon = Icons.Outlined.ShoppingBag
                        )
                    }
                }
            }
        }
    }
}
