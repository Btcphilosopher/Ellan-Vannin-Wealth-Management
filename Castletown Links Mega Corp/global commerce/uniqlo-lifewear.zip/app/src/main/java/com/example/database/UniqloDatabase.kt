package com.example.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        CartItemEntity::class,
        WishlistItemEntity::class,
        OrderEntity::class,
        SizeProfileEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class UniqloDatabase : RoomDatabase() {
    abstract fun cartDao(): CartDao
    abstract fun wishlistDao(): WishlistDao
    abstract fun orderDao(): OrderDao
    abstract fun sizeProfileDao(): SizeProfileDao

    companion object {
        @Volatile
        private var INSTANCE: UniqloDatabase? = null

        fun getDatabase(context: Context): UniqloDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    UniqloDatabase::class.java,
                    "uniqlo_lifewear_db"
                ).fallbackToDestructiveMigration()
                 .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
