package com.example.data.seed

import com.example.domain.model.*

object SeedData {

    val standardColors = listOf(
        ProductColor("00 WHITE", "00", "#FFFFFF", "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=600"),
        ProductColor("09 BLACK", "09", "#111111", "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=600"),
        ProductColor("69 NAVY", "69", "#1A2332", "https://images.unsplash.com/photo-1618354691373-d851c5c3a990?w=600"),
        ProductColor("57 OLIVE", "57", "#4B5320", "https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=600"),
        ProductColor("30 NATURAL", "30", "#EAE6DF", "https://images.unsplash.com/photo-1562157873-818bc0726f68?w=600"),
        ProductColor("03 GRAY", "03", "#999999", "https://images.unsplash.com/photo-1618354691438-25bc04584c23?w=600")
    )

    val standardSizes = listOf(
        ProductSize("XS"), ProductSize("S"), ProductSize("M"), ProductSize("L"), ProductSize("XL"), ProductSize("XXL")
    )

    val products = listOf(
        Product(
            id = "uniqlo-465187",
            sku = "465187",
            name = "MEN'S AIRism Cotton Oversized T-Shirt",
            subName = "Half Sleeve / LifeWear Essential",
            targetGender = TargetGender.MEN,
            category = ProductCategory.AIRism,
            collection = CollectionLine.AIRism,
            description = "Heavyweight feel on the outside, silky AIRism cotton on the inside. Oversized boxy silhouette designed by Clare Waight Keller & Uniqlo R&D center Paris.",
            price = 19.90,
            colors = standardColors,
            sizes = standardSizes,
            materialComposition = "53% Cotton, 47% Polyester (AIRism Tech)",
            careInstructions = "Machine wash cold, gentle cycle. Do not dry clean.",
            fitType = FitType.OVERSIZED,
            rating = 4.8,
            reviewCount = 1420,
            isNew = true,
            isExclusive = false,
            eanBarcode = "4549501823101",
            mainImageUrl = "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=800",
            galleryImages = listOf(
                "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=800",
                "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=800",
                "https://images.unsplash.com/photo-1562157873-818bc0726f68?w=800"
            ),
            supportsAlterations = false
        ),
        Product(
            id = "uniqlo-461523",
            sku = "461523",
            name = "MEN'S HEATTECH Extra Warm Crew Neck Top",
            subName = "1.5x Warmer Regular HEATTECH",
            targetGender = TargetGender.MEN,
            category = ProductCategory.HEATTECH,
            collection = CollectionLine.HEATTECH,
            description = "Brushed interior lining retains maximum body heat. Ultra lightweight fiber engineered with Toray Industries Japan.",
            price = 24.90,
            colors = listOf(standardColors[1], standardColors[2], standardColors[5]),
            sizes = standardSizes,
            materialComposition = "52% Acrylic, 28% Rayon, 16% Polyester, 4% Elastane",
            careInstructions = "Machine wash cold. Do not tumble dry.",
            fitType = FitType.SLIM,
            rating = 4.9,
            reviewCount = 2890,
            isNew = false,
            eanBarcode = "4549501823102",
            mainImageUrl = "https://images.unsplash.com/photo-1618354691373-d851c5c3a990?w=800",
            supportsAlterations = false
        ),
        Product(
            id = "uniqlo-460912",
            sku = "460912",
            name = "WOMEN'S Seamless Down Parka",
            subName = "Water-repellent & Windproof",
            targetGender = TargetGender.WOMEN,
            category = ProductCategory.OUTERWEAR,
            collection = CollectionLine.PUFFERTECH,
            description = "Seamless construction keeps cold wind and rain out while trapping 750+ fill power premium down warmth.",
            price = 129.90,
            originalPrice = 149.90,
            colors = listOf(standardColors[0], standardColors[1], standardColors[3]),
            sizes = standardSizes,
            materialComposition = "Shell: 100% Polyester / Filling: 90% Down, 10% Feathers",
            careInstructions = "Hand wash cold or dry clean.",
            fitType = FitType.REGULAR,
            rating = 4.7,
            reviewCount = 850,
            isSale = true,
            eanBarcode = "4549501823103",
            mainImageUrl = "https://images.unsplash.com/photo-1544441893-675973e31985?w=800",
            supportsAlterations = false
        ),
        Product(
            id = "uniqlo-450119",
            sku = "450119",
            name = "MEN'S Smart Ankle Trousers (2-Way Stretch)",
            subName = "Clean Tailored Fit",
            targetGender = TargetGender.MEN,
            category = ProductCategory.TROUSERS_JEANS,
            collection = CollectionLine.LIFEWEAR,
            description = "Elegant wool-like texture with comfortable 2-way stretch movement. Tapered cut suitable for work or weekend.",
            price = 39.90,
            colors = listOf(standardColors[1], standardColors[2], standardColors[5]),
            sizes = standardSizes,
            materialComposition = "67% Polyester, 29% Rayon, 4% Elastane",
            careInstructions = "Machine wash cold, delicate cycle.",
            fitType = FitType.REGULAR,
            rating = 4.6,
            reviewCount = 1100,
            eanBarcode = "4549501823104",
            mainImageUrl = "https://images.unsplash.com/photo-1473966968600-fa801b869a1a?w=800",
            supportsAlterations = true
        ),
        Product(
            id = "uniqlo-462881",
            sku = "462881",
            name = "WOMEN'S 100% Cashmere Crew Neck Sweater",
            subName = "UNIQLO U Collection",
            targetGender = TargetGender.WOMEN,
            category = ProductCategory.KNITWEAR,
            collection = CollectionLine.UNIQLO_U,
            description = "100% Grade-A cashmere knitted with incredible softness and pill-resistant finishing. Designed by Christophe Lemaire.",
            price = 89.90,
            colors = listOf(standardColors[0], standardColors[3], standardColors[4]),
            sizes = standardSizes,
            materialComposition = "100% Cashmere",
            careInstructions = "Dry clean or hand wash cold with wool detergent.",
            fitType = FitType.REGULAR,
            rating = 4.9,
            reviewCount = 620,
            isExclusive = true,
            eanBarcode = "4549501823105",
            mainImageUrl = "https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=800",
            supportsAlterations = false
        ),
        Product(
            id = "uniqlo-469001",
            sku = "469001",
            name = "UT Graphic T-Shirt x Louvre Museum (Mona Lisa)",
            subName = "Art & Culture Special Edition",
            targetGender = TargetGender.MEN,
            category = ProductCategory.UT_GRAPHICS,
            collection = CollectionLine.UT,
            description = "Reimagined Louvre masterpiece graphic artwork printed on 100% heavy cotton jersey fabric.",
            price = 19.90,
            colors = listOf(standardColors[0], standardColors[1]),
            sizes = standardSizes,
            materialComposition = "100% Cotton",
            careInstructions = "Machine wash cold inside out.",
            fitType = FitType.RELAXED,
            rating = 4.8,
            reviewCount = 310,
            isNew = true,
            eanBarcode = "4549501823106",
            mainImageUrl = "https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?w=800",
            supportsAlterations = false
        ),
        Product(
            id = "uniqlo-458112",
            sku = "458112",
            name = "WOMEN'S Premium Linen Long Sleeve Shirt",
            subName = "100% European Flax",
            targetGender = TargetGender.WOMEN,
            category = ProductCategory.SHIRTS_BLOUSES,
            collection = CollectionLine.LINEN,
            description = "Breathable 100% European linen gets softer with every wash. Perfect for layering in warm weather.",
            price = 34.90,
            colors = listOf(standardColors[0], standardColors[4], standardColors[5]),
            sizes = standardSizes,
            materialComposition = "100% Linen",
            careInstructions = "Machine wash cold gently.",
            fitType = FitType.RELAXED,
            rating = 4.7,
            reviewCount = 940,
            eanBarcode = "4549501823107",
            mainImageUrl = "https://images.unsplash.com/photo-1598033129183-c4f50c736f10?w=800",
            supportsAlterations = false
        ),
        Product(
            id = "uniqlo-461029",
            sku = "461029",
            name = "KIDS AIRism Cotton Crew Neck T-Shirt",
            subName = "Quick-Dry & Smooth Touch",
            targetGender = TargetGender.KIDS,
            category = ProductCategory.AIRism,
            collection = CollectionLine.AIRism,
            description = "Keeps kids cool and dry all day during sports or outdoor play.",
            price = 9.90,
            colors = listOf(standardColors[0], standardColors[2], standardColors[3]),
            sizes = listOf(ProductSize("110"), ProductSize("120"), ProductSize("130"), ProductSize("140"), ProductSize("150")),
            materialComposition = "53% Cotton, 47% Polyester",
            careInstructions = "Machine wash cold.",
            fitType = FitType.REGULAR,
            rating = 4.9,
            reviewCount = 480,
            eanBarcode = "4549501823108",
            mainImageUrl = "https://images.unsplash.com/photo-1519238263530-99bdd11df2ea?w=800",
            supportsAlterations = false
        ),
        Product(
            id = "uniqlo-452331",
            sku = "452331",
            name = "BABY AIRism Mesh Short Sleeve Bodysuit",
            subName = "Pack of 2",
            targetGender = TargetGender.BABY,
            category = ProductCategory.INNERWEAR,
            collection = CollectionLine.AIRism,
            description = "Ultra-breathable AIRism mesh gentle on sensitive infant skin.",
            price = 12.90,
            colors = listOf(standardColors[0], standardColors[4]),
            sizes = listOf(ProductSize("60cm"), ProductSize("70cm"), ProductSize("80cm")),
            materialComposition = "100% Polyester (AIRism Mesh)",
            careInstructions = "Machine wash cold in laundry net.",
            fitType = FitType.REGULAR,
            rating = 5.0,
            reviewCount = 320,
            eanBarcode = "4549501823109",
            mainImageUrl = "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?w=800",
            supportsAlterations = false
        )
    )

    val stores = listOf(
        Store(
            id = "store-oxford-st",
            name = "UNIQLO Oxford Street Global Flagship",
            city = "London",
            address = "311 Oxford Street, London",
            postcode = "W1C 2HP",
            distanceKm = 0.8,
            openingHours = "Mon - Sat: 09:00 - 21:00 / Sun: 11:30 - 18:00",
            phoneNumber = "+44 20 7290 7700",
            services = listOf(
                StoreService.CLICK_AND_COLLECT,
                StoreService.PICK_UP_TODAY,
                StoreService.ALTERATIONS,
                StoreService.RE_UNIQLO,
                StoreService.UT_ME,
                StoreService.MENSWEAR,
                StoreService.WOMENSWEAR,
                StoreService.KIDS
            ),
            lat = 51.515,
            lng = -0.141
        ),
        Store(
            id = "store-regent-st",
            name = "UNIQLO Regent Street & Theory",
            city = "London",
            address = "103-113 Regent Street, London",
            postcode = "W1B 4HL",
            distanceKm = 1.2,
            openingHours = "Mon - Sat: 10:00 - 21:00 / Sun: 12:00 - 18:00",
            phoneNumber = "+44 20 7434 2200",
            services = listOf(
                StoreService.CLICK_AND_COLLECT,
                StoreService.ALTERATIONS,
                StoreService.RE_UNIQLO,
                StoreService.MENSWEAR,
                StoreService.WOMENSWEAR
            ),
            lat = 51.511,
            lng = -0.138
        ),
        Store(
            id = "store-5th-ave",
            name = "UNIQLO 5th Avenue Flagship",
            city = "New York",
            address = "666 5th Ave, New York, NY",
            postcode = "10103",
            distanceKm = 5.4,
            openingHours = "Mon - Sat: 10:00 - 20:00 / Sun: 11:00 - 19:00",
            phoneNumber = "+1 877 486 4756",
            services = listOf(
                StoreService.CLICK_AND_COLLECT,
                StoreService.ALTERATIONS,
                StoreService.UT_ME,
                StoreService.RE_UNIQLO
            ),
            lat = 40.760,
            lng = -73.976
        ),
        Store(
            id = "store-ginza",
            name = "UNIQLO Ginza Global Flagship Store",
            city = "Tokyo",
            address = "6-9-5 Ginza, Chuo-ku, Tokyo",
            postcode = "104-0061",
            distanceKm = 12.0,
            openingHours = "11:00 - 21:00 Daily",
            phoneNumber = "+81 3 6252 5181",
            services = StoreService.values().toList(),
            lat = 35.671,
            lng = 139.764
        )
    )

    val outfits = listOf(
        Outfit(
            id = "outfit-1",
            title = "Tokyo City Minimalist",
            occasion = OutfitOccasion.MINIMAL,
            minTempC = 5,
            maxTempC = 16,
            description = "Clean silhouette layering an AIRism oversized tee under a seamless down parka paired with Smart Ankle trousers.",
            imageUrl = "https://images.unsplash.com/photo-1544441893-675973e31985?w=800",
            products = listOf(products[0], products[2], products[3])
        ),
        Outfit(
            id = "outfit-2",
            title = "Winter Workday Utility",
            occasion = OutfitOccasion.WORK,
            minTempC = 0,
            maxTempC = 12,
            description = "Warmth without weight. HEATTECH Extra warm layer underneath Grade-A Cashmere knitwear.",
            imageUrl = "https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=800",
            products = listOf(products[1], products[4], products[3])
        )
    )

    val stylePosts = listOf(
        StylePost(
            id = "style-1",
            creatorName = "Taro K.",
            creatorTitle = "UNIQLO Oxford Street Staff",
            userAvatarUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200",
            imageUrl = "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=800",
            title = "AIRism Oversized Tee in Natural (Size L)",
            likesCount = 342,
            heightCm = 178,
            taggedProducts = listOf(products[0], products[3])
        ),
        StylePost(
            id = "style-2",
            creatorName = "Yuki M.",
            creatorTitle = "Ginza Flagship Stylist",
            userAvatarUrl = "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200",
            imageUrl = "https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=800",
            title = "100% Cashmere Knit with Linen Accent",
            likesCount = 589,
            heightCm = 165,
            taggedProducts = listOf(products[4], products[6])
        )
    )

    val reviews = listOf(
        Review(
            id = "rev-1",
            productId = "uniqlo-465187",
            authorName = "Alexander M.",
            rating = 5,
            title = "The best basic t-shirt ever made",
            comment = "Holds its boxy shape perfectly after multiple cold washes. The AIRism fabric stays cool even under hot weather.",
            sizePurchased = "L",
            heightCm = 182,
            fitFeedback = FitFeedback.TRUE_TO_SIZE,
            dateText = "12 Oct 2026"
        ),
        Review(
            id = "rev-2",
            productId = "uniqlo-465187",
            authorName = "Kenji S.",
            rating = 5,
            title = "Extremely clean silhouette",
            comment = "Pairs easily with trousers or denim. Oversized fit is intentional and looks very high quality.",
            sizePurchased = "M",
            heightCm = 174,
            fitFeedback = FitFeedback.TRUE_TO_SIZE,
            dateText = "04 Oct 2026"
        )
    )
}
