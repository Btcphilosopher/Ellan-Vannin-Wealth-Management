package com.example.domain.model

enum class PreferredFit(val label: String) {
    SLIM("Slim Fit"),
    REGULAR("Regular Fit"),
    RELAXED("Relaxed Fit"),
    OVERSIZED("Oversized Fit")
}

data class SizeProfile(
    val heightCm: Int = 175,
    val weightKg: Int = 70,
    val chestCm: Int = 96,
    val waistCm: Int = 80,
    val hipCm: Int = 94,
    val shoulderCm: Int = 44,
    val inseamCm: Int = 78,
    val preferredFit: PreferredFit = PreferredFit.REGULAR,
    val knownSizes: Map<String, String> = mapOf("AIRism" to "M", "HEATTECH" to "M", "Jeans" to "31 inch")
)

data class SizeRecommendation(
    val recommendedSize: String,
    val confidenceScore: Int, // e.g. 92
    val fitNotes: String,
    val alternativeSize: String? = null,
    val alternativeNotes: String? = null
)
