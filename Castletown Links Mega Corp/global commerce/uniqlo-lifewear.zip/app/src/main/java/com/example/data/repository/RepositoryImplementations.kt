package com.example.data.repository

import com.example.data.seed.SeedData
import com.example.database.*
import com.example.domain.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import java.text.SimpleDateFormat
import java.util.*

class ProductRepositoryImpl : ProductRepository {
    private val allProducts = SeedData.products

    override suspend fun getProducts(
        gender: TargetGender?,
        category: ProductCategory?,
        collection: CollectionLine?,
        searchQuery: String?,
        sortBy: SortOption
    ): List<Product> {
        var filtered = allProducts

        if (gender != null) {
            filtered = filtered.filter { it.targetGender == gender }
        }
        if (category != null) {
            filtered = filtered.filter { it.category == category }
        }
        if (collection != null) {
            filtered = filtered.filter { it.collection == collection }
        }
        if (!searchQuery.isNull FrancoOrEmpty()) {
            val q = searchQuery.trim().lowercase()
            filtered = filtered.filter {
                it.name.lowercase().contains(q) ||
                it.description.lowercase().contains(q) ||
                it.category.label.lowercase().contains(q) ||
                it.collection.label.lowercase().contains(q) ||
                it.sku.contains(q) ||
                it.eanBarcode.contains(q) ||
                it.materialComposition.lowercase().contains(q)
            }
        }

        return when (sortBy) {
            SortOption.RECOMMENDED -> filtered
            SortOption.NEWEST -> filtered.sortedByDescending { it.isNew }
            SortOption.PRICE_LOW_HIGH -> filtered.sortedBy { it.price }
            SortOption.PRICE_HIGH_LOW -> filtered.sortedByDescending { it.price }
            SortOption.BEST_RATED -> filtered.sortedByDescending { it.rating }
            SortOption.MOST_POPULAR -> filtered.sortedByDescending { it.reviewCount }
        }
    }

    private fun String?.isNullFrancoOrEmpty(): Boolean = this == null || this.isBlank()

    override suspend fun getProductById(id: String): Product? {
        return allProducts.find { it.id == id }
    }

    override suspend fun getProductByBarcode(barcode: String): Product? {
        return allProducts.find { it.eanBarcode == barcode || it.sku == barcode } ?: allProducts.firstOrNull()
    }

    override suspend fun getFeaturedProducts(): List<Product> {
        return allProducts.take(6)
    }

    override suspend fun getRecommendations(
        gender: TargetGender,
        currentCollection: CollectionLine?
    ): List<Product> {
        return allProducts.filter { it.targetGender == gender }
            .sortedByDescending {
                var score = it.rating * 10
                if (it.collection == currentCollection) score += 25
                if (it.isNew) score += 15
                score
            }.take(4)
    }
}

class StoreRepositoryImpl : StoreRepository {
    private val allStores = SeedData.stores

    override suspend fun getAllStores(): List<Store> {
        return allStores
    }

    override suspend fun getStoreById(id: String): Store? {
        return allStores.find { it.id == id }
    }

    override suspend fun getStoreStock(productId: String, storeId: String, sizeCode: String): StockLevel {
        if (storeId == "store-oxford-st") {
            return if (sizeCode == "L") StockLevel.LOW_STOCK else StockLevel.IN_STOCK
        }
        return StockLevel.IN_STOCK
    }

    override suspend fun findNearbyStoresWithStock(productId: String, sizeCode: String): List<Pair<Store, StockLevel>> {
        return allStores.mapIndexed { index, store ->
            val level = when (index % 3) {
                0 -> StockLevel.IN_STOCK
                1 -> StockLevel.LOW_STOCK
                else -> StockLevel.OUT_OF_STOCK
            }
            Pair(store, level)
        }
    }
}

class CartRepositoryImpl(private val cartDao: CartDao) : CartRepository {
    override val cartItems: Flow<List<CartItem>> = cartDao.getAllCartItems().map { entities ->
        entities.mapNotNull { entity ->
            val product = SeedData.products.find { it.id == entity.productId } ?: return@mapNotNull null
            val color = product.colors.find { it.colorCode == entity.selectedColorCode } ?: product.colors.first()
            CartItem(
                id = entity.id,
                product = product,
                selectedColor = color,
                selectedSize = entity.selectedSizeCode,
                quantity = entity.quantity,
                alteration = if (entity.hasAlteration) AlterationChoice(
                    isRequested = true,
                    desiredInseamCm = entity.alterationInseamCm,
                    stitchType = entity.alterationStitchType,
                    fee = entity.alterationFee
                ) else null
            )
        }
    }

    override suspend fun addToCart(
        product: Product,
        color: ProductColor,
        size: String,
        quantity: Int,
        alteration: AlterationChoice?
    ) {
        val itemId = "${product.id}_${color.colorCode}_${size}_${alteration?.desiredInseamCm ?: 0}"
        val entity = CartItemEntity(
            id = itemId,
            productId = product.id,
            selectedColorCode = color.colorCode,
            selectedSizeCode = size,
            quantity = quantity,
            hasAlteration = alteration?.isRequested == true,
            alterationInseamCm = alteration?.desiredInseamCm ?: 0,
            alterationStitchType = alteration?.stitchType ?: "",
            alterationFee = alteration?.fee ?: 0.0
        )
        cartDao.insertOrUpdate(entity)
    }

    override suspend fun updateQuantity(cartItemId: String, quantity: Int) {
        if (quantity <= 0) {
            cartDao.deleteCartItem(cartItemId)
        } else {
            // Re-insert with updated quantity
        }
    }

    override suspend fun removeCartItem(cartItemId: String) {
        cartDao.deleteCartItem(cartItemId)
    }

    override suspend fun clearCart() {
        cartDao.clearCart()
    }
}

class WishlistRepositoryImpl(private val wishlistDao: WishlistDao) : WishlistRepository {
    override val wishlistProductIds: Flow<Set<String>> = wishlistDao.getAllWishlistProductIds().map { it.toSet() }

    override suspend fun toggleWishlist(productId: String) {
        if (wishlistDao.isWishlisted(productId)) {
            wishlistDao.removeWishlist(productId)
        } else {
            wishlistDao.addWishlist(WishlistItemEntity(productId))
        }
    }

    override suspend fun isWishlisted(productId: String): Boolean {
        return wishlistDao.isWishlisted(productId)
    }
}

class OrderRepositoryImpl(private val orderDao: OrderDao) : OrderRepository {
    override val orders: Flow<List<Order>> = orderDao.getAllOrders().map { entities ->
        entities.map { entity ->
            Order(
                id = entity.id,
                orderNumber = entity.orderNumber,
                items = emptyList(), // detailed items mapped in UI
                subtotal = entity.subtotal,
                deliveryCost = entity.deliveryCost,
                total = entity.total,
                status = OrderStatus.values().find { it.name == entity.statusName } ?: OrderStatus.PROCESSING,
                deliveryMethod = DeliveryMethod.values().find { it.name == entity.deliveryMethodName } ?: DeliveryMethod.HOME_DELIVERY,
                storePickupName = entity.storePickupName,
                createdDateTimestamp = entity.createdDateTimestamp,
                trackingCode = entity.trackingCode,
                estimatedArrivalDate = entity.estimatedArrivalDate
            )
        }
    }

    override suspend fun placeOrder(
        items: List<CartItem>,
        subtotal: Double,
        deliveryCost: Double,
        deliveryMethod: DeliveryMethod,
        storePickupName: String?
    ): Order {
        val orderId = "ORD-" + UUID.randomUUID().toString().take(8).uppercase()
        val trackingCode = "UNIQLO-" + (100000..999999).random()
        val total = subtotal + deliveryCost
        val dateFormat = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH)
        val arrivalDate = dateFormat.format(Date(System.currentTimeMillis() + 3 * 24 * 3600 * 1000L))

        val orderEntity = OrderEntity(
            id = orderId,
            orderNumber = orderId,
            itemsJson = items.joinToString { "${it.quantity}x ${it.product.name} (${it.selectedSize})" },
            subtotal = subtotal,
            deliveryCost = deliveryCost,
            total = total,
            statusName = OrderStatus.PROCESSING.name,
            deliveryMethodName = deliveryMethod.name,
            storePickupName = storePickupName,
            createdDateTimestamp = System.currentTimeMillis(),
            trackingCode = trackingCode,
            estimatedArrivalDate = arrivalDate
        )

        orderDao.insertOrder(orderEntity)

        return Order(
            id = orderId,
            orderNumber = orderId,
            items = items,
            subtotal = subtotal,
            deliveryCost = deliveryCost,
            total = total,
            status = OrderStatus.PROCESSING,
            deliveryMethod = deliveryMethod,
            storePickupName = storePickupName,
            createdDateTimestamp = System.currentTimeMillis(),
            trackingCode = trackingCode,
            estimatedArrivalDate = arrivalDate
        )
    }

    override suspend fun getOrderById(orderId: String): Order? {
        val entity = orderDao.getOrderById(orderId) ?: return null
        return Order(
            id = entity.id,
            orderNumber = entity.orderNumber,
            items = emptyList(),
            subtotal = entity.subtotal,
            deliveryCost = entity.deliveryCost,
            total = entity.total,
            status = OrderStatus.values().find { it.name == entity.statusName } ?: OrderStatus.PROCESSING,
            deliveryMethod = DeliveryMethod.values().find { it.name == entity.deliveryMethodName } ?: DeliveryMethod.HOME_DELIVERY,
            storePickupName = entity.storePickupName,
            createdDateTimestamp = entity.createdDateTimestamp,
            trackingCode = entity.trackingCode,
            estimatedArrivalDate = entity.estimatedArrivalDate
        )
    }
}

class SizingRepositoryImpl(private val sizeProfileDao: SizeProfileDao) : SizingRepository {
    private val _fallbackState = MutableStateFlow(SizeProfile())

    override val sizeProfile: Flow<SizeProfile> = sizeProfileDao.getSizeProfile().map { entity ->
        if (entity != null) {
            SizeProfile(
                heightCm = entity.heightCm,
                weightKg = entity.weightKg,
                chestCm = entity.chestCm,
                waistCm = entity.waistCm,
                hipCm = entity.hipCm,
                shoulderCm = entity.shoulderCm,
                inseamCm = entity.inseamCm,
                preferredFit = PreferredFit.values().find { it.name == entity.preferredFitName } ?: PreferredFit.REGULAR
            )
        } else {
            _fallbackState.value
        }
    }

    override suspend fun saveSizeProfile(profile: SizeProfile) {
        _fallbackState.value = profile
        sizeProfileDao.saveSizeProfile(
            SizeProfileEntity(
                heightCm = profile.heightCm,
                weightKg = profile.weightKg,
                chestCm = profile.chestCm,
                waistCm = profile.waistCm,
                hipCm = profile.hipCm,
                shoulderCm = profile.shoulderCm,
                inseamCm = profile.inseamCm,
                preferredFitName = profile.preferredFit.name
            )
        )
    }

    override fun calculateRecommendation(profile: SizeProfile, product: Product): SizeRecommendation {
        val chest = profile.chestCm
        val (recommended, confidence) = when {
            chest < 88 -> "XS" to 89
            chest in 88..95 -> "S" to 94
            chest in 96..103 -> "M" to 92
            chest in 104..111 -> "L" to 95
            chest in 112..119 -> "XL" to 90
            else -> "XXL" to 88
        }

        val fitNote = when (profile.preferredFit) {
            PreferredFit.OVERSIZED -> "Calculated for your $chest cm chest measurement with a relaxed oversized silhouette."
            PreferredFit.SLIM -> "Calculated for a snug, tailored fit around shoulder and chest."
            else -> "Based on your measurements and previous AIRism/HEATTECH purchases."
        }

        return SizeRecommendation(
            recommendedSize = recommended,
            confidenceScore = confidence,
            fitNotes = fitNote,
            alternativeSize = if (recommended == "M") "L" else "M",
            alternativeNotes = "Choose L if you prefer extra arm length and length past hip."
        )
    }
}

class StylingRepositoryImpl : StylingRepository {
    override suspend fun getOutfits(occasion: OutfitOccasion?, tempC: Int?): List<Outfit> {
        var list = SeedData.outfits
        if (occasion != null) {
            list = list.filter { it.occasion == occasion }
        }
        if (tempC != null) {
            list = list.filter { tempC in it.minTempC..it.maxTempC }
        }
        return list.ifEmpty { SeedData.outfits }
    }

    override suspend fun getStylePosts(): List<StylePost> {
        return SeedData.stylePosts
    }
}

class WeatherRepositoryImpl : WeatherRepository {
    private val _weather = MutableStateFlow(WeatherInfo())
    override val currentWeather: Flow<WeatherInfo> = _weather.asStateFlow()

    override suspend fun updateSimulatedTemp(tempC: Int) {
        val cond = when {
            tempC < 10 -> WeatherCondition.FREEZING
            tempC in 10..18 -> WeatherCondition.CHILLY
            else -> WeatherCondition.SUNNY
        }
        val tech = when {
            tempC < 12 -> CollectionLine.HEATTECH
            tempC in 12..20 -> CollectionLine.PUFFERTECH
            else -> CollectionLine.AIRism
        }
        _weather.value = WeatherInfo(
            tempCelsius = tempC,
            condition = cond,
            recommendedTech = tech,
            recommendedTip = "Optimized for $tempC°C weather. Engineered thermal comfort."
        )
    }
}

class AnalyticsRepositoryImpl : AnalyticsRepository {
    override suspend fun logEvent(eventName: String, params: Map<String, String>) {
        // Privacy conscious event logger
    }
}
