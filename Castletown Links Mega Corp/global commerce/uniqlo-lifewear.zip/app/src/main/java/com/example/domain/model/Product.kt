package com.example.domain.model

enum class TargetGender(val label: String) {
    WOMEN("WOMEN"),
    MEN("MEN"),
    KIDS("KIDS"),
    BABY("BABY")
}

enum class ProductCategory(val label: String) {
    OUTERWEAR("Outerwear"),
    T_SHIRTS("T-Shirts"),
    SWEATS_FLEECE("Sweats & Fleece"),
    SHIRTS_BLOUSES("Shirts & Blouses"),
    KNITWEAR("Knitwear"),
    TROUSERS_JEANS("Trousers & Jeans"),
    SHORTS("Shorts"),
    DRESSES_SKIRTS("Dresses & Skirts"),
    INNERWEAR("Innerwear & Underwear"),
    HEATTECH("HEATTECH"),
    AIRism("AIRism"),
    UT_GRAPHICS("UT Graphic T-Shirts"),
    ACCESSORIES("Accessories"),
    LOUNGEWEAR("Loungewear")
}

enum class CollectionLine(val label: String) {
    LIFEWEAR("LifeWear"),
    HEATTECH("HEATTECH"),
    AIRism("AIRism"),
    PUFFERTECH("PUFFERTECH"),
    LINEN("Linen"),
    UNIQLO_U("UNIQLO U"),
    UNIQLO_C("UNIQLO : C"),
    UT("UT Graphic T-Shirts"),
    JW_ANDERSON("JW ANDERSON"),
    SPORT_UTILITY("Sport Utility Wear")
}

enum class FitType(val label: String) {
    SLIM("Slim Fit"),
    REGULAR("Regular Fit"),
    RELAXED("Relaxed Fit"),
    OVERSIZED("Oversized Fit")
}

data class ProductColor(
    val name: String,
    val colorCode: String, // e.g. "00 WHITE"
    val hexValue: String,  // e.g. "#FFFFFF"
    val imageUrl: String
)

data class ProductSize(
    val code: String, // e.g. "XS", "S", "M", "L", "XL", "XXL"
    val isAvailable: Boolean = true,
    val stockQuantity: Int = 10
)

data class Product(
    val id: String,
    val sku: String,
    val name: String,
    val subName: String? = null,
    val targetGender: TargetGender,
    val category: ProductCategory,
    val collection: CollectionLine,
    val description: String,
    val price: Double,
    val originalPrice: Double? = null,
    val currency: String = "£",
    val colors: List<ProductColor>,
    val sizes: List<ProductSize>,
    val materialComposition: String,
    val careInstructions: String,
    val fitType: FitType,
    val rating: Double,
    val reviewCount: Int,
    val isNew: Boolean = false,
    val isSale: Boolean = false,
    val isExclusive: Boolean = false,
    val eanBarcode: String,
    val mainImageUrl: String,
    val galleryImages: List<String> = emptyList(),
    val supportsAlterations: Boolean = false
)
