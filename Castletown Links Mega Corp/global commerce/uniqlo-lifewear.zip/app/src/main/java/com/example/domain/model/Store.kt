package com.example.domain.model

enum class StockLevel(val label: String) {
    IN_STOCK("IN STOCK"),
    LOW_STOCK("LOW STOCK"),
    OUT_OF_STOCK("OUT OF STOCK"),
    ONLINE_ONLY("ONLINE ONLY")
}

enum class StoreService(val label: String) {
    CLICK_AND_COLLECT("Click & Collect"),
    PICK_UP_TODAY("Pick Up Today"),
    ALTERATIONS("Alterations"),
    RE_UNIQLO("RE.UNIQLO Studio"),
    UT_ME("UTme! Custom Printing"),
    MENSWEAR("Menswear"),
    WOMENSWEAR("Womenswear"),
    KIDS("Kids & Baby")
}

data class StoreInventoryItem(
    val storeId: String,
    val productId: String,
    val colorCode: String,
    val sizeCode: String,
    val stockLevel: StockLevel,
    val quantity: Int
)

data class Store(
    val id: String,
    val name: String,
    val city: String,
    val address: String,
    val postcode: String,
    val distanceKm: Double,
    val openingHours: String,
    val phoneNumber: String,
    val services: List<StoreService>,
    val lat: Double,
    val lng: Double
)
