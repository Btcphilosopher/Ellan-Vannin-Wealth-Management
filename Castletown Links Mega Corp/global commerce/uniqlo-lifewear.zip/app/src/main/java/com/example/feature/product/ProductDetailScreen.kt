package com.example.feature.product

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.designsystem.components.*
import com.example.domain.model.*
import com.example.feature.viewmodel.ProductDetailUiState
import com.example.ui.theme.*

@Composable
fun ProductDetailScreen(
    uiState: ProductDetailUiState,
    onColorSelect: (ProductColor) -> Unit,
    onSizeSelect: (String) -> Unit,
    onAlterationChange: (Int, String) -> Unit,
    onAddToCart: () -> Unit,
    onOpenSizeAssist: () -> Unit,
    onOpenStoreStock: () -> Unit,
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val product = uiState.product
    val scrollState = rememberScrollState()

    if (product == null) {
        Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = UniqloRed)
        }
        return
    }

    Scaffold(
        bottomBar = {
            Surface(
                shadowElevation = 8.dp,
                color = UniqloWhite,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .navigationBarsPadding()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "TOTAL PRICE",
                            style = MaterialTheme.typography.labelSmall,
                            color = UniqloMidGray
                        )
                        val alterationFee = if (uiState.alterationChoice.isRequested) uiState.alterationChoice.fee else 0.0
                        Text(
                            text = "${product.currency}${String.format("%.2f", product.price + alterationFee)}",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Black,
                            color = UniqloBlack
                        )
                    }

                    UniqloRedButton(
                        text = if (uiState.isAddedToBagSuccess) "ADDED TO BAG ✓" else "ADD TO BAG",
                        onClick = onAddToCart,
                        modifier = Modifier.width(200.dp),
                        icon = if (uiState.isAddedToBagSuccess) Icons.Default.CheckCircle else Icons.Outlined.ShoppingBag,
                        testTag = "add_to_bag_btn"
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(UniqloWhite)
                .verticalScroll(scrollState)
        ) {
            // Main Product Image Gallery
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(0.9f)
                    .background(UniqloSubtleGray)
            ) {
                AsyncImage(
                    model = uiState.selectedColor?.imageUrl ?: product.mainImageUrl,
                    contentDescription = product.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(12.dp)
                        .background(UniqloWhite.copy(alpha = 0.8f), CircleShape)
                ) {
                    Icon(imageVector = Icons.Outlined.ArrowBack, contentDescription = "Back", tint = UniqloBlack)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Title and Price Block
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                Text(
                    text = "${product.collection.label} / SKU: ${product.sku}".uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = UniqloMidGray,
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = product.name,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = UniqloBlack
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "${product.currency}${String.format("%.2f", product.price)}",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Black,
                        color = UniqloRed
                    )

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Filled.Star, contentDescription = null, tint = Color(0xFFFFB400), modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${product.rating} (${product.reviewCount} Reviews)",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = UniqloBlack
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = UniqloLightGray)
                Spacer(modifier = Modifier.height(16.dp))

                // Colour Swatches Section
                Text(
                    text = "COLOUR: ${uiState.selectedColor?.name ?: ""}".uppercase(),
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = UniqloBlack
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    product.colors.forEach { color ->
                        val isSelected = color == uiState.selectedColor
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(
                                    try {
                                        Color(android.graphics.Color.parseColor(color.hexValue))
                                    } catch (e: Exception) {
                                        UniqloDarkGray
                                    }
                                )
                                .border(
                                    width = if (isSelected) 2.dp else 0.5.dp,
                                    color = if (isSelected) UniqloRed else UniqloLightGray,
                                    shape = CircleShape
                                )
                                .clickable { onColorSelect(color) }
                        ) {
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = if (color.hexValue == "#FFFFFF") UniqloBlack else UniqloWhite,
                                    modifier = Modifier
                                        .size(16.dp)
                                        .align(Alignment.Center)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Size Grid & MySize Assist Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "SIZE: ${uiState.selectedSize}".uppercase(),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = UniqloBlack
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { onOpenSizeAssist() }
                    ) {
                        Icon(imageVector = Icons.Outlined.Straighten, contentDescription = null, tint = UniqloRed, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "FIND MY SIZE",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = UniqloRed,
                            letterSpacing = 0.5.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Size Options Row
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    product.sizes.forEach { size ->
                        val isSelected = size.code == uiState.selectedSize
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .background(if (isSelected) UniqloBlack else UniqloWhite)
                                .border(1.dp, if (isSelected) UniqloBlack else UniqloLightGray, RoundedCornerShape(2.dp))
                                .clickable { onSizeSelect(size.code) },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = size.code,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) UniqloWhite else UniqloBlack
                            )
                        }
                    }
                }

                // Sizing Recommendation Box
                if (uiState.sizeRecommendation != null) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(UniqloSubtleGray)
                            .padding(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .background(UniqloRed, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = uiState.sizeRecommendation.recommendedSize,
                                    color = UniqloWhite,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "RECOMMENDED SIZE: ${uiState.sizeRecommendation.recommendedSize} (${uiState.sizeRecommendation.confidenceScore}% CONFIDENCE)",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = UniqloBlack
                                )
                                Text(
                                    text = uiState.sizeRecommendation.fitNotes,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = UniqloDarkGray
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Store Stock Button
                UniqloOutlinedButton(
                    text = "CHECK STORE STOCK",
                    onClick = onOpenStoreStock,
                    icon = Icons.Outlined.Storefront,
                    testTag = "check_store_stock_btn"
                )

                // Alteration Option if supported
                if (product.supportsAlterations) {
                    Spacer(modifier = Modifier.height(20.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, UniqloLightGray)
                            .padding(14.dp)
                    ) {
                        Column {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "ALTERATION SERVICE",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = UniqloBlack
                                )

                                Switch(
                                    checked = uiState.alterationChoice.isRequested,
                                    onCheckedChange = { requested ->
                                        if (requested) onAlterationChange(74, "Normal Stitch (£3.00)")
                                        else onAlterationChange(0, "")
                                    },
                                    colors = SwitchDefaults.colors(checkedThumbColor = UniqloRed, checkedTrackColor = UniqloSubtleGray)
                                )
                            }

                            if (uiState.alterationChoice.isRequested) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Desired Inseam: ${uiState.alterationChoice.desiredInseamCm} cm (${uiState.alterationChoice.stitchType})",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = UniqloBlack
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
                HorizontalDivider(color = UniqloLightGray)
                Spacer(modifier = Modifier.height(16.dp))

                // Product Overview & Care
                Text(
                    text = "PRODUCT DESCRIPTION",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = UniqloBlack,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = product.description,
                    style = MaterialTheme.typography.bodyLarge,
                    color = UniqloCharcoal,
                    lineHeight = 22.sp
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "MATERIAL COMPOSITION",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = UniqloBlack
                )
                Text(
                    text = product.materialComposition,
                    style = MaterialTheme.typography.bodyMedium,
                    color = UniqloDarkGray
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "CARE INSTRUCTIONS",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = UniqloBlack
                )
                Text(
                    text = product.careInstructions,
                    style = MaterialTheme.typography.bodyMedium,
                    color = UniqloDarkGray
                )

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}
