package com.example.feature.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.*
import com.example.domain.model.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

// --- HomeViewModel ---
data class HomeUiState(
    val selectedGender: TargetGender = TargetGender.MEN,
    val featuredProducts: List<Product> = emptyList(),
    val recommendedProducts: List<Product> = emptyList(),
    val weatherInfo: WeatherInfo = WeatherInfo(),
    val isLoading: Boolean = false
)

class HomeViewModel(
    private val productRepo: ProductRepository,
    private val weatherRepo: WeatherRepository
) : ViewModel() {
    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    init {
        loadHomeData()
        viewModelScope.launch {
            weatherRepo.currentWeather.collect { weather ->
                _uiState.update { it.copy(weatherInfo = weather) }
            }
        }
    }

    fun selectGender(gender: TargetGender) {
        _uiState.update { it.copy(selectedGender = gender) }
        loadHomeData()
    }

    fun loadHomeData() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val featured = productRepo.getProducts(gender = _uiState.value.selectedGender)
            val recs = productRepo.getRecommendations(gender = _uiState.value.selectedGender)
            _uiState.update {
                it.copy(
                    featuredProducts = featured,
                    recommendedProducts = recs,
                    isLoading = false
                )
            }
        }
    }
}

// --- CatalogueViewModel ---
data class CatalogueUiState(
    val products: List<Product> = emptyList(),
    val selectedGender: TargetGender? = null,
    val selectedCategory: ProductCategory? = null,
    val selectedCollection: CollectionLine? = null,
    val searchQuery: String = "",
    val selectedSort: SortOption = SortOption.RECOMMENDED,
    val isLoading: Boolean = false
)

class CatalogueViewModel(
    private val productRepo: ProductRepository
) : ViewModel() {
    private val _uiState = MutableStateFlow(CatalogueUiState())
    val uiState: StateFlow<CatalogueUiState> = _uiState.asStateFlow()

    init {
        loadCatalogue()
    }

    fun setGender(gender: TargetGender?) {
        _uiState.update { it.copy(selectedGender = gender) }
        loadCatalogue()
    }

    fun setCategory(category: ProductCategory?) {
        _uiState.update { it.copy(selectedCategory = category) }
        loadCatalogue()
    }

    fun setCollection(collection: CollectionLine?) {
        _uiState.update { it.copy(selectedCollection = collection) }
        loadCatalogue()
    }

    fun setSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
        loadCatalogue()
    }

    fun setSort(sort: SortOption) {
        _uiState.update { it.copy(selectedSort = sort) }
        loadCatalogue()
    }

    fun loadCatalogue() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val results = productRepo.getProducts(
                gender = _uiState.value.selectedGender,
                category = _uiState.value.selectedCategory,
                collection = _uiState.value.selectedCollection,
                searchQuery = _uiState.value.searchQuery,
                sortBy = _uiState.value.selectedSort
            )
            _uiState.update { it.copy(products = results, isLoading = false) }
        }
    }
}

// --- ProductDetailViewModel ---
data class ProductDetailUiState(
    val product: Product? = null,
    val selectedColor: ProductColor? = null,
    val selectedSize: String = "M",
    val storeStockList: List<Pair<Store, StockLevel>> = emptyList(),
    val sizeRecommendation: SizeRecommendation? = null,
    val alterationChoice: AlterationChoice = AlterationChoice(),
    val isAddedToBagSuccess: Boolean = false,
    val isLoading: Boolean = false
)

class ProductDetailViewModel(
    private val productRepo: ProductRepository,
    private val storeRepo: StoreRepository,
    private val sizingRepo: SizingRepository,
    private val cartRepo: CartRepository
) : ViewModel() {
    private val _uiState = MutableStateFlow(ProductDetailUiState())
    val uiState: StateFlow<ProductDetailUiState> = _uiState.asStateFlow()

    fun loadProduct(productId: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val p = productRepo.getProductById(productId)
            if (p != null) {
                val stock = storeRepo.findNearbyStoresWithStock(p.id, _uiState.value.selectedSize)
                val sizeRec = sizingRepo.calculateRecommendation(SizeProfile(), p)
                _uiState.update {
                    it.copy(
                        product = p,
                        selectedColor = p.colors.firstOrNull(),
                        storeStockList = stock,
                        sizeRecommendation = sizeRec,
                        isLoading = false
                    )
                }
            }
        }
    }

    fun selectColor(color: ProductColor) {
        _uiState.update { it.copy(selectedColor = color) }
    }

    fun selectSize(size: String) {
        _uiState.update { it.copy(selectedSize = size) }
        val p = _uiState.value.product
        if (p != null) {
            viewModelScope.launch {
                val stock = storeRepo.findNearbyStoresWithStock(p.id, size)
                _uiState.update { it.copy(storeStockList = stock) }
            }
        }
    }

    fun updateAlteration(inseamCm: Int, stitchType: String) {
        _uiState.update {
            it.copy(
                alterationChoice = AlterationChoice(
                    isRequested = true,
                    desiredInseamCm = inseamCm,
                    stitchType = stitchType,
                    fee = if (stitchType.contains("3.00")) 3.00 else 5.00
                )
            )
        }
    }

    fun addToBag() {
        val p = _uiState.value.product ?: return
        val c = _uiState.value.selectedColor ?: p.colors.first()
        viewModelScope.launch {
            cartRepo.addToCart(
                product = p,
                color = c,
                size = _uiState.value.selectedSize,
                quantity = 1,
                alteration = if (_uiState.value.alterationChoice.isRequested) _uiState.value.alterationChoice else null
            )
            _uiState.update { it.copy(isAddedToBagSuccess = true) }
        }
    }

    fun resetBagSuccess() {
        _uiState.update { it.copy(isAddedToBagSuccess = false) }
    }
}

// --- CartViewModel ---
data class CartUiState(
    val cartItems: List<CartItem> = emptyList(),
    val subtotal: Double = 0.0,
    val deliveryCost: Double = 3.95,
    val selectedDeliveryMethod: DeliveryMethod = DeliveryMethod.HOME_DELIVERY,
    val selectedStorePickupName: String? = null,
    val isOrderPlacedSuccess: Boolean = false,
    val lastPlacedOrder: Order? = null
)

class CartViewModel(
    private val cartRepo: CartRepository,
    private val orderRepo: OrderRepository
) : ViewModel() {
    private val _uiState = MutableStateFlow(CartUiState())
    val uiState: StateFlow<CartUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            cartRepo.cartItems.collect { items ->
                val sub = items.sumOf { (it.product.price + (it.alteration?.fee ?: 0.0)) * it.quantity }
                _uiState.update {
                    it.copy(
                        cartItems = items,
                        subtotal = sub
                    )
                }
            }
        }
    }

    fun setDeliveryMethod(method: DeliveryMethod, storeName: String? = null) {
        _uiState.update {
            it.copy(
                selectedDeliveryMethod = method,
                deliveryCost = method.price,
                selectedStorePickupName = storeName
            )
        }
    }

    fun removeItem(cartItemId: String) {
        viewModelScope.launch { cartRepo.removeCartItem(cartItemId) }
    }

    fun checkout() {
        val items = _uiState.value.cartItems
        if (items.isEmpty()) return
        viewModelScope.launch {
            val order = orderRepo.placeOrder(
                items = items,
                subtotal = _uiState.value.subtotal,
                deliveryCost = _uiState.value.deliveryCost,
                deliveryMethod = _uiState.value.selectedDeliveryMethod,
                storePickupName = _uiState.value.selectedStorePickupName
            )
            cartRepo.clearCart()
            _uiState.update {
                it.copy(
                    isOrderPlacedSuccess = true,
                    lastPlacedOrder = order
                )
            }
        }
    }

    fun resetOrderSuccess() {
        _uiState.update { it.copy(isOrderPlacedSuccess = false) }
    }
}
