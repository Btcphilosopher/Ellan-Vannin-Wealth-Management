import React, { useState } from 'react';
import { MainSimulation } from '../simulation/mainSimulation';
import { Language } from '../types';
import { translations } from '../i18n/translations';
import { Globe2, ArrowRightLeft, ShieldCheck, CheckCircle2 } from 'lucide-react';

interface NordicViewProps {
  sim: MainSimulation;
  lang: Language;
}

export const NordicView: React.FC<NordicViewProps> = ({ sim, lang }) => {
  const t = translations[lang];

  const [sourceCountry, setSourceCountry] = useState<string>('DK');
  const [targetCountry, setTargetCountry] = useState<string>('SE');
  const [sourceAmount, setSourceAmount] = useState<number>(10000000); // 10M
  const [fxResult, setFxResult] = useState<any>(null);

  const countries = sim.nordic.getCountries();

  const handleSimulateCrossBorder = () => {
    const res = sim.nordic.simulateCrossBorderPayment({
      sourceCountry,
      targetCountry,
      amountSourceCurrency: sourceAmount
    });
    setFxResult(res);
  };

  return (
    <div className="space-y-4 font-mono text-xs">
      {/* Nordic Payment Infrastructure Network */}
      <div className="bg-[#141619] border border-[#2d3238] rounded-xs p-4 space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-[#2b3036]">
          <div className="flex items-center gap-2">
            <Globe2 className="w-4 h-4 text-[#c1121f]" />
            <h2 className="text-sm font-bold text-white uppercase tracking-wider">
              NORDIC & EUROPEAN CROSS-BORDER PAYMENT NETWORK
            </h2>
          </div>
          <span className="text-[10px] text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded-xs border border-emerald-800">
            TIPS DKK / RIX-INST / TARGET2 INTEGRATION
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {countries.map(c => (
            <div key={c.code} className="p-3 bg-[#1a1d21] border border-[#2d3238] rounded-xs space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-white text-xs">{c.name}</span>
                <span className="text-[10px] text-emerald-400 font-bold">{c.currency}</span>
              </div>
              <div className="text-[11px] text-[#a0aab2] space-y-0.5">
                <div>Central Bank: <span className="text-white">{c.central_bank}</span></div>
                <div>Instant System: <span className="text-white">{c.instant_network}</span></div>
                <div>FX Rate to DKK: <span className="text-emerald-400 font-mono">1 {c.currency} = {c.fx_rate_to_dkk} DKK</span></div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Cross-Currency Atomic PvP Simulator */}
      <div className="bg-[#141619] border border-[#2d3238] rounded-xs p-4 space-y-3">
        <div className="flex items-center gap-2 pb-2 border-b border-[#2b3036]">
          <ArrowRightLeft className="w-4 h-4 text-emerald-400" />
          <h3 className="text-xs font-bold text-white uppercase tracking-wider">
            ATOMIC PAYMENT-VERSUS-PAYMENT (PvP) CROSS-CURRENCY ENGINE
          </h3>
        </div>

        <div className="bg-[#1a1d21] p-3 border border-[#2d3238] rounded-xs space-y-3">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <label className="block text-[10px] text-[#a0aab2] mb-1">Source Country / Currency:</label>
              <select
                value={sourceCountry}
                onChange={e => setSourceCountry(e.target.value)}
                className="w-full bg-[#212529] text-white border border-[#343a40] px-2 py-1 rounded-xs text-xs font-mono"
              >
                {countries.map(c => (
                  <option key={c.code} value={c.code}>{c.name} ({c.currency})</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[10px] text-[#a0aab2] mb-1">Destination Country / Currency:</label>
              <select
                value={targetCountry}
                onChange={e => setTargetCountry(e.target.value)}
                className="w-full bg-[#212529] text-white border border-[#343a40] px-2 py-1 rounded-xs text-xs font-mono"
              >
                {countries.map(c => (
                  <option key={c.code} value={c.code}>{c.name} ({c.currency})</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[10px] text-[#a0aab2] mb-1">Source Amount:</label>
              <input
                type="number"
                value={sourceAmount}
                onChange={e => setSourceAmount(Number(e.target.value))}
                className="w-full bg-[#212529] text-white border border-[#343a40] px-2 py-1 rounded-xs text-xs font-mono"
              />
            </div>
          </div>

          <button
            onClick={handleSimulateCrossBorder}
            className="w-full bg-[#1d3557] hover:bg-[#152741] text-white font-bold px-4 py-2 rounded-xs transition-colors text-xs flex items-center justify-center gap-2"
          >
            <ArrowRightLeft className="w-4 h-4" /> Execute Atomic PvP Cross-Border Settlement
          </button>

          {fxResult && (
            <div className="p-3 bg-emerald-950/60 border border-emerald-800 rounded-xs space-y-2 text-emerald-300">
              <div className="flex items-center justify-between font-bold text-xs pb-1 border-b border-emerald-900">
                <span className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  STATUS: {fxResult.status}
                </span>
                <span>LATENCY: {fxResult.estimatedLatencyMs} ms</span>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-[11px] pt-1">
                <div>Source: <strong className="text-white">{fxResult.sourceAmount.toLocaleString('da-DK')} {fxResult.sourceCurrency}</strong></div>
                <div>Target Received: <strong className="text-white">{fxResult.targetAmount.toLocaleString('da-DK')} {fxResult.targetCurrency}</strong></div>
                <div>Synthetic FX Rate: <strong className="text-white">{fxResult.fxRate}</strong></div>
                <div>Required Liquidity: <strong className="text-white">DKK {fxResult.liquidityRequiredDKK.toLocaleString('da-DK')}</strong></div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
