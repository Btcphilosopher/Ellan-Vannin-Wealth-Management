import React, { useState } from 'react';
import { MainSimulation } from '../simulation/mainSimulation';
import { Language } from '../types';
import { translations } from '../i18n/translations';
import { FlaskConical, Shield, Smartphone, AlertTriangle, Cpu, Layers } from 'lucide-react';

interface ResearchLabsViewProps {
  sim: MainSimulation;
  lang: Language;
  activeSubView: string;
}

export const ResearchLabsView: React.FC<ResearchLabsViewProps> = ({
  sim,
  lang,
  activeSubView
}) => {
  const t = translations[lang];

  // Holding Limits Lab State
  const [holdingLimitOption, setHoldingLimitOption] = useState<number>(sim.macro.holding_limit_citizen);

  // Offline Lab State
  const [offlineAmt, setOfflineAmt] = useState<number>(350);
  const [doubleSpendTest, setDoubleSpendTest] = useState<boolean>(false);
  const [offlineResult, setOfflineResult] = useState<any>(null);

  // Privacy Lab State
  const [privacyMode, setPrivacyMode] = useState<'HIGH_PRIVACY' | 'BALANCED' | 'HIGH_TRACEABILITY'>('BALANCED');

  // Resilience Outage State
  const [outageType, setOutageType] = useState<any>('INSTANT_PAYMENT_OUTAGE');
  const [outageSeverity, setOutageSeverity] = useState<number>(75);

  const handleApplyHoldingLimit = (limit: number) => {
    setHoldingLimitOption(limit);
    sim.updateHoldingLimit(limit);
  };

  const handleSimulateOffline = () => {
    const res = sim.offline.simulateOfflinePayment({
      senderDevice: 'SECURE_ELEMENT_DK_7801',
      receiverDevice: 'POS_TERMINAL_DK_9942',
      amount: offlineAmt,
      simulateDoubleSpend: doubleSpendTest
    });
    setOfflineResult(res);
  };

  const handleTriggerOutage = () => {
    sim.resilience.triggerOutage(outageType, outageSeverity);
  };

  const handleResolveOutage = () => {
    sim.resilience.resolveOutage();
  };

  const activeOutage = sim.resilience.getActiveScenario();
  const privacyConfigs = sim.privacy.getPrivacyConfigs();

  return (
    <div className="space-y-4 font-mono text-xs">
      {/* 1. HOLDING LIMITS LAB */}
      {(activeSubView === 'research_holding_limits' || activeSubView === 'research_main') && (
        <div className="bg-[#141619] border border-[#2d3238] rounded-xs p-4 space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-[#2b3036]">
            <div className="flex items-center gap-2">
              <FlaskConical className="w-4 h-4 text-[#c1121f]" />
              <h2 className="text-sm font-bold text-white uppercase tracking-wider">
                CBDC HOLDING LIMITS RESEARCH LAB
              </h2>
            </div>
            <span className="text-[10px] text-amber-400 bg-amber-950/80 px-2 py-0.5 rounded-xs border border-amber-800">
              SYNTHETIC RESEARCH PARAMETER
            </span>
          </div>

          <p className="text-[11px] text-[#a0aab2]">
            Test how citizen holding limits alter total bank deposit substitution, central bank balance sheet size, and transaction liquidity.
          </p>

          <div className="flex flex-wrap items-center gap-2 pt-2">
            {[0, 5000, 10000, 30000, 100000, 999999999].map(limit => (
              <button
                key={limit}
                onClick={() => handleApplyHoldingLimit(limit)}
                className={`px-3 py-1.5 rounded-xs border font-bold text-xs transition-colors ${
                  holdingLimitOption === limit
                    ? 'bg-[#c1121f] text-white border-white'
                    : 'bg-[#1a1d21] text-[#a0aab2] border-[#343a40] hover:text-white'
                }`}
              >
                {limit === 0 ? 'DKK 0 (No Retail)' : limit > 1000000 ? 'UNLIMITED' : `DKK ${limit.toLocaleString('da-DK')}`}
              </button>
            ))}
          </div>

          <div className="p-3 bg-[#1a1d21] border border-[#2d3238] rounded-xs space-y-2 text-[11px]">
            <div className="flex justify-between">
              <span className="text-[#a0aab2]">Active Holding Limit:</span>
              <strong className="text-white">
                {holdingLimitOption > 1000000 ? 'UNLIMITED' : `DKK ${holdingLimitOption.toLocaleString('da-DK')}`}
              </strong>
            </div>
            <div className="flex justify-between">
              <span className="text-[#a0aab2]">Estimated Bank Deposit Flight:</span>
              <strong className="text-amber-400">
                {holdingLimitOption === 0 ? '0.0%' : holdingLimitOption <= 10000 ? '1.8%' : holdingLimitOption <= 30000 ? '5.4%' : '18.2%'}
              </strong>
            </div>
          </div>
        </div>
      )}

      {/* 2. PRIVACY LAB */}
      {(activeSubView === 'research_privacy') && (
        <div className="bg-[#141619] border border-[#2d3238] rounded-xs p-4 space-y-3">
          <div className="flex items-center gap-2 pb-2 border-b border-[#2b3036]">
            <Shield className="w-4 h-4 text-emerald-400" />
            <h2 className="text-sm font-bold text-white uppercase tracking-wider">
              PRIVACY & ANONYMITY ARCHITECTURE LAB
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {(Object.keys(privacyConfigs) as (keyof typeof privacyConfigs)[]).map(mode => {
              const cfg = privacyConfigs[mode];
              const isSelected = privacyMode === mode;

              return (
                <div
                  key={mode}
                  onClick={() => setPrivacyMode(mode)}
                  className={`p-3 rounded-xs border cursor-pointer transition-all ${
                    isSelected ? 'bg-[#1a1d21] border-[#c1121f]' : 'bg-[#141619] border-[#2b3036]'
                  }`}
                >
                  <span className="font-bold text-white text-xs block mb-2">{mode}</span>
                  <div className="space-y-1 text-[10px] text-[#a0aab2]">
                    <div>CB Visibility: <span className="text-white">{cfg.central_bank_visibility}</span></div>
                    <div>Zero-Knowledge Proofs: <span className="text-emerald-400">{cfg.zero_knowledge_proofs ? 'YES' : 'NO'}</span></div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 3. OFFLINE LAB */}
      {(activeSubView === 'research_offline_lab') && (
        <div className="bg-[#141619] border border-[#2d3238] rounded-xs p-4 space-y-3">
          <div className="flex items-center gap-2 pb-2 border-b border-[#2b3036]">
            <Smartphone className="w-4 h-4 text-emerald-400" />
            <h2 className="text-sm font-bold text-white uppercase tracking-wider">
              OFFLINE DIGITAL KRONE RESEARCH LABORATORY
            </h2>
          </div>

          <p className="text-[11px] text-[#a0aab2]">
            Danmarks Nationalbank and the BIS Innovation Hub Nordic Centre have specifically investigated offline CBDC transactions via hardware Secure Elements.
          </p>

          <div className="bg-[#1a1d21] p-3 border border-[#2d3238] rounded-xs space-y-3">
            <div className="flex flex-wrap items-center gap-3">
              <div>
                <label className="block text-[10px] text-[#a0aab2] mb-1">Offline Tx Amount (DKK):</label>
                <input
                  type="number"
                  value={offlineAmt}
                  onChange={e => setOfflineAmt(Number(e.target.value))}
                  className="bg-[#212529] text-white border border-[#343a40] px-2 py-1 rounded-xs text-xs font-mono w-32"
                />
              </div>

              <label className="flex items-center gap-2 text-xs text-[#a0aab2] cursor-pointer pt-4">
                <input
                  type="checkbox"
                  checked={doubleSpendTest}
                  onChange={e => setDoubleSpendTest(e.target.checked)}
                  className="accent-[#c1121f]"
                />
                <span className="text-amber-400 font-bold">Simulate Counter Reuse (Double-Spend Attack)</span>
              </label>

              <button
                onClick={handleSimulateOffline}
                className="bg-[#c1121f] hover:bg-[#a00f1a] text-white font-bold px-4 py-1.5 rounded-xs transition-colors text-xs ml-auto mt-4"
              >
                Execute Hardware D2D Payment
              </button>
            </div>

            {offlineResult && (
              <div className={`p-3 border rounded-xs ${offlineResult.success ? 'bg-emerald-950/60 border-emerald-800 text-emerald-300' : 'bg-red-950/60 border-red-800 text-red-300'}`}>
                <div className="font-bold text-xs mb-1">{offlineResult.message}</div>
                <div className="text-[10px] font-mono">
                  Device Counter Sequence: #{offlineResult.transaction.counter_seq} | Signature: {offlineResult.transaction.signature}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 4. RESILIENCE LAB */}
      {(activeSubView === 'research_resilience_lab') && (
        <div className="bg-[#141619] border border-[#2d3238] rounded-xs p-4 space-y-3">
          <div className="flex items-center gap-2 pb-2 border-b border-[#2b3036]">
            <AlertTriangle className="w-4 h-4 text-amber-500" />
            <h2 className="text-sm font-bold text-white uppercase tracking-wider">
              OPERATIONAL RESILIENCE & OUTAGE LAB
            </h2>
          </div>

          <div className="bg-[#1a1d21] p-3 border border-[#2d3238] rounded-xs space-y-3">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <label className="block text-[10px] text-[#a0aab2] mb-1">Outage Type:</label>
                <select
                  value={outageType}
                  onChange={e => setOutageType(e.target.value)}
                  className="w-full bg-[#212529] text-white border border-[#343a40] px-2 py-1 rounded-xs text-xs font-mono"
                >
                  <option value="CARD_OUTAGE">Dankort / Card Network Outage</option>
                  <option value="INSTANT_PAYMENT_OUTAGE">Straksclearing / Kronos2 Outage</option>
                  <option value="DLT_OUTAGE">Wholesale DLT Consensus Partition</option>
                  <option value="CENTRAL_LEDGER_OUTAGE">Central Bank Core Ledger Failover</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] text-[#a0aab2] mb-1">Severity (%):</label>
                <input
                  type="range"
                  min="20"
                  max="100"
                  value={outageSeverity}
                  onChange={e => setOutageSeverity(Number(e.target.value))}
                  className="w-full accent-[#c1121f]"
                />
              </div>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={handleTriggerOutage}
                className="bg-red-800 hover:bg-red-700 text-white font-bold px-4 py-1.5 rounded-xs transition-colors text-xs"
              >
                Trigger Operational Outage Scenario
              </button>
              <button
                onClick={handleResolveOutage}
                className="bg-[#1d3557] hover:bg-[#152741] text-white font-bold px-4 py-1.5 rounded-xs transition-colors text-xs"
              >
                Restore Normal Operations
              </button>
            </div>

            {activeOutage.active && (
              <div className="p-3 bg-red-950/60 border border-red-800 rounded-xs text-red-300 text-xs font-mono">
                <strong>OUTAGE ACTIVE:</strong> {activeOutage.name} | Queue Backlog: {activeOutage.queue_length.toLocaleString('da-DK')} Txs | Est. Recovery: {activeOutage.estimated_recovery_minutes} Minutes
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
