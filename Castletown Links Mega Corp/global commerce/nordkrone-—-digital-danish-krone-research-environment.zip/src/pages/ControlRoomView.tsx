import React, { useState } from 'react';
import { MainSimulation } from '../simulation/mainSimulation';
import { Language } from '../types';
import { translations } from '../i18n/translations';
import { Terminal, MapPin, Cpu, Activity, Layers, ArrowRight, ShieldCheck } from 'lucide-react';

interface ControlRoomViewProps {
  sim: MainSimulation;
  lang: Language;
  activeSubView: string;
}

export const ControlRoomView: React.FC<ControlRoomViewProps> = ({
  sim,
  lang,
  activeSubView
}) => {
  const t = translations[lang];

  // CLI Terminal State
  const [cliInput, setCliInput] = useState<string>('');
  const [cliLogs, setCliLogs] = useState<{ cmd: string; output: string; status: string }[]>([
    {
      cmd: 'nordkrone status',
      output: `[NORDKRONE DIGITAL TWIN STATUS]\nSystem Status: NOMINAL | Ledger: SYNCHRONISED | Seed: 2026`,
      status: 'SUCCESS'
    }
  ]);

  // Interactive Architecture Diagram Selection State
  const [selectedArchStep, setSelectedArchStep] = useState<string>('CB_MONEY');

  const handleCliSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!cliInput.trim()) return;

    const res = sim.cli.executeCommand(cliInput);
    setCliLogs(prev => [...prev, { cmd: cliInput, output: res.output, status: res.status }]);
    setCliInput('');
  };

  const anomalyModel = sim.ml.getPaymentAnomalyModelStats();
  const liquidityModel = sim.ml.getLiquidityForecastModelStats();
  const adoptionModel = sim.ml.getCBDCAdoptionModelStats();

  const archSteps = [
    { id: 'USER', label: '1. Citizen / Merchant', desc: 'Synthetic end-users initiating payments via Mobile / POS terminal.' },
    { id: 'WALLET', label: '2. Digital Wallet', desc: 'Secure Element hardware / cloud wallet with holding & daily limits.' },
    { id: 'PSP', label: '3. Payment Provider', desc: 'Licensed Danish payment institution providing onboarding & KYC.' },
    { id: 'BANK', label: '4. Commercial Bank', desc: 'Danske Bank, Nordea, Jyske, Nykredit commercial balance sheet interface.' },
    { id: 'INSTANT_NET', label: '5. Straksclearing / TIPS', desc: 'Instant payment clearing gateway connected to European infrastructure.' },
    { id: 'WHOLESALE', label: '6. Wholesale DLT', desc: 'Atomic DvP & PvP settlement ledger operated by central bank validators.' },
    { id: 'CB_MONEY', label: '7. Danmarks Nationalbank', desc: 'Central bank issuing DKK-Digital reserve money and underlying liability.' }
  ];

  return (
    <div className="space-y-4 font-mono text-xs">
      {/* Sub-view switcher tabs inside Control Room */}
      <div className="flex flex-wrap items-center gap-2 pb-2 border-b border-[#2d3238]">
        <span className="text-xs font-bold text-white uppercase flex items-center gap-1">
          <Activity className="w-4 h-4 text-[#c1121f]" /> CONTROL ROOM WORKSTATION:
        </span>
      </div>

      {/* 1. INTERACTIVE TERMINAL / CLI */}
      {(activeSubView === 'control_terminal' || activeSubView === 'control_main') && (
        <div className="bg-[#0f1114] border border-[#2d3238] rounded-xs p-4 font-mono space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-[#25292e]">
            <div className="flex items-center gap-2">
              <Terminal className="w-4 h-4 text-emerald-400" />
              <h2 className="text-xs font-bold text-white uppercase tracking-wider">
                NORDKRONE COMMAND LINE TERMINAL (CLI)
              </h2>
            </div>
            <span className="text-[10px] text-[#a0aab2]">
              Type <code className="text-emerald-400 font-bold">help</code> to list available commands
            </span>
          </div>

          <div className="bg-[#0a0b0d] p-3 rounded-xs border border-[#1e2227] h-64 overflow-y-auto space-y-3 font-mono text-xs">
            {cliLogs.map((log, idx) => (
              <div key={idx} className="space-y-1">
                <div className="flex items-center gap-2 text-emerald-400 font-bold">
                  <span>nordkrone-cli&gt;</span>
                  <span className="text-white">{log.cmd}</span>
                </div>
                <pre className="text-[11px] text-[#c2cad0] bg-[#121417] p-2 rounded-xs border border-[#212529] whitespace-pre-wrap font-mono">
                  {log.output}
                </pre>
              </div>
            ))}
          </div>

          <form onSubmit={handleCliSubmit} className="flex items-center gap-2">
            <span className="text-emerald-400 font-bold">nordkrone-cli&gt;</span>
            <input
              type="text"
              value={cliInput}
              onChange={e => setCliInput(e.target.value)}
              placeholder="e.g. nordkrone status, cbdc supply, payment simulate 500, bond settle..."
              className="flex-1 bg-[#16181c] text-white border border-[#343a40] px-3 py-1.5 rounded-xs text-xs font-mono focus:border-emerald-500 outline-none"
            />
            <button
              type="submit"
              className="bg-[#c1121f] hover:bg-[#a00f1a] text-white font-bold px-4 py-1.5 rounded-xs transition-colors text-xs"
            >
              EXECUTE
            </button>
          </form>
        </div>
      )}

      {/* 2. INTERACTIVE DENMARK GIS MAP */}
      {(activeSubView === 'control_gis') && (
        <div className="bg-[#141619] border border-[#2d3238] rounded-xs p-4 space-y-3">
          <div className="flex items-center gap-2 pb-2 border-b border-[#2b3036]">
            <MapPin className="w-4 h-4 text-[#c1121f]" />
            <h2 className="text-sm font-bold text-white uppercase tracking-wider">
              INTERACTIVE DENMARK PAYMENT MAP & NETWORK NODES
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {sim.mapNodes.map(node => (
              <div key={node.id} className="p-3 bg-[#1a1d21] border border-[#2d3238] rounded-xs space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white text-xs">{node.city}</span>
                  <span className="text-[9px] bg-emerald-950/80 text-emerald-400 px-1.5 py-0.2 rounded-xs border border-emerald-800 font-bold">
                    {node.status}
                  </span>
                </div>
                <div className="text-[11px] text-[#a0aab2] space-y-0.5">
                  <div>24h Retail: <span className="text-white">DKK {(node.retail_volume_24h / 1e6).toFixed(1)}M</span></div>
                  <div>24h Wholesale: <span className="text-white">DKK {(node.wholesale_volume_24h / 1e9).toFixed(2)}B</span></div>
                  <div>Active Wallets: <span className="text-white">{node.active_wallets.toLocaleString('da-DK')}</span></div>
                  <div>Latency: <span className="text-emerald-400 font-bold">{node.latency_ms} ms</span></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 3. TECHNICAL ARCHITECTURE VIEW */}
      {(activeSubView === 'overview_arch') && (
        <div className="bg-[#141619] border border-[#2d3238] rounded-xs p-4 space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-[#2b3036]">
            <Layers className="w-4 h-4 text-emerald-400" />
            <h2 className="text-sm font-bold text-white uppercase tracking-wider">
              TECHNICAL ARCHITECTURE — RETAIL & WHOLESALE MONEY FLOW
            </h2>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-2 overflow-x-auto p-2 bg-[#1a1d21] border border-[#2d3238] rounded-xs">
            {archSteps.map((step, idx) => (
              <React.Fragment key={step.id}>
                <button
                  onClick={() => setSelectedArchStep(step.id)}
                  className={`p-2 rounded-xs border text-center transition-all min-w-[120px] ${
                    selectedArchStep === step.id
                      ? 'bg-[#c1121f] text-white border-white font-bold'
                      : 'bg-[#212529] text-[#c2cad0] border-[#343a40] hover:text-white'
                  }`}
                >
                  <div className="text-[11px] uppercase truncate">{step.label}</div>
                </button>
                {idx < archSteps.length - 1 && (
                  <ArrowRight className="w-4 h-4 text-[#808d98] shrink-0" />
                )}
              </React.Fragment>
            ))}
          </div>

          {selectedArchStep && (
            <div className="p-3 bg-[#1a1d21] border border-[#2d3238] rounded-xs text-xs space-y-1">
              <h4 className="font-bold text-emerald-400 uppercase">
                {archSteps.find(s => s.id === selectedArchStep)?.label}
              </h4>
              <p className="text-[#c2cad0]">
                {archSteps.find(s => s.id === selectedArchStep)?.desc}
              </p>
            </div>
          )}
        </div>
      )}

      {/* 4. MACHINE LEARNING LAB */}
      {(activeSubView === 'control_ml') && (
        <div className="bg-[#141619] border border-[#2d3238] rounded-xs p-4 space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-[#2b3036]">
            <Cpu className="w-4 h-4 text-[#c1121f]" />
            <h2 className="text-sm font-bold text-white uppercase tracking-wider">
              MACHINE LEARNING & QUANTITATIVE MODELS LAB
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Payment Anomaly Model */}
            <div className="bg-[#1a1d21] border border-[#2d3238] rounded-xs p-3 space-y-2">
              <div className="flex items-center justify-between border-b border-[#2b3036] pb-1">
                <span className="font-bold text-white text-xs">{anomalyModel.model_name}</span>
                <span className="text-[9px] bg-emerald-950 text-emerald-400 px-1.5 py-0.2 rounded-xs border border-emerald-800">
                  {anomalyModel.version}
                </span>
              </div>
              <p className="text-[10px] text-[#a0aab2]">{anomalyModel.prediction_summary}</p>
              <div className="text-[10px] space-y-1 pt-2 border-t border-[#25292e]">
                <div className="font-bold text-white">Feature Importance:</div>
                {anomalyModel.feature_importance.map((f, i) => (
                  <div key={i} className="flex justify-between text-[#a0aab2]">
                    <span>{f.feature}:</span>
                    <span className="text-emerald-400 font-bold">{(f.importance * 100).toFixed(0)}%</span>
                  </div>
                ))}
              </div>
              <div className="text-[9px] text-amber-500 font-semibold pt-1">
                {anomalyModel.limitations_disclaimer}
              </div>
            </div>

            {/* Liquidity Forecast Model */}
            <div className="bg-[#1a1d21] border border-[#2d3238] rounded-xs p-3 space-y-2">
              <div className="flex items-center justify-between border-b border-[#2b3036] pb-1">
                <span className="font-bold text-white text-xs">{liquidityModel.model_name}</span>
                <span className="text-[9px] bg-blue-950 text-blue-400 px-1.5 py-0.2 rounded-xs border border-blue-800">
                  {liquidityModel.version}
                </span>
              </div>
              <p className="text-[10px] text-[#a0aab2]">{liquidityModel.prediction_summary}</p>
              <div className="text-[10px] space-y-1 pt-2 border-t border-[#25292e]">
                <div className="font-bold text-white">Feature Importance:</div>
                {liquidityModel.feature_importance.map((f, i) => (
                  <div key={i} className="flex justify-between text-[#a0aab2]">
                    <span>{f.feature}:</span>
                    <span className="text-blue-400 font-bold">{(f.importance * 100).toFixed(0)}%</span>
                  </div>
                ))}
              </div>
              <div className="text-[9px] text-amber-500 font-semibold pt-1">
                {liquidityModel.limitations_disclaimer}
              </div>
            </div>

            {/* CBDC Adoption Model */}
            <div className="bg-[#1a1d21] border border-[#2d3238] rounded-xs p-3 space-y-2">
              <div className="flex items-center justify-between border-b border-[#2b3036] pb-1">
                <span className="font-bold text-white text-xs">{adoptionModel.model_name}</span>
                <span className="text-[9px] bg-amber-950 text-amber-400 px-1.5 py-0.2 rounded-xs border border-amber-800">
                  {adoptionModel.version}
                </span>
              </div>
              <p className="text-[10px] text-[#a0aab2]">{adoptionModel.prediction_summary}</p>
              <div className="text-[10px] space-y-1 pt-2 border-t border-[#25292e]">
                <div className="font-bold text-white">Feature Importance:</div>
                {adoptionModel.feature_importance.map((f, i) => (
                  <div key={i} className="flex justify-between text-[#a0aab2]">
                    <span>{f.feature}:</span>
                    <span className="text-amber-400 font-bold">{(f.importance * 100).toFixed(0)}%</span>
                  </div>
                ))}
              </div>
              <div className="text-[9px] text-amber-500 font-semibold pt-1">
                {adoptionModel.limitations_disclaimer}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
