import React from 'react';
import { MainSimulation } from '../simulation/mainSimulation';
import { Language } from '../types';
import { translations } from '../i18n/translations';
import { MetricCard } from '../components/MetricCard';
import { DemonstrationBanner } from '../components/DemonstrationBanner';
import { Activity, ShieldCheck, Zap, Layers, ArrowUpRight } from 'lucide-react';

interface OverviewViewProps {
  sim: MainSimulation;
  lang: Language;
  onRunScenario: (scenarioId: string) => void;
  activeScenarioId: string;
}

export const OverviewView: React.FC<OverviewViewProps> = ({
  sim,
  lang,
  onRunScenario,
  activeScenarioId
}) => {
  const t = translations[lang];
  const txs = sim.ledger.getTransactions().slice(0, 8);
  const activeOutage = sim.resilience.getActiveScenario();

  return (
    <div className="space-y-4 font-mono">
      {/* Synthetic Demonstration Header */}
      <DemonstrationBanner
        onRunScenario={onRunScenario}
        activeScenarioId={activeScenarioId}
      />

      {/* Primary Metrics 8-Card Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <MetricCard
          label={t.cbdcCirculation}
          value={`DKK ${(sim.macro.cbdc_supply).toFixed(1)}B`}
          subValue="Central Bank M0 Issued"
          badge="SYNTHETIC"
          badgeColor="emerald"
          accent
        />
        <MetricCard
          label={t.wholesaleVolume}
          value="DKK 42.8B"
          subValue="24h Interbank Settlement"
          badge="NOMINAL"
          badgeColor="blue"
        />
        <MetricCard
          label={t.retailTxVolume}
          value="3,800,000"
          subValue="Daily Simulated Payments"
          badge="120ms LATENCY"
          badgeColor="emerald"
        />
        <MetricCard
          label={t.activeWallets}
          value="1,250,000"
          subValue="Consumer & Merchant Wallets"
          badge="RETAIL"
          badgeColor="neutral"
        />
        <MetricCard
          label={t.bankLiquidity}
          value="DKK 55.1B"
          subValue="Reserves at Danmarks Nationalbank"
          badge="BUFFER 1.42x"
          badgeColor="emerald"
        />
        <MetricCard
          label={t.dltVolume}
          value="DKK 18.2B"
          subValue="Atomic DvP & PvP Settlement"
          badge="DLT ACTIVE"
          badgeColor="blue"
        />
        <MetricCard
          label={t.settlementLatency}
          value={activeOutage.active ? `${activeOutage.estimated_recovery_minutes * 60}ms` : "120 ms"}
          subValue={activeOutage.active ? "AFBRYDELSE AKTIV" : "Sub-second Atomic Finality"}
          badge={activeOutage.active ? "OUTAGE" : "SUB-SECOND"}
          badgeColor={activeOutage.active ? "red" : "emerald"}
        />
        <MetricCard
          label={t.systemUtilization}
          value="42.8%"
          subValue="Peak Intraday Capacity"
          badge="STABLE"
          badgeColor="neutral"
        />
      </div>

      {/* Two-Column Core Status Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Live Transaction Ledger Stream (2 cols) */}
        <div className="lg:col-span-2 bg-[#141619] border border-[#2d3238] rounded-xs p-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#2b3036] mb-3">
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-[#c1121f]" />
              <h2 className="text-xs font-bold text-white uppercase tracking-wider">
                LIVE DOUBLE-ENTRY LEDGER TRANSACTIONS
              </h2>
            </div>
            <span className="text-[10px] text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded-xs border border-emerald-800">
              REAL-TIME SIMULATION TICKING
            </span>
          </div>

          <div className="space-y-2 overflow-x-auto">
            <table className="w-full text-left text-xs text-[#c2cad0]">
              <thead>
                <tr className="text-[10px] text-[#808d98] uppercase border-b border-[#25292e]">
                  <th className="pb-1">Tx ID</th>
                  <th className="pb-1">Type</th>
                  <th className="pb-1">Sender</th>
                  <th className="pb-1">Receiver</th>
                  <th className="pb-1 text-right">Amount (DKK)</th>
                  <th className="pb-1 text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1e2227] text-[11px]">
                {txs.map(tx => (
                  <tr key={tx.transaction_id} className="hover:bg-[#1a1d21] transition-colors">
                    <td className="py-2 text-[#a0aab2] font-mono">{tx.transaction_id.substring(0, 16)}</td>
                    <td className="py-2">
                      <span className="bg-[#212529] text-white px-1.5 py-0.5 rounded-xs text-[9px] border border-[#343a40]">
                        {tx.type}
                      </span>
                    </td>
                    <td className="py-2 font-semibold text-white truncate max-w-[120px]">{tx.sender_name}</td>
                    <td className="py-2 font-semibold text-white truncate max-w-[120px]">{tx.receiver_name}</td>
                    <td className="py-2 text-right font-bold text-emerald-400 font-mono">
                      +{tx.amount.toLocaleString('da-DK')}
                    </td>
                    <td className="py-2 text-right">
                      <span className="text-[10px] text-emerald-400 font-bold bg-emerald-950/50 px-1.5 py-0.5 rounded-xs border border-emerald-800">
                        {tx.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Central Bank Architecture & System Health (1 col) */}
        <div className="bg-[#141619] border border-[#2d3238] rounded-xs p-4 space-y-4">
          <div>
            <div className="flex items-center gap-2 pb-2 border-b border-[#2b3036] mb-3">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <h2 className="text-xs font-bold text-white uppercase tracking-wider">
                MONETARY ARCHITECTURE
              </h2>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between p-2 bg-[#1a1d21] rounded-xs border border-[#2d3238]">
                <span className="text-[#a0aab2]">Issuing Authority:</span>
                <span className="font-bold text-white">Danmarks Nationalbank</span>
              </div>
              <div className="flex items-center justify-between p-2 bg-[#1a1d21] rounded-xs border border-[#2d3238]">
                <span className="text-[#a0aab2]">Denomination:</span>
                <span className="font-bold text-emerald-400">DKK-Digital (1:1 DKK)</span>
              </div>
              <div className="flex items-center justify-between p-2 bg-[#1a1d21] rounded-xs border border-[#2d3238]">
                <span className="text-[#a0aab2]">Citizen Holding Limit:</span>
                <span className="font-bold text-amber-400">
                  DKK {sim.macro.holding_limit_citizen.toLocaleString('da-DK')}
                </span>
              </div>
              <div className="flex items-center justify-between p-2 bg-[#1a1d21] rounded-xs border border-[#2d3238]">
                <span className="text-[#a0aab2]">Wholesale Settlement:</span>
                <span className="font-bold text-blue-400">Kronos2 / DLT Atomic</span>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-[11px] font-bold text-[#808d98] uppercase tracking-wider mb-2">
              DANISH BANKING SYSTEM LIQUIDITY
            </h3>
            <div className="space-y-1.5 text-xs">
              {sim.banks.getBanks().slice(0, 4).map(b => (
                <div key={b.id} className="flex items-center justify-between text-[11px]">
                  <span className="text-[#c2cad0] truncate max-w-[140px]">{b.name}</span>
                  <span className="font-bold font-mono text-white">
                    DKK {(b.assets.reserves_at_cb / 1e9).toFixed(2)}B
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
