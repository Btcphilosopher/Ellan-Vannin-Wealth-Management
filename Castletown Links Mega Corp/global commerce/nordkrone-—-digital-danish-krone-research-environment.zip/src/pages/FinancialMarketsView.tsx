import React, { useState } from 'react';
import { MainSimulation } from '../simulation/mainSimulation';
import { Language } from '../types';
import { translations } from '../i18n/translations';
import { Layers, ArrowRight, Shield, TrendingUp, Scale } from 'lucide-react';

interface FinancialMarketsViewProps {
  sim: MainSimulation;
  lang: Language;
}

export const FinancialMarketsView: React.FC<FinancialMarketsViewProps> = ({ sim, lang }) => {
  const t = translations[lang];

  const [borrower, setBorrower] = useState<string>('BANK_JUTLAND');
  const [lender, setLender] = useState<string>('BANK_DANSKE');
  const [repoAmount, setRepoAmount] = useState<number>(250000000); // 250M DKK
  const [haircutPct, setHaircutPct] = useState<number>(3.5);
  const [repoRatePct, setRepoRatePct] = useState<number>(2.15);
  const [repoStatusMsg, setRepoStatusMsg] = useState<string | null>(null);

  const bonds = sim.securities.getBonds();
  const repos = sim.securities.getRepoTransactions();
  const tokenisedDeps = sim.securities.getTokenisedDeposits();

  const handleCreateRepo = () => {
    const repo = sim.securities.createRepoTransaction({
      borrower_id: borrower,
      borrower_name: sim.banks.getBank(borrower)?.name || borrower,
      lender_id: lender,
      lender_name: sim.banks.getBank(lender)?.name || lender,
      bond_isin: 'DK0009924538',
      cash_amount: repoAmount,
      haircut_pct: haircutPct,
      repo_rate_pct: repoRatePct,
      maturity_days: 7
    });

    setRepoStatusMsg(`REPOSUCCES: Repoforretning ${repo.id} oprettet. Kontanter: DKK ${repo.cash_amount.toLocaleString('da-DK')}. Pantsat Sikkerhed: DKK ${repo.collateral_value.toLocaleString('da-DK')} (Haircut ${haircutPct}%).`);
  };

  return (
    <div className="space-y-4 font-mono text-xs">
      {/* Danish Government Bonds & Corporate Bonds */}
      <div className="bg-[#141619] border border-[#2d3238] rounded-xs p-4 space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-[#2b3036]">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-[#c1121f]" />
            <h2 className="text-sm font-bold text-white uppercase tracking-wider">
              DANISH TOKENISED SECURITIES & BONDS
            </h2>
          </div>
          <span className="text-[10px] text-blue-400 bg-blue-950/80 px-2 py-0.5 rounded-xs border border-blue-800">
            VP SECURITIES / DLT ATOMIC DVP SETTLEMENT
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {bonds.map(b => (
            <div key={b.isin_sim} className="p-3 bg-[#1a1d21] border border-[#2d3238] rounded-xs space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-white text-xs">{b.name}</span>
                <span className="text-emerald-400 font-bold font-mono">{b.price_pct}%</span>
              </div>
              <div className="text-[11px] text-[#a0aab2] space-y-0.5">
                <div>ISIN: <span className="text-white">{b.isin_sim}</span></div>
                <div>Coupon: <span className="text-white">{b.coupon_rate}%</span> | Maturity: <span className="text-white">{b.maturity_year}</span></div>
                <div>Owner: <span className="text-white">{b.owner_name}</span></div>
                <div>Settlement Asset: <span className="text-emerald-400 font-bold">{b.settlement_asset}</span></div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Repo Market Engine */}
      <div className="bg-[#141619] border border-[#2d3238] rounded-xs p-4 space-y-3">
        <div className="flex items-center gap-2 pb-2 border-b border-[#2b3036]">
          <Scale className="w-4 h-4 text-emerald-400" />
          <h3 className="text-xs font-bold text-white uppercase tracking-wider">
            INSTITUTIONAL REPO MARKET & COLLATERAL ENGINE
          </h3>
        </div>

        <div className="bg-[#1a1d21] p-3 border border-[#2d3238] rounded-xs space-y-3">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            <div>
              <label className="block text-[10px] text-[#a0aab2] mb-1">Borrower Bank:</label>
              <select
                value={borrower}
                onChange={e => setBorrower(e.target.value)}
                className="w-full bg-[#212529] text-white border border-[#343a40] px-2 py-1 rounded-xs text-xs font-mono"
              >
                {sim.banks.getBanks().map(b => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[10px] text-[#a0aab2] mb-1">Lender Bank:</label>
              <select
                value={lender}
                onChange={e => setLender(e.target.value)}
                className="w-full bg-[#212529] text-white border border-[#343a40] px-2 py-1 rounded-xs text-xs font-mono"
              >
                {sim.banks.getBanks().map(b => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[10px] text-[#a0aab2] mb-1">Cash Loan Amount (DKK):</label>
              <input
                type="number"
                value={repoAmount}
                onChange={e => setRepoAmount(Number(e.target.value))}
                className="w-full bg-[#212529] text-white border border-[#343a40] px-2 py-1 rounded-xs text-xs font-mono"
              />
            </div>

            <div>
              <label className="block text-[10px] text-[#a0aab2] mb-1">Haircut (%):</label>
              <input
                type="number"
                step="0.1"
                value={haircutPct}
                onChange={e => setHaircutPct(Number(e.target.value))}
                className="w-full bg-[#212529] text-white border border-[#343a40] px-2 py-1 rounded-xs text-xs font-mono"
              />
            </div>
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-[#2a3038]">
            <div className="text-[11px] text-[#a0aab2]">
              Pledged Collateral Required: <strong className="text-white font-mono">DKK {Math.floor(repoAmount * (1 + haircutPct / 100)).toLocaleString('da-DK')}</strong> (DGB-2033)
            </div>
            <button
              onClick={handleCreateRepo}
              className="bg-[#c1121f] hover:bg-[#a00f1a] text-white font-bold px-4 py-1.5 rounded-xs transition-colors text-xs flex items-center gap-1.5"
            >
              <ArrowRight className="w-4 h-4" /> Create Institutional Repo Transaction
            </button>
          </div>

          {repoStatusMsg && (
            <div className="p-2 bg-[#212529] text-emerald-400 border border-emerald-800 rounded-xs text-xs font-mono">
              {repoStatusMsg}
            </div>
          )}
        </div>

        {/* Active Repo Transactions Directory */}
        <div className="space-y-2">
          <h4 className="text-[11px] font-bold text-[#808d98] uppercase">ACTIVE REPO TRANSACTIONS</h4>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="text-[10px] text-[#808d98] uppercase border-b border-[#25292e]">
                  <th className="pb-1">Repo ID</th>
                  <th className="pb-1">Borrower</th>
                  <th className="pb-1">Lender</th>
                  <th className="pb-1 text-right">Cash Amount</th>
                  <th className="pb-1 text-right">Collateral Value</th>
                  <th className="pb-1 text-right">Haircut</th>
                  <th className="pb-1 text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1e2227] text-[11px]">
                {repos.map(r => (
                  <tr key={r.id} className="hover:bg-[#1a1d21]">
                    <td className="py-2 text-[#a0aab2] font-mono">{r.id}</td>
                    <td className="py-2 font-bold text-white">{r.borrower_name}</td>
                    <td className="py-2 font-bold text-white">{r.lender_name}</td>
                    <td className="py-2 text-right font-mono text-emerald-400">DKK {r.cash_amount.toLocaleString('da-DK')}</td>
                    <td className="py-2 text-right font-mono text-blue-400">DKK {r.collateral_value.toLocaleString('da-DK')}</td>
                    <td className="py-2 text-right font-mono text-white">{r.haircut_pct}%</td>
                    <td className="py-2 text-right font-bold text-emerald-400">{r.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
