import React, { useState } from 'react';
import { MainSimulation } from '../simulation/mainSimulation';
import { Language } from '../types';
import { translations } from '../i18n/translations';
import { Cpu, ArrowRightLeft, ShieldCheck, CheckCircle2, AlertTriangle, Layers } from 'lucide-react';

interface DLTViewProps {
  sim: MainSimulation;
  lang: Language;
}

export const DLTView: React.FC<DLTViewProps> = ({ sim, lang }) => {
  const t = translations[lang];

  const [dvpBuyer, setDvpBuyer] = useState<string>('BANK_DANSKE');
  const [dvpSeller, setDvpSeller] = useState<string>('BANK_NORDIC');
  const [dvpAmount, setDvpAmount] = useState<number>(50000000); // 50M DKK Bond
  const [dvpCash, setDvpCash] = useState<number>(51250000); // 51.25M DKK Money
  const [failDvp, setFailDvp] = useState<boolean>(false);
  const [dvpResult, setDvpResult] = useState<any>(null);

  const blocks = sim.dlt.getBlocks().slice(-6);
  const dvpExecs = sim.dlt.getDvPExecutions();
  const pvpExecs = sim.dlt.getPvPExecutions();

  const handleExecuteDvP = () => {
    const res = sim.dlt.executeAtomicDvP(dvpBuyer, dvpSeller, 'DK0009924538 (DGB 2033)', dvpAmount, dvpCash, failDvp);
    setDvpResult(res);
  };

  return (
    <div className="space-y-4 font-mono text-xs">
      {/* Live DLT Ledger Blocks Stream */}
      <div className="bg-[#141619] border border-[#2d3238] rounded-xs p-4 space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-[#2b3036]">
          <div className="flex items-center gap-2">
            <Cpu className="w-4 h-4 text-[#c1121f]" />
            <h2 className="text-sm font-bold text-white uppercase tracking-wider">
              WHOLESALE DLT LEDGER & BLOCK EXPLORER
            </h2>
          </div>
          <span className="text-[10px] text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded-xs border border-emerald-800">
            NORDIC FMI VALIDATOR CONSENSUS
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {blocks.map(b => (
            <div key={b.block_height} className="p-3 bg-[#1a1d21] border border-[#2d3238] rounded-xs space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="font-bold text-emerald-400 text-xs">BLOCK #{b.block_height}</span>
                <span className="text-[9px] bg-[#212529] text-[#a0aab2] px-1.5 py-0.5 rounded-xs border border-[#343a40]">
                  {b.status}
                </span>
              </div>
              <div className="text-[10px] text-[#a0aab2] font-mono truncate">
                Hash: <span className="text-white">{b.hash.substring(0, 20)}...</span>
              </div>
              <div className="text-[10px] text-[#a0aab2] flex justify-between pt-1 border-t border-[#25292e]">
                <span>Txs: {b.transactions_count}</span>
                <span className="truncate max-w-[120px]">{b.validator}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Delivery-versus-Payment (DvP) Atomic Simulator */}
      <div className="bg-[#141619] border border-[#2d3238] rounded-xs p-4 space-y-3">
        <div className="flex items-center gap-2 pb-2 border-b border-[#2b3036]">
          <ArrowRightLeft className="w-4 h-4 text-emerald-400" />
          <h3 className="text-xs font-bold text-white uppercase tracking-wider">
            ATOMIC DELIVERY-VERSUS-PAYMENT (DvP) SIMULATOR
          </h3>
        </div>

        <p className="text-[11px] text-[#a0aab2]">
          Atomic DvP ensures that either <strong>BOND + MONEY</strong> settle together simultaneously on the DLT ledger, or <strong>NOTHING SETTLES</strong>.
        </p>

        <div className="bg-[#1a1d21] p-3 border border-[#2d3238] rounded-xs space-y-3">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            <div>
              <label className="block text-[10px] text-[#a0aab2] mb-1">Buyer (Payer of Money):</label>
              <select
                value={dvpBuyer}
                onChange={e => setDvpBuyer(e.target.value)}
                className="w-full bg-[#212529] text-white border border-[#343a40] px-2 py-1 rounded-xs text-xs font-mono"
              >
                {sim.banks.getBanks().map(b => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[10px] text-[#a0aab2] mb-1">Seller (Deliverer of Bond):</label>
              <select
                value={dvpSeller}
                onChange={e => setDvpSeller(e.target.value)}
                className="w-full bg-[#212529] text-white border border-[#343a40] px-2 py-1 rounded-xs text-xs font-mono"
              >
                {sim.banks.getBanks().map(b => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[10px] text-[#a0aab2] mb-1">Bond Value (DKK):</label>
              <input
                type="number"
                value={dvpAmount}
                onChange={e => setDvpAmount(Number(e.target.value))}
                className="w-full bg-[#212529] text-white border border-[#343a40] px-2 py-1 rounded-xs text-xs font-mono"
              />
            </div>

            <div>
              <label className="block text-[10px] text-[#a0aab2] mb-1">Money Cash (DKK):</label>
              <input
                type="number"
                value={dvpCash}
                onChange={e => setDvpCash(Number(e.target.value))}
                className="w-full bg-[#212529] text-white border border-[#343a40] px-2 py-1 rounded-xs text-xs font-mono"
              />
            </div>
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-[#2a3038]">
            <label className="flex items-center gap-2 text-xs text-[#a0aab2] cursor-pointer">
              <input
                type="checkbox"
                checked={failDvp}
                onChange={e => setFailDvp(e.target.checked)}
                className="accent-[#c1121f]"
              />
              <span className="text-amber-400 font-bold">Simulate Payment Failure / Abort Leg</span>
            </label>

            <button
              onClick={handleExecuteDvP}
              className="bg-[#c1121f] hover:bg-[#a00f1a] text-white font-bold px-4 py-1.5 rounded-xs transition-colors text-xs flex items-center gap-1.5"
            >
              <ArrowRightLeft className="w-4 h-4" /> Execute Atomic DvP Settlement
            </button>
          </div>

          {dvpResult && (
            <div
              className={`p-3 border rounded-xs ${
                dvpResult.status === 'ATOMIC_SETTLED'
                  ? 'bg-emerald-950/60 border-emerald-800 text-emerald-300'
                  : 'bg-red-950/60 border-red-800 text-red-300'
              }`}
            >
              <div className="flex items-center justify-between font-bold text-xs mb-1">
                <span className="flex items-center gap-1.5">
                  {dvpResult.status === 'ATOMIC_SETTLED' ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <AlertTriangle className="w-4 h-4 text-red-400" />
                  )}
                  ATOMIC DvP STATUS: {dvpResult.status}
                </span>
                <span>ID: {dvpResult.id}</span>
              </div>
              <p className="text-[11px] opacity-90">
                {dvpResult.status === 'ATOMIC_SETTLED'
                  ? `SUCCESS: Bond DGB-2033 (DKK ${dvpAmount.toLocaleString('da-DK')}) transferred to ${dvpBuyer} AND Money DKK-Digital (${dvpCash.toLocaleString('da-DK')}) transferred to ${dvpSeller} simultaneously.`
                  : `ABORTED: Payment leg failed. Zero assets transferred. Buyer retained cash and Seller retained bond.`}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
