import React, { useState } from 'react';
import { MainSimulation } from '../simulation/mainSimulation';
import { Language } from '../types';
import { translations } from '../i18n/translations';
import { Landmark, ArrowRight, ShieldCheck, Database, RefreshCw } from 'lucide-react';

interface NationalMoneyViewProps {
  sim: MainSimulation;
  lang: Language;
}

export const NationalMoneyView: React.FC<NationalMoneyViewProps> = ({ sim, lang }) => {
  const t = translations[lang];
  const [issueAmount, setIssueAmount] = useState<number>(500000000); // 500M
  const [selectedBank, setSelectedBank] = useState<string>('BANK_DANSKE');
  const [statusMsg, setStatusMsg] = useState<string | null>(null);

  const accounts = sim.ledger.getAllAccounts();
  const entries = sim.ledger.getLedgerEntries().slice(0, 15);

  const handleIssue = () => {
    const res = sim.ledger.issueCBDC(issueAmount, selectedBank);
    if (res.success) {
      setStatusMsg(`SUCCES: Udstedt DKK ${issueAmount.toLocaleString('da-DK')} fra Danmarks Nationalbank til ${selectedBank}.`);
    } else {
      setStatusMsg(`FEJL: ${res.error}`);
    }
  };

  const handleRedeem = () => {
    const res = sim.ledger.redeemCBDC(issueAmount, selectedBank);
    if (res.success) {
      setStatusMsg(`SUCCES: Indløst DKK ${issueAmount.toLocaleString('da-DK')} fra ${selectedBank} til centralbankreserver.`);
    } else {
      setStatusMsg(`FEJL: ${res.error}`);
    }
  };

  return (
    <div className="space-y-4 font-mono text-xs">
      <div className="bg-[#141619] border border-[#2d3238] rounded-xs p-4">
        <div className="flex items-center gap-2 pb-2 border-b border-[#2b3036] mb-3">
          <Landmark className="w-4 h-4 text-[#c1121f]" />
          <h2 className="text-sm font-bold text-white uppercase tracking-wider">
            DANMARKS NATIONALBANK — DIGITAL KRONE ISSUANCE & LEDGER
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
          <div className="p-3 bg-[#1a1d21] border border-[#2d3238] rounded-xs">
            <span className="text-[10px] text-[#a0aab2] uppercase block">CBDC Supply in Circulation</span>
            <span className="text-lg font-bold text-white">DKK 12.400.000.000</span>
            <p className="text-[10px] text-emerald-400 mt-1">Direct liability of Danmarks Nationalbank</p>
          </div>
          <div className="p-3 bg-[#1a1d21] border border-[#2d3238] rounded-xs">
            <span className="text-[10px] text-[#a0aab2] uppercase block">Wholesale Settlement Reserve</span>
            <span className="text-lg font-bold text-white">DKK 45.000.000.000</span>
            <p className="text-[10px] text-blue-400 mt-1">Kronos2 & DLT Interbank Vault</p>
          </div>
          <div className="p-3 bg-[#1a1d21] border border-[#2d3238] rounded-xs">
            <span className="text-[10px] text-[#a0aab2] uppercase block">Accounting Ledger Format</span>
            <span className="text-lg font-bold text-emerald-400">DOUBLE-ENTRY STRICT</span>
            <p className="text-[10px] text-[#a0aab2] mt-1">Derived purely from verified debits & credits</p>
          </div>
        </div>

        {/* Issue / Redeem Actions */}
        <div className="bg-[#1a1d21] p-3 border border-[#2d3238] rounded-xs space-y-3">
          <h3 className="text-xs font-bold text-white uppercase tracking-wide">
            WHOLESALE CENTRAL BANK MONEY ISSUANCE & REDEMPTION
          </h3>

          <div className="flex flex-wrap items-center gap-3">
            <div>
              <label className="block text-[10px] text-[#a0aab2] mb-1">Target Commercial Bank:</label>
              <select
                value={selectedBank}
                onChange={e => setSelectedBank(e.target.value)}
                className="bg-[#212529] text-white border border-[#343a40] px-2 py-1 rounded-xs text-xs font-mono"
              >
                {sim.banks.getBanks().map(b => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[10px] text-[#a0aab2] mb-1">Amount (DKK):</label>
              <input
                type="number"
                value={issueAmount}
                onChange={e => setIssueAmount(Number(e.target.value))}
                className="bg-[#212529] text-white border border-[#343a40] px-2 py-1 rounded-xs text-xs font-mono w-40"
              />
            </div>

            <div className="flex items-end gap-2 pt-4">
              <button
                onClick={handleIssue}
                className="bg-[#c1121f] hover:bg-[#a00f1a] text-white font-bold px-3 py-1.5 rounded-xs transition-colors text-xs flex items-center gap-1"
              >
                <ArrowRight className="w-3.5 h-3.5" /> Issue Digital Krone
              </button>
              <button
                onClick={handleRedeem}
                className="bg-[#1d3557] hover:bg-[#152741] text-white font-bold px-3 py-1.5 rounded-xs transition-colors text-xs flex items-center gap-1"
              >
                <RefreshCw className="w-3.5 h-3.5" /> Redeem to Reserves
              </button>
            </div>
          </div>

          {statusMsg && (
            <div className="p-2 bg-[#212529] text-white border border-[#343a40] rounded-xs text-xs font-mono">
              {statusMsg}
            </div>
          )}
        </div>
      </div>

      {/* Double-Entry Ledger Inspector */}
      <div className="bg-[#141619] border border-[#2d3238] rounded-xs p-4 space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-[#2b3036]">
          <div className="flex items-center gap-2">
            <Database className="w-4 h-4 text-emerald-400" />
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              DOUBLE-ENTRY LEDGER ENTRIES INSPECTOR
            </h3>
          </div>
          <span className="text-[10px] text-[#a0aab2]">
            VERIFIED AUDIT LOG ({entries.length} RECENT ENTRIES)
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="text-[10px] text-[#808d98] uppercase border-b border-[#25292e]">
                <th className="pb-1">Entry ID</th>
                <th className="pb-1">Tx Reference</th>
                <th className="pb-1">Account</th>
                <th className="pb-1 text-right">Debit (DKK)</th>
                <th className="pb-1 text-right">Credit (DKK)</th>
                <th className="pb-1">Description</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1e2227] text-[11px]">
              {entries.map(ent => (
                <tr key={ent.entry_id} className="hover:bg-[#1a1d21]">
                  <td className="py-2 text-[#a0aab2] font-mono">{ent.entry_id}</td>
                  <td className="py-2 text-[#a0aab2] font-mono">{ent.transaction_id.substring(0, 14)}</td>
                  <td className="py-2 font-bold text-white">{ent.account_name}</td>
                  <td className="py-2 text-right font-mono text-red-400">
                    {ent.debit > 0 ? `-${ent.debit.toLocaleString('da-DK')}` : '-'}
                  </td>
                  <td className="py-2 text-right font-mono text-emerald-400">
                    {ent.credit > 0 ? `+${ent.credit.toLocaleString('da-DK')}` : '-'}
                  </td>
                  <td className="py-2 text-[#a0aab2]">{ent.description}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
