import React, { useState } from 'react';
import { MainSimulation } from '../simulation/mainSimulation';
import { Language } from '../types';
import { translations } from '../i18n/translations';
import { Building2, AlertOctagon, TrendingDown, RefreshCw, ShieldAlert } from 'lucide-react';

interface BankingViewProps {
  sim: MainSimulation;
  lang: Language;
}

export const BankingView: React.FC<BankingViewProps> = ({ sim, lang }) => {
  const t = translations[lang];
  const [selectedBankId, setSelectedBankId] = useState<string>('BANK_DANSKE');
  const [shockMagnitude, setShockMagnitude] = useState<number>(15);
  const [stressMsg, setStressMsg] = useState<string | null>(null);

  const banks = sim.banks.getBanks();
  const selectedBank = sim.banks.getBank(selectedBankId);

  const handleTriggerStress = () => {
    sim.banks.triggerBankLiquidityStress(selectedBankId, shockMagnitude);
    setStressMsg(`LIKVIDITETSCHOK UDLØST: ${selectedBank?.name} oplevede ${shockMagnitude}% indlånsflugt. Centralbankreserver faldet til DKK ${(selectedBank!.assets.reserves_at_cb / 1e9).toFixed(2)}B.`);
  };

  return (
    <div className="space-y-4 font-mono text-xs">
      {/* 5 Danish Commercial Banks Balance Sheet Grid */}
      <div className="bg-[#141619] border border-[#2d3238] rounded-xs p-4 space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-[#2b3036]">
          <div className="flex items-center gap-2">
            <Building2 className="w-4 h-4 text-[#c1121f]" />
            <h2 className="text-sm font-bold text-white uppercase tracking-wider">
              DANISH COMMERCIAL BANKS BALANCE SHEETS & RESERVES
            </h2>
          </div>
          <span className="text-[10px] text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded-xs border border-emerald-800">
            5 SYNTHETIC COMMERCIAL BANKS
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-3">
          {banks.map(b => (
            <div
              key={b.id}
              onClick={() => setSelectedBankId(b.id)}
              className={`p-3 rounded-xs border cursor-pointer transition-all ${
                selectedBankId === b.id
                  ? 'bg-[#1a1d21] border-[#c1121f] shadow-md'
                  : 'bg-[#141619] border-[#2b3036] hover:border-[#3e4650]'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="font-bold text-white text-xs truncate">{b.code}</span>
                <span className="text-[9px] bg-[#212529] text-[#a0aab2] px-1 py-0.2 rounded-xs border border-[#343a40]">
                  {b.id}
                </span>
              </div>
              <div className="text-[10px] text-[#a0aab2] truncate">{b.name}</div>

              <div className="mt-2 space-y-1 text-[11px]">
                <div className="flex justify-between">
                  <span className="text-[#a0aab2]">Reserves:</span>
                  <span className="font-bold text-emerald-400">DKK {(b.assets.reserves_at_cb / 1e9).toFixed(1)}B</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#a0aab2]">Deposits:</span>
                  <span className="font-bold text-white">DKK {(b.liabilities.customer_deposits / 1e9).toFixed(1)}B</span>
                </div>
                <div className="flex justify-between pt-1 border-t border-[#25292e]">
                  <span className="text-[#a0aab2]">Liquidity Buffer:</span>
                  <span className="font-bold text-blue-400">DKK {(b.liquidity_buffer / 1e9).toFixed(1)}B</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Balance Sheet Inspector & Liquidity Stress Engine */}
      {selectedBank && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Detailed Assets & Liabilities Breakdown */}
          <div className="bg-[#141619] border border-[#2d3238] rounded-xs p-4 space-y-3">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider pb-2 border-b border-[#2b3036]">
              BALANCE SHEET INSPECTOR — {selectedBank.name}
            </h3>

            <div className="grid grid-cols-2 gap-3">
              {/* Assets Column */}
              <div className="bg-[#1a1d21] p-3 border border-[#2d3238] rounded-xs space-y-2">
                <span className="text-xs font-bold text-emerald-400 uppercase block pb-1 border-b border-[#2a3038]">
                  ASSETS (AKTIVER)
                </span>
                <div className="space-y-1.5 text-[11px]">
                  <div className="flex justify-between">
                    <span className="text-[#a0aab2]">Reserves at Central Bank:</span>
                    <span className="font-bold text-white">DKK {(selectedBank.assets.reserves_at_cb / 1e9).toFixed(2)}B</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#a0aab2]">CBDC Vault Holding:</span>
                    <span className="font-bold text-white">DKK {(selectedBank.assets.cbdc_vault / 1e9).toFixed(2)}B</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#a0aab2]">Loans & Mortgages:</span>
                    <span className="font-bold text-white">DKK {(selectedBank.assets.loans / 1e9).toFixed(2)}B</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#a0aab2]">Danish Bonds:</span>
                    <span className="font-bold text-white">DKK {(selectedBank.assets.securities / 1e9).toFixed(2)}B</span>
                  </div>
                </div>
              </div>

              {/* Liabilities Column */}
              <div className="bg-[#1a1d21] p-3 border border-[#2d3238] rounded-xs space-y-2">
                <span className="text-xs font-bold text-[#c1121f] uppercase block pb-1 border-b border-[#2a3038]">
                  LIABILITIES (PASSIVER)
                </span>
                <div className="space-y-1.5 text-[11px]">
                  <div className="flex justify-between">
                    <span className="text-[#a0aab2]">Customer Deposits:</span>
                    <span className="font-bold text-white">DKK {(selectedBank.liabilities.customer_deposits / 1e9).toFixed(2)}B</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#a0aab2]">Tokenised Deposits:</span>
                    <span className="font-bold text-white">DKK {(selectedBank.liabilities.tokenised_deposits / 1e9).toFixed(2)}B</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#a0aab2]">Central Bank Borrowing:</span>
                    <span className="font-bold text-white">DKK {(selectedBank.liabilities.cb_borrowing / 1e9).toFixed(2)}B</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#a0aab2]">Capital / Equity:</span>
                    <span className="font-bold text-white">DKK {(selectedBank.liabilities.capital / 1e9).toFixed(2)}B</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Liquidity Shock Simulator */}
          <div className="bg-[#141619] border border-[#2d3238] rounded-xs p-4 space-y-3">
            <div className="flex items-center gap-2 pb-2 border-b border-[#2b3036]">
              <AlertOctagon className="w-4 h-4 text-amber-500" />
              <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                BANK LIQUIDITY STRESS & SHOCK ENGINE
              </h3>
            </div>

            <p className="text-[11px] text-[#a0aab2]">
              Simulate an abrupt deposit flight scenario where household deposits move out of bank accounts directly into Digital Krone central bank money.
            </p>

            <div className="bg-[#1a1d21] p-3 border border-[#2d3238] rounded-xs space-y-3">
              <div>
                <label className="block text-[10px] text-[#a0aab2] mb-1">
                  Deposit Flight Shock Magnitude (% of customer deposits):
                </label>
                <div className="flex items-center gap-3">
                  <input
                    type="range"
                    min="5"
                    max="40"
                    value={shockMagnitude}
                    onChange={e => setShockMagnitude(Number(e.target.value))}
                    className="flex-1 accent-[#c1121f] cursor-pointer"
                  />
                  <span className="font-bold text-red-400 font-mono w-12">{shockMagnitude}%</span>
                </div>
              </div>

              <button
                onClick={handleTriggerStress}
                className="w-full bg-red-800 hover:bg-red-700 text-white font-bold px-4 py-2 rounded-xs transition-colors text-xs flex items-center justify-center gap-2"
              >
                <ShieldAlert className="w-4 h-4" /> Trigger Deposit Flight Shock on {selectedBank.code}
              </button>

              {stressMsg && (
                <div className="p-2 bg-[#212529] text-amber-400 border border-amber-800 rounded-xs text-xs font-mono">
                  {stressMsg}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
