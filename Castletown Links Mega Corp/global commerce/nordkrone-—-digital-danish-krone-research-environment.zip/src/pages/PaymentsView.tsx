import React, { useState } from 'react';
import { MainSimulation } from '../simulation/mainSimulation';
import { Language } from '../types';
import { translations } from '../i18n/translations';
import { CreditCard, ArrowRight, CheckCircle2, Clock, Smartphone, Zap } from 'lucide-react';

interface PaymentsViewProps {
  sim: MainSimulation;
  lang: Language;
}

export const PaymentsView: React.FC<PaymentsViewProps> = ({ sim, lang }) => {
  const t = translations[lang];
  const [adoptionPct, setAdoptionPct] = useState<number>(sim.macro.retail_cbdc_adoption_pct);
  const [testAmount, setTestAmount] = useState<number>(275);
  const [lifecycleResult, setLifecycleResult] = useState<any>(null);

  const channelVols = sim.payments.getChannelVolumes();

  const handleAdoptionChange = (newVal: number) => {
    setAdoptionPct(newVal);
    sim.payments.setAdoptionLevel(newVal);
    sim.banks.simulateRetailCBDCAdoptionShift(newVal);
    sim.macro.retail_cbdc_adoption_pct = newVal;
  };

  const handleSimulatePayment = () => {
    const res = sim.payments.simulateRetailLifecycle('CONSUMER_1', 'MERCHANT_1', testAmount);
    setLifecycleResult(res);
  };

  return (
    <div className="space-y-4 font-mono text-xs">
      {/* Payment Channels Volume Distribution */}
      <div className="bg-[#141619] border border-[#2d3238] rounded-xs p-4 space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-[#2b3036]">
          <div className="flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-[#c1121f]" />
            <h2 className="text-sm font-bold text-white uppercase tracking-wider">
              DANISH PAYMENT ENVIRONMENT & CHANNEL DISTRIBUTION
            </h2>
          </div>
          <span className="text-[10px] text-amber-400 bg-amber-950/80 px-2 py-0.5 rounded-xs border border-amber-800">
            HIGHLY DIGITAL BASELINE ENVIRONMENT
          </span>
        </div>

        {/* Adoption Level Slider */}
        <div className="bg-[#1a1d21] p-3 border border-[#2d3238] rounded-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-white uppercase">
              SIMULATION PARAMETER: RETAIL DIGITAL KRONE ADOPTION LEVEL
            </span>
            <span className="text-sm font-bold text-emerald-400 font-mono">
              {adoptionPct}% ADOPTION
            </span>
          </div>
          <input
            type="range"
            min="0"
            max="80"
            value={adoptionPct}
            onChange={e => handleAdoptionChange(Number(e.target.value))}
            className="w-full accent-[#c1121f] cursor-pointer"
          />
          <div className="flex justify-between text-[10px] text-[#808d98]">
            <span>0% (No Retail CBDC)</span>
            <span>25% (Moderate Adoption)</span>
            <span>50% (High Adoption)</span>
            <span>80% (Extreme Substitution)</span>
          </div>
        </div>

        {/* Channel Breakdown Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {channelVols.map(ch => (
            <div key={ch.channel} className="p-3 bg-[#1a1d21] border border-[#2d3238] rounded-xs space-y-1">
              <div className="flex items-center justify-between">
                <span className="font-bold text-white text-xs">{ch.channel_name}</span>
                <span className="text-emerald-400 font-bold">{ch.share_pct}%</span>
              </div>
              <div className="text-sm font-bold text-white">
                DKK {(ch.volume_24h_dkk / 1e6).toFixed(1)}M / day
              </div>
              <div className="text-[10px] text-[#a0aab2] flex justify-between pt-1 border-t border-[#25292e]">
                <span>Txs: {ch.tx_count_24h.toLocaleString('da-DK')}</span>
                <span>Latency: {ch.avg_latency_ms}ms</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Retail Lifecycle Simulation Engine */}
      <div className="bg-[#141619] border border-[#2d3238] rounded-xs p-4 space-y-3">
        <div className="flex items-center gap-2 pb-2 border-b border-[#2b3036]">
          <Zap className="w-4 h-4 text-emerald-400" />
          <h3 className="text-xs font-bold text-white uppercase tracking-wider">
            RETAIL PAYMENT LIFECYCLE SIMULATOR
          </h3>
        </div>

        <div className="flex items-center gap-3 bg-[#1a1d21] p-3 border border-[#2d3238] rounded-xs">
          <span className="text-xs text-[#a0aab2]">Payment Amount:</span>
          <input
            type="number"
            value={testAmount}
            onChange={e => setTestAmount(Number(e.target.value))}
            className="bg-[#212529] text-white border border-[#343a40] px-2 py-1 rounded-xs text-xs font-mono w-32"
          />
          <span className="text-xs font-bold text-white">DKK</span>

          <button
            onClick={handleSimulatePayment}
            className="bg-[#c1121f] hover:bg-[#a00f1a] text-white font-bold px-4 py-1.5 rounded-xs transition-colors text-xs flex items-center gap-1.5"
          >
            <Smartphone className="w-4 h-4" /> Execute Consumer → Merchant Payment (DKK {testAmount})
          </button>
        </div>

        {lifecycleResult && (
          <div className="bg-[#1a1d21] p-3 border border-emerald-900/60 rounded-xs space-y-2">
            <div className="flex items-center justify-between text-xs font-bold text-emerald-400 pb-2 border-b border-[#25292e]">
              <span>LIFECYCLE VERIFIED: CONSUMER (DKK {testAmount}) → MERCHANT (DKK {testAmount})</span>
              <span>TOTAL LATENCY: {lifecycleResult.totalTimeMs} ms</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-2 pt-1">
              {lifecycleResult.lifecycle.map((step: any, idx: number) => (
                <div key={idx} className="p-2 bg-[#212529] border border-[#343a40] rounded-xs">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-white mb-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>{step.step}</span>
                  </div>
                  <p className="text-[10px] text-[#a0aab2] leading-tight">{step.detail}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
