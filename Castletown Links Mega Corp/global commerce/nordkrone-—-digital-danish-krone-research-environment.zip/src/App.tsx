import React, { useState, useEffect } from 'react';
import { simulationInstance, MainSimulation } from './simulation/mainSimulation';
import { Language } from './types';
import { Header } from './components/Header';
import { Sidebar, MainNavModule } from './components/Sidebar';
import { OverviewView } from './pages/OverviewView';
import { NationalMoneyView } from './pages/NationalMoneyView';
import { PaymentsView } from './pages/PaymentsView';
import { FinancialMarketsView } from './pages/FinancialMarketsView';
import { DLTView } from './pages/DLTView';
import { BankingView } from './pages/BankingView';
import { NordicView } from './pages/NordicView';
import { ResearchLabsView } from './pages/ResearchLabsView';
import { ControlRoomView } from './pages/ControlRoomView';

export default function App() {
  const [lang, setLang] = useState<Language>('da');
  const [activeModule, setActiveModule] = useState<MainNavModule>('overview');
  const [activeSubView, setActiveSubView] = useState<string>('overview_main');
  const [activeScenarioId, setActiveScenarioId] = useState<string>('BASELINE');
  const [, setTickCounter] = useState<number>(0);

  // Subscribe to simulation state ticks
  useEffect(() => {
    const unsubscribe = simulationInstance.subscribe(() => {
      setTickCounter(prev => prev + 1);
    });
    return () => unsubscribe();
  }, []);

  const handleRunScenario = (scenarioId: string) => {
    setActiveScenarioId(scenarioId);
    simulationInstance.applyScenario(scenarioId);
  };

  return (
    <div className="min-h-screen bg-[#0f1114] text-[#f4f5f7] flex flex-col font-sans selection:bg-[#c1121f] selection:text-white">
      {/* Header Bar */}
      <Header
        lang={lang}
        onLanguageChange={setLang}
        clock={simulationInstance.clock}
        onSetClockSpeed={(speed) => simulationInstance.setClockSpeed(speed)}
        onStepClock={() => simulationInstance.step()}
        onResetClock={() => simulationInstance.resetSimulation()}
        onRunScenario={handleRunScenario}
        activeScenarioId={activeScenarioId}
      />

      {/* Main Content Layout with Sidebar */}
      <div className="flex-1 flex overflow-hidden">
        {/* Navigation Sidebar */}
        <Sidebar
          lang={lang}
          activeModule={activeModule}
          onSelectModule={setActiveModule}
          activeSubView={activeSubView}
          onSelectSubView={setActiveSubView}
        />

        {/* Viewport Content Area */}
        <main className="flex-1 overflow-y-auto p-4 md:p-6 bg-[#0f1114]">
          {activeModule === 'overview' && (
            <OverviewView
              sim={simulationInstance}
              lang={lang}
              onRunScenario={handleRunScenario}
              activeScenarioId={activeScenarioId}
            />
          )}

          {activeModule === 'national_money' && (
            <NationalMoneyView
              sim={simulationInstance}
              lang={lang}
            />
          )}

          {activeModule === 'payments' && (
            <PaymentsView
              sim={simulationInstance}
              lang={lang}
            />
          )}

          {activeModule === 'markets' && (
            <FinancialMarketsView
              sim={simulationInstance}
              lang={lang}
            />
          )}

          {activeModule === 'dlt' && (
            <DLTView
              sim={simulationInstance}
              lang={lang}
            />
          )}

          {activeModule === 'banking' && (
            <BankingView
              sim={simulationInstance}
              lang={lang}
            />
          )}

          {activeModule === 'nordic' && (
            <NordicView
              sim={simulationInstance}
              lang={lang}
            />
          )}

          {activeModule === 'research' && (
            <ResearchLabsView
              sim={simulationInstance}
              lang={lang}
              activeSubView={activeSubView}
            />
          )}

          {activeModule === 'control_room' && (
            <ControlRoomView
              sim={simulationInstance}
              lang={lang}
              activeSubView={activeSubView}
            />
          )}
        </main>
      </div>
    </div>
  );
}
