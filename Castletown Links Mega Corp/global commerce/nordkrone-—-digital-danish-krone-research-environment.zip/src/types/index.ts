export type Language = 'da' | 'en';

export type EntityType = 
  | 'CentralBank'
  | 'CommercialBank'
  | 'PaymentInstitution'
  | 'Wallet'
  | 'Merchant'
  | 'Consumer'
  | 'Government'
  | 'FinancialMarketInfrastructure';

export type TransactionType =
  | 'ISSUE'
  | 'REDEEM'
  | 'TRANSFER'
  | 'MERCHANT_PAYMENT'
  | 'INTERBANK_TRANSFER'
  | 'SECURITIES_SETTLEMENT'
  | 'FX_SETTLEMENT'
  | 'COLLATERAL_TRANSFER'
  | 'REPO'
  | 'REFUND'
  | 'REVERSAL';

export type SettlementStatus = 'INITIATED' | 'PENDING' | 'AUTHORISED' | 'SETTLED' | 'CONFIRMED' | 'FAILED' | 'QUEUED';

export type PaymentChannel = 
  | 'DIGITAL_KRONE'
  | 'BANK_TRANSFER'
  | 'INSTANT_PAYMENT'
  | 'CARD'
  | 'CASH'
  | 'TOKENISED_DEPOSIT';

export interface DigitalKrone {
  amount: number;
  currency: 'DKK';
  issuer: 'Danmarks Nationalbank';
  ledger_reference: string;
  creation_timestamp: number;
  settlement_status: SettlementStatus;
}

export interface Account {
  id: string;
  name: string;
  type: EntityType;
  currency: string;
  balance: number;
  central_bank_reserves: number;
  cbdc_balance: number;
  commercial_deposits: number;
  holding_limit: number;
  daily_limit: number;
  offline_limit: number;
  status: 'ACTIVE' | 'FROZEN' | 'RESTRICTED';
}

export interface LedgerEntry {
  entry_id: string;
  transaction_id: string;
  account_id: string;
  account_name: string;
  debit: number;
  credit: number;
  currency: string;
  timestamp: number;
  description: string;
}

export interface Transaction {
  transaction_id: string;
  timestamp: number;
  sender_id: string;
  sender_name: string;
  receiver_id: string;
  receiver_name: string;
  amount: number;
  currency: string;
  type: TransactionType;
  channel: PaymentChannel;
  status: SettlementStatus;
  settlement_reference: string;
  correlation_id: string;
  risk_score?: number;
  note?: string;
  offline_flag?: boolean;
}

export interface CommercialBank {
  id: string;
  name: string;
  code: string;
  assets: {
    reserves_at_cb: number;
    cbdc_vault: number;
    loans: number;
    securities: number;
    other_assets: number;
  };
  liabilities: {
    customer_deposits: number;
    tokenised_deposits: number;
    cb_borrowing: number;
    capital: number;
  };
  liquidity_buffer: number;
  settlement_capacity: number;
  collateral_capacity: number;
  intraday_liquidity: number;
  stress_liquidity: number;
  cbdc_outflow_today: number;
}

export interface Bond {
  id: string;
  isin_sim: string;
  name: string;
  type: 'GOVERNMENT' | 'CORPORATE' | 'GREEN_BOND';
  face_value: number;
  coupon_rate: number;
  maturity_year: number;
  total_issued: number;
  owner_id: string;
  owner_name: string;
  settlement_asset: 'DKK' | 'DKK_DIGITAL' | 'EUR';
  price_pct: number;
}

export interface RepoTransaction {
  id: string;
  borrower_id: string;
  borrower_name: string;
  lender_id: string;
  lender_name: string;
  bond_isin: string;
  cash_amount: number;
  collateral_value: number;
  haircut_pct: number;
  repo_rate_pct: number;
  maturity_days: number;
  status: 'INITIATED' | 'ACTIVE' | 'SETTLED' | 'DEFAULTED';
  timestamp: number;
}

export interface TokenisedDeposit {
  id: string;
  issuing_bank_id: string;
  issuing_bank_name: string;
  holder_id: string;
  amount: number;
  currency: 'DKK';
  reserve_backing_pct: number;
  dlt_token_id: string;
}

export interface DLTBlock {
  block_height: number;
  hash: string;
  prev_hash: string;
  timestamp: number;
  transactions_count: number;
  validator: string;
  status: 'COMMITTED' | 'PENDING';
}

export interface DvPExecution {
  id: string;
  buyer_id: string;
  seller_id: string;
  asset_type: 'BOND' | 'EQUITY';
  asset_isin: string;
  asset_amount: number;
  cash_amount: number;
  status: 'PROPOSED' | 'LOCKED' | 'ATOMIC_SETTLED' | 'FAILED_ABORTED';
  step: 'INIT' | 'ASSET_LOCK' | 'PAYMENT_LOCK' | 'ATOMIC_SWAP' | 'COMPLETE';
  timestamp: number;
}

export interface PvPExecution {
  id: string;
  party_a: string;
  party_b: string;
  currency_a: string;
  amount_a: number;
  currency_b: string;
  amount_b: number;
  exchange_rate: number;
  status: 'INITIATED' | 'LEG1_LOCKED' | 'LEG2_LOCKED' | 'ATOMIC_SWAPPED' | 'REVERTED';
  timestamp: number;
}

export interface NordicCountry {
  code: 'DK' | 'SE' | 'NO' | 'FI' | 'IS' | 'EU';
  name: string;
  central_bank: string;
  currency: string;
  fx_rate_to_dkk: number;
  instant_network: string;
  daily_cross_border_volume: number;
  status: 'ONLINE' | 'DEGRADED' | 'OFFLINE';
}

export interface OfflineTransaction {
  id: string;
  sender_device: string;
  receiver_device: string;
  amount: number;
  counter_seq: number;
  signature: string;
  timestamp: number;
  reconciled: boolean;
  status: 'PENDING_RECONCILIATION' | 'RECONCILED' | 'DOUBLE_SPEND_REJECTED' | 'EXPIRED';
}

export interface ResilienceScenario {
  id: string;
  name: string;
  active: boolean;
  type: 
    | 'NONE'
    | 'CARD_OUTAGE'
    | 'INSTANT_PAYMENT_OUTAGE'
    | 'DLT_OUTAGE'
    | 'CENTRAL_LEDGER_OUTAGE'
    | 'BANK_OUTAGE'
    | 'REGIONAL_NETWORK_FAILURE'
    | 'POWER_INTERRUPTION';
  severity_pct: number;
  affected_node?: string;
  queue_length: number;
  estimated_recovery_minutes: number;
}

export interface PrivacyLevelConfig {
  mode: 'HIGH_PRIVACY' | 'BALANCED' | 'HIGH_TRACEABILITY';
  central_bank_visibility: string;
  commercial_bank_visibility: string;
  merchant_visibility: string;
  zero_knowledge_proofs: boolean;
  audit_threshold_dkk: number;
}

export interface AMLRiskEvent {
  id: string;
  transaction_id: string;
  risk_score: number; // 0 - 100
  pattern: 'CIRCULAR_TRANSFER' | 'VELOCITY_SPIKE' | 'STRUCTURING' | 'MULE_NETWORK' | 'UNKNOWN_DEVICE';
  reason_codes: string[];
  status: 'FLAGGED' | 'UNDER_REVIEW' | 'CLEARED' | 'BLOCKED';
  timestamp: number;
}

export interface MapNode {
  id: string;
  city: string;
  lat: number;
  lng: number;
  retail_volume_24h: number;
  wholesale_volume_24h: number;
  active_wallets: number;
  latency_ms: number;
  status: 'NOMINAL' | 'DEGRADED' | 'OUTAGE';
}

export interface MacroVariables {
  money_supply_m0: number; // in billions DKK
  money_supply_m1: number;
  cbdc_supply: number;
  commercial_bank_deposits: number;
  velocity_of_money: number;
  simulated_gdp: number;
  cpi_inflation_pct: number;
  central_bank_policy_rate_pct: number;
  credit_growth_pct: number;
  retail_cbdc_adoption_pct: number;
  holding_limit_citizen: number;
  holding_limit_merchant: number;
  holding_limit_institution: number;
}

export interface SimulationClock {
  speed: 'REALTIME' | '2X' | '5X' | '10X' | 'PAUSED';
  current_tick: number;
  simulated_datetime: string;
  seed: number;
}

export interface ScenarioDefinition {
  id: string;
  name: string;
  name_da: string;
  description: string;
  description_da: string;
  adoption_rate: number;
  holding_limit: number;
  stress_mode: boolean;
  dlt_enabled: boolean;
  offline_event: boolean;
  outage_mode: string;
  metrics: {
    deposit_flight_pct: number;
    bank_liquidity_ratio: number;
    settlement_latency_ms: number;
    offline_volume: number;
    system_availability_pct: number;
  };
}

export interface MLModelOutput {
  model_name: string;
  version: string;
  training_samples: number;
  accuracy_or_r2: number;
  feature_importance: { feature: string; importance: number }[];
  confidence_score: number;
  prediction_summary: string;
  limitations_disclaimer: string;
}
