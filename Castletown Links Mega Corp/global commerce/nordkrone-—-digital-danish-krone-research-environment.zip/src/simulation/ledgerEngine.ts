import { Account, LedgerEntry, Transaction, TransactionType, PaymentChannel, SettlementStatus, EntityType } from '../types';

export class LedgerEngine {
  private accounts: Map<string, Account> = new Map();
  private entries: LedgerEntry[] = [];
  private transactions: Transaction[] = [];

  constructor() {
    this.initializeDefaultAccounts();
  }

  private initializeDefaultAccounts() {
    // 1. Danmarks Nationalbank (Central Bank)
    this.createAccount({
      id: 'CB_ISSUANCE_ACCT',
      name: 'Danmarks Nationalbank - Primary Issuance Account',
      type: 'CentralBank',
      currency: 'DKK',
      balance: 100000000000, // 100 Billion DKK
      central_bank_reserves: 100000000000,
      cbdc_balance: 12400000000, // 12.4 Billion in circulation
      commercial_deposits: 0,
      holding_limit: Infinity,
      daily_limit: Infinity,
      offline_limit: Infinity,
      status: 'ACTIVE'
    });

    this.createAccount({
      id: 'CB_WHOLESALE_RESERVES',
      name: 'Danmarks Nationalbank - Wholesale Settlement Vault',
      type: 'CentralBank',
      currency: 'DKK',
      balance: 45000000000,
      central_bank_reserves: 45000000000,
      cbdc_balance: 0,
      commercial_deposits: 0,
      holding_limit: Infinity,
      daily_limit: Infinity,
      offline_limit: Infinity,
      status: 'ACTIVE'
    });

    // 2. Commercial Banks
    const bankConfigs: { id: string; name: string; reserves: number; cbdc: number }[] = [
      { id: 'BANK_DANSKE', name: 'Danske Bank (DANSKE-SIM)', reserves: 18500000000, cbdc: 3200000000 },
      { id: 'BANK_NORDIC', name: 'Nordea Danmark (NORDIC-SIM)', reserves: 14200000000, cbdc: 2800000000 },
      { id: 'BANK_JUTLAND', name: 'Jyske Bank (JUTLAND-SIM)', reserves: 8400000000, cbdc: 1900000000 },
      { id: 'BANK_COPENHAGEN', name: 'Nykredit Bank (COPENHAGEN-SIM)', reserves: 9100000000, cbdc: 2100000000 },
      { id: 'BANK_FJORD', name: 'Sydbank / Spar Nord (FJORD-SIM)', reserves: 4800000000, cbdc: 1100000000 }
    ];

    bankConfigs.forEach(b => {
      this.createAccount({
        id: b.id,
        name: b.name,
        type: 'CommercialBank',
        currency: 'DKK',
        balance: b.reserves + b.cbdc,
        central_bank_reserves: b.reserves,
        cbdc_balance: b.cbdc,
        commercial_deposits: 35000000000,
        holding_limit: 50000000000,
        daily_limit: 10000000000,
        offline_limit: 500000000,
        status: 'ACTIVE'
      });
    });

    // 3. Government & FMIs
    this.createAccount({
      id: 'GOVT_TREASURY',
      name: 'Finansministeriet (Danish Ministry of Finance)',
      type: 'Government',
      currency: 'DKK',
      balance: 15000000000,
      central_bank_reserves: 15000000000,
      cbdc_balance: 0,
      commercial_deposits: 0,
      holding_limit: Infinity,
      daily_limit: Infinity,
      offline_limit: Infinity,
      status: 'ACTIVE'
    });

    this.createAccount({
      id: 'FMI_VP_SECURITIES',
      name: 'Euronext Securities Copenhagen (VP Securities)',
      type: 'FinancialMarketInfrastructure',
      currency: 'DKK',
      balance: 5000000000,
      central_bank_reserves: 5000000000,
      cbdc_balance: 0,
      commercial_deposits: 0,
      holding_limit: Infinity,
      daily_limit: Infinity,
      offline_limit: Infinity,
      status: 'ACTIVE'
    });

    // 4. Sample Retail Consumers & Merchants
    const consumerNames = [
      'Lars Møller (København)', 'Freja Nielsen (Aarhus)', 'Mikkel Jensen (Odense)',
      'Astrid Hansen (Aalborg)', 'Søren Pedersen (Esbjerg)', 'Sofie Andersen (Roskilde)',
      'Christian Berg (Hellerup)', 'Mette Christensen (Kolding)'
    ];

    consumerNames.forEach((name, idx) => {
      this.createAccount({
        id: `CONSUMER_${idx + 1}`,
        name: name,
        type: 'Consumer',
        currency: 'DKK',
        balance: 12500 + idx * 2400,
        central_bank_reserves: 0,
        cbdc_balance: 12500 + idx * 2400,
        commercial_deposits: 45000 + idx * 8000,
        holding_limit: 30000,
        daily_limit: 10000,
        offline_limit: 3000,
        status: 'ACTIVE'
      });
    });

    const merchantNames = [
      'Netto Supermarked (Copenhagen Central)', 'Irma Gourmet (Torvehallerne)', '7-Eleven Nørreport Station',
      'Illum Department Store', 'Joe & The Juice Amagertorv', 'Lagkagehuset Vesterbro',
      'Matas ApS Aarhus', 'DSB Billet Salg'
    ];

    merchantNames.forEach((name, idx) => {
      this.createAccount({
        id: `MERCHANT_${idx + 1}`,
        name: name,
        type: 'Merchant',
        currency: 'DKK',
        balance: 145000 + idx * 62000,
        central_bank_reserves: 0,
        cbdc_balance: 145000 + idx * 62000,
        commercial_deposits: 850000 + idx * 120000,
        holding_limit: 500000,
        daily_limit: 250000,
        offline_limit: 25000,
        status: 'ACTIVE'
      });
    });
  }

  public createAccount(account: Account): Account {
    this.accounts.set(account.id, { ...account });
    return account;
  }

  public getAccount(id: string): Account | undefined {
    return this.accounts.get(id);
  }

  public getAllAccounts(): Account[] {
    return Array.from(this.accounts.values());
  }

  public getAccountsByType(type: EntityType): Account[] {
    return Array.from(this.accounts.values()).filter(a => a.type === type);
  }

  public getLedgerEntries(): LedgerEntry[] {
    return [...this.entries];
  }

  public getTransactions(): Transaction[] {
    return [...this.transactions];
  }

  public recordTransaction(params: {
    sender_id: string;
    receiver_id: string;
    amount: number;
    currency?: string;
    type: TransactionType;
    channel: PaymentChannel;
    note?: string;
    offline_flag?: boolean;
    override_limit_check?: boolean;
  }): { success: boolean; transaction?: Transaction; error?: string } {
    const currency = params.currency || 'DKK';
    const sender = this.accounts.get(params.sender_id);
    const receiver = this.accounts.get(params.receiver_id);

    if (!sender) return { success: false, error: `Sender account '${params.sender_id}' not found.` };
    if (!receiver) return { success: false, error: `Receiver account '${params.receiver_id}' not found.` };
    if (params.amount <= 0) return { success: false, error: 'Transaction amount must be positive.' };

    // Limit check for retail holding
    if (!params.override_limit_check && receiver.holding_limit !== Infinity) {
      if (receiver.balance + params.amount > receiver.holding_limit) {
        return {
          success: false,
          error: `Holding limit exceeded. Receiver limit: ${receiver.holding_limit.toLocaleString('da-DK')} DKK.`
        };
      }
    }

    // Sufficient balance check
    if (sender.balance < params.amount && sender.type !== 'CentralBank') {
      return { success: false, error: `Insufficient funds. Available: ${sender.balance.toLocaleString('da-DK')} DKK.` };
    }

    const txId = `TX_${Date.now()}_${Math.floor(Math.random() * 10000)}`;
    const timestamp = Date.now();
    const correlationId = `CORR_${Math.random().toString(36).substr(2, 9)}`;

    // Create double-entry records
    const debitEntry: LedgerEntry = {
      entry_id: `ENT_${timestamp}_1`,
      transaction_id: txId,
      account_id: sender.id,
      account_name: sender.name,
      debit: params.amount,
      credit: 0,
      currency: currency,
      timestamp: timestamp,
      description: `Transfer to ${receiver.name} (${params.type})`
    };

    const creditEntry: LedgerEntry = {
      entry_id: `ENT_${timestamp}_2`,
      transaction_id: txId,
      account_id: receiver.id,
      account_name: receiver.name,
      debit: 0,
      credit: params.amount,
      currency: currency,
      timestamp: timestamp,
      description: `Transfer from ${sender.name} (${params.type})`
    };

    this.entries.unshift(debitEntry, creditEntry);

    // Update account balances
    sender.balance -= params.amount;
    if (params.channel === 'DIGITAL_KRONE') {
      sender.cbdc_balance = Math.max(0, sender.cbdc_balance - params.amount);
    } else {
      sender.central_bank_reserves = Math.max(0, sender.central_bank_reserves - params.amount);
    }

    receiver.balance += params.amount;
    if (params.channel === 'DIGITAL_KRONE') {
      receiver.cbdc_balance += params.amount;
    } else {
      receiver.central_bank_reserves += params.amount;
    }

    const transaction: Transaction = {
      transaction_id: txId,
      timestamp: timestamp,
      sender_id: sender.id,
      sender_name: sender.name,
      receiver_id: receiver.id,
      receiver_name: receiver.name,
      amount: params.amount,
      currency: currency,
      type: params.type,
      channel: params.channel,
      status: 'CONFIRMED',
      settlement_reference: `SETTLE_${timestamp}`,
      correlation_id: correlationId,
      risk_score: Math.floor(Math.random() * 15),
      note: params.note,
      offline_flag: params.offline_flag || false
    };

    this.transactions.unshift(transaction);
    if (this.transactions.length > 500) {
      this.transactions.pop();
    }

    return { success: true, transaction };
  }

  public calculateDerivedBalance(accountId: string): number {
    let balance = 0;
    for (const entry of this.entries) {
      if (entry.account_id === accountId) {
        balance += entry.credit - entry.debit;
      }
    }
    return balance;
  }

  public issueCBDC(amount: number, targetBankId: string): { success: boolean; transaction?: Transaction; error?: string } {
    return this.recordTransaction({
      sender_id: 'CB_ISSUANCE_ACCT',
      receiver_id: targetBankId,
      amount: amount,
      type: 'ISSUE',
      channel: 'DIGITAL_KRONE',
      note: 'Danmarks Nationalbank CBDC Issuance to Bank'
    });
  }

  public redeemCBDC(amount: number, fromBankId: string): { success: boolean; transaction?: Transaction; error?: string } {
    return this.recordTransaction({
      sender_id: fromBankId,
      receiver_id: 'CB_ISSUANCE_ACCT',
      amount: amount,
      type: 'REDEEM',
      channel: 'DIGITAL_KRONE',
      note: 'CBDC Redemption to Central Bank Reserves'
    });
  }

  public setHoldingLimit(accountType: 'Consumer' | 'Merchant' | 'CommercialBank', limit: number) {
    this.accounts.forEach(acc => {
      if (acc.type === accountType) {
        acc.holding_limit = limit;
      }
    });
  }
}
