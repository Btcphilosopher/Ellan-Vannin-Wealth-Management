import { OfflineTransaction } from '../types';

export class OfflineEngine {
  private offlineQueue: OfflineTransaction[] = [];
  private allocatedOfflineBalanceDKK = 18500000; // 18.5M DKK allocated offline across devices
  private deviceCounterMap: Map<string, number> = new Map();

  constructor() {
    this.initializeQueue();
  }

  private initializeQueue() {
    this.offlineQueue = [
      {
        id: 'OFF_201',
        sender_device: 'SECURE_ELEMENT_DK_7801',
        receiver_device: 'POS_TERMINAL_DK_9942',
        amount: 275,
        counter_seq: 14,
        signature: 'SIG_ED25519_9a8f7c6b5a4',
        timestamp: Date.now() - 3600000,
        reconciled: true,
        status: 'RECONCILED'
      },
      {
        id: 'OFF_202',
        sender_device: 'SECURE_ELEMENT_DK_8812',
        receiver_device: 'POS_TERMINAL_DK_9942',
        amount: 450,
        counter_seq: 3,
        signature: 'SIG_ED25519_1b2c3d4e5f6',
        timestamp: Date.now() - 1800000,
        reconciled: false,
        status: 'PENDING_RECONCILIATION'
      }
    ];

    this.deviceCounterMap.set('SECURE_ELEMENT_DK_7801', 14);
    this.deviceCounterMap.set('SECURE_ELEMENT_DK_8812', 3);
  }

  public getQueue(): OfflineTransaction[] {
    return [...this.offlineQueue];
  }

  public getAllocatedOfflineBalance(): number {
    return this.allocatedOfflineBalanceDKK;
  }

  public simulateOfflinePayment(params: {
    senderDevice: string;
    receiverDevice: string;
    amount: number;
    simulateDoubleSpend?: boolean;
  }): { success: boolean; transaction: OfflineTransaction; message: string } {
    const currentSeq = (this.deviceCounterMap.get(params.senderDevice) || 0) + 1;

    let seqToUse = currentSeq;
    if (params.simulateDoubleSpend) {
      // Intentionally reuse a sequence counter to trigger duplicate spend rejection
      seqToUse = currentSeq - 1;
    } else {
      this.deviceCounterMap.set(params.senderDevice, currentSeq);
    }

    const tx: OfflineTransaction = {
      id: `OFF_${Math.floor(100 + Math.random() * 900)}`,
      sender_device: params.senderDevice,
      receiver_device: params.receiverDevice,
      amount: params.amount,
      counter_seq: seqToUse,
      signature: `SIG_ED25519_${Math.random().toString(16).substr(2, 10)}`,
      timestamp: Date.now(),
      reconciled: false,
      status: params.simulateDoubleSpend ? 'DOUBLE_SPEND_REJECTED' : 'PENDING_RECONCILIATION'
    };

    this.offlineQueue.unshift(tx);

    if (params.simulateDoubleSpend) {
      return {
        success: false,
        transaction: tx,
        message: `ALERT: Double-spending attempt detected! Sequence counter ${seqToUse} previously spent.`
      };
    }

    return {
      success: true,
      transaction: tx,
      message: `Offline transaction of DKK ${params.amount} signed via hardware Secure Element.`
    };
  }

  public reconcileAllPending(): { reconciledCount: number; totalAmountReconciled: number } {
    let count = 0;
    let total = 0;

    this.offlineQueue.forEach(tx => {
      if (tx.status === 'PENDING_RECONCILIATION') {
        tx.status = 'RECONCILED';
        tx.reconciled = true;
        count++;
        total += tx.amount;
      }
    });

    return { reconciledCount: count, totalAmountReconciled: total };
  }
}
