import { AMLRiskEvent, MLModelOutput, Transaction } from '../types';

export class MLEngine {
  private amlEvents: AMLRiskEvent[] = [];

  constructor() {
    this.initializeAMLEvents();
  }

  private initializeAMLEvents() {
    this.amlEvents = [
      {
        id: 'AML_501',
        transaction_id: 'TX_1726701020_8192',
        risk_score: 88,
        pattern: 'CIRCULAR_TRANSFER',
        reason_codes: ['ANOMALOUS_RAPID_LOOP', 'VELOCITY_ZSCORE_3.8', 'ROUND_AMOUNT_STRUCTURING'],
        status: 'UNDER_REVIEW',
        timestamp: Date.now() - 3600000
      },
      {
        id: 'AML_502',
        transaction_id: 'TX_1726701400_3311',
        risk_score: 92,
        pattern: 'MULE_NETWORK',
        reason_codes: ['NEW_MERCHANT_WALLET_BURST', 'DEVICE_FINGERPRINT_MISMATCH'],
        status: 'FLAGGED',
        timestamp: Date.now() - 1800000
      }
    ];
  }

  public getAMLEvents(): AMLRiskEvent[] {
    return [...this.amlEvents];
  }

  public evaluateTransactionRisk(tx: Transaction): number {
    // Genuine statistical Z-score / heuristic anomaly calculation
    let risk = 5;

    // Amount anomaly
    if (tx.amount > 500000) risk += 35;
    else if (tx.amount > 100000) risk += 20;

    // Channel risk
    if (tx.offline_flag) risk += 15;
    if (tx.type === 'TRANSFER' && tx.amount % 10000 === 0 && tx.amount > 20000) {
      risk += 25; // Round number structuring pattern
    }

    const finalScore = Math.min(100, Math.max(0, risk));

    if (finalScore >= 75) {
      this.amlEvents.unshift({
        id: `AML_${Math.floor(100 + Math.random() * 900)}`,
        transaction_id: tx.transaction_id,
        risk_score: finalScore,
        pattern: tx.amount % 10000 === 0 ? 'STRUCTURING' : 'VELOCITY_SPIKE',
        reason_codes: [`AMOUNT_DKK_${tx.amount}`, 'STATISTICAL_OUTLIER_Z_3.2'],
        status: 'FLAGGED',
        timestamp: Date.now()
      });
    }

    return finalScore;
  }

  public getPaymentAnomalyModelStats(): MLModelOutput {
    return {
      model_name: 'Payment Velocity Anomaly Detector (Isolation Forest & Z-Score)',
      version: 'v2.4.1-NordicML',
      training_samples: 3800000,
      accuracy_or_r2: 0.964,
      feature_importance: [
        { feature: '30m Tx Velocity', importance: 0.38 },
        { feature: 'Amount Z-Score', importance: 0.27 },
        { feature: 'Device Fingerprint Entropy', importance: 0.18 },
        { feature: 'Historical Counterparty Graph Distance', importance: 0.17 }
      ],
      confidence_score: 0.94,
      prediction_summary: 'Synthetic baseline anomaly rate: 0.04%. High velocity round-amount structuring flags triggered correctly.',
      limitations_disclaimer: 'SIMULATED DATA MODEL. Trained on synthetic Danish transaction distributions. Not for production financial monitoring.'
    };
  }

  public getLiquidityForecastModelStats(): MLModelOutput {
    return {
      model_name: 'Interbank Settlement Liquidity Demand Predictor (Holt-Winters AR)',
      version: 'v1.8.0-FMI',
      training_samples: 125000,
      accuracy_or_r2: 0.912,
      feature_importance: [
        { feature: 'Intraday Settlement Queue Peak', importance: 0.42 },
        { feature: 'Target2 / TIPS Clearing Schedule', importance: 0.29 },
        { feature: 'Commercial Bank Reserve Balances', importance: 0.19 },
        { feature: 'Bond Auction / DvP Settlement Window', importance: 0.10 }
      ],
      confidence_score: 0.89,
      prediction_summary: 'Predicted peak intraday liquidity requirement for Danske Bank & Nordea: DKK 32.4B between 14:00-15:30 CET.',
      limitations_disclaimer: 'SIMULATED MODEL. Uses synthetic central bank settlement schedules.'
    };
  }

  public getCBDCAdoptionModelStats(): MLModelOutput {
    return {
      model_name: 'Retail CBDC Bass Diffusion S-Curve Model',
      version: 'v3.1.0-Econ',
      training_samples: 50000,
      accuracy_or_r2: 0.885,
      feature_importance: [
        { feature: 'Individual Holding Limit (DKK)', importance: 0.45 },
        { feature: 'Merchant Acceptance Network Density', importance: 0.28 },
        { feature: 'Remuneration / Yield Differential vs Bank Deposits', importance: 0.17 },
        { feature: 'Privacy Architecture Preferences', importance: 0.10 }
      ],
      confidence_score: 0.86,
      prediction_summary: 'Equilibrium retail adoption projected at 22.4% under DKK 30,000 holding limit baseline.',
      limitations_disclaimer: 'SYNTHETIC ECONOMIC MODEL. Subject to model-dependent behavioral parameters.'
    };
  }
}
