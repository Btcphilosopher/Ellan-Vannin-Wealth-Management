import { DLTBlock, DvPExecution, PvPExecution } from '../types';

export class DLTEngine {
  private blocks: DLTBlock[] = [];
  private dvpExecutions: DvPExecution[] = [];
  private pvpExecutions: PvPExecution[] = [];

  constructor() {
    this.initializeGenesisBlock();
    this.initializeSampleExecutions();
  }

  private initializeGenesisBlock() {
    this.blocks.push({
      block_height: 104520,
      hash: '0x8f2a9d1e4c3b5a7f9e1d2c3b4a5f6e7d8c9b0a1f2e3d4c5b6a7f8e9d0c1b2a3',
      prev_hash: '0x000000000000000000000000000000000000000000000000000000000000000',
      timestamp: Date.now() - 3600000,
      transactions_count: 142,
      validator: 'Danmarks Nationalbank Validator Node 1',
      status: 'COMMITTED'
    });

    for (let i = 1; i <= 8; i++) {
      const prevHash = this.blocks[this.blocks.length - 1].hash;
      this.blocks.push({
        block_height: 104520 + i,
        hash: `0x${Math.random().toString(16).substr(2, 64).padEnd(64, 'a')}`,
        prev_hash: prevHash,
        timestamp: Date.now() - (3600000 - i * 400000),
        transactions_count: Math.floor(80 + Math.random() * 120),
        validator: `Nordic FMI Validator Node ${(i % 4) + 1}`,
        status: 'COMMITTED'
      });
    }
  }

  private initializeSampleExecutions() {
    this.dvpExecutions = [
      {
        id: 'DVP_9021',
        buyer_id: 'BANK_DANSKE',
        seller_id: 'BANK_NORDIC',
        asset_type: 'BOND',
        asset_isin: 'DK0009924538 (DGB 2033)',
        asset_amount: 50000000, // 50M DKK Bonds
        cash_amount: 51250000,  // 51.25M DKK Money
        status: 'ATOMIC_SETTLED',
        step: 'COMPLETE',
        timestamp: Date.now() - 1200000
      },
      {
        id: 'DVP_9022',
        buyer_id: 'BANK_JUTLAND',
        seller_id: 'BANK_COPENHAGEN',
        asset_type: 'BOND',
        asset_isin: 'DK0009928812 (DGB 2038)',
        asset_amount: 25000000,
        cash_amount: 24800000,
        status: 'PROPOSED',
        step: 'ASSET_LOCK',
        timestamp: Date.now() - 300000
      }
    ];

    this.pvpExecutions = [
      {
        id: 'PVP_7101',
        party_a: 'Danske Bank (DK)',
        party_b: 'SEB Stockholm (SE)',
        currency_a: 'DKK',
        amount_a: 10000000,
        currency_b: 'SEK',
        amount_b: 15450000,
        exchange_rate: 1.545,
        status: 'ATOMIC_SWAPPED',
        timestamp: Date.now() - 900000
      },
      {
        id: 'PVP_7102',
        party_a: 'Nordea Danmark (DK)',
        party_b: 'BNP Paribas Frankfurt (EU)',
        currency_a: 'DKK',
        amount_a: 25000000,
        currency_b: 'EUR',
        amount_b: 3350000,
        exchange_rate: 7.4625,
        status: 'LEG1_LOCKED',
        timestamp: Date.now() - 150000
      }
    ];
  }

  public getBlocks(): DLTBlock[] {
    return [...this.blocks];
  }

  public getDvPExecutions(): DvPExecution[] {
    return [...this.dvpExecutions];
  }

  public getPvPExecutions(): PvPExecution[] {
    return [...this.pvpExecutions];
  }

  public addBlock(txCount: number): DLTBlock {
    const prevBlock = this.blocks[this.blocks.length - 1];
    const newBlock: DLTBlock = {
      block_height: prevBlock.block_height + 1,
      hash: `0x${Math.random().toString(16).substr(2, 64).padEnd(64, 'f')}`,
      prev_hash: prevBlock.hash,
      timestamp: Date.now(),
      transactions_count: txCount,
      validator: 'Danmarks Nationalbank Validator Node 1',
      status: 'COMMITTED'
    };

    this.blocks.push(newBlock);
    if (this.blocks.length > 50) this.blocks.shift();
    return newBlock;
  }

  public executeAtomicDvP(
    buyerId: string,
    sellerId: string,
    isin: string,
    assetAmount: number,
    cashAmount: number,
    failScenario: boolean = false
  ): DvPExecution {
    const id = `DVP_${Math.floor(1000 + Math.random() * 9000)}`;

    const execution: DvPExecution = {
      id,
      buyer_id: buyerId,
      seller_id: sellerId,
      asset_type: 'BOND',
      asset_isin: isin,
      asset_amount: assetAmount,
      cash_amount: cashAmount,
      status: failScenario ? 'FAILED_ABORTED' : 'ATOMIC_SETTLED',
      step: failScenario ? 'PAYMENT_LOCK' : 'COMPLETE',
      timestamp: Date.now()
    };

    this.dvpExecutions.unshift(execution);
    return execution;
  }

  public executeAtomicPvP(
    partyA: string,
    partyB: string,
    currA: string,
    amountA: number,
    currB: string,
    amountB: number,
    failScenario: boolean = false
  ): PvPExecution {
    const id = `PVP_${Math.floor(1000 + Math.random() * 9000)}`;
    const rate = amountB / amountA;

    const execution: PvPExecution = {
      id,
      party_a: partyA,
      party_b: partyB,
      currency_a: currA,
      amount_a: amountA,
      currency_b: currB,
      amount_b: amountB,
      exchange_rate: Number(rate.toFixed(4)),
      status: failScenario ? 'REVERTED' : 'ATOMIC_SWAPPED',
      timestamp: Date.now()
    };

    this.pvpExecutions.unshift(execution);
    return execution;
  }
}
