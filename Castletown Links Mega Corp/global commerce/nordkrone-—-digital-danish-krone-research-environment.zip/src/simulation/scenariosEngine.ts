import { ScenarioDefinition } from '../types';

export class ScenariosEngine {
  private scenarios: Map<string, ScenarioDefinition> = new Map();

  constructor() {
    this.initializeScenarios();
  }

  private initializeScenarios() {
    const list: ScenarioDefinition[] = [
      {
        id: 'BASELINE',
        name: 'Baseline Operational State',
        name_da: 'Standard Driftstilstand',
        description: 'Standard Danish monetary system configuration. Moderate retail CBDC adoption (15%), normal liquidity buffers, nominal DLT throughput.',
        description_da: 'Standard dansk monetær konfiguration. Moderat digital krone udbredelse (15%), normale likviditetsbuffere, nominel DLT kapacitet.',
        adoption_rate: 15,
        holding_limit: 30000,
        stress_mode: false,
        dlt_enabled: true,
        offline_event: false,
        outage_mode: 'NONE',
        metrics: {
          deposit_flight_pct: 2.1,
          bank_liquidity_ratio: 1.45,
          settlement_latency_ms: 120,
          offline_volume: 18500000,
          system_availability_pct: 99.99
        }
      },
      {
        id: 'HIGH_CBDC_ADOPTION',
        name: 'Scenario 1: High Retail CBDC Adoption',
        name_da: 'Scenarie 1: Høj Digital Krone Udbredelse',
        description: 'Rapid shift of household deposits into Digital Krone (50% adoption). Models deposit flight, bank liquidity pressure, and central bank reserve contraction.',
        description_da: 'Hurtig forskydning af indlån til digital krone (50% udbredelse). Modellerer indlånsflugt, likviditetspres og centralbankreserver.',
        adoption_rate: 50,
        holding_limit: 100000,
        stress_mode: false,
        dlt_enabled: true,
        offline_event: false,
        outage_mode: 'NONE',
        metrics: {
          deposit_flight_pct: 18.4,
          bank_liquidity_ratio: 1.12,
          settlement_latency_ms: 145,
          offline_volume: 45000000,
          system_availability_pct: 99.98
        }
      },
      {
        id: 'WHOLESALE_TOKENISED_BOND',
        name: 'Scenario 2: Wholesale Tokenised Bond Market',
        name_da: 'Scenarie 2: Engros Tokeniseret Obligationsmarked',
        description: 'Primary issuance and secondary trading of Danish Government Bonds (DGB-2033/2038) settled atomically (DvP) against Wholesale CBDC on DLT.',
        description_da: 'Primærudstedelse og sekundær handel med danske statsobligationer afviklet atomart (DvP) mod engros CBDC på DLT.',
        adoption_rate: 20,
        holding_limit: 50000000,
        stress_mode: false,
        dlt_enabled: true,
        offline_event: false,
        outage_mode: 'NONE',
        metrics: {
          deposit_flight_pct: 3.2,
          bank_liquidity_ratio: 1.58,
          settlement_latency_ms: 45,
          offline_volume: 12000000,
          system_availability_pct: 100.0
        }
      },
      {
        id: 'NORDIC_CROSS_BORDER_SURGE',
        name: 'Scenario 3: Cross-Border DKK/SEK Payment Surge',
        name_da: 'Scenarie 3: Grænseoverskridende DKK/SEK Betalingsbølge',
        description: 'High-volume instant cross-border liquidity demand between Denmark and Sweden. Evaluates atomic Payment-versus-Payment (PvP) & TIPS DKK liquidity queues.',
        description_da: 'Højvolumen øjeblikkelig grænseoverskridende likviditetsefterspørgsel mellem Danmark og Sverige. Evaluere atomar PvP og TIPS likviditetskøer.',
        adoption_rate: 25,
        holding_limit: 30000,
        stress_mode: false,
        dlt_enabled: true,
        offline_event: false,
        outage_mode: 'NONE',
        metrics: {
          deposit_flight_pct: 4.0,
          bank_liquidity_ratio: 1.38,
          settlement_latency_ms: 380,
          offline_volume: 22000000,
          system_availability_pct: 99.95
        }
      },
      {
        id: 'NATIONAL_PAYMENT_OUTAGE',
        name: 'Scenario 4: National Payment Infrastructure Outage',
        name_da: 'Scenarie 4: National Betalingsinfrastruktur Afbrydelse',
        description: 'Simulates card & instant payment network outages. System relies on offline Digital Krone secure elements and delayed batch reconciliation.',
        description_da: 'Simulerer kort- og straksclearing-afbrydelser. Systemet støtter sig til offline digital krone og forsinket genforening.',
        adoption_rate: 30,
        holding_limit: 30000,
        stress_mode: true,
        dlt_enabled: false,
        offline_event: true,
        outage_mode: 'INSTANT_PAYMENT_OUTAGE',
        metrics: {
          deposit_flight_pct: 8.5,
          bank_liquidity_ratio: 1.08,
          settlement_latency_ms: 4200,
          offline_volume: 185000000,
          system_availability_pct: 82.4
        }
      },
      {
        id: 'BANKING_LIQUIDITY_STRESS',
        name: 'Scenario 5: Commercial Bank Liquidity Stress',
        name_da: 'Scenarie 5: Kommerciel Bank Likviditetsstres',
        description: 'Severe macroeconomic liquidity shock and rapid deposit outflow at Danske Bank & Jyske Bank. Triggers Central Bank emergency liquidity facilities.',
        description_da: 'Alvorligt makroøkonomisk likviditetschok og hurtig indlånsudstrømning i Danske Bank og Jyske Bank. Udløser nødlikviditetsfaciliteter.',
        adoption_rate: 45,
        holding_limit: 100000,
        stress_mode: true,
        dlt_enabled: true,
        offline_event: false,
        outage_mode: 'BANK_OUTAGE',
        metrics: {
          deposit_flight_pct: 28.6,
          bank_liquidity_ratio: 0.88,
          settlement_latency_ms: 1850,
          offline_volume: 65000000,
          system_availability_pct: 94.2
        }
      }
    ];

    list.forEach(s => this.scenarios.set(s.id, s));
  }

  public getScenarios(): ScenarioDefinition[] {
    return Array.from(this.scenarios.values());
  }

  public getScenario(id: string): ScenarioDefinition | undefined {
    return this.scenarios.get(id);
  }
}
