import { LedgerEngine } from './ledgerEngine';
import { BankEngine } from './bankEngine';
import { DLTEngine } from './dltEngine';
import { SecuritiesEngine } from './securitiesEngine';
import { NordicEngine } from './nordicEngine';
import { OfflineEngine } from './offlineEngine';

export class CLIEngine {
  constructor(
    private ledger: LedgerEngine,
    private banks: BankEngine,
    private dlt: DLTEngine,
    private securities: SecuritiesEngine,
    private nordic: NordicEngine,
    private offline: OfflineEngine
  ) {}

  public executeCommand(input: string): { output: string; status: 'SUCCESS' | 'ERROR' | 'INFO' } {
    const trimmed = input.trim();
    if (!trimmed) return { output: '', status: 'INFO' };

    const parts = trimmed.split(/\s+/);
    const cmd = parts[0].toLowerCase();
    const subCmd = parts[1] ? parts[1].toLowerCase() : '';

    try {
      // 1. nordkrone status
      if (cmd === 'nordkrone' && subCmd === 'status') {
        const totalCBDC = 12400000000;
        const activeWallets = 1250000;
        const totalReserves = this.ledger.getAccount('CB_ISSUANCE_ACCT')?.balance || 0;
        return {
          status: 'SUCCESS',
          output: `[NORDKRONE DIGITAL TWIN STATUS]
--------------------------------------------------
System Status      : NOMINAL
Ledger State       : SYNCHRONISED
CBDC Supply (M0)   : DKK ${(totalCBDC / 1e9).toFixed(2)} Billion
Central Bank Vault : DKK ${(totalReserves / 1e9).toFixed(2)} Billion
Active Wallets     : ${activeWallets.toLocaleString('da-DK')}
Settlement Engine  : Kronos2 / TIPS / DLT Atomic
Deterministic Seed : 2026`
        };
      }

      // 2. cbdc supply / issue / redeem
      if (cmd === 'cbdc') {
        if (subCmd === 'supply') {
          return {
            status: 'SUCCESS',
            output: `[DIGITAL KRONE SUPPLY STATISTICS]
In Circulation     : DKK 12.400.000.000 (12.4 Billion DKK)
Wholesale Vault    : DKK 45.000.000.000
Bank Reserves      : DKK 55.000.000.000
Accounting Origin  : Danmarks Nationalbank Issuance Ledger Ref #DN-DKK-DIGITAL-2026`
          };
        }

        if (subCmd === 'issue') {
          const amount = parseFloat(parts[2]) || 100000000; // 100M DKK default
          const bankId = parts[3] || 'BANK_DANSKE';
          const res = this.ledger.issueCBDC(amount, bankId);
          if (res.success) {
            return {
              status: 'SUCCESS',
              output: `[CBDC ISSUANCE SUCCESSFUL]
Issued DKK ${amount.toLocaleString('da-DK')} from Danmarks Nationalbank to ${bankId}.
Tx ID: ${res.transaction?.transaction_id}
Status: CONFIRMED`
            };
          }
          return { status: 'ERROR', output: `CBDC Issuance Failed: ${res.error}` };
        }

        if (subCmd === 'redeem') {
          const amount = parseFloat(parts[2]) || 50000000;
          const bankId = parts[3] || 'BANK_DANSKE';
          const res = this.ledger.redeemCBDC(amount, bankId);
          if (res.success) {
            return {
              status: 'SUCCESS',
              output: `[CBDC REDEMPTION SUCCESSFUL]
Redeemed DKK ${amount.toLocaleString('da-DK')} from ${bankId} to Central Bank Reserves.
Tx ID: ${res.transaction?.transaction_id}`
            };
          }
          return { status: 'ERROR', output: `CBDC Redemption Failed: ${res.error}` };
        }
      }

      // 3. wallet list
      if (cmd === 'wallet' && subCmd === 'list') {
        const accounts = this.ledger.getAllAccounts().filter(a => a.type === 'Consumer' || a.type === 'Merchant');
        let out = `[SYNTHETIC WALLETS DIRECTORY]\n`;
        accounts.forEach(a => {
          out += `- ${a.name} (${a.id}) | Balance: DKK ${a.balance.toLocaleString('da-DK')} | Limit: ${a.holding_limit === Infinity ? 'Unlimited' : 'DKK ' + a.holding_limit.toLocaleString('da-DK')}\n`;
        });
        return { status: 'SUCCESS', output: out };
      }

      // 4. payment simulate
      if (cmd === 'payment' && subCmd === 'simulate') {
        const amount = parseFloat(parts[2]) || 275;
        const res = this.ledger.recordTransaction({
          sender_id: 'CONSUMER_1',
          receiver_id: 'MERCHANT_1',
          amount: amount,
          type: 'MERCHANT_PAYMENT',
          channel: 'DIGITAL_KRONE',
          note: 'CLI Simulated Merchant Payment'
        });

        if (res.success) {
          return {
            status: 'SUCCESS',
            output: `[RETAIL PAYMENT LIFECYCLE COMPLETED]
Step 1: INITIATED   - Consumer 1 sent DKK ${amount}
Step 2: AUTHORISED - Holding limit checked & cryptographic signature verified
Step 3: SETTLED    - Atomic double-entry debited & credited
Step 4: CONFIRMED  - Tx ID: ${res.transaction?.transaction_id}`
          };
        }
        return { status: 'ERROR', output: `Payment simulation failed: ${res.error}` };
      }

      // 5. banks status
      if (cmd === 'banks' && subCmd === 'status') {
        const bList = this.banks.getBanks();
        let out = `[COMMERCIAL BANKS BALANCE SHEET STATUS]\n`;
        bList.forEach(b => {
          out += `* ${b.name} (${b.code})\n  Reserves: DKK ${(b.assets.reserves_at_cb / 1e9).toFixed(2)}B | Deposits: DKK ${(b.liabilities.customer_deposits / 1e9).toFixed(2)}B | CBDC Vault: DKK ${(b.assets.cbdc_vault / 1e9).toFixed(2)}B\n`;
        });
        return { status: 'SUCCESS', output: out };
      }

      // 6. dlt status
      if (cmd === 'dlt' && subCmd === 'status') {
        const blocks = this.dlt.getBlocks();
        const latest = blocks[blocks.length - 1];
        return {
          status: 'SUCCESS',
          output: `[WHOLESALE DLT LEDGER STATUS]
Current Block Height : #${latest.block_height}
Latest Hash          : ${latest.hash.substring(0, 24)}...
Validator Node       : ${latest.validator}
Total Executions     : ${blocks.length} Blocks Committed
Atomic DvP Engine    : ONLINE
Atomic PvP Engine    : ONLINE`
        };
      }

      // 7. bond issue / settle
      if (cmd === 'bond') {
        if (subCmd === 'issue' || subCmd === 'settle') {
          const dvp = this.dlt.executeAtomicDvP('BANK_DANSKE', 'BANK_NORDIC', 'DK0009924538 (DGB 2033)', 50000000, 51250000);
          return {
            status: 'SUCCESS',
            output: `[ATOMIC DvP BOND SETTLEMENT COMPLETED]
DvP Execution ID : ${dvp.id}
Asset            : ${dvp.asset_isin}
Buyer            : ${dvp.buyer_id} | Seller: ${dvp.seller_id}
Bond Amount      : DKK ${dvp.asset_amount.toLocaleString('da-DK')}
Cash Amount      : DKK ${dvp.cash_amount.toLocaleString('da-DK')}
Status           : ATOMIC_SETTLED (Money & Bond Swapped Simultaneously)`
          };
        }
      }

      // 8. fx simulate
      if (cmd === 'fx' && subCmd === 'simulate') {
        const res = this.nordic.simulateCrossBorderPayment({
          sourceCountry: 'DK',
          targetCountry: 'SE',
          amountSourceCurrency: 10000000
        });
        return {
          status: 'SUCCESS',
          output: `[CROSS-BORDER FX ATOMIC PvP SIMULATION]
Source        : 10,000,000 DKK (Denmark)
Target        : ${res.targetAmount.toLocaleString('da-DK')} SEK (Sweden)
FX Rate       : 1 DKK = ${(1 / res.fxRate).toFixed(4)} SEK
PvP Status    : ${res.status}
Settlement    : TIPS DKK / RIX-INST SEK Atomic Gateway`
        };
      }

      // 9. repo simulate
      if (cmd === 'repo' && subCmd === 'simulate') {
        const repo = this.securities.createRepoTransaction({
          borrower_id: 'BANK_JUTLAND',
          borrower_name: 'Jyske Bank',
          lender_id: 'BANK_DANSKE',
          lender_name: 'Danske Bank',
          bond_isin: 'DK0009924538',
          cash_amount: 250000000,
          haircut_pct: 3.5,
          repo_rate_pct: 2.15,
          maturity_days: 7
        });
        return {
          status: 'SUCCESS',
          output: `[INSTITUTIONAL REPO TRANSACTION CREATED]
Repo ID          : ${repo.id}
Borrower         : ${repo.borrower_name} | Lender: ${repo.lender_name}
Cash Amount      : DKK ${repo.cash_amount.toLocaleString('da-DK')}
Pledged Collateral: DKK ${repo.collateral_value.toLocaleString('da-DK')} (Haircut: ${repo.haircut_pct}%)
Repo Rate        : ${repo.repo_rate_pct}% | Maturity: ${repo.maturity_days} Days`
        };
      }

      // 10. offline simulate
      if (cmd === 'offline' && subCmd === 'simulate') {
        const res = this.offline.simulateOfflinePayment({
          senderDevice: 'SECURE_ELEMENT_DK_7801',
          receiverDevice: 'POS_TERMINAL_DK_9942',
          amount: 350
        });
        return {
          status: 'SUCCESS',
          output: `[OFFLINE DEVICE-TO-DEVICE PAYMENT]
Tx ID      : ${res.transaction.id}
Amount     : DKK ${res.transaction.amount}
Sequence   : #${res.transaction.counter_seq}
Signature  : ${res.transaction.signature}
Status     : ${res.transaction.status}
Message    : ${res.message}`
        };
      }

      // 11. help
      if (cmd === 'help') {
        return {
          status: 'INFO',
          output: `[NORDKRONE CLI COMMANDS DIRECTORY]
- nordkrone status       : View overall digital twin status
- cbdc supply           : View CBDC supply breakdown
- cbdc issue <amt>      : Issue CBDC to bank
- cbdc redeem <amt>     : Redeem CBDC from bank
- wallet list           : View synthetic consumer and merchant wallets
- payment simulate <amt>: Simulate retail merchant payment
- banks status          : Display commercial bank balance sheets
- dlt status            : Display DLT ledger and block height
- bond settle           : Execute atomic DvP bond settlement
- fx simulate           : Execute cross-border DKK/SEK atomic PvP
- repo simulate         : Create institutional repo transaction
- offline simulate      : Execute offline device-to-device payment`
        };
      }

      return {
        status: 'ERROR',
        output: `Unknown command '${input}'. Type 'help' to view available commands.`
      };

    } catch (err: any) {
      return { status: 'ERROR', output: `Execution Error: ${err?.message || 'Unknown error'}` };
    }
  }
}
