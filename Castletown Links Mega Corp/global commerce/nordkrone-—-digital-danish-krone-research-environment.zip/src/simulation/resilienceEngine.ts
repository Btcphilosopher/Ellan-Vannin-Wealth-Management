import { ResilienceScenario } from '../types';

export class ResilienceEngine {
  private activeScenario: ResilienceScenario = {
    id: 'RES_NORMAL',
    name: 'Normal Operations (All Systems Synchronised)',
    active: false,
    type: 'NONE',
    severity_pct: 0,
    queue_length: 0,
    estimated_recovery_minutes: 0
  };

  private history: ResilienceScenario[] = [];

  public getActiveScenario(): ResilienceScenario {
    return { ...this.activeScenario };
  }

  public getHistory(): ResilienceScenario[] {
    return [...this.history];
  }

  public triggerOutage(
    type: ResilienceScenario['type'],
    severityPct: number,
    affectedNode?: string
  ): ResilienceScenario {
    const labels: Record<ResilienceScenario['type'], string> = {
      NONE: 'Normal Operations',
      CARD_OUTAGE: 'Dankort / Card Network Outage (National)',
      INSTANT_PAYMENT_OUTAGE: 'Straksclearing / Kronos2 Outage',
      DLT_OUTAGE: 'Wholesale DLT Validator Consensus Partition',
      CENTRAL_LEDGER_OUTAGE: 'Central Bank Core Ledger Failover Event',
      BANK_OUTAGE: 'Commercial Bank Core Banking Service Interruption',
      REGIONAL_NETWORK_FAILURE: 'Fiber Optic Backhaul Disruption (Jutland-Zealand)',
      POWER_INTERRUPTION: 'Substation Power Outage (Greater Copenhagen)'
    };

    const estRecovery = Math.ceil((severityPct / 100) * 120 + 15);
    const queueLength = Math.ceil((severityPct / 100) * 45000);

    this.activeScenario = {
      id: `RES_${Date.now()}`,
      name: labels[type],
      active: type !== 'NONE',
      type: type,
      severity_pct: severityPct,
      affected_node: affectedNode || 'National Grid',
      queue_length: queueLength,
      estimated_recovery_minutes: estRecovery
    };

    this.history.unshift({ ...this.activeScenario });
    return this.activeScenario;
  }

  public resolveOutage() {
    this.activeScenario = {
      id: 'RES_NORMAL',
      name: 'Normal Operations (All Systems Synchronised)',
      active: false,
      type: 'NONE',
      severity_pct: 0,
      queue_length: 0,
      estimated_recovery_minutes: 0
    };
  }
}
