import { CommercialBank } from '../types';

export class BankEngine {
  private banks: Map<string, CommercialBank> = new Map();

  constructor() {
    this.initializeBanks();
  }

  private initializeBanks() {
    const defaultBanks: CommercialBank[] = [
      {
        id: 'BANK_DANSKE',
        name: 'Danske Bank (DANSKE-SIM)',
        code: 'DANS',
        assets: {
          reserves_at_cb: 18500000000,
          cbdc_vault: 3200000000,
          loans: 125000000000,
          securities: 42000000000,
          other_assets: 8500000000
        },
        liabilities: {
          customer_deposits: 145000000000,
          tokenised_deposits: 12000000000,
          cb_borrowing: 5000000000,
          capital: 35200000000
        },
        liquidity_buffer: 21700000000,
        settlement_capacity: 18500000000,
        collateral_capacity: 38000000000,
        intraday_liquidity: 14200000000,
        stress_liquidity: 11000000000,
        cbdc_outflow_today: 450000000
      },
      {
        id: 'BANK_NORDIC',
        name: 'Nordea Danmark (NORDIC-SIM)',
        code: 'NDEA',
        assets: {
          reserves_at_cb: 14200000000,
          cbdc_vault: 2800000000,
          loans: 98000000000,
          securities: 31000000000,
          other_assets: 6200000000
        },
        liabilities: {
          customer_deposits: 112000000000,
          tokenised_deposits: 9500000000,
          cb_borrowing: 3800000000,
          capital: 26900000000
        },
        liquidity_buffer: 17000000000,
        settlement_capacity: 14200000000,
        collateral_capacity: 28000000000,
        intraday_liquidity: 11500000000,
        stress_liquidity: 8800000000,
        cbdc_outflow_today: 380000000
      },
      {
        id: 'BANK_JUTLAND',
        name: 'Jyske Bank (JUTLAND-SIM)',
        code: 'JYSK',
        assets: {
          reserves_at_cb: 8400000000,
          cbdc_vault: 1900000000,
          loans: 58000000000,
          securities: 19000000000,
          other_assets: 4100000000
        },
        liabilities: {
          customer_deposits: 64000000000,
          tokenised_deposits: 5200000000,
          cb_borrowing: 2100000000,
          capital: 20100000000
        },
        liquidity_buffer: 10300000000,
        settlement_capacity: 8400000000,
        collateral_capacity: 17000000000,
        intraday_liquidity: 6900000000,
        stress_liquidity: 5200000000,
        cbdc_outflow_today: 210000000
      },
      {
        id: 'BANK_COPENHAGEN',
        name: 'Nykredit Bank (COPENHAGEN-SIM)',
        code: 'NYKR',
        assets: {
          reserves_at_cb: 9100000000,
          cbdc_vault: 2100000000,
          loans: 64000000000,
          securities: 22000000000,
          other_assets: 4500000000
        },
        liabilities: {
          customer_deposits: 71000000000,
          tokenised_deposits: 6100000000,
          cb_borrowing: 2500000000,
          capital: 22100000000
        },
        liquidity_buffer: 11200000000,
        settlement_capacity: 9100000000,
        collateral_capacity: 19500000000,
        intraday_liquidity: 7500000000,
        stress_liquidity: 5800000000,
        cbdc_outflow_today: 260000000
      },
      {
        id: 'BANK_FJORD',
        name: 'Sydbank / Spar Nord (FJORD-SIM)',
        code: 'SYDP',
        assets: {
          reserves_at_cb: 4800000000,
          cbdc_vault: 1100000000,
          loans: 32000000000,
          securities: 11000000000,
          other_assets: 2300000000
        },
        liabilities: {
          customer_deposits: 36000000000,
          tokenised_deposits: 3100000000,
          cb_borrowing: 1200000000,
          capital: 10900000000
        },
        liquidity_buffer: 5900000000,
        settlement_capacity: 4800000000,
        collateral_capacity: 9800000000,
        intraday_liquidity: 3900000000,
        stress_liquidity: 2900000000,
        cbdc_outflow_today: 140000000
      }
    ];

    defaultBanks.forEach(b => this.banks.set(b.id, b));
  }

  public getBanks(): CommercialBank[] {
    return Array.from(this.banks.values());
  }

  public getBank(id: string): CommercialBank | undefined {
    return this.banks.get(id);
  }

  public simulateRetailCBDCAdoptionShift(adoptionPct: number) {
    // Model transmission: Retail CBDC Adoption ^ -> Bank Deposit Outflow -> Reserves Drop -> Wholesale Settlement Capacity change
    const baseAdoption = 15; // 15% default baseline
    const shiftDelta = (adoptionPct - baseAdoption) / 100;

    this.banks.forEach(bank => {
      const outflow = Math.floor(bank.liabilities.customer_deposits * shiftDelta * 0.12);
      if (outflow > 0) {
        // Outflow from bank deposits into CBDC
        bank.liabilities.customer_deposits -= outflow;
        bank.assets.reserves_at_cb = Math.max(1000000000, bank.assets.reserves_at_cb - outflow);
        bank.cbdc_outflow_today += outflow;
      } else if (outflow < 0) {
        // Inflow back into bank deposits
        const inflow = Math.abs(outflow);
        bank.liabilities.customer_deposits += inflow;
        bank.assets.reserves_at_cb += inflow;
      }

      // Recalculate metrics
      bank.liquidity_buffer = bank.assets.reserves_at_cb + bank.assets.cbdc_vault;
      bank.settlement_capacity = bank.assets.reserves_at_cb;
      bank.intraday_liquidity = Math.floor(bank.assets.reserves_at_cb * 0.75);
      bank.stress_liquidity = Math.floor(bank.assets.reserves_at_cb * 0.55);
    });
  }

  public triggerBankLiquidityStress(bankId: string, shockMagnitudePct: number) {
    const bank = this.banks.get(bankId);
    if (!bank) return;

    const depositShock = Math.floor(bank.liabilities.customer_deposits * (shockMagnitudePct / 100));
    bank.liabilities.customer_deposits -= depositShock;
    bank.assets.reserves_at_cb = Math.max(500000000, bank.assets.reserves_at_cb - depositShock);
    bank.cbdc_outflow_today += depositShock;

    bank.liquidity_buffer = bank.assets.reserves_at_cb + bank.assets.cbdc_vault;
    bank.settlement_capacity = bank.assets.reserves_at_cb;
    bank.stress_liquidity = Math.floor(bank.assets.reserves_at_cb * 0.4);
  }
}
