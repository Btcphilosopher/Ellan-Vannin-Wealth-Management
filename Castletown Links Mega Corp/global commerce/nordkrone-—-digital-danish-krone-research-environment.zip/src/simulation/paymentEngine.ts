import { PaymentChannel, Transaction } from '../types';

export interface ChannelVolume {
  channel: PaymentChannel;
  channel_name: string;
  volume_24h_dkk: number;
  tx_count_24h: number;
  share_pct: number;
  avg_latency_ms: number;
}

export class PaymentEngine {
  private channelDistribution: Record<PaymentChannel, number> = {
    DIGITAL_KRONE: 18,
    BANK_TRANSFER: 28,
    INSTANT_PAYMENT: 32,
    CARD: 14,
    CASH: 3,
    TOKENISED_DEPOSIT: 5
  };

  private baseDailyVolumeDKK = 3800000000; // 3.8 Billion DKK daily
  private baseDailyTxCount = 3800000;

  public getChannelVolumes(): ChannelVolume[] {
    const totalShare = Object.values(this.channelDistribution).reduce((a, b) => a + b, 0);

    const labels: Record<PaymentChannel, string> = {
      DIGITAL_KRONE: 'Digital Krone (CBDC)',
      BANK_TRANSFER: 'Bankoverførsel (Standard)',
      INSTANT_PAYMENT: 'Straksclearing (Instant)',
      CARD: 'Dankort / Debit Kort',
      CASH: 'Kontanter (Physical Cash)',
      TOKENISED_DEPOSIT: 'Tokenised Bank Deposits'
    };

    const latencies: Record<PaymentChannel, number> = {
      DIGITAL_KRONE: 120,
      BANK_TRANSFER: 14400000, // 4 hours batch
      INSTANT_PAYMENT: 450,
      CARD: 1200,
      CASH: 0,
      TOKENISED_DEPOSIT: 180
    };

    return (Object.keys(this.channelDistribution) as PaymentChannel[]).map(channel => {
      const share = (this.channelDistribution[channel] / totalShare) * 100;
      const vol = (this.baseDailyVolumeDKK * share) / 100;
      const count = Math.floor((this.baseDailyTxCount * share) / 100);

      return {
        channel,
        channel_name: labels[channel],
        volume_24h_dkk: vol,
        tx_count_24h: count,
        share_pct: Number(share.toFixed(1)),
        avg_latency_ms: latencies[channel]
      };
    });
  }

  public setAdoptionLevel(digitalKroneSharePct: number) {
    const remaining = 100 - digitalKroneSharePct;
    this.channelDistribution.DIGITAL_KRONE = digitalKroneSharePct;
    this.channelDistribution.INSTANT_PAYMENT = Math.max(5, Math.floor(remaining * 0.4));
    this.channelDistribution.BANK_TRANSFER = Math.max(5, Math.floor(remaining * 0.3));
    this.channelDistribution.CARD = Math.max(2, Math.floor(remaining * 0.18));
    this.channelDistribution.TOKENISED_DEPOSIT = Math.max(1, Math.floor(remaining * 0.08));
    this.channelDistribution.CASH = Math.max(0.5, Number((remaining * 0.04).toFixed(1)));
  }

  public simulateRetailLifecycle(
    consumerId: string,
    merchantId: string,
    amount: number
  ): {
    lifecycle: { step: string; timestamp: number; detail: string }[];
    totalTimeMs: number;
  } {
    const now = Date.now();
    const steps = [
      { step: 'INITIATED', timestamp: now, detail: `Consumer initiated payment of DKK ${amount.toLocaleString('da-DK')} to merchant terminal` },
      { step: 'AUTHORISED', timestamp: now + 40, detail: 'Digital signature verified & holding limit checked' },
      { step: 'SETTLED', timestamp: now + 95, detail: 'Atomic double-entry ledger debit & credit recorded on Central Bank ledger' },
      { step: 'CONFIRMED', timestamp: now + 120, detail: 'Merchant POS received final settlement receipt (DKK-Digital)' }
    ];

    return {
      lifecycle: steps,
      totalTimeMs: 120
    };
  }
}
