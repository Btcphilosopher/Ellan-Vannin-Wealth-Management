import { LedgerEngine } from './ledgerEngine';
import { BankEngine } from './bankEngine';
import { PaymentEngine } from './paymentEngine';
import { DLTEngine } from './dltEngine';
import { SecuritiesEngine } from './securitiesEngine';
import { NordicEngine } from './nordicEngine';
import { OfflineEngine } from './offlineEngine';
import { ResilienceEngine } from './resilienceEngine';
import { MLEngine } from './mlEngine';
import { PrivacyEngine } from './privacyEngine';
import { CLIEngine } from './cliEngine';
import { ScenariosEngine } from './scenariosEngine';
import { MapNode, MacroVariables, SimulationClock } from '../types';

export class MainSimulation {
  public ledger: LedgerEngine;
  public banks: BankEngine;
  public payments: PaymentEngine;
  public dlt: DLTEngine;
  public securities: SecuritiesEngine;
  public nordic: NordicEngine;
  public offline: OfflineEngine;
  public resilience: ResilienceEngine;
  public ml: MLEngine;
  public privacy: PrivacyEngine;
  public cli: CLIEngine;
  public scenarios: ScenariosEngine;

  public clock: SimulationClock = {
    speed: 'REALTIME',
    current_tick: 10420,
    simulated_datetime: '2026-09-19 10:30:00 CET',
    seed: 2026
  };

  public macro: MacroVariables = {
    money_supply_m0: 12.4, // 12.4B CBDC
    money_supply_m1: 1420.0, // 1,420B Total M1
    cbdc_supply: 12.4,
    commercial_bank_deposits: 428.0,
    velocity_of_money: 1.42,
    simulated_gdp: 2850.0, // 2,850B DKK
    cpi_inflation_pct: 1.8,
    central_bank_policy_rate_pct: 2.75,
    credit_growth_pct: 3.2,
    retail_cbdc_adoption_pct: 15.0,
    holding_limit_citizen: 30000,
    holding_limit_merchant: 500000,
    holding_limit_institution: 50000000
  };

  public mapNodes: MapNode[] = [
    { id: 'NODE_CPH', city: 'København (Copenhagen)', lat: 55.6761, lng: 12.5683, retail_volume_24h: 1850000000, wholesale_volume_24h: 12400000000, active_wallets: 650000, latency_ms: 12, status: 'NOMINAL' },
    { id: 'NODE_AAR', city: 'Aarhus', lat: 56.1629, lng: 10.2039, retail_volume_24h: 780000000, wholesale_volume_24h: 3200000000, active_wallets: 280000, latency_ms: 14, status: 'NOMINAL' },
    { id: 'NODE_ODE', city: 'Odense', lat: 55.4038, lng: 10.4024, retail_volume_24h: 420000000, wholesale_volume_24h: 1800000000, active_wallets: 150000, latency_ms: 15, status: 'NOMINAL' },
    { id: 'NODE_AAL', city: 'Aalborg', lat: 57.0488, lng: 9.9217, retail_volume_24h: 360000000, wholesale_volume_24h: 1400000000, active_wallets: 120000, latency_ms: 16, status: 'NOMINAL' },
    { id: 'NODE_ESB', city: 'Esbjerg', lat: 55.4765, lng: 8.4594, retail_volume_24h: 220000000, wholesale_volume_24h: 950000000, active_wallets: 75000, latency_ms: 18, status: 'NOMINAL' },
    { id: 'NODE_ROS', city: 'Roskilde', lat: 55.6419, lng: 12.0878, retail_volume_24h: 170000000, wholesale_volume_24h: 820000000, active_wallets: 55000, latency_ms: 13, status: 'NOMINAL' }
  ];

  private listeners: Set<() => void> = new Set();
  private timer: any = null;

  constructor() {
    this.ledger = new LedgerEngine();
    this.banks = new BankEngine();
    this.payments = new PaymentEngine();
    this.dlt = new DLTEngine();
    this.securities = new SecuritiesEngine();
    this.nordic = new NordicEngine();
    this.offline = new OfflineEngine();
    this.resilience = new ResilienceEngine();
    this.ml = new MLEngine();
    this.privacy = new PrivacyEngine();
    this.scenarios = new ScenariosEngine();
    this.cli = new CLIEngine(
      this.ledger,
      this.banks,
      this.dlt,
      this.securities,
      this.nordic,
      this.offline
    );

    this.startClock();
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify() {
    this.listeners.forEach(cb => cb());
  }

  public setClockSpeed(speed: SimulationClock['speed']) {
    this.clock.speed = speed;
    this.startClock();
    this.notify();
  }

  public startClock() {
    if (this.timer) clearInterval(this.timer);

    if (this.clock.speed === 'PAUSED') return;

    const intervalMs =
      this.clock.speed === 'REALTIME' ? 2000 :
      this.clock.speed === '2X' ? 1000 :
      this.clock.speed === '5X' ? 400 : 200;

    this.timer = setInterval(() => {
      this.tick();
    }, intervalMs);
  }

  public tick() {
    this.clock.current_tick++;

    // Generate deterministic background transactions
    const amount = Math.floor(120 + (this.clock.current_tick % 15) * 45);
    const consumerIdx = (this.clock.current_tick % 8) + 1;
    const merchantIdx = (this.clock.current_tick % 8) + 1;

    const txRes = this.ledger.recordTransaction({
      sender_id: `CONSUMER_${consumerIdx}`,
      receiver_id: `MERCHANT_${merchantIdx}`,
      amount: amount,
      type: 'MERCHANT_PAYMENT',
      channel: 'DIGITAL_KRONE',
      note: `Tick #${this.clock.current_tick} payment`
    });

    if (txRes.transaction) {
      this.ml.evaluateTransactionRisk(txRes.transaction);
    }

    // Every 5 ticks, add a DLT block
    if (this.clock.current_tick % 5 === 0) {
      this.dlt.addBlock(Math.floor(60 + Math.random() * 80));
    }

    this.notify();
  }

  public step() {
    this.tick();
  }

  public resetSimulation() {
    this.clock.current_tick = 10000;
    this.macro.retail_cbdc_adoption_pct = 15.0;
    this.macro.holding_limit_citizen = 30000;
    this.resilience.resolveOutage();
    this.notify();
  }

  public applyScenario(scenarioId: string) {
    const sc = this.scenarios.getScenario(scenarioId);
    if (!sc) return;

    this.macro.retail_cbdc_adoption_pct = sc.adoption_rate;
    this.macro.holding_limit_citizen = sc.holding_limit;
    this.payments.setAdoptionLevel(sc.adoption_rate);
    this.banks.simulateRetailCBDCAdoptionShift(sc.adoption_rate);

    if (sc.outage_mode !== 'NONE') {
      this.resilience.triggerOutage(sc.outage_mode as any, 75);
    } else {
      this.resilience.resolveOutage();
    }

    this.notify();
  }

  public updateHoldingLimit(limit: number) {
    this.macro.holding_limit_citizen = limit;
    this.ledger.setHoldingLimit('Consumer', limit);
    this.notify();
  }
}

// Global simulation singleton instance
export const simulationInstance = new MainSimulation();
