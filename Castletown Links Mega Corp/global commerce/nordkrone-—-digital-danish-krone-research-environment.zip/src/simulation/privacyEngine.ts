import { PrivacyLevelConfig } from '../types';

export class PrivacyEngine {
  private currentMode: PrivacyLevelConfig['mode'] = 'BALANCED';

  public getPrivacyConfigs(): Record<PrivacyLevelConfig['mode'], PrivacyLevelConfig> {
    return {
      HIGH_PRIVACY: {
        mode: 'HIGH_PRIVACY',
        central_bank_visibility: 'Zero visibility into individual identity or balances. Blended cryptographic commitments.',
        commercial_bank_visibility: 'Sees onboarding KYC, but no transaction counterparty detail for under DKK 10,000.',
        merchant_visibility: 'Merchant receives instant payment token; no consumer name or bank disclosed.',
        zero_knowledge_proofs: true,
        audit_threshold_dkk: 10000
      },
      BALANCED: {
        mode: 'BALANCED',
        central_bank_visibility: 'Pseudonymous transaction graph. Holds aggregate ledger totals with deferred identity unmasking.',
        commercial_bank_visibility: 'Full visibility for account holders; pseudonymous counterparty details.',
        merchant_visibility: 'Receives transaction confirmation with standard payment token ID.',
        zero_knowledge_proofs: true,
        audit_threshold_dkk: 50000
      },
      HIGH_TRACEABILITY: {
        mode: 'HIGH_TRACEABILITY',
        central_bank_visibility: 'Full real-time identity & transaction visibility across all retail and wholesale transfers.',
        commercial_bank_visibility: 'Full visibility into all inbound/outbound counterparty identities.',
        merchant_visibility: 'Receives full payer name and verified identity token.',
        zero_knowledge_proofs: false,
        audit_threshold_dkk: 0
      }
    };
  }

  public getCurrentConfig(): PrivacyLevelConfig {
    return this.getPrivacyConfigs()[this.currentMode];
  }

  public setPrivacyMode(mode: PrivacyLevelConfig['mode']) {
    this.currentMode = mode;
  }
}
