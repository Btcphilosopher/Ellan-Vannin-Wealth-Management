import { Bond, RepoTransaction, TokenisedDeposit } from '../types';

export class SecuritiesEngine {
  private bonds: Map<string, Bond> = new Map();
  private repoTransactions: RepoTransaction[] = [];
  private tokenisedDeposits: TokenisedDeposit[] = [];

  constructor() {
    this.initializeBonds();
    this.initializeRepos();
    this.initializeTokenisedDeposits();
  }

  private initializeBonds() {
    const initialBonds: Bond[] = [
      {
        id: 'BOND_DGB_2033',
        isin_sim: 'DK0009924538',
        name: 'Danish Govt Bond 2.25% 2033 (DGB-2033)',
        type: 'GOVERNMENT',
        face_value: 1000,
        coupon_rate: 2.25,
        maturity_year: 2033,
        total_issued: 85000000000, // 85 Billion DKK
        owner_id: 'BANK_DANSKE',
        owner_name: 'Danske Bank',
        settlement_asset: 'DKK_DIGITAL',
        price_pct: 102.45
      },
      {
        id: 'BOND_DGB_2038',
        isin_sim: 'DK0009928812',
        name: 'Danish Govt Bond 0.50% 2038 (DGB-2038)',
        type: 'GOVERNMENT',
        face_value: 1000,
        coupon_rate: 0.50,
        maturity_year: 2038,
        total_issued: 60000000000,
        owner_id: 'BANK_NORDIC',
        owner_name: 'Nordea Danmark',
        settlement_asset: 'DKK_DIGITAL',
        price_pct: 88.30
      },
      {
        id: 'BOND_NYK_COVERED',
        isin_sim: 'DK0009532111',
        name: 'Nykredit Realkredit 1.0% SDO Covered Bond 2050',
        type: 'CORPORATE',
        face_value: 1000,
        coupon_rate: 1.00,
        maturity_year: 2050,
        total_issued: 120000000000,
        owner_id: 'BANK_COPENHAGEN',
        owner_name: 'Nykredit Bank',
        settlement_asset: 'DKK',
        price_pct: 91.20
      },
      {
        id: 'BOND_ORSTED_GREEN',
        isin_sim: 'DK0009801239',
        name: 'Ørsted A/S Green Transition Bond 3.125% 2029',
        type: 'GREEN_BOND',
        face_value: 1000,
        coupon_rate: 3.125,
        maturity_year: 2029,
        total_issued: 15000000000,
        owner_id: 'BANK_JUTLAND',
        owner_name: 'Jyske Bank',
        settlement_asset: 'DKK_DIGITAL',
        price_pct: 101.10
      }
    ];

    initialBonds.forEach(b => this.bonds.set(b.isin_sim, b));
  }

  private initializeRepos() {
    this.repoTransactions = [
      {
        id: 'REPO_4011',
        borrower_id: 'BANK_JUTLAND',
        borrower_name: 'Jyske Bank',
        lender_id: 'BANK_DANSKE',
        lender_name: 'Danske Bank',
        bond_isin: 'DK0009924538',
        cash_amount: 500000000, // 500M DKK
        collateral_value: 520000000, // 520M Bond
        haircut_pct: 3.85,
        repo_rate_pct: 2.15,
        maturity_days: 7,
        status: 'ACTIVE',
        timestamp: Date.now() - 86400000
      },
      {
        id: 'REPO_4012',
        borrower_id: 'BANK_FJORD',
        borrower_name: 'Sydbank',
        lender_id: 'BANK_NORDIC',
        lender_name: 'Nordea Danmark',
        bond_isin: 'DK0009928812',
        cash_amount: 300000000,
        collateral_value: 315000000,
        haircut_pct: 4.76,
        repo_rate_pct: 2.20,
        maturity_days: 1,
        status: 'SETTLED',
        timestamp: Date.now() - 172800000
      }
    ];
  }

  private initializeTokenisedDeposits() {
    this.tokenisedDeposits = [
      {
        id: 'TOK_DEP_101',
        issuing_bank_id: 'BANK_DANSKE',
        issuing_bank_name: 'Danske Bank',
        holder_id: 'CORP_MAERSK',
        amount: 250000000,
        currency: 'DKK',
        reserve_backing_pct: 100,
        dlt_token_id: 'TOK-DANSKE-DKK-001'
      },
      {
        id: 'TOK_DEP_102',
        issuing_bank_id: 'BANK_NORDIC',
        issuing_bank_name: 'Nordea Danmark',
        holder_id: 'CORP_NOVO_NORDISK',
        amount: 400000000,
        currency: 'DKK',
        reserve_backing_pct: 100,
        dlt_token_id: 'TOK-NORDIC-DKK-002'
      }
    ];
  }

  public getBonds(): Bond[] {
    return Array.from(this.bonds.values());
  }

  public getRepoTransactions(): RepoTransaction[] {
    return [...this.repoTransactions];
  }

  public getTokenisedDeposits(): TokenisedDeposit[] {
    return [...this.tokenisedDeposits];
  }

  public createRepoTransaction(params: {
    borrower_id: string;
    borrower_name: string;
    lender_id: string;
    lender_name: string;
    bond_isin: string;
    cash_amount: number;
    haircut_pct: number;
    repo_rate_pct: number;
    maturity_days: number;
  }): RepoTransaction {
    const collateralValue = Math.floor(params.cash_amount * (1 + params.haircut_pct / 100));

    const repo: RepoTransaction = {
      id: `REPO_${Math.floor(1000 + Math.random() * 9000)}`,
      borrower_id: params.borrower_id,
      borrower_name: params.borrower_name,
      lender_id: params.lender_id,
      lender_name: params.lender_name,
      bond_isin: params.bond_isin,
      cash_amount: params.cash_amount,
      collateral_value: collateralValue,
      haircut_pct: params.haircut_pct,
      repo_rate_pct: params.repo_rate_pct,
      maturity_days: params.maturity_days,
      status: 'ACTIVE',
      timestamp: Date.now()
    };

    this.repoTransactions.unshift(repo);
    return repo;
  }

  public issueTokenisedDeposit(
    bankId: string,
    bankName: string,
    holderId: string,
    amount: number
  ): TokenisedDeposit {
    const dep: TokenisedDeposit = {
      id: `TOK_DEP_${Math.floor(100 + Math.random() * 900)}`,
      issuing_bank_id: bankId,
      issuing_bank_name: bankName,
      holder_id: holderId,
      amount: amount,
      currency: 'DKK',
      reserve_backing_pct: 100,
      dlt_token_id: `TOK-${bankName.substring(0, 4).toUpperCase()}-DKK-${Math.floor(100 + Math.random() * 900)}`
    };

    this.tokenisedDeposits.unshift(dep);
    return dep;
  }
}
