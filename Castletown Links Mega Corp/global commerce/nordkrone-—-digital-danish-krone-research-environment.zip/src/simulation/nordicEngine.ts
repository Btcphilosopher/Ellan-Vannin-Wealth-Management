import { NordicCountry } from '../types';

export class NordicEngine {
  private countries: Map<string, NordicCountry> = new Map();

  constructor() {
    this.initializeCountries();
  }

  private initializeCountries() {
    const list: NordicCountry[] = [
      {
        code: 'DK',
        name: 'Denmark (Danmark)',
        central_bank: 'Danmarks Nationalbank',
        currency: 'DKK',
        fx_rate_to_dkk: 1.0,
        instant_network: 'Straksclearing / Kronos2 / TIPS DKK',
        daily_cross_border_volume: 4850000000,
        status: 'ONLINE'
      },
      {
        code: 'SE',
        name: 'Sweden (Sverige)',
        central_bank: 'Sveriges Riksbank',
        currency: 'SEK',
        fx_rate_to_dkk: 0.6472, // 1 SEK = 0.6472 DKK
        instant_network: 'RIX-INST / Swish / TIPS SEK',
        daily_cross_border_volume: 3400000000,
        status: 'ONLINE'
      },
      {
        code: 'NO',
        name: 'Norway (Norge)',
        central_bank: 'Norges Bank',
        currency: 'NOK',
        fx_rate_to_dkk: 0.6385, // 1 NOK = 0.6385 DKK
        instant_network: 'NBO / Straksbetalinger',
        daily_cross_border_volume: 2900000000,
        status: 'ONLINE'
      },
      {
        code: 'FI',
        name: 'Finland (Suomi)',
        central_bank: 'Suomen Pankki (Bank of Finland)',
        currency: 'EUR',
        fx_rate_to_dkk: 7.4625, // 1 EUR = 7.4625 DKK
        instant_network: 'TIPS EUR / TARGET2',
        daily_cross_border_volume: 5200000000,
        status: 'ONLINE'
      },
      {
        code: 'IS',
        name: 'Iceland (Ísland)',
        central_bank: 'Seðlabanki Íslands',
        currency: 'ISK',
        fx_rate_to_dkk: 0.0512, // 1 ISK = 0.0512 DKK
        instant_network: 'RB Real-time Clearing',
        daily_cross_border_volume: 420000000,
        status: 'ONLINE'
      },
      {
        code: 'EU',
        name: 'Euro Area (Eurosystem)',
        central_bank: 'European Central Bank (ECB)',
        currency: 'EUR',
        fx_rate_to_dkk: 7.4625,
        instant_network: 'TIPS / TARGET2 / ECB Gateway',
        daily_cross_border_volume: 18500000000,
        status: 'ONLINE'
      }
    ];

    list.forEach(c => this.countries.set(c.code, c));
  }

  public getCountries(): NordicCountry[] {
    return Array.from(this.countries.values());
  }

  public simulateCrossBorderPayment(params: {
    sourceCountry: string;
    targetCountry: string;
    amountSourceCurrency: number;
  }): {
    sourceCurrency: string;
    targetCurrency: string;
    sourceAmount: number;
    fxRate: number;
    targetAmount: number;
    liquidityRequiredDKK: number;
    estimatedLatencyMs: number;
    status: string;
  } {
    const src = this.countries.get(params.sourceCountry);
    const tgt = this.countries.get(params.targetCountry);

    if (!src || !tgt) {
      throw new Error('Invalid Nordic country selected.');
    }

    const dkkValue = params.amountSourceCurrency * src.fx_rate_to_dkk;
    const targetAmount = dkkValue / tgt.fx_rate_to_dkk;
    const crossFx = src.fx_rate_to_dkk / tgt.fx_rate_to_dkk;

    return {
      sourceCurrency: src.currency,
      targetCurrency: tgt.currency,
      sourceAmount: params.amountSourceCurrency,
      fxRate: Number(crossFx.toFixed(6)),
      targetAmount: Number(targetAmount.toFixed(2)),
      liquidityRequiredDKK: Math.ceil(dkkValue),
      estimatedLatencyMs: 380,
      status: 'ATOMIC_PVP_CONFIRMED'
    };
  }
}
