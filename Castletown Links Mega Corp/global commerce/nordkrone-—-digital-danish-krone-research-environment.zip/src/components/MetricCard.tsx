import React from 'react';

interface MetricCardProps {
  label: string;
  value: string | number;
  subValue?: string;
  badge?: string;
  badgeColor?: 'emerald' | 'amber' | 'red' | 'blue' | 'neutral';
  accent?: boolean;
}

export const MetricCard: React.FC<MetricCardProps> = ({
  label,
  value,
  subValue,
  badge,
  badgeColor = 'neutral',
  accent = false
}) => {
  const badgeClasses = {
    emerald: 'bg-emerald-950/80 text-emerald-400 border-emerald-800',
    amber: 'bg-amber-950/80 text-amber-400 border-amber-800',
    red: 'bg-red-950/80 text-red-400 border-red-800',
    blue: 'bg-blue-950/80 text-blue-400 border-blue-800',
    neutral: 'bg-[#212529] text-[#a0aab2] border-[#343a40]'
  }[badgeColor];

  return (
    <div
      className={`p-3.5 rounded-xs border font-mono transition-all ${
        accent
          ? 'bg-[#181a1e] border-[#c1121f]/50 shadow-sm'
          : 'bg-[#141619] border-[#2b3036] hover:border-[#3a4149]'
      }`}
    >
      <div className="flex items-center justify-between gap-2 mb-1">
        <span className="text-[10px] text-[#9a8c90] uppercase font-semibold tracking-wider truncate">
          {label}
        </span>
        {badge && (
          <span className={`text-[9px] px-1.5 py-0.2 rounded-xs border font-bold ${badgeClasses}`}>
            {badge}
          </span>
        )}
      </div>

      <div className="text-lg font-bold text-white tracking-tight leading-tight">
        {value}
      </div>

      {subValue && (
        <div className="text-[10px] text-[#a0aab2] mt-1 font-sans">
          {subValue}
        </div>
      )}
    </div>
  );
};
