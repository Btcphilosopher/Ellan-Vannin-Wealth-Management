import React from 'react';
import { Play, Pause, FastForward, RotateCcw, StepForward, ShieldAlert, Cpu, Globe, Database } from 'lucide-react';
import { Language, SimulationClock } from '../types';
import { translations } from '../i18n/translations';

interface HeaderProps {
  lang: Language;
  onLanguageChange: (lang: Language) => void;
  clock: SimulationClock;
  onSetClockSpeed: (speed: SimulationClock['speed']) => void;
  onStepClock: () => void;
  onResetClock: () => void;
  onRunScenario: (scenarioId: string) => void;
  activeScenarioId: string;
}

export const Header: React.FC<HeaderProps> = ({
  lang,
  onLanguageChange,
  clock,
  onSetClockSpeed,
  onStepClock,
  onResetClock,
  onRunScenario,
  activeScenarioId
}) => {
  const t = translations[lang];

  return (
    <header className="bg-[#121417] text-[#f4f5f7] border-b border-[#2d3238] sticky top-0 z-50 shadow-md">
      {/* Top Banner Disclaimer */}
      <div className="bg-[#c1121f] text-white text-[11px] font-mono py-1 px-4 tracking-wider flex items-center justify-between">
        <div className="flex items-center gap-2 font-bold uppercase">
          <ShieldAlert className="w-3.5 h-3.5" />
          <span>{t.disclaimer}</span>
        </div>
        <div className="hidden sm:flex items-center gap-4 text-[10px] opacity-90 font-mono">
          <span>SEED: {clock.seed}</span>
          <span>DANMARKS NATIONALBANK RESEARCH DIGITAL TWIN</span>
        </div>
      </div>

      {/* Main Header Toolbar */}
      <div className="px-4 py-2.5 flex flex-wrap items-center justify-between gap-4">
        {/* Brand & Title */}
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-[#c1121f] text-white flex items-center justify-center font-bold text-lg rounded-xs tracking-tighter border border-white/20">
            NK
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base font-bold tracking-wider font-mono text-white leading-none">
                {t.appTitle}
              </h1>
              <span className="bg-[#212529] text-[#a0aab2] text-[10px] font-mono px-1.5 py-0.5 rounded-xs border border-[#343a40]">
                v3.7-PROTOTYPE
              </span>
            </div>
            <p className="text-[11px] font-mono text-[#a0aab2] mt-0.5 uppercase tracking-wide">
              {t.appSubTitle}
            </p>
          </div>
        </div>

        {/* Live System Status Indicators */}
        <div className="hidden lg:flex items-center gap-3 font-mono text-[11px] bg-[#1a1d21] px-3 py-1.5 rounded-xs border border-[#2d3238]">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span className="text-[#a0aab2]">{t.systemStatus}:</span>
            <span className="text-emerald-400 font-bold">{t.nominal}</span>
          </div>
          <span className="text-[#343a40]">|</span>
          <div className="flex items-center gap-1 text-[#c2cad0]">
            <Database className="w-3 h-3 text-[#1d3557]" />
            <span>{t.ledgerSync}</span>
          </div>
          <span className="text-[#343a40]">|</span>
          <div className="flex items-center gap-1 text-[#c2cad0]">
            <Cpu className="w-3 h-3 text-emerald-400" />
            <span>TICK #{clock.current_tick}</span>
          </div>
        </div>

        {/* Simulation Clock Controls */}
        <div className="flex items-center gap-2">
          <div className="flex items-center bg-[#1a1d21] p-1 rounded-xs border border-[#2d3238] font-mono text-xs">
            <button
              onClick={() => onSetClockSpeed('REALTIME')}
              className={`px-2 py-1 rounded-xs flex items-center gap-1 transition-colors ${
                clock.speed === 'REALTIME'
                  ? 'bg-[#c1121f] text-white font-bold'
                  : 'text-[#a0aab2] hover:text-white'
              }`}
              title="Real-time (1 tick / 2s)"
            >
              <Play className="w-3 h-3" />
              <span>1x</span>
            </button>
            <button
              onClick={() => onSetClockSpeed('2X')}
              className={`px-2 py-1 rounded-xs transition-colors ${
                clock.speed === '2X'
                  ? 'bg-[#c1121f] text-white font-bold'
                  : 'text-[#a0aab2] hover:text-white'
              }`}
            >
              2x
            </button>
            <button
              onClick={() => onSetClockSpeed('5X')}
              className={`px-2 py-1 rounded-xs transition-colors ${
                clock.speed === '5X'
                  ? 'bg-[#c1121f] text-white font-bold'
                  : 'text-[#a0aab2] hover:text-white'
              }`}
            >
              5x
            </button>
            <button
              onClick={() => onSetClockSpeed('10X')}
              className={`px-2 py-1 rounded-xs flex items-center gap-1 transition-colors ${
                clock.speed === '10X'
                  ? 'bg-[#c1121f] text-white font-bold'
                  : 'text-[#a0aab2] hover:text-white'
              }`}
            >
              <FastForward className="w-3 h-3" />
              <span>10x</span>
            </button>
            <button
              onClick={() => onSetClockSpeed('PAUSED')}
              className={`px-2 py-1 rounded-xs flex items-center gap-1 transition-colors ${
                clock.speed === 'PAUSED'
                  ? 'bg-amber-600 text-white font-bold'
                  : 'text-[#a0aab2] hover:text-white'
              }`}
            >
              <Pause className="w-3 h-3" />
            </button>
            <button
              onClick={onStepClock}
              className="px-1.5 py-1 text-[#a0aab2] hover:text-white border-l border-[#2d3238] ml-1"
              title="Step Single Tick"
            >
              <StepForward className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={onResetClock}
              className="px-1.5 py-1 text-[#a0aab2] hover:text-white"
              title="Reset Simulation Clock"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Language Switcher */}
          <div className="flex items-center bg-[#1a1d21] p-1 rounded-xs border border-[#2d3238] font-mono text-xs">
            <button
              onClick={() => onLanguageChange('da')}
              className={`px-2 py-1 rounded-xs transition-colors ${
                lang === 'da'
                  ? 'bg-[#1d3557] text-white font-bold'
                  : 'text-[#a0aab2] hover:text-white'
              }`}
            >
              DANSK
            </button>
            <button
              onClick={() => onLanguageChange('en')}
              className={`px-2 py-1 rounded-xs transition-colors ${
                lang === 'en'
                  ? 'bg-[#1d3557] text-white font-bold'
                  : 'text-[#a0aab2] hover:text-white'
              }`}
            >
              ENGLISH
            </button>
          </div>
        </div>
      </div>

      {/* Quick Scenario Preset Trigger Bar */}
      <div className="bg-[#181b1f] border-t border-[#25292e] px-4 py-1.5 flex items-center gap-2 overflow-x-auto text-[11px] font-mono text-[#a0aab2]">
        <span className="text-[#c1121f] font-bold uppercase shrink-0 flex items-center gap-1">
          <Globe className="w-3 h-3" /> SCENARIOS:
        </span>
        <button
          onClick={() => onRunScenario('BASELINE')}
          className={`px-2 py-0.5 rounded-xs shrink-0 transition-colors ${
            activeScenarioId === 'BASELINE'
              ? 'bg-[#343a40] text-white border border-white/20'
              : 'hover:bg-[#212529] hover:text-white'
          }`}
        >
          Baseline
        </button>
        <button
          onClick={() => onRunScenario('HIGH_CBDC_ADOPTION')}
          className={`px-2 py-0.5 rounded-xs shrink-0 transition-colors ${
            activeScenarioId === 'HIGH_CBDC_ADOPTION'
              ? 'bg-[#c1121f] text-white font-bold'
              : 'hover:bg-[#212529] hover:text-white'
          }`}
        >
          1. High CBDC Adoption
        </button>
        <button
          onClick={() => onRunScenario('WHOLESALE_TOKENISED_BOND')}
          className={`px-2 py-0.5 rounded-xs shrink-0 transition-colors ${
            activeScenarioId === 'WHOLESALE_TOKENISED_BOND'
              ? 'bg-[#1d3557] text-white font-bold'
              : 'hover:bg-[#212529] hover:text-white'
          }`}
        >
          2. Wholesale Bond Market (DvP)
        </button>
        <button
          onClick={() => onRunScenario('NORDIC_CROSS_BORDER_SURGE')}
          className={`px-2 py-0.5 rounded-xs shrink-0 transition-colors ${
            activeScenarioId === 'NORDIC_CROSS_BORDER_SURGE'
              ? 'bg-[#1d3557] text-white font-bold'
              : 'hover:bg-[#212529] hover:text-white'
          }`}
        >
          3. Nordic Cross-Border Surge (PvP)
        </button>
        <button
          onClick={() => onRunScenario('NATIONAL_PAYMENT_OUTAGE')}
          className={`px-2 py-0.5 rounded-xs shrink-0 transition-colors ${
            activeScenarioId === 'NATIONAL_PAYMENT_OUTAGE'
              ? 'bg-amber-600 text-white font-bold'
              : 'hover:bg-[#212529] hover:text-white'
          }`}
        >
          4. National Payment Disruption
        </button>
        <button
          onClick={() => onRunScenario('BANKING_LIQUIDITY_STRESS')}
          className={`px-2 py-0.5 rounded-xs shrink-0 transition-colors ${
            activeScenarioId === 'BANKING_LIQUIDITY_STRESS'
              ? 'bg-red-700 text-white font-bold'
              : 'hover:bg-[#212529] hover:text-white'
          }`}
        >
          5. Bank Liquidity Stress
        </button>
      </div>
    </header>
  );
};
