import React from 'react';
import {
  Landmark,
  CreditCard,
  Building2,
  Cpu,
  Layers,
  Globe2,
  FlaskConical,
  Terminal,
  Activity,
  MapPin,
  TrendingUp,
  Scale
} from 'lucide-react';
import { Language } from '../types';
import { translations } from '../i18n/translations';

export type MainNavModule =
  | 'overview'
  | 'national_money'
  | 'payments'
  | 'markets'
  | 'dlt'
  | 'banking'
  | 'nordic'
  | 'research'
  | 'control_room';

interface SidebarProps {
  lang: Language;
  activeModule: MainNavModule;
  onSelectModule: (mod: MainNavModule) => void;
  activeSubView: string;
  onSelectSubView: (sub: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  lang,
  activeModule,
  onSelectModule,
  activeSubView,
  onSelectSubView
}) => {
  const t = translations[lang];

  const modules = [
    {
      id: 'overview' as MainNavModule,
      label: t.navOverview,
      icon: Landmark,
      subViews: [
        { id: 'overview_main', label: t.subOverview },
        { id: 'overview_map', label: t.subGISMap },
        { id: 'overview_arch', label: t.subArchitecture }
      ]
    },
    {
      id: 'national_money' as MainNavModule,
      label: t.navNationalMoney,
      icon: TrendingUp,
      subViews: [
        { id: 'money_supply', label: t.subDigitalSupply },
        { id: 'money_wholesale', label: t.subWholesaleSettlement },
        { id: 'money_retail', label: t.subRetailPayments },
        { id: 'money_liquidity', label: t.subLiquidity },
        { id: 'money_monetary_stats', label: t.subMonetaryStats }
      ]
    },
    {
      id: 'payments' as MainNavModule,
      label: t.navPayments,
      icon: CreditCard,
      subViews: [
        { id: 'payments_instant', label: t.subInstantPayments },
        { id: 'payments_routing', label: t.subRouting },
        { id: 'payments_resilience', label: t.subResilience },
        { id: 'payments_offline', label: t.subOffline }
      ]
    },
    {
      id: 'markets' as MainNavModule,
      label: t.navMarkets,
      icon: Layers,
      subViews: [
        { id: 'markets_tokenised_deposits', label: t.subTokenisedDeposits },
        { id: 'markets_bonds', label: t.subBonds },
        { id: 'markets_repo', label: t.subRepo }
      ]
    },
    {
      id: 'dlt' as MainNavModule,
      label: t.navDLT,
      icon: Cpu,
      subViews: [
        { id: 'dlt_ledger', label: t.subDLTLedger },
        { id: 'dlt_dvp', label: t.subDvP },
        { id: 'dlt_pvp', label: t.subPvP }
      ]
    },
    {
      id: 'banking' as MainNavModule,
      label: t.navBanking,
      icon: Building2,
      subViews: [
        { id: 'banking_sheets', label: t.subBankBalanceSheets },
        { id: 'banking_substitution', label: t.subCBDCSubstitution }
      ]
    },
    {
      id: 'nordic' as MainNavModule,
      label: t.navNordic,
      icon: Globe2,
      subViews: [
        { id: 'nordic_network', label: t.subNordicNetwork },
        { id: 'nordic_fx', label: t.subCrossCurrency },
        { id: 'nordic_tips', label: t.subTIPSGateway }
      ]
    },
    {
      id: 'research' as MainNavModule,
      label: t.navResearch,
      icon: FlaskConical,
      subViews: [
        { id: 'research_holding_limits', label: 'Holding Limits Lab' },
        { id: 'research_privacy', label: t.subPrivacyLab },
        { id: 'research_offline_lab', label: 'Offline Lab' },
        { id: 'research_stability', label: 'Financial Stability Lab' },
        { id: 'research_scenarios', label: t.subScenarioLab },
        { id: 'research_resilience_lab', label: 'Resilience Lab' },
        { id: 'research_aml', label: t.subAML }
      ]
    },
    {
      id: 'control_room' as MainNavModule,
      label: t.navControlRoom,
      icon: Activity,
      subViews: [
        { id: 'control_terminal', label: t.subTerminal },
        { id: 'control_ml', label: t.subMLLab },
        { id: 'control_gis', label: t.subGISMap }
      ]
    }
  ];

  return (
    <aside className="w-64 bg-[#121417] text-[#f4f5f7] border-r border-[#2d3238] flex flex-col shrink-0 select-none">
      <div className="p-3 border-b border-[#2d3238] font-mono text-[10px] text-[#a0aab2] tracking-wider uppercase flex items-center justify-between">
        <span>RESEARCH MODULES</span>
        <span className="text-[#c1121f]">9 ACTIVE</span>
      </div>

      <nav className="flex-1 overflow-y-auto py-2 px-1.5 space-y-1 font-mono text-xs">
        {modules.map(mod => {
          const Icon = mod.icon;
          const isSelected = activeModule === mod.id;

          return (
            <div key={mod.id} className="space-y-0.5">
              <button
                onClick={() => {
                  onSelectModule(mod.id);
                  onSelectSubView(mod.subViews[0].id);
                }}
                className={`w-full flex items-center gap-2.5 px-2.5 py-2 rounded-xs text-left transition-all ${
                  isSelected
                    ? 'bg-[#1d3557] text-white font-bold border-l-2 border-[#c1121f]'
                    : 'text-[#c2cad0] hover:bg-[#1f2328] hover:text-white'
                }`}
              >
                <Icon className={`w-4 h-4 shrink-0 ${isSelected ? 'text-[#c1121f]' : 'text-[#a0aab2]'}`} />
                <span className="truncate">{mod.label}</span>
              </button>

              {/* Sub-views dropdown list */}
              {isSelected && (
                <div className="pl-6 pr-1 py-1 space-y-0.5 border-l border-[#2d3238] ml-3.5 my-1">
                  {mod.subViews.map(sub => (
                    <button
                      key={sub.id}
                      onClick={() => onSelectSubView(sub.id)}
                      className={`w-full text-left px-2 py-1 text-[11px] rounded-xs transition-colors truncate ${
                        activeSubView === sub.id
                          ? 'bg-[#343a40] text-white font-semibold'
                          : 'text-[#909ca6] hover:text-white hover:bg-[#1a1d21]'
                      }`}
                    >
                      • {sub.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </nav>

      {/* Bottom Footer Info */}
      <div className="p-3 border-t border-[#2d3238] bg-[#0d0e10] font-mono text-[10px] text-[#a0aab2]">
        <div className="flex items-center justify-between font-bold text-white mb-1">
          <span>DANMARKS NATIONALBANK</span>
          <span className="text-emerald-400">ONLINE</span>
        </div>
        <p className="leading-tight text-[9px] text-[#808d98]">
          Fictional central bank digital currency research environment.
        </p>
      </div>
    </aside>
  );
};
