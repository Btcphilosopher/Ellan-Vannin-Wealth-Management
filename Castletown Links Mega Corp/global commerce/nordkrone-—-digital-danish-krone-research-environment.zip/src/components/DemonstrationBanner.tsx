import React from 'react';
import { AlertTriangle, PlayCircle } from 'lucide-react';

interface DemonstrationBannerProps {
  onRunScenario: (scenarioId: string) => void;
  activeScenarioId: string;
}

export const DemonstrationBanner: React.FC<DemonstrationBannerProps> = ({
  onRunScenario,
  activeScenarioId
}) => {
  return (
    <div className="bg-[#181c20] border border-[#2e343c] rounded-xs p-3.5 mb-4 font-mono">
      <div className="flex flex-wrap items-center justify-between gap-3 pb-2.5 border-b border-[#2a3038]">
        <div className="flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0" />
          <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">
            SYNTHETIC DEMONSTRATION DATA
          </span>
          <span className="text-[10px] text-[#a0aab2] bg-[#212529] px-2 py-0.5 rounded-xs border border-[#343a40]">
            FIRST DEMONSTRATION SET
          </span>
        </div>

        <div className="flex items-center gap-4 text-xs text-[#c2cad0]">
          <div><span className="text-[#a0aab2]">CBDC Supply:</span> <strong className="text-white">DKK 12.4B</strong></div>
          <div><span className="text-[#a0aab2]">Active Wallets:</span> <strong className="text-white">1,250,000</strong></div>
          <div><span className="text-[#a0aab2]">Merchants:</span> <strong className="text-white">48,000</strong></div>
          <div><span className="text-[#a0aab2]">Banks:</span> <strong className="text-white">12</strong></div>
          <div><span className="text-[#a0aab2]">Daily Txs:</span> <strong className="text-white">3,800,000</strong></div>
        </div>
      </div>

      <div className="pt-2.5 flex flex-wrap items-center gap-2 text-xs">
        <span className="text-[#a0aab2] font-semibold text-[11px] uppercase mr-1 flex items-center gap-1">
          <PlayCircle className="w-3.5 h-3.5 text-[#c1121f]" /> RUN DEMO SCENARIO:
        </span>

        <button
          onClick={() => onRunScenario('HIGH_CBDC_ADOPTION')}
          className={`px-2.5 py-1 rounded-xs border transition-all text-[11px] ${
            activeScenarioId === 'HIGH_CBDC_ADOPTION'
              ? 'bg-[#c1121f] text-white border-white font-bold shadow-xs'
              : 'bg-[#212529] text-[#c2cad0] border-[#343a40] hover:bg-[#2b3036] hover:text-white'
          }`}
        >
          SCENARIO 1: Retail Adoption ↑
        </button>

        <button
          onClick={() => onRunScenario('WHOLESALE_TOKENISED_BOND')}
          className={`px-2.5 py-1 rounded-xs border transition-all text-[11px] ${
            activeScenarioId === 'WHOLESALE_TOKENISED_BOND'
              ? 'bg-[#1d3557] text-white border-white font-bold shadow-xs'
              : 'bg-[#212529] text-[#c2cad0] border-[#343a40] hover:bg-[#2b3036] hover:text-white'
          }`}
        >
          SCENARIO 2: Tokenised Bond Market (DvP)
        </button>

        <button
          onClick={() => onRunScenario('NORDIC_CROSS_BORDER_SURGE')}
          className={`px-2.5 py-1 rounded-xs border transition-all text-[11px] ${
            activeScenarioId === 'NORDIC_CROSS_BORDER_SURGE'
              ? 'bg-[#1d3557] text-white border-white font-bold shadow-xs'
              : 'bg-[#212529] text-[#c2cad0] border-[#343a40] hover:bg-[#2b3036] hover:text-white'
          }`}
        >
          SCENARIO 3: Cross-Border DKK/SEK Surge (PvP)
        </button>

        <button
          onClick={() => onRunScenario('NATIONAL_PAYMENT_OUTAGE')}
          className={`px-2.5 py-1 rounded-xs border transition-all text-[11px] ${
            activeScenarioId === 'NATIONAL_PAYMENT_OUTAGE'
              ? 'bg-amber-600 text-white border-white font-bold shadow-xs'
              : 'bg-[#212529] text-[#c2cad0] border-[#343a40] hover:bg-[#2b3036] hover:text-white'
          }`}
        >
          SCENARIO 4: National Payment Outage & Offline
        </button>

        <button
          onClick={() => onRunScenario('BANKING_LIQUIDITY_STRESS')}
          className={`px-2.5 py-1 rounded-xs border transition-all text-[11px] ${
            activeScenarioId === 'BANKING_LIQUIDITY_STRESS'
              ? 'bg-red-700 text-white border-white font-bold shadow-xs'
              : 'bg-[#212529] text-[#c2cad0] border-[#343a40] hover:bg-[#2b3036] hover:text-white'
          }`}
        >
          SCENARIO 5: Bank Liquidity Stress
        </button>
      </div>
    </div>
  );
};
