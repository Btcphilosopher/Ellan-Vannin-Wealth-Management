from __future__ import annotations

from collections.abc import AsyncGenerator
from pathlib import Path
import sys

import httpx
import pytest
import pytest_asyncio

BACKEND_DIR = Path(__file__).resolve().parents[1]
if str(BACKEND_DIR) not in sys.path:
    sys.path.insert(0, str(BACKEND_DIR))

from app.core.database import Base, create_engine_and_sessionmaker, get_db  # noqa: E402
from app.core.security import rate_limiter  # noqa: E402
from app.main import create_app  # noqa: E402
from app.services.seed import seed_demo_data  # noqa: E402


@pytest_asyncio.fixture()
async def test_app(tmp_path: Path):
    db_file = tmp_path / "test_sunburst.db"
    db_url = f"sqlite+aiosqlite:///{db_file}"
    engine, session_factory = create_engine_and_sessionmaker(db_url)

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    async with session_factory() as seed_session:
        await seed_demo_data(seed_session)

    app = create_app()

    async def _override_get_db() -> AsyncGenerator:
        async with session_factory() as session:
            yield session

    app.dependency_overrides[get_db] = _override_get_db
    rate_limiter.reset()

    yield app, session_factory

    app.dependency_overrides.clear()
    await engine.dispose()


@pytest_asyncio.fixture()
async def client(test_app) -> AsyncGenerator[httpx.AsyncClient, None]:
    app, _ = test_app
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://testserver") as ac:
        yield ac
