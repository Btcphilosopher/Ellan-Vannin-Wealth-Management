from __future__ import annotations

import asyncio
from datetime import datetime, timedelta, timezone
import hashlib
import hmac
import json

import httpx
import pytest
from sqlalchemy import select

from app.core.config import get_settings
from app.core.security import RedactingLogFilter, validate_image_upload
from app.models.catalog import PriceHistory, ProductVariant
from app.models.orders import InventoryReservation, Order
from app.services.inventory import release_expired_reservations


async def _login_demo(client: httpx.AsyncClient) -> str:
    resp = await client.post(
        "/api/v1/account/login",
        json={
            "email": "demo@sunburst.example",
            "password": "SunburstDemo2026!",
            "device_name": "Test iPad Pro",
        },
    )
    assert resp.status_code == 200
    return resp.json()["token"]


async def _register_second_user(client: httpx.AsyncClient) -> str:
    resp = await client.post(
        "/api/v1/account/register",
        json={
            "email": "other@sunburst.example",
            "password": "AnotherStrongPassword1!",
            "display_name": "Jordan Lee",
            "device_name": "Other iPad",
        },
    )
    assert resp.status_code == 201
    return resp.json()["token"]


DEMO_ADDRESS = {
    "label": "Studio",
    "recipient_name": "Alex Rivera",
    "line1": "742 Market Street",
    "line2": "Suite 4B",
    "city": "San Francisco",
    "region": "CA",
    "postal_code": "94107",
    "country_code": "US",
    "is_default": True,
}


@pytest.mark.asyncio
async def test_discover_search_variant_consistency_and_reference_price(client: httpx.AsyncClient):
    discover = await client.get("/api/v1/discover")
    assert discover.status_code == 200
    body = discover.json()
    assert len(body["categories"]) == 5
    assert len(body["featured_products"]) >= 5
    assert body["collections"][0]["explanation"]

    search = await client.get(
        "/api/v1/catalog/search",
        params={"q": "kettle", "in_stock_only": True, "sort": "price_asc"},
    )
    assert search.status_code == 200
    items = search.json()["items"]
    assert len(items) == 1
    detail = await client.get(f"/api/v1/catalog/products/{items[0]['id']}")
    assert detail.status_code == 200
    d_json = detail.json()
    variants = {v["id"]: v for v in d_json["variants"]}
    # Terracotta has backed PriceHistory record -> exposes reference_price_minor
    assert variants["var_kettle_terracotta"]["reference_price_minor"] == 3490
    # Charcoal has no higher historical price -> reference_price_minor must stay None (never invented)
    assert variants["var_kettle_charcoal"]["reference_price_minor"] is None


@pytest.mark.asyncio
async def test_server_authoritative_pricing_and_changed_price_notice(client: httpx.AsyncClient):
    token = await _login_demo(client)
    headers = {"Authorization": f"Bearer {token}"}
    admin_headers = {"X-Admin-Token": get_settings().admin_api_token}

    # Add kettle Terracotta ($28.90) + brass pen ($22.00)
    await client.post(
        "/api/v1/bag/items",
        headers=headers,
        json={"product_id": "prod_ceramic_kettle", "variant_id": "var_kettle_terracotta", "quantity": 1},
    )
    await client.post(
        "/api/v1/bag/items",
        headers=headers,
        json={"product_id": "prod_brass_pen", "variant_id": "var_pen_raw", "quantity": 1},
    )

    # Admin updates pen price on server ($22.00 -> $25.00)
    upd = await client.patch(
        "/api/v1/admin/variants/var_pen_raw/price",
        headers=admin_headers,
        json={"price_minor": 2500, "reason": "Brass material cost adjustment"},
    )
    assert upd.status_code == 200

    # Bag refresh must detect price change and calculate authoritative total
    bag = (await client.get("/api/v1/bag", headers=headers)).json()
    assert bag["subtotal_minor"] == 2890 + 2500
    assert any("Price changed" in n for n in bag["notices"])

    # Checkout preview computes multi-seller shipping & promotions cleanly
    preview = await client.post(
        "/api/v1/checkout/preview",
        headers=headers,
        json={
            "address": DEMO_ADDRESS,
            "delivery_method": "standard",
            "promo_codes": ["WELCOME15"],
        },
    )
    assert preview.status_code == 200
    p_json = preview.json()
    assert p_json["subtotal_minor"] == 5390
    assert p_json["discount_minor"] == (5390 * 1500) // 10_000  # 808
    assert len(p_json["seller_breakdowns"]) == 2
    assert p_json["is_demo_checkout"] is True


@pytest.mark.asyncio
async def test_promotion_precedence_and_exclusions(client: httpx.AsyncClient):
    token = await _login_demo(client)
    headers = {"Authorization": f"Bearer {token}"}

    # Add Homeware kettle ($28.90 x 2 = $57.80) + excluded electronics GaN charger ($25.90)
    await client.post(
        "/api/v1/bag/items",
        headers=headers,
        json={"product_id": "prod_ceramic_kettle", "variant_id": "var_kettle_terracotta", "quantity": 2},
    )
    await client.post(
        "/api/v1/bag/items",
        headers=headers,
        json={"product_id": "prod_gan_charger", "variant_id": "var_gan_white", "quantity": 1},
    )

    # HOME20 (precedence 5, non-stackable) should win over WELCOME15 (precedence 10)
    preview = await client.post(
        "/api/v1/checkout/preview",
        headers=headers,
        json={
            "address": DEMO_ADDRESS,
            "delivery_method": "standard",
            "promo_codes": ["WELCOME15", "HOME20"],
        },
    )
    assert preview.status_code == 200
    data = preview.json()
    applied_codes = [p["code"] for p in data["applied_promotions"]]
    assert applied_codes == ["HOME20"]
    assert any(r["code"] == "WELCOME15" for r in data["rejected_promotions"])


@pytest.mark.asyncio
async def test_idempotent_checkout_lost_response_and_multi_seller_returns(client: httpx.AsyncClient):
    token = await _login_demo(client)
    headers = {"Authorization": f"Bearer {token}"}

    await client.post(
        "/api/v1/bag/items",
        headers=headers,
        json={"product_id": "prod_ceramic_kettle", "variant_id": "var_kettle_terracotta", "quantity": 1},
    )
    await client.post(
        "/api/v1/bag/items",
        headers=headers,
        json={"product_id": "prod_dot_notebook", "variant_id": "var_nb_persimmon", "quantity": 2},
    )

    idem_key = "idem-checkout-lost-response-001"
    payload = {
        "address": DEMO_ADDRESS,
        "delivery_method": "standard",
        "promo_codes": ["WELCOME15"],
        "simulation_outcome": "success",
    }

    first = await client.post(
        "/api/v1/checkout/confirm",
        headers={**headers, "Idempotency-Key": idem_key},
        json=payload,
    )
    assert first.status_code == 200
    first_json = first.json()
    assert first_json["replayed_from_idempotency"] is False
    order = first_json["order"]
    assert len(order["fulfillments"]) == 2  # Two distinct sellers
    assert order["payment_status"] == "paid"

    # Simulate client retry after lost response using identical Idempotency-Key
    replay = await client.post(
        "/api/v1/checkout/confirm",
        headers={**headers, "Idempotency-Key": idem_key},
        json=payload,
    )
    assert replay.status_code == 200
    replay_json = replay.json()
    assert replay_json["replayed_from_idempotency"] is True
    assert replay_json["order"]["id"] == order["id"]

    # Other customer CANNOT access or return this order
    other_token = await _register_second_user(client)
    other_headers = {"Authorization": f"Bearer {other_token}"}
    forbidden_view = await client.get(f"/api/v1/orders/{order['id']}", headers=other_headers)
    assert forbidden_view.status_code == 404

    # Track synthetic shipment & request return
    track = await client.post(
        f"/api/v1/orders/{order['id']}/tracking/advance",
        headers=headers,
    )
    assert track.status_code == 200
    first_item_id = order["fulfillments"][0]["items"][0]["id"]

    # Refund exceeding eligible amount must be rejected
    bad_ret = await client.post(
        f"/api/v1/orders/{order['id']}/returns",
        headers=headers,
        json={
            "items": [{"order_item_id": first_item_id, "quantity": 1}],
            "reason": "Changed mind",
            "requested_amount_minor": 999_999,
        },
    )
    assert bad_ret.status_code == 400

    # Valid return + distinct refund transitions
    good_ret = await client.post(
        f"/api/v1/orders/{order['id']}/returns",
        headers=headers,
        json={"items": [{"order_item_id": first_item_id, "quantity": 1}], "reason": "Wrong color"},
    )
    assert good_ret.status_code == 201
    ret_id = good_ret.json()["id"]
    assert good_ret.json()["refund_status"] == "refund_approved"

    admin_headers = {"X-Admin-Token": get_settings().admin_api_token}
    sub = await client.post(
        f"/api/v1/admin/returns/{ret_id}/refund-transition",
        headers=admin_headers,
        json={"next_refund_status": "refund_submitted"},
    )
    assert sub.status_code == 200
    assert sub.json()["refund_status"] == "refund_submitted"

    conf = await client.post(
        f"/api/v1/admin/returns/{ret_id}/refund-transition",
        headers=admin_headers,
        json={"next_refund_status": "refund_confirmed"},
    )
    assert conf.status_code == 200
    assert conf.json()["refund_status"] == "refund_confirmed"


@pytest.mark.asyncio
async def test_concurrent_reservations_expiry_recovery_and_webhook_reconciliation(
    client: httpx.AsyncClient,
    test_app,
):
    _, session_factory = test_app
    token_a = await _login_demo(client)
    token_b = await _register_second_user(client)

    # var_tee_charcoal_m has stock_on_hand = 3
    await client.post(
        "/api/v1/bag/items",
        headers={"Authorization": f"Bearer {token_a}"},
        json={"product_id": "prod_heavy_tee", "variant_id": "var_tee_charcoal_m", "quantity": 2},
    )
    await client.post(
        "/api/v1/bag/items",
        headers={"Authorization": f"Bearer {token_b}"},
        json={"product_id": "prod_heavy_tee", "variant_id": "var_tee_charcoal_m", "quantity": 2},
    )

    req_body = {
        "address": DEMO_ADDRESS,
        "delivery_method": "standard",
        "promo_codes": [],
        "simulation_outcome": "uncertain_timeout",
    }

    res_a, res_b = await asyncio.gather(
        client.post(
            "/api/v1/checkout/confirm",
            headers={"Authorization": f"Bearer {token_a}", "Idempotency-Key": "conc-a-001"},
            json=req_body,
        ),
        client.post(
            "/api/v1/checkout/confirm",
            headers={"Authorization": f"Bearer {token_b}", "Idempotency-Key": "conc-b-001"},
            json=req_body,
        ),
    )

    statuses = sorted([res_a.status_code, res_b.status_code])
    assert statuses == [200, 409]  # Atomic reservation prevents overselling 3 units across 2+2!

    winner = res_a if res_a.status_code == 200 else res_b
    winner_json = winner.json()
    assert winner_json["payment_status"] == "uncertain"
    provider_ref = winner_json["provider_reference"]
    order_id = winner_json["order"]["id"]

    # Unsigned webhook must fail
    bad_wh = await client.post(
        "/api/v1/webhooks/payment",
        json={"provider_reference": provider_ref, "event_status": "succeeded"},
    )
    assert bad_wh.status_code == 401

    # Valid HMAC webhook reconciles uncertain order to paid
    wh_payload = json.dumps(
        {"provider_reference": provider_ref, "event_status": "succeeded"}
    ).encode("utf-8")
    sig = hmac.new(
        get_settings().payment_webhook_secret.encode("utf-8"),
        wh_payload,
        hashlib.sha256,
    ).hexdigest()
    good_wh = await client.post(
        "/api/v1/webhooks/payment",
        headers={"X-Webhook-Signature": f"sha256={sig}", "Content-Type": "application/json"},
        content=wh_payload,
    )
    assert good_wh.status_code == 200
    assert good_wh.json()["payment_status"] == "paid"

    # Also verify reservation expiry sweep releases expired locks cleanly
    async with session_factory() as db:
        variant = await db.get(ProductVariant, "var_tee_charcoal_m")
        assert variant.stock_on_hand == 1  # 3 - 2 consumed
        assert variant.reserved_stock == 0

        # Insert an expired reservation manually to test sweep
        fake_order = Order(
            id="ord_expired_test",
            order_number="SM-EXPTEST",
            customer_id="cust_demo",
            order_status="pending_payment",
            payment_status="pending",
            fulfillment_status="unfulfilled",
            currency="USD",
            subtotal_minor=1690,
            total_minor=1690,
            shipping_address_json=DEMO_ADDRESS,
            idempotency_key="exp-test",
        )
        db.add(fake_order)
        variant.reserved_stock += 1
        db.add(
            InventoryReservation(
                id="res_expired_test",
                order_id="ord_expired_test",
                variant_id="var_tee_charcoal_m",
                quantity=1,
                status="active",
                expires_at=datetime.now(timezone.utc) - timedelta(minutes=1),
            )
        )
        await db.commit()

        released = await release_expired_reservations(db)
        await db.commit()
        assert released == 1
        await db.refresh(variant)
        assert variant.reserved_stock == 0


def test_upload_magic_bytes_and_log_redaction():
    valid_png = b"\x89PNG\r\n\x1a\n" + b"\x00" * 32
    assert validate_image_upload("sample.png", valid_png, 1024) == "image/png"

    with pytest.raises(Exception):
        validate_image_upload("fake.png", b"not-a-png", 1024)

    import logging
    rec = logging.LogRecord("test", logging.INFO, "", 0, "Header Authorization=secret123 Bearer abc.def", (), None)
    RedactingLogFilter().filter(rec)
    assert "secret123" not in rec.msg
    assert "abc.def" not in rec.msg
