"""Initial Sunburst Market commerce schema.

Revision ID: 0001_initial_schema
Revises:
Create Date: 2026-11-19 22:30:00
"""
from __future__ import annotations

from alembic import op
import sqlalchemy as sa

revision = "0001_initial_schema"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "sellers",
        sa.Column("id", sa.String(40), primary_key=True),
        sa.Column("name", sa.String(120), nullable=False),
        sa.Column("slug", sa.String(120), nullable=False, unique=True),
        sa.Column("support_email", sa.String(160), nullable=False),
        sa.Column("dispatch_city", sa.String(80), nullable=False),
        sa.Column("dispatch_country", sa.String(8), nullable=False, server_default="US"),
        sa.Column("free_shipping_threshold_minor", sa.Integer(), nullable=False, server_default="3500"),
        sa.Column("base_shipping_minor", sa.Integer(), nullable=False, server_default="499"),
        sa.Column("return_window_days", sa.Integer(), nullable=False, server_default="30"),
        sa.Column("return_policy_summary", sa.Text(), nullable=False),
        sa.Column("verified_badge", sa.Boolean(), nullable=False, server_default=sa.text("true")),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )

    op.create_table(
        "categories",
        sa.Column("id", sa.String(40), primary_key=True),
        sa.Column("name", sa.String(80), nullable=False),
        sa.Column("slug", sa.String(80), nullable=False, unique=True),
        sa.Column("icon_name", sa.String(64), nullable=False),
        sa.Column("description", sa.Text(), nullable=False, server_default=""),
        sa.Column("sort_order", sa.Integer(), nullable=False, server_default="0"),
    )

    op.create_table(
        "products",
        sa.Column("id", sa.String(40), primary_key=True),
        sa.Column("seller_id", sa.String(40), sa.ForeignKey("sellers.id", ondelete="CASCADE"), nullable=False),
        sa.Column("category_id", sa.String(40), sa.ForeignKey("categories.id", ondelete="RESTRICT"), nullable=False),
        sa.Column("title", sa.String(180), nullable=False),
        sa.Column("subtitle", sa.String(240), nullable=False, server_default=""),
        sa.Column("description", sa.Text(), nullable=False),
        sa.Column("collection_tag", sa.String(80), nullable=True),
        sa.Column("featured_rank", sa.Integer(), nullable=True),
        sa.Column("dimensions_cm", sa.String(120), nullable=False),
        sa.Column("weight_grams", sa.Integer(), nullable=False),
        sa.Column("materials", sa.JSON(), nullable=False),
        sa.Column("shipping_restrictions", sa.JSON(), nullable=False),
        sa.Column("estimated_min_days", sa.Integer(), nullable=False, server_default="3"),
        sa.Column("estimated_max_days", sa.Integer(), nullable=False, server_default="6"),
        sa.Column("guaranteed_by_days", sa.Integer(), nullable=True),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.text("true")),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_products_seller_id", "products", ["seller_id"])
    op.create_index("ix_products_category_id", "products", ["category_id"])
    op.create_index("ix_products_collection_tag", "products", ["collection_tag"])

    op.create_table(
        "product_variants",
        sa.Column("id", sa.String(40), primary_key=True),
        sa.Column("product_id", sa.String(40), sa.ForeignKey("products.id", ondelete="CASCADE"), nullable=False),
        sa.Column("sku", sa.String(64), nullable=False, unique=True),
        sa.Column("title", sa.String(120), nullable=False),
        sa.Column("attributes", sa.JSON(), nullable=False),
        sa.Column("currency", sa.String(3), nullable=False, server_default="USD"),
        sa.Column("price_minor", sa.Integer(), nullable=False),
        sa.Column("stock_on_hand", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("reserved_stock", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.text("true")),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_product_variants_product_id", "product_variants", ["product_id"])

    op.create_table(
        "product_images",
        sa.Column("id", sa.String(40), primary_key=True),
        sa.Column("product_id", sa.String(40), sa.ForeignKey("products.id", ondelete="CASCADE"), nullable=False),
        sa.Column("variant_id", sa.String(40), sa.ForeignKey("product_variants.id", ondelete="SET NULL"), nullable=True),
        sa.Column("object_key", sa.String(255), nullable=False),
        sa.Column("url", sa.String(500), nullable=False),
        sa.Column("alt_text", sa.String(240), nullable=False),
        sa.Column("sort_order", sa.Integer(), nullable=False, server_default="0"),
    )

    op.create_table(
        "price_history",
        sa.Column("id", sa.String(40), primary_key=True),
        sa.Column("variant_id", sa.String(40), sa.ForeignKey("product_variants.id", ondelete="CASCADE"), nullable=False),
        sa.Column("currency", sa.String(3), nullable=False, server_default="USD"),
        sa.Column("price_minor", sa.Integer(), nullable=False),
        sa.Column("reason", sa.String(160), nullable=False),
        sa.Column("recorded_at", sa.DateTime(timezone=True), nullable=False),
    )

    op.create_table(
        "product_documents",
        sa.Column("id", sa.String(40), primary_key=True),
        sa.Column("product_id", sa.String(40), sa.ForeignKey("products.id", ondelete="CASCADE"), nullable=False),
        sa.Column("title", sa.String(140), nullable=False),
        sa.Column("doc_type", sa.String(40), nullable=False),
        sa.Column("url", sa.String(500), nullable=False),
        sa.Column("summary", sa.Text(), nullable=False),
    )

    op.create_table(
        "product_reviews",
        sa.Column("id", sa.String(40), primary_key=True),
        sa.Column("product_id", sa.String(40), sa.ForeignKey("products.id", ondelete="CASCADE"), nullable=False),
        sa.Column("variant_title", sa.String(120), nullable=False),
        sa.Column("author_display", sa.String(80), nullable=False),
        sa.Column("rating", sa.Integer(), nullable=False),
        sa.Column("title", sa.String(140), nullable=False),
        sa.Column("body", sa.Text(), nullable=False),
        sa.Column("verified_demo_purchase", sa.Boolean(), nullable=False, server_default=sa.text("true")),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )

    op.create_table(
        "customers",
        sa.Column("id", sa.String(40), primary_key=True),
        sa.Column("email", sa.String(180), nullable=True, unique=True),
        sa.Column("password_hash", sa.String(255), nullable=True),
        sa.Column("display_name", sa.String(120), nullable=False),
        sa.Column("is_guest", sa.Boolean(), nullable=False, server_default=sa.text("false")),
        sa.Column("deletion_requested_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )

    op.create_table(
        "device_sessions",
        sa.Column("id", sa.String(40), primary_key=True),
        sa.Column("customer_id", sa.String(40), sa.ForeignKey("customers.id", ondelete="CASCADE"), nullable=False),
        sa.Column("device_name", sa.String(120), nullable=False),
        sa.Column("platform", sa.String(40), nullable=False, server_default="iPadOS"),
        sa.Column("last_active_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("revoked_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )

    op.create_table(
        "customer_addresses",
        sa.Column("id", sa.String(40), primary_key=True),
        sa.Column("customer_id", sa.String(40), sa.ForeignKey("customers.id", ondelete="CASCADE"), nullable=False),
        sa.Column("label", sa.String(60), nullable=False),
        sa.Column("recipient_name", sa.String(120), nullable=False),
        sa.Column("line1", sa.String(180), nullable=False),
        sa.Column("line2", sa.String(180), nullable=False, server_default=""),
        sa.Column("city", sa.String(80), nullable=False),
        sa.Column("region", sa.String(80), nullable=False),
        sa.Column("postal_code", sa.String(24), nullable=False),
        sa.Column("country_code", sa.String(4), nullable=False),
        sa.Column("is_default", sa.Boolean(), nullable=False, server_default=sa.text("false")),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )

    op.create_table(
        "customer_preferences",
        sa.Column("customer_id", sa.String(40), sa.ForeignKey("customers.id", ondelete="CASCADE"), primary_key=True),
        sa.Column("destination_country", sa.String(4), nullable=False, server_default="US"),
        sa.Column("destination_postal", sa.String(24), nullable=False, server_default="94107"),
        sa.Column("currency", sa.String(3), nullable=False, server_default="USD"),
        sa.Column("order_updates_enabled", sa.Boolean(), nullable=False, server_default=sa.text("true")),
        sa.Column("promo_alerts_enabled", sa.Boolean(), nullable=False, server_default=sa.text("false")),
        sa.Column("price_drop_alerts_enabled", sa.Boolean(), nullable=False, server_default=sa.text("true")),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )

    op.create_table(
        "saved_products",
        sa.Column("id", sa.String(40), primary_key=True),
        sa.Column("customer_id", sa.String(40), sa.ForeignKey("customers.id", ondelete="CASCADE"), nullable=False),
        sa.Column("product_id", sa.String(40), sa.ForeignKey("products.id", ondelete="CASCADE"), nullable=False),
        sa.Column("preferred_variant_id", sa.String(40), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("customer_id", "product_id", name="uq_saved_customer_product"),
    )

    op.create_table(
        "recently_viewed",
        sa.Column("id", sa.String(40), primary_key=True),
        sa.Column("customer_id", sa.String(40), sa.ForeignKey("customers.id", ondelete="CASCADE"), nullable=False),
        sa.Column("product_id", sa.String(40), sa.ForeignKey("products.id", ondelete="CASCADE"), nullable=False),
        sa.Column("viewed_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("customer_id", "product_id", name="uq_recent_customer_product"),
    )

    op.create_table(
        "bag_items",
        sa.Column("id", sa.String(40), primary_key=True),
        sa.Column("customer_id", sa.String(40), sa.ForeignKey("customers.id", ondelete="CASCADE"), nullable=False),
        sa.Column("product_id", sa.String(40), sa.ForeignKey("products.id", ondelete="CASCADE"), nullable=False),
        sa.Column("variant_id", sa.String(40), sa.ForeignKey("product_variants.id", ondelete="CASCADE"), nullable=False),
        sa.Column("quantity", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("status", sa.String(24), nullable=False, server_default="active"),
        sa.Column("unit_price_snapshot_minor", sa.Integer(), nullable=False),
        sa.Column("currency", sa.String(3), nullable=False, server_default="USD"),
        sa.Column("notice_message", sa.Text(), nullable=True),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("customer_id", "variant_id", "status", name="uq_bag_customer_variant_status"),
    )

    op.create_table(
        "promotions",
        sa.Column("id", sa.String(40), primary_key=True),
        sa.Column("code", sa.String(40), nullable=False),
        sa.Column("version", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("title", sa.String(120), nullable=False),
        sa.Column("description", sa.Text(), nullable=False),
        sa.Column("discount_type", sa.String(20), nullable=False),
        sa.Column("discount_value", sa.Integer(), nullable=False),
        sa.Column("currency", sa.String(3), nullable=False, server_default="USD"),
        sa.Column("min_spend_minor", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("max_discount_minor", sa.Integer(), nullable=True),
        sa.Column("starts_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("ends_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("stacking_precedence", sa.Integer(), nullable=False, server_default="100"),
        sa.Column("is_stackable", sa.Boolean(), nullable=False, server_default=sa.text("false")),
        sa.Column("eligible_category_ids", sa.JSON(), nullable=False),
        sa.Column("excluded_product_ids", sa.JSON(), nullable=False),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.text("true")),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )

    op.create_table(
        "orders",
        sa.Column("id", sa.String(40), primary_key=True),
        sa.Column("order_number", sa.String(32), nullable=False, unique=True),
        sa.Column("customer_id", sa.String(40), sa.ForeignKey("customers.id", ondelete="CASCADE"), nullable=False),
        sa.Column("order_status", sa.String(32), nullable=False),
        sa.Column("payment_status", sa.String(32), nullable=False),
        sa.Column("fulfillment_status", sa.String(32), nullable=False),
        sa.Column("currency", sa.String(3), nullable=False, server_default="USD"),
        sa.Column("subtotal_minor", sa.Integer(), nullable=False),
        sa.Column("discount_minor", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("shipping_minor", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("tax_minor", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("total_minor", sa.Integer(), nullable=False),
        sa.Column("delivery_method", sa.String(32), nullable=False, server_default="standard"),
        sa.Column("shipping_address_json", sa.JSON(), nullable=False),
        sa.Column("applied_promotions_json", sa.JSON(), nullable=False),
        sa.Column("discount_explanation", sa.Text(), nullable=False, server_default=""),
        sa.Column("idempotency_key", sa.String(120), nullable=False),
        sa.Column("is_demo_order", sa.Boolean(), nullable=False, server_default=sa.text("true")),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )

    op.create_table(
        "promotion_usages",
        sa.Column("id", sa.String(40), primary_key=True),
        sa.Column("promotion_id", sa.String(40), sa.ForeignKey("promotions.id", ondelete="CASCADE"), nullable=False),
        sa.Column("promotion_version", sa.Integer(), nullable=False),
        sa.Column("customer_id", sa.String(40), sa.ForeignKey("customers.id", ondelete="CASCADE"), nullable=False),
        sa.Column("order_id", sa.String(40), sa.ForeignKey("orders.id", ondelete="CASCADE"), nullable=False),
        sa.Column("discount_applied_minor", sa.Integer(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )

    op.create_table(
        "inventory_reservations",
        sa.Column("id", sa.String(40), primary_key=True),
        sa.Column("order_id", sa.String(40), sa.ForeignKey("orders.id", ondelete="CASCADE"), nullable=False),
        sa.Column("variant_id", sa.String(40), sa.ForeignKey("product_variants.id", ondelete="CASCADE"), nullable=False),
        sa.Column("quantity", sa.Integer(), nullable=False),
        sa.Column("status", sa.String(24), nullable=False),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )

    op.create_table(
        "order_seller_fulfillments",
        sa.Column("id", sa.String(40), primary_key=True),
        sa.Column("order_id", sa.String(40), sa.ForeignKey("orders.id", ondelete="CASCADE"), nullable=False),
        sa.Column("seller_id", sa.String(40), sa.ForeignKey("sellers.id", ondelete="RESTRICT"), nullable=False),
        sa.Column("seller_name", sa.String(120), nullable=False),
        sa.Column("status", sa.String(32), nullable=False),
        sa.Column("carrier_name", sa.String(60), nullable=False),
        sa.Column("tracking_number", sa.String(64), nullable=False),
        sa.Column("shipping_minor", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("estimated_window", sa.String(80), nullable=False),
        sa.Column("guaranteed_by", sa.String(80), nullable=True),
        sa.Column("exception_note", sa.Text(), nullable=True),
        sa.Column("tracking_events_json", sa.JSON(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )

    op.create_table(
        "order_items",
        sa.Column("id", sa.String(40), primary_key=True),
        sa.Column("order_id", sa.String(40), sa.ForeignKey("orders.id", ondelete="CASCADE"), nullable=False),
        sa.Column("fulfillment_id", sa.String(40), sa.ForeignKey("order_seller_fulfillments.id", ondelete="CASCADE"), nullable=False),
        sa.Column("seller_id", sa.String(40), nullable=False),
        sa.Column("product_id", sa.String(40), nullable=False),
        sa.Column("variant_id", sa.String(40), nullable=False),
        sa.Column("sku", sa.String(64), nullable=False),
        sa.Column("product_title", sa.String(180), nullable=False),
        sa.Column("variant_summary", sa.String(120), nullable=False),
        sa.Column("image_url", sa.String(500), nullable=False),
        sa.Column("currency", sa.String(3), nullable=False, server_default="USD"),
        sa.Column("unit_price_minor", sa.Integer(), nullable=False),
        sa.Column("quantity", sa.Integer(), nullable=False),
        sa.Column("line_total_minor", sa.Integer(), nullable=False),
    )

    op.create_table(
        "payment_attempts",
        sa.Column("id", sa.String(40), primary_key=True),
        sa.Column("order_id", sa.String(40), sa.ForeignKey("orders.id", ondelete="CASCADE"), nullable=False),
        sa.Column("provider", sa.String(40), nullable=False),
        sa.Column("provider_reference", sa.String(120), nullable=False),
        sa.Column("status", sa.String(32), nullable=False),
        sa.Column("amount_minor", sa.Integer(), nullable=False),
        sa.Column("currency", sa.String(3), nullable=False, server_default="USD"),
        sa.Column("failure_reason", sa.Text(), nullable=True),
        sa.Column("idempotency_key", sa.String(120), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )

    op.create_table(
        "return_requests",
        sa.Column("id", sa.String(40), primary_key=True),
        sa.Column("order_id", sa.String(40), sa.ForeignKey("orders.id", ondelete="CASCADE"), nullable=False),
        sa.Column("customer_id", sa.String(40), sa.ForeignKey("customers.id", ondelete="CASCADE"), nullable=False),
        sa.Column("items_json", sa.JSON(), nullable=False),
        sa.Column("reason", sa.Text(), nullable=False),
        sa.Column("eligible_amount_minor", sa.Integer(), nullable=False),
        sa.Column("requested_amount_minor", sa.Integer(), nullable=False),
        sa.Column("currency", sa.String(3), nullable=False, server_default="USD"),
        sa.Column("return_status", sa.String(32), nullable=False),
        sa.Column("refund_status", sa.String(32), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )

    op.create_table(
        "support_messages",
        sa.Column("id", sa.String(40), primary_key=True),
        sa.Column("order_id", sa.String(40), sa.ForeignKey("orders.id", ondelete="CASCADE"), nullable=False),
        sa.Column("customer_id", sa.String(40), sa.ForeignKey("customers.id", ondelete="CASCADE"), nullable=False),
        sa.Column("sender_role", sa.String(24), nullable=False),
        sa.Column("body", sa.Text(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )

    op.create_table(
        "idempotency_records",
        sa.Column("id", sa.String(40), primary_key=True),
        sa.Column("scope", sa.String(48), nullable=False),
        sa.Column("customer_id", sa.String(40), nullable=False),
        sa.Column("key", sa.String(120), nullable=False),
        sa.Column("request_hash", sa.String(64), nullable=False),
        sa.Column("response_status", sa.Integer(), nullable=False),
        sa.Column("response_body", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("scope", "customer_id", "key", name="uq_idempotency_scope_cust_key"),
    )


def downgrade() -> None:
    for table in [
        "idempotency_records",
        "support_messages",
        "return_requests",
        "payment_attempts",
        "order_items",
        "order_seller_fulfillments",
        "inventory_reservations",
        "promotion_usages",
        "orders",
        "promotions",
        "bag_items",
        "recently_viewed",
        "saved_products",
        "customer_preferences",
        "customer_addresses",
        "device_sessions",
        "customers",
        "product_reviews",
        "product_documents",
        "price_history",
        "product_images",
        "product_variants",
        "products",
        "categories",
        "sellers",
    ]:
        op.drop_table(table)
