# Sunburst Market Backend API Reference

Base URL (local Docker Compose): `http://localhost:8000`
Interactive OpenAPI docs: `http://localhost:8000/docs`

All monetary values use **integer minor units** (e.g., `2890` = `$28.90` USD) with explicit `currency` fields.

## Authentication & Security
- Customer endpoints use `Authorization: Bearer <token>` returned by `/api/v1/account/login`, `/register`, or `/guest`.
- Tokens bind to a `DeviceSession` (`device_session_id`) so individual iPad sessions can be revoked remotely.
- Admin endpoints require `X-Admin-Token: <ADMIN_API_TOKEN>`.
- Payment webhooks require `X-Webhook-Signature: sha256=<hmac_sha256>`.
- Request payloads are bounded (`MAX_REQUEST_BODY_BYTES`), uploads validate magic bytes, and sensitive endpoints enforce rate limits.

## Endpoints

### Health
- `GET /health` — Reports PostgreSQL/SQLite database connectivity, S3/local object storage status, and assistant mode (`gemini` or `scripted_fallback`).

### Discover & Catalog
- `GET /api/v1/discover?destination_country=US&destination_postal=94107` — Editorial banner (real `ends_at` only when configured), category shortcuts, featured products, account recently-viewed items, and explainable recommended collections.
- `GET /api/v1/catalog/categories` — All categories ordered by `sort_order`.
- `GET /api/v1/catalog/sellers` — All verified sellers with shipping thresholds and return summaries.
- `GET /api/v1/catalog/search` — Query parameters: `q`, `category_id`, `seller_id`, `min_price_minor`, `max_price_minor`, `attribute_key`, `attribute_value`, `in_stock_only`, `eligible_only`, `destination_country`, `sort` (`relevance`, `price_asc`, `price_desc`, `newest`), `page`, `page_size`.
- `GET /api/v1/catalog/products/{product_id}` — Full product detail, variant-level prices/stock/SKU/price history, product documents, shipping restrictions, and verified demonstration reviews.

### Shopping Bag
- `GET /api/v1/bag` — Persistent customer bag grouped by seller, plus `saved_for_later`, live server price/stock refresh, and change notices.
- `POST /api/v1/bag/items` — Add `{product_id, variant_id, quantity}`.
- `PATCH /api/v1/bag/items/{item_id}` — Update `quantity`, switch `variant_id`, or toggle `status` (`active` / `saved_for_later`).
- `POST /api/v1/bag/acknowledge-changes` — Acknowledge updated server prices on bag lines.
- `DELETE /api/v1/bag/items/{item_id}` — Remove line item.

### Demo Checkout & Webhooks
- `POST /api/v1/checkout/preview` — Server-calculates subtotal, versioned promotion discounts (with precedence & explanation), seller shipping, taxes, and minor-unit total.
- `POST /api/v1/checkout/confirm` — Requires `Idempotency-Key` header. Atomically reserves inventory, creates seller-level `OrderSellerFulfillment` records, executes demo payment adapter (`success`, `failed`, `uncertain_timeout`), and replays identical cached responses safely on network retry.
- `POST /api/v1/webhooks/payment` — HMAC-signed reconciliation endpoint transitioning `uncertain` orders to `paid` or `payment_failed`.

### Orders, Tracking, Cancellations & Returns
- `GET /api/v1/orders` — Customer's orders only.
- `GET /api/v1/orders/{order_id}` — Enforces ownership; includes multi-seller fulfillments, synthetic carrier events, returns, and support messages.
- `POST /api/v1/orders/{order_id}/tracking/advance` — Advances synthetic carrier events or simulates a delivery exception.
- `POST /api/v1/orders/{order_id}/cancel` — Cancels unshipped orders and releases inventory reservations.
- `POST /api/v1/orders/{order_id}/returns` — Creates a return request capped strictly at the eligible purchased amount; sets `refund_status = "refund_approved"`.
- `POST /api/v1/orders/{order_id}/messages` — Posts an order-scoped customer service message.

### Account & Privacy
- `POST /api/v1/account/guest` | `POST /api/v1/account/register` | `POST /api/v1/account/login`
- `GET /api/v1/account/me` | `PATCH /api/v1/account/preferences`
- `POST /api/v1/account/addresses` | `DELETE /api/v1/account/addresses/{id}`
- `POST /api/v1/account/sessions/{id}/revoke`
- `POST /api/v1/account/deletion-request`
- `GET/POST/DELETE /api/v1/account/saved`

### Shopping Assistant
- `POST /api/v1/assistant/chat` — Answers product/attribute/delivery/return/order queries using permissioned backend tools and requires confirmation tokens before mutating actions.

### Admin Interface & CLI
- `GET /api/v1/admin/integration-health`
- `POST /api/v1/admin/sellers` | `POST /api/v1/admin/products` | `POST /api/v1/admin/variants`
- `PATCH /api/v1/admin/variants/{id}/price` | `PATCH /api/v1/admin/variants/{id}/inventory`
- `POST /api/v1/admin/products/{id}/images` — Validates magic bytes (PNG/JPEG/WEBP) and size cap.
- `POST /api/v1/admin/promotions`
- `GET /api/v1/admin/orders` | `GET /api/v1/admin/returns`
- `POST /api/v1/admin/returns/{id}/refund-transition` — Enforces `refund_approved -> refund_submitted -> refund_confirmed`.
- `POST /api/v1/admin/reservations/release-expired`
