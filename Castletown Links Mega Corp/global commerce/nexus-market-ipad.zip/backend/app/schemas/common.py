from __future__ import annotations

from datetime import datetime
from typing import Any, Literal
from pydantic import BaseModel, Field


class MoneyDTO(BaseModel):
    amount_minor: int
    currency: str = "USD"


class SellerSummaryDTO(BaseModel):
    id: str
    name: str
    slug: str
    dispatch_city: str
    dispatch_country: str
    free_shipping_threshold_minor: int
    base_shipping_minor: int
    return_window_days: int
    return_policy_summary: str
    verified_badge: bool


class CategoryDTO(BaseModel):
    id: str
    name: str
    slug: str
    icon_name: str
    description: str


class PriceHistoryDTO(BaseModel):
    id: str
    price_minor: int
    currency: str
    reason: str
    recorded_at: datetime


class ProductImageDTO(BaseModel):
    id: str
    variant_id: str | None = None
    url: str
    alt_text: str
    sort_order: int


class ProductDocumentDTO(BaseModel):
    id: str
    title: str
    doc_type: str
    url: str
    summary: str


class ProductReviewDTO(BaseModel):
    id: str
    variant_title: str
    author_display: str
    rating: int
    title: str
    body: str
    verified_demo_purchase: bool
    created_at: datetime


class VariantDTO(BaseModel):
    id: str
    sku: str
    title: str
    attributes: dict[str, str]
    currency: str
    price_minor: int
    reference_price_minor: int | None = None
    reference_price_basis: str | None = None
    available_stock: int
    is_active: bool
    price_history: list[PriceHistoryDTO] = Field(default_factory=list)


class DeliverySummaryDTO(BaseModel):
    estimated_window: str
    guaranteed_by: str | None = None
    is_guaranteed: bool
    eligible_for_destination: bool
    restriction_reason: str | None = None


class ProductCardDTO(BaseModel):
    id: str
    title: str
    subtitle: str
    category_id: str
    category_name: str
    seller: SellerSummaryDTO
    primary_image_url: str
    starting_price_minor: int
    reference_price_minor: int | None = None
    currency: str
    variant_count: int
    variant_swatches: list[str]
    in_stock: bool
    delivery: DeliverySummaryDTO
    rating_average: float | None = None
    review_count: int = 0
    recommendation_reason: str | None = None


class ProductDetailDTO(BaseModel):
    id: str
    title: str
    subtitle: str
    description: str
    category: CategoryDTO
    seller: SellerSummaryDTO
    dimensions_cm: str
    weight_grams: int
    materials: list[str]
    shipping_restrictions: dict[str, Any]
    delivery: DeliverySummaryDTO
    variants: list[VariantDTO]
    images: list[ProductImageDTO]
    documents: list[ProductDocumentDTO]
    reviews: list[ProductReviewDTO]
    rating_average: float | None = None
    is_saved: bool = False


class PromotionBannerDTO(BaseModel):
    id: str
    code: str
    version: int
    title: str
    description: str
    ends_at: datetime | None = None


class RecommendedCollectionDTO(BaseModel):
    id: str
    title: str
    explanation: str
    products: list[ProductCardDTO]


class DiscoverResponseDTO(BaseModel):
    destination_country: str
    destination_postal: str
    banner: PromotionBannerDTO | None = None
    categories: list[CategoryDTO]
    featured_products: list[ProductCardDTO]
    recently_viewed: list[ProductCardDTO]
    collections: list[RecommendedCollectionDTO]


class SearchResponseDTO(BaseModel):
    items: list[ProductCardDTO]
    total: int
    page: int
    page_size: int
    has_next: bool


class BagAddRequest(BaseModel):
    product_id: str
    variant_id: str
    quantity: int = Field(ge=1, le=50)


class BagUpdateRequest(BaseModel):
    quantity: int | None = Field(default=None, ge=1, le=50)
    variant_id: str | None = None
    status: Literal["active", "saved_for_later"] | None = None


class BagLineDTO(BaseModel):
    id: str
    product_id: str
    variant_id: str
    sku: str
    product_title: str
    variant_title: str
    available_variants: list[VariantDTO]
    image_url: str
    quantity: int
    unit_price_minor: int
    previous_unit_price_minor: int
    line_total_minor: int
    currency: str
    available_stock: int
    status: str
    price_changed: bool
    stock_insufficient: bool
    notice_message: str | None = None
    eligible_for_destination: bool
    restriction_reason: str | None = None


class BagSellerGroupDTO(BaseModel):
    seller: SellerSummaryDTO
    items: list[BagLineDTO]
    subtotal_minor: int
    estimated_shipping_minor: int
    free_shipping_remaining_minor: int


class BagResponseDTO(BaseModel):
    destination_country: str
    currency: str
    seller_groups: list[BagSellerGroupDTO]
    saved_for_later: list[BagLineDTO]
    subtotal_minor: int
    estimated_shipping_minor: int
    has_blocking_issues: bool
    notices: list[str]


class AddressInput(BaseModel):
    label: str = Field(min_length=1, max_length=60)
    recipient_name: str = Field(min_length=1, max_length=120)
    line1: str = Field(min_length=1, max_length=180)
    line2: str = Field(default="", max_length=180)
    city: str = Field(min_length=1, max_length=80)
    region: str = Field(min_length=1, max_length=80)
    postal_code: str = Field(min_length=2, max_length=24)
    country_code: str = Field(min_length=2, max_length=4)
    is_default: bool = False


class AddressDTO(AddressInput):
    id: str


class CheckoutPreviewRequest(BaseModel):
    address: AddressInput
    delivery_method: Literal["standard", "express"] = "standard"
    promo_codes: list[str] = Field(default_factory=list, max_length=5)


class AppliedPromotionDTO(BaseModel):
    id: str
    code: str
    version: int
    title: str
    discount_minor: int
    explanation: str


class CheckoutSellerSummaryDTO(BaseModel):
    seller_id: str
    seller_name: str
    subtotal_minor: int
    shipping_minor: int
    estimated_window: str
    guaranteed_by: str | None = None
    item_count: int


class CheckoutPreviewResponseDTO(BaseModel):
    currency: str
    subtotal_minor: int
    discount_minor: int
    shipping_minor: int
    tax_minor: int
    total_minor: int
    tax_rate_bps: int
    applied_promotions: list[AppliedPromotionDTO]
    rejected_promotions: list[dict[str, str]]
    discount_explanation: str
    seller_breakdowns: list[CheckoutSellerSummaryDTO]
    is_demo_checkout: bool = True
    notices: list[str] = Field(default_factory=list)


class CheckoutConfirmRequest(BaseModel):
    address: AddressInput
    delivery_method: Literal["standard", "express"] = "standard"
    promo_codes: list[str] = Field(default_factory=list, max_length=5)
    simulation_outcome: Literal["success", "failed", "uncertain_timeout"] = "success"


class OrderItemDTO(BaseModel):
    id: str
    product_id: str
    variant_id: str
    sku: str
    product_title: str
    variant_summary: str
    image_url: str
    currency: str
    unit_price_minor: int
    quantity: int
    line_total_minor: int


class TrackingEventDTO(BaseModel):
    timestamp: str
    status: str
    location: str
    detail: str
    is_synthetic: bool = True


class OrderFulfillmentDTO(BaseModel):
    id: str
    seller_id: str
    seller_name: str
    status: str
    carrier_name: str
    tracking_number: str
    shipping_minor: int
    estimated_window: str
    guaranteed_by: str | None = None
    exception_note: str | None = None
    events: list[TrackingEventDTO]
    items: list[OrderItemDTO]


class ReturnRequestDTO(BaseModel):
    id: str
    order_id: str
    reason: str
    items_json: list[dict[str, Any]]
    eligible_amount_minor: int
    requested_amount_minor: int
    currency: str
    return_status: str
    refund_status: str
    created_at: datetime


class SupportMessageDTO(BaseModel):
    id: str
    order_id: str
    sender_role: str
    body: str
    created_at: datetime


class OrderDTO(BaseModel):
    id: str
    order_number: str
    order_status: str
    payment_status: str
    fulfillment_status: str
    currency: str
    subtotal_minor: int
    discount_minor: int
    shipping_minor: int
    tax_minor: int
    total_minor: int
    delivery_method: str
    shipping_address: dict[str, Any]
    applied_promotions: list[dict[str, Any]]
    discount_explanation: str
    is_demo_order: bool
    created_at: datetime
    fulfillments: list[OrderFulfillmentDTO]
    returns: list[ReturnRequestDTO] = Field(default_factory=list)
    support_messages: list[SupportMessageDTO] = Field(default_factory=list)


class CheckoutConfirmResponseDTO(BaseModel):
    order: OrderDTO
    payment_status: str
    provider_reference: str
    replayed_from_idempotency: bool = False
    message: str


class CreateReturnRequest(BaseModel):
    items: list[dict[str, Any]] = Field(min_length=1)
    reason: str = Field(min_length=3, max_length=500)
    requested_amount_minor: int | None = Field(default=None, ge=1)


class SupportMessageInput(BaseModel):
    body: str = Field(min_length=1, max_length=1000)


class AuthRegisterRequest(BaseModel):
    email: str = Field(min_length=3, max_length=180)
    password: str = Field(min_length=8, max_length=128)
    display_name: str = Field(min_length=1, max_length=120)
    device_name: str = Field(default="iPad", max_length=120)


class AuthLoginRequest(BaseModel):
    email: str
    password: str
    device_name: str = Field(default="iPad", max_length=120)


class GuestSessionRequest(BaseModel):
    device_name: str = Field(default="iPad Guest", max_length=120)


class AuthResponseDTO(BaseModel):
    token: str
    customer_id: str
    display_name: str
    email: str | None
    is_guest: bool
    device_session_id: str


class PreferencesUpdateRequest(BaseModel):
    destination_country: str | None = Field(default=None, min_length=2, max_length=4)
    destination_postal: str | None = Field(default=None, min_length=2, max_length=24)
    currency: str | None = Field(default=None, min_length=3, max_length=3)
    order_updates_enabled: bool | None = None
    promo_alerts_enabled: bool | None = None
    price_drop_alerts_enabled: bool | None = None


class DeviceSessionDTO(BaseModel):
    id: str
    device_name: str
    platform: str
    last_active_at: datetime
    revoked_at: datetime | None = None
    is_current: bool = False


class AccountSummaryDTO(BaseModel):
    customer_id: str
    email: str | None
    display_name: str
    is_guest: bool
    deletion_requested_at: datetime | None = None
    preferences: dict[str, Any]
    addresses: list[AddressDTO]
    sessions: list[DeviceSessionDTO]


class AssistantChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=1000)
    confirm_action_token: str | None = None


class AssistantChatResponseDTO(BaseModel):
    reply: str
    mode: str  # "gemini" or "scripted_fallback"
    referenced_products: list[ProductCardDTO] = Field(default_factory=list)
    referenced_orders: list[dict[str, Any]] = Field(default_factory=list)
    pending_confirmation: dict[str, Any] | None = None
