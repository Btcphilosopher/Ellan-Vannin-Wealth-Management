from __future__ import annotations

import argparse
import asyncio
import json

from app.core.config import get_settings
from app.core.database import AsyncSessionLocal, Base, engine
from app.core.storage import get_object_storage
from app.models.catalog import PriceHistory, ProductVariant, new_id
from app.services.inventory import release_expired_reservations
from app.services.orders import transition_refund_status
from app.services.seed import seed_demo_data


async def _cmd_seed() -> None:
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    async with AsyncSessionLocal() as session:
        res = await seed_demo_data(session)
    print(json.dumps(res))


async def _cmd_update_price(variant_id: str, price_minor: int, reason: str) -> None:
    async with AsyncSessionLocal() as session:
        variant = await session.get(ProductVariant, variant_id)
        if not variant:
            raise SystemExit(f"Variant {variant_id} not found")
        variant.price_minor = price_minor
        session.add(
            PriceHistory(
                id=new_id("ph"),
                variant_id=variant.id,
                currency=variant.currency,
                price_minor=price_minor,
                reason=reason,
            )
        )
        await session.commit()
    print(json.dumps({"variant_id": variant_id, "price_minor": price_minor}))


async def _cmd_update_stock(variant_id: str, stock_on_hand: int) -> None:
    async with AsyncSessionLocal() as session:
        variant = await session.get(ProductVariant, variant_id)
        if not variant:
            raise SystemExit(f"Variant {variant_id} not found")
        variant.stock_on_hand = stock_on_hand
        await session.commit()
    print(json.dumps({"variant_id": variant_id, "stock_on_hand": stock_on_hand}))


async def _cmd_transition_refund(return_id: str, next_status: str) -> None:
    async with AsyncSessionLocal() as session:
        ret = await transition_refund_status(session, return_id, next_status)
    print(json.dumps({"return_id": ret.id, "refund_status": ret.refund_status}))


async def _cmd_release_expired() -> None:
    async with AsyncSessionLocal() as session:
        count = await release_expired_reservations(session)
        await session.commit()
    print(json.dumps({"released": count}))


def _cmd_health() -> None:
    settings = get_settings()
    ok, storage_info = get_object_storage().health_check()
    print(
        json.dumps(
            {
                "brand": settings.brand_name,
                "object_storage_ok": ok,
                "object_storage": storage_info,
                "ai_mode": "gemini" if bool(settings.gemini_api_key) else "scripted_fallback",
            }
        )
    )


def main() -> None:
    parser = argparse.ArgumentParser(description="Sunburst Market Admin CLI")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("seed-demo")
    sub.add_parser("release-expired")
    sub.add_parser("integration-health")

    p_price = sub.add_parser("update-price")
    p_price.add_argument("variant_id")
    p_price.add_argument("price_minor", type=int)
    p_price.add_argument("--reason", default="Admin CLI price update")

    p_stock = sub.add_parser("update-stock")
    p_stock.add_argument("variant_id")
    p_stock.add_argument("stock_on_hand", type=int)

    p_refund = sub.add_parser("transition-refund")
    p_refund.add_argument("return_id")
    p_refund.add_argument("next_status", choices=["refund_approved", "refund_submitted", "refund_confirmed", "rejected"])

    args = parser.parse_args()
    if args.command == "seed-demo":
        asyncio.run(_cmd_seed())
    elif args.command == "update-price":
        asyncio.run(_cmd_update_price(args.variant_id, args.price_minor, args.reason))
    elif args.command == "update-stock":
        asyncio.run(_cmd_update_stock(args.variant_id, args.stock_on_hand))
    elif args.command == "transition-refund":
        asyncio.run(_cmd_transition_refund(args.return_id, args.next_status))
    elif args.command == "release-expired":
        asyncio.run(_cmd_release_expired())
    elif args.command == "integration-health":
        _cmd_health()


if __name__ == "__main__":
    main()
