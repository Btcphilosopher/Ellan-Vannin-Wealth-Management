from __future__ import annotations

import base64
from collections import defaultdict, deque
import hashlib
import hmac
import json
import logging
import re
import secrets
import time
from typing import Any

from fastapi import HTTPException, Request, status
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse, Response

from app.core.config import get_settings

SENSITIVE_KEY_PATTERN = re.compile(
    r"(password|secret|token|authorization|cookie|api_key|webhook_signature)",
    re.IGNORECASE,
)


class RedactingLogFilter(logging.Filter):
    """Redacts bearer tokens, secrets, and credentials from structured log messages."""

    TOKEN_REGEX = re.compile(r"(Bearer\s+)[A-Za-z0-9\-._~+/]+=*", re.IGNORECASE)
    KV_REGEX = re.compile(
        r"((?:password|secret|token|api_key|authorization)=)([^\s,;]+)",
        re.IGNORECASE,
    )

    def filter(self, record: logging.LogRecord) -> bool:
        if isinstance(record.msg, str):
            msg = self.TOKEN_REGEX.sub(r"\1[REDACTED]", record.msg)
            msg = self.KV_REGEX.sub(r"\1[REDACTED]", msg)
            record.msg = msg
        return True


def redact_dict(payload: dict[str, Any]) -> dict[str, Any]:
    sanitized: dict[str, Any] = {}
    for key, value in payload.items():
        if SENSITIVE_KEY_PATTERN.search(key):
            sanitized[key] = "[REDACTED]"
        elif isinstance(value, dict):
            sanitized[key] = redact_dict(value)
        else:
            sanitized[key] = value
    return sanitized


def hash_password(password: str, salt: str | None = None) -> str:
    salt_hex = salt or secrets.token_hex(16)
    derived = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        salt_hex.encode("utf-8"),
        200_000,
    )
    return f"pbkdf2_sha256${salt_hex}${base64.urlsafe_b64encode(derived).decode('ascii')}"


def verify_password(password: str, stored_hash: str) -> bool:
    try:
        scheme, salt_hex, expected_b64 = stored_hash.split("$", 2)
        if scheme != "pbkdf2_sha256":
            return False
        recomputed = hash_password(password, salt_hex)
        return hmac.compare_digest(recomputed, stored_hash)
    except ValueError:
        return False


def create_signed_token(
    customer_id: str,
    device_session_id: str,
    is_guest: bool,
    ttl_seconds: int = 86400 * 14,
) -> str:
    settings = get_settings()
    payload = {
        "sub": customer_id,
        "sid": device_session_id,
        "guest": is_guest,
        "exp": int(time.time()) + ttl_seconds,
    }
    encoded_payload = base64.urlsafe_b64encode(
        json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")
    ).decode("ascii")
    sig = hmac.new(
        settings.session_secret_key.encode("utf-8"),
        encoded_payload.encode("ascii"),
        hashlib.sha256,
    ).digest()
    encoded_sig = base64.urlsafe_b64encode(sig).decode("ascii")
    return f"{encoded_payload}.{encoded_sig}"


def verify_signed_token(token: str) -> dict[str, Any]:
    settings = get_settings()
    try:
        encoded_payload, encoded_sig = token.split(".", 1)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Malformed authentication token.",
        ) from exc

    expected_sig = hmac.new(
        settings.session_secret_key.encode("utf-8"),
        encoded_payload.encode("ascii"),
        hashlib.sha256,
    ).digest()
    expected_b64 = base64.urlsafe_b64encode(expected_sig).decode("ascii")
    if not hmac.compare_digest(encoded_sig, expected_b64):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token signature.",
        )

    try:
        payload = json.loads(base64.urlsafe_b64decode(encoded_payload.encode("ascii")))
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token payload.",
        ) from exc

    if int(payload.get("exp", 0)) < int(time.time()):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication token has expired.",
        )
    return payload


def verify_webhook_hmac(raw_body: bytes, signature_header: str | None) -> bool:
    if not signature_header:
        return False
    secret = get_settings().payment_webhook_secret.encode("utf-8")
    digest = hmac.new(secret, raw_body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(digest, signature_header.removeprefix("sha256="))


def validate_image_upload(filename: str, content: bytes, max_bytes: int) -> str:
    """Validates uploaded image size and magic bytes; returns canonical MIME type."""
    if not content:
        raise HTTPException(status_code=400, detail="Uploaded file is empty.")
    if len(content) > max_bytes:
        raise HTTPException(
            status_code=413,
            detail=f"Uploaded file exceeds maximum allowed size of {max_bytes} bytes.",
        )

    ext = filename.lower().rsplit(".", 1)[-1] if "." in filename else ""
    if content.startswith(b"\x89PNG\r\n\x1a\n") and ext in {"png"}:
        return "image/png"
    if content.startswith(b"\xff\xd8\xff") and ext in {"jpg", "jpeg"}:
        return "image/jpeg"
    if content[:4] == b"RIFF" and content[8:12] == b"WEBP" and ext == "webp":
        return "image/webp"

    raise HTTPException(
        status_code=400,
        detail="Unsupported or mismatched image file. Allowed formats: PNG, JPEG, WEBP.",
    )


class InMemoryRateLimiter:
    def __init__(self) -> None:
        self._buckets: dict[str, deque[float]] = defaultdict(deque)

    def allow(self, key: str, limit: int, window_seconds: int = 60) -> bool:
        now = time.monotonic()
        bucket = self._buckets[key]
        while bucket and now - bucket[0] > window_seconds:
            bucket.popleft()
        if len(bucket) >= limit:
            return False
        bucket.append(now)
        return True

    def reset(self) -> None:
        self._buckets.clear()


rate_limiter = InMemoryRateLimiter()


class SecurityEnforcementMiddleware(BaseHTTPMiddleware):
    SENSITIVE_PREFIXES = (
        "/api/v1/account/login",
        "/api/v1/account/register",
        "/api/v1/checkout/confirm",
        "/api/v1/admin",
        "/api/v1/webhooks",
    )

    async def dispatch(self, request: Request, call_next) -> Response:
        settings = get_settings()
        content_length = request.headers.get("content-length")
        if content_length:
            try:
                if int(content_length) > settings.max_request_body_bytes:
                    return JSONResponse(
                        status_code=413,
                        content={"detail": "Request payload exceeds configured maximum size."},
                    )
            except ValueError:
                return JSONResponse(
                    status_code=400,
                    content={"detail": "Invalid Content-Length header."},
                )

        client_ip = request.client.host if request.client else "unknown"
        path = request.url.path
        is_sensitive = any(path.startswith(prefix) for prefix in self.SENSITIVE_PREFIXES)
        limit = (
            settings.sensitive_rate_limit_per_minute
            if is_sensitive
            else settings.rate_limit_per_minute
        )
        bucket_key = f"{client_ip}:{'sensitive' if is_sensitive else 'general'}"
        if not rate_limiter.allow(bucket_key, limit=limit):
            return JSONResponse(
                status_code=429,
                content={"detail": "Rate limit exceeded. Please wait briefly before retrying."},
            )

        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        return response
