from __future__ import annotations

from datetime import datetime, timezone
import hmac

from fastapi import Depends, Header, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.core.database import get_db
from app.core.security import verify_signed_token
from app.models.commerce import Customer, DeviceSession


async def get_optional_auth(
    authorization: str | None = Header(default=None),
    db: AsyncSession = Depends(get_db),
) -> tuple[Customer, DeviceSession] | None:
    if not authorization or not authorization.startswith("Bearer "):
        return None
    token = authorization.removeprefix("Bearer ").strip()
    payload = verify_signed_token(token)
    customer = await db.get(Customer, payload["sub"])
    session = await db.get(DeviceSession, payload["sid"])
    if not customer or not session or session.revoked_at is not None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Session is invalid or revoked.",
        )
    if customer.deletion_requested_at is not None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Account is pending deletion.",
        )
    session.last_active_at = datetime.now(timezone.utc)
    await db.commit()
    return customer, session


async def require_customer_auth(
    auth: tuple[Customer, DeviceSession] | None = Depends(get_optional_auth),
) -> tuple[Customer, DeviceSession]:
    if auth is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required.",
        )
    return auth


async def require_admin_token(
    x_admin_token: str | None = Header(default=None),
) -> None:
    expected = get_settings().admin_api_token
    if not x_admin_token or not hmac.compare_digest(x_admin_token, expected):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Valid X-Admin-Token header required.",
        )
