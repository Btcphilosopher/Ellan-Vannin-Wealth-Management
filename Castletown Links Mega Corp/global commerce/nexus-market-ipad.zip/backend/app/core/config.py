from __future__ import annotations

from functools import lru_cache
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    app_name: str = "Sunburst Market API"
    brand_name: str = "Sunburst Market"
    environment: str = "development"
    log_level: str = "INFO"

    database_url: str = "sqlite+aiosqlite:///./sunburst_dev.db"
    database_url_sync: str = "sqlite:///./sunburst_dev.db"

    session_secret_key: str = "dev-only-session-secret-change-me-32bytes"
    admin_api_token: str = "dev-only-admin-token-change-me"
    payment_webhook_secret: str = "dev-only-webhook-secret-change-me"

    object_storage_mode: str = "local"  # "s3" or "local"
    s3_endpoint_url: str = "http://localhost:9000"
    s3_public_base_url: str = "http://localhost:9000/sunburst-media"
    s3_access_key: str = "minioadmin"
    s3_secret_key: str = "minioadmin_dev_pw"
    s3_bucket: str = "sunburst-media"
    s3_region: str = "us-east-1"

    default_currency: str = "USD"
    default_tax_rate_bps: int = 825  # 8.25%
    reservation_ttl_seconds: int = 900  # 15 minutes
    max_request_body_bytes: int = 2 * 1024 * 1024
    max_upload_bytes: int = 5 * 1024 * 1024
    rate_limit_per_minute: int = 120
    sensitive_rate_limit_per_minute: int = 20

    gemini_api_key: str = Field(default="")
    gemini_model: str = "gemini-2.5-flash"


@lru_cache
def get_settings() -> Settings:
    return Settings()
