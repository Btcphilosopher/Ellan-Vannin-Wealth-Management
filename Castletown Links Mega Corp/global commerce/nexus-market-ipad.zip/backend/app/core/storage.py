from __future__ import annotations

from pathlib import Path
from typing import Protocol

import boto3
from botocore.exceptions import BotoCoreError, ClientError

from app.core.config import get_settings


class ObjectStorageClient(Protocol):
    def put_object(self, key: str, data: bytes, content_type: str) -> str: ...
    def public_url(self, key: str) -> str: ...
    def health_check(self) -> tuple[bool, str]: ...


class LocalAssetStorage:
    """Stores product images and documents locally under /static/media for dev & tests."""

    def __init__(self, root_dir: Path | None = None) -> None:
        self.root_dir = root_dir or (Path(__file__).resolve().parents[2] / "static" / "media")
        self.root_dir.mkdir(parents=True, exist_ok=True)

    def put_object(self, key: str, data: bytes, content_type: str) -> str:
        safe_key = key.lstrip("/").replace("..", "")
        target = self.root_dir / safe_key
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        return self.public_url(safe_key)

    def public_url(self, key: str) -> str:
        safe_key = key.lstrip("/")
        return f"/media/{safe_key}"

    def health_check(self) -> tuple[bool, str]:
        return self.root_dir.exists(), f"local_dir:{self.root_dir}"


class S3ObjectStorage:
    """S3/MinIO object storage adapter with local fallback URL awareness."""

    def __init__(self) -> None:
        settings = get_settings()
        self.bucket = settings.s3_bucket
        self.public_base = settings.s3_public_base_url.rstrip("/")
        self.client = boto3.client(
            "s3",
            endpoint_url=settings.s3_endpoint_url,
            aws_access_key_id=settings.s3_access_key,
            aws_secret_access_key=settings.s3_secret_key,
            region_name=settings.s3_region,
        )

    def put_object(self, key: str, data: bytes, content_type: str) -> str:
        safe_key = key.lstrip("/")
        self.client.put_object(
            Bucket=self.bucket,
            Key=safe_key,
            Body=data,
            ContentType=content_type,
        )
        return self.public_url(safe_key)

    def public_url(self, key: str) -> str:
        return f"{self.public_base}/{key.lstrip('/')}"

    def health_check(self) -> tuple[bool, str]:
        try:
            self.client.head_bucket(Bucket=self.bucket)
            return True, f"s3_bucket:{self.bucket}"
        except (BotoCoreError, ClientError) as exc:
            return False, f"s3_error:{type(exc).__name__}"


def get_object_storage() -> ObjectStorageClient:
    settings = get_settings()
    if settings.object_storage_mode == "s3":
        return S3ObjectStorage()
    return LocalAssetStorage()
