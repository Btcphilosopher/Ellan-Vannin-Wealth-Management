from __future__ import annotations

from fastapi import APIRouter, Depends, Header, HTTPException, Request
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.security import verify_webhook_hmac
from app.services.checkout import reconcile_payment_webhook

router = APIRouter(prefix="/api/v1/webhooks", tags=["webhooks"])


class PaymentWebhookPayload(BaseModel):
    provider_reference: str
    event_status: str  # "succeeded" | "failed"
    failure_reason: str | None = None


@router.post("/payment")
async def handle_payment_webhook(
    request: Request,
    payload: PaymentWebhookPayload,
    x_webhook_signature: str | None = Header(default=None),
    db: AsyncSession = Depends(get_db),
) -> dict:
    raw = await request.body()
    if not verify_webhook_hmac(raw, x_webhook_signature):
        raise HTTPException(status_code=401, detail="Invalid payment webhook HMAC signature.")
    order = await reconcile_payment_webhook(
        db=db,
        provider_reference=payload.provider_reference,
        event_status=payload.event_status,
        failure_reason=payload.failure_reason,
    )
    return {
        "order_id": order.id,
        "order_number": order.order_number,
        "payment_status": order.payment_status,
        "order_status": order.order_status,
    }
