from __future__ import annotations

from fastapi import APIRouter, Depends, Header
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.deps import require_customer_auth
from app.models.commerce import Customer, DeviceSession
from app.schemas.common import (
    CheckoutConfirmRequest,
    CheckoutConfirmResponseDTO,
    CheckoutPreviewRequest,
    CheckoutPreviewResponseDTO,
)
from app.services.checkout import build_checkout_preview, confirm_checkout

router = APIRouter(prefix="/api/v1/checkout", tags=["checkout"])


@router.post("/preview", response_model=CheckoutPreviewResponseDTO)
async def preview_checkout(
    payload: CheckoutPreviewRequest,
    auth: tuple[Customer, DeviceSession] = Depends(require_customer_auth),
    db: AsyncSession = Depends(get_db),
) -> CheckoutPreviewResponseDTO:
    customer, _ = auth
    return await build_checkout_preview(db, customer.id, payload)


@router.post("/confirm", response_model=CheckoutConfirmResponseDTO)
async def confirm_checkout_endpoint(
    payload: CheckoutConfirmRequest,
    idempotency_key: str = Header(..., alias="Idempotency-Key"),
    auth: tuple[Customer, DeviceSession] = Depends(require_customer_auth),
    db: AsyncSession = Depends(get_db),
) -> CheckoutConfirmResponseDTO:
    customer, _ = auth
    return await confirm_checkout(
        db=db,
        customer=customer,
        idempotency_key=idempotency_key,
        payload=payload,
    )
