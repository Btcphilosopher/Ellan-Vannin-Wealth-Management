from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.deps import require_customer_auth
from app.models.commerce import Customer, CustomerPreferences, DeviceSession
from app.schemas.common import AssistantChatRequest, AssistantChatResponseDTO
from app.services.assistant import run_shopping_assistant

router = APIRouter(prefix="/api/v1/assistant", tags=["assistant"])


@router.post("/chat", response_model=AssistantChatResponseDTO)
async def chat_with_assistant(
    payload: AssistantChatRequest,
    auth: tuple[Customer, DeviceSession] = Depends(require_customer_auth),
    db: AsyncSession = Depends(get_db),
) -> AssistantChatResponseDTO:
    customer, _ = auth
    prefs = await db.get(CustomerPreferences, customer.id)
    dest = prefs.destination_country if prefs else "US"
    return await run_shopping_assistant(
        db=db,
        customer_id=customer.id,
        message=payload.message,
        destination_country=dest,
        confirm_action_token=payload.confirm_action_token,
    )
