from __future__ import annotations

from datetime import datetime, timezone

from fastapi import APIRouter, Depends, Query
from sqlalchemy import desc, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.deps import get_optional_auth
from app.models.catalog import Category, Product
from app.models.commerce import Customer, CustomerPreferences, DeviceSession, RecentlyViewed
from app.models.promotion import Promotion
from app.schemas.common import (
    DiscoverResponseDTO,
    PromotionBannerDTO,
    RecommendedCollectionDTO,
)
from app.services.catalog_mapper import (
    category_to_dto,
    load_full_product_query,
    product_to_card_dto,
)

router = APIRouter(prefix="/api/v1/discover", tags=["discover"])


@router.get("", response_model=DiscoverResponseDTO)
async def get_discover(
    destination_country: str | None = Query(default=None, min_length=2, max_length=4),
    destination_postal: str | None = Query(default=None, min_length=2, max_length=24),
    auth: tuple[Customer, DeviceSession] | None = Depends(get_optional_auth),
    db: AsyncSession = Depends(get_db),
) -> DiscoverResponseDTO:
    dest_country = (destination_country or "US").upper()
    dest_postal = destination_postal or "94107"
    customer_id = None
    if auth:
        customer, _ = auth
        customer_id = customer.id
        prefs = await db.get(CustomerPreferences, customer_id)
        if prefs and destination_country is None:
            dest_country = prefs.destination_country
            dest_postal = prefs.destination_postal

    categories = list(
        (await db.execute(select(Category).order_by(Category.sort_order))).scalars().all()
    )

    now = datetime.now(timezone.utc)
    promos = list(
        (
            await db.execute(
                select(Promotion)
                .where(Promotion.is_active.is_(True))
                .order_by(Promotion.stacking_precedence)
            )
        )
        .scalars()
        .all()
    )
    active_banner = None
    for p in promos:
        starts = p.starts_at if p.starts_at.tzinfo else p.starts_at.replace(tzinfo=timezone.utc)
        ends = (
            p.ends_at if (p.ends_at is None or p.ends_at.tzinfo) else p.ends_at.replace(tzinfo=timezone.utc)
        )
        if starts <= now and (ends is None or ends >= now):
            active_banner = PromotionBannerDTO(
                id=p.id,
                code=p.code,
                version=p.version,
                title=p.title,
                description=p.description,
                ends_at=p.ends_at,
            )
            break

    all_products = list(
        (
            await db.execute(
                (await load_full_product_query())
                .where(Product.is_active.is_(True))
                .order_by(Product.featured_rank.asc().nulls_last(), Product.created_at.desc())
            )
        )
        .scalars()
        .unique()
        .all()
    )

    featured = [
        product_to_card_dto(
            p,
            destination_country=dest_country,
            recommendation_reason="Featured catalog selection",
        )
        for p in all_products
        if p.featured_rank is not None
    ][:6]

    recently_viewed_cards = []
    if customer_id:
        rec_rows = (
            await db.execute(
                select(RecentlyViewed)
                .where(RecentlyViewed.customer_id == customer_id)
                .order_by(desc(RecentlyViewed.viewed_at))
                .limit(6)
            )
        ).scalars().all()
        rec_ids = [r.product_id for r in rec_rows]
        by_id = {p.id: p for p in all_products}
        for pid in rec_ids:
            if pid in by_id:
                recently_viewed_cards.append(
                    product_to_card_dto(
                        by_id[pid],
                        destination_country=dest_country,
                        recommendation_reason="Recently viewed on your account",
                    )
                )

    # Explainable rule-based collections
    desk_items = [
        product_to_card_dto(
            p,
            destination_country=dest_country,
            recommendation_reason="Matches Desk & Workspace collection rule",
        )
        for p in all_products
        if p.collection_tag == "desk-essentials"
    ]
    morning_items = [
        product_to_card_dto(
            p,
            destination_country=dest_country,
            recommendation_reason="Grouped by Home & Morning Rituals tag",
        )
        for p in all_products
        if p.collection_tag in {"morning-rituals", "tidy-spaces"}
    ]
    carry_items = [
        product_to_card_dto(
            p,
            destination_country=dest_country,
            recommendation_reason="Grouped by Everyday Carry & Apparel tag",
        )
        for p in all_products
        if p.collection_tag == "everyday-carry"
    ]

    collections = [
        RecommendedCollectionDTO(
            id="col_desk",
            title="Focused Desk & Studio Tools",
            explanation="Explainability rule: items tagged 'desk-essentials' with in-stock variants.",
            products=desk_items,
        ),
        RecommendedCollectionDTO(
            id="col_home",
            title="Calm Morning & Kitchen Homeware",
            explanation="Explainability rule: items tagged 'morning-rituals' or 'tidy-spaces'.",
            products=morning_items,
        ),
        RecommendedCollectionDTO(
            id="col_carry",
            title="Everyday Carry & Heavyweight Basics",
            explanation="Explainability rule: items tagged 'everyday-carry'.",
            products=carry_items,
        ),
    ]

    return DiscoverResponseDTO(
        destination_country=dest_country,
        destination_postal=dest_postal,
        banner=active_banner,
        categories=[category_to_dto(c) for c in categories],
        featured_products=featured,
        recently_viewed=recently_viewed_cards,
        collections=[c for c in collections if c.products],
    )
