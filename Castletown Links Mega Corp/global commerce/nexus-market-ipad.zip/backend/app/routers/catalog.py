from __future__ import annotations

from datetime import datetime, timezone
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import and_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.deps import get_optional_auth
from app.models.catalog import Category, Product, Seller, new_id
from app.models.commerce import Customer, DeviceSession, RecentlyViewed, SavedProduct
from app.schemas.common import CategoryDTO, ProductDetailDTO, SearchResponseDTO, SellerSummaryDTO
from app.services.catalog_mapper import (
    category_to_dto,
    compute_delivery_summary,
    load_full_product_query,
    product_to_card_dto,
    product_to_detail_dto,
    seller_to_dto,
)

router = APIRouter(prefix="/api/v1/catalog", tags=["catalog"])


@router.get("/categories", response_model=list[CategoryDTO])
async def list_categories(db: AsyncSession = Depends(get_db)) -> list[CategoryDTO]:
    cats = (await db.execute(select(Category).order_by(Category.sort_order))).scalars().all()
    return [category_to_dto(c) for c in cats]


@router.get("/sellers", response_model=list[SellerSummaryDTO])
async def list_sellers(db: AsyncSession = Depends(get_db)) -> list[SellerSummaryDTO]:
    sellers = (await db.execute(select(Seller).order_by(Seller.name))).scalars().all()
    return [seller_to_dto(s) for s in sellers]


@router.get("/search", response_model=SearchResponseDTO)
async def search_products(
    q: str = Query(default="", max_length=120),
    category_id: str | None = None,
    seller_id: str | None = None,
    min_price_minor: int | None = Query(default=None, ge=0),
    max_price_minor: int | None = Query(default=None, ge=0),
    attribute_key: str | None = None,
    attribute_value: str | None = None,
    in_stock_only: bool = False,
    eligible_only: bool = False,
    destination_country: str = Query(default="US", min_length=2, max_length=4),
    sort: Literal["relevance", "price_asc", "price_desc", "newest"] = "relevance",
    page: int = Query(default=1, ge=1, le=200),
    page_size: int = Query(default=12, ge=1, le=50),
    db: AsyncSession = Depends(get_db),
) -> SearchResponseDTO:
    stmt = (await load_full_product_query()).where(Product.is_active.is_(True))
    if category_id:
        stmt = stmt.where(Product.category_id == category_id)
    if seller_id:
        stmt = stmt.where(Product.seller_id == seller_id)

    products = list((await db.execute(stmt)).scalars().unique().all())
    query_norm = q.strip().lower()
    dest = destination_country.upper()

    filtered: list[Product] = []
    for prod in products:
        if query_norm:
            haystack = " ".join(
                [
                    prod.title.lower(),
                    prod.subtitle.lower(),
                    prod.description.lower(),
                    prod.seller.name.lower(),
                    prod.category.name.lower(),
                    " ".join(v.sku.lower() + " " + v.title.lower() for v in prod.variants),
                ]
            )
            if not all(tok in haystack for tok in query_norm.split()):
                continue

        active_variants = [v for v in prod.variants if v.is_active]
        if not active_variants:
            continue

        if in_stock_only and not any(v.available_stock > 0 for v in active_variants):
            continue

        if eligible_only and not compute_delivery_summary(prod, dest).eligible_for_destination:
            continue

        if min_price_minor is not None and not any(v.price_minor >= min_price_minor for v in active_variants):
            continue
        if max_price_minor is not None and not any(v.price_minor <= max_price_minor for v in active_variants):
            continue

        if attribute_key and attribute_value:
            k_low = attribute_key.strip().lower()
            v_low = attribute_value.strip().lower()
            matched_attr = any(
                str((v.attributes or {}).get(k, "")).lower() == v_low
                for v in active_variants
                for k in (v.attributes or {})
                if k.lower() == k_low
            )
            if not matched_attr:
                continue

        filtered.append(prod)

    if sort == "price_asc":
        filtered.sort(key=lambda p: min(v.price_minor for v in p.variants))
    elif sort == "price_desc":
        filtered.sort(key=lambda p: min(v.price_minor for v in p.variants), reverse=True)
    elif sort == "newest":
        filtered.sort(key=lambda p: p.created_at, reverse=True)
    else:
        filtered.sort(
            key=lambda p: (
                p.featured_rank if p.featured_rank is not None else 999,
                p.title,
            )
        )

    total = len(filtered)
    start = (page - 1) * page_size
    end = start + page_size
    page_items = [
        product_to_card_dto(p, destination_country=dest)
        for p in filtered[start:end]
    ]

    return SearchResponseDTO(
        items=page_items,
        total=total,
        page=page,
        page_size=page_size,
        has_next=end < total,
    )


@router.get("/products/{product_id}", response_model=ProductDetailDTO)
async def get_product_detail(
    product_id: str,
    destination_country: str = Query(default="US", min_length=2, max_length=4),
    auth: tuple[Customer, DeviceSession] | None = Depends(get_optional_auth),
    db: AsyncSession = Depends(get_db),
) -> ProductDetailDTO:
    stmt = (await load_full_product_query()).where(Product.id == product_id)
    product = (await db.execute(stmt)).scalar_one_or_none()
    if not product or not product.is_active:
        raise HTTPException(status_code=404, detail="Product not found.")

    is_saved = False
    if auth:
        customer, _ = auth
        saved = (
            await db.execute(
                select(SavedProduct).where(
                    and_(
                        SavedProduct.customer_id == customer.id,
                        SavedProduct.product_id == product_id,
                    )
                )
            )
        ).scalar_one_or_none()
        is_saved = saved is not None

        recent = (
            await db.execute(
                select(RecentlyViewed).where(
                    and_(
                        RecentlyViewed.customer_id == customer.id,
                        RecentlyViewed.product_id == product_id,
                    )
                )
            )
        ).scalar_one_or_none()
        if recent:
            recent.viewed_at = datetime.now(timezone.utc)
        else:
            db.add(
                RecentlyViewed(
                    id=new_id("rec"),
                    customer_id=customer.id,
                    product_id=product_id,
                    viewed_at=datetime.now(timezone.utc),
                )
            )
        await db.commit()

    return product_to_detail_dto(
        product,
        destination_country=destination_country.upper(),
        is_saved=is_saved,
    )
