from __future__ import annotations

from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import and_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.deps import require_customer_auth
from app.core.database import get_db
from app.core.security import create_signed_token, hash_password, verify_password
from app.models.catalog import new_id
from app.models.commerce import (
    Customer,
    CustomerAddress,
    CustomerPreferences,
    DeviceSession,
    SavedProduct,
)
from app.schemas.common import (
    AccountSummaryDTO,
    AddressDTO,
    AddressInput,
    AuthLoginRequest,
    AuthRegisterRequest,
    AuthResponseDTO,
    DeviceSessionDTO,
    GuestSessionRequest,
    PreferencesUpdateRequest,
    ProductCardDTO,
)
from app.services.catalog_mapper import load_full_product_query, product_to_card_dto

router = APIRouter(prefix="/api/v1/account", tags=["account"])


async def _issue_session(
    db: AsyncSession,
    customer: Customer,
    device_name: str,
) -> AuthResponseDTO:
    session = DeviceSession(
        id=new_id("ses"),
        customer_id=customer.id,
        device_name=device_name,
        platform="iPadOS",
    )
    db.add(session)
    await db.commit()
    token = create_signed_token(
        customer_id=customer.id,
        device_session_id=session.id,
        is_guest=customer.is_guest,
    )
    return AuthResponseDTO(
        token=token,
        customer_id=customer.id,
        display_name=customer.display_name,
        email=customer.email,
        is_guest=customer.is_guest,
        device_session_id=session.id,
    )


@router.post("/guest", response_model=AuthResponseDTO)
async def create_guest_session(
    payload: GuestSessionRequest,
    db: AsyncSession = Depends(get_db),
) -> AuthResponseDTO:
    customer = Customer(
        id=new_id("cust"),
        email=None,
        password_hash=None,
        display_name="Guest Shopper",
        is_guest=True,
    )
    db.add(customer)
    await db.flush()
    db.add(CustomerPreferences(customer_id=customer.id))
    return await _issue_session(db, customer, payload.device_name)


@router.post("/register", response_model=AuthResponseDTO, status_code=201)
async def register_customer(
    payload: AuthRegisterRequest,
    db: AsyncSession = Depends(get_db),
) -> AuthResponseDTO:
    email_norm = payload.email.strip().lower()
    existing = (
        await db.execute(select(Customer).where(Customer.email == email_norm))
    ).scalar_one_or_none()
    if existing:
        raise HTTPException(status_code=409, detail="Email address is already registered.")

    customer = Customer(
        id=new_id("cust"),
        email=email_norm,
        password_hash=hash_password(payload.password),
        display_name=payload.display_name.strip(),
        is_guest=False,
    )
    db.add(customer)
    await db.flush()
    db.add(CustomerPreferences(customer_id=customer.id))
    return await _issue_session(db, customer, payload.device_name)


@router.post("/login", response_model=AuthResponseDTO)
async def login_customer(
    payload: AuthLoginRequest,
    db: AsyncSession = Depends(get_db),
) -> AuthResponseDTO:
    email_norm = payload.email.strip().lower()
    customer = (
        await db.execute(select(Customer).where(Customer.email == email_norm))
    ).scalar_one_or_none()
    if not customer or not customer.password_hash or not verify_password(payload.password, customer.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password.",
        )
    if customer.deletion_requested_at is not None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Account deletion has been requested for this account.",
        )
    return await _issue_session(db, customer, payload.device_name)


@router.get("/me", response_model=AccountSummaryDTO)
async def get_account_summary(
    auth: tuple[Customer, DeviceSession] = Depends(require_customer_auth),
    db: AsyncSession = Depends(get_db),
) -> AccountSummaryDTO:
    customer, current_session = auth
    prefs = await db.get(CustomerPreferences, customer.id)
    if not prefs:
        prefs = CustomerPreferences(customer_id=customer.id)
        db.add(prefs)
        await db.commit()

    addrs = list(
        (
            await db.execute(
                select(CustomerAddress).where(CustomerAddress.customer_id == customer.id)
            )
        )
        .scalars()
        .all()
    )
    sessions = list(
        (
            await db.execute(
                select(DeviceSession).where(DeviceSession.customer_id == customer.id)
            )
        )
        .scalars()
        .all()
    )

    return AccountSummaryDTO(
        customer_id=customer.id,
        email=customer.email,
        display_name=customer.display_name,
        is_guest=customer.is_guest,
        deletion_requested_at=customer.deletion_requested_at,
        preferences={
            "destination_country": prefs.destination_country,
            "destination_postal": prefs.destination_postal,
            "currency": prefs.currency,
            "order_updates_enabled": prefs.order_updates_enabled,
            "promo_alerts_enabled": prefs.promo_alerts_enabled,
            "price_drop_alerts_enabled": prefs.price_drop_alerts_enabled,
        },
        addresses=[
            AddressDTO(
                id=a.id,
                label=a.label,
                recipient_name=a.recipient_name,
                line1=a.line1,
                line2=a.line2,
                city=a.city,
                region=a.region,
                postal_code=a.postal_code,
                country_code=a.country_code,
                is_default=a.is_default,
            )
            for a in addrs
        ],
        sessions=[
            DeviceSessionDTO(
                id=s.id,
                device_name=s.device_name,
                platform=s.platform,
                last_active_at=s.last_active_at,
                revoked_at=s.revoked_at,
                is_current=(s.id == current_session.id),
            )
            for s in sessions
        ],
    )


@router.patch("/preferences")
async def update_preferences(
    payload: PreferencesUpdateRequest,
    auth: tuple[Customer, DeviceSession] = Depends(require_customer_auth),
    db: AsyncSession = Depends(get_db),
) -> dict:
    customer, _ = auth
    prefs = await db.get(CustomerPreferences, customer.id)
    if not prefs:
        prefs = CustomerPreferences(customer_id=customer.id)
        db.add(prefs)
    for field, value in payload.model_dump(exclude_none=True).items():
        if field in {"destination_country", "currency"} and isinstance(value, str):
            value = value.upper()
        setattr(prefs, field, value)
    await db.commit()
    return {
        "destination_country": prefs.destination_country,
        "destination_postal": prefs.destination_postal,
        "currency": prefs.currency,
        "order_updates_enabled": prefs.order_updates_enabled,
        "promo_alerts_enabled": prefs.promo_alerts_enabled,
        "price_drop_alerts_enabled": prefs.price_drop_alerts_enabled,
    }


@router.post("/addresses", response_model=AddressDTO, status_code=201)
async def add_address(
    payload: AddressInput,
    auth: tuple[Customer, DeviceSession] = Depends(require_customer_auth),
    db: AsyncSession = Depends(get_db),
) -> AddressDTO:
    customer, _ = auth
    if payload.is_default:
        existing = (
            await db.execute(
                select(CustomerAddress).where(CustomerAddress.customer_id == customer.id)
            )
        ).scalars().all()
        for item in existing:
            item.is_default = False

    addr = CustomerAddress(
        id=new_id("addr"),
        customer_id=customer.id,
        **payload.model_dump(),
    )
    db.add(addr)
    await db.commit()
    return AddressDTO(id=addr.id, **payload.model_dump())


@router.delete("/addresses/{address_id}")
async def delete_address(
    address_id: str,
    auth: tuple[Customer, DeviceSession] = Depends(require_customer_auth),
    db: AsyncSession = Depends(get_db),
) -> dict:
    customer, _ = auth
    addr = await db.get(CustomerAddress, address_id)
    if not addr or addr.customer_id != customer.id:
        raise HTTPException(status_code=404, detail="Address not found.")
    await db.delete(addr)
    await db.commit()
    return {"deleted": address_id}


@router.post("/sessions/{session_id}/revoke")
async def revoke_device_session(
    session_id: str,
    auth: tuple[Customer, DeviceSession] = Depends(require_customer_auth),
    db: AsyncSession = Depends(get_db),
) -> dict:
    customer, _ = auth
    ses = await db.get(DeviceSession, session_id)
    if not ses or ses.customer_id != customer.id:
        raise HTTPException(status_code=404, detail="Device session not found.")
    ses.revoked_at = datetime.now(timezone.utc)
    await db.commit()
    return {"revoked": session_id}


@router.post("/deletion-request")
async def request_account_deletion(
    auth: tuple[Customer, DeviceSession] = Depends(require_customer_auth),
    db: AsyncSession = Depends(get_db),
) -> dict:
    customer, _ = auth
    now = datetime.now(timezone.utc)
    customer.deletion_requested_at = now
    sessions = (
        await db.execute(
            select(DeviceSession).where(DeviceSession.customer_id == customer.id)
        )
    ).scalars().all()
    for s in sessions:
        s.revoked_at = now
    await db.commit()
    return {"status": "deletion_requested", "requested_at": now.isoformat()}


@router.get("/saved", response_model=list[ProductCardDTO])
async def list_saved_products(
    auth: tuple[Customer, DeviceSession] = Depends(require_customer_auth),
    db: AsyncSession = Depends(get_db),
) -> list[ProductCardDTO]:
    customer, _ = auth
    prefs = await db.get(CustomerPreferences, customer.id)
    dest = prefs.destination_country if prefs else "US"
    saved_rows = (
        await db.execute(
            select(SavedProduct).where(SavedProduct.customer_id == customer.id)
        )
    ).scalars().all()
    if not saved_rows:
        return []
    product_ids = [r.product_id for r in saved_rows]
    stmt = (await load_full_product_query()).where(Product.id.in_(product_ids))
    products = (await db.execute(stmt)).scalars().unique().all()
    return [product_to_card_dto(p, destination_country=dest) for p in products]


@router.post("/saved/{product_id}")
async def save_product(
    product_id: str,
    preferred_variant_id: str | None = None,
    auth: tuple[Customer, DeviceSession] = Depends(require_customer_auth),
    db: AsyncSession = Depends(get_db),
) -> dict:
    customer, _ = auth
    existing = (
        await db.execute(
            select(SavedProduct).where(
                and_(
                    SavedProduct.customer_id == customer.id,
                    SavedProduct.product_id == product_id,
                )
            )
        )
    ).scalar_one_or_none()
    if not existing:
        db.add(
            SavedProduct(
                id=new_id("sav"),
                customer_id=customer.id,
                product_id=product_id,
                preferred_variant_id=preferred_variant_id,
            )
        )
        await db.commit()
    return {"saved": True, "product_id": product_id}


@router.delete("/saved/{product_id}")
async def unsave_product(
    product_id: str,
    auth: tuple[Customer, DeviceSession] = Depends(require_customer_auth),
    db: AsyncSession = Depends(get_db),
) -> dict:
    customer, _ = auth
    existing = (
        await db.execute(
            select(SavedProduct).where(
                and_(
                    SavedProduct.customer_id == customer.id,
                    SavedProduct.product_id == product_id,
                )
            )
        )
    ).scalar_one_or_none()
    if existing:
        await db.delete(existing)
        await db.commit()
    return {"saved": False, "product_id": product_id}
