from __future__ import annotations

from fastapi import APIRouter, Depends, Query
from sqlalchemy import desc, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.database import get_db
from app.core.deps import require_customer_auth
from app.models.commerce import Customer, DeviceSession
from app.models.orders import Order
from app.schemas.common import (
    CreateReturnRequest,
    OrderDTO,
    ReturnRequestDTO,
    SupportMessageDTO,
    SupportMessageInput,
)
from app.services.orders import (
    add_support_message,
    advance_synthetic_tracking,
    cancel_order_if_eligible,
    create_return_request,
    get_owned_order,
    order_to_dto,
)

router = APIRouter(prefix="/api/v1/orders", tags=["orders"])


@router.get("", response_model=list[OrderDTO])
async def list_orders(
    auth: tuple[Customer, DeviceSession] = Depends(require_customer_auth),
    db: AsyncSession = Depends(get_db),
) -> list[OrderDTO]:
    customer, _ = auth
    rows = (
        await db.execute(
            select(Order)
            .where(Order.customer_id == customer.id)
            .order_by(desc(Order.created_at))
            .options(
                selectinload(Order.items),
                selectinload(Order.fulfillments),
                selectinload(Order.returns),
                selectinload(Order.messages),
            )
        )
    ).scalars().all()
    return [await order_to_dto(db, o) for o in rows]


@router.get("/{order_id}", response_model=OrderDTO)
async def get_order_detail(
    order_id: str,
    auth: tuple[Customer, DeviceSession] = Depends(require_customer_auth),
    db: AsyncSession = Depends(get_db),
) -> OrderDTO:
    customer, _ = auth
    order = await get_owned_order(db, order_id, customer.id)
    return await order_to_dto(db, order)


@router.post("/{order_id}/tracking/advance", response_model=OrderDTO)
async def advance_tracking_demo(
    order_id: str,
    fulfillment_id: str | None = Query(default=None),
    simulate_exception: bool = Query(default=False),
    auth: tuple[Customer, DeviceSession] = Depends(require_customer_auth),
    db: AsyncSession = Depends(get_db),
) -> OrderDTO:
    customer, _ = auth
    order = await get_owned_order(db, order_id, customer.id)
    updated = await advance_synthetic_tracking(
        db,
        order,
        fulfillment_id=fulfillment_id,
        simulate_exception=simulate_exception,
    )
    return await order_to_dto(db, updated)


@router.post("/{order_id}/cancel", response_model=OrderDTO)
async def cancel_order_endpoint(
    order_id: str,
    auth: tuple[Customer, DeviceSession] = Depends(require_customer_auth),
    db: AsyncSession = Depends(get_db),
) -> OrderDTO:
    customer, _ = auth
    order = await get_owned_order(db, order_id, customer.id)
    updated = await cancel_order_if_eligible(db, order)
    return await order_to_dto(db, updated)


@router.post("/{order_id}/returns", response_model=ReturnRequestDTO, status_code=201)
async def request_return_endpoint(
    order_id: str,
    payload: CreateReturnRequest,
    auth: tuple[Customer, DeviceSession] = Depends(require_customer_auth),
    db: AsyncSession = Depends(get_db),
) -> ReturnRequestDTO:
    customer, _ = auth
    order = await get_owned_order(db, order_id, customer.id)
    ret = await create_return_request(db, order, customer.id, payload)
    return ReturnRequestDTO(
        id=ret.id,
        order_id=ret.order_id,
        reason=ret.reason,
        items_json=ret.items_json,
        eligible_amount_minor=ret.eligible_amount_minor,
        requested_amount_minor=ret.requested_amount_minor,
        currency=ret.currency,
        return_status=ret.return_status,
        refund_status=ret.refund_status,
        created_at=ret.created_at,
    )


@router.post("/{order_id}/messages", response_model=SupportMessageDTO, status_code=201)
async def post_support_message(
    order_id: str,
    payload: SupportMessageInput,
    auth: tuple[Customer, DeviceSession] = Depends(require_customer_auth),
    db: AsyncSession = Depends(get_db),
) -> SupportMessageDTO:
    customer, _ = auth
    order = await get_owned_order(db, order_id, customer.id)
    msg = await add_support_message(db, order, customer.id, payload.body)
    return SupportMessageDTO(
        id=msg.id,
        order_id=msg.order_id,
        sender_role=msg.sender_role,
        body=msg.body,
        created_at=msg.created_at,
    )
