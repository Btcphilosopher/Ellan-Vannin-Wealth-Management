from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.core.database import get_db
from app.core.storage import get_object_storage

router = APIRouter(tags=["health"])


@router.get("/health")
async def health_check(db: AsyncSession = Depends(get_db)) -> dict:
    settings = get_settings()
    db_ok = False
    try:
        await db.execute(text("SELECT 1"))
        db_ok = True
    except Exception:
        db_ok = False

    storage_ok, storage_detail = get_object_storage().health_check()
    return {
        "status": "ok" if (db_ok and storage_ok) else "degraded",
        "brand": settings.brand_name,
        "database": "ok" if db_ok else "error",
        "object_storage": storage_detail,
        "ai_mode": "gemini" if bool(settings.gemini_api_key) else "scripted_fallback",
    }
