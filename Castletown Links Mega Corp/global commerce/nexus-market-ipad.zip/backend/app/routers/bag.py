from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import and_, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.database import get_db
from app.core.deps import require_customer_auth
from app.models.catalog import Product, ProductVariant, new_id
from app.models.commerce import BagItem, Customer, CustomerPreferences, DeviceSession
from app.schemas.common import (
    BagAddRequest,
    BagLineDTO,
    BagResponseDTO,
    BagSellerGroupDTO,
    BagUpdateRequest,
)
from app.services.catalog_mapper import (
    compute_delivery_summary,
    primary_image_for_product,
    seller_to_dto,
    variant_to_dto,
)

router = APIRouter(prefix="/api/v1/bag", tags=["bag"])


async def _serialize_bag(
    db: AsyncSession,
    customer_id: str,
    destination_country: str,
) -> BagResponseDTO:
    rows = list(
        (
            await db.execute(
                select(BagItem).where(BagItem.customer_id == customer_id)
            )
        )
        .scalars()
        .all()
    )

    notices: list[str] = []
    has_blocking = False
    active_by_seller: dict[str, tuple[object, list[BagLineDTO]]] = {}
    saved_for_later: list[BagLineDTO] = []

    for row in rows:
        product = (
            await db.execute(
                select(Product)
                .where(Product.id == row.product_id)
                .options(
                    selectinload(Product.seller),
                    selectinload(Product.images),
                    selectinload(Product.variants).selectinload(ProductVariant.price_history),
                )
            )
        ).scalar_one_or_none()
        variant = await db.get(
            ProductVariant,
            row.variant_id,
            options=[selectinload(ProductVariant.price_history)],
        )
        if not product or not variant:
            continue

        price_changed = row.unit_price_snapshot_minor != variant.price_minor
        stock_insufficient = variant.available_stock < row.quantity
        delivery = compute_delivery_summary(product, destination_country)

        notice_parts: list[str] = []
        if price_changed:
            msg = (
                f"Price changed for {product.title} ({variant.title}): "
                f"was ${row.unit_price_snapshot_minor / 100:.2f}, now ${variant.price_minor / 100:.2f}."
            )
            notice_parts.append(msg)
            notices.append(msg)
        if stock_insufficient:
            msg = (
                f"Only {variant.available_stock} left for {product.title} ({variant.title}); "
                f"you have {row.quantity} in your bag."
            )
            notice_parts.append(msg)
            notices.append(msg)
            if row.status == "active":
                has_blocking = True
        if not delivery.eligible_for_destination:
            msg = delivery.restriction_reason or f"{product.title} is restricted for {destination_country}."
            notice_parts.append(msg)
            notices.append(msg)
            if row.status == "active":
                has_blocking = True

        line = BagLineDTO(
            id=row.id,
            product_id=product.id,
            variant_id=variant.id,
            sku=variant.sku,
            product_title=product.title,
            variant_title=variant.title,
            available_variants=[
                variant_to_dto(v)
                for v in sorted(product.variants, key=lambda x: x.price_minor)
                if v.is_active
            ],
            image_url=primary_image_for_product(product, variant.id),
            quantity=row.quantity,
            unit_price_minor=variant.price_minor,
            previous_unit_price_minor=row.unit_price_snapshot_minor,
            line_total_minor=variant.price_minor * row.quantity,
            currency=variant.currency,
            available_stock=variant.available_stock,
            status=row.status,
            price_changed=price_changed,
            stock_insufficient=stock_insufficient,
            notice_message=" ".join(notice_parts) if notice_parts else None,
            eligible_for_destination=delivery.eligible_for_destination,
            restriction_reason=delivery.restriction_reason,
        )

        if row.status == "saved_for_later":
            saved_for_later.append(line)
        else:
            seller = product.seller
            if seller.id not in active_by_seller:
                active_by_seller[seller.id] = (seller, [])
            active_by_seller[seller.id][1].append(line)

    seller_groups: list[BagSellerGroupDTO] = []
    subtotal_minor = 0
    shipping_minor = 0

    for _, (seller, items) in active_by_seller.items():
        s_sub = sum(i.line_total_minor for i in items)
        s_ship = 0 if s_sub >= seller.free_shipping_threshold_minor else seller.base_shipping_minor
        remaining = max(0, seller.free_shipping_threshold_minor - s_sub)
        subtotal_minor += s_sub
        shipping_minor += s_ship
        seller_groups.append(
            BagSellerGroupDTO(
                seller=seller_to_dto(seller),
                items=items,
                subtotal_minor=s_sub,
                estimated_shipping_minor=s_ship,
                free_shipping_remaining_minor=remaining,
            )
        )

    return BagResponseDTO(
        destination_country=destination_country,
        currency="USD",
        seller_groups=seller_groups,
        saved_for_later=saved_for_later,
        subtotal_minor=subtotal_minor,
        estimated_shipping_minor=shipping_minor,
        has_blocking_issues=has_blocking,
        notices=notices,
    )


@router.get("", response_model=BagResponseDTO)
async def get_bag(
    destination_country: str | None = Query(default=None, min_length=2, max_length=4),
    auth: tuple[Customer, DeviceSession] = Depends(require_customer_auth),
    db: AsyncSession = Depends(get_db),
) -> BagResponseDTO:
    customer, _ = auth
    prefs = await db.get(CustomerPreferences, customer.id)
    dest = (destination_country or (prefs.destination_country if prefs else "US")).upper()
    return await _serialize_bag(db, customer.id, dest)


@router.post("/items", response_model=BagResponseDTO)
async def add_to_bag(
    payload: BagAddRequest,
    destination_country: str = Query(default="US", min_length=2, max_length=4),
    auth: tuple[Customer, DeviceSession] = Depends(require_customer_auth),
    db: AsyncSession = Depends(get_db),
) -> BagResponseDTO:
    customer, _ = auth
    variant = await db.get(ProductVariant, payload.variant_id)
    if not variant or variant.product_id != payload.product_id or not variant.is_active:
        raise HTTPException(status_code=404, detail="Selected product variant not found.")

    existing = (
        await db.execute(
            select(BagItem).where(
                and_(
                    BagItem.customer_id == customer.id,
                    BagItem.variant_id == payload.variant_id,
                    BagItem.status == "active",
                )
            )
        )
    ).scalar_one_or_none()

    target_qty = payload.quantity + (existing.quantity if existing else 0)
    if variant.available_stock < target_qty:
        raise HTTPException(
            status_code=409,
            detail=f"Only {variant.available_stock} units available for {variant.title}.",
        )

    if existing:
        existing.quantity = target_qty
        existing.unit_price_snapshot_minor = variant.price_minor
    else:
        db.add(
            BagItem(
                id=new_id("bag"),
                customer_id=customer.id,
                product_id=payload.product_id,
                variant_id=payload.variant_id,
                quantity=payload.quantity,
                status="active",
                unit_price_snapshot_minor=variant.price_minor,
                currency=variant.currency,
            )
        )
    await db.commit()
    return await _serialize_bag(db, customer.id, destination_country.upper())


@router.patch("/items/{item_id}", response_model=BagResponseDTO)
async def update_bag_item(
    item_id: str,
    payload: BagUpdateRequest,
    destination_country: str = Query(default="US", min_length=2, max_length=4),
    auth: tuple[Customer, DeviceSession] = Depends(require_customer_auth),
    db: AsyncSession = Depends(get_db),
) -> BagResponseDTO:
    customer, _ = auth
    item = await db.get(BagItem, item_id)
    if not item or item.customer_id != customer.id:
        raise HTTPException(status_code=404, detail="Bag item not found.")

    new_variant_id = payload.variant_id or item.variant_id
    new_status = payload.status or item.status
    new_qty = payload.quantity if payload.quantity is not None else item.quantity

    variant = await db.get(ProductVariant, new_variant_id)
    if not variant or variant.product_id != item.product_id or not variant.is_active:
        raise HTTPException(status_code=404, detail="Variant not found for this product.")
    if new_status == "active" and variant.available_stock < new_qty:
        raise HTTPException(
            status_code=409,
            detail=f"Only {variant.available_stock} units available for {variant.title}.",
        )

    # Handle merge if switching variant or status collides with an existing row
    collision = (
        await db.execute(
            select(BagItem).where(
                and_(
                    BagItem.customer_id == customer.id,
                    BagItem.variant_id == new_variant_id,
                    BagItem.status == new_status,
                    BagItem.id != item.id,
                )
            )
        )
    ).scalar_one_or_none()

    if collision:
        merged_qty = collision.quantity + new_qty
        if new_status == "active" and variant.available_stock < merged_qty:
            raise HTTPException(
                status_code=409,
                detail=f"Merged quantity ({merged_qty}) exceeds stock ({variant.available_stock}).",
            )
        collision.quantity = merged_qty
        collision.unit_price_snapshot_minor = variant.price_minor
        await db.delete(item)
    else:
        item.variant_id = new_variant_id
        item.status = new_status
        item.quantity = new_qty
        item.unit_price_snapshot_minor = variant.price_minor

    await db.commit()
    return await _serialize_bag(db, customer.id, destination_country.upper())


@router.post("/acknowledge-changes", response_model=BagResponseDTO)
async def acknowledge_price_changes(
    destination_country: str = Query(default="US", min_length=2, max_length=4),
    auth: tuple[Customer, DeviceSession] = Depends(require_customer_auth),
    db: AsyncSession = Depends(get_db),
) -> BagResponseDTO:
    customer, _ = auth
    rows = (
        await db.execute(select(BagItem).where(BagItem.customer_id == customer.id))
    ).scalars().all()
    for row in rows:
        variant = await db.get(ProductVariant, row.variant_id)
        if variant:
            row.unit_price_snapshot_minor = variant.price_minor
    await db.commit()
    return await _serialize_bag(db, customer.id, destination_country.upper())


@router.delete("/items/{item_id}", response_model=BagResponseDTO)
async def remove_bag_item(
    item_id: str,
    destination_country: str = Query(default="US", min_length=2, max_length=4),
    auth: tuple[Customer, DeviceSession] = Depends(require_customer_auth),
    db: AsyncSession = Depends(get_db),
) -> BagResponseDTO:
    customer, _ = auth
    item = await db.get(BagItem, item_id)
    if not item or item.customer_id != customer.id:
        raise HTTPException(status_code=404, detail="Bag item not found.")
    await db.delete(item)
    await db.commit()
    return await _serialize_bag(db, customer.id, destination_country.upper())
