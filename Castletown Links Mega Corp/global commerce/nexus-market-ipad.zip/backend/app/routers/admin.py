from __future__ import annotations

from datetime import datetime, timezone

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from pydantic import BaseModel, Field
from sqlalchemy import desc, select, text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.core.database import get_db
from app.core.deps import require_admin_token
from app.core.security import validate_image_upload
from app.core.storage import get_object_storage
from app.models.catalog import (
    PriceHistory,
    Product,
    ProductImage,
    ProductVariant,
    Seller,
    new_id,
)
from app.models.orders import Order, ReturnRequest
from app.models.promotion import Promotion
from app.services.inventory import release_expired_reservations
from app.services.orders import transition_refund_status

router = APIRouter(
    prefix="/api/v1/admin",
    tags=["admin"],
    dependencies=[Depends(require_admin_token)],
)


class SellerCreateRequest(BaseModel):
    name: str
    slug: str
    support_email: str
    dispatch_city: str
    dispatch_country: str = "US"
    free_shipping_threshold_minor: int = 3500
    base_shipping_minor: int = 499
    return_window_days: int = 30
    return_policy_summary: str


class ProductCreateRequest(BaseModel):
    seller_id: str
    category_id: str
    title: str
    subtitle: str = ""
    description: str
    dimensions_cm: str
    weight_grams: int = Field(gt=0)
    materials: list[str] = Field(default_factory=list)


class VariantCreateRequest(BaseModel):
    product_id: str
    sku: str
    title: str
    attributes: dict[str, str] = Field(default_factory=dict)
    price_minor: int = Field(gt=0)
    stock_on_hand: int = Field(ge=0)


class VariantPriceUpdateRequest(BaseModel):
    price_minor: int = Field(gt=0)
    reason: str = Field(min_length=2, max_length=160)


class VariantInventoryUpdateRequest(BaseModel):
    stock_on_hand: int = Field(ge=0)


class PromotionCreateRequest(BaseModel):
    code: str
    version: int = 1
    title: str
    description: str
    discount_type: str
    discount_value: int = Field(gt=0)
    min_spend_minor: int = Field(ge=0, default=0)
    max_discount_minor: int | None = None
    starts_at: datetime
    ends_at: datetime | None = None
    stacking_precedence: int = 100
    is_stackable: bool = False
    eligible_category_ids: list[str] = Field(default_factory=list)
    excluded_product_ids: list[str] = Field(default_factory=list)


class RefundTransitionRequest(BaseModel):
    next_refund_status: str


@router.get("/integration-health")
async def integration_health(db: AsyncSession = Depends(get_db)) -> dict:
    settings = get_settings()
    db_ok = True
    try:
        await db.execute(text("SELECT 1"))
    except Exception:
        db_ok = False
    storage_ok, storage_info = get_object_storage().health_check()
    return {
        "database": "ok" if db_ok else "error",
        "object_storage_ok": storage_ok,
        "object_storage_detail": storage_info,
        "payment_adapter": "demo_hosted_checkout (stripe/adyen adapter ready)",
        "ai_assistant": "gemini" if bool(settings.gemini_api_key) else "scripted_fallback",
    }


@router.post("/sellers", status_code=201)
async def create_seller(
    payload: SellerCreateRequest,
    db: AsyncSession = Depends(get_db),
) -> dict:
    seller = Seller(id=new_id("sel"), **payload.model_dump())
    db.add(seller)
    await db.commit()
    return {"id": seller.id, "name": seller.name}


@router.post("/products", status_code=201)
async def create_product(
    payload: ProductCreateRequest,
    db: AsyncSession = Depends(get_db),
) -> dict:
    product = Product(id=new_id("prod"), **payload.model_dump())
    db.add(product)
    await db.commit()
    return {"id": product.id, "title": product.title}


@router.post("/variants", status_code=201)
async def create_variant(
    payload: VariantCreateRequest,
    db: AsyncSession = Depends(get_db),
) -> dict:
    variant = ProductVariant(id=new_id("var"), **payload.model_dump())
    db.add(variant)
    await db.flush()
    db.add(
        PriceHistory(
            id=new_id("ph"),
            variant_id=variant.id,
            currency=variant.currency,
            price_minor=variant.price_minor,
            reason="Initial SKU price",
        )
    )
    await db.commit()
    return {"id": variant.id, "sku": variant.sku}


@router.patch("/variants/{variant_id}/price")
async def update_variant_price(
    variant_id: str,
    payload: VariantPriceUpdateRequest,
    db: AsyncSession = Depends(get_db),
) -> dict:
    variant = await db.get(ProductVariant, variant_id)
    if not variant:
        raise HTTPException(status_code=404, detail="Variant not found.")

    old_price = variant.price_minor
    variant.price_minor = payload.price_minor
    db.add(
        PriceHistory(
            id=new_id("ph"),
            variant_id=variant.id,
            currency=variant.currency,
            price_minor=payload.price_minor,
            reason=payload.reason,
        )
    )
    await db.commit()
    return {
        "variant_id": variant.id,
        "previous_price_minor": old_price,
        "new_price_minor": variant.price_minor,
    }


@router.patch("/variants/{variant_id}/inventory")
async def update_variant_inventory(
    variant_id: str,
    payload: VariantInventoryUpdateRequest,
    db: AsyncSession = Depends(get_db),
) -> dict:
    variant = await db.get(ProductVariant, variant_id)
    if not variant:
        raise HTTPException(status_code=404, detail="Variant not found.")
    if payload.stock_on_hand < variant.reserved_stock:
        raise HTTPException(
            status_code=409,
            detail=f"Cannot set stock_on_hand below currently reserved_stock ({variant.reserved_stock}).",
        )
    variant.stock_on_hand = payload.stock_on_hand
    await db.commit()
    return {
        "variant_id": variant.id,
        "stock_on_hand": variant.stock_on_hand,
        "reserved_stock": variant.reserved_stock,
        "available_stock": variant.available_stock,
    }


@router.post("/products/{product_id}/images", status_code=201)
async def upload_product_image(
    product_id: str,
    variant_id: str | None = None,
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
) -> dict:
    product = await db.get(Product, product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Product not found.")
    settings = get_settings()
    raw = await file.read(settings.max_upload_bytes + 1)
    mime = validate_image_upload(file.filename or "upload.png", raw, settings.max_upload_bytes)
    ext = mime.split("/")[-1].replace("jpeg", "jpg")
    key = f"products/{product_id}/{new_id('img')}.{ext}"
    url = get_object_storage().put_object(key, raw, mime)
    img = ProductImage(
        id=new_id("img"),
        product_id=product_id,
        variant_id=variant_id,
        object_key=key,
        url=url,
        alt_text=f"{product.title} uploaded media",
        sort_order=99,
    )
    db.add(img)
    await db.commit()
    return {"id": img.id, "url": img.url}


@router.post("/promotions", status_code=201)
async def create_promotion(
    payload: PromotionCreateRequest,
    db: AsyncSession = Depends(get_db),
) -> dict:
    promo = Promotion(id=new_id("promo"), **payload.model_dump())
    db.add(promo)
    await db.commit()
    return {"id": promo.id, "code": promo.code, "version": promo.version}


@router.get("/orders")
async def list_all_orders(db: AsyncSession = Depends(get_db)) -> list[dict]:
    orders = (
        await db.execute(select(Order).order_by(desc(Order.created_at)).limit(50))
    ).scalars().all()
    return [
        {
            "id": o.id,
            "order_number": o.order_number,
            "customer_id": o.customer_id,
            "order_status": o.order_status,
            "payment_status": o.payment_status,
            "fulfillment_status": o.fulfillment_status,
            "total_minor": o.total_minor,
            "created_at": o.created_at.isoformat(),
        }
        for o in orders
    ]


@router.get("/returns")
async def list_all_returns(db: AsyncSession = Depends(get_db)) -> list[dict]:
    rows = (
        await db.execute(select(ReturnRequest).order_by(desc(ReturnRequest.created_at)).limit(50))
    ).scalars().all()
    return [
        {
            "id": r.id,
            "order_id": r.order_id,
            "requested_amount_minor": r.requested_amount_minor,
            "eligible_amount_minor": r.eligible_amount_minor,
            "return_status": r.return_status,
            "refund_status": r.refund_status,
        }
        for r in rows
    ]


@router.post("/returns/{return_id}/refund-transition")
async def admin_transition_refund(
    return_id: str,
    payload: RefundTransitionRequest,
    db: AsyncSession = Depends(get_db),
) -> dict:
    ret = await transition_refund_status(db, return_id, payload.next_refund_status)
    return {
        "return_id": ret.id,
        "return_status": ret.return_status,
        "refund_status": ret.refund_status,
    }


@router.post("/reservations/release-expired")
async def admin_release_expired(db: AsyncSession = Depends(get_db)) -> dict:
    count = await release_expired_reservations(db)
    await db.commit()
    return {"released_count": count, "checked_at": datetime.now(timezone.utc).isoformat()}
