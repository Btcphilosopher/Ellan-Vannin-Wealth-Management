from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

from app.models.catalog import PriceHistory, Product, ProductVariant, Seller
from app.models.promotion import Promotion


@dataclass(frozen=True)
class PricedLineInput:
    product: Product
    variant: ProductVariant
    seller: Seller
    quantity: int


@dataclass(frozen=True)
class AppliedPromoResult:
    promotion_id: str
    code: str
    version: int
    title: str
    discount_minor: int
    explanation: str


@dataclass(frozen=True)
class QuoteBreakdown:
    currency: str
    subtotal_minor: int
    discount_minor: int
    shipping_minor: int
    tax_minor: int
    total_minor: int
    tax_rate_bps: int
    applied_promotions: list[AppliedPromoResult]
    rejected_promotions: list[dict[str, str]]
    discount_explanation: str
    seller_shipping_minor: dict[str, int]


def verified_reference_price(
    variant: ProductVariant,
    now: datetime | None = None,
) -> tuple[int | None, str | None]:
    """
    Returns a reference price ONLY when backed by an actual PriceHistory record
    within the last 90 days whose recorded price is strictly higher than the current price.
    Prevents invented crossed-out prices.
    """
    current_time = now or datetime.now(timezone.utc)
    cutoff = current_time - timedelta(days=90)

    def _aware(dt: datetime) -> datetime:
        return dt if dt.tzinfo is not None else dt.replace(tzinfo=timezone.utc)

    recent_higher = [
        entry
        for entry in variant.price_history
        if entry.currency == variant.currency
        and _aware(entry.recorded_at) >= cutoff
        and entry.price_minor > variant.price_minor
    ]
    if not recent_higher:
        return None, None
    highest = max(recent_higher, key=lambda e: e.price_minor)
    return highest.price_minor, f"Previous price {highest.recorded_at.date().isoformat()} ({highest.reason})"


def evaluate_promotions_and_totals(
    lines: list[PricedLineInput],
    promotions: list[Promotion],
    requested_codes: list[str],
    delivery_method: str,
    tax_rate_bps: int,
    currency: str = "USD",
    now: datetime | None = None,
) -> QuoteBreakdown:
    current_time = now or datetime.now(timezone.utc)
    subtotal_minor = sum(line.variant.price_minor * line.quantity for line in lines)

    def _aware(dt: datetime) -> datetime:
        return dt if dt.tzinfo is not None else dt.replace(tzinfo=timezone.utc)

    normalized_codes = [c.strip().upper() for c in requested_codes if c.strip()]
    promo_by_code: dict[str, Promotion] = {}
    for promo in promotions:
        existing = promo_by_code.get(promo.code.upper())
        if existing is None or promo.version > existing.version:
            promo_by_code[promo.code.upper()] = promo

    candidates: list[Promotion] = []
    rejected: list[dict[str, str]] = []
    seen_codes: set[str] = set()

    for code in normalized_codes:
        if code in seen_codes:
            continue
        seen_codes.add(code)
        promo = promo_by_code.get(code)
        if not promo or not promo.is_active:
            rejected.append({"code": code, "reason": "Promotion code not found or inactive."})
            continue
        if promo.currency != currency:
            rejected.append({"code": code, "reason": f"Promotion applies to {promo.currency} orders only."})
            continue
        if current_time < _aware(promo.starts_at):
            rejected.append({"code": code, "reason": "Promotion has not started yet."})
            continue
        if promo.ends_at is not None and current_time > _aware(promo.ends_at):
            rejected.append({"code": code, "reason": "Promotion has expired."})
            continue
        candidates.append(promo)

    # Sort by stacking precedence ascending (lower number = higher priority)
    candidates.sort(key=lambda p: (p.stacking_precedence, -p.version, p.code))

    applied: list[AppliedPromoResult] = []
    total_discount_minor = 0
    non_stackable_applied = False

    for promo in candidates:
        if non_stackable_applied and not promo.is_stackable:
            rejected.append({
                "code": promo.code,
                "reason": "Cannot be combined with a higher-precedence exclusive promotion.",
            })
            continue
        if applied and not promo.is_stackable:
            rejected.append({
                "code": promo.code,
                "reason": "Exclusive promotion cannot stack after an already applied promotion.",
            })
            continue

        eligible_subtotal = 0
        for line in lines:
            if line.product.id in (promo.excluded_product_ids or []):
                continue
            if promo.eligible_category_ids and line.product.category_id not in promo.eligible_category_ids:
                continue
            eligible_subtotal += line.variant.price_minor * line.quantity

        if eligible_subtotal == 0:
            rejected.append({"code": promo.code, "reason": "No eligible items in bag for this promotion."})
            continue
        if eligible_subtotal < promo.min_spend_minor:
            needed = (promo.min_spend_minor - eligible_subtotal) / 100
            rejected.append({
                "code": promo.code,
                "reason": f"Requires ${promo.min_spend_minor / 100:.2f} in eligible items (${needed:.2f} more needed).",
            })
            continue

        remaining_cap = max(0, eligible_subtotal - total_discount_minor)
        if remaining_cap == 0:
            rejected.append({"code": promo.code, "reason": "Eligible item subtotal already fully discounted."})
            continue

        if promo.discount_type == "percent_bps":
            raw_discount = (eligible_subtotal * promo.discount_value) // 10_000
            rule_desc = f"{promo.discount_value / 100:.0f}% off eligible subtotal ${eligible_subtotal / 100:.2f}"
        else:
            raw_discount = promo.discount_value
            rule_desc = f"${promo.discount_value / 100:.2f} fixed discount on eligible items"

        if promo.max_discount_minor is not None and raw_discount > promo.max_discount_minor:
            raw_discount = promo.max_discount_minor
            rule_desc += f" (capped at ${promo.max_discount_minor / 100:.2f})"

        applied_discount = min(raw_discount, remaining_cap, subtotal_minor - total_discount_minor)
        if applied_discount <= 0:
            rejected.append({"code": promo.code, "reason": "Discount amount evaluated to zero."})
            continue

        total_discount_minor += applied_discount
        if not promo.is_stackable:
            non_stackable_applied = True
        applied.append(
            AppliedPromoResult(
                promotion_id=promo.id,
                code=promo.code,
                version=promo.version,
                title=promo.title,
                discount_minor=applied_discount,
                explanation=f"{promo.code} (v{promo.version}, precedence {promo.stacking_precedence}): {rule_desc} = -${applied_discount / 100:.2f}",
            )
        )

    # Seller-level shipping calculation
    seller_subtotals: dict[str, int] = {}
    sellers_by_id: dict[str, Seller] = {}
    for line in lines:
        seller_subtotals[line.seller.id] = seller_subtotals.get(line.seller.id, 0) + (
            line.variant.price_minor * line.quantity
        )
        sellers_by_id[line.seller.id] = line.seller

    seller_shipping_minor: dict[str, int] = {}
    for seller_id, s_sub in seller_subtotals.items():
        seller = sellers_by_id[seller_id]
        base = 0 if s_sub >= seller.free_shipping_threshold_minor else seller.base_shipping_minor
        if delivery_method == "express":
            base += 799
        seller_shipping_minor[seller_id] = base

    shipping_minor = sum(seller_shipping_minor.values())
    taxable_minor = max(0, subtotal_minor - total_discount_minor)
    tax_minor = (taxable_minor * tax_rate_bps + 5_000) // 10_000
    total_minor = taxable_minor + shipping_minor + tax_minor

    explanation = (
        " | ".join(item.explanation for item in applied)
        if applied
        else "No promotional discounts applied."
    )

    return QuoteBreakdown(
        currency=currency,
        subtotal_minor=subtotal_minor,
        discount_minor=total_discount_minor,
        shipping_minor=shipping_minor,
        tax_minor=tax_minor,
        total_minor=total_minor,
        tax_rate_bps=tax_rate_bps,
        applied_promotions=applied,
        rejected_promotions=rejected,
        discount_explanation=explanation,
        seller_shipping_minor=seller_shipping_minor,
    )
