from __future__ import annotations

import hashlib
import hmac
import json
import time
from typing import Any

import httpx
from sqlalchemy import desc, or_, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.config import get_settings
from app.models.catalog import Product, ProductVariant, Seller
from app.models.orders import Order
from app.schemas.common import AssistantChatResponseDTO, ProductCardDTO
from app.services.catalog_mapper import (
    compute_delivery_summary,
    load_full_product_query,
    product_to_card_dto,
)


def _sign_confirmation_token(customer_id: str, action: dict[str, Any]) -> str:
    secret = get_settings().session_secret_key.encode("utf-8")
    payload = {
        "cid": customer_id,
        "action": action,
        "exp": int(time.time()) + 300,
    }
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    sig = hmac.new(secret, raw.encode("utf-8"), hashlib.sha256).hexdigest()
    return f"{raw}|{sig}"


async def _tool_find_products(
    db: AsyncSession,
    query_text: str,
    destination_country: str,
    limit: int = 4,
) -> list[Product]:
    stmt = await load_full_product_query()
    tokens = [t.strip().lower() for t in query_text.split() if len(t.strip()) >= 3]
    stmt = stmt.where(Product.is_active.is_(True))
    if tokens:
        filters = []
        for tok in tokens[:4]:
            like = f"%{tok}%"
            filters.append(Product.title.ilike(like))
            filters.append(Product.description.ilike(like))
            filters.append(Product.collection_tag.ilike(like))
        stmt = stmt.where(or_(*filters))
    result = await db.execute(stmt.limit(limit))
    products = list(result.scalars().unique().all())
    if not products:
        fallback_stmt = (await load_full_product_query()).where(Product.is_active.is_(True)).limit(limit)
        products = list((await db.execute(fallback_stmt)).scalars().unique().all())
    return products


async def _tool_lookup_orders(db: AsyncSession, customer_id: str) -> list[dict[str, Any]]:
    result = await db.execute(
        select(Order)
        .where(Order.customer_id == customer_id)
        .order_by(desc(Order.created_at))
        .limit(5)
        .options(selectinload(Order.fulfillments))
    )
    orders = list(result.scalars().all())
    return [
        {
            "order_id": o.id,
            "order_number": o.order_number,
            "order_status": o.order_status,
            "payment_status": o.payment_status,
            "fulfillment_status": o.fulfillment_status,
            "total_formatted": f"${o.total_minor / 100:.2f}",
            "tracking_numbers": [f.tracking_number for f in o.fulfillments],
        }
        for o in orders
    ]


async def run_shopping_assistant(
    db: AsyncSession,
    customer_id: str,
    message: str,
    destination_country: str = "US",
    confirm_action_token: str | None = None,
) -> AssistantChatResponseDTO:
    lower = message.lower()
    products = await _tool_find_products(db, message, destination_country)
    cards: list[ProductCardDTO] = [
        product_to_card_dto(p, destination_country=destination_country)
        for p in products
    ]
    orders = await _tool_lookup_orders(db, customer_id)

    # Enforce explicit confirmation before any mutating suggestion (e.g. adding to bag)
    pending_confirmation = None
    if any(word in lower for word in ["add to bag", "buy ", "place order", "change address"]):
        if not confirm_action_token and cards:
            action = {"type": "add_to_bag", "product_id": cards[0].id}
            pending_confirmation = {
                "summary": f"Confirm adding {cards[0].title} (${cards[0].starting_price_minor / 100:.2f}) to your bag?",
                "confirm_token": _sign_confirmation_token(customer_id, action),
            }

    # Tool-grounded factual context for both Gemini and deterministic fallback
    grounded_context = {
        "destination_country": destination_country,
        "products": [
            {
                "title": p.title,
                "seller": p.seller.name,
                "return_window_days": p.seller.return_window_days,
                "return_policy": p.seller.return_policy_summary,
                "dimensions_cm": p.dimensions_cm,
                "materials": p.materials,
                "delivery": compute_delivery_summary(p, destination_country).model_dump(),
                "variants": [
                    {
                        "title": v.title,
                        "sku": v.sku,
                        "price": f"${v.price_minor / 100:.2f}",
                        "available_stock": v.available_stock,
                    }
                    for v in p.variants
                ],
            }
            for p in products
        ],
        "customer_orders": orders,
    }

    settings = get_settings()
    if settings.gemini_api_key:
        try:
            prompt = (
                "You are a factual shopping assistant for Sunburst Market. "
                "Use ONLY the JSON facts provided below. Never invent specifications, "
                "reviews, discounts, or delivery guarantees. Require explicit customer "
                "confirmation before placing orders or modifying account details.\n\n"
                f"FACTS:\n{json.dumps(grounded_context, indent=2)}\n\n"
                f"CUSTOMER QUESTION: {message}"
            )
            url = (
                f"https://generativelanguage.googleapis.com/v1beta/models/"
                f"{settings.gemini_model}:generateContent?key={settings.gemini_api_key}"
            )
            async with httpx.AsyncClient(timeout=12.0) as client:
                resp = await client.post(
                    url,
                    json={"contents": [{"parts": [{"text": prompt}]}]},
                )
                if resp.status_code == 200:
                    data = resp.json()
                    text = (
                        data.get("candidates", [{}])[0]
                        .get("content", {})
                        .get("parts", [{}])[0]
                        .get("text", "")
                    )
                    if text.strip():
                        return AssistantChatResponseDTO(
                            reply=text.strip(),
                            mode="gemini",
                            referenced_products=cards,
                            referenced_orders=orders if "order" in lower or "track" in lower else [],
                            pending_confirmation=pending_confirmation,
                        )
        except Exception:
            pass  # Fall through safely to deterministic tool-backed script

    # Deterministic scripted fallback (no model credentials needed)
    if any(k in lower for k in ["order", "track", "shipment", "refund"]):
        if not orders:
            reply = "You have no orders on this account yet. Once you complete demo checkout, I can look up order numbers and synthetic tracking updates here."
        else:
            latest = orders[0]
            reply = (
                f"Your most recent order is {latest['order_number']} "
                f"({latest['order_status']}, payment: {latest['payment_status']}, "
                f"fulfillment: {latest['fulfillment_status']}, total: {latest['total_formatted']}). "
                f"Tracking: {', '.join(latest['tracking_numbers'])}."
            )
        return AssistantChatResponseDTO(
            reply=reply,
            mode="scripted_fallback",
            referenced_products=[],
            referenced_orders=orders,
            pending_confirmation=pending_confirmation,
        )

    if any(k in lower for k in ["return", "policy"]):
        lines = [
            f"• {p.title} ({p.seller.name}): {p.seller.return_window_days}-day return window — {p.seller.return_policy_summary}"
            for p in products[:3]
        ]
        reply = "Published seller return terms for matching items:\n" + "\n".join(lines)
    elif any(k in lower for k in ["deliver", "shipping", "arrive"]):
        lines = []
        for p in products[:3]:
            d = compute_delivery_summary(p, destination_country)
            guarantee = f" | {d.guaranteed_by}" if d.guaranteed_by else " | No guaranteed arrival date"
            elig = d.estimated_window if d.eligible_for_destination else (d.restriction_reason or "Restricted")
            lines.append(f"• {p.title}: {elig}{guarantee}")
        reply = f"Delivery information for {destination_country}:\n" + "\n".join(lines)
    elif any(k in lower for k in ["compare", "dimension", "material", "spec"]):
        lines = []
        for p in products[:3]:
            cheapest = min(p.variants, key=lambda v: v.price_minor)
            mats = ", ".join(p.materials or [])
            lines.append(
                f"• {p.title}: ${cheapest.price_minor / 100:.2f}, {p.dimensions_cm}, {p.weight_grams}g, materials: {mats}"
            )
        reply = "Catalogue specification comparison:\n" + "\n".join(lines)
    else:
        lines = [
            f"• {c.title} from ${c.starting_price_minor / 100:.2f} ({c.variant_count} variants, {c.delivery.estimated_window})"
            for c in cards[:3]
        ]
        reply = "Here are matching items from our catalogue:\n" + "\n".join(lines)

    if pending_confirmation:
        reply += "\n\nI prepared a confirmation prompt before modifying your bag."

    return AssistantChatResponseDTO(
        reply=reply,
        mode="scripted_fallback",
        referenced_products=cards,
        referenced_orders=[],
        pending_confirmation=pending_confirmation,
    )
