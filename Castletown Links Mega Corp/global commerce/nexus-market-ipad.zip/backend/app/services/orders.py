from __future__ import annotations

from datetime import datetime, timezone

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.models.catalog import new_id
from app.models.orders import (
    Order,
    OrderItem,
    OrderSellerFulfillment,
    ReturnRequest,
    SupportMessage,
)
from app.schemas.common import (
    CreateReturnRequest,
    OrderDTO,
    OrderFulfillmentDTO,
    OrderItemDTO,
    ReturnRequestDTO,
    SupportMessageDTO,
    TrackingEventDTO,
)
from app.services.inventory import release_reservations_for_order


VALID_REFUND_TRANSITIONS: dict[str, set[str]] = {
    "none": {"refund_approved", "rejected"},
    "refund_approved": {"refund_submitted", "rejected"},
    "refund_submitted": {"refund_confirmed"},
    "refund_confirmed": set(),
    "rejected": set(),
}


async def order_to_dto(db: AsyncSession, order: Order) -> OrderDTO:
    items_by_fulfillment: dict[str, list[OrderItemDTO]] = {}
    for item in order.items:
        items_by_fulfillment.setdefault(item.fulfillment_id, []).append(
            OrderItemDTO(
                id=item.id,
                product_id=item.product_id,
                variant_id=item.variant_id,
                sku=item.sku,
                product_title=item.product_title,
                variant_summary=item.variant_summary,
                image_url=item.image_url,
                currency=item.currency,
                unit_price_minor=item.unit_price_minor,
                quantity=item.quantity,
                line_total_minor=item.line_total_minor,
            )
        )

    fulfillments = [
        OrderFulfillmentDTO(
            id=ful.id,
            seller_id=ful.seller_id,
            seller_name=ful.seller_name,
            status=ful.status,
            carrier_name=ful.carrier_name,
            tracking_number=ful.tracking_number,
            shipping_minor=ful.shipping_minor,
            estimated_window=ful.estimated_window,
            guaranteed_by=ful.guaranteed_by,
            exception_note=ful.exception_note,
            events=[TrackingEventDTO(**ev) for ev in (ful.tracking_events_json or [])],
            items=items_by_fulfillment.get(ful.id, []),
        )
        for ful in order.fulfillments
    ]

    returns = [
        ReturnRequestDTO(
            id=ret.id,
            order_id=ret.order_id,
            reason=ret.reason,
            items_json=list(ret.items_json or []),
            eligible_amount_minor=ret.eligible_amount_minor,
            requested_amount_minor=ret.requested_amount_minor,
            currency=ret.currency,
            return_status=ret.return_status,
            refund_status=ret.refund_status,
            created_at=ret.created_at,
        )
        for ret in sorted(order.returns, key=lambda r: r.created_at, reverse=True)
    ]

    messages = [
        SupportMessageDTO(
            id=msg.id,
            order_id=msg.order_id,
            sender_role=msg.sender_role,
            body=msg.body,
            created_at=msg.created_at,
        )
        for msg in sorted(order.messages, key=lambda m: m.created_at)
    ]

    return OrderDTO(
        id=order.id,
        order_number=order.order_number,
        order_status=order.order_status,
        payment_status=order.payment_status,
        fulfillment_status=order.fulfillment_status,
        currency=order.currency,
        subtotal_minor=order.subtotal_minor,
        discount_minor=order.discount_minor,
        shipping_minor=order.shipping_minor,
        tax_minor=order.tax_minor,
        total_minor=order.total_minor,
        delivery_method=order.delivery_method,
        shipping_address=dict(order.shipping_address_json or {}),
        applied_promotions=list(order.applied_promotions_json or []),
        discount_explanation=order.discount_explanation,
        is_demo_order=order.is_demo_order,
        created_at=order.created_at,
        fulfillments=fulfillments,
        returns=returns,
        support_messages=messages,
    )


async def get_owned_order(db: AsyncSession, order_id: str, customer_id: str) -> Order:
    result = await db.execute(
        select(Order)
        .where(Order.id == order_id)
        .options(
            selectinload(Order.items),
            selectinload(Order.fulfillments),
            selectinload(Order.returns),
            selectinload(Order.messages),
        )
    )
    order = result.scalar_one_or_none()
    if not order or order.customer_id != customer_id:
        raise HTTPException(status_code=404, detail="Order not found.")
    return order


async def advance_synthetic_tracking(
    db: AsyncSession,
    order: Order,
    fulfillment_id: str | None = None,
    simulate_exception: bool = False,
) -> Order:
    targets = [
        ful
        for ful in order.fulfillments
        if fulfillment_id is None or ful.id == fulfillment_id
    ]
    if not targets:
        raise HTTPException(status_code=404, detail="Fulfillment record not found.")

    progression = ["label_created", "in_transit", "out_for_delivery", "delivered"]
    now_iso = datetime.now(timezone.utc).isoformat()

    for ful in targets:
        events = list(ful.tracking_events_json or [])
        if simulate_exception:
            ful.status = "delivery_exception"
            ful.exception_note = "Synthetic weather hold at regional hub — rescheduled for next business day."
            events.append(
                {
                    "timestamp": now_iso,
                    "status": "delivery_exception",
                    "location": "Regional Hub",
                    "detail": ful.exception_note,
                    "is_synthetic": True,
                }
            )
        else:
            if ful.status in progression:
                idx = progression.index(ful.status)
                next_status = progression[min(idx + 1, len(progression) - 1)]
            else:
                next_status = "in_transit"
            ful.status = next_status
            ful.exception_note = None
            detail_map = {
                "label_created": "Synthetic carrier received package data.",
                "in_transit": "Departed origin sorting facility (synthetic event).",
                "out_for_delivery": "With local synthetic courier for delivery today.",
                "delivered": "Delivered to reception/front porch (synthetic event).",
            }
            events.append(
                {
                    "timestamp": now_iso,
                    "status": next_status,
                    "location": "Oakland Distribution Hub" if next_status == "in_transit" else "Destination City",
                    "detail": detail_map[next_status],
                    "is_synthetic": True,
                }
            )
        ful.tracking_events_json = events

    statuses = {f.status for f in order.fulfillments}
    if statuses == {"delivered"}:
        order.fulfillment_status = "delivered"
        order.order_status = "delivered"
    elif "delivered" in statuses:
        order.fulfillment_status = "partially_delivered"
    elif "delivery_exception" in statuses:
        order.fulfillment_status = "exception"
    elif "in_transit" in statuses or "out_for_delivery" in statuses:
        order.fulfillment_status = "in_transit"

    await db.commit()
    return order


async def cancel_order_if_eligible(db: AsyncSession, order: Order) -> Order:
    shipped = any(
        f.status in {"in_transit", "out_for_delivery", "delivered"}
        for f in order.fulfillments
    )
    if shipped:
        raise HTTPException(
            status_code=409,
            detail="Order has already entered transit and cannot be cancelled; request a return instead.",
        )
    if order.order_status == "cancelled":
        return order

    await release_reservations_for_order(db, order.id)
    order.order_status = "cancelled"
    order.fulfillment_status = "cancelled"
    for ful in order.fulfillments:
        ful.status = "cancelled"
    await db.commit()
    return order


async def create_return_request(
    db: AsyncSession,
    order: Order,
    customer_id: str,
    payload: CreateReturnRequest,
) -> ReturnRequest:
    if order.payment_status != "paid":
        raise HTTPException(
            status_code=400,
            detail="Returns are only available for paid orders.",
        )

    items_by_id = {item.id: item for item in order.items}
    already_requested_minor = sum(
        r.requested_amount_minor
        for r in order.returns
        if r.refund_status != "rejected"
    )
    remaining_order_cap = max(0, order.total_minor - already_requested_minor)

    computed_eligible_minor = 0
    normalized_items: list[dict] = []
    for entry in payload.items:
        order_item_id = str(entry.get("order_item_id", ""))
        qty = int(entry.get("quantity", 1))
        order_item = items_by_id.get(order_item_id)
        if not order_item or qty <= 0 or qty > order_item.quantity:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid return item or quantity for {order_item_id}.",
            )
        line_eligible = order_item.unit_price_minor * qty
        computed_eligible_minor += line_eligible
        normalized_items.append(
            {
                "order_item_id": order_item.id,
                "sku": order_item.sku,
                "product_title": order_item.product_title,
                "variant_summary": order_item.variant_summary,
                "quantity": qty,
                "eligible_minor": line_eligible,
            }
        )

    eligible_cap = min(computed_eligible_minor, remaining_order_cap)
    requested = payload.requested_amount_minor or eligible_cap
    if requested > eligible_cap:
        raise HTTPException(
            status_code=400,
            detail=f"Requested refund (${requested / 100:.2f}) exceeds eligible purchased amount (${eligible_cap / 100:.2f}).",
        )

    ret = ReturnRequest(
        id=new_id("ret"),
        order_id=order.id,
        customer_id=customer_id,
        items_json=normalized_items,
        reason=payload.reason,
        eligible_amount_minor=eligible_cap,
        requested_amount_minor=requested,
        currency=order.currency,
        return_status="approved_for_dropoff",
        refund_status="refund_approved",
    )
    db.add(ret)
    await db.commit()
    await db.refresh(ret)
    return ret


async def transition_refund_status(
    db: AsyncSession,
    return_id: str,
    next_refund_status: str,
) -> ReturnRequest:
    ret = await db.get(ReturnRequest, return_id)
    if not ret:
        raise HTTPException(status_code=404, detail="Return request not found.")
    allowed = VALID_REFUND_TRANSITIONS.get(ret.refund_status, set())
    if next_refund_status not in allowed:
        raise HTTPException(
            status_code=409,
            detail=f"Invalid refund transition {ret.refund_status} -> {next_refund_status}.",
        )
    ret.refund_status = next_refund_status
    if next_refund_status == "refund_confirmed":
        ret.return_status = "completed"
    elif next_refund_status == "refund_submitted":
        ret.return_status = "refund_processing"
    elif next_refund_status == "rejected":
        ret.return_status = "rejected"
    await db.commit()
    await db.refresh(ret)
    return ret


async def add_support_message(
    db: AsyncSession,
    order: Order,
    customer_id: str,
    body: str,
    sender_role: str = "customer",
) -> SupportMessage:
    msg = SupportMessage(
        id=new_id("msg"),
        order_id=order.id,
        customer_id=customer_id,
        sender_role=sender_role,
        body=body,
    )
    db.add(msg)
    await db.commit()
    await db.refresh(msg)
    return msg
