from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.models.catalog import (
    Category,
    Product,
    ProductImage,
    ProductVariant,
    Seller,
)
from app.schemas.common import (
    CategoryDTO,
    DeliverySummaryDTO,
    PriceHistoryDTO,
    ProductCardDTO,
    ProductDetailDTO,
    ProductDocumentDTO,
    ProductImageDTO,
    ProductReviewDTO,
    SellerSummaryDTO,
    VariantDTO,
)
from app.services.pricing import verified_reference_price


def seller_to_dto(seller: Seller) -> SellerSummaryDTO:
    return SellerSummaryDTO(
        id=seller.id,
        name=seller.name,
        slug=seller.slug,
        dispatch_city=seller.dispatch_city,
        dispatch_country=seller.dispatch_country,
        free_shipping_threshold_minor=seller.free_shipping_threshold_minor,
        base_shipping_minor=seller.base_shipping_minor,
        return_window_days=seller.return_window_days,
        return_policy_summary=seller.return_policy_summary,
        verified_badge=seller.verified_badge,
    )


def category_to_dto(category: Category) -> CategoryDTO:
    return CategoryDTO(
        id=category.id,
        name=category.name,
        slug=category.slug,
        icon_name=category.icon_name,
        description=category.description,
    )


def compute_delivery_summary(product: Product, destination_country: str) -> DeliverySummaryDTO:
    restrictions = product.shipping_restrictions or {}
    blocked = [c.upper() for c in restrictions.get("blocked_countries", [])]
    allowed = [c.upper() for c in restrictions.get("allowed_countries", [])]
    dest = destination_country.upper()

    eligible = True
    reason = None
    if dest in blocked:
        eligible = False
        reason = restrictions.get("reason") or f"Shipping to {dest} is restricted for this item."
    elif allowed and dest not in allowed:
        eligible = False
        reason = restrictions.get("reason") or f"Ships only to {', '.join(allowed)}."

    est_window = f"{product.estimated_min_days}–{product.estimated_max_days} business days (estimated)"
    guaranteed = (
        f"Guaranteed within {product.guaranteed_by_days} business days"
        if product.guaranteed_by_days is not None and eligible
        else None
    )
    return DeliverySummaryDTO(
        estimated_window=est_window,
        guaranteed_by=guaranteed,
        is_guaranteed=guaranteed is not None,
        eligible_for_destination=eligible,
        restriction_reason=reason,
    )


def variant_to_dto(variant: ProductVariant) -> VariantDTO:
    ref_price, ref_basis = verified_reference_price(variant)
    return VariantDTO(
        id=variant.id,
        sku=variant.sku,
        title=variant.title,
        attributes={str(k): str(v) for k, v in (variant.attributes or {}).items()},
        currency=variant.currency,
        price_minor=variant.price_minor,
        reference_price_minor=ref_price,
        reference_price_basis=ref_basis,
        available_stock=variant.available_stock,
        is_active=variant.is_active,
        price_history=[
            PriceHistoryDTO(
                id=ph.id,
                price_minor=ph.price_minor,
                currency=ph.currency,
                reason=ph.reason,
                recorded_at=ph.recorded_at,
            )
            for ph in variant.price_history
        ],
    )


def primary_image_for_product(product: Product, variant_id: str | None = None) -> str:
    images = sorted(product.images, key=lambda i: i.sort_order)
    if variant_id:
        for img in images:
            if img.variant_id == variant_id:
                return img.url
    if images:
        return images[0].url
    return "/media/placeholder.svg"


def product_to_card_dto(
    product: Product,
    destination_country: str = "US",
    recommendation_reason: str | None = None,
) -> ProductCardDTO:
    active_variants = [v for v in product.variants if v.is_active] or product.variants
    cheapest = min(active_variants, key=lambda v: v.price_minor)
    ref_price, _ = verified_reference_price(cheapest)
    swatches: list[str] = []
    for variant in active_variants:
        color = (variant.attributes or {}).get("color")
        if color and color not in swatches:
            swatches.append(str(color))

    ratings = [r.rating for r in product.reviews]
    avg_rating = round(sum(ratings) / len(ratings), 1) if ratings else None

    return ProductCardDTO(
        id=product.id,
        title=product.title,
        subtitle=product.subtitle,
        category_id=product.category_id,
        category_name=product.category.name,
        seller=seller_to_dto(product.seller),
        primary_image_url=primary_image_for_product(product, cheapest.id),
        starting_price_minor=cheapest.price_minor,
        reference_price_minor=ref_price,
        currency=cheapest.currency,
        variant_count=len(active_variants),
        variant_swatches=swatches[:5],
        in_stock=any(v.available_stock > 0 for v in active_variants),
        delivery=compute_delivery_summary(product, destination_country),
        rating_average=avg_rating,
        review_count=len(ratings),
        recommendation_reason=recommendation_reason,
    )


def product_to_detail_dto(
    product: Product,
    destination_country: str = "US",
    is_saved: bool = False,
) -> ProductDetailDTO:
    variants = [variant_to_dto(v) for v in sorted(product.variants, key=lambda x: x.price_minor)]
    images = [
        ProductImageDTO(
            id=img.id,
            variant_id=img.variant_id,
            url=img.url,
            alt_text=img.alt_text,
            sort_order=img.sort_order,
        )
        for img in sorted(product.images, key=lambda x: x.sort_order)
    ]
    documents = [
        ProductDocumentDTO(
            id=doc.id,
            title=doc.title,
            doc_type=doc.doc_type,
            url=doc.url,
            summary=doc.summary,
        )
        for doc in product.documents
    ]
    reviews = [
        ProductReviewDTO(
            id=rev.id,
            variant_title=rev.variant_title,
            author_display=rev.author_display,
            rating=rev.rating,
            title=rev.title,
            body=rev.body,
            verified_demo_purchase=rev.verified_demo_purchase,
            created_at=rev.created_at,
        )
        for rev in sorted(product.reviews, key=lambda r: r.created_at, reverse=True)
    ]
    ratings = [r.rating for r in reviews]
    avg_rating = round(sum(ratings) / len(ratings), 1) if ratings else None

    return ProductDetailDTO(
        id=product.id,
        title=product.title,
        subtitle=product.subtitle,
        description=product.description,
        category=category_to_dto(product.category),
        seller=seller_to_dto(product.seller),
        dimensions_cm=product.dimensions_cm,
        weight_grams=product.weight_grams,
        materials=list(product.materials or []),
        shipping_restrictions=dict(product.shipping_restrictions or {}),
        delivery=compute_delivery_summary(product, destination_country),
        variants=variants,
        images=images,
        documents=documents,
        reviews=reviews,
        rating_average=avg_rating,
        is_saved=is_saved,
    )


async def load_full_product_query():
    return select(Product).options(
        selectinload(Product.seller),
        selectinload(Product.category),
        selectinload(Product.variants).selectinload(ProductVariant.price_history),
        selectinload(Product.images),
        selectinload(Product.documents),
        selectinload(Product.reviews),
    )
