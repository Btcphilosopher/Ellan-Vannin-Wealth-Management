from __future__ import annotations

from datetime import datetime, timedelta, timezone
import struct
import uuid
import zlib

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.security import hash_password
from app.core.storage import get_object_storage
from app.models.catalog import (
    Category,
    PriceHistory,
    Product,
    ProductDocument,
    ProductImage,
    ProductReview,
    ProductVariant,
    Seller,
)
from app.models.commerce import (
    Customer,
    CustomerAddress,
    CustomerPreferences,
    RecentlyViewed,
    SavedProduct,
)
from app.models.orders import Order, OrderItem, OrderSellerFulfillment, PaymentAttempt
from app.models.promotion import Promotion


def _render_studio_png(
    bg_rgb: tuple[int, int, int],
    accent_rgb: tuple[int, int, int],
    badge_rgb: tuple[int, int, int],
    shape: str = "box",
    size: int = 360,
) -> bytes:
    """
    Generates a valid 24-bit RGB PNG studio product visual using stdlib zlib/struct
    so iPadOS AsyncImage loads every product image natively without external Pillow dependency.
    """
    rows = bytearray()
    cx = cy = size // 2
    r_outer = int(size * 0.28)
    r_inner = int(size * 0.16)

    for y in range(size):
        rows.append(0)  # PNG filter type 0
        row = bytearray()
        # subtle vertical gradient on studio backdrop
        grad = int((y / size) * 18)
        br = max(0, min(255, bg_rgb[0] - grad))
        bg = max(0, min(255, bg_rgb[1] - grad))
        bb = max(0, min(255, bg_rgb[2] - grad))

        for x in range(size):
            dx = x - cx
            dy = y - cy
            dist2 = dx * dx + dy * dy
            in_shape = False
            in_highlight = False

            if shape == "circle":
                in_shape = dist2 <= r_outer * r_outer
                in_highlight = (dx + 18) ** 2 + (dy + 18) ** 2 <= r_inner * r_inner
            elif shape == "pill":
                in_shape = abs(dx) <= int(size * 0.30) and abs(dy) <= int(size * 0.17)
                in_highlight = abs(dx + 14) <= int(size * 0.18) and abs(dy + 10) <= int(size * 0.08)
            else:
                in_shape = abs(dx) <= r_outer and abs(dy) <= r_outer
                in_highlight = abs(dx + 16) <= r_inner and abs(dy + 16) <= r_inner

            if in_highlight:
                row.extend(badge_rgb)
            elif in_shape:
                row.extend(accent_rgb)
            else:
                row.extend((br, bg, bb))
        rows.extend(row)

    def _chunk(tag: bytes, data: bytes) -> bytes:
        return (
            struct.pack(">I", len(data))
            + tag
            + data
            + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)
        )

    ihdr = struct.pack(">IIBBBBB", size, size, 8, 2, 0, 0, 0)
    idat = zlib.compress(bytes(rows), level=6)
    return (
        b"\x89PNG\r\n\x1a\n"
        + _chunk(b"IHDR", ihdr)
        + _chunk(b"IDAT", idat)
        + _chunk(b"IEND", b"")
    )


async def seed_demo_data(db: AsyncSession) -> dict[str, int]:
    existing_prod = (await db.execute(select(Product.id).limit(1))).scalar_one_or_none()
    if existing_prod is not None:
        return {"seeded": 0}

    storage = get_object_storage()
    now = datetime.now(timezone.utc)

    # 1. Categories
    categories = [
        Category(
            id="cat_homeware",
            name="Homeware",
            slug="homeware",
            icon_name="lamp.table.fill",
            description="Ceramics, lighting, organizers, and compact kitchen tools.",
            sort_order=1,
        ),
        Category(
            id="cat_accessories",
            name="Accessories",
            slug="accessories",
            icon_name="bag.fill",
            description="Everyday carry totes, organizers, and travel essentials.",
            sort_order=2,
        ),
        Category(
            id="cat_stationery",
            name="Stationery",
            slug="stationery",
            icon_name="pencil.and.ruler.fill",
            description="Fountain-friendly notebooks, brass pens, and desk trays.",
            sort_order=3,
        ),
        Category(
            id="cat_clothing",
            name="Clothing",
            slug="clothing",
            icon_name="tshirt.fill",
            description="Heavyweight organic cotton tees, fleece layers, and socks.",
            sort_order=4,
        ),
        Category(
            id="cat_electronics",
            name="Small Electronics",
            slug="small-electronics",
            icon_name="bolt.fill",
            description="GaN chargers, mechanical keypads, and desk lamps.",
            sort_order=5,
        ),
    ]
    db.add_all(categories)

    # 2. Sellers
    sellers = [
        Seller(
            id="sel_hearth",
            name="Hearth & Loom Studio",
            slug="hearth-and-loom",
            support_email="support@hearthloom.example",
            dispatch_city="Portland, OR",
            dispatch_country="US",
            free_shipping_threshold_minor=3500,
            base_shipping_minor=499,
            return_window_days=30,
            return_policy_summary="Free 30-day returns in unused original packaging; return shipping covered for damaged items.",
            verified_badge=True,
        ),
        Seller(
            id="sel_kora",
            name="Kora Deskworks",
            slug="kora-deskworks",
            support_email="care@koradesk.example",
            dispatch_city="Austin, TX",
            dispatch_country="US",
            free_shipping_threshold_minor=3000,
            base_shipping_minor=399,
            return_window_days=45,
            return_policy_summary="45-day stationery & desk accessory return window; opened notebooks ineligible unless defective.",
            verified_badge=True,
        ),
        Seller(
            id="sel_verve",
            name="Verve Everyday Goods",
            slug="verve-everyday",
            support_email="hello@vervegoods.example",
            dispatch_city="Chicago, IL",
            dispatch_country="US",
            free_shipping_threshold_minor=4000,
            base_shipping_minor=549,
            return_window_days=30,
            return_policy_summary="30-day apparel & carry returns with tags attached.",
            verified_badge=True,
        ),
        Seller(
            id="sel_solstice",
            name="Solstice MicroTech",
            slug="solstice-microtech",
            support_email="warranty@solsticemt.example",
            dispatch_city="San Jose, CA",
            dispatch_country="US",
            free_shipping_threshold_minor=4500,
            base_shipping_minor=599,
            return_window_days=30,
            return_policy_summary="30-day returns plus 1-year limited replacement warranty on certified power & lighting electronics.",
            verified_badge=True,
        ),
    ]
    db.add_all(sellers)
    await db.flush()

    # 3. Synthetic Catalogue (12 Products across 5 categories)
    catalog_spec = [
        {
            "id": "prod_ceramic_kettle",
            "seller_id": "sel_hearth",
            "category_id": "cat_homeware",
            "title": "Matte Stoneware Pour-Over Kettle",
            "subtitle": "Precision gooseneck spout with insulated walnut handle",
            "description": "Crafted from thermal-shock-resistant stoneware and 304 stainless inner liner for steady pour-over coffee extraction.",
            "collection_tag": "morning-rituals",
            "featured_rank": 1,
            "dimensions_cm": "24 x 13 x 16 cm",
            "weight_grams": 740,
            "materials": ["Glazed Stoneware", "304 Stainless Steel", "Oiled Walnut"],
            "shipping_restrictions": {"blocked_countries": [], "reason": None},
            "est_min": 3,
            "est_max": 5,
            "guaranteed_days": 6,
            "shape": "circle",
            "palette": ((250, 244, 238), (224, 98, 42), (255, 198, 150)),
            "variants": [
                ("var_kettle_terracotta", "HLS-KTL-TER", "Terracotta / 800ml", {"color": "Terracotta", "capacity": "800ml"}, 2890, 3490, 18),
                ("var_kettle_charcoal", "HLS-KTL-CHR", "Charcoal / 800ml", {"color": "Charcoal", "capacity": "800ml"}, 2990, None, 12),
                ("var_kettle_oat", "HLS-KTL-OAT", "Warm Oat / 1.0L", {"color": "Warm Oat", "capacity": "1.0L"}, 3290, None, 9),
            ],
            "review": ("Terracotta / 800ml", "Elena M.", 5, "Balanced pour without wrist strain", "Handle stays cool and the flow rate is easy to control for single-cup pours."),
        },
        {
            "id": "prod_modular_tray",
            "seller_id": "sel_hearth",
            "category_id": "cat_homeware",
            "title": "Stackable Bamboo Drawer Organizer Set",
            "subtitle": "6-piece interlocking kitchen & vanity trays",
            "description": "FSC-certified Moso bamboo organizer bins with non-slip cork pads underneath.",
            "collection_tag": "tidy-spaces",
            "featured_rank": 2,
            "dimensions_cm": "38 x 28 x 6 cm",
            "weight_grams": 920,
            "materials": ["Moso Bamboo", "Natural Cork"],
            "shipping_restrictions": {"blocked_countries": [], "reason": None},
            "est_min": 2,
            "est_max": 4,
            "guaranteed_days": 5,
            "shape": "box",
            "palette": ((246, 244, 236), (191, 146, 92), (242, 224, 194)),
            "variants": [
                ("var_tray_natural", "HLS-TRY-NAT", "Natural Bamboo (6-Pack)", {"color": "Natural", "pack": "6-Pack"}, 1950, 2450, 24),
                ("var_tray_espresso", "HLS-TRY-ESP", "Smoked Espresso (6-Pack)", {"color": "Espresso", "pack": "6-Pack"}, 2150, None, 14),
            ],
            "review": ("Natural Bamboo (6-Pack)", "Marcus T.", 4, "Clean fit for shallow drawers", "Cork feet keep the trays from sliding when closing the drawer."),
        },
        {
            "id": "prod_linen_throw",
            "seller_id": "sel_hearth",
            "category_id": "cat_homeware",
            "title": "Washed Cotton-Linen Waffle Throw",
            "subtitle": "Breathable 420 GSM textured blanket",
            "description": "Stone-washed cotton and European flax weave designed for year-round sofa or bed layering.",
            "collection_tag": "morning-rituals",
            "featured_rank": 5,
            "dimensions_cm": "150 x 200 cm",
            "weight_grams": 1150,
            "materials": ["70% Combed Cotton", "30% European Flax"],
            "shipping_restrictions": {"blocked_countries": [], "reason": None},
            "est_min": 4,
            "est_max": 7,
            "guaranteed_days": None,
            "shape": "box",
            "palette": ((245, 243, 240), (217, 119, 66), (252, 222, 198)),
            "variants": [
                ("var_throw_amber", "HLS-THW-AMB", "Amber Clay / Standard", {"color": "Amber", "size": "150x200cm"}, 3400, 3990, 11),
                ("var_throw_slate", "HLS-THW-SLT", "Slate Mist / Standard", {"color": "Slate", "size": "150x200cm"}, 3400, None, 16),
            ],
            "review": None,
        },
        {
            "id": "prod_brass_pen",
            "seller_id": "sel_kora",
            "category_id": "cat_stationery",
            "title": "Machined Brass Rollerball Pen",
            "subtitle": "Refillable 0.5mm ceramic roller with knurled grip",
            "description": "Solid C36000 brass barrel weighted for relaxed note-taking, compatible with standard Euro rollerball refills.",
            "collection_tag": "desk-essentials",
            "featured_rank": 3,
            "dimensions_cm": "13.8 x 1.0 x 1.0 cm",
            "weight_grams": 46,
            "materials": ["Solid C36000 Brass", "Stainless Clip"],
            "shipping_restrictions": {"blocked_countries": [], "reason": None},
            "est_min": 2,
            "est_max": 4,
            "guaranteed_days": 5,
            "shape": "pill",
            "palette": ((248, 246, 240), (196, 152, 62), (249, 232, 180)),
            "variants": [
                ("var_pen_raw", "KOR-PEN-RAW", "Raw Brushed Brass / 0.5mm", {"color": "Brass", "tip": "0.5mm"}, 2200, 2600, 32),
                ("var_pen_matte", "KOR-PEN-BLK", "PVD Matte Black / 0.5mm", {"color": "Matte Black", "tip": "0.5mm"}, 2450, None, 15),
            ],
            "review": ("Raw Brushed Brass / 0.5mm", "Nadia K.", 5, "Zero ink skipping", "Feels substantial in hand and takes standard refills without wobble."),
        },
        {
            "id": "prod_dot_notebook",
            "seller_id": "sel_kora",
            "category_id": "cat_stationery",
            "title": "Lay-Flat 120gsm Dot Grid Notebook",
            "subtitle": "Thread-sewn 192 numbered pages with index",
            "description": "Acid-free 120gsm ivory paper that resists fountain pen bleed-through, bound in tactile bookcloth.",
            "collection_tag": "desk-essentials",
            "featured_rank": None,
            "dimensions_cm": "21.0 x 14.8 x 1.8 cm",
            "weight_grams": 380,
            "materials": ["120gsm FSC Paper", "Linen Bookcloth"],
            "shipping_restrictions": {"blocked_countries": [], "reason": None},
            "est_min": 2,
            "est_max": 5,
            "guaranteed_days": 6,
            "shape": "box",
            "palette": ((243, 246, 248), (242, 108, 44), (255, 224, 200)),
            "variants": [
                ("var_nb_persimmon", "KOR-NB-PER", "Persimmon A5 / Dot Grid", {"color": "Persimmon", "size": "A5"}, 1450, None, 40),
                ("var_nb_ink", "KOR-NB-INK", "Deep Charcoal A5 / Dot Grid", {"color": "Charcoal", "size": "A5"}, 1450, None, 28),
                ("var_nb_sage_b5", "KOR-NB-SGB5", "Sage B5 / Ruled", {"color": "Sage", "size": "B5"}, 1850, None, 12),
            ],
            "review": ("Persimmon A5 / Dot Grid", "Devon R.", 5, "Handles broad nibs cleanly", "No ghosting even with wet ink; opens completely flat on a desk."),
        },
        {
            "id": "prod_felt_desk_mat",
            "seller_id": "sel_kora",
            "category_id": "cat_stationery",
            "title": "Merino Wool & Cork Desk Mat",
            "subtitle": "Acoustic desk pad for keyboards and iPad stands",
            "description": "4mm dense wool felt laminated to Portuguese cork backing for warm wrist support.",
            "collection_tag": "desk-essentials",
            "featured_rank": None,
            "dimensions_cm": "80 x 35 x 0.4 cm",
            "weight_grams": 460,
            "materials": ["Merino Wool Felt", "Natural Cork"],
            "shipping_restrictions": {"blocked_countries": [], "reason": None},
            "est_min": 3,
            "est_max": 6,
            "guaranteed_days": None,
            "shape": "pill",
            "palette": ((242, 242, 244), (92, 98, 108), (218, 220, 226)),
            "variants": [
                ("var_mat_heather", "KOR-MAT-HTH", "Heather Gray / 80x35cm", {"color": "Heather Gray", "size": "80x35cm"}, 2690, 3190, 19),
                ("var_mat_onyx", "KOR-MAT-ONX", "Charcoal Onyx / 90x40cm", {"color": "Onyx", "size": "90x40cm"}, 3190, None, 8),
            ],
            "review": None,
        },
        {
            "id": "prod_canvas_tote",
            "seller_id": "sel_verve",
            "category_id": "cat_accessories",
            "title": "16oz Waxed Canvas Commuter Tote",
            "subtitle": "Padded 13-inch tablet sleeve & magnetic closure",
            "description": "Water-resistant dry-waxed cotton canvas with six interior pockets and reinforced webbing straps.",
            "collection_tag": "everyday-carry",
            "featured_rank": 4,
            "dimensions_cm": "38 x 31 x 13 cm",
            "weight_grams": 620,
            "materials": ["16oz Waxed Cotton Canvas", "Recycled Nylon Liner"],
            "shipping_restrictions": {"blocked_countries": [], "reason": None},
            "est_min": 3,
            "est_max": 5,
            "guaranteed_days": 6,
            "shape": "box",
            "palette": ((248, 244, 240), (235, 94, 38), (255, 214, 184)),
            "variants": [
                ("var_tote_rust", "VRV-TOT-RST", "Burnt Sienna / Medium", {"color": "Sienna", "size": "Medium"}, 3650, 4200, 16),
                ("var_tote_olive", "VRV-TOT-OLV", "Field Olive / Medium", {"color": "Olive", "size": "Medium"}, 3650, None, 21),
                ("var_tote_black", "VRV-TOT-BLK", "Graphite Black / Large", {"color": "Graphite", "size": "Large"}, 4150, None, 5),
            ],
            "review": ("Burnt Sienna / Medium", "Priya S.", 5, "Fits iPad Pro + notebook effortlessly", "Stands upright on its own and the padded sleeve fits an iPad with Magic Keyboard."),
        },
        {
            "id": "prod_tech_pouch",
            "seller_id": "sel_verve",
            "category_id": "cat_accessories",
            "title": "Accordion Cable & Adapter Pouch",
            "subtitle": "Weather-sealed YKK zipper with elastic loops",
            "description": "Compact flat-opening organizer for chargers, SSDs, Apple Pencil, and travel adapters.",
            "collection_tag": "everyday-carry",
            "featured_rank": None,
            "dimensions_cm": "22 x 13 x 7 cm",
            "weight_grams": 195,
            "materials": ["Recycled Ripstop Nylon", "Microfleece Divider"],
            "shipping_restrictions": {"blocked_countries": [], "reason": None},
            "est_min": 2,
            "est_max": 4,
            "guaranteed_days": 5,
            "shape": "pill",
            "palette": ((240, 244, 248), (52, 62, 74), (255, 130, 56)),
            "variants": [
                ("var_pouch_slate", "VRV-PCH-SLT", "Slate / Orange Trim", {"color": "Slate"}, 1890, None, 26),
                ("var_pouch_sand", "VRV-PCH-SND", "Sandstone", {"color": "Sandstone"}, 1890, None, 14),
            ],
            "review": None,
        },
        {
            "id": "prod_heavy_tee",
            "seller_id": "sel_verve",
            "category_id": "cat_clothing",
            "title": "280gsm Organic Cotton Boxy Tee",
            "subtitle": "Pre-shrunk combed ring-spun jersey",
            "description": "Structured heavyweight everyday tee with reinforced double-needle collar.",
            "collection_tag": "everyday-carry",
            "featured_rank": 6,
            "dimensions_cm": "Apparel Folded 30 x 24 x 3 cm",
            "weight_grams": 310,
            "materials": ["100% Organic Ring-Spun Cotton"],
            "shipping_restrictions": {"blocked_countries": [], "reason": None},
            "est_min": 3,
            "est_max": 6,
            "guaranteed_days": None,
            "shape": "box",
            "palette": ((246, 246, 248), (44, 48, 56), (255, 118, 48)),
            "variants": [
                ("var_tee_chalk_m", "VRV-TEE-CHK-M", "Chalk White / Size M", {"color": "Chalk", "size": "M"}, 1690, 2100, 22),
                ("var_tee_chalk_l", "VRV-TEE-CHK-L", "Chalk White / Size L", {"color": "Chalk", "size": "L"}, 1690, None, 17),
                ("var_tee_charcoal_m", "VRV-TEE-CHR-M", "Charcoal / Size M", {"color": "Charcoal", "size": "M"}, 1690, None, 3),
                ("var_tee_tangerine_s", "VRV-TEE-TAN-S", "Tangerine / Size S", {"color": "Tangerine", "size": "S"}, 1750, None, 0),
            ],
            "review": ("Chalk White / Size M", "Liam C.", 4, "Thick fabric with great drape", "Collar keeps its shape after multiple washes."),
        },
        {
            "id": "prod_merino_crew",
            "seller_id": "sel_verve",
            "category_id": "cat_clothing",
            "title": "Midweight Merino Lounge Crewneck",
            "subtitle": "Temperature-regulating 19.5-micron wool blend",
            "description": "Soft brushed interior knit designed for travel and layered studio comfort.",
            "collection_tag": "morning-rituals",
            "featured_rank": None,
            "dimensions_cm": "Apparel Folded 34 x 27 x 5 cm",
            "weight_grams": 490,
            "materials": ["65% Merino Wool", "35% Tencel Lyocell"],
            "shipping_restrictions": {"blocked_countries": [], "reason": None},
            "est_min": 4,
            "est_max": 7,
            "guaranteed_days": None,
            "shape": "box",
            "palette": ((244, 242, 246), (112, 84, 72), (235, 208, 192)),
            "variants": [
                ("var_crew_espresso_m", "VRV-CRW-ESP-M", "Espresso / Size M", {"color": "Espresso", "size": "M"}, 4400, None, 9),
                ("var_crew_oat_l", "VRV-CRW-OAT-L", "Oatmeal / Size L", {"color": "Oatmeal", "size": "L"}, 4400, None, 11),
            ],
            "review": None,
        },
        {
            "id": "prod_gan_charger",
            "seller_id": "sel_solstice",
            "category_id": "cat_electronics",
            "title": "65W Dual-Port GaN USB-C Charger",
            "subtitle": "Foldable US prongs with braided 2m USB-C cable",
            "description": "Compact gallium-nitride power brick delivering 65W single-port or 45W+20W split PD 3.0 output for iPad and Mac.",
            "collection_tag": "desk-essentials",
            "featured_rank": 7,
            "dimensions_cm": "5.2 x 5.2 x 2.9 cm",
            "weight_grams": 128,
            "materials": ["Flame-Retardant Polycarbonate", "GaN Power Stage"],
            "shipping_restrictions": {
                "allowed_countries": ["US", "CA"],
                "blocked_countries": ["GB", "EU", "AU"],
                "reason": "US Type-A foldable plug certified for North America (US/CA) voltage & outlet standards only.",
            },
            "est_min": 2,
            "est_max": 4,
            "guaranteed_days": 4,
            "shape": "pill",
            "palette": ((240, 244, 250), (255, 107, 0), (255, 215, 175)),
            "variants": [
                ("var_gan_white", "SOL-GAN-WHT", "Matte White / US Plug", {"color": "White", "plug": "US Type-A"}, 2590, 3290, 25),
                ("var_gan_charcoal", "SOL-GAN-CHR", "Charcoal / US Plug", {"color": "Charcoal", "plug": "US Type-A"}, 2690, None, 19),
            ],
            "review": ("Matte White / US Plug", "Hannah W.", 5, "Runs cool under 65W load", "Charges an iPad Pro and phone simultaneously without coil whine."),
        },
        {
            "id": "prod_clip_lamp",
            "seller_id": "sel_solstice",
            "category_id": "cat_electronics",
            "title": "USB-C Aluminum Task Light Bar",
            "subtitle": "Stepless 2700K–5500K dimming with CRI 95+ LEDs",
            "description": "Asymmetric glare-free desk and monitor light bar powered via USB-C with magnetic dimmer puck.",
            "collection_tag": "tidy-spaces",
            "featured_rank": 8,
            "dimensions_cm": "44 x 2.4 x 2.4 cm",
            "weight_grams": 390,
            "materials": ["Anodized 6061 Aluminum", "Optical Polycarbonate"],
            "shipping_restrictions": {"blocked_countries": [], "reason": None},
            "est_min": 3,
            "est_max": 5,
            "guaranteed_days": 6,
            "shape": "pill",
            "palette": ((238, 240, 244), (36, 40, 48), (255, 174, 66)),
            "variants": [
                ("var_lamp_silver", "SOL-LMP-SLV", "Silver Aluminum", {"color": "Silver"}, 3250, 3850, 14),
                ("var_lamp_black", "SOL-LMP-BLK", "Space Charcoal", {"color": "Charcoal"}, 3350, None, 10),
            ],
            "review": None,
        },
    ]

    for item in catalog_spec:
        product = Product(
            id=item["id"],
            seller_id=item["seller_id"],
            category_id=item["category_id"],
            title=item["title"],
            subtitle=item["subtitle"],
            description=item["description"],
            collection_tag=item["collection_tag"],
            featured_rank=item["featured_rank"],
            dimensions_cm=item["dimensions_cm"],
            weight_grams=item["weight_grams"],
            materials=item["materials"],
            shipping_restrictions=item["shipping_restrictions"],
            estimated_min_days=item["est_min"],
            estimated_max_days=item["est_max"],
            guaranteed_by_days=item["guaranteed_days"],
            is_active=True,
        )
        db.add(product)
        await db.flush()

        # Upload crisp PNG product artwork to configured object storage
        bg, accent, badge = item["palette"]
        main_png = _render_studio_png(bg, accent, badge, shape=item["shape"])
        main_key = f"products/{item['id']}/main.png"
        main_url = storage.put_object(main_key, main_png, "image/png")
        db.add(
            ProductImage(
                id=f"img_{item['id']}_0",
                product_id=item["id"],
                variant_id=None,
                object_key=main_key,
                url=main_url,
                alt_text=f"{item['title']} studio product photo",
                sort_order=0,
            )
        )

        # Variants + variant-specific images + price history
        for idx, (v_id, sku, v_title, attrs, price_minor, ref_price_minor, stock) in enumerate(item["variants"]):
            variant = ProductVariant(
                id=v_id,
                product_id=item["id"],
                sku=sku,
                title=v_title,
                attributes=attrs,
                currency="USD",
                price_minor=price_minor,
                stock_on_hand=stock,
                reserved_stock=0,
                is_active=True,
            )
            db.add(variant)
            await db.flush()

            # Variant-specific tinted thumbnail
            shift = (idx * 24) % 70
            v_accent = (max(20, accent[0] - shift), min(240, accent[1] + shift // 2), min(240, accent[2] + shift))
            v_png = _render_studio_png(bg, v_accent, badge, shape=item["shape"])
            v_key = f"products/{item['id']}/{v_id}.png"
            v_url = storage.put_object(v_key, v_png, "image/png")
            db.add(
                ProductImage(
                    id=f"img_{v_id}",
                    product_id=item["id"],
                    variant_id=v_id,
                    object_key=v_key,
                    url=v_url,
                    alt_text=f"{item['title']} - {v_title}",
                    sort_order=idx + 1,
                )
            )

            # Price history record supporting reference price ONLY when configured
            if ref_price_minor is not None:
                db.add(
                    PriceHistory(
                        id=f"ph_{v_id}_prev",
                        variant_id=v_id,
                        currency="USD",
                        price_minor=ref_price_minor,
                        reason="Standard catalog price (30-day record)",
                        recorded_at=now - timedelta(days=18),
                    )
                )
            db.add(
                PriceHistory(
                    id=f"ph_{v_id}_curr",
                    variant_id=v_id,
                    currency="USD",
                    price_minor=price_minor,
                    reason="Current catalog price",
                    recorded_at=now - timedelta(days=2),
                )
            )

        # Product documentation
        doc_key = f"docs/{item['id']}_spec.txt"
        doc_bytes = (
            f"{item['title']}\nDimensions: {item['dimensions_cm']}\n"
            f"Weight: {item['weight_grams']}g\nMaterials: {', '.join(item['materials'])}\n"
        ).encode("utf-8")
        doc_url = storage.put_object(doc_key, doc_bytes, "text/plain")
        db.add(
            ProductDocument(
                id=f"doc_{item['id']}",
                product_id=item["id"],
                title="Product Specifications & Care Sheet",
                doc_type="spec_sheet",
                url=doc_url,
                summary=f"Dimensions {item['dimensions_cm']}, weight {item['weight_grams']}g, materials: {', '.join(item['materials'])}.",
            )
        )

        # Demonstration review ONLY where explicitly defined
        if item["review"] is not None:
            v_title, author, rating, r_title, r_body = item["review"]
            db.add(
                ProductReview(
                    id=f"rev_{item['id']}",
                    product_id=item["id"],
                    variant_title=v_title,
                    author_display=author,
                    rating=rating,
                    title=r_title,
                    body=r_body,
                    verified_demo_purchase=True,
                    created_at=now - timedelta(days=9),
                )
            )

    # 4. Versioned Promotions
    promotions = [
        Promotion(
            id="promo_welcome15_v1",
            code="WELCOME15",
            version=1,
            title="15% Off Orders $25+",
            description="Save 15% (up to $20) on eligible items when spending $25 or more.",
            discount_type="percent_bps",
            discount_value=1500,
            currency="USD",
            min_spend_minor=2500,
            max_discount_minor=2000,
            starts_at=now - timedelta(days=10),
            ends_at=now + timedelta(days=30),
            stacking_precedence=10,
            is_stackable=True,
            eligible_category_ids=[],
            excluded_product_ids=["prod_gan_charger"],
            is_active=True,
        ),
        Promotion(
            id="promo_desk10_v1",
            code="DESK10",
            version=1,
            title="$10 Off Stationery ($30+)",
            description="Stackable $10 savings on Stationery orders over $30.",
            discount_type="fixed_minor",
            discount_value=1000,
            currency="USD",
            min_spend_minor=3000,
            max_discount_minor=1000,
            starts_at=now - timedelta(days=5),
            ends_at=now + timedelta(days=14),
            stacking_precedence=20,
            is_stackable=True,
            eligible_category_ids=["cat_stationery"],
            excluded_product_ids=[],
            is_active=True,
        ),
        Promotion(
            id="promo_home20_v2",
            code="HOME20",
            version=2,
            title="20% Off Homeware Event",
            description="Exclusive 20% discount (max $25) on Homeware orders $35+. Non-stackable.",
            discount_type="percent_bps",
            discount_value=2000,
            currency="USD",
            min_spend_minor=3500,
            max_discount_minor=2500,
            starts_at=now - timedelta(days=1),
            ends_at=now + timedelta(hours=36),
            stacking_precedence=5,
            is_stackable=False,
            eligible_category_ids=["cat_homeware"],
            excluded_product_ids=[],
            is_active=True,
        ),
    ]
    db.add_all(promotions)

    # 5. Demo Customer Account + Address + Preferences + Historical Order
    demo_customer = Customer(
        id="cust_demo",
        email="demo@sunburst.example",
        password_hash=hash_password("SunburstDemo2026!"),
        display_name="Alex Rivera",
        is_guest=False,
    )
    db.add(demo_customer)
    await db.flush()

    db.add(
        CustomerPreferences(
            customer_id="cust_demo",
            destination_country="US",
            destination_postal="94107",
            currency="USD",
            order_updates_enabled=True,
            promo_alerts_enabled=False,
            price_drop_alerts_enabled=True,
        )
    )
    db.add(
        CustomerAddress(
            id="addr_demo_home",
            customer_id="cust_demo",
            label="Home Studio",
            recipient_name="Alex Rivera",
            line1="742 Market Street",
            line2="Suite 4B",
            city="San Francisco",
            region="CA",
            postal_code="94107",
            country_code="US",
            is_default=True,
        )
    )
    db.add_all(
        [
            SavedProduct(
                id="sav_demo_1",
                customer_id="cust_demo",
                product_id="prod_ceramic_kettle",
                preferred_variant_id="var_kettle_terracotta",
            ),
            SavedProduct(
                id="sav_demo_2",
                customer_id="cust_demo",
                product_id="prod_canvas_tote",
                preferred_variant_id="var_tote_rust",
            ),
            RecentlyViewed(
                id="rec_demo_1",
                customer_id="cust_demo",
                product_id="prod_brass_pen",
                viewed_at=now - timedelta(hours=3),
            ),
            RecentlyViewed(
                id="rec_demo_2",
                customer_id="cust_demo",
                product_id="prod_gan_charger",
                viewed_at=now - timedelta(hours=1),
            ),
        ]
    )

    # Historical sample order so Order History & Tracking are populated on first launch
    hist_order_id = "ord_demo_history"
    db.add(
        Order(
            id=hist_order_id,
            order_number="SM-DEMO1042",
            customer_id="cust_demo",
            order_status="confirmed",
            payment_status="paid",
            fulfillment_status="in_transit",
            currency="USD",
            subtotal_minor=3650,
            discount_minor=547,
            shipping_minor=499,
            tax_minor=256,
            total_minor=3858,
            delivery_method="standard",
            shipping_address_json={
                "label": "Home Studio",
                "recipient_name": "Alex Rivera",
                "line1": "742 Market Street",
                "line2": "Suite 4B",
                "city": "San Francisco",
                "region": "CA",
                "postal_code": "94107",
                "country_code": "US",
            },
            applied_promotions_json=[
                {
                    "id": "promo_welcome15_v1",
                    "code": "WELCOME15",
                    "version": 1,
                    "title": "15% Off Orders $25+",
                    "discount_minor": 547,
                    "explanation": "WELCOME15 (v1, precedence 10): 15% off eligible subtotal $36.50 = -$5.47",
                }
            ],
            discount_explanation="WELCOME15 (v1, precedence 10): 15% off eligible subtotal $36.50 = -$5.47",
            idempotency_key="seed-demo-order-1042",
            is_demo_order=True,
            created_at=now - timedelta(days=2),
        )
    )
    await db.flush()

    hist_ful_id = "ful_demo_history"
    db.add(
        OrderSellerFulfillment(
            id=hist_ful_id,
            order_id=hist_order_id,
            seller_id="sel_verve",
            seller_name="Verve Everyday Goods",
            status="in_transit",
            carrier_name="Sunburst Parcel (Synthetic)",
            tracking_number="SYN-DEMO88421A",
            shipping_minor=499,
            estimated_window="3–5 business days (estimated)",
            guaranteed_by="Guaranteed within 6 business days",
            tracking_events_json=[
                {
                    "timestamp": (now - timedelta(days=2)).isoformat(),
                    "status": "label_created",
                    "location": "Chicago, IL",
                    "detail": "Demo payment settled. Synthetic carrier shipping label created.",
                    "is_synthetic": True,
                },
                {
                    "timestamp": (now - timedelta(days=1)).isoformat(),
                    "status": "in_transit",
                    "location": "Denver Distribution Hub",
                    "detail": "Departed regional sorting facility (synthetic event).",
                    "is_synthetic": True,
                },
            ],
        )
    )
    await db.flush()

    db.add(
        OrderItem(
            id="oi_demo_history",
            order_id=hist_order_id,
            fulfillment_id=hist_ful_id,
            seller_id="sel_verve",
            product_id="prod_canvas_tote",
            variant_id="var_tote_rust",
            sku="VRV-TOT-RST",
            product_title="16oz Waxed Canvas Commuter Tote",
            variant_summary="Burnt Sienna / Medium",
            image_url=storage.public_url("products/prod_canvas_tote/var_tote_rust.png"),
            currency="USD",
            unit_price_minor=3650,
            quantity=1,
            line_total_minor=3650,
        )
    )
    db.add(
        PaymentAttempt(
            id="pay_demo_history",
            order_id=hist_order_id,
            provider="demo_hosted_checkout",
            provider_reference="demo_pay_seed_1042",
            status="succeeded",
            amount_minor=3858,
            currency="USD",
            idempotency_key="seed-demo-order-1042",
        )
    )

    await db.commit()
    return {"seeded": len(catalog_spec)}
