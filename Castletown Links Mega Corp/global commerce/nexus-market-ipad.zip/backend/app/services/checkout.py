from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
from typing import Protocol
import uuid

from fastapi import HTTPException, status
from sqlalchemy import and_, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.config import get_settings
from app.models.catalog import Product, ProductVariant, Seller, new_id
from app.models.commerce import BagItem, Customer
from app.models.orders import (
    IdempotencyRecord,
    Order,
    OrderItem,
    OrderSellerFulfillment,
    PaymentAttempt,
)
from app.models.promotion import Promotion, PromotionUsage
from app.schemas.common import (
    AppliedPromotionDTO,
    CheckoutConfirmRequest,
    CheckoutConfirmResponseDTO,
    CheckoutPreviewRequest,
    CheckoutPreviewResponseDTO,
    CheckoutSellerSummaryDTO,
)
from app.services.catalog_mapper import compute_delivery_summary, primary_image_for_product
from app.services.inventory import (
    consume_reservations_for_order,
    release_reservations_for_order,
    reserve_variants_atomically,
)
from app.services.orders import order_to_dto
from app.services.pricing import PricedLineInput, evaluate_promotions_and_totals


@dataclass
class PaymentProviderResult:
    provider: str
    provider_reference: str
    status: str  # "succeeded", "failed", "uncertain"
    failure_reason: str | None = None


class PaymentProviderAdapter(Protocol):
    """Adapter boundary for hosted payment providers (Stripe/Adyen/etc.)."""

    async def authorize_demo_session(
        self,
        order_id: str,
        amount_minor: int,
        currency: str,
        simulation_outcome: str,
    ) -> PaymentProviderResult: ...


class DemoHostedPaymentAdapter:
    """
    Demo checkout provider. Never accepts raw card numbers.
    Supports deterministic simulation outcomes: success, failed, uncertain_timeout.
    """

    async def authorize_demo_session(
        self,
        order_id: str,
        amount_minor: int,
        currency: str,
        simulation_outcome: str,
    ) -> PaymentProviderResult:
        ref = f"demo_pay_{uuid.uuid4().hex[:14]}"
        if simulation_outcome == "failed":
            return PaymentProviderResult(
                provider="demo_hosted_checkout",
                provider_reference=ref,
                status="failed",
                failure_reason="Simulated issuer decline (Demo Checkout — no real card charged).",
            )
        if simulation_outcome == "uncertain_timeout":
            return PaymentProviderResult(
                provider="demo_hosted_checkout",
                provider_reference=ref,
                status="uncertain",
                failure_reason="Simulated network timeout awaiting payment webhook reconciliation.",
            )
        return PaymentProviderResult(
            provider="demo_hosted_checkout",
            provider_reference=ref,
            status="succeeded",
        )


async def _load_active_bag_lines(
    db: AsyncSession,
    customer_id: str,
    destination_country: str,
) -> tuple[list[BagItem], list[PricedLineInput], list[str]]:
    result = await db.execute(
        select(BagItem).where(
            and_(BagItem.customer_id == customer_id, BagItem.status == "active")
        )
    )
    bag_items = list(result.scalars().all())
    if not bag_items:
        raise HTTPException(status_code=400, detail="Your shopping bag is empty.")

    lines: list[PricedLineInput] = []
    notices: list[str] = []
    for item in bag_items:
        product = (
            await db.execute(
                select(Product)
                .where(Product.id == item.product_id)
                .options(
                    selectinload(Product.seller),
                    selectinload(Product.images),
                    selectinload(Product.variants),
                )
            )
        ).scalar_one_or_none()
        variant = await db.get(ProductVariant, item.variant_id)
        if not product or not variant or not product.is_active or not variant.is_active:
            raise HTTPException(
                status_code=409,
                detail="One or more items in your bag are no longer available.",
            )
        if item.unit_price_snapshot_minor != variant.price_minor:
            notices.append(
                f"Price updated for {product.title} ({variant.title}): "
                f"${item.unit_price_snapshot_minor / 100:.2f} -> ${variant.price_minor / 100:.2f}."
            )
            item.unit_price_snapshot_minor = variant.price_minor
        delivery = compute_delivery_summary(product, destination_country)
        if not delivery.eligible_for_destination:
            raise HTTPException(
                status_code=400,
                detail=delivery.restriction_reason
                or f"{product.title} cannot be shipped to {destination_country}.",
            )
        if variant.available_stock < item.quantity:
            raise HTTPException(
                status_code=409,
                detail=f"Insufficient stock for {product.title} ({variant.title}). "
                f"Available: {variant.available_stock}, requested: {item.quantity}.",
            )
        lines.append(
            PricedLineInput(
                product=product,
                variant=variant,
                seller=product.seller,
                quantity=item.quantity,
            )
        )
    return bag_items, lines, notices


async def build_checkout_preview(
    db: AsyncSession,
    customer_id: str,
    payload: CheckoutPreviewRequest,
) -> CheckoutPreviewResponseDTO:
    settings = get_settings()
    _, lines, notices = await _load_active_bag_lines(
        db, customer_id, payload.address.country_code
    )
    promos = list((await db.execute(select(Promotion))).scalars().all())
    quote = evaluate_promotions_and_totals(
        lines=lines,
        promotions=promos,
        requested_codes=payload.promo_codes,
        delivery_method=payload.delivery_method,
        tax_rate_bps=settings.default_tax_rate_bps,
        currency=settings.default_currency,
    )

    by_seller: dict[str, list[PricedLineInput]] = {}
    for line in lines:
        by_seller.setdefault(line.seller.id, []).append(line)

    seller_breakdowns: list[CheckoutSellerSummaryDTO] = []
    for seller_id, seller_lines in by_seller.items():
        seller = seller_lines[0].seller
        s_sub = sum(l.variant.price_minor * l.quantity for l in seller_lines)
        min_days = max(l.product.estimated_min_days for l in seller_lines)
        max_days = max(l.product.estimated_max_days for l in seller_lines)
        if payload.delivery_method == "express":
            min_days = max(1, min_days - 2)
            max_days = max(2, max_days - 2)
        g_days = [
            l.product.guaranteed_by_days
            for l in seller_lines
            if l.product.guaranteed_by_days is not None
        ]
        seller_breakdowns.append(
            CheckoutSellerSummaryDTO(
                seller_id=seller_id,
                seller_name=seller.name,
                subtotal_minor=s_sub,
                shipping_minor=quote.seller_shipping_minor[seller_id],
                estimated_window=f"{min_days}–{max_days} business days (estimated)",
                guaranteed_by=(
                    f"Guaranteed within {max(g_days)} business days"
                    if g_days and len(g_days) == len(seller_lines)
                    else None
                ),
                item_count=sum(l.quantity for l in seller_lines),
            )
        )

    return CheckoutPreviewResponseDTO(
        currency=quote.currency,
        subtotal_minor=quote.subtotal_minor,
        discount_minor=quote.discount_minor,
        shipping_minor=quote.shipping_minor,
        tax_minor=quote.tax_minor,
        total_minor=quote.total_minor,
        tax_rate_bps=quote.tax_rate_bps,
        applied_promotions=[
            AppliedPromotionDTO(
                id=p.promotion_id,
                code=p.code,
                version=p.version,
                title=p.title,
                discount_minor=p.discount_minor,
                explanation=p.explanation,
            )
            for p in quote.applied_promotions
        ],
        rejected_promotions=quote.rejected_promotions,
        discount_explanation=quote.discount_explanation,
        seller_breakdowns=seller_breakdowns,
        is_demo_checkout=True,
        notices=notices,
    )


def _hash_request(payload: CheckoutConfirmRequest) -> str:
    canonical = json.dumps(payload.model_dump(mode="json"), sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


async def confirm_checkout(
    db: AsyncSession,
    customer: Customer,
    idempotency_key: str,
    payload: CheckoutConfirmRequest,
    payment_adapter: PaymentProviderAdapter | None = None,
) -> CheckoutConfirmResponseDTO:
    if not idempotency_key or len(idempotency_key) < 6:
        raise HTTPException(
            status_code=400,
            detail="Idempotency-Key header (min 6 chars) is required for checkout confirmation.",
        )

    req_hash = _hash_request(payload)
    existing_idem = (
        await db.execute(
            select(IdempotencyRecord).where(
                and_(
                    IdempotencyRecord.scope == "checkout_confirm",
                    IdempotencyRecord.customer_id == customer.id,
                    IdempotencyRecord.key == idempotency_key,
                )
            )
        )
    ).scalar_one_or_none()
    if existing_idem:
        if existing_idem.request_hash != req_hash:
            raise HTTPException(
                status_code=409,
                detail="Idempotency-Key was already used with a different checkout payload.",
            )
        cached = dict(existing_idem.response_body)
        cached["replayed_from_idempotency"] = True
        return CheckoutConfirmResponseDTO.model_validate(cached)

    settings = get_settings()
    bag_items, lines, _ = await _load_active_bag_lines(
        db, customer.id, payload.address.country_code
    )
    promos = list((await db.execute(select(Promotion))).scalars().all())
    quote = evaluate_promotions_and_totals(
        lines=lines,
        promotions=promos,
        requested_codes=payload.promo_codes,
        delivery_method=payload.delivery_method,
        tax_rate_bps=settings.default_tax_rate_bps,
        currency=settings.default_currency,
    )

    order_id = new_id("ord")
    order_number = f"SM-{uuid.uuid4().hex[:8].upper()}"
    order = Order(
        id=order_id,
        order_number=order_number,
        customer_id=customer.id,
        order_status="pending_payment",
        payment_status="pending",
        fulfillment_status="unfulfilled",
        currency=quote.currency,
        subtotal_minor=quote.subtotal_minor,
        discount_minor=quote.discount_minor,
        shipping_minor=quote.shipping_minor,
        tax_minor=quote.tax_minor,
        total_minor=quote.total_minor,
        delivery_method=payload.delivery_method,
        shipping_address_json=payload.address.model_dump(mode="json"),
        applied_promotions_json=[
            {
                "id": p.promotion_id,
                "code": p.code,
                "version": p.version,
                "title": p.title,
                "discount_minor": p.discount_minor,
                "explanation": p.explanation,
            }
            for p in quote.applied_promotions
        ],
        discount_explanation=quote.discount_explanation,
        idempotency_key=idempotency_key,
        is_demo_order=True,
    )
    db.add(order)
    await db.flush()

    # Reserve inventory atomically BEFORE payment simulation
    await reserve_variants_atomically(
        db=db,
        order_id=order_id,
        requested_items=[(line.variant.id, line.quantity) for line in lines],
        ttl_seconds=settings.reservation_ttl_seconds,
    )

    by_seller: dict[str, list[PricedLineInput]] = {}
    for line in lines:
        by_seller.setdefault(line.seller.id, []).append(line)

    now_iso = datetime.now(timezone.utc).isoformat()
    for seller_id, seller_lines in by_seller.items():
        seller = seller_lines[0].seller
        min_days = max(l.product.estimated_min_days for l in seller_lines)
        max_days = max(l.product.estimated_max_days for l in seller_lines)
        if payload.delivery_method == "express":
            min_days = max(1, min_days - 2)
            max_days = max(2, max_days - 2)
        g_days = [
            l.product.guaranteed_by_days
            for l in seller_lines
            if l.product.guaranteed_by_days is not None
        ]
        fulfillment = OrderSellerFulfillment(
            id=new_id("ful"),
            order_id=order_id,
            seller_id=seller_id,
            seller_name=seller.name,
            status="awaiting_payment",
            carrier_name="Sunburst Parcel (Synthetic)",
            tracking_number=f"SYN-{uuid.uuid4().hex[:10].upper()}",
            shipping_minor=quote.seller_shipping_minor[seller_id],
            estimated_window=f"{min_days}–{max_days} business days (estimated)",
            guaranteed_by=(
                f"Guaranteed within {max(g_days)} business days"
                if g_days and len(g_days) == len(seller_lines)
                else None
            ),
            tracking_events_json=[
                {
                    "timestamp": now_iso,
                    "status": "order_created",
                    "location": seller.dispatch_city,
                    "detail": "Order recorded; awaiting payment confirmation.",
                    "is_synthetic": True,
                }
            ],
        )
        db.add(fulfillment)
        await db.flush()

        for line in seller_lines:
            db.add(
                OrderItem(
                    id=new_id("oi"),
                    order_id=order_id,
                    fulfillment_id=fulfillment.id,
                    seller_id=seller_id,
                    product_id=line.product.id,
                    variant_id=line.variant.id,
                    sku=line.variant.sku,
                    product_title=line.product.title,
                    variant_summary=line.variant.title,
                    image_url=primary_image_for_product(line.product, line.variant.id),
                    currency=line.variant.currency,
                    unit_price_minor=line.variant.price_minor,
                    quantity=line.quantity,
                    line_total_minor=line.variant.price_minor * line.quantity,
                )
            )

    adapter = payment_adapter or DemoHostedPaymentAdapter()
    payment_result = await adapter.authorize_demo_session(
        order_id=order_id,
        amount_minor=quote.total_minor,
        currency=quote.currency,
        simulation_outcome=payload.simulation_outcome,
    )
    attempt = PaymentAttempt(
        id=new_id("pay"),
        order_id=order_id,
        provider=payment_result.provider,
        provider_reference=payment_result.provider_reference,
        status=payment_result.status,
        amount_minor=quote.total_minor,
        currency=quote.currency,
        failure_reason=payment_result.failure_reason,
        idempotency_key=idempotency_key,
    )
    db.add(attempt)

    if payment_result.status == "succeeded":
        await apply_payment_succeeded(db, order, quote.applied_promotions, customer.id)
        for item in bag_items:
            await db.delete(item)
        msg = "Demo payment confirmed. Order is confirmed and inventory committed."
    elif payment_result.status == "failed":
        order.payment_status = "failed"
        order.order_status = "payment_failed"
        await release_reservations_for_order(db, order_id)
        msg = payment_result.failure_reason or "Demo payment failed; inventory reservation released."
    else:
        # uncertain timeout: keep reservation active until TTL or webhook reconciliation
        order.payment_status = "uncertain"
        order.order_status = "awaiting_reconciliation"
        msg = "Payment response uncertain; inventory temporarily held pending webhook reconciliation."

    await db.flush()
    full_order = await _reload_order(db, order_id)
    order_dto = await order_to_dto(db, full_order)
    response_dto = CheckoutConfirmResponseDTO(
        order=order_dto,
        payment_status=order.payment_status,
        provider_reference=payment_result.provider_reference,
        replayed_from_idempotency=False,
        message=msg,
    )

    db.add(
        IdempotencyRecord(
            id=new_id("idem"),
            scope="checkout_confirm",
            customer_id=customer.id,
            key=idempotency_key,
            request_hash=req_hash,
            response_status=200,
            response_body=response_dto.model_dump(mode="json"),
        )
    )
    await db.commit()
    return response_dto


async def apply_payment_succeeded(
    db: AsyncSession,
    order: Order,
    applied_promos: list | None = None,
    customer_id: str | None = None,
) -> None:
    if order.payment_status == "paid":
        return
    await consume_reservations_for_order(db, order.id)
    order.payment_status = "paid"
    order.order_status = "confirmed"
    order.fulfillment_status = "processing"

    ful_result = await db.execute(
        select(OrderSellerFulfillment).where(OrderSellerFulfillment.order_id == order.id)
    )
    now_iso = datetime.now(timezone.utc).isoformat()
    for ful in ful_result.scalars().all():
        ful.status = "label_created"
        events = list(ful.tracking_events_json or [])
        events.append(
            {
                "timestamp": now_iso,
                "status": "label_created",
                "location": ful.seller_name,
                "detail": "Demo payment settled. Synthetic carrier shipping label created.",
                "is_synthetic": True,
            }
        )
        ful.tracking_events_json = events

    if applied_promos and customer_id:
        for promo in applied_promos:
            db.add(
                PromotionUsage(
                    id=new_id("pu"),
                    promotion_id=promo.promotion_id,
                    promotion_version=promo.version,
                    customer_id=customer_id,
                    order_id=order.id,
                    discount_applied_minor=promo.discount_minor,
                )
            )


async def reconcile_payment_webhook(
    db: AsyncSession,
    provider_reference: str,
    event_status: str,
    failure_reason: str | None = None,
) -> Order:
    """
    Server-verified payment webhook reconciliation.
    Orders are NEVER marked paid from a client redirect alone.
    """
    attempt = (
        await db.execute(
            select(PaymentAttempt).where(PaymentAttempt.provider_reference == provider_reference)
        )
    ).scalar_one_or_none()
    if not attempt:
        raise HTTPException(status_code=404, detail="Payment reference not found.")

    order = await _reload_order(db, attempt.order_id)
    if event_status == "succeeded":
        if attempt.status != "succeeded":
            attempt.status = "succeeded"
            await apply_payment_succeeded(db, order)
    elif event_status == "failed":
        if attempt.status != "succeeded":
            attempt.status = "failed"
            attempt.failure_reason = failure_reason or "Webhook reported payment failure."
            order.payment_status = "failed"
            order.order_status = "payment_failed"
            await release_reservations_for_order(db, order.id)
    else:
        raise HTTPException(status_code=400, detail="Unsupported webhook event status.")

    await db.commit()
    return await _reload_order(db, order.id)


async def _reload_order(db: AsyncSession, order_id: str) -> Order:
    result = await db.execute(
        select(Order)
        .where(Order.id == order_id)
        .options(
            selectinload(Order.items),
            selectinload(Order.fulfillments),
            selectinload(Order.returns),
            selectinload(Order.messages),
            selectinload(Order.payments),
        )
    )
    order = result.scalar_one_or_none()
    if not order:
        raise HTTPException(status_code=404, detail="Order not found.")
    return order
