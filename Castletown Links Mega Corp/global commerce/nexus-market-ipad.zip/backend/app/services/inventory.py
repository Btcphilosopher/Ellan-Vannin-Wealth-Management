from __future__ import annotations

from datetime import datetime, timedelta, timezone

from fastapi import HTTPException, status
from sqlalchemy import and_, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.catalog import ProductVariant, new_id
from app.models.orders import InventoryReservation, Order


async def release_expired_reservations(db: AsyncSession, now: datetime | None = None) -> int:
    """
    Reclaims inventory from expired pending reservations so stuck/abandoned checkouts
    cannot permanently lock stock.
    """
    current_time = now or datetime.now(timezone.utc)
    result = await db.execute(
        select(InventoryReservation).where(
            and_(
                InventoryReservation.status == "active",
                InventoryReservation.expires_at <= current_time,
            )
        )
    )
    expired = list(result.scalars().all())
    for res in expired:
        res.status = "expired"
        await db.execute(
            update(ProductVariant)
            .where(ProductVariant.id == res.variant_id)
            .values(
                reserved_stock=ProductVariant.reserved_stock - res.quantity
            )
        )
        order = await db.get(Order, res.order_id)
        if order and order.payment_status in {"pending", "uncertain"}:
            order.payment_status = "expired"
            order.order_status = "expired"
    return len(expired)


async def reserve_variants_atomically(
    db: AsyncSession,
    order_id: str,
    requested_items: list[tuple[str, int]],
    ttl_seconds: int,
) -> list[InventoryReservation]:
    """
    Atomically reserves stock across all requested variants.
    Uses conditional UPDATE (stock_on_hand - reserved_stock >= qty) to prevent overselling
    even under concurrent checkout requests on both PostgreSQL and SQLite.
    """
    await release_expired_reservations(db)
    expires_at = datetime.now(timezone.utc) + timedelta(seconds=ttl_seconds)
    reservations: list[InventoryReservation] = []

    # Sort variant IDs deterministically to eliminate lock-order deadlocks
    for variant_id, qty in sorted(requested_items, key=lambda pair: pair[0]):
        if qty <= 0:
            raise HTTPException(status_code=400, detail="Quantity must be positive.")

        stmt = (
            update(ProductVariant)
            .where(
                and_(
                    ProductVariant.id == variant_id,
                    ProductVariant.is_active.is_(True),
                    (ProductVariant.stock_on_hand - ProductVariant.reserved_stock) >= qty,
                )
            )
            .values(reserved_stock=ProductVariant.reserved_stock + qty)
        )
        result = await db.execute(stmt)
        if result.rowcount != 1:
            variant = await db.get(ProductVariant, variant_id)
            available = variant.available_stock if variant else 0
            title = variant.title if variant else variant_id
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=f"Insufficient stock for {title}. Requested {qty}, available {available}.",
            )

        reservation = InventoryReservation(
            id=new_id("res"),
            order_id=order_id,
            variant_id=variant_id,
            quantity=qty,
            status="active",
            expires_at=expires_at,
        )
        db.add(reservation)
        reservations.append(reservation)

    return reservations


async def consume_reservations_for_order(db: AsyncSession, order_id: str) -> None:
    """Marks active reservations consumed and decrements stock_on_hand & reserved_stock atomically."""
    result = await db.execute(
        select(InventoryReservation).where(
            and_(
                InventoryReservation.order_id == order_id,
                InventoryReservation.status == "active",
            )
        )
    )
    for res in result.scalars().all():
        res.status = "consumed"
        await db.execute(
            update(ProductVariant)
            .where(ProductVariant.id == res.variant_id)
            .values(
                stock_on_hand=ProductVariant.stock_on_hand - res.quantity,
                reserved_stock=ProductVariant.reserved_stock - res.quantity,
            )
        )


async def release_reservations_for_order(db: AsyncSession, order_id: str) -> None:
    """Releases active reservations when payment fails or order is cancelled before capture."""
    result = await db.execute(
        select(InventoryReservation).where(
            and_(
                InventoryReservation.order_id == order_id,
                InventoryReservation.status == "active",
            )
        )
    )
    for res in result.scalars().all():
        res.status = "released"
        await db.execute(
            update(ProductVariant)
            .where(ProductVariant.id == res.variant_id)
            .values(reserved_stock=ProductVariant.reserved_stock - res.quantity)
        )
