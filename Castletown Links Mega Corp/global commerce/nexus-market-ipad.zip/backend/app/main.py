from __future__ import annotations

from contextlib import asynccontextmanager
import logging
from pathlib import Path

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from app.core.config import get_settings
from app.core.database import AsyncSessionLocal, Base, engine
from app.core.security import RedactingLogFilter, SecurityEnforcementMiddleware
import app.models  # noqa: F401
from app.routers import (
    account,
    admin,
    assistant,
    bag,
    catalog,
    checkout,
    discover,
    health,
    orders,
    webhooks,
)
from app.services.seed import seed_demo_data


def configure_logging() -> None:
    root_logger = logging.getLogger()
    redactor = RedactingLogFilter()
    for handler in root_logger.handlers:
        handler.addFilter(redactor)
    root_logger.addFilter(redactor)


@asynccontextmanager
async def lifespan(_app: FastAPI):
    configure_logging()
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    async with AsyncSessionLocal() as session:
        await seed_demo_data(session)
    yield


def create_app() -> FastAPI:
    settings = get_settings()
    app = FastAPI(
        title=settings.app_name,
        version="1.0.0",
        description="Sunburst Market iPad Commerce & Demo Checkout API",
        lifespan=lifespan,
    )
    app.add_middleware(SecurityEnforcementMiddleware)

    media_dir = Path(__file__).resolve().parents[1] / "static" / "media"
    media_dir.mkdir(parents=True, exist_ok=True)
    app.mount("/media", StaticFiles(directory=str(media_dir)), name="media")

    app.include_router(health.router)
    app.include_router(account.router)
    app.include_router(discover.router)
    app.include_router(catalog.router)
    app.include_router(bag.router)
    app.include_router(checkout.router)
    app.include_router(orders.router)
    app.include_router(assistant.router)
    app.include_router(webhooks.router)
    app.include_router(admin.router)
    return app


app = create_app()
