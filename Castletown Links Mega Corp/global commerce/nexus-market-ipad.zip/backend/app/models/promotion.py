from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, JSON, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.models.catalog import utcnow


class Promotion(Base):
    __tablename__ = "promotions"

    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    code: Mapped[str] = mapped_column(String(40), nullable=False, index=True)
    version: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    title: Mapped[str] = mapped_column(String(120), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    discount_type: Mapped[str] = mapped_column(String(20), nullable=False)  # "percent_bps" or "fixed_minor"
    discount_value: Mapped[int] = mapped_column(Integer, nullable=False)  # bps (e.g. 1500 = 15%) or minor units
    currency: Mapped[str] = mapped_column(String(3), default="USD", nullable=False)
    min_spend_minor: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    max_discount_minor: Mapped[int | None] = mapped_column(Integer, nullable=True)
    starts_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    ends_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    stacking_precedence: Mapped[int] = mapped_column(Integer, default=100, nullable=False)
    is_stackable: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    eligible_category_ids: Mapped[list[str]] = mapped_column(JSON, default=list, nullable=False)
    excluded_product_ids: Mapped[list[str]] = mapped_column(JSON, default=list, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)


class PromotionUsage(Base):
    __tablename__ = "promotion_usages"

    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    promotion_id: Mapped[str] = mapped_column(ForeignKey("promotions.id", ondelete="CASCADE"), nullable=False, index=True)
    promotion_version: Mapped[int] = mapped_column(Integer, nullable=False)
    customer_id: Mapped[str] = mapped_column(ForeignKey("customers.id", ondelete="CASCADE"), nullable=False, index=True)
    order_id: Mapped[str] = mapped_column(ForeignKey("orders.id", ondelete="CASCADE"), nullable=False, index=True)
    discount_applied_minor: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)
