import XCTest
@testable import SunburstMarket

/// Slow/out-of-order mock transport to verify search cancellation & generation guards.
actor DelayedSearchTransport: CommerceTransport {
    private let base = DemoTransportService()
    func updateToken(_ token: String?) async { await base.updateToken(token) }
    func fetchDiscover(country: String, postal: String) async throws -> DiscoverPayload { try await base.fetchDiscover(country: country, postal: postal) }
    func fetchCategories() async throws -> [CategoryItem] { try await base.fetchCategories() }
    func fetchSellers() async throws -> [SellerSummary] { try await base.fetchSellers() }
    func fetchProductDetail(productId: String, country: String) async throws -> ProductDetail { try await base.fetchProductDetail(productId: productId, country: country) }
    func fetchBag(country: String) async throws -> BagPayload { try await base.fetchBag(country: country) }
    func addToBag(productId: String, variantId: String, quantity: Int, country: String) async throws -> BagPayload { try await base.addToBag(productId: productId, variantId: variantId, quantity: quantity, country: country) }
    func updateBagItem(itemId: String, quantity: Int?, variantId: String?, status: String?, country: String) async throws -> BagPayload { try await base.updateBagItem(itemId: itemId, quantity: quantity, variantId: variantId, status: status, country: country) }
    func removeBagItem(itemId: String, country: String) async throws -> BagPayload { try await base.removeBagItem(itemId: itemId, country: country) }
    func acknowledgeBagChanges(country: String) async throws -> BagPayload { try await base.acknowledgeBagChanges(country: country) }
    func previewCheckout(address: AddressRecord, deliveryMethod: String, promoCodes: [String]) async throws -> CheckoutPreviewPayload { try await base.previewCheckout(address: address, deliveryMethod: deliveryMethod, promoCodes: promoCodes) }
    func confirmCheckout(address: AddressRecord, deliveryMethod: String, promoCodes: [String], outcome: CheckoutSimulationOutcome, idempotencyKey: String) async throws -> CheckoutConfirmPayload { try await base.confirmCheckout(address: address, deliveryMethod: deliveryMethod, promoCodes: promoCodes, outcome: outcome, idempotencyKey: idempotencyKey) }
    func fetchOrders() async throws -> [OrderRecord] { try await base.fetchOrders() }
    func fetchOrderDetail(orderId: String) async throws -> OrderRecord { try await base.fetchOrderDetail(orderId: orderId) }
    func advanceTracking(orderId: String, simulateException: Bool) async throws -> OrderRecord { try await base.advanceTracking(orderId: orderId, simulateException: simulateException) }
    func cancelOrder(orderId: String) async throws -> OrderRecord { try await base.cancelOrder(orderId: orderId) }
    func requestReturn(orderId: String, items: [[String: AnyCodableValue]], reason: String, requestedAmountMinor: Int?) async throws -> ReturnRequestRecord { try await base.requestReturn(orderId: orderId, items: items, reason: reason, requestedAmountMinor: requestedAmountMinor) }
    func postSupportMessage(orderId: String, body: String) async throws -> SupportMessageRecord { try await base.postSupportMessage(orderId: orderId, body: body) }
    func createGuestSession(deviceName: String) async throws -> AuthSessionPayload { try await base.createGuestSession(deviceName: deviceName) }
    func login(email: String, password: String, deviceName: String) async throws -> AuthSessionPayload { try await base.login(email: email, password: password, deviceName: deviceName) }
    func register(email: String, password: String, displayName: String, deviceName: String) async throws -> AuthSessionPayload { try await base.register(email: email, password: password, displayName: displayName, deviceName: deviceName) }
    func fetchAccountSummary() async throws -> AccountSummaryPayload { try await base.fetchAccountSummary() }
    func updatePreferences(_ prefs: CustomerPreferencesRecord) async throws -> CustomerPreferencesRecord { try await base.updatePreferences(prefs) }
    func addAddress(_ address: AddressRecord) async throws -> AddressRecord { try await base.addAddress(address) }
    func deleteAddress(id: String) async throws { try await base.deleteAddress(id: id) }
    func revokeSession(id: String) async throws { try await base.revokeSession(id: id) }
    func requestAccountDeletion() async throws { try await base.requestAccountDeletion() }
    func fetchSavedProducts() async throws -> [ProductCard] { try await base.fetchSavedProducts() }
    func setProductSaved(productId: String, variantId: String?, saved: Bool) async throws { try await base.setProductSaved(productId: productId, variantId: variantId, saved: saved) }
    func sendAssistantMessage(_ message: String, confirmToken: String?) async throws -> AssistantChatPayload { try await base.sendAssistantMessage(message, confirmToken: confirmToken) }

    func searchCatalog(filters: SearchFilters, country: String, page: Int, pageSize: Int) async throws -> SearchResultsPayload {
        if filters.query == "slow" {
            try await Task.sleep(nanoseconds: 350_000_000)
        }
        return try await base.searchCatalog(filters: filters, country: country, page: page, pageSize: pageSize)
    }
}

@MainActor
final class SunburstMarketTests: XCTestCase {
    func testSearchCancellationPreventsStaleOverwrite() async {
        let vm = SearchViewModel()
        let transport = DelayedSearchTransport()

        vm.filters.query = "slow"
        vm.scheduleSearch(using: transport, country: "US", debounceMs: 10)
        try? await Task.sleep(nanoseconds: 40_000_000)

        vm.filters.query = "kettle"
        await vm.runSearch(using: transport, country: "US")
        try? await Task.sleep(nanoseconds: 400_000_000)

        XCTAssertEqual(vm.results.count, 1)
        XCTAssertEqual(vm.results.first?.id, "prod_ceramic_kettle")
    }

    func testVariantConsistencyAndChangedPriceNotice() async throws {
        let state = AppState(useOfflineDemoTransport: true)
        await state.bootstrap()

        await state.addToBag(productId: "prod_ceramic_kettle", variantId: "var_kettle_terracotta", quantity: 1)
        await state.addToBag(productId: "prod_brass_pen", variantId: "var_pen_raw", quantity: 1)

        XCTAssertEqual(state.bagItemCount, 2)
        await state.demoTransport.simulateServerPriceChangeOnFirstBagItem()
        await state.refreshBag()

        XCTAssertFalse(state.bag?.notices.isEmpty ?? true)
    }

    func testIdempotentCheckoutReplayAndReturns() async throws {
        let state = AppState(useOfflineDemoTransport: true)
        await state.bootstrap()
        await state.addToBag(productId: "prod_ceramic_kettle", variantId: "var_kettle_terracotta", quantity: 1)

        state.checkoutVM.resetForNewCheckout(defaultAddress: nil)
        state.checkoutVM.simulationOutcome = .uncertainTimeout
        await state.checkoutVM.submitDemoPayment(using: state.transport)
        let firstOrderId = state.checkoutVM.confirmation?.order.id

        await state.checkoutVM.retryWithSameIdempotencyKey(using: state.transport)
        XCTAssertEqual(state.checkoutVM.confirmation?.replayedFromIdempotency, true)
        XCTAssertEqual(state.checkoutVM.confirmation?.order.id, firstOrderId)
    }

    func testAppStateRestorationSnapshotRoundTrip() {
        let state = AppState(useOfflineDemoTransport: true)
        state.selectedSidebar = .search
        state.destinationCountry = "CA"
        state.destinationPostal = "M5V 2T6"
        state.showBagInspector = false
        state.searchVM.filters.query = "brass"
        state.searchVM.filters.inStockOnly = true

        let encoded = state.exportSnapshotJSON()
        let restored = AppState(useOfflineDemoTransport: true)
        restored.restore(from: encoded)

        XCTAssertEqual(restored.selectedSidebar, .search)
        XCTAssertEqual(restored.destinationCountry, "CA")
        XCTAssertEqual(restored.showBagInspector, false)
        XCTAssertEqual(restored.searchVM.filters.query, "brass")
        XCTAssertTrue(restored.searchVM.filters.inStockOnly)
    }
}
