import Foundation

enum SidebarDestination: String, CaseIterable, Identifiable, Codable, Hashable {
    case discover
    case categories
    case search
    case saved
    case orders
    case account

    var id: String { rawValue }

    var title: String {
        switch self {
        case .discover: return "Discover"
        case .categories: return "Categories"
        case .search: return "Search"
        case .saved: return "Saved"
        case .orders: return "Orders"
        case .account: return "Account"
        }
    }

    var systemImage: String {
        switch self {
        case .discover: return "sparkles"
        case .categories: return "square.grid.2x2.fill"
        case .search: return "magnifyingglass"
        case .saved: return "heart.fill"
        case .orders: return "shippingbox.fill"
        case .account: return "person.crop.circle.fill"
        }
    }
}

struct SellerSummary: Codable, Sendable, Identifiable, Hashable {
    let id: String
    let name: String
    let slug: String
    let dispatchCity: String
    let dispatchCountry: String
    let freeShippingThresholdMinor: Int
    let baseShippingMinor: Int
    let returnWindowDays: Int
    let returnPolicySummary: String
    let verifiedBadge: Bool
}

struct CategoryItem: Codable, Sendable, Identifiable, Hashable {
    let id: String
    let name: String
    let slug: String
    let iconName: String
    let description: String
}

struct PriceHistoryEntry: Codable, Sendable, Identifiable, Hashable {
    let id: String
    let priceMinor: Int
    let currency: String
    let reason: String
    let recordedAt: Date
}

struct ProductImageItem: Codable, Sendable, Identifiable, Hashable {
    let id: String
    let variantId: String?
    let url: String
    let altText: String
    let sortOrder: Int
}

struct ProductDocumentItem: Codable, Sendable, Identifiable, Hashable {
    let id: String
    let title: String
    let docType: String
    let url: String
    let summary: String
}

struct ProductReviewItem: Codable, Sendable, Identifiable, Hashable {
    let id: String
    let variantTitle: String
    let authorDisplay: String
    let rating: Int
    let title: String
    let body: String
    let verifiedDemoPurchase: Bool
    let createdAt: Date
}

struct ProductVariantItem: Codable, Sendable, Identifiable, Hashable {
    let id: String
    let sku: String
    let title: String
    let attributes: [String: String]
    let currency: String
    let priceMinor: Int
    let referencePriceMinor: Int?
    let referencePriceBasis: String?
    let availableStock: Int
    let isActive: Bool
    let priceHistory: [PriceHistoryEntry]
}

struct DeliverySummary: Codable, Sendable, Hashable {
    let estimatedWindow: String
    let guaranteedBy: String?
    let isGuaranteed: Bool
    let eligibleForDestination: Bool
    let restrictionReason: String?
}

struct ProductCard: Codable, Sendable, Identifiable, Hashable {
    let id: String
    let title: String
    let subtitle: String
    let categoryId: String
    let categoryName: String
    let seller: SellerSummary
    let primaryImageUrl: String
    let startingPriceMinor: Int
    let referencePriceMinor: Int?
    let currency: String
    let variantCount: Int
    let variantSwatches: [String]
    let inStock: Bool
    let delivery: DeliverySummary
    let ratingAverage: Double?
    let reviewCount: Int
    let recommendationReason: String?
}

struct ProductDetail: Codable, Sendable, Identifiable, Hashable {
    let id: String
    let title: String
    let subtitle: String
    let description: String
    let category: CategoryItem
    let seller: SellerSummary
    let dimensionsCm: String
    let weightGrams: Int
    let materials: [String]
    let shippingRestrictions: [String: AnyCodableValue]
    let delivery: DeliverySummary
    let variants: [ProductVariantItem]
    let images: [ProductImageItem]
    let documents: [ProductDocumentItem]
    let reviews: [ProductReviewItem]
    let ratingAverage: Double?
    let isSaved: Bool
}

struct PromotionBanner: Codable, Sendable, Identifiable, Hashable {
    let id: String
    let code: String
    let version: Int
    let title: String
    let description: String
    let endsAt: Date?
}

struct RecommendedCollection: Codable, Sendable, Identifiable, Hashable {
    let id: String
    let title: String
    let explanation: String
    let products: [ProductCard]
}

struct DiscoverPayload: Codable, Sendable {
    let destinationCountry: String
    let destinationPostal: String
    let banner: PromotionBanner?
    let categories: [CategoryItem]
    let featuredProducts: [ProductCard]
    let recentlyViewed: [ProductCard]
    let collections: [RecommendedCollection]
}

struct SearchResultsPayload: Codable, Sendable {
    let items: [ProductCard]
    let total: Int
    let page: Int
    let pageSize: Int
    let hasNext: Bool
}

struct SearchFilters: Codable, Sendable, Equatable {
    var query: String = ""
    var categoryId: String? = nil
    var sellerId: String? = nil
    var minPriceMinor: Int? = nil
    var maxPriceMinor: Int? = nil
    var attributeKey: String? = nil
    var attributeValue: String? = nil
    var inStockOnly: Bool = false
    var eligibleOnly: Bool = false
    var sort: String = "relevance"
}

struct BagLineItem: Codable, Sendable, Identifiable, Hashable {
    let id: String
    let productId: String
    let variantId: String
    let sku: String
    let productTitle: String
    let variantTitle: String
    let availableVariants: [ProductVariantItem]
    let imageUrl: String
    let quantity: Int
    let unitPriceMinor: Int
    let previousUnitPriceMinor: Int
    let lineTotalMinor: Int
    let currency: String
    let availableStock: Int
    let status: String
    let priceChanged: Bool
    let stockInsufficient: Bool
    let noticeMessage: String?
    let eligibleForDestination: Bool
    let restrictionReason: String?
}

struct BagSellerGroup: Codable, Sendable, Identifiable, Hashable {
    var id: String { seller.id }
    let seller: SellerSummary
    let items: [BagLineItem]
    let subtotalMinor: Int
    let estimatedShippingMinor: Int
    let freeShippingRemainingMinor: Int
}

struct BagPayload: Codable, Sendable {
    let destinationCountry: String
    let currency: String
    let sellerGroups: [BagSellerGroup]
    let savedForLater: [BagLineItem]
    let subtotalMinor: Int
    let estimatedShippingMinor: Int
    let hasBlockingIssues: Bool
    let notices: [String]
}

struct AddressRecord: Codable, Sendable, Identifiable, Hashable {
    var id: String
    var label: String
    var recipientName: String
    var line1: String
    var line2: String
    var city: String
    var region: String
    var postalCode: String
    var countryCode: String
    var isDefault: Bool
}

struct AppliedPromotionItem: Codable, Sendable, Identifiable, Hashable {
    let id: String
    let code: String
    let version: Int
    let title: String
    let discountMinor: Int
    let explanation: String
}

struct CheckoutSellerBreakdown: Codable, Sendable, Identifiable, Hashable {
    var id: String { sellerId }
    let sellerId: String
    let sellerName: String
    let subtotalMinor: Int
    let shippingMinor: Int
    let estimatedWindow: String
    let guaranteedBy: String?
    let itemCount: Int
}

struct CheckoutPreviewPayload: Codable, Sendable {
    let currency: String
    let subtotalMinor: Int
    let discountMinor: Int
    let shippingMinor: Int
    let taxMinor: Int
    let totalMinor: Int
    let taxRateBps: Int
    let appliedPromotions: [AppliedPromotionItem]
    let rejectedPromotions: [[String: String]]
    let discountExplanation: String
    let sellerBreakdowns: [CheckoutSellerBreakdown]
    let isDemoCheckout: Bool
    let notices: [String]
}

enum CheckoutSimulationOutcome: String, CaseIterable, Identifiable, Codable, Sendable {
    case success
    case failed
    case uncertainTimeout = "uncertain_timeout"

    var id: String { rawValue }
    var displayName: String {
        switch self {
        case .success: return "Demo Payment Succeeds"
        case .failed: return "Simulate Declined Payment"
        case .uncertainTimeout: return "Simulate Lost Response / Timeout"
        }
    }
}

struct OrderItemRecord: Codable, Sendable, Identifiable, Hashable {
    let id: String
    let productId: String
    let variantId: String
    let sku: String
    let productTitle: String
    let variantSummary: String
    let imageUrl: String
    let currency: String
    let unitPriceMinor: Int
    let quantity: Int
    let lineTotalMinor: Int
}

struct TrackingEventRecord: Codable, Sendable, Identifiable, Hashable {
    var id: String { "\(timestamp)-\(status)" }
    let timestamp: String
    let status: String
    let location: String
    let detail: String
    let isSynthetic: Bool
}

struct OrderFulfillmentRecord: Codable, Sendable, Identifiable, Hashable {
    let id: String
    let sellerId: String
    let sellerName: String
    let status: String
    let carrierName: String
    let trackingNumber: String
    let shippingMinor: Int
    let estimatedWindow: String
    let guaranteedBy: String?
    let exceptionNote: String?
    let events: [TrackingEventRecord]
    let items: [OrderItemRecord]
}

struct ReturnRequestRecord: Codable, Sendable, Identifiable, Hashable {
    let id: String
    let orderId: String
    let reason: String
    let eligibleAmountMinor: Int
    let requestedAmountMinor: Int
    let currency: String
    let returnStatus: String
    let refundStatus: String
    let createdAt: Date

    var refundStageTitle: String {
        switch refundStatus {
        case "refund_approved": return "Refund Approved"
        case "refund_submitted": return "Refund Submitted"
        case "refund_confirmed": return "Refund Confirmed"
        case "rejected": return "Refund Rejected"
        default: return "No Refund Initiated"
        }
    }
}

struct SupportMessageRecord: Codable, Sendable, Identifiable, Hashable {
    let id: String
    let orderId: String
    let senderRole: String
    let body: String
    let createdAt: Date
}

struct OrderRecord: Codable, Sendable, Identifiable, Hashable {
    let id: String
    let orderNumber: String
    let orderStatus: String
    let paymentStatus: String
    let fulfillmentStatus: String
    let currency: String
    let subtotalMinor: Int
    let discountMinor: Int
    let shippingMinor: Int
    let taxMinor: Int
    let totalMinor: Int
    let deliveryMethod: String
    let discountExplanation: String
    let isDemoOrder: Bool
    let createdAt: Date
    let fulfillments: [OrderFulfillmentRecord]
    let returns: [ReturnRequestRecord]
    let supportMessages: [SupportMessageRecord]
}

struct CheckoutConfirmPayload: Codable, Sendable {
    let order: OrderRecord
    let paymentStatus: String
    let providerReference: String
    let replayedFromIdempotency: Bool
    let message: String
}

struct AuthSessionPayload: Codable, Sendable {
    let token: String
    let customerId: String
    let displayName: String
    let email: String?
    let isGuest: Bool
    let deviceSessionId: String
}

struct DeviceSessionRecord: Codable, Sendable, Identifiable, Hashable {
    let id: String
    let deviceName: String
    let platform: String
    let lastActiveAt: Date
    let revokedAt: Date?
    let isCurrent: Bool
}

struct CustomerPreferencesRecord: Codable, Sendable, Equatable {
    var destinationCountry: String
    var destinationPostal: String
    var currency: String
    var orderUpdatesEnabled: Bool
    var promoAlertsEnabled: Bool
    var priceDropAlertsEnabled: Bool
}

struct AccountSummaryPayload: Codable, Sendable {
    let customerId: String
    let email: String?
    let displayName: String
    let isGuest: Bool
    let deletionRequestedAt: Date?
    let preferences: CustomerPreferencesRecord
    let addresses: [AddressRecord]
    let sessions: [DeviceSessionRecord]
}

struct AssistantPendingConfirmation: Codable, Sendable, Hashable {
    let summary: String
    let confirmToken: String
}

struct AssistantChatPayload: Codable, Sendable {
    let reply: String
    let mode: String
    let referencedProducts: [ProductCard]
    let pendingConfirmation: AssistantPendingConfirmation?
}

/// Lightweight Codable wrapper for heterogeneous JSON metadata (e.g., shipping restrictions).
enum AnyCodableValue: Codable, Sendable, Hashable {
    case string(String)
    case bool(Bool)
    case int(Int)
    case double(Double)
    case array([String])
    case null

    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if container.decodeNil() {
            self = .null
        } else if let b = try? container.decode(Bool.self) {
            self = .bool(b)
        } else if let i = try? container.decode(Int.self) {
            self = .int(i)
        } else if let d = try? container.decode(Double.self) {
            self = .double(d)
        } else if let s = try? container.decode(String.self) {
            self = .string(s)
        } else if let a = try? container.decode([String].self) {
            self = .array(a)
        } else {
            self = .null
        }
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        switch self {
        case .string(let v): try container.encode(v)
        case .bool(let v): try container.encode(v)
        case .int(let v): try container.encode(v)
        case .double(let v): try container.encode(v)
        case .array(let v): try container.encode(v)
        case .null: try container.encodeNil()
        }
    }
}
