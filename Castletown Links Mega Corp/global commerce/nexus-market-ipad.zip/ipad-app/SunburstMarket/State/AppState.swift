import Foundation
import SwiftUI

struct RestorableAppSnapshot: Codable {
    var selectedSidebar: SidebarDestination
    var destinationCountry: String
    var destinationPostal: String
    var showBagInspector: Bool
    var searchFilters: SearchFilters
}

@MainActor
@Observable
final class AppState {
    var selectedSidebar: SidebarDestination = .discover
    var showBagInspector: Bool = true
    var destinationCountry: String = "US"
    var destinationPostal: String = "94107"

    // Navigation paths per sidebar tab preserve exact scroll/stack state when returning from product detail
    var discoverPath: [String] = []
    var categoriesPath: [String] = []
    var searchPath: [String] = []
    var savedPath: [String] = []
    var ordersPath: [String] = []

    var useOfflineDemoTransport: Bool
    let liveClient: LiveAPIClient
    let demoTransport: DemoTransportService
    let keychain: KeychainStore

    var transport: any CommerceTransport {
        useOfflineDemoTransport ? demoTransport : liveClient
    }

    var session: AuthSessionPayload?
    var discoverData: DiscoverPayload?
    var discoverLoading: Bool = false
    var discoverError: String?

    var bag: BagPayload?
    var bagLoading: Bool = false
    var savedProducts: [ProductCard] = []
    var orders: [OrderRecord] = []
    var accountSummary: AccountSummaryPayload?

    var bannerToast: String?
    var showCheckoutSheet: Bool = false
    var showAssistantSheet: Bool = false
    var focusSearchTrigger: Int = 0

    let searchVM: SearchViewModel
    let checkoutVM: CheckoutViewModel

    init(
        useOfflineDemoTransport: Bool = false,
        liveClient: LiveAPIClient = LiveAPIClient(),
        demoTransport: DemoTransportService = DemoTransportService(),
        keychain: KeychainStore = KeychainStore()
    ) {
        self.useOfflineDemoTransport = useOfflineDemoTransport
        self.liveClient = liveClient
        self.demoTransport = demoTransport
        self.keychain = keychain
        self.searchVM = SearchViewModel()
        self.checkoutVM = CheckoutViewModel()

        if let saved = keychain.loadSession() {
            self.session = saved
        }
    }

    func restore(from jsonString: String) {
        guard !jsonString.isEmpty,
              let data = jsonString.data(using: .utf8),
              let snap = try? JSONDecoder().decode(RestorableAppSnapshot.self, from: data) else { return }
        selectedSidebar = snap.selectedSidebar
        destinationCountry = snap.destinationCountry
        destinationPostal = snap.destinationPostal
        showBagInspector = snap.showBagInspector
        searchVM.filters = snap.searchFilters
    }

    func exportSnapshotJSON() -> String {
        let snap = RestorableAppSnapshot(
            selectedSidebar: selectedSidebar,
            destinationCountry: destinationCountry,
            destinationPostal: destinationPostal,
            showBagInspector: showBagInspector,
            searchFilters: searchVM.filters
        )
        guard let data = try? JSONEncoder().encode(snap),
              let str = String(data: data, encoding: .utf8) else { return "" }
        return str
    }

    func bootstrap() async {
        if let existing = session {
            await liveClient.updateToken(existing.token)
        } else if !useOfflineDemoTransport {
            do {
                let guest = try await liveClient.createGuestSession(deviceName: "iPad")
                self.session = guest
                keychain.saveSession(guest)
                await liveClient.updateToken(guest.token)
            } catch {
                // Automatically switch to deterministic DemoTransportService when local FastAPI is unreachable
                self.useOfflineDemoTransport = true
                self.session = try? await demoTransport.createGuestSession(deviceName: "iPad Demo")
            }
        } else {
            self.session = try? await demoTransport.createGuestSession(deviceName: "iPad Demo")
        }

        await withTaskGroup(of: Void.self) { group in
            group.addTask { await self.loadDiscover() }
            group.addTask { await self.refreshBag() }
            group.addTask { await self.loadCategoriesAndSellers() }
        }
    }

    func loadCategoriesAndSellers() async {
        do {
            async let cats = transport.fetchCategories()
            async let sels = transport.fetchSellers()
            searchVM.categories = try await cats
            searchVM.sellers = try await sels
        } catch {}
    }

    func loadDiscover() async {
        discoverLoading = true
        discoverError = nil
        do {
            discoverData = try await transport.fetchDiscover(country: destinationCountry, postal: destinationPostal)
        } catch {
            discoverError = error.localizedDescription
        }
        discoverLoading = false
    }

    func updateDestination(country: String, postal: String) async {
        destinationCountry = country.uppercased()
        destinationPostal = postal
        await loadDiscover()
        await refreshBag()
        await searchVM.runSearch(using: transport, country: destinationCountry, resetPage: true)
    }

    func refreshBag() async {
        bagLoading = true
        do {
            bag = try await transport.fetchBag(country: destinationCountry)
        } catch {}
        bagLoading = false
    }

    func addToBag(productId: String, variantId: String, quantity: Int) async {
        do {
            bag = try await transport.addToBag(productId: productId, variantId: variantId, quantity: quantity, country: destinationCountry)
            bannerToast = "Added to shopping bag"
        } catch {
            bannerToast = error.localizedDescription
        }
    }

    func updateBagItem(itemId: String, quantity: Int? = nil, variantId: String? = nil, status: String? = nil) async {
        do {
            bag = try await transport.updateBagItem(itemId: itemId, quantity: quantity, variantId: variantId, status: status, country: destinationCountry)
        } catch {
            bannerToast = error.localizedDescription
        }
    }

    func removeBagItem(itemId: String) async {
        do {
            bag = try await transport.removeBagItem(itemId: itemId, country: destinationCountry)
        } catch {
            bannerToast = error.localizedDescription
        }
    }

    func acknowledgeBagChanges() async {
        do {
            bag = try await transport.acknowledgeBagChanges(country: destinationCountry)
        } catch {
            bannerToast = error.localizedDescription
        }
    }

    func toggleSaved(productId: String, variantId: String? = nil, currentlySaved: Bool) async {
        do {
            try await transport.setProductSaved(productId: productId, variantId: variantId, saved: !currentlySaved)
            savedProducts = try await transport.fetchSavedProducts()
            bannerToast = currentlySaved ? "Removed from Saved" : "Saved to your list"
        } catch {
            bannerToast = error.localizedDescription
        }
    }

    func loadSaved() async {
        do {
            savedProducts = try await transport.fetchSavedProducts()
        } catch {}
    }

    func loadOrders() async {
        do {
            orders = try await transport.fetchOrders()
        } catch {}
    }

    func loadAccount() async {
        do {
            accountSummary = try await transport.fetchAccountSummary()
        } catch {}
    }

    func signIn(email: String, password: String) async {
        do {
            let auth = try await transport.login(email: email, password: password, deviceName: "iPad Pro")
            session = auth
            keychain.saveSession(auth)
            await transport.updateToken(auth.token)
            await loadAccount()
            await loadOrders()
            await loadSaved()
            await refreshBag()
            bannerToast = "Signed in as \(auth.displayName)"
        } catch {
            bannerToast = error.localizedDescription
        }
    }

    func resolveImageURL(_ pathOrURL: String) -> URL? {
        if pathOrURL.hasPrefix("http://") || pathOrURL.hasPrefix("https://") || pathOrURL.hasPrefix("demo://") {
            return URL(string: pathOrURL)
        }
        return URL(string: pathOrURL, relativeTo: BrandConfig.defaultBaseURL)?.absoluteURL
    }

    var bagItemCount: Int {
        bag?.sellerGroups.flatMap(\.items).reduce(0) { $0 + $1.quantity } ?? 0
    }
}
