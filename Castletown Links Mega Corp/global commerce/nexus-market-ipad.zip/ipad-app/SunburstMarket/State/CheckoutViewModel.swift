import Foundation

enum CheckoutStep: Int, CaseIterable, Identifiable {
    case address = 0
    case delivery = 1
    case review = 2
    case payment = 3
    case confirmation = 4

    var id: Int { rawValue }
    var title: String {
        switch self {
        case .address: return "Address"
        case .delivery: return "Delivery"
        case .review: return "Review"
        case .payment: return "Payment"
        case .confirmation: return "Confirmation"
        }
    }
}

@MainActor
@Observable
final class CheckoutViewModel {
    var step: CheckoutStep = .address
    var address = AddressRecord(
        id: "draft",
        label: "Home Studio",
        recipientName: "Alex Rivera",
        line1: "742 Market Street",
        line2: "Suite 4B",
        city: "San Francisco",
        region: "CA",
        postalCode: "94107",
        countryCode: "US",
        isDefault: true
    )
    var deliveryMethod: String = "standard"
    var promoInput: String = "WELCOME15"
    var appliedCodes: [String] = ["WELCOME15"]
    var simulationOutcome: CheckoutSimulationOutcome = .success

    var preview: CheckoutPreviewPayload?
    var confirmation: CheckoutConfirmPayload?
    var isBusy: Bool = false
    var errorMessage: String?

    /// Maintained across retries for a lost network response so checkout stays idempotent.
    var activeIdempotencyKey: String = "ipad-\(UUID().uuidString)"

    func resetForNewCheckout(defaultAddress: AddressRecord?) {
        step = .address
        if let defaultAddress {
            address = defaultAddress
        }
        preview = nil
        confirmation = nil
        errorMessage = nil
        simulationOutcome = .success
        activeIdempotencyKey = "ipad-\(UUID().uuidString)"
    }

    func refreshPreview(using transport: any CommerceTransport) async {
        isBusy = true
        errorMessage = nil
        do {
            preview = try await transport.previewCheckout(
                address: address,
                deliveryMethod: deliveryMethod,
                promoCodes: appliedCodes
            )
        } catch {
            errorMessage = error.localizedDescription
        }
        isBusy = false
    }

    func addPromoCode(_ code: String, using transport: any CommerceTransport) async {
        let trimmed = code.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        guard !trimmed.isEmpty else { return }
        if !appliedCodes.contains(trimmed) {
            appliedCodes.append(trimmed)
        }
        promoInput = ""
        await refreshPreview(using: transport)
    }

    func removePromoCode(_ code: String, using transport: any CommerceTransport) async {
        appliedCodes.removeAll { $0 == code }
        await refreshPreview(using: transport)
    }

    func submitDemoPayment(using transport: any CommerceTransport) async {
        isBusy = true
        errorMessage = nil
        do {
            let result = try await transport.confirmCheckout(
                address: address,
                deliveryMethod: deliveryMethod,
                promoCodes: appliedCodes,
                outcome: simulationOutcome,
                idempotencyKey: activeIdempotencyKey
            )
            confirmation = result
            step = .confirmation
        } catch {
            errorMessage = error.localizedDescription
        }
        isBusy = false
    }

    /// Re-submits with the exact same Idempotency-Key to demonstrate safe recovery after a lost checkout response.
    func retryWithSameIdempotencyKey(using transport: any CommerceTransport) async {
        await submitDemoPayment(using: transport)
    }
}
