import Foundation

@MainActor
@Observable
final class SearchViewModel {
    var filters = SearchFilters()
    var categories: [CategoryItem] = []
    var sellers: [SellerSummary] = []

    var results: [ProductCard] = []
    var totalCount: Int = 0
    var currentPage: Int = 1
    var hasNextPage: Bool = false
    var isLoading: Bool = false
    var errorMessage: String?
    var scrolledProductId: String?

    private var activeTask: Task<Void, Never>?
    private var requestGeneration: UInt64 = 0

    func scheduleSearch(using transport: any CommerceTransport, country: String, debounceMs: UInt64 = 220) {
        activeTask?.cancel()
        requestGeneration &+= 1
        let expectedGen = requestGeneration

        activeTask = Task {
            if debounceMs > 0 {
                try? await Task.sleep(nanoseconds: debounceMs * 1_000_000)
            }
            guard !Task.isCancelled else { return }
            await performSearch(using: transport, country: country, page: 1, append: false, generation: expectedGen)
        }
    }

    func runSearch(using transport: any CommerceTransport, country: String, resetPage: Bool = true) async {
        activeTask?.cancel()
        requestGeneration &+= 1
        let expectedGen = requestGeneration
        let targetPage = resetPage ? 1 : currentPage + 1
        await performSearch(using: transport, country: country, page: targetPage, append: !resetPage, generation: expectedGen)
    }

    private func performSearch(
        using transport: any CommerceTransport,
        country: String,
        page: Int,
        append: Bool,
        generation: UInt64
    ) async {
        isLoading = true
        errorMessage = nil
        do {
            let response = try await transport.searchCatalog(filters: filters, country: country, page: page, pageSize: 12)
            // Guard against stale out-of-order responses
            guard generation == requestGeneration, !Task.isCancelled else { return }
            if append {
                results.append(contentsOf: response.items)
            } else {
                results = response.items
            }
            totalCount = response.total
            currentPage = response.page
            hasNextPage = response.hasNext
        } catch is CancellationError {
            return
        } catch {
            guard generation == requestGeneration else { return }
            errorMessage = error.localizedDescription
        }
        if generation == requestGeneration {
            isLoading = false
        }
    }

    func clearFilters(using transport: any CommerceTransport, country: String) async {
        filters = SearchFilters()
        await runSearch(using: transport, country: country, resetPage: true)
    }
}
