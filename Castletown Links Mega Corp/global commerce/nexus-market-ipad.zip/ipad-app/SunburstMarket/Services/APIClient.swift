import Foundation

enum APIError: LocalizedError, Sendable {
    case invalidURL
    case serverError(statusCode: Int, message: String)
    case transportError(String)
    case decodingError(String)

    var errorDescription: String? {
        switch self {
        case .invalidURL:
            return "Invalid backend server URL."
        case .serverError(_, let message):
            return message
        case .transportError(let detail):
            return "Network unavailable: \(detail)"
        case .decodingError(let detail):
            return "Unexpected server response format: \(detail)"
        }
    }
}

protocol CommerceTransport: Sendable {
    func updateToken(_ token: String?) async
    func fetchDiscover(country: String, postal: String) async throws -> DiscoverPayload
    func searchCatalog(filters: SearchFilters, country: String, page: Int, pageSize: Int) async throws -> SearchResultsPayload
    func fetchCategories() async throws -> [CategoryItem]
    func fetchSellers() async throws -> [SellerSummary]
    func fetchProductDetail(productId: String, country: String) async throws -> ProductDetail
    func fetchBag(country: String) async throws -> BagPayload
    func addToBag(productId: String, variantId: String, quantity: Int, country: String) async throws -> BagPayload
    func updateBagItem(itemId: String, quantity: Int?, variantId: String?, status: String?, country: String) async throws -> BagPayload
    func removeBagItem(itemId: String, country: String) async throws -> BagPayload
    func acknowledgeBagChanges(country: String) async throws -> BagPayload
    func previewCheckout(address: AddressRecord, deliveryMethod: String, promoCodes: [String]) async throws -> CheckoutPreviewPayload
    func confirmCheckout(address: AddressRecord, deliveryMethod: String, promoCodes: [String], outcome: CheckoutSimulationOutcome, idempotencyKey: String) async throws -> CheckoutConfirmPayload
    func fetchOrders() async throws -> [OrderRecord]
    func fetchOrderDetail(orderId: String) async throws -> OrderRecord
    func advanceTracking(orderId: String, simulateException: Bool) async throws -> OrderRecord
    func cancelOrder(orderId: String) async throws -> OrderRecord
    func requestReturn(orderId: String, items: [[String: AnyCodableValue]], reason: String, requestedAmountMinor: Int?) async throws -> ReturnRequestRecord
    func postSupportMessage(orderId: String, body: String) async throws -> SupportMessageRecord
    func createGuestSession(deviceName: String) async throws -> AuthSessionPayload
    func login(email: String, password: String, deviceName: String) async throws -> AuthSessionPayload
    func register(email: String, password: String, displayName: String, deviceName: String) async throws -> AuthSessionPayload
    func fetchAccountSummary() async throws -> AccountSummaryPayload
    func updatePreferences(_ prefs: CustomerPreferencesRecord) async throws -> CustomerPreferencesRecord
    func addAddress(_ address: AddressRecord) async throws -> AddressRecord
    func deleteAddress(id: String) async throws
    func revokeSession(id: String) async throws
    func requestAccountDeletion() async throws
    func fetchSavedProducts() async throws -> [ProductCard]
    func setProductSaved(productId: String, variantId: String?, saved: Bool) async throws
    func sendAssistantMessage(_ message: String, confirmToken: String?) async throws -> AssistantChatPayload
}

actor LiveAPIClient: CommerceTransport {
    private var baseURL: URL
    private var authToken: String?
    private let session: URLSession
    private let decoder: JSONDecoder
    private let encoder: JSONEncoder

    init(baseURL: URL = BrandConfig.defaultBaseURL, authToken: String? = nil, session: URLSession = .shared) {
        self.baseURL = baseURL
        self.authToken = authToken
        self.session = session

        let dec = JSONDecoder()
        dec.keyDecodingStrategy = .convertFromSnakeCase
        dec.dateDecodingStrategy = .iso8601
        self.decoder = dec

        let enc = JSONEncoder()
        enc.keyEncodingStrategy = .convertToSnakeCase
        enc.dateEncodingStrategy = .iso8601
        self.encoder = enc
    }

    func updateBaseURL(_ url: URL) {
        self.baseURL = url
    }

    func updateToken(_ token: String?) {
        self.authToken = token
    }

    func resolveMediaURL(_ pathOrURL: String) -> URL? {
        if pathOrURL.hasPrefix("http://") || pathOrURL.hasPrefix("https://") {
            return URL(string: pathOrURL)
        }
        return URL(string: pathOrURL, relativeTo: baseURL)?.absoluteURL
    }

    private func send<T: Decodable>(
        path: String,
        method: String = "GET",
        queryItems: [URLQueryItem] = [],
        bodyData: Data? = nil,
        extraHeaders: [String: String] = [:]
    ) async throws -> T {
        guard var components = URLComponents(url: baseURL.appendingPathComponent(path), resolvingAgainstBaseURL: true) else {
            throw APIError.invalidURL
        }
        if !queryItems.isEmpty {
            components.queryItems = queryItems
        }
        guard let url = components.url else { throw APIError.invalidURL }

        var request = URLRequest(url: url)
        request.httpMethod = method
        request.timeoutInterval = 20
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        if bodyData != nil {
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.httpBody = bodyData
        }
        if let token = authToken {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        for (k, v) in extraHeaders {
            request.setValue(v, forHTTPHeaderField: k)
        }

        let (data, response): (Data, URLResponse)
        do {
            (data, response) = try await session.data(for: request)
        } catch is CancellationError {
            throw CancellationError()
        } catch let urlErr as URLError where urlErr.code == .cancelled {
            throw CancellationError()
        } catch {
            throw APIError.transportError(error.localizedDescription)
        }

        guard let http = response as? HTTPURLResponse else {
            throw APIError.transportError("Non-HTTP response")
        }
        if !(200...299).contains(http.statusCode) {
            let detail = (try? JSONSerialization.jsonObject(with: data) as? [String: Any])?["detail"] as? String
            throw APIError.serverError(statusCode: http.statusCode, message: detail ?? "HTTP \(http.statusCode)")
        }
        do {
            return try decoder.decode(T.self, from: data)
        } catch {
            throw APIError.decodingError(error.localizedDescription)
        }
    }

    func fetchDiscover(country: String, postal: String) async throws -> DiscoverPayload {
        try await send(
            path: "/api/v1/discover",
            queryItems: [
                URLQueryItem(name: "destination_country", value: country),
                URLQueryItem(name: "destination_postal", value: postal),
            ]
        )
    }

    func searchCatalog(filters: SearchFilters, country: String, page: Int, pageSize: Int) async throws -> SearchResultsPayload {
        var items: [URLQueryItem] = [
            URLQueryItem(name: "q", value: filters.query),
            URLQueryItem(name: "destination_country", value: country),
            URLQueryItem(name: "sort", value: filters.sort),
            URLQueryItem(name: "page", value: String(page)),
            URLQueryItem(name: "page_size", value: String(pageSize)),
            URLQueryItem(name: "in_stock_only", value: String(filters.inStockOnly)),
            URLQueryItem(name: "eligible_only", value: String(filters.eligibleOnly)),
        ]
        if let cat = filters.categoryId { items.append(URLQueryItem(name: "category_id", value: cat)) }
        if let sel = filters.sellerId { items.append(URLQueryItem(name: "seller_id", value: sel)) }
        if let minP = filters.minPriceMinor { items.append(URLQueryItem(name: "min_price_minor", value: String(minP))) }
        if let maxP = filters.maxPriceMinor { items.append(URLQueryItem(name: "max_price_minor", value: String(maxP))) }
        if let ak = filters.attributeKey, let av = filters.attributeValue {
            items.append(URLQueryItem(name: "attribute_key", value: ak))
            items.append(URLQueryItem(name: "attribute_value", value: av))
        }
        return try await send(path: "/api/v1/catalog/search", queryItems: items)
    }

    func fetchCategories() async throws -> [CategoryItem] {
        try await send(path: "/api/v1/catalog/categories")
    }

    func fetchSellers() async throws -> [SellerSummary] {
        try await send(path: "/api/v1/catalog/sellers")
    }

    func fetchProductDetail(productId: String, country: String) async throws -> ProductDetail {
        try await send(
            path: "/api/v1/catalog/products/\(productId)",
            queryItems: [URLQueryItem(name: "destination_country", value: country)]
        )
    }

    func fetchBag(country: String) async throws -> BagPayload {
        try await send(
            path: "/api/v1/bag",
            queryItems: [URLQueryItem(name: "destination_country", value: country)]
        )
    }

    func addToBag(productId: String, variantId: String, quantity: Int, country: String) async throws -> BagPayload {
        struct Body: Encodable { let productId: String; let variantId: String; let quantity: Int }
        let data = try encoder.encode(Body(productId: productId, variantId: variantId, quantity: quantity))
        return try await send(
            path: "/api/v1/bag/items",
            method: "POST",
            queryItems: [URLQueryItem(name: "destination_country", value: country)],
            bodyData: data
        )
    }

    func updateBagItem(itemId: String, quantity: Int?, variantId: String?, status: String?, country: String) async throws -> BagPayload {
        struct Body: Encodable { let quantity: Int?; let variantId: String?; let status: String? }
        let data = try encoder.encode(Body(quantity: quantity, variantId: variantId, status: status))
        return try await send(
            path: "/api/v1/bag/items/\(itemId)",
            method: "PATCH",
            queryItems: [URLQueryItem(name: "destination_country", value: country)],
            bodyData: data
        )
    }

    func removeBagItem(itemId: String, country: String) async throws -> BagPayload {
        try await send(
            path: "/api/v1/bag/items/\(itemId)",
            method: "DELETE",
            queryItems: [URLQueryItem(name: "destination_country", value: country)]
        )
    }

    func acknowledgeBagChanges(country: String) async throws -> BagPayload {
        try await send(
            path: "/api/v1/bag/acknowledge-changes",
            method: "POST",
            queryItems: [URLQueryItem(name: "destination_country", value: country)]
        )
    }

    func previewCheckout(address: AddressRecord, deliveryMethod: String, promoCodes: [String]) async throws -> CheckoutPreviewPayload {
        struct Body: Encodable { let address: AddressRecord; let deliveryMethod: String; let promoCodes: [String] }
        let data = try encoder.encode(Body(address: address, deliveryMethod: deliveryMethod, promoCodes: promoCodes))
        return try await send(path: "/api/v1/checkout/preview", method: "POST", bodyData: data)
    }

    func confirmCheckout(address: AddressRecord, deliveryMethod: String, promoCodes: [String], outcome: CheckoutSimulationOutcome, idempotencyKey: String) async throws -> CheckoutConfirmPayload {
        struct Body: Encodable { let address: AddressRecord; let deliveryMethod: String; let promoCodes: [String]; let simulationOutcome: String }
        let data = try encoder.encode(Body(address: address, deliveryMethod: deliveryMethod, promoCodes: promoCodes, simulationOutcome: outcome.rawValue))
        return try await send(
            path: "/api/v1/checkout/confirm",
            method: "POST",
            bodyData: data,
            extraHeaders: ["Idempotency-Key": idempotencyKey]
        )
    }

    func fetchOrders() async throws -> [OrderRecord] {
        try await send(path: "/api/v1/orders")
    }

    func fetchOrderDetail(orderId: String) async throws -> OrderRecord {
        try await send(path: "/api/v1/orders/\(orderId)")
    }

    func advanceTracking(orderId: String, simulateException: Bool) async throws -> OrderRecord {
        try await send(
            path: "/api/v1/orders/\(orderId)/tracking/advance",
            method: "POST",
            queryItems: [URLQueryItem(name: "simulate_exception", value: String(simulateException))]
        )
    }

    func cancelOrder(orderId: String) async throws -> OrderRecord {
        try await send(path: "/api/v1/orders/\(orderId)/cancel", method: "POST")
    }

    func requestReturn(orderId: String, items: [[String: AnyCodableValue]], reason: String, requestedAmountMinor: Int?) async throws -> ReturnRequestRecord {
        struct Body: Encodable { let items: [[String: AnyCodableValue]]; let reason: String; let requestedAmountMinor: Int? }
        let data = try encoder.encode(Body(items: items, reason: reason, requestedAmountMinor: requestedAmountMinor))
        return try await send(path: "/api/v1/orders/\(orderId)/returns", method: "POST", bodyData: data)
    }

    func postSupportMessage(orderId: String, body: String) async throws -> SupportMessageRecord {
        struct Body: Encodable { let body: String }
        let data = try encoder.encode(Body(body: body))
        return try await send(path: "/api/v1/orders/\(orderId)/messages", method: "POST", bodyData: data)
    }

    func createGuestSession(deviceName: String) async throws -> AuthSessionPayload {
        struct Body: Encodable { let deviceName: String }
        let data = try encoder.encode(Body(deviceName: deviceName))
        return try await send(path: "/api/v1/account/guest", method: "POST", bodyData: data)
    }

    func login(email: String, password: String, deviceName: String) async throws -> AuthSessionPayload {
        struct Body: Encodable { let email: String; let password: String; let deviceName: String }
        let data = try encoder.encode(Body(email: email, password: password, deviceName: deviceName))
        return try await send(path: "/api/v1/account/login", method: "POST", bodyData: data)
    }

    func register(email: String, password: String, displayName: String, deviceName: String) async throws -> AuthSessionPayload {
        struct Body: Encodable { let email: String; let password: String; let displayName: String; let deviceName: String }
        let data = try encoder.encode(Body(email: email, password: password, displayName: displayName, deviceName: deviceName))
        return try await send(path: "/api/v1/account/register", method: "POST", bodyData: data)
    }

    func fetchAccountSummary() async throws -> AccountSummaryPayload {
        try await send(path: "/api/v1/account/me")
    }

    func updatePreferences(_ prefs: CustomerPreferencesRecord) async throws -> CustomerPreferencesRecord {
        let data = try encoder.encode(prefs)
        return try await send(path: "/api/v1/account/preferences", method: "PATCH", bodyData: data)
    }

    func addAddress(_ address: AddressRecord) async throws -> AddressRecord {
        let data = try encoder.encode(address)
        return try await send(path: "/api/v1/account/addresses", method: "POST", bodyData: data)
    }

    func deleteAddress(id: String) async throws {
        struct Ack: Decodable { let deleted: String }
        let _: Ack = try await send(path: "/api/v1/account/addresses/\(id)", method: "DELETE")
    }

    func revokeSession(id: String) async throws {
        struct Ack: Decodable { let revoked: String }
        let _: Ack = try await send(path: "/api/v1/account/sessions/\(id)/revoke", method: "POST")
    }

    func requestAccountDeletion() async throws {
        struct Ack: Decodable { let status: String }
        let _: Ack = try await send(path: "/api/v1/account/deletion-request", method: "POST")
    }

    func fetchSavedProducts() async throws -> [ProductCard] {
        try await send(path: "/api/v1/account/saved")
    }

    func setProductSaved(productId: String, variantId: String?, saved: Bool) async throws {
        struct Ack: Decodable { let saved: Bool }
        if saved {
            var q: [URLQueryItem] = []
            if let variantId { q.append(URLQueryItem(name: "preferred_variant_id", value: variantId)) }
            let _: Ack = try await send(path: "/api/v1/account/saved/\(productId)", method: "POST", queryItems: q)
        } else {
            let _: Ack = try await send(path: "/api/v1/account/saved/\(productId)", method: "DELETE")
        }
    }

    func sendAssistantMessage(_ message: String, confirmToken: String?) async throws -> AssistantChatPayload {
        struct Body: Encodable { let message: String; let confirmActionToken: String? }
        let data = try encoder.encode(Body(message: message, confirmActionToken: confirmToken))
        return try await send(path: "/api/v1/assistant/chat", method: "POST", bodyData: data)
    }
}
