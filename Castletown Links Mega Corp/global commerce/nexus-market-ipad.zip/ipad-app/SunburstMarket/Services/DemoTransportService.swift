import Foundation

/// In-memory deterministic CommerceTransport used for SwiftUI Previews, XCTest, and offline walkthroughs
/// when the local Docker FastAPI server is not running. Enforces identical business rules (minor-unit
/// server pricing, variant stock locks, promotion precedence, idempotent checkout, and refund caps).
actor DemoTransportService: CommerceTransport {
    private var token: String? = "demo_local_token"
    private var sellers: [SellerSummary]
    private var categories: [CategoryItem]
    private var products: [ProductDetail]
    private var savedIds: Set<String> = ["prod_ceramic_kettle", "prod_canvas_tote"]
    private var recentIds: [String] = ["prod_brass_pen", "prod_gan_charger"]
    private var bagEntries: [(id: String, productId: String, variantId: String, quantity: Int, status: String, snapshotMinor: Int)] = []
    private var orders: [OrderRecord] = []
    private var idempotencyCache: [String: CheckoutConfirmPayload] = [:]
    private var addresses: [AddressRecord]
    private var preferences = CustomerPreferencesRecord(
        destinationCountry: "US",
        destinationPostal: "94107",
        currency: "USD",
        orderUpdatesEnabled: true,
        promoAlertsEnabled: false,
        priceDropAlertsEnabled: true
    )
    private var sessions: [DeviceSessionRecord]

    init() {
        let now = Date()
        let hearth = SellerSummary(
            id: "sel_hearth", name: "Hearth & Loom Studio", slug: "hearth-and-loom",
            dispatchCity: "Portland, OR", dispatchCountry: "US",
            freeShippingThresholdMinor: 3500, baseShippingMinor: 499,
            returnWindowDays: 30,
            returnPolicySummary: "Free 30-day returns in unused original packaging; return shipping covered for damaged items.",
            verifiedBadge: true
        )
        let kora = SellerSummary(
            id: "sel_kora", name: "Kora Deskworks", slug: "kora-deskworks",
            dispatchCity: "Austin, TX", dispatchCountry: "US",
            freeShippingThresholdMinor: 3000, baseShippingMinor: 399,
            returnWindowDays: 45,
            returnPolicySummary: "45-day stationery & desk accessory return window.",
            verifiedBadge: true
        )
        let verve = SellerSummary(
            id: "sel_verve", name: "Verve Everyday Goods", slug: "verve-everyday",
            dispatchCity: "Chicago, IL", dispatchCountry: "US",
            freeShippingThresholdMinor: 4000, baseShippingMinor: 549,
            returnWindowDays: 30,
            returnPolicySummary: "30-day apparel & carry returns with tags attached.",
            verifiedBadge: true
        )
        let solstice = SellerSummary(
            id: "sel_solstice", name: "Solstice MicroTech", slug: "solstice-microtech",
            dispatchCity: "San Jose, CA", dispatchCountry: "US",
            freeShippingThresholdMinor: 4500, baseShippingMinor: 599,
            returnWindowDays: 30,
            returnPolicySummary: "30-day returns plus 1-year limited replacement warranty.",
            verifiedBadge: true
        )
        self.sellers = [hearth, kora, verve, solstice]

        let catHome = CategoryItem(id: "cat_homeware", name: "Homeware", slug: "homeware", iconName: "lamp.table.fill", description: "Ceramics, lighting, and compact kitchen tools.")
        let catAcc = CategoryItem(id: "cat_accessories", name: "Accessories", slug: "accessories", iconName: "bag.fill", description: "Everyday carry totes and organizers.")
        let catStat = CategoryItem(id: "cat_stationery", name: "Stationery", slug: "stationery", iconName: "pencil.and.ruler.fill", description: "Fountain-friendly notebooks and brass pens.")
        let catCloth = CategoryItem(id: "cat_clothing", name: "Clothing", slug: "clothing", iconName: "tshirt.fill", description: "Heavyweight organic cotton tees and knitwear.")
        let catElec = CategoryItem(id: "cat_electronics", name: "Small Electronics", slug: "small-electronics", iconName: "bolt.fill", description: "GaN chargers and task light bars.")
        self.categories = [catHome, catAcc, catStat, catCloth, catElec]

        let refDate = now.addingTimeInterval(-86400 * 14)

        self.products = [
            ProductDetail(
                id: "prod_ceramic_kettle",
                title: "Matte Stoneware Pour-Over Kettle",
                subtitle: "Precision gooseneck spout with insulated walnut handle",
                description: "Crafted from thermal-shock-resistant stoneware and 304 stainless inner liner for steady pour-over extraction.",
                category: catHome, seller: hearth,
                dimensionsCm: "24 x 13 x 16 cm", weightGrams: 740,
                materials: ["Glazed Stoneware", "304 Stainless Steel", "Oiled Walnut"],
                shippingRestrictions: [:],
                delivery: DeliverySummary(estimatedWindow: "3–5 business days (estimated)", guaranteedBy: "Guaranteed within 6 business days", isGuaranteed: true, eligibleForDestination: true, restrictionReason: nil),
                variants: [
                    ProductVariantItem(id: "var_kettle_terracotta", sku: "HLS-KTL-TER", title: "Terracotta / 800ml", attributes: ["color": "Terracotta", "capacity": "800ml"], currency: "USD", priceMinor: 2890, referencePriceMinor: 3490, referencePriceBasis: "Previous price 30-day record", availableStock: 18, isActive: true, priceHistory: [PriceHistoryEntry(id: "ph1", priceMinor: 3490, currency: "USD", reason: "Standard catalog price", recordedAt: refDate)]),
                    ProductVariantItem(id: "var_kettle_charcoal", sku: "HLS-KTL-CHR", title: "Charcoal / 800ml", attributes: ["color": "Charcoal", "capacity": "800ml"], currency: "USD", priceMinor: 2990, referencePriceMinor: nil, referencePriceBasis: nil, availableStock: 12, isActive: true, priceHistory: []),
                ],
                images: [ProductImageItem(id: "img_k1", variantId: "var_kettle_terracotta", url: "demo://kettle/terracotta", altText: "Terracotta Kettle", sortOrder: 0)],
                documents: [ProductDocumentItem(id: "doc_k1", title: "Care & Brewing Guide", docType: "manual", url: "demo://doc/kettle", summary: "Hand-wash only; rated up to 100°C.")],
                reviews: [ProductReviewItem(id: "rev_k1", variantTitle: "Terracotta / 800ml", authorDisplay: "Elena M.", rating: 5, title: "Balanced pour without wrist strain", body: "Handle stays cool and flow rate is easy to control.", verifiedDemoPurchase: true, createdAt: refDate)],
                ratingAverage: 5.0, isSaved: true
            ),
            ProductDetail(
                id: "prod_brass_pen",
                title: "Machined Brass Rollerball Pen",
                subtitle: "Refillable 0.5mm ceramic roller with knurled grip",
                description: "Solid C36000 brass barrel weighted for relaxed note-taking, compatible with standard Euro refills.",
                category: catStat, seller: kora,
                dimensionsCm: "13.8 x 1.0 x 1.0 cm", weightGrams: 46,
                materials: ["Solid C36000 Brass", "Stainless Clip"],
                shippingRestrictions: [:],
                delivery: DeliverySummary(estimatedWindow: "2–4 business days (estimated)", guaranteedBy: "Guaranteed within 5 business days", isGuaranteed: true, eligibleForDestination: true, restrictionReason: nil),
                variants: [
                    ProductVariantItem(id: "var_pen_raw", sku: "KOR-PEN-RAW", title: "Raw Brushed Brass / 0.5mm", attributes: ["color": "Brass", "tip": "0.5mm"], currency: "USD", priceMinor: 2200, referencePriceMinor: 2600, referencePriceBasis: "Previous price 30-day record", availableStock: 32, isActive: true, priceHistory: []),
                    ProductVariantItem(id: "var_pen_matte", sku: "KOR-PEN-BLK", title: "PVD Matte Black / 0.5mm", attributes: ["color": "Matte Black", "tip": "0.5mm"], currency: "USD", priceMinor: 2450, referencePriceMinor: nil, referencePriceBasis: nil, availableStock: 15, isActive: true, priceHistory: []),
                ],
                images: [ProductImageItem(id: "img_p1", variantId: "var_pen_raw", url: "demo://pen/brass", altText: "Brass Pen", sortOrder: 0)],
                documents: [ProductDocumentItem(id: "doc_p1", title: "Refill Compatibility Sheet", docType: "spec_sheet", url: "demo://doc/pen", summary: "Fits Schmidt 5888 & Pilot G2 style ceramic refills.")],
                reviews: [ProductReviewItem(id: "rev_p1", variantTitle: "Raw Brushed Brass / 0.5mm", authorDisplay: "Nadia K.", rating: 5, title: "Zero ink skipping", body: "Feels substantial in hand with zero tip wobble.", verifiedDemoPurchase: true, createdAt: refDate)],
                ratingAverage: 5.0, isSaved: false
            ),
            ProductDetail(
                id: "prod_dot_notebook",
                title: "Lay-Flat 120gsm Dot Grid Notebook",
                subtitle: "Thread-sewn 192 numbered pages with index",
                description: "Acid-free 120gsm ivory paper that resists fountain pen bleed-through, bound in tactile bookcloth.",
                category: catStat, seller: kora,
                dimensionsCm: "21.0 x 14.8 x 1.8 cm", weightGrams: 380,
                materials: ["120gsm FSC Paper", "Linen Bookcloth"],
                shippingRestrictions: [:],
                delivery: DeliverySummary(estimatedWindow: "2–5 business days (estimated)", guaranteedBy: "Guaranteed within 6 business days", isGuaranteed: true, eligibleForDestination: true, restrictionReason: nil),
                variants: [
                    ProductVariantItem(id: "var_nb_persimmon", sku: "KOR-NB-PER", title: "Persimmon A5 / Dot Grid", attributes: ["color": "Persimmon", "size": "A5"], currency: "USD", priceMinor: 1450, referencePriceMinor: nil, referencePriceBasis: nil, availableStock: 40, isActive: true, priceHistory: []),
                    ProductVariantItem(id: "var_nb_ink", sku: "KOR-NB-INK", title: "Deep Charcoal A5 / Dot Grid", attributes: ["color": "Charcoal", "size": "A5"], currency: "USD", priceMinor: 1450, referencePriceMinor: nil, referencePriceBasis: nil, availableStock: 28, isActive: true, priceHistory: []),
                ],
                images: [ProductImageItem(id: "img_n1", variantId: "var_nb_persimmon", url: "demo://notebook/persimmon", altText: "Persimmon Notebook", sortOrder: 0)],
                documents: [],
                reviews: [],
                ratingAverage: nil, isSaved: false
            ),
            ProductDetail(
                id: "prod_canvas_tote",
                title: "16oz Waxed Canvas Commuter Tote",
                subtitle: "Padded 13-inch tablet sleeve & magnetic closure",
                description: "Water-resistant dry-waxed cotton canvas with six interior pockets and reinforced webbing straps.",
                category: catAcc, seller: verve,
                dimensionsCm: "38 x 31 x 13 cm", weightGrams: 620,
                materials: ["16oz Waxed Cotton Canvas", "Recycled Nylon Liner"],
                shippingRestrictions: [:],
                delivery: DeliverySummary(estimatedWindow: "3–5 business days (estimated)", guaranteedBy: "Guaranteed within 6 business days", isGuaranteed: true, eligibleForDestination: true, restrictionReason: nil),
                variants: [
                    ProductVariantItem(id: "var_tote_rust", sku: "VRV-TOT-RST", title: "Burnt Sienna / Medium", attributes: ["color": "Sienna", "size": "Medium"], currency: "USD", priceMinor: 3650, referencePriceMinor: 4200, referencePriceBasis: "Previous price 30-day record", availableStock: 16, isActive: true, priceHistory: []),
                    ProductVariantItem(id: "var_tote_olive", sku: "VRV-TOT-OLV", title: "Field Olive / Medium", attributes: ["color": "Olive", "size": "Medium"], currency: "USD", priceMinor: 3650, referencePriceMinor: nil, referencePriceBasis: nil, availableStock: 21, isActive: true, priceHistory: []),
                ],
                images: [ProductImageItem(id: "img_t1", variantId: "var_tote_rust", url: "demo://tote/sienna", altText: "Commuter Tote", sortOrder: 0)],
                documents: [],
                reviews: [ProductReviewItem(id: "rev_t1", variantTitle: "Burnt Sienna / Medium", authorDisplay: "Priya S.", rating: 5, title: "Fits iPad Pro effortlessly", body: "Stands upright and fits an iPad with Magic Keyboard.", verifiedDemoPurchase: true, createdAt: refDate)],
                ratingAverage: 5.0, isSaved: true
            ),
            ProductDetail(
                id: "prod_heavy_tee",
                title: "280gsm Organic Cotton Boxy Tee",
                subtitle: "Pre-shrunk combed ring-spun jersey",
                description: "Structured heavyweight everyday tee with reinforced double-needle collar.",
                category: catCloth, seller: verve,
                dimensionsCm: "Folded 30 x 24 x 3 cm", weightGrams: 310,
                materials: ["100% Organic Ring-Spun Cotton"],
                shippingRestrictions: [:],
                delivery: DeliverySummary(estimatedWindow: "3–6 business days (estimated)", guaranteedBy: nil, isGuaranteed: false, eligibleForDestination: true, restrictionReason: nil),
                variants: [
                    ProductVariantItem(id: "var_tee_chalk_m", sku: "VRV-TEE-CHK-M", title: "Chalk White / Size M", attributes: ["color": "Chalk", "size": "M"], currency: "USD", priceMinor: 1690, referencePriceMinor: 2100, referencePriceBasis: "Previous price 30-day record", availableStock: 22, isActive: true, priceHistory: []),
                    ProductVariantItem(id: "var_tee_charcoal_m", sku: "VRV-TEE-CHR-M", title: "Charcoal / Size M", attributes: ["color": "Charcoal", "size": "M"], currency: "USD", priceMinor: 1690, referencePriceMinor: nil, referencePriceBasis: nil, availableStock: 2, isActive: true, priceHistory: []),
                    ProductVariantItem(id: "var_tee_tangerine_s", sku: "VRV-TEE-TAN-S", title: "Tangerine / Size S", attributes: ["color": "Tangerine", "size": "S"], currency: "USD", priceMinor: 1750, referencePriceMinor: nil, referencePriceBasis: nil, availableStock: 0, isActive: true, priceHistory: []),
                ],
                images: [ProductImageItem(id: "img_c1", variantId: "var_tee_chalk_m", url: "demo://tee/chalk", altText: "Boxy Tee", sortOrder: 0)],
                documents: [],
                reviews: [ProductReviewItem(id: "rev_c1", variantTitle: "Chalk White / Size M", authorDisplay: "Liam C.", rating: 4, title: "Thick fabric with great drape", body: "Collar keeps its shape after multiple washes.", verifiedDemoPurchase: true, createdAt: refDate)],
                ratingAverage: 4.0, isSaved: false
            ),
            ProductDetail(
                id: "prod_gan_charger",
                title: "65W Dual-Port GaN USB-C Charger",
                subtitle: "Foldable US prongs with braided 2m USB-C cable",
                description: "Compact gallium-nitride power brick delivering 65W single-port or 45W+20W split PD 3.0 output.",
                category: catElec, seller: solstice,
                dimensionsCm: "5.2 x 5.2 x 2.9 cm", weightGrams: 128,
                materials: ["Flame-Retardant Polycarbonate", "GaN Power Stage"],
                shippingRestrictions: ["allowed_countries": .array(["US", "CA"]), "reason": .string("US Type-A plug certified for North America (US/CA) only.")],
                delivery: DeliverySummary(estimatedWindow: "2–4 business days (estimated)", guaranteedBy: "Guaranteed within 4 business days", isGuaranteed: true, eligibleForDestination: true, restrictionReason: nil),
                variants: [
                    ProductVariantItem(id: "var_gan_white", sku: "SOL-GAN-WHT", title: "Matte White / US Plug", attributes: ["color": "White", "plug": "US Type-A"], currency: "USD", priceMinor: 2590, referencePriceMinor: 3290, referencePriceBasis: "Previous price 30-day record", availableStock: 25, isActive: true, priceHistory: []),
                    ProductVariantItem(id: "var_gan_charcoal", sku: "SOL-GAN-CHR", title: "Charcoal / US Plug", attributes: ["color": "Charcoal", "plug": "US Type-A"], currency: "USD", priceMinor: 2690, referencePriceMinor: nil, referencePriceBasis: nil, availableStock: 19, isActive: true, priceHistory: []),
                ],
                images: [ProductImageItem(id: "img_g1", variantId: "var_gan_white", url: "demo://charger/white", altText: "GaN Charger", sortOrder: 0)],
                documents: [ProductDocumentItem(id: "doc_g1", title: "UL/FCC Compliance Summary", docType: "compliance", url: "demo://doc/gan", summary: "Over-voltage & thermal cutoff verified at 65W.")],
                reviews: [ProductReviewItem(id: "rev_g1", variantTitle: "Matte White / US Plug", authorDisplay: "Hannah W.", rating: 5, title: "Runs cool under 65W load", body: "Charges iPad Pro and phone simultaneously.", verifiedDemoPurchase: true, createdAt: refDate)],
                ratingAverage: 5.0, isSaved: false
            ),
        ]

        self.addresses = [
            AddressRecord(
                id: "addr_demo_home",
                label: "Home Studio",
                recipientName: "Alex Rivera",
                line1: "742 Market Street",
                line2: "Suite 4B",
                city: "San Francisco",
                region: "CA",
                postalCode: "94107",
                countryCode: "US",
                isDefault: true
            )
        ]

        self.sessions = [
            DeviceSessionRecord(id: "ses_demo_ipad", deviceName: "iPad Pro 13-inch", platform: "iPadOS", lastActiveAt: now, revokedAt: nil, isCurrent: true)
        ]

        self.orders = [
            OrderRecord(
                id: "ord_demo_history",
                orderNumber: "SM-DEMO1042",
                orderStatus: "confirmed",
                paymentStatus: "paid",
                fulfillmentStatus: "in_transit",
                currency: "USD",
                subtotalMinor: 3650,
                discountMinor: 547,
                shippingMinor: 499,
                taxMinor: 256,
                totalMinor: 3858,
                deliveryMethod: "standard",
                discountExplanation: "WELCOME15 (v1): 15% off eligible subtotal $36.50 = -$5.47",
                isDemoOrder: true,
                createdAt: now.addingTimeInterval(-86400 * 2),
                fulfillments: [
                    OrderFulfillmentRecord(
                        id: "ful_demo_history",
                        sellerId: verve.id,
                        sellerName: verve.name,
                        status: "in_transit",
                        carrierName: "Sunburst Parcel (Synthetic)",
                        trackingNumber: "SYN-DEMO88421A",
                        shippingMinor: 499,
                        estimatedWindow: "3–5 business days (estimated)",
                        guaranteedBy: "Guaranteed within 6 business days",
                        exceptionNote: nil,
                        events: [
                            TrackingEventRecord(timestamp: ISO8601DateFormatter().string(from: now.addingTimeInterval(-86400 * 2)), status: "label_created", location: "Chicago, IL", detail: "Demo payment settled. Synthetic label created.", isSynthetic: true),
                            TrackingEventRecord(timestamp: ISO8601DateFormatter().string(from: now.addingTimeInterval(-86400)), status: "in_transit", location: "Denver Hub", detail: "Departed sorting facility (synthetic event).", isSynthetic: true),
                        ],
                        items: [
                            OrderItemRecord(id: "oi_demo_history", productId: "prod_canvas_tote", variantId: "var_tote_rust", sku: "VRV-TOT-RST", productTitle: "16oz Waxed Canvas Commuter Tote", variantSummary: "Burnt Sienna / Medium", imageUrl: "demo://tote/sienna", currency: "USD", unitPriceMinor: 3650, quantity: 1, lineTotalMinor: 3650)
                        ]
                    )
                ],
                returns: [],
                supportMessages: []
            )
        ]
    }

    func updateToken(_ token: String?) {
        self.token = token
    }

    // MARK: - Demo Edge Case Triggers
    func simulateServerPriceChangeOnFirstBagItem() {
        guard !bagEntries.isEmpty else { return }
        let targetVariantId = bagEntries[0].variantId
        if let pIdx = products.firstIndex(where: { $0.variants.contains(where: { $0.id == targetVariantId }) }),
           let vIdx = products[pIdx].variants.firstIndex(where: { $0.id == targetVariantId }) {
            var variants = products[pIdx].variants
            let old = variants[vIdx]
            let newPrice = old.priceMinor + 300
            variants[vIdx] = ProductVariantItem(
                id: old.id, sku: old.sku, title: old.title, attributes: old.attributes,
                currency: old.currency, priceMinor: newPrice,
                referencePriceMinor: old.referencePriceMinor, referencePriceBasis: old.referencePriceBasis,
                availableStock: old.availableStock, isActive: old.isActive, priceHistory: old.priceHistory
            )
            let p = products[pIdx]
            products[pIdx] = ProductDetail(
                id: p.id, title: p.title, subtitle: p.subtitle, description: p.description,
                category: p.category, seller: p.seller, dimensionsCm: p.dimensionsCm,
                weightGrams: p.weightGrams, materials: p.materials,
                shippingRestrictions: p.shippingRestrictions, delivery: p.delivery,
                variants: variants, images: p.images, documents: p.documents,
                reviews: p.reviews, ratingAverage: p.ratingAverage, isSaved: p.isSaved
            )
        }
    }

    // MARK: - Helpers
    private func card(for p: ProductDetail, country: String, reason: String? = nil) -> ProductCard {
        let eligible = !(p.id == "prod_gan_charger" && !["US", "CA"].contains(country.uppercased()))
        let restriction = eligible ? nil : "US Type-A plug certified for North America (US/CA) only."
        let delivery = DeliverySummary(
            estimatedWindow: p.delivery.estimatedWindow,
            guaranteedBy: eligible ? p.delivery.guaranteedBy : nil,
            isGuaranteed: eligible && p.delivery.guaranteedBy != nil,
            eligibleForDestination: eligible,
            restrictionReason: restriction
        )
        let cheapest = p.variants.min(by: { $0.priceMinor < $1.priceMinor }) ?? p.variants[0]
        let swatches = p.variants.compactMap { $0.attributes["color"] }
        return ProductCard(
            id: p.id, title: p.title, subtitle: p.subtitle,
            categoryId: p.category.id, categoryName: p.category.name,
            seller: p.seller,
            primaryImageUrl: p.images.first?.url ?? "",
            startingPriceMinor: cheapest.priceMinor,
            referencePriceMinor: cheapest.referencePriceMinor,
            currency: cheapest.currency,
            variantCount: p.variants.count,
            variantSwatches: swatches,
            inStock: p.variants.contains(where: { $0.availableStock > 0 }),
            delivery: delivery,
            ratingAverage: p.ratingAverage,
            reviewCount: p.reviews.count,
            recommendationReason: reason
        )
    }

    func fetchDiscover(country: String, postal: String) async throws -> DiscoverPayload {
        let banner = PromotionBanner(
            id: "promo_welcome15_v1",
            code: "WELCOME15",
            version: 1,
            title: "15% Off Orders $25+ (Code: WELCOME15)",
            description: "Save 15% up to $20 on eligible items. Stackable with DESK10 on Stationery.",
            endsAt: Date().addingTimeInterval(3600 * 36)
        )
        let featured = products.map { card(for: $0, country: country, reason: "Featured catalog selection") }
        let recent = products.filter { recentIds.contains($0.id) }.map { card(for: $0, country: country, reason: "Recently viewed on your account") }
        let collections = [
            RecommendedCollection(
                id: "col_desk",
                title: "Focused Desk & Studio Tools",
                explanation: "Explainability rule: Stationery & Electronics with verified stock.",
                products: products.filter { ["cat_stationery", "cat_electronics"].contains($0.category.id) }.map { card(for: $0, country: country, reason: "Desk & Studio rule match") }
            ),
            RecommendedCollection(
                id: "col_carry",
                title: "Everyday Carry & Homeware",
                explanation: "Explainability rule: Homeware, Accessories & Clothing bestsellers.",
                products: products.filter { ["cat_homeware", "cat_accessories", "cat_clothing"].contains($0.category.id) }.map { card(for: $0, country: country, reason: "Everyday essentials rule match") }
            )
        ]
        return DiscoverPayload(
            destinationCountry: country,
            destinationPostal: postal,
            banner: banner,
            categories: categories,
            featuredProducts: featured,
            recentlyViewed: recent,
            collections: collections
        )
    }

    func searchCatalog(filters: SearchFilters, country: String, page: Int, pageSize: Int) async throws -> SearchResultsPayload {
        var matched = products.filter { p in
            if !filters.query.trimmingCharacters(in: .whitespaces).isEmpty {
                let q = filters.query.lowercased()
                let hay = "\(p.title) \(p.subtitle) \(p.description) \(p.seller.name) \(p.category.name)".lowercased()
                if !hay.contains(q) { return false }
            }
            if let cat = filters.categoryId, p.category.id != cat { return false }
            if let sel = filters.sellerId, p.seller.id != sel { return false }
            if filters.inStockOnly && !p.variants.contains(where: { $0.availableStock > 0 }) { return false }
            if filters.eligibleOnly && !card(for: p, country: country).delivery.eligibleForDestination { return false }
            if let minP = filters.minPriceMinor, !p.variants.contains(where: { $0.priceMinor >= minP }) { return false }
            if let maxP = filters.maxPriceMinor, !p.variants.contains(where: { $0.priceMinor <= maxP }) { return false }
            return true
        }
        if filters.sort == "price_asc" {
            matched.sort { ($0.variants.map(\.priceMinor).min() ?? 0) < ($1.variants.map(\.priceMinor).min() ?? 0) }
        } else if filters.sort == "price_desc" {
            matched.sort { ($0.variants.map(\.priceMinor).min() ?? 0) > ($1.variants.map(\.priceMinor).min() ?? 0) }
        }
        let cards = matched.map { card(for: $0, country: country) }
        return SearchResultsPayload(items: cards, total: cards.count, page: page, pageSize: pageSize, hasNext: false)
    }

    func fetchCategories() async throws -> [CategoryItem] { categories }
    func fetchSellers() async throws -> [SellerSummary] { sellers }

    func fetchProductDetail(productId: String, country: String) async throws -> ProductDetail {
        guard let p = products.first(where: { $0.id == productId }) else {
            throw APIError.serverError(statusCode: 404, message: "Product not found")
        }
        recentIds.removeAll(where: { $0 == productId })
        recentIds.insert(productId, at: 0)
        let c = card(for: p, country: country)
        return ProductDetail(
            id: p.id, title: p.title, subtitle: p.subtitle, description: p.description,
            category: p.category, seller: p.seller, dimensionsCm: p.dimensionsCm,
            weightGrams: p.weightGrams, materials: p.materials,
            shippingRestrictions: p.shippingRestrictions, delivery: c.delivery,
            variants: p.variants, images: p.images, documents: p.documents,
            reviews: p.reviews, ratingAverage: p.ratingAverage, isSaved: savedIds.contains(p.id)
        )
    }

    func fetchBag(country: String) async throws -> BagPayload {
        var groupsBySeller: [String: (SellerSummary, [BagLineItem])] = [:]
        var saved: [BagLineItem] = []
        var notices: [String] = []
        var hasBlocking = false

        for entry in bagEntries {
            guard let p = products.first(where: { $0.id == entry.productId }),
                  let v = p.variants.first(where: { $0.id == entry.variantId }) else { continue }
            let c = card(for: p, country: country)
            let priceChanged = entry.snapshotMinor != v.priceMinor
            let stockBad = v.availableStock < entry.quantity
            var lineNotice: [String] = []
            if priceChanged {
                let m = "Price changed for \(p.title) (\(v.title)): was \(MoneyFormatter.format(minor: entry.snapshotMinor)), now \(MoneyFormatter.format(minor: v.priceMinor))."
                lineNotice.append(m); notices.append(m)
            }
            if stockBad {
                let m = "Only \(v.availableStock) left for \(p.title) (\(v.title))."
                lineNotice.append(m); notices.append(m)
                if entry.status == "active" { hasBlocking = true }
            }
            if !c.delivery.eligibleForDestination {
                let m = c.delivery.restrictionReason ?? "Restricted for \(country)."
                lineNotice.append(m); notices.append(m)
                if entry.status == "active" { hasBlocking = true }
            }
            let line = BagLineItem(
                id: entry.id, productId: p.id, variantId: v.id, sku: v.sku,
                productTitle: p.title, variantTitle: v.title, availableVariants: p.variants,
                imageUrl: p.images.first?.url ?? "", quantity: entry.quantity,
                unitPriceMinor: v.priceMinor, previousUnitPriceMinor: entry.snapshotMinor,
                lineTotalMinor: v.priceMinor * entry.quantity, currency: v.currency,
                availableStock: v.availableStock, status: entry.status,
                priceChanged: priceChanged, stockInsufficient: stockBad,
                noticeMessage: lineNotice.isEmpty ? nil : lineNotice.joined(separator: " "),
                eligibleForDestination: c.delivery.eligibleForDestination,
                restrictionReason: c.delivery.restrictionReason
            )
            if entry.status == "saved_for_later" {
                saved.append(line)
            } else {
                var tuple = groupsBySeller[p.seller.id] ?? (p.seller, [])
                tuple.1.append(line)
                groupsBySeller[p.seller.id] = tuple
            }
        }

        var sellerGroups: [BagSellerGroup] = []
        var subTotal = 0
        var shipTotal = 0
        for (_, (seller, items)) in groupsBySeller {
            let sub = items.reduce(0) { $0 + $1.lineTotalMinor }
            let ship = sub >= seller.freeShippingThresholdMinor ? 0 : seller.baseShippingMinor
            subTotal += sub
            shipTotal += ship
            sellerGroups.append(BagSellerGroup(
                seller: seller, items: items, subtotalMinor: sub,
                estimatedShippingMinor: ship,
                freeShippingRemainingMinor: max(0, seller.freeShippingThresholdMinor - sub)
            ))
        }
        return BagPayload(
            destinationCountry: country, currency: "USD",
            sellerGroups: sellerGroups, savedForLater: saved,
            subtotalMinor: subTotal, estimatedShippingMinor: shipTotal,
            hasBlockingIssues: hasBlocking, notices: notices
        )
    }

    func addToBag(productId: String, variantId: String, quantity: Int, country: String) async throws -> BagPayload {
        guard let p = products.first(where: { $0.id == productId }),
              let v = p.variants.first(where: { $0.id == variantId }) else {
            throw APIError.serverError(statusCode: 404, message: "Variant not found")
        }
        if let idx = bagEntries.firstIndex(where: { $0.variantId == variantId && $0.status == "active" }) {
            let nextQty = bagEntries[idx].quantity + quantity
            guard v.availableStock >= nextQty else {
                throw APIError.serverError(statusCode: 409, message: "Insufficient stock: only \(v.availableStock) available.")
            }
            bagEntries[idx].quantity = nextQty
            bagEntries[idx].snapshotMinor = v.priceMinor
        } else {
            guard v.availableStock >= quantity else {
                throw APIError.serverError(statusCode: 409, message: "Insufficient stock: only \(v.availableStock) available.")
            }
            bagEntries.append((id: "bag_\(UUID().uuidString.prefix(8))", productId: productId, variantId: variantId, quantity: quantity, status: "active", snapshotMinor: v.priceMinor))
        }
        return try await fetchBag(country: country)
    }

    func updateBagItem(itemId: String, quantity: Int?, variantId: String?, status: String?, country: String) async throws -> BagPayload {
        guard let idx = bagEntries.firstIndex(where: { $0.id == itemId }) else {
            throw APIError.serverError(statusCode: 404, message: "Bag item not found")
        }
        let targetVariant = variantId ?? bagEntries[idx].variantId
        let targetQty = quantity ?? bagEntries[idx].quantity
        let targetStatus = status ?? bagEntries[idx].status
        if let p = products.first(where: { $0.id == bagEntries[idx].productId }),
           let v = p.variants.first(where: { $0.id == targetVariant }) {
            if targetStatus == "active" && v.availableStock < targetQty {
                throw APIError.serverError(statusCode: 409, message: "Only \(v.availableStock) units available for \(v.title).")
            }
            bagEntries[idx].variantId = targetVariant
            bagEntries[idx].quantity = targetQty
            bagEntries[idx].status = targetStatus
            bagEntries[idx].snapshotMinor = v.priceMinor
        }
        return try await fetchBag(country: country)
    }

    func removeBagItem(itemId: String, country: String) async throws -> BagPayload {
        bagEntries.removeAll(where: { $0.id == itemId })
        return try await fetchBag(country: country)
    }

    func acknowledgeBagChanges(country: String) async throws -> BagPayload {
        for i in bagEntries.indices {
            if let p = products.first(where: { $0.id == bagEntries[i].productId }),
               let v = p.variants.first(where: { $0.id == bagEntries[i].variantId }) {
                bagEntries[i].snapshotMinor = v.priceMinor
            }
        }
        return try await fetchBag(country: country)
    }

    func previewCheckout(address: AddressRecord, deliveryMethod: String, promoCodes: [String]) async throws -> CheckoutPreviewPayload {
        let bag = try await fetchBag(country: address.countryCode)
        guard !bag.sellerGroups.isEmpty else {
            throw APIError.serverError(statusCode: 400, message: "Shopping bag is empty.")
        }
        if bag.hasBlockingIssues {
            throw APIError.serverError(statusCode: 409, message: bag.notices.first ?? "Resolve bag availability issues before checkout.")
        }

        var applied: [AppliedPromotionItem] = []
        var rejected: [[String: String]] = []
        var discountMinor = 0
        let codes = promoCodes.map { $0.trimmingCharacters(in: .whitespaces).uppercased() }.filter { !$0.isEmpty }

        for code in codes {
            if code == "WELCOME15" {
                if bag.subtotalMinor >= 2500 {
                    let d = min((bag.subtotalMinor * 1500) / 10000, 2000)
                    discountMinor += d
                    applied.append(AppliedPromotionItem(id: "promo_welcome15_v1", code: "WELCOME15", version: 1, title: "15% Off Orders $25+", discountMinor: d, explanation: "WELCOME15 (v1): 15% off eligible items = -\(MoneyFormatter.format(minor: d))"))
                } else {
                    rejected.append(["code": code, "reason": "Requires $25.00 minimum eligible spend."])
                }
            } else if code == "DESK10" {
                let statSub = bag.sellerGroups.flatMap(\.items).filter { item in
                    products.first(where: { $0.id == item.productId })?.category.id == "cat_stationery"
                }.reduce(0) { $0 + $1.lineTotalMinor }
                if statSub >= 3000 {
                    discountMinor += 1000
                    applied.append(AppliedPromotionItem(id: "promo_desk10_v1", code: "DESK10", version: 1, title: "$10 Off Stationery", discountMinor: 1000, explanation: "DESK10 (v1): $10.00 off Stationery ($30+) = -$10.00"))
                } else {
                    rejected.append(["code": code, "reason": "Requires $30.00 in Stationery items."])
                }
            } else {
                rejected.append(["code": code, "reason": "Promotion code not recognized."])
            }
        }

        let extraShip = deliveryMethod == "express" ? 799 : 0
        let breakdowns = bag.sellerGroups.map { g in
            CheckoutSellerBreakdown(
                sellerId: g.seller.id, sellerName: g.seller.name,
                subtotalMinor: g.subtotalMinor,
                shippingMinor: g.estimatedShippingMinor + extraShip,
                estimatedWindow: deliveryMethod == "express" ? "1–3 business days (estimated)" : "3–5 business days (estimated)",
                guaranteedBy: "Guaranteed within 6 business days",
                itemCount: g.items.reduce(0) { $0 + $1.quantity }
            )
        }
        let shippingMinor = breakdowns.reduce(0) { $0 + $1.shippingMinor }
        let taxable = max(0, bag.subtotalMinor - discountMinor)
        let taxMinor = (taxable * 825 + 5000) / 10000
        return CheckoutPreviewPayload(
            currency: "USD",
            subtotalMinor: bag.subtotalMinor,
            discountMinor: discountMinor,
            shippingMinor: shippingMinor,
            taxMinor: taxMinor,
            totalMinor: taxable + shippingMinor + taxMinor,
            taxRateBps: 825,
            appliedPromotions: applied,
            rejectedPromotions: rejected,
            discountExplanation: applied.isEmpty ? "No promotional discounts applied." : applied.map(\.explanation).joined(separator: " | "),
            sellerBreakdowns: breakdowns,
            isDemoCheckout: true,
            notices: bag.notices
        )
    }

    func confirmCheckout(address: AddressRecord, deliveryMethod: String, promoCodes: [String], outcome: CheckoutSimulationOutcome, idempotencyKey: String) async throws -> CheckoutConfirmPayload {
        if let cached = idempotencyCache[idempotencyKey] {
            return CheckoutConfirmPayload(
                order: cached.order,
                paymentStatus: cached.paymentStatus,
                providerReference: cached.providerReference,
                replayedFromIdempotency: true,
                message: "Idempotent replay: returned existing order without creating a duplicate."
            )
        }
        let preview = try await previewCheckout(address: address, deliveryMethod: deliveryMethod, promoCodes: promoCodes)
        let bag = try await fetchBag(country: address.countryCode)
        let now = Date()
        let iso = ISO8601DateFormatter().string(from: now)

        let fulfillments = bag.sellerGroups.map { group in
            let ship = group.estimatedShippingMinor + (deliveryMethod == "express" ? 799 : 0)
            let orderItems = group.items.map { i in
                OrderItemRecord(
                    id: "oi_\(UUID().uuidString.prefix(8))", productId: i.productId, variantId: i.variantId,
                    sku: i.sku, productTitle: i.productTitle, variantSummary: i.variantTitle,
                    imageUrl: i.imageUrl, currency: i.currency, unitPriceMinor: i.unitPriceMinor,
                    quantity: i.quantity, lineTotalMinor: i.lineTotalMinor
                )
            }
            return OrderFulfillmentRecord(
                id: "ful_\(UUID().uuidString.prefix(8))",
                sellerId: group.seller.id, sellerName: group.seller.name,
                status: outcome == .success ? "label_created" : "awaiting_payment",
                carrierName: "Sunburst Parcel (Synthetic)",
                trackingNumber: "SYN-\(UUID().uuidString.prefix(8).uppercased())",
                shippingMinor: ship,
                estimatedWindow: deliveryMethod == "express" ? "1–3 business days (estimated)" : "3–5 business days (estimated)",
                guaranteedBy: "Guaranteed within 6 business days",
                exceptionNote: nil,
                events: [TrackingEventRecord(timestamp: iso, status: outcome == .success ? "label_created" : "order_created", location: group.seller.dispatchCity, detail: outcome == .success ? "Demo payment confirmed; synthetic label generated." : "Order created awaiting payment.", isSynthetic: true)],
                items: orderItems
            )
        }

        let pStatus = outcome == .success ? "paid" : (outcome == .failed ? "failed" : "uncertain")
        let oStatus = outcome == .success ? "confirmed" : (outcome == .failed ? "payment_failed" : "awaiting_reconciliation")
        let order = OrderRecord(
            id: "ord_\(UUID().uuidString.prefix(8))",
            orderNumber: "SM-\(UUID().uuidString.prefix(6).uppercased())",
            orderStatus: oStatus, paymentStatus: pStatus,
            fulfillmentStatus: outcome == .success ? "processing" : "unfulfilled",
            currency: preview.currency,
            subtotalMinor: preview.subtotalMinor, discountMinor: preview.discountMinor,
            shippingMinor: preview.shippingMinor, taxMinor: preview.taxMinor, totalMinor: preview.totalMinor,
            deliveryMethod: deliveryMethod, discountExplanation: preview.discountExplanation,
            isDemoOrder: true, createdAt: now, fulfillments: fulfillments, returns: [], supportMessages: []
        )
        orders.insert(order, at: 0)
        if outcome == .success {
            bagEntries.removeAll(where: { $0.status == "active" })
        }
        let result = CheckoutConfirmPayload(
            order: order,
            paymentStatus: pStatus,
            providerReference: "demo_pay_\(UUID().uuidString.prefix(10))",
            replayedFromIdempotency: false,
            message: outcome == .success
                ? "Demo payment confirmed! Order \(order.orderNumber) created."
                : (outcome == .failed ? "Simulated payment decline; inventory reservation released." : "Simulated lost response / timeout; retry safely with same idempotency key.")
        )
        idempotencyCache[idempotencyKey] = result
        return result
    }

    func fetchOrders() async throws -> [OrderRecord] { orders }
    func fetchOrderDetail(orderId: String) async throws -> OrderRecord {
        guard let o = orders.first(where: { $0.id == orderId }) else {
            throw APIError.serverError(statusCode: 404, message: "Order not found")
        }
        return o
    }

    func advanceTracking(orderId: String, simulateException: Bool) async throws -> OrderRecord {
        guard let idx = orders.firstIndex(where: { $0.id == orderId }) else {
            throw APIError.serverError(statusCode: 404, message: "Order not found")
        }
        let old = orders[idx]
        let steps = ["label_created", "in_transit", "out_for_delivery", "delivered"]
        let iso = ISO8601DateFormatter().string(from: Date())
        let updatedFulfillments = old.fulfillments.map { f in
            var nextStatus = "in_transit"
            if simulateException {
                nextStatus = "delivery_exception"
            } else if let curIdx = steps.firstIndex(of: f.status) {
                nextStatus = steps[min(curIdx + 1, steps.count - 1)]
            }
            let detail = simulateException
                ? "Synthetic weather hold at regional hub — rescheduled."
                : "Synthetic carrier event: \(nextStatus.replacingOccurrences(of: "_", with: " "))."
            let ev = TrackingEventRecord(timestamp: iso, status: nextStatus, location: "Regional Hub", detail: detail, isSynthetic: true)
            return OrderFulfillmentRecord(
                id: f.id, sellerId: f.sellerId, sellerName: f.sellerName, status: nextStatus,
                carrierName: f.carrierName, trackingNumber: f.trackingNumber, shippingMinor: f.shippingMinor,
                estimatedWindow: f.estimatedWindow, guaranteedBy: f.guaranteedBy,
                exceptionNote: simulateException ? detail : nil,
                events: f.events + [ev], items: f.items
            )
        }
        let allDelivered = updatedFulfillments.allSatisfy { $0.status == "delivered" }
        let updated = OrderRecord(
            id: old.id, orderNumber: old.orderNumber,
            orderStatus: allDelivered ? "delivered" : old.orderStatus,
            paymentStatus: old.paymentStatus,
            fulfillmentStatus: simulateException ? "exception" : (allDelivered ? "delivered" : "in_transit"),
            currency: old.currency, subtotalMinor: old.subtotalMinor, discountMinor: old.discountMinor,
            shippingMinor: old.shippingMinor, taxMinor: old.taxMinor, totalMinor: old.totalMinor,
            deliveryMethod: old.deliveryMethod, discountExplanation: old.discountExplanation,
            isDemoOrder: true, createdAt: old.createdAt, fulfillments: updatedFulfillments,
            returns: old.returns, supportMessages: old.supportMessages
        )
        orders[idx] = updated
        return updated
    }

    func cancelOrder(orderId: String) async throws -> OrderRecord {
        guard let idx = orders.firstIndex(where: { $0.id == orderId }) else {
            throw APIError.serverError(statusCode: 404, message: "Order not found")
        }
        let old = orders[idx]
        if old.fulfillments.contains(where: { ["in_transit", "out_for_delivery", "delivered"].contains($0.status) }) {
            throw APIError.serverError(statusCode: 409, message: "Order already in transit; request a return instead.")
        }
        let cancelled = OrderRecord(
            id: old.id, orderNumber: old.orderNumber, orderStatus: "cancelled",
            paymentStatus: old.paymentStatus, fulfillmentStatus: "cancelled",
            currency: old.currency, subtotalMinor: old.subtotalMinor, discountMinor: old.discountMinor,
            shippingMinor: old.shippingMinor, taxMinor: old.taxMinor, totalMinor: old.totalMinor,
            deliveryMethod: old.deliveryMethod, discountExplanation: old.discountExplanation,
            isDemoOrder: true, createdAt: old.createdAt, fulfillments: old.fulfillments,
            returns: old.returns, supportMessages: old.supportMessages
        )
        orders[idx] = cancelled
        return cancelled
    }

    func requestReturn(orderId: String, items: [[String: AnyCodableValue]], reason: String, requestedAmountMinor: Int?) async throws -> ReturnRequestRecord {
        guard let idx = orders.firstIndex(where: { $0.id == orderId }) else {
            throw APIError.serverError(statusCode: 404, message: "Order not found")
        }
        let old = orders[idx]
        let allItems = old.fulfillments.flatMap(\.items)
        var eligible = 0
        for entry in items {
            if case .string(let itemId) = entry["order_item_id"],
               let item = allItems.first(where: { $0.id == itemId }) {
                let qty: Int
                if case .int(let q) = entry["quantity"] { qty = q } else { qty = 1 }
                eligible += item.unitPriceMinor * min(qty, item.quantity)
            }
        }
        let cap = min(eligible, old.totalMinor)
        let req = requestedAmountMinor ?? cap
        if req > cap {
            throw APIError.serverError(statusCode: 400, message: "Requested refund exceeds eligible purchased amount.")
        }
        let ret = ReturnRequestRecord(
            id: "ret_\(UUID().uuidString.prefix(8))", orderId: old.id, reason: reason,
            eligibleAmountMinor: cap, requestedAmountMinor: req, currency: old.currency,
            returnStatus: "approved_for_dropoff", refundStatus: "refund_approved", createdAt: Date()
        )
        orders[idx] = OrderRecord(
            id: old.id, orderNumber: old.orderNumber, orderStatus: old.orderStatus,
            paymentStatus: old.paymentStatus, fulfillmentStatus: old.fulfillmentStatus,
            currency: old.currency, subtotalMinor: old.subtotalMinor, discountMinor: old.discountMinor,
            shippingMinor: old.shippingMinor, taxMinor: old.taxMinor, totalMinor: old.totalMinor,
            deliveryMethod: old.deliveryMethod, discountExplanation: old.discountExplanation,
            isDemoOrder: true, createdAt: old.createdAt, fulfillments: old.fulfillments,
            returns: [ret] + old.returns, supportMessages: old.supportMessages
        )
        return ret
    }

    func postSupportMessage(orderId: String, body: String) async throws -> SupportMessageRecord {
        guard let idx = orders.firstIndex(where: { $0.id == orderId }) else {
            throw APIError.serverError(statusCode: 404, message: "Order not found")
        }
        let old = orders[idx]
        let msg = SupportMessageRecord(id: "msg_\(UUID().uuidString.prefix(8))", orderId: orderId, senderRole: "customer", body: body, createdAt: Date())
        orders[idx] = OrderRecord(
            id: old.id, orderNumber: old.orderNumber, orderStatus: old.orderStatus,
            paymentStatus: old.paymentStatus, fulfillmentStatus: old.fulfillmentStatus,
            currency: old.currency, subtotalMinor: old.subtotalMinor, discountMinor: old.discountMinor,
            shippingMinor: old.shippingMinor, taxMinor: old.taxMinor, totalMinor: old.totalMinor,
            deliveryMethod: old.deliveryMethod, discountExplanation: old.discountExplanation,
            isDemoOrder: true, createdAt: old.createdAt, fulfillments: old.fulfillments,
            returns: old.returns, supportMessages: old.supportMessages + [msg]
        )
        return msg
    }

    func createGuestSession(deviceName: String) async throws -> AuthSessionPayload {
        AuthSessionPayload(token: "demo_guest_token", customerId: "cust_guest", displayName: "Guest Shopper", email: nil, isGuest: true, deviceSessionId: "ses_guest")
    }
    func login(email: String, password: String, deviceName: String) async throws -> AuthSessionPayload {
        AuthSessionPayload(token: "demo_user_token", customerId: "cust_demo", displayName: "Alex Rivera", email: email, isGuest: false, deviceSessionId: "ses_demo_ipad")
    }
    func register(email: String, password: String, displayName: String, deviceName: String) async throws -> AuthSessionPayload {
        AuthSessionPayload(token: "demo_user_token", customerId: "cust_demo", displayName: displayName, email: email, isGuest: false, deviceSessionId: "ses_demo_ipad")
    }
    func fetchAccountSummary() async throws -> AccountSummaryPayload {
        AccountSummaryPayload(customerId: "cust_demo", email: "demo@sunburst.example", displayName: "Alex Rivera", isGuest: false, deletionRequestedAt: nil, preferences: preferences, addresses: addresses, sessions: sessions)
    }
    func updatePreferences(_ prefs: CustomerPreferencesRecord) async throws -> CustomerPreferencesRecord {
        self.preferences = prefs
        return prefs
    }
    func addAddress(_ address: AddressRecord) async throws -> AddressRecord {
        var copy = address
        copy.id = "addr_\(UUID().uuidString.prefix(8))"
        addresses.append(copy)
        return copy
    }
    func deleteAddress(id: String) async throws { addresses.removeAll(where: { $0.id == id }) }
    func revokeSession(id: String) async throws {
        sessions = sessions.map { $0.id == id ? DeviceSessionRecord(id: $0.id, deviceName: $0.deviceName, platform: $0.platform, lastActiveAt: $0.lastActiveAt, revokedAt: Date(), isCurrent: $0.isCurrent) : $0 }
    }
    func requestAccountDeletion() async throws {}
    func fetchSavedProducts() async throws -> [ProductCard] {
        products.filter { savedIds.contains($0.id) }.map { card(for: $0, country: preferences.destinationCountry) }
    }
    func setProductSaved(productId: String, variantId: String?, saved: Bool) async throws {
        if saved { savedIds.insert(productId) } else { savedIds.remove(productId) }
    }
    func sendAssistantMessage(_ message: String, confirmToken: String?) async throws -> AssistantChatPayload {
        let lower = message.lowercased()
        if lower.contains("order") || lower.contains("track") {
            let latest = orders.first
            let reply = latest.map { "Order \($0.orderNumber) is currently \($0.orderStatus) (payment: \($0.paymentStatus), fulfillment: \($0.fulfillmentStatus))." } ?? "No orders placed yet."
            return AssistantChatPayload(reply: reply, mode: "scripted_fallback", referencedProducts: [], pendingConfirmation: nil)
        }
        let matches = products.filter { $0.title.lowercased().contains(lower) || lower.contains("kettle") && $0.id == "prod_ceramic_kettle" }
        let chosen = matches.isEmpty ? Array(products.prefix(2)) : matches
        let cards = chosen.map { card(for: $0, country: preferences.destinationCountry) }
        return AssistantChatPayload(
            reply: "Grounded catalogue facts: " + chosen.map { "\($0.title) (\($0.seller.returnWindowDays)-day return policy, \($0.delivery.estimatedWindow))" }.joined(separator: "; "),
            mode: "scripted_fallback",
            referencedProducts: cards,
            pendingConfirmation: lower.contains("add to bag") && !cards.isEmpty
                ? AssistantPendingConfirmation(summary: "Confirm adding \(cards[0].title) to your shopping bag?", confirmToken: "demo_confirm_token")
                : nil
        )
    }
}
