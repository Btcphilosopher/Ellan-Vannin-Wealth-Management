import SwiftUI

@main
struct SunburstMarketApp: App {
    @State private var appState = AppState()
    @SceneStorage("sunburst.restorable_snapshot") private var snapshotJSON: String = ""
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup {
            RootSplitView()
                .environment(appState)
                .task {
                    appState.restore(from: snapshotJSON)
                    await appState.bootstrap()
                }
                .onChange(of: scenePhase) { _, phase in
                    if phase == .background || phase == .inactive {
                        snapshotJSON = appState.exportSnapshotJSON()
                    }
                }
        }
        .commands {
            CommandGroup(after: .sidebar) {
                Button("Toggle Shopping Bag Inspector") {
                    withAnimation {
                        appState.showBagInspector.toggle()
                    }
                }
                .keyboardShortcut("b", modifiers: .command)

                Button("Focus Search") {
                    appState.selectedSidebar = .search
                    appState.focusSearchTrigger += 1
                }
                .keyboardShortcut("f", modifiers: .command)

                Divider()
                ForEach(Array(SidebarDestination.allCases.enumerated()), id: \.element.id) { idx, dest in
                    Button(dest.title) {
                        appState.selectedSidebar = dest
                    }
                    .keyboardShortcut(KeyEquivalent(Character("\(idx + 1)")), modifiers: .command)
                }
            }
        }
    }
}
