import SwiftUI

/// Centralized, replaceable brand and visual identity configuration.
enum BrandConfig {
    static let appName = "Sunburst Market"
    static let tagline = "Direct Studio & Everyday Finds"
    static let supportEmail = "help@sunburst.example"
    static let defaultBaseURL = URL(string: "http://localhost:8000")!

    // Temu-inspired vibrant orange, crisp white, and deep charcoal palette
    static let accentOrange = Color(red: 1.0, green: 0.42, blue: 0.0)        // #FF6B00
    static let accentOrangeDark = Color(red: 0.92, green: 0.33, blue: 0.0)   // #EB5400
    static let softOrangeTint = Color(red: 1.0, green: 0.94, blue: 0.89)     // #FFF0E3
    static let charcoal = Color(red: 0.11, green: 0.12, blue: 0.13)          // #1C1E21
    static let slateMuted = Color(red: 0.40, green: 0.42, blue: 0.45)        // #666B73
    static let surfaceCanvas = Color(red: 0.97, green: 0.97, blue: 0.98)     // #F7F7F8
    static let cardWhite = Color.white
    static let verifiedGreen = Color(red: 0.09, green: 0.50, blue: 0.24)     // #16803C
    static let warningAmber = Color(red: 0.71, green: 0.33, blue: 0.04)      // #B45309
    static let alertRed = Color(red: 0.78, green: 0.12, blue: 0.12)          // #C81E1E
}

enum MoneyFormatter {
    static func format(minor: Int, currency: String = "USD") -> String {
        let decimal = Decimal(minor) / 100
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.currencyCode = currency
        formatter.minimumFractionDigits = 2
        formatter.maximumFractionDigits = 2
        return formatter.string(from: decimal as NSDecimalNumber) ?? "$\(decimal)"
    }
}
