import SwiftUI

struct ProductDetailView: View {
    let productId: String
    @Environment(AppState.self) private var appState
    @Environment(\.horizontalSizeClass) private var hSizeClass

    @State private var detail: ProductDetail?
    @State private var selectedVariantId: String?
    @State private var selectedImageURL: String?
    @State private var zoomScale: CGFloat = 1.0
    @State private var quantity: Int = 1
    @State private var isLoading = true
    @State private var errorMessage: String?

    var body: some View {
        Group {
            if isLoading {
                ProgressView("Loading product details…")
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else if let err = errorMessage {
                ContentUnavailableView {
                    Label("Unavailable", systemImage: "exclamationmark.triangle")
                } description: {
                    Text(err)
                } actions: {
                    Button("Retry") { Task { await load() } }
                }
            } else if let detail {
                ScrollView {
                    if hSizeClass == .regular {
                        HStack(alignment: .top, spacing: 28) {
                            galleryAndSpecsColumn(detail)
                                .frame(maxWidth: .infinity)
                            purchaseAndSellerColumn(detail)
                                .frame(maxWidth: 460)
                        }
                        .padding(24)
                    } else {
                        VStack(alignment: .leading, spacing: 20) {
                            galleryAndSpecsColumn(detail)
                            purchaseAndSellerColumn(detail)
                        }
                        .padding(16)
                    }
                }
                .background(BrandConfig.surfaceCanvas)
                .navigationTitle(detail.title)
                .navigationBarTitleDisplayMode(.inline)
            }
        }
        .task(id: productId) {
            await load()
        }
    }

    private func load() async {
        isLoading = true
        errorMessage = nil
        do {
            let loaded = try await appState.transport.fetchProductDetail(productId: productId, country: appState.destinationCountry)
            detail = loaded
            let defaultVariant = loaded.variants.first(where: { $0.availableStock > 0 }) ?? loaded.variants.first
            selectedVariantId = defaultVariant?.id
            selectedImageURL = imageURL(for: defaultVariant?.id, in: loaded)
        } catch {
            errorMessage = error.localizedDescription
        }
        isLoading = false
    }

    private func activeVariant(in detail: ProductDetail) -> ProductVariantItem? {
        detail.variants.first(where: { $0.id == selectedVariantId }) ?? detail.variants.first
    }

    private func imageURL(for variantId: String?, in detail: ProductDetail) -> String {
        if let vId = variantId, let match = detail.images.first(where: { $0.variantId == vId }) {
            return match.url
        }
        return detail.images.first?.url ?? ""
    }

    @ViewBuilder
    private func galleryAndSpecsColumn(_ detail: ProductDetail) -> some View {
        VStack(alignment: .leading, spacing: 18) {
            // Zoomable Product Photography Card
            ZStack(alignment: .bottomTrailing) {
                ProductImageView(urlString: selectedImageURL ?? "", altText: detail.title)
                    .scaleEffect(zoomScale)
                    .frame(height: 380)
                    .frame(maxWidth: .infinity)
                    .clipped()
                    .background(BrandConfig.cardWhite)
                    .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
                    .gesture(
                        MagnificationGesture()
                            .onChanged { value in
                                zoomScale = min(max(1.0, value), 2.5)
                            }
                            .onEnded { _ in
                                withAnimation(.spring()) { zoomScale = max(1.0, min(zoomScale, 2.2)) }
                            }
                    )
                    .onTapGesture(count: 2) {
                        withAnimation(.spring()) {
                            zoomScale = zoomScale > 1.1 ? 1.0 : 1.85
                        }
                    }

                Button {
                    withAnimation(.spring()) {
                        zoomScale = zoomScale > 1.1 ? 1.0 : 1.85
                    }
                } label: {
                    Label(zoomScale > 1.1 ? "Reset Zoom" : "Zoom", systemImage: zoomScale > 1.1 ? "minus.magnifyingglass" : "plus.magnifyingglass")
                        .font(.caption.weight(.semibold))
                        .padding(.horizontal, 12)
                        .padding(.vertical, 7)
                        .background(.ultraThinMaterial)
                        .clipShape(Capsule())
                }
                .padding(12)
                .accessibilityLabel(zoomScale > 1.1 ? "Reset image zoom" : "Zoom product image")
            }

            if detail.images.count > 1 {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 10) {
                        ForEach(detail.images) { img in
                            Button {
                                selectedImageURL = img.url
                                if let vId = img.variantId {
                                    selectedVariantId = vId
                                }
                            } label: {
                                ProductImageView(urlString: img.url, altText: img.altText)
                                    .frame(width: 72, height: 72)
                                    .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 10, style: .continuous)
                                            .stroke(selectedImageURL == img.url ? BrandConfig.accentOrange : Color.clear, lineWidth: 2.5)
                                    )
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
            }

            // Description, Materials, Dimensions & Product Documentation
            VStack(alignment: .leading, spacing: 12) {
                Text("Product Details & Specifications")
                    .font(.headline)
                Text(detail.description)
                    .font(.body)
                    .foregroundStyle(BrandConfig.charcoal)

                Divider()
                LabeledContent("Dimensions", value: detail.dimensionsCm)
                LabeledContent("Weight", value: "\(detail.weightGrams) g")
                LabeledContent("Materials", value: detail.materials.joined(separator: ", "))
                if let restriction = detail.delivery.restrictionReason {
                    Label(restriction, systemImage: "exclamationmark.triangle.fill")
                        .font(.subheadline)
                        .foregroundStyle(BrandConfig.alertRed)
                }

                if !detail.documents.isEmpty {
                    Divider()
                    Text("Product Documentation")
                        .font(.subheadline.weight(.semibold))
                    ForEach(detail.documents) { doc in
                        VStack(alignment: .leading, spacing: 2) {
                            Label(doc.title, systemImage: "doc.text.fill")
                                .font(.subheadline.weight(.medium))
                                .foregroundStyle(BrandConfig.accentOrangeDark)
                            Text(doc.summary)
                                .font(.caption)
                                .foregroundStyle(BrandConfig.slateMuted)
                        }
                    }
                }
            }
            .padding(18)
            .background(BrandConfig.cardWhite)
            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))

            // Verified demonstration reviews ONLY when supported by actual records
            if !detail.reviews.isEmpty {
                VStack(alignment: .leading, spacing: 12) {
                    HStack {
                        Text("Demonstration Reviews (\(detail.reviews.count))")
                            .font(.headline)
                        Spacer()
                        if let avg = detail.ratingAverage {
                            Label(String(format: "%.1f / 5.0", avg), systemImage: "star.fill")
                                .font(.subheadline.weight(.bold))
                                .foregroundStyle(BrandConfig.accentOrange)
                        }
                    }
                    ForEach(detail.reviews) { rev in
                        VStack(alignment: .leading, spacing: 4) {
                            HStack {
                                Text(rev.title)
                                    .font(.subheadline.weight(.semibold))
                                Spacer()
                                Text("\(rev.rating)★")
                                    .font(.caption.weight(.bold))
                                    .foregroundStyle(BrandConfig.accentOrange)
                            }
                            Text("\(rev.authorDisplay) • Variant: \(rev.variantTitle) • Verified Demo Record")
                                .font(.caption)
                                .foregroundStyle(BrandConfig.slateMuted)
                            Text(rev.body)
                                .font(.subheadline)
                        }
                        .padding(.vertical, 6)
                    }
                }
                .padding(18)
                .background(BrandConfig.cardWhite)
                .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
            }
        }
    }

    @ViewBuilder
    private func purchaseAndSellerColumn(_ detail: ProductDetail) -> some View {
        let variant = activeVariant(in: detail)
        VStack(alignment: .leading, spacing: 16) {
            VStack(alignment: .leading, spacing: 8) {
                Text(detail.category.name.uppercased())
                    .font(.caption.weight(.bold))
                    .foregroundStyle(BrandConfig.accentOrangeDark)
                Text(detail.title)
                    .font(.title2.weight(.bold))
                    .foregroundStyle(BrandConfig.charcoal)
                Text(detail.subtitle)
                    .font(.subheadline)
                    .foregroundStyle(BrandConfig.slateMuted)

                if let variant {
                    HStack(alignment: .firstTextBaseline, spacing: 10) {
                        Text(MoneyFormatter.format(minor: variant.priceMinor, currency: variant.currency))
                            .font(.largeTitle.weight(.bold))
                            .foregroundStyle(BrandConfig.accentOrangeDark)
                        if let ref = variant.referencePriceMinor, ref > variant.priceMinor {
                            Text(MoneyFormatter.format(minor: ref, currency: variant.currency))
                                .font(.title3)
                                .strikethrough()
                                .foregroundStyle(BrandConfig.slateMuted)
                        }
                    }
                    if let basis = variant.referencePriceBasis {
                        Text("Reference basis: \(basis)")
                            .font(.caption)
                            .foregroundStyle(BrandConfig.verifiedGreen)
                    }
                    Text("SKU: \(variant.sku) • \(variant.availableStock > 0 ? "\(variant.availableStock) available" : "Out of stock")")
                        .font(.caption.weight(.medium))
                        .foregroundStyle(variant.availableStock > 0 ? BrandConfig.slateMuted : BrandConfig.alertRed)
                }
            }
            .padding(18)
            .background(BrandConfig.cardWhite)
            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))

            // Variant Selector
            VStack(alignment: .leading, spacing: 10) {
                Text("Select Variant")
                    .font(.headline)
                ForEach(detail.variants) { v in
                    let isSelected = v.id == variant?.id
                    Button {
                        selectedVariantId = v.id
                        selectedImageURL = imageURL(for: v.id, in: detail)
                        quantity = min(quantity, max(1, v.availableStock))
                    } label: {
                        HStack {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(v.title)
                                    .font(.subheadline.weight(.semibold))
                                    .foregroundStyle(BrandConfig.charcoal)
                                Text(v.availableStock > 0 ? "\(v.availableStock) in stock" : "Out of stock")
                                    .font(.caption)
                                    .foregroundStyle(v.availableStock > 0 ? BrandConfig.slateMuted : BrandConfig.alertRed)
                            }
                            Spacer()
                            Text(MoneyFormatter.format(minor: v.priceMinor, currency: v.currency))
                                .font(.subheadline.weight(.bold))
                                .foregroundStyle(BrandConfig.charcoal)
                            Image(systemName: isSelected ? "checkmark.circle.fill" : "circle")
                                .foregroundStyle(isSelected ? BrandConfig.accentOrange : BrandConfig.slateMuted)
                        }
                        .padding(12)
                        .background(isSelected ? BrandConfig.softOrangeTint : BrandConfig.surfaceCanvas)
                        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: 12, style: .continuous)
                                .stroke(isSelected ? BrandConfig.accentOrange : Color.clear, lineWidth: 1.5)
                        )
                    }
                    .buttonStyle(.plain)
                }

                Divider().padding(.vertical, 4)

                Stepper("Quantity: \(quantity)", value: $quantity, in: 1...max(1, variant?.availableStock ?? 1))
                    .disabled((variant?.availableStock ?? 0) == 0)

                HStack(spacing: 10) {
                    Button {
                        guard let v = variant else { return }
                        Task {
                            await appState.addToBag(productId: detail.id, variantId: v.id, quantity: quantity)
                            appState.showBagInspector = true
                        }
                    } label: {
                        Label("Add to Bag", systemImage: "bag.badge.plus")
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 6)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(BrandConfig.accentOrange)
                    .disabled((variant?.availableStock ?? 0) == 0 || !detail.delivery.eligibleForDestination)
                    .accessibilityLabel("Add \(quantity) to shopping bag")

                    Button {
                        Task {
                            await appState.toggleSaved(productId: detail.id, variantId: variant?.id, currentlySaved: detail.isSaved)
                            await load()
                        }
                    } label: {
                        Image(systemName: detail.isSaved ? "heart.fill" : "heart")
                            .padding(10)
                    }
                    .buttonStyle(.bordered)
                    .tint(detail.isSaved ? BrandConfig.accentOrange : BrandConfig.charcoal)
                    .accessibilityLabel(detail.isSaved ? "Remove from saved products" : "Save product")
                }
            }
            .padding(18)
            .background(BrandConfig.cardWhite)
            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))

            // Delivery & Seller Details
            VStack(alignment: .leading, spacing: 10) {
                Text("Delivery & Seller")
                    .font(.headline)
                Label(detail.delivery.estimatedWindow, systemImage: "truck.box")
                    .font(.subheadline)
                if let guarantee = detail.delivery.guaranteedBy {
                    Label(guarantee, systemImage: "checkmark.seal.fill")
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(BrandConfig.verifiedGreen)
                } else {
                    Text("Estimated range only — no guaranteed arrival date for this item.")
                        .font(.caption)
                        .foregroundStyle(BrandConfig.slateMuted)
                }

                Divider()
                HStack {
                    Text(detail.seller.name)
                        .font(.subheadline.weight(.semibold))
                    if detail.seller.verifiedBadge {
                        Image(systemName: "checkmark.shield.fill")
                            .foregroundStyle(BrandConfig.verifiedGreen)
                    }
                }
                Text("Ships from \(detail.seller.dispatchCity) • Free shipping over \(MoneyFormatter.format(minor: detail.seller.freeShippingThresholdMinor))")
                    .font(.caption)
                    .foregroundStyle(BrandConfig.slateMuted)
                Text("Returns: \(detail.seller.returnWindowDays)-day window. \(detail.seller.returnPolicySummary)")
                    .font(.caption)
                    .foregroundStyle(BrandConfig.slateMuted)

                Button {
                    appState.showAssistantSheet = true
                } label: {
                    Label("Ask Assistant about this item", systemImage: "bubble.left.and.sparkles")
                        .font(.subheadline.weight(.medium))
                }
                .buttonStyle(.bordered)
            }
            .padding(18)
            .background(BrandConfig.cardWhite)
            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
        }
    }
}
