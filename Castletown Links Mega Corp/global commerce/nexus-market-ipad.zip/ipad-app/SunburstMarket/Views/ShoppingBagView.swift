import SwiftUI

struct ShoppingBagView: View {
    @Environment(AppState.self) private var appState
    let isInspector: Bool

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Label("Shopping Bag (\(appState.bagItemCount))", systemImage: "bag.fill")
                    .font(.headline)
                    .foregroundStyle(BrandConfig.charcoal)
                Spacer()
                Button {
                    Task { await appState.refreshBag() }
                } label: {
                    Image(systemName: "arrow.clockwise")
                }
                .accessibilityLabel("Refresh bag prices and stock from server")

                if isInspector {
                    Button {
                        appState.showBagInspector = false
                    } label: {
                        Image(systemName: "sidebar.right")
                    }
                    .accessibilityLabel("Collapse bag inspector")
                }
            }
            .padding(14)
            .background(BrandConfig.cardWhite)

            Divider()

            if let bag = appState.bag {
                ScrollView {
                    VStack(alignment: .leading, spacing: 14) {
                        if !bag.notices.isEmpty {
                            VStack(alignment: .leading, spacing: 6) {
                                Label("Server Terms Updated", systemImage: "exclamationmark.triangle.fill")
                                    .font(.subheadline.weight(.bold))
                                    .foregroundStyle(BrandConfig.warningAmber)
                                ForEach(bag.notices, id: \.self) { notice in
                                    Text("• \(notice)")
                                        .font(.caption)
                                        .foregroundStyle(BrandConfig.charcoal)
                                }
                                Button("Acknowledge Price Updates") {
                                    Task { await appState.acknowledgeBagChanges() }
                                }
                                .buttonStyle(.bordered)
                                .controlSize(.small)
                            }
                            .padding(12)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(BrandConfig.softOrangeTint)
                            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                        }

                        if bag.sellerGroups.isEmpty {
                            ContentUnavailableView(
                                "Your Bag is Empty",
                                systemImage: "bag",
                                description: Text("Browse Discover or Search to add items.")
                            )
                            .padding(.vertical, 24)
                        } else {
                            ForEach(bag.sellerGroups) { group in
                                sellerGroupCard(group)
                            }
                        }

                        if !bag.savedForLater.isEmpty {
                            VStack(alignment: .leading, spacing: 10) {
                                Text("Saved for Later (\(bag.savedForLater.count))")
                                    .font(.subheadline.weight(.bold))
                                ForEach(bag.savedForLater) { line in
                                    HStack(spacing: 10) {
                                        ProductImageView(urlString: line.imageUrl, altText: line.productTitle)
                                            .frame(width: 48, height: 48)
                                            .clipShape(RoundedRectangle(cornerRadius: 8))
                                        VStack(alignment: .leading, spacing: 2) {
                                            Text(line.productTitle)
                                                .font(.caption.weight(.semibold))
                                                .lineLimit(1)
                                            Text("\(line.variantTitle) • \(MoneyFormatter.format(minor: line.unitPriceMinor))")
                                                .font(.caption2)
                                                .foregroundStyle(BrandConfig.slateMuted)
                                        }
                                        Spacer()
                                        Button("Move to Bag") {
                                            Task { await appState.updateBagItem(itemId: line.id, status: "active") }
                                        }
                                        .buttonStyle(.bordered)
                                        .controlSize(.mini)
                                    }
                                    .padding(10)
                                    .background(BrandConfig.cardWhite)
                                    .clipShape(RoundedRectangle(cornerRadius: 12))
                                }
                            }
                        }
                    }
                    .padding(14)
                }
                .background(BrandConfig.surfaceCanvas)

                if !bag.sellerGroups.isEmpty {
                    Divider()
                    VStack(spacing: 10) {
                        HStack {
                            Text("Estimated Subtotal")
                                .font(.subheadline)
                            Spacer()
                            Text(MoneyFormatter.format(minor: bag.subtotalMinor, currency: bag.currency))
                                .font(.headline.weight(.bold))
                        }
                        HStack {
                            Text("Estimated Shipping (\(bag.destinationCountry))")
                                .font(.caption)
                                .foregroundStyle(BrandConfig.slateMuted)
                            Spacer()
                            Text(bag.estimatedShippingMinor == 0 ? "FREE" : MoneyFormatter.format(minor: bag.estimatedShippingMinor))
                                .font(.caption.weight(.semibold))
                                .foregroundStyle(bag.estimatedShippingMinor == 0 ? BrandConfig.verifiedGreen : BrandConfig.charcoal)
                        }
                        Button {
                            appState.checkoutVM.resetForNewCheckout(defaultAddress: appState.accountSummary?.addresses.first(where: \.isDefault))
                            appState.showCheckoutSheet = true
                        } label: {
                            Text("Proceed to Demo Checkout")
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 6)
                        }
                        .buttonStyle(.borderedProminent)
                        .tint(BrandConfig.accentOrange)
                        .disabled(bag.hasBlockingIssues)
                    }
                    .padding(14)
                    .background(BrandConfig.cardWhite)
                }
            } else {
                ProgressView()
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
    }

    private func sellerGroupCard(_ group: BagSellerGroup) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text(group.seller.name)
                    .font(.subheadline.weight(.bold))
                Spacer()
                if group.freeShippingRemainingMinor == 0 {
                    Text("Free shipping unlocked")
                        .font(.caption2.weight(.semibold))
                        .foregroundStyle(BrandConfig.verifiedGreen)
                } else {
                    Text("Add \(MoneyFormatter.format(minor: group.freeShippingRemainingMinor)) for free shipping")
                        .font(.caption2)
                        .foregroundStyle(BrandConfig.slateMuted)
                }
            }

            ForEach(group.items) { line in
                VStack(alignment: .leading, spacing: 8) {
                    HStack(alignment: .top, spacing: 10) {
                        ProductImageView(urlString: line.imageUrl, altText: line.productTitle)
                            .frame(width: 62, height: 62)
                            .clipShape(RoundedRectangle(cornerRadius: 10))

                        VStack(alignment: .leading, spacing: 3) {
                            Text(line.productTitle)
                                .font(.subheadline.weight(.semibold))
                                .lineLimit(2)

                            Menu {
                                ForEach(line.availableVariants) { v in
                                    Button("\(v.title) — \(MoneyFormatter.format(minor: v.priceMinor))") {
                                        Task { await appState.updateBagItem(itemId: line.id, variantId: v.id) }
                                    }
                                    .disabled(v.availableStock < line.quantity)
                                }
                            } label: {
                                Label(line.variantTitle, systemImage: "chevron.down.circle")
                                    .font(.caption)
                                    .foregroundStyle(BrandConfig.accentOrangeDark)
                            }

                            Text("SKU: \(line.sku) • \(MoneyFormatter.format(minor: line.unitPriceMinor)) each")
                                .font(.caption2)
                                .foregroundStyle(BrandConfig.slateMuted)

                            if let notice = line.noticeMessage {
                                Text(notice)
                                    .font(.caption2.weight(.semibold))
                                    .foregroundStyle(line.stockInsufficient || !line.eligibleForDestination ? BrandConfig.alertRed : BrandConfig.warningAmber)
                            }
                        }
                    }

                    HStack {
                        HStack(spacing: 8) {
                            Button {
                                if line.quantity > 1 {
                                    Task { await appState.updateBagItem(itemId: line.id, quantity: line.quantity - 1) }
                                } else {
                                    Task { await appState.removeBagItem(itemId: line.id) }
                                }
                            } label: {
                                Image(systemName: "minus.circle.fill")
                            }
                            .accessibilityLabel("Decrease quantity")

                            Text("\(line.quantity)")
                                .font(.subheadline.weight(.bold))
                                .frame(minWidth: 20)

                            Button {
                                Task { await appState.updateBagItem(itemId: line.id, quantity: line.quantity + 1) }
                            } label: {
                                Image(systemName: "plus.circle.fill")
                            }
                            .disabled(line.quantity >= line.availableStock)
                            .accessibilityLabel("Increase quantity")
                        }
                        .foregroundStyle(BrandConfig.accentOrange)

                        Spacer()

                        Button("Save") {
                            Task { await appState.updateBagItem(itemId: line.id, status: "saved_for_later") }
                        }
                        .font(.caption)
                        .buttonStyle(.bordered)
                        .controlSize(.mini)

                        Button(role: .destructive) {
                            Task { await appState.removeBagItem(itemId: line.id) }
                        } label: {
                            Image(systemName: "trash")
                                .font(.caption)
                        }
                        .buttonStyle(.bordered)
                        .controlSize(.mini)
                        .accessibilityLabel("Remove \(line.productTitle)")
                    }
                }
                .padding(10)
                .background(BrandConfig.surfaceCanvas)
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            }
        }
        .padding(12)
        .background(BrandConfig.cardWhite)
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
    }
}
