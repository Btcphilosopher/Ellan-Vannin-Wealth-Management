import SwiftUI

struct SearchView: View {
    @Environment(AppState.self) private var appState
    @FocusState private var searchFocused: Bool

    private let gridColumns = [
        GridItem(.adaptive(minimum: 220, maximum: 280), spacing: 16)
    ]

    var body: some View {
        @Bindable var state = appState
        @Bindable var vm = appState.searchVM

        NavigationStack(path: $state.searchPath) {
            VStack(spacing: 0) {
                filterBar(vm: vm)
                Divider()

                if vm.isLoading && vm.results.isEmpty {
                    ProgressView("Searching catalogue…")
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else if let err = vm.errorMessage {
                    ContentUnavailableView {
                        Label("Search Failed", systemImage: "exclamationmark.triangle")
                    } description: {
                        Text(err)
                    } actions: {
                        Button("Retry") {
                            Task { await vm.runSearch(using: appState.transport, country: appState.destinationCountry) }
                        }
                        .buttonStyle(.borderedProminent)
                        .tint(BrandConfig.accentOrange)
                    }
                } else if vm.results.isEmpty {
                    ContentUnavailableView {
                        Label("No Matching Products", systemImage: "magnifyingglass")
                    } description: {
                        Text("Try clearing a filter or searching for kettle, pen, notebook, tee, or charger.")
                    } actions: {
                        Button("Reset Filters") {
                            Task { await vm.clearFilters(using: appState.transport, country: appState.destinationCountry) }
                        }
                        .buttonStyle(.borderedProminent)
                        .tint(BrandConfig.accentOrange)
                    }
                } else {
                    ScrollView {
                        LazyVGrid(columns: gridColumns, spacing: 16) {
                            ForEach(vm.results) { item in
                                ProductCardView(product: item) {
                                    vm.scrolledProductId = item.id
                                    appState.searchPath.append(item.id)
                                }
                                .id(item.id)
                            }
                        }
                        .scrollTargetLayout()
                        .padding(20)

                        if vm.hasNextPage {
                            Button("Load More (\(vm.results.count) of \(vm.totalCount))") {
                                Task { await vm.runSearch(using: appState.transport, country: appState.destinationCountry, resetPage: false) }
                            }
                            .buttonStyle(.bordered)
                            .padding(.bottom, 24)
                        }
                    }
                    .scrollPosition(id: $vm.scrolledProductId, anchor: .center)
                }
            }
            .background(BrandConfig.surfaceCanvas)
            .navigationTitle("Search & Filter (\(vm.totalCount))")
            .navigationDestination(for: String.self) { productId in
                ProductDetailView(productId: productId)
            }
            .task {
                if vm.results.isEmpty {
                    await vm.runSearch(using: appState.transport, country: appState.destinationCountry)
                }
            }
            .onChange(of: appState.focusSearchTrigger) { _, _ in
                searchFocused = true
            }
        }
    }

    @ViewBuilder
    private func filterBar(vm: SearchViewModel) -> some View {
        @Bindable var bindableVM = vm
        VStack(spacing: 10) {
            HStack(spacing: 12) {
                HStack(spacing: 8) {
                    Image(systemName: "magnifyingglass")
                        .foregroundStyle(BrandConfig.accentOrange)
                    TextField("Search products, SKUs, sellers…", text: $bindableVM.filters.query)
                        .focused($searchFocused)
                        .onChange(of: bindableVM.filters.query) { _, _ in
                            vm.scheduleSearch(using: appState.transport, country: appState.destinationCountry)
                        }
                    if !bindableVM.filters.query.isEmpty {
                        Button {
                            bindableVM.filters.query = ""
                            vm.scheduleSearch(using: appState.transport, country: appState.destinationCountry, debounceMs: 0)
                        } label: {
                            Image(systemName: "xmark.circle.fill")
                                .foregroundStyle(BrandConfig.slateMuted)
                        }
                        .accessibilityLabel("Clear search text")
                    }
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 9)
                .background(BrandConfig.surfaceCanvas)
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))

                Picker("Sort", selection: $bindableVM.filters.sort) {
                    Text("Relevance").tag("relevance")
                    Text("Price: Low to High").tag("price_asc")
                    Text("Price: High to Low").tag("price_desc")
                    Text("Newest").tag("newest")
                }
                .pickerStyle(.menu)
                .onChange(of: bindableVM.filters.sort) { _, _ in
                    Task { await vm.runSearch(using: appState.transport, country: appState.destinationCountry) }
                }
            }

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 10) {
                    Picker("Category", selection: $bindableVM.filters.categoryId) {
                        Text("All Categories").tag(String?.none)
                        ForEach(vm.categories) { cat in
                            Text(cat.name).tag(String?.some(cat.id))
                        }
                    }
                    .pickerStyle(.menu)
                    .onChange(of: bindableVM.filters.categoryId) { _, _ in
                        Task { await vm.runSearch(using: appState.transport, country: appState.destinationCountry) }
                    }

                    Picker("Seller", selection: $bindableVM.filters.sellerId) {
                        Text("All Sellers").tag(String?.none)
                        ForEach(vm.sellers) { sel in
                            Text(sel.name).tag(String?.some(sel.id))
                        }
                    }
                    .pickerStyle(.menu)
                    .onChange(of: bindableVM.filters.sellerId) { _, _ in
                        Task { await vm.runSearch(using: appState.transport, country: appState.destinationCountry) }
                    }

                    Toggle("In Stock Only", isOn: $bindableVM.filters.inStockOnly)
                        .toggleStyle(.button)
                        .tint(BrandConfig.accentOrange)
                        .onChange(of: bindableVM.filters.inStockOnly) { _, _ in
                            Task { await vm.runSearch(using: appState.transport, country: appState.destinationCountry) }
                        }

                    Toggle("Ships to \(appState.destinationCountry)", isOn: $bindableVM.filters.eligibleOnly)
                        .toggleStyle(.button)
                        .tint(BrandConfig.accentOrange)
                        .onChange(of: bindableVM.filters.eligibleOnly) { _, _ in
                            Task { await vm.runSearch(using: appState.transport, country: appState.destinationCountry) }
                        }

                    Button("Reset") {
                        Task { await vm.clearFilters(using: appState.transport, country: appState.destinationCountry) }
                    }
                    .buttonStyle(.bordered)
                }
            }
        }
        .padding(14)
        .background(BrandConfig.cardWhite)
    }
}
