import SwiftUI

struct CategoriesView: View {
    @Environment(AppState.self) private var appState
    @State private var selectedCategoryId: String?
    @State private var categoryProducts: [ProductCard] = []
    @State private var isLoading = false

    private let gridColumns = [
        GridItem(.adaptive(minimum: 220, maximum: 280), spacing: 16)
    ]

    var body: some View {
        @Bindable var state = appState
        NavigationStack(path: $state.categoriesPath) {
            HStack(spacing: 0) {
                List(appState.searchVM.categories, selection: $selectedCategoryId) { cat in
                    HStack(spacing: 12) {
                        Image(systemName: cat.iconName)
                            .foregroundStyle(BrandConfig.accentOrange)
                            .frame(width: 24)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(cat.name)
                                .font(.headline)
                            Text(cat.description)
                                .font(.caption)
                                .foregroundStyle(BrandConfig.slateMuted)
                                .lineLimit(2)
                        }
                    }
                    .padding(.vertical, 6)
                    .tag(cat.id)
                }
                .listStyle(.insetGrouped)
                .frame(maxWidth: 300)

                Divider()

                Group {
                    if isLoading {
                        ProgressView("Loading category…")
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                    } else if categoryProducts.isEmpty {
                        ContentUnavailableView("Select a Category", systemImage: "square.grid.2x2")
                    } else {
                        ScrollView {
                            LazyVGrid(columns: gridColumns, spacing: 16) {
                                ForEach(categoryProducts) { product in
                                    ProductCardView(product: product) {
                                        appState.categoriesPath.append(product.id)
                                    }
                                }
                            }
                            .padding(20)
                        }
                    }
                }
                .background(BrandConfig.surfaceCanvas)
            }
            .navigationTitle("Categories")
            .navigationDestination(for: String.self) { productId in
                ProductDetailView(productId: productId)
            }
            .task {
                if selectedCategoryId == nil, let first = appState.searchVM.categories.first {
                    selectedCategoryId = first.id
                }
                await loadCategoryProducts()
            }
            .onChange(of: selectedCategoryId) { _, _ in
                Task { await loadCategoryProducts() }
            }
        }
    }

    private func loadCategoryProducts() async {
        guard let catId = selectedCategoryId else { return }
        isLoading = true
        var filters = SearchFilters()
        filters.categoryId = catId
        do {
            let res = try await appState.transport.searchCatalog(filters: filters, country: appState.destinationCountry, page: 1, pageSize: 30)
            categoryProducts = res.items
        } catch {
            categoryProducts = []
        }
        isLoading = false
    }
}
