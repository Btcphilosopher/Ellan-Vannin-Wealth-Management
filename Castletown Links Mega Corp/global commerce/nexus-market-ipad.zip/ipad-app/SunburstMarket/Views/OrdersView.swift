import SwiftUI

struct OrdersView: View {
    @Environment(AppState.self) private var appState

    var body: some View {
        @Bindable var state = appState
        NavigationStack(path: $state.ordersPath) {
            Group {
                if appState.orders.isEmpty {
                    ContentUnavailableView(
                        "No Orders Yet",
                        systemImage: "shippingbox",
                        description: Text("Complete a demo checkout to track shipments and test returns.")
                    )
                } else {
                    List(appState.orders) { order in
                        NavigationLink(value: order.id) {
                            VStack(alignment: .leading, spacing: 6) {
                                HStack {
                                    Text(order.orderNumber)
                                        .font(.headline.weight(.bold))
                                    Spacer()
                                    Text(MoneyFormatter.format(minor: order.totalMinor, currency: order.currency))
                                        .font(.headline.weight(.bold))
                                        .foregroundStyle(BrandConfig.accentOrangeDark)
                                }
                                HStack(spacing: 8) {
                                    badge(order.orderStatus.replacingOccurrences(of: "_", with: " ").capitalized, color: BrandConfig.charcoal)
                                    badge("Payment: \(order.paymentStatus)", color: order.paymentStatus == "paid" ? BrandConfig.verifiedGreen : BrandConfig.warningAmber)
                                    badge("Fulfillment: \(order.fulfillmentStatus)", color: BrandConfig.accentOrangeDark)
                                }
                                Text("\(order.fulfillments.count) seller shipment(s) • \(order.createdAt.formatted(date: .abbreviated, time: .shortened))")
                                    .font(.caption)
                                    .foregroundStyle(BrandConfig.slateMuted)
                            }
                            .padding(.vertical, 6)
                        }
                    }
                    .listStyle(.insetGrouped)
                }
            }
            .navigationTitle("Orders & Tracking")
            .navigationDestination(for: String.self) { orderId in
                OrderDetailView(orderId: orderId)
            }
            .task {
                await appState.loadOrders()
            }
        }
    }

    private func badge(_ text: String, color: Color) -> some View {
        Text(text)
            .font(.caption2.weight(.semibold))
            .padding(.horizontal, 8)
            .padding(.vertical, 3)
            .background(color.opacity(0.12))
            .foregroundStyle(color)
            .clipShape(Capsule())
    }
}

struct OrderDetailView: View {
    let orderId: String
    @Environment(AppState.self) private var appState

    @State private var order: OrderRecord?
    @State private var isLoading = true
    @State private var showReturnSheet = false
    @State private var returnReason = "Item does not fit my studio setup"
    @State private var supportDraft = ""
    @State private var errorNotice: String?

    var body: some View {
        Group {
            if isLoading {
                ProgressView("Loading order…")
            } else if let order {
                ScrollView {
                    VStack(alignment: .leading, spacing: 18) {
                        summaryCard(order)

                        ForEach(order.fulfillments) { ful in
                            fulfillmentCard(ful, order: order)
                        }

                        if !order.returns.isEmpty {
                            returnsCard(order.returns)
                        }

                        supportCard(order)
                    }
                    .padding(20)
                }
                .background(BrandConfig.surfaceCanvas)
                .sheet(isPresented: $showReturnSheet) {
                    returnRequestSheet(order: order)
                }
            } else {
                ContentUnavailableView("Order Not Found", systemImage: "exclamationmark.triangle")
            }
        }
        .navigationTitle(order?.orderNumber ?? "Order")
        .task(id: orderId) {
            await reload()
        }
    }

    private func reload() async {
        isLoading = true
        order = try? await appState.transport.fetchOrderDetail(orderId: orderId)
        isLoading = false
    }

    private func summaryCard(_ order: OrderRecord) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("Order \(order.orderNumber)")
                    .font(.title2.weight(.bold))
                Spacer()
                if order.isDemoOrder {
                    Text("DEMO ORDER")
                        .font(.caption2.weight(.bold))
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(BrandConfig.softOrangeTint)
                        .foregroundStyle(BrandConfig.accentOrangeDark)
                        .clipShape(Capsule())
                }
            }

            HStack(spacing: 16) {
                LabeledContent("Order", value: order.orderStatus)
                LabeledContent("Payment", value: order.paymentStatus)
                LabeledContent("Fulfillment", value: order.fulfillmentStatus)
            }
            .font(.caption)

            if let err = errorNotice {
                Text(err).font(.caption).foregroundStyle(BrandConfig.alertRed)
            }

            Divider()
            LabeledContent("Subtotal", value: MoneyFormatter.format(minor: order.subtotalMinor, currency: order.currency))
            LabeledContent("Discount", value: "-\(MoneyFormatter.format(minor: order.discountMinor, currency: order.currency))")
            LabeledContent("Shipping", value: MoneyFormatter.format(minor: order.shippingMinor, currency: order.currency))
            LabeledContent("Tax", value: MoneyFormatter.format(minor: order.taxMinor, currency: order.currency))
            LabeledContent("Total Paid", value: MoneyFormatter.format(minor: order.totalMinor, currency: order.currency))
                .font(.headline.weight(.bold))
            Text(order.discountExplanation)
                .font(.caption)
                .foregroundStyle(BrandConfig.slateMuted)

            HStack(spacing: 10) {
                Button("Advance Synthetic Tracking") {
                    Task {
                        orderAction { try await appState.transport.advanceTracking(orderId: order.id, simulateException: false) }
                    }
                }
                .buttonStyle(.bordered)

                Button("Simulate Exception") {
                    Task {
                        orderAction { try await appState.transport.advanceTracking(orderId: order.id, simulateException: true) }
                    }
                }
                .buttonStyle(.bordered)

                Button("Cancel Order", role: .destructive) {
                    Task {
                        orderAction { try await appState.transport.cancelOrder(orderId: order.id) }
                    }
                }
                .buttonStyle(.bordered)

                if order.paymentStatus == "paid" {
                    Button("Request Return") {
                        showReturnSheet = true
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(BrandConfig.accentOrange)
                }
            }
        }
        .padding(18)
        .background(BrandConfig.cardWhite)
        .clipShape(RoundedRectangle(cornerRadius: 18))
    }

    private func fulfillmentCard(_ ful: OrderFulfillmentRecord, order: OrderRecord) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text(ful.sellerName).font(.headline)
                    Text("\(ful.carrierName) • Tracking: \(ful.trackingNumber)")
                        .font(.caption).foregroundStyle(BrandConfig.slateMuted)
                }
                Spacer()
                Text(ful.status.replacingOccurrences(of: "_", with: " ").capitalized)
                    .font(.caption.weight(.bold))
                    .padding(.horizontal, 10)
                    .padding(.vertical, 4)
                    .background(ful.status == "delivery_exception" ? BrandConfig.alertRed.opacity(0.15) : BrandConfig.softOrangeTint)
                    .foregroundStyle(ful.status == "delivery_exception" ? BrandConfig.alertRed : BrandConfig.accentOrangeDark)
                    .clipShape(Capsule())
            }

            if let note = ful.exceptionNote {
                Label(note, systemImage: "exclamationmark.triangle.fill")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(BrandConfig.alertRed)
            }

            Text(ful.guaranteedBy ?? ful.estimatedWindow)
                .font(.caption)
                .foregroundStyle(ful.guaranteedBy != nil ? BrandConfig.verifiedGreen : BrandConfig.slateMuted)

            ForEach(ful.items) { item in
                HStack(spacing: 10) {
                    ProductImageView(urlString: item.imageUrl, altText: item.productTitle)
                        .frame(width: 48, height: 48)
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                    VStack(alignment: .leading, spacing: 2) {
                        Text(item.productTitle).font(.subheadline.weight(.semibold))
                        Text("Variant: \(item.variantSummary) • SKU: \(item.sku) • Qty \(item.quantity)")
                            .font(.caption).foregroundStyle(BrandConfig.slateMuted)
                    }
                    Spacer()
                    Text(MoneyFormatter.format(minor: item.lineTotalMinor, currency: item.currency))
                        .font(.subheadline.weight(.bold))
                }
            }

            Divider()
            Text("Synthetic Carrier Timeline")
                .font(.caption.weight(.bold))
                .foregroundStyle(BrandConfig.slateMuted)
            ForEach(ful.events.reversed()) { ev in
                HStack(alignment: .top, spacing: 8) {
                    Circle().fill(BrandConfig.accentOrange).frame(width: 8, height: 8).padding(.top, 5)
                    VStack(alignment: .leading, spacing: 1) {
                        Text("\(ev.status.replacingOccurrences(of: "_", with: " ").capitalized) — \(ev.location)")
                            .font(.caption.weight(.semibold))
                        Text(ev.detail)
                            .font(.caption2)
                            .foregroundStyle(BrandConfig.slateMuted)
                    }
                }
            }
        }
        .padding(18)
        .background(BrandConfig.cardWhite)
        .clipShape(RoundedRectangle(cornerRadius: 18))
    }

    private func returnsCard(_ returns: [ReturnRequestRecord]) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Returns & Refund Status")
                .font(.headline)
            ForEach(returns) { ret in
                VStack(alignment: .leading, spacing: 4) {
                    HStack {
                        Text("Return \(ret.id)")
                            .font(.subheadline.weight(.semibold))
                        Spacer()
                        Text(ret.refundStageTitle)
                            .font(.caption.weight(.bold))
                            .padding(.horizontal, 10)
                            .padding(.vertical, 4)
                            .background(BrandConfig.verifiedGreen.opacity(0.14))
                            .foregroundStyle(BrandConfig.verifiedGreen)
                            .clipShape(Capsule())
                    }
                    Text("Reason: \(ret.reason)")
                        .font(.caption)
                    Text("Requested: \(MoneyFormatter.format(minor: ret.requestedAmountMinor, currency: ret.currency)) (Eligible cap: \(MoneyFormatter.format(minor: ret.eligibleAmountMinor, currency: ret.currency)))")
                        .font(.caption2)
                        .foregroundStyle(BrandConfig.slateMuted)
                }
                .padding(10)
                .background(BrandConfig.surfaceCanvas)
                .clipShape(RoundedRectangle(cornerRadius: 10))
            }
        }
        .padding(18)
        .background(BrandConfig.cardWhite)
        .clipShape(RoundedRectangle(cornerRadius: 18))
    }

    private func supportCard(_ order: OrderRecord) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Order Customer Service")
                .font(.headline)
            Text("Messages here are strictly scoped to order \(order.orderNumber).")
                .font(.caption)
                .foregroundStyle(BrandConfig.slateMuted)

            ForEach(order.supportMessages) { msg in
                VStack(alignment: .leading, spacing: 2) {
                    Text(msg.senderRole.capitalized)
                        .font(.caption2.weight(.bold))
                        .foregroundStyle(BrandConfig.accentOrangeDark)
                    Text(msg.body)
                        .font(.subheadline)
                }
                .padding(10)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(BrandConfig.surfaceCanvas)
                .clipShape(RoundedRectangle(cornerRadius: 10))
            }

            HStack {
                TextField("Send a message about this order…", text: $supportDraft)
                    .textFieldStyle(.roundedBorder)
                Button("Send") {
                    let body = supportDraft.trimmingCharacters(in: .whitespacesAndNewlines)
                    guard !body.isEmpty else { return }
                    supportDraft = ""
                    Task {
                        _ = try? await appState.transport.postSupportMessage(orderId: order.id, body: body)
                        await reload()
                    }
                }
                .buttonStyle(.borderedProminent)
                .tint(BrandConfig.accentOrange)
            }
        }
        .padding(18)
        .background(BrandConfig.cardWhite)
        .clipShape(RoundedRectangle(cornerRadius: 18))
    }

    private func returnRequestSheet(order: OrderRecord) -> some View {
        let items = order.fulfillments.flatMap(\.items)
        return NavigationStack {
            Form {
                Section("Items Eligible for Return") {
                    ForEach(items) { item in
                        LabeledContent(item.productTitle, value: MoneyFormatter.format(minor: item.lineTotalMinor, currency: item.currency))
                    }
                }
                Section("Return Reason") {
                    TextField("Reason for return", text: $returnReason)
                }
                Section {
                    Button("Submit Return Request") {
                        guard let first = items.first else { return }
                        Task {
                            do {
                                _ = try await appState.transport.requestReturn(
                                    orderId: order.id,
                                    items: [["order_item_id": .string(first.id), "quantity": .int(1)]],
                                    reason: returnReason,
                                    requestedAmountMinor: nil
                                )
                                showReturnSheet = false
                                await reload()
                            } catch {
                                errorNotice = error.localizedDescription
                                showReturnSheet = false
                            }
                        }
                    }
                    .tint(BrandConfig.accentOrange)
                }
            }
            .navigationTitle("Request Return")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { showReturnSheet = false }
                }
            }
        }
    }

    private func orderAction(_ op: @escaping () async throws -> OrderRecord) {
        Task {
            do {
                order = try await op()
                errorNotice = nil
                await appState.loadOrders()
            } catch {
                errorNotice = error.localizedDescription
            }
        }
    }
}
