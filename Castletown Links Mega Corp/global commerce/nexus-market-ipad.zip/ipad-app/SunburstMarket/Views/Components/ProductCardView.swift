import SwiftUI

struct ProductCardView: View {
    let product: ProductCard
    let onSelect: () -> Void

    var body: some View {
        Button(action: onSelect) {
            VStack(alignment: .leading, spacing: 10) {
                ZStack(alignment: .topLeading) {
                    ProductImageView(urlString: product.primaryImageUrl, altText: product.title)
                        .frame(height: 185)
                        .frame(maxWidth: .infinity)
                        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))

                    if !product.inStock {
                        statusPill("Out of stock", bg: BrandConfig.alertRed)
                            .padding(8)
                    } else if let ref = product.referencePriceMinor, ref > product.startingPriceMinor {
                        let pct = ((ref - product.startingPriceMinor) * 100) / ref
                        statusPill("-\(pct)% vs 30d price", bg: BrandConfig.accentOrange)
                            .padding(8)
                    }
                }

                VStack(alignment: .leading, spacing: 6) {
                    if let reason = product.recommendationReason {
                        Text(reason)
                            .font(.caption2.weight(.medium))
                            .foregroundStyle(BrandConfig.accentOrangeDark)
                            .lineLimit(1)
                    }

                    Text(product.title)
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(BrandConfig.charcoal)
                        .lineLimit(2)
                        .multilineTextAlignment(.leading)

                    HStack(alignment: .firstTextBaseline, spacing: 6) {
                        Text(MoneyFormatter.format(minor: product.startingPriceMinor, currency: product.currency))
                            .font(.title3.weight(.bold))
                            .foregroundStyle(BrandConfig.accentOrangeDark)

                        if let ref = product.referencePriceMinor, ref > product.startingPriceMinor {
                            Text(MoneyFormatter.format(minor: ref, currency: product.currency))
                                .font(.caption)
                                .strikethrough()
                                .foregroundStyle(BrandConfig.slateMuted)
                        }
                    }

                    HStack(spacing: 6) {
                        Text("\(product.variantCount) variant\(product.variantCount == 1 ? "" : "s")")
                            .font(.caption)
                            .foregroundStyle(BrandConfig.slateMuted)
                        if !product.variantSwatches.isEmpty {
                            Text("• " + product.variantSwatches.prefix(3).joined(separator: ", "))
                                .font(.caption)
                                .foregroundStyle(BrandConfig.slateMuted)
                                .lineLimit(1)
                        }
                    }

                    // Sourced delivery estimate vs guaranteed arrival distinction
                    HStack(spacing: 4) {
                        Image(systemName: product.delivery.eligibleForDestination ? (product.delivery.isGuaranteed ? "checkmark.seal.fill" : "truck.box") : "exclamationmark.triangle.fill")
                            .font(.caption2)
                            .foregroundStyle(product.delivery.eligibleForDestination ? (product.delivery.isGuaranteed ? BrandConfig.verifiedGreen : BrandConfig.slateMuted) : BrandConfig.alertRed)

                        if product.delivery.eligibleForDestination {
                            Text(product.delivery.guaranteedBy ?? product.delivery.estimatedWindow)
                                .font(.caption2)
                                .foregroundStyle(product.delivery.isGuaranteed ? BrandConfig.verifiedGreen : BrandConfig.slateMuted)
                                .lineLimit(1)
                        } else {
                            Text("Restricted for destination")
                                .font(.caption2.weight(.semibold))
                                .foregroundStyle(BrandConfig.alertRed)
                                .lineLimit(1)
                        }
                    }

                    if let avg = product.ratingAverage, product.reviewCount > 0 {
                        HStack(spacing: 3) {
                            Image(systemName: "star.fill")
                                .font(.caption2)
                                .foregroundStyle(BrandConfig.accentOrange)
                            Text(String(format: "%.1f (%d verified demo)", avg, product.reviewCount))
                                .font(.caption2)
                                .foregroundStyle(BrandConfig.slateMuted)
                        }
                    }
                }
                .padding(.horizontal, 4)
            }
            .padding(10)
            .background(BrandConfig.cardWhite)
            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .stroke(Color.black.opacity(0.06), lineWidth: 1)
            )
            .shadow(color: Color.black.opacity(0.04), radius: 8, x: 0, y: 3)
        }
        .buttonStyle(.plain)
        .hoverEffect(.lift)
        .accessibilityElement(children: .combine)
        .accessibilityLabel("\(product.title), from \(MoneyFormatter.format(minor: product.startingPriceMinor, currency: product.currency)), \(product.variantCount) variants")
        .accessibilityHint("Opens product details")
    }

    private func statusPill(_ text: String, bg: Color) -> some View {
        Text(text)
            .font(.caption2.weight(.bold))
            .foregroundStyle(.white)
            .padding(.horizontal, 8)
            .padding(.vertical, 4)
            .background(bg)
            .clipShape(Capsule())
    }
}
