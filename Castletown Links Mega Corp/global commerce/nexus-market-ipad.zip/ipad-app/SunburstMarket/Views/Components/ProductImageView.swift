import SwiftUI

/// Renders remote object-storage product imagery via AsyncImage, and provides crisp
/// vector studio artwork for offline `demo://` preview URLs.
struct ProductImageView: View {
    let urlString: String
    let altText: String
    @Environment(AppState.self) private var appState

    var body: some View {
        Group {
            if urlString.hasPrefix("demo://") {
                demoArtwork(for: urlString)
            } else if let resolved = appState.resolveImageURL(urlString) {
                AsyncImage(url: resolved) { phase in
                    switch phase {
                    case .success(let image):
                        image
                            .resizable()
                            .scaledToFill()
                    case .failure:
                        demoArtwork(for: urlString)
                    case .empty:
                        ZStack {
                            BrandConfig.surfaceCanvas
                            ProgressView()
                                .tint(BrandConfig.accentOrange)
                        }
                    @unknown default:
                        demoArtwork(for: urlString)
                    }
                }
            } else {
                demoArtwork(for: urlString)
            }
        }
        .accessibilityLabel(altText)
    }

    @ViewBuilder
    private func demoArtwork(for key: String) -> some View {
        let lower = key.lowercased()
        let (bg, icon, tint): (Color, String, Color) = {
            if lower.contains("kettle") {
                return (Color(red: 0.98, green: 0.94, blue: 0.91), "mug.fill", BrandConfig.accentOrange)
            } else if lower.contains("pen") {
                return (Color(red: 0.97, green: 0.95, blue: 0.90), "pencil.tip", Color(red: 0.72, green: 0.52, blue: 0.16))
            } else if lower.contains("notebook") {
                return (Color(red: 0.95, green: 0.96, blue: 0.98), "book.closed.fill", BrandConfig.accentOrangeDark)
            } else if lower.contains("tote") {
                return (Color(red: 0.97, green: 0.94, blue: 0.92), "bag.fill", Color(red: 0.78, green: 0.34, blue: 0.16))
            } else if lower.contains("tee") {
                return (Color(red: 0.95, green: 0.95, blue: 0.97), "tshirt.fill", BrandConfig.charcoal)
            } else if lower.contains("charger") {
                return (Color(red: 0.94, green: 0.96, blue: 0.99), "bolt.fill", BrandConfig.accentOrange)
            } else {
                return (BrandConfig.surfaceCanvas, "shippingbox.fill", BrandConfig.accentOrange)
            }
        }()

        ZStack {
            LinearGradient(colors: [bg, bg.opacity(0.7)], startPoint: .topLeading, endPoint: .bottomTrailing)
            Circle()
                .fill(tint.opacity(0.14))
                .frame(width: 112, height: 112)
            Image(systemName: icon)
                .font(.system(size: 46, weight: .semibold))
                .foregroundStyle(tint)
        }
    }
}
