import SwiftUI

struct RootSplitView: View {
    @Environment(AppState.self) private var appState
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    @State private var columnVisibility: NavigationSplitViewVisibility = .all
    @State private var showCompactBagSheet = false

    var body: some View {
        @Bindable var state = appState

        NavigationSplitView(columnVisibility: $columnVisibility) {
            List(SidebarDestination.allCases, selection: $state.selectedSidebar) { dest in
                Label {
                    Text(dest.title)
                        .font(.body.weight(.medium))
                } icon: {
                    Image(systemName: dest.systemImage)
                        .foregroundStyle(BrandConfig.accentOrange)
                }
                .tag(dest)
            }
            .navigationTitle(BrandConfig.appName)
            .listStyle(.sidebar)
        } detail: {
            HStack(spacing: 0) {
                mainWorkspace(for: state.selectedSidebar)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)

                // On wider iPad layouts (.regular), show collapsible right-hand Bag Inspector
                if horizontalSizeClass == .regular && state.showBagInspector {
                    Divider()
                    ShoppingBagView(isInspector: true)
                        .frame(width: 340)
                        .transition(.move(edge: .trailing))
                }
            }
        }
        .tint(BrandConfig.accentOrange)
        .overlay(alignment: .bottom) {
            if let toast = state.bannerToast {
                HStack(spacing: 10) {
                    Text(toast)
                        .font(.subheadline.weight(.medium))
                        .foregroundStyle(.white)
                    Button("Dismiss") {
                        state.bannerToast = nil
                    }
                    .font(.caption.weight(.bold))
                    .foregroundStyle(BrandConfig.accentOrange)
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 10)
                .background(BrandConfig.charcoal)
                .clipShape(Capsule())
                .shadow(radius: 8)
                .padding(.bottom, 16)
                .task(id: toast) {
                    try? await Task.sleep(nanoseconds: 3_500_000_000)
                    if state.bannerToast == toast {
                        state.bannerToast = nil
                    }
                }
            }
        }
        // On narrower Split View / Slide Over (.compact), present Shopping Bag as a dedicated sheet
        .sheet(isPresented: $showCompactBagSheet) {
            NavigationStack {
                ShoppingBagView(isInspector: false)
                    .toolbar {
                        ToolbarItem(placement: .cancellationAction) {
                            Button("Close") { showCompactBagSheet = false }
                        }
                    }
            }
        }
        .sheet(isPresented: $state.showCheckoutSheet) {
            CheckoutFlowView()
        }
        .sheet(isPresented: $state.showAssistantSheet) {
            AssistantSheetView()
        }
        .onChange(of: state.showBagInspector) { _, newValue in
            if horizontalSizeClass == .compact && newValue {
                showCompactBagSheet = true
                state.showBagInspector = false
            }
        }
    }

    @ViewBuilder
    private func mainWorkspace(for destination: SidebarDestination) -> some View {
        switch destination {
        case .discover:
            DiscoverView()
        case .categories:
            CategoriesView()
        case .search:
            SearchView()
        case .saved:
            SavedView()
        case .orders:
            OrdersView()
        case .account:
            AccountView()
        }
    }
}
