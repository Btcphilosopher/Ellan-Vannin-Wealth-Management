import SwiftUI

struct AssistantSheetView: View {
    @Environment(AppState.self) private var appState
    @Environment(\.dismiss) private var dismiss

    @State private var promptInput = ""
    @State private var messages: [(role: String, text: String, mode: String?, products: [ProductCard], confirmation: AssistantPendingConfirmation?)] = [
        (
            role: "assistant",
            text: "Ask me to find products, compare dimensions/materials, explain delivery estimates, summarize return windows, or locate your orders. All answers come from live catalogue and account tools.",
            mode: "scripted_fallback",
            products: [],
            confirmation: nil
        )
    ]
    @State private var isSending = false

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                ScrollView {
                    VStack(alignment: .leading, spacing: 14) {
                        ForEach(Array(messages.enumerated()), id: \.offset) { _, msg in
                            VStack(alignment: .leading, spacing: 8) {
                                HStack {
                                    Text(msg.role == "user" ? "You" : "Shopping Assistant")
                                        .font(.caption.weight(.bold))
                                        .foregroundStyle(msg.role == "user" ? BrandConfig.charcoal : BrandConfig.accentOrangeDark)
                                    if let mode = msg.mode {
                                        Text("(\(mode))")
                                            .font(.caption2)
                                            .foregroundStyle(BrandConfig.slateMuted)
                                    }
                                }
                                Text(msg.text)
                                    .font(.subheadline)

                                if let conf = msg.confirmation {
                                    HStack {
                                        Text(conf.summary).font(.caption.weight(.semibold))
                                        Spacer()
                                        Button("Confirm") {
                                            Task { await send(text: "Confirmed", confirmToken: conf.confirmToken) }
                                        }
                                        .buttonStyle(.borderedProminent)
                                        .tint(BrandConfig.accentOrange)
                                        .controlSize(.small)
                                    }
                                    .padding(10)
                                    .background(BrandConfig.softOrangeTint)
                                    .clipShape(RoundedRectangle(cornerRadius: 10))
                                }

                                ForEach(msg.products) { card in
                                    HStack {
                                        Text("\(card.title) — \(MoneyFormatter.format(minor: card.startingPriceMinor))")
                                            .font(.caption.weight(.semibold))
                                        Spacer()
                                        Button("Open") {
                                            appState.selectedSidebar = .discover
                                            appState.discoverPath.append(card.id)
                                            dismiss()
                                        }
                                        .buttonStyle(.bordered)
                                        .controlSize(.mini)
                                    }
                                    .padding(8)
                                    .background(BrandConfig.surfaceCanvas)
                                    .clipShape(RoundedRectangle(cornerRadius: 8))
                                }
                            }
                            .padding(12)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(msg.role == "user" ? BrandConfig.softOrangeTint : BrandConfig.cardWhite)
                            .clipShape(RoundedRectangle(cornerRadius: 14))
                        }
                    }
                    .padding(16)
                }
                .background(BrandConfig.surfaceCanvas)

                Divider()
                HStack(spacing: 10) {
                    TextField("Ask about products, delivery, returns, or orders…", text: $promptInput)
                        .textFieldStyle(.roundedBorder)
                        .onSubmit {
                            let q = promptInput
                            promptInput = ""
                            Task { await send(text: q, confirmToken: nil) }
                        }
                    Button(isSending ? "…" : "Send") {
                        let q = promptInput
                        promptInput = ""
                        Task { await send(text: q, confirmToken: nil) }
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(BrandConfig.accentOrange)
                    .disabled(promptInput.trimmingCharacters(in: .whitespaces).isEmpty || isSending)
                }
                .padding(12)
                .background(BrandConfig.cardWhite)
            }
            .navigationTitle("Shopping Assistant")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Done") { dismiss() }
                }
            }
        }
    }

    private func send(text: String, confirmToken: String?) async {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        messages.append((role: "user", text: trimmed, mode: nil, products: [], confirmation: nil))
        isSending = true
        do {
            let reply = try await appState.transport.sendAssistantMessage(trimmed, confirmToken: confirmToken)
            messages.append((
                role: "assistant",
                text: reply.reply,
                mode: reply.mode,
                products: reply.referencedProducts,
                confirmation: reply.pendingConfirmation
            ))
        } catch {
            messages.append((role: "assistant", text: error.localizedDescription, mode: "error", products: [], confirmation: nil))
        }
        isSending = false
    }
}
