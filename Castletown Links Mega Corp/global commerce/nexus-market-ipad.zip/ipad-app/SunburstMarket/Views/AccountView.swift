import SwiftUI

struct AccountView: View {
    @Environment(AppState.self) private var appState
    @State private var emailInput = "demo@sunburst.example"
    @State private var passwordInput = "SunburstDemo2026!"
    @State private var serverURLInput = BrandConfig.defaultBaseURL.absoluteString
    @State private var newAddressLine1 = ""
    @State private var newAddressCity = ""

    var body: some View {
        @Bindable var state = appState
        NavigationStack {
            Form {
                Section("Session & Sign-In") {
                    if let ses = appState.session {
                        LabeledContent("Signed in as", value: ses.displayName)
                        LabeledContent("Mode", value: ses.isGuest ? "Guest Checkout Session" : (ses.email ?? "Customer"))
                    }
                    TextField("Email", text: $emailInput)
                        .textInputAutocapitalization(.never)
                        .keyboardType(.emailAddress)
                    SecureField("Password", text: $passwordInput)
                    Button("Sign In to Demo Account") {
                        Task { await appState.signIn(email: emailInput, password: passwordInput) }
                    }
                    .tint(BrandConfig.accentOrange)
                }

                Section("Backend Connection") {
                    Toggle("Use Offline Deterministic Demo Engine", isOn: $state.useOfflineDemoTransport)
                        .onChange(of: state.useOfflineDemoTransport) { _, _ in
                            Task { await appState.bootstrap() }
                        }
                    TextField("FastAPI Base URL", text: $serverURLInput)
                        .textInputAutocapitalization(.never)
                    Button("Update Server URL") {
                        if let url = URL(string: serverURLInput) {
                            Task {
                                await appState.liveClient.updateBaseURL(url)
                                await appState.bootstrap()
                            }
                        }
                    }
                }

                if let summary = appState.accountSummary {
                    Section("Notification Preferences") {
                        Toggle("Order & Shipment Updates", isOn: Binding(
                            get: { summary.preferences.orderUpdatesEnabled },
                            set: { val in
                                var prefs = summary.preferences
                                prefs.orderUpdatesEnabled = val
                                Task {
                                    _ = try? await appState.transport.updatePreferences(prefs)
                                    await appState.loadAccount()
                                }
                            }
                        ))
                        Toggle("Price Drop Alerts", isOn: Binding(
                            get: { summary.preferences.priceDropAlertsEnabled },
                            set: { val in
                                var prefs = summary.preferences
                                prefs.priceDropAlertsEnabled = val
                                Task {
                                    _ = try? await appState.transport.updatePreferences(prefs)
                                    await appState.loadAccount()
                                }
                            }
                        ))
                        Toggle("Promotional Announcements", isOn: Binding(
                            get: { summary.preferences.promoAlertsEnabled },
                            set: { val in
                                var prefs = summary.preferences
                                prefs.promoAlertsEnabled = val
                                Task {
                                    _ = try? await appState.transport.updatePreferences(prefs)
                                    await appState.loadAccount()
                                }
                            }
                        ))
                    }

                    Section("Saved Addresses") {
                        ForEach(summary.addresses) { addr in
                            VStack(alignment: .leading) {
                                Text("\(addr.label) — \(addr.recipientName)")
                                    .font(.subheadline.weight(.semibold))
                                Text("\(addr.line1), \(addr.city), \(addr.region) \(addr.postalCode) (\(addr.countryCode))")
                                    .font(.caption)
                                    .foregroundStyle(BrandConfig.slateMuted)
                            }
                        }
                        HStack {
                            TextField("New street address", text: $newAddressLine1)
                            TextField("City", text: $newAddressCity)
                            Button("Add") {
                                guard !newAddressLine1.isEmpty else { return }
                                let addr = AddressRecord(id: "new", label: "Work", recipientName: summary.displayName, line1: newAddressLine1, line2: "", city: newAddressCity.isEmpty ? "San Francisco" : newAddressCity, region: "CA", postalCode: "94107", countryCode: appState.destinationCountry, isDefault: false)
                                newAddressLine1 = ""; newAddressCity = ""
                                Task {
                                    _ = try? await appState.transport.addAddress(addr)
                                    await appState.loadAccount()
                                }
                            }
                        }
                    }

                    Section("Device Sessions (Keychain Protected)") {
                        ForEach(summary.sessions) { s in
                            HStack {
                                VStack(alignment: .leading) {
                                    Text("\(s.deviceName) (\(s.platform))")
                                        .font(.subheadline.weight(.medium))
                                    Text(s.revokedAt == nil ? (s.isCurrent ? "Current active session" : "Active") : "Revoked")
                                        .font(.caption)
                                        .foregroundStyle(s.revokedAt == nil ? BrandConfig.verifiedGreen : BrandConfig.alertRed)
                                }
                                Spacer()
                                if s.revokedAt == nil && !s.isCurrent {
                                    Button("Revoke") {
                                        Task {
                                            try? await appState.transport.revokeSession(id: s.id)
                                            await appState.loadAccount()
                                        }
                                    }
                                    .buttonStyle(.bordered)
                                }
                            }
                        }
                    }
                }

                Section("Demo Edge-Case Lab") {
                    Button("Simulate Server Price Change on Bag Item") {
                        Task {
                            await appState.demoTransport.simulateServerPriceChangeOnFirstBagItem()
                            await appState.refreshBag()
                            appState.showBagInspector = true
                            appState.bannerToast = "Simulated server price update — check Bag Inspector"
                        }
                    }
                    Button("Request Account Deletion", role: .destructive) {
                        Task {
                            try? await appState.transport.requestAccountDeletion()
                            appState.keychain.clearSession()
                            appState.bannerToast = "Account deletion requested & sessions revoked"
                        }
                    }
                }
            }
            .navigationTitle("Account & Privacy")
            .task {
                await appState.loadAccount()
            }
        }
    }
}
