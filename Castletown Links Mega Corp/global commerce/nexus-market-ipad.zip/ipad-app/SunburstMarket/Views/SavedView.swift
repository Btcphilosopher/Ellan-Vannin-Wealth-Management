import SwiftUI

struct SavedView: View {
    @Environment(AppState.self) private var appState

    private let gridColumns = [
        GridItem(.adaptive(minimum: 220, maximum: 280), spacing: 16)
    ]

    var body: some View {
        @Bindable var state = appState
        NavigationStack(path: $state.savedPath) {
            Group {
                if appState.savedProducts.isEmpty {
                    ContentUnavailableView(
                        "No Saved Items Yet",
                        systemImage: "heart",
                        description: Text("Tap the heart icon on any product to save it here.")
                    )
                } else {
                    ScrollView {
                        LazyVGrid(columns: gridColumns, spacing: 16) {
                            ForEach(appState.savedProducts) { product in
                                ProductCardView(product: product) {
                                    appState.savedPath.append(product.id)
                                }
                            }
                        }
                        .padding(20)
                    }
                }
            }
            .background(BrandConfig.surfaceCanvas)
            .navigationTitle("Saved Items")
            .navigationDestination(for: String.self) { productId in
                ProductDetailView(productId: productId)
            }
            .task {
                await appState.loadSaved()
            }
        }
    }
}
