import SwiftUI

struct CheckoutFlowView: View {
    @Environment(AppState.self) private var appState
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        @Bindable var vm = appState.checkoutVM
        NavigationStack {
            VStack(spacing: 0) {
                demoBanner
                stepIndicator(current: vm.step)
                Divider()

                ScrollView {
                    VStack(alignment: .leading, spacing: 18) {
                        switch vm.step {
                        case .address:
                            addressStep(vm: vm)
                        case .delivery:
                            deliveryStep(vm: vm)
                        case .review:
                            reviewStep(vm: vm)
                        case .payment:
                            paymentStep(vm: vm)
                        case .confirmation:
                            confirmationStep(vm: vm)
                        }
                    }
                    .padding(24)
                    .frame(maxWidth: 680)
                    .frame(maxWidth: .infinity)
                }
                .background(BrandConfig.surfaceCanvas)
            }
            .navigationTitle("Demo Checkout")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Close") { dismiss() }
                }
            }
        }
    }

    private var demoBanner: some View {
        HStack {
            Image(systemName: "info.circle.fill")
            Text("DEMO CHECKOUT — No real payment or card numbers collected. Hosted provider adapter simulation.")
                .font(.caption.weight(.semibold))
            Spacer()
        }
        .foregroundStyle(.white)
        .padding(.horizontal, 16)
        .padding(.vertical, 8)
        .background(BrandConfig.charcoal)
    }

    private func stepIndicator(current: CheckoutStep) -> some View {
        HStack(spacing: 8) {
            ForEach(CheckoutStep.allCases) { step in
                HStack(spacing: 6) {
                    Circle()
                        .fill(step.rawValue <= current.rawValue ? BrandConfig.accentOrange : Color.gray.opacity(0.3))
                        .frame(width: 24, height: 24)
                        .overlay(
                            Text("\(step.rawValue + 1)")
                                .font(.caption2.weight(.bold))
                                .foregroundStyle(.white)
                        )
                    Text(step.title)
                        .font(.caption.weight(step == current ? .bold : .regular))
                        .foregroundStyle(step == current ? BrandConfig.charcoal : BrandConfig.slateMuted)
                }
                if step != .confirmation {
                    Rectangle().fill(Color.gray.opacity(0.25)).frame(height: 1)
                }
            }
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 12)
        .background(BrandConfig.cardWhite)
    }

    @ViewBuilder
    private func addressStep(vm: CheckoutViewModel) -> some View {
        @Bindable var bindVM = vm
        VStack(alignment: .leading, spacing: 12) {
            Text("1. Shipping Address")
                .font(.title3.weight(.bold))
            TextField("Recipient Name", text: $bindVM.address.recipientName).textFieldStyle(.roundedBorder)
            TextField("Street Address", text: $bindVM.address.line1).textFieldStyle(.roundedBorder)
            TextField("Apt / Suite (optional)", text: $bindVM.address.line2).textFieldStyle(.roundedBorder)
            HStack {
                TextField("City", text: $bindVM.address.city).textFieldStyle(.roundedBorder)
                TextField("State / Region", text: $bindVM.address.region).textFieldStyle(.roundedBorder)
            }
            HStack {
                TextField("Postal Code", text: $bindVM.address.postalCode).textFieldStyle(.roundedBorder)
                TextField("Country (US, CA, GB)", text: $bindVM.address.countryCode).textFieldStyle(.roundedBorder)
            }
            Button("Continue to Delivery") {
                vm.step = .delivery
                Task { await vm.refreshPreview(using: appState.transport) }
            }
            .buttonStyle(.borderedProminent)
            .tint(BrandConfig.accentOrange)
        }
        .padding(20)
        .background(BrandConfig.cardWhite)
        .clipShape(RoundedRectangle(cornerRadius: 18))
    }

    @ViewBuilder
    private func deliveryStep(vm: CheckoutViewModel) -> some View {
        @Bindable var bindVM = vm
        VStack(alignment: .leading, spacing: 14) {
            Text("2. Delivery Speed & Seller Fulfillments")
                .font(.title3.weight(.bold))

            Picker("Delivery Method", selection: $bindVM.deliveryMethod) {
                Text("Standard Delivery (Seller Thresholds Apply)").tag("standard")
                Text("Express Delivery (+$7.99 per seller)").tag("express")
            }
            .pickerStyle(.segmented)
            .onChange(of: bindVM.deliveryMethod) { _, _ in
                Task { await vm.refreshPreview(using: appState.transport) }
            }

            if let preview = vm.preview {
                ForEach(preview.sellerBreakdowns) { seller in
                    HStack {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(seller.sellerName).font(.subheadline.weight(.semibold))
                            Text("\(seller.itemCount) item(s) • \(seller.estimatedWindow)")
                                .font(.caption).foregroundStyle(BrandConfig.slateMuted)
                            if let g = seller.guaranteedBy {
                                Text(g).font(.caption2.weight(.semibold)).foregroundStyle(BrandConfig.verifiedGreen)
                            }
                        }
                        Spacer()
                        Text(seller.shippingMinor == 0 ? "FREE" : MoneyFormatter.format(minor: seller.shippingMinor))
                            .font(.subheadline.weight(.bold))
                    }
                    .padding(12)
                    .background(BrandConfig.surfaceCanvas)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                }
            }

            HStack {
                Button("Back") { vm.step = .address }.buttonStyle(.bordered)
                Spacer()
                Button("Review Order") {
                    vm.step = .review
                    Task { await vm.refreshPreview(using: appState.transport) }
                }
                .buttonStyle(.borderedProminent)
                .tint(BrandConfig.accentOrange)
            }
        }
        .padding(20)
        .background(BrandConfig.cardWhite)
        .clipShape(RoundedRectangle(cornerRadius: 18))
    }

    @ViewBuilder
    private func reviewStep(vm: CheckoutViewModel) -> some View {
        @Bindable var bindVM = vm
        VStack(alignment: .leading, spacing: 14) {
            Text("3. Server-Authoritative Order Review")
                .font(.title3.weight(.bold))

            HStack {
                TextField("Promo code (e.g. WELCOME15, DESK10, HOME20)", text: $bindVM.promoInput)
                    .textFieldStyle(.roundedBorder)
                Button("Apply") {
                    Task { await vm.addPromoCode(vm.promoInput, using: appState.transport) }
                }
                .buttonStyle(.bordered)
            }

            if !vm.appliedCodes.isEmpty {
                HStack(spacing: 8) {
                    ForEach(vm.appliedCodes, id: \.self) { code in
                        HStack(spacing: 4) {
                            Text(code).font(.caption.weight(.bold))
                            Button {
                                Task { await vm.removePromoCode(code, using: appState.transport) }
                            } label: {
                                Image(systemName: "xmark.circle.fill").font(.caption)
                            }
                        }
                        .padding(.horizontal, 10)
                        .padding(.vertical, 5)
                        .background(BrandConfig.softOrangeTint)
                        .clipShape(Capsule())
                    }
                }
            }

            if let err = vm.errorMessage {
                Text(err).font(.subheadline).foregroundStyle(BrandConfig.alertRed)
            }

            if let preview = vm.preview {
                VStack(alignment: .leading, spacing: 8) {
                    LabeledContent("Items Subtotal", value: MoneyFormatter.format(minor: preview.subtotalMinor, currency: preview.currency))
                    LabeledContent("Promotional Discount", value: "-\(MoneyFormatter.format(minor: preview.discountMinor, currency: preview.currency))")
                        .foregroundStyle(BrandConfig.verifiedGreen)
                    Text(preview.discountExplanation)
                        .font(.caption)
                        .foregroundStyle(BrandConfig.slateMuted)

                    ForEach(preview.rejectedPromotions, id: \.self) { rej in
                        Text("Code \(rej["code"] ?? ""): \(rej["reason"] ?? "")")
                            .font(.caption)
                            .foregroundStyle(BrandConfig.warningAmber)
                    }

                    LabeledContent("Shipping", value: MoneyFormatter.format(minor: preview.shippingMinor, currency: preview.currency))
                    LabeledContent("Tax (\(String(format: "%.2f%%", Double(preview.taxRateBps) / 100.0)))", value: MoneyFormatter.format(minor: preview.taxMinor, currency: preview.currency))
                    Divider()
                    LabeledContent("Authoritative Total", value: MoneyFormatter.format(minor: preview.totalMinor, currency: preview.currency))
                        .font(.title3.weight(.bold))
                }
                .padding(14)
                .background(BrandConfig.surfaceCanvas)
                .clipShape(RoundedRectangle(cornerRadius: 12))
            }

            HStack {
                Button("Back") { vm.step = .delivery }.buttonStyle(.bordered)
                Spacer()
                Button("Proceed to Demo Payment") { vm.step = .payment }
                    .buttonStyle(.borderedProminent)
                    .tint(BrandConfig.accentOrange)
                    .disabled(vm.preview == nil)
            }
        }
        .padding(20)
        .background(BrandConfig.cardWhite)
        .clipShape(RoundedRectangle(cornerRadius: 18))
    }

    @ViewBuilder
    private func paymentStep(vm: CheckoutViewModel) -> some View {
        @Bindable var bindVM = vm
        VStack(alignment: .leading, spacing: 14) {
            Text("4. Hosted Demo Payment Adapter")
                .font(.title3.weight(.bold))
            Text("Select a simulated payment outcome to verify atomic reservations, failed-payment stock release, and idempotent retry behavior. No card numbers are collected.")
                .font(.subheadline)
                .foregroundStyle(BrandConfig.slateMuted)

            Picker("Simulation Outcome", selection: $bindVM.simulationOutcome) {
                ForEach(CheckoutSimulationOutcome.allCases) { outcome in
                    Text(outcome.displayName).tag(outcome)
                }
            }
            .pickerStyle(.inline)

            Text("Idempotency-Key: \(vm.activeIdempotencyKey)")
                .font(.caption.monospaced())
                .foregroundStyle(BrandConfig.slateMuted)

            if let err = vm.errorMessage {
                Text(err).font(.subheadline).foregroundStyle(BrandConfig.alertRed)
            }

            HStack {
                Button("Back") { vm.step = .review }.buttonStyle(.bordered)
                Spacer()
                Button(vm.isBusy ? "Processing…" : "Confirm Demo Payment") {
                    Task {
                        await vm.submitDemoPayment(using: appState.transport)
                        await appState.refreshBag()
                        await appState.loadOrders()
                    }
                }
                .buttonStyle(.borderedProminent)
                .tint(BrandConfig.accentOrange)
                .disabled(vm.isBusy)
            }
        }
        .padding(20)
        .background(BrandConfig.cardWhite)
        .clipShape(RoundedRectangle(cornerRadius: 18))
    }

    @ViewBuilder
    private func confirmationStep(vm: CheckoutViewModel) -> some View {
        if let conf = vm.confirmation {
            VStack(alignment: .leading, spacing: 14) {
                HStack(spacing: 10) {
                    Image(systemName: conf.paymentStatus == "paid" ? "checkmark.seal.fill" : "exclamationmark.triangle.fill")
                        .font(.largeTitle)
                        .foregroundStyle(conf.paymentStatus == "paid" ? BrandConfig.verifiedGreen : BrandConfig.warningAmber)
                    VStack(alignment: .leading) {
                        Text("Order \(conf.order.orderNumber)")
                            .font(.title2.weight(.bold))
                        Text("Order Status: \(conf.order.orderStatus) • Payment: \(conf.paymentStatus)")
                            .font(.subheadline)
                            .foregroundStyle(BrandConfig.slateMuted)
                    }
                }

                Text(conf.message)
                    .font(.subheadline)

                if conf.replayedFromIdempotency {
                    Label("Replayed safely from Idempotency-Key — zero duplicate order created.", systemImage: "arrow.triangle.2.circlepath.circle.fill")
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(BrandConfig.verifiedGreen)
                }

                HStack(spacing: 12) {
                    Button("Simulate Retry (Same Idempotency-Key)") {
                        Task { await vm.retryWithSameIdempotencyKey(using: appState.transport) }
                    }
                    .buttonStyle(.bordered)

                    Button("Track Order") {
                        appState.selectedSidebar = .orders
                        appState.ordersPath = [conf.order.id]
                        dismiss()
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(BrandConfig.accentOrange)
                }
            }
            .padding(20)
            .background(BrandConfig.cardWhite)
            .clipShape(RoundedRectangle(cornerRadius: 18))
        }
    }
}
