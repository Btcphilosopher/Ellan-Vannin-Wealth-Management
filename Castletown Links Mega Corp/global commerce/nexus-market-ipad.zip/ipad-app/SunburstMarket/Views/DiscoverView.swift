import SwiftUI

struct DiscoverView: View {
    @Environment(AppState.self) private var appState
    @State private var showDestinationPopover = false
    @State private var draftCountry = "US"
    @State private var draftPostal = "94107"
    @State private var quickSearchText = ""

    private let gridColumns = [
        GridItem(.adaptive(minimum: 220, maximum: 290), spacing: 16)
    ]

    var body: some View {
        @Bindable var state = appState
        NavigationStack(path: $state.discoverPath) {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    topActionBar

                    if let data = appState.discoverData {
                        if let banner = data.banner {
                            editorialBanner(banner)
                        }

                        categoryShortcuts(data.categories)

                        if !data.recentlyViewed.isEmpty {
                            recentlyViewedSection(data.recentlyViewed)
                        }

                        featuredGrid(data.featuredProducts)

                        ForEach(data.collections) { collection in
                            explainableCollection(collection)
                        }
                    } else if appState.discoverLoading {
                        ProgressView("Loading curated catalog…")
                            .frame(maxWidth: .infinity, minHeight: 280)
                    } else if let err = appState.discoverError {
                        ContentUnavailableView {
                            Label("Could Not Load Discover", systemImage: "wifi.exclamationmark")
                        } description: {
                            Text(err)
                        } actions: {
                            Button("Retry") {
                                Task { await appState.loadDiscover() }
                            }
                            .buttonStyle(.borderedProminent)
                            .tint(BrandConfig.accentOrange)
                        }
                    }
                }
                .padding(20)
            }
            .background(BrandConfig.surfaceCanvas)
            .navigationTitle(BrandConfig.appName)
            .navigationDestination(for: String.self) { productId in
                ProductDetailView(productId: productId)
            }
            .toolbar {
                ToolbarItemGroup(placement: .topBarTrailing) {
                    Button {
                        appState.showAssistantSheet = true
                    } label: {
                        Label("Assistant", systemImage: "bubble.left.and.sparkles")
                    }
                    .accessibilityLabel("Open shopping assistant")

                    Button {
                        appState.showBagInspector.toggle()
                    } label: {
                        Label("Bag (\(appState.bagItemCount))", systemImage: "bag.fill")
                    }
                    .tint(BrandConfig.accentOrange)
                    .accessibilityLabel("Toggle shopping bag inspector, \(appState.bagItemCount) items")
                }
            }
        }
    }

    private var topActionBar: some View {
        ViewThatFits(in: .horizontal) {
            HStack(spacing: 12) {
                searchShortcutBar
                destinationChip
            }
            VStack(alignment: .leading, spacing: 10) {
                searchShortcutBar
                destinationChip
            }
        }
    }

    private var searchShortcutBar: some View {
        HStack(spacing: 10) {
            Image(systemName: "magnifyingglass")
                .foregroundStyle(BrandConfig.accentOrange)
            TextField("Search stoneware, brass pens, GaN chargers…", text: $quickSearchText)
                .textFieldStyle(.plain)
                .submitLabel(.search)
                .onSubmit {
                    appState.searchVM.filters.query = quickSearchText
                    appState.selectedSidebar = .search
                    Task {
                        await appState.searchVM.runSearch(using: appState.transport, country: appState.destinationCountry)
                    }
                }
            Button("Search") {
                appState.searchVM.filters.query = quickSearchText
                appState.selectedSidebar = .search
                Task {
                    await appState.searchVM.runSearch(using: appState.transport, country: appState.destinationCountry)
                }
            }
            .buttonStyle(.borderedProminent)
            .tint(BrandConfig.accentOrange)
            .controlSize(.small)
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
        .background(BrandConfig.cardWhite)
        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .stroke(BrandConfig.accentOrange.opacity(0.35), lineWidth: 1.5)
        )
    }

    private var destinationChip: some View {
        Button {
            draftCountry = appState.destinationCountry
            draftPostal = appState.destinationPostal
            showDestinationPopover = true
        } label: {
            HStack(spacing: 8) {
                Image(systemName: "location.circle.fill")
                    .foregroundStyle(BrandConfig.accentOrange)
                VStack(alignment: .leading, spacing: 1) {
                    Text("Deliver to")
                        .font(.caption2)
                        .foregroundStyle(BrandConfig.slateMuted)
                    Text("\(appState.destinationCountry) • \(appState.destinationPostal)")
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(BrandConfig.charcoal)
                }
                Image(systemName: "chevron.down")
                    .font(.caption)
                    .foregroundStyle(BrandConfig.slateMuted)
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 8)
            .background(BrandConfig.cardWhite)
            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .stroke(Color.black.opacity(0.08), lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
        .hoverEffect(.highlight)
        .popover(isPresented: $showDestinationPopover) {
            VStack(alignment: .leading, spacing: 14) {
                Text("Delivery Destination")
                    .font(.headline)
                Text("Updates shipping eligibility, restrictions, and delivery estimates.")
                    .font(.caption)
                    .foregroundStyle(BrandConfig.slateMuted)
                Picker("Country", selection: $draftCountry) {
                    Text("United States (US)").tag("US")
                    Text("Canada (CA)").tag("CA")
                    Text("United Kingdom (GB) — tests restrictions").tag("GB")
                    Text("Australia (AU) — tests restrictions").tag("AU")
                }
                .pickerStyle(.menu)

                TextField("Postal / ZIP Code", text: $draftPostal)
                    .textFieldStyle(.roundedBorder)

                HStack {
                    Spacer()
                    Button("Apply") {
                        showDestinationPopover = false
                        Task {
                            await appState.updateDestination(country: draftCountry, postal: draftPostal)
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(BrandConfig.accentOrange)
                }
            }
            .padding()
            .frame(width: 320)
        }
    }

    private func editorialBanner(_ banner: PromotionBanner) -> some View {
        HStack(spacing: 16) {
            VStack(alignment: .leading, spacing: 6) {
                HStack(spacing: 8) {
                    Text("CODE: \(banner.code)")
                        .font(.caption.weight(.bold))
                        .padding(.horizontal, 10)
                        .padding(.vertical, 4)
                        .background(.white)
                        .foregroundStyle(BrandConfig.accentOrangeDark)
                        .clipShape(Capsule())

                    // Real countdown shown ONLY when a configured offer has an explicit endsAt timestamp
                    if let endsAt = banner.endsAt, endsAt > Date() {
                        Text("Ends \(endsAt, style: .relative)")
                            .font(.caption.weight(.semibold))
                            .foregroundStyle(.white.opacity(0.95))
                    }
                }
                Text(banner.title)
                    .font(.title2.weight(.bold))
                    .foregroundStyle(.white)
                Text(banner.description)
                    .font(.subheadline)
                    .foregroundStyle(.white.opacity(0.92))
            }
            Spacer()
            Button("Apply in Bag") {
                appState.checkoutVM.promoInput = banner.code
                if !appState.checkoutVM.appliedCodes.contains(banner.code) {
                    appState.checkoutVM.appliedCodes.append(banner.code)
                }
                appState.showBagInspector = true
                appState.bannerToast = "Saved promo code \(banner.code) for checkout"
            }
            .buttonStyle(.borderedProminent)
            .tint(.white)
            .foregroundStyle(BrandConfig.accentOrangeDark)
        }
        .padding(22)
        .background(
            LinearGradient(
                colors: [BrandConfig.accentOrange, BrandConfig.accentOrangeDark],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        )
        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
    }

    private func categoryShortcuts(_ categories: [CategoryItem]) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Shop by Category")
                .font(.title3.weight(.bold))
                .foregroundStyle(BrandConfig.charcoal)

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 12) {
                    ForEach(categories) { cat in
                        Button {
                            appState.searchVM.filters.categoryId = cat.id
                            appState.selectedSidebar = .search
                            Task {
                                await appState.searchVM.runSearch(using: appState.transport, country: appState.destinationCountry)
                            }
                        } label: {
                            HStack(spacing: 8) {
                                Image(systemName: cat.iconName)
                                    .foregroundStyle(BrandConfig.accentOrange)
                                Text(cat.name)
                                    .font(.subheadline.weight(.semibold))
                                    .foregroundStyle(BrandConfig.charcoal)
                            }
                            .padding(.horizontal, 16)
                            .padding(.vertical, 10)
                            .background(BrandConfig.cardWhite)
                            .clipShape(Capsule())
                            .overlay(
                                Capsule().stroke(Color.black.opacity(0.08), lineWidth: 1)
                            )
                        }
                        .buttonStyle(.plain)
                        .hoverEffect(.lift)
                    }
                }
            }
        }
    }

    private func recentlyViewedSection(_ items: [ProductCard]) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Recently Viewed")
                .font(.title3.weight(.bold))
                .foregroundStyle(BrandConfig.charcoal)

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 14) {
                    ForEach(items) { product in
                        ProductCardView(product: product) {
                            appState.discoverPath.append(product.id)
                        }
                        .frame(width: 240)
                    }
                }
            }
        }
    }

    private func featuredGrid(_ products: [ProductCard]) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Featured Finds")
                .font(.title3.weight(.bold))
                .foregroundStyle(BrandConfig.charcoal)

            LazyVGrid(columns: gridColumns, spacing: 16) {
                ForEach(products) { product in
                    ProductCardView(product: product) {
                        appState.discoverPath.append(product.id)
                    }
                }
            }
        }
    }

    private func explainableCollection(_ collection: RecommendedCollection) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            VStack(alignment: .leading, spacing: 2) {
                Text(collection.title)
                    .font(.title3.weight(.bold))
                    .foregroundStyle(BrandConfig.charcoal)
                Text(collection.explanation)
                    .font(.caption)
                    .foregroundStyle(BrandConfig.slateMuted)
            }
            LazyVGrid(columns: gridColumns, spacing: 16) {
                ForEach(collection.products) { product in
                    ProductCardView(product: product) {
                        appState.discoverPath.append(product.id)
                    }
                }
            }
        }
    }
}
