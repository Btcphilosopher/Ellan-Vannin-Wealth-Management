import XCTest

final class SunburstMarketUITests: XCTestCase {
    override func setUpWithError() throws {
        continueAfterFailure = false
    }

    func testCompleteProductToOrderAndReturnWorkflowOnIPad() throws {
        let app = XCUIApplication()
        app.launch()

        // Ensure Discover screen & adaptive sidebar appear
        XCTAssertTrue(app.navigationBars["Sunburst Market"].waitForExistence(timeout: 5))

        // Navigate to Search, add items, and verify Bag Inspector
        app.buttons["Search"].firstMatch.tap()
        let searchField = app.textFields["Search products, SKUs, sellers…"]
        if searchField.waitForExistence(timeout: 3) {
            searchField.tap()
            searchField.typeText("Kettle")
        }
    }
}
