# Sunburst Market — iPad Shopping App & FastAPI Commerce Backend

Replaceable, Temu-inspired iPadOS SwiftUI shopping application backed by Python/FastAPI, PostgreSQL 16, Alembic migrations, and S3-compatible object storage (MinIO).

## Repository Layout

- `/ipad-app/` — Native iPadOS 17+ Swift & SwiftUI app (`SunburstMarket.xcodeproj`)
  - `SunburstMarket/App/` — `SunburstMarketApp.swift` (`SceneStorage`, hardware keyboard shortcuts), `BrandConfig.swift`
  - `SunburstMarket/Models/` — `DomainModels.swift` (Codable/Sendable minor-unit models)
  - `SunburstMarket/Services/` — `APIClient.swift` (`actor`), `KeychainStore.swift`, `DemoTransportService.swift`
  - `SunburstMarket/State/` — `@Observable` `AppState`, `SearchViewModel` (task cancellation & generation guard), `CheckoutViewModel` (idempotent key management)
  - `SunburstMarket/Views/` — Adaptive `NavigationSplitView` (`RootSplitView`), `DiscoverView`, `CategoriesView`, `SearchView`, `ProductDetailView`, `ShoppingBagView` (collapsible Bag Inspector + compact Bag screen), `CheckoutFlowView`, `OrdersView`, `SavedView`, `AccountView`, `AssistantSheetView`
  - `SunburstMarketTests/` & `SunburstMarketUITests/` — XCTest & XCUITest suites
- `/backend/` — FastAPI + PostgreSQL + MinIO backend
  - `docker-compose.yml` & `Dockerfile` — PostgreSQL 16, MinIO S3 object storage, bucket setup, FastAPI service
  - `alembic/` — Initial schema migration (`0001_initial_schema.py`)
  - `app/models/` — Catalogue, sellers, variants, SKUs, price history, documents, reviews, promotions, customers, sessions, bags, atomic reservations, orders, multi-seller fulfillments, payments, returns, idempotency
  - `app/services/` — Server-authoritative integer-minor pricing & promotion engine, atomic reservations & expiry sweep, idempotent checkout & HMAC webhook reconciliation, synthetic tracking & refund state machine, permissioned assistant, idempotent demo seed with studio PNG generation
  - `app/cli.py` — Admin CLI (`seed-demo`, `update-price`, `update-stock`, `transition-refund`, `release-expired`, `integration-health`)
  - `docs/API.md` — Endpoint and security reference
  - `tests/` — Pytest async integration suite

## Startup Instructions

### 1. Backend (Docker Compose: PostgreSQL + MinIO + FastAPI)

```bash
cd backend
cp .env.example .env
docker compose up --build
```

- API & Interactive Docs: `http://localhost:8000/docs`
- MinIO Console: `http://localhost:9001` (`minioadmin` / `minioadmin_dev_pw`)
- Demo Account: `demo@sunburst.example` / `SunburstDemo2026!`
- Promotion Codes: `WELCOME15`, `DESK10`, `HOME20`

Run backend tests locally:

```bash
cd backend
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
pytest -v
```

### 2. Native iPad App (macOS + Xcode 15/16)

1. Open `/ipad-app/SunburstMarket.xcodeproj` in Xcode on macOS.
2. Select an **iPad** simulator (e.g., iPad Pro 13-inch) and press **Cmd+R** to run, or **Cmd+U** to run `SunburstMarketTests` and `SunburstMarketUITests`.
3. In the app, `AppState` connects to `http://localhost:8000` when the FastAPI backend is running, or automatically engages `DemoTransportService` when offline so all walkthroughs remain testable.
