package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.*
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28]) // Use 28 or another standard target for Robolectric tests in this environment
class ExampleRobolectricTest {

    private lateinit var db: AppDatabase
    private lateinit var repository: FinanceRepository

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = AppDatabase.getDatabase(context)
        repository = FinanceRepository(db)
    }

    @Test
    fun `read string from context matches super app launcher name`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("MYNT//GCASH", appName)
    }

    @Test
    fun `double entry financial ledger updates balances with centavos precision`() = runBlocking {
        // Ensure db is seeded
        repository.seedDatabaseIfNeeded()

        val initialUser = db.userDao().getUserSync()!!
        val initialWallet = initialUser.walletBalance

        // 1. Execute a Send Money transaction of 1,500.00
        val tx = repository.sendMoney(recipient = "Mama", amount = 1500.0, message = "Pang-groceries")
        assertTrue(tx != null)
        assertEquals("SEND", tx!!.type)
        assertEquals(1500.0, tx.amount, 0.0)

        // 2. Assert double-entry invariant: wallet decrements exactly by the transfer amount
        val nextUser = db.userDao().getUserSync()!!
        val expectedBalance = initialWallet - 1500.0
        assertEquals(expectedBalance, nextUser.walletBalance, 0.0)
    }

    @Test
    fun `fraud detection engine flags critical risk on large transactions`() {
        // 1. Normal small transaction should be LOW risk
        val risk1 = calculateRisk("ABC Sari-Sari Store", 185.0)
        assertEquals("LOW", risk1)

        // 2. Suspicious large merchant transaction should flag HIGH or CRITICAL
        val risk2 = calculateRisk("Unknown Online Merchant", 18500.0)
        assertEquals("CRITICAL", risk2)
    }

    private fun calculateRisk(merchant: String, amount: Double): String {
        return when {
            amount >= 15000.0 -> "CRITICAL"
            amount >= 8000.0 && (merchant.lowercase().contains("unknown") || merchant.lowercase().contains("online")) -> "HIGH"
            amount >= 3000.0 -> "MEDIUM"
            else -> "LOW"
        }
    }
}
