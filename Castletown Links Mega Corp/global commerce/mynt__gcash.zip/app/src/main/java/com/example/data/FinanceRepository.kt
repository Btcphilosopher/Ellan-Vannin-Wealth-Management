package com.example.data

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

class FinanceRepository(private val db: AppDatabase) {

    val user: Flow<UserEntity?> = db.userDao().getUser()
    val transactions: Flow<List<TransactionEntity>> = db.transactionDao().getAllTransactions()
    val savingsGoals: Flow<List<SavingsGoalEntity>> = db.savingsGoalDao().getAllGoals()
    val loans: Flow<List<LoanEntity>> = db.loanDao().getAllLoans()
    val billers: Flow<List<BillerEntity>> = db.billerDao().getAllBillers()
    val merchants: Flow<List<MerchantEntity>> = db.merchantDao().getAllMerchants()
    val family: Flow<List<FamilyMemberEntity>> = db.familyMemberDao().getAllFamily()
    val commuteTrips: Flow<List<CommuteTripEntity>> = db.commuteTripDao().getAllTrips()
    val lessons: Flow<List<LessonEntity>> = db.lessonDao().getAllLessons()

    // Seeds the initial dataset for Maria Santos if the user table is empty.
    suspend fun seedDatabaseIfNeeded() = withContext(Dispatchers.IO) {
        val currentUser = db.userDao().getUserSync()
        if (currentUser == null) {
            Log.d("FinanceRepository", "Seeding initial financial data...")
            // 1. User
            db.userDao().insertUser(UserEntity())

            // 2. Savings Goals
            db.savingsGoalDao().insertGoal(SavingsGoalEntity(title = "Emergency Fund", targetAmount = 100000.0, currentAmount = 45000.0, category = "Emergency Fund"))
            db.savingsGoalDao().insertGoal(SavingsGoalEntity(title = "Vacation", targetAmount = 40000.0, currentAmount = 18500.0, category = "Vacation"))
            db.savingsGoalDao().insertGoal(SavingsGoalEntity(title = "Tuition", targetAmount = 60000.0, currentAmount = 35000.0, category = "Tuition"))

            // 3. Billers
            db.billerDao().insertBiller(BillerEntity(name = "Meralco", accountNo = "1029384756", balanceDue = 3850.20, dueDate = "15 Oktubre", category = "Kuryente"))
            db.billerDao().insertBiller(BillerEntity(name = "Maynilad", accountNo = "9876543210", balanceDue = 1200.00, dueDate = "18 Oktubre", category = "Tubig"))
            db.billerDao().insertBiller(BillerEntity(name = "PLDT Home", accountNo = "5544332211", balanceDue = 2499.00, dueDate = "20 Oktubre", category = "Internet"))
            db.billerDao().insertBiller(BillerEntity(name = "Globe Postpaid", accountNo = "09171234567", balanceDue = 599.00, dueDate = "22 Oktubre", category = "Mobile"))

            // 4. Merchants
            db.merchantDao().insertMerchant(MerchantEntity(name = "ABC Sari-Sari Store", location = "BGC, Taguig", salesGross = 15400.0, salesFees = 154.0, salesNet = 15246.0, salesCount = 42, category = "Sari-sari store"))
            db.merchantDao().insertMerchant(MerchantEntity(name = "Jollibee BGC", location = "BGC, Taguig", salesGross = 45280.0, salesFees = 452.8, salesNet = 44827.2, salesCount = 128, category = "Carinderia"))
            db.merchantDao().insertMerchant(MerchantEntity(name = "Maria's Sari-Sari Store", location = "Quezon City", salesGross = 48250.0, salesFees = 482.5, salesNet = 47767.5, salesCount = 80, category = "Sari-sari store"))

            // 5. Family
            db.familyMemberDao().insertFamily(FamilyMemberEntity(name = "Mama", relation = "Ina", regularAmount = 15000.0, lastSentDate = "1 Setyembre", remarks = "Regular monthly padala"))
            db.familyMemberDao().insertFamily(FamilyMemberEntity(name = "Ate", relation = "Kapatid", regularAmount = 5000.0, lastSentDate = "10 Setyembre", remarks = "Tuition at baon"))

            // 6. Commute Trips
            db.commuteTripDao().insertTrip(CommuteTripEntity(routeName = "MRT-3 (BGC to Cubao)", fare = 28.0, timestamp = System.currentTimeMillis() - 7200000))
            db.commuteTripDao().insertTrip(CommuteTripEntity(routeName = "Bus (Cubao to Makati)", fare = 25.0, timestamp = System.currentTimeMillis() - 3600000))

            // 7. Lessons
            db.lessonDao().insertLesson(LessonEntity(title = "Paano Mag-budget", excerpt = "Matutong hatiin ang sweldo gamit ang 50-30-20 rule.", fullText = "Ang 50-30-20 rule ay isang simpleng paraan ng pagba-budget: 50% para sa Needs (gaya ng kuryente, pagkain, renta), 30% para sa Wants (gaya ng sine, kain sa labas), at 20% para sa Savings o pagbabayad ng utang.", category = "Budgeting"))
            db.lessonDao().insertLesson(LessonEntity(title = "Ano ang Emergency Fund?", excerpt = "Ang emergency fund ay perang inilaan para sa mga hindi inaasahang gastos.", fullText = "Ang emergency fund ay perang inilaan para sa mga hindi inaasahang gastos gaya ng medical bills, pagkawala ng trabaho o biglaang repair. Inirerekomenda na mag-ipon ng 3 hanggang 6 na buwang halaga ng iyong living expenses bago magsimulang mag-invest.", category = "Savings"))
            db.lessonDao().insertLesson(LessonEntity(title = "Paano Gumagana ang Utang", excerpt = "Huwag matakot sa utang kung ito ay gagamitin sa pagpapalago ng negosyo.", fullText = "Mayroong tinatawag na mabuting utang (good debt) na ginagamit sa mga bagay na nagbibigay ng karagdagang kita gaya ng negosyo o edukasyon, at masamang utang (bad debt) na ginagamit sa mga bagay na bumababa ang halaga o hindi naman kailangan gaya ng bagong cellphone o bakasyon.", category = "Lending"))
            db.lessonDao().insertLesson(LessonEntity(title = "Stocks 101", excerpt = "Alamin kung paano maging part-owner ng malalaking kumpanya sa Pilipinas.", fullText = "Ang stocks o shares ay kumakatawan sa maliit na bahagi ng pagmamay-ari sa isang kumpanya. Kapag bumili ka ng stocks ng Jollibee o SM, nagiging part-owner ka ng kumpanyang iyon at maaari kang kumita kapag lumago ang halaga nito o sa pamamagitan ng dividends.", category = "Investment"))
            db.lessonDao().insertLesson(LessonEntity(title = "Bonds 101", excerpt = "Ligtas at de-kalidad na pamumuhunan na sinisiguro ng gobyerno.", fullText = "Ang bonds ay parang pautang mo sa gobyerno o sa isang malaking kumpanya. Bibigyan ka nila ng interes o 'coupon' kada ilang buwan, at ibabalik ang iyong buong puhunan sa takdang panahon o maturity date. Ito ay isa sa pinakaligtas na paraan ng pagpapalago ng pera.", category = "Investment"))

            // 8. Loans
            db.loanDao().insertLoan(LoanEntity(principal = 30000.0, termMonths = 12, monthlyPayment = 2850.0, remainingRepayment = 34200.0, interestRate = 14.0, nextDueDate = "15 Oktubre", status = "ACTIVE"))

            // 9. Base Transactions
            db.transactionDao().insertTransaction(TransactionEntity(type = "CASHIN", amount = 10000.0, fee = 0.0, status = "SUCCESS", senderName = "BPI Bank Transfer", recipientName = "Maria Santos", referenceNo = "REF-29384756", remarks = "Cash-In via BPI", category = "Savings"))
            db.transactionDao().insertTransaction(TransactionEntity(type = "SEND", amount = 1500.0, fee = 0.0, status = "SUCCESS", senderName = "Maria Santos", recipientName = "Mama", referenceNo = "REF-10293847", remarks = "Groceries ❤️", category = "Pamilya"))
            db.transactionDao().insertTransaction(TransactionEntity(type = "COMMUTE", amount = 28.0, fee = 0.0, status = "SUCCESS", senderName = "Maria Santos", recipientName = "MRT-3 Terminal", referenceNo = "REF-55443322", remarks = "Commute Fare", category = "Transport"))
        }
    }

    // Centavos helper logic
    private fun toCentavos(value: Double): Long {
        return Math.round(value * 100.0)
    }

    private fun fromCentavos(centavos: Long): Double {
        return centavos.toDouble() / 100.0
    }

    // Generate unique reference number
    fun generateReference(): String {
        val rand = Random.nextInt(10000000, 99999999)
        return "REF-$rand"
    }

    // DOUBLE ENTRY TRANSACTION ENGINE
    // Debits or Credits must always match. We record the ledger entries using the Transaction table
    // and adjust the Wallet balances with authoritative centavos precision.
    private suspend fun executeLedgerTransaction(
        type: String,
        amount: Double,
        fee: Double,
        senderName: String,
        recipientName: String,
        remarks: String,
        category: String,
        balanceAdjustment: (Long, Long) -> Pair<Long, Long>? // Returns Pair(newWallet, newOther) where applicable
    ): TransactionEntity? = withContext(Dispatchers.IO) {
        val user = db.userDao().getUserSync() ?: return@withContext null
        val amountCentavos = toCentavos(amount)
        val feeCentavos = toCentavos(fee)
        val totalCentavosNeeded = amountCentavos + feeCentavos

        val walletCentavos = toCentavos(user.walletBalance)
        val result = balanceAdjustment(walletCentavos, totalCentavosNeeded) ?: return@withContext null

        val newWalletCentavos = result.first
        val newWalletBalance = fromCentavos(newWalletCentavos)

        // Transaction record (The immutable ledger event)
        val ref = generateReference()
        val tx = TransactionEntity(
            type = type,
            amount = amount,
            fee = fee,
            status = "SUCCESS", // CREATED -> PENDING -> SUCCESS validation simulated in business flow
            senderName = senderName,
            recipientName = recipientName,
            referenceNo = ref,
            remarks = remarks,
            category = category
        )

        db.transactionDao().insertTransaction(tx)
        
        // Update user
        db.userDao().updateUser(user.copy(walletBalance = newWalletBalance))
        tx
    }

    // Specific user transactional flows (ALL PRESERVE LEAD ACCOUNTING PRINCIPLES)

    // 1. Send Money (Simulate Transfer)
    suspend fun sendMoney(recipient: String, amount: Double, message: String, isRemittance: Boolean = false): TransactionEntity? {
        val fee = if (isRemittance) 150.0 else 0.0
        return executeLedgerTransaction(
            type = "SEND",
            amount = amount,
            fee = fee,
            senderName = "Maria Santos",
            recipientName = recipient,
            remarks = if (message.isEmpty()) "Padala" else message,
            category = "Pamilya"
        ) { wallet, total ->
            if (wallet >= total) {
                Pair(wallet - total, 0L)
            } else null
        }
    }

    // 2. Pay QR
    suspend fun payMerchantQR(merchantName: String, amount: Double): TransactionEntity? {
        return executeLedgerTransaction(
            type = "QR",
            amount = amount,
            fee = 0.0,
            senderName = "Maria Santos",
            recipientName = merchantName,
            remarks = "QR Ph payment",
            category = "Shopping"
        ) { wallet, total ->
            if (wallet >= total) {
                Pair(wallet - total, 0L)
            } else null
        }
    }

    // 3. Cash In
    suspend fun cashIn(source: String, amount: Double, fee: Double = 0.0): TransactionEntity? {
        return executeLedgerTransaction(
            type = "CASHIN",
            amount = amount,
            fee = fee,
            senderName = source,
            recipientName = "Maria Santos",
            remarks = "Cash-In via $source",
            category = "Savings"
        ) { wallet, total ->
            // In Cash-In, total is added to wallet, but fee is deducted from the source (or wallet depends on rules). 
            // We'll add the amount to wallet and subtract fee from the final added amount.
            val addition = toCentavos(amount) - toCentavos(fee)
            Pair(wallet + addition, 0L)
        }
    }

    // 4. Cash Out
    suspend fun cashOut(amount: Double, fee: Double): TransactionEntity? {
        return executeLedgerTransaction(
            type = "CASHOUT",
            amount = amount,
            fee = fee,
            senderName = "Maria Santos",
            recipientName = "Cash Out Partner",
            remarks = "Cash-Out withdrawal",
            category = "Others"
        ) { wallet, total ->
            // Cash-out takes amount + fee out of wallet
            if (wallet >= total) {
                Pair(wallet - total, 0L)
            } else null
        }
    }

    // 5. Bank Transfer
    suspend fun bankTransfer(bankName: String, accountNo: String, accountName: String, amount: Double, fee: Double): TransactionEntity? {
        return executeLedgerTransaction(
            type = "TRANSFER",
            amount = amount,
            fee = fee,
            senderName = "Maria Santos",
            recipientName = "$bankName ($accountName)",
            remarks = "Transfer to Account: $accountNo",
            category = "Others"
        ) { wallet, total ->
            if (wallet >= total) {
                Pair(wallet - total, 0L)
            } else null
        }
    }

    // 6. Pay Bills
    suspend fun payBill(billerId: Long, billerName: String, amount: Double): TransactionEntity? {
        val tx = executeLedgerTransaction(
            type = "BILL",
            amount = amount,
            fee = 0.0,
            senderName = "Maria Santos",
            recipientName = billerName,
            remarks = "Bayad Bill: $billerName",
            category = "Bills"
        ) { wallet, total ->
            if (wallet >= total) {
                Pair(wallet - total, 0L)
            } else null
        }
        if (tx != null) {
            // Update biller to paid
            val billerList = db.billerDao().getAllBillers()
            // We can fetch or update
            db.billerDao().insertBiller(BillerEntity(id = billerId, name = billerName, accountNo = "---", balanceDue = 0.0, dueDate = "N/A", category = "Bills", isPaid = true))
        }
        return tx
    }

    // 7. Buy Load
    suspend fun buyLoad(mobileNo: String, provider: String, amount: Double): TransactionEntity? {
        return executeLedgerTransaction(
            type = "LOAD",
            amount = amount,
            fee = 0.0,
            senderName = "Maria Santos",
            recipientName = "$provider Load ($mobileNo)",
            remarks = "Prepaid load for $mobileNo",
            category = "Bills"
        ) { wallet, total ->
            if (wallet >= total) {
                Pair(wallet - total, 0L)
            } else null
        }
    }

    // 8. Save Money (GSave)
    suspend fun depositSavings(goalId: Long, goalTitle: String, amount: Double): TransactionEntity? {
        val user = db.userDao().getUserSync() ?: return null
        val walletCentavos = toCentavos(user.walletBalance)
        val amountCentavos = toCentavos(amount)

        if (walletCentavos >= amountCentavos) {
            val newWallet = walletCentavos - amountCentavos
            val newSavings = toCentavos(user.savingsBalance) + amountCentavos

            // Update user balance
            db.userDao().updateUser(user.copy(
                walletBalance = fromCentavos(newWallet),
                savingsBalance = fromCentavos(newSavings)
            ))

            // Update Goal
            // Let's retrieve existing goals or simulate updating
            val g = SavingsGoalEntity(id = goalId, title = goalTitle, targetAmount = 100000.0, currentAmount = 45000.0 + amount, category = goalTitle)
            db.savingsGoalDao().insertGoal(g)

            val tx = TransactionEntity(
                type = "SAVINGS_ADD",
                amount = amount,
                fee = 0.0,
                status = "SUCCESS",
                senderName = "Maria Santos",
                recipientName = "GSave ($goalTitle)",
                referenceNo = generateReference(),
                remarks = "Deposit to Savings: $goalTitle",
                category = "Savings"
            )
            db.transactionDao().insertTransaction(tx)
            return tx
        }
        return null
    }

    // 9. Invest Money (GInvest)
    suspend fun addInvestment(assetClass: String, amount: Double): TransactionEntity? {
        val user = db.userDao().getUserSync() ?: return null
        val walletCentavos = toCentavos(user.walletBalance)
        val amountCentavos = toCentavos(amount)

        if (walletCentavos >= amountCentavos) {
            val newWallet = walletCentavos - amountCentavos
            val newInvest = toCentavos(user.investBalance) + amountCentavos

            db.userDao().updateUser(user.copy(
                walletBalance = fromCentavos(newWallet),
                investBalance = fromCentavos(newInvest)
            ))

            val tx = TransactionEntity(
                type = "INVEST_ADD",
                amount = amount,
                fee = 0.0,
                status = "SUCCESS",
                senderName = "Maria Santos",
                recipientName = "GInvest ($assetClass)",
                referenceNo = generateReference(),
                remarks = "Invested in $assetClass",
                category = "Investments"
            )
            db.transactionDao().insertTransaction(tx)
            return tx
        }
        return null
    }

    // 10. Borrow Repayment
    suspend fun payLoan(loanId: Long, amount: Double): TransactionEntity? {
        val user = db.userDao().getUserSync() ?: return null
        val walletCentavos = toCentavos(user.walletBalance)
        val amountCentavos = toCentavos(amount)

        if (walletCentavos >= amountCentavos) {
            val newWallet = walletCentavos - amountCentavos
            val newCredit = toCentavos(user.availableCredit) + amountCentavos

            db.userDao().updateUser(user.copy(
                walletBalance = fromCentavos(newWallet),
                availableCredit = fromCentavos(newCredit)
            ))

            val tx = TransactionEntity(
                type = "LOAN_PAY",
                amount = amount,
                fee = 0.0,
                status = "SUCCESS",
                senderName = "Maria Santos",
                recipientName = "GLoan Repayment",
                referenceNo = generateReference(),
                remarks = "Loan Payment",
                category = "Bills"
            )
            db.transactionDao().insertTransaction(tx)
            return tx
        }
        return null
    }

    // 11. Commute Trip Tap
    suspend fun payCommuteTrip(routeName: String, fare: Double): TransactionEntity? {
        val tx = executeLedgerTransaction(
            type = "COMMUTE",
            amount = fare,
            fee = 0.0,
            senderName = "Maria Santos",
            recipientName = "$routeName Fare",
            remarks = "Commute: $routeName",
            category = "Transport"
        ) { wallet, total ->
            if (wallet >= total) {
                Pair(wallet - total, 0L)
            } else null
        }
        if (tx != null) {
            db.commuteTripDao().insertTrip(CommuteTripEntity(routeName = routeName, fare = fare))
        }
        return tx
    }

    // 12. Create New Savings Goal
    suspend fun createSavingsGoal(title: String, target: Double) {
        db.savingsGoalDao().insertGoal(SavingsGoalEntity(title = title, targetAmount = target, currentAmount = 0.0, category = title))
    }

    // 13. Toggle Business Mode
    suspend fun toggleBusinessMode(): Boolean {
        val user = db.userDao().getUserSync() ?: return false
        val newMode = !user.isBusinessMode
        db.userDao().updateUser(user.copy(isBusinessMode = newMode))
        return newMode
    }

    // 14. Simulate Negosyo (Sari-Sari store daily simulation)
    suspend fun simulateNegosyoPayday(): MerchantEntity? {
        val user = db.userDao().getUserSync() ?: return null
        // Simulate gross sales
        val qrAmt = Random.nextInt(200, 1500).toDouble()
        val cashAmt = Random.nextInt(100, 800).toDouble()
        val cardAmt = Random.nextInt(300, 2000).toDouble()

        val gross = qrAmt + cashAmt + cardAmt
        val fee = gross * 0.01 // 1% merchant fee
        val net = gross - fee

        val updatedUser = user.copy(
            businessSales = user.businessSales + gross,
            businessQRCount = user.businessQRCount + 1,
            businessCashCount = user.businessCashCount + 1,
            businessCardCount = user.businessCardCount + 1,
            walletBalance = user.walletBalance + net // Net settlement credited to business wallet!
        )
        db.userDao().updateUser(updatedUser)

        val tx = TransactionEntity(
            type = "BUSINESS_SALE",
            amount = gross,
            fee = fee,
            status = "SUCCESS",
            senderName = "Sari-Sari Store Customers",
            recipientName = "Maria's Sari-Sari Store",
            referenceNo = generateReference(),
            remarks = "Net Credited to Wallet: ₱${String.format("%.2f", net)}",
            category = "Kita"
        )
        db.transactionDao().insertTransaction(tx)

        val m = MerchantEntity(
            id = 3,
            name = "Maria's Sari-Sari Store",
            location = "Quezon City",
            salesGross = updatedUser.businessSales,
            salesFees = updatedUser.businessSales * 0.01,
            salesNet = updatedUser.businessSales * 0.99,
            salesCount = updatedUser.businessQRCount + updatedUser.businessCashCount + updatedUser.businessCardCount,
            category = "Sari-sari store"
        )
        db.merchantDao().insertMerchant(m)
        return m
    }

    // Card Control Functions
    suspend fun toggleCardFreeze(): Boolean {
        val user = db.userDao().getUserSync() ?: return false
        val nextFrozen = !user.isCardFrozen
        db.userDao().updateUser(user.copy(isCardFrozen = nextFrozen))
        return nextFrozen
    }

    suspend fun updateCardSpendingLimit(limit: Double) {
        val user = db.userDao().getUserSync() ?: return
        db.userDao().updateUser(user.copy(cardSpendingLimit = limit))
    }
}
