package com.example.ui

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BillerEntity
import com.example.data.UserEntity
import com.example.ui.theme.*

@Composable
fun PayTabScreen(
    user: UserEntity,
    billers: List<BillerEntity>,
    viewModel: FinanceViewModel
) {
    var subScreen by remember { mutableStateOf("MAIN") } // MAIN, BILLS, LOAD, QR, TAPPAY

    BackHandler(enabled = subScreen != "MAIN") {
        subScreen = "MAIN"
    }

    when (subScreen) {
        "BILLS" -> PayBillsScreen(billers = billers, viewModel = viewModel, onBack = { subScreen = "MAIN" })
        "LOAD" -> BuyLoadScreen(viewModel = viewModel, onBack = { subScreen = "MAIN" })
        "QR" -> QrPhScreen(viewModel = viewModel, onBack = { subScreen = "MAIN" })
        "TAPPAY" -> TapToPayScreen(viewModel = viewModel, onBack = { subScreen = "MAIN" })
        else -> {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Background)
                    .testTag("pay_tab_screen"),
                contentPadding = PaddingValues(bottom = 90.dp)
            ) {
                // Header Banner
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Primary)
                            .padding(top = 48.dp, bottom = 24.dp, start = 16.dp, end = 16.dp)
                    ) {
                        Text(
                            "MAGBAYAD NGAYON",
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Quick Cards for Pay options
                item {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("MGA PARAAN PARA MAGBAYAD", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GGrayText)
                        Spacer(modifier = Modifier.height(12.dp))

                        PayFeatureCard(
                            title = "Bayaran ang Bills",
                            desc = "Meralco, Maynilad, PLDT, Globe postpaid, at iba pa.",
                            icon = Icons.Default.Receipt,
                            color = Color(0xFF9C27B0),
                            onClick = { subScreen = "BILLS" }
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        PayFeatureCard(
                            title = "Mag-Load ng Mobile",
                            desc = "Globe, Smart, TM, TNT, DITO prepaid, at gaming credits.",
                            icon = Icons.Default.PhoneAndroid,
                            color = Color(0xFF00ACC1),
                            onClick = { subScreen = "LOAD" }
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        PayFeatureCard(
                            title = "I-scan ang QR Ph para Magbayad",
                            desc = "Magbayad sa sari-sari stores at mall gamit ang QR.",
                            icon = Icons.Default.QrCodeScanner,
                            color = Primary,
                            onClick = { subScreen = "QR" }
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        PayFeatureCard(
                            title = "Tap to Pay (NFC)",
                            desc = "I-tap ang phone sa terminals gaya ng Jollibee at MRT.",
                            icon = Icons.Default.Nfc,
                            color = GAccentGreen,
                            onClick = { subScreen = "TAPPAY" }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PayFeatureCard(
    title: String,
    desc: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("pay_card_${title.lowercase().replace(" ", "_")}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = title, tint = color, modifier = Modifier.size(24.dp))
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = GNavyDeep)
                Text(text = desc, fontSize = 12.sp, color = GGrayText)
            }
            Icon(Icons.Default.ArrowForwardIos, contentDescription = "Go", tint = Color.LightGray, modifier = Modifier.size(16.dp))
        }
    }
}

@Composable
fun PayBillsScreen(
    billers: List<BillerEntity>,
    viewModel: FinanceViewModel,
    onBack: () -> Unit
) {
    var showReceipt by remember { mutableStateOf(false) }
    var activeBiller by remember { mutableStateOf<BillerEntity?>(null) }
    var alertMsg by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().background(Background)) {
        SectionHeader(title = "Bayaran ang Bills", onBack = onBack)

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f),
            contentPadding = PaddingValues(16.dp)
        ) {
            item {
                Text("IYONG MGA KASALUKUYANG BAYARIN", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GGrayText)
                Spacer(modifier = Modifier.height(12.dp))
            }

            items(billers) { biller ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                        .testTag("biller_${biller.name.lowercase()}"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = biller.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text(text = "Account: ${biller.accountNo}", fontSize = 12.sp, color = GGrayText)
                            Text(text = "Due Date: ${biller.dueDate}", fontSize = 12.sp, color = GAccentRed)
                        }
                        if (biller.isPaid) {
                            Text(
                                text = "BAYAD NA",
                                color = GAccentGreen,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        } else {
                            Button(
                                onClick = {
                                    viewModel.payBill(
                                        billerId = biller.id,
                                        billerName = biller.name,
                                        amount = biller.balanceDue,
                                        onSuccess = {
                                            activeBiller = biller
                                            showReceipt = true
                                        },
                                        onError = { alertMsg = it }
                                    )
                                },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Primary)
                            ) {
                                Text("₱${String.format("%,.2f", biller.balanceDue)}", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }

    if (alertMsg.isNotEmpty()) {
        AlertDialog(
            onDismissRequest = { alertMsg = "" },
            title = { Text("Abiso") },
            text = { Text(alertMsg) },
            confirmButton = { TextButton(onClick = { alertMsg = "" }) { Text("Ok") } }
        )
    }

    if (showReceipt && activeBiller != null) {
        val receipt = viewModel.lastTransactionReceipt.collectAsState().value
        ReceiptDialog(transaction = receipt, onDismiss = {
            showReceipt = false
            activeBiller = null
        })
    }
}

@Composable
fun BuyLoadScreen(
    viewModel: FinanceViewModel,
    onBack: () -> Unit
) {
    var mobileNo by remember { mutableStateOf("09171234567") }
    var provider by remember { mutableStateOf("Globe") }
    var selectedAmount by remember { mutableStateOf(100.0) }
    var showPinDialog by remember { mutableStateOf(false) }
    var showReceipt by remember { mutableStateOf(false) }
    var alertMsg by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().background(Background)) {
        SectionHeader(title = "Bumili ng Mobile Load", onBack = onBack)

        Column(modifier = Modifier.padding(20.dp).verticalScroll(rememberScrollState())) {
            Text("MOBILES NUMBER", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GGrayText)
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = mobileNo,
                onValueChange = { mobileNo = it },
                modifier = Modifier.fillMaxWidth().testTag("load_mobile_input"),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))
            Text("MABILIS NA TELECOMS", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GGrayText)
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                listOf("Globe", "Smart", "DITO").forEach { p ->
                    val isSelected = provider == p
                    Button(
                        onClick = { provider = p },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isSelected) Primary else MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(p)
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
            Text("PUMILI NG HALAGA", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GGrayText)
            Spacer(modifier = Modifier.height(12.dp))
            
            // Grid of amounts
            val amounts = listOf(50.0, 100.0, 300.0, 500.0)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    amounts.take(2).forEach { amt ->
                        LoadAmountCard(amount = amt, isSelected = selectedAmount == amt, onClick = { selectedAmount = amt })
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    amounts.takeLast(2).forEach { amt ->
                        LoadAmountCard(amount = amt, isSelected = selectedAmount == amt, onClick = { selectedAmount = amt })
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
            AppButton(text = "IPADALA ANG LOAD (₱${selectedAmount.toInt()})", onClick = {
                if (mobileNo.length < 11) {
                    alertMsg = "Suriin ang inyong mobile number."
                } else {
                    showPinDialog = true
                }
            })
        }
    }

    if (alertMsg.isNotEmpty()) {
        AlertDialog(
            onDismissRequest = { alertMsg = "" },
            title = { Text("Babala") },
            text = { Text(alertMsg) },
            confirmButton = { TextButton(onClick = { alertMsg = "" }) { Text("Ok") } }
        )
    }

    if (showPinDialog) {
        PinConfirmDialog(onConfirm = {
            showPinDialog = false
            val amt = selectedAmount
            viewModel.buyLoad(mobileNo, provider, amt, onSuccess = {
                showReceipt = true
            }, onError = { alertMsg = it })
        }, onDismiss = { showPinDialog = false })
    }

    if (showReceipt) {
        val receipt = viewModel.lastTransactionReceipt.collectAsState().value
        ReceiptDialog(transaction = receipt, onDismiss = {
            showReceipt = false
        })
    }
}

@Composable
fun RowScope.LoadAmountCard(amount: Double, isSelected: Boolean, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .weight(1f)
            .height(72.dp)
            .clickable(onClick = onClick)
            .border(
                width = if (isSelected) 2.dp else 0.dp,
                color = if (isSelected) Primary else Color.Transparent,
                shape = RoundedCornerShape(12.dp)
            ),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = if (isSelected) PrimaryContainer else Color.White)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("₱${amount.toInt()}", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = if (isSelected) Primary else GNavyDeep)
            Text("Regular Load", fontSize = 11.sp, color = GGrayText)
        }
    }
}

@Composable
fun QrPhScreen(
    viewModel: FinanceViewModel,
    onBack: () -> Unit
) {
    var tabSelected by remember { mutableStateOf("SCAN") } // SCAN, GENERATE
    var showReceipt by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize().background(Background)) {
        SectionHeader(title = "QR Ph - I-scan para Magbayad", onBack = onBack)

        TabRow(selectedTabIndex = if (tabSelected == "SCAN") 0 else 1) {
            Tab(selected = tabSelected == "SCAN", onClick = { tabSelected = "SCAN" }) {
                Text("SCAN QR CODE", modifier = Modifier.padding(12.dp), fontWeight = FontWeight.Bold)
            }
            Tab(selected = tabSelected == "GENERATE", onClick = { tabSelected = "GENERATE" }) {
                Text("AKING QR PH", modifier = Modifier.padding(12.dp), fontWeight = FontWeight.Bold)
            }
        }

        if (tabSelected == "SCAN") {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // Simulated scanning viewport
                Box(
                    modifier = Modifier
                        .size(260.dp)
                        .border(4.dp, Primary, RoundedCornerShape(24.dp))
                        .padding(12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.DarkGray.copy(alpha = 0.8f), RoundedCornerShape(16.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.QrCodeScanner, contentDescription = "Camera", tint = Color.LightGray, modifier = Modifier.size(64.dp))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("Nakahanap ng Merchant!", color = Color.White, fontSize = 12.sp)
                            Text("ABC SARI-SARI STORE", color = GAccentGreen, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
                Text("Merchant: ABC SARI-SARI STORE", fontWeight = FontWeight.Bold)
                Text("Halaga: ₱185.00", fontSize = 15.sp, color = GGrayText)
                Spacer(modifier = Modifier.height(32.dp))
                AppButton(text = "MAGBAYAD ₱185.00", onClick = {
                    viewModel.payMerchantQR("ABC Sari-Sari Store", 185.0, onSuccess = {
                        showReceipt = true
                    }, onError = {})
                })
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Card(
                    modifier = Modifier.padding(16.dp),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("QR Ph interoperable QR code", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Primary)
                        Spacer(modifier = Modifier.height(12.dp))
                        
                        // Fake visual QR representation
                        Box(
                            modifier = Modifier
                                .size(200.dp)
                                .background(Color.Black, RoundedCornerShape(12.dp))
                                .padding(12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(176.dp)
                                    .background(Color.White)
                                    .padding(8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                // Draw fake QR grid or pattern
                                Canvas(modifier = Modifier.fillMaxSize()) {
                                    // A nice design pattern mimicking qr
                                    val sizeX = size.width
                                    val sizeY = size.height
                                    drawRect(Color.Black, size = androidx.compose.ui.geometry.Size(40.dp.toPx(), 40.dp.toPx()))
                                    drawRect(Color.Black, topLeft = androidx.compose.ui.geometry.Offset(sizeX - 40.dp.toPx(), 0f), size = androidx.compose.ui.geometry.Size(40.dp.toPx(), 40.dp.toPx()))
                                    drawRect(Color.Black, topLeft = androidx.compose.ui.geometry.Offset(0f, sizeY - 40.dp.toPx()), size = androidx.compose.ui.geometry.Size(40.dp.toPx(), 40.dp.toPx()))
                                    
                                    drawRect(Primary, topLeft = androidx.compose.ui.geometry.Offset(sizeX/2 - 15.dp.toPx(), sizeY/2 - 15.dp.toPx()), size = androidx.compose.ui.geometry.Size(30.dp.toPx(), 30.dp.toPx()))
                                }
                            }
                        }
                        
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("Maria Santos", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("0917-***-4567", fontSize = 13.sp, color = GGrayText)
                    }
                }
            }
        }
    }

    if (showReceipt) {
        val receipt = viewModel.lastTransactionReceipt.collectAsState().value
        ReceiptDialog(transaction = receipt, onDismiss = {
            showReceipt = false
        })
    }
}

@Composable
fun TapToPayScreen(
    viewModel: FinanceViewModel,
    onBack: () -> Unit
) {
    var isTapped by remember { mutableStateOf(false) }
    var showReceipt by remember { mutableStateOf(false) }
    val context = LocalContext.current

    Column(modifier = Modifier.fillMaxSize().background(Background)) {
        SectionHeader(title = "NFC Tap to Pay", onBack = onBack)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.Nfc,
                contentDescription = "NFC Antenna",
                tint = if (isTapped) GAccentGreen else Primary,
                modifier = Modifier.size(100.dp)
            )
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = if (isTapped) "NABASA NA!" else "Ilapit ang phone sa Payment Terminal",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Text(
                text = "Suportado sa Jollibee, McDonald's, MRT-3, at iba pa.",
                fontSize = 13.sp,
                color = GGrayText,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 24.dp)
            )

            Spacer(modifier = Modifier.height(48.dp))
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth().padding(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("SIMULATOR TERMINAL", fontSize = 11.sp, color = GAccentRed, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Jollibee BGC Terminal #12", fontWeight = FontWeight.Bold)
                    Text("Bayarin: ₱285.00", fontSize = 16.sp, color = Primary, fontWeight = FontWeight.ExtraBold)
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
            AppButton(text = "I-TAP ANG TELEPONO", onClick = {
                // Trigger physical haptic feedback (vibrator)
                try {
                    val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        vibrator.vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE))
                    } else {
                        @Suppress("DEPRECATION")
                        vibrator.vibrate(150)
                    }
                } catch (e: Exception) {
                    // Ignore haptic errors
                }

                isTapped = true
                viewModel.payMerchantQR("Jollibee BGC", 285.0, onSuccess = {
                    showReceipt = true
                }, onError = {})
            })
        }
    }

    if (showReceipt) {
        val receipt = viewModel.lastTransactionReceipt.collectAsState().value
        ReceiptDialog(transaction = receipt, onDismiss = {
            showReceipt = false
            isTapped = false
        })
    }
}
