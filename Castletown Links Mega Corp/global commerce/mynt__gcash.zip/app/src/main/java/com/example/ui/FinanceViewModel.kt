package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.GeminiClient
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class ChatMessage(val text: String, val isUser: Boolean, val timestamp: Long = System.currentTimeMillis())

class FinanceViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val repository = FinanceRepository(db)

    // Navigation Stack
    private val screenStack = mutableListOf<String>()
    private val _currentScreen = MutableStateFlow("HOME")
    val currentScreen: StateFlow<String> = _currentScreen.asStateFlow()

    // Database UI States
    val user: StateFlow<UserEntity?> = repository.user.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )

    val transactions: StateFlow<List<TransactionEntity>> = repository.transactions.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val savingsGoals: StateFlow<List<SavingsGoalEntity>> = repository.savingsGoals.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val loans: StateFlow<List<LoanEntity>> = repository.loans.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val billers: StateFlow<List<BillerEntity>> = repository.billers.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val merchants: StateFlow<List<MerchantEntity>> = repository.merchants.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val family: StateFlow<List<FamilyMemberEntity>> = repository.family.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val commuteTrips: StateFlow<List<CommuteTripEntity>> = repository.commuteTrips.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val lessons: StateFlow<List<LessonEntity>> = repository.lessons.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Recent transaction receipt state
    private val _lastTransactionReceipt = MutableStateFlow<TransactionEntity?>(null)
    val lastTransactionReceipt: StateFlow<TransactionEntity?> = _lastTransactionReceipt.asStateFlow()

    // AI Chat History
    private val _aiChatHistory = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage("Kumusta, Maria! Ako si Pera Coach, ang iyong gabay sa tamang pag-hawak at pagpapalago ng pera dito sa MYNT//GCASH. Paano kita matutulungan mag-ipon, mag-budget, o mag-invest ngayong araw?", false)
        )
    )
    val aiChatHistory: StateFlow<List<ChatMessage>> = _aiChatHistory.asStateFlow()
    val isAiLoading = MutableStateFlow(false)

    // Fraud alerts & Security status
    private val _fraudAlerts = MutableStateFlow<List<String>>(emptyList())
    val fraudAlerts: StateFlow<List<String>> = _fraudAlerts.asStateFlow()

    init {
        // Ensure initial seeding runs on database generation
        viewModelScope.launch {
            repository.seedDatabaseIfNeeded()
        }
    }

    // Navigation helper
    fun navigateTo(screen: String) {
        if (_currentScreen.value != screen) {
            screenStack.add(_currentScreen.value)
            _currentScreen.value = screen
        }
    }

    fun navigateBack(): Boolean {
        if (screenStack.isNotEmpty()) {
            _currentScreen.value = screenStack.removeAt(screenStack.size - 1)
            return true
        }
        return false
    }

    // Interactive Transaction Operations
    fun sendMoney(recipient: String, amount: Double, message: String, isRemittance: Boolean = false, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            val u = user.value ?: return@launch
            if (u.walletBalance < (amount + if (isRemittance) 150.0 else 0.0)) {
                onError("Walang sapat na balanse sa iyong GCash wallet.")
                return@launch
            }
            val tx = repository.sendMoney(recipient, amount, message, isRemittance)
            if (tx != null) {
                _lastTransactionReceipt.value = tx
                onSuccess()
            } else {
                onError("Nagka-error sa pagsend. Subukan muli.")
            }
        }
    }

    fun payMerchantQR(merchantName: String, amount: Double, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            val u = user.value ?: return@launch
            if (u.walletBalance < amount) {
                onError("Walang sapat na balanse.")
                return@launch
            }
            val tx = repository.payMerchantQR(merchantName, amount)
            if (tx != null) {
                _lastTransactionReceipt.value = tx
                onSuccess()
            } else {
                onError("Nagka-error sa pagbayad ng QR.")
            }
        }
    }

    fun cashIn(source: String, amount: Double, fee: Double, onSuccess: () -> Unit) {
        viewModelScope.launch {
            val tx = repository.cashIn(source, amount, fee)
            if (tx != null) {
                _lastTransactionReceipt.value = tx
                onSuccess()
            }
        }
    }

    fun cashOut(amount: Double, fee: Double, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            val u = user.value ?: return@launch
            if (u.walletBalance < (amount + fee)) {
                onError("Walang sapat na balanse.")
                return@launch
            }
            val tx = repository.cashOut(amount, fee)
            if (tx != null) {
                _lastTransactionReceipt.value = tx
                onSuccess()
            } else {
                onError("Nagka-error sa cash out.")
            }
        }
    }

    fun bankTransfer(bankName: String, accountNo: String, accountName: String, amount: Double, fee: Double, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            val u = user.value ?: return@launch
            if (u.walletBalance < (amount + fee)) {
                onError("Suriin ang iyong balanse para sa transfer at fee.")
                return@launch
            }
            val tx = repository.bankTransfer(bankName, accountNo, accountName, amount, fee)
            if (tx != null) {
                _lastTransactionReceipt.value = tx
                onSuccess()
            } else {
                onError("Bigo ang paglipat sa bangko.")
            }
        }
    }

    fun payBill(billerId: Long, billerName: String, amount: Double, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            val u = user.value ?: return@launch
            if (u.walletBalance < amount) {
                onError("Hindi sapat ang balanse para bayaran ang bill.")
                return@launch
            }
            val tx = repository.payBill(billerId, billerName, amount)
            if (tx != null) {
                _lastTransactionReceipt.value = tx
                onSuccess()
            } else {
                onError("Hindi matapos ang pagbabayad ng bill.")
            }
        }
    }

    fun buyLoad(mobileNo: String, provider: String, amount: Double, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            val u = user.value ?: return@launch
            if (u.walletBalance < amount) {
                onError("Kulang ang balanse para sa load.")
                return@launch
            }
            val tx = repository.buyLoad(mobileNo, provider, amount)
            if (tx != null) {
                _lastTransactionReceipt.value = tx
                onSuccess()
            } else {
                onError("Hindi nakabili ng load.")
            }
        }
    }

    fun depositSavings(goalId: Long, goalTitle: String, amount: Double, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            val u = user.value ?: return@launch
            if (u.walletBalance < amount) {
                onError("Kulang ang iyong wallet balance.")
                return@launch
            }
            val tx = repository.depositSavings(goalId, goalTitle, amount)
            if (tx != null) {
                _lastTransactionReceipt.value = tx
                onSuccess()
            } else {
                onError("Bigo ang pagdagdag sa savings goal.")
            }
        }
    }

    fun addInvestment(assetClass: String, amount: Double, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            val u = user.value ?: return@launch
            if (u.walletBalance < amount) {
                onError("Kulang ang iyong balanse para makapag-invest.")
                return@launch
            }
            val tx = repository.addInvestment(assetClass, amount)
            if (tx != null) {
                _lastTransactionReceipt.value = tx
                onSuccess()
            } else {
                onError("Bigo sa pag-invest.")
            }
        }
    }

    fun payLoan(loanId: Long, amount: Double, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            val u = user.value ?: return@launch
            if (u.walletBalance < amount) {
                onError("Suriin ang iyong balanse para sa pagbabayad.")
                return@launch
            }
            val tx = repository.payLoan(loanId, amount)
            if (tx != null) {
                _lastTransactionReceipt.value = tx
                onSuccess()
            } else {
                onError("Bigo ang loan payment.")
            }
        }
    }

    fun payCommuteTrip(routeName: String, fare: Double, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            val u = user.value ?: return@launch
            if (u.walletBalance < fare) {
                onError("Masyadong mababa ang iyong wallet balance para sa commute.")
                return@launch
            }
            val tx = repository.payCommuteTrip(routeName, fare)
            if (tx != null) {
                _lastTransactionReceipt.value = tx
                onSuccess()
            } else {
                onError("Hindi nabayaran ang commute.")
            }
        }
    }

    fun createSavingsGoal(title: String, target: Double, onSuccess: () -> Unit) {
        viewModelScope.launch {
            repository.createSavingsGoal(title, target)
            onSuccess()
        }
    }

    fun toggleBusinessMode() {
        viewModelScope.launch {
            repository.toggleBusinessMode()
        }
    }

    fun simulateNegosyoPayday(onSuccess: () -> Unit) {
        viewModelScope.launch {
            val m = repository.simulateNegosyoPayday()
            if (m != null) {
                onSuccess()
            }
        }
    }

    fun toggleCardFreeze() {
        viewModelScope.launch {
            repository.toggleCardFreeze()
        }
    }

    fun updateCardSpendingLimit(limit: Double) {
        viewModelScope.launch {
            repository.updateCardSpendingLimit(limit)
        }
    }

    // Ask Pera Coach (AI Chat Bot with smart live-ledger analysis)
    fun askPeraCoach(prompt: String) {
        if (prompt.trim().isEmpty()) return
        val currentHistory = _aiChatHistory.value.toMutableList()
        val userMsg = ChatMessage(prompt, true)
        currentHistory.add(userMsg)
        _aiChatHistory.value = currentHistory

        isAiLoading.value = true

        viewModelScope.launch {
            val u = user.value ?: UserEntity()
            val advice = GeminiClient.getPeraCoachAdvice(
                prompt = prompt,
                walletBalance = u.walletBalance,
                savingsBalance = u.savingsBalance,
                investBalance = u.investBalance,
                creditLimit = u.creditLimit,
                availableCredit = u.availableCredit,
                gScore = u.gScore
            )
            isAiLoading.value = false
            val aiMsg = ChatMessage(advice, false)
            val nextHistory = _aiChatHistory.value.toMutableList()
            nextHistory.add(aiMsg)
            _aiChatHistory.value = nextHistory
        }
    }

    // Simulated Real-Time Fraud Engine
    // Runs when security audits or online purchases exceed safe amounts
    fun runFraudDetection(merchant: String, amount: Double): String {
        val u = user.value ?: return "LOW"
        
        val riskScore = when {
            amount >= 15000.0 -> "CRITICAL"
            amount >= 8000.0 && (merchant.lowercase().contains("unknown") || merchant.lowercase().contains("online")) -> "HIGH"
            amount >= 3000.0 -> "MEDIUM"
            else -> "LOW"
        }

        if (riskScore == "HIGH" || riskScore == "CRITICAL") {
            val alert = "Babala: Nakitaan ng kahina-hinalang transaksyon sa $merchant na nagkakahalaga ng ₱${String.format("%.2f", amount)}. Ito ay sinusuri ng aming Real-time Fraud Engine."
            _fraudAlerts.value = _fraudAlerts.value.toMutableList().apply { add(0, alert) }
        }
        return riskScore
    }

    fun clearFraudAlerts() {
        _fraudAlerts.value = emptyList()
    }
}
