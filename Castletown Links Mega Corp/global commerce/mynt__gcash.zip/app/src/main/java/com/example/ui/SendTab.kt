package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.FamilyMemberEntity
import com.example.data.UserEntity
import com.example.ui.theme.*

@Composable
fun SendTabScreen(
    user: UserEntity,
    familyList: List<FamilyMemberEntity>,
    viewModel: FinanceViewModel
) {
    var subScreen by remember { mutableStateOf("MAIN") } // MAIN, SEND_MONEY, BANK_TRANSFER, REMITTANCE, FAMILY
    
    BackHandler(enabled = subScreen != "MAIN") {
        subScreen = "MAIN"
    }

    when (subScreen) {
        "SEND_MONEY" -> InstantSendScreen(viewModel = viewModel, onBack = { subScreen = "MAIN" })
        "BANK_TRANSFER" -> BankTransferScreen(viewModel = viewModel, onBack = { subScreen = "MAIN" })
        "REMITTANCE" -> RemittanceScreen(viewModel = viewModel, onBack = { subScreen = "MAIN" })
        "FAMILY" -> FamilyPadalaScreen(familyList = familyList, viewModel = viewModel, onBack = { subScreen = "MAIN" })
        else -> {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Background)
                    .testTag("send_tab_screen"),
                contentPadding = PaddingValues(bottom = 90.dp)
            ) {
                // Header Banner
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Primary)
                            .padding(top = 48.dp, bottom = 24.dp, start = 16.dp, end = 16.dp)
                    ) {
                        Text(
                            "MAGPADALA NG PERA",
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Options list
                item {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("MAGPADALA AT MAG-TRANSFER", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GGrayText)
                        Spacer(modifier = Modifier.height(12.dp))

                        PayFeatureCard(
                            title = "Magpadala sa GCash / Mobile",
                            desc = "Instant transfer na may ₱0 fee sa kahit kanino.",
                            icon = Icons.Default.Send,
                            color = Primary,
                            onClick = { subScreen = "SEND_MONEY" }
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        PayFeatureCard(
                            title = "Bank Transfer (InstaPay)",
                            desc = "Magpadala sa BDO, BPI, Landbank, at 50+ na bangko.",
                            icon = Icons.Default.AccountBalance,
                            color = Color(0xFFE65100),
                            onClick = { subScreen = "BANK_TRANSFER" }
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        PayFeatureCard(
                            title = "Padala sa Pamilya",
                            desc = "Suriin ang buwanang suporta at regular padala sa pamilya.",
                            icon = Icons.Default.People,
                            color = Color(0xFFE91E63),
                            onClick = { subScreen = "FAMILY" }
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        PayFeatureCard(
                            title = "Remittance",
                            desc = "Tanggapin o magpadala mula sa UK, USA, UAE, Canada, at iba pa.",
                            icon = Icons.Default.Language,
                            color = GAccentGreen,
                            onClick = { subScreen = "REMITTANCE" }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun InstantSendScreen(
    viewModel: FinanceViewModel,
    onBack: () -> Unit
) {
    var recipient by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var showPinDialog by remember { mutableStateOf(false) }
    var showReceipt by remember { mutableStateOf(false) }
    var alertMsg by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().background(Background)) {
        SectionHeader(title = "Magpadala sa GCash", onBack = onBack)

        Column(modifier = Modifier.padding(20.dp).verticalScroll(rememberScrollState())) {
            Text("PABORITONG TATANGGAP", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GGrayText)
            Spacer(modifier = Modifier.height(8.dp))
            
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                FavoriteAvatar(name = "Mama", relation = "Ina", onClick = { recipient = "Mama (0917-293-8472)" })
                FavoriteAvatar(name = "Ate", relation = "Kapatid", onClick = { recipient = "Ate (0918-554-4332)" })
            }

            Spacer(modifier = Modifier.height(24.dp))
            Text("NUMERO O PANGALAN NG TATANGGAP", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GGrayText)
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = recipient,
                onValueChange = { recipient = it },
                placeholder = { Text("0917XXXXXXX o Pangalan") },
                modifier = Modifier.fillMaxWidth().testTag("send_recipient_input"),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))
            Text("HALAGA NG PERA (₱)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GGrayText)
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = amountText,
                onValueChange = { amountText = it },
                placeholder = { Text("0.00") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth().testTag("send_amount_input"),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))
            Text("MENSAHE AT TALA (OPTIONAL)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GGrayText)
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = message,
                onValueChange = { message = it },
                placeholder = { Text("Para sa groceries ❤️") },
                modifier = Modifier.fillMaxWidth().testTag("send_message_input"),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(36.dp))
            AppButton(text = "IPADALA ANG PERA", onClick = {
                val amt = amountText.toDoubleOrNull() ?: 0.0
                if (recipient.isEmpty()) {
                    alertMsg = "Suriin ang inyong recipient."
                } else if (amt <= 0.0) {
                    alertMsg = "Maglagay ng wastong halaga."
                } else {
                    showPinDialog = true
                }
            })
        }
    }

    if (alertMsg.isNotEmpty()) {
        AlertDialog(
            onDismissRequest = { alertMsg = "" },
            title = { Text("Babala") },
            text = { Text(alertMsg) },
            confirmButton = { TextButton(onClick = { alertMsg = "" }) { Text("Ok") } }
        )
    }

    if (showPinDialog) {
        PinConfirmDialog(onConfirm = {
            showPinDialog = false
            val amt = amountText.toDoubleOrNull() ?: 0.0
            viewModel.sendMoney(recipient, amt, message, isRemittance = false, onSuccess = {
                showReceipt = true
                recipient = ""
                amountText = ""
                message = ""
            }, onError = { alertMsg = it })
        }, onDismiss = { showPinDialog = false })
    }

    if (showReceipt) {
        val receipt = viewModel.lastTransactionReceipt.collectAsState().value
        ReceiptDialog(transaction = receipt, onDismiss = {
            showReceipt = false
        })
    }
}

@Composable
fun FavoriteAvatar(name: String, relation: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .width(80.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(Primary.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Text(name.take(1), fontWeight = FontWeight.Bold, color = Primary, fontSize = 16.sp)
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(name, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(relation, fontSize = 10.sp, color = GGrayText)
        }
    }
}

@Composable
fun BankTransferScreen(
    viewModel: FinanceViewModel,
    onBack: () -> Unit
) {
    var selectedBank by remember { mutableStateOf("BPI") }
    var accountNo by remember { mutableStateOf("") }
    var accountName by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var showPinDialog by remember { mutableStateOf(false) }
    var showReceipt by remember { mutableStateOf(false) }
    var alertMsg by remember { mutableStateOf("") }

    val banks = listOf("BPI", "BDO", "Metrobank", "Landbank", "UnionBank")

    Column(modifier = Modifier.fillMaxSize().background(Background)) {
        SectionHeader(title = "Bank Transfer via InstaPay", onBack = onBack)

        Column(modifier = Modifier.padding(20.dp).verticalScroll(rememberScrollState())) {
            Text("PUMILI NG BANGKO", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GGrayText)
            Spacer(modifier = Modifier.height(8.dp))
            
            Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                banks.forEach { b ->
                    val isSelected = selectedBank == b
                    Card(
                        modifier = Modifier
                            .width(100.dp)
                            .clickable { selectedBank = b }
                            .border(
                                width = if (isSelected) 2.dp else 0.dp,
                                color = if (isSelected) Primary else Color.Transparent,
                                shape = RoundedCornerShape(8.dp)
                            ),
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = if (isSelected) PrimaryContainer else Color.White)
                    ) {
                        Box(modifier = Modifier.padding(12.dp), contentAlignment = Alignment.Center) {
                            Text(b, fontWeight = FontWeight.Bold, color = if (isSelected) Primary else GNavyDeep)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
            Text("ACCOUNT NUMBER", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GGrayText)
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = accountNo,
                onValueChange = { accountNo = it },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth().testTag("bank_account_input"),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))
            Text("ACCOUNT NAME", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GGrayText)
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = accountName,
                onValueChange = { accountName = it },
                modifier = Modifier.fillMaxWidth().testTag("bank_name_input"),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))
            Text("HALAGA NG IPAPADALA (₱)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GGrayText)
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = amountText,
                onValueChange = { amountText = it },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth().testTag("bank_amount_input"),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("InstaPay Fee", fontSize = 13.sp, color = GGrayText)
                Text("₱15.00", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = GNavyDeep)
            }

            Spacer(modifier = Modifier.height(28.dp))
            AppButton(text = "MAG-TRANSFER NGAYON", onClick = {
                val amt = amountText.toDoubleOrNull() ?: 0.0
                if (accountNo.isEmpty() || accountName.isEmpty()) {
                    alertMsg = "Suriin ang account number at pangalan."
                } else if (amt <= 0.0) {
                    alertMsg = "Maglagay ng wastong halaga."
                } else {
                    showPinDialog = true
                }
            })
        }
    }

    if (alertMsg.isNotEmpty()) {
        AlertDialog(
            onDismissRequest = { alertMsg = "" },
            title = { Text("Babala") },
            text = { Text(alertMsg) },
            confirmButton = { TextButton(onClick = { alertMsg = "" }) { Text("Ok") } }
        )
    }

    if (showPinDialog) {
        PinConfirmDialog(onConfirm = {
            showPinDialog = false
            val amt = amountText.toDoubleOrNull() ?: 0.0
            viewModel.bankTransfer(selectedBank, accountNo, accountName, amt, fee = 15.0, onSuccess = {
                showReceipt = true
                accountNo = ""
                accountName = ""
                amountText = ""
            }, onError = { alertMsg = it })
        }, onDismiss = { showPinDialog = false })
    }

    if (showReceipt) {
        val receipt = viewModel.lastTransactionReceipt.collectAsState().value
        ReceiptDialog(transaction = receipt, onDismiss = {
            showReceipt = false
        })
    }
}

@Composable
fun RemittanceScreen(
    viewModel: FinanceViewModel,
    onBack: () -> Unit
) {
    var selectedCountry by remember { mutableStateOf("UK") }
    var showReceipt by remember { mutableStateOf(false) }
    var isSimulating by remember { mutableStateOf(false) }

    val countries = listOf("UK" to "£", "USA" to "$", "Canada" to "C$", "Singapore" to "S$")

    Column(modifier = Modifier.fillMaxSize().background(Background)) {
        SectionHeader(title = "Remittance - Padala", onBack = onBack)

        Column(modifier = Modifier.padding(20.dp).verticalScroll(rememberScrollState())) {
            Text("PUMILI NG BANSA NG NAGPADALA", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GGrayText)
            Spacer(modifier = Modifier.height(12.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                countries.forEach { (country, currency) ->
                    val isSelected = selectedCountry == country
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedCountry = country }
                            .border(
                                width = if (isSelected) 2.dp else 0.dp,
                                color = if (isSelected) Primary else Color.Transparent,
                                shape = RoundedCornerShape(12.dp)
                            ),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = if (isSelected) PrimaryContainer else Color.White)
                    ) {
                        Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(country, fontWeight = FontWeight.Bold, color = if (isSelected) Primary else GNavyDeep)
                            Text(currency, fontSize = 12.sp, color = GGrayText)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("REMITTANCE ESTIMATE", fontSize = 11.sp, color = GAccentGreen, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(12.dp))

                    val foreignAmount = if (selectedCountry == "UK") "£500.00" else if (selectedCountry == "USA") "$500.00" else "500.00"
                    val rate = if (selectedCountry == "UK") "₱78.20" else if (selectedCountry == "USA") "₱56.50" else "₱41.20"
                    val received = if (selectedCountry == "UK") "₱38,950.00" else if (selectedCountry == "USA") "₱28,100.00" else "₱20,450.00"

                    ReceiptRow(label = "Ipinadalang Halaga", value = foreignAmount)
                    ReceiptRow(label = "FX Rate", value = "1 Foreign unit = $rate")
                    ReceiptRow(label = "Remittance Fee", value = "₱150.00")
                    Divider(modifier = Modifier.padding(vertical = 12.dp))
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Matatanggap sa Wallet", fontWeight = FontWeight.Bold, color = Primary)
                        Text(received, fontWeight = FontWeight.ExtraBold, color = Primary, fontSize = 16.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(36.dp))
            AppButton(
                text = "TANGGAPIN ANG REMITTANCE",
                onClick = {
                    isSimulating = true
                    val amountToReceive = if (selectedCountry == "UK") 38950.0 else if (selectedCountry == "USA") 28100.0 else 20450.0
                    viewModel.cashIn("Remittance mula $selectedCountry", amountToReceive, fee = 150.0) {
                        isSimulating = false
                        showReceipt = true
                    }
                },
                enabled = !isSimulating
            )
        }
    }

    if (showReceipt) {
        val receipt = viewModel.lastTransactionReceipt.collectAsState().value
        ReceiptDialog(transaction = receipt, onDismiss = {
            showReceipt = false
        })
    }
}

@Composable
fun FamilyPadalaScreen(
    familyList: List<FamilyMemberEntity>,
    viewModel: FinanceViewModel,
    onBack: () -> Unit
) {
    var showReceipt by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize().background(Background)) {
        SectionHeader(title = "Padala sa Pamilya", onBack = onBack)

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp)
        ) {
            item {
                Text("IYONG MGA BUWANANG SUPORTA", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GGrayText)
                Spacer(modifier = Modifier.height(12.dp))
            }

            items(familyList) { member ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                        .testTag("family_${member.name.lowercase()}"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(Primary.copy(alpha = 0.12f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Person, contentDescription = null, tint = Primary)
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(member.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    Text(member.relation, fontSize = 12.sp, color = GGrayText)
                                }
                            }
                            Text("₱${String.format("%,.2f", member.regularAmount)}", fontWeight = FontWeight.Black, color = Primary, fontSize = 16.sp)
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Divider()
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Remarks: ${member.remarks}", fontSize = 11.sp, color = GGrayText)
                                Text("Huling Padala: ${member.lastSentDate}", fontSize = 11.sp, color = GGrayText)
                            }

                            Button(
                                onClick = {
                                    viewModel.sendMoney(member.name, member.regularAmount, "Monthly Support", onSuccess = {
                                        showReceipt = true
                                    }, onError = {})
                                },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = GAccentGreen)
                            ) {
                                Text("Ipadala", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showReceipt) {
        val receipt = viewModel.lastTransactionReceipt.collectAsState().value
        ReceiptDialog(transaction = receipt, onDismiss = {
            showReceipt = false
        })
    }
}
