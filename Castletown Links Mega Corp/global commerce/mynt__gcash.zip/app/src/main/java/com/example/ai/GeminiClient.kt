package com.example.ai

import android.util.Log
import com.example.BuildConfig
import com.squareup.moshi.JsonClass
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class GenerateContentRequest(
    val contents: List<Content>,
    val generationConfig: GenerationConfig? = null,
    val systemInstruction: Content? = null
)

@JsonClass(generateAdapter = true)
data class Content(
    val parts: List<Part>
)

@JsonClass(generateAdapter = true)
data class Part(
    val text: String? = null
)

@JsonClass(generateAdapter = true)
data class GenerationConfig(
    val temperature: Float? = null,
    val topP: Float? = null,
    val topK: Int? = null
)

@JsonClass(generateAdapter = true)
data class GenerateContentResponse(
    val candidates: List<Candidate>? = null
)

@JsonClass(generateAdapter = true)
data class Candidate(
    val content: Content? = null
)

interface GeminiApiService {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GenerateContentRequest
    ): GenerateContentResponse
}

object GeminiClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    val service: GeminiApiService by lazy {
        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create())
            .build()
        retrofit.create(GeminiApiService::class.java)
    }

    suspend fun getPeraCoachAdvice(
        prompt: String,
        walletBalance: Double,
        savingsBalance: Double,
        investBalance: Double,
        creditLimit: Double,
        availableCredit: Double,
        gScore: Int
    ): String {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

        // If no API key is set, or if it is the placeholder, use the smart rule-based fallback
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            Log.d("GeminiClient", "Using local smart fallback for Pera Coach.")
            return getLocalCoachFallback(prompt, walletBalance, savingsBalance, investBalance, creditLimit, availableCredit, gScore)
        }

        val systemContext = """
            You are "Pera Coach", a friendly, knowledgeable, and energetic Filipino financial assistant in the MYNT//GCASH super-app.
            Speak in contemporary, natural, polite Taglish/Filipino.
            The user Maria Santos has:
            - Wallet Balance: ₱$walletBalance
            - Savings Balance: ₱$savingsBalance
            - Investments: ₱$investBalance
            - Credit Limit: ₱$creditLimit (Available Credit: ₱$availableCredit)
            - GScore: $gScore
            Provide smart, practical, non-academic financial tips. Encourage savings (GSave), investments (GInvest), and responsible borrowing (GLoan/GGives/GCredit).
            Never make up transactions or balances.
        """.trimIndent()

        val request = GenerateContentRequest(
            contents = listOf(Content(parts = listOf(Part(text = prompt)))),
            systemInstruction = Content(parts = listOf(Part(text = systemContext))),
            generationConfig = GenerationConfig(temperature = 0.7f)
        )

        return try {
            val response = service.generateContent(apiKey, request)
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text 
                ?: "Pasensya na, hindi ko makuha ang sagot. Subukan natin ulit mamaya!"
        } catch (e: Exception) {
            Log.e("GeminiClient", "API error, falling back to local coach", e)
            getLocalCoachFallback(prompt, walletBalance, savingsBalance, investBalance, creditLimit, availableCredit, gScore)
        }
    }

    private fun getLocalCoachFallback(
        prompt: String,
        walletBalance: Double,
        savingsBalance: Double,
        investBalance: Double,
        creditLimit: Double,
        availableCredit: Double,
        gScore: Int
    ): String {
        val query = prompt.lowercase()
        return when {
            query.contains("magastos") || query.contains("gastos") || query.contains("pinakamalaking") || query.contains("budget") -> {
                "Magandang tanong, Maria! Sa kasalukuyan, ang pinakamalaki mong gastos ay karaniwang napupunta sa **Bills** gaya ng iyong kuryente (Meralco ₱3,850.20). Ang maipapayo ko bilang iyong Pera Coach ay sundin ang **50-30-20 rule**: itabi agad ang 20% para sa iyong GSave o GInvest bago gumastos para sa iba pang bagay!"
            }
            query.contains("ipon") || query.contains("gising") || query.contains("naipon") || query.contains("save") -> {
                "Wow, Maria! Mayroon ka nang **₱$savingsBalance** sa iyong GSave! Bukod pa rito, may tatlo kang savings goals na sinimulan:\n\n" +
                        "1. **Emergency Fund** (₱45,000 / ₱100,000)\n" +
                        "2. **Vacation** (₱18,500 / ₱40,000)\n" +
                        "3. **Tuition** (₱35,000 / ₱60,000)\n\n" +
                        "Para mas mabilis mong maabot ang iyong goals, maaari mong i-activate ang **Auto-Deposit** para kusa itong malalagyan tuwing payday (kada 15 at 30 ng buwan)!"
            }
            query.contains("invest") || query.contains("stocks") || query.contains("crypto") -> {
                "Mayroon ka nang **₱$investBalance** sa iyong GInvest portfolio! Kasalukuyan kang may investment sa **GStocks PH** at **GFunds**. " +
                        "Maganda ang performance ng iyong portfolio ngayong araw na may **+8.4%** return (+₱1,850.00). " +
                        "Tandaan: Ang pag-iinvest ay para sa mahabang panahon (long-term). Mag-invest lamang ng perang kaya mong ipatabi ng 3-5 taon!"
            }
            query.contains("utang") || query.contains("loan") || query.contains("hiram") -> {
                "Maria, mayroon kang aktibong loan na **₱30,000** sa GLoan na may buwanang bayad na **₱2,850.00** tuwing ika-15 ng buwan. " +
                        "Ang credit limit mo naman sa GCredit ay **₱$creditLimit** at may available credit ka pa na **₱$availableCredit**. " +
                        "Kahanga-hanga ang iyong GScore na **$gScore** (Excellent)! Dahil maganda ang iyong record, madali kang makaka-qualify sa mas mababang interes sa iyong susunod na hiram."
            }
            query.contains("mama") || query.contains("padala") || query.contains("pamilya") -> {
                "Naka-schedule ang iyong regular monthly padala kay **Mama** na nagkakahalaga ng **₱15,000.00** tuwing ika-1 ng buwan. " +
                        "Karaniwang ginagamit ito para sa groceries ng pamilya. Napakabuti mong anak, Maria! Sa GCash, walang bawas o transfer fee ang pagpapadala direct sa pamilya mo."
            }
            query.contains("hello") || query.contains("hi") || query.contains("kumusta") || query.contains("sino ka") -> {
                "Kumusta Maria! Ako si **Pera Coach**, ang iyong gabay sa pananalapi dito sa MYNT//GCASH. " +
                        "Maaari mo akong tanungin tungkol sa iyong mga naipon, mga aktibong utang, payo sa pag-budget, o kung paano mag-invest para sa iyong kinabukasan. Ano ang maitutulong ko sa iyo ngayon?"
            }
            else -> {
                "Salamat sa iyong tanong, Maria! Ang iyong Available Balance ngayon sa wallet ay **₱$walletBalance**. " +
                        "Tandaan na palaging maging matalino sa paggasta. Kung nais mong mag-ipon para sa hinaharap, bisitahin ang aming **GSave** para kumita ng hanggang 4% hanggang 6% interest kada taon! May iba ka pa bang nais malaman?"
            }
        }
    }
}
