package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.Primary
import com.example.ui.theme.Secondary

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val fViewModel: FinanceViewModel = viewModel()
                MainAppContainer(viewModel = fViewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppContainer(viewModel: FinanceViewModel) {
    val currentTab by viewModel.currentScreen.collectAsState()
    
    val userState by viewModel.user.collectAsState()
    val transactionsState by viewModel.transactions.collectAsState()
    val goalsState by viewModel.savingsGoals.collectAsState()
    val loansState by viewModel.loans.collectAsState()
    val billersState by viewModel.billers.collectAsState()
    val lessonsState by viewModel.lessons.collectAsState()
    val familyState by viewModel.family.collectAsState()

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            BottomNavigationBar(
                selectedTab = currentTab,
                onTabSelected = { viewModel.navigateTo(it) }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            val user = userState
            if (user != null) {
                when (currentTab) {
                    "HOME" -> HomeTabScreen(
                        user = user,
                        transactions = transactionsState,
                        onQuickAction = { action ->
                            when (action) {
                                "SEND" -> viewModel.navigateTo("SEND")
                                "QR" -> viewModel.navigateTo("PAY")
                                "CASHIN", "CASHOUT", "TAPPAY" -> viewModel.navigateTo("PAY")
                                "PERACOACH" -> viewModel.navigateTo("MORE")
                                "TRANSACTIONS" -> viewModel.navigateTo("HOME")
                            }
                        }
                    )
                    "PAY" -> PayTabScreen(
                        user = user,
                        billers = billersState,
                        viewModel = viewModel
                    )
                    "SEND" -> SendTabScreen(
                        user = user,
                        familyList = familyState,
                        viewModel = viewModel
                    )
                    "GROW" -> GrowTabScreen(
                        user = user,
                        goals = goalsState,
                        viewModel = viewModel
                    )
                    "MORE" -> MoreTabScreen(
                        user = user,
                        loans = loansState,
                        lessons = lessonsState,
                        viewModel = viewModel
                    )
                }
            } else {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            }
        }
    }
}

@Composable
fun BottomNavigationBar(
    selectedTab: String,
    onTabSelected: (String) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(72.dp)
            .testTag("bottom_nav"),
        shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            BottomNavItem(icon = Icons.Default.Home, label = "HOME", isSelected = selectedTab == "HOME", onClick = { onTabSelected("HOME") })
            BottomNavItem(icon = Icons.Default.Payment, label = "PAY", isSelected = selectedTab == "PAY", onClick = { onTabSelected("PAY") })
            
            // Center Floating Action QR Button
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(Primary)
                    .clickable { onTabSelected("PAY") }
                    .testTag("bottom_nav_qr"),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.QrCodeScanner, contentDescription = "QR Ph", tint = Color.White, modifier = Modifier.size(28.dp))
            }

            BottomNavItem(icon = Icons.Default.Send, label = "SEND", isSelected = selectedTab == "SEND", onClick = { onTabSelected("SEND") })
            BottomNavItem(icon = Icons.Default.TrendingUp, label = "GROW", isSelected = selectedTab == "GROW", onClick = { onTabSelected("GROW") })
        }
    }
}

@Composable
fun BottomNavItem(
    icon: ImageVector,
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier
            .width(64.dp)
            .fillMaxHeight()
            .clickable(onClick = onClick)
            .testTag("nav_item_$label")
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (isSelected) Primary else Color.Gray,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = if (isSelected) Primary else Color.Gray
        )
    }
}
