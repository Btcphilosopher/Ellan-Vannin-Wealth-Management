package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SavingsGoalEntity
import com.example.data.UserEntity
import com.example.ui.theme.*

@Composable
fun GrowTabScreen(
    user: UserEntity,
    goals: List<SavingsGoalEntity>,
    viewModel: FinanceViewModel
) {
    var subScreen by remember { mutableStateOf("MAIN") } // MAIN, GSAVE, GINVEST, GINSURE

    BackHandler(enabled = subScreen != "MAIN") {
        subScreen = "MAIN"
    }

    when (subScreen) {
        "GSAVE" -> GSaveScreen(goals = goals, viewModel = viewModel, onBack = { subScreen = "MAIN" })
        "GINVEST" -> GInvestScreen(viewModel = viewModel, onBack = { subScreen = "MAIN" })
        "GINSURE" -> GInsureScreen(onBack = { subScreen = "MAIN" })
        else -> {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Background)
                    .testTag("grow_tab_screen"),
                contentPadding = PaddingValues(bottom = 90.dp)
            ) {
                // Header Banner
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Primary)
                            .padding(top = 48.dp, bottom = 24.dp, start = 16.dp, end = 16.dp)
                    ) {
                        Text(
                            "MAGPALAGO NG PERA",
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Grow assets
                item {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("MGA PRODUKTO SA PAG-PALAGO AT PROTEKSYON", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GGrayText)
                        Spacer(modifier = Modifier.height(12.dp))

                        PayFeatureCard(
                            title = "GSave (Simulan ang Ipon)",
                            desc = "Mag-ipon para sa iyong pangarap at kumita ng hanggang 4% interes.",
                            icon = Icons.Default.Savings,
                            color = GAccentGreen,
                            onClick = { subScreen = "GSAVE" }
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        PayFeatureCard(
                            title = "GInvest (Pamumuhunan)",
                            desc = "Bumili ng Stocks, Mutual Funds, Bonds, o GCrypto.",
                            icon = Icons.Default.ShowChart,
                            color = Color(0xFFEF9A9A),
                            onClick = { subScreen = "GINVEST" }
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        PayFeatureCard(
                            title = "GInsure (Proteksyon)",
                            desc = "Protektahan ang sarili, pamilya, at device mula sa hindi inaasahang gastos.",
                            icon = Icons.Default.Shield,
                            color = Color(0xFF3F51B5),
                            onClick = { subScreen = "GINSURE" }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun GSaveScreen(
    goals: List<SavingsGoalEntity>,
    viewModel: FinanceViewModel,
    onBack: () -> Unit
) {
    var showAddGoalDialog by remember { mutableStateOf(false) }
    var showDepositDialog by remember { mutableStateOf(false) }
    var selectedGoalForDeposit by remember { mutableStateOf<SavingsGoalEntity?>(null) }
    
    var newGoalTitle by remember { mutableStateOf("") }
    var newGoalTarget by remember { mutableStateOf("") }

    var depositAmountText by remember { mutableStateOf("") }
    var alertMsg by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().background(Background)) {
        SectionHeader(title = "GSave - Mga Layunin sa Ipon", onBack = onBack)

        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(16.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("IYONG MGA SAVINGS GOALS", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GGrayText)
                    TextButton(onClick = { showAddGoalDialog = true }) {
                        Text("+ Bagong Goal", fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            items(goals) { goal ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                        .testTag("goal_${goal.title.lowercase()}"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(goal.title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            val pct = if (goal.targetAmount > 0) (goal.currentAmount / goal.targetAmount * 100).toInt() else 0
                            Text("$pct%", fontWeight = FontWeight.Bold, color = GAccentGreen, fontSize = 14.sp)
                        }
                        
                        Spacer(modifier = Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = if (goal.targetAmount > 0) (goal.currentAmount / goal.targetAmount).toFloat() else 0f,
                            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                            color = GAccentGreen,
                            trackColor = Color.LightGray.copy(alpha = 0.3f)
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "₱${String.format("%,.0f", goal.currentAmount)} / ₱${String.format("%,.0f", goal.targetAmount)}",
                                fontSize = 12.sp,
                                color = GGrayText
                            )
                            Button(
                                onClick = {
                                    selectedGoalForDeposit = goal
                                    showDepositDialog = true
                                },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = GAccentGreen)
                            ) {
                                Text("Mag-ipon", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }

    // Add goal dialog
    if (showAddGoalDialog) {
        AlertDialog(
            onDismissRequest = { showAddGoalDialog = false },
            title = { Text("Gumawa ng Bagong Goal") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = newGoalTitle,
                        onValueChange = { newGoalTitle = it },
                        label = { Text("Pangalan ng Goal (e.g. Pang-negosyo)") },
                        modifier = Modifier.fillMaxWidth().testTag("goal_title_input")
                    )
                    OutlinedTextField(
                        value = newGoalTarget,
                        onValueChange = { newGoalTarget = it },
                        label = { Text("Target na Halaga (₱)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth().testTag("goal_target_input")
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    val targetVal = newGoalTarget.toDoubleOrNull() ?: 0.0
                    if (newGoalTitle.isNotEmpty() && targetVal > 0) {
                        viewModel.createSavingsGoal(newGoalTitle, targetVal, onSuccess = {
                            showAddGoalDialog = false
                            newGoalTitle = ""
                            newGoalTarget = ""
                        })
                    }
                }) {
                    Text("Gumawa")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddGoalDialog = false }) { Text("I-cancel") }
            }
        )
    }

    // Deposit dialog
    if (showDepositDialog && selectedGoalForDeposit != null) {
        AlertDialog(
            onDismissRequest = { showDepositDialog = false },
            title = { Text("Magdagdag sa ${selectedGoalForDeposit!!.title}") },
            text = {
                OutlinedTextField(
                    value = depositAmountText,
                    onValueChange = { depositAmountText = it },
                    label = { Text("Magkano ang idadagdag (₱)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().testTag("goal_deposit_input")
                )
            },
            confirmButton = {
                Button(onClick = {
                    val amt = depositAmountText.toDoubleOrNull() ?: 0.0
                    if (amt > 0) {
                        viewModel.depositSavings(
                            goalId = selectedGoalForDeposit!!.id,
                            goalTitle = selectedGoalForDeposit!!.title,
                            amount = amt,
                            onSuccess = {
                                showDepositDialog = false
                                depositAmountText = ""
                            },
                            onError = { alertMsg = it }
                        )
                    }
                }) {
                    Text("I-deposit")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDepositDialog = false }) { Text("I-cancel") }
            }
        )
    }

    if (alertMsg.isNotEmpty()) {
        AlertDialog(
            onDismissRequest = { alertMsg = "" },
            title = { Text("Abiso") },
            text = { Text(alertMsg) },
            confirmButton = { TextButton(onClick = { alertMsg = "" }) { Text("Ok") } }
        )
    }
}

@Composable
fun GInvestScreen(
    viewModel: FinanceViewModel,
    onBack: () -> Unit
) {
    var selectedAssetClass by remember { mutableStateOf("GStocks PH") }
    var showBuyDialog by remember { mutableStateOf(false) }
    var investAmountText by remember { mutableStateOf("") }
    var alertMsg by remember { mutableStateOf("") }

    val userState = viewModel.user.collectAsState().value

    val PSEWatchlist = listOf(
        "JFC" to "Jollibee Foods Corp • ₱265.50",
        "SM" to "SM Investments Corp • ₱910.00",
        "TEL" to "PLDT Inc • ₱1,350.00",
        "ALI" to "Ayala Land Inc • ₱32.40"
    )

    Column(modifier = Modifier.fillMaxSize().background(Background)) {
        SectionHeader(title = "GInvest - Pamumuhunan", onBack = onBack)

        Column(modifier = Modifier.padding(20.dp).verticalScroll(rememberScrollState())) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Primary),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("GInvest Portfolio", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                    Text("₱${String.format("%,.2f", userState?.investBalance ?: 145250.00)}", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("Today's Gain: +₱1,850.00", color = Color.White.copy(alpha = 0.9f), fontSize = 12.sp)
                        Text("+8.4% Return", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
            Text("PUMILI NG ASSET CLASS", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GGrayText)
            Spacer(modifier = Modifier.height(10.dp))

            Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("GStocks PH", "GFunds", "GBonds", "GCrypto").forEach { asset ->
                    val isSelected = selectedAssetClass == asset
                    Card(
                        modifier = Modifier
                            .width(110.dp)
                            .clickable { selectedAssetClass = asset }
                            .border(
                                width = if (isSelected) 2.dp else 0.dp,
                                color = if (isSelected) Primary else Color.Transparent,
                                shape = RoundedCornerShape(12.dp)
                            ),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = if (isSelected) PrimaryContainer else Color.White)
                    ) {
                        Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(asset, fontWeight = FontWeight.Bold, color = if (isSelected) Primary else GNavyDeep, fontSize = 12.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
            Text("PSE STOCK WATCHLIST (GStocks PH)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GGrayText)
            Spacer(modifier = Modifier.height(8.dp))
            
            PSEWatchlist.forEach { (code, desc) ->
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(code, fontWeight = FontWeight.Bold, color = Primary)
                            Text(desc, fontSize = 12.sp, color = GGrayText)
                        }
                        Icon(Icons.Default.TrendingUp, contentDescription = "Up", tint = GAccentGreen)
                    }
                }
            }

            Spacer(modifier = Modifier.height(28.dp))
            AppButton(text = "MAG-INVEST SA $selectedAssetClass", onClick = { showBuyDialog = true })
        }
    }

    if (showBuyDialog) {
        AlertDialog(
            onDismissRequest = { showBuyDialog = false },
            title = { Text("Invest sa $selectedAssetClass") },
            text = {
                OutlinedTextField(
                    value = investAmountText,
                    onValueChange = { investAmountText = it },
                    label = { Text("Magkano ang ii-invest (₱)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().testTag("invest_input")
                )
            },
            confirmButton = {
                Button(onClick = {
                    val amt = investAmountText.toDoubleOrNull() ?: 0.0
                    if (amt > 0) {
                        viewModel.addInvestment(selectedAssetClass, amt, onSuccess = {
                            showBuyDialog = false
                            investAmountText = ""
                        }, onError = { alertMsg = it })
                    }
                }) {
                    Text("Bumili")
                }
            },
            dismissButton = {
                TextButton(onClick = { showBuyDialog = false }) { Text("I-cancel") }
            }
        )
    }

    if (alertMsg.isNotEmpty()) {
        AlertDialog(
            onDismissRequest = { alertMsg = "" },
            title = { Text("Abiso") },
            text = { Text(alertMsg) },
            confirmButton = { TextButton(onClick = { alertMsg = "" }) { Text("Ok") } }
        )
    }
}

@Composable
fun GInsureScreen(
    onBack: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().background(Background)) {
        SectionHeader(title = "GInsure - Proteksyon", onBack = onBack)

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp)
        ) {
            item {
                Text("IYONG MGA SEGURIDAD AT PROTEKSYON", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GGrayText)
                Spacer(modifier = Modifier.height(12.dp))
            }

            val products = listOf(
                Triple("Singlife Cash for Medical Costs", "₱39.00 / buwan", "Hanggang ₱100k para sa medical bills. Instant activation."),
                Triple("GInsure Travel Protection", "₱150.00 / trip", "Sinisiguro ang delay, baggages, at medical emergencies habang naglalakbay."),
                Triple("Mobile Phone Protection", "₱49.00 / buwan", "Proteksyon laban sa basag na screen o aksidenteng pagkasira.")
            )

            items(products) { (title, premium, desc) ->
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(title, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = GNavyDeep)
                            Text(premium, fontWeight = FontWeight.Bold, color = Primary, fontSize = 13.sp)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(desc, fontSize = 12.sp, color = GGrayText)
                        
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = {},
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.align(Alignment.End)
                        ) {
                            Text("Kumuha ng Policy", fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}
