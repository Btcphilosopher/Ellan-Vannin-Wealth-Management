package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary GCash Philippine Blue
val GBluePrimary = Color(0xFF005CE6)
val GBlueDark = Color(0xFF003D99)
val GBlueLight = Color(0xFFE6F0FF)

// Neutrals & Accents
val GAccentGreen = Color(0xFF00B050)
val GAccentRed = Color(0xFFD62828)
val GBackgroundLight = Color(0xFFF8FAFC)
val GSurfaceWhite = Color(0xFFFFFFFF)
val GNavyDeep = Color(0xFF0F172A)
val GGrayText = Color(0xFF64748B)

// Material 3 Colors
val Primary = GBluePrimary
val OnPrimary = Color(0xFFFFFFFF)
val PrimaryContainer = GBlueLight
val OnPrimaryContainer = GBlueDark

val Secondary = GNavyDeep
val OnSecondary = Color(0xFFFFFFFF)
val SecondaryContainer = Color(0xFFF1F5F9)
val OnSecondaryContainer = GNavyDeep

val Background = GBackgroundLight
val OnBackground = GNavyDeep
val Surface = GSurfaceWhite
val OnSurface = GNavyDeep
