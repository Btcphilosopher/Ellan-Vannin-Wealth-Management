package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.LessonEntity
import com.example.data.LoanEntity
import com.example.data.UserEntity
import com.example.ui.theme.*

@Composable
fun MoreTabScreen(
    user: UserEntity,
    loans: List<LoanEntity>,
    lessons: List<LessonEntity>,
    viewModel: FinanceViewModel
) {
    var subScreen by remember { mutableStateOf("MAIN") } // MAIN, SCORE, LOAN, CARD, COMMUTE, EDUCATION, REWARDS, SECURITY, AI_COACH
    val alerts by viewModel.fraudAlerts.collectAsState()

    BackHandler(enabled = subScreen != "MAIN") {
        subScreen = "MAIN"
    }

    when (subScreen) {
        "SCORE" -> GScoreScreen(user = user, onBack = { subScreen = "MAIN" })
        "LOAN" -> LoanScreen(loans = loans, viewModel = viewModel, onBack = { subScreen = "MAIN" })
        "CARD" -> CardControlsScreen(user = user, viewModel = viewModel, onBack = { subScreen = "MAIN" })
        "COMMUTE" -> CommuteScreen(viewModel = viewModel, onBack = { subScreen = "MAIN" })
        "EDUCATION" -> FinancialEducationScreen(lessons = lessons, onBack = { subScreen = "MAIN" })
        "REWARDS" -> RewardsScreen(user = user, onBack = { subScreen = "MAIN" })
        "SECURITY" -> SecurityScreen(alerts = alerts, viewModel = viewModel, onBack = { subScreen = "MAIN" })
        "AI_COACH" -> PeraCoachChatScreen(viewModel = viewModel, onBack = { subScreen = "MAIN" })
        else -> {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Background)
                    .testTag("more_tab_screen"),
                contentPadding = PaddingValues(bottom = 90.dp)
            ) {
                // Header Banner with Personal | Negosyo Selector
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Primary)
                            .padding(top = 48.dp, bottom = 20.dp, start = 16.dp, end = 16.dp)
                    ) {
                        Text(
                            "MGA KARAGDAGANG FEATURE",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        
                        // Switch Personal | Negosyo
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.White.copy(alpha = 0.15f))
                                .padding(2.dp)
                        ) {
                            val isBiz = user.isBusinessMode
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (!isBiz) Color.White else Color.Transparent)
                                    .clickable { if (isBiz) viewModel.toggleBusinessMode() },
                                contentAlignment = Alignment.Center
                            ) {
                                Text("PERSONAL", fontWeight = FontWeight.Bold, color = if (!isBiz) Primary else Color.White, fontSize = 12.sp)
                            }
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (isBiz) Color.White else Color.Transparent)
                                    .clickable { if (!isBiz) viewModel.toggleBusinessMode() },
                                contentAlignment = Alignment.Center
                            ) {
                                Text("NEGOSYO (MSME)", fontWeight = FontWeight.Bold, color = if (isBiz) Primary else Color.White, fontSize = 12.sp)
                            }
                        }
                    }
                }

                // If Negosyo Mode is active, show Business Dashboard
                if (user.isBusinessMode) {
                    item {
                        BusinessDashboardSection(user = user, viewModel = viewModel)
                    }
                } else {
                    // Regular Personal options
                    item {
                        Column(modifier = Modifier.padding(16.dp)) {
                            // Security Warning Header if alerts exist
                            if (alerts.isNotEmpty()) {
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(bottom = 16.dp)
                                        .clickable { subScreen = "SECURITY" },
                                    colors = CardDefaults.cardColors(containerColor = GAccentRed.copy(alpha = 0.1f)),
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(1.dp, GAccentRed)
                                ) {
                                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Warning, contentDescription = "Alert", tint = GAccentRed)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Babala sa Seguridad! May nakita kaming kakaibang kilos.", fontSize = 12.sp, color = GAccentRed, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            // Quick AI prompt shortcut
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 16.dp)
                                    .clickable { subScreen = "AI_COACH" },
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = PrimaryContainer)
                            ) {
                                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Chat, contentDescription = null, tint = Primary)
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("Kausapin si Pera Coach", fontWeight = FontWeight.Bold, color = OnPrimaryContainer, fontSize = 15.sp)
                                        Text("Humingi ng instant advice o payo sa pananalapi.", fontSize = 12.sp, color = GGrayText)
                                    }
                                }
                            }

                            Text("MGA LINGKURAN AT PINANSIYAL HEALTH", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GGrayText)
                            Spacer(modifier = Modifier.height(12.dp))

                            PayFeatureCard(title = "GScore & Credit Health", desc = "Suriin ang iyong credit rating at pinansyal na katayuan.", icon = Icons.Default.TrendingUp, color = Primary, onClick = { subScreen = "SCORE" })
                            Spacer(modifier = Modifier.height(12.dp))
                            PayFeatureCard(title = "GLoan & Utang", desc = "Mabilisang hiram ng pera na may mababang interes.", icon = Icons.Default.MonetizationOn, color = Color(0xFFE65100), onClick = { subScreen = "LOAN" })
                            Spacer(modifier = Modifier.height(12.dp))
                            PayFeatureCard(title = "Aking GCash Card", desc = "Freeze/unfreeze at spending limits para sa iyong visa card.", icon = Icons.Default.CreditCard, color = Color(0xFF43A047), onClick = { subScreen = "CARD" })
                            Spacer(modifier = Modifier.height(12.dp))
                            PayFeatureCard(title = "Commute & Transport", desc = "I-tap ang phone para sa MRT at bus trips.", icon = Icons.Default.DirectionsTransit, color = Color(0xFFE53935), onClick = { subScreen = "COMMUTE" })
                            Spacer(modifier = Modifier.height(12.dp))
                            PayFeatureCard(title = "Matuto sa Pera (Financial Ed)", desc = "Mga aralin tungkol sa pag-budget, stocks, at bonds.", icon = Icons.Default.MenuBook, color = Color(0xFF8E24AA), onClick = { subScreen = "EDUCATION" })
                            Spacer(modifier = Modifier.height(12.dp))
                            PayFeatureCard(title = "GCash Rewards (Points)", desc = "I-redeem ang mga points para sa promos at discounts.", icon = Icons.Default.Star, color = Color(0xFFFDD835), onClick = { subScreen = "REWARDS" })
                            Spacer(modifier = Modifier.height(12.dp))
                            PayFeatureCard(title = "Seguridad at Alerts", desc = "Suriin ang tiwala sa device at mga logs.", icon = Icons.Default.Security, color = GAccentRed, onClick = { subScreen = "SECURITY" })
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BusinessDashboardSection(
    user: UserEntity,
    viewModel: FinanceViewModel
) {
    var isSimulating by remember { mutableStateOf(false) }

    Column(modifier = Modifier.padding(16.dp)) {
        Text("GCASH FOR BUSINESS (NEGOSYO)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GGrayText)
        Spacer(modifier = Modifier.height(12.dp))

        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = GNavyDeep),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Today's Net Sales", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
                Text("₱${String.format("%,.2f", user.businessSales * 0.99)}", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Black)
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Gross: ₱${String.format("%,.2f", user.businessSales)}", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                    Text("1% Fees: -₱${String.format("%,.2f", user.businessSales * 0.01)}", color = GAccentRed.copy(alpha = 0.8f), fontSize = 12.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            BusinessStatCard(title = "QR Payments", value = "${user.businessQRCount}", modifier = Modifier.weight(1f))
            BusinessStatCard(title = "Card Payments", value = "${user.businessCardCount}", modifier = Modifier.weight(1f))
            BusinessStatCard(title = "Cash Payments", value = "${user.businessCashCount}", modifier = Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(24.dp))
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("MERCHANT QR CODE", fontSize = 12.sp, color = Primary, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(12.dp))
                Icon(Icons.Default.QrCode, contentDescription = "Business QR", modifier = Modifier.size(140.dp), tint = Primary)
                Spacer(modifier = Modifier.height(8.dp))
                Text("Sari-Sari Store Terminal ID #29384", fontSize = 11.sp, color = GGrayText)
            }
        }

        Spacer(modifier = Modifier.height(28.dp))
        Button(
            onClick = {
                isSimulating = true
                viewModel.simulateNegosyoPayday {
                    isSimulating = false
                }
            },
            modifier = Modifier.fillMaxWidth().height(52.dp).testTag("simulate_sale"),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = GAccentGreen)
        ) {
            Text(if (isSimulating) "Nag-simulate..." else "Simulate 1 Customer Sale (+Income!)", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun BusinessStatCard(title: String, value: String, modifier: Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, fontSize = 11.sp, color = GGrayText, textAlign = TextAlign.Center)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = GNavyDeep)
        }
    }
}

@Composable
fun GScoreScreen(
    user: UserEntity,
    onBack: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().background(Background)) {
        SectionHeader(title = "Credit Health", onBack = onBack)

        Column(modifier = Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("ANG IYONG GSCORE", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = GGrayText)
            Spacer(modifier = Modifier.height(16.dp))
            
            // Big dial representation
            Box(
                modifier = Modifier
                    .size(160.dp)
                    .clip(CircleShape)
                    .background(Primary.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("${user.gScore}", fontSize = 48.sp, fontWeight = FontWeight.Black, color = Primary)
                    Text("Excellent!", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = GAccentGreen)
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("CREDIT METRICS BREAKDOWN", fontSize = 11.sp, color = Primary, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(12.dp))

                    ReceiptRow(label = "Payment History", value = "Excellent")
                    ReceiptRow(label = "Debt Utilisation", value = "Good")
                    ReceiptRow(label = "Cash-Flow Stability", value = "Excellent")
                    ReceiptRow(label = "Repayment Behaviour", value = "Excellent")
                }
            }
        }
    }
}

@Composable
fun LoanScreen(
    loans: List<LoanEntity>,
    viewModel: FinanceViewModel,
    onBack: () -> Unit
) {
    var payAmountText by remember { mutableStateOf("") }
    var selectedLoanForPay by remember { mutableStateOf<LoanEntity?>(null) }
    var alertMsg by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().background(Background)) {
        SectionHeader(title = "GLoan - Mga Hiram", onBack = onBack)

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp)
        ) {
            item {
                Text("IYONG MGA AKTIBONG UTANG", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GGrayText)
                Spacer(modifier = Modifier.height(12.dp))
            }

            items(loans) { loan ->
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("GLoan Personal Loan", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text(loan.status, fontWeight = FontWeight.Bold, color = if (loan.status == "ACTIVE") Color(0xFFE65100) else GAccentGreen)
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        ReceiptRow(label = "Hiram na Principal", value = "₱${String.format("%,.2f", loan.principal)}")
                        ReceiptRow(label = "Monthly Payment", value = "₱${String.format("%,.2f", loan.monthlyPayment)}")
                        ReceiptRow(label = "Remaining Balance", value = "₱${String.format("%,.2f", loan.remainingRepayment)}")
                        ReceiptRow(label = "Interest Rate", value = "${loan.interestRate}% APR")
                        ReceiptRow(label = "Due Date", value = loan.nextDueDate)

                        Spacer(modifier = Modifier.height(16.dp))
                        Divider()
                        Spacer(modifier = Modifier.height(16.dp))

                        if (loan.remainingRepayment > 0) {
                            OutlinedTextField(
                                value = payAmountText,
                                onValueChange = { payAmountText = it },
                                label = { Text("Halaga ng ibabayad (₱)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.fillMaxWidth().testTag("loan_repay_input")
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            AppButton(text = "MAGBAYAD NG LOAN", onClick = {
                                val amt = payAmountText.toDoubleOrNull() ?: 0.0
                                if (amt > 0) {
                                    viewModel.payLoan(loan.id, amt, onSuccess = {
                                        payAmountText = ""
                                    }, onError = { alertMsg = it })
                                }
                            })
                        }
                    }
                }
            }
        }
    }

    if (alertMsg.isNotEmpty()) {
        AlertDialog(
            onDismissRequest = { alertMsg = "" },
            title = { Text("Abiso") },
            text = { Text(alertMsg) },
            confirmButton = { TextButton(onClick = { alertMsg = "" }) { Text("Ok") } }
        )
    }
}

@Composable
fun CardControlsScreen(
    user: UserEntity,
    viewModel: FinanceViewModel,
    onBack: () -> Unit
) {
    var spendingLimit by remember { mutableStateOf(user.cardSpendingLimit.toFloat()) }

    Column(modifier = Modifier.fillMaxSize().background(Background)) {
        SectionHeader(title = "GCash Visa Card", onBack = onBack)

        Column(modifier = Modifier.padding(24.dp)) {
            // Drawn Visa Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = GBlueDark),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.SpaceBetween) {
                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("GCash Card", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("VISA", color = Color.White, fontWeight = FontWeight.Black, fontSize = 18.sp)
                    }
                    Text("••••  ••••  ••••  4567", color = Color.White, fontSize = 20.sp, letterSpacing = 2.sp)
                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text(user.name, color = Color.White, fontSize = 12.sp)
                        Text("10 / 29", color = Color.White, fontSize = 12.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(28.dp))
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Freeze / Lock Card", fontWeight = FontWeight.Bold)
                            Text("Pansamantalang i-lock ang card", fontSize = 11.sp, color = GGrayText)
                        }
                        Switch(
                            checked = user.isCardFrozen,
                            onCheckedChange = { viewModel.toggleCardFreeze() },
                            colors = SwitchDefaults.colors(checkedThumbColor = Primary)
                        )
                    }
                    Divider(modifier = Modifier.padding(vertical = 12.dp))
                    Column {
                        Text("Spending Limit: ₱${spendingLimit.toInt()}", fontWeight = FontWeight.Bold)
                        Text("I-adjust ang limitasyon kada araw", fontSize = 11.sp, color = GGrayText)
                        Slider(
                            value = spendingLimit,
                            onValueChange = {
                                spendingLimit = it
                                viewModel.updateCardSpendingLimit(it.toDouble())
                            },
                            valueRange = 1000f..50000f,
                            colors = SliderDefaults.colors(thumbColor = Primary, activeTrackColor = Primary)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CommuteScreen(
    viewModel: FinanceViewModel,
    onBack: () -> Unit
) {
    var routeSelected by remember { mutableStateOf("MRT-3 (BGC to Cubao)") }
    var showReceipt by remember { mutableStateOf(false) }

    val routes = listOf(
        "MRT-3 (BGC to Cubao)" to 28.0,
        "LRT-1 (Edsa to Monumento)" to 35.0,
        "LRT-2 (Cubao to Recto)" to 30.0,
        "Bus (Cubao to Makati)" to 25.0
    )

    Column(modifier = Modifier.fillMaxSize().background(Background)) {
        SectionHeader(title = "Commute / Transport Card", onBack = onBack)

        Column(modifier = Modifier.padding(20.dp).verticalScroll(rememberScrollState())) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFE53935)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("Beep Card Wallet", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
                    Text("₱2,840.00", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black)
                    Text("Monthly commute expenses logs", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
            Text("PUMILI NG ROUTE SA SIMULATOR", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GGrayText)
            Spacer(modifier = Modifier.height(10.dp))

            routes.forEach { (name, fare) ->
                val isSelected = routeSelected == name
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clickable { routeSelected = name }
                        .border(
                            width = if (isSelected) 2.dp else 0.dp,
                            color = if (isSelected) Color(0xFFE53935) else Color.Transparent,
                            shape = RoundedCornerShape(10.dp)
                        ),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = if (isSelected) Color(0xFFFFEBEE) else Color.White)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(name, fontWeight = FontWeight.Bold)
                        Text("₱${fare.toInt()}", fontWeight = FontWeight.Black, color = Color(0xFFE53935))
                    }
                }
            }

            Spacer(modifier = Modifier.height(36.dp))
            AppButton(
                text = "I-TAP ANG CARD SA TERMINAL",
                containerColor = Color(0xFFE53935),
                onClick = {
                    val fare = routes.find { it.first == routeSelected }?.second ?: 20.0
                    viewModel.payCommuteTrip(routeSelected, fare, onSuccess = {
                        showReceipt = true
                    }, onError = {})
                }
            )
        }
    }

    if (showReceipt) {
        val receipt = viewModel.lastTransactionReceipt.collectAsState().value
        ReceiptDialog(transaction = receipt, onDismiss = {
            showReceipt = false
        })
    }
}

@Composable
fun FinancialEducationScreen(
    lessons: List<LessonEntity>,
    onBack: () -> Unit
) {
    var activeLesson by remember { mutableStateOf<LessonEntity?>(null) }

    Column(modifier = Modifier.fillMaxSize().background(Background)) {
        SectionHeader(title = "Matuto sa Pera", onBack = onBack)

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp)
        ) {
            items(lessons) { lesson ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                        .clickable { activeLesson = lesson }
                        .testTag("lesson_${lesson.title.lowercase()}"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text(lesson.title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text(lesson.category, fontSize = 11.sp, color = Primary, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(lesson.excerpt, fontSize = 13.sp, color = GGrayText)
                    }
                }
            }
        }
    }

    if (activeLesson != null) {
        Dialog(onDismissRequest = { activeLesson = null }) {
            Card(
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp)
                ) {
                    Text(activeLesson!!.title, fontWeight = FontWeight.Black, fontSize = 18.sp, color = Primary)
                    Text("Category: ${activeLesson!!.category}", fontSize = 11.sp, color = GGrayText)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(activeLesson!!.fullText, fontSize = 14.sp, lineHeight = 20.sp)
                    Spacer(modifier = Modifier.height(24.dp))
                    Button(
                        onClick = { activeLesson = null },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Naintindihan ko!")
                    }
                }
            }
        }
    }
}

@Composable
fun RewardsScreen(
    user: UserEntity,
    onBack: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().background(Background)) {
        SectionHeader(title = "GCash Rewards", onBack = onBack)

        Column(modifier = Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("IYONG REWARDS POINTS", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = GGrayText)
            Spacer(modifier = Modifier.height(16.dp))

            Box(
                modifier = Modifier
                    .size(140.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFFDD835).copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Star, contentDescription = "Points", tint = Color(0xFFFDD835), modifier = Modifier.size(40.dp))
                    Text("${user.rewardsPoints.toInt()}", fontSize = 28.sp, fontWeight = FontWeight.Black, color = GNavyDeep)
                    Text("Points", fontSize = 12.sp, color = GGrayText)
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("MGA EXCLUSIVE PROMOS", fontSize = 11.sp, color = Primary, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(12.dp))

                    Text("1. ₱50 Jollibee Voucher (Redeem with 5,000 points)", fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("2. 1GB Surf Data promo (Redeem with 1,000 points)", fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
fun SecurityScreen(
    alerts: List<String>,
    viewModel: FinanceViewModel,
    onBack: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().background(Background)) {
        SectionHeader(title = "Seguridad at Alerts", onBack = onBack)

        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("REAL-TIME FRAUD ALERTS", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GGrayText)
                TextButton(onClick = { viewModel.clearFraudAlerts() }) {
                    Text("Clear Alerts", color = GAccentRed)
                }
            }
            Spacer(modifier = Modifier.height(12.dp))

            if (alerts.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Ligtas ang iyong account. Walang alertong nakita.", color = GAccentGreen, fontWeight = FontWeight.Bold)
                }
            } else {
                LazyColumn(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    items(alerts) { alert ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = GAccentRed.copy(alpha = 0.08f)),
                            border = BorderStroke(1.dp, GAccentRed)
                        ) {
                            Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Security, contentDescription = null, tint = GAccentRed)
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(alert, fontSize = 12.sp, color = GAccentRed)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PeraCoachChatScreen(
    viewModel: FinanceViewModel,
    onBack: () -> Unit
) {
    var promptText by remember { mutableStateOf("") }
    val history by viewModel.aiChatHistory.collectAsState()
    val isLoading by viewModel.isAiLoading.collectAsState()

    Column(modifier = Modifier.fillMaxSize().background(Background)) {
        SectionHeader(title = "Pera Coach AI Chat", onBack = onBack)

        Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
            // Chat area
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentPadding = PaddingValues(bottom = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(history) { msg ->
                    ChatBubble(msg = msg)
                }
                if (isLoading) {
                    item {
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            modifier = Modifier.width(180.dp).padding(4.dp)
                        ) {
                            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(10.dp))
                                Text("Nagsusuri...", fontSize = 12.sp, color = GGrayText)
                            }
                        }
                    }
                }
            }

            // Input bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White, RoundedCornerShape(16.dp))
                    .padding(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = promptText,
                    onValueChange = { promptText = it },
                    placeholder = { Text("Tumingin ng payo kay Pera Coach...") },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("ai_prompt_input"),
                    shape = RoundedCornerShape(12.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = {
                        if (promptText.isNotEmpty()) {
                            viewModel.askPeraCoach(promptText)
                            promptText = ""
                        }
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(Primary)
                ) {
                    Icon(Icons.Default.Send, contentDescription = "Ipadala", tint = Color.White)
                }
            }
        }
    }
}

@Composable
fun ChatBubble(msg: ChatMessage) {
    val align = if (msg.isUser) Alignment.End else Alignment.Start
    val color = if (msg.isUser) Primary else MaterialTheme.colorScheme.surfaceVariant
    val textCol = if (msg.isUser) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
    val shape = if (msg.isUser) RoundedCornerShape(16.dp, 16.dp, 0.dp, 16.dp) else RoundedCornerShape(16.dp, 16.dp, 16.dp, 0.dp)

    Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = align) {
        Card(
            shape = shape,
            colors = CardDefaults.cardColors(containerColor = color),
            modifier = Modifier
                .widthIn(max = 280.dp)
                .padding(horizontal = 4.dp, vertical = 2.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(msg.text, fontSize = 13.sp, color = textCol, lineHeight = 18.sp)
            }
        }
    }
}
