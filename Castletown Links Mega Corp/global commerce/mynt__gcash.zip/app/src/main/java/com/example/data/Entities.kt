package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val id: Int = 1,
    val name: String = "Maria Santos",
    val walletBalance: Double = 24850.50,
    val savingsBalance: Double = 82400.00,
    val investBalance: Double = 145250.00,
    val creditLimit: Double = 50000.00,
    val availableCredit: Double = 45000.00,
    val gScore: Int = 742,
    val isBusinessMode: Boolean = false,
    val businessSales: Double = 48250.00,
    val businessQRCount: Int = 50,
    val businessCashCount: Int = 20,
    val businessCardCount: Int = 10,
    val rewardsPoints: Double = 12850.0,
    val isCardFrozen: Boolean = false,
    val cardSpendingLimit: Double = 10000.0
)

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val type: String, // "SEND", "BILL", "CASHIN", "CASHOUT", "TRANSFER", "LOAD", "SAVINGS_ADD", "INVEST_ADD", "LOAN_PAY", "COMMUTE", "BUSINESS_SALE", "REWARD"
    val amount: Double,
    val fee: Double,
    val status: String, // "CREATED", "PENDING", "SUCCESS", "FAILED"
    val senderName: String,
    val recipientName: String,
    val referenceNo: String,
    val remarks: String,
    val category: String // "Pagkain", "Transport", "Bahay", "Bills", "Shopping", "Pamilya", "Savings", "Investments", "Kita", "Others"
)

@Entity(tableName = "savings_goals")
data class SavingsGoalEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val targetAmount: Double,
    val currentAmount: Double,
    val category: String // e.g., "Emergency Fund", "Vacation", "Tuition"
)

@Entity(tableName = "loans")
data class LoanEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val principal: Double,
    val termMonths: Int,
    val monthlyPayment: Double,
    val remainingRepayment: Double,
    val interestRate: Double,
    val nextDueDate: String,
    val status: String // "ACTIVE", "PAID"
)

@Entity(tableName = "billers")
data class BillerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val accountNo: String,
    val balanceDue: Double,
    val dueDate: String,
    val category: String, // "Kuryente", "Tubig", "Internet", "Mobile", "Credit Card"
    val isPaid: Boolean = false
)

@Entity(tableName = "merchants")
data class MerchantEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val location: String,
    val salesGross: Double,
    val salesFees: Double,
    val salesNet: Double,
    val salesCount: Int,
    val category: String // "Sari-sari store", "Carinderia", "Online seller", "Freelancer"
)

@Entity(tableName = "family_members")
data class FamilyMemberEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val relation: String,
    val regularAmount: Double,
    val lastSentDate: String,
    val remarks: String
)

@Entity(tableName = "commute_trips")
data class CommuteTripEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val routeName: String, // "MRT-3", "LRT-1", "LRT-2", "Bus", "Jeepney"
    val fare: Double,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "lessons")
data class LessonEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val excerpt: String,
    val fullText: String,
    val category: String
)
