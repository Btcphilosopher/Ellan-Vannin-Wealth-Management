package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TransactionEntity
import com.example.data.UserEntity
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeTabScreen(
    user: UserEntity,
    transactions: List<TransactionEntity>,
    onQuickAction: (String) -> Unit
) {
    var isBalanceVisible by remember { mutableStateOf(true) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Background)
            .testTag("home_screen"),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // 1. App Premium Blue Header & Balance Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        brush = Brush.verticalGradient(
                            colors = listOf(Primary, GBlueDark)
                        ),
                        shape = RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp)
                    )
                    .padding(top = 48.dp, bottom = 32.dp, start = 20.dp, end = 20.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    // Row with greeting & avatar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Magandang araw!",
                                color = Color.White.copy(alpha = 0.8f),
                                fontSize = 14.sp
                            )
                            Text(
                                text = user.name,
                                color = Color.White,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Person, contentDescription = "Avatar", tint = Color.White, modifier = Modifier.size(28.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    // Available balance widget
                    Text(
                        text = "AVAILABLE BALANCE",
                        color = Color.White.copy(alpha = 0.7f),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 1.sp
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { isBalanceVisible = !isBalanceVisible }
                    ) {
                        Text(
                            text = if (isBalanceVisible) "₱${String.format("%,.2f", user.walletBalance)}" else "₱••••••",
                            color = Color.White,
                            fontSize = 34.sp,
                            fontWeight = FontWeight.Black
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(
                            imageVector = if (isBalanceVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                            contentDescription = "Toggle Balance",
                            tint = Color.White.copy(alpha = 0.8f),
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Pera para sa Araw-araw",
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 12.sp
                    )
                }
            }
        }

        // 2. Quick Actions Bar
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .offset(y = (-16).dp),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 16.dp, horizontal = 8.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    QuickActionItem(icon = Icons.Default.Send, label = "SEND", onClick = { onQuickAction("SEND") })
                    QuickActionItem(icon = Icons.Default.QrCodeScanner, label = "QR Ph", onClick = { onQuickAction("QR") })
                    QuickActionItem(icon = Icons.Default.TrendingUp, label = "CASH IN", onClick = { onQuickAction("CASHIN") })
                    QuickActionItem(icon = Icons.Default.TrendingDown, label = "CASH OUT", onClick = { onQuickAction("CASHOUT") })
                    QuickActionItem(icon = Icons.Default.Nfc, label = "TAP PAY", onClick = { onQuickAction("TAPPAY") })
                }
            }
        }

        // 3. AI Assistant Banner Card (Pera Coach)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
                    .clickable { onQuickAction("PERACOACH") },
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = PrimaryContainer)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Primary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.SmartToy, contentDescription = "AI", tint = Color.White)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Mag-chat kay Pera Coach!",
                            fontWeight = FontWeight.Bold,
                            color = OnPrimaryContainer,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "Humingi ng gabay sa ipon, budget, o pag-invest sa ating AI assistant.",
                            color = OnPrimaryContainer.copy(alpha = 0.8f),
                            fontSize = 12.sp
                        )
                    }
                    Icon(Icons.Default.ArrowForwardIos, contentDescription = "Go", tint = Primary, modifier = Modifier.size(16.dp))
                }
            }
        }

        // 4. Detailed "ANG PERA MO" asset breakdown
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text(
                    text = "ANG PERA MO",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = GGrayText,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        AssetRow(icon = Icons.Default.AccountBalanceWallet, label = "Wallet (GCash)", value = user.walletBalance, color = Primary)
                        Divider(modifier = Modifier.padding(vertical = 12.dp))
                        AssetRow(icon = Icons.Default.Savings, label = "Savings (GSave)", value = user.savingsBalance, color = GAccentGreen)
                        Divider(modifier = Modifier.padding(vertical = 12.dp))
                        AssetRow(icon = Icons.Default.ShowChart, label = "Investments (GInvest)", value = user.investBalance, color = Color(0xFFEF9A9A))
                        Divider(modifier = Modifier.padding(vertical = 12.dp))
                        AssetRow(icon = Icons.Default.CreditCard, label = "Available Credit (GCredit)", value = user.availableCredit, color = Color(0xFFFFB74D))
                        
                        Spacer(modifier = Modifier.height(16.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Primary.copy(alpha = 0.08f), RoundedCornerShape(12.dp))
                                .padding(16.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("Kabuuang Financial Position", fontSize = 12.sp, color = Primary, fontWeight = FontWeight.Bold)
                                    Text("Lahat ng iyong ipon at pamumuhunan", fontSize = 11.sp, color = GGrayText)
                                }
                                val total = user.walletBalance + user.savingsBalance + user.investBalance
                                Text(
                                    text = "₱${String.format("%,.2f", total)}",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Primary
                                )
                            }
                        }
                    }
                }
            }
        }

        // 5. Recent Transactions Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "KASAYSAYAN NG TRANSAKSYON",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = GGrayText
                )
                Text(
                    text = "Tingnan lahat",
                    fontSize = 13.sp,
                    color = Primary,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clickable { onQuickAction("TRANSACTIONS") }
                )
            }
        }

        // 6. Recent Transaction Items (Show up to 4 items)
        val limit = if (transactions.size > 4) transactions.take(4) else transactions
        if (limit.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Walang nakaraang transaksyon.", color = GGrayText)
                }
            }
        } else {
            items(limit) { tx ->
                TransactionRow(tx = tx)
            }
        }
    }
}

@Composable
fun QuickActionItem(icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(4.dp)
            .testTag("action_$label")
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(Primary.copy(alpha = 0.1f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = label, tint = Primary, modifier = Modifier.size(24.dp))
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = label, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = GNavyDeep)
    }
}

@Composable
fun AssetRow(icon: ImageVector, label: String, value: Double, color: Color) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = label, tint = color, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.width(12.dp))
            Text(text = label, fontWeight = FontWeight.Medium, fontSize = 14.sp)
        }
        Text(
            text = "₱${String.format("%,.2f", value)}",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp
        )
    }
}

@Composable
fun TransactionRow(tx: TransactionEntity) {
    val df = SimpleDateFormat("dd MMM, hh:mm a", Locale.US)
    val formattedDate = df.format(Date(tx.timestamp))

    val (icon, color) = when (tx.type) {
        "CASHIN" -> Pair(Icons.Default.TrendingUp, GAccentGreen)
        "CASHOUT" -> Pair(Icons.Default.TrendingDown, GAccentRed)
        "SEND" -> Pair(Icons.Default.Send, Primary)
        "BILL" -> Pair(Icons.Default.Receipt, Color(0xFF9C27B0))
        "TRANSFER" -> Pair(Icons.Default.AccountBalance, Color(0xFFE65100))
        "LOAD" -> Pair(Icons.Default.PhoneAndroid, Color(0xFF00ACC1))
        "SAVINGS_ADD" -> Pair(Icons.Default.Savings, GAccentGreen)
        "INVEST_ADD" -> Pair(Icons.Default.ShowChart, Color(0xFF0D47A1))
        "LOAN_PAY" -> Pair(Icons.Default.LocalAtm, Color(0xFFFF6F00))
        "COMMUTE" -> Pair(Icons.Default.DirectionsTransit, Color(0xFF455A64))
        "BUSINESS_SALE" -> Pair(Icons.Default.Storefront, Color(0xFF2E7D32))
        else -> Pair(Icons.Default.Payment, GGrayText)
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Row(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = tx.type, tint = color, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = tx.remarks, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = GNavyDeep)
                Text(text = "$formattedDate • Ref: ${tx.referenceNo.takeLast(6)}", fontSize = 11.sp, color = GGrayText)
            }
            val sign = if (tx.type == "CASHIN" || tx.type == "BUSINESS_SALE" || tx.type == "REWARD") "+" else "-"
            val amtColor = if (tx.type == "CASHIN" || tx.type == "BUSINESS_SALE") GAccentGreen else GNavyDeep
            Text(
                text = "$sign₱${String.format("%,.2f", tx.amount)}",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = amtColor
            )
        }
    }
}
