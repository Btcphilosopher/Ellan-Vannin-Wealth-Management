package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val SevenGreen = Color(0xFF007934)
val SevenOrange = Color(0xFFF36633)
val SevenRed = Color(0xFFE31B23)
val SevenDarkGreen = Color(0xFF005022)
val SevenLightOrange = Color(0xFFFF8B5E)

val BackgroundLight = Color(0xFFF7F9F7)
val SurfaceLight = Color(0xFFFFFFFF)
val OnSurfaceLight = Color(0xFF1A1A1A)
val OutlineLight = Color(0xFFD0D7D0)

val BackgroundDark = Color(0xFF111411)
val SurfaceDark = Color(0xFF1C221C)
val OnSurfaceDark = Color(0xFFE2E8E2)
val OutlineDark = Color(0xFF404D40)
