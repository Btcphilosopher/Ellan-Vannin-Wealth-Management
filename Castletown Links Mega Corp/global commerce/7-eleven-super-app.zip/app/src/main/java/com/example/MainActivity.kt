package com.example

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.google.firebase.FirebaseApp
import com.google.firebase.appcheck.appCheck
import com.google.firebase.appcheck.debug.DebugAppCheckProviderFactory
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.SevenOrange

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        configureAppCheck(this, intent)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                SevenElevenAppRoot()
            }
        }
    }
}

fun configureAppCheck(context: Context, intent: Intent?) {
    try {
        FirebaseApp.initializeApp(context)
        val firebaseAppCheck = com.google.firebase.Firebase.appCheck
        val prefs = context.getSharedPreferences("app_check_debug", Context.MODE_PRIVATE)
        if (!prefs.contains("token")) {
            prefs.edit().putString("token", java.util.UUID.randomUUID().toString()).commit()
        }
        firebaseAppCheck.installAppCheckProviderFactory(
            DebugAppCheckProviderFactory.getInstance()
        )
    } catch (e: Exception) {
        Log.e("AppCheck", "Failed to initialize App Check", e)
    }
}

sealed class Screen(val route: String, val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    object Home : Screen("home", "Home", Icons.Default.Home)
    object Shop : Screen("shop", "Shop", Icons.Default.ShoppingBag)
    object Rewards : Screen("rewards", "7Rewards", Icons.Default.CardGiftcard)
    object Delivery : Screen("delivery", "7NOW", Icons.Default.DeliveryDining)
    object Account : Screen("account", "Account", Icons.Default.Person)
}

@Composable
fun SevenElevenAppRoot() {
    var currentTab by remember { mutableStateOf<Screen>(Screen.Home) }
    var currentSubScreen by remember { mutableStateOf<String?>(null) }

    val items = listOf(
        Screen.Home,
        Screen.Shop,
        Screen.Rewards,
        Screen.Delivery,
        Screen.Account
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            if (currentSubScreen == null) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp
                ) {
                    items.forEach { screen ->
                        val selected = currentTab == screen
                        NavigationBarItem(
                            icon = { Icon(screen.icon, contentDescription = screen.title) },
                            label = { Text(screen.title) },
                            selected = selected,
                            onClick = { currentTab = screen },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = SevenOrange,
                                selectedTextColor = SevenOrange,
                                indicatorColor = SevenOrange.copy(alpha = 0.15f)
                            ),
                            modifier = Modifier.testTag("nav_tab_${screen.route}")
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding)) {
            when (currentSubScreen) {
                "scan_pay" -> ScanPayScreen(onBack = { currentSubScreen = null })
                "fuel" -> FuelScreen(onBack = { currentSubScreen = null })
                "ai" -> AiAssistantScreen(onBack = { currentSubScreen = null })
                else -> {
                    when (currentTab) {
                        Screen.Home -> HomeScreen(
                            onNavigateToShop = { currentTab = Screen.Shop },
                            onNavigateToRewards = { currentTab = Screen.Rewards },
                            onNavigateToDelivery = { currentTab = Screen.Delivery },
                            onNavigateToScanPay = { currentSubScreen = "scan_pay" },
                            onNavigateToFuel = { currentSubScreen = "fuel" },
                            onNavigateToAi = { currentSubScreen = "ai" }
                        )
                        Screen.Shop -> ShopScreen(
                            onOpenBasket = { currentTab = Screen.Delivery }
                        )
                        Screen.Rewards -> RewardsScreen()
                        Screen.Delivery -> DeliveryScreen(
                            onNavigateToShop = { currentTab = Screen.Shop }
                        )
                        Screen.Account -> AccountScreen()
                    }
                }
            }
        }
    }
}
