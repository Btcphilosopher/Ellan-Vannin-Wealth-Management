package com.example.data

import androidx.annotation.Keep

@Keep
data class Product(
    val id: String,
    val name: String,
    val category: String,
    val price: Double,
    val promoPrice: Double? = null,
    val imageUrl: String = "",
    val description: String,
    val calories: Int = 0,
    val isAgeRestricted: Boolean = false,
    val rating: Double = 4.8
)

@Keep
data class Store(
    val id: String,
    val name: String,
    val address: String,
    val distance: String,
    val isOpen: Boolean,
    val hasFuel: Boolean,
    val hasDelivery: Boolean,
    val hasPickup: Boolean,
    val hours: String
)

@Keep
data class RewardOffer(
    val id: String,
    val title: String,
    val pointsCost: Int,
    val description: String,
    val expiryDate: String,
    val category: String,
    val isUnlocked: Boolean = false
)

@Keep
data class BasketItem(
    val product: Product,
    val quantity: Int = 1,
    val customisation: String = ""
)

@Keep
data class Order(
    val id: String,
    val storeName: String,
    val items: List<BasketItem>,
    val total: Double,
    val status: String, // "Preparing", "Out for Delivery", "Ready for Pickup", "Delivered"
    val timestamp: Long = System.currentTimeMillis(),
    val deliveryType: String // "Delivery" or "Pickup"
)

@Keep
data class FuelStation(
    val id: String,
    val name: String,
    val address: String,
    val regularPrice: Double,
    val midPrice: Double,
    val premiumPrice: Double,
    val dieselPrice: Double,
    val distance: String
)

@Keep
data class WalletTransaction(
    val id: String,
    val title: String,
    val amount: Double,
    val date: String,
    val type: String // "Purchase", "Reward", "Top-up"
)
