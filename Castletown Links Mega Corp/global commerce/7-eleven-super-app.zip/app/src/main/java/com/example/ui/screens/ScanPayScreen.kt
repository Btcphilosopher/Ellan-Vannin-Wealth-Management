package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SevenElevenRepository
import com.example.ui.theme.SevenGreen
import com.example.ui.theme.SevenOrange
import com.example.ui.theme.SevenRed

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScanPayScreen(
    onBack: () -> Unit
) {
    var isScanning by remember { mutableStateOf(false) }
    var checkoutSuccess by remember { mutableStateOf(false) }
    val basket by SevenElevenRepository.basket.collectAsState()
    val total = basket.sumOf { (it.product.promoPrice ?: it.product.price) * it.quantity }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Scan & Pay (In-Store Checkout)", fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SevenGreen)
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Scanner Viewfinder Simulator Box
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.Black)
                ) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.QrCodeScanner, contentDescription = null, tint = SevenOrange, modifier = Modifier.size(64.dp))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "Point camera at product barcode",
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = {
                                    val randomProduct = SevenElevenRepository.products.random()
                                    SevenElevenRepository.addToBasket(randomProduct)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = SevenOrange),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.testTag("simulate_scan_btn")
                            ) {
                                Text("Simulate Scan Item", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Scanned Items (${basket.sumOf { it.quantity }})",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    if (basket.isNotEmpty()) {
                        TextButton(onClick = { SevenElevenRepository.clearBasket() }) {
                            Text("Clear All", color = SevenRed)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(basket) { item ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(item.product.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text("$${item.product.promoPrice ?: item.product.price} x ${item.quantity}", fontSize = 12.sp, color = Color.Gray)
                                }
                                Text("$${String.format("%.2f", (item.product.promoPrice ?: item.product.price) * item.quantity)}", fontWeight = FontWeight.Bold, color = SevenOrange)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (basket.isNotEmpty()) {
                    Button(
                        onClick = {
                            checkoutSuccess = true
                            SevenElevenRepository.clearBasket()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("complete_scan_pay_btn"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = SevenGreen)
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Pay $${String.format("%.2f", total)} & Exit Store", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            if (checkoutSuccess) {
                AlertDialog(
                    onDismissRequest = { checkoutSuccess = false },
                    title = { Text("Checkout Successful!") },
                    text = { Text("Your mobile checkout receipt is ready. Show digital QR receipt at exit if requested by store associate.") },
                    confirmButton = {
                        Button(onClick = { checkoutSuccess = false }) {
                            Text("Done")
                        }
                    }
                )
            }
        }
    }
}
