package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SevenElevenRepository
import com.example.ui.theme.SevenGreen
import com.example.ui.theme.SevenOrange

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FuelScreen(
    onBack: () -> Unit
) {
    var priceLocked by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("7-Eleven Fuel & Savings", fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SevenGreen)
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Price Lock Banner
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = SevenOrange)
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("7-ELEVEN PRICE LOCK", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Lock in today's regular fuel price for 48 hours", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Black, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = { priceLocked = true },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.testTag("price_lock_btn")
                            ) {
                                Text(if (priceLocked) "Price Locked ($4.39/gal)" else "Lock Gas Price Now", color = SevenOrange, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                item {
                    Text(
                        text = "Nearby 7-Eleven Fuel Stations",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }

                items(SevenElevenRepository.fuelStations) { station ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("fuel_station_${station.id}"),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(station.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                Text(station.distance, fontSize = 13.sp, color = SevenGreen, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(station.address, fontSize = 12.sp, color = Color.Gray)
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceEvenly
                            ) {
                                FuelPriceBadge(grade = "Regular", price = station.regularPrice)
                                FuelPriceBadge(grade = "Mid-Grade", price = station.midPrice)
                                FuelPriceBadge(grade = "Premium", price = station.premiumPrice)
                                FuelPriceBadge(grade = "Diesel", price = station.dieselPrice)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FuelPriceBadge(grade: String, price: Double) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(grade, fontSize = 11.sp, color = Color.Gray)
        Spacer(modifier = Modifier.height(2.dp))
        Text("$${price}", fontSize = 15.sp, fontWeight = FontWeight.Black, color = SevenGreen)
    }
}
