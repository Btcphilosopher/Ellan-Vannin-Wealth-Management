package com.example.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object SevenElevenRepository {

    val categories = listOf(
        "All",
        "Coffee & Drinks",
        "Slurpee",
        "Fresh Food",
        "Pizza & Hot",
        "Snacks",
        "Bakery",
        "Essentials"
    )

    val products = listOf(
        Product(
            id = "p1",
            name = "7-Select Fresh Brewed Coffee",
            category = "Coffee & Drinks",
            price = 2.19,
            promoPrice = 1.49,
            description = "100% Arabica bean roast. Rich, bold and freshly brewed all day long.",
            calories = 5
        ),
        Product(
            id = "p2",
            name = "Coca-Cola Slurpee (Large)",
            category = "Slurpee",
            price = 1.99,
            description = "The iconic frozen carbonated beverage you know and love.",
            calories = 240
        ),
        Product(
            id = "p3",
            name = "Big Gulp Fountain Drink",
            category = "Coffee & Drinks",
            price = 1.89,
            description = "Choose your favorite fountain soda in our legendary 32oz Big Gulp cup.",
            calories = 280
        ),
        Product(
            id = "p4",
            name = "Spicy Bite Jumbo Taquito",
            category = "Pizza & Hot",
            price = 2.49,
            promoPrice = 2.00,
            description = "Crispy corn tortilla stuffed with spicy beef and jalapeños.",
            calories = 320
        ),
        Product(
            id = "p5",
            name = "Pepperoni Pizza Slice (Hot)",
            category = "Pizza & Hot",
            price = 2.99,
            description = "Freshly baked hot pizza slice loaded with savory pepperoni and mozzarella.",
            calories = 450
        ),
        Product(
            id = "p6",
            name = "Cheeseburger Deluxe Sub",
            category = "Fresh Food",
            price = 4.99,
            description = "Freshly made daily with beef patty, cheddar cheese, lettuce, and secret sauce.",
            calories = 620
        ),
        Product(
            id = "p7",
            name = "Crispy Chicken Sandwich",
            category = "Fresh Food",
            price = 4.49,
            description = "Crispy breaded chicken breast on a brioche bun with pickles and mayo.",
            calories = 580
        ),
        Product(
            id = "p8",
            name = "Doritos Nacho Cheese Chips",
            category = "Snacks",
            price = 2.49,
            description = "The classic crunchy tortilla chip loaded with bold nacho cheese flavor.",
            calories = 310
        ),
        Product(
            id = "p9",
            name = "Glazed Jumbo Donut",
            category = "Bakery",
            price = 1.79,
            description = "Soft, fluffy raised ring donut with a sweet glossy vanilla glaze.",
            calories = 360
        ),
        Product(
            id = "p10",
            name = "Red Bull Energy Drink 12oz",
            category = "Essentials",
            price = 3.29,
            description = "Vitalizes body and mind with taurine, caffeine, and B-group vitamins.",
            calories = 160
        )
    )

    val stores = listOf(
        Store(
            id = "s1",
            name = "7-Eleven #38421 - Downtown",
            address = "450 Market St, San Francisco, CA",
            distance = "0.3 mi",
            isOpen = true,
            hasFuel = true,
            hasDelivery = true,
            hasPickup = true,
            hours = "Open 24/7"
        ),
        Store(
            id = "s2",
            name = "7-Eleven #22104 - Financial District",
            address = "120 California St, San Francisco, CA",
            distance = "0.7 mi",
            isOpen = true,
            hasFuel = false,
            hasDelivery = true,
            hasPickup = true,
            hours = "Open 24/7"
        ),
        Store(
            id = "s3",
            name = "7-Eleven #41992 - SoMa Station",
            address = "890 Howard St, San Francisco, CA",
            distance = "1.2 mi",
            isOpen = true,
            hasFuel = true,
            hasDelivery = true,
            hasPickup = true,
            hours = "Open 24/7"
        )
    )

    val fuelStations = listOf(
        FuelStation(
            id = "f1",
            name = "7-Eleven Fuel #38421",
            address = "450 Market St, San Francisco, CA",
            regularPrice = 4.39,
            midPrice = 4.69,
            premiumPrice = 4.99,
            dieselPrice = 5.19,
            distance = "0.3 mi"
        ),
        FuelStation(
            id = "f2",
            name = "7-Eleven Fuel #41992",
            address = "890 Howard St, San Francisco, CA",
            regularPrice = 4.35,
            midPrice = 4.65,
            premiumPrice = 4.95,
            dieselPrice = 5.15,
            distance = "1.2 mi"
        )
    )

    val rewardOffers = listOf(
        RewardOffer(
            id = "r1",
            title = "Free Any Size Coffee",
            pointsCost = 800,
            description = "Redeem for any hot coffee, cappuccino or latte.",
            expiryDate = "Valid until Dec 31",
            category = "Drinks",
            isUnlocked = true
        ),
        RewardOffer(
            id = "r2",
            title = "Free Slurpee or Big Gulp",
            pointsCost = 1000,
            description = "Enjoy a refreshing large Slurpee or Big Gulp on us.",
            expiryDate = "Valid until Dec 31",
            category = "Slurpee",
            isUnlocked = true
        ),
        RewardOffer(
            id = "r3",
            title = "$2 Off Any Fresh Food Item",
            pointsCost = 1200,
            description = "Save $2 on sandwiches, subs, or hot roller foods.",
            expiryDate = "Valid until Jan 15",
            category = "Food",
            isUnlocked = false
        ),
        RewardOffer(
            id = "r4",
            title = "Free Pizza Slice with Fill-Up",
            pointsCost = 1500,
            description = "Get a hot pepperoni or cheese pizza slice free.",
            expiryDate = "Valid until Jan 31",
            category = "Pizza",
            isUnlocked = false
        )
    )

    // State flows for dynamic app state
    private val _basket = MutableStateFlow<List<BasketItem>>(emptyList())
    val basket: StateFlow<List<BasketItem>> = _basket.asStateFlow()

    private val _orders = MutableStateFlow<List<Order>>(
        listOf(
            Order(
                id = "7NOW-8492",
                storeName = "7-Eleven #38421 - Downtown",
                items = listOf(BasketItem(products[0], 2), BasketItem(products[4], 1)),
                total = 7.37,
                status = "Delivered",
                timestamp = System.currentTimeMillis() - 3600000 * 4,
                deliveryType = "Delivery"
            )
        )
    )
    val orders: StateFlow<List<Order>> = _orders.asStateFlow()

    private val _loyaltyPoints = MutableStateFlow(2450)
    val loyaltyPoints: StateFlow<Int> = _loyaltyPoints.asStateFlow()

    private val _walletBalance = MutableStateFlow(25.00)
    val walletBalance: StateFlow<Double> = _walletBalance.asStateFlow()

    fun addToBasket(product: Product, quantity: Int = 1) {
        val current = _basket.value.toMutableList()
        val existingIndex = current.indexOfFirst { it.product.id == product.id }
        if (existingIndex >= 0) {
            val item = current[existingIndex]
            current[existingIndex] = item.copy(quantity = item.quantity + quantity)
        } else {
            current.add(BasketItem(product, quantity))
        }
        _basket.value = current
    }

    fun removeFromBasket(productId: String) {
        _basket.value = _basket.value.filter { it.product.id != productId }
    }

    fun updateQuantity(productId: String, quantity: Int) {
        if (quantity <= 0) {
            removeFromBasket(productId)
            return
        }
        _basket.value = _basket.value.map {
            if (it.product.id == productId) it.copy(quantity = quantity) else it
        }
    }

    fun clearBasket() {
        _basket.value = emptyList()
    }

    fun placeOrder(storeName: String, deliveryType: String): Order {
        val items = _basket.value
        val total = items.sumOf { (it.product.promoPrice ?: it.product.price) * it.quantity } + if (deliveryType == "Delivery") 3.99 else 0.0
        val newOrder = Order(
            id = "7NOW-${(1000..9999).random()}",
            storeName = storeName,
            items = items,
            total = String.format("%.2f", total).toDouble(),
            status = "Preparing",
            timestamp = System.currentTimeMillis(),
            deliveryType = deliveryType
        )
        _orders.value = listOf(newOrder) + _orders.value
        // Earn loyalty points (10 points per dollar)
        _loyaltyPoints.value += (total * 10).toInt()
        clearBasket()
        return newOrder
    }

    fun redeemReward(offer: RewardOffer): Boolean {
        if (_loyaltyPoints.value >= offer.pointsCost) {
            _loyaltyPoints.value -= offer.pointsCost
            return true
        }
        return false
    }

    fun topUpWallet(amount: Double) {
        _walletBalance.value += amount
    }
}
