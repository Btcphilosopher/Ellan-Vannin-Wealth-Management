package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SevenElevenRepository
import com.example.ui.theme.SevenGreen
import com.example.ui.theme.SevenOrange
import com.example.ui.theme.SevenRed

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeliveryScreen(
    onNavigateToShop: () -> Unit
) {
    var deliveryType by remember { mutableStateOf("Delivery") } // Delivery or Pickup
    val basket by SevenElevenRepository.basket.collectAsState()
    val orders by SevenElevenRepository.orders.collectAsState()
    var orderPlacedSuccess by remember { mutableStateOf<String?>(null) }

    val subtotal = basket.sumOf { (it.product.promoPrice ?: it.product.price) * it.quantity }
    val deliveryFee = if (deliveryType == "Delivery") 3.99 else 0.0
    val tax = subtotal * 0.085
    val total = subtotal + deliveryFee + tax

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("7NOW Delivery & Pickup", fontWeight = FontWeight.Bold, color = Color.White) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SevenGreen)
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Fulfillment Type Selector
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { deliveryType = "Delivery" },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("segment_delivery"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (deliveryType == "Delivery") SevenOrange else MaterialTheme.colorScheme.surface,
                                contentColor = if (deliveryType == "Delivery") Color.White else MaterialTheme.colorScheme.onSurface
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.DeliveryDining, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Delivery")
                        }
                        Button(
                            onClick = { deliveryType = "Pickup" },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("segment_pickup"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (deliveryType == "Pickup") SevenOrange else MaterialTheme.colorScheme.surface,
                                contentColor = if (deliveryType == "Pickup") Color.White else MaterialTheme.colorScheme.onSurface
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Store, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Pickup")
                        }
                    }
                }

                // Address / Store Banner
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                if (deliveryType == "Delivery") Icons.Default.LocationOn else Icons.Default.Store,
                                contentDescription = null,
                                tint = SevenGreen,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (deliveryType == "Delivery") "Deliver to Home" else "Pickup at Store",
                                    fontSize = 12.sp,
                                    color = Color.Gray,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = if (deliveryType == "Delivery") "780 Mission St, Apt 4B, SF" else "7-Eleven #38421 (450 Market St)",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }

                // Basket Summary Section
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Current Basket (${basket.sumOf { it.quantity }} items)",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        TextButton(onClick = onNavigateToShop) {
                            Text("+ Add Items", color = SevenOrange, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                if (basket.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(32.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(Icons.Default.ShoppingBasket, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(48.dp))
                                Spacer(modifier = Modifier.height(12.dp))
                                Text("Your basket is empty", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("Add coffee, snacks or meals from the shop", fontSize = 13.sp, color = Color.Gray)
                                Spacer(modifier = Modifier.height(16.dp))
                                Button(
                                    onClick = onNavigateToShop,
                                    colors = ButtonDefaults.buttonColors(containerColor = SevenGreen)
                                ) {
                                    Text("Browse Catalogue")
                                }
                            }
                        }
                    }
                } else {
                    items(basket) { basketItem ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = basketItem.product.name,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "$${basketItem.product.promoPrice ?: basketItem.product.price} each",
                                        fontSize = 12.sp,
                                        color = Color.Gray
                                    )
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(
                                        onClick = { SevenElevenRepository.updateQuantity(basketItem.product.id, basketItem.quantity - 1) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(Icons.Default.Remove, contentDescription = "Decrease", modifier = Modifier.size(16.dp))
                                    }
                                    Text(
                                        text = "${basketItem.quantity}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        modifier = Modifier.padding(horizontal = 8.dp)
                                    )
                                    IconButton(
                                        onClick = { SevenElevenRepository.updateQuantity(basketItem.product.id, basketItem.quantity + 1) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = "Increase", modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }

                    // Price Breakdown & Checkout Button
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Payment Summary", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Spacer(modifier = Modifier.height(12.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Subtotal", color = Color.Gray)
                                    Text("$${String.format("%.2f", subtotal)}")
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(if (deliveryType == "Delivery") "Delivery Fee" else "Pickup Fee", color = Color.Gray)
                                    Text(if (deliveryFee == 0.0) "FREE" else "$${String.format("%.2f", deliveryFee)}")
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Estimated Tax", color = Color.Gray)
                                    Text("$${String.format("%.2f", tax)}")
                                }
                                Divider(modifier = Modifier.padding(vertical = 12.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Total", fontWeight = FontWeight.Black, fontSize = 16.sp)
                                    Text("$${String.format("%.2f", total)}", fontWeight = FontWeight.Black, fontSize = 16.sp, color = SevenOrange)
                                }
                                Spacer(modifier = Modifier.height(16.dp))
                                Button(
                                    onClick = {
                                        val order = SevenElevenRepository.placeOrder("7-Eleven #38421 - Downtown", deliveryType)
                                        orderPlacedSuccess = "Order ${order.id} placed successfully!"
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(50.dp)
                                        .testTag("place_order_btn"),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = SevenOrange)
                                ) {
                                    Text("Place Order ($${String.format("%.2f", total)})", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                // Active Orders Section
                item {
                    Text(
                        text = "Recent Orders & Tracking",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }

                items(orders) { order ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("order_item_${order.id}"),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(order.id, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = SevenGreen)
                                Surface(
                                    color = if (order.status == "Delivered") SevenGreen.copy(alpha = 0.15f) else SevenOrange.copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = " ${order.status} ",
                                        color = if (order.status == "Delivered") SevenGreen else SevenOrange,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(order.storeName, fontSize = 13.sp, color = Color.Gray)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("${order.items.sumOf { it.quantity }} items • Total: $${order.total}", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }

            if (orderPlacedSuccess != null) {
                Snackbar(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(16.dp),
                    action = {
                        TextButton(onClick = { orderPlacedSuccess = null }) {
                            Text("OK", color = Color.White)
                        }
                    }
                ) {
                    Text(orderPlacedSuccess!!)
                }
            }
        }
    }
}
