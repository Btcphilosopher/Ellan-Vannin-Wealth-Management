package com.example.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout

sealed interface AiUiState {
    data object Idle : AiUiState
    data object Loading : AiUiState
    data class Success(val responseText: String) : AiUiState
    data class Error(val message: String) : AiUiState
}

class AiViewModel : ViewModel() {
    private val tag = "AiViewModel"

    private val model by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash"
        )
    }

    private val _uiState = MutableStateFlow<AiUiState>(AiUiState.Idle)
    val uiState: StateFlow<AiUiState> = _uiState.asStateFlow()

    fun askAiAssistant(userPrompt: String) {
        viewModelScope.launch {
            _uiState.value = AiUiState.Loading
            try {
                val systemContext = "You are the 7-Eleven AI Convenience Concierge. You help customers find stores, coffee, Slurpees, pizza, hot food, deals, and 7Rewards points. Keep answers concise, helpful, and energetic."
                val fullPrompt = "$systemContext\n\nCustomer request: $userPrompt"

                val response = withTimeout(60_000L) {
                    model.generateContent(fullPrompt)
                }
                val text = response.text
                if (!text.isNullOrBlank()) {
                    _uiState.value = AiUiState.Success(text)
                } else {
                    _uiState.value = AiUiState.Error("No response received from 7-Eleven AI Assistant.")
                }
            } catch (e: TimeoutCancellationException) {
                Log.e(tag, "AI generation timed out", e)
                _uiState.value = AiUiState.Error("Request timed out. Please try again.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(tag, "AI generation failed", e)
                _uiState.value = AiUiState.Error(e.localizedMessage ?: "AI Assistant currently unavailable.")
            }
        }
    }

    fun resetState() {
        _uiState.value = AiUiState.Idle
    }
}
