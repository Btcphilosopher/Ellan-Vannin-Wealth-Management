package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.ErewhonDatabase
import com.example.data.model.*
import com.example.data.repository.ErewhonRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

sealed class Screen {
    object Home : Screen()
    object Shop : Screen()
    object Smoothies : Screen()
    object PreparedFoods : Screen()
    object Journal : Screen()
    object Bag : Screen()
    object Checkout : Screen()
    data class ProductDetail(val productId: String) : Screen()
    data class ArticleDetail(val articleId: String) : Screen()
    data class OrderTracking(val orderId: String) : Screen()
    object Stores : Screen()
    object Rewards : Screen()
    object Favourites : Screen()
    object ErewhonHQ : Screen()
}

class ErewhonViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = ErewhonRepository(ErewhonDatabase.getDatabase(application))

    // UI States
    val allProducts: StateFlow<List<Product>> = repository.allProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allStores: StateFlow<List<Store>> = repository.allStores
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val cartItems: StateFlow<List<CartItem>> = repository.allCartItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val orders: StateFlow<List<Order>> = repository.allOrders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val articles: StateFlow<List<EditorialArticle>> = repository.allArticles
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favourites: StateFlow<List<FavouriteItem>> = repository.allFavourites
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active Navigation Screen
    private val _currentScreen = MutableStateFlow<Screen>(Screen.Home)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    // Active Store (default Santa Monica)
    private val _selectedStore = MutableStateFlow<Store?>(null)
    val selectedStore: StateFlow<Store?> = _selectedStore.asStateFlow()

    // Global Search
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Toast Message for feedback
    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    // Filter and Category
    private val _selectedCategory = MutableStateFlow("ALL")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _selectedCollection = MutableStateFlow<String?>(null)
    val selectedCollection: StateFlow<String?> = _selectedCollection.asStateFlow()

    // Latest created order for live tracking
    private val _latestOrder = MutableStateFlow<Order?>(null)
    val latestOrder: StateFlow<Order?> = _latestOrder.asStateFlow()

    init {
        viewModelScope.launch {
            repository.seedInitialDataIfEmpty()
            allStores.firstOrNull { it.isNotEmpty() }?.let { stores ->
                if (_selectedStore.value == null) {
                    _selectedStore.value = stores.first()
                }
            }
        }
    }

    fun navigateTo(screen: Screen) {
        _currentScreen.value = screen
    }

    fun selectStore(store: Store) {
        _selectedStore.value = store
        showToast("Switched store to ${store.name}")
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectCategory(category: String) {
        _selectedCategory.value = category
        _selectedCollection.value = null
    }

    fun selectCollection(collection: String) {
        _selectedCollection.value = collection
        _selectedCategory.value = "ALL"
    }

    fun addToCart(product: Product, quantity: Int = 1) {
        viewModelScope.launch {
            val storeId = _selectedStore.value?.id ?: "store_sm"
            repository.addToCart(product, storeId, quantity)
            showToast("Added ${product.name} to Bag")
        }
    }

    fun updateCartQuantity(cartItemId: Int, newQty: Int) {
        viewModelScope.launch {
            repository.updateCartQuantity(cartItemId, newQty)
        }
    }

    fun removeCartItem(cartItemId: Int) {
        viewModelScope.launch {
            repository.removeCartItem(cartItemId)
        }
    }

    fun clearCart() {
        viewModelScope.launch {
            repository.clearCart()
        }
    }

    fun placeOrder(orderType: String, pickupTimeSlot: String, paymentMethod: String) {
        viewModelScope.launch {
            val store = _selectedStore.value ?: allStores.value.first()
            try {
                val newOrder = repository.placeOrder(
                    storeId = store.id,
                    storeName = store.name,
                    orderType = orderType,
                    pickupTimeSlot = pickupTimeSlot,
                    paymentMethod = paymentMethod
                )
                _latestOrder.value = newOrder
                showToast("Order #${newOrder.id} confirmed!")
                navigateTo(Screen.OrderTracking(newOrder.id))
            } catch (e: Exception) {
                showToast(e.message ?: "Could not place order")
            }
        }
    }

    fun updateOrderStatusFromHq(orderId: String, newStatus: String) {
        viewModelScope.launch {
            repository.updateOrderStatus(orderId, newStatus)
            showToast("Order #$orderId status set to $newStatus")
        }
    }

    fun toggleFavourite(product: Product) {
        viewModelScope.launch {
            repository.toggleFavourite(product)
            showToast(if (!product.isFavourite) "Saved to Favourites" else "Removed from Favourites")
        }
    }

    fun updateHqInventory(storeId: String, productId: String, newStock: Int) {
        viewModelScope.launch {
            repository.updateStoreInventory(storeId, productId, newStock)
            showToast("Inventory updated")
        }
    }

    fun showToast(msg: String) {
        _toastMessage.value = msg
    }

    fun clearToast() {
        _toastMessage.value = null
    }
}
