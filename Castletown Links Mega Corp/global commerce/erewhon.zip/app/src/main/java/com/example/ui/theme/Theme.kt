package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = ErewhonWarmIvory,
    onPrimary = ErewhonCharcoal,
    primaryContainer = ErewhonCharcoal,
    onPrimaryContainer = ErewhonWarmIvory,
    secondary = ErewhonAccentGold,
    onSecondary = ErewhonBlack,
    background = ErewhonBlack,
    onBackground = ErewhonWarmIvory,
    surface = ErewhonCharcoal,
    onSurface = ErewhonWarmIvory,
    surfaceVariant = Color(0xFF2C2D30),
    onSurfaceVariant = ErewhonWarmBeige,
    outline = Color(0xFF424448)
)

private val LightColorScheme = lightColorScheme(
    primary = ErewhonCharcoal,
    onPrimary = ErewhonWarmIvory,
    primaryContainer = ErewhonWarmBeige,
    onPrimaryContainer = ErewhonCharcoal,
    secondary = ErewhonMutedGreen,
    onSecondary = ErewhonSoftWhite,
    tertiary = ErewhonOlive,
    background = ErewhonWarmIvory,
    onBackground = ErewhonCharcoal,
    surface = ErewhonCream,
    onSurface = ErewhonCharcoal,
    surfaceVariant = ErewhonSoftWhite,
    onSurfaceVariant = ErewhonGrayText,
    outline = ErewhonLightBorder
)

@Composable
fun ErewhonTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    ErewhonTheme(darkTheme = darkTheme, content = content)
}
