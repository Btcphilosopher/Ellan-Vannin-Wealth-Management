package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Order
import com.example.data.model.OrderStatus
import com.example.data.model.Product
import com.example.data.model.Store
import com.example.ui.theme.*

@Composable
fun ErewhonHqScreen(
    orders: List<Order>,
    products: List<Product>,
    stores: List<Store>,
    onUpdateOrderStatus: (String, String) -> Unit,
    onUpdateStock: (String, String, Int) -> Unit,
    onExitHq: () -> Unit
) {
    var activeTab by remember { mutableStateOf(0) } // 0: Dashboard, 1: Orders, 2: Inventory

    val totalRevenue = remember(orders) { orders.sumOf { it.total } }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ErewhonWarmIvory)
            .testTag("erewhon_hq_screen")
    ) {
        // HQ Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(ErewhonCharcoal)
                .padding(horizontal = 20.dp, vertical = 20.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AdminPanelSettings, contentDescription = "HQ", tint = ErewhonAccentGold)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "EREWHON HQ PORTAL",
                            style = MaterialTheme.typography.labelSmall,
                            color = ErewhonAccentGold,
                            letterSpacing = 2.sp
                        )
                    }

                    OutlinedButton(
                        onClick = onExitHq,
                        shape = RoundedCornerShape(2.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.testTag("exit_hq_button")
                    ) {
                        Text("EXIT HQ", style = MaterialTheme.typography.labelSmall, color = ErewhonWarmIvory)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "INTERNAL OPERATIONS & CONTROL",
                    style = MaterialTheme.typography.titleLarge,
                    fontFamily = FontFamily.Serif,
                    color = ErewhonWarmIvory
                )
            }
        }

        // Tab Selector Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(ErewhonCream)
                .border(0.5.dp, ErewhonLightBorder)
        ) {
            listOf("DASHBOARD", "ORDERS (${orders.size})", "INVENTORY").forEachIndexed { idx, title ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { activeTab = idx }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (activeTab == idx) ErewhonCharcoal else ErewhonGrayText,
                        fontWeight = if (activeTab == idx) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            if (activeTab == 0) {
                // DASHBOARD TAB
                item {
                    Text("TODAY'S HQ PERFORMANCE", style = MaterialTheme.typography.labelSmall, color = ErewhonCharcoal, letterSpacing = 1.5.sp)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = ErewhonCream),
                            shape = RoundedCornerShape(2.dp),
                            modifier = Modifier
                                .weight(1f)
                                .border(0.5.dp, ErewhonLightBorder, RoundedCornerShape(2.dp))
                                .padding(16.dp)
                        ) {
                            Column {
                                Text("REVENUE", style = MaterialTheme.typography.labelSmall, color = ErewhonOlive)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("$${String.format("%.2f", totalRevenue)}", style = MaterialTheme.typography.titleLarge, fontFamily = FontFamily.Serif)
                            }
                        }

                        Card(
                            colors = CardDefaults.cardColors(containerColor = ErewhonCream),
                            shape = RoundedCornerShape(2.dp),
                            modifier = Modifier
                                .weight(1f)
                                .border(0.5.dp, ErewhonLightBorder, RoundedCornerShape(2.dp))
                                .padding(16.dp)
                        ) {
                            Column {
                                Text("ACTIVE ORDERS", style = MaterialTheme.typography.labelSmall, color = ErewhonOlive)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("${orders.size}", style = MaterialTheme.typography.titleLarge, fontFamily = FontFamily.Serif)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text("STORE STATUS & INVENTORY HEALTH", style = MaterialTheme.typography.labelSmall, color = ErewhonCharcoal, letterSpacing = 1.5.sp)
                    Spacer(modifier = Modifier.height(8.dp))

                    stores.take(4).forEach { store ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(ErewhonSoftWhite)
                                .border(0.5.dp, ErewhonLightBorder, RoundedCornerShape(2.dp))
                                .padding(12.dp)
                        ) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(store.name, style = MaterialTheme.typography.bodyMedium, color = ErewhonCharcoal)
                                Text("OPERATIONAL (7 AM - 10 PM)", style = MaterialTheme.typography.labelSmall, color = ErewhonMutedGreen)
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                    }
                }
            } else if (activeTab == 1) {
                // ORDERS MANAGEMENT TAB
                if (orders.isEmpty()) {
                    item {
                        Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                            Text("No customer orders placed yet.", style = MaterialTheme.typography.bodyLarge, color = ErewhonGrayText)
                        }
                    }
                } else {
                    items(orders) { order ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = ErewhonSoftWhite),
                            shape = RoundedCornerShape(2.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(0.5.dp, ErewhonLightBorder, RoundedCornerShape(2.dp))
                                .testTag("hq_order_row_${order.id}")
                        ) {
                            Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("ORDER #${order.id}", style = MaterialTheme.typography.titleMedium, fontFamily = FontFamily.Serif)
                                    Text("$${String.format("%.2f", order.total)}", style = MaterialTheme.typography.titleMedium)
                                }

                                Spacer(modifier = Modifier.height(4.dp))
                                Text("Store: ${order.storeName}", style = MaterialTheme.typography.bodyMedium, color = ErewhonGrayText)
                                Text("Items: ${order.itemsJson}", style = MaterialTheme.typography.bodyMedium)
                                Spacer(modifier = Modifier.height(8.dp))

                                Text("CURRENT STATUS: ${order.status}", style = MaterialTheme.typography.labelSmall, color = ErewhonMutedGreen)

                                Spacer(modifier = Modifier.height(12.dp))

                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    if (order.status == OrderStatus.CONFIRMED.name) {
                                        Button(
                                            onClick = { onUpdateOrderStatus(order.id, OrderStatus.PREPARING.name) },
                                            colors = ButtonDefaults.buttonColors(containerColor = ErewhonCharcoal),
                                            shape = RoundedCornerShape(2.dp),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                            modifier = Modifier.testTag("advance_to_preparing_${order.id}")
                                        ) {
                                            Text("MARK PREPARING IN KITCHEN", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp))
                                        }
                                    }

                                    if (order.status == OrderStatus.PREPARING.name) {
                                        Button(
                                            onClick = { onUpdateOrderStatus(order.id, OrderStatus.READY.name) },
                                            colors = ButtonDefaults.buttonColors(containerColor = ErewhonMutedGreen),
                                            shape = RoundedCornerShape(2.dp),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                            modifier = Modifier.testTag("advance_to_ready_${order.id}")
                                        ) {
                                            Text("MARK READY FOR PICKUP", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp))
                                        }
                                    }

                                    if (order.status == OrderStatus.READY.name) {
                                        Button(
                                            onClick = { onUpdateOrderStatus(order.id, OrderStatus.COLLECTED.name) },
                                            colors = ButtonDefaults.buttonColors(containerColor = ErewhonOlive),
                                            shape = RoundedCornerShape(2.dp),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                            modifier = Modifier.testTag("advance_to_collected_${order.id}")
                                        ) {
                                            Text("MARK COLLECTED", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } else if (activeTab == 2) {
                // INVENTORY CONTROL TAB
                item {
                    Text("SANTA MONICA LIVE STOCK COUNTS", style = MaterialTheme.typography.labelSmall, color = ErewhonCharcoal, letterSpacing = 1.5.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                }

                items(products) { prod ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = ErewhonCream),
                        shape = RoundedCornerShape(2.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(0.5.dp, ErewhonLightBorder, RoundedCornerShape(2.dp))
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(prod.name, style = MaterialTheme.typography.titleMedium)
                                Text(prod.category, style = MaterialTheme.typography.bodyMedium, color = ErewhonGrayText)
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Button(
                                    onClick = { onUpdateStock("store_sm", prod.id, 45) },
                                    colors = ButtonDefaults.buttonColors(containerColor = ErewhonCharcoal),
                                    shape = RoundedCornerShape(2.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Text("RESTOCK 45 UNITS", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
