package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class StockStatus {
    IN_STOCK,
    LOW_STOCK,
    OUT_OF_STOCK,
    DISCONTINUED
}

enum class ProductCategory(val displayName: String) {
    SMOOTHIES("Smoothies & Tonics"),
    PREPARED_FOODS("Prepared Foods"),
    GROCERY("Organic Grocery"),
    SUPPLEMENTS("Foundational Supplements"),
    BEAUTY("Clean Beauty"),
    WELLNESS("Wellness & Elixirs"),
    DRINKS("Cold-Pressed Juices"),
    PANTRY("The Pantry Edit"),
    REFRIGERATED("Refrigerated Goods"),
    FROZEN("Organic Frozen"),
    NEW("New Arrivals")
}

@Entity(tableName = "products")
data class Product(
    @PrimaryKey val id: String,
    val name: String,
    val brand: String = "Erewhon Organic",
    val category: String,
    val price: Double,
    val shortDescription: String,
    val fullDescription: String,
    val imageUrl: String,
    val categoryMarker: String = "ORGANIC",
    val ingredients: String = "",
    val calories: Int = 0,
    val proteinGrams: Int = 0,
    val carbsGrams: Int = 0,
    val fatGrams: Int = 0,
    val isOrganic: Boolean = true,
    val isVegan: Boolean = false,
    val isGlutenFree: Boolean = false,
    val isNonGmo: Boolean = true,
    val isKeto: Boolean = false,
    val isHighProtein: Boolean = false,
    val isNoAddedSugar: Boolean = false,
    val isColdPressed: Boolean = false,
    val collectionName: String? = null,
    val isFavourite: Boolean = false,
    val productStory: String? = null
)
