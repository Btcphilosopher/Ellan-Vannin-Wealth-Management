package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Product
import com.example.data.model.Store
import com.example.ui.theme.*

@Composable
fun ProductDetailScreen(
    product: Product?,
    selectedStore: Store?,
    allStores: List<Store>,
    onBackClick: () -> Unit,
    onAddToCart: (Product) -> Unit,
    onToggleFavourite: (Product) -> Unit
) {
    if (product == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Product not found", style = MaterialTheme.typography.bodyLarge)
        }
        return
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ErewhonWarmIvory)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Top Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier.testTag("product_detail_back_button")
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = ErewhonCharcoal)
                }

                Text(
                    text = product.brand.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = ErewhonGrayText,
                    modifier = Modifier.padding(start = 8.dp)
                )
            }

            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
            ) {
                // Hero Image Card
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(260.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(ErewhonCream)
                            .border(0.5.dp, ErewhonLightBorder, RoundedCornerShape(2.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Text(
                                text = product.categoryMarker,
                                style = MaterialTheme.typography.labelSmall,
                                color = ErewhonOlive,
                                letterSpacing = 2.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = product.name,
                                style = MaterialTheme.typography.displayMedium,
                                fontFamily = FontFamily.Serif,
                                color = ErewhonCharcoal
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))
                }

                // Title & Price
                item {
                    Text(
                        text = product.categoryMarker.uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        color = ErewhonOlive,
                        letterSpacing = 1.5.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = product.name,
                        style = MaterialTheme.typography.displayMedium,
                        fontFamily = FontFamily.Serif,
                        color = ErewhonCharcoal
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "$${String.format("%.2f", product.price)}",
                        style = MaterialTheme.typography.titleLarge,
                        fontFamily = FontFamily.Serif,
                        color = ErewhonCharcoal
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                }

                // Dietary Attributes Chips
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        if (product.isOrganic) AttributeBadge("ORGANIC")
                        if (product.isGlutenFree) AttributeBadge("GLUTEN FREE")
                        if (product.isVegan) AttributeBadge("VEGAN")
                        if (product.isKeto) AttributeBadge("KETO")
                        if (product.isColdPressed) AttributeBadge("COLD PRESSED")
                    }

                    Spacer(modifier = Modifier.height(20.dp))
                }

                // Description & Story
                item {
                    Text(
                        text = "DESCRIPTION",
                        style = MaterialTheme.typography.labelSmall,
                        color = ErewhonCharcoal,
                        letterSpacing = 1.5.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = product.fullDescription,
                        style = MaterialTheme.typography.bodyLarge,
                        color = ErewhonCharcoal,
                        lineHeight = 24.sp
                    )

                    if (!product.productStory.isNullOrEmpty()) {
                        Spacer(modifier = Modifier.height(16.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(ErewhonCream)
                                .border(0.5.dp, ErewhonLightBorder, RoundedCornerShape(2.dp))
                                .padding(16.dp)
                        ) {
                            Column {
                                Text(
                                    text = "THE EREWHON STANDARD",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ErewhonAccentGold,
                                    letterSpacing = 1.5.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = product.productStory!!,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = ErewhonCharcoal
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))
                }

                // Ingredients
                if (product.ingredients.isNotEmpty()) {
                    item {
                        Text(
                            text = "INGREDIENTS",
                            style = MaterialTheme.typography.labelSmall,
                            color = ErewhonCharcoal,
                            letterSpacing = 1.5.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = product.ingredients,
                            style = MaterialTheme.typography.bodyMedium,
                            color = ErewhonGrayText,
                            lineHeight = 20.sp
                        )

                        Spacer(modifier = Modifier.height(20.dp))
                    }
                }

                // Nutrition Table
                if (product.calories > 0) {
                    item {
                        Text(
                            text = "NUTRITION FACTS",
                            style = MaterialTheme.typography.labelSmall,
                            color = ErewhonCharcoal,
                            letterSpacing = 1.5.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(0.5.dp, ErewhonLightBorder, RoundedCornerShape(2.dp))
                                .padding(12.dp)
                        ) {
                            Column {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Calories", style = MaterialTheme.typography.bodyMedium)
                                    Text("${product.calories} kcal", style = MaterialTheme.typography.titleMedium)
                                }
                                HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp), color = ErewhonLightBorder)
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Protein", style = MaterialTheme.typography.bodyMedium)
                                    Text("${product.proteinGrams}g", style = MaterialTheme.typography.bodyMedium)
                                }
                                HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp), color = ErewhonLightBorder)
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Total Carbs", style = MaterialTheme.typography.bodyMedium)
                                    Text("${product.carbsGrams}g", style = MaterialTheme.typography.bodyMedium)
                                }
                                HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp), color = ErewhonLightBorder)
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Total Fat", style = MaterialTheme.typography.bodyMedium)
                                    Text("${product.fatGrams}g", style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))
                    }
                }

                // Store Availability Matrix
                item {
                    Text(
                        text = "STORE AVAILABILITY",
                        style = MaterialTheme.typography.labelSmall,
                        color = ErewhonCharcoal,
                        letterSpacing = 1.5.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(0.5.dp, ErewhonLightBorder, RoundedCornerShape(2.dp))
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        allStores.take(4).forEach { store ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = store.name.replace("Erewhon — ", ""),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = ErewhonCharcoal
                                )

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = "In stock",
                                        tint = ErewhonMutedGreen,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "IN STOCK",
                                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                        color = ErewhonMutedGreen
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(30.dp))
                }
            }

            // Bottom Sticky Bar: ADD TO BAG
            Surface(
                color = ErewhonWarmIvory,
                tonalElevation = 8.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { onToggleFavourite(product) },
                        modifier = Modifier
                            .size(48.dp)
                            .border(0.5.dp, ErewhonCharcoal, RoundedCornerShape(2.dp))
                    ) {
                        Icon(
                            imageVector = if (product.isFavourite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                            contentDescription = "Save favourite",
                            tint = if (product.isFavourite) Color(0xFFC84B31) else ErewhonCharcoal
                        )
                    }

                    Button(
                        onClick = { onAddToCart(product) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ErewhonCharcoal,
                            contentColor = ErewhonWarmIvory
                        ),
                        shape = RoundedCornerShape(2.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("add_to_bag_detail_button")
                    ) {
                        Text(
                            text = "ADD TO BAG — $${String.format("%.2f", product.price)}",
                            style = MaterialTheme.typography.labelLarge,
                            letterSpacing = 2.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AttributeBadge(label: String) {
    Box(
        modifier = Modifier
            .background(ErewhonCream)
            .border(0.5.dp, ErewhonLightBorder, RoundedCornerShape(2.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
            color = ErewhonOlive,
            letterSpacing = 1.sp
        )
    }
}
