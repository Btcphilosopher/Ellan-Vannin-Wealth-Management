package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Store
import com.example.ui.theme.*
import com.example.ui.viewmodel.Screen

@Composable
fun ErewhonTopAppBar(
    currentStore: Store?,
    cartCount: Int,
    onStoreClick: () -> Unit,
    onSearchClick: () -> Unit,
    onBagClick: () -> Unit,
    onHqClick: () -> Unit
) {
    Surface(
        color = ErewhonWarmIvory,
        tonalElevation = 1.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Store Picker Chip
                Row(
                    modifier = Modifier
                        .testTag("store_selector_chip")
                        .clip(RoundedCornerShape(20.dp))
                        .background(ErewhonCream)
                        .clickable { onStoreClick() }
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = "Store location",
                        tint = ErewhonOlive,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = currentStore?.name?.replace("Erewhon — ", "")?.uppercase() ?: "SANTA MONICA",
                        style = MaterialTheme.typography.labelSmall,
                        color = ErewhonCharcoal
                    )
                    Icon(
                        imageVector = Icons.Default.ArrowDropDown,
                        contentDescription = "Change store",
                        tint = ErewhonCharcoal,
                        modifier = Modifier.size(16.dp)
                    )
                }

                // Brand Header
                Text(
                    text = "EREWHON",
                    style = MaterialTheme.typography.titleLarge,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Normal,
                    letterSpacing = 4.sp,
                    color = ErewhonCharcoal,
                    modifier = Modifier.testTag("erewhon_logo_header")
                )

                // Actions: Search, HQ, Bag
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(
                        onClick = onSearchClick,
                        modifier = Modifier.testTag("search_button")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Search,
                            contentDescription = "Search Erewhon",
                            tint = ErewhonCharcoal
                        )
                    }

                    IconButton(
                        onClick = onHqClick,
                        modifier = Modifier.testTag("hq_toggle_button")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.AdminPanelSettings,
                            contentDescription = "Erewhon HQ",
                            tint = ErewhonMutedGreen
                        )
                    }

                    Box(
                        modifier = Modifier
                            .testTag("cart_bag_button")
                            .clickable { onBagClick() }
                            .padding(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.ShoppingBag,
                            contentDescription = "Shopping Bag",
                            tint = ErewhonCharcoal,
                            modifier = Modifier.size(26.dp)
                        )
                        if (cartCount > 0) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .offset(x = 4.dp, y = (-2).dp)
                                    .size(18.dp)
                                    .clip(CircleShape)
                                    .background(ErewhonCharcoal),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = cartCount.toString(),
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                    color = ErewhonWarmIvory
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ErewhonBottomNavigationBar(
    currentScreen: Screen,
    onNavigate: (Screen) -> Unit
) {
    Surface(
        color = ErewhonWarmIvory,
        tonalElevation = 6.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            NavItem(
                label = "HOME",
                icon = Icons.Outlined.Home,
                selectedIcon = Icons.Filled.Home,
                isSelected = currentScreen is Screen.Home,
                onClick = { onNavigate(Screen.Home) }
            )
            NavItem(
                label = "SHOP",
                icon = Icons.Outlined.GridView,
                selectedIcon = Icons.Filled.GridView,
                isSelected = currentScreen is Screen.Shop,
                onClick = { onNavigate(Screen.Shop) }
            )
            NavItem(
                label = "SMOOTHIES",
                icon = Icons.Outlined.LocalDrink,
                selectedIcon = Icons.Filled.LocalDrink,
                isSelected = currentScreen is Screen.Smoothies,
                onClick = { onNavigate(Screen.Smoothies) }
            )
            NavItem(
                label = "JOURNAL",
                icon = Icons.Outlined.MenuBook,
                selectedIcon = Icons.Filled.MenuBook,
                isSelected = currentScreen is Screen.Journal,
                onClick = { onNavigate(Screen.Journal) }
            )
            NavItem(
                label = "STORES",
                icon = Icons.Outlined.Storefront,
                selectedIcon = Icons.Filled.Storefront,
                isSelected = currentScreen is Screen.Stores,
                onClick = { onNavigate(Screen.Stores) }
            )
            NavItem(
                label = "REWARDS",
                icon = Icons.Outlined.CardMembership,
                selectedIcon = Icons.Filled.CardMembership,
                isSelected = currentScreen is Screen.Rewards,
                onClick = { onNavigate(Screen.Rewards) }
            )
        }
    }
}

@Composable
private fun NavItem(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selectedIcon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .testTag("nav_item_$label")
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Icon(
            imageVector = if (isSelected) selectedIcon else icon,
            contentDescription = label,
            tint = if (isSelected) ErewhonCharcoal else ErewhonGrayText,
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
            color = if (isSelected) ErewhonCharcoal else ErewhonGrayText
        )
    }
}
