package com.example.data.db

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductDao {
    @Query("SELECT * FROM products")
    fun getAllProducts(): Flow<List<Product>>

    @Query("SELECT * FROM products WHERE id = :id")
    suspend fun getProductById(id: String): Product?

    @Query("SELECT * FROM products WHERE category = :category")
    fun getProductsByCategory(category: String): Flow<List<Product>>

    @Query("SELECT * FROM products WHERE collectionName = :collectionName")
    fun getProductsByCollection(collectionName: String): Flow<List<Product>>

    @Query("SELECT * FROM products WHERE name LIKE '%' || :query || '%' OR category LIKE '%' || :query || '%' OR brand LIKE '%' || :query || '%'")
    fun searchProducts(query: String): Flow<List<Product>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProducts(products: List<Product>)

    @Query("UPDATE products SET isFavourite = :isFav WHERE id = :id")
    suspend fun updateFavourite(id: String, isFav: Boolean)
}

@Dao
interface StoreDao {
    @Query("SELECT * FROM stores")
    fun getAllStores(): Flow<List<Store>>

    @Query("SELECT * FROM stores WHERE id = :id")
    suspend fun getStoreById(id: String): Store?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStores(stores: List<Store>)

    @Query("SELECT * FROM store_inventory WHERE storeId = :storeId")
    fun getInventoryForStore(storeId: String): Flow<List<StoreInventory>>

    @Query("SELECT * FROM store_inventory WHERE storeId = :storeId AND productId = :productId")
    suspend fun getInventoryItem(storeId: String, productId: String): StoreInventory?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInventory(inventory: List<StoreInventory>)

    @Query("UPDATE store_inventory SET onHandQuantity = :onHand, reservedQuantity = :reserved, status = :status WHERE storeId = :storeId AND productId = :productId")
    suspend fun updateStock(storeId: String, productId: String, onHand: Int, reserved: Int, status: String)
}

@Dao
interface CartDao {
    @Query("SELECT * FROM cart_items")
    fun getCartItems(): Flow<List<CartItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCartItem(item: CartItem)

    @Query("UPDATE cart_items SET quantity = :quantity WHERE id = :id")
    suspend fun updateQuantity(id: Int, quantity: Int)

    @Query("DELETE FROM cart_items WHERE id = :id")
    suspend fun deleteCartItem(id: Int)

    @Query("DELETE FROM cart_items")
    suspend fun clearCart()
}

@Dao
interface OrderDao {
    @Query("SELECT * FROM orders ORDER BY timestamp DESC")
    fun getAllOrders(): Flow<List<Order>>

    @Query("SELECT * FROM orders WHERE id = :id")
    fun getOrderById(id: String): Flow<Order?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: Order)

    @Query("UPDATE orders SET status = :status WHERE id = :id")
    suspend fun updateOrderStatus(id: String, status: String)
}

@Dao
interface EditorialDao {
    @Query("SELECT * FROM editorial_articles")
    fun getAllArticles(): Flow<List<EditorialArticle>>

    @Query("SELECT * FROM editorial_articles WHERE id = :id")
    suspend fun getArticleById(id: String): EditorialArticle?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertArticles(articles: List<EditorialArticle>)
}

@Dao
interface FavouriteDao {
    @Query("SELECT * FROM favourites")
    fun getAllFavourites(): Flow<List<FavouriteItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addFavourite(item: FavouriteItem)

    @Query("DELETE FROM favourites WHERE id = :id")
    suspend fun removeFavourite(id: String)
}
