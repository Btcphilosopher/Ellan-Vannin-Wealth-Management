package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Store
import com.example.ui.theme.*

@Composable
fun StoreLocatorScreen(
    stores: List<Store>,
    selectedStore: Store?,
    onSelectStore: (Store) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }

    val filteredStores = remember(stores, searchQuery) {
        if (searchQuery.isBlank()) stores
        else stores.filter {
            it.name.contains(searchQuery, ignoreCase = true) ||
                    it.address.contains(searchQuery, ignoreCase = true) ||
                    it.city.contains(searchQuery, ignoreCase = true) ||
                    it.zipCode.contains(searchQuery)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ErewhonWarmIvory)
            .testTag("store_locator_screen")
    ) {
        // Banner Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(ErewhonCharcoal)
                .padding(20.dp)
        ) {
            Column {
                Text(
                    text = "LOCATIONS & INVENTORY",
                    style = MaterialTheme.typography.labelSmall,
                    color = ErewhonAccentGold,
                    letterSpacing = 2.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "FIND EREWHON NEAR YOU",
                    style = MaterialTheme.typography.displayMedium,
                    fontFamily = FontFamily.Serif,
                    color = ErewhonWarmIvory
                )
            }
        }

        // Search Input
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search by City or ZIP Code (e.g. Santa Monica, 90210)", style = MaterialTheme.typography.bodyMedium, color = ErewhonGrayText) },
            leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = "Search", tint = ErewhonGrayText) },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = ErewhonCharcoal,
                unfocusedBorderColor = ErewhonLightBorder,
                focusedContainerColor = ErewhonSoftWhite,
                unfocusedContainerColor = ErewhonSoftWhite
            ),
            shape = RoundedCornerShape(2.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .testTag("store_search_input")
        )

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(filteredStores) { store ->
                val isSelected = selectedStore?.id == store.id

                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) ErewhonCream else ErewhonSoftWhite
                    ),
                    shape = RoundedCornerShape(2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            width = if (isSelected) 1.dp else 0.5.dp,
                            color = if (isSelected) ErewhonCharcoal else ErewhonLightBorder,
                            shape = RoundedCornerShape(2.dp)
                        )
                        .testTag("store_card_${store.id}")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = store.name,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontFamily = FontFamily.Serif,
                                    color = ErewhonCharcoal
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "${store.address}, ${store.city} ${store.zipCode}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = ErewhonGrayText
                                )
                            }

                            if (isSelected) {
                                Surface(
                                    color = ErewhonCharcoal,
                                    shape = RoundedCornerShape(2.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Default.Check, contentDescription = "Active", tint = ErewhonWarmIvory, modifier = Modifier.size(12.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("ACTIVE STORE", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = ErewhonWarmIvory)
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "HOURS: ${store.hours}",
                            style = MaterialTheme.typography.labelSmall,
                            color = ErewhonOlive
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "SERVICES: ${store.services}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = ErewhonGrayText
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = { onSelectStore(store) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSelected) ErewhonMutedGreen else ErewhonCharcoal,
                                contentColor = ErewhonWarmIvory
                            ),
                            shape = RoundedCornerShape(2.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(40.dp)
                                .testTag("select_store_button_${store.id}")
                        ) {
                            Text(
                                text = if (isSelected) "CURRENT PREFERRED STORE" else "SET AS MY STORE",
                                style = MaterialTheme.typography.labelSmall,
                                letterSpacing = 1.5.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
