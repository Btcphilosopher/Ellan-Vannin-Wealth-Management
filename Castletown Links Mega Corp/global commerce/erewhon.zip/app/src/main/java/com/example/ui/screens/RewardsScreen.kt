package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FavouriteItem
import com.example.data.model.Order
import com.example.data.model.Store
import com.example.ui.theme.*
import com.example.ui.viewmodel.Screen

@Composable
fun RewardsScreen(
    selectedStore: Store?,
    orders: List<Order>,
    favourites: List<FavouriteItem>,
    onNavigateTo: (Screen) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ErewhonWarmIvory)
            .testTag("rewards_screen")
    ) {
        // Membership Header Pass
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(ErewhonCharcoal)
                .padding(24.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "MY EREWHON",
                        style = MaterialTheme.typography.labelSmall,
                        color = ErewhonAccentGold,
                        letterSpacing = 2.sp
                    )

                    Surface(
                        color = ErewhonAccentGold,
                        shape = RoundedCornerShape(2.dp)
                    ) {
                        Text(
                            text = "VIP MEMBER",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                            color = ErewhonBlack,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "VIP WELLNESS PASS",
                    style = MaterialTheme.typography.displayMedium,
                    fontFamily = FontFamily.Serif,
                    color = ErewhonWarmIvory
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "Preferred Store: ${selectedStore?.name ?: "Santa Monica"}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = ErewhonWarmBeige
                )
            }
        }

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            // Stats Row
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = ErewhonCream),
                        shape = RoundedCornerShape(2.dp),
                        modifier = Modifier
                            .weight(1f)
                            .border(0.5.dp, ErewhonLightBorder, RoundedCornerShape(2.dp))
                            .padding(16.dp)
                    ) {
                        Column {
                            Text("SAVED ITEMS", style = MaterialTheme.typography.labelSmall, color = ErewhonOlive)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("${favourites.size}", style = MaterialTheme.typography.displayMedium, fontFamily = FontFamily.Serif)
                        }
                    }

                    Card(
                        colors = CardDefaults.cardColors(containerColor = ErewhonCream),
                        shape = RoundedCornerShape(2.dp),
                        modifier = Modifier
                            .weight(1f)
                            .border(0.5.dp, ErewhonLightBorder, RoundedCornerShape(2.dp))
                            .padding(16.dp)
                    ) {
                        Column {
                            Text("TOTAL ORDERS", style = MaterialTheme.typography.labelSmall, color = ErewhonOlive)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("${orders.size}", style = MaterialTheme.typography.displayMedium, fontFamily = FontFamily.Serif)
                        }
                    }
                }
            }

            // Navigation Actions
            item {
                Text(
                    text = "ACCOUNT & FAVOURITES",
                    style = MaterialTheme.typography.labelSmall,
                    color = ErewhonCharcoal,
                    letterSpacing = 1.5.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(0.5.dp, ErewhonLightBorder, RoundedCornerShape(2.dp))
                ) {
                    AccountOptionRow(title = "Saved Favourites (${favourites.size})", icon = Icons.Default.Favorite, onClick = { onNavigateTo(Screen.Favourites) })
                    HorizontalDivider(color = ErewhonLightBorder)
                    AccountOptionRow(title = "Preferred Store (${selectedStore?.name?.replace("Erewhon — ", "") ?: "Santa Monica"})", icon = Icons.Default.Storefront, onClick = { onNavigateTo(Screen.Stores) })
                    HorizontalDivider(color = ErewhonLightBorder)
                    AccountOptionRow(title = "Internal Erewhon HQ Portal", icon = Icons.Default.Star, onClick = { onNavigateTo(Screen.ErewhonHQ) })
                }
            }

            // Order History List
            if (orders.isNotEmpty()) {
                item {
                    Text(
                        text = "RECENT ORDERS",
                        style = MaterialTheme.typography.labelSmall,
                        color = ErewhonCharcoal,
                        letterSpacing = 1.5.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }

                items(orders) { order ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = ErewhonSoftWhite),
                        shape = RoundedCornerShape(2.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(0.5.dp, ErewhonLightBorder, RoundedCornerShape(2.dp))
                            .clickable { onNavigateTo(Screen.OrderTracking(order.id)) }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("ORDER #${order.id}", style = MaterialTheme.typography.titleMedium)
                                Text(order.itemsJson, style = MaterialTheme.typography.bodyMedium, color = ErewhonGrayText)
                                Text("Status: ${order.status}", style = MaterialTheme.typography.labelSmall, color = ErewhonMutedGreen)
                            }

                            Text("$${String.format("%.2f", order.total)}", style = MaterialTheme.typography.titleMedium, fontFamily = FontFamily.Serif)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AccountOptionRow(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = title, tint = ErewhonCharcoal, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(12.dp))
            Text(title, style = MaterialTheme.typography.bodyLarge, color = ErewhonCharcoal)
        }

        Icon(Icons.Default.ChevronRight, contentDescription = "Open", tint = ErewhonGrayText)
    }
}
