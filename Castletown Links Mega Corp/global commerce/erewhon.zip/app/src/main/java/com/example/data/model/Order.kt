package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cart_items")
data class CartItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val productId: String,
    val productName: String,
    val brand: String,
    val price: Double,
    val imageUrl: String,
    val categoryMarker: String,
    var quantity: Int,
    val selectedStoreId: String,
    val customizationNotes: String = ""
)

enum class OrderStatus(val displayName: String) {
    CONFIRMED("Confirmed"),
    PREPARING("Preparing in Kitchen"),
    READY("Ready for Pickup"),
    OUT_FOR_DELIVERY("Out for Delivery"),
    COLLECTED("Collected / Delivered")
}

@Entity(tableName = "orders")
data class Order(
    @PrimaryKey val id: String, // e.g. "EW-10482"
    val timestamp: Long = System.currentTimeMillis(),
    val storeId: String,
    val storeName: String,
    val orderType: String, // "STORE_PICKUP" or "DELIVERY"
    val pickupTimeSlot: String,
    val paymentMethod: String, // "Credit Card", "Apple Pay", "Google Pay"
    val itemsJson: String, // Serialized list of items
    val subtotal: Double,
    val tax: Double,
    val total: Double,
    val status: String = OrderStatus.CONFIRMED.name,
    val customerName: String = "Erewhon VIP Member"
)
