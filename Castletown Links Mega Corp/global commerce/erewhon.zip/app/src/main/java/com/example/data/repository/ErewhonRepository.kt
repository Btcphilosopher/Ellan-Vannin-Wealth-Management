package com.example.data.repository

import com.example.data.db.ErewhonDataSeeder
import com.example.data.db.ErewhonDatabase
import com.example.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.util.UUID

class ErewhonRepository(private val db: ErewhonDatabase) {

    val allProducts: Flow<List<Product>> = db.productDao().getAllProducts()
    val allStores: Flow<List<Store>> = db.storeDao().getAllStores()
    val allCartItems: Flow<List<CartItem>> = db.cartDao().getCartItems()
    val allOrders: Flow<List<Order>> = db.orderDao().getAllOrders()
    val allArticles: Flow<List<EditorialArticle>> = db.editorialDao().getAllArticles()
    val allFavourites: Flow<List<FavouriteItem>> = db.favouriteDao().getAllFavourites()

    suspend fun seedInitialDataIfEmpty() = withContext(Dispatchers.IO) {
        val existingProducts = db.productDao().getAllProducts().first()
        if (existingProducts.isEmpty()) {
            db.storeDao().insertStores(ErewhonDataSeeder.stores)
            db.productDao().insertProducts(ErewhonDataSeeder.products)
            db.editorialDao().insertArticles(ErewhonDataSeeder.editorialArticles)
            db.storeDao().insertInventory(ErewhonDataSeeder.createInventory())
        }
    }

    fun getProductsByCategory(category: String): Flow<List<Product>> {
        return db.productDao().getProductsByCategory(category)
    }

    fun getProductsByCollection(collectionName: String): Flow<List<Product>> {
        return db.productDao().getProductsByCollection(collectionName)
    }

    fun searchProducts(query: String): Flow<List<Product>> {
        return db.productDao().searchProducts(query)
    }

    suspend fun getProductById(id: String): Product? = withContext(Dispatchers.IO) {
        db.productDao().getProductById(id)
    }

    suspend fun addToCart(product: Product, storeId: String, quantity: Int = 1) = withContext(Dispatchers.IO) {
        val currentCart = db.cartDao().getCartItems().first()
        val existing = currentCart.find { it.productId == product.id && it.selectedStoreId == storeId }
        if (existing != null) {
            db.cartDao().updateQuantity(existing.id, existing.quantity + quantity)
        } else {
            val newItem = CartItem(
                productId = product.id,
                productName = product.name,
                brand = product.brand,
                price = product.price,
                imageUrl = product.imageUrl,
                categoryMarker = product.categoryMarker,
                quantity = quantity,
                selectedStoreId = storeId
            )
            db.cartDao().insertCartItem(newItem)
        }
    }

    suspend fun updateCartQuantity(cartItemId: Int, newQty: Int) = withContext(Dispatchers.IO) {
        if (newQty <= 0) {
            db.cartDao().deleteCartItem(cartItemId)
        } else {
            db.cartDao().updateQuantity(cartItemId, newQty)
        }
    }

    suspend fun removeCartItem(cartItemId: Int) = withContext(Dispatchers.IO) {
        db.cartDao().deleteCartItem(cartItemId)
    }

    suspend fun clearCart() = withContext(Dispatchers.IO) {
        db.cartDao().clearCart()
    }

    suspend fun placeOrder(
        storeId: String,
        storeName: String,
        orderType: String,
        pickupTimeSlot: String,
        paymentMethod: String
    ): Order = withContext(Dispatchers.IO) {
        val cartItems = db.cartDao().getCartItems().first()
        require(cartItems.isNotEmpty()) { "Cart is empty" }

        val subtotal = cartItems.sumOf { it.price * it.quantity }
        val tax = subtotal * 0.095 // 9.5% CA sales tax
        val total = subtotal + tax

        val orderId = "EW-" + (10000..99999).random()

        // Serialize cart items simple JSON string
        val itemsSummary = cartItems.joinToString(" | ") { "${it.quantity}x ${it.productName}" }

        val order = Order(
            id = orderId,
            timestamp = System.currentTimeMillis(),
            storeId = storeId,
            storeName = storeName,
            orderType = orderType,
            pickupTimeSlot = pickupTimeSlot,
            paymentMethod = paymentMethod,
            itemsJson = itemsSummary,
            subtotal = subtotal,
            tax = tax,
            total = total,
            status = OrderStatus.CONFIRMED.name
        )

        db.orderDao().insertOrder(order)

        // Update synthetic inventory reserved counts in HQ
        for (item in cartItems) {
            val inv = db.storeDao().getInventoryItem(storeId, item.productId)
            if (inv != null) {
                val newOnHand = maxOf(0, inv.onHandQuantity - item.quantity)
                val newReserved = inv.reservedQuantity + item.quantity
                val status = if (newOnHand <= 0) StockStatus.OUT_OF_STOCK.name else if (newOnHand < 10) StockStatus.LOW_STOCK.name else StockStatus.IN_STOCK.name
                db.storeDao().updateStock(storeId, item.productId, newOnHand, newReserved, status)
            }
        }

        db.cartDao().clearCart()
        order
    }

    suspend fun updateOrderStatus(orderId: String, newStatus: String) = withContext(Dispatchers.IO) {
        db.orderDao().updateOrderStatus(orderId, newStatus)
    }

    suspend fun toggleFavourite(product: Product) = withContext(Dispatchers.IO) {
        val newFav = !product.isFavourite
        db.productDao().updateFavourite(product.id, newFav)
        if (newFav) {
            db.favouriteDao().addFavourite(
                FavouriteItem(
                    id = product.id,
                    type = "PRODUCT",
                    title = product.name,
                    subtitle = product.category,
                    imageUrl = product.imageUrl
                )
            )
        } else {
            db.favouriteDao().removeFavourite(product.id)
        }
    }

    suspend fun updateStoreInventory(storeId: String, productId: String, newOnHand: Int) = withContext(Dispatchers.IO) {
        val status = if (newOnHand <= 0) StockStatus.OUT_OF_STOCK.name else if (newOnHand < 10) StockStatus.LOW_STOCK.name else StockStatus.IN_STOCK.name
        db.storeDao().updateStock(storeId, productId, newOnHand, 0, status)
    }

    suspend fun publishEditorialArticle(article: EditorialArticle) = withContext(Dispatchers.IO) {
        db.editorialDao().insertArticles(listOf(article))
    }

    fun getInventoryForStore(storeId: String): Flow<List<StoreInventory>> {
        return db.storeDao().getInventoryForStore(storeId)
    }
}
