package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.EditorialArticle
import com.example.data.model.Product
import com.example.ui.components.ProductCard
import com.example.ui.theme.*

@Composable
fun JournalScreen(
    articles: List<EditorialArticle>,
    selectedArticleId: String?,
    products: List<Product>,
    onSelectArticle: (String?) -> Unit,
    onAddToCart: (Product) -> Unit,
    onToggleFavourite: (Product) -> Unit
) {
    if (selectedArticleId != null) {
        val article = articles.find { it.id == selectedArticleId }
        ArticleReaderScreen(
            article = article,
            allProducts = products,
            onBackClick = { onSelectArticle(null) },
            onAddToCart = onAddToCart,
            onToggleFavourite = onToggleFavourite
        )
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ErewhonWarmIvory)
            .testTag("journal_screen_container")
    ) {
        // Journal Banner Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(ErewhonCharcoal)
                .padding(horizontal = 20.dp, vertical = 28.dp)
        ) {
            Column {
                Text(
                    text = "EREWHON EDITORIAL",
                    style = MaterialTheme.typography.labelSmall,
                    color = ErewhonAccentGold,
                    letterSpacing = 2.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "JOURNAL & SHOP THE STORY",
                    style = MaterialTheme.typography.displayMedium,
                    fontFamily = FontFamily.Serif,
                    color = ErewhonWarmIvory
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Deep dives into wellness science, organic makers, and food rituals.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = ErewhonWarmBeige
                )
            }
        }

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(articles) { article ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = ErewhonCream),
                    shape = RoundedCornerShape(2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(0.5.dp, ErewhonLightBorder, RoundedCornerShape(2.dp))
                        .clickable { onSelectArticle(article.id) }
                        .testTag("article_card_${article.id}")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp)
                    ) {
                        Text(
                            text = "${article.category} • ${article.dateText}",
                            style = MaterialTheme.typography.labelSmall,
                            color = ErewhonOlive,
                            letterSpacing = 1.5.sp
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = article.title,
                            style = MaterialTheme.typography.displayMedium,
                            fontFamily = FontFamily.Serif,
                            color = ErewhonCharcoal
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = article.subtitle,
                            style = MaterialTheme.typography.bodyLarge,
                            color = ErewhonGrayText
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "READ STORY & SHOP PRODUCTS",
                                style = MaterialTheme.typography.labelSmall,
                                color = ErewhonCharcoal,
                                letterSpacing = 1.5.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                imageVector = Icons.Default.ArrowForward,
                                contentDescription = "Read article",
                                tint = ErewhonCharcoal,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ArticleReaderScreen(
    article: EditorialArticle?,
    allProducts: List<Product>,
    onBackClick: () -> Unit,
    onAddToCart: (Product) -> Unit,
    onToggleFavourite: (Product) -> Unit
) {
    if (article == null) return

    val relatedProductIdsList = article.relatedProductIds.split(",")
    val relatedProducts = allProducts.filter { p -> relatedProductIdsList.contains(p.id) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ErewhonWarmIvory)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBackClick,
                modifier = Modifier.testTag("article_back_button")
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = ErewhonCharcoal)
            }
            Text(
                text = "EREWHON JOURNAL",
                style = MaterialTheme.typography.labelSmall,
                color = ErewhonGrayText,
                letterSpacing = 2.sp
            )
        }

        LazyColumn(
            contentPadding = PaddingValues(20.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            item {
                Text(
                    text = "${article.category} • ${article.dateText}",
                    style = MaterialTheme.typography.labelSmall,
                    color = ErewhonOlive,
                    letterSpacing = 2.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = article.title,
                    style = MaterialTheme.typography.displayLarge,
                    fontFamily = FontFamily.Serif,
                    color = ErewhonCharcoal
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "By ${article.author}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = ErewhonGrayText
                )

                Spacer(modifier = Modifier.height(20.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(ErewhonCream)
                        .border(0.5.dp, ErewhonLightBorder)
                        .padding(20.dp)
                ) {
                    Text(
                        text = article.leadParagraph,
                        style = MaterialTheme.typography.titleMedium,
                        fontFamily = FontFamily.Serif,
                        color = ErewhonCharcoal,
                        lineHeight = 26.sp
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = article.bodyText,
                    style = MaterialTheme.typography.bodyLarge,
                    color = ErewhonCharcoal,
                    lineHeight = 26.sp
                )

                Spacer(modifier = Modifier.height(30.dp))
            }

            // Embedded "Shop the Story" Tray
            if (relatedProducts.isNotEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = ErewhonCream),
                        shape = RoundedCornerShape(2.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(0.5.dp, ErewhonLightBorder, RoundedCornerShape(2.dp))
                            .padding(16.dp)
                    ) {
                        Column {
                            Text(
                                text = "SHOP THE STORY",
                                style = MaterialTheme.typography.labelLarge,
                                color = ErewhonCharcoal,
                                letterSpacing = 2.sp
                            )
                            Text(
                                text = "Featured products mentioned in this article.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = ErewhonGrayText
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                items(relatedProducts) { p ->
                                    ProductCard(
                                        product = p,
                                        onProductClick = { },
                                        onAddToCart = onAddToCart,
                                        onToggleFavourite = onToggleFavourite,
                                        modifier = Modifier.width(200.dp)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(40.dp))
                }
            }
        }
    }
}
