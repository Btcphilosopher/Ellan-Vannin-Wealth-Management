package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Product
import com.example.ui.components.ErewhonBottomNavigationBar
import com.example.ui.components.ErewhonTopAppBar
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.ErewhonViewModel
import com.example.ui.viewmodel.Screen
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {

    private val viewModel: ErewhonViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            ErewhonTheme {
                ErewhonMainApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun ErewhonMainApp(viewModel: ErewhonViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val allProducts by viewModel.allProducts.collectAsStateWithLifecycle()
    val allStores by viewModel.allStores.collectAsStateWithLifecycle()
    val cartItems by viewModel.cartItems.collectAsStateWithLifecycle()
    val orders by viewModel.orders.collectAsStateWithLifecycle()
    val articles by viewModel.articles.collectAsStateWithLifecycle()
    val favourites by viewModel.favourites.collectAsStateWithLifecycle()
    val selectedStore by viewModel.selectedStore.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val toastMessage by viewModel.toastMessage.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val selectedCollection by viewModel.selectedCollection.collectAsStateWithLifecycle()
    val latestOrder by viewModel.latestOrder.collectAsStateWithLifecycle()

    val totalCartCount = remember(cartItems) { cartItems.sumOf { it.quantity } }

    // Handle Back Button on secondary screens
    if (currentScreen !is Screen.Home) {
        BackHandler {
            viewModel.navigateTo(Screen.Home)
        }
    }

    // Auto-dismiss toast
    LaunchedEffect(toastMessage) {
        if (toastMessage != null) {
            delay(2800)
            viewModel.clearToast()
        }
    }

    val favouriteProducts = remember(allProducts, favourites) {
        val favIds = favourites.map { it.id }
        allProducts.filter { favIds.contains(it.id) || it.isFavourite }
    }

    val smoothiesList = remember(allProducts) {
        allProducts.filter { it.category.contains("Smoothie", ignoreCase = true) }
    }

    val preparedList = remember(allProducts) {
        allProducts.filter { it.category.contains("Prepared", ignoreCase = true) || it.category.contains("Kitchen", ignoreCase = true) }
    }

    Scaffold(
        topBar = {
            if (currentScreen !is Screen.ErewhonHQ) {
                ErewhonTopAppBar(
                    currentStore = selectedStore,
                    cartCount = totalCartCount,
                    onStoreClick = { viewModel.navigateTo(Screen.Stores) },
                    onSearchClick = { viewModel.navigateTo(Screen.Shop) },
                    onBagClick = { viewModel.navigateTo(Screen.Bag) },
                    onHqClick = { viewModel.navigateTo(Screen.ErewhonHQ) }
                )
            }
        },
        bottomBar = {
            if (currentScreen !is Screen.ErewhonHQ && currentScreen !is Screen.Checkout) {
                ErewhonBottomNavigationBar(
                    currentScreen = currentScreen,
                    onNavigate = { viewModel.navigateTo(it) }
                )
            }
        },
        containerColor = ErewhonWarmIvory
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Main Screen Content Router
            Crossfade(
                targetState = currentScreen,
                label = "screen_transition"
            ) { screen ->
                when (screen) {
                    is Screen.Home -> {
                        HomeScreen(
                            products = allProducts,
                            selectedStore = selectedStore,
                            onNavigateTo = { viewModel.navigateTo(it) },
                            onAddToCart = { viewModel.addToCart(it) },
                            onToggleFavourite = { viewModel.toggleFavourite(it) },
                            onSelectCollection = { viewModel.selectCollection(it) }
                        )
                    }

                    is Screen.Shop -> {
                        ShopScreen(
                            products = allProducts,
                            selectedCategory = selectedCategory,
                            selectedCollection = selectedCollection,
                            searchQuery = searchQuery,
                            onCategorySelect = { viewModel.selectCategory(it) },
                            onCollectionSelect = { viewModel.selectCollection(it) },
                            onSearchQueryChange = { viewModel.setSearchQuery(it) },
                            onProductClick = { viewModel.navigateTo(Screen.ProductDetail(it.id)) },
                            onAddToCart = { viewModel.addToCart(it) },
                            onToggleFavourite = { viewModel.toggleFavourite(it) }
                        )
                    }

                    is Screen.ProductDetail -> {
                        val product = allProducts.find { it.id == screen.productId }
                        ProductDetailScreen(
                            product = product,
                            selectedStore = selectedStore,
                            allStores = allStores,
                            onBackClick = { viewModel.navigateTo(Screen.Shop) },
                            onAddToCart = { viewModel.addToCart(it) },
                            onToggleFavourite = { viewModel.toggleFavourite(it) }
                        )
                    }

                    is Screen.Smoothies -> {
                        SmoothieBarScreen(
                            smoothies = smoothiesList,
                            selectedStore = selectedStore,
                            onAddToCart = { viewModel.addToCart(it) },
                            onSmoothieClick = { viewModel.navigateTo(Screen.ProductDetail(it.id)) }
                        )
                    }

                    is Screen.PreparedFoods -> {
                        PreparedFoodsScreen(
                            preparedItems = preparedList,
                            selectedStore = selectedStore,
                            onProductClick = { viewModel.navigateTo(Screen.ProductDetail(it.id)) },
                            onAddToCart = { viewModel.addToCart(it) },
                            onToggleFavourite = { viewModel.toggleFavourite(it) }
                        )
                    }

                    is Screen.Journal -> {
                        JournalScreen(
                            articles = articles,
                            selectedArticleId = null,
                            products = allProducts,
                            onSelectArticle = { id ->
                                if (id != null) viewModel.navigateTo(Screen.ArticleDetail(id))
                            },
                            onAddToCart = { viewModel.addToCart(it) },
                            onToggleFavourite = { viewModel.toggleFavourite(it) }
                        )
                    }

                    is Screen.ArticleDetail -> {
                        JournalScreen(
                            articles = articles,
                            selectedArticleId = screen.articleId,
                            products = allProducts,
                            onSelectArticle = { viewModel.navigateTo(Screen.Journal) },
                            onAddToCart = { viewModel.addToCart(it) },
                            onToggleFavourite = { viewModel.toggleFavourite(it) }
                        )
                    }

                    is Screen.Bag -> {
                        BagCheckoutScreen(
                            cartItems = cartItems,
                            selectedStore = selectedStore,
                            allStores = allStores,
                            onUpdateQuantity = { id, qty -> viewModel.updateCartQuantity(id, qty) },
                            onRemoveItem = { id -> viewModel.removeCartItem(id) },
                            onClearCart = { viewModel.clearCart() },
                            onSelectStore = { viewModel.selectStore(it) },
                            onPlaceOrder = { type, slot, payment ->
                                viewModel.placeOrder(type, slot, payment)
                            },
                            onContinueShopping = { viewModel.navigateTo(Screen.Shop) }
                        )
                    }

                    is Screen.Checkout -> {
                        BagCheckoutScreen(
                            cartItems = cartItems,
                            selectedStore = selectedStore,
                            allStores = allStores,
                            onUpdateQuantity = { id, qty -> viewModel.updateCartQuantity(id, qty) },
                            onRemoveItem = { id -> viewModel.removeCartItem(id) },
                            onClearCart = { viewModel.clearCart() },
                            onSelectStore = { viewModel.selectStore(it) },
                            onPlaceOrder = { type, slot, payment ->
                                viewModel.placeOrder(type, slot, payment)
                            },
                            onContinueShopping = { viewModel.navigateTo(Screen.Shop) }
                        )
                    }

                    is Screen.OrderTracking -> {
                        val activeOrder = orders.find { it.id == screen.orderId } ?: latestOrder
                        OrderTrackingScreen(
                            order = activeOrder,
                            onBackToHome = { viewModel.navigateTo(Screen.Home) }
                        )
                    }

                    is Screen.Stores -> {
                        StoreLocatorScreen(
                            stores = allStores,
                            selectedStore = selectedStore,
                            onSelectStore = { viewModel.selectStore(it) }
                        )
                    }

                    is Screen.Rewards -> {
                        RewardsScreen(
                            selectedStore = selectedStore,
                            orders = orders,
                            favourites = favourites,
                            onNavigateTo = { viewModel.navigateTo(it) }
                        )
                    }

                    is Screen.Favourites -> {
                        FavouritesScreen(
                            favouriteProducts = favouriteProducts,
                            onProductClick = { viewModel.navigateTo(Screen.ProductDetail(it.id)) },
                            onAddToCart = { viewModel.addToCart(it) },
                            onToggleFavourite = { viewModel.toggleFavourite(it) }
                        )
                    }

                    is Screen.ErewhonHQ -> {
                        ErewhonHqScreen(
                            orders = orders,
                            products = allProducts,
                            stores = allStores,
                            onUpdateOrderStatus = { id, status ->
                                viewModel.updateOrderStatusFromHq(id, status)
                            },
                            onUpdateStock = { storeId, prodId, qty ->
                                viewModel.updateHqInventory(storeId, prodId, qty)
                            },
                            onExitHq = { viewModel.navigateTo(Screen.Home) }
                        )
                    }
                }
            }

            // Floating Toast Banner
            AnimatedVisibility(
                visible = toastMessage != null,
                enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 16.dp, start = 16.dp, end = 16.dp)
            ) {
                toastMessage?.let { msg ->
                    Surface(
                        color = ErewhonCharcoal,
                        contentColor = ErewhonWarmIvory,
                        shape = RoundedCornerShape(2.dp),
                        tonalElevation = 6.dp,
                        modifier = Modifier
                            .border(0.5.dp, ErewhonAccentGold, RoundedCornerShape(2.dp))
                            .testTag("toast_notification_banner")
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "✧ ",
                                color = ErewhonAccentGold,
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Text(
                                text = msg,
                                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp),
                                color = ErewhonWarmIvory
                            )
                        }
                    }
                }
            }
        }
    }
}
