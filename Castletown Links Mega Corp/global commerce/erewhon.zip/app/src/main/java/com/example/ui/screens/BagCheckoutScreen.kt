package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CartItem
import com.example.data.model.Store
import com.example.ui.theme.*

@Composable
fun BagCheckoutScreen(
    cartItems: List<CartItem>,
    selectedStore: Store?,
    allStores: List<Store>,
    onUpdateQuantity: (Int, Int) -> Unit,
    onRemoveItem: (Int) -> Unit,
    onClearCart: () -> Unit,
    onSelectStore: (Store) -> Unit,
    onPlaceOrder: (String, String, String) -> Unit,
    onContinueShopping: () -> Unit
) {
    var orderType by remember { mutableStateOf("STORE_PICKUP") } // "STORE_PICKUP" or "DELIVERY"
    var pickupTimeSlot by remember { mutableStateOf("ASAP (15 mins)") }
    var paymentMethod by remember { mutableStateOf("Apple Pay") }

    val subtotal = remember(cartItems) { cartItems.sumOf { it.price * it.quantity } }
    val tax = remember(subtotal) { subtotal * 0.095 }
    val total = remember(subtotal, tax) { subtotal + tax }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ErewhonWarmIvory)
            .testTag("bag_checkout_screen")
    ) {
        // Top Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(ErewhonCharcoal)
                .padding(horizontal = 20.dp, vertical = 20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "YOUR BAG",
                        style = MaterialTheme.typography.titleLarge,
                        fontFamily = FontFamily.Serif,
                        color = ErewhonWarmIvory
                    )
                    Text(
                        text = "${cartItems.sumOf { it.quantity }} items",
                        style = MaterialTheme.typography.bodyMedium,
                        color = ErewhonWarmBeige
                    )
                }

                if (cartItems.isNotEmpty()) {
                    TextButton(onClick = onClearCart) {
                        Text("Clear Bag", style = MaterialTheme.typography.labelSmall, color = ErewhonAccentGold)
                    }
                }
            }
        }

        if (cartItems.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "YOUR BAG IS EMPTY",
                        style = MaterialTheme.typography.titleLarge,
                        fontFamily = FontFamily.Serif,
                        color = ErewhonCharcoal
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Explore smoothies, organic elixirs & prepared foods.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = ErewhonGrayText
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Button(
                        onClick = onContinueShopping,
                        colors = ButtonDefaults.buttonColors(containerColor = ErewhonCharcoal),
                        shape = RoundedCornerShape(2.dp),
                        modifier = Modifier.testTag("continue_shopping_button")
                    ) {
                        Text("SHOP EREWHON", style = MaterialTheme.typography.labelLarge)
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item { Spacer(modifier = Modifier.height(8.dp)) }

                // Cart Items List
                items(cartItems, key = { it.id }) { item ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = ErewhonCream),
                        shape = RoundedCornerShape(2.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(0.5.dp, ErewhonLightBorder, RoundedCornerShape(2.dp))
                            .testTag("cart_item_row_${item.id}")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.categoryMarker.uppercase(),
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                    color = ErewhonOlive
                                )
                                Text(
                                    text = item.productName,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = ErewhonCharcoal
                                )
                                Text(
                                    text = "$${String.format("%.2f", item.price)} each",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = ErewhonGrayText
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "$${String.format("%.2f", item.price * item.quantity)}",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontFamily = FontFamily.Serif,
                                    color = ErewhonCharcoal
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .background(ErewhonSoftWhite)
                                        .border(0.5.dp, ErewhonLightBorder, RoundedCornerShape(2.dp))
                                ) {
                                    IconButton(
                                        onClick = { onUpdateQuantity(item.id, item.quantity - 1) },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(Icons.Default.Remove, contentDescription = "Decrease", modifier = Modifier.size(14.dp))
                                    }

                                    Text(
                                        text = item.quantity.toString(),
                                        style = MaterialTheme.typography.labelSmall,
                                        modifier = Modifier.padding(horizontal = 8.dp)
                                    )

                                    IconButton(
                                        onClick = { onUpdateQuantity(item.id, item.quantity + 1) },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = "Increase", modifier = Modifier.size(14.dp))
                                    }
                                }
                            }
                        }
                    }
                }

                // Fulfillment Method: Pickup vs Delivery
                item {
                    Text(
                        text = "FULFILLMENT METHOD",
                        style = MaterialTheme.typography.labelSmall,
                        color = ErewhonCharcoal,
                        letterSpacing = 1.5.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OptionChip(
                            label = "STORE PICKUP",
                            isSelected = orderType == "STORE_PICKUP",
                            onClick = { orderType = "STORE_PICKUP" },
                            modifier = Modifier.weight(1f)
                        )
                        OptionChip(
                            label = "CURBSIDE DELIVERY",
                            isSelected = orderType == "DELIVERY",
                            onClick = { orderType = "DELIVERY" },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                }

                // Pickup Store Selection
                item {
                    Text(
                        text = "FULFILLMENT LOCATION",
                        style = MaterialTheme.typography.labelSmall,
                        color = ErewhonCharcoal,
                        letterSpacing = 1.5.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(ErewhonCream)
                            .border(0.5.dp, ErewhonLightBorder, RoundedCornerShape(2.dp))
                            .padding(14.dp)
                    ) {
                        Column {
                            Text(
                                text = selectedStore?.name ?: "Erewhon — Santa Monica",
                                style = MaterialTheme.typography.titleMedium,
                                color = ErewhonCharcoal
                            )
                            Text(
                                text = selectedStore?.address ?: "2800 Wilshire Blvd, Santa Monica",
                                style = MaterialTheme.typography.bodyMedium,
                                color = ErewhonGrayText
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                }

                // Time Slot Selection
                item {
                    Text(
                        text = "PICKUP TIME SLOT",
                        style = MaterialTheme.typography.labelSmall,
                        color = ErewhonCharcoal,
                        letterSpacing = 1.5.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    val timeSlots = listOf("ASAP (15 mins)", "Today at 2:30 PM", "Today at 3:15 PM", "Today at 4:00 PM")
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        timeSlots.take(2).forEach { slot ->
                            OptionChip(
                                label = slot,
                                isSelected = pickupTimeSlot == slot,
                                onClick = { pickupTimeSlot = slot },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                }

                // Payment Method
                item {
                    Text(
                        text = "PAYMENT METHOD",
                        style = MaterialTheme.typography.labelSmall,
                        color = ErewhonCharcoal,
                        letterSpacing = 1.5.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    val methods = listOf("Apple Pay", "Credit Card", "Google Pay")
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        methods.forEach { method ->
                            OptionChip(
                                label = method,
                                isSelected = paymentMethod == method,
                                onClick = { paymentMethod = method },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))
                }

                // Order Summary Card
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = ErewhonSoftWhite),
                        shape = RoundedCornerShape(2.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(0.5.dp, ErewhonLightBorder, RoundedCornerShape(2.dp))
                            .padding(16.dp)
                    ) {
                        Column {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Subtotal", style = MaterialTheme.typography.bodyMedium)
                                Text("$${String.format("%.2f", subtotal)}", style = MaterialTheme.typography.bodyMedium)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Estimated Tax (9.5%)", style = MaterialTheme.typography.bodyMedium)
                                Text("$${String.format("%.2f", tax)}", style = MaterialTheme.typography.bodyMedium)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Fulfillment Fee", style = MaterialTheme.typography.bodyMedium)
                                Text("COMPLIMENTARY", style = MaterialTheme.typography.labelSmall, color = ErewhonMutedGreen)
                            }

                            HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = ErewhonLightBorder)

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Total", style = MaterialTheme.typography.titleLarge, fontFamily = FontFamily.Serif)
                                Text("$${String.format("%.2f", total)}", style = MaterialTheme.typography.titleLarge, fontFamily = FontFamily.Serif)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))
                }
            }

            // Bottom Sticky Checkout Bar
            Surface(
                color = ErewhonWarmIvory,
                tonalElevation = 8.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Button(
                    onClick = {
                        onPlaceOrder(orderType, pickupTimeSlot, paymentMethod)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ErewhonCharcoal, contentColor = ErewhonWarmIvory),
                    shape = RoundedCornerShape(2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .height(50.dp)
                        .testTag("place_order_button")
                ) {
                    Text(
                        text = "PLACE ORDER — $${String.format("%.2f", total)}",
                        style = MaterialTheme.typography.labelLarge,
                        letterSpacing = 2.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun OptionChip(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(2.dp))
            .background(if (isSelected) ErewhonCharcoal else ErewhonCream)
            .border(0.5.dp, if (isSelected) ErewhonCharcoal else ErewhonLightBorder, RoundedCornerShape(2.dp))
            .clickable { onClick() }
            .padding(vertical = 10.dp, horizontal = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
            color = if (isSelected) ErewhonWarmIvory else ErewhonCharcoal,
            letterSpacing = 1.sp
        )
    }
}
