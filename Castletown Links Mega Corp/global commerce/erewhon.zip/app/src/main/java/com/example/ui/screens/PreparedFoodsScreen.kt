package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Product
import com.example.data.model.Store
import com.example.ui.components.ProductCard
import com.example.ui.theme.*

@Composable
fun PreparedFoodsScreen(
    preparedItems: List<Product>,
    selectedStore: Store?,
    onProductClick: (Product) -> Unit,
    onAddToCart: (Product) -> Unit,
    onToggleFavourite: (Product) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ErewhonWarmIvory)
            .testTag("prepared_foods_screen")
    ) {
        // Banner Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(ErewhonCream)
                .border(0.5.dp, ErewhonLightBorder)
                .padding(20.dp)
        ) {
            Column {
                Text(
                    text = "EREWHON KITCHEN & BAKERY",
                    style = MaterialTheme.typography.labelSmall,
                    color = ErewhonOlive,
                    letterSpacing = 2.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "PREPARED FOODS & HOT BAR",
                    style = MaterialTheme.typography.displayMedium,
                    fontFamily = FontFamily.Serif,
                    color = ErewhonCharcoal
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Made fresh daily at ${selectedStore?.name ?: "Santa Monica"} Kitchen.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = ErewhonGrayText
                )
            }
        }

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(preparedItems) { item ->
                ProductCard(
                    product = item,
                    onProductClick = { onProductClick(item) },
                    onAddToCart = onAddToCart,
                    onToggleFavourite = onToggleFavourite,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}
