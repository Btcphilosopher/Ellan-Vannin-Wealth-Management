package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.LocalDrink
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Order
import com.example.data.model.OrderStatus
import com.example.ui.theme.*

@Composable
fun OrderTrackingScreen(
    order: Order?,
    onBackToHome: () -> Unit
) {
    if (order == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No order found", style = MaterialTheme.typography.bodyLarge)
        }
        return
    }

    val currentStatusIndex = when (order.status) {
        OrderStatus.CONFIRMED.name -> 1
        OrderStatus.PREPARING.name -> 2
        OrderStatus.READY.name -> 3
        OrderStatus.COLLECTED.name, OrderStatus.OUT_FOR_DELIVERY.name -> 4
        else -> 1
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ErewhonWarmIvory)
            .testTag("order_tracking_screen")
    ) {
        // Header Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(ErewhonCharcoal)
                .padding(24.dp)
        ) {
            Column {
                Text(
                    text = "LIVE ORDER TRACKING",
                    style = MaterialTheme.typography.labelSmall,
                    color = ErewhonAccentGold,
                    letterSpacing = 2.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "ORDER #${order.id}",
                    style = MaterialTheme.typography.displayMedium,
                    fontFamily = FontFamily.Serif,
                    color = ErewhonWarmIvory
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Fulfillment at ${order.storeName} • ${order.pickupTimeSlot}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = ErewhonWarmBeige
                )
            }
        }

        LazyColumn(
            contentPadding = PaddingValues(20.dp),
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Timeline Status Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = ErewhonCream),
                    shape = RoundedCornerShape(2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(0.5.dp, ErewhonLightBorder, RoundedCornerShape(2.dp))
                        .padding(20.dp)
                ) {
                    Column {
                        Text(
                            text = "FULFILLMENT STATUS",
                            style = MaterialTheme.typography.labelSmall,
                            color = ErewhonOlive,
                            letterSpacing = 1.5.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))

                        TimelineStep(stepNumber = 1, title = "ORDER CONFIRMED", subtitle = "Received by Erewhon Kitchen", isCompleted = currentStatusIndex >= 1, isCurrent = currentStatusIndex == 1)
                        Spacer(modifier = Modifier.height(12.dp))
                        TimelineStep(stepNumber = 2, title = "PREPARING IN KITCHEN", subtitle = "Hand-crafted by Tonic Bar Artisans", isCompleted = currentStatusIndex >= 2, isCurrent = currentStatusIndex == 2)
                        Spacer(modifier = Modifier.height(12.dp))
                        TimelineStep(stepNumber = 3, title = "READY FOR PICKUP", subtitle = "Ready at Pick-Up Counter", isCompleted = currentStatusIndex >= 3, isCurrent = currentStatusIndex == 3)
                        Spacer(modifier = Modifier.height(12.dp))
                        TimelineStep(stepNumber = 4, title = "COLLECTED / DELIVERED", subtitle = "Enjoy your Erewhon items", isCompleted = currentStatusIndex >= 4, isCurrent = currentStatusIndex == 4)
                    }
                }
            }

            // Items Summary
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = ErewhonSoftWhite),
                    shape = RoundedCornerShape(2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(0.5.dp, ErewhonLightBorder, RoundedCornerShape(2.dp))
                        .padding(16.dp)
                ) {
                    Column {
                        Text(
                            text = "ORDER DETAILS",
                            style = MaterialTheme.typography.labelSmall,
                            color = ErewhonCharcoal,
                            letterSpacing = 1.5.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = order.itemsJson,
                            style = MaterialTheme.typography.bodyLarge,
                            color = ErewhonCharcoal,
                            lineHeight = 22.sp
                        )

                        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = ErewhonLightBorder)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Total Paid", style = MaterialTheme.typography.titleMedium, fontFamily = FontFamily.Serif)
                            Text("$${String.format("%.2f", order.total)}", style = MaterialTheme.typography.titleMedium, fontFamily = FontFamily.Serif)
                        }
                    }
                }
            }

            item {
                Button(
                    onClick = onBackToHome,
                    colors = ButtonDefaults.buttonColors(containerColor = ErewhonCharcoal),
                    shape = RoundedCornerShape(2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("back_to_home_button")
                ) {
                    Text("BACK TO HOME", style = MaterialTheme.typography.labelLarge, letterSpacing = 2.sp)
                }
            }
        }
    }
}

@Composable
private fun TimelineStep(
    stepNumber: Int,
    title: String,
    subtitle: String,
    isCompleted: Boolean,
    isCurrent: Boolean
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(
            modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(if (isCompleted) ErewhonMutedGreen else if (isCurrent) ErewhonCharcoal else ErewhonLightBorder),
            contentAlignment = Alignment.Center
        ) {
            if (isCompleted) {
                Icon(Icons.Default.Check, contentDescription = "Completed", tint = ErewhonWarmIvory, modifier = Modifier.size(16.dp))
            } else {
                Text(stepNumber.toString(), style = MaterialTheme.typography.labelSmall, color = ErewhonWarmIvory)
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium.copy(fontSize = 13.sp),
                color = if (isCompleted || isCurrent) ErewhonCharcoal else ErewhonGrayText
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp),
                color = ErewhonGrayText
            )
        }
    }
}
