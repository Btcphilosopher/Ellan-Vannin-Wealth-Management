package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Product
import com.example.data.model.Store
import com.example.ui.components.ProductCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.Screen

@Composable
fun HomeScreen(
    products: List<Product>,
    selectedStore: Store?,
    onNavigateTo: (Screen) -> Unit,
    onAddToCart: (Product) -> Unit,
    onToggleFavourite: (Product) -> Unit,
    onSelectCollection: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ErewhonWarmIvory)
            .testTag("home_screen_list")
    ) {
        // Section 1: Hero Magazine Front Page
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ErewhonCharcoal)
                    .padding(horizontal = 24.dp, vertical = 40.dp)
            ) {
                Column(
                    horizontalAlignment = Alignment.Start,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "ORGANIC • WELLNESS • GROCERY",
                        style = MaterialTheme.typography.labelSmall,
                        color = ErewhonAccentGold,
                        letterSpacing = 3.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "LIVE WELL.\nEAT BEAUTIFULLY.",
                        style = MaterialTheme.typography.displayLarge,
                        fontFamily = FontFamily.Serif,
                        color = ErewhonWarmIvory,
                        lineHeight = 44.sp
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "California's benchmark for uncompromised organic standards and high-vibration living.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = ErewhonWarmBeige,
                        modifier = Modifier.fillMaxWidth(0.9f)
                    )
                    Spacer(modifier = Modifier.height(28.dp))

                    Button(
                        onClick = { onNavigateTo(Screen.Shop) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ErewhonWarmIvory,
                            contentColor = ErewhonCharcoal
                        ),
                        shape = RoundedCornerShape(2.dp),
                        contentPadding = PaddingValues(horizontal = 24.dp, vertical = 14.dp),
                        modifier = Modifier.testTag("explore_collection_button")
                    ) {
                        Text(
                            text = "EXPLORE EREWHON WORLD",
                            style = MaterialTheme.typography.labelLarge,
                            letterSpacing = 2.sp
                        )
                    }
                }
            }
        }

        // Section 2: Editorial Hero Panel
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = ErewhonCream),
                shape = RoundedCornerShape(0.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .border(0.5.dp, ErewhonLightBorder, RoundedCornerShape(2.dp))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp)
                ) {
                    Text(
                        text = "NEW AT EREWHON",
                        style = MaterialTheme.typography.labelSmall,
                        color = ErewhonOlive,
                        letterSpacing = 2.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "SUMMER ESSENTIALS & SKIN SMOOTHIES",
                        style = MaterialTheme.typography.displayMedium,
                        fontFamily = FontFamily.Serif,
                        color = ErewhonCharcoal
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Featuring Hailey Bieber's Strawberry Glaze Skin Smoothie, raw wildflower honey, and wildcrafted sea moss.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = ErewhonGrayText
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedButton(
                        onClick = {
                            onSelectCollection("SUMMER ESSENTIALS")
                            onNavigateTo(Screen.Shop)
                        },
                        shape = RoundedCornerShape(2.dp),
                        border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(ErewhonCharcoal)),
                        modifier = Modifier.testTag("shop_seasonal_collection")
                    ) {
                        Text(
                            text = "SHOP SEASONAL COLLECTION",
                            style = MaterialTheme.typography.labelLarge,
                            color = ErewhonCharcoal,
                            letterSpacing = 1.5.sp
                        )
                    }
                }
            }
        }

        // Section 3: Elegant Category Navigation Grid
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 16.dp)
            ) {
                Text(
                    text = "CATEGORIES",
                    style = MaterialTheme.typography.labelLarge,
                    color = ErewhonCharcoal,
                    letterSpacing = 2.sp
                )
                Spacer(modifier = Modifier.height(12.dp))

                val categories = listOf(
                    "SMOOTHIES" to Screen.Smoothies,
                    "PREPARED FOODS" to Screen.PreparedFoods,
                    "ORGANIC GROCERY" to Screen.Shop,
                    "SUPPLEMENTS" to Screen.Shop,
                    "BEAUTY" to Screen.Shop,
                    "PANTRY" to Screen.Shop
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    categories.take(3).forEach { (catName, targetScreen) ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(ErewhonSoftWhite)
                                .border(0.5.dp, ErewhonLightBorder, RoundedCornerShape(2.dp))
                                .clickable { onNavigateTo(targetScreen) },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = catName,
                                style = MaterialTheme.typography.labelSmall,
                                color = ErewhonCharcoal,
                                letterSpacing = 1.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    categories.drop(3).forEach { (catName, targetScreen) ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(ErewhonSoftWhite)
                                .border(0.5.dp, ErewhonLightBorder, RoundedCornerShape(2.dp))
                                .clickable { onNavigateTo(targetScreen) },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = catName,
                                style = MaterialTheme.typography.labelSmall,
                                color = ErewhonCharcoal,
                                letterSpacing = 1.sp
                            )
                        }
                    }
                }
            }
        }

        // Section 4: Erewhon Favourites Carousel
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "EREWHON FAVOURITES",
                        style = MaterialTheme.typography.labelLarge,
                        color = ErewhonCharcoal,
                        letterSpacing = 2.sp
                    )

                    Text(
                        text = "VIEW ALL",
                        style = MaterialTheme.typography.labelSmall,
                        color = ErewhonOlive,
                        modifier = Modifier
                            .clickable { onNavigateTo(Screen.Shop) }
                            .padding(4.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(products.take(5)) { product ->
                        ProductCard(
                            product = product,
                            onProductClick = { onNavigateTo(Screen.ProductDetail(product.id)) },
                            onAddToCart = onAddToCart,
                            onToggleFavourite = onToggleFavourite,
                            modifier = Modifier.width(220.dp)
                        )
                    }
                }
            }
        }

        // Section 5: Journal / Shop the Story Teaser
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = ErewhonCharcoal),
                shape = RoundedCornerShape(0.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp)
                    .clickable { onNavigateTo(Screen.Journal) }
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp)
                ) {
                    Text(
                        text = "JOURNAL",
                        style = MaterialTheme.typography.labelSmall,
                        color = ErewhonAccentGold,
                        letterSpacing = 2.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "THE CALIFORNIA PANTRY: ANCESTRAL OILS & ELIXIRS",
                        style = MaterialTheme.typography.titleLarge,
                        fontFamily = FontFamily.Serif,
                        color = ErewhonWarmIvory
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "A deep dive into cold-extracted Sicilian olive oils and first-harvest Uji Japanese matcha.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = ErewhonWarmBeige
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "READ & SHOP THE STORY",
                            style = MaterialTheme.typography.labelLarge,
                            color = ErewhonWarmIvory,
                            letterSpacing = 1.5.sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = Icons.Default.ArrowForward,
                            contentDescription = "Read story",
                            tint = ErewhonWarmIvory,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }

        // Section 6: Selected Store Locator Banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .background(ErewhonCream)
                    .border(0.5.dp, ErewhonLightBorder, RoundedCornerShape(2.dp))
                    .padding(20.dp)
            ) {
                Column {
                    Text(
                        text = "YOUR PREFERRED STORE",
                        style = MaterialTheme.typography.labelSmall,
                        color = ErewhonOlive,
                        letterSpacing = 1.5.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = selectedStore?.name ?: "Erewhon — Santa Monica",
                        style = MaterialTheme.typography.titleLarge,
                        fontFamily = FontFamily.Serif,
                        color = ErewhonCharcoal
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${selectedStore?.address ?: "2800 Wilshire Blvd"} • Open Today ${selectedStore?.hours ?: "7 AM - 10 PM"}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = ErewhonGrayText
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedButton(
                        onClick = { onNavigateTo(Screen.Stores) },
                        shape = RoundedCornerShape(2.dp),
                        modifier = Modifier.testTag("change_preferred_store_button")
                    ) {
                        Text(
                            text = "VIEW STORE INVENTORY & LOCATIONS",
                            style = MaterialTheme.typography.labelSmall,
                            color = ErewhonCharcoal
                        )
                    }
                }
            }
        }
    }
}
