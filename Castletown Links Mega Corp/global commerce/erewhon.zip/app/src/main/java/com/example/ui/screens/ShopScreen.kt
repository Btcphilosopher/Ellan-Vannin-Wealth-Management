package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Product
import com.example.ui.components.ProductCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.Screen

@Composable
fun ShopScreen(
    products: List<Product>,
    selectedCategory: String,
    selectedCollection: String?,
    searchQuery: String,
    onCategorySelect: (String) -> Unit,
    onCollectionSelect: (String) -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onProductClick: (Product) -> Unit,
    onAddToCart: (Product) -> Unit,
    onToggleFavourite: (Product) -> Unit
) {
    val filteredProducts = remember(products, selectedCategory, selectedCollection, searchQuery) {
        products.filter { p ->
            val matchesCategory = if (selectedCategory == "ALL") true else p.category.lowercase().contains(selectedCategory.lowercase())
            val matchesCollection = if (selectedCollection == null) true else p.collectionName?.equals(selectedCollection, ignoreCase = true) == true
            val matchesSearch = if (searchQuery.isBlank()) true else p.name.contains(searchQuery, ignoreCase = true) || p.shortDescription.contains(searchQuery, ignoreCase = true) || p.ingredients.contains(searchQuery, ignoreCase = true)
            matchesCategory && matchesCollection && matchesSearch
        }
    }

    val categories = listOf("ALL", "Smoothies & Tonics", "Prepared Foods", "Organic Grocery", "Foundational Supplements", "Clean Beauty", "The Pantry Edit")
    val collections = listOf("SUMMER ESSENTIALS", "THE MORNING EDIT", "POST-WORKOUT", "THE PANTRY EDIT", "BEAUTY & WELLNESS", "HIGH-PROTEIN")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ErewhonWarmIvory)
            .testTag("shop_screen_container")
    ) {
        // Header Title
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Text(
                text = if (selectedCollection != null) selectedCollection.uppercase() else "SHOP EREWHON",
                style = MaterialTheme.typography.displayMedium,
                fontFamily = FontFamily.Serif,
                color = ErewhonCharcoal
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "${filteredProducts.size} Items Available",
                style = MaterialTheme.typography.bodyMedium,
                color = ErewhonGrayText
            )
        }

        // Search Bar Input
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchQueryChange,
            placeholder = { Text("Search products, sea moss, matcha, protein...", style = MaterialTheme.typography.bodyMedium, color = ErewhonGrayText) },
            leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = "Search icon", tint = ErewhonGrayText) },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = ErewhonCharcoal,
                unfocusedBorderColor = ErewhonLightBorder,
                focusedContainerColor = ErewhonSoftWhite,
                unfocusedContainerColor = ErewhonSoftWhite
            ),
            shape = RoundedCornerShape(2.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp)
                .testTag("shop_search_input")
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Categories Chips Row
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(categories) { cat ->
                val isSelected = (selectedCategory == cat) && (selectedCollection == null)
                Box(
                    modifier = Modifier
                        .testTag("category_chip_$cat")
                        .clip(RoundedCornerShape(2.dp))
                        .background(if (isSelected) ErewhonCharcoal else ErewhonCream)
                        .border(0.5.dp, ErewhonLightBorder, RoundedCornerShape(2.dp))
                        .clickable { onCategorySelect(cat) }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = cat.uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isSelected) ErewhonWarmIvory else ErewhonCharcoal,
                        letterSpacing = 1.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Collections Chips Row
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(collections) { col ->
                val isSelected = selectedCollection == col
                Box(
                    modifier = Modifier
                        .testTag("collection_chip_$col")
                        .clip(RoundedCornerShape(2.dp))
                        .background(if (isSelected) ErewhonMutedGreen else ErewhonSoftWhite)
                        .border(0.5.dp, if (isSelected) ErewhonMutedGreen else ErewhonLightBorder, RoundedCornerShape(2.dp))
                        .clickable { onCollectionSelect(col) }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "✧ $col",
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                        color = if (isSelected) ErewhonWarmIvory else ErewhonCharcoal,
                        letterSpacing = 1.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Product Grid
        if (filteredProducts.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No products found matching your search.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = ErewhonGrayText
                )
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredProducts, key = { it.id }) { product ->
                    ProductCard(
                        product = product,
                        onProductClick = { onProductClick(product) },
                        onAddToCart = onAddToCart,
                        onToggleFavourite = onToggleFavourite
                    )
                }
            }
        }
    }
}
