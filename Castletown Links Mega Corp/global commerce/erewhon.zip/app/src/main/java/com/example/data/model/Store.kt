package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "stores")
data class Store(
    @PrimaryKey val id: String,
    val name: String,
    val address: String,
    val city: String,
    val zipCode: String,
    val hours: String,
    val phone: String,
    val distanceMiles: Double,
    val services: String, // Comma separated services
    val isOpenNow: Boolean = true,
    val imageUrl: String = ""
)

@Entity(tableName = "store_inventory", primaryKeys = ["storeId", "productId"])
data class StoreInventory(
    val storeId: String,
    val productId: String,
    val onHandQuantity: Int,
    val reservedQuantity: Int = 0,
    val status: String // IN_STOCK, LOW_STOCK, OUT_OF_STOCK
)
