package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "editorial_articles")
data class EditorialArticle(
    @PrimaryKey val id: String,
    val title: String,
    val subtitle: String,
    val category: String, // "JOURNAL", "MEET THE MAKER", "EDUCATION", "WELLNESS", "RECIPES"
    val author: String,
    val dateText: String,
    val heroImageUrl: String,
    val leadParagraph: String,
    val bodyText: String,
    val relatedProductIds: String, // Comma separated IDs
    val relatedCollectionName: String? = null
)

@Entity(tableName = "favourites")
data class FavouriteItem(
    @PrimaryKey val id: String, // productId, storeId, or articleId
    val type: String, // "PRODUCT", "SMOOTHIE", "STORE", "ARTICLE"
    val title: String,
    val subtitle: String,
    val imageUrl: String
)
