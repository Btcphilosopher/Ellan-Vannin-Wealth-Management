package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.LocalDrink
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Product
import com.example.data.model.Store
import com.example.ui.theme.*

@Composable
fun SmoothieBarScreen(
    smoothies: List<Product>,
    selectedStore: Store?,
    onAddToCart: (Product) -> Unit,
    onSmoothieClick: (Product) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ErewhonWarmIvory)
            .testTag("smoothie_bar_screen")
    ) {
        // Hero Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(ErewhonCharcoal)
                .padding(horizontal = 20.dp, vertical = 28.dp)
        ) {
            Column {
                Text(
                    text = "EREWHON TONIC & SMOOTHIE BAR",
                    style = MaterialTheme.typography.labelSmall,
                    color = ErewhonAccentGold,
                    letterSpacing = 2.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "WORLD FAMOUS SMOOTHIES & ELIXIRS",
                    style = MaterialTheme.typography.displayMedium,
                    fontFamily = FontFamily.Serif,
                    color = ErewhonWarmIvory
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Freshly blended at ${selectedStore?.name ?: "Santa Monica"} Tonic Bar.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = ErewhonWarmBeige
                )
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(smoothies) { smoothie ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = ErewhonCream),
                    shape = RoundedCornerShape(2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(0.5.dp, ErewhonLightBorder, RoundedCornerShape(2.dp))
                        .clickable { onSmoothieClick(smoothie) }
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = smoothie.brand.uppercase(),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ErewhonOlive,
                                    letterSpacing = 1.sp
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = smoothie.name,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontFamily = FontFamily.Serif,
                                    color = ErewhonCharcoal
                                )
                            }

                            Text(
                                text = "$${String.format("%.2f", smoothie.price)}",
                                style = MaterialTheme.typography.titleLarge,
                                fontFamily = FontFamily.Serif,
                                color = ErewhonCharcoal,
                                modifier = Modifier.padding(start = 12.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = smoothie.shortDescription,
                            style = MaterialTheme.typography.bodyMedium,
                            color = ErewhonGrayText
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Ingredients chips preview
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "STORE PICKUP: AVAILABLE NOW",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                color = ErewhonMutedGreen,
                                letterSpacing = 1.sp
                            )

                            Button(
                                onClick = { onAddToCart(smoothie) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = ErewhonCharcoal,
                                    contentColor = ErewhonWarmIvory
                                ),
                                shape = RoundedCornerShape(2.dp),
                                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                                modifier = Modifier
                                    .height(36.dp)
                                    .testTag("add_smoothie_button_${smoothie.id}")
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = "Add",
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "ORDER SMOOTHIE",
                                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                        letterSpacing = 1.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
