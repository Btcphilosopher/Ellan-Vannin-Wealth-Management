package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ErewhonWarmIvory = Color(0xFFFDFBF7)
val ErewhonCream = Color(0xFFF6F3EC)
val ErewhonSoftWhite = Color(0xFFFFFFFF)
val ErewhonCharcoal = Color(0xFF1F2022)
val ErewhonBlack = Color(0xFF0F0F0F)
val ErewhonMutedGreen = Color(0xFF3E4E3A)
val ErewhonOlive = Color(0xFF556046)
val ErewhonEarthBrown = Color(0xFF4A3E38)
val ErewhonWarmBeige = Color(0xFFEBE6DD)
val ErewhonAccentGold = Color(0xFFC5A059)
val ErewhonGrayText = Color(0xFF6E7175)
val ErewhonLightBorder = Color(0xFFE0D8CB)
