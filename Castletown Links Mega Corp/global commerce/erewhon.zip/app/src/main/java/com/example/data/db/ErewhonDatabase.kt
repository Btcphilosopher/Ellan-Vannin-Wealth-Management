package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.*

@Database(
    entities = [
        Product::class,
        Store::class,
        StoreInventory::class,
        CartItem::class,
        Order::class,
        EditorialArticle::class,
        FavouriteItem::class
    ],
    version = 1,
    exportSchema = false
)
abstract class ErewhonDatabase : RoomDatabase() {
    abstract fun productDao(): ProductDao
    abstract fun storeDao(): StoreDao
    abstract fun cartDao(): CartDao
    abstract fun orderDao(): OrderDao
    abstract fun editorialDao(): EditorialDao
    abstract fun favouriteDao(): FavouriteDao

    companion object {
        @Volatile
        private var INSTANCE: ErewhonDatabase? = null

        fun getDatabase(context: Context): ErewhonDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ErewhonDatabase::class.java,
                    "erewhon_db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
