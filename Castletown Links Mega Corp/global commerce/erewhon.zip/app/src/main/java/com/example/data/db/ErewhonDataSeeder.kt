package com.example.data.db

import com.example.data.model.*

object ErewhonDataSeeder {

    val stores = listOf(
        Store(
            id = "store_sm",
            name = "Erewhon — Santa Monica",
            address = "2800 Wilshire Blvd",
            city = "Santa Monica",
            zipCode = "90403",
            hours = "7:00 AM – 10:00 PM",
            phone = "(310) 310-8555",
            distanceMiles = 1.2,
            services = "Smoothie Bar, Tonic Bar, Hot Food, Organic Produce, Wellness Consultation, Valet Parking",
            isOpenNow = true
        ),
        Store(
            id = "store_bh",
            name = "Erewhon — Beverly Hills",
            address = "438 N Canon Dr",
            city = "Beverly Hills",
            zipCode = "90210",
            hours = "7:00 AM – 10:00 PM",
            phone = "(310) 247-0500",
            distanceMiles = 4.8,
            services = "Smoothie Bar, Tonic Bar, Pizza Oven, Organic Produce, Valet Parking",
            isOpenNow = true
        ),
        Store(
            id = "store_venice",
            name = "Erewhon — Venice",
            address = "585 Venice Blvd",
            city = "Venice",
            zipCode = "90291",
            hours = "7:00 AM – 9:00 PM",
            phone = "(310) 370-7500",
            distanceMiles = 3.5,
            services = "Smoothie Bar, Tonic Bar, Hot Food, Espresso Bar, Outdoor Patio",
            isOpenNow = true
        ),
        Store(
            id = "store_calabasas",
            name = "Erewhon — Calabasas",
            address = "26767 Agoura Rd",
            city = "Calabasas",
            zipCode = "91302",
            hours = "7:00 AM – 9:00 PM",
            phone = "(818) 857-3300",
            distanceMiles = 18.4,
            services = "Smoothie Bar, Organic Cafe, Juice Bar, Produce, Wellness Consultation",
            isOpenNow = true
        ),
        Store(
            id = "store_palisades",
            name = "Erewhon — Pacific Palisades",
            address = "15285 Sunset Blvd",
            city = "Pacific Palisades",
            zipCode = "90272",
            hours = "7:00 AM – 9:00 PM",
            phone = "(310) 561-8888",
            distanceMiles = 6.1,
            services = "Smoothie Bar, Cafe & Kitchen, Bakery, Produce",
            isOpenNow = true
        ),
        Store(
            id = "store_silverlake",
            name = "Erewhon — Silver Lake",
            address = "4121 Santa Monica Blvd",
            city = "Los Angeles",
            zipCode = "90029",
            hours = "7:00 AM – 10:00 PM",
            phone = "(323) 667-0500",
            distanceMiles = 11.3,
            services = "Smoothie Bar, Prepared Foods, Organic Produce, Coffee Bar",
            isOpenNow = true
        )
    )

    val products = listOf(
        // SMOOTHIES
        Product(
            id = "sm_01",
            name = "Hailey Bieber's Strawberry Glaze Skin Smoothie",
            brand = "Erewhon x Hailey Bieber",
            category = ProductCategory.SMOOTHIES.displayName,
            price = 19.00,
            shortDescription = "Organic almond milk, strawberries, avocado, hyaluronic acid, sea moss & coconut whip.",
            fullDescription = "Formulated with organic strawberries, Malk organic almond milk, Neocell hyaluronic acid, Zuma Valley organic coconut cream, and wildcrafted Irish sea moss gel. Created for a radiant glow.",
            imageUrl = "https://images.unsplash.com/photo-1553530666-ba11a7da3888?auto=format&fit=crop&w=800&q=80",
            categoryMarker = "SIGNATURE SMOOTHIE",
            ingredients = "Organic Strawberries, Organic Malk Almond Milk, Hyaluronic Acid, Wildcrafted Irish Sea Moss, Organic Avocado, Maple Syrup, Organic Coconut Whip, Collagen Peptides.",
            calories = 380,
            proteinGrams = 12,
            carbsGrams = 42,
            fatGrams = 18,
            isOrganic = true,
            isGlutenFree = true,
            isNoAddedSugar = true,
            collectionName = "SUMMER ESSENTIALS",
            productStory = "The world-famous viral smoothie designed to promote skin hydration and cellular radiance."
        ),
        Product(
            id = "sm_02",
            name = "Coconut Cloud Smoothie",
            brand = "Erewhon Organic",
            category = ProductCategory.SMOOTHIES.displayName,
            price = 18.00,
            shortDescription = "Blue spirulina, organic coconut cream, almond butter, vanilla bean & sea moss.",
            fullDescription = "An ethereal blue blend featuring nutrient-dense organic blue spirulina, raw almond butter, fresh avocado, organic coconut cream cloud, and Ceylon vanilla bean.",
            imageUrl = "https://images.unsplash.com/photo-1577805947697-89e18249d767?auto=format&fit=crop&w=800&q=80",
            categoryMarker = "WELLNESS SMOOTHIE",
            ingredients = "Organic Coconut Milk, Organic Blue Spirulina, Raw Almond Butter, Organic Avocado, Wildcrafted Sea Moss, Organic Vanilla Bean, Stevia.",
            calories = 420,
            proteinGrams = 14,
            carbsGrams = 28,
            fatGrams = 28,
            isOrganic = true,
            isKeto = true,
            isGlutenFree = true,
            isVegan = true,
            collectionName = "BEAUTY & WELLNESS"
        ),
        Product(
            id = "sm_03",
            name = "Japanese Matcha Cloud Smoothie",
            brand = "Erewhon Organic",
            category = ProductCategory.SMOOTHIES.displayName,
            price = 19.50,
            shortDescription = "Uji ceremonial matcha, oat milk, lion's mane, vanilla bean cloud whip.",
            fullDescription = "First-harvest ceremonial grade Japanese matcha layered with organic oat milk, adaptogenic lion's mane mushroom extract, and Madagascar vanilla whip.",
            imageUrl = "https://images.unsplash.com/photo-1536256263959-770b48d82b0a?auto=format&fit=crop&w=800&q=80",
            categoryMarker = "ADAPTOGENIC",
            ingredients = "First Harvest Organic Uji Matcha, Organic Oat Milk, Organic Lion's Mane Extract, Organic Vanilla Bean, Organic Coconut Cream, Monk Fruit.",
            calories = 310,
            proteinGrams = 8,
            carbsGrams = 34,
            fatGrams = 14,
            isOrganic = true,
            isVegan = true,
            isGlutenFree = true,
            collectionName = "THE MORNING EDIT"
        ),
        Product(
            id = "sm_04",
            name = "Sea Moss Detox Elixir",
            brand = "Erewhon Elixirs",
            category = ProductCategory.SMOOTHIES.displayName,
            price = 17.50,
            shortDescription = "Wildcrafted Irish sea moss, organic pineapple, dandelion root & ginger.",
            fullDescription = "Rich in 92 essential trace minerals. Formulated with wildcrafted St. Lucia Irish sea moss, cold-pressed pineapple, dandelion digestive bitter, and Hawaiian ginger root.",
            imageUrl = "https://images.unsplash.com/photo-1622597467836-f3285f2131b7?auto=format&fit=crop&w=800&q=80",
            categoryMarker = "MINERAL TONIC",
            ingredients = "Wildcrafted St. Lucia Sea Moss Gel, Organic Pineapple Juice, Organic Dandelion Root Extract, Cold-Pressed Ginger, Alkaline Water.",
            calories = 140,
            proteinGrams = 4,
            carbsGrams = 30,
            fatGrams = 1,
            isOrganic = true,
            isVegan = true,
            isGlutenFree = true,
            collectionName = "POST-WORKOUT"
        ),

        // PREPARED FOODS
        Product(
            id = "pf_01",
            name = "Erewhon Organic Buffalo Cauliflower",
            brand = "Erewhon Kitchen",
            category = ProductCategory.PREPARED_FOODS.displayName,
            price = 16.00,
            shortDescription = "Almond flour crusted cauliflower in house cayenne glaze with vegan ranch.",
            fullDescription = "Organic cauliflower florets lightly coated in sprouted almond flour, baked to golden perfection, and tossed in house fermented cayenne buffalo sauce.",
            imageUrl = "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=800&q=80",
            categoryMarker = "HOT BAR FAVORITE",
            ingredients = "Organic Cauliflower, Sprouted Almond Flour, Organic Cayenne Glaze, Avocado Oil, House Vegan Cashew Ranch.",
            calories = 320,
            proteinGrams = 9,
            carbsGrams = 22,
            fatGrams = 22,
            isOrganic = true,
            isVegan = true,
            isGlutenFree = true,
            collectionName = "CALIFORNIA KITCHEN"
        ),
        Product(
            id = "pf_02",
            name = "Wild King Salmon Poke Bowl",
            brand = "Erewhon Kitchen",
            category = ProductCategory.PREPARED_FOODS.displayName,
            price = 26.00,
            shortDescription = "Sustainably caught wild salmon, kelp noodles, avocado & tamari ponzu.",
            fullDescription = "Fresh wild Pacific king salmon diced over mineral-rich kelp noodles, organic Hass avocado, cucumber, pickled daikon radish, and house toasted sesame tamari.",
            imageUrl = "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80",
            categoryMarker = "RAW BAR",
            ingredients = "Wild Pacific King Salmon, Sea Kelp Noodles, Organic Avocado, Organic Cucumber, Pickled Daikon, Organic Tamari, Toasted Sesame Oil.",
            calories = 490,
            proteinGrams = 38,
            carbsGrams = 18,
            fatGrams = 28,
            isOrganic = true,
            isGlutenFree = true,
            isHighProtein = true,
            isKeto = true,
            collectionName = "HIGH-PROTEIN"
        ),
        Product(
            id = "pf_03",
            name = "Raw Vegan Zucchini Lasagna",
            brand = "Erewhon Kitchen",
            category = ProductCategory.PREPARED_FOODS.displayName,
            price = 24.00,
            shortDescription = "Layered zucchini ribbons, macadamia ricotta, sun-dried marinara & pesto.",
            fullDescription = "Delicately mandolined organic zucchini ribbon layers filled with sprouted macadamia nut ricotta, sun-dried tomato marinara, and fresh pine nut basil pesto.",
            imageUrl = "https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=800&q=80",
            categoryMarker = "RAW VEGAN",
            ingredients = "Organic Zucchini, Raw Macadamia Nuts, Sun-dried Tomatoes, Basil, Raw Pine Nuts, Extra Virgin Olive Oil, Nutritional Yeast.",
            calories = 380,
            proteinGrams = 12,
            carbsGrams = 24,
            fatGrams = 28,
            isOrganic = true,
            isVegan = true,
            isGlutenFree = true,
            collectionName = "THE HOST'S TABLE"
        ),

        // PANTRY & GROCERY
        Product(
            id = "gr_01",
            name = "Erewhon Cold-Pressed Sicilian Extra Virgin Olive Oil",
            brand = "Erewhon Reserve",
            category = ProductCategory.PANTRY.displayName,
            price = 38.00,
            shortDescription = "Single-estate early harvest Sicilian olives, unfiltered in UV glass.",
            fullDescription = "Cold-extracted within 4 hours of harvest in Val di Mazara, Sicily. Rich in polyphenols, grass-green color, with a vibrant peppery finish.",
            imageUrl = "https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?auto=format&fit=crop&w=800&q=80",
            categoryMarker = "RESERVE ESTATE",
            ingredients = "100% Organic Extra Virgin Olive Oil (Nocellara del Belice olives).",
            calories = 120,
            proteinGrams = 0,
            carbsGrams = 0,
            fatGrams = 14,
            isOrganic = true,
            isVegan = true,
            isColdPressed = true,
            isKeto = true,
            collectionName = "THE PANTRY EDIT",
            productStory = "Hand-picked from ancient Sicilian groves and bottled unrefined to preserve delicate health-boosting antioxidants."
        ),
        Product(
            id = "gr_02",
            name = "Organic Raw Wildflower Honey 16oz",
            brand = "Erewhon Apiary",
            category = ProductCategory.PANTRY.displayName,
            price = 28.00,
            shortDescription = "Unheated, unfiltered wild nectar harvested from California coastal hills.",
            fullDescription = "Pure unprocessed wildflower honey retain all natural pollen, enzymes, and propolis. Never heated or micro-filtered.",
            imageUrl = "https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&w=800&q=80",
            categoryMarker = "RAW HARVEST",
            ingredients = "100% Raw Unfiltered Organic Wildflower Honey.",
            calories = 60,
            proteinGrams = 0,
            carbsGrams = 17,
            fatGrams = 0,
            isOrganic = true,
            isGlutenFree = true,
            collectionName = "CALIFORNIA KITCHEN"
        ),
        Product(
            id = "gr_03",
            name = "Japanese Ceremonial Uji Matcha Powder 100g",
            brand = "Erewhon Tea Master",
            category = ProductCategory.DRINKS.displayName,
            price = 48.00,
            shortDescription = "First harvest shade-grown stone-ground Uji green tea leaf.",
            fullDescription = "Shade-grown for 30 days before spring harvest in Kyoto, Japan. Stone-ground into a vibrant emerald powder with velvety umami sweetness.",
            imageUrl = "https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=800&q=80",
            categoryMarker = "FIRST HARVEST",
            ingredients = "100% Organic Shade-Grown Ceremonial Japanese Green Tea Leaf.",
            calories = 10,
            proteinGrams = 1,
            carbsGrams = 1,
            fatGrams = 0,
            isOrganic = true,
            isVegan = true,
            collectionName = "THE MORNING EDIT",
            productStory = "Sourced directly from an 8th-generation family tea farm in Uji, Kyoto."
        ),

        // SUPPLEMENTS & BEAUTY
        Product(
            id = "sp_01",
            name = "Foundational Liposomal Vitamin C 250ml",
            brand = "Erewhon Labs",
            category = ProductCategory.SUPPLEMENTS.displayName,
            price = 42.00,
            shortDescription = "Cellular absorption liquid vitamin C with non-GMO sunflower phospholipids.",
            fullDescription = "Advanced liposomal delivery encapsulates L-ascorbic acid in natural phospholipid spheres for maximum immune cell uptake without stomach distress.",
            imageUrl = "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&w=800&q=80",
            categoryMarker = "LIPOSOMAL TECH",
            ingredients = "L-Ascorbic Acid, Organic Sunflower Lecithin Phospholipids, Purified Water, Organic Citrus Extract.",
            calories = 15,
            proteinGrams = 0,
            carbsGrams = 1,
            fatGrams = 1,
            isOrganic = true,
            isVegan = true,
            isGlutenFree = true,
            collectionName = "BEAUTY & WELLNESS"
        ),
        Product(
            id = "sp_02",
            name = "Botanical Youth Face Elixir 30ml",
            brand = "Erewhon Apothecary",
            category = ProductCategory.BEAUTY.displayName,
            price = 68.00,
            shortDescription = "Cold-pressed jojoba, rosehip, sea buckthorn berry & neroli flower oil.",
            fullDescription = "A potent bio-active serum rich in naturally occurring Omega 7, Vitamin A, and antioxidants. Deeply nourishes skin barrier with luminous finish.",
            imageUrl = "https://images.unsplash.com/photo-1608248597379-e242453e970b?auto=format&fit=crop&w=800&q=80",
            categoryMarker = "ORGANIC BOTANICAL",
            ingredients = "Organic Jojoba Oil, Organic Cold-Pressed Rosehip Seed Oil, Wild Sea Buckthorn Oil, Organic Neroli Essential Oil.",
            calories = 0,
            proteinGrams = 0,
            carbsGrams = 0,
            fatGrams = 0,
            isOrganic = true,
            isVegan = true,
            collectionName = "BEAUTY & WELLNESS"
        )
    )

    val editorialArticles = listOf(
        EditorialArticle(
            id = "art_01",
            title = "The California Pantry: Cold-Pressed Elixirs & Artisanal Olive Oils",
            subtitle = "A celebration of single-estate producers preserving ancestral food traditions.",
            category = "MEET THE MAKER",
            author = "Erewhon Editorial Team",
            dateText = "SEPTEMBER 2026",
            heroImageUrl = "https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?auto=format&fit=crop&w=1000&q=80",
            leadParagraph = "At Erewhon, we believe that true luxury lies in uncompromised purity. When olive oil is harvested at early green maturity and pressed within hours, it retains therapeutic levels of polyphenols.",
            bodyText = "In the hills of Val di Mazara, Sicily, third-generation olive farmers continue the sacred tradition of hand-picking Nocellara olives. The result is Erewhon's Reserve Estate Olive Oil — bright green, peppery, and alive with antioxidants.",
            relatedProductIds = "gr_01,gr_02,gr_03",
            relatedCollectionName = "THE PANTRY EDIT"
        ),
        EditorialArticle(
            id = "art_02",
            title = "Inside Hailey Bieber's Morning Glow Routine",
            subtitle = "How collagen, hyaluronic acid, and wildcrafted sea moss create the signature glaze.",
            category = "WELLNESS",
            author = "Erewhon Beauty Editor",
            dateText = "AUGUST 2026",
            heroImageUrl = "https://images.unsplash.com/photo-1553530666-ba11a7da3888?auto=format&fit=crop&w=1000&q=80",
            leadParagraph = "Skin health begins on the cellular level. When Hailey Bieber partnered with Erewhon, the goal was simple: create a delicious daily ritual packed with bioavailable skin nutrition.",
            bodyText = "By combining organic strawberries with liposomal hyaluronic acid and St. Lucia sea moss, the Strawberry Glaze smoothie supplies essential trace minerals and cellular hydration.",
            relatedProductIds = "sm_01,sm_02,sp_02",
            relatedCollectionName = "BEAUTY & WELLNESS"
        )
    )

    fun createInventory(): List<StoreInventory> {
        val inventoryList = mutableListOf<StoreInventory>()
        for (store in stores) {
            for (product in products) {
                val qty = when (store.id) {
                    "store_sm", "store_bh" -> 45
                    "store_venice" -> 30
                    else -> 18
                }
                inventoryList.add(
                    StoreInventory(
                        storeId = store.id,
                        productId = product.id,
                        onHandQuantity = qty,
                        reservedQuantity = 0,
                        status = StockStatus.IN_STOCK.name
                    )
                )
            }
        }
        return inventoryList
    }
}
