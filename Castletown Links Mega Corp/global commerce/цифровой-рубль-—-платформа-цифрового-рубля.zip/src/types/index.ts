export type NavigationTab =
  | 'overview'
  | 'architecture'
  | 'issuance'
  | 'accounts'
  | 'participants'
  | 'payments'
  | 'transfers'
  | 'settlement'
  | 'merchants'
  | 'offline'
  | 'programmable'
  | 'liquidity'
  | 'risk'
  | 'analytics'
  | 'audit'
  | 'system'
  | 'lab';

export type AccountType = 'INDIVIDUAL' | 'BUSINESS' | 'SOLE_TRADER' | 'INSTITUTION' | 'CENTRAL_BANK';
export type AccountStatus = 'ACTIVE' | 'BLOCKED' | 'SUSPENDED' | 'RESTRICTED';

export interface DigitalRubleAccount {
  id: string; // e.g., 40817810099810012345
  ownerName: string;
  ownerTaxId: string; // ИНН
  type: AccountType;
  bankId: string;
  bankName: string;
  balance: number;
  availableBalance: number;
  status: AccountStatus;
  transactionCount: number;
  lastOperationDate: string;
  createdAt: string;
  region: string;
}

export interface Institution {
  id: string; // e.g. BANK-01
  name: string; // e.g. Северный Банк
  bik: string; // БИК
  type: 'COMMERCIAL_BANK' | 'SETTLEMENT_DEPOSITORY' | 'TREASURY' | 'CENTRAL_BANK';
  status: 'ACTIVE' | 'MAINTENANCE' | 'WARNING';
  digitalRubleAccountCount: number;
  liquidityPosition: number;
  pendingSettlement: number;
  dailyVolume: number;
  requestsPerSec: number;
  latencyMs: number;
  isFictional: boolean;
}

export interface Merchant {
  id: string; // TSP-77041289
  name: string;
  category: string;
  taxId: string;
  bankId: string;
  bankName: string;
  todayTurnover: number;
  todayTxCount: number;
  avgCheck: number;
  pendingSettlement: number;
  totalBalance: number;
  terminalId: string;
  region: string;
  acquiringFeePct?: number;
}

export type TransactionStatus =
  | 'CREATED'
  | 'ACCEPTED'
  | 'CHECKING'
  | 'EXECUTING'
  | 'EXECUTED'
  | 'REJECTED'
  | 'SUSPENDED';

export type PaymentMethod =
  | 'QR'
  | 'MOBILE'
  | 'NFC'
  | 'ONLINE'
  | 'ACCOUNT_TRANSFER'
  | 'AUTOMATIC'
  | 'PROGRAMMABLE'
  | 'OFFLINE';

export interface Transaction {
  id: string; // DR-2048193
  timestamp: string;
  payerAccountId: string;
  payerName: string;
  payerBank: string;
  recipientAccountId: string;
  recipientName: string;
  recipientBank: string;
  amount: number;
  purpose: string;
  method: PaymentMethod;
  status: TransactionStatus;
  processingTimeMs: number;
  auditId: string;
  riskScore: number;
  region: string;
}

export interface IssuanceOperation {
  id: string; // ISS-88912
  type: 'ISSUANCE' | 'REDEMPTION'; // Выпуск или Погашение
  amount: number;
  date: string;
  basis: string; // Основание
  participantId: string;
  participantName: string;
  balanceBefore: number;
  balanceAfter: number;
  status: 'COMPLETED' | 'IN_PROGRESS' | 'REJECTED';
  auditId: string;
}

export interface SettlementItem {
  id: string; // SETTL-9901
  payerBankId: string;
  payerBankName: string;
  recipientBankId: string;
  recipientBankName: string;
  amount: number;
  queueStatus: 'QUEUED' | 'VERIFYING' | 'SETTLING' | 'COMPLETED' | 'SUSPENDED';
  status?: string;
  timestamp: string;
  queuedAt?: string;
  priority: 'HIGH' | 'NORMAL' | 'LOW';
}

export interface SmartContract {
  id: string; // SC-1042
  title: string;
  description?: string;
  condition?: string;
  payerAccountId: string;
  payerName: string;
  recipientAccountId: string;
  recipientName: string;
  amount: number;
  conditionType: 'DELIVERY_VERIFICATION' | 'REGULAR_SCHEDULE' | 'TAX_CLEARANCE' | 'CONDITIONAL_FINANCING';
  conditionDesc: string;
  executionDate: string;
  expiryDate: string;
  status: 'WAITING_CONDITION' | 'EXECUTED' | 'EXPIRED' | 'CANCELLED';
}

export interface OfflineTransaction {
  id: string; // OFF-4412
  deviceId: string;
  secureModuleId: string;
  amount: number;
  senderAccount: string;
  senderName: string;
  recipientAccount: string;
  recipientName: string;
  timestamp: string;
  syncStatus: 'SAVED_LOCALLY' | 'SYNCING' | 'RECONCILING' | 'COMPLETED';
}

export interface RiskControlEvent {
  id: string;
  timestamp: string;
  category: string;
  riskLevel: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  description: string;
  actionTaken: string;
}

export interface RiskAlert {
  id: string; // RSK-7721
  transactionId: string;
  amount: number;
  payerName: string;
  reason: string; // e.g. "ОТКЛОНЕНИЕ ОТ ЗАДАННОГО ШАБЛОНА"
  severity: 'CRITICAL' | 'WARNING' | 'INFO';
  status: 'REQUIRES_CHECK' | 'CONFIRMED' | 'DISMISSED';
  timestamp: string;
}

export interface AuditEvent {
  id: string; // AUD-99120
  timestamp: string;
  participant: string;
  actor?: string;
  operation: string;
  actionType?: string;
  targetObject: string;
  hash?: string;
  signature?: string;
  result: 'SUCCESS' | 'DENIED' | 'FLAGGED';
  level: 'INFO' | 'WARN' | 'CRITICAL';
}

export interface RegionalData {
  regionCode: string;
  regionName: string;
  txCountToday: number;
  volumeToday: number;
  accountCount: number;
  merchantCount: number;
  settlementLoadPct: number;
}

export interface SystemServiceStatus {
  id: string;
  name: string;
  status: 'NORMAL' | 'WARNING' | 'ERROR' | 'MAINTENANCE';
  latencyMs: number;
  tps: number;
  errorRatePct: number;
  lastHeartbeat: string;
  queueSize: number;
}

export interface EconomicLabParams {
  totalCirculationTarget: number;
  velocityMultiplier: number;
  activeAccountsRatio: number;
  digitalPaymentsSharePct: number;
  simulationSpeed: 1 | 10 | 100;
  isRunning: boolean;
}
