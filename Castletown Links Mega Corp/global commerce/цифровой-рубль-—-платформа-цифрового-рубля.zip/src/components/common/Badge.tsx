import React from 'react';

interface BadgeProps {
  children: React.ReactNode;
  variant?: 'green' | 'blue' | 'amber' | 'red' | 'grey' | 'burgundy' | 'outline';
  size?: 'sm' | 'md';
  pulse?: boolean;
}

export const Badge: React.FC<BadgeProps> = ({
  children,
  variant = 'blue',
  size = 'md',
  pulse = false,
}) => {
  const variantStyles = {
    green: 'bg-emerald-950/80 text-emerald-300 border-emerald-800/80',
    blue: 'bg-blue-950/80 text-blue-300 border-blue-800/80',
    amber: 'bg-amber-950/80 text-amber-300 border-amber-800/80',
    red: 'bg-rose-950/80 text-rose-300 border-rose-800/80',
    grey: 'bg-slate-800 text-slate-300 border-slate-700',
    burgundy: 'bg-rose-950 text-rose-200 border-rose-900',
    outline: 'bg-transparent text-slate-300 border-slate-700',
  };

  const sizeStyles = {
    sm: 'text-[10px] px-1.5 py-0.5 tracking-wider',
    md: 'text-xs px-2.5 py-1 tracking-wide',
  };

  return (
    <span
      className={`inline-flex items-center gap-1.5 font-mono font-medium rounded border ${variantStyles[variant]} ${sizeStyles[size]} whitespace-nowrap`}
    >
      {pulse && (
        <span className="relative flex h-2 w-2">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
        </span>
      )}
      {children}
    </span>
  );
};
