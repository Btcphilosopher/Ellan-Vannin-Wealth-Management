import React from 'react';

interface StatCardProps {
  title: string;
  value: string | React.ReactNode;
  subtitle?: string;
  change?: string;
  changeType?: 'positive' | 'negative' | 'neutral';
  icon?: React.ReactNode;
  accent?: 'blue' | 'emerald' | 'amber' | 'rose' | 'slate';
  isSimulatedBadge?: boolean;
}

export const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  subtitle,
  change,
  changeType = 'neutral',
  icon,
  accent = 'slate',
  isSimulatedBadge = false,
}) => {
  const accentBorders = {
    blue: 'border-l-2 border-l-blue-500',
    emerald: 'border-l-2 border-l-emerald-500',
    amber: 'border-l-2 border-l-amber-500',
    rose: 'border-l-2 border-l-rose-500',
    slate: 'border-l-2 border-l-slate-600',
  };

  const changeColors = {
    positive: 'text-emerald-400',
    negative: 'text-rose-400',
    neutral: 'text-slate-400',
  };

  return (
    <div
      className={`bg-[#121824] border border-slate-800 rounded-lg p-4 relative overflow-hidden shadow-sm ${accentBorders[accent]}`}
    >
      <div className="flex items-start justify-between gap-2 mb-1.5">
        <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 leading-tight">
          {title}
        </span>
        {icon && <div className="text-slate-500 p-1 bg-slate-800/50 rounded">{icon}</div>}
      </div>

      <div className="text-xl sm:text-2xl font-bold font-mono text-white tracking-tight my-1 tabular-nums">
        {value}
      </div>

      <div className="flex items-center justify-between text-xs mt-2 pt-2 border-t border-slate-800/80">
        {subtitle && <span className="text-slate-400 truncate max-w-[70%]">{subtitle}</span>}
        {change && (
          <span className={`font-mono font-medium ${changeColors[changeType]}`}>
            {change}
          </span>
        )}
        {isSimulatedBadge && (
          <span className="text-[10px] font-mono text-slate-500 bg-slate-900/90 border border-slate-800 px-1.5 py-0.5 rounded">
            МОДЕЛИРОВАННЫЕ ДАННЫЕ
          </span>
        )}
      </div>
    </div>
  );
};
