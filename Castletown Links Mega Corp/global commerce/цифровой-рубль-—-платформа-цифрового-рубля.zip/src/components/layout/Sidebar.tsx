import React from 'react';
import { NavigationTab } from '../../types';
import {
  LayoutDashboard,
  Layers,
  Coins,
  Wallet,
  Building2,
  CreditCard,
  UserCheck,
  RefreshCw,
  Store,
  WifiOff,
  Code2,
  TrendingUp,
  ShieldAlert,
  BarChart3,
  FileText,
  Activity,
  Sliders,
} from 'lucide-react';

interface SidebarProps {
  activeTab: NavigationTab;
  setActiveTab: (tab: NavigationTab) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab }) => {
  const navItems: { id: NavigationTab; label: string; icon: React.ReactNode }[] = [
    { id: 'overview', label: 'Обзор', icon: <LayoutDashboard className="w-4 h-4" /> },
    { id: 'architecture', label: 'Платформа', icon: <Layers className="w-4 h-4" /> },
    { id: 'issuance', label: 'Выпуск цифровых рублей', icon: <Coins className="w-4 h-4" /> },
    { id: 'accounts', label: 'Счета цифрового рубля', icon: <Wallet className="w-4 h-4" /> },
    { id: 'participants', label: 'Участники', icon: <Building2 className="w-4 h-4" /> },
    { id: 'payments', label: 'Платежи', icon: <CreditCard className="w-4 h-4" /> },
    { id: 'transfers', label: 'Переводы', icon: <UserCheck className="w-4 h-4" /> },
    { id: 'settlement', label: 'Расчеты', icon: <RefreshCw className="w-4 h-4" /> },
    { id: 'merchants', label: 'Торгово-сервисная сеть', icon: <Store className="w-4 h-4" /> },
    { id: 'offline', label: 'Офлайн-операции', icon: <WifiOff className="w-4 h-4" /> },
    { id: 'programmable', label: 'Умные контракты', icon: <Code2 className="w-4 h-4" /> },
    { id: 'liquidity', label: 'Ликвидность', icon: <TrendingUp className="w-4 h-4" /> },
    { id: 'risk', label: 'Риск-контроль', icon: <ShieldAlert className="w-4 h-4" /> },
    { id: 'analytics', label: 'Аналитика', icon: <BarChart3 className="w-4 h-4" /> },
    { id: 'audit', label: 'Аудит', icon: <FileText className="w-4 h-4" /> },
    { id: 'system', label: 'Мониторинг системы', icon: <Activity className="w-4 h-4" /> },
    { id: 'lab', label: 'Администрирование', icon: <Sliders className="w-4 h-4" /> },
  ];

  return (
    <aside className="w-64 bg-[#0a0e16] border-r border-slate-800 flex-shrink-0 flex flex-col justify-between select-none">
      <div className="py-3 px-2 overflow-y-auto space-y-1">
        <div className="px-3 py-1.5 text-[10px] font-mono font-bold uppercase tracking-wider text-slate-500">
          НАВИГАЦИЯ ПЛАТФОРМЫ
        </div>

        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-mono font-medium transition-all duration-150 text-left ${
                isActive
                  ? 'bg-blue-600/20 text-blue-300 border border-blue-500/40 shadow-xs'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <span className={isActive ? 'text-blue-400' : 'text-slate-500'}>
                {item.icon}
              </span>
              <span className="truncate">{item.label}</span>
            </button>
          );
        })}
      </div>

      {/* Footer Branding Notice */}
      <div className="p-3 border-t border-slate-800 bg-[#070a10]">
        <div className="text-[10px] font-mono text-slate-500 space-y-1">
          <div className="text-slate-400 font-bold uppercase">СИМУЛЯЦИОННАЯ СИСТЕМА</div>
          <div>БАНК РОССИИ — ЦР ПЛАТФОРМА</div>
          <div className="text-emerald-500 font-semibold">ВЕРСИЯ 2030.4.2-SIM</div>
        </div>
      </div>
    </aside>
  );
};
