import React, { useState } from 'react';
import { useSimulation } from '../../simulation/SimulationContext';
import { Badge } from '../common/Badge';
import { Modal } from '../common/Modal';
import { formatDateTime, formatRuble } from '../../utils/formatters';
import {
  Play,
  Pause,
  RotateCcw,
  Send,
  PlusCircle,
  Landmark,
  ShieldCheck,
  Globe,
} from 'lucide-react';

export const Header: React.FC = () => {
  const {
    simTime,
    simSpeed,
    isSimRunning,
    setSimSpeed,
    toggleSimRunning,
    resetSimulation,
    executePayment,
    executeIssuance,
    createAccount,
    accounts,
    institutions,
  } = useSimulation();

  // Quick Action Modal states
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [isIssuanceModalOpen, setIsIssuanceModalOpen] = useState(false);
  const [isNewAccountModalOpen, setIsNewAccountModalOpen] = useState(false);

  // Form states
  const [payPayerId, setPayPayerId] = useState(accounts[0]?.id || '');
  const [payRecipientId, setPayRecipientId] = useState(accounts[1]?.id || '');
  const [payAmount, setPayAmount] = useState('2500');
  const [payPurpose, setPayPurpose] = useState('Перевод по номеру счета');
  const [payMsg, setPayMsg] = useState('');

  const [issAmount, setIssAmount] = useState('10000000000');
  const [issBankId, setIssBankId] = useState('BANK-02');
  const [issBasis, setIssBasis] = useState('Депонирование средств на корреспондентском счете ЦБ');
  const [issType, setIssType] = useState<'ISSUANCE' | 'REDEMPTION'>('ISSUANCE');
  const [issMsg, setIssMsg] = useState('');

  const [accName, setAccName] = useState('');
  const [accTaxId, setAccTaxId] = useState('');
  const [accType, setAccType] = useState<'INDIVIDUAL' | 'BUSINESS' | 'SOLE_TRADER'>('INDIVIDUAL');
  const [accBankId, setAccBankId] = useState('BANK-01');
  const [accInitialBal, setAccInitialBal] = useState('50000');
  const [accMsg, setAccMsg] = useState('');

  const handleQuickPaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(payAmount);
    if (isNaN(amt) || amt <= 0) return;
    const res = executePayment({
      payerAccountId: payPayerId,
      recipientAccountId: payRecipientId,
      amount: amt,
      purpose: payPurpose,
      method: 'ACCOUNT_TRANSFER',
    });
    setPayMsg(res.message);
    if (res.success) {
      setTimeout(() => {
        setIsPaymentModalOpen(false);
        setPayMsg('');
      }, 1500);
    }
  };

  const handleQuickIssuanceSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(issAmount);
    if (isNaN(amt) || amt <= 0) return;
    const res = executeIssuance(amt, issBankId, issBasis, issType);
    setIssMsg(res.message);
    if (res.success) {
      setTimeout(() => {
        setIsIssuanceModalOpen(false);
        setIssMsg('');
      }, 1500);
    }
  };

  const handleCreateAccountSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!accName || !accTaxId) return;
    const newAcc = createAccount({
      ownerName: accName,
      ownerTaxId: accTaxId,
      type: accType,
      bankId: accBankId,
      initialBalance: parseFloat(accInitialBal) || 0,
      region: 'Москва',
    });
    setAccMsg(`Счет успешно открыт: ${newAcc.id}`);
    setTimeout(() => {
      setIsNewAccountModalOpen(false);
      setAccMsg('');
      setAccName('');
      setAccTaxId('');
    }, 1500);
  };

  return (
    <>
      <header className="bg-[#0a0e16] border-b border-slate-800 text-white sticky top-0 z-40">
        {/* Main Header Container */}
        <div className="max-w-[1920px] mx-auto px-4 py-3 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          {/* Product Identification Branding */}
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-600 via-blue-700 to-slate-900 border border-blue-400/30 flex items-center justify-center shadow-lg font-mono text-xl font-bold text-white">
              ₽
            </div>
            <div>
              <div className="flex items-center gap-2.5">
                <h1 className="text-lg font-extrabold tracking-tight font-mono uppercase text-white">
                  ЦИФРОВОЙ РУБЛЬ
                </h1>
                <Badge variant="blue" size="sm">
                  ПЛАТФОРМА ЦИФРОВОГО РУБЛЯ
                </Badge>
              </div>
              <p className="text-xs text-slate-400 font-sans mt-0.5">
                Система управления выпуском, обращением, платежами и расчетами
              </p>
            </div>
          </div>

          {/* Status Indicators & Controls */}
          <div className="flex flex-wrap items-center gap-2.5 lg:justify-end">
            <Badge variant="green" pulse>
              ● СИСТЕМА РАБОТАЕТ
            </Badge>

            <Badge variant="amber">ТЕСТОВАЯ СРЕДА</Badge>

            <Badge variant="grey">МОДЕЛИРОВАННЫЕ ДАННЫЕ</Badge>

            <Badge variant="outline">₽ RUB</Badge>

            {/* Clock Ticker */}
            <div className="bg-[#121824] border border-slate-800 px-3 py-1 rounded text-xs font-mono font-medium text-blue-300 flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse"></span>
              {formatDateTime(simTime)}
            </div>

            {/* Simulation Speed & Control Buttons */}
            <div className="flex items-center gap-1 bg-[#121824] border border-slate-800 p-1 rounded">
              <button
                onClick={toggleSimRunning}
                className={`p-1.5 rounded transition-colors ${
                  isSimRunning
                    ? 'text-amber-400 hover:bg-slate-800'
                    : 'text-emerald-400 hover:bg-slate-800'
                }`}
                title={isSimRunning ? 'Пауза симуляции' : 'Запуск симуляции'}
              >
                {isSimRunning ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              </button>

              <button
                onClick={() => setSimSpeed(1)}
                className={`px-1.5 py-0.5 text-[10px] font-mono rounded ${
                  simSpeed === 1 ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                ×1
              </button>
              <button
                onClick={() => setSimSpeed(10)}
                className={`px-1.5 py-0.5 text-[10px] font-mono rounded ${
                  simSpeed === 10 ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                ×10
              </button>
              <button
                onClick={() => setSimSpeed(100)}
                className={`px-1.5 py-0.5 text-[10px] font-mono rounded ${
                  simSpeed === 100 ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                ×100
              </button>

              <button
                onClick={resetSimulation}
                className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded transition-colors"
                title="Сбросить симуляцию"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Quick Modals Triggers */}
            <div className="flex items-center gap-2 border-l border-slate-800 pl-2 ml-1">
              <button
                onClick={() => setIsPaymentModalOpen(true)}
                className="inline-flex items-center gap-1.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-mono font-medium px-2.5 py-1.5 rounded transition-colors"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Платеж</span>
              </button>

              <button
                onClick={() => setIsIssuanceModalOpen(true)}
                className="inline-flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-mono font-medium px-2.5 py-1.5 rounded transition-colors"
              >
                <Landmark className="w-3.5 h-3.5" />
                <span>Выпуск</span>
              </button>

              <button
                onClick={() => setIsNewAccountModalOpen(true)}
                className="inline-flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-mono font-medium px-2.5 py-1.5 rounded transition-colors"
              >
                <PlusCircle className="w-3.5 h-3.5" />
                <span>Новый счет</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* QUICK PAYMENT MODAL */}
      <Modal
        isOpen={isPaymentModalOpen}
        onClose={() => setIsPaymentModalOpen(false)}
        title="ПРОСТЕНИЕ И ИСПОЛНЕНИЕ ПЛАТЕЖА"
        subtitle="Симуляция проведения операции цифрового рубля"
      >
        <form onSubmit={handleQuickPaymentSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-mono text-slate-300 mb-1">
              Счет плательщика (Отправитель)
            </label>
            <select
              value={payPayerId}
              onChange={(e) => setPayPayerId(e.target.value)}
              className="w-full bg-[#161c2c] border border-slate-700 rounded p-2 text-xs font-mono text-white"
            >
              {accounts.map((acc) => (
                <option key={acc.id} value={acc.id}>
                  {acc.ownerName} ({acc.id}) — {formatRuble(acc.availableBalance)}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-mono text-slate-300 mb-1">
              Счет получателя (Получатель)
            </label>
            <select
              value={payRecipientId}
              onChange={(e) => setPayRecipientId(e.target.value)}
              className="w-full bg-[#161c2c] border border-slate-700 rounded p-2 text-xs font-mono text-white"
            >
              {accounts.map((acc) => (
                <option key={acc.id} value={acc.id}>
                  {acc.ownerName} ({acc.id})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-mono text-slate-300 mb-1">
              Сумма операции (₽)
            </label>
            <input
              type="number"
              value={payAmount}
              onChange={(e) => setPayAmount(e.target.value)}
              className="w-full bg-[#161c2c] border border-slate-700 rounded p-2 text-xs font-mono text-white"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-mono text-slate-300 mb-1">
              Назначение платежа
            </label>
            <input
              type="text"
              value={payPurpose}
              onChange={(e) => setPayPurpose(e.target.value)}
              className="w-full bg-[#161c2c] border border-slate-700 rounded p-2 text-xs font-mono text-white"
              required
            />
          </div>

          {payMsg && (
            <div
              className={`p-3 rounded text-xs font-mono ${
                payMsg.includes('ошибка') || payMsg.includes('отклонена')
                  ? 'bg-rose-950/80 text-rose-300 border border-rose-800'
                  : 'bg-emerald-950/80 text-emerald-300 border border-emerald-800'
              }`}
            >
              {payMsg}
            </div>
          )}

          <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
            <button
              type="button"
              onClick={() => setIsPaymentModalOpen(false)}
              className="px-3 py-1.5 bg-slate-800 text-slate-300 text-xs font-mono rounded"
            >
              Отмена
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-mono font-bold rounded"
            >
              Исполнить платеж
            </button>
          </div>
        </form>
      </Modal>

      {/* QUICK ISSUANCE MODAL */}
      <Modal
        isOpen={isIssuanceModalOpen}
        onClose={() => setIsIssuanceModalOpen(false)}
        title="ОПЕРАЦИЯ ВЫПУСКА / ПОГАШЕНИЯ ЦИФРОВЫХ РУБЛЕЙ"
        subtitle="Централизованный выпуск Банком России для участника платформы"
      >
        <form onSubmit={handleQuickIssuanceSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-mono text-slate-300 mb-1">Тип операции</label>
            <div className="flex items-center gap-3">
              <label className="flex items-center gap-1.5 text-xs text-white">
                <input
                  type="radio"
                  name="issType"
                  checked={issType === 'ISSUANCE'}
                  onChange={() => setIssType('ISSUANCE')}
                />
                Выпуск (Эмиссия)
              </label>
              <label className="flex items-center gap-1.5 text-xs text-white">
                <input
                  type="radio"
                  name="issType"
                  checked={issType === 'REDEMPTION'}
                  onChange={() => setIssType('REDEMPTION')}
                />
                Погашение (Изъятие)
              </label>
            </div>
          </div>

          <div>
            <label className="block text-xs font-mono text-slate-300 mb-1">
              Банк — Участник платформы
            </label>
            <select
              value={issBankId}
              onChange={(e) => setIssBankId(e.target.value)}
              className="w-full bg-[#161c2c] border border-slate-700 rounded p-2 text-xs font-mono text-white"
            >
              {institutions
                .filter((i) => i.type !== 'CENTRAL_BANK')
                .map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name} (Ликвидность: {formatRuble(b.liquidityPosition)})
                  </option>
                ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-mono text-slate-300 mb-1">Сумма (₽)</label>
            <input
              type="number"
              value={issAmount}
              onChange={(e) => setIssAmount(e.target.value)}
              className="w-full bg-[#161c2c] border border-slate-700 rounded p-2 text-xs font-mono text-white"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-mono text-slate-300 mb-1">Основание операции</label>
            <input
              type="text"
              value={issBasis}
              onChange={(e) => setIssBasis(e.target.value)}
              className="w-full bg-[#161c2c] border border-slate-700 rounded p-2 text-xs font-mono text-white"
              required
            />
          </div>

          {issMsg && (
            <div
              className={`p-3 rounded text-xs font-mono ${
                issMsg.includes('Ошибка')
                  ? 'bg-rose-950/80 text-rose-300 border border-rose-800'
                  : 'bg-emerald-950/80 text-emerald-300 border border-emerald-800'
              }`}
            >
              {issMsg}
            </div>
          )}

          <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
            <button
              type="button"
              onClick={() => setIsIssuanceModalOpen(false)}
              className="px-3 py-1.5 bg-slate-800 text-slate-300 text-xs font-mono rounded"
            >
              Отмена
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-mono font-bold rounded"
            >
              Провести эмиссию
            </button>
          </div>
        </form>
      </Modal>

      {/* NEW ACCOUNT MODAL */}
      <Modal
        isOpen={isNewAccountModalOpen}
        onClose={() => setIsNewAccountModalOpen(false)}
        title="ОТКРЫТИЕ СЧЕТА ЦИФРОВОГО РУБЛЯ"
        subtitle="Регистрация нового клиента на платформе Центрального Банка"
      >
        <form onSubmit={handleCreateAccountSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-mono text-slate-300 mb-1">
              Наименование / ФИО владельца
            </label>
            <input
              type="text"
              value={accName}
              onChange={(e) => setAccName(e.target.value)}
              placeholder="Сидоров Иван Петрович или ООО Вектор"
              className="w-full bg-[#161c2c] border border-slate-700 rounded p-2 text-xs font-mono text-white"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-mono text-slate-300 mb-1">ИНН Клиента</label>
            <input
              type="text"
              value={accTaxId}
              onChange={(e) => setAccTaxId(e.target.value)}
              placeholder="7704918201"
              className="w-full bg-[#161c2c] border border-slate-700 rounded p-2 text-xs font-mono text-white"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-mono text-slate-300 mb-1">Тип счета</label>
            <select
              value={accType}
              onChange={(e) => setAccType(e.target.value as any)}
              className="w-full bg-[#161c2c] border border-slate-700 rounded p-2 text-xs font-mono text-white"
            >
              <option value="INDIVIDUAL">Счет физического лица</option>
              <option value="BUSINESS">Счет организации (Юр.лицо)</option>
              <option value="SOLE_TRADER">Счет индивидуального предпринимателя (ИП)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-mono text-slate-300 mb-1">
              Банк — Обслуживающий участник
            </label>
            <select
              value={accBankId}
              onChange={(e) => setAccBankId(e.target.value)}
              className="w-full bg-[#161c2c] border border-slate-700 rounded p-2 text-xs font-mono text-white"
            >
              {institutions
                .filter((i) => i.type !== 'CENTRAL_BANK')
                .map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name}
                  </option>
                ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-mono text-slate-300 mb-1">Начальный баланс (₽)</label>
            <input
              type="number"
              value={accInitialBal}
              onChange={(e) => setAccInitialBal(e.target.value)}
              className="w-full bg-[#161c2c] border border-slate-700 rounded p-2 text-xs font-mono text-white"
            />
          </div>

          {accMsg && (
            <div className="p-3 bg-emerald-950/80 text-emerald-300 border border-emerald-800 rounded text-xs font-mono">
              {accMsg}
            </div>
          )}

          <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
            <button
              type="button"
              onClick={() => setIsNewAccountModalOpen(false)}
              className="px-3 py-1.5 bg-slate-800 text-slate-300 text-xs font-mono rounded"
            >
              Отмена
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-mono font-bold rounded"
            >
              Зарегистрировать счет
            </button>
          </div>
        </form>
      </Modal>
    </>
  );
};
