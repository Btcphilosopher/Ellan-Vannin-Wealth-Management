import React from 'react';

interface DataPoint {
  label: string;
  value: number;
}

interface SimpleLineChartProps {
  data: DataPoint[];
  title?: string;
  height?: number;
  color?: string; // hex or tailwind class
  formatValue?: (val: number) => string;
}

export const SimpleLineChart: React.FC<SimpleLineChartProps> = ({
  data,
  title,
  height = 180,
  color = '#3b82f6',
  formatValue = (v) => v.toLocaleString('ru-RU'),
}) => {
  if (!data || data.length === 0) return null;

  const padding = 25;
  const svgWidth = 500;
  const svgHeight = height;

  const values = data.map((d) => d.value);
  const minVal = Math.min(...values) * 0.95;
  const maxVal = Math.max(...values) * 1.05 || 1;

  const points = data.map((d, i) => {
    const x = padding + (i / (data.length - 1 || 1)) * (svgWidth - padding * 2);
    const y = svgHeight - padding - ((d.value - minVal) / (maxVal - minVal || 1)) * (svgHeight - padding * 2);
    return { x, y, label: d.label, value: d.value };
  });

  const pathD = points.reduce(
    (acc, pt, i) => (i === 0 ? `M ${pt.x} ${pt.y}` : `${acc} L ${pt.x} ${pt.y}`),
    ''
  );

  const areaD = `${pathD} L ${points[points.length - 1].x} ${svgHeight - padding} L ${points[0].x} ${svgHeight - padding} Z`;

  return (
    <div className="w-full bg-[#121824] border border-slate-800 rounded-lg p-3">
      {title && (
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-semibold text-slate-300 font-mono uppercase tracking-wider">
            {title}
          </span>
          <span className="text-[10px] text-slate-500 font-mono">МОДЕЛИРОВАННЫЕ ДАННЫЕ</span>
        </div>
      )}

      <svg viewBox={`0 0 ${svgWidth} ${svgHeight}`} className="w-full h-auto overflow-visible">
        <defs>
          <linearGradient id={`grad-${color.replace('#', '')}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity="0.35" />
            <stop offset="100%" stopColor={color} stopOpacity="0.0" />
          </linearGradient>
        </defs>

        {/* Grid lines */}
        {[0.25, 0.5, 0.75].map((ratio, idx) => {
          const y = svgHeight - padding - ratio * (svgHeight - padding * 2);
          return (
            <line
              key={idx}
              x1={padding}
              y1={y}
              x2={svgWidth - padding}
              y2={y}
              stroke="#1e293b"
              strokeDasharray="3 3"
            />
          );
        })}

        {/* Fill Area */}
        <path d={areaD} fill={`url(#grad-${color.replace('#', '')})`} />

        {/* Line */}
        <path d={pathD} fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" />

        {/* Data points */}
        {points.map((pt, i) => (
          <g key={i} className="group">
            <circle
              cx={pt.x}
              cy={pt.y}
              r="3.5"
              fill={color}
              className="transition-transform group-hover:r-5 cursor-pointer"
            />
            <text
              x={pt.x}
              y={svgHeight - 6}
              fontSize="9"
              fill="#64748b"
              textAnchor="middle"
              className="font-mono"
            >
              {pt.label}
            </text>
          </g>
        ))}
      </svg>
    </div>
  );
};
