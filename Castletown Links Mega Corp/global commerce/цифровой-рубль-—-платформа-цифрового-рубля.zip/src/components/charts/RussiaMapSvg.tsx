import React, { useState } from 'react';
import { RegionalData } from '../../types';
import { formatRuble, formatNumber } from '../../utils/formatters';

interface RussiaMapProps {
  regions: RegionalData[];
}

export const RussiaMapSvg: React.FC<RussiaMapProps> = ({ regions }) => {
  const [selectedCode, setSelectedCode] = useState<string>('MOW');

  const selectedRegion = regions.find((r) => r.regionCode === selectedCode) || regions[0];

  // SVG coordinates for Federal Districts
  const regionNodes = [
    { code: 'MOW', name: 'Москва', cx: 160, cy: 190, r: 18, color: '#3b82f6' },
    { code: 'SPE', name: 'СЗФО (СПб)', cx: 140, cy: 120, r: 15, color: '#2563eb' },
    { code: 'CFO', name: 'ЦФО', cx: 210, cy: 210, r: 14, color: '#1d4ed8' },
    { code: 'SKFO', name: 'СКФО', cx: 140, cy: 300, r: 10, color: '#1e40af' },
    { code: 'UFO_SOUTH', name: 'ЮФО', cx: 180, cy: 280, r: 12, color: '#1e3a8a' },
    { code: 'PFO', name: 'ПФО', cx: 270, cy: 220, r: 15, color: '#3b82f6' },
    { code: 'UFO', name: 'УрФО', cx: 370, cy: 190, r: 16, color: '#2563eb' },
    { code: 'SFO', name: 'СФО', cx: 520, cy: 210, r: 18, color: '#1d4ed8' },
    { code: 'DFO', name: 'ДФО', cx: 700, cy: 190, r: 22, color: '#1e40af' },
  ];

  const connections = [
    ['MOW', 'SPE'],
    ['MOW', 'CFO'],
    ['MOW', 'UFO_SOUTH'],
    ['UFO_SOUTH', 'SKFO'],
    ['CFO', 'PFO'],
    ['PFO', 'UFO'],
    ['UFO', 'SFO'],
    ['SFO', 'DFO'],
  ];

  return (
    <div className="bg-[#121824] border border-slate-800 rounded-xl p-5 shadow-sm">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between pb-4 border-b border-slate-800 gap-3">
        <div>
          <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
            КАРТА НАЦИОНАЛЬНОЙ ИНФРАСТРУКТУРЫ ЦИФРОВОГО РУБЛЯ
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Мониторинг расчетной нагрузки и активности по федеральным округам
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[10px] font-mono text-slate-400 bg-slate-900 border border-slate-800 px-2 py-1 rounded">
            СИНХРОНИЗАЦИЯ: 100%
          </span>
          <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/80 border border-emerald-800/80 px-2 py-1 rounded">
            СЕТЬ АКТИВНА
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-5">
        {/* Abstract Map Area */}
        <div className="lg:col-span-2 bg-[#0d121c] border border-slate-800/80 rounded-lg p-4 relative min-h-[320px] flex items-center justify-center">
          <svg viewBox="0 0 820 380" className="w-full h-auto overflow-visible">
            {/* Background grid */}
            <pattern id="mapGrid" width="20" height="20" patternUnits="userSpaceOnUse">
              <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#1e293b" strokeWidth="0.5" />
            </pattern>
            <rect width="820" height="380" fill="url(#mapGrid)" rx="6" opacity="0.6" />

            {/* Inter-regional Backbone lines */}
            {connections.map(([code1, code2], idx) => {
              const n1 = regionNodes.find((n) => n.code === code1);
              const n2 = regionNodes.find((n) => n.code === code2);
              if (!n1 || !n2) return null;

              return (
                <g key={idx}>
                  <line
                    x1={n1.cx}
                    y1={n1.cy}
                    x2={n2.cx}
                    y2={n2.cy}
                    stroke="#2563eb"
                    strokeWidth="1.5"
                    strokeOpacity="0.4"
                    strokeDasharray="4 2"
                  />
                </g>
              );
            })}

            {/* Regional Nodes */}
            {regionNodes.map((node) => {
              const regData = regions.find((r) => r.regionCode === node.code);
              const isSelected = node.code === selectedCode;

              return (
                <g
                  key={node.code}
                  onClick={() => setSelectedCode(node.code)}
                  className="cursor-pointer group"
                >
                  {/* Glowing ring if selected */}
                  {isSelected && (
                    <circle
                      cx={node.cx}
                      cy={node.cy}
                      r={node.r + 8}
                      fill="none"
                      stroke="#3b82f6"
                      strokeWidth="2"
                      className="animate-pulse"
                    />
                  )}

                  <circle
                    cx={node.cx}
                    cy={node.cy}
                    r={node.r}
                    fill={isSelected ? '#3b82f6' : '#1e293b'}
                    stroke={isSelected ? '#93c5fd' : '#334155'}
                    strokeWidth="2"
                    className="transition-all duration-200 group-hover:fill-blue-600"
                  />

                  <text
                    x={node.cx}
                    y={node.cy + 4}
                    fontSize="10"
                    fill="#ffffff"
                    textAnchor="middle"
                    className="font-mono font-bold pointer-events-none"
                  >
                    {node.code.slice(0, 3)}
                  </text>

                  <text
                    x={node.cx}
                    y={node.cy + node.r + 14}
                    fontSize="11"
                    fill={isSelected ? '#93c5fd' : '#94a3b8'}
                    textAnchor="middle"
                    className="font-sans font-semibold pointer-events-none"
                  >
                    {node.name}
                  </text>
                </g>
              );
            })}
          </svg>
        </div>

        {/* Selected Region Detailed Panel */}
        <div className="bg-[#0f1420] border border-slate-800 rounded-lg p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <span className="text-xs font-mono font-semibold text-blue-400 uppercase">
                {selectedRegion.regionCode}
              </span>
              <span className="text-[10px] font-mono text-slate-500">РЕГИОНАЛЬНЫЙ УЗЕЛ</span>
            </div>

            <h4 className="text-base font-bold text-white mt-3 font-mono">
              {selectedRegion.regionName}
            </h4>

            <div className="space-y-3 mt-4 text-xs font-mono">
              <div className="bg-[#141b2b] p-3 rounded border border-slate-800/80">
                <span className="text-slate-400 block text-[11px] mb-1">ОБЪЕМ ОПЕРАЦИЙ СЕГОДНЯ</span>
                <span className="text-lg font-bold text-white text-emerald-400">
                  {formatRuble(selectedRegion.volumeToday)}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="bg-[#141b2b] p-2.5 rounded border border-slate-800/80">
                  <span className="text-slate-400 block text-[10px]">КОЛ-ВО ОПЕРАЦИЙ</span>
                  <span className="text-sm font-bold text-white mt-0.5 block">
                    {formatNumber(selectedRegion.txCountToday)}
                  </span>
                </div>
                <div className="bg-[#141b2b] p-2.5 rounded border border-slate-800/80">
                  <span className="text-slate-400 block text-[10px]">СЧЕТА ЦИФРОВОГО РУБЛЯ</span>
                  <span className="text-sm font-bold text-white mt-0.5 block">
                    {formatNumber(selectedRegion.accountCount)}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="bg-[#141b2b] p-2.5 rounded border border-slate-800/80">
                  <span className="text-slate-400 block text-[10px]">ТОРГОВЫЕ ТОЧКИ (ТСП)</span>
                  <span className="text-sm font-bold text-white mt-0.5 block">
                    {formatNumber(selectedRegion.merchantCount)}
                  </span>
                </div>
                <div className="bg-[#141b2b] p-2.5 rounded border border-slate-800/80">
                  <span className="text-slate-400 block text-[10px]">РАСЧЕТНАЯ НАГРУЗКА</span>
                  <span className="text-sm font-bold text-blue-400 mt-0.5 block">
                    {selectedRegion.settlementLoadPct}%
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800 text-[10px] text-slate-500 font-mono text-center">
            МОДЕЛИРОВАННЫЕ РЕГИОНАЛЬНЫЕ ДАННЫЕ СИМУЛЯЦИИ
          </div>
        </div>
      </div>
    </div>
  );
};
