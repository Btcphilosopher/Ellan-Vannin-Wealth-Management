import React from 'react';

interface BarDataPoint {
  label: string;
  value: number;
  secondaryValue?: number;
}

interface SimpleBarChartProps {
  data: BarDataPoint[];
  title?: string;
  height?: number;
  primaryColor?: string;
  formatValue?: (val: number) => string;
}

export const SimpleBarChart: React.FC<SimpleBarChartProps> = ({
  data,
  title,
  height = 180,
  primaryColor = '#2563eb',
  formatValue = (v) => v.toLocaleString('ru-RU'),
}) => {
  if (!data || data.length === 0) return null;

  const maxVal = Math.max(...data.map((d) => d.value)) * 1.1 || 1;

  return (
    <div className="w-full bg-[#121824] border border-slate-800 rounded-lg p-3">
      {title && (
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs font-semibold text-slate-300 font-mono uppercase tracking-wider">
            {title}
          </span>
          <span className="text-[10px] text-slate-500 font-mono">МОДЕЛИРОВАННЫЕ ДАННЫЕ</span>
        </div>
      )}

      <div className="flex items-end gap-2 h-36 pt-2 pb-5 px-1 border-b border-slate-800">
        {data.map((item, idx) => {
          const heightPct = Math.min(100, Math.max(8, (item.value / maxVal) * 100));
          return (
            <div key={idx} className="flex-1 flex flex-col items-center h-full justify-end group relative">
              {/* Tooltip */}
              <div className="absolute -top-7 opacity-0 group-hover:opacity-100 transition-opacity bg-slate-900 border border-slate-700 text-[10px] text-white px-1.5 py-0.5 rounded font-mono z-10 whitespace-nowrap shadow">
                {formatValue(item.value)}
              </div>

              {/* Bar */}
              <div
                className="w-full max-w-[36px] rounded-t transition-all duration-300 group-hover:brightness-125"
                style={{
                  height: `${heightPct}%`,
                  backgroundColor: primaryColor,
                }}
              />

              {/* Label */}
              <span className="text-[10px] font-mono text-slate-400 mt-2 truncate w-full text-center">
                {item.label}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};
