/**
 * Russian Financial & Date Formatting Utilities
 * Strictly conforms to Russian financial system guidelines:
 * - Space separated thousands (1 284 580)
 * - Comma decimal separator (,00)
 * - Ruble symbol prefix/suffix (₽ 1 284 580,00 / 1 284 580 ₽)
 */

export function formatRuble(
  amount: number,
  format: 'prefix' | 'suffix' | 'plain' = 'prefix',
  includeDecimals: boolean = true
): string {
  const isNegative = amount < 0;
  const absVal = Math.abs(amount);

  const parts = absVal.toFixed(includeDecimals ? 2 : 0).split('.');
  const integerPart = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
  const decimalPart = parts[1] ? `,${parts[1]}` : '';

  const formattedNum = `${integerPart}${decimalPart}`;
  const sign = isNegative ? '-' : '';

  if (format === 'prefix') {
    return `${sign}₽ ${formattedNum}`;
  } else if (format === 'suffix') {
    return `${sign}${formattedNum} ₽`;
  }
  return `${sign}${formattedNum}`;
}

export function formatNumber(num: number): string {
  return Math.floor(num).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
}

export function formatDate(dateInput: string | Date = new Date()): string {
  const d = typeof dateInput === 'string' ? new Date(dateInput) : dateInput;
  if (isNaN(d.getTime())) return dateInput.toString();
  const day = String(d.getDate()).padStart(2, '0');
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const year = d.getFullYear();
  return `${day}.${month}.${year}`;
}

export function formatTime(dateInput: string | Date = new Date()): string {
  const d = typeof dateInput === 'string' ? new Date(dateInput) : dateInput;
  if (isNaN(d.getTime())) return '00:00:00';
  const hours = String(d.getHours()).padStart(2, '0');
  const minutes = String(d.getMinutes()).padStart(2, '0');
  const seconds = String(d.getSeconds()).padStart(2, '0');
  return `${hours}:${minutes}:${seconds}`;
}

export function formatDateTime(dateInput: string | Date = new Date()): string {
  return `${formatDate(dateInput)} ${formatTime(dateInput)}`;
}

/**
 * Truncates string ID for display e.g. 4081...2345
 */
export function formatCompactId(id: string, startLen = 6, endLen = 4): string {
  if (id.length <= startLen + endLen) return id;
  return `${id.slice(0, startLen)}...${id.slice(-endLen)}`;
}
