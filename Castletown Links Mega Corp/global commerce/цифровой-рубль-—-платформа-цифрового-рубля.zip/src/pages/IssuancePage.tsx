import React, { useState } from 'react';
import { useSimulation } from '../simulation/SimulationContext';
import { StatCard } from '../components/common/StatCard';
import { formatRuble } from '../utils/formatters';
import { Coins, ArrowRight, CheckCircle2, Landmark, RefreshCw } from 'lucide-react';

export const IssuancePage: React.FC = () => {
  const {
    totalCirculation,
    totalIssued,
    totalRedeemed,
    issuanceOps,
    institutions,
    executeIssuance,
  } = useSimulation();

  const [type, setType] = useState<'ISSUANCE' | 'REDEMPTION'>('ISSUANCE');
  const [bankId, setBankId] = useState('BANK-02');
  const [amount, setAmount] = useState('5000000000');
  const [basis, setBasis] = useState('Депонирование безотзывных средств коммерческого банка');
  const [resultMsg, setResultMsg] = useState<{ text: string; success: boolean } | null>(null);

  const selectedBank = institutions.find((i) => i.id === bankId) || institutions[0];

  const handleSimulate = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmt = parseFloat(amount);
    if (isNaN(numAmt) || numAmt <= 0) return;

    const res = executeIssuance(numAmt, bankId, basis, type);
    setResultMsg({ text: res.message, success: res.success });
  };

  const lifecycleSteps = [
    'БАНК РОССИИ',
    'ВЫПУСК (ЭМИССИЯ)',
    'ПЛАТФОРМА ЦР',
    'СЧЕТ ЦИФРОВОГО РУБЛЯ',
    'ПЛАТЕЖ / ПЕРЕВОД',
    'МЕЖБАНКОВСКИЙ РАСЧЕТ',
    'ПОГАШЕНИЕ',
  ];

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-[#121929] border border-blue-900/60 rounded-xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-white uppercase font-mono tracking-wider">
            ВЫПУСК И ПОГАШЕНИЕ ЦИФРОВЫХ РУБЛЕЙ (ЭМИССИОННЫЙ ЦЕНТР)
          </h2>
          <p className="text-xs text-slate-300 mt-0.5">
            Монопольное право эмиссии цифрового рубля принадлежит Банку России. Выпуск производится против списания безналичных средств.
          </p>
        </div>
        <span className="text-xs font-mono text-emerald-400 bg-emerald-950 border border-emerald-800 px-3 py-1 rounded">
          ЭМИССИЯ АКТИВНА
        </span>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <StatCard
          title="Объем в обращении"
          value={formatRuble(totalCirculation)}
          subtitle="Текущий чистый объем ЦР"
          accent="emerald"
          isSimulatedBadge
        />
        <StatCard
          title="Всего выпущено (Эмиссия)"
          value={formatRuble(totalIssued)}
          subtitle="Накопленный объем эмиссии"
          accent="blue"
          isSimulatedBadge
        />
        <StatCard
          title="Всего погашено (Изъятие)"
          value={formatRuble(totalRedeemed)}
          subtitle="Возвращено на корсчета ЦБ"
          accent="amber"
          isSimulatedBadge
        />
      </div>

      {/* Lifecycle Flowchart */}
      <div className="bg-[#121824] border border-slate-800 rounded-xl p-5 shadow-sm">
        <h3 className="text-xs font-bold text-slate-300 uppercase font-mono tracking-wider mb-4">
          ЖИЗНЕННЫЙ ЦИКЛ ЦИФРОВОГО РУБЛЯ (ISSUANCE LIFECYCLE)
        </h3>

        <div className="flex flex-wrap items-center justify-between gap-2 bg-[#0d121c] p-4 rounded-lg border border-slate-800">
          {lifecycleSteps.map((step, idx) => (
            <React.Fragment key={idx}>
              <div className="bg-[#161d2e] border border-slate-700 px-3 py-2 rounded text-center text-xs font-mono font-bold text-white">
                {step}
              </div>
              {idx < lifecycleSteps.length - 1 && (
                <ArrowRight className="w-4 h-4 text-blue-500 hidden sm:block flex-shrink-0" />
              )}
            </React.Fragment>
          ))}
        </div>
      </div>

      {/* Interactive Simulator Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Form Input */}
        <div className="bg-[#121824] border border-slate-800 rounded-xl p-5 shadow-sm">
          <h3 className="text-sm font-bold text-white uppercase font-mono tracking-wider pb-3 border-b border-slate-800 mb-4">
            СИМУЛЯТОР ЭМИССИОННЫХ ОПЕРАЦИЙ
          </h3>

          <form onSubmit={handleSimulate} className="space-y-4 font-mono text-xs">
            <div>
              <label className="block text-slate-300 mb-1">Вид эмиссионной операции</label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setType('ISSUANCE')}
                  className={`p-2.5 rounded border font-bold text-center transition-colors ${
                    type === 'ISSUANCE'
                      ? 'bg-blue-600 border-blue-500 text-white'
                      : 'bg-[#161c2c] border-slate-700 text-slate-400 hover:text-white'
                  }`}
                >
                  ВЫПУСК (ЭМИССИЯ)
                </button>
                <button
                  type="button"
                  onClick={() => setType('REDEMPTION')}
                  className={`p-2.5 rounded border font-bold text-center transition-colors ${
                    type === 'REDEMPTION'
                      ? 'bg-amber-600 border-amber-500 text-white'
                      : 'bg-[#161c2c] border-slate-700 text-slate-400 hover:text-white'
                  }`}
                >
                  ПОГАШЕНИЕ (ИЗЪЯТИЕ)
                </button>
              </div>
            </div>

            <div>
              <label className="block text-slate-300 mb-1">Банк — Получатель эмиссии</label>
              <select
                value={bankId}
                onChange={(e) => setBankId(e.target.value)}
                className="w-full bg-[#161c2c] border border-slate-700 rounded p-2.5 text-white"
              >
                {institutions
                  .filter((i) => i.type !== 'CENTRAL_BANK')
                  .map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.name} (Остаток ликвидности: {formatRuble(b.liquidityPosition)})
                    </option>
                  ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-300 mb-1">Сумма операции (₽)</label>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full bg-[#161c2c] border border-slate-700 rounded p-2.5 text-white"
                required
              />
            </div>

            <div>
              <label className="block text-slate-300 mb-1">Правовое и учетное основание</label>
              <input
                type="text"
                value={basis}
                onChange={(e) => setBasis(e.target.value)}
                className="w-full bg-[#161c2c] border border-slate-700 rounded p-2.5 text-white"
                required
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded uppercase tracking-wider transition-colors shadow"
            >
              ИСПОЛНИТЬ ЭМИССИОННУЮ ТРАНЗАКЦИЮ
            </button>
          </form>

          {resultMsg && (
            <div
              className={`mt-4 p-3 rounded border text-xs font-mono ${
                resultMsg.success
                  ? 'bg-emerald-950/80 text-emerald-300 border-emerald-800'
                  : 'bg-rose-950/80 text-rose-300 border-rose-800'
              }`}
            >
              {resultMsg.text}
            </div>
          )}
        </div>

        {/* Live Ledger Preview */}
        <div className="bg-[#121824] border border-slate-800 rounded-xl p-5 shadow-sm flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-white uppercase font-mono tracking-wider pb-3 border-b border-slate-800 mb-4">
              РАСЧЕТНЫЙ БАЛАНС УЧАСТНИКА
            </h3>

            <div className="space-y-3 font-mono text-xs">
              <div className="bg-[#161c2c] p-3 rounded border border-slate-800">
                <span className="text-slate-400 block text-[10px]">УЧАСТНИК ПЛАТФОРМЫ</span>
                <span className="text-sm font-bold text-white mt-0.5 block">{selectedBank.name}</span>
                <span className="text-[10px] text-slate-500">БИК: {selectedBank.bik}</span>
              </div>

              <div className="bg-[#161c2c] p-3 rounded border border-slate-800">
                <span className="text-slate-400 block text-[10px]">ОСТАТОК ДО ОПЕРАЦИИ</span>
                <span className="text-base font-bold text-slate-200 mt-0.5 block">
                  {formatRuble(selectedBank.liquidityPosition)}
                </span>
              </div>

              <div className="bg-[#161c2c] p-3 rounded border border-slate-800">
                <span className="text-slate-400 block text-[10px]">СУММА ЭМИССИОННОГО ИЗМЕНЕНИЯ</span>
                <span
                  className={`text-base font-bold mt-0.5 block ${
                    type === 'ISSUANCE' ? 'text-emerald-400' : 'text-amber-400'
                  }`}
                >
                  {type === 'ISSUANCE' ? '+' : '-'}{formatRuble(parseFloat(amount) || 0)}
                </span>
              </div>

              <div className="bg-[#161c2c] p-3 rounded border border-slate-800">
                <span className="text-slate-400 block text-[10px]">РАСЧЕТНЫЙ ОСТАТОК ПОСЛЕ ОПЕРАЦИИ</span>
                <span className="text-base font-bold text-blue-400 mt-0.5 block">
                  {formatRuble(
                    type === 'ISSUANCE'
                      ? selectedBank.liquidityPosition + (parseFloat(amount) || 0)
                      : selectedBank.liquidityPosition - (parseFloat(amount) || 0)
                  )}
                </span>
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800 text-[10px] text-slate-500 font-mono text-center mt-4">
            АВТОМАТИЧЕСКАЯ ЗАПИСЬ В ЦЕНТРАЛЬНЫЙ РЕЕСТР БАНКА РОССИИ
          </div>
        </div>
      </div>

      {/* Issuance Operations History Log */}
      <div className="bg-[#121824] border border-slate-800 rounded-xl p-5 shadow-sm">
        <h3 className="text-sm font-bold text-white uppercase font-mono tracking-wider pb-3 border-b border-slate-800 mb-4">
          ИСТОРИЯ ОПЕРАЦИЙ ВЫПУСКА И ПОГАШЕНИЯ
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px]">
                <th className="py-2.5 px-3">ID Операции</th>
                <th className="py-2.5 px-3">Тип</th>
                <th className="py-2.5 px-3">Дата</th>
                <th className="py-2.5 px-3">Участник</th>
                <th className="py-2.5 px-3">Основание</th>
                <th className="py-2.5 px-3">Сумма (₽)</th>
                <th className="py-2.5 px-3">Статус</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {issuanceOps.map((op) => (
                <tr key={op.id} className="hover:bg-slate-800/40">
                  <td className="py-2.5 px-3 font-bold text-blue-400">{op.id}</td>
                  <td className="py-2.5 px-3 whitespace-nowrap">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] ${
                        op.type === 'ISSUANCE'
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : 'bg-amber-950 text-amber-300 border border-amber-800'
                      }`}
                    >
                      {op.type === 'ISSUANCE' ? 'ВЫПУСК' : 'ПОГАШЕНИЕ'}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-slate-400 whitespace-nowrap">{op.date}</td>
                  <td className="py-2.5 px-3 font-semibold">{op.participantName}</td>
                  <td className="py-2.5 px-3 text-slate-300 max-w-xs truncate">{op.basis}</td>
                  <td className="py-2.5 px-3 font-bold whitespace-nowrap">
                    {formatRuble(op.amount)}
                  </td>
                  <td className="py-2.5 px-3 text-emerald-400 font-bold">ИСПОЛНЕНО</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
