import React, { useState } from 'react';
import { useSimulation } from '../simulation/SimulationContext';
import { formatRuble } from '../utils/formatters';
import { Code2, Play, CheckCircle2, ShieldAlert, Sparkles, Lock, ArrowRight } from 'lucide-react';

export const ProgrammablePage: React.FC = () => {
  const { smartContracts, executeSmartContract } = useSimulation();

  const [selectedContractId, setSelectedContractId] = useState(smartContracts[0]?.id || '');
  const [executionLog, setExecutionLog] = useState<string | null>(null);

  const selectedContract = smartContracts.find((c) => c.id === selectedContractId) || smartContracts[0];

  const handleRunContract = () => {
    const res = executeSmartContract(selectedContract.id);
    setExecutionLog(res.message);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-[#121929] border border-blue-900/60 rounded-xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-white uppercase font-mono tracking-wider">
            УМНЫЕ КОНТРАКТЫ И ПРОГРАММИРУЕМЫЕ ПЛАТЕЖИ (PROGRAMMABLE MONEY)
          </h2>
          <p className="text-xs text-slate-300 mt-0.5">
            Использование цифрового рубля с заранее запрограммированными условиями: окрашивание бюджетных средств, безопасные эскроу-сделки и автоналоги.
          </p>
        </div>
        <span className="text-xs font-mono text-indigo-400 bg-indigo-950 border border-indigo-800 px-3 py-1.5 rounded font-bold">
          SMART CONTRACT ENGINE
        </span>
      </div>

      {/* Contracts Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 font-mono text-xs">
        {smartContracts.map((sc) => (
          <div
            key={sc.id}
            onClick={() => {
              setSelectedContractId(sc.id);
              setExecutionLog(null);
            }}
            className={`p-5 rounded-xl border cursor-pointer transition-all ${
              selectedContractId === sc.id
                ? 'bg-indigo-950/40 border-indigo-500 shadow-lg ring-1 ring-indigo-500'
                : 'bg-[#121824] border-slate-800 hover:border-slate-700'
            }`}
          >
            <div className="flex items-start justify-between gap-2">
              <span className="font-bold text-blue-400 text-sm">{sc.title}</span>
              <span
                className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                  sc.status === 'WAITING_CONDITION'
                    ? 'bg-amber-950 text-amber-300 border border-amber-800'
                    : 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                }`}
              >
                {sc.status === 'WAITING_CONDITION' ? 'ОЖИДАЕТ УСЛОВИЯ' : 'ИСПОЛНЕН'}
              </span>
            </div>

            <p className="text-slate-300 mt-2 font-sans text-xs">{sc.conditionDesc}</p>

            <div className="bg-[#0e131e] p-3 rounded-lg border border-slate-800/80 mt-3 space-y-1.5 text-[11px]">
              <div className="flex justify-between text-slate-400">
                <span>Заблокированная сумма:</span>
                <span className="text-emerald-400 font-bold">{formatRuble(sc.amount)}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Условие расходования:</span>
                <span className="text-indigo-300">{sc.conditionType}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Selected Contract Execution Console */}
      <div className="bg-[#121824] border border-slate-800 rounded-xl p-6 shadow-sm font-mono text-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-3">
          <div>
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">
              КОНСОЛЬ ИСПОЛНЕНИЯ КОНТРАКТА: {selectedContract.id}
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">{selectedContract.title}</p>
          </div>

          <button
            onClick={handleRunContract}
            className="inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold px-4 py-2 rounded-lg transition-colors shadow"
          >
            <Play className="w-4 h-4 fill-white" />
            <span>СИМУЛИРОВАТЬ ИСПОЛНЕНИЕ УСЛОВИЯ</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-[#0f1420] p-4 rounded-lg border border-slate-800 space-y-2">
            <span className="text-slate-400 text-[10px] block uppercase">КОД УСЛОВИЯ И ОКРАШИВАНИЯ (CONTRACT LOGIC)</span>
            <pre className="text-emerald-400 text-[11px] font-mono leading-relaxed bg-[#070a10] p-3 rounded border border-slate-900 overflow-x-auto">
{`// Окрашивание целевого назначения
function verifySpendingTag(tx) {
  if (tx.purposeType !== "${selectedContract.conditionType}") {
    revert("Нарушение целевого назначения средств!");
  }
  return true;
}`}
            </pre>
          </div>

          <div className="bg-[#0f1420] p-4 rounded-lg border border-slate-800 space-y-2 flex flex-col justify-between">
            <div>
              <span className="text-slate-400 text-[10px] block uppercase">ЖУРНАЛ ИСПОЛНЕНИЯ (EXECUTION CONSOLE)</span>
              {executionLog ? (
                <div className="p-3 bg-emerald-950/80 border border-emerald-800 text-emerald-300 rounded mt-2">
                  {executionLog}
                </div>
              ) : (
                <div className="text-slate-500 text-center py-8">
                  Нажмите кнопку симуляции выше для проверки триггера умного контракта
                </div>
              )}
            </div>

            <div className="text-[10px] text-slate-500 pt-2 border-t border-slate-800 text-center">
              АВТОМАТИЧЕСКАЯ БЕЗОПАСНАЯ СДЕЛЬНАЯ ГАРАНТИЯ БАНКА РОССИИ
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
