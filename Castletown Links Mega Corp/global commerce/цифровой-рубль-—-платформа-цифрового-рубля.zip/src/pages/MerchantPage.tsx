import React, { useState } from 'react';
import { useSimulation } from '../simulation/SimulationContext';
import { formatRuble, formatNumber } from '../utils/formatters';
import { Store, QrCode, CreditCard, Percent, ArrowRight, CheckCircle2 } from 'lucide-react';

export const MerchantPage: React.FC = () => {
  const { merchants, accounts, executePayment } = useSimulation();

  const [selectedMerchantId, setSelectedMerchantId] = useState(merchants[0]?.id || '');
  const [billAmount, setBillAmount] = useState('1850');
  const [payerAccId, setPayerAccId] = useState(accounts[0]?.id || '');
  const [qrGenerated, setQrGenerated] = useState(false);
  const [payMsg, setPayMsg] = useState('');

  const merchant = merchants.find((m) => m.id === selectedMerchantId) || merchants[0];
  const parsedAmt = parseFloat(billAmount) || 0;
  const fee03 = parsedAmt * 0.003;
  const netSettlement = parsedAmt - fee03;

  const handleGenerateQr = (e: React.FormEvent) => {
    e.preventDefault();
    setQrGenerated(true);
    setPayMsg('');
  };

  const handleSimulateQrPayment = () => {
    const res = executePayment({
      payerAccountId: payerAccId,
      recipientAccountId: merchant.id,
      amount: parsedAmt,
      purpose: `Оплата чека ТСП ${merchant.name} по QR-коду (Комиссия 0.3%)`,
      method: 'QR',
    });

    setPayMsg(res.message);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-[#121929] border border-blue-900/60 rounded-xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-white uppercase font-mono tracking-wider">
            ТОРГОВО-СЕРВИСНАЯ СЕТЬ (ТСП) И СВЕРХЭКОНОМИЧНЫЙ ЭКВАЙРИНГ
          </h2>
          <p className="text-xs text-slate-300 mt-0.5">
            Законодательно установленный тариф комиссии эквайринга в цифровых рублях составляет не более 0,3% (против 2.5–3.0% в классических картах).
          </p>
        </div>
        <div className="text-xs font-mono text-emerald-400 bg-emerald-950 border border-emerald-800 px-3 py-1.5 rounded font-bold">
          ТАРИФ ЭКВАЙРИНГА: 0.3%
        </div>
      </div>

      {/* Interactive POS Terminal Simulator */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Terminal Input */}
        <div className="bg-[#121824] border border-slate-800 rounded-xl p-5 shadow-sm">
          <h3 className="text-sm font-bold text-white uppercase font-mono tracking-wider pb-3 border-b border-slate-800 mb-4">
            ТЕРМИНАЛ ОПЛАТЫ ТСП (POS SIMULATOR)
          </h3>

          <form onSubmit={handleGenerateQr} className="space-y-4 font-mono text-xs">
            <div>
              <label className="block text-slate-300 mb-1">Выбор торгового предприятия (ТСП)</label>
              <select
                value={selectedMerchantId}
                onChange={(e) => {
                  setSelectedMerchantId(e.target.value);
                  setQrGenerated(false);
                }}
                className="w-full bg-[#161c2c] border border-slate-700 rounded p-2.5 text-white"
              >
                {merchants.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.name} ({m.category}) — {m.id}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-300 mb-1">Сумма чека (покупки) ₽</label>
              <input
                type="number"
                value={billAmount}
                onChange={(e) => {
                  setBillAmount(e.target.value);
                  setQrGenerated(false);
                }}
                className="w-full bg-[#161c2c] border border-slate-700 rounded p-2.5 text-white"
                required
              />
            </div>

            {/* Tariff Breakdown Box */}
            <div className="bg-[#0f1420] p-3 rounded border border-slate-800 space-y-1.5 text-[11px]">
              <div className="flex justify-between text-slate-400">
                <span>Стандартная комиссия карт (2.5%):</span>
                <span className="line-through text-rose-400">{formatRuble(parsedAmt * 0.025)}</span>
              </div>
              <div className="flex justify-between text-emerald-400 font-bold">
                <span>Комиссия ЦР (0.3% max):</span>
                <span>{formatRuble(fee03)}</span>
              </div>
              <div className="flex justify-between text-white font-bold pt-1 border-t border-slate-800">
                <span>Зачисление на счет ТСП:</span>
                <span>{formatRuble(netSettlement)}</span>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded uppercase tracking-wider transition-colors shadow"
            >
              СФОРМИРОВАТЬ ДИНАМИЧЕСКИЙ QR-КОД
            </button>
          </form>
        </div>

        {/* Dynamic QR Display & Execution */}
        <div className="bg-[#121824] border border-slate-800 rounded-xl p-5 shadow-sm flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-white uppercase font-mono tracking-wider pb-3 border-b border-slate-800 mb-4">
              ЭКРАН ПОКУПАТЕЛЯ / QR ДИСПЛЕЙ
            </h3>

            {qrGenerated ? (
              <div className="text-center space-y-4 font-mono">
                <div className="w-48 h-48 mx-auto bg-white p-3 rounded-xl flex items-center justify-center shadow">
                  <div className="w-full h-full border-4 border-slate-900 flex flex-col items-center justify-center font-bold text-slate-900 text-xs">
                    <span>[QR ЦИФРОВОЙ РУБЛЬ]</span>
                    <span className="mt-2 text-blue-600 text-sm font-extrabold">
                      {formatRuble(parsedAmt)}
                    </span>
                  </div>
                </div>

                <div className="bg-[#161c2c] p-3 rounded border border-slate-800 text-xs text-left space-y-2">
                  <label className="block text-slate-400 text-[10px]">
                    Выберите счет плательщика для симуляции сканирования:
                  </label>
                  <select
                    value={payerAccId}
                    onChange={(e) => setPayerAccId(e.target.value)}
                    className="w-full bg-[#0f1420] border border-slate-700 rounded p-2 text-white"
                  >
                    {accounts.map((acc) => (
                      <option key={acc.id} value={acc.id}>
                        {acc.ownerName} ({formatRuble(acc.availableBalance)})
                      </option>
                    ))}
                  </select>

                  <button
                    onClick={handleSimulateQrPayment}
                    className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded uppercase mt-2 transition-colors"
                  >
                    ОПЛАТИТЬ СКАНЕРОМ В ПРИЛОЖЕНИИ
                  </button>
                </div>

                {payMsg && (
                  <div className="p-3 bg-emerald-950 border border-emerald-800 text-emerald-300 text-xs rounded">
                    {payMsg}
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center text-slate-500 font-mono text-xs py-12">
                Сформируйте динамический QR-код чека на терминале слева
              </div>
            )}
          </div>

          <div className="pt-3 border-t border-slate-800 text-[10px] text-slate-500 font-mono text-center mt-4">
            МГНОВЕННЫЙ РАСЧЕТ И ЗАЧИСЛЕНИЕ СРЕДСТВ НА СЧЕТ ТСП В ЦЕНТРАЛЬНОМ РЕЕСТРЕ
          </div>
        </div>
      </div>

      {/* Merchant Registry Table */}
      <div className="bg-[#121824] border border-slate-800 rounded-xl p-5 shadow-sm">
        <h3 className="text-sm font-bold text-white uppercase font-mono tracking-wider pb-3 border-b border-slate-800 mb-4">
          РЕЕСТР ПОДКЛЮЧЕННЫХ ТОРГОВО-СЕРВИСНЫХ ПРЕДПРИЯТИЙ
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px]">
                <th className="py-2.5 px-3">Идентификатор ТСП</th>
                <th className="py-2.5 px-3">Наименование</th>
                <th className="py-2.5 px-3">ИНН</th>
                <th className="py-2.5 px-3">Категория</th>
                <th className="py-2.5 px-3">Обслуживающий банк</th>
                <th className="py-2.5 px-3">Эквайринг комиссия</th>
                <th className="py-2.5 px-3">Статус</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {merchants.map((m) => (
                <tr key={m.id} className="hover:bg-slate-800/40">
                  <td className="py-2.5 px-3 font-bold text-blue-400">{m.id}</td>
                  <td className="py-2.5 px-3 font-semibold text-white">{m.name}</td>
                  <td className="py-2.5 px-3 text-slate-400">{m.taxId}</td>
                  <td className="py-2.5 px-3 text-slate-300">{m.category}</td>
                  <td className="py-2.5 px-3 text-slate-400">{m.bankName}</td>
                  <td className="py-2.5 px-3 font-bold text-emerald-400">0.3%</td>
                  <td className="py-2.5 px-3 whitespace-nowrap">
                    <span className="px-2 py-0.5 bg-emerald-950 text-emerald-300 border border-emerald-800 rounded text-[10px]">
                      ПОДКЛЮЧЕНО
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
