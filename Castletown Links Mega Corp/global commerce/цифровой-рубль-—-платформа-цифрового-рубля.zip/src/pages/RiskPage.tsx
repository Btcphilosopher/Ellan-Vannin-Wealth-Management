import React from 'react';
import { useSimulation } from '../simulation/SimulationContext';
import { ShieldAlert, AlertOctagon, CheckCircle2, Lock } from 'lucide-react';

export const RiskPage: React.FC = () => {
  const { riskAlerts } = useSimulation();

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-[#121929] border border-blue-900/60 rounded-xl p-4 flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-white uppercase font-mono tracking-wider">
            ЦЕНТР АВТОМАТИЗИРОВАННОГО РИСК-КОНТРОЛЯ И ФИНМОНИТОРИНГА
          </h2>
          <p className="text-xs text-slate-300 mt-0.5">
            Проверка транзакций на аномалии, превышение лимитов и финмониторинг (ПОД/ФТ) в режиме real-time.
          </p>
        </div>
        <span className="text-xs font-mono text-rose-400 bg-rose-950 border border-rose-800 px-3 py-1.5 rounded font-bold">
          РИСК-ДВИЖОК АКТИВЕН
        </span>
      </div>

      {/* Control Events List */}
      <div className="bg-[#121824] border border-slate-800 rounded-xl p-5 shadow-sm">
        <h3 className="text-sm font-bold text-white uppercase font-mono tracking-wider pb-3 border-b border-slate-800 mb-4">
          ЖУРНАЛ ТРЕВОГ И РИСК-СОБЫТИЙ (RISK EVENTS LOG)
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px]">
                <th className="py-2.5 px-3">Время</th>
                <th className="py-2.5 px-3">ID События</th>
                <th className="py-2.5 px-3">Уровень риска</th>
                <th className="py-2.5 px-3">Плательщик</th>
                <th className="py-2.5 px-3">Описание аномалии</th>
                <th className="py-2.5 px-3">Реакция системы</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {riskAlerts.map((ev) => (
                <tr key={ev.id} className="hover:bg-slate-800/40">
                  <td className="py-2.5 px-3 text-slate-400 whitespace-nowrap">{ev.timestamp}</td>
                  <td className="py-2.5 px-3 font-bold text-blue-400">{ev.id}</td>
                  <td className="py-2.5 px-3 whitespace-nowrap">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        ev.severity === 'CRITICAL'
                          ? 'bg-rose-950 text-rose-300 border border-rose-800'
                          : ev.severity === 'WARNING'
                          ? 'bg-amber-950 text-amber-300 border border-amber-800'
                          : 'bg-blue-950 text-blue-300 border border-blue-800'
                      }`}
                    >
                      {ev.severity}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 font-semibold text-slate-300">{ev.payerName}</td>
                  <td className="py-2.5 px-3 text-slate-200 max-w-sm">{ev.reason}</td>
                  <td className="py-2.5 px-3 text-emerald-400 font-bold">
                    {ev.status === 'REQUIRES_CHECK' ? 'ПРИОСТАНОВЛЕНО ДЛЯ ПРОВЕРКИ' : 'ПОДТВЕРЖДЕНО'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
