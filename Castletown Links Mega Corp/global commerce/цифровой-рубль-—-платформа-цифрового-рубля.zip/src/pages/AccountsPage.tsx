import React, { useState } from 'react';
import { useSimulation } from '../simulation/SimulationContext';
import { DigitalRubleAccount } from '../types';
import { formatRuble, formatCompactId } from '../utils/formatters';
import { Wallet, Search, Filter, Lock, Unlock, ArrowUpRight, History } from 'lucide-react';

export const AccountsPage: React.FC = () => {
  const { accounts, toggleAccountStatus, transactions } = useSimulation();

  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('ALL');
  const [selectedAccHistory, setSelectedAccHistory] = useState<DigitalRubleAccount | null>(null);

  const filteredAccounts = accounts.filter((acc) => {
    const matchesSearch =
      acc.id.includes(search) ||
      acc.ownerName.toLowerCase().includes(search.toLowerCase()) ||
      acc.ownerTaxId.includes(search);

    const matchesType = typeFilter === 'ALL' || acc.type === typeFilter;

    return matchesSearch && matchesType;
  });

  const getAccountHistory = (accId: string) => {
    return transactions.filter(
      (t) => t.payerAccountId === accId || t.recipientAccountId === accId
    );
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-[#121929] border border-blue-900/60 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-white uppercase font-mono tracking-wider">
            УПРАВЛЕНИЕ СЧЕТАМИ ЦИФРОВОГО РУБЛЯ
          </h2>
          <p className="text-xs text-slate-300 mt-0.5">
            Счета открываются гражданам и юридическим лицам на центральной платформе Банка России.
          </p>
        </div>
        <div className="text-xs font-mono text-slate-300 bg-slate-900 px-3 py-1.5 rounded border border-slate-800">
          ВСЕГО СЧЕТОВ В РЕЕСТРЕ: <span className="text-blue-400 font-bold">{accounts.length}</span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-[#121824] border border-slate-800 rounded-xl p-4 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Поиск по номеру счета, ФИО или ИНН..."
            className="w-full bg-[#161c2c] border border-slate-700 rounded-lg pl-9 pr-3 py-2 text-xs font-mono text-white placeholder-slate-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto font-mono text-xs">
          <Filter className="w-4 h-4 text-slate-500" />
          <span className="text-slate-400">Тип счета:</span>
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="bg-[#161c2c] border border-slate-700 rounded-lg px-3 py-1.5 text-white"
          >
            <option value="ALL">Все категории</option>
            <option value="INDIVIDUAL">Счет физического лица</option>
            <option value="BUSINESS">Счет организации</option>
            <option value="SOLE_TRADER">Счет ИП</option>
          </select>
        </div>
      </div>

      {/* Main Accounts Table */}
      <div className="bg-[#121824] border border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px]">
                <th className="py-3 px-3">Номер счета</th>
                <th className="py-3 px-3">Владелец / ИНН</th>
                <th className="py-3 px-3">Тип</th>
                <th className="py-3 px-3">Банк-участник</th>
                <th className="py-3 px-3">Баланс (₽)</th>
                <th className="py-3 px-3">Доступный остаток</th>
                <th className="py-3 px-3">Статус</th>
                <th className="py-3 px-3">Действия</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {filteredAccounts.map((acc) => (
                <tr key={acc.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3 px-3 font-bold text-blue-400 whitespace-nowrap">
                    {acc.id}
                  </td>
                  <td className="py-3 px-3">
                    <div className="font-semibold text-white">{acc.ownerName}</div>
                    <div className="text-[10px] text-slate-500">ИНН: {acc.ownerTaxId}</div>
                  </td>
                  <td className="py-3 px-3 whitespace-nowrap">
                    <span className="text-[10px] text-slate-300 bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
                      {acc.type === 'INDIVIDUAL'
                        ? 'Физ.лицо'
                        : acc.type === 'BUSINESS'
                        ? 'Юр.лицо'
                        : 'ИП'}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-slate-300 max-w-xs truncate">{acc.bankName}</td>
                  <td className="py-3 px-3 font-bold text-white whitespace-nowrap">
                    {formatRuble(acc.balance)}
                  </td>
                  <td className="py-3 px-3 font-semibold text-emerald-400 whitespace-nowrap">
                    {formatRuble(acc.availableBalance)}
                  </td>
                  <td className="py-3 px-3 whitespace-nowrap">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        acc.status === 'ACTIVE'
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : 'bg-rose-950 text-rose-300 border border-rose-800'
                      }`}
                    >
                      {acc.status === 'ACTIVE' ? 'АКТИВЕН' : 'ЗАБЛОКИРОВАН'}
                    </span>
                  </td>
                  <td className="py-3 px-3 whitespace-nowrap">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setSelectedAccHistory(acc)}
                        className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded"
                        title="История операций"
                      >
                        <History className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={() => toggleAccountStatus(acc.id)}
                        className={`p-1.5 rounded transition-colors ${
                          acc.status === 'ACTIVE'
                            ? 'text-rose-400 hover:bg-rose-950/80'
                            : 'text-emerald-400 hover:bg-emerald-950/80'
                        }`}
                        title={acc.status === 'ACTIVE' ? 'Заблокировать счет' : 'Разблокировать счет'}
                      >
                        {acc.status === 'ACTIVE' ? (
                          <Lock className="w-3.5 h-3.5" />
                        ) : (
                          <Unlock className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Account History Modal */}
      {selectedAccHistory && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className="bg-[#111622] border border-slate-700 rounded-xl p-5 max-w-2xl w-full max-h-[80vh] overflow-y-auto space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <h3 className="text-sm font-bold text-white uppercase font-mono">
                  ИСТОРИЯ ОПЕРАЦИЙ ПО СЧЕТУ
                </h3>
                <p className="text-xs text-slate-400 font-mono">
                  {selectedAccHistory.ownerName} ({selectedAccHistory.id})
                </p>
              </div>
              <button
                onClick={() => setSelectedAccHistory(null)}
                className="text-slate-400 hover:text-white text-xs font-mono bg-slate-800 px-2 py-1 rounded"
              >
                Закрыть
              </button>
            </div>

            <div className="space-y-2">
              {getAccountHistory(selectedAccHistory.id).length === 0 ? (
                <div className="text-xs text-slate-500 font-mono text-center py-6">
                  Нет записей по данному счету в текущей сессии
                </div>
              ) : (
                getAccountHistory(selectedAccHistory.id).map((t) => (
                  <div
                    key={t.id}
                    className="p-3 bg-[#161c2c] border border-slate-800 rounded font-mono text-xs flex items-center justify-between"
                  >
                    <div>
                      <div className="font-bold text-white">{t.purpose}</div>
                      <div className="text-[10px] text-slate-500 mt-0.5">
                        {t.timestamp} | {t.id}
                      </div>
                    </div>
                    <div
                      className={`text-sm font-bold ${
                        t.payerAccountId === selectedAccHistory.id
                          ? 'text-rose-400'
                          : 'text-emerald-400'
                      }`}
                    >
                      {t.payerAccountId === selectedAccHistory.id ? '-' : '+'}
                      {formatRuble(t.amount)}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
