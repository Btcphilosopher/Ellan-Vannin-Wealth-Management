import React from 'react';
import { useSimulation } from '../simulation/SimulationContext';
import { RussiaMapSvg } from '../components/charts/RussiaMapSvg';
import { SimpleLineChart } from '../components/charts/SimpleLineChart';
import { StatCard } from '../components/common/StatCard';
import { formatRuble, formatNumber } from '../utils/formatters';
import { BarChart3, TrendingUp, Globe, Coins, Shield } from 'lucide-react';

export const AnalyticsPage: React.FC = () => {
  const { regionalData, totalCirculation, todayOpsVolume, todayOpsCount } = useSimulation();

  const velocityData = [
    { label: 'Пн', value: 1.12 },
    { label: 'Вт', value: 1.24 },
    { label: 'Ср', value: 1.38 },
    { label: 'Чт', value: 1.45 },
    { label: 'Пт', value: 1.62 },
  ];

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-[#121929] border border-blue-900/60 rounded-xl p-4 flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-white uppercase font-mono tracking-wider">
            НАЦИОНАЛЬНАЯ АНАЛИТИКА И МАКРОЭКОНОМИЧЕСКИЙ МОНИТОРИНГ
          </h2>
          <p className="text-xs text-slate-300 mt-0.5">
            Анализ распределения ликвидности цифрового рубля по субъектам Российской Федерации.
          </p>
        </div>
        <span className="text-xs font-mono text-emerald-400 bg-emerald-950 border border-emerald-800 px-3 py-1.5 rounded font-bold">
          АНАЛИТИКА ЦБ РОССИИ
        </span>
      </div>

      {/* Russia Map */}
      <RussiaMapSvg regions={regionalData} />

      {/* Macro Indicators Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <StatCard
          title="Скорость обращения ЦР (Velocity)"
          value="1.62 об/мес"
          subtitle="Коэффициент оборачиваемости"
          change="+0.14 с прошлого месяца"
          changeType="positive"
          accent="blue"
          isSimulatedBadge
        />

        <StatCard
          title="Доля ЦР в денежной массе М2"
          value="4.85%"
          subtitle="Параллельно наличным и безналичным"
          change="Рост доли в расчетах"
          changeType="positive"
          accent="emerald"
          isSimulatedBadge
        />

        <StatCard
          title="Средний чек розничной операции"
          value="1 420 ₽"
          subtitle="Снижение издержек бизнеса"
          change="Экономия на комиссиях 0.3%"
          changeType="neutral"
          accent="amber"
          isSimulatedBadge
        />
      </div>

      {/* Chart */}
      <SimpleLineChart
        data={velocityData}
        title="ДИНАМИКА СКОРОСТИ ОБРАЩЕНИЯ ЦИФРОВОГО РУБЛЯ (VELOCITY)"
        height={180}
        color="#3b82f6"
        formatValue={(v) => `${v.toFixed(2)}x`}
      />
    </div>
  );
};
