import React from 'react';
import { useSimulation } from '../simulation/SimulationContext';
import { StatCard } from '../components/common/StatCard';
import { SimpleLineChart } from '../components/charts/SimpleLineChart';
import { SimpleBarChart } from '../components/charts/SimpleBarChart';
import { formatRuble, formatNumber } from '../utils/formatters';
import {
  Coins,
  Wallet,
  Activity,
  Building2,
  Store,
  RefreshCw,
  ShieldAlert,
  ArrowRight,
} from 'lucide-react';

export const OverviewPage: React.FC = () => {
  const {
    totalCirculation,
    todayOpsCount,
    todayOpsVolume,
    accountsCount,
    activeAccountsCount,
    participantsCount,
    merchantsCount,
    pendingSettlementVolume,
    controlEventsCount,
    transactions,
  } = useSimulation();

  // Synthetic charts
  const circulationData = [
    { label: '08:00', value: 18420000000000 },
    { label: '10:00', value: 18450000000000 },
    { label: '12:00', value: 18480000000000 },
    { label: '14:00', value: totalCirculation },
  ];

  const opsByHour = [
    { label: '08:00', value: 142000 },
    { label: '09:00', value: 284000 },
    { label: '10:00', value: 412000 },
    { label: '11:00', value: 589000 },
    { label: '12:00', value: 610000 },
    { label: '13:00', value: 520000 },
    { label: '14:00', value: todayOpsCount - 2000000 },
  ];

  const bankActivityData = [
    { label: 'МКБ', value: 29800000000 },
    { label: 'Северный', value: 18400000000 },
    { label: 'Восточный', value: 11200000000 },
    { label: 'Уральский', value: 9400000000 },
    { label: 'Волга', value: 8100000000 },
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner Notice */}
      <div className="bg-[#121929] border border-blue-900/60 rounded-xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-bold text-blue-400 uppercase">
              ОБЩИЙ ОБЗОР ПЛАТФОРМЫ ЦИФРОВОГО РУБЛЯ
            </span>
            <span className="text-[10px] font-mono text-slate-400 bg-slate-900 border border-slate-800 px-2 py-0.5 rounded">
              БАНК РОССИИ
            </span>
          </div>
          <p className="text-xs text-slate-300 mt-1">
            Централизованная инфраструктура эмиссии, учета счетов, проверок и национальных расчетов
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-right font-mono">
            <span className="text-[10px] text-slate-400 block">ОБЪЕМ В ОБРАЩЕНИИ</span>
            <span className="text-base font-bold text-white text-emerald-400">
              {formatRuble(totalCirculation)}
            </span>
          </div>
        </div>
      </div>

      {/* Core Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Объем цифровых рублей в обращении"
          value={formatRuble(totalCirculation)}
          subtitle="Централизованная эмиссия ЦБ"
          change="+2.4% за сутки"
          changeType="positive"
          icon={<Coins className="w-4 h-4" />}
          accent="emerald"
          isSimulatedBadge
        />

        <StatCard
          title="Операции сегодня"
          value={formatNumber(todayOpsCount)}
          subtitle={`Объем: ${formatRuble(todayOpsVolume)}`}
          change="Высокая активность"
          changeType="positive"
          icon={<Activity className="w-4 h-4" />}
          accent="blue"
          isSimulatedBadge
        />

        <StatCard
          title="Счета цифрового рубля"
          value={formatNumber(accountsCount)}
          subtitle={`Активные: ${formatNumber(activeAccountsCount)}`}
          change="9.4 млн активных"
          changeType="neutral"
          icon={<Wallet className="w-4 h-4" />}
          accent="amber"
          isSimulatedBadge
        />

        <StatCard
          title="Участники и Торговая сеть"
          value={`${participantsCount} банков / ${formatNumber(merchantsCount)} ТСП`}
          subtitle={`В очереди расчетов: ${formatRuble(pendingSettlementVolume)}`}
          change={`${controlEventsCount} тревог риска`}
          changeType={controlEventsCount > 0 ? 'negative' : 'neutral'}
          icon={<Building2 className="w-4 h-4" />}
          accent="rose"
          isSimulatedBadge
        />
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <SimpleLineChart
          data={circulationData}
          title="ДИНАМИКА ОБЪЕМА ЦИФРОВЫХ РУБЛЕЙ В ОБРАЩЕНИИ (₽)"
          height={190}
          color="#10b981"
          formatValue={(v) => formatRuble(v)}
        />

        <SimpleBarChart
          data={bankActivityData}
          title="АКТИВНОСТЬ БАНКОВ-УЧАСТНИКОВ (ОБЪЕМ ОПЕРАЦИЙ ₽)"
          height={190}
          primaryColor="#3b82f6"
          formatValue={(v) => formatRuble(v)}
        />
      </div>

      {/* Recent Live Transactions Feed */}
      <div className="bg-[#121824] border border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
          <div>
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
              ПОСЛЕДНИЕ РЕАЛЬНЫЕ СИМУЛИРОВАННЫЕ ОПЕРАЦИИ ПЛАТФОРМЫ
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Живой поток транзакций, реестров и межбанковских расчетов
            </p>
          </div>
          <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/80 border border-emerald-800/80 px-2.5 py-1 rounded">
            ПОТОК АКТИВЕН
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px]">
                <th className="py-2.5 px-3">ID Операции</th>
                <th className="py-2.5 px-3">Время</th>
                <th className="py-2.5 px-3">Отправитель</th>
                <th className="py-2.5 px-3">Получатель</th>
                <th className="py-2.5 px-3">Назначение</th>
                <th className="py-2.5 px-3">Сумма (₽)</th>
                <th className="py-2.5 px-3">Статус</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {transactions.slice(0, 6).map((tx) => (
                <tr key={tx.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-2.5 px-3 font-bold text-blue-400">{tx.id}</td>
                  <td className="py-2.5 px-3 text-slate-400 whitespace-nowrap">{tx.timestamp}</td>
                  <td className="py-2.5 px-3">
                    <div className="font-semibold">{tx.payerName}</div>
                    <div className="text-[10px] text-slate-500">{tx.payerBank}</div>
                  </td>
                  <td className="py-2.5 px-3">
                    <div className="font-semibold">{tx.recipientName}</div>
                    <div className="text-[10px] text-slate-500">{tx.recipientBank}</div>
                  </td>
                  <td className="py-2.5 px-3 text-slate-300 max-w-xs truncate">{tx.purpose}</td>
                  <td className="py-2.5 px-3 font-bold text-white whitespace-nowrap">
                    {formatRuble(tx.amount)}
                  </td>
                  <td className="py-2.5 px-3 whitespace-nowrap">
                    <span
                      className={`inline-block px-2 py-0.5 rounded text-[10px] ${
                        tx.status === 'EXECUTED'
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : 'bg-amber-950 text-amber-300 border border-amber-800'
                      }`}
                    >
                      {tx.status === 'EXECUTED' ? 'ИСПОЛНЕНА' : 'ПРОВЕРЯЕТСЯ'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
