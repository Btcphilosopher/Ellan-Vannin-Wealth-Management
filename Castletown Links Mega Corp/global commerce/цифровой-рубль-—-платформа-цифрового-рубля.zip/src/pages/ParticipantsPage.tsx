import React from 'react';
import { useSimulation } from '../simulation/SimulationContext';
import { Badge } from '../components/common/Badge';
import { formatRuble, formatNumber } from '../utils/formatters';
import { Building2, Server, ShieldCheck, Activity, Landmark } from 'lucide-react';

export const ParticipantsPage: React.FC = () => {
  const { institutions } = useSimulation();

  return (
    <div className="space-y-6">
      {/* Distinction Header Banner */}
      <div className="bg-[#121929] border border-blue-900/60 rounded-xl p-5 shadow-sm">
        <div className="flex items-center justify-between pb-3 border-b border-blue-900/40">
          <div>
            <h2 className="text-base font-bold text-white uppercase font-mono tracking-wider">
              БАНКИ — УЧАСТНИКИ ПЛАТФОРМЫ (COMMERCIAL BANK ACCESS LAYER)
            </h2>
            <p className="text-xs text-slate-300 mt-0.5">
              Коммерческие банки не хранят депозиты цифрового рубля на своих балансах; они обеспечивают клиентский интерфейс, аутентификацию и доступ к центральной платформе ЦБ.
            </p>
          </div>
          <Badge variant="grey">ВЫМЫШЛЕННЫЕ УЧАСТНИКИ</Badge>
        </div>

        {/* Visual Distinction Matrix */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4 text-xs font-mono">
          <div className="bg-[#0f1422] p-4 rounded-lg border border-slate-700/80 space-y-2">
            <div className="flex items-center gap-2 text-blue-400 font-bold uppercase">
              <Building2 className="w-4 h-4" />
              <span>ОБЯЗАННОСТИ БАНКА-УЧАСТНИКА:</span>
            </div>
            <ul className="space-y-1.5 text-slate-300 text-[11px] list-disc list-inside">
              <li>Идентификация и аутентификация клиентов (ЕСИА / Биометрия)</li>
              <li>Предоставление мобильных банковских приложений</li>
              <li>Маршрутизация распоряжений на платформу ЦБ</li>
              <li>Отображение выписок и статусов проведенных операций</li>
            </ul>
          </div>

          <div className="bg-[#0f1422] p-4 rounded-lg border border-blue-800/80 space-y-2">
            <div className="flex items-center gap-2 text-emerald-400 font-bold uppercase">
              <Landmark className="w-4 h-4" />
              <span>ОБЯЗАННОСТИ ПЛАТФОРМЫ БАНКА РОССИИ:</span>
            </div>
            <ul className="space-y-1.5 text-slate-300 text-[11px] list-disc list-inside">
              <li>Ведение реестров счетов и проверка прав собственников</li>
              <li>Централизованная эмиссия и прямое исполнение транзакций</li>
              <li>Окончательные валовые расчеты (Central Ledger)</li>
              <li>Обеспечение неизменяемости финансовой информации</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Fictional Institutions Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {institutions.map((bank) => (
          <div
            key={bank.id}
            className="bg-[#121824] border border-slate-800 rounded-xl p-5 shadow-sm flex flex-col justify-between space-y-4"
          >
            <div>
              <div className="flex items-start justify-between gap-2">
                <span className="text-xs font-mono font-bold text-blue-400 uppercase">
                  {bank.bik}
                </span>
                <span className="text-[10px] font-mono text-amber-400 bg-amber-950 border border-amber-800 px-2 py-0.5 rounded">
                  ВЫМЫШЛЕННЫЙ УЧАСТНИК
                </span>
              </div>

              <h3 className="text-base font-bold text-white font-mono mt-2">{bank.name}</h3>
              <p className="text-xs text-slate-400 font-sans mt-0.5">
                Участник платформы цифрового рубля
              </p>
            </div>

            <div className="space-y-2 font-mono text-xs bg-[#0f1420] p-3 rounded-lg border border-slate-800">
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Счета клиентов:</span>
                <span className="text-white font-bold">{formatNumber(bank.digitalRubleAccountCount)}</span>
              </div>

              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Ликвидность:</span>
                <span className="text-emerald-400 font-bold">{formatRuble(bank.liquidityPosition)}</span>
              </div>

              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Ожидает расчета:</span>
                <span className="text-amber-400 font-bold">{formatRuble(bank.pendingSettlement)}</span>
              </div>

              <div className="flex justify-between py-1">
                <span className="text-slate-400">Объем за сутки:</span>
                <span className="text-blue-300 font-bold">{formatRuble(bank.dailyVolume)}</span>
              </div>
            </div>

            <div className="flex items-center justify-between text-[10px] font-mono pt-2 border-t border-slate-800 text-slate-400">
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span>API Gateway: {bank.latencyMs} мс</span>
              </div>
              <span>{bank.requestsPerSec} RPS</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
