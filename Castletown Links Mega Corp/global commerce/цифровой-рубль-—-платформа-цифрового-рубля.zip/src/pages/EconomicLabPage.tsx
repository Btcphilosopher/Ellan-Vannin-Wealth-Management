import React, { useState } from 'react';
import { useSimulation } from '../simulation/SimulationContext';
import { formatRuble, formatNumber } from '../utils/formatters';
import { Sliders, Sparkles, RefreshCw, BarChart, TrendingUp, ShieldAlert } from 'lucide-react';

export const EconomicLabPage: React.FC = () => {
  const { totalCirculation } = useSimulation();

  const [adoptionRate, setAdoptionRate] = useState(35); // 35%
  const [acquiringCap, setAcquiringCap] = useState(0.3); // 0.3%
  const [offlineCap, setOfflineCap] = useState(50000); // 50k RUB
  const [amlThreshold, setAmlThreshold] = useState(10000000); // 10M RUB

  // Calculated Macro Projections
  const projectedDailyVolume = totalCirculation * (adoptionRate / 100) * 0.12;
  const merchantSavingsAnnual = projectedDailyVolume * 365 * ((2.5 - acquiringCap) / 100);
  const estimatedTpsPeak = Math.round(15000 + adoptionRate * 850);

  return (
    <div className="space-y-6 font-mono">
      {/* Header Banner */}
      <div className="bg-[#121929] border border-blue-900/60 rounded-xl p-4 flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-white uppercase tracking-wider">
            ЛАБОРАТОРИЯ МАКРОЭКОНОМИЧЕСКОГО МОДЕЛИРОВАНИЯ И ЭКСПЕРИМЕНТОВ
          </h2>
          <p className="text-xs text-slate-300 mt-0.5">
            Симуляционный полигон Банка России для тестирования регуляторных параметров цифрового рубля.
          </p>
        </div>
        <span className="text-xs text-indigo-400 bg-indigo-950 border border-indigo-800 px-3 py-1.5 rounded font-bold">
          ЭКОНОМИЧЕСКАЯ МОДЕЛЬ 2030
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 text-xs">
        {/* Controls Sliders */}
        <div className="bg-[#121824] border border-slate-800 rounded-xl p-5 shadow-sm space-y-5">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider pb-3 border-b border-slate-800">
            РЕГУЛЯТОРНЫЕ И ТЕХНОЛОГИЧЕСКИЕ ПАРАМЕТРЫ
          </h3>

          <div>
            <div className="flex justify-between text-slate-300 mb-1">
              <span>Доля проникновения у населения (Retail Adoption Rate):</span>
              <span className="text-blue-400 font-bold">{adoptionRate}%</span>
            </div>
            <input
              type="range"
              min="5"
              max="90"
              value={adoptionRate}
              onChange={(e) => setAdoptionRate(parseInt(e.target.value))}
              className="w-full accent-blue-500 cursor-pointer"
            />
            <span className="text-[10px] text-slate-500 block">Процент граждан, получающих доходы в ЦР</span>
          </div>

          <div>
            <div className="flex justify-between text-slate-300 mb-1">
              <span>Предельный тариф эквайринга ТСП:</span>
              <span className="text-emerald-400 font-bold">{acquiringCap.toFixed(1)}%</span>
            </div>
            <input
              type="range"
              min="0.1"
              max="1.5"
              step="0.1"
              value={acquiringCap}
              onChange={(e) => setAcquiringCap(parseFloat(e.target.value))}
              className="w-full accent-emerald-500 cursor-pointer"
            />
            <span className="text-[10px] text-slate-500 block">Законодательный потолок комиссии для бизнеса</span>
          </div>

          <div>
            <div className="flex justify-between text-slate-300 mb-1">
              <span>Предельный остаток офлайн-кошелька:</span>
              <span className="text-amber-400 font-bold">{formatRuble(offlineCap)}</span>
            </div>
            <input
              type="range"
              min="10000"
              max="200000"
              step="5000"
              value={offlineCap}
              onChange={(e) => setOfflineCap(parseInt(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer"
            />
            <span className="text-[10px] text-slate-500 block">Лимит средств без подключения к сети</span>
          </div>

          <div>
            <div className="flex justify-between text-slate-300 mb-1">
              <span>Порог автоматической проверки ПОД/ФТ:</span>
              <span className="text-rose-400 font-bold">{formatRuble(amlThreshold)}</span>
            </div>
            <input
              type="range"
              min="1000000"
              max="100000000"
              step="1000000"
              value={amlThreshold}
              onChange={(e) => setAmlThreshold(parseInt(e.target.value))}
              className="w-full accent-rose-500 cursor-pointer"
            />
            <span className="text-[10px] text-slate-500 block">Сумма единовременной операции для контроля</span>
          </div>
        </div>

        {/* Calculated Forecast Metrics */}
        <div className="bg-[#121824] border border-slate-800 rounded-xl p-5 shadow-sm flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-white uppercase tracking-wider pb-3 border-b border-slate-800 mb-4">
              РАСЧЕТНЫЙ МАКРОЭКОНОМИЧЕСКИЙ ПРОГНОЗ
            </h3>

            <div className="space-y-4">
              <div className="bg-[#0f1420] p-3.5 rounded border border-slate-800">
                <span className="text-slate-400 block text-[10px]">ПРОГНОЗНЫЙ СУТОЧНЫЙ ОБЪЕМ ОПЕРАЦИЙ</span>
                <span className="text-lg font-bold text-blue-400 mt-1 block">
                  {formatRuble(projectedDailyVolume)}
                </span>
              </div>

              <div className="bg-[#0f1420] p-3.5 rounded border border-slate-800">
                <span className="text-slate-400 block text-[10px]">ГОДОВАЯ ЭКОНОМИЯ ТОРГОВЛИ НА КОМИССИЯХ</span>
                <span className="text-lg font-bold text-emerald-400 mt-1 block">
                  {formatRuble(merchantSavingsAnnual)}
                </span>
                <span className="text-[10px] text-slate-500 mt-0.5 block">
                  По сравнению со стандартным эквайрингом 2.5%
                </span>
              </div>

              <div className="bg-[#0f1420] p-3.5 rounded border border-slate-800">
                <span className="text-slate-400 block text-[10px]">ПИКОВАЯ НАГРУЗКА ИНФРАСТРУКТУРЫ</span>
                <span className="text-lg font-bold text-amber-400 mt-1 block">
                  {formatNumber(estimatedTpsPeak)} TPS
                </span>
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800 text-[10px] text-slate-500 text-center mt-4">
            МОДЕЛИРОВАНИЕ ВЫПОЛНЕНО НА БАЗЕ ИИ-ДВИЖКА БАНКА РОССИИ
          </div>
        </div>
      </div>
    </div>
  );
};
