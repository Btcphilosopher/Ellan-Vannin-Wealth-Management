import React, { useState } from 'react';
import { useSimulation } from '../simulation/SimulationContext';
import { PaymentMethod, TransactionStatus } from '../types';
import { formatRuble } from '../utils/formatters';
import {
  CreditCard,
  QrCode,
  Smartphone,
  Wifi,
  Globe,
  UserCheck,
  Zap,
  Code2,
  CheckCircle2,
  XCircle,
  AlertOctagon,
  Clock,
} from 'lucide-react';

export const PaymentsPage: React.FC = () => {
  const { accounts, merchants, transactions, executePayment } = useSimulation();

  const [selectedMethod, setSelectedMethod] = useState<PaymentMethod>('QR');
  const [payerId, setPayerId] = useState(accounts[0]?.id || '');
  const [recipientId, setRecipientId] = useState(merchants[0]?.id || accounts[1]?.id || '');
  const [amount, setAmount] = useState('3280');
  const [purpose, setPurpose] = useState('Оплата товаров по QR-коду СБП/ЦР');

  const [simState, setSimState] = useState<TransactionStatus | null>(null);
  const [resultMsg, setResultMsg] = useState<string | null>(null);

  const methodsList: { id: PaymentMethod; label: string; icon: React.ReactNode }[] = [
    { id: 'QR', label: 'QR-код', icon: <QrCode className="w-4 h-4" /> },
    { id: 'MOBILE', label: 'Мобильное приложение', icon: <Smartphone className="w-4 h-4" /> },
    { id: 'NFC', label: 'NFC Бесконтактно', icon: <Wifi className="w-4 h-4" /> },
    { id: 'ONLINE', label: 'Онлайн-оплата', icon: <Globe className="w-4 h-4" /> },
    { id: 'ACCOUNT_TRANSFER', label: 'Перевод по счету', icon: <UserCheck className="w-4 h-4" /> },
    { id: 'AUTOMATIC', label: 'Автоматический платеж', icon: <Zap className="w-4 h-4" /> },
    { id: 'PROGRAMMABLE', label: 'Программируемый', icon: <Code2 className="w-4 h-4" /> },
  ];

  const pipelineStatuses: TransactionStatus[] = [
    'CREATED',
    'ACCEPTED',
    'CHECKING',
    'EXECUTING',
    'EXECUTED',
  ];

  const handleRunPayment = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(amount);
    if (isNaN(amt) || amt <= 0) return;

    // Simulate step-by-step pipeline
    setSimState('CREATED');
    setResultMsg(null);

    setTimeout(() => setSimState('ACCEPTED'), 300);
    setTimeout(() => setSimState('CHECKING'), 600);
    setTimeout(() => setSimState('EXECUTING'), 900);

    setTimeout(() => {
      const res = executePayment({
        payerAccountId: payerId,
        recipientAccountId: recipientId,
        amount: amt,
        purpose,
        method: selectedMethod,
      });

      if (res.transaction) {
        setSimState(res.transaction.status);
      } else {
        setSimState('REJECTED');
      }
      setResultMsg(res.message);
    }, 1200);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-[#121929] border border-blue-900/60 rounded-xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-white uppercase font-mono tracking-wider">
            ПЛАТЕЖНЫЙ ДВИЖОК ЦИФРОВОГО РУБЛЯ (PAYMENT ENGINE)
          </h2>
          <p className="text-xs text-slate-300 mt-0.5">
            Поддержка розничных, коммерческих, автоматических и программируемых платежных методов.
          </p>
        </div>
        <span className="text-xs font-mono text-blue-400 bg-blue-950 border border-blue-800 px-3 py-1 rounded">
          ПРОЦЕССИНГ 24/7
        </span>
      </div>

      {/* Methods Selection Bar */}
      <div className="bg-[#121824] border border-slate-800 rounded-xl p-4">
        <h3 className="text-xs font-bold text-slate-400 uppercase font-mono tracking-wider mb-3">
          ВЫБОР ПЛАТЕЖНОГО МЕТОДА (METHOD SELECTOR)
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
          {methodsList.map((m) => (
            <button
              key={m.id}
              onClick={() => setSelectedMethod(m.id)}
              className={`p-3 rounded-lg border flex flex-col items-center justify-center gap-2 text-xs font-mono font-medium transition-all ${
                selectedMethod === m.id
                  ? 'bg-blue-600 border-blue-400 text-white shadow-md'
                  : 'bg-[#161c2c] border-slate-700/80 text-slate-400 hover:text-white'
              }`}
            >
              {m.icon}
              <span className="text-[11px] text-center leading-tight">{m.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Payment Form & Pipeline Visualizer */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Form */}
        <div className="bg-[#121824] border border-slate-800 rounded-xl p-5 shadow-sm">
          <h3 className="text-sm font-bold text-white uppercase font-mono tracking-wider pb-3 border-b border-slate-800 mb-4">
            ФОРМИРОВАНИЕ ПЛАТЕЖНОГО РАСПОРЯЖЕНИЯ
          </h3>

          <form onSubmit={handleRunPayment} className="space-y-4 font-mono text-xs">
            <div>
              <label className="block text-slate-300 mb-1">Плательщик (Счет ЦР)</label>
              <select
                value={payerId}
                onChange={(e) => setPayerId(e.target.value)}
                className="w-full bg-[#161c2c] border border-slate-700 rounded p-2.5 text-white"
              >
                {accounts.map((acc) => (
                  <option key={acc.id} value={acc.id}>
                    {acc.ownerName} ({acc.id}) — {formatRuble(acc.availableBalance)}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-300 mb-1">
                Получатель (Счет физического, юр.лица или ТСП)
              </label>
              <select
                value={recipientId}
                onChange={(e) => setRecipientId(e.target.value)}
                className="w-full bg-[#161c2c] border border-slate-700 rounded p-2.5 text-white"
              >
                <optgroup label="Торгово-сервисные предприятия (ТСП)">
                  {merchants.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.name} ({m.id})
                    </option>
                  ))}
                </optgroup>
                <optgroup label="Счета клиентов">
                  {accounts.map((acc) => (
                    <option key={acc.id} value={acc.id}>
                      {acc.ownerName} ({acc.id})
                    </option>
                  ))}
                </optgroup>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-300 mb-1">Сумма платежа (₽)</label>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full bg-[#161c2c] border border-slate-700 rounded p-2.5 text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Метод</label>
                <input
                  type="text"
                  value={methodsList.find((m) => m.id === selectedMethod)?.label || 'Платеж'}
                  disabled
                  className="w-full bg-[#0e131d] border border-slate-800 rounded p-2.5 text-blue-400 font-bold"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-300 mb-1">Назначение платежа</label>
              <input
                type="text"
                value={purpose}
                onChange={(e) => setPurpose(e.target.value)}
                className="w-full bg-[#161c2c] border border-slate-700 rounded p-2.5 text-white"
                required
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded uppercase tracking-wider transition-colors shadow"
            >
              ОТПРАВИТЬ РАСПОРЯЖЕНИЕ НА ПЛАТФОРМУ
            </button>
          </form>
        </div>

        {/* Live Status Pipeline Monitor */}
        <div className="bg-[#121824] border border-slate-800 rounded-xl p-5 shadow-sm flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-white uppercase font-mono tracking-wider pb-3 border-b border-slate-800 mb-4">
              ЖИВОЙ СТАТУС ОБРАБОТКИ ПЛАТЕЖА
            </h3>

            <div className="space-y-3 font-mono text-xs">
              {pipelineStatuses.map((st, idx) => {
                const labels: Record<string, string> = {
                  CREATED: '1. СОЗДАНА (ИНИЦИАЦИЯ)',
                  ACCEPTED: '2. ПРИНЯТА В ОБРАБОТКУ',
                  CHECKING: '3. ПРОВЕРЯЕТСЯ (РИСК-КОНТРОЛЬ)',
                  EXECUTING: '4. ИСПОЛНЯЕТСЯ (РЕЕСТР)',
                  EXECUTED: '5. ИСПОЛНЕНА (ОКОНЧАТЕЛЬНЫЙ РАСЧЕТ)',
                };

                const isCurrent = simState === st;
                const isPassed =
                  simState &&
                  pipelineStatuses.indexOf(simState) > idx &&
                  simState !== 'REJECTED' &&
                  simState !== 'SUSPENDED';

                return (
                  <div
                    key={st}
                    className={`p-3 rounded border flex items-center justify-between transition-all ${
                      isCurrent
                        ? 'bg-blue-950 border-blue-500 text-white animate-pulse'
                        : isPassed
                        ? 'bg-emerald-950/40 border-emerald-800/80 text-emerald-300'
                        : 'bg-[#161c2c] border-slate-800 text-slate-500'
                    }`}
                  >
                    <span>{labels[st]}</span>
                    {isCurrent && <Clock className="w-4 h-4 text-blue-400 animate-spin" />}
                    {isPassed && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
                  </div>
                );
              })}

              {simState === 'SUSPENDED' && (
                <div className="p-3 bg-amber-950 border border-amber-800 text-amber-300 rounded font-bold flex items-center justify-between">
                  <span>СТАТУС: ПРИОСТАНОВЛЕНА (КРУПНЫЙ ПЛАТЕЖ / РИСК)</span>
                  <AlertOctagon className="w-4 h-4" />
                </div>
              )}

              {simState === 'REJECTED' && (
                <div className="p-3 bg-rose-950 border border-rose-800 text-rose-300 rounded font-bold flex items-center justify-between">
                  <span>СТАТУС: ОТКЛОНЕНА</span>
                  <XCircle className="w-4 h-4" />
                </div>
              )}
            </div>

            {resultMsg && (
              <div className="mt-4 p-3 bg-[#161c2c] border border-slate-700 rounded text-xs font-mono text-slate-200">
                {resultMsg}
              </div>
            )}
          </div>

          <div className="pt-3 border-t border-slate-800 text-[10px] text-slate-500 font-mono text-center mt-4">
            ОККЛИНГ И ПРЯМОЕ СПИСАНИЕ НА ЦЕНТРАЛЬНОЙ ПЛАТФОРМЕ БАНКА РОССИИ
          </div>
        </div>
      </div>
    </div>
  );
};
