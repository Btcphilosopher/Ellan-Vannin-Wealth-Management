import React, { useState } from 'react';
import { useSimulation } from '../simulation/SimulationContext';
import { formatRuble } from '../utils/formatters';
import {
  Wallet,
  Send,
  QrCode,
  ArrowDownLeft,
  History,
  ShoppingBag,
  Bus,
  Utensils,
  Globe,
  Home,
  CheckCircle2,
} from 'lucide-react';

export const ConsumerPage: React.FC = () => {
  const { accounts, executePayment } = useSimulation();

  // Find primary simulated citizen account
  const citizenAccount = accounts.find((a) => a.id === '40817810099810000001') || accounts[0];

  const [activeModal, setActiveModal] = useState<'TRANSFER' | 'RECEIVE' | 'PAY' | 'REQUEST' | null>(null);
  const [transferRecipient, setTransferRecipient] = useState('40817810099810000002');
  const [transferAmount, setTransferAmount] = useState('1500');
  const [transferPurpose, setTransferPurpose] = useState('Перевод другу');
  const [actionMsg, setActionMsg] = useState('');

  const consumerTxs = [
    { title: 'Продукты (Глобус-Север)', amount: 2840, type: 'PAYMENT', icon: <ShoppingBag className="w-4 h-4 text-emerald-400" />, date: 'Сегодня, 14:41' },
    { title: 'Транспорт (МосГорТранс)', amount: 186, type: 'PAYMENT', icon: <Bus className="w-4 h-4 text-blue-400" />, date: 'Сегодня, 14:31' },
    { title: 'Ресторан (Сибирь)', amount: 1240, type: 'PAYMENT', icon: <Utensils className="w-4 h-4 text-amber-400" />, date: 'Вчера, 20:15' },
    { title: 'Онлайн-покупка (ТехноМир)', amount: 4800, type: 'PAYMENT', icon: <Globe className="w-4 h-4 text-indigo-400" />, date: '16.09.2026' },
    { title: 'Коммунальные услуги (ЖКУ)', amount: 3420, type: 'PAYMENT', icon: <Home className="w-4 h-4 text-rose-400" />, date: '15.09.2026' },
  ];

  const handleActionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(transferAmount);
    if (isNaN(amt) || amt <= 0) return;

    const res = executePayment({
      payerAccountId: citizenAccount.id,
      recipientAccountId: transferRecipient,
      amount: amt,
      purpose: transferPurpose,
      method: 'MOBILE',
    });

    setActionMsg(res.message);
    if (res.success) {
      setTimeout(() => {
        setActiveModal(null);
        setActionMsg('');
      }, 1500);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Consumer Interface Banner */}
      <div className="bg-gradient-to-r from-blue-950 via-slate-900 to-slate-900 border border-blue-800/80 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center font-mono font-bold text-white text-base">
              ₽
            </div>
            <div>
              <h2 className="text-sm font-bold text-white font-mono uppercase tracking-wider">
                ЦИФРОВОЙ РУБЛЬ — МОБИЛЬНЫЙ ИНТЕРФЕЙС ГРАЖДАНИНА
              </h2>
              <p className="text-xs text-slate-400">
                Доступ через приложение АКБ Московский Коммерческий Банк
              </p>
            </div>
          </div>
          <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950 border border-emerald-800 px-2.5 py-1 rounded">
            СЧЕТ ЦБ АКТИВЕН
          </span>
        </div>

        {/* Balance Display */}
        <div className="my-6 text-center sm:text-left">
          <span className="text-xs font-mono text-slate-400 uppercase tracking-widest block">
            ДОСТУПНЫЙ БАЛАНС СЧЕТА ЦИФРОВОГО РУБЛЯ
          </span>
          <div className="text-3xl sm:text-4xl font-extrabold font-mono text-white tracking-tight mt-1 text-emerald-400 tabular-nums">
            {formatRuble(citizenAccount.availableBalance)}
          </div>
          <div className="text-xs font-mono text-slate-500 mt-1">
            Номер счета: {citizenAccount.id}
          </div>
        </div>

        {/* Quick Actions Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
          <button
            onClick={() => {
              setActiveModal('TRANSFER');
              setActionMsg('');
            }}
            className="p-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-mono text-xs font-bold flex flex-col items-center gap-1.5 transition-colors shadow"
          >
            <Send className="w-4 h-4" />
            <span>Перевести</span>
          </button>

          <button
            onClick={() => {
              setActiveModal('RECEIVE');
              setActionMsg('');
            }}
            className="p-3 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl font-mono text-xs font-bold flex flex-col items-center gap-1.5 transition-colors"
          >
            <ArrowDownLeft className="w-4 h-4 text-emerald-400" />
            <span>Получить</span>
          </button>

          <button
            onClick={() => {
              setActiveModal('PAY');
              setActionMsg('');
            }}
            className="p-3 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl font-mono text-xs font-bold flex flex-col items-center gap-1.5 transition-colors"
          >
            <QrCode className="w-4 h-4 text-blue-400" />
            <span>Оплатить (QR)</span>
          </button>

          <button
            onClick={() => {
              setActiveModal('REQUEST');
              setActionMsg('');
            }}
            className="p-3 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl font-mono text-xs font-bold flex flex-col items-center gap-1.5 transition-colors"
          >
            <History className="w-4 h-4 text-amber-400" />
            <span>Запросить</span>
          </button>
        </div>
      </div>

      {/* Recent Transactions Feed */}
      <div className="bg-[#121824] border border-slate-800 rounded-2xl p-6 shadow-sm">
        <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-4">
          <h3 className="text-sm font-bold text-white uppercase font-mono tracking-wider">
            ПОСЛЕДНИЕ ОПЕРАЦИИ (RECENT TRANSACTIONS)
          </h3>
          <span className="text-xs font-mono text-slate-400">Счет {citizenAccount.id.slice(-6)}</span>
        </div>

        <div className="space-y-3 font-mono text-xs">
          {consumerTxs.map((tx, idx) => (
            <div
              key={idx}
              className="p-3.5 bg-[#161c2c] border border-slate-800/80 rounded-xl flex items-center justify-between hover:bg-slate-800/60 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-slate-900 border border-slate-800 rounded-lg">
                  {tx.icon}
                </div>
                <div>
                  <div className="font-bold text-white text-sm">{tx.title}</div>
                  <div className="text-[10px] text-slate-400 mt-0.5">{tx.date}</div>
                </div>
              </div>

              <div className="text-right">
                <div className="text-sm font-bold text-rose-400">
                  -{formatRuble(tx.amount)}
                </div>
                <div className="text-[10px] text-emerald-400">Исполнено</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Interactive Modal */}
      {activeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className="bg-[#111622] border border-slate-700 rounded-xl p-6 max-w-md w-full space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-sm font-bold text-white uppercase font-mono">
                {activeModal === 'TRANSFER'
                  ? 'ПЕРЕВОД ЦИФРОВЫХ РУБЛЕЙ'
                  : activeModal === 'RECEIVE'
                  ? 'ПОЛУЧЕНИЕ СРЕДСТВ (QR)'
                  : activeModal === 'PAY'
                  ? 'ОПЛАТА ПО QR-КОДУ'
                  : 'ЗАПРОС ПЕРЕВОДА'}
              </h3>
              <button
                onClick={() => setActiveModal(null)}
                className="text-slate-400 hover:text-white text-xs font-mono bg-slate-800 px-2 py-1 rounded"
              >
                Закрыть
              </button>
            </div>

            {activeModal === 'RECEIVE' ? (
              <div className="text-center space-y-4 py-3 font-mono">
                <div className="w-44 h-44 mx-auto bg-white p-3 rounded-xl flex items-center justify-center shadow">
                  <div className="w-full h-full border-4 border-slate-900 flex items-center justify-center font-bold text-slate-900 text-xs">
                    [QR ЦИФРОВОЙ РУБЛЬ]
                  </div>
                </div>
                <p className="text-xs text-slate-300">
                  Покажите этот QR-код для получения перевода на счет {citizenAccount.id}
                </p>
              </div>
            ) : (
              <form onSubmit={handleActionSubmit} className="space-y-4 font-mono text-xs">
                <div>
                  <label className="block text-slate-300 mb-1">Счет / Номер получателя</label>
                  <input
                    type="text"
                    value={transferRecipient}
                    onChange={(e) => setTransferRecipient(e.target.value)}
                    className="w-full bg-[#161c2c] border border-slate-700 rounded p-2.5 text-white"
                    required
                  />
                </div>

                <div>
                  <label className="block text-slate-300 mb-1">Сумма (₽)</label>
                  <input
                    type="number"
                    value={transferAmount}
                    onChange={(e) => setTransferAmount(e.target.value)}
                    className="w-full bg-[#161c2c] border border-slate-700 rounded p-2.5 text-white"
                    required
                  />
                </div>

                <div>
                  <label className="block text-slate-300 mb-1">Комментарий</label>
                  <input
                    type="text"
                    value={transferPurpose}
                    onChange={(e) => setTransferPurpose(e.target.value)}
                    className="w-full bg-[#161c2c] border border-slate-700 rounded p-2.5 text-white"
                  />
                </div>

                {actionMsg && (
                  <div className="p-3 bg-emerald-950/80 text-emerald-300 border border-emerald-800 rounded text-xs">
                    {actionMsg}
                  </div>
                )}

                <button
                  type="submit"
                  className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded uppercase tracking-wider"
                >
                  ПОДТВЕРДИТЬ ОПЕРАЦИЮ
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
