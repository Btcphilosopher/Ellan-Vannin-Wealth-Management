import React from 'react';
import { useSimulation } from '../simulation/SimulationContext';
import { StatCard } from '../components/common/StatCard';
import { Activity, Server, Cpu, Database, Network, ShieldCheck } from 'lucide-react';

export const OperationsPage: React.FC = () => {
  const { services, todayOpsCount } = useSimulation();

  return (
    <div className="space-y-6 font-mono">
      {/* Header Banner */}
      <div className="bg-[#121929] border border-blue-900/60 rounded-xl p-4 flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-white uppercase tracking-wider">
            ЦЕНТР МОНИТОРИНГА СИСТЕМНОЙ ОПЕРАЦИОННОЙ ИНФРАСТРУКТУРЫ (NOC)
          </h2>
          <p className="text-xs text-slate-300 mt-0.5">
            Контроль пропускной способности, доступности API и системных задержек в реальном времени.
          </p>
        </div>
        <span className="text-xs text-emerald-400 bg-emerald-950 border border-emerald-800 px-3 py-1.5 rounded font-bold">
          SLA: 99.999%
        </span>
      </div>

      {/* Infrastructure Telemetry Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <StatCard
          title="Суммарный пропуск (TPS)"
          value="48 500 TPS"
          subtitle="Максимальный пик: 100 000 TPS"
          accent="blue"
          isSimulatedBadge
        />

        <StatCard
          title="Средняя задержка (Latency)"
          value="1.2 мс"
          subtitle="От ответа ядра до подтверждения"
          accent="emerald"
          isSimulatedBadge
        />

        <StatCard
          title="Доступность платформы (Uptime)"
          value="100.00%"
          subtitle="Непрерывно без сбоев"
          accent="amber"
          isSimulatedBadge
        />

        <StatCard
          title="Нагрузка очереди сообщений"
          value="0.02%"
          subtitle="Буфер безопасен"
          accent="slate"
          isSimulatedBadge
        />
      </div>

      {/* Services Health Status Table */}
      <div className="bg-[#121824] border border-slate-800 rounded-xl p-5 shadow-sm">
        <h3 className="text-sm font-bold text-white uppercase tracking-wider pb-3 border-b border-slate-800 mb-4">
          СТАТУС И ТЕЛЕМЕТРИЯ СЕРВИСОВ ПЛАТФОРМЫ
        </h3>

        <div className="overflow-x-auto text-xs">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px]">
                <th className="py-2.5 px-3">Идентификатор</th>
                <th className="py-2.5 px-3">Наименование сервиса</th>
                <th className="py-2.5 px-3">Задержка (мс)</th>
                <th className="py-2.5 px-3">Нагрузка (TPS)</th>
                <th className="py-2.5 px-3">Ошибки (%)</th>
                <th className="py-2.5 px-3">Heartbeat</th>
                <th className="py-2.5 px-3">Статус</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {services.map((svc) => (
                <tr key={svc.id} className="hover:bg-slate-800/40">
                  <td className="py-2.5 px-3 font-bold text-blue-400">{svc.id}</td>
                  <td className="py-2.5 px-3 font-semibold text-white">{svc.name}</td>
                  <td className="py-2.5 px-3 text-emerald-400 font-bold">{svc.latencyMs} мс</td>
                  <td className="py-2.5 px-3 text-slate-200">{svc.tps.toLocaleString('ru-RU')}</td>
                  <td className="py-2.5 px-3 text-slate-400">{svc.errorRatePct}%</td>
                  <td className="py-2.5 px-3 text-slate-400 text-[10px]">{svc.lastHeartbeat}</td>
                  <td className="py-2.5 px-3 whitespace-nowrap">
                    <span className="px-2 py-0.5 bg-emerald-950 text-emerald-300 border border-emerald-800 rounded text-[10px] font-bold">
                      {svc.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
