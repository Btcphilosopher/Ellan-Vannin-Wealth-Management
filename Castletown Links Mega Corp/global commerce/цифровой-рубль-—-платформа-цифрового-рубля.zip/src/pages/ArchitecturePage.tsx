import React from 'react';
import { useSimulation } from '../simulation/SimulationContext';
import { Badge } from '../components/common/Badge';
import { Layers, ArrowDown, Activity, CheckCircle2, AlertTriangle, Shield, Server } from 'lucide-react';

export const ArchitecturePage: React.FC = () => {
  const { services } = useSimulation();

  const architectureLayers = [
    { title: 'БАНК РОССИИ', desc: 'Центральный орган эмиссии, управления платформами и установитель правил', color: 'border-blue-500 bg-blue-950/40 text-blue-300' },
    { title: 'ПЛАТФОРМА ЦИФРОВОГО РУБЛЯ', desc: 'Авторитетный централизованный технологический слой инфраструктуры CBDC', color: 'border-blue-600 bg-blue-900/40 text-white' },
    { title: 'ЦЕНТРАЛЬНЫЙ РЕЕСТР И ПРОЦЕССИНГ', desc: 'Неизменяемый реестр счетов, балансов и центральный процессинговый ядро', color: 'border-indigo-600 bg-indigo-950/40 text-indigo-200' },
    { title: 'ЦЕНТР МЕЖБАНКОВСКИХ РАСЧЕТОВ', desc: 'Расчеты по обязательствам банков-участников и клиринг', color: 'border-cyan-600 bg-cyan-950/40 text-cyan-200' },
    { title: 'БАНКИ — УЧАСТНИКИ ПЛАТФОРМЫ', desc: 'Коммерческие банки, предоставляющие клиентам доступ через банковские приложения', color: 'border-slate-600 bg-slate-900 text-slate-200' },
    { title: 'СЧЕТА ЦИФРОВОГО РУБЛЯ', desc: 'Ведутся исключительно на платформе Банка России', color: 'border-emerald-600 bg-emerald-950/40 text-emerald-200' },
    { title: 'ГРАЖДАНЕ / БИЗНЕС', desc: 'Конечные владельцы счетов, плательщики и получатели средств', color: 'border-slate-500 bg-slate-800 text-white' },
  ];

  return (
    <div className="space-y-6">
      <div className="bg-[#121929] border border-blue-900/60 rounded-xl p-4 flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-white uppercase font-mono tracking-wider">
            СИСТЕМНАЯ АРХИТЕКТУРА И ИНФРАСТРУКТУРА ПЛАТФОРМЫ
          </h2>
          <p className="text-xs text-slate-300 mt-0.5">
            Двухуровневая модель: Центральный банк ведает платформой и счетами; коммерческие банки обеспечивают клиентский доступ.
          </p>
        </div>
        <Badge variant="blue">ЦЕНТРАЛИЗОВАННАЯ CBDC</Badge>
      </div>

      {/* Vertical Interactive Flowchart */}
      <div className="bg-[#121824] border border-slate-800 rounded-xl p-6 shadow-sm">
        <h3 className="text-sm font-bold text-white uppercase font-mono tracking-wider mb-6 pb-2 border-b border-slate-800">
          АРХИТЕКТУРНАЯ ИЕРАРХИЯ СЛОЕВ ПЛАТФОРМЫ
        </h3>

        <div className="max-w-2xl mx-auto space-y-3">
          {architectureLayers.map((layer, idx) => (
            <React.Fragment key={idx}>
              <div
                className={`p-4 rounded-xl border-2 ${layer.color} shadow-md transition-all hover:scale-[1.01]`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold uppercase tracking-widest">
                    {layer.title}
                  </span>
                  <span className="text-[10px] font-mono text-slate-400">СЛОЙ 0{idx + 1}</span>
                </div>
                <p className="text-xs mt-1 opacity-90 font-sans">{layer.desc}</p>
              </div>

              {idx < architectureLayers.length - 1 && (
                <div className="flex justify-center my-1 text-blue-500">
                  <ArrowDown className="w-5 h-5 animate-bounce" />
                </div>
              )}
            </React.Fragment>
          ))}
        </div>
      </div>

      {/* Supporting Infrastructure Services Grid */}
      <div className="bg-[#121824] border border-slate-800 rounded-xl p-6 shadow-sm">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-5">
          <div>
            <h3 className="text-sm font-bold text-white uppercase font-mono tracking-wider">
              ВСПОМОГАТЕЛЬНЫЕ СЕРВИСЫ И ИНТЕГРАЦИИ (SERVICE MATRIX)
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Мониторинг задержки, пропускной способности и отказоустойчивости сервисов
            </p>
          </div>
          <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950 border border-emerald-800 px-2 py-1 rounded">
            ВСЕ СЕРВИСЫ РАБОТАЮТ
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {services.map((svc) => (
            <div
              key={svc.id}
              className="bg-[#0f1420] border border-slate-800 rounded-lg p-4 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2">
                  <span className="text-xs font-bold text-white font-mono">{svc.name}</span>
                  <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950 px-1.5 py-0.5 rounded border border-emerald-800">
                    {svc.status}
                  </span>
                </div>
                <div className="text-[10px] text-slate-500 font-mono mt-0.5">{svc.id}</div>
              </div>

              <div className="grid grid-cols-2 gap-2 my-3 text-[11px] font-mono bg-[#141b2b] p-2.5 rounded border border-slate-800/80">
                <div>
                  <span className="text-slate-400 block text-[10px]">ЗАДЕРЖКА:</span>
                  <span className="text-blue-400 font-bold">{svc.latencyMs} мс</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">ПРОПУСКНАЯ СПОСОБНОСТЬ:</span>
                  <span className="text-emerald-400 font-bold">{svc.tps.toLocaleString('ru-RU')} TPS</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">ОШИБКИ:</span>
                  <span className="text-slate-200">{svc.errorRatePct}%</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">ОЧЕРЕДЬ:</span>
                  <span className="text-amber-400">{svc.queueSize}</span>
                </div>
              </div>

              <div className="text-[10px] font-mono text-slate-500 flex items-center justify-between pt-2 border-t border-slate-800/80">
                <span>Heartbeat:</span>
                <span className="text-slate-400">{svc.lastHeartbeat}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
