import React from 'react';
import { useSimulation } from '../simulation/SimulationContext';
import { FileText, ShieldCheck, CheckCircle2, Lock } from 'lucide-react';

export const AuditPage: React.FC = () => {
  const { auditLogs } = useSimulation();

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-[#121929] border border-blue-900/60 rounded-xl p-4 flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-white uppercase font-mono tracking-wider">
            НЕИЗМЕНЯЕМЫЙ ЖУРНАЛ АУДИТА И КРИПТОГРАФИЧЕСКАЯ ВЕРИФИКАЦИЯ
          </h2>
          <p className="text-xs text-slate-300 mt-0.5">
            Юридически значимый протокол Банка России с хешированием всех записей центрального реестра.
          </p>
        </div>
        <span className="text-xs font-mono text-emerald-400 bg-emerald-950 border border-emerald-800 px-3 py-1.5 rounded font-bold flex items-center gap-1.5">
          <ShieldCheck className="w-4 h-4" />
          <span>КРИПТО-ЦЕПОЧКА ЦЕЛА</span>
        </span>
      </div>

      {/* Audit Table */}
      <div className="bg-[#121824] border border-slate-800 rounded-xl p-5 shadow-sm">
        <h3 className="text-sm font-bold text-white uppercase font-mono tracking-wider pb-3 border-b border-slate-800 mb-4">
          ЦЕНТРАЛЬНЫЙ АУДИТОРСКИЙ ЖУРНАЛ СОБЫТИЙ (AUDIT TRAIL)
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px]">
                <th className="py-2.5 px-3">ID События</th>
                <th className="py-2.5 px-3">Время</th>
                <th className="py-2.5 px-3">Тип события</th>
                <th className="py-2.5 px-3">Участник</th>
                <th className="py-2.5 px-3">Объект</th>
                <th className="py-2.5 px-3">Криптографический хеш (SHA-256)</th>
                <th className="py-2.5 px-3">Проверка</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {auditLogs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-800/40">
                  <td className="py-2.5 px-3 font-bold text-blue-400">{log.id}</td>
                  <td className="py-2.5 px-3 text-slate-400 whitespace-nowrap">{log.timestamp}</td>
                  <td className="py-2.5 px-3 font-semibold text-white">{log.operation}</td>
                  <td className="py-2.5 px-3 text-slate-300">{log.participant}</td>
                  <td className="py-2.5 px-3 text-slate-400">{log.targetObject}</td>
                  <td className="py-2.5 px-3 font-mono text-[10px] text-emerald-400 max-w-xs truncate">
                    {log.hash || `0x7f8a9b2c3d4e5f6a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b2c3d4e${log.id}`}
                  </td>
                  <td className="py-2.5 px-3 whitespace-nowrap">
                    <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-400 bg-emerald-950 border border-emerald-800 px-2 py-0.5 rounded">
                      <CheckCircle2 className="w-3 h-3" />
                      <span>ВЕРИФИЦИРОВАНО</span>
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
