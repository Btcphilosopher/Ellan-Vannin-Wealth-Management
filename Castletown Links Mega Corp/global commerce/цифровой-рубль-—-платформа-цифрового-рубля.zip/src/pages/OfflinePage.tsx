import React, { useState } from 'react';
import { useSimulation } from '../simulation/SimulationContext';
import { formatRuble } from '../utils/formatters';
import { WifiOff, ArrowRight, ShieldCheck, RefreshCw, Lock, Cpu, CheckCircle2 } from 'lucide-react';

export const OfflinePage: React.FC = () => {
  const { accounts, executePayment } = useSimulation();

  const [offlineAccount, setOfflineAccount] = useState({
    id: 'OFFLINE-WALLET-77049',
    hardwareChipId: 'SECURE_ELEMENT_RU_v3_889104',
    reservedBalance: 15000,
    maxLimit: 50000,
    pendingLocalTxsCount: 2,
    lastSyncTime: '18.09.2026 13:10:00',
  });

  const [reserveInput, setReserveInput] = useState('5000');
  const [offlinePaymentAmt, setOfflinePaymentAmt] = useState('850');
  const [offlineStatusMsg, setOfflineStatusMsg] = useState('');

  const flowSteps = [
    'ОНЛАЙН-СЧЕТ ЦР',
    'РЕЗЕРВИРОВАНИЕ СРЕДСТВ',
    'SECURE ELEMENT CHIP',
    'ОФЛАЙН-ОПЛАТА P2P/P2M',
    'СИНХРОНИЗАЦИЯ С ПЛАТФОРМОЙ',
  ];

  const handleReserveFunds = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(reserveInput);
    if (isNaN(amt) || amt <= 0) return;

    if (offlineAccount.reservedBalance + amt > offlineAccount.maxLimit) {
      setOfflineStatusMsg('Превышен законодательный лимит офлайн-кошелька (50 000 ₽)');
      return;
    }

    setOfflineAccount((prev) => ({
      ...prev,
      reservedBalance: prev.reservedBalance + amt,
    }));
    setOfflineStatusMsg(`Успешно зарезервировано ${formatRuble(amt)} в криптографическом модуле`);
  };

  const handleOfflineTransaction = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(offlinePaymentAmt);
    if (isNaN(amt) || amt <= 0) return;

    if (amt > offlineAccount.reservedBalance) {
      setOfflineStatusMsg('Недостаточно зарезервированных средств в офлайн-модуле');
      return;
    }

    setOfflineAccount((prev) => ({
      ...prev,
      reservedBalance: prev.reservedBalance - amt,
      pendingLocalTxsCount: prev.pendingLocalTxsCount + 1,
    }));
    setOfflineStatusMsg(`Офлайн-операция на сумму ${formatRuble(amt)} подписана чипом SECURE ELEMENT`);
  };

  const handleSyncOnline = () => {
    setOfflineStatusMsg('Синхронизация офлайн-реестра с Центральным реестром ЦБ завершена!');
    setOfflineAccount((prev) => ({
      ...prev,
      pendingLocalTxsCount: 0,
      lastSyncTime: new Date().toLocaleString('ru-RU'),
    }));
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-[#121929] border border-blue-900/60 rounded-xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-white uppercase font-mono tracking-wider">
            ОФЛАЙН-ОПЕРАЦИИ И ВТОРИЧНЫЙ ОФЛАЙН-КОШЕЛЕК
          </h2>
          <p className="text-xs text-slate-300 mt-0.5">
            Проведение расчетов при отсутствии связи (P2P/P2M) с использованием изолированного криптографического Secure Element.
          </p>
        </div>
        <span className="text-xs font-mono text-amber-400 bg-amber-950 border border-amber-800 px-3 py-1.5 rounded font-bold flex items-center gap-1.5">
          <WifiOff className="w-3.5 h-3.5" />
          <span>ОФЛАЙН РЕЖИМ ГОТОВ</span>
        </span>
      </div>

      {/* Visual Flowchart */}
      <div className="bg-[#121824] border border-slate-800 rounded-xl p-5 shadow-sm">
        <h3 className="text-xs font-bold text-slate-300 uppercase font-mono tracking-wider mb-4">
          СХЕМА ФУНКЦИОНИРОВАНИЯ ОФЛАЙН-КОШЕЛЬКА (OFFLINE ARCHITECTURE)
        </h3>

        <div className="flex flex-wrap items-center justify-between gap-2 bg-[#0d121c] p-4 rounded-lg border border-slate-800">
          {flowSteps.map((step, idx) => (
            <React.Fragment key={idx}>
              <div className="bg-[#161d2e] border border-slate-700 px-3 py-2 rounded text-center text-xs font-mono font-bold text-white">
                {step}
              </div>
              {idx < flowSteps.length - 1 && (
                <ArrowRight className="w-4 h-4 text-blue-500 hidden sm:block flex-shrink-0" />
              )}
            </React.Fragment>
          ))}
        </div>
      </div>

      {/* Simulator Interface */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 font-mono text-xs">
        {/* Reservation and Hardware Panel */}
        <div className="bg-[#121824] border border-slate-800 rounded-xl p-5 shadow-sm space-y-4">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider pb-3 border-b border-slate-800">
            1. ПОПОЛНЕНИЕ АППАРАТНОГО МОДУЛЯ (SECURE ELEMENT)
          </h3>

          <div className="bg-[#0f1420] p-3 rounded border border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Идентификатор чипа:</span>
              <span className="text-blue-400 font-bold">{offlineAccount.hardwareChipId}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Зарезервировано в чипе:</span>
              <span className="text-emerald-400 font-bold">{formatRuble(offlineAccount.reservedBalance)}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Макс. законодательный лимит:</span>
              <span className="text-white">{formatRuble(offlineAccount.maxLimit)}</span>
            </div>
          </div>

          <form onSubmit={handleReserveFunds} className="space-y-3">
            <div>
              <label className="block text-slate-300 mb-1">Зарезервировать сумму с онлайн-счета (₽)</label>
              <input
                type="number"
                value={reserveInput}
                onChange={(e) => setReserveInput(e.target.value)}
                className="w-full bg-[#161c2c] border border-slate-700 rounded p-2.5 text-white"
                required
              />
            </div>
            <button
              type="submit"
              className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded uppercase"
            >
              РЕЗЕРВИРОВАТЬ СРЕДСТВА В АППАРАТНОМ КОШЕЛЬКЕ
            </button>
          </form>
        </div>

        {/* Offline Execution Panel */}
        <div className="bg-[#121824] border border-slate-800 rounded-xl p-5 shadow-sm space-y-4">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider pb-3 border-b border-slate-800">
            2. ПРОВЕДЕНИЕ ОФЛАЙН-ОПЛАТЫ БЕЗ СВЯЗИ С СЕТЬЮ
          </h3>

          <form onSubmit={handleOfflineTransaction} className="space-y-3">
            <div>
              <label className="block text-slate-300 mb-1">Сумма офлайн-покупки / P2P перевода (₽)</label>
              <input
                type="number"
                value={offlinePaymentAmt}
                onChange={(e) => setOfflinePaymentAmt(e.target.value)}
                className="w-full bg-[#161c2c] border border-slate-700 rounded p-2.5 text-white"
                required
              />
            </div>
            <button
              type="submit"
              className="w-full py-2.5 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded uppercase"
            >
              ПОДПИСАТЬ ОФЛАЙН-ТРАНЗАКЦИЮ ЧИПОМ
            </button>
          </form>

          <div className="bg-[#0f1420] p-3 rounded border border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Несинхронизированных транзакций:</span>
              <span className="text-amber-400 font-bold">{offlineAccount.pendingLocalTxsCount}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Последняя синхронизация:</span>
              <span className="text-slate-300">{offlineAccount.lastSyncTime}</span>
            </div>

            <button
              onClick={handleSyncOnline}
              className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded uppercase mt-2 flex items-center justify-center gap-2"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>ВОССТАНОВИТЬ СВЯЗЬ И СИНХРОНИЗИРОВАТЬ С ЦБ</span>
            </button>
          </div>
        </div>
      </div>

      {offlineStatusMsg && (
        <div className="p-3 bg-[#161c2c] border border-blue-800 text-blue-300 font-mono text-xs rounded-lg">
          {offlineStatusMsg}
        </div>
      )}
    </div>
  );
};
