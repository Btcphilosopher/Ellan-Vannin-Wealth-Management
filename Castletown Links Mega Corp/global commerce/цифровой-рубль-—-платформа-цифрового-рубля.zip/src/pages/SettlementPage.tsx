import React, { useState } from 'react';
import { useSimulation } from '../simulation/SimulationContext';
import { formatRuble } from '../utils/formatters';
import { RefreshCw, CheckCircle2, Landmark, Play, Layers, ShieldCheck } from 'lucide-react';

export const SettlementPage: React.FC = () => {
  const { settlementQueue, pendingSettlementVolume, processAllSettlements } = useSimulation();

  const [clearingMsg, setClearingMsg] = useState<string | null>(null);

  const handleRunClearing = () => {
    processAllSettlements();
    setClearingMsg('Все межбанковские расчеты клиринговой очереди успешно исполнены!');
    setTimeout(() => setClearingMsg(null), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-[#121929] border border-blue-900/60 rounded-xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-white uppercase font-mono tracking-wider">
            ЦЕНТР РАСЧЕТОВ И ВАЛОВЫЙ КЛИРИНГ БАНКА РОССИИ
          </h2>
          <p className="text-xs text-slate-300 mt-0.5">
            Окончательные непрерывные межбанковские расчеты в режиме реального времени (RTGS).
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleRunClearing}
            className="inline-flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-mono text-xs font-bold px-4 py-2 rounded-lg transition-colors shadow"
          >
            <RefreshCw className="w-4 h-4" />
            <span>ИСПОЛНИТЬ КЛИРИНГ</span>
          </button>
        </div>
      </div>

      {clearingMsg && (
        <div className="p-3 bg-emerald-950 border border-emerald-800 text-emerald-300 font-mono text-xs rounded-lg">
          {clearingMsg}
        </div>
      )}

      {/* Summary Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono">
        <div className="bg-[#121824] border border-slate-800 rounded-xl p-4">
          <span className="text-[10px] font-bold text-slate-400 uppercase">ОБЪЕМ В ОЧЕРЕДИ КЛИРИНГА</span>
          <div className="text-xl font-bold text-amber-400 mt-1">{formatRuble(pendingSettlementVolume)}</div>
          <span className="text-[10px] text-slate-500 block mt-1">Ожидают окончательного расчета</span>
        </div>

        <div className="bg-[#121824] border border-slate-800 rounded-xl p-4">
          <span className="text-[10px] font-bold text-slate-400 uppercase">ПОЗИЦИЙ В ОЧЕРЕДИ</span>
          <div className="text-xl font-bold text-white mt-1">{settlementQueue.length} записей</div>
          <span className="text-[10px] text-emerald-400 block mt-1">Задержка клиринга &lt; 0.4 сек</span>
        </div>

        <div className="bg-[#121824] border border-slate-800 rounded-xl p-4">
          <span className="text-[10px] font-bold text-slate-400 uppercase">РЕЖИМ ИСПОЛНЕНИЯ</span>
          <div className="text-xl font-bold text-blue-400 mt-1">REAL-TIME GROSS</div>
          <span className="text-[10px] text-slate-500 block mt-1">Гарантия безотзывности ЦБ</span>
        </div>
      </div>

      {/* Clearing Queue Table */}
      <div className="bg-[#121824] border border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
          <h3 className="text-sm font-bold text-white uppercase font-mono tracking-wider">
            ОЧЕРЕДЬ РЕГУЛЯРНЫХ МЕЖБАНКОВСКИХ РАСЧЕТОВ (SETTLEMENT QUEUE)
          </h3>
          <span className="text-[10px] font-mono text-slate-400 bg-slate-900 px-2 py-1 rounded">
            АВТОМАТИЧЕСКИЙ КЛИРИНГ
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px]">
                <th className="py-2.5 px-3">ID Записи</th>
                <th className="py-2.5 px-3">Банк-Плательщик</th>
                <th className="py-2.5 px-3">Банк-Получатель</th>
                <th className="py-2.5 px-3">Сумма (₽)</th>
                <th className="py-2.5 px-3">Время поступления</th>
                <th className="py-2.5 px-3">Статус</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {settlementQueue.map((item) => (
                <tr key={item.id} className="hover:bg-slate-800/40">
                  <td className="py-2.5 px-3 font-bold text-blue-400">{item.id}</td>
                  <td className="py-2.5 px-3 font-semibold">{item.payerBankName}</td>
                  <td className="py-2.5 px-3 font-semibold">{item.recipientBankName}</td>
                  <td className="py-2.5 px-3 font-bold text-white whitespace-nowrap">
                    {formatRuble(item.amount)}
                  </td>
                  <td className="py-2.5 px-3 text-slate-400 whitespace-nowrap">{item.timestamp}</td>
                  <td className="py-2.5 px-3 whitespace-nowrap">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        item.queueStatus === 'QUEUED'
                          ? 'bg-amber-950 text-amber-300 border border-amber-800'
                          : 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                      }`}
                    >
                      {item.queueStatus === 'QUEUED' ? 'В ОЧЕРЕДИ' : 'ИСПОЛНЕНО'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
