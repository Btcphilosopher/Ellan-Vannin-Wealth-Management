import React, { useState } from 'react';
import { useSimulation } from '../simulation/SimulationContext';
import { SimpleBarChart } from '../components/charts/SimpleBarChart';
import { formatRuble } from '../utils/formatters';
import { TrendingUp, AlertTriangle, ShieldCheck, Activity, Zap } from 'lucide-react';

export const LiquidityPage: React.FC = () => {
  const { institutions, runStressTest } = useSimulation();

  const [stressLog, setStressLog] = useState<string | null>(null);

  const handleRunStressTest = () => {
    const res = runStressTest();
    setStressLog(res.message);
  };

  const chartData = institutions
    .filter((i) => i.type !== 'CENTRAL_BANK')
    .map((b) => ({
      label: b.name.slice(0, 10),
      value: b.liquidityPosition,
    }));

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-[#121929] border border-blue-900/60 rounded-xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-white uppercase font-mono tracking-wider">
            МОНИТОРИНГ ЛИКВИДНОСТИ И СТРЕСС-ТЕСТИРОВАНИЕ
          </h2>
          <p className="text-xs text-slate-300 mt-0.5">
            Непрерывный контроль ликвидности кредитных организаций на центральной платформе.
          </p>
        </div>

        <button
          onClick={handleRunStressTest}
          className="inline-flex items-center gap-2 bg-rose-600 hover:bg-rose-500 text-white font-mono text-xs font-bold px-4 py-2 rounded-lg transition-colors shadow"
        >
          <Zap className="w-4 h-4" />
          <span>ЗАПУСТИТЬ СТРЕСС-ТЕСТ ЛИКВИДНОСТИ</span>
        </button>
      </div>

      {stressLog && (
        <div className="p-3 bg-amber-950 border border-amber-800 text-amber-300 font-mono text-xs rounded-lg animate-pulse">
          {stressLog}
        </div>
      )}

      {/* Chart */}
      <SimpleBarChart
        data={chartData}
        title="ОСТАТКИ ЛИКВИДНОСТИ БАНКОВ-УЧАСТНИКОВ НА ПЛАТФОРМЕ ЦБ (₽)"
        height={200}
        primaryColor="#10b981"
        formatValue={(v) => formatRuble(v)}
      />

      {/* Detailed Bank Liquidity Table */}
      <div className="bg-[#121824] border border-slate-800 rounded-xl p-5 shadow-sm">
        <h3 className="text-sm font-bold text-white uppercase font-mono tracking-wider pb-3 border-b border-slate-800 mb-4">
          ПОЗИЦИИ ЛИКВИДНОСТИ КРЕДИТНЫХ ОРГАНИЗАЦИЙ
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px]">
                <th className="py-2.5 px-3">Участник</th>
                <th className="py-2.5 px-3">БИК</th>
                <th className="py-2.5 px-3">Позиция ликвидности (₽)</th>
                <th className="py-2.5 px-3">Ожидающие списания</th>
                <th className="py-2.5 px-3">Чистая позиция</th>
                <th className="py-2.5 px-3">Статус Риска</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {institutions
                .filter((i) => i.type !== 'CENTRAL_BANK')
                .map((b) => {
                  const net = b.liquidityPosition - b.pendingSettlement;
                  const isLow = net < 50000000000;

                  return (
                    <tr key={b.id} className="hover:bg-slate-800/40">
                      <td className="py-2.5 px-3 font-bold text-white">{b.name}</td>
                      <td className="py-2.5 px-3 text-slate-400">{b.bik}</td>
                      <td className="py-2.5 px-3 font-bold text-emerald-400">
                        {formatRuble(b.liquidityPosition)}
                      </td>
                      <td className="py-2.5 px-3 text-amber-400 font-bold">
                        {formatRuble(b.pendingSettlement)}
                      </td>
                      <td className="py-2.5 px-3 font-bold text-blue-300">{formatRuble(net)}</td>
                      <td className="py-2.5 px-3 whitespace-nowrap">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            isLow
                              ? 'bg-amber-950 text-amber-300 border border-amber-800'
                              : 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          }`}
                        >
                          {isLow ? 'ПРЕДУПРЕЖДЕНИЕ' : 'НОРМА'}
                        </span>
                      </td>
                    </tr>
                  );
                })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
