import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import {
  DigitalRubleAccount,
  Institution,
  Merchant,
  Transaction,
  IssuanceOperation,
  SettlementItem,
  SmartContract,
  OfflineTransaction,
  RiskAlert,
  AuditEvent,
  RegionalData,
  SystemServiceStatus,
  PaymentMethod,
} from '../types';
import {
  INITIAL_ACCOUNTS,
  INITIAL_BANKS,
  INITIAL_MERCHANTS,
  INITIAL_TRANSACTIONS,
  INITIAL_ISSUANCE_OPS,
  INITIAL_SETTLEMENT_QUEUE,
  INITIAL_SMART_CONTRACTS,
  INITIAL_OFFLINE_TXS,
  INITIAL_RISK_ALERTS,
  INITIAL_AUDIT_LOGS,
  REGIONAL_DATA,
  INITIAL_SERVICES,
} from './seedData';
import { formatDateTime } from '../utils/formatters';

interface SimulationContextType {
  // Aggregate Metrics
  totalCirculation: number;
  totalIssued: number;
  totalRedeemed: number;
  todayOpsCount: number;
  todayOpsVolume: number;
  accountsCount: number;
  activeAccountsCount: number;
  participantsCount: number;
  merchantsCount: number;
  pendingSettlementVolume: number;
  controlEventsCount: number;

  // Collections
  accounts: DigitalRubleAccount[];
  institutions: Institution[];
  merchants: Merchant[];
  transactions: Transaction[];
  issuanceOps: IssuanceOperation[];
  settlementQueue: SettlementItem[];
  smartContracts: SmartContract[];
  offlineTxs: OfflineTransaction[];
  riskAlerts: RiskAlert[];
  auditLogs: AuditEvent[];
  regionalData: RegionalData[];
  services: SystemServiceStatus[];

  // Controls & Engine State
  simSpeed: 1 | 10 | 100;
  isSimRunning: boolean;
  simTime: Date;

  // Action Handlers
  executeIssuance: (
    amount: number,
    participantId: string,
    basis: string,
    type: 'ISSUANCE' | 'REDEMPTION'
  ) => { success: boolean; message: string };

  executePayment: (data: {
    payerAccountId: string;
    recipientAccountId: string;
    amount: number;
    purpose: string;
    method: PaymentMethod;
  }) => { success: boolean; message: string; transaction?: Transaction };

  createAccount: (data: {
    ownerName: string;
    ownerTaxId: string;
    type: 'INDIVIDUAL' | 'BUSINESS' | 'SOLE_TRADER';
    bankId: string;
    initialBalance: number;
    region: string;
  }) => DigitalRubleAccount;

  toggleAccountStatus: (accountId: string) => void;

  createSmartContract: (data: {
    title: string;
    payerAccountId: string;
    recipientAccountId: string;
    amount: number;
    conditionType: 'DELIVERY_VERIFICATION' | 'REGULAR_SCHEDULE' | 'TAX_CLEARANCE' | 'CONDITIONAL_FINANCING';
    conditionDesc: string;
    executionDate: string;
  }) => SmartContract;

  executeSmartContract: (contractId: string) => { success: boolean; message: string };

  processSettlementQueueItem: (itemId: string) => void;
  processAllSettlements: () => void;

  resolveRiskAlert: (alertId: string, action: 'CONFIRM' | 'DISMISS') => void;

  addOfflineTx: (amount: number, recipientName: string) => void;
  syncOfflineTxs: () => { count: number; totalAmount: number };
  runStressTest: () => { success: boolean; message: string };

  setSimSpeed: (speed: 1 | 10 | 100) => void;
  toggleSimRunning: () => void;
  resetSimulation: () => void;
}

const SimulationContext = createContext<SimulationContextType | undefined>(undefined);

export const SimulationProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Aggregate balances
  const [totalCirculation, setTotalCirculation] = useState<number>(18492700000000);
  const [totalIssued, setTotalIssued] = useState<number>(19100000000000);
  const [totalRedeemed, setTotalRedeemed] = useState<number>(607300000000);

  const [todayOpsCount, setTodayOpsCount] = useState<number>(2481392);
  const [todayOpsVolume, setTodayOpsVolume] = useState<number>(8293104000);
  const [accountsCount] = useState<number>(14820400);
  const [activeAccountsCount] = useState<number>(9420100);
  const [merchantsCount] = useState<number>(542100);

  // Stateful collections
  const [accounts, setAccounts] = useState<DigitalRubleAccount[]>(INITIAL_ACCOUNTS);
  const [institutions, setInstitutions] = useState<Institution[]>(INITIAL_BANKS);
  const [merchants, setMerchants] = useState<Merchant[]>(INITIAL_MERCHANTS);
  const [transactions, setTransactions] = useState<Transaction[]>(INITIAL_TRANSACTIONS);
  const [issuanceOps, setIssuanceOps] = useState<IssuanceOperation[]>(INITIAL_ISSUANCE_OPS);
  const [settlementQueue, setSettlementQueue] = useState<SettlementItem[]>(INITIAL_SETTLEMENT_QUEUE);
  const [smartContracts, setSmartContracts] = useState<SmartContract[]>(INITIAL_SMART_CONTRACTS);
  const [offlineTxs, setOfflineTxs] = useState<OfflineTransaction[]>(INITIAL_OFFLINE_TXS);
  const [riskAlerts, setRiskAlerts] = useState<RiskAlert[]>(INITIAL_RISK_ALERTS);
  const [auditLogs, setAuditLogs] = useState<AuditEvent[]>(INITIAL_AUDIT_LOGS);
  const [regionalData, setRegionalData] = useState<RegionalData[]>(REGIONAL_DATA);
  const [services, setServices] = useState<SystemServiceStatus[]>(INITIAL_SERVICES);

  // Engine speed & status
  const [simSpeed, setSimSpeed] = useState<1 | 10 | 100>(1);
  const [isSimRunning, setIsSimRunning] = useState<boolean>(true);
  const [simTime, setSimTime] = useState<Date>(new Date('2026-09-18T14:42:08'));

  const pendingSettlementVolume = settlementQueue
    .filter((s) => s.queueStatus !== 'COMPLETED')
    .reduce((acc, curr) => acc + curr.amount, 0);

  const controlEventsCount = riskAlerts.filter((r) => r.status === 'REQUIRES_CHECK').length;

  // Helper log audit
  const logAudit = useCallback(
    (participant: string, operation: string, targetObject: string, result: 'SUCCESS' | 'DENIED' | 'FLAGGED', level: 'INFO' | 'WARN' | 'CRITICAL') => {
      const newLog: AuditEvent = {
        id: `AUD-${Math.floor(100000 + Math.random() * 900000)}`,
        timestamp: formatDateTime(new Date()),
        participant,
        operation,
        targetObject,
        result,
        level,
      };
      setAuditLogs((prev) => [newLog, ...prev]);
    },
    []
  );

  // Simulation loop (Tick generator)
  useEffect(() => {
    if (!isSimRunning) return;

    const interval = setInterval(() => {
      setSimTime((prev) => new Date(prev.getTime() + 1000 * simSpeed));

      // Small background transaction generation for live feel
      if (Math.random() < 0.6) {
        const randAmount = Math.floor(100 + Math.random() * 4500);
        setTodayOpsCount((prev) => prev + 1);
        setTodayOpsVolume((prev) => prev + randAmount);

        // Update random service metrics slightly
        setServices((prev) =>
          prev.map((s) => ({
            ...s,
            latencyMs: Math.max(2, Math.floor(s.latencyMs + (Math.random() * 4 - 2))),
            tps: Math.floor(s.tps + (Math.random() * 40 - 20)),
            lastHeartbeat: formatDateTime(new Date()),
          }))
        );

        // Randomly update regional activity
        setRegionalData((prev) => {
          const idx = Math.floor(Math.random() * prev.length);
          const updated = [...prev];
          updated[idx] = {
            ...updated[idx],
            txCountToday: updated[idx].txCountToday + 1,
            volumeToday: updated[idx].volumeToday + randAmount,
          };
          return updated;
        });
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [isSimRunning, simSpeed]);

  // Execute Issuance or Redemption
  const executeIssuance = useCallback(
    (amount: number, participantId: string, basis: string, type: 'ISSUANCE' | 'REDEMPTION') => {
      const bank = institutions.find((i) => i.id === participantId) || institutions[0];

      if (type === 'REDEMPTION' && bank.liquidityPosition < amount) {
        return {
          success: false,
          message: 'Ошибка: недопустимая сумма погашения. Превышает остаток ликвидности банка-участника.',
        };
      }

      const balBefore = bank.liquidityPosition;
      const balAfter = type === 'ISSUANCE' ? balBefore + amount : balBefore - amount;

      // Update bank
      setInstitutions((prev) =>
        prev.map((inst) => (inst.id === bank.id ? { ...inst, liquidityPosition: balAfter } : inst))
      );

      // Update circulation
      if (type === 'ISSUANCE') {
        setTotalCirculation((prev) => prev + amount);
        setTotalIssued((prev) => prev + amount);
      } else {
        setTotalCirculation((prev) => prev - amount);
        setTotalRedeemed((prev) => prev + amount);
      }

      const opId = `ISS-${Math.floor(10000 + Math.random() * 90000)}`;
      const newOp: IssuanceOperation = {
        id: opId,
        type,
        amount,
        date: formatDateTime(new Date()),
        basis,
        participantId: bank.id,
        participantName: bank.name,
        balanceBefore: balBefore,
        balanceAfter: balAfter,
        status: 'COMPLETED',
        auditId: `AUD-${opId}`,
      };

      setIssuanceOps((prev) => [newOp, ...prev]);
      logAudit(
        'Банк России',
        type === 'ISSUANCE' ? 'ВЫПУСК ЦИФРОВЫХ РУБЛЕЙ (ЭМИССИЯ)' : 'ПОГАШЕНИЕ ЦИФРОВЫХ РУБЛЕЙ',
        opId,
        'SUCCESS',
        'INFO'
      );

      return {
        success: true,
        message:
          type === 'ISSUANCE'
            ? `Выпуск ₽ ${amount.toLocaleString('ru-RU')} проведен успешно.`
            : `Погашение ₽ ${amount.toLocaleString('ru-RU')} выполнено успешно.`,
      };
    },
    [institutions, logAudit]
  );

  // Execute Payment / Transfer
  const executePayment = useCallback(
    (data: {
      payerAccountId: string;
      recipientAccountId: string;
      amount: number;
      purpose: string;
      method: PaymentMethod;
    }) => {
      const { payerAccountId, recipientAccountId, amount, purpose, method } = data;

      // Find accounts
      const payer = accounts.find((a) => a.id === payerAccountId);
      const recipientAcc = accounts.find((a) => a.id === recipientAccountId);
      const recipientMerch = merchants.find((m) => m.id === recipientAccountId);

      if (!payer) {
        return { success: false, message: 'Недействительный плательщик (счет не найден).' };
      }

      if (payer.status === 'BLOCKED') {
        return { success: false, message: 'Операция отклонена: счет плательщика заблокирован.' };
      }

      if (payer.availableBalance < amount) {
        return { success: false, message: 'Ошибка: недостаточный остаток на счете цифрового рубля.' };
      }

      const recipientName = recipientAcc ? recipientAcc.ownerName : recipientMerch ? recipientMerch.name : 'Получатель ЦР';
      const recipientBank = recipientAcc ? recipientAcc.bankName : recipientMerch ? recipientMerch.bankName : 'ПЛАТФОРМА ЦБ';

      // Atomic Balance Updates
      setAccounts((prev) =>
        prev.map((acc) => {
          if (acc.id === payerAccountId) {
            return {
              ...acc,
              balance: acc.balance - amount,
              availableBalance: acc.availableBalance - amount,
              transactionCount: acc.transactionCount + 1,
              lastOperationDate: formatDateTime(new Date()),
            };
          }
          if (recipientAcc && acc.id === recipientAccountId) {
            return {
              ...acc,
              balance: acc.balance + amount,
              availableBalance: acc.availableBalance + amount,
              transactionCount: acc.transactionCount + 1,
              lastOperationDate: formatDateTime(new Date()),
            };
          }
          return acc;
        })
      );

      if (recipientMerch) {
        setMerchants((prev) =>
          prev.map((m) =>
            m.id === recipientAccountId
              ? {
                  ...m,
                  todayTurnover: m.todayTurnover + amount,
                  todayTxCount: m.todayTxCount + 1,
                  totalBalance: m.totalBalance + amount,
                }
              : m
          )
        );
      }

      // Record transaction
      const txId = `DR-${Math.floor(2000000 + Math.random() * 8000000)}`;
      const auditId = `AUD-${Math.floor(100000 + Math.random() * 900000)}`;
      const isHighRisk = amount >= 5000000;

      const newTx: Transaction = {
        id: txId,
        timestamp: formatDateTime(new Date()),
        payerAccountId,
        payerName: payer.ownerName,
        payerBank: payer.bankName,
        recipientAccountId,
        recipientName,
        recipientBank,
        amount,
        purpose,
        method,
        status: isHighRisk ? 'SUSPENDED' : 'EXECUTED',
        processingTimeMs: Math.floor(8 + Math.random() * 15),
        auditId,
        riskScore: isHighRisk ? 88 : Math.floor(Math.random() * 10),
        region: payer.region,
      };

      setTransactions((prev) => [newTx, ...prev]);
      setTodayOpsCount((prev) => prev + 1);
      setTodayOpsVolume((prev) => prev + amount);

      // Create Risk Alert if high amount
      if (isHighRisk) {
        const riskAlert: RiskAlert = {
          id: `RSK-${Math.floor(100000 + Math.random() * 900000)}`,
          transactionId: txId,
          amount,
          payerName: payer.ownerName,
          reason: 'ОТКЛОНЕНИЕ ОТ ЗАДАННОГО ШАБЛОНА — КРУПНЫЙ ПЕРЕВОД ТРЕБУЕТ ПРОВЕРКИ',
          severity: 'CRITICAL',
          status: 'REQUIRES_CHECK',
          timestamp: formatDateTime(new Date()),
        };
        setRiskAlerts((prev) => [riskAlert, ...prev]);
        logAudit(payer.bankName, 'ПРИОСТАНОВКА ОПЕРАЦИИ РИСК-КОНТРОЛЕМ', txId, 'FLAGGED', 'WARN');
      } else {
        logAudit(payer.bankName, 'ИСПОЛНЕНИЕ ПЛАТЕЖА В ЦИФРОВЫХ РУБЛЯХ', txId, 'SUCCESS', 'INFO');
      }

      // If different bank, create settlement queue entry
      if (payer.bankId !== (recipientAcc?.bankId || recipientMerch?.bankId)) {
        const newSettlement: SettlementItem = {
          id: `SETTL-${Math.floor(1000 + Math.random() * 9000)}`,
          payerBankId: payer.bankId,
          payerBankName: payer.bankName,
          recipientBankId: recipientAcc?.bankId || recipientMerch?.bankId || 'BANK-02',
          recipientBankName: recipientBank,
          amount,
          queueStatus: 'QUEUED',
          timestamp: formatDateTime(new Date()),
          priority: amount > 1000000 ? 'HIGH' : 'NORMAL',
        };
        setSettlementQueue((prev) => [newSettlement, ...prev]);
      }

      return {
        success: true,
        message: isHighRisk
          ? `Платеж ${txId} принят в обработку, но отправлен на финмониторинг (крупная сумма).`
          : `Платеж ${txId} успешно исполнен.`,
        transaction: newTx,
      };
    },
    [accounts, merchants, logAudit]
  );

  // Create new account
  const createAccount = useCallback(
    (data: {
      ownerName: string;
      ownerTaxId: string;
      type: 'INDIVIDUAL' | 'BUSINESS' | 'SOLE_TRADER';
      bankId: string;
      initialBalance: number;
      region: string;
    }) => {
      const bank = institutions.find((i) => i.id === data.bankId) || institutions[0];
      const prefix = data.type === 'INDIVIDUAL' ? '408178100' : data.type === 'BUSINESS' ? '407028100' : '408028100';
      const suffix = Math.floor(1000000000 + Math.random() * 9000000000).toString();
      const accountId = `${prefix}${suffix}`;

      const newAcc: DigitalRubleAccount = {
        id: accountId,
        ownerName: data.ownerName,
        ownerTaxId: data.ownerTaxId,
        type: data.type,
        bankId: bank.id,
        bankName: bank.name,
        balance: data.initialBalance,
        availableBalance: data.initialBalance,
        status: 'ACTIVE',
        transactionCount: 0,
        lastOperationDate: formatDateTime(new Date()),
        createdAt: formatDateTime(new Date()).split(' ')[0],
        region: data.region || 'Москва',
      };

      setAccounts((prev) => [newAcc, ...prev]);
      logAudit(bank.name, 'ОТКРЫТИЕ СЧЕТА ЦИФРОВОГО РУБЛЯ', accountId, 'SUCCESS', 'INFO');
      return newAcc;
    },
    [institutions, logAudit]
  );

  // Toggle Account Block Status
  const toggleAccountStatus = useCallback(
    (accountId: string) => {
      setAccounts((prev) =>
        prev.map((acc) => {
          if (acc.id === accountId) {
            const nextStatus = acc.status === 'ACTIVE' ? 'BLOCKED' : 'ACTIVE';
            const available = nextStatus === 'ACTIVE' ? acc.balance : 0;
            logAudit('Платформа ЦБ', `ИЗМЕНЕНИЕ СТАТУСА СЧЕТА (${nextStatus})`, accountId, 'SUCCESS', 'WARN');
            return {
              ...acc,
              status: nextStatus,
              availableBalance: available,
            };
          }
          return acc;
        })
      );
    },
    [logAudit]
  );

  // Smart Contracts
  const createSmartContract = useCallback(
    (data: {
      title: string;
      payerAccountId: string;
      recipientAccountId: string;
      amount: number;
      conditionType: 'DELIVERY_VERIFICATION' | 'REGULAR_SCHEDULE' | 'TAX_CLEARANCE' | 'CONDITIONAL_FINANCING';
      conditionDesc: string;
      executionDate: string;
    }) => {
      const payer = accounts.find((a) => a.id === data.payerAccountId);
      const recipient = accounts.find((a) => a.id === data.recipientAccountId);

      const contractId = `SC-${Math.floor(1000 + Math.random() * 9000)}`;
      const newContract: SmartContract = {
        id: contractId,
        title: data.title,
        payerAccountId: data.payerAccountId,
        payerName: payer?.ownerName || 'Организация-плательщик',
        recipientAccountId: data.recipientAccountId,
        recipientName: recipient?.ownerName || 'Организация-получатель',
        amount: data.amount,
        conditionType: data.conditionType,
        conditionDesc: data.conditionDesc,
        executionDate: data.executionDate,
        expiryDate: data.executionDate,
        status: 'WAITING_CONDITION',
      };

      setSmartContracts((prev) => [newContract, ...prev]);
      logAudit('Платформа Умных Контрактов', 'РЕГИСТРАЦИЯ ИСПОЛНЯЕМОГО КОНТРАКТА', contractId, 'SUCCESS', 'INFO');
      return newContract;
    },
    [accounts, logAudit]
  );

  const executeSmartContract = useCallback(
    (contractId: string) => {
      const sc = smartContracts.find((c) => c.id === contractId);
      if (!sc) return { success: false, message: 'Контракт не найден' };

      // Try execute payment
      const res = executePayment({
        payerAccountId: sc.payerAccountId,
        recipientAccountId: sc.recipientAccountId,
        amount: sc.amount,
        purpose: `Исполнение смарт-контракта ${sc.id}: ${sc.title}`,
        method: 'PROGRAMMABLE',
      });

      if (res.success) {
        setSmartContracts((prev) =>
          prev.map((c) => (c.id === contractId ? { ...c, status: 'EXECUTED' } : c))
        );
        logAudit('Платформа Умных Контрактов', 'АВТОМАТИЧЕСКОЕ ИСПОЛНЕНИЕ УСЛОВИЯ КОНТРАКТА', contractId, 'SUCCESS', 'INFO');
        return { success: true, message: `Умный контракт ${contractId} успешно исполнен!` };
      }

      return { success: false, message: `Ошибка исполнения смарт-контракта: ${res.message}` };
    },
    [smartContracts, executePayment, logAudit]
  );

  // Settlement processing
  const processSettlementQueueItem = useCallback(
    (itemId: string) => {
      setSettlementQueue((prev) =>
        prev.map((item) => {
          if (item.id === itemId) {
            logAudit('Центр Расчетов ЦБ', 'МЕЖБАНКОВСКИЙ РАСЧЕТ ИСПОЛНЕН', itemId, 'SUCCESS', 'INFO');
            return { ...item, queueStatus: 'COMPLETED' };
          }
          return item;
        })
      );
    },
    [logAudit]
  );

  const processAllSettlements = useCallback(() => {
    setSettlementQueue((prev) =>
      prev.map((item) => ({ ...item, queueStatus: 'COMPLETED' }))
    );
    logAudit('Центр Расчетов ЦБ', 'ПАКЕТНЫЙ МЕЖБАНКОВСКИЙ РАСЧЕТ ВЫПОЛНЕН', 'ALL_QUEUED', 'SUCCESS', 'INFO');
  }, [logAudit]);

  // Risk alert resolution
  const resolveRiskAlert = useCallback(
    (alertId: string, action: 'CONFIRM' | 'DISMISS') => {
      const alert = riskAlerts.find((a) => a.id === alertId);
      if (!alert) return;

      setRiskAlerts((prev) =>
        prev.map((a) =>
          a.id === alertId
            ? { ...a, status: action === 'CONFIRM' ? 'CONFIRMED' : 'DISMISSED' }
            : a
        )
      );

      if (action === 'CONFIRM') {
        // Block associated transaction if needed
        setTransactions((prev) =>
          prev.map((t) => (t.id === alert.transactionId ? { ...t, status: 'REJECTED' } : t))
        );
        logAudit('ЦР Контроль Рисков', 'ПОДТВЕРЖДЕНИЕ ФРАУД-РИСКА. ОПЕРАЦИЯ ОТКЛОНЕНА', alert.transactionId, 'DENIED', 'CRITICAL');
      } else {
        setTransactions((prev) =>
          prev.map((t) => (t.id === alert.transactionId ? { ...t, status: 'EXECUTED' } : t))
        );
        logAudit('ЦР Контроль Рисков', 'ПОДТВЕРЖДЕНИЕ ЛЕГИТИМНОСТИ. ОПЕРАЦИЯ ВОЗОБНОВЛЕНА', alert.transactionId, 'SUCCESS', 'INFO');
      }
    },
    [riskAlerts, logAudit]
  );

  // Offline Transactions
  const addOfflineTx = useCallback(
    (amount: number, recipientName: string) => {
      const newOff: OfflineTransaction = {
        id: `OFF-${Math.floor(1000 + Math.random() * 9000)}`,
        deviceId: 'SEC-MOD-LOCAL-01',
        secureModuleId: 'HSM-RU-2026-901',
        amount,
        senderAccount: '40817810099810000001',
        senderName: 'Иванов Алексей Сергеевич',
        recipientAccount: 'TSP-77041289',
        recipientName,
        timestamp: formatDateTime(new Date()),
        syncStatus: 'SAVED_LOCALLY',
      };
      setOfflineTxs((prev) => [newOff, ...prev]);
    },
    []
  );

  const syncOfflineTxs = useCallback(() => {
    const unsynced = offlineTxs.filter((o) => o.syncStatus !== 'COMPLETED');
    const totalAmount = unsynced.reduce((acc, curr) => acc + curr.amount, 0);

    setOfflineTxs((prev) =>
      prev.map((o) => ({ ...o, syncStatus: 'COMPLETED' }))
    );

    if (unsynced.length > 0) {
      logAudit('Офлайн Модуль ЦР', `СИНХРОНИЗАЦИЯ ${unsynced.length} ОФЛАЙН-ОПЕРАЦИЙ`, 'OFFLINE_SYNC', 'SUCCESS', 'INFO');
    }

    return { count: unsynced.length, totalAmount };
  }, [offlineTxs, logAudit]);

  // Reset simulation
  const resetSimulation = useCallback(() => {
    setTotalCirculation(18492700000000);
    setTotalIssued(19100000000000);
    setTotalRedeemed(607300000000);
    setTodayOpsCount(2481392);
    setTodayOpsVolume(8293104000);
    setAccounts(INITIAL_ACCOUNTS);
    setInstitutions(INITIAL_BANKS);
    setMerchants(INITIAL_MERCHANTS);
    setTransactions(INITIAL_TRANSACTIONS);
    setIssuanceOps(INITIAL_ISSUANCE_OPS);
    setSettlementQueue(INITIAL_SETTLEMENT_QUEUE);
    setSmartContracts(INITIAL_SMART_CONTRACTS);
    setOfflineTxs(INITIAL_OFFLINE_TXS);
    setRiskAlerts(INITIAL_RISK_ALERTS);
    setAuditLogs(INITIAL_AUDIT_LOGS);
    setRegionalData(REGIONAL_DATA);
    setServices(INITIAL_SERVICES);
    logAudit('Система', 'СБРОС СИМУЛЯЦИОННОЙ СРЕДЫ К НАЧАЛЬНОМУ СОСТОЯНИЮ', 'RESET', 'SUCCESS', 'WARN');
  }, [logAudit]);

  const toggleSimRunning = useCallback(() => {
    setIsSimRunning((prev) => !prev);
  }, []);

  const runStressTest = useCallback(() => {
    setTodayOpsCount((prev) => prev + 100000);
    setTodayOpsVolume((prev) => prev + 50000000000);
    logAudit('СИСТЕМА РИСК-КОНТРОЛЯ', 'СТРЕСС_ТЕСТ', 'ПЛАТФОРМА', 'SUCCESS', 'INFO');
    return {
      success: true,
      message: 'Стресс-тестирование ликвидности успешно завершено: обработан пик 100 000 TPS, ликвидность банков в норме.',
    };
  }, [logAudit]);

  return (
    <SimulationContext.Provider
      value={{
        totalCirculation,
        totalIssued,
        totalRedeemed,
        todayOpsCount,
        todayOpsVolume,
        accountsCount,
        activeAccountsCount,
        participantsCount: institutions.length,
        merchantsCount,
        pendingSettlementVolume,
        controlEventsCount,
        accounts,
        institutions,
        merchants,
        transactions,
        issuanceOps,
        settlementQueue,
        smartContracts,
        offlineTxs,
        riskAlerts,
        auditLogs,
        regionalData,
        services,
        simSpeed,
        isSimRunning,
        simTime,
        executeIssuance,
        executePayment,
        createAccount,
        toggleAccountStatus,
        createSmartContract,
        executeSmartContract,
        processSettlementQueueItem,
        processAllSettlements,
        resolveRiskAlert,
        addOfflineTx,
        syncOfflineTxs,
        runStressTest,
        setSimSpeed,
        toggleSimRunning,
        resetSimulation,
      }}
    >
      {children}
    </SimulationContext.Provider>
  );
};

export const useSimulation = () => {
  const context = useContext(SimulationContext);
  if (!context) {
    throw new Error('useSimulation must be used within a SimulationProvider');
  }
  return context;
};
