import React, { useState } from 'react';
import { SimulationProvider } from './simulation/SimulationContext';
import { NavigationTab } from './types';
import { Header } from './components/layout/Header';
import { Sidebar } from './components/layout/Sidebar';

// Pages
import { OverviewPage } from './pages/OverviewPage';
import { ArchitecturePage } from './pages/ArchitecturePage';
import { IssuancePage } from './pages/IssuancePage';
import { AccountsPage } from './pages/AccountsPage';
import { ParticipantsPage } from './pages/ParticipantsPage';
import { PaymentsPage } from './pages/PaymentsPage';
import { ConsumerPage } from './pages/ConsumerPage';
import { SettlementPage } from './pages/SettlementPage';
import { MerchantPage } from './pages/MerchantPage';
import { OfflinePage } from './pages/OfflinePage';
import { ProgrammablePage } from './pages/ProgrammablePage';
import { LiquidityPage } from './pages/LiquidityPage';
import { RiskPage } from './pages/RiskPage';
import { AnalyticsPage } from './pages/AnalyticsPage';
import { AuditPage } from './pages/AuditPage';
import { OperationsPage } from './pages/OperationsPage';
import { EconomicLabPage } from './pages/EconomicLabPage';

function MainAppContent() {
  const [activeTab, setActiveTab] = useState<NavigationTab>('overview');

  const renderTabContent = () => {
    switch (activeTab) {
      case 'overview':
        return <OverviewPage />;
      case 'architecture':
        return <ArchitecturePage />;
      case 'issuance':
        return <IssuancePage />;
      case 'accounts':
        return <AccountsPage />;
      case 'participants':
        return <ParticipantsPage />;
      case 'payments':
        return <PaymentsPage />;
      case 'transfers':
        return <ConsumerPage />;
      case 'settlement':
        return <SettlementPage />;
      case 'merchants':
        return <MerchantPage />;
      case 'offline':
        return <OfflinePage />;
      case 'programmable':
        return <ProgrammablePage />;
      case 'liquidity':
        return <LiquidityPage />;
      case 'risk':
        return <RiskPage />;
      case 'analytics':
        return <AnalyticsPage />;
      case 'audit':
        return <AuditPage />;
      case 'system':
        return <OperationsPage />;
      case 'lab':
        return <EconomicLabPage />;
      default:
        return <OverviewPage />;
    }
  };

  return (
    <div className="min-h-screen bg-[#070a10] text-slate-100 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      {/* Top Banner Header */}
      <Header />

      {/* Main Content Area with Sidebar */}
      <div className="flex-1 flex max-w-[1920px] w-full mx-auto overflow-hidden">
        <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />

        <main className="flex-1 p-6 overflow-y-auto max-h-[calc(100vh-65px)]">
          {renderTabContent()}
        </main>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <SimulationProvider>
      <MainAppContent />
    </SimulationProvider>
  );
}
