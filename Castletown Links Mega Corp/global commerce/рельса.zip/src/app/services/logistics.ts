import { Injectable, signal } from '@angular/core';

// Re-exporting types for frontend use
export interface Station {
  id: string;
  nameRu: string;
  nameEn: string;
  regionRu: string;
  regionEn: string;
  code: string;
  lat: number;
  lng: number;
}

export interface Segment {
  id: string;
  fromId: string;
  toId: string;
  distanceKm: number;
  speedLimitKmh: number;
  riskFactor: number;
  isElectrified: boolean;
  congestion: number;
  isClosed: boolean;
}

export interface Terminal {
  id: string;
  stationId: string;
  nameRu: string;
  nameEn: string;
  capacityWagons: number;
  utilization: number;
  averageDwellHours: number;
  servicesRu: string[];
  servicesEn: string[];
}

export interface Wagon {
  id: string;
  typeRu: string;
  typeEn: string;
  number: string;
  capacityTons: number;
  volumeCbm: number;
  owner: string;
  statusRu: string;
  statusEn: string;
  stationId: string;
  dailyRateRub: number;
}

export interface Container {
  id: string;
  typeRu: string;
  typeEn: string;
  number: string;
  capacityTons: number;
  statusRu: string;
  statusEn: string;
  stationId: string;
}

export interface CostBreakdown {
  baseTransportRub: number;
  wagonRentRub: number;
  terminalHandlingRub: number;
  urgencySurchargeRub: number;
  insuranceRub: number;
  taxRub: number;
  totalRub: number;
}

export interface RouteOption {
  id: string;
  nameRu: string;
  nameEn: string;
  path: string[];
  distanceKm: number;
  travelTimeHours: number;
  delayRiskPercent: number;
  carbonCo2Kg: number;
  pricing: CostBreakdown;
  score: number;
  explanationRu: string;
  explanationEn: string;
}

export interface Shipment {
  id: string;
  cargoRu: string;
  cargoEn: string;
  cargoCode: string;
  weightTons: number;
  originId: string;
  destinationId: string;
  selectedRouteId: string;
  routePath: string[];
  currentStationId: string;
  progressPercent: number;
  eta: string;
  statusRu: string;
  statusEn: string;
  wagonsAssigned: string[];
  containersAssigned: string[];
  documents: string[];
  trackingEvents: {
    timestamp: string;
    stationId: string;
    eventRu: string;
    eventEn: string;
    status: string;
  }[];
}

export interface Alert {
  id: string;
  shipmentId: string;
  severity: 'warning' | 'critical';
  timestamp: string;
  messageRu: string;
  messageEn: string;
  causeRu: string;
  causeEn: string;
  recommendedActionRu: string;
  recommendedActionEn: string;
  resolved: boolean;
}

export interface Document {
  id: string;
  shipmentId: string;
  typeRu: string;
  typeEn: string;
  statusRu: string;
  statusEn: string;
  createdAt: string;
  signedAt?: string;
  signerName?: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  entityId: string;
  entityType: 'Shipment' | 'Document';
  actorRu: string;
  actorEn: string;
  actionRu: string;
  actionEn: string;
  details: string;
}

@Injectable({
  providedIn: 'root'
})
export class LogisticsService {
  // Localization state
  locale = signal<'ru' | 'en'>('ru');

  // RBAC Role Model State
  role = signal<'ГРУЗООТПРАВИТЕЛЬ' | 'ДИСПЕТЧЕР' | 'ЛОГИСТ' | 'EXECUTIVE' | 'АНАЛИТИК'>('ДИСПЕТЧЕР');

  // In-Memory Database Mirrors
  stations = signal<Station[]>([]);
  segments = signal<Segment[]>([]);
  terminals = signal<Terminal[]>([]);
  wagons = signal<Wagon[]>([]);
  containers = signal<Container[]>([]);
  shipments = signal<Shipment[]>([]);
  alerts = signal<Alert[]>([]);
  documents = signal<Document[]>([]);
  auditLogs = signal<AuditLog[]>([]);

  // Loading indicator
  isLoading = signal<boolean>(false);

  // Search Results & Active Route Calculation Cache
  routeOptions = signal<RouteOption[]>([]);
  isCalculatingRoutes = signal<boolean>(false);

  // Master demo state variables
  demoStep = signal<number>(1);
  demoSelectedRoute = signal<RouteOption | null>(null);
  demoSelectedWagonsCount = signal<number>(12);
  demoCreatedShipmentId = signal<string>('');

  constructor() {
    // Initial data fetch
    this.refreshState();
  }

  // Fetch full state from backend
  async refreshState() {
    this.isLoading.set(true);
    try {
      const res = await fetch('/api/v1/state');
      if (res.ok) {
        const data = await res.json();
        this.stations.set(data.stations || []);
        this.segments.set(data.segments || []);
        this.terminals.set(data.terminals || []);
        this.wagons.set(data.wagons || []);
        this.containers.set(data.containers || []);
        this.shipments.set(data.shipments || []);
        this.alerts.set(data.alerts || []);
        this.documents.set(data.documents || []);
        this.auditLogs.set(data.auditLogs || []);
      }
    } catch (e) {
      console.error('Failed to sync state with backend API:', e);
    } finally {
      this.isLoading.set(false);
    }
  }

  // Calculate alternative routes
  async calculateRoutes(params: {
    originId: string;
    destinationId: string;
    cargoRu: string;
    cargoEn: string;
    weightTons: number;
    isUrgent: boolean;
    wagonType: string;
  }) {
    this.isCalculatingRoutes.set(true);
    this.routeOptions.set([]);
    try {
      const res = await fetch('/api/v1/routes/calculate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params)
      });
      if (res.ok) {
        const data = await res.json();
        this.routeOptions.set(data.options || []);
      }
    } catch (e) {
      console.error('Failed to calculate alternative routes:', e);
    } finally {
      this.isCalculatingRoutes.set(false);
    }
  }

  // Book/Create new shipment
  async bookShipment(params: {
    cargoRu: string;
    cargoEn: string;
    cargoCode: string;
    weightTons: number;
    originId: string;
    destinationId: string;
    selectedRouteId: string;
    routePath: string[];
    wagonsCount: number;
    wagonType: string;
    isContainerized?: boolean;
    containerType?: string;
  }) {
    this.isLoading.set(true);
    try {
      const res = await fetch('/api/v1/shipments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params)
      });
      if (res.ok) {
        const data = await res.json();
        this.demoCreatedShipmentId.set(data.id);
        await this.refreshState();
        return data;
      }
    } catch (e) {
      console.error('Failed to book shipment:', e);
    } finally {
      this.isLoading.set(false);
    }
    return null;
  }

  // Re-route active shipment
  async rerouteShipment(shipmentId: string, newPath: string[]) {
    this.isLoading.set(true);
    try {
      const res = await fetch(`/api/v1/shipments/${shipmentId}/reroute`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ newPath })
      });
      if (res.ok) {
        await this.refreshState();
      }
    } catch (e) {
      console.error('Failed to reroute shipment:', e);
    } finally {
      this.isLoading.set(false);
    }
  }

  // Simulate delay incident
  async simulateDelay(shipmentId: string) {
    this.isLoading.set(true);
    try {
      const res = await fetch(`/api/v1/shipments/${shipmentId}/simulate-delay`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      if (res.ok) {
        await this.refreshState();
      }
    } catch (e) {
      console.error('Failed to simulate delay incident:', e);
    } finally {
      this.isLoading.set(false);
    }
  }

  // Sign document
  async signDocument(docId: string, signerName: string) {
    this.isLoading.set(true);
    try {
      const res = await fetch(`/api/v1/documents/${docId}/sign`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ signerName })
      });
      if (res.ok) {
        await this.refreshState();
      }
    } catch (e) {
      console.error('Failed to sign document:', e);
    } finally {
      this.isLoading.set(false);
    }
  }

  // AI Assistant Chat Request
  async askAi(message: string, history: { role: string; content: string }[]): Promise<string> {
    try {
      const res = await fetch('/api/v1/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message, history })
      });
      if (res.ok) {
        const data = await res.json();
        return data.text;
      }
    } catch (e) {
      console.error('Failed to get response from РЕЛЬСА AI:', e);
    }
    return 'Извините, произошла техническая ошибка при связи с РЕЛЬСА AI. Пожалуйста, попробуйте позже.';
  }
}
