import { ChangeDetectionStrategy, Component, inject, signal, computed, effect } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CommonModule, DecimalPipe, DatePipe } from '@angular/common';
import { ReactiveFormsModule, FormGroup, FormControl, Validators } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { LogisticsService, Shipment, RouteOption, Segment, Wagon, Document } from './services/logistics';
import { translations } from './utils/translations';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [CommonModule, RouterOutlet, ReactiveFormsModule, MatIconModule],
  providers: [DecimalPipe, DatePipe],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  logistics = inject(LogisticsService);
  protected readonly Math = Math;

  // Active Tab
  activeTab = signal<'home' | 'routes' | 'tracking' | 'dispatcher' | 'wagons' | 'terminals' | 'documents' | 'analytics' | 'ai'>('home');

  // Translation computed signal
  t = computed(() => {
    const locale = this.logistics.locale();
    return translations[locale];
  });

  // Current Server Time Simulation
  currentTime = signal<string>('');

  // Reactive Route Calculation Form
  routeForm = new FormGroup({
    originId: new FormControl('6', { nonNullable: true, validators: [Validators.required] }), // Yekaterinburg
    destinationId: new FormControl('1', { nonNullable: true, validators: [Validators.required] }), // Moscow
    cargoRu: new FormControl('Сталь листовая в рулонах', { nonNullable: true, validators: [Validators.required] }),
    cargoEn: new FormControl('Coiled Steel Sheets', { nonNullable: true, validators: [Validators.required] }),
    cargoCode: new FormControl('324102', { nonNullable: true }),
    weightTons: new FormControl(2400, { nonNullable: true, validators: [Validators.required, Validators.min(1)] }),
    wagonType: new FormControl('Полувагон', { nonNullable: true }),
    isUrgent: new FormControl(false, { nonNullable: true })
  });

  // AI Chat Messages state
  chatMessages = signal<{ role: 'user' | 'model'; content: string }[]>([
    {
      role: 'model',
      content: translations['ru'].aiGreeting
    }
  ]);
  chatInput = signal<string>('');
  isAiThinking = signal<boolean>(false);

  // Selected Interactive entities on UI
  selectedShipment = signal<Shipment | null>(null);
  selectedRouteOption = signal<RouteOption | null>(null);

  // Filters
  wagonTypeFilter = signal<string>('all');
  shipmentStatusFilter = signal<string>('all');
  documentStatusFilter = signal<string>('all');

  // Computed totals for dashboard
  activeAlertCount = computed(() => {
    return this.logistics.alerts().filter(a => !a.resolved).length;
  });

  totalActiveTonnage = computed(() => {
    return this.logistics.shipments()
      .filter(s => s.statusRu !== 'Прибыл' && s.statusRu !== 'Выдан')
      .reduce((sum, s) => sum + s.weightTons, 0);
  });

  totalRevenueRub = computed(() => {
    // Calculated based on completed + active shipments
    return this.logistics.shipments().length * 1840000;
  });

  constructor() {
    this.updateClock();
    setInterval(() => this.updateClock(), 1000);

    // Auto-select first active shipment on start to fill details
    effect(() => {
      const active = this.logistics.shipments();
      if (active.length > 0 && !this.selectedShipment()) {
        this.selectedShipment.set(active[0]);
      }
    });

    // Auto-update selected shipment if the global state is refreshed
    effect(() => {
      const selected = this.selectedShipment();
      if (selected) {
        const updated = this.logistics.shipments().find(s => s.id === selected.id);
        if (updated) {
          this.selectedShipment.set(updated);
        }
      }
    });
  }

  updateClock() {
    const options: Intl.DateTimeFormatOptions = {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false
    };
    this.currentTime.set(new Date().toLocaleTimeString('ru-RU', options));
  }

  // ==========================================
  // VIEW TRIGGERS & WORKFLOWS
  // ==========================================

  selectTab(tab: 'home' | 'routes' | 'tracking' | 'dispatcher' | 'wagons' | 'terminals' | 'documents' | 'analytics' | 'ai') {
    this.activeTab.set(tab);
    
    // Auto-sync AI Greeting language if tab transitions to AI
    if (tab === 'ai' && this.chatMessages().length === 1) {
      this.chatMessages.set([
        {
          role: 'model',
          content: this.t().aiGreeting
        }
      ]);
    }
  }

  toggleLanguage() {
    const nextLocale = this.logistics.locale() === 'ru' ? 'en' : 'ru';
    this.logistics.locale.set(nextLocale);
    
    // Refresh greeting in chat if it's the only message
    if (this.chatMessages().length === 1) {
      this.chatMessages.set([
        {
          role: 'model',
          content: translations[nextLocale].aiGreeting
        }
      ]);
    }
  }

  toggleRole(event: Event) {
    const select = event.target as HTMLSelectElement;
    const nextRole = select.value as 'ГРУЗООТПРАВИТЕЛЬ' | 'ДИСПЕТЧЕР' | 'ЛОГИСТ' | 'EXECUTIVE' | 'АНАЛИТИК';
    this.logistics.role.set(nextRole);
  }

  // Calculate Routes from UI form
  async onCalculate() {
    if (this.routeForm.invalid) return;
    const formVal = this.routeForm.getRawValue();
    await this.logistics.calculateRoutes({
      originId: formVal.originId,
      destinationId: formVal.destinationId,
      cargoRu: formVal.cargoRu,
      cargoEn: formVal.cargoEn,
      weightTons: formVal.weightTons,
      isUrgent: formVal.isUrgent,
      wagonType: formVal.wagonType
    });
    // Auto-select first option
    if (this.logistics.routeOptions().length > 0) {
      this.selectedRouteOption.set(this.logistics.routeOptions()[0]);
      this.logistics.demoSelectedRoute.set(this.logistics.routeOptions()[0]);
    }
  }

  selectRouteOption(option: RouteOption) {
    this.selectedRouteOption.set(option);
    this.logistics.demoSelectedRoute.set(option);
  }

  // Book Route Option
  async onBookRoute() {
    const route = this.selectedRouteOption();
    if (!route) return;

    const formVal = this.routeForm.getRawValue();
    const result = await this.logistics.bookShipment({
      cargoRu: formVal.cargoRu,
      cargoEn: formVal.cargoEn,
      cargoCode: formVal.cargoCode,
      weightTons: formVal.weightTons,
      originId: formVal.originId,
      destinationId: formVal.destinationId,
      selectedRouteId: route.id,
      routePath: route.path,
      wagonsCount: Math.ceil(formVal.weightTons / 70),
      wagonType: formVal.wagonType,
      isContainerized: formVal.wagonType === 'Контейнеровоз',
      containerType: formVal.wagonType === 'Контейнеровоз' ? '40-фут' : undefined
    });

    if (result) {
      this.selectedShipment.set(result);
      // Advance master demo to Step 3
      this.logistics.demoStep.set(3);
      this.selectTab('tracking');
    }
  }

  // Sign document
  async onSignDocument(docId: string) {
    await this.logistics.signDocument(docId, 'Том (Грузоотправитель)');
  }

  async simulateDelay(shipmentId: string) {
    await this.logistics.simulateDelay(shipmentId);
  }

  async rerouteShipment(shipmentId: string, bypassPath: string[]) {
    await this.logistics.rerouteShipment(shipmentId, bypassPath);
  }

  // AI Chat send
  async onSendAiMessage() {
    const text = this.chatInput().trim();
    if (!text) return;

    this.chatMessages.update(msgs => [...msgs, { role: 'user', content: text }]);
    this.chatInput.set('');
    this.isAiThinking.set(true);

    const history = this.chatMessages().slice(0, -1).map(m => ({ role: m.role, content: m.content }));
    const reply = await this.logistics.askAi(text, history);

    this.isAiThinking.set(false);
    this.chatMessages.update(msgs => [...msgs, { role: 'model', content: reply }]);
  }

  applySuggestedPrompt(promptKey: 'suggestPrompt1' | 'suggestPrompt2' | 'suggestPrompt3') {
    const prompt = this.t()[promptKey];
    this.chatInput.set(prompt);
    this.onSendAiMessage();
  }

  // ==========================================
  // MASTER DEMO WIZARD CONTROLS
  // ==========================================

  async advanceDemo() {
    const step = this.logistics.demoStep();

    if (step === 1) {
      // Step 1: Pre-fill and trigger calculation
      this.routeForm.patchValue({
        originId: '6', // Yekaterinburg
        destinationId: '1', // Moscow
        cargoRu: 'Сталь в рулонах',
        cargoEn: 'Coiled Steel',
        cargoCode: '324102',
        weightTons: 2400,
        wagonType: 'Полувагон',
        isUrgent: false
      });
      this.selectTab('routes');
      await this.onCalculate();
      this.logistics.demoStep.set(2);
    } 
    else if (step === 2) {
      // Step 2: Ensure a route is selected and book it
      const option = this.logistics.routeOptions().find(o => o.id === 'balanced') || this.logistics.routeOptions()[0];
      if (option) {
        this.selectedRouteOption.set(option);
        this.logistics.demoSelectedRoute.set(option);
      }
      await this.onBookRoute(); // Automatically books and advances to step 3 and tracking tab
    } 
    else if (step === 3) {
      // Step 3: View map & digital twin
      this.selectTab('dispatcher');
      this.logistics.demoStep.set(4);
    } 
    else if (step === 4) {
      // Step 4: Simulate delay force-majeure
      const targetId = this.logistics.demoCreatedShipmentId() || 'S-48192';
      await this.logistics.simulateDelay(targetId);
      const targetShipment = this.logistics.shipments().find(s => s.id === targetId);
      if (targetShipment) {
        this.selectedShipment.set(targetShipment);
      }
      this.selectTab('dispatcher');
      this.logistics.demoStep.set(5);
    } 
    else if (step === 5) {
      // Step 5: Resolve and Reroute
      const targetId = this.logistics.demoCreatedShipmentId() || 'S-48192';
      // Calculate optimized route bypassing the blockage (Station 4 to Station 1 bypass is 4 -> 3 -> 1)
      const bypassPath = ['6', '4', '3', '1'];
      await this.logistics.rerouteShipment(targetId, bypassPath);
      this.logistics.demoStep.set(6); // Finish!
      this.selectTab('tracking');
    }
  }

  resetDemo() {
    this.logistics.demoStep.set(1);
    this.logistics.demoCreatedShipmentId.set('');
    this.logistics.demoSelectedRoute.set(null);
    this.routeForm.reset();
    this.logistics.refreshState();
    this.selectTab('home');
  }

  // ==========================================
  // CONVENIENCE UTILS FOR HTML TEMPLATE
  // ==========================================

  getStationName(stationId: string): string {
    const locale = this.logistics.locale();
    const st = this.logistics.stations().find(s => s.id === stationId);
    if (!st) return stationId;
    return locale === 'ru' ? st.nameRu : st.nameEn;
  }

  getStationRegion(stationId: string): string {
    const locale = this.logistics.locale();
    const st = this.logistics.stations().find(s => s.id === stationId);
    if (!st) return '';
    return locale === 'ru' ? st.regionRu : st.regionEn;
  }

  getStationCoords(stationId: string): { x: number; y: number } {
    const st = this.logistics.stations().find(s => s.id === stationId);
    if (!st) return { x: 100, y: 100 };
    
    // Scale lat/lng of synthetic Russian cities to look beautiful in an 800x450 SVG box
    // Russia ranges: lat 42 to 70, lng 20 to 140
    // Standard mapping with custom adjustments to look visually balanced on our UI
    const minLat = 41;
    const maxLat = 61;
    const minLng = 28;
    const maxLng = 135;

    const x = 50 + ((st.lng - minLng) / (maxLng - minLng)) * 700;
    // Invert Y because SVG coordinates start at top
    const y = 380 - ((st.lat - minLat) / (maxLat - minLat)) * 320;

    return { x: Math.round(x), y: Math.round(y) };
  }

  getSegmentLine(seg: Segment): { x1: number; y1: number; x2: number; y2: number } {
    const p1 = this.getStationCoords(seg.fromId);
    const p2 = this.getStationCoords(seg.toId);
    return {
      x1: p1.x,
      y1: p1.y,
      x2: p2.x,
      y2: p2.y
    };
  }

  getFilteredWagons(): Wagon[] {
    const filter = this.wagonTypeFilter();
    const list = this.logistics.wagons();
    if (filter === 'all') return list;
    return list.filter(w => w.typeRu === filter || w.typeEn === filter);
  }

  getFilteredShipments(): Shipment[] {
    const filter = this.shipmentStatusFilter();
    const list = this.logistics.shipments();
    if (filter === 'all') return list;
    return list.filter(s => s.statusRu === filter || s.statusEn === filter);
  }

  getFilteredDocuments(): Document[] {
    const filter = this.documentStatusFilter();
    const list = this.logistics.documents();
    if (filter === 'all') return list;
    return list.filter(d => d.statusRu === filter || d.statusEn === filter);
  }

  getStationActiveWagonsCount(stationId: string): number {
    return this.logistics.wagons().filter(w => w.stationId === stationId && w.statusRu === 'Доступен').length;
  }
}

