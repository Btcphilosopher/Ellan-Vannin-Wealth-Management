import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express, { Request, Response } from 'express';
import { join } from 'node:path';
import { GoogleGenAI } from '@google/genai';

// ==========================================
// 1. TYPES & INTERFACES
// ==========================================

export interface Station {
  id: string;
  nameRu: string;
  nameEn: string;
  regionRu: string;
  regionEn: string;
  code: string;
  lat: number;
  lng: number;
}

export interface Segment {
  id: string;
  fromId: string;
  toId: string;
  distanceKm: number;
  speedLimitKmh: number;
  riskFactor: number; // 0.0 to 1.0 (prob of delays)
  isElectrified: boolean;
  congestion: number; // 0.0 to 1.0 (load)
  isClosed: boolean;
}

export interface Terminal {
  id: string;
  stationId: string;
  nameRu: string;
  nameEn: string;
  capacityWagons: number;
  utilization: number; // 0.0 to 1.0
  averageDwellHours: number;
  servicesRu: string[];
  servicesEn: string[];
}

export interface Wagon {
  id: string;
  typeRu: 'Полувагон' | 'Крытый вагон' | 'Платформа' | 'Цистерна' | 'Хоппер';
  typeEn: 'Open Wagon' | 'Boxcar' | 'Platform' | 'Tank car' | 'Hopper';
  number: string;
  capacityTons: number;
  volumeCbm: number;
  owner: string;
  statusRu: 'Доступен' | 'В пути' | 'На ремонте' | 'Порожний';
  statusEn: 'Available' | 'In Transit' | 'Maintenance' | 'Empty';
  stationId: string;
  dailyRateRub: number;
}

export interface Container {
  id: string;
  typeRu: '20-фут' | '40-фут' | '45-фут' | 'Рефрижератор';
  typeEn: '20-ft' | '40-ft' | '45-ft' | 'Reefer';
  number: string;
  capacityTons: number;
  statusRu: 'Свободен' | 'Занят' | 'В пути';
  statusEn: 'Available' | 'Occupied' | 'In Transit';
  stationId: string;
}

export interface CostBreakdown {
  baseTransportRub: number;
  wagonRentRub: number;
  terminalHandlingRub: number;
  urgencySurchargeRub: number;
  insuranceRub: number;
  taxRub: number;
  totalRub: number;
}

export interface RouteOption {
  id: string;
  nameRu: string;
  nameEn: string;
  path: string[]; // List of Station IDs
  distanceKm: number;
  travelTimeHours: number;
  delayRiskPercent: number;
  carbonCo2Kg: number;
  pricing: CostBreakdown;
  score: number; // 0 to 100
  explanationRu: string;
  explanationEn: string;
}

export interface Shipment {
  id: string;
  cargoRu: string;
  cargoEn: string;
  cargoCode: string;
  weightTons: number;
  originId: string;
  destinationId: string;
  selectedRouteId: string;
  routePath: string[]; // Station IDs
  currentStationId: string;
  progressPercent: number; // 0 to 100
  eta: string; // ISO string
  statusRu: 'Черновик' | 'Оформлен' | 'Погрузка' | 'В пути' | 'Задержка' | 'На сортировке' | 'Прибыл' | 'Выдан';
  statusEn: 'Draft' | 'Booked' | 'Loading' | 'In Transit' | 'Delayed' | 'Sorting' | 'Arrived' | 'Delivered';
  wagonsAssigned: string[]; // Wagon IDs
  containersAssigned: string[]; // Container IDs
  documents: string[]; // Document IDs
  trackingEvents: {
    timestamp: string;
    stationId: string;
    eventRu: string;
    eventEn: string;
    status: string;
  }[];
}

export interface Alert {
  id: string;
  shipmentId: string;
  severity: 'warning' | 'critical';
  timestamp: string;
  messageRu: string;
  messageEn: string;
  causeRu: string;
  causeEn: string;
  recommendedActionRu: string;
  recommendedActionEn: string;
  resolved: boolean;
}

export interface Document {
  id: string;
  shipmentId: string;
  typeRu: 'Транспортная накладная' | 'Договор перевозки' | 'Счёт на оплату' | 'Акт приёма-передачи';
  typeEn: 'Consignment Note' | 'Transportation Contract' | 'Commercial Invoice' | 'Acceptance Act';
  statusRu: 'Черновик' | 'На проверке' | 'Подписан' | 'Аннулирован';
  statusEn: 'Draft' | 'Validating' | 'Signed' | 'Cancelled';
  createdAt: string;
  signedAt?: string;
  signerName?: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  entityId: string;
  entityType: 'Shipment' | 'Document';
  actorRu: string;
  actorEn: string;
  actionRu: string;
  actionEn: string;
  details: string;
}

// ==========================================
// 2. SEED DATA & IN-MEMORY STORE
// ==========================================

const stations: Station[] = [
  { id: '1', nameRu: 'Москва-Сортировочная', nameEn: 'Moscow-Sorting', regionRu: 'Московская обл.', regionEn: 'Moscow Region', code: '200000', lat: 55.7558, lng: 37.6173 },
  { id: '2', nameRu: 'Санкт-Петербург-Товарный', nameEn: 'St. Petersburg-Freight', regionRu: 'Ленинградская обл.', regionEn: 'Leningrad Region', code: '030000', lat: 59.9343, lng: 30.3351 },
  { id: '3', nameRu: 'Нижний Новгород-Сортировочный', nameEn: 'Nizhny Novgorod-Sorting', regionRu: 'Нижегородская обл.', regionEn: 'Nizhny Novgorod Region', code: '240000', lat: 56.3269, lng: 44.0059 },
  { id: '4', nameRu: 'Самара-Товарная', nameEn: 'Samara-Freight', regionRu: 'Самарская обл.', regionEn: 'Samara Region', code: '630000', lat: 53.2001, lng: 50.1500 },
  { id: '5', nameRu: 'Ростов-Главный-Товарный', nameEn: 'Rostov-Freight', regionRu: 'Ростовская обл.', regionEn: 'Rostov Region', code: '340000', lat: 47.2357, lng: 39.7015 },
  { id: '6', nameRu: 'Екатеринбург-Сортировочный', nameEn: 'Yekaterinburg-Sorting', regionRu: 'Свердловская обл.', regionEn: 'Sverdlovsk Region', code: '760000', lat: 56.8389, lng: 60.6057 },
  { id: '7', nameRu: 'Новосибирск-Главный', nameEn: 'Novosibirsk-Main', regionRu: 'Новосибирская обл.', regionEn: 'Novosibirsk Region', code: '540000', lat: 55.0084, lng: 82.9357 },
  { id: '8', nameRu: 'Красноярск-Восточный', nameEn: 'Krasnoyarsk-East', regionRu: 'Красноярский край', regionEn: 'Krasnoyarsk Region', code: '243000', lat: 56.0153, lng: 92.8932 },
  { id: '9', nameRu: 'Иркутск-Сортировочный', nameEn: 'Irkutsk-Sorting', regionRu: 'Иркутская обл.', regionEn: 'Irkutsk Region', code: '380000', lat: 52.2870, lng: 104.3050 },
  { id: '10', nameRu: 'Владивосток-Порт', nameEn: 'Vladivostok-Port', regionRu: 'Приморский край', regionEn: 'Primorsky Krai', code: '690000', lat: 43.1198, lng: 131.8869 }
];

const segments: Segment[] = [
  { id: 's1', fromId: '1', toId: '2', distanceKm: 650, speedLimitKmh: 80, riskFactor: 0.05, isElectrified: true, congestion: 0.4, isClosed: false },
  { id: 's2', fromId: '1', toId: '3', distanceKm: 440, speedLimitKmh: 90, riskFactor: 0.03, isElectrified: true, congestion: 0.3, isClosed: false },
  { id: 's3', fromId: '3', toId: '4', distanceKm: 710, speedLimitKmh: 80, riskFactor: 0.06, isElectrified: true, congestion: 0.5, isClosed: false },
  { id: 's4', fromId: '4', toId: '6', distanceKm: 980, speedLimitKmh: 75, riskFactor: 0.08, isElectrified: false, congestion: 0.6, isClosed: false },
  { id: 's5', fromId: '1', toId: '6', distanceKm: 1660, speedLimitKmh: 85, riskFactor: 0.09, isElectrified: true, congestion: 0.7, isClosed: false },
  { id: 's6', fromId: '6', toId: '7', distanceKm: 1520, speedLimitKmh: 80, riskFactor: 0.07, isElectrified: true, congestion: 0.5, isClosed: false },
  { id: 's7', fromId: '7', toId: '8', distanceKm: 760, speedLimitKmh: 90, riskFactor: 0.04, isElectrified: true, congestion: 0.4, isClosed: false },
  { id: 's8', fromId: '8', toId: '9', distanceKm: 1050, speedLimitKmh: 80, riskFactor: 0.08, isElectrified: true, congestion: 0.6, isClosed: false },
  { id: 's9', fromId: '9', toId: '10', distanceKm: 3950, speedLimitKmh: 70, riskFactor: 0.12, isElectrified: true, congestion: 0.8, isClosed: false },
  { id: 's10', fromId: '4', toId: '5', distanceKm: 1250, speedLimitKmh: 80, riskFactor: 0.05, isElectrified: true, congestion: 0.4, isClosed: false },
  { id: 's11', fromId: '1', toId: '5', distanceKm: 1100, speedLimitKmh: 85, riskFactor: 0.04, isElectrified: true, congestion: 0.5, isClosed: false }
];

const terminals: Terminal[] = [
  { id: 't1', stationId: '1', nameRu: 'Логистический центр Кунцево', nameEn: 'Kuntsevo Logistics Hub', capacityWagons: 150, utilization: 0.78, averageDwellHours: 6, servicesRu: ['Сортировка', 'Кросс-докинг', 'Таможня'], servicesEn: ['Sorting', 'Cross-docking', 'Customs'] },
  { id: 't2', stationId: '6', nameRu: 'Грузовой Терминал Екатеринбург-Товарный', nameEn: 'Yekaterinburg-Freight Terminal', capacityWagons: 200, utilization: 0.65, averageDwellHours: 8, servicesRu: ['Контейнерная площадка', 'Хранение угля', 'Перевалка руды'], servicesEn: ['Container Yard', 'Coal Storage', 'Ore Transshipment'] },
  { id: 't3', stationId: '10', nameRu: 'Тихоокеанский Морской Железнодорожный Терминал', nameEn: 'Pacific Marine Railway Terminal', capacityWagons: 350, utilization: 0.88, averageDwellHours: 14, servicesRu: ['Портовая перевалка', 'Мультимодальный транзит', 'Таможенный склад'], servicesEn: ['Port Transshipment', 'Multimodal Transit', 'Customs Warehouse'] },
  { id: 't4', stationId: '7', nameRu: 'Сибирский Сухой Порт', nameEn: 'Siberian Dry Port', capacityWagons: 180, utilization: 0.72, averageDwellHours: 7, servicesRu: ['Контейнерный терминал', 'Рефрижераторные склады'], servicesEn: ['Container Terminal', 'Reefer Warehouses'] }
];

// Generate synthetic wagons deterministically
const wagons: Wagon[] = [];
const wagonTypes: { ru: Wagon['typeRu']; en: Wagon['typeEn']; capacity: number; volume: number; rate: number }[] = [
  { ru: 'Полувагон', en: 'Open Wagon', capacity: 70, volume: 85, rate: 2400 },
  { ru: 'Крытый вагон', en: 'Boxcar', capacity: 68, volume: 120, rate: 2600 },
  { ru: 'Платформа', en: 'Platform', capacity: 72, volume: 0, rate: 2200 },
  { ru: 'Цистерна', en: 'Tank car', capacity: 66, volume: 80, rate: 3100 },
  { ru: 'Хоппер', en: 'Hopper', capacity: 71, volume: 92, rate: 2800 }
];

const wagonOwners = ['ПГК (Первая грузовая компания)', 'ФГК (Федеральная грузовая компания)', 'ТрансКонтейнер', 'Globaltrans', 'НефтеТрансСервис'];

for (let i = 1; i <= 150; i++) {
  const typeObj = wagonTypes[i % wagonTypes.length];
  const station = stations[i % stations.length];
  const isWagonActive = (i % 8 !== 0); // Some in maintenance
  wagons.push({
    id: `W-${10000 + i}`,
    typeRu: typeObj.ru,
    typeEn: typeObj.en,
    number: `5${Math.floor(1000000 + i * 4523).toString().substring(0, 7)}`,
    capacityTons: typeObj.capacity,
    volumeCbm: typeObj.volume,
    owner: wagonOwners[i % wagonOwners.length],
    statusRu: isWagonActive ? (i % 5 === 0 ? 'Порожний' : 'Доступен') : 'На ремонте',
    statusEn: isWagonActive ? (i % 5 === 0 ? 'Empty' : 'Available') : 'Maintenance',
    stationId: station.id,
    dailyRateRub: typeObj.rate
  });
}

// Generate synthetic containers deterministically
const containers: Container[] = [];
const containerTypes: { ru: Container['typeRu']; en: Container['typeEn']; capacity: number }[] = [
  { ru: '20-фут', en: '20-ft', capacity: 24 },
  { ru: '40-фут', en: '40-ft', capacity: 30 },
  { ru: '45-фут', en: '45-ft', capacity: 32 },
  { ru: 'Рефрижератор', en: 'Reefer', capacity: 28 }
];

for (let i = 1; i <= 100; i++) {
  const typeObj = containerTypes[i % containerTypes.length];
  const station = stations[i % stations.length];
  containers.push({
    id: `C-${20000 + i}`,
    typeRu: typeObj.ru,
    typeEn: typeObj.en,
    number: `RZDU ${Math.floor(100000 + i * 2319)}`,
    capacityTons: typeObj.capacity,
    statusRu: i % 4 === 0 ? 'Занят' : 'Свободен',
    statusEn: i % 4 === 0 ? 'Occupied' : 'Available',
    stationId: station.id
  });
}

// Global state variables
let shipments: Shipment[] = [
  {
    id: 'S-48192',
    cargoRu: 'Сталь в рулонах',
    cargoEn: 'Coiled Steel',
    cargoCode: '324102',
    weightTons: 2400,
    originId: '6', // Екатеринбург
    destinationId: '1', // Москва
    selectedRouteId: 'balanced',
    routePath: ['6', '4', '3', '1'],
    currentStationId: '4', // Самара
    progressPercent: 45,
    eta: new Date(Date.now() + 36 * 3600 * 1000).toISOString(), // 36 hours from now
    statusRu: 'В пути',
    statusEn: 'In Transit',
    wagonsAssigned: ['W-10001', 'W-10002', 'W-10003', 'W-10004', 'W-10005', 'W-10006', 'W-10007', 'W-10008'],
    containersAssigned: [],
    documents: ['D-801', 'D-802', 'D-803'],
    trackingEvents: [
      { timestamp: new Date(Date.now() - 12 * 3600 * 1000).toISOString(), stationId: '6', eventRu: 'Груз погружен на станции Екатеринбург-Сортировочный', eventEn: 'Cargo loaded at Yekaterinburg-Sorting station', status: 'Loading' },
      { timestamp: new Date(Date.now() - 10 * 3600 * 1000).toISOString(), stationId: '6', eventRu: 'Поезд отправлен со станции Екатеринбург', eventEn: 'Train departed from Yekaterinburg station', status: 'In Transit' },
      { timestamp: new Date(Date.now() - 2 * 3600 * 1000).toISOString(), stationId: '4', eventRu: 'Поезд прибыл на станцию Самара-Товарная на технический осмотр', eventEn: 'Train arrived at Samara-Freight station for technical inspection', status: 'Sorting' }
    ]
  },
  {
    id: 'S-48195',
    cargoRu: 'Уголь каменный',
    cargoEn: 'Bituminous Coal',
    cargoCode: '161008',
    weightTons: 5000,
    originId: '8', // Красноярск
    destinationId: '10', // Владивосток
    selectedRouteId: 'cost',
    routePath: ['8', '9', '10'],
    currentStationId: '9', // Иркутск
    progressPercent: 60,
    eta: new Date(Date.now() + 48 * 3600 * 1000).toISOString(),
    statusRu: 'В пути',
    statusEn: 'In Transit',
    wagonsAssigned: ['W-10010', 'W-10011', 'W-10012', 'W-10013', 'W-10014'],
    containersAssigned: [],
    documents: ['D-804', 'D-805'],
    trackingEvents: [
      { timestamp: new Date(Date.now() - 24 * 3600 * 1000).toISOString(), stationId: '8', eventRu: 'Состав сформирован и погружен', eventEn: 'Wagon train formed and loaded', status: 'Loading' },
      { timestamp: new Date(Date.now() - 22 * 3600 * 1000).toISOString(), stationId: '8', eventRu: 'Отправление со станции Красноярск-Восточный', eventEn: 'Departure from Krasnoyarsk-East station', status: 'In Transit' },
      { timestamp: new Date(Date.now() - 4 * 3600 * 1000).toISOString(), stationId: '9', eventRu: 'Прохождение сортировочного узла Иркутск-Сортировочный', eventEn: 'Passing Irkutsk-Sorting dispatch node', status: 'In Transit' }
    ]
  }
];

let alerts: Alert[] = [
  {
    id: 'A-501',
    shipmentId: 'S-48192',
    severity: 'warning',
    timestamp: new Date().toISOString(),
    messageRu: 'Ожидается задержка на узле Самара-Товарная',
    messageEn: 'Delay expected at Samara-Freight junction',
    causeRu: 'Повышенная загрузка путей сортировочной станции',
    causeEn: 'High track congestion at sorting station',
    recommendedActionRu: 'Перенаправить состав по обходному пути через Саранск или переждать загрузку',
    recommendedActionEn: 'Reroute the train via detour through Saransk or await congestion clearance',
    resolved: false
  }
];

const documents: Document[] = [
  { id: 'D-801', shipmentId: 'S-48192', typeRu: 'Транспортная накладная', typeEn: 'Consignment Note', statusRu: 'Подписан', statusEn: 'Signed', createdAt: new Date(Date.now() - 15 * 3600 * 1000).toISOString(), signedAt: new Date(Date.now() - 14 * 3600 * 1000).toISOString(), signerName: 'Иванов А.В. (Логист)' },
  { id: 'D-802', shipmentId: 'S-48192', typeRu: 'Договор перевозки', typeEn: 'Transportation Contract', statusRu: 'Подписан', statusEn: 'Signed', createdAt: new Date(Date.now() - 15 * 3600 * 1000).toISOString(), signedAt: new Date(Date.now() - 14 * 3600 * 1000).toISOString(), signerName: 'Петров С.Н. (Экспедитор)' },
  { id: 'D-803', shipmentId: 'S-48192', typeRu: 'Счёт на оплату', typeEn: 'Commercial Invoice', statusRu: 'Подписан', statusEn: 'Signed', createdAt: new Date(Date.now() - 15 * 3600 * 1000).toISOString(), signedAt: new Date(Date.now() - 13 * 3600 * 1000).toISOString(), signerName: 'Козлова Е.И. (Финансы)' },
  { id: 'D-804', shipmentId: 'S-48195', typeRu: 'Транспортная накладная', typeEn: 'Consignment Note', statusRu: 'Подписан', statusEn: 'Signed', createdAt: new Date(Date.now() - 26 * 3600 * 1000).toISOString(), signedAt: new Date(Date.now() - 25 * 3600 * 1000).toISOString(), signerName: 'Смирнов И.К. (Логист)' },
  { id: 'D-805', shipmentId: 'S-48195', typeRu: 'Счёт на оплату', typeEn: 'Commercial Invoice', statusRu: 'На проверке', statusEn: 'Validating', createdAt: new Date(Date.now() - 26 * 3600 * 1000).toISOString() }
];

const auditLogs: AuditLog[] = [
  { id: 'L-1', timestamp: new Date(Date.now() - 15 * 3600 * 1000).toISOString(), entityId: 'S-48192', entityType: 'Shipment', actorRu: 'Иванов А.В. (Логист)', actorEn: 'Ivanov A.V. (Logistics)', actionRu: 'Создание заявки', actionEn: 'Created RFQ', details: 'Заявка создана на перевозку 2400т стали Екатеринбург → Москва' },
  { id: 'L-2', timestamp: new Date(Date.now() - 14 * 3600 * 1000).toISOString(), entityId: 'D-801', entityType: 'Document', actorRu: 'Петров С.Н. (Диспетчер)', actorEn: 'Petrov S.N. (Dispatcher)', actionRu: 'Подписание накладной', actionEn: 'Signed Consignment Note', details: 'Накладная D-801 заверена электронной подписью' }
];

// ==========================================
// 3. GRAPH ENGINE (Dijkstra algorithm)
// ==========================================

function getDirectSegment(fromId: string, toId: string): Segment | undefined {
  return segments.find(s => 
    (s.fromId === fromId && s.toId === toId && !s.isClosed) ||
    (s.fromId === toId && s.toId === fromId && !s.isClosed)
  );
}

function findAlternativePaths(fromId: string, toId: string): { path: string[]; distanceKm: number; baseHours: number; risk: number }[] {
  // Dijkstra variants: minimum distance, minimum risk, minimum congestion
  const results: { path: string[]; distanceKm: number; baseHours: number; risk: number }[] = [];

  const dijkstra = (weightFn: (s: Segment) => number) => {
    const dist: Record<string, number> = {};
    const prev: Record<string, string | null> = {};
    const nodes = stations.map(s => s.id);

    nodes.forEach(n => {
      dist[n] = Infinity;
      prev[n] = null;
    });
    dist[fromId] = 0;

    const q = new Set(nodes);

    while (q.size > 0) {
      let u: string | null = null;
      let minDist = Infinity;
      q.forEach(n => {
        if (dist[n] < minDist) {
          minDist = dist[n];
          u = n;
        }
      });

      if (!u || u === toId) break;
      q.delete(u);

      const uNode: string = u;
      stations.forEach(neighbor => {
        if (!q.has(neighbor.id)) return;
        const segment = getDirectSegment(uNode, neighbor.id);
        if (!segment) return;

        const weight = weightFn(segment);
        const alt = dist[uNode] + weight;
        if (alt < dist[neighbor.id]) {
          dist[neighbor.id] = alt;
          prev[neighbor.id] = uNode;
        }
      });
    }

    if (dist[toId] === Infinity) return null;

    const path: string[] = [];
    let curr: string | null = toId;
    while (curr) {
      path.unshift(curr);
      curr = prev[curr];
    }
    return path;
  };

  // Variant 1: Shortest Distance
  const pathDist = dijkstra((s) => s.distanceKm);
  if (pathDist) {
    results.push(calculatePathStats(pathDist));
  }

  // Variant 2: Safest (Minimise Risk)
  const pathSafe = dijkstra((s) => s.distanceKm * (1 + s.riskFactor * 10));
  if (pathSafe && JSON.stringify(pathSafe) !== JSON.stringify(pathDist)) {
    results.push(calculatePathStats(pathSafe));
  }

  // Variant 3: Low Congestion
  const pathCongested = dijkstra((s) => s.distanceKm * (1 + s.congestion * 5));
  if (pathCongested && JSON.stringify(pathCongested) !== JSON.stringify(pathDist) && JSON.stringify(pathCongested) !== JSON.stringify(pathSafe)) {
    results.push(calculatePathStats(pathCongested));
  }

  // Variant 4: If empty or we need another route, create a forced alternative
  if (results.length < 3 && stations.length > 3) {
    // Standard backup path via Nizhny Novgorod (3)
    const backupPath = [fromId, '3', '6', toId].filter((v, i, a) => a.indexOf(v) === i && stations.some(s => s.id === v));
    if (backupPath.length >= 2 && JSON.stringify(backupPath) !== JSON.stringify(pathDist)) {
      results.push(calculatePathStats(backupPath));
    }
  }

  return results;
}

function calculatePathStats(path: string[]): { path: string[]; distanceKm: number; baseHours: number; risk: number } {
  let distanceKm = 0;
  let baseHours = 0;
  let riskSum = 0;
  let segmentCount = 0;

  for (let i = 0; i < path.length - 1; i++) {
    const seg = getDirectSegment(path[i], path[i + 1]);
    if (seg) {
      distanceKm += seg.distanceKm;
      baseHours += seg.distanceKm / seg.speedLimitKmh;
      riskSum += seg.riskFactor;
      segmentCount++;
    } else {
      // Direct jump fallback
      distanceKm += 500;
      baseHours += 6;
      riskSum += 0.05;
      segmentCount++;
    }
  }

  return {
    path,
    distanceKm,
    baseHours: Math.round(baseHours * 10) / 10,
    risk: Math.round((riskSum / (segmentCount || 1)) * 100)
  };
}

// ==========================================
// 4. PRICING & DECIMALS SIMULATOR
// ==========================================

function calculatePricing(distanceKm: number, weightTons: number, isUrgent: boolean, wagonType: string): CostBreakdown {
  // Use scaled integer arithmetic (in Rubles) to avoid binary floats.
  const ratePerTonKmScaled = 150; // 1.50 RUB in scaled integer (x100)
  const baseRateWagonScaled = 250000; // 2500 RUB per wagon-day in scaled integer (x100)

  let typeMultiplier = 1.0;
  if (wagonType === 'Цистерна') typeMultiplier = 1.25;
  if (wagonType === 'Хоппер') typeMultiplier = 1.15;
  if (wagonType === 'Крытый вагон') typeMultiplier = 1.10;

  // Estimating wagons needed (max 70 tons per wagon)
  const wagonsNeeded = Math.ceil(weightTons / 70) || 1;
  const transitDays = Math.ceil(distanceKm / 500) || 1;

  const baseTransportScaled = Math.round((weightTons * distanceKm * ratePerTonKmScaled * typeMultiplier) / 100);
  const wagonRentScaled = wagonsNeeded * transitDays * baseRateWagonScaled;
  const terminalHandlingScaled = wagonsNeeded * 450000; // 4500 RUB handling per wagon x100

  const baseTransportRub = baseTransportScaled / 100;
  const wagonRentRub = wagonRentScaled / 100;
  const terminalHandlingRub = terminalHandlingScaled / 100;

  const urgencySurchargeRub = isUrgent ? Math.round((baseTransportRub + wagonRentRub) * 0.25) : 0;
  const subtotal = baseTransportRub + wagonRentRub + terminalHandlingRub + urgencySurchargeRub;
  const insuranceRub = Math.round(subtotal * 0.005);
  const taxRub = Math.round((subtotal + insuranceRub) * 0.20); // 20% VAT in Russia

  return {
    baseTransportRub,
    wagonRentRub,
    terminalHandlingRub,
    urgencySurchargeRub,
    insuranceRub,
    taxRub,
    totalRub: Math.round(subtotal + insuranceRub + taxRub)
  };
}

// ==========================================
// 5. DIGITAL TWIN SIMULATION RUNNER
// ==========================================

function advanceDigitalTwin() {
  shipments = shipments.map(s => {
    if (s.statusRu === 'Прибыл' || s.statusRu === 'Выдан' || s.statusRu === 'Черновик') {
      return s;
    }

    // Load active track information
    let currentProgress = s.progressPercent + 10;
    if (currentProgress >= 100) {
      currentProgress = 100;
    }

    const pathIndex = Math.floor((currentProgress / 100) * (s.routePath.length - 1));
    const currentStation = s.routePath[pathIndex] || s.destinationId;

    let statusRu: Shipment['statusRu'] = s.statusRu;
    let statusEn: Shipment['statusEn'] = s.statusEn;

    if (currentProgress === 100) {
      statusRu = 'Прибыл';
      statusEn = 'Arrived';
    } else if (currentProgress % 30 === 0) {
      statusRu = 'На сортировке';
      statusEn = 'Sorting';
    } else if (s.statusRu !== 'Задержка') {
      statusRu = 'В пути';
      statusEn = 'In Transit';
    }

    const wasStatusChanged = s.progressPercent !== currentProgress || s.statusRu !== statusRu;
    const trackingEvents = [...s.trackingEvents];

    if (wasStatusChanged) {
      const stationObj = stations.find(st => st.id === currentStation);
      const stationNameRu = stationObj ? stationObj.nameRu : 'Станция';
      const stationNameEn = stationObj ? stationObj.nameEn : 'Station';

      if (currentProgress === 100) {
        trackingEvents.push({
          timestamp: new Date().toISOString(),
          stationId: currentStation,
          eventRu: `Состав прибыл на станцию назначения ${stationNameRu}. Начат процесс разгрузки.`,
          eventEn: `Train arrived at destination station ${stationNameEn}. Unloading process started.`,
          status: 'Arrived'
        });
      } else if (statusRu === 'На сортировке') {
        trackingEvents.push({
          timestamp: new Date().toISOString(),
          stationId: currentStation,
          eventRu: `Состав зашёл на сортировочный узел ${stationNameRu} для технической инспекции`,
          eventEn: `Train entered sorting hub ${stationNameEn} for technical inspection`,
          status: 'Sorting'
        });
      } else {
        trackingEvents.push({
          timestamp: new Date().toISOString(),
          stationId: currentStation,
          eventRu: `Поезд зафиксирован датчиками АПК-ДК на перегоне близ ${stationNameRu}`,
          eventEn: `Train recorded by telemetry sensors near ${stationNameEn}`,
          status: 'In Transit'
        });
      }
    }

    return {
      ...s,
      progressPercent: currentProgress,
      currentStationId: currentStation,
      statusRu,
      statusEn,
      trackingEvents
    } as Shipment;
  });
}

// Set up interval for background twin simulation
setInterval(() => {
  advanceDigitalTwin();
}, 60000); // Ticks every 60 seconds

// ==========================================
// 6. EXPRESS BOOTSTRAP & EXPRESS APP API
// ==========================================

const app = express();
app.use(express.json()); // Essential body-parser!

const browserDistFolder = join(import.meta.dirname, '../browser');

// Serve static assets
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

// ------------------------------------------
// GET STATE: Returns whole DB snapshot
// ------------------------------------------
app.get('/api/v1/state', (req: Request, res: Response) => {
  res.json({
    stations,
    segments,
    terminals,
    wagons,
    containers,
    shipments,
    alerts,
    documents,
    auditLogs
  });
});

// ------------------------------------------
// ROUTE CALCULATOR
// ------------------------------------------
app.post('/api/v1/routes/calculate', (req: Request, res: Response) => {
  const { originId, destinationId, weightTons, isUrgent, wagonType } = req.body;

  if (!originId || !destinationId) {
    return res.status(400).json({ error: 'Origin and destination are required' });
  }

  const alternativePaths = findAlternativePaths(originId, destinationId);
  const namesRu = ['Скоростной экспресс-маршрут', 'Экономичный обходной маршрут', 'Сбалансированная траектория'];
  const namesEn = ['Express High-Speed Route', 'Eco-Economic Detour Route', 'Balanced Path Option'];

  const options: RouteOption[] = alternativePaths.map((ap, index) => {
    const isExpress = index === 0;
    const pricing = calculatePricing(ap.distanceKm, weightTons || 2400, isUrgent || isExpress, wagonType || 'Полувагон');
    
    // Custom explanation
    let explanationRu = `Маршрут проложен напрямую через основные ж/д ветки. Сортировок: ${index + 1}.`;
    let explanationEn = `Route mapped directly via core railway trunks. Sorting points: ${index + 1}.`;

    if (index === 0) {
      explanationRu = 'Рекомендованный экспресс-путь с высоким приоритетом пропуска на перегонах. Минимальное транзитное время.';
      explanationEn = 'Recommended high-priority express routing with maximum pass rights. Minimum transit duration.';
    } else if (index === 1) {
      explanationRu = 'Экономический обход с оптимизированным простоем на сортировках. Минимизирует тариф РЖД на 10-12%.';
      explanationEn = 'Economic bypass path with optimized sorting yard stays. Lowers baseline rail tariffs by 10-12%.';
    }

    return {
      id: index === 0 ? 'fastest' : index === 1 ? 'cost' : 'balanced',
      nameRu: namesRu[index] || 'Альтернативный путь',
      nameEn: namesEn[index] || 'Alternative Path',
      path: ap.path,
      distanceKm: ap.distanceKm,
      travelTimeHours: ap.baseHours,
      delayRiskPercent: ap.risk,
      carbonCo2Kg: Math.round(ap.distanceKm * (weightTons || 2400) * 0.015), // 15g CO2 per ton-km
      pricing,
      score: 100 - (ap.risk * 0.4) - ((pricing.totalRub / 50000) * 0.2),
      explanationRu,
      explanationEn
    };
  });

  return res.json({ options });
});

// ------------------------------------------
// CREATE SHIPMENT
// ------------------------------------------
app.post('/api/v1/shipments', (req: Request, res: Response) => {
  const {
    cargoRu,
    cargoEn,
    cargoCode,
    weightTons,
    originId,
    destinationId,
    selectedRouteId,
    routePath,
    wagonsCount,
    isContainerized
  } = req.body;

  const id = `S-${Math.floor(40000 + Math.random() * 9999)}`;
  const allocatedWagons: string[] = [];
  const allocatedContainers: string[] = [];

  // Wagon allocation
  const neededWagons = Math.ceil(weightTons / 70) || wagonsCount || 1;
  let countAllocated = 0;
  for (const w of wagons) {
    if (w.stationId === originId && w.statusRu === 'Доступен') {
      w.statusRu = 'В пути';
      w.statusEn = 'In Transit';
      allocatedWagons.push(w.id);
      countAllocated++;
      if (countAllocated >= neededWagons) break;
    }
  }

  // Backup if no local available wagons
  if (allocatedWagons.length < neededWagons) {
    const missing = neededWagons - allocatedWagons.length;
    for (let j = 0; j < missing; j++) {
      allocatedWagons.push(`W-${12000 + j}`);
    }
  }

  // Container allocation
  if (isContainerized) {
    const neededContainers = Math.ceil(weightTons / 25) || 1;
    let containerAllocCount = 0;
    for (const c of containers) {
      if (c.stationId === originId && c.statusRu === 'Свободен') {
        c.statusRu = 'В пути';
        c.statusEn = 'In Transit';
        allocatedContainers.push(c.id);
        containerAllocCount++;
        if (containerAllocCount >= neededContainers) break;
      }
    }
    if (allocatedContainers.length < neededContainers) {
      const missingC = neededContainers - allocatedContainers.length;
      for (let j = 0; j < missingC; j++) {
        allocatedContainers.push(`C-${22000 + j}`);
      }
    }
  }

  // Document IDs
  const d1 = `D-${850 + Math.floor(Math.random() * 100)}`;
  const d2 = `D-${850 + Math.floor(Math.random() * 100)}`;

  const doc1: Document = {
    id: d1,
    shipmentId: id,
    typeRu: 'Транспортная накладная',
    typeEn: 'Consignment Note',
    statusRu: 'Черновик',
    statusEn: 'Draft',
    createdAt: new Date().toISOString()
  };

  const doc2: Document = {
    id: d2,
    shipmentId: id,
    typeRu: 'Договор перевозки',
    typeEn: 'Transportation Contract',
    statusRu: 'Черновик',
    statusEn: 'Draft',
    createdAt: new Date().toISOString()
  };

  documents.push(doc1, doc2);

  const newShipment: Shipment = {
    id,
    cargoRu: cargoRu || 'Строительные материалы',
    cargoEn: cargoEn || 'Construction Materials',
    cargoCode: cargoCode || '421003',
    weightTons: weightTons || 1000,
    originId,
    destinationId,
    selectedRouteId,
    routePath,
    currentStationId: originId,
    progressPercent: 0,
    eta: new Date(Date.now() + 42 * 3600 * 1000).toISOString(), // Estimated 42h
    statusRu: 'Оформлен',
    statusEn: 'Booked',
    wagonsAssigned: allocatedWagons,
    containersAssigned: allocatedContainers,
    documents: [d1, d2],
    trackingEvents: [
      {
        timestamp: new Date().toISOString(),
        stationId: originId,
        eventRu: 'Заявка успешно подтверждена. Подвижной состав выделен под погрузку.',
        eventEn: 'Order successfully confirmed. Rolling stock allocated for loading.',
        status: 'Booked'
      }
    ]
  };

  shipments.push(newShipment);

  // Add audit logs
  auditLogs.push({
    id: `L-${auditLogs.length + 10}`,
    timestamp: new Date().toISOString(),
    entityId: id,
    entityType: 'Shipment',
    actorRu: 'Том (Грузоотправитель)',
    actorEn: 'Tom (Shipper)',
    actionRu: 'Оформление перевозки',
    actionEn: 'Shipment Booked',
    details: `Оформлена новая перевозка ${id} объёмом ${weightTons}т`
  });

  res.status(201).json(newShipment);
});

// ------------------------------------------
// RE-ROUTE / OPTIMISE ACTIVE SHIPMENT
// ------------------------------------------
app.post('/api/v1/shipments/:id/reroute', (req: Request, res: Response) => {
  const { id } = req.params;
  const { newPath } = req.body;

  const shipmentIndex = shipments.findIndex(s => s.id === id);
  if (shipmentIndex === -1) {
    return res.status(404).json({ error: 'Shipment not found' });
  }

  const shipment = shipments[shipmentIndex];
  shipment.routePath = newPath;
  shipment.statusRu = 'В пути';
  shipment.statusEn = 'In Transit';
  shipment.eta = new Date(Date.now() + 30 * 3600 * 1000).toISOString(); // Re-optimized ETA

  // Appending route change event
  shipment.trackingEvents.push({
    timestamp: new Date().toISOString(),
    stationId: shipment.currentStationId,
    eventRu: 'Диспетчер перенаправил состав по оптимизированному обходному маршруту для минимизации задержки',
    eventEn: 'Dispatcher rerouted train along optimized bypass path to minimize delay impact',
    status: 'In Transit'
  });

  // Resolve active alerts for this shipment
  alerts = alerts.map(a => {
    if (a.shipmentId === (id as string)) {
      return { ...a, resolved: true };
    }
    return a;
  });

  auditLogs.push({
    id: `L-${auditLogs.length + 10}`,
    timestamp: new Date().toISOString(),
    entityId: id as string,
    entityType: 'Shipment',
    actorRu: 'Система (Автодиспетчер)',
    actorEn: 'System (Auto-Dispatcher)',
    actionRu: 'Оптимизация маршрута',
    actionEn: 'Route Rerouted',
    details: `Маршрут перевозки ${id} успешно изменен в режиме реального времени`
  });

  return res.json(shipment);
});

// ------------------------------------------
// SIMULATE DELAY INCIDENT
// ------------------------------------------
app.post('/api/v1/shipments/:id/simulate-delay', (req: Request, res: Response) => {
  const { id } = req.params;

  const shipmentIndex = shipments.findIndex(s => s.id === id);
  if (shipmentIndex === -1) {
    return res.status(404).json({ error: 'Shipment not found' });
  }

  const shipment = shipments[shipmentIndex];
  shipment.statusRu = 'Задержка';
  shipment.statusEn = 'Delayed';
  shipment.eta = new Date(Date.now() + 72 * 3600 * 1000).toISOString(); // Push ETA back 3 days!

  shipment.trackingEvents.push({
    timestamp: new Date().toISOString(),
    stationId: shipment.currentStationId,
    eventRu: 'ВНИМАНИЕ: Обнаружена внеплановая техническая остановка на перегоне из-за проведения путевых работ',
    eventEn: 'ALERT: Unplanned technical stop detected on rail stretch due to track maintenance works',
    status: 'Delayed'
  });

  const alertId = `A-${500 + Math.floor(Math.random() * 400)}`;
  alerts.push({
    id: alertId,
    shipmentId: id as string,
    severity: 'critical',
    timestamp: new Date().toISOString(),
    messageRu: `Высокий риск срыва сроков доставки по отправке ${id}`,
    messageEn: `High delivery SLA breach risk for shipment ${id}`,
    causeRu: 'Ограничение пропускной способности из-за ремонта путей',
    causeEn: 'Track capacity bottleneck due to maintenance works',
    recommendedActionRu: 'Пересчитать маршрут перевозки в обход закрытого перегона через сортировочные узлы',
    recommendedActionEn: 'Calculate alternative routing to bypass the closed track via secondary sorting yards',
    resolved: false
  });

  auditLogs.push({
    id: `L-${auditLogs.length + 10}`,
    timestamp: new Date().toISOString(),
    entityId: id as string,
    entityType: 'Shipment',
    actorRu: 'Служба мониторинга (Телеметрия)',
    actorEn: 'Monitoring Service (Telemetry)',
    actionRu: 'Инцидент задержки',
    actionEn: 'Delay Incident Triggered',
    details: `Инициирована искусственная симуляция задержки по перевозке ${id}`
  });

  return res.json(shipment);
});

// ------------------------------------------
// SIGN DOCUMENT
// ------------------------------------------
app.post('/api/v1/documents/:id/sign', (req: Request, res: Response) => {
  const { id } = req.params;
  const { signerName } = req.body;

  const docIndex = documents.findIndex(d => d.id === id);
  if (docIndex === -1) {
    return res.status(404).json({ error: 'Document not found' });
  }

  const doc = documents[docIndex];
  doc.statusRu = 'Подписан';
  doc.statusEn = 'Signed';
  doc.signedAt = new Date().toISOString();
  doc.signerName = signerName || 'Том (Грузоотправитель)';

  auditLogs.push({
    id: `L-${auditLogs.length + 10}`,
    timestamp: new Date().toISOString(),
    entityId: id as string,
    entityType: 'Document',
    actorRu: signerName || 'Том',
    actorEn: signerName || 'Tom',
    actionRu: 'Цифровое подписание',
    actionEn: 'Digitally Signed',
    details: `Документ ${id} (${doc.typeRu}) успешно подписан электронной подписью`
  });

  return res.json(doc);
});

// ------------------------------------------
// LAZY-INITIALIZED GEMINI AI COMPILER CHAT
// ------------------------------------------
let genAiClient: GoogleGenAI | null = null;

function getGenAi(): GoogleGenAI | null {
  if (!genAiClient) {
    const key = process.env['GEMINI_API_KEY'];
    if (key) {
      genAiClient = new GoogleGenAI({
        apiKey: key,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });
    }
  }
  return genAiClient;
}

app.post('/api/v1/ai/chat', async (req: Request, res: Response) => {
  const { message, history } = req.body;

  if (!message) {
    return res.status(400).json({ error: 'Message is required' });
  }

  // Construct structured state context for the model to reason over
  const activeShipmentContext = shipments.map(s => ({
    id: s.id,
    cargo: s.cargoRu,
    weight: s.weightTons,
    status: s.statusRu,
    eta: s.eta,
    route: s.routePath.map(stId => stations.find(st => st.id === stId)?.nameRu || stId).join(' -> '),
    progress: `${s.progressPercent}%`
  }));

  const activeAlertsContext = alerts.filter(a => !a.resolved).map(a => ({
    shipment: a.shipmentId,
    message: a.messageRu,
    cause: a.causeRu,
    recommendation: a.recommendedActionRu
  }));

  const availableWagonsCount = wagons.filter(w => w.statusRu === 'Доступен').length;
  const terminalUtilization = terminals.map(t => `${t.nameRu}: ${Math.round(t.utilization * 100)}%`).join(', ');

  const systemInstruction = `Вы являетесь интеллектуальным AI-ассистентом "РЕЛЬСА AI" цифровой логистической платформы грузовых железных дорог.
Вы помогаете диспетчерам, логистам и грузоотправителям оптимизировать движение, находить порожний подвижной состав, рассчитывать маршруты и разбираться в задержках грузов.

Вот текущее точное состояние системы (используйте только эти СИНТЕТИЧЕСКИЕ ДАННЫЕ для ответов, не выдумывайте стороннюю информацию):
- Активные перевозки в реальном времени: ${JSON.stringify(activeShipmentContext)}
- Текущие активные инциденты/предупреждения: ${JSON.stringify(activeAlertsContext)}
- Количество свободных доступных вагонов для погрузки на станциях: ${availableWagonsCount}
- Текущая загрузка ж/д терминалов: ${terminalUtilization}

Правила ответа:
1. Будьте вежливы, профессиональны и точны. Пишите на русском языке (если пользователь не обращается на английском).
2. Ссылайтесь на реальные номера перевозок (например, S-48192) и рекомендуйте реальные альтернативные действия.
3. Открыто упоминайте, что все данные синтезированы в рамках демонстрации и симуляции платформы РЕЛЬСА.
4. Включайте калькуляции и сбалансированные экономические выводы, если вас спрашивают про стоимость или маршрут.`;

  const ai = getGenAi();
  if (!ai) {
    // Elegant heuristic fallback in case the API key is not configured yet
    const lowerMsg = message.toLowerCase();
    let reply = 'Приветствую! Я — РЕЛЬСА AI, ваш логистический помощник.\n\n';
    
    if (lowerMsg.includes('задерж') || lowerMsg.includes('s-48192')) {
      reply += 'Анализируя текущее состояние, отправка **S-48192** (Сталь в рулонах) имеет статус **"В пути" с прогнозируемой задержкой** в районе Самары.\n\n**Причина:** Повышенная загрузка путей сортировочной станции Самара-Товарная.\n\n**Рекомендация:** На панели управления Диспетчера нажмите кнопку **"Пересчитать и оптимизировать маршрут"**, чтобы направить поезд по обходной траектории через Саранск. Это сократит время задержки на 14 часов!';
    } else if (lowerMsg.includes('маршрут') || lowerMsg.includes('москва') || lowerMsg.includes('екатеринбург')) {
      reply += 'Для перевозки металлов или тяжелых грузов по маршруту **Екатеринбург ↔ Москва** я рекомендую использовать **Сбалансированный маршрут** через Самару.\n\n- **Расстояние:** ~1750 км\n- **Срок транзита:** 36-38 часов\n- **Экономия:** до 8.4% за счёт отсутствия перегруженности путей во Владимирском узле.';
    } else if (lowerMsg.includes('вагон') || lowerMsg.includes('сколько')) {
      reply += `В данный момент на станциях доступно **${availableWagonsCount} свободных грузовых вагонов** (в основном полувагоны и платформы в Екатеринбурге и Самаре).\n\nВы можете оформить Новую Заявку, и система автоматически зарезервирует их под вашу отправку.`;
    } else {
      reply += `Я готов ответить на любые ваши вопросы по ж/д логистике! В нашей симуляции сейчас находится **${shipments.length} активных перевозок**, а средняя загрузка терминалов составляет около 75%.\n\n*Примечание: Для полноценного подключения AI-модели Gemini Flash, пожалуйста, вставьте ваш GEMINI_API_KEY в меню Secrets.*`;
    }

    return res.json({ text: reply });
  }

  try {
    interface ContentPart {
      text: string;
    }
    interface ContentMessage {
      role: 'user' | 'model';
      parts: ContentPart[];
    }
    const contents: ContentMessage[] = [];
    if (history && Array.isArray(history)) {
      history.forEach((h: { role: string; content: string }) => {
        contents.push({
          role: h.role === 'user' ? 'user' : 'model',
          parts: [{ text: h.content }]
        });
      });
    }
    contents.push({ role: 'user', parts: [{ text: message }] });

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents,
      config: {
        systemInstruction,
        temperature: 0.7,
      }
    });

    return res.json({ text: response.text });
  } catch (error) {
    const err = error as Error;
    console.error('Error generating AI response:', err);
    return res.status(500).json({ error: 'AI processing failed', details: err.message });
  }
});

// ==========================================
// 7. ANGULAR SSR APP ENGINE RUNNER
// ==========================================
const angularApp = new AngularNodeAppEngine();

app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 3000; // MUST be 3000!
  app.listen(port, () => {
    console.log(`Node Express Server (РЕЛЬСА / RAILS) running on port ${port}`);
  });
}

export const reqHandler = createNodeRequestHandler(app);
