/**
 * EUROCORE AML/CFT & Fraud Compliance Simulation Engine
 * Evaluates real-time transaction streams against synthetic monitoring rules (RULE-001 to RULE-005)
 * and generates actionable risk cases for compliance analyst review.
 */

import { EntityId, PaymentOrder, RiskAlert } from '../types/eurocore';

export class ComplianceEngine {
  private alerts: RiskAlert[] = [];

  constructor() {
    this.seedInitialAlerts();
  }

  private seedInitialAlerts() {
    const now = new Date();
    this.alerts = [
      {
        id: 'ALT-2030-001',
        ruleId: 'RULE-001',
        ruleName: 'High-Velocity Rapid Transactions',
        severity: 'HIGH',
        triggeringPaymentId: 'PAY-88201',
        subjectWalletId: 'W-DE-FRA-08',
        subjectPspId: 'PSP-DE-COMMERZ',
        evidence: 'Detected 12 transactions totaling €4,850.00 within a 3.5 minute window.',
        riskScore: 84,
        status: 'NEW',
        createdAt: new Date(now.getTime() - 1000 * 60 * 15).toISOString(),
      },
      {
        id: 'ALT-2030-002',
        ruleId: 'RULE-004',
        ruleName: 'Rapid Circular Chain Layering',
        severity: 'CRITICAL',
        triggeringPaymentId: 'PAY-88245',
        subjectWalletId: 'W-FR-PAR-12',
        subjectPspId: 'PSP-FR-BNP',
        evidence: 'Sequential transfer through 4 synthetic wallets within 45 seconds ending at origin PSP.',
        riskScore: 92,
        status: 'UNDER_REVIEW',
        createdAt: new Date(now.getTime() - 1000 * 60 * 40).toISOString(),
      },
      {
        id: 'ALT-2030-003',
        ruleId: 'RULE-003',
        ruleName: 'Multi-Wallet Single Device Binding',
        severity: 'MEDIUM',
        subjectWalletId: 'W-ES-MAD-03',
        subjectPspId: 'PSP-ES-BBVA',
        evidence: 'Device Hardware Binding ID SHA-256(DEV-991) associated with 6 distinct consumer user identities.',
        riskScore: 68,
        status: 'NEW',
        createdAt: new Date(now.getTime() - 1000 * 60 * 120).toISOString(),
      },
    ];
  }

  /**
   * Analyzes an incoming payment order for compliance triggers.
   */
  public evaluatePaymentForRisk(
    payment: PaymentOrder,
    payerHistoricalCountInWindow: number,
    payerHistoricalVolumeInWindow: number
  ): RiskAlert | null {
    // RULE-001: High Velocity
    if (payerHistoricalCountInWindow >= 8) {
      const alert: RiskAlert = {
        id: `ALT-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        ruleId: 'RULE-001',
        ruleName: 'High-Velocity Rapid Transactions',
        severity: 'HIGH',
        triggeringPaymentId: payment.id,
        subjectWalletId: payment.payerWalletId,
        subjectPspId: payment.payerPspId,
        evidence: `Triggered by payment ${payment.id} (€${(payment.amount / 100).toFixed(
          2
        )}). Payer generated ${payerHistoricalCountInWindow} transactions in short window.`,
        riskScore: 78,
        status: 'NEW',
        createdAt: new Date().toISOString(),
      };
      this.alerts.unshift(alert);
      return alert;
    }

    // RULE-002: Threshold Structuring / Large Value
    if (payment.amount >= 95000) {
      // €950.00+
      const alert: RiskAlert = {
        id: `ALT-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        ruleId: 'RULE-002',
        ruleName: 'Near-Limit Structuring Pattern',
        severity: 'MEDIUM',
        triggeringPaymentId: payment.id,
        subjectWalletId: payment.payerWalletId,
        subjectPspId: payment.payerPspId,
        evidence: `Transaction value (€${(payment.amount / 100).toFixed(
          2
        )}) is within 5% of single transaction policy ceiling (€1,000.00).`,
        riskScore: 62,
        status: 'NEW',
        createdAt: new Date().toISOString(),
      };
      this.alerts.unshift(alert);
      return alert;
    }

    return null;
  }

  public updateAlertStatus(
    alertId: EntityId,
    newStatus: RiskAlert['status'],
    decisionNote?: string
  ): boolean {
    const alert = this.alerts.find((a) => a.id === alertId);
    if (!alert) return false;
    alert.status = newStatus;
    if (decisionNote) {
      alert.analystDecisionNote = decisionNote;
    }
    return true;
  }

  public getAllAlerts(): RiskAlert[] {
    return [...this.alerts];
  }
}
