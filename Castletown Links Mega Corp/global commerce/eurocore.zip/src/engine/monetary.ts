/**
 * EUROCORE Monetary Engine
 * Handles exact integer minor unit math (€1 = 100 cents),
 * zero binary floating point drift, and double-entry invariants.
 */

import { AmountMinor, EuroAmount } from '../types/eurocore';

export class MonetaryEngine {
  /**
   * Formats integer minor units to a clean Euro currency string.
   * e.g., 300000 -> "€3,000.00"
   */
  public static formatEuro(minor: AmountMinor): string {
    const isNegative = minor < 0;
    const absMinor = Math.abs(Math.round(minor));
    const euros = Math.floor(absMinor / 100);
    const cents = absMinor % 100;
    
    const formattedEuros = new Intl.NumberFormat('de-DE', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(euros);

    const centsStr = cents < 10 ? `0${cents}` : `${cents}`;
    const sign = isNegative ? '-' : '';

    return `${sign}€${formattedEuros},${centsStr}`;
  }

  public static toEuroAmount(minor: AmountMinor): EuroAmount {
    return {
      minor: Math.round(minor),
      formatted: this.formatEuro(minor),
    };
  }

  /**
   * Convert floating point string input safely to integer minor units.
   * e.g. "25.50" -> 2550
   */
  public static parseEuroToMinor(input: string | number): AmountMinor {
    if (typeof input === 'number') {
      return Math.round(input * 100);
    }
    const sanitized = input.replace(',', '.').replace(/[^0-9.-]/g, '');
    const parsed = parseFloat(sanitized);
    if (isNaN(parsed)) return 0;
    return Math.round(parsed * 100);
  }

  /**
   * Validates double-entry transaction invariants:
   * Total Debits MUST EXACTLY equal Total Credits.
   */
  public static validateDoubleEntryInvariants(entries: { debit: AmountMinor; credit: AmountMinor }[]): {
    isValid: boolean;
    totalDebits: AmountMinor;
    totalCredits: AmountMinor;
    imbalance: AmountMinor;
  } {
    let totalDebits = 0;
    let totalCredits = 0;

    for (const entry of entries) {
      totalDebits += Math.round(entry.debit);
      totalCredits += Math.round(entry.credit);
    }

    const imbalance = totalDebits - totalCredits;
    return {
      isValid: imbalance === 0,
      totalDebits,
      totalCredits,
      imbalance,
    };
  }

  /**
   * Validates central bank monetary creation invariant:
   * Eurosystem Digital Euro Liabilities = Total Issued - Total Redeemed
   */
  public static validateCentralBankBalanceSheet(
    totalIssued: AmountMinor,
    totalRedeemed: AmountMinor,
    activeCirculating: AmountMinor
  ): {
    isValid: boolean;
    expectedCirculation: AmountMinor;
    discrepancy: AmountMinor;
  } {
    const expectedCirculation = totalIssued - totalRedeemed;
    const discrepancy = activeCirculating - expectedCirculation;

    return {
      isValid: discrepancy === 0,
      expectedCirculation,
      discrepancy,
    };
  }
}
