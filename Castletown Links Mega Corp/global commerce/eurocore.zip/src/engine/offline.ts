/**
 * EUROCORE Offline Payment Engine & NFC Tap Emulator
 * Simulates hardware Secure Element (SE), monotonic transaction counter,
 * offline signature envelope, NFC APDU protocol state machine, and sync reconciliation.
 */

import {
  AmountMinor,
  DigitalWallet,
  EntityId,
  OfflinePaymentEnvelope,
  OfflineWallet,
  PaymentReceipt,
} from '../types/eurocore';
import { LedgerEngine } from './ledger';

export type NfcProtocolStep =
  | 'IDLE'
  | 'DEVICE_DISCOVERY'
  | 'PROXIMITY_ESTABLISHED'
  | 'SESSION_NEGOTIATION'
  | 'PAYMENT_REQUEST'
  | 'PAYMENT_AUTHENTICATION'
  | 'PAYMENT_ACCEPTED'
  | 'RECEIPT_CREATED'
  | 'ERROR_REPLAY_DETECTED'
  | 'ERROR_INSUFFICIENT_BALANCE'
  | 'ERROR_COUNTER_MISMATCH';

export interface NfcSessionState {
  currentStep: NfcProtocolStep;
  payerDeviceSerial: string;
  payeeDeviceSerial: string;
  requestedAmount: AmountMinor;
  activeCounter: number;
  simulatedApduLog: { step: NfcProtocolStep; apduHex: string; description: string; timestamp: string }[];
  completedEnvelope?: OfflinePaymentEnvelope;
}

export class OfflinePaymentEngine {
  private ledger: LedgerEngine;
  private offlineWallets: Map<EntityId, OfflineWallet> = new Map();
  private pendingEnvelopes: OfflinePaymentEnvelope[] = [];
  private syncedEnvelopes: OfflinePaymentEnvelope[] = [];

  constructor(ledger: LedgerEngine) {
    this.ledger = ledger;
  }

  public registerOfflineWallet(parentWalletId: EntityId, secureElementSerial: string): OfflineWallet {
    const offlineWallet: OfflineWallet = {
      id: `SE-W-${parentWalletId}`,
      parentWalletId,
      secureElementSerial,
      offlineBalance: 0,
      maxOfflineCapacity: 50000, // €500.00 max
      transactionCounter: 100, // Starts at 100
      devicePublicKey: `ED25519-PUB-${secureElementSerial.substring(0, 8)}`,
      lastSyncedCounter: 100,
      lastSyncedAt: new Date().toISOString(),
      pendingUnsyncedTxCount: 0,
      status: 'ACTIVE',
    };
    this.offlineWallets.set(parentWalletId, offlineWallet);
    return { ...offlineWallet };
  }

  public getOfflineWallet(parentWalletId: EntityId): OfflineWallet | undefined {
    const wallet = this.offlineWallets.get(parentWalletId);
    return wallet ? { ...wallet } : undefined;
  }

  /**
   * Loads funds from Online Digital Euro balance into Offline Secure Element balance.
   */
  public loadOfflineBalance(
    onlineWallet: DigitalWallet,
    amount: AmountMinor,
    offlineAccountId: EntityId
  ): { success: boolean; newOfflineBalance?: AmountMinor; error?: string } {
    const offlineWallet = this.offlineWallets.get(onlineWallet.id);
    if (!offlineWallet) {
      return { success: false, error: 'Offline Secure Element not provisioned for this wallet.' };
    }

    if (amount <= 0) {
      return { success: false, error: 'Load amount must be positive.' };
    }

    if (onlineWallet.onlineBalance < amount) {
      return {
        success: false,
        error: `Insufficient online funds (€${(onlineWallet.onlineBalance / 100).toFixed(2)}) to transfer to offline SE.`,
      };
    }

    if (offlineWallet.offlineBalance + amount > offlineWallet.maxOfflineCapacity) {
      return {
        success: false,
        error: `Transfer would exceed maximum offline Secure Element limit (€${(
          offlineWallet.maxOfflineCapacity / 100
        ).toFixed(2)}).`,
      };
    }

    // Move in double entry ledger: Online Wallet -> Offline SE Holding Account
    const postResult = this.ledger.postTransaction(
      'P2P_TRANSFER',
      [
        {
          accountId: onlineWallet.onlineAccountId,
          debit: amount,
          credit: 0,
          description: `Transfer to Offline Secure Element ${offlineWallet.secureElementSerial}`,
        },
        {
          accountId: offlineAccountId,
          debit: 0,
          credit: amount,
          description: `Secure Element Offline Balance Loaded (${offlineWallet.secureElementSerial})`,
        },
      ],
      `CORR-SE-LOAD-${Date.now()}`,
      `IDEM-SE-LOAD-${Date.now()}-${onlineWallet.id}`
    );

    if (!postResult.success) {
      return { success: false, error: postResult.error };
    }

    onlineWallet.onlineBalance -= amount;
    offlineWallet.offlineBalance += amount;

    return { success: true, newOfflineBalance: offlineWallet.offlineBalance };
  }

  /**
   * Executes step-by-step NFC Proximity Protocol emulation.
   */
  public executeNfcProximityPayment(
    payerWalletId: EntityId,
    payeeWalletId: EntityId,
    amount: AmountMinor
  ): NfcSessionState {
    const payerSE = this.offlineWallets.get(payerWalletId);
    const payeeSE = this.offlineWallets.get(payeeWalletId);

    const apduLog: NfcSessionState['simulatedApduLog'] = [];
    const logStep = (step: NfcProtocolStep, apduHex: string, desc: string) => {
      apduLog.push({ step, apduHex, description: desc, timestamp: new Date().toISOString() });
    };

    // 1. Discovery
    logStep('DEVICE_DISCOVERY', '00 A4 04 00 07 A0 00 00 02 47 10 01', 'NFC ISO/IEC 14443-4 Proximity Select APDU sent');

    if (!payerSE || !payeeSE) {
      logStep('ERROR_COUNTER_MISMATCH', '6F 00', 'Secure Element target not initialized or missing');
      return {
        currentStep: 'ERROR_COUNTER_MISMATCH',
        payerDeviceSerial: payerSE?.secureElementSerial || 'SE-ERR-00',
        payeeDeviceSerial: payeeSE?.secureElementSerial || 'SE-ERR-01',
        requestedAmount: amount,
        activeCounter: 0,
        simulatedApduLog: apduLog,
      };
    }

    // 2. Proximity Established
    logStep('PROXIMITY_ESTABLISHED', '90 00', 'Proximity established at 13.56 MHz carrier frequency');

    // 3. Session Negotiation
    logStep('SESSION_NEGOTIATION', '80 10 00 00 10', 'ECC P-256 / Ed25519 ECDH secure channel session keys derived');

    // 4. Payment Request
    logStep('PAYMENT_REQUEST', `80 20 00 00 08 ${amount.toString(16).padStart(8, '0')}`, `Payment request for €${(amount / 100).toFixed(2)} received`);

    // Balance check on SE
    if (payerSE.offlineBalance < amount) {
      logStep('ERROR_INSUFFICIENT_BALANCE', '6A 84', 'Insufficient Offline Secure Element funds');
      return {
        currentStep: 'ERROR_INSUFFICIENT_BALANCE',
        payerDeviceSerial: payerSE.secureElementSerial,
        payeeDeviceSerial: payeeSE.secureElementSerial,
        requestedAmount: amount,
        activeCounter: payerSE.transactionCounter,
        simulatedApduLog: apduLog,
      };
    }

    // Monotonic Counter check
    payerSE.transactionCounter += 1;
    const currentCounter = payerSE.transactionCounter;

    // 5. Authentication & Signature
    const envelopeId = `ENV-OFF-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const prevHash = `HASH-${Math.abs(envelopeId.length * currentCounter * 31).toString(16)}`;
    const signature = `ED25519-SIG-${payerSE.secureElementSerial}-${currentCounter}-${amount}`;

    logStep('PAYMENT_AUTHENTICATION', '80 30 00 00 40 ...', `Counter #${currentCounter} verified. Signed offline payment envelope.`);

    // Deduct offline balances locally
    payerSE.offlineBalance -= amount;
    payeeSE.offlineBalance += amount;
    payerSE.pendingUnsyncedTxCount += 1;

    const envelope: OfflinePaymentEnvelope = {
      id: envelopeId,
      offlineWalletId: payerSE.id,
      payerDeviceSerial: payerSE.secureElementSerial,
      payeeDeviceSerial: payeeSE.secureElementSerial,
      counter: currentCounter,
      amount,
      timestamp: new Date().toISOString(),
      previousTxHash: prevHash,
      signature,
      syncedToCentralLedger: false,
      status: 'ACCEPTED_LOCALLY',
    };

    this.pendingEnvelopes.push(envelope);

    // 6. Accepted & Receipt
    logStep('PAYMENT_ACCEPTED', '90 00', 'Offline transaction committed locally to Secure Element storage');
    logStep('RECEIPT_CREATED', '80 40 00 00 10', 'Local immutable receipt token issued');

    return {
      currentStep: 'RECEIPT_CREATED',
      payerDeviceSerial: payerSE.secureElementSerial,
      payeeDeviceSerial: payeeSE.secureElementSerial,
      requestedAmount: amount,
      activeCounter: currentCounter,
      simulatedApduLog: apduLog,
      completedEnvelope: envelope,
    };
  }

  /**
   * Synchronises offline pending payment envelopes with the central digital euro ledger upon reconnection.
   */
  public synchroniseOfflineQueue(): {
    syncedCount: number;
    failedCount: number;
    reconciliationLog: string[];
  } {
    const log: string[] = [];
    let syncedCount = 0;
    let failedCount = 0;

    const queue = [...this.pendingEnvelopes];
    this.pendingEnvelopes = [];

    for (const env of queue) {
      // Replay Detection Check
      const isReplay = this.syncedEnvelopes.some(
        (existing) => existing.payerDeviceSerial === env.payerDeviceSerial && existing.counter === env.counter
      );

      if (isReplay) {
        env.status = 'REJECTED_REPLAY';
        log.push(`[REJECTED] Duplicate/Replay attack detected for SE ${env.payerDeviceSerial} Counter #${env.counter}`);
        failedCount += 1;
        continue;
      }

      // Mark synchronised
      env.status = 'SYNCHRONISED';
      env.syncedToCentralLedger = true;
      env.syncTimestamp = new Date().toISOString();
      this.syncedEnvelopes.push(env);

      // Reset unsynced count on payer SE
      const payerSE = Array.from(this.offlineWallets.values()).find(
        (w) => w.secureElementSerial === env.payerDeviceSerial
      );
      if (payerSE) {
        payerSE.pendingUnsyncedTxCount = Math.max(0, payerSE.pendingUnsyncedTxCount - 1);
        payerSE.lastSyncedAt = env.syncTimestamp;
        payerSE.lastSyncedCounter = env.counter;
      }

      log.push(`[SUCCESS] Synchronised envelope ${env.id} (€${(env.amount / 100).toFixed(2)}) into central ledger`);
      syncedCount += 1;
    }

    return { syncedCount, failedCount, reconciliationLog: log };
  }

  public getPendingEnvelopes(): OfflinePaymentEnvelope[] {
    return [...this.pendingEnvelopes];
  }

  public getSyncedEnvelopes(): OfflinePaymentEnvelope[] {
    return [...this.syncedEnvelopes];
  }
}
