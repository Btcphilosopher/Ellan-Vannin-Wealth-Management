/**
 * EUROCORE Policy & Limits Engine
 * Evaluates holding limits (€3,000 max default), single transaction limits,
 * offline limits (€500 default), and velocity rules with detailed rejection codes.
 */

import { AmountMinor, PolicyConfiguration } from '../types/eurocore';

export interface PolicyEvaluationResult {
  isAllowed: boolean;
  rejectionCode?: 'HOLDING_LIMIT_EXCEEDED' | 'SINGLE_TX_LIMIT_EXCEEDED' | 'DAILY_LIMIT_EXCEEDED' | 'OFFLINE_LIMIT_EXCEEDED' | 'VELOCITY_EXCEEDED';
  policyId: string;
  humanMessage?: string;
  currentValue?: AmountMinor;
  limitValue?: AmountMinor;
}

export class PolicyEngine {
  private config: PolicyConfiguration;

  constructor(initialConfig?: Partial<PolicyConfiguration>) {
    this.config = {
      id: 'POLICY-EU-DEFAULT-2030',
      version: 1,
      updatedAt: new Date().toISOString(),
      maxWalletHolding: 300000, // €3,000.00
      maxOfflineHolding: 50000, // €500.00
      maxSingleTransaction: 100000, // €1,000.00
      dailyPaymentLimit: 500000, // €5,000.00
      velocityTxCountLimit: 10,
      offlineMaxTxCountWithoutSync: 15,
      offlineSyncDelayThresholdMinutes: 120,
      holdingLimitExceededAction: 'REJECT',
      ...initialConfig,
    };
  }

  public getConfig(): PolicyConfiguration {
    return { ...this.config };
  }

  public updateConfig(newConfig: Partial<PolicyConfiguration>): PolicyConfiguration {
    this.config = {
      ...this.config,
      ...newConfig,
      version: this.config.version + 1,
      updatedAt: new Date().toISOString(),
    };
    return { ...this.config };
  }

  /**
   * Evaluates if a proposed online payment complies with Eurosystem policies.
   */
  public evaluateOnlinePayment(
    amount: AmountMinor,
    recipientCurrentBalance: AmountMinor,
    payerDailyVolumeSoFar: AmountMinor = 0,
    payerRecentTxCount: number = 0
  ): PolicyEvaluationResult {
    // 1. Single Transaction Limit Check
    if (amount > this.config.maxSingleTransaction) {
      return {
        isAllowed: false,
        rejectionCode: 'SINGLE_TX_LIMIT_EXCEEDED',
        policyId: this.config.id,
        humanMessage: `The requested payment amount exceeds the maximum single transaction limit of €${(
          this.config.maxSingleTransaction / 100
        ).toLocaleString()}.`,
        currentValue: amount,
        limitValue: this.config.maxSingleTransaction,
      };
    }

    // 2. Recipient Holding Limit Check
    const projectedRecipientBalance = recipientCurrentBalance + amount;
    if (projectedRecipientBalance > this.config.maxWalletHolding) {
      return {
        isAllowed: false,
        rejectionCode: 'HOLDING_LIMIT_EXCEEDED',
        policyId: this.config.id,
        humanMessage: `The recipient wallet would exceed its configured holding limit of €${(
          this.config.maxWalletHolding / 100
        ).toLocaleString()}. Current: €${(recipientCurrentBalance / 100).toLocaleString()}, Proposed: €${(
          projectedRecipientBalance / 100
        ).toLocaleString()}.`,
        currentValue: projectedRecipientBalance,
        limitValue: this.config.maxWalletHolding,
      };
    }

    // 3. Daily Payment Volume Limit
    if (payerDailyVolumeSoFar + amount > this.config.dailyPaymentLimit) {
      return {
        isAllowed: false,
        rejectionCode: 'DAILY_LIMIT_EXCEEDED',
        policyId: this.config.id,
        humanMessage: `The daily aggregate spending limit of €${(
          this.config.dailyPaymentLimit / 100
        ).toLocaleString()} would be exceeded.`,
        currentValue: payerDailyVolumeSoFar + amount,
        limitValue: this.config.dailyPaymentLimit,
      };
    }

    // 4. Velocity Check
    if (payerRecentTxCount >= this.config.velocityTxCountLimit) {
      return {
        isAllowed: false,
        rejectionCode: 'VELOCITY_EXCEEDED',
        policyId: this.config.id,
        humanMessage: `Payment frequency limit exceeded (${this.config.velocityTxCountLimit} txs in time window). Please wait before retrying.`,
        currentValue: payerRecentTxCount,
        limitValue: this.config.velocityTxCountLimit,
      };
    }

    return { isAllowed: true, policyId: this.config.id };
  }

  /**
   * Evaluates if an offline payment or loading operation complies with offline limits.
   */
  public evaluateOfflinePayment(
    amount: AmountMinor,
    currentOfflineBalance: AmountMinor,
    unsyncedTxCount: number
  ): PolicyEvaluationResult {
    const projectedOfflineBalance = currentOfflineBalance + amount;

    if (projectedOfflineBalance > this.config.maxOfflineHolding) {
      return {
        isAllowed: false,
        rejectionCode: 'OFFLINE_LIMIT_EXCEEDED',
        policyId: this.config.id,
        humanMessage: `The offline wallet holding limit of €${(
          this.config.maxOfflineHolding / 100
        ).toLocaleString()} would be exceeded.`,
        currentValue: projectedOfflineBalance,
        limitValue: this.config.maxOfflineHolding,
      };
    }

    if (unsyncedTxCount >= this.config.offlineMaxTxCountWithoutSync) {
      return {
        isAllowed: false,
        rejectionCode: 'OFFLINE_LIMIT_EXCEEDED',
        policyId: this.config.id,
        humanMessage: `Maximum unsynchronised offline transaction count (${this.config.offlineMaxTxCountWithoutSync}) reached. Synchronisation required.`,
        currentValue: unsyncedTxCount,
        limitValue: this.config.offlineMaxTxCountWithoutSync,
      };
    }

    return { isAllowed: true, policyId: this.config.id };
  }
}
