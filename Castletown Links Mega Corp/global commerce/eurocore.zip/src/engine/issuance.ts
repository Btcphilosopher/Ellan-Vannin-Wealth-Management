/**
 * EUROCORE Eurosystem Issuance & Redemption Engine
 * Simulates central bank money creation (Issuance) and burning/conversion (Redemption)
 * between Eurosystem Central Bank liabilities and Commercial Bank PSP technical accounts.
 */

import { AmountMinor, EntityId, PaymentServiceProvider } from '../types/eurocore';
import { LedgerEngine } from './ledger';

export interface IssuanceRequest {
  id: EntityId;
  ncbCode: string; // e.g. "DE", "FR", "IT"
  pspId: EntityId;
  amount: AmountMinor;
  collateralRef: string;
  status: 'REQUESTED' | 'VALIDATING' | 'AUTHORISED' | 'EXECUTING' | 'SETTLED' | 'RECONCILED' | 'REJECTED';
  rejectionReason?: string;
  createdAt: string;
  settledAt?: string;
}

export interface RedemptionRequest {
  id: EntityId;
  pspId: EntityId;
  amount: AmountMinor;
  commercialBankRoutingBic: string;
  status: 'REQUESTED' | 'VALIDATING' | 'AUTHORISED' | 'EXECUTING' | 'SETTLED' | 'RECONCILED' | 'REJECTED';
  rejectionReason?: string;
  createdAt: string;
  settledAt?: string;
}

export class IssuanceRedemptionEngine {
  private ledger: LedgerEngine;
  private issuanceAccountMap: Map<string, EntityId> = new Map(); // NCB -> Account ID
  private issuanceRequests: IssuanceRequest[] = [];
  private redemptionRequests: RedemptionRequest[] = [];

  constructor(ledger: LedgerEngine, ncbAccountMap: Map<string, EntityId>) {
    this.ledger = ledger;
    this.issuanceAccountMap = ncbAccountMap;
  }

  /**
   * Executes explicit Eurosystem Digital Euro Issuance:
   * Debits Eurosystem Issuance Liability Account, Credits PSP Technical Omnibus Account.
   */
  public executeIssuance(
    ncbCode: string,
    psp: PaymentServiceProvider,
    amount: AmountMinor,
    collateralRef: string
  ): { success: boolean; request?: IssuanceRequest; error?: string } {
    const requestId = `ISS-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const now = new Date().toISOString();

    const request: IssuanceRequest = {
      id: requestId,
      ncbCode,
      pspId: psp.id,
      amount,
      collateralRef,
      status: 'REQUESTED',
      createdAt: now,
    };
    this.issuanceRequests.unshift(request);

    // 1. Validation
    request.status = 'VALIDATING';
    if (psp.licenceStatus !== 'LICENSED' || psp.certificationStatus !== 'CERTIFIED') {
      request.status = 'REJECTED';
      request.rejectionReason = `PSP ${psp.legalName} is not in certified operational status (${psp.licenceStatus}/${psp.certificationStatus}).`;
      return { success: false, request, error: request.rejectionReason };
    }

    const ncbIssuanceAccountId = this.issuanceAccountMap.get(ncbCode);
    if (!ncbIssuanceAccountId) {
      request.status = 'REJECTED';
      request.rejectionReason = `NCB ${ncbCode} central bank issuance account not configured.`;
      return { success: false, request, error: request.rejectionReason };
    }

    // 2. Authorisation
    request.status = 'AUTHORISED';

    // 3. Executing Double Entry Ledger Posting
    request.status = 'EXECUTING';

    // In double-entry:
    // Debit Eurosystem Central Bank Liability Account (+Liability)
    // Credit PSP Technical Omnibus Account (+PSP Holding)
    const postResult = this.ledger.postTransaction(
      'ISSUANCE',
      [
        {
          accountId: ncbIssuanceAccountId,
          debit: amount,
          credit: 0,
          description: `Eurosystem Issuance by NCB ${ncbCode} for PSP ${psp.legalName} (Collateral: ${collateralRef})`,
        },
        {
          accountId: psp.technicalAccountId,
          debit: 0,
          credit: amount,
          description: `Digital Euro Issuance Credited to Technical Omnibus Account for ${psp.legalName}`,
        },
      ],
      `CORR-ISS-${requestId}`,
      `IDEM-ISS-${requestId}`
    );

    if (!postResult.success) {
      request.status = 'REJECTED';
      request.rejectionReason = postResult.error || 'Ledger posting failed';
      return { success: false, request, error: request.rejectionReason };
    }

    // Update PSP omnibus balance
    psp.omnibusBalance += amount;

    request.status = 'SETTLED';
    request.settledAt = new Date().toISOString();

    // Final reconciliation check
    request.status = 'RECONCILED';

    return { success: true, request };
  }

  /**
   * Executes Digital Euro Redemption back into Commercial Bank Money:
   * Debits PSP Technical Omnibus Account, Credits Eurosystem Redemption Account.
   */
  public executeRedemption(
    psp: PaymentServiceProvider,
    amount: AmountMinor,
    commercialBankRoutingBic: string
  ): { success: boolean; request?: RedemptionRequest; error?: string } {
    const requestId = `RED-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const now = new Date().toISOString();

    const request: RedemptionRequest = {
      id: requestId,
      pspId: psp.id,
      amount,
      commercialBankRoutingBic,
      status: 'REQUESTED',
      createdAt: now,
    };
    this.redemptionRequests.unshift(request);

    // 1. Validation
    request.status = 'VALIDATING';
    if (psp.omnibusBalance < amount) {
      request.status = 'REJECTED';
      request.rejectionReason = `Insufficient PSP omnibus balance (€${(psp.omnibusBalance / 100).toFixed(
        2
      )}) for requested redemption (€${(amount / 100).toFixed(2)}).`;
      return { success: false, request, error: request.rejectionReason };
    }

    request.status = 'AUTHORISED';
    request.status = 'EXECUTING';

    const ncbRedemptionAccountId = this.issuanceAccountMap.get('DE') || Array.from(this.issuanceAccountMap.values())[0];

    // Ledger posting:
    // Debit PSP Technical Omnibus Account (-PSP Holding)
    // Credit Eurosystem Central Bank Liability Account (-Liability)
    const postResult = this.ledger.postTransaction(
      'REDEMPTION',
      [
        {
          accountId: psp.technicalAccountId,
          debit: amount,
          credit: 0,
          description: `Digital Euro Redemption by PSP ${psp.legalName} to Commercial Money (BIC: ${commercialBankRoutingBic})`,
        },
        {
          accountId: ncbRedemptionAccountId,
          debit: 0,
          credit: amount,
          description: `Eurosystem Digital Euro Liability Extinguished/Redeemed`,
        },
      ],
      `CORR-RED-${requestId}`,
      `IDEM-RED-${requestId}`
    );

    if (!postResult.success) {
      request.status = 'REJECTED';
      request.rejectionReason = postResult.error;
      return { success: false, request, error: request.rejectionReason };
    }

    psp.omnibusBalance -= amount;

    request.status = 'SETTLED';
    request.settledAt = new Date().toISOString();
    request.status = 'RECONCILED';

    return { success: true, request };
  }

  public getIssuanceHistory(): IssuanceRequest[] {
    return [...this.issuanceRequests];
  }

  public getRedemptionHistory(): RedemptionRequest[] {
    return [...this.redemptionRequests];
  }
}
