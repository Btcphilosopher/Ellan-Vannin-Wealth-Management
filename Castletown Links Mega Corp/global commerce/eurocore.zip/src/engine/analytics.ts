/**
 * EUROCORE R-Style Analytical & Data Science Engine
 * Computes settlement metrics, latency distributions, network graphs,
 * liquidity stress projections, and statistical research reports.
 */

import { AmountMinor, SystemAnalytics } from '../types/eurocore';
import { MonetaryEngine } from './monetary';

export class AnalyticsEngine {
  public static getSystemAnalytics(
    totalIssued: AmountMinor,
    totalRedeemed: AmountMinor,
    activeCirculating: AmountMinor,
    onlineVolume: AmountMinor,
    offlineVolume: AmountMinor
  ): SystemAnalytics {
    return {
      tpsCurrent: 42,
      tpsPeak: 184,
      settlementSuccessRate: 99.88,
      avgLatencyMs: 14.2,
      p99LatencyMs: 48.5,
      totalIssuedEuro: totalIssued,
      totalRedeemedEuro: totalRedeemed,
      totalActiveHoldingsEuro: activeCirculating,
      onlineVolumeEuro: onlineVolume,
      offlineVolumeEuro: offlineVolume,
      hourlyVolumeProfile: [
        { hour: '00:00', online: 12000, offline: 1500 },
        { hour: '04:00', online: 4500, offline: 800 },
        { hour: '08:00', online: 68000, offline: 12400 },
        { hour: '12:00', online: 142000, offline: 34000 },
        { hour: '16:00', online: 189000, offline: 41000 },
        { hour: '20:00', online: 95000, offline: 18000 },
      ],
      latencyDistribution: [
        { bucketMs: '< 5ms', count: 14200 },
        { bucketMs: '5 - 15ms', count: 48900 },
        { bucketMs: '15 - 30ms', count: 18400 },
        { bucketMs: '30 - 50ms', count: 3200 },
        { bucketMs: '> 50ms', count: 410 },
      ],
      pspLiquidityShare: [
        { pspName: 'Deutsche Bank Digital', sharePercent: 28.5, balance: Math.round(activeCirculating * 0.285) },
        { pspName: 'BNP Paribas Digital Euro', sharePercent: 24.2, balance: Math.round(activeCirculating * 0.242) },
        { pspName: 'Intesa Sanpaolo PSP', sharePercent: 18.0, balance: Math.round(activeCirculating * 0.18) },
        { pspName: 'Banco Santander Digital', sharePercent: 14.8, balance: Math.round(activeCirculating * 0.148) },
        { pspName: 'ING Group Digital', sharePercent: 9.5, balance: Math.round(activeCirculating * 0.095) },
        { pspName: 'Other Eurozone PSPs', sharePercent: 5.0, balance: Math.round(activeCirculating * 0.05) },
      ],
      depositMigrationModel: [
        { holdingLimitEur: 500, estimatedDepositShiftBillions: 120, bankLiquidityImpact: 'LOW_MANAGEABLE' },
        { holdingLimitEur: 1000, estimatedDepositShiftBillions: 240, bankLiquidityImpact: 'MODERATE' },
        { holdingLimitEur: 3000, estimatedDepositShiftBillions: 650, bankLiquidityImpact: 'SIGNIFICANT_BUFFERED' },
        { holdingLimitEur: 5000, estimatedDepositShiftBillions: 1100, bankLiquidityImpact: 'HIGH_COLLATERAL_ADJUSTMENT' },
        { holdingLimitEur: 10000, estimatedDepositShiftBillions: 1950, bankLiquidityImpact: 'SEVERE_DEPOSIT_OUTFLOW' },
      ],
    };
  }

  /**
   * Generates a network graph nodes and links data structure for payment flow visualization.
   */
  public static getNetworkGraphData() {
    const nodes = [
      { id: 'ECB', name: 'Eurosystem Central Settlement', type: 'CENTRAL_BANK', val: 30 },
      { id: 'DE-BUBA', name: 'Deutsche Bundesbank', type: 'NCB', val: 20 },
      { id: 'FR-BDF', name: 'Banque de France', type: 'NCB', val: 20 },
      { id: 'IT-BI', name: 'Banca d\'Italia', type: 'NCB', val: 18 },
      { id: 'ES-BDE', name: 'Banco de España', type: 'NCB', val: 18 },
      { id: 'PSP-DE-DB', name: 'Deutsche Bank Digital', type: 'PSP', val: 15 },
      { id: 'PSP-FR-BNP', name: 'BNP Paribas', type: 'PSP', val: 15 },
      { id: 'PSP-IT-ISP', name: 'Intesa Sanpaolo', type: 'PSP', val: 14 },
      { id: 'PSP-ES-SAN', name: 'Banco Santander', type: 'PSP', val: 14 },
      { id: 'M-EUROCAFE', name: 'EuroCafé Berlin', type: 'MERCHANT', val: 10 },
      { id: 'M-LOUVRE', name: 'Boutique Louvre Paris', type: 'MERCHANT', val: 10 },
      { id: 'M-MILANO', name: 'Moda Milano Outlet', type: 'MERCHANT', val: 10 },
      { id: 'W-CONSUMER-1', name: 'Consumer Wallets (Germany)', type: 'WALLET', val: 8 },
      { id: 'W-CONSUMER-2', name: 'Consumer Wallets (France)', type: 'WALLET', val: 8 },
    ];

    const links = [
      { source: 'ECB', target: 'DE-BUBA', value: 800 },
      { source: 'ECB', target: 'FR-BDF', value: 720 },
      { source: 'ECB', target: 'IT-BI', value: 540 },
      { source: 'ECB', target: 'ES-BDE', value: 480 },
      { source: 'DE-BUBA', target: 'PSP-DE-DB', value: 650 },
      { source: 'FR-BDF', target: 'PSP-FR-BNP', value: 590 },
      { source: 'IT-BI', target: 'PSP-IT-ISP', value: 450 },
      { source: 'ES-BDE', target: 'PSP-ES-SAN', value: 410 },
      { source: 'PSP-DE-DB', target: 'M-EUROCAFE', value: 320 },
      { source: 'PSP-FR-BNP', target: 'M-LOUVRE', value: 290 },
      { source: 'PSP-IT-ISP', target: 'M-MILANO', value: 240 },
      { source: 'PSP-DE-DB', target: 'W-CONSUMER-1', value: 450 },
      { source: 'PSP-FR-BNP', target: 'W-CONSUMER-2', value: 380 },
      { source: 'W-CONSUMER-1', target: 'M-EUROCAFE', value: 210 },
      { source: 'W-CONSUMER-2', target: 'M-LOUVRE', value: 180 },
    ];

    return { nodes, links };
  }

  /**
   * Generates a downloadable research markdown/text report with statistical findings.
   */
  public static generateResearchReport(analytics: SystemAnalytics): string {
    const disclaimer = 'EUROCORE — INDEPENDENT DIGITAL EURO INFRASTRUCTURE SIMULATOR\nSYNTHETIC SIMULATION DATA — NOT OFFICIAL EURO AREA STATISTICS';

    return `${disclaimer}
================================================================================
EUROCORE RESEARCH REPORT: DIGITAL EURO INFRASTRUCTURE SIMULATION
Generated: ${new Date().toISOString()}
================================================================================

1. MONETARY & LIQUIDITY SUMMARY
--------------------------------------------------------------------------------
- Total Digital Euro Issued:       ${MonetaryEngine.formatEuro(analytics.totalIssuedEuro)}
- Total Digital Euro Redeemed:     ${MonetaryEngine.formatEuro(analytics.totalRedeemedEuro)}
- Total Active Circulating:        ${MonetaryEngine.formatEuro(analytics.totalActiveHoldingsEuro)}
- Net Central Bank Liabilities:    ${MonetaryEngine.formatEuro(analytics.totalIssuedEuro - analytics.totalRedeemedEuro)}

2. SETTLEMENT & OPERATIONAL PERFORMANCE
--------------------------------------------------------------------------------
- Average Settlement Throughput:   ${analytics.tpsCurrent} TPS (Peak: ${analytics.tpsPeak} TPS)
- Settlement Finality Success Rate: ${analytics.settlementSuccessRate}%
- Mean Settlement Latency:         ${analytics.avgLatencyMs} ms
- P99 Latency Ceiling:             ${analytics.p99LatencyMs} ms
- Total Online Volume:             ${MonetaryEngine.formatEuro(analytics.onlineVolumeEuro)}
- Total Offline SE Volume:         ${MonetaryEngine.formatEuro(analytics.offlineVolumeEuro)}

3. PSP PARTICIPANT LIQUIDITY DISTRIBUTION
--------------------------------------------------------------------------------
${analytics.pspLiquidityShare
  .map((p) => `- ${p.pspName.padEnd(30)}: ${p.sharePercent}% (${MonetaryEngine.formatEuro(p.balance)})`)
  .join('\n')}

4. FINANCIAL STABILITY & DEPOSIT MIGRATION SENSITIVITY
--------------------------------------------------------------------------------
Holding Ceiling | Est. Commercial Deposit Shift | Bank Liquidity Impact Rating
--------------------------------------------------------------------------------
€500            | €120 Billion                 | Low (Manageable)
€1,000          | €240 Billion                 | Moderate
€3,000          | €650 Billion                 | Significant (Buffered by Central Bank)
€5,000          | €1,100 Billion               | High (Collateral Adjustment Required)
€10,000         | €1,950 Billion               | Severe Deposit Outflow Risk

================================================================================
END OF REPORT — EUROCORE RESEARCH DIVISION
`;
  }
}
