/**
 * EUROCORE Central Double-Entry Ledger Engine
 * Implements immutable journal entries, atomic posting, and compensating reversals.
 */

import {
  AccountType,
  AmountMinor,
  EntityId,
  JournalEntry,
  LedgerAccount,
  LedgerTransaction,
} from '../types/eurocore';
import { MonetaryEngine } from './monetary';

export class LedgerEngine {
  private accounts: Map<EntityId, LedgerAccount> = new Map();
  private transactions: LedgerTransaction[] = [];
  private idempotencyCache: Map<string, LedgerTransaction> = new Map();

  constructor(initialAccounts: LedgerAccount[] = []) {
    for (const acc of initialAccounts) {
      this.accounts.set(acc.id, { ...acc });
    }
  }

  public getAccount(accountId: EntityId): LedgerAccount | undefined {
    const acc = this.accounts.get(accountId);
    return acc ? { ...acc } : undefined;
  }

  public getAllAccounts(): LedgerAccount[] {
    return Array.from(this.accounts.values()).map((acc) => ({ ...acc }));
  }

  public createAccount(
    id: EntityId,
    accountNumber: string,
    name: string,
    type: AccountType,
    ownerId: EntityId,
    ownerType: 'EUROSYSTEM' | 'PSP' | 'CONSUMER' | 'MERCHANT' | 'DEVICE',
    initialBalance: AmountMinor = 0
  ): LedgerAccount {
    const account: LedgerAccount = {
      id,
      accountNumber,
      name,
      type,
      ownerId,
      ownerType,
      balance: initialBalance,
      currency: 'EUR',
      status: 'ACTIVE',
      createdAt: new Date().toISOString(),
    };
    this.accounts.set(id, account);
    return { ...account };
  }

  /**
   * Posts an atomic double-entry transaction.
   * Ensures debits = credits, updates account balances atomically, and saves journal entry.
   */
  public postTransaction(
    type: LedgerTransaction['type'],
    entries: { accountId: EntityId; debit: AmountMinor; credit: AmountMinor; description: string }[],
    correlationId: string,
    idempotencyKey?: string
  ): { success: boolean; transaction?: LedgerTransaction; error?: string } {
    // Check idempotency
    if (idempotencyKey && this.idempotencyCache.has(idempotencyKey)) {
      return { success: true, transaction: this.idempotencyCache.get(idempotencyKey) };
    }

    // Validate double entry debits == credits
    const validation = MonetaryEngine.validateDoubleEntryInvariants(entries);
    if (!validation.isValid) {
      return {
        success: false,
        error: `Double-entry invariant failure: Debits (${validation.totalDebits}) do not match Credits (${validation.totalCredits}). Imbalance: ${validation.imbalance}`,
      };
    }

    // Verify all target accounts exist and are ACTIVE
    for (const entry of entries) {
      const acc = this.accounts.get(entry.accountId);
      if (!acc) {
        return { success: false, error: `Account ${entry.accountId} not found in ledger` };
      }
      if (acc.status !== 'ACTIVE') {
        return { success: false, error: `Account ${acc.name} (${entry.accountId}) is currently ${acc.status}` };
      }
    }

    // Apply balance updates:
    // Debit increases asset/holding accounts, Credit decreases asset/holding accounts.
    const txId = `TX-${Date.now()}-${Math.floor(Math.random() * 100000)}`;
    const now = new Date().toISOString();
    const journalEntries: JournalEntry[] = [];

    for (const entry of entries) {
      const acc = this.accounts.get(entry.accountId)!;
      // Net change calculation
      const netChange = entry.debit - entry.credit;
      acc.balance += netChange;

      const jEntry: JournalEntry = {
        id: `JNL-${txId}-${entry.accountId.substring(0, 8)}`,
        transactionId: txId,
        accountId: entry.accountId,
        debit: entry.debit,
        credit: entry.credit,
        description: entry.description,
        timestamp: now,
      };
      journalEntries.push(jEntry);
    }

    // Compute simple deterministic audit hash
    const auditRaw = `${txId}|${type}|${correlationId}|${JSON.stringify(journalEntries)}`;
    const auditHash = `HASH-${Math.abs(
      auditRaw.split('').reduce((a, b) => ((a << 5) - a + b.charCodeAt(0)) | 0, 0)
    ).toString(16)}`;

    const transaction: LedgerTransaction = {
      id: txId,
      correlationId,
      idempotencyKey,
      type,
      status: 'POSTED',
      entries: journalEntries,
      timestamp: now,
      auditHash,
    };

    this.transactions.unshift(transaction);
    if (idempotencyKey) {
      this.idempotencyCache.set(idempotencyKey, transaction);
    }

    return { success: true, transaction };
  }

  /**
   * Posts a compensating reversal transaction to preserve audit immutability.
   */
  public reverseTransaction(
    originalTxId: EntityId,
    reason: string
  ): { success: boolean; reversalTransaction?: LedgerTransaction; error?: string } {
    const original = this.transactions.find((tx) => tx.id === originalTxId);
    if (!original) {
      return { success: false, error: `Original transaction ${originalTxId} not found` };
    }
    if (original.status === 'REVERSED') {
      return { success: false, error: `Transaction ${originalTxId} is already reversed` };
    }

    // Reverse debits and credits
    const reversalEntries = original.entries.map((j) => ({
      accountId: j.accountId,
      debit: j.credit, // swap
      credit: j.debit, // swap
      description: `REVERSAL of ${originalTxId}: ${reason}`,
    }));

    const result = this.postTransaction(
      'REVERSAL',
      reversalEntries,
      `REV-${original.correlationId}`,
      `IDEM-REV-${originalTxId}`
    );

    if (result.success) {
      original.status = 'REVERSED';
    }

    return result;
  }

  public getTransactionHistory(limit: number = 50): LedgerTransaction[] {
    return this.transactions.slice(0, limit);
  }

  public getJournalEntries(): JournalEntry[] {
    const list: JournalEntry[] = [];
    for (const tx of this.transactions) {
      list.push(...tx.entries);
    }
    return list;
  }
}
