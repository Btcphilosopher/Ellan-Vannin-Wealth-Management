/**
 * EUROCORE Privacy Matrix & Role-Based Data Redaction Engine
 * Evaluates field-level access control rules across Consumer, Merchant, PSP, Eurosystem, and Auditor roles.
 */

import { PaymentOrder, UserRole } from '../types/eurocore';

export interface PrivacyMatrixRow {
  field: string;
  consumer: 'FULL' | 'OWN_ONLY' | 'REDACTED';
  merchant: 'FULL' | 'CONFIGURABLE' | 'REDACTED';
  psp: 'FULL' | 'FULL' | 'REDACTED';
  eurosystem: 'REDACTED' | 'PSEUDONYMOUS' | 'AGGREGATED' | 'FULL';
  auditor: 'CONTROLLED' | 'FULL' | 'REDACTED';
  description: string;
}

export const EUROCORE_PRIVACY_MATRIX: PrivacyMatrixRow[] = [
  {
    field: 'Payment Amount',
    consumer: 'FULL',
    merchant: 'FULL',
    psp: 'FULL',
    eurosystem: 'PSEUDONYMOUS',
    auditor: 'CONTROLLED',
    description: 'Exact Euro amount of transaction',
  },
  {
    field: 'Payer Legal Identity',
    consumer: 'OWN_ONLY',
    merchant: 'REDACTED',
    psp: 'FULL',
    eurosystem: 'REDACTED',
    auditor: 'CONTROLLED',
    description: 'Full legal name and KYC identification details of consumer',
  },
  {
    field: 'Pseudonymous Identifier',
    consumer: 'FULL',
    merchant: 'FULL',
    psp: 'FULL',
    eurosystem: 'PSEUDONYMOUS',
    auditor: 'CONTROLLED',
    description: 'Zero-knowledge / rotated pseudonymous payment address',
  },
  {
    field: 'Merchant Identity & Outlet',
    consumer: 'FULL',
    merchant: 'FULL',
    psp: 'FULL',
    eurosystem: 'PSEUDONYMOUS',
    auditor: 'FULL',
    description: 'Brand name, merchant category code (MCC), location',
  },
  {
    field: 'Payment Purpose / Reference',
    consumer: 'FULL',
    merchant: 'CONFIGURABLE',
    psp: 'REDACTED',
    eurosystem: 'REDACTED',
    auditor: 'CONTROLLED',
    description: 'Unstructured user memo or invoice reference string',
  },
  {
    field: 'Device Hardware Metadata',
    consumer: 'OWN_ONLY',
    merchant: 'REDACTED',
    psp: 'FULL',
    eurosystem: 'REDACTED',
    auditor: 'CONTROLLED',
    description: 'Secure Element serial number, NFC APDU protocol traces',
  },
];

export class PrivacyEngine {
  /**
   * Applies role-based data redaction to a payment order object.
   */
  public static redactPaymentForRole(payment: PaymentOrder, role: UserRole): Partial<PaymentOrder> {
    const copy = { ...payment };

    if (role === 'CONSUMER') {
      // Consumers see full details for their own wallet, payee alias, amount, receipt
      return copy;
    }

    if (role === 'MERCHANT_OPERATOR') {
      // Merchants do NOT see payer legal identity or payer PSP internal IDs
      copy.payerWalletId = 'REDACTED_PSEUDONYM';
      copy.payerPspId = 'REDACTED_PSP';
      return copy;
    }

    if (role === 'EUROSYSTEM_OPERATOR') {
      // Central Bank sees amount, timestamp, PSP IDs, status, but NO payer legal name/purpose
      copy.payerAlias = `PSEUDO-ID-${payment.payerWalletId?.substring(0, 8) || 'ANON'}`;
      copy.purpose = '[REDACTED_PRIVACY_PROTECTED]';
      return copy;
    }

    if (role === 'AUDITOR' || role === 'COMPLIANCE_ANALYST' || role === 'SYSTEM_ADMIN') {
      // Full audit access for compliance verification
      return copy;
    }

    // Default restricted observer view
    copy.payerAlias = '[REDACTED]';
    copy.payeeAlias = '[REDACTED]';
    copy.purpose = '[REDACTED]';
    return copy;
  }
}
