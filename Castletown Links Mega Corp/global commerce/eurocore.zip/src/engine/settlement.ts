/**
 * EUROCORE Centralised Digital Euro Settlement Engine
 * Centralised, non-blockchain, deterministic settlement pipeline with double-spend lock,
 * idempotency protection, state machine transitions, and atomic ledger posting.
 */

import {
  AmountMinor,
  DigitalWallet,
  EntityId,
  MerchantOutlet,
  PaymentOrder,
  PaymentReceipt,
  PaymentStatus,
  PaymentType,
} from '../types/eurocore';
import { LedgerEngine } from './ledger';

export class SettlementEngine {
  private ledger: LedgerEngine;
  private pendingQueue: PaymentOrder[] = [];
  private processedPayments: Map<EntityId, PaymentOrder> = new Map();
  private receipts: Map<EntityId, PaymentReceipt> = new Map();
  private idempotencyMap: Map<string, PaymentOrder> = new Map();
  private activeLocks: Set<EntityId> = new Set(); // Wallet IDs under active transaction settlement lock

  constructor(ledger: LedgerEngine) {
    this.ledger = ledger;
  }

  /**
   * Submits an online payment order into the settlement pipeline.
   */
  public submitPayment(
    type: PaymentType,
    amount: AmountMinor,
    payerWallet: DigitalWallet,
    payeeWallet?: DigitalWallet,
    payeeMerchant?: MerchantOutlet,
    purpose: string = 'Digital Euro Transfer',
    reference: string = `REF-${Math.floor(100000 + Math.random() * 900000)}`,
    idempotencyKey: string = `IDEM-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`
  ): { success: boolean; payment?: PaymentOrder; receipt?: PaymentReceipt; rejectionReason?: string } {
    // 1. Idempotency Check
    if (this.idempotencyMap.has(idempotencyKey)) {
      const existing = this.idempotencyMap.get(idempotencyKey)!;
      const receipt = this.receipts.get(existing.id);
      return { success: existing.status === 'SETTLED' || existing.status === 'RECONCILED', payment: existing, receipt };
    }

    const txId = `PAY-${Date.now()}-${Math.floor(Math.random() * 100000)}`;
    const correlationId = `CORR-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const now = new Date().toISOString();

    const order: PaymentOrder = {
      id: txId,
      idempotencyKey,
      correlationId,
      type,
      payerWalletId: payerWallet.id,
      payerAlias: payerWallet.alias,
      payerPspId: payerWallet.pspId,
      payeeWalletId: payeeWallet?.id,
      payeeAlias: payeeWallet?.alias || payeeMerchant?.brandName,
      payeeMerchantOutletId: payeeMerchant?.id,
      payeePspId: payeeWallet?.pspId || payeeMerchant?.acquiringPspId,
      amount,
      currency: 'EUR',
      purpose,
      reference,
      status: 'CREATED',
      isOffline: false,
      createdAt: now,
      auditTrail: [{ timestamp: now, state: 'CREATED', note: 'Payment order created by initiator' }],
    };

    this.idempotencyMap.set(idempotencyKey, order);
    this.updateStatus(order, 'RECEIVED', 'Received by Central Digital Euro Settlement Engine');

    // 2. Double-Spend Lock check
    if (this.activeLocks.has(payerWallet.id)) {
      this.updateStatus(order, 'REJECTED', 'Payer wallet has concurrent lock pending');
      order.rejectionReason = {
        code: 'CONCURRENT_LOCK_REJECT',
        policyId: 'SYS-LOCK-01',
        message: 'A concurrent transaction is currently being processed for this wallet.',
      };
      this.processedPayments.set(order.id, order);
      return { success: false, payment: order, rejectionReason: order.rejectionReason.message };
    }

    // Acquire lock
    this.activeLocks.add(payerWallet.id);

    try {
      // 3. Validation
      this.updateStatus(order, 'VALIDATING', 'Validating balances, signatures, and idempotency constraints');

      if (amount <= 0) {
        this.updateStatus(order, 'REJECTED', 'Invalid monetary amount');
        order.rejectionReason = {
          code: 'INVALID_AMOUNT',
          policyId: 'SYS-VAL-01',
          message: 'Payment amount must be greater than zero cents.',
        };
        this.processedPayments.set(order.id, order);
        return { success: false, payment: order, rejectionReason: order.rejectionReason.message };
      }

      if (payerWallet.onlineBalance < amount) {
        this.updateStatus(order, 'REJECTED', 'Insufficient online digital euro balance');
        order.rejectionReason = {
          code: 'INSUFFICIENT_FUNDS',
          policyId: 'SYS-BAL-01',
          message: `Payer online balance (€${(payerWallet.onlineBalance / 100).toFixed(
            2
          )}) is less than required payment (€${(amount / 100).toFixed(2)}).`,
        };
        this.processedPayments.set(order.id, order);
        return { success: false, payment: order, rejectionReason: order.rejectionReason.message };
      }

      this.updateStatus(order, 'AUTHORISED', 'Authorised by payer PSP security checks');
      this.updateStatus(order, 'RESERVED', 'Funds reserved in payer online digital euro account');
      this.updateStatus(order, 'SETTLING', 'Executing double-entry settlement in central ledger');

      // Determine target ledger account
      const payeeAccountId = payeeWallet?.onlineAccountId || payeeMerchant?.settlementAccountId;
      if (!payeeAccountId) {
        this.updateStatus(order, 'REJECTED', 'Destination ledger account not found');
        order.rejectionReason = {
          code: 'PAYEE_ACCOUNT_NOT_FOUND',
          policyId: 'SYS-ACC-01',
          message: 'The destination wallet or merchant settlement account does not exist.',
        };
        this.processedPayments.set(order.id, order);
        return { success: false, payment: order, rejectionReason: order.rejectionReason.message };
      }

      // Execute double-entry ledger move:
      // Debit Payer Account (-Balance)
      // Credit Payee Account (+Balance)
      const postResult = this.ledger.postTransaction(
        type === 'P2B' ? 'P2B_PAYMENT' : 'P2P_TRANSFER',
        [
          {
            accountId: payerWallet.onlineAccountId,
            debit: amount,
            credit: 0,
            description: `Payment to ${order.payeeAlias} (Ref: ${reference})`,
          },
          {
            accountId: payeeAccountId,
            debit: 0,
            credit: amount,
            description: `Payment received from ${payerWallet.alias} (Ref: ${reference})`,
          },
        ],
        correlationId,
        idempotencyKey
      );

      if (!postResult.success) {
        this.updateStatus(order, 'FAILED', `Ledger posting error: ${postResult.error}`);
        this.processedPayments.set(order.id, order);
        return { success: false, payment: order, rejectionReason: postResult.error };
      }

      // Update state balances
      payerWallet.onlineBalance -= amount;
      if (payeeWallet) {
        payeeWallet.onlineBalance += amount;
      }
      if (payeeMerchant) {
        payeeMerchant.dailyTurnover += amount;
      }

      const settledAt = new Date().toISOString();
      this.updateStatus(order, 'SETTLED', 'Payment atomically settled in central double-entry ledger');
      order.settledAt = settledAt;

      // Final reconciliation
      this.updateStatus(order, 'RECONCILED', 'Matched against PSP transaction log');

      // Generate immutable receipt
      const receiptId = `RCPT-${txId.substring(4)}`;
      const receipt: PaymentReceipt = {
        id: receiptId,
        paymentId: order.id,
        payerAlias: payerWallet.alias,
        payeeAlias: order.payeeAlias || 'Eurosystem Participant',
        amount,
        currency: 'EUR',
        reference,
        timestamp: settledAt,
        ledgerTransactionId: postResult.transaction!.id,
        settlementConfirmationHash: postResult.transaction!.auditHash,
        isOffline: false,
      };

      order.receiptId = receiptId;
      this.receipts.set(order.id, receipt);
      this.processedPayments.set(order.id, order);

      return { success: true, payment: order, receipt };
    } finally {
      // Release lock
      this.activeLocks.delete(payerWallet.id);
    }
  }

  private updateStatus(order: PaymentOrder, state: PaymentStatus, note: string) {
    order.status = state;
    order.auditTrail.push({
      timestamp: new Date().toISOString(),
      state,
      note,
    });
  }

  public getPayment(id: EntityId): PaymentOrder | undefined {
    return this.processedPayments.get(id);
  }

  public getReceipt(paymentId: EntityId): PaymentReceipt | undefined {
    return this.receipts.get(paymentId);
  }

  public getAllPayments(limit: number = 100): PaymentOrder[] {
    return Array.from(this.processedPayments.values())
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, limit);
  }

  public getPendingQueue(): PaymentOrder[] {
    return [...this.pendingQueue];
  }
}
