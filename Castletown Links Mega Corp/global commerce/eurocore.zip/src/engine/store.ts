/**
 * EUROCORE Central System Store & Seed Data Orchestrator
 * Integrates Ledger, Policy, Issuance, Settlement, Offline, Compliance, and Digital Twin engines.
 */

import {
  AmountMinor,
  ConsumerUser,
  DigitalWallet,
  EntityId,
  LedgerAccount,
  MerchantOutlet,
  MerchantTerminal,
  NationalCentralBank,
  PaymentServiceProvider,
} from '../types/eurocore';
import { ComplianceEngine } from './compliance';
import { DigitalTwinSimulator } from './digitalTwin';
import { IssuanceRedemptionEngine } from './issuance';
import { LedgerEngine } from './ledger';
import { OfflinePaymentEngine } from './offline';
import { PolicyEngine } from './policy';
import { SettlementEngine } from './settlement';

export class EurocoreStore {
  public ledger: LedgerEngine;
  public policy: PolicyEngine;
  public issuance: IssuanceRedemptionEngine;
  public redemption: IssuanceRedemptionEngine;
  public settlement: SettlementEngine;
  public offline: OfflinePaymentEngine;
  public compliance: ComplianceEngine;
  public digitalTwin: DigitalTwinSimulator;

  public ncbs: NationalCentralBank[] = [];
  public psps: PaymentServiceProvider[] = [];
  public consumers: ConsumerUser[] = [];
  public wallets: DigitalWallet[] = [];
  public merchants: MerchantOutlet[] = [];
  public terminals: MerchantTerminal[] = [];

  constructor() {
    this.ledger = new LedgerEngine();
    this.policy = new PolicyEngine();
    this.compliance = new ComplianceEngine();
    this.digitalTwin = new DigitalTwinSimulator();

    const ncbAccountMap = this.seedEurosystemAndNcbs();
    this.seedPSPs();
    this.seedConsumersAndWallets();
    this.seedMerchantsAndTerminals();

    this.issuance = new IssuanceRedemptionEngine(this.ledger, ncbAccountMap);
    this.redemption = this.issuance;
    this.settlement = new SettlementEngine(this.ledger);
    this.offline = new OfflinePaymentEngine(this.ledger);

    this.provisionOfflineSecureElements();
    this.performInitialIssuanceAndFunding();
  }

  private seedEurosystemAndNcbs(): Map<string, EntityId> {
    const map = new Map<string, EntityId>();

    const ncbData = [
      { code: 'DE', name: 'Deutsche Bundesbank', country: 'Germany', issued: 125000000 }, // €1,250,000.00
      { code: 'FR', name: 'Banque de France', country: 'France', issued: 98000000 }, // €980,000.00
      { code: 'IT', name: "Banca d'Italia", country: 'Italy', issued: 74000000 },
      { code: 'ES', name: 'Banco de España', country: 'Spain', issued: 62000000 },
      { code: 'NL', name: 'De Nederlandsche Bank', country: 'Netherlands', issued: 48000000 },
      { code: 'AT', name: 'Oesterreichische Nationalbank', country: 'Austria', issued: 22000000 },
      { code: 'IE', name: 'Central Bank of Ireland', country: 'Ireland', issued: 19000000 },
      { code: 'PT', name: 'Banco de Portugal', country: 'Portugal', issued: 18000000 },
      { code: 'GR', name: 'Bank of Greece', country: 'Greece', issued: 15000000 },
      { code: 'FI', name: 'Bank of Finland', country: 'Finland', issued: 14000000 },
    ];

    for (const data of ncbData) {
      const ncbId = `NCB-${data.code}`;
      this.ncbs.push({
        id: ncbId,
        code: data.code,
        name: data.name,
        country: data.country,
        issuedBalance: data.issued,
        activePSPCount: 2,
        status: 'ACTIVE',
      });

      // Create central bank issuance liability account in ledger
      const accountId = `ACC-CB-ISSUE-${data.code}`;
      this.ledger.createAccount(
        accountId,
        `ECB-LIAB-${data.code}-001`,
        `Eurosystem Digital Euro Liabilities (${data.name})`,
        'EUROSYSTEM_LIABILITY_ISSUANCE',
        ncbId,
        'EUROSYSTEM',
        0
      );
      map.set(data.code, accountId);
    }

    return map;
  }

  private seedPSPs() {
    const pspConfigs = [
      { id: 'PSP-DE-DB', name: 'Deutsche Bank Digital', bic: 'DEUTDEFFXXX', jur: 'Germany' },
      { id: 'PSP-DE-COMMERZ', name: 'Commerzbank Digital', bic: 'COBADEFFXXX', jur: 'Germany' },
      { id: 'PSP-FR-BNP', name: 'BNP Paribas Digital Euro', bic: 'BNPAFRPPXXX', jur: 'France' },
      { id: 'PSP-IT-ISP', name: 'Intesa Sanpaolo PSP', bic: 'BCITITMMXXX', jur: 'Italy' },
      { id: 'PSP-ES-SAN', name: 'Banco Santander Digital', bic: 'BSCHESMMXXX', jur: 'Spain' },
      { id: 'PSP-NL-ING', name: 'ING Group Digital', bic: 'INGBNL2AXXX', jur: 'Netherlands' },
      { id: 'PSP-AT-ERSTE', name: 'Erste Group Digital', bic: 'GIBAATWWXXX', jur: 'Austria' },
      { id: 'PSP-IE-AIB', name: 'AIB Digital Euro', bic: 'AIBKIE2DXXX', jur: 'Ireland' },
    ];

    for (const p of pspConfigs) {
      const techAccountId = `ACC-PSP-TECH-${p.id}`;
      const depositAccountId = `ACC-PSP-COMM-${p.id}`;

      this.ledger.createAccount(
        techAccountId,
        `OMNIBUS-${p.bic}-01`,
        `${p.name} Digital Euro Technical Omnibus Account`,
        'PSP_TECHNICAL_OMNIBUS',
        p.id,
        'PSP',
        0
      );

      this.ledger.createAccount(
        depositAccountId,
        `DEPOSIT-${p.bic}-02`,
        `${p.name} Commercial Bank Settlement Deposit Account`,
        'PSP_COMMERCIAL_BANK_DEPOSIT',
        p.id,
        'PSP',
        50000000 // €500,000 commercial reserve
      );

      this.psps.push({
        id: p.id,
        legalName: p.name,
        bic: p.bic,
        jurisdiction: p.jur,
        licenceStatus: 'LICENSED',
        certificationStatus: 'CERTIFIED',
        technicalAccountId: techAccountId,
        commercialDepositAccountId: depositAccountId,
        omnibusBalance: 0,
        customerCount: 1250,
        apiHealth: 'HEALTHY',
        settlementLimit: 100000000, // €1,000,000
        riskScore: 12,
      });
    }
  }

  private seedConsumersAndWallets() {
    const consumerList = [
      { id: 'USR-DE-01', name: 'Maria Schmidt', email: 'maria.schmidt@eurocore.de', alias: 'maria.schmidt@eurocore.de', pspId: 'PSP-DE-DB', jur: 'Germany' },
      { id: 'USR-FR-02', name: 'Jean Dupont', email: 'jean.dupont@eurocore.fr', alias: 'jean.dupont@eurocore.fr', pspId: 'PSP-FR-BNP', jur: 'France' },
      { id: 'USR-IT-03', name: 'Marco Rossi', email: 'marco.rossi@eurocore.it', alias: 'marco.rossi@eurocore.it', pspId: 'PSP-IT-ISP', jur: 'Italy' },
      { id: 'USR-ES-04', name: 'Sofia Garcia', email: 'sofia.garcia@eurocore.es', alias: 'sofia.garcia@eurocore.es', pspId: 'PSP-ES-SAN', jur: 'Spain' },
      { id: 'USR-NL-05', name: 'Lucas de Jong', email: 'lucas.dejong@eurocore.nl', alias: 'lucas.dejong@eurocore.nl', pspId: 'PSP-NL-ING', jur: 'Netherlands' },
    ];

    for (const c of consumerList) {
      this.consumers.push({
        id: c.id,
        fullName: c.name,
        pseudonymId: `PSEUDO-${c.id.substring(4)}-${Math.floor(Math.random() * 9000 + 1000)}`,
        email: c.email,
        jurisdiction: c.jur,
        pspId: c.pspId,
        kycLevel: 'TIER_1_STANDARD',
        status: 'ACTIVE',
        createdAt: new Date().toISOString(),
      });

      const walletId = `W-${c.id}`;
      const accId = `ACC-CUST-ONL-${c.id}`;

      this.ledger.createAccount(
        accId,
        `DIGI-EUR-WAL-${c.id.substring(4)}`,
        `Digital Euro Balance (${c.name})`,
        'CONSUMER_DIGITAL_EURO',
        walletId,
        'CONSUMER',
        0
      );

      this.wallets.push({
        id: walletId,
        userId: c.id,
        pspId: c.pspId,
        walletAddress: `EUR-ADDR-${c.id}-${Math.floor(Math.random() * 900000 + 100000)}`,
        alias: c.alias,
        onlineAccountId: accId,
        onlineBalance: 0,
        holdingLimit: 300000, // €3,000 limit
        status: 'ACTIVE',
        deviceId: `DEV-HW-${c.id.substring(4)}`,
        hasSecureElement: true,
        createdAt: new Date().toISOString(),
      });
    }
  }

  private seedMerchantsAndTerminals() {
    const merchantList = [
      { id: 'MCH-BER-01', name: 'EuroCafé Berlin', brand: 'EuroCafé', location: 'Alexanderplatz 4, Berlin, DE', pspId: 'PSP-DE-DB' },
      { id: 'MCH-PAR-02', name: 'Boutique Louvre Paris', brand: 'Boutique Louvre', location: 'Rue de Rivoli 99, Paris, FR', pspId: 'PSP-FR-BNP' },
      { id: 'MCH-MIL-03', name: 'Moda Milano Outlet', brand: 'Moda Milano', location: 'Via Montenapoleone 12, Milano, IT', pspId: 'PSP-IT-ISP' },
      { id: 'MCH-BCN-04', name: 'Mercat de la Boqueria Stand 42', brand: 'La Boqueria Fresh', location: 'La Rambla 91, Barcelona, ES', pspId: 'PSP-ES-SAN' },
    ];

    for (const m of merchantList) {
      const accId = `ACC-MERCH-SETTLE-${m.id}`;
      this.ledger.createAccount(
        accId,
        `MERCH-RCV-${m.id.substring(4)}`,
        `${m.name} Merchant Settlement Receivable`,
        'MERCHANT_SETTLEMENT_RECEIVABLE',
        m.id,
        'MERCHANT',
        0
      );

      this.merchants.push({
        id: m.id,
        merchantName: m.name,
        brandName: m.brand,
        categoryCode: '5812',
        outletLocation: m.location,
        acquiringPspId: m.pspId,
        settlementAccountId: accId,
        terminalCount: 2,
        dailyTurnover: 0,
        status: 'ACTIVE',
      });

      // Terminals
      const termId = `TERM-${m.id}-01`;
      this.terminals.push({
        id: termId,
        outletId: m.id,
        terminalCode: `EC-SOFTPOS-${m.id.substring(4)}-01`,
        type: 'SOFTPOS_MOBILE',
        supportedModes: ['ONLINE', 'OFFLINE_NFC'],
        status: 'ONLINE',
        lastPing: new Date().toISOString(),
      });
    }
  }

  private provisionOfflineSecureElements() {
    for (const w of this.wallets) {
      if (w.hasSecureElement) {
        const offW = this.offline.registerOfflineWallet(w.id, `SE-CHIP-HW-${w.id.substring(2)}`);
        w.offlineWalletId = offW.id;
      }
    }
  }

  private performInitialIssuanceAndFunding() {
    // Perform explicit central bank issuance to Deutsche Bank Digital (€150,000) and BNP Paribas (€120,000)
    const pspDB = this.psps.find((p) => p.id === 'PSP-DE-DB')!;
    const pspBNP = this.psps.find((p) => p.id === 'PSP-FR-BNP')!;
    const pspISP = this.psps.find((p) => p.id === 'PSP-IT-ISP')!;
    const pspSAN = this.psps.find((p) => p.id === 'PSP-ES-SAN')!;
    const pspING = this.psps.find((p) => p.id === 'PSP-NL-ING')!;

    this.issuance.executeIssuance('DE', pspDB, 15000000, 'ECB-COLLATERAL-DE-9811');
    this.issuance.executeIssuance('FR', pspBNP, 12000000, 'ECB-COLLATERAL-FR-4412');
    this.issuance.executeIssuance('IT', pspISP, 9000000, 'ECB-COLLATERAL-IT-7781');
    this.issuance.executeIssuance('ES', pspSAN, 8000000, 'ECB-COLLATERAL-ES-3319');
    this.issuance.executeIssuance('NL', pspING, 6000000, 'ECB-COLLATERAL-NL-1102');

    // Fund initial consumer wallets from technical accounts
    const wMaria = this.wallets.find((w) => w.userId === 'USR-DE-01')!;
    const wJean = this.wallets.find((w) => w.userId === 'USR-FR-02')!;
    const wMarco = this.wallets.find((w) => w.userId === 'USR-IT-03')!;
    const wSofia = this.wallets.find((w) => w.userId === 'USR-ES-04')!;
    const wLucas = this.wallets.find((w) => w.userId === 'USR-NL-05')!;

    const fundWallet = (wallet: DigitalWallet, psp: PaymentServiceProvider, amount: AmountMinor) => {
      this.ledger.postTransaction(
        'ISSUANCE',
        [
          { accountId: psp.technicalAccountId, debit: amount, credit: 0, description: `Initial Wallet Funding for ${wallet.alias}` },
          { accountId: wallet.onlineAccountId, debit: 0, credit: amount, description: `Initial Wallet Digital Euro Deposit` },
        ],
        `INIT-FUND-${wallet.id}`,
        `IDEM-INIT-FUND-${wallet.id}`
      );
      wallet.onlineBalance += amount;
    };

    if (wMaria) fundWallet(wMaria, pspDB, 185000); // €1,850.00
    if (wJean) fundWallet(wJean, pspBNP, 142000); // €1,420.00
    if (wMarco) fundWallet(wMarco, pspISP, 98000); // €980.00
    if (wSofia) fundWallet(wSofia, pspSAN, 75000); // €750.00
    if (wLucas) fundWallet(wLucas, pspING, 120000); // €1,200.00

    // Also load some offline balance into Maria and Jean's Secure Elements
    if (wMaria) {
      const seAccId = `ACC-SE-HOLD-${wMaria.id}`;
      this.ledger.createAccount(seAccId, `SE-ACC-${wMaria.id}`, `Offline Secure Element Balance`, 'OFFLINE_DEVICE_HOLDING', wMaria.id, 'DEVICE', 0);
      this.offline.loadOfflineBalance(wMaria, 15000, seAccId); // €150.00 offline
    }
  }

  /**
   * Helper to recalculate total active circulating central bank liabilities.
   */
  public getTotalCirculatingSupply(): AmountMinor {
    let total = 0;
    for (const w of this.wallets) {
      total += w.onlineBalance;
      const offW = this.offline.getOfflineWallet(w.id);
      if (offW) {
        total += offW.offlineBalance;
      }
    }
    for (const m of this.merchants) {
      total += m.dailyTurnover;
    }
    return total;
  }
}
