/**
 * EUROCORE Digital Twin Scenario Laboratory Engine
 * Runs 10 preconfigured scenarios for testing payment infrastructure,
 * PSP outages, network blackouts, idempotency duplicate attacks, and deposit migration stress tests.
 */

import { ScenarioDefinition, ScenarioRunState } from '../types/eurocore';

export const PRECONFIGURED_SCENARIOS: ScenarioDefinition[] = [
  {
    id: 'SCENARIO-01',
    title: 'Normal Eurozone Operational Equilibrium',
    description: '10,000 synthetic consumer wallets, 500 merchant outlets across 8 Eurosystem PSPs operating in online/offline baseline conditions.',
    category: 'OPERATIONAL',
    walletCount: 10000,
    merchantCount: 500,
    pspCount: 8,
    tpsTarget: 25,
    offlineRatioPercent: 12,
    durationSeconds: 300,
    specialConditions: ['Baseline Eurosystem Target Services routing', 'Standard holding limit €3,000'],
  },
  {
    id: 'SCENARIO-02',
    title: 'Major Tier-1 PSP Outage & Rerouting',
    description: 'Simulates complete technical API outage at major German PSP (Commerzbank Digital). Tests failure handling, pending queues, and transaction re-routing.',
    category: 'OFFLINE_OUTAGE',
    walletCount: 10000,
    merchantCount: 500,
    pspCount: 8,
    tpsTarget: 30,
    offlineRatioPercent: 20,
    durationSeconds: 180,
    specialConditions: ['PSP-DE-COMMERZ API set to OUTAGE', 'Affected consumer wallets receive clear PSP_UNAVAILABLE rejections'],
  },
  {
    id: 'SCENARIO-03',
    title: 'Widespread Network Blackout (Offline Weekend)',
    description: 'Simulates 48-hour telecom connectivity loss across southern Europe. Payment traffic shifts entirely to local Secure Element NFC offline mode.',
    category: 'OFFLINE_OUTAGE',
    walletCount: 10000,
    merchantCount: 500,
    pspCount: 8,
    tpsTarget: 15,
    offlineRatioPercent: 95,
    durationSeconds: 240,
    specialConditions: ['Online settlement gateway paused', 'Unsynced transaction counters accumulate in SE devices'],
  },
  {
    id: 'SCENARIO-04',
    title: 'Black Friday Payment Volume Surge',
    description: 'Simulates a 10x transaction volume spike across retail merchant terminals. Tests settlement queue depth, lock contention, and latency P99.',
    category: 'CAPACITY_SURGE',
    walletCount: 25000,
    merchantCount: 2000,
    pspCount: 12,
    tpsTarget: 250,
    offlineRatioPercent: 5,
    durationSeconds: 180,
    specialConditions: ['High concurrency lock contention test', 'Settlement queue depth monitored'],
  },
  {
    id: 'SCENARIO-05',
    title: 'Holding-Limit Policy Adjustment Impact',
    description: 'Reduces maximum consumer holding limit from €3,000 down to €1,500 mid-session. Evaluates rejection rate and waterfall re-routing.',
    category: 'POLICY_CHANGE',
    walletCount: 10000,
    merchantCount: 500,
    pspCount: 8,
    tpsTarget: 20,
    offlineRatioPercent: 10,
    durationSeconds: 120,
    specialConditions: ['Policy version incremented', 'Rejections yield HOLDING_LIMIT_EXCEEDED with policy ID'],
  },
  {
    id: 'SCENARIO-06',
    title: 'Synthetic AML Circular Layering Injection',
    description: 'Injects automated rapid high-frequency transfers between synthetic wallets to test compliance Rule-001 and Rule-004 alert generation.',
    category: 'SECURITY',
    walletCount: 5000,
    merchantCount: 100,
    pspCount: 6,
    tpsTarget: 40,
    offlineRatioPercent: 0,
    durationSeconds: 180,
    specialConditions: ['Rapid circular payments generated', 'Compliance workstation alerts triggered'],
  },
  {
    id: 'SCENARIO-07',
    title: 'Duplicate Payment Idempotency Attack',
    description: 'Fuzzes payment API with 1,000 identical duplicate idempotency keys in rapid succession. Proves exactly-once double-entry ledger invariant.',
    category: 'SECURITY',
    walletCount: 2000,
    merchantCount: 50,
    pspCount: 4,
    tpsTarget: 100,
    offlineRatioPercent: 0,
    durationSeconds: 60,
    specialConditions: ['High-frequency idempotency key collision test', 'Proves single monetary effect'],
  },
  {
    id: 'SCENARIO-08',
    title: 'Database & Process Recovery Verification',
    description: 'Simulates sudden settlement engine crash mid-batch followed by automated recovery and event replay. Verifies zero double-debit.',
    category: 'OPERATIONAL',
    walletCount: 5000,
    merchantCount: 200,
    pspCount: 6,
    tpsTarget: 50,
    offlineRatioPercent: 10,
    durationSeconds: 120,
    specialConditions: ['Settlement queue crash injection', 'Event journal replay verification'],
  },
  {
    id: 'SCENARIO-09',
    title: 'Eurozone SoftPOS Merchant Rapid Adoption',
    description: 'Onboards 5,000 new small merchant outlets across Spain and Italy using mobile SoftPOS NFC terminals.',
    category: 'OPERATIONAL',
    walletCount: 15000,
    merchantCount: 5000,
    pspCount: 10,
    tpsTarget: 80,
    offlineRatioPercent: 25,
    durationSeconds: 240,
    specialConditions: ['Merchant acquiring volume expansion', 'SoftPOS terminal registration spike'],
  },
  {
    id: 'SCENARIO-10',
    title: 'Financial Stability Deposit Migration Stress Test',
    description: 'Models a hypothetical scenario where 30% of commercial bank retail deposits migrate into Digital Euro central bank money.',
    category: 'FINANCIAL_STABILITY',
    walletCount: 50000,
    merchantCount: 1000,
    pspCount: 12,
    tpsTarget: 60,
    offlineRatioPercent: 10,
    durationSeconds: 300,
    specialConditions: ['Simulates commercial bank deposit outflows', 'Calculates PSP central bank collateral requirement'],
  },
];

export class DigitalTwinSimulator {
  private activeScenario: ScenarioDefinition = PRECONFIGURED_SCENARIOS[0];
  private state: ScenarioRunState = {
    scenarioId: PRECONFIGURED_SCENARIOS[0].id,
    isRunning: false,
    isPaused: false,
    speedMultiplier: 1,
    elapsedSeconds: 0,
    processedTransactions: 14820,
    settledTransactions: 14798,
    rejectedTransactions: 22,
    totalVolume: 42589000, // €425,890.00
    settlementLatencyMs: 14,
    activeIncidents: [],
  };

  public getActiveScenario(): ScenarioDefinition {
    return { ...this.activeScenario };
  }

  public getState(): ScenarioRunState {
    return { ...this.state };
  }

  public selectScenario(scenarioId: string): ScenarioDefinition | undefined {
    const found = PRECONFIGURED_SCENARIOS.find((s) => s.id === scenarioId);
    if (!found) return undefined;
    this.activeScenario = found;
    this.resetState();
    return { ...found };
  }

  public start() {
    this.state.isRunning = true;
    this.state.isPaused = false;
  }

  public pause() {
    this.state.isPaused = true;
  }

  public setSpeed(speed: number) {
    this.state.speedMultiplier = Math.max(1, Math.min(10, speed));
  }

  public resetState() {
    this.state = {
      scenarioId: this.activeScenario.id,
      isRunning: false,
      isPaused: false,
      speedMultiplier: 1,
      elapsedSeconds: 0,
      processedTransactions: 0,
      settledTransactions: 0,
      rejectedTransactions: 0,
      totalVolume: 0,
      settlementLatencyMs: 12,
      activeIncidents: [],
    };
  }

  /**
   * Advances simulation state by a given time step in seconds.
   */
  public tick(seconds: number = 1): ScenarioRunState {
    if (!this.state.isRunning || this.state.isPaused) {
      return this.getState();
    }

    const effectiveSeconds = seconds * this.state.speedMultiplier;
    this.state.elapsedSeconds += effectiveSeconds;

    // Simulate traffic generation based on target TPS
    const generatedTx = Math.round(this.activeScenario.tpsTarget * effectiveSeconds * (0.85 + Math.random() * 0.3));
    const rejections = Math.floor(generatedTx * (this.activeScenario.id === 'SCENARIO-05' ? 0.08 : 0.002));
    const settled = generatedTx - rejections;
    const avgAmountCents = Math.round(2500 + Math.random() * 3000); // ~€25 to €55

    this.state.processedTransactions += generatedTx;
    this.state.settledTransactions += settled;
    this.state.rejectedTransactions += rejections;
    this.state.totalVolume += settled * avgAmountCents;

    // Latency variance based on TPS
    this.state.settlementLatencyMs = Math.round(10 + (generatedTx / 10) * 0.8 + Math.random() * 4);

    if (this.state.elapsedSeconds >= this.activeScenario.durationSeconds) {
      this.state.isRunning = false;
    }

    return this.getState();
  }
}
