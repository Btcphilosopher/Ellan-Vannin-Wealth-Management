/**
 * EUROCORE — European Digital Money Infrastructure Domain Types
 * Independent Central Bank Digital Euro Infrastructure Simulator
 */

export type Currency = 'EUR';

// Fixed decimal or integer minor units (1 EUR = 100 cents)
export type AmountMinor = number; // Cents integer representation

export interface EuroAmount {
  minor: AmountMinor;
  formatted: string; // e.g. "€3,000.00"
}

export type EntityId = string;

// Roles
export type UserRole =
  | 'SYSTEM_ADMIN'
  | 'EUROSYSTEM_OPERATOR'
  | 'PSP_OPERATOR'
  | 'MERCHANT_OPERATOR'
  | 'CONSUMER'
  | 'COMPLIANCE_ANALYST'
  | 'RISK_ANALYST'
  | 'AUDITOR'
  | 'RESEARCHER'
  | 'READ_ONLY_OBSERVER';

// Eurosystem Entities
export interface NationalCentralBank {
  id: EntityId;
  code: string; // e.g. "DE" (Bundesbank), "FR" (Banque de France), "IT" (Banca d'Italia), "ES" (Banco de España), "NL", "AT", "IE", "PT", "GR", "FI"
  name: string;
  country: string;
  issuedBalance: AmountMinor;
  activePSPCount: number;
  status: 'ACTIVE' | 'MAINTENANCE' | 'DEGRADED';
}

export interface PolicyConfiguration {
  id: string;
  version: number;
  updatedAt: string;
  maxWalletHolding: AmountMinor; // e.g. 300,000 cents (€3,000)
  maxOfflineHolding: AmountMinor; // e.g. 50,000 cents (€500)
  maxSingleTransaction: AmountMinor; // e.g. 100,000 cents (€1,000)
  dailyPaymentLimit: AmountMinor; // e.g. 500,000 cents (€5,000)
  velocityTxCountLimit: number; // e.g. 10 txs / 5 mins
  offlineMaxTxCountWithoutSync: number; // e.g. 15 txs
  offlineSyncDelayThresholdMinutes: number; // e.g. 120 mins
  holdingLimitExceededAction: 'REJECT' | 'WATERFALL_TO_COMMERCIAL_BANK';
}

// Ledger & Double Entry
export type AccountType =
  | 'EUROSYSTEM_LIABILITY_ISSUANCE'
  | 'EUROSYSTEM_LIABILITY_REDEMPTION'
  | 'PSP_TECHNICAL_OMNIBUS'
  | 'PSP_COMMERCIAL_BANK_DEPOSIT'
  | 'CONSUMER_DIGITAL_EURO'
  | 'MERCHANT_SETTLEMENT_RECEIVABLE'
  | 'OFFLINE_DEVICE_HOLDING'
  | 'SYSTEM_FEE_ACCOUNT';

export interface LedgerAccount {
  id: EntityId;
  accountNumber: string;
  name: string;
  type: AccountType;
  ownerId: EntityId;
  ownerType: 'EUROSYSTEM' | 'PSP' | 'CONSUMER' | 'MERCHANT' | 'DEVICE';
  balance: AmountMinor; // debits - credits
  currency: Currency;
  status: 'ACTIVE' | 'FROZEN' | 'CLOSED';
  createdAt: string;
}

export interface JournalEntry {
  id: EntityId;
  transactionId: EntityId;
  accountId: EntityId;
  debit: AmountMinor;
  credit: AmountMinor;
  description: string;
  timestamp: string;
}

export interface LedgerTransaction {
  id: EntityId;
  correlationId: string;
  idempotencyKey?: string;
  type: 'ISSUANCE' | 'REDEMPTION' | 'P2P_TRANSFER' | 'P2B_PAYMENT' | 'B2B_PAYMENT' | 'REFUND' | 'REVERSAL' | 'OFFLINE_SETTLEMENT';
  status: 'POSTED' | 'REVERSED' | 'FAILED';
  entries: JournalEntry[];
  timestamp: string;
  auditHash: string;
}

// Payment Service Provider (PSP)
export interface PaymentServiceProvider {
  id: EntityId;
  legalName: string;
  bic: string;
  jurisdiction: string;
  licenceStatus: 'LICENSED' | 'SUSPENDED' | 'UNDER_REVIEW';
  certificationStatus: 'CERTIFIED' | 'PENDING' | 'REVOKED';
  technicalAccountId: EntityId;
  commercialDepositAccountId: EntityId;
  omnibusBalance: AmountMinor;
  customerCount: number;
  apiHealth: 'HEALTHY' | 'DEGRADED' | 'OUTAGE';
  settlementLimit: AmountMinor;
  riskScore: number; // 0-100
}

// Consumer & Wallet
export interface ConsumerUser {
  id: EntityId;
  fullName: string;
  pseudonymId: string; // Privacy identifier
  email: string;
  jurisdiction: string;
  pspId: EntityId;
  kycLevel: 'TIER_1_STANDARD' | 'TIER_2_ENHANCED';
  status: 'ACTIVE' | 'SUSPENDED' | 'RESTRICTED';
  createdAt: string;
}

export interface DigitalWallet {
  id: EntityId;
  userId: EntityId;
  pspId: EntityId;
  walletAddress: string;
  alias: string; // e.g. "john.doe@eurocore.eu" or mobile number
  onlineAccountId: EntityId;
  onlineBalance: AmountMinor;
  holdingLimit: AmountMinor;
  status: 'ACTIVE' | 'LOCKED' | 'FLAGGED';
  deviceId: EntityId;
  hasSecureElement: boolean;
  offlineWalletId?: EntityId;
  createdAt: string;
}

// Merchant
export interface MerchantOutlet {
  id: EntityId;
  merchantName: string;
  brandName: string;
  categoryCode: string; // MCC e.g. 5411 Supermarkets, 5812 Restaurants
  outletLocation: string; // e.g. "Alexanderplatz 4, Berlin"
  acquiringPspId: EntityId;
  settlementAccountId: EntityId;
  terminalCount: number;
  dailyTurnover: AmountMinor;
  status: 'ACTIVE' | 'SUSPENDED';
}

export interface MerchantTerminal {
  id: EntityId;
  outletId: EntityId;
  terminalCode: string; // e.g. "EC-BER-0042"
  type: 'SOFTPOS_MOBILE' | 'HARDWARE_POS' | 'ONLINE_GATEWAY';
  supportedModes: ('ONLINE' | 'OFFLINE_NFC')[];
  status: 'ONLINE' | 'OFFLINE_STANDALONE' | 'MAINTENANCE';
  lastPing: string;
}

// Payment Orders & State Machine
export type PaymentStatus =
  | 'CREATED'
  | 'RECEIVED'
  | 'VALIDATING'
  | 'AUTHORISED'
  | 'RESERVED'
  | 'SETTLING'
  | 'SETTLED'
  | 'RECONCILED'
  | 'REJECTED'
  | 'EXPIRED'
  | 'CANCELLED'
  | 'REVERSED'
  | 'SUSPENDED'
  | 'FAILED';

export type PaymentType = 'P2P' | 'P2B' | 'B2B' | 'ISSUANCE' | 'REDEMPTION' | 'OFFLINE_NFC';

export interface PaymentOrder {
  id: EntityId;
  idempotencyKey: string;
  correlationId: string;
  type: PaymentType;
  payerWalletId?: EntityId;
  payerAlias?: string;
  payerPspId?: EntityId;
  payeeWalletId?: EntityId;
  payeeAlias?: string;
  payeeMerchantOutletId?: EntityId;
  payeePspId?: EntityId;
  amount: AmountMinor;
  currency: Currency;
  purpose: string;
  reference: string;
  status: PaymentStatus;
  rejectionReason?: {
    code: string;
    policyId: string;
    message: string;
  };
  isOffline: boolean;
  offlineEnvelopeId?: string;
  createdAt: string;
  settledAt?: string;
  receiptId?: string;
  auditTrail: { timestamp: string; state: PaymentStatus; note: string }[];
}

export interface PaymentReceipt {
  id: EntityId;
  paymentId: EntityId;
  payerAlias: string;
  payeeAlias: string;
  amount: AmountMinor;
  currency: Currency;
  reference: string;
  timestamp: string;
  ledgerTransactionId: EntityId;
  settlementConfirmationHash: string;
  isOffline: boolean;
}

// Offline & Secure Element
export interface OfflineWallet {
  id: EntityId;
  parentWalletId: EntityId;
  secureElementSerial: string;
  offlineBalance: AmountMinor;
  maxOfflineCapacity: AmountMinor; // €500
  transactionCounter: number; // Monotonically increasing counter
  devicePublicKey: string;
  lastSyncedCounter: number;
  lastSyncedAt: string;
  pendingUnsyncedTxCount: number;
  status: 'ACTIVE' | 'OUT_OF_SYNC' | 'BLOCKED';
}

export interface OfflinePaymentEnvelope {
  id: EntityId;
  offlineWalletId: EntityId;
  payerDeviceSerial: string;
  payeeDeviceSerial: string;
  counter: number;
  amount: AmountMinor;
  timestamp: string;
  previousTxHash: string;
  signature: string; // Simulated cryptographic signature
  syncedToCentralLedger: boolean;
  syncTimestamp?: string;
  status: 'ACCEPTED_LOCALLY' | 'SYNCHRONISED' | 'REJECTED_REPLAY' | 'COUNTER_MISMATCH';
}

// Compliance & Fraud Alerts
export interface RiskAlert {
  id: EntityId;
  ruleId: string; // e.g. "RULE-001", "RULE-002"
  ruleName: string;
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  triggeringPaymentId?: EntityId;
  subjectWalletId?: EntityId;
  subjectPspId?: EntityId;
  evidence: string;
  riskScore: number; // 0 - 100
  status: 'NEW' | 'UNDER_REVIEW' | 'ESCALATED' | 'DISMISSED' | 'CONFIRMED_FRAUD';
  analystDecisionNote?: string;
  createdAt: string;
}

// Digital Twin & Scenario Laboratory
export interface ScenarioDefinition {
  id: string;
  title: string;
  description: string;
  category: 'OPERATIONAL' | 'OFFLINE_OUTAGE' | 'CAPACITY_SURGE' | 'POLICY_CHANGE' | 'SECURITY' | 'FINANCIAL_STABILITY';
  walletCount: number;
  merchantCount: number;
  pspCount: number;
  tpsTarget: number;
  offlineRatioPercent: number;
  durationSeconds: number;
  specialConditions: string[];
}

export interface ScenarioRunState {
  scenarioId: string;
  isRunning: boolean;
  isPaused: boolean;
  speedMultiplier: number; // 1x, 5x, 10x
  elapsedSeconds: number;
  processedTransactions: number;
  settledTransactions: number;
  rejectedTransactions: number;
  totalVolume: AmountMinor;
  settlementLatencyMs: number;
  activeIncidents: string[];
}

// R Analytics & Data Science Metrics
export interface SystemAnalytics {
  tpsCurrent: number;
  tpsPeak: number;
  settlementSuccessRate: number; // percentage
  avgLatencyMs: number;
  p99LatencyMs: number;
  totalIssuedEuro: AmountMinor;
  totalRedeemedEuro: AmountMinor;
  totalActiveHoldingsEuro: AmountMinor;
  onlineVolumeEuro: AmountMinor;
  offlineVolumeEuro: AmountMinor;
  hourlyVolumeProfile: { hour: string; online: number; offline: number }[];
  latencyDistribution: { bucketMs: string; count: number }[];
  pspLiquidityShare: { pspName: string; sharePercent: number; balance: AmountMinor }[];
  depositMigrationModel: { holdingLimitEur: number; estimatedDepositShiftBillions: number; bankLiquidityImpact: string }[];
}
