import React, { useState, useEffect } from 'react';
import { Header, ViewTab } from './components/Header';
import { ControlCentreView } from './components/ControlCentreView';
import { PspPortalView } from './components/PspPortalView';
import { MerchantTerminalView } from './components/MerchantTerminalView';
import { ConsumerWalletView } from './components/ConsumerWalletView';
import { OfflineNfcView } from './components/OfflineNfcView';
import { PolicyLabView } from './components/PolicyLabView';
import { ComplianceView } from './components/ComplianceView';
import { DigitalTwinView } from './components/DigitalTwinView';
import { AnalyticsView } from './components/AnalyticsView';
import { PrivacyAuditView } from './components/PrivacyAuditView';
import { SpecsView } from './components/SpecsView';

import { EurocoreStore } from './engine/store';
import { AnalyticsEngine } from './engine/analytics';
import { UserRole, PaymentReceipt, OfflineWallet, OfflinePaymentEnvelope } from './types/eurocore';
import { MonetaryEngine } from './engine/monetary';

// Initialize global store singleton for the app session
const globalStore = new EurocoreStore();

export function App() {
  const [activeTab, setActiveTab] = useState<ViewTab>('control_centre');
  const [activeRole, setActiveRole] = useState<UserRole>('EUROSYSTEM_OPERATOR');

  // React state mirrors
  const [ncbs, setNcbs] = useState([...globalStore.ncbs]);
  const [psps, setPsps] = useState([...globalStore.psps]);
  const [wallets, setWallets] = useState([...globalStore.wallets]);
  const [merchants, setMerchants] = useState([...globalStore.merchants]);
  const [journalEntries, setJournalEntries] = useState([...globalStore.ledger.getJournalEntries()]);
  const [policyConfig, setPolicyConfig] = useState(globalStore.policy.getConfig());
  const [alerts, setAlerts] = useState([...globalStore.compliance.getAllAlerts()]);
  const [activeScenario, setActiveScenario] = useState(globalStore.digitalTwin.getActiveScenario());
  const [runState, setRunState] = useState(globalStore.digitalTwin.getState());

  const [offlineWalletsMap, setOfflineWalletsMap] = useState<Map<string, OfflineWallet>>(() => {
    const map = new Map<string, OfflineWallet>();
    for (const w of globalStore.wallets) {
      const off = globalStore.offline.getOfflineWallet(w.id);
      if (off) map.set(w.id, off);
    }
    return map;
  });

  const refreshState = () => {
    setNcbs([...globalStore.ncbs]);
    setPsps([...globalStore.psps]);
    setWallets([...globalStore.wallets]);
    setMerchants([...globalStore.merchants]);
    setJournalEntries([...globalStore.ledger.getJournalEntries()]);
    setPolicyConfig(globalStore.policy.getConfig());
    setAlerts([...globalStore.compliance.getAllAlerts()]);
    setActiveScenario(globalStore.digitalTwin.getActiveScenario());
    setRunState(globalStore.digitalTwin.getState());

    const map = new Map<string, OfflineWallet>();
    for (const w of globalStore.wallets) {
      const off = globalStore.offline.getOfflineWallet(w.id);
      if (off) map.set(w.id, off);
    }
    setOfflineWalletsMap(map);
  };

  // Timer tick for Digital Twin simulator when running
  useEffect(() => {
    if (!runState.isRunning || runState.isPaused) return;

    const interval = setInterval(() => {
      globalStore.digitalTwin.tick(1);
      setRunState(globalStore.digitalTwin.getState());
    }, 1000);

    return () => clearInterval(interval);
  }, [runState.isRunning, runState.isPaused]);

  // Handlers
  const handleExecuteIssuance = (ncbCode: string, pspId: string, amountEuro: number, collateral: string) => {
    const amountMinor = MonetaryEngine.parseEuroToMinor(amountEuro.toString());
    const psp = globalStore.psps.find((p) => p.id === pspId);
    if (psp) {
      globalStore.issuance.executeIssuance(ncbCode, psp, amountMinor, collateral);
      refreshState();
    }
  };

  const handleExecuteRedemption = (pspId: string, amountEuro: number, bic: string) => {
    const amountMinor = MonetaryEngine.parseEuroToMinor(amountEuro.toString());
    const psp = globalStore.psps.find((p) => p.id === pspId);
    if (psp) {
      globalStore.redemption.executeRedemption(psp, amountMinor, bic);
      refreshState();
    }
  };

  const handleExecuteP2P = (payerWalletId: string, payeeAlias: string, amountEuro: number, purpose: string) => {
    const amountMinor = MonetaryEngine.parseEuroToMinor(amountEuro.toString());
    const payerWallet = globalStore.wallets.find((w) => w.id === payerWalletId);
    if (!payerWallet) return { success: false, error: 'Payer wallet not found' };

    const payeeWallet = globalStore.wallets.find((w) => w.alias.toLowerCase() === payeeAlias.toLowerCase());
    if (!payeeWallet) return { success: false, error: `Recipient user alias '${payeeAlias}' not found in Eurosystem registry.` };

    // Policy Evaluation
    const policyResult = globalStore.policy.evaluateOnlinePayment(amountMinor, payeeWallet.onlineBalance);
    if (!policyResult.isAllowed) {
      return { success: false, error: `${policyResult.rejectionCode}: ${policyResult.humanMessage}` };
    }

    const res = globalStore.settlement.submitPayment(
      'P2P',
      amountMinor,
      payerWallet,
      payeeWallet,
      undefined,
      purpose,
      `REF-P2P-${Math.floor(100000 + Math.random() * 900000)}`,
      `IDEM-P2P-${Date.now()}`
    );

    refreshState();
    return { success: res.success, receipt: res.receipt, error: res.rejectionReason };
  };

  const handleExecuteMerchantPayment = (
    payerWalletId: string,
    merchantId: string,
    amountEuro: number,
    reference: string
  ) => {
    const amountMinor = MonetaryEngine.parseEuroToMinor(amountEuro.toString());
    const payerWallet = globalStore.wallets.find((w) => w.id === payerWalletId);
    if (!payerWallet) return { success: false, error: 'Payer wallet not found' };

    const merchant = globalStore.merchants.find((m) => m.id === merchantId);
    if (!merchant) return { success: false, error: 'Merchant outlet not found' };

    const policyResult = globalStore.policy.evaluateOnlinePayment(amountMinor, 0);
    if (!policyResult.isAllowed) {
      return { success: false, error: `${policyResult.rejectionCode}: ${policyResult.humanMessage}` };
    }

    const res = globalStore.settlement.submitPayment(
      'P2B',
      amountMinor,
      payerWallet,
      undefined,
      merchant,
      `Purchase at ${merchant.brandName}`,
      reference,
      `IDEM-P2B-${Date.now()}`
    );

    refreshState();
    return { success: res.success, receipt: res.receipt, error: res.rejectionReason };
  };

  const handleLoadOffline = (onlineWalletId: string, amountEuro: number) => {
    const amountMinor = MonetaryEngine.parseEuroToMinor(amountEuro.toString());
    const onlineWallet = globalStore.wallets.find((w) => w.id === onlineWalletId);
    if (!onlineWallet) return { success: false, error: 'Wallet not found' };

    const seAccId = `ACC-SE-HOLD-${onlineWallet.id}`;
    const res = globalStore.offline.loadOfflineBalance(onlineWallet, amountMinor, seAccId);
    refreshState();
    return { success: res.success, error: res.error };
  };

  const handleExecuteNfcTap = (payerWalletId: string, payeeWalletId: string, amountEuro: number) => {
    const amountMinor = MonetaryEngine.parseEuroToMinor(amountEuro.toString());
    const sessionState = globalStore.offline.executeNfcProximityPayment(payerWalletId, payeeWalletId, amountMinor);
    refreshState();
    return sessionState;
  };

  const handleSyncOfflineQueue = () => {
    const res = globalStore.offline.synchroniseOfflineQueue();
    refreshState();
    return res;
  };

  const handleUpdatePolicyConfig = (newConfig: Partial<typeof policyConfig>) => {
    globalStore.policy.updateConfig(newConfig);
    refreshState();
  };

  const handleUpdateAlertStatus = (alertId: string, status: any, note?: string) => {
    globalStore.compliance.updateAlertStatus(alertId, status, note);
    refreshState();
  };

  const handleSelectScenario = (scenarioId: string) => {
    globalStore.digitalTwin.selectScenario(scenarioId);
    refreshState();
  };

  const handleControlAction = (action: 'start' | 'pause' | 'reset' | 'tick', speed?: number) => {
    if (action === 'start') globalStore.digitalTwin.start();
    if (action === 'pause') globalStore.digitalTwin.pause();
    if (action === 'reset') globalStore.digitalTwin.resetState();
    if (action === 'tick') globalStore.digitalTwin.tick(1);
    if (speed) globalStore.digitalTwin.setSpeed(speed);
    refreshState();
  };

  const totalIssued = ncbs.reduce((sum, n) => sum + n.issuedBalance, 0);
  const totalCirculating = globalStore.getTotalCirculatingSupply();
  const systemAnalytics = AnalyticsEngine.getSystemAnalytics(
    totalIssued,
    0,
    totalCirculating,
    38500000,
    4089000
  );

  return (
    <div className="bg-slate-950 text-slate-100 min-h-screen flex flex-col font-sans">
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        activeRole={activeRole}
        setActiveRole={setActiveRole}
        systemHealth="OPERATIONAL (10/10 NCBs)"
        activeScenarioTitle={activeScenario.title}
        simulationRunning={runState.isRunning}
      />

      <main className="flex-1">
        {activeTab === 'control_centre' && (
          <ControlCentreView
            ncbs={ncbs}
            psps={psps}
            journalEntries={journalEntries}
            totalIssued={totalIssued}
            totalCirculating={totalCirculating}
            onExecuteIssuance={handleExecuteIssuance}
            onExecuteRedemption={handleExecuteRedemption}
          />
        )}

        {activeTab === 'psp_portal' && <PspPortalView psps={psps} wallets={wallets} />}

        {activeTab === 'merchant_terminal' && (
          <MerchantTerminalView
            merchants={merchants}
            wallets={wallets}
            onExecuteMerchantPayment={handleExecuteMerchantPayment}
          />
        )}

        {activeTab === 'consumer_wallet' && (
          <ConsumerWalletView
            wallets={wallets}
            offlineWallets={offlineWalletsMap}
            onExecuteP2P={handleExecuteP2P}
            onLoadOffline={handleLoadOffline}
          />
        )}

        {activeTab === 'offline_nfc' && (
          <OfflineNfcView
            wallets={wallets}
            offlineWallets={offlineWalletsMap}
            onExecuteNfcTap={handleExecuteNfcTap}
            onSyncOfflineQueue={handleSyncOfflineQueue}
            pendingEnvelopes={globalStore.offline.getPendingEnvelopes()}
          />
        )}

        {activeTab === 'policy_lab' && (
          <PolicyLabView
            policyConfig={policyConfig}
            onUpdatePolicyConfig={handleUpdatePolicyConfig}
            policyEngine={globalStore.policy}
          />
        )}

        {activeTab === 'compliance' && (
          <ComplianceView alerts={alerts} onUpdateAlertStatus={handleUpdateAlertStatus} />
        )}

        {activeTab === 'digital_twin' && (
          <DigitalTwinView
            activeScenario={activeScenario}
            runState={runState}
            onSelectScenario={handleSelectScenario}
            onControlAction={handleControlAction}
          />
        )}

        {activeTab === 'analytics' && <AnalyticsView analytics={systemAnalytics} />}

        {activeTab === 'privacy_audit' && <PrivacyAuditView />}

        {activeTab === 'specs' && <SpecsView />}
      </main>
    </div>
  );
}

export default App;
