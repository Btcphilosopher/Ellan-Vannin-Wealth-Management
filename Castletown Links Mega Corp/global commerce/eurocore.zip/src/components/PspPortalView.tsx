import React, { useState } from 'react';
import { Layers, ShieldCheck, CheckCircle2, AlertTriangle, Users, Building, ArrowUpRight, Plus } from 'lucide-react';
import { PaymentServiceProvider, DigitalWallet } from '../types/eurocore';
import { MonetaryEngine } from '../engine/monetary';

interface PspPortalViewProps {
  psps: PaymentServiceProvider[];
  wallets: DigitalWallet[];
}

export const PspPortalView: React.FC<PspPortalViewProps> = ({ psps, wallets }) => {
  const [selectedPspId, setSelectedPspId] = useState<string>(psps[0]?.id || 'PSP-DE-DB');
  const [onboardFormOpen, setOnboardFormOpen] = useState<boolean>(false);
  const [newPspName, setNewPspName] = useState<string>('Crédit Agricole Digital');
  const [newBic, setNewBic] = useState<string>('AGRIFRPPXXX');
  const [newJurisdiction, setNewJurisdiction] = useState<string>('France');

  const selectedPsp = psps.find((p) => p.id === selectedPspId) || psps[0];
  const pspWallets = wallets.filter((w) => w.pspId === selectedPspId);

  return (
    <div className="p-4 md:p-6 bg-slate-900 text-slate-100 min-h-[calc(100vh-80px)] font-sans space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-slate-800 pb-4 gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <Layers className="w-6 h-6 text-sky-400" />
            <h1 className="text-xl font-bold font-mono tracking-tight">PAYMENT SERVICE PROVIDER (PSP) PORTAL</h1>
          </div>
          <p className="text-xs text-slate-400 mt-1 font-mono">
            Commercial Bank & Payment Institution Integration Services • Technical Omnibus Liquidity Management
          </p>
        </div>

        <button
          onClick={() => setOnboardFormOpen(!onboardFormOpen)}
          className="bg-sky-600 hover:bg-sky-500 text-white font-mono text-xs font-bold px-3 py-2 rounded flex items-center space-x-2 transition-all self-start md:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>ONBOARD NEW PSP PARTICIPANT</span>
        </button>
      </div>

      {onboardFormOpen && (
        <div className="bg-slate-950 border border-sky-800 p-4 rounded shadow-lg font-mono text-xs space-y-3">
          <div className="text-sky-400 font-bold text-sm">PSP Onboarding Workflow Simulator</div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <label className="block text-slate-400 mb-1">Legal Institution Name:</label>
              <input
                type="text"
                value={newPspName}
                onChange={(e) => setNewPspName(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-slate-100 p-2 rounded"
              />
            </div>
            <div>
              <label className="block text-slate-400 mb-1">SWIFT / BIC Code:</label>
              <input
                type="text"
                value={newBic}
                onChange={(e) => setNewBic(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-slate-100 p-2 rounded"
              />
            </div>
            <div>
              <label className="block text-slate-400 mb-1">Jurisdiction:</label>
              <input
                type="text"
                value={newJurisdiction}
                onChange={(e) => setNewJurisdiction(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-slate-100 p-2 rounded"
              />
            </div>
          </div>
          <div className="text-[11px] text-slate-400 bg-slate-900 p-2 rounded border border-slate-800">
            Stages: APPLICATION → IDENTITY_VALIDATION → TECHNICAL_ASSESSMENT → SECURITY_ASSESSMENT → CERTIFICATION → ACTIVATION
          </div>
          <button
            onClick={() => {
              alert(`Simulated Onboarding Workflow Initiated for ${newPspName}. Technical Omnibus Account Created.`);
              setOnboardFormOpen(false);
            }}
            className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-4 py-2 rounded"
          >
            SUBMIT PARTICIPANT CERTIFICATION REQUEST
          </button>
        </div>
      )}

      {/* PSP Selection Selector */}
      <div className="flex space-x-2 overflow-x-auto pb-2 border-b border-slate-800 font-mono text-xs">
        {psps.map((p) => (
          <button
            key={p.id}
            onClick={() => setSelectedPspId(p.id)}
            className={`px-3 py-2 rounded border transition-all whitespace-nowrap flex items-center space-x-2 ${
              selectedPspId === p.id
                ? 'bg-slate-800 border-sky-500 text-sky-400 font-bold'
                : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Building className="w-3.5 h-3.5" />
            <span>{p.legalName}</span>
          </button>
        ))}
      </div>

      {/* Selected PSP Detailed View */}
      {selectedPsp && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 font-mono">
          <div className="lg:col-span-2 space-y-6">
            {/* PSP Stats Overview */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div className="bg-slate-950 border border-slate-800 p-3.5 rounded">
                <div className="text-[11px] text-slate-400">Technical Omnibus Balance</div>
                <div className="text-lg font-bold text-sky-400 mt-1">
                  {MonetaryEngine.formatEuro(selectedPsp.omnibusBalance)}
                </div>
                <div className="text-[10px] text-slate-500 mt-1">Central Bank Reserve Account</div>
              </div>

              <div className="bg-slate-950 border border-slate-800 p-3.5 rounded">
                <div className="text-[11px] text-slate-400">Active Customer Wallets</div>
                <div className="text-lg font-bold text-emerald-400 mt-1">{selectedPsp.customerCount}</div>
                <div className="text-[10px] text-slate-500 mt-1">Tier-1 KYC Registered</div>
              </div>

              <div className="bg-slate-950 border border-slate-800 p-3.5 rounded">
                <div className="text-[11px] text-slate-400">Settlement Limit</div>
                <div className="text-lg font-bold text-indigo-400 mt-1">
                  {MonetaryEngine.formatEuro(selectedPsp.settlementLimit)}
                </div>
                <div className="text-[10px] text-slate-500 mt-1">Daily Cap</div>
              </div>
            </div>

            {/* Customer Wallet Population Table */}
            <div className="bg-slate-950 border border-slate-800 rounded p-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
                <div className="flex items-center space-x-2">
                  <Users className="w-4 h-4 text-sky-400" />
                  <h2 className="text-sm font-bold uppercase text-slate-200">
                    Customer Digital Euro Wallet Portfolio ({pspWallets.length})
                  </h2>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px] bg-slate-900/80">
                      <th className="py-2 px-2">Wallet ID</th>
                      <th className="py-2 px-2">User Alias</th>
                      <th className="py-2 px-2 text-right">Online Balance</th>
                      <th className="py-2 px-2 text-right">Holding Limit</th>
                      <th className="py-2 px-2 text-center">Secure Element</th>
                      <th className="py-2 px-2 text-right">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {pspWallets.map((w) => (
                      <tr key={w.id} className="hover:bg-slate-900/60">
                        <td className="py-2 px-2 text-sky-400">{w.id}</td>
                        <td className="py-2 px-2 text-slate-200">{w.alias}</td>
                        <td className="py-2 px-2 text-right font-bold text-emerald-400">
                          {MonetaryEngine.formatEuro(w.onlineBalance)}
                        </td>
                        <td className="py-2 px-2 text-right text-slate-400">
                          {MonetaryEngine.formatEuro(w.holdingLimit)}
                        </td>
                        <td className="py-2 px-2 text-center">
                          <span className="bg-emerald-950 text-emerald-400 text-[10px] px-1.5 py-0.5 rounded border border-emerald-800">
                            ENABLED
                          </span>
                        </td>
                        <td className="py-2 px-2 text-right text-emerald-400 font-semibold">{w.status}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Right Column: Participant Health & Security Status */}
          <div className="space-y-6">
            <div className="bg-slate-950 border border-slate-800 rounded p-4 space-y-4">
              <div className="flex items-center space-x-2 border-b border-slate-800 pb-3">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <h2 className="text-sm font-bold uppercase text-slate-200">Regulatory Certification</h2>
              </div>

              <div className="space-y-2 text-xs">
                <div className="flex justify-between py-1 border-b border-slate-900">
                  <span className="text-slate-400">Licence Status:</span>
                  <span className="text-emerald-400 font-bold">{selectedPsp.licenceStatus}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-900">
                  <span className="text-slate-400">Eurosystem Certification:</span>
                  <span className="text-emerald-400 font-bold">{selectedPsp.certificationStatus}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-900">
                  <span className="text-slate-400">SWIFT / BIC Code:</span>
                  <span className="text-sky-400">{selectedPsp.bic}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-900">
                  <span className="text-slate-400">Jurisdiction:</span>
                  <span className="text-slate-200">{selectedPsp.jurisdiction}</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">API Health Status:</span>
                  <span className="text-emerald-400 font-bold">{selectedPsp.apiHealth}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
