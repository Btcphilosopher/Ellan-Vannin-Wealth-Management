import React, { useState } from 'react';
import { Wallet, Smartphone, Send, Download, ArrowUpRight, ArrowDownLeft, ShieldCheck, CheckCircle2, AlertTriangle, WifiOff } from 'lucide-react';
import { DigitalWallet, PaymentReceipt, OfflineWallet } from '../types/eurocore';
import { MonetaryEngine } from '../engine/monetary';

interface ConsumerWalletViewProps {
  wallets: DigitalWallet[];
  offlineWallets: Map<string, OfflineWallet>;
  onExecuteP2P: (
    payerWalletId: string,
    payeeAlias: string,
    amountEuro: number,
    purpose: string
  ) => { success: boolean; receipt?: PaymentReceipt; error?: string };
  onLoadOffline: (
    onlineWalletId: string,
    amountEuro: number
  ) => { success: boolean; error?: string };
}

export const ConsumerWalletView: React.FC<ConsumerWalletViewProps> = ({
  wallets,
  offlineWallets,
  onExecuteP2P,
  onLoadOffline,
}) => {
  const [selectedWalletId, setSelectedWalletId] = useState<string>(wallets[0]?.id || 'W-USR-DE-01');
  const [payeeAlias, setPayeeAlias] = useState<string>('jean.dupont@eurocore.fr');
  const [p2pAmountStr, setP2pAmountStr] = useState<string>('25.00');
  const [p2pPurpose, setP2pPurpose] = useState<string>('Dinner share');
  const [loadOfflineAmountStr, setLoadOfflineAmountStr] = useState<string>('50.00');

  const [p2pResultMsg, setP2pResultMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [offlineLoadMsg, setOfflineLoadMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const activeWallet = wallets.find((w) => w.id === selectedWalletId) || wallets[0];
  const activeOfflineWallet = offlineWallets.get(activeWallet?.id || '');

  const totalHoldingCents = activeWallet.onlineBalance + (activeOfflineWallet?.offlineBalance || 0);
  const holdingLimitCents = activeWallet.holdingLimit;
  const holdingRatio = Math.min(100, (totalHoldingCents / holdingLimitCents) * 100);

  const handleP2PSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setP2pResultMsg(null);

    const amountEuro = parseFloat(p2pAmountStr);
    if (isNaN(amountEuro) || amountEuro <= 0) {
      setP2pResultMsg({ type: 'error', text: 'Invalid transfer amount' });
      return;
    }

    const res = onExecuteP2P(activeWallet.id, payeeAlias, amountEuro, p2pPurpose);
    if (res.success && res.receipt) {
      setP2pResultMsg({
        type: 'success',
        text: `Sent ${MonetaryEngine.formatEuro(res.receipt.amount)} to ${res.receipt.payeeAlias}. Receipt ID: ${res.receipt.id}`,
      });
    } else {
      setP2pResultMsg({ type: 'error', text: res.error || 'P2P Transfer failed' });
    }
  };

  const handleLoadOfflineSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setOfflineLoadMsg(null);

    const amountEuro = parseFloat(loadOfflineAmountStr);
    if (isNaN(amountEuro) || amountEuro <= 0) {
      setOfflineLoadMsg({ type: 'error', text: 'Invalid load amount' });
      return;
    }

    const res = onLoadOffline(activeWallet.id, amountEuro);
    if (res.success) {
      setOfflineLoadMsg({
        type: 'success',
        text: `Successfully transferred €${amountEuro.toFixed(2)} into Hardware Secure Element.`,
      });
    } else {
      setOfflineLoadMsg({ type: 'error', text: res.error || 'Offline load failed' });
    }
  };

  return (
    <div className="p-4 md:p-6 bg-slate-900 text-slate-100 min-h-[calc(100vh-80px)] font-sans space-y-6">
      {/* Top Bar Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-slate-800 pb-4 gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <Smartphone className="w-6 h-6 text-sky-400" />
            <h1 className="text-xl font-bold font-mono tracking-tight">EUROSYSTEM CITIZEN DIGITAL EURO APP</h1>
          </div>
          <p className="text-xs text-slate-400 mt-1 font-mono">
            Direct Central Bank Money Wallet • Dual Online & Offline Secure Element Storage
          </p>
        </div>

        {/* User / Wallet Selector */}
        <div className="flex items-center space-x-2 font-mono text-xs">
          <span className="text-slate-400">Select Citizen:</span>
          <select
            value={selectedWalletId}
            onChange={(e) => setSelectedWalletId(e.target.value)}
            className="bg-slate-950 border border-slate-700 text-slate-100 p-2 rounded focus:outline-none focus:border-sky-500 font-bold"
          >
            {wallets.map((w) => (
              <option key={w.id} value={w.id}>
                {w.alias} ({w.pspId})
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 font-mono">
        {/* Mobile App Screen Shell */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-5">
            {/* Wallet Card Header */}
            <div className="bg-gradient-to-br from-slate-900 to-sky-950 p-4 rounded-xl border border-sky-800/80 space-y-3">
              <div className="flex justify-between items-center text-xs">
                <span className="text-sky-300 font-bold uppercase tracking-wider">Digital Euro Account</span>
                <span className="bg-sky-900/80 text-sky-300 px-2 py-0.5 rounded text-[10px] border border-sky-700">
                  {activeWallet?.pspId}
                </span>
              </div>

              <div>
                <div className="text-[11px] text-slate-400">Total Holding Balance</div>
                <div className="text-2xl font-extrabold text-slate-100 mt-0.5">
                  {MonetaryEngine.formatEuro(totalHoldingCents)}
                </div>
              </div>

              {/* Holding Limit Meter */}
              <div className="space-y-1.5 pt-2 border-t border-sky-900/60 text-[11px]">
                <div className="flex justify-between text-slate-300">
                  <span>Holding Ceiling Usage:</span>
                  <span className="font-bold text-sky-400">
                    {MonetaryEngine.formatEuro(totalHoldingCents)} / {MonetaryEngine.formatEuro(holdingLimitCents)}
                  </span>
                </div>
                <div className="w-full bg-slate-900 rounded-full h-2 overflow-hidden border border-slate-800">
                  <div
                    className={`h-full transition-all duration-500 ${
                      holdingRatio > 90 ? 'bg-rose-500' : holdingRatio > 70 ? 'bg-amber-400' : 'bg-emerald-400'
                    }`}
                    style={{ width: `${holdingRatio}%` }}
                  ></div>
                </div>
              </div>
            </div>

            {/* Split Balances: Online vs Offline SE */}
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg">
                <div className="text-slate-400 text-[10px] uppercase">Online Central Ledger</div>
                <div className="text-base font-bold text-emerald-400 mt-1">
                  {MonetaryEngine.formatEuro(activeWallet?.onlineBalance || 0)}
                </div>
              </div>

              <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg">
                <div className="flex items-center space-x-1 text-slate-400 text-[10px] uppercase">
                  <WifiOff className="w-3 h-3 text-amber-400" />
                  <span>Offline Chip (SE)</span>
                </div>
                <div className="text-base font-bold text-amber-400 mt-1">
                  {MonetaryEngine.formatEuro(activeOfflineWallet?.offlineBalance || 0)}
                </div>
              </div>
            </div>

            {/* Hardware SE Load Action Form */}
            <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-3 text-xs">
              <div className="flex items-center space-x-2 text-slate-200 font-bold border-b border-slate-800 pb-2">
                <Download className="w-4 h-4 text-amber-400" />
                <span>Load Funds to Offline Secure Element</span>
              </div>

              <form onSubmit={handleLoadOfflineSubmit} className="space-y-3">
                <div>
                  <label className="block text-slate-400 mb-1">Transfer Amount (€):</label>
                  <input
                    type="number"
                    step="0.01"
                    value={loadOfflineAmountStr}
                    onChange={(e) => setLoadOfflineAmountStr(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 text-slate-100 p-2 rounded text-xs font-bold"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold py-2 px-3 rounded transition-all text-xs flex items-center justify-center space-x-1.5"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>TRANSFER TO SECURE ELEMENT CHIP</span>
                </button>
              </form>

              {offlineLoadMsg && (
                <div
                  className={`p-2 rounded text-[11px] ${
                    offlineLoadMsg.type === 'success'
                      ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-800'
                      : 'bg-rose-950/80 text-rose-300 border border-rose-800'
                  }`}
                >
                  {offlineLoadMsg.text}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* P2P Send Payment Section */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-slate-950 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6">
            <div className="flex items-center space-x-2 border-b border-slate-800 pb-4">
              <Send className="w-5 h-5 text-sky-400" />
              <h2 className="text-base font-bold uppercase tracking-wide text-slate-200">
                Send Instant Digital Euro Payment (P2P)
              </h2>
            </div>

            <form onSubmit={handleP2PSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-400 mb-1">Recipient User Alias / Email:</label>
                <input
                  type="text"
                  value={payeeAlias}
                  onChange={(e) => setPayeeAlias(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 text-slate-100 p-2.5 rounded font-mono"
                  placeholder="alias@eurocore.eu"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Amount (€ EUR):</label>
                <input
                  type="number"
                  step="0.01"
                  value={p2pAmountStr}
                  onChange={(e) => setP2pAmountStr(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 text-slate-100 p-2.5 rounded text-lg font-bold"
                  placeholder="0.00"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Payment Purpose / Memo:</label>
                <input
                  type="text"
                  value={p2pPurpose}
                  onChange={(e) => setP2pPurpose(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 text-slate-100 p-2 rounded"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-sky-600 hover:bg-sky-500 text-white font-bold py-3 px-4 rounded transition-all text-sm flex items-center justify-center space-x-2"
              >
                <Send className="w-4 h-4" />
                <span>CONFIRM & EXECUTE INSTANT TRANSFER</span>
              </button>
            </form>

            {p2pResultMsg && (
              <div
                className={`p-3 rounded text-xs flex items-center space-x-2 ${
                  p2pResultMsg.type === 'success'
                    ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-800'
                    : 'bg-rose-950/80 text-rose-300 border border-rose-800'
                }`}
              >
                {p2pResultMsg.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                ) : (
                  <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                )}
                <span>{p2pResultMsg.text}</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
