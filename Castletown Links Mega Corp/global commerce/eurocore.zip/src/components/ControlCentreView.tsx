import React, { useState } from 'react';
import {
  Building2,
  TrendingUp,
  Activity,
  CheckCircle,
  AlertCircle,
  PlusCircle,
  ArrowDownRight,
  ArrowUpRight,
  Shield,
  Layers,
  Database,
  RefreshCw,
  Search,
} from 'lucide-react';
import { NationalCentralBank, PaymentServiceProvider, JournalEntry } from '../types/eurocore';
import { MonetaryEngine } from '../engine/monetary';

interface ControlCentreViewProps {
  ncbs: NationalCentralBank[];
  psps: PaymentServiceProvider[];
  journalEntries: JournalEntry[];
  totalIssued: number;
  totalCirculating: number;
  onExecuteIssuance: (ncbCode: string, pspId: string, amountEuro: number, collateral: string) => void;
  onExecuteRedemption: (pspId: string, amountEuro: number, bic: string) => void;
}

export const ControlCentreView: React.FC<ControlCentreViewProps> = ({
  ncbs,
  psps,
  journalEntries,
  totalIssued,
  totalCirculating,
  onExecuteIssuance,
  onExecuteRedemption,
}) => {
  const [selectedNcb, setSelectedNcb] = useState<string>('DE');
  const [selectedPsp, setSelectedPsp] = useState<string>(psps[0]?.id || 'PSP-DE-DB');
  const [issuanceAmountStr, setIssuanceAmountStr] = useState<string>('50000');
  const [collateralRef, setCollateralRef] = useState<string>('ECB-COLLATERAL-DE-2030');
  const [redemptionAmountStr, setRedemptionAmountStr] = useState<string>('25000');
  const [issuanceSuccessMsg, setIssuanceSuccessMsg] = useState<string | null>(null);

  const handleIssuanceSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amountMinor = MonetaryEngine.parseEuroToMinor(issuanceAmountStr);
    if (amountMinor <= 0) return;
    onExecuteIssuance(selectedNcb, selectedPsp, amountMinor / 100, collateralRef);
    setIssuanceSuccessMsg(`Successfully executed Eurosystem Digital Euro Issuance of €${parseFloat(issuanceAmountStr).toLocaleString()} via ${selectedNcb} NCB.`);
    setTimeout(() => setIssuanceSuccessMsg(null), 4000);
  };

  const handleRedemptionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amountMinor = MonetaryEngine.parseEuroToMinor(redemptionAmountStr);
    if (amountMinor <= 0) return;
    const targetPsp = psps.find((p) => p.id === selectedPsp);
    onExecuteRedemption(selectedPsp, amountMinor / 100, targetPsp?.bic || 'DEUTDEFFXXX');
    setIssuanceSuccessMsg(`Successfully executed Digital Euro Redemption of €${parseFloat(redemptionAmountStr).toLocaleString()} for ${targetPsp?.legalName}.`);
    setTimeout(() => setIssuanceSuccessMsg(null), 4000);
  };

  return (
    <div className="p-4 md:p-6 bg-slate-900 text-slate-100 min-h-[calc(100vh-80px)] font-sans space-y-6">
      {/* Title Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-slate-800 pb-4 gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <Building2 className="w-6 h-6 text-sky-400" />
            <h1 className="text-xl font-bold text-slate-100 font-mono tracking-tight">
              EUROSYSTEM OPERATIONS CONTROL CENTRE
            </h1>
          </div>
          <p className="text-xs text-slate-400 mt-1 font-mono">
            Centralized Digital Euro Settlement Engine • Real-time TARGET Services Operations Dashboard
          </p>
        </div>

        <div className="flex items-center space-x-3 text-xs font-mono">
          <div className="bg-slate-950 border border-slate-800 px-3 py-1.5 rounded flex items-center space-x-2">
            <span className="text-slate-400">LEDGER INVARIANT:</span>
            <span className="text-emerald-400 font-bold flex items-center space-x-1">
              <CheckCircle className="w-3.5 h-3.5 inline" />
              <span>DEBITS == CREDITS</span>
            </span>
          </div>
          <div className="bg-slate-950 border border-slate-800 px-3 py-1.5 rounded flex items-center space-x-2">
            <span className="text-slate-400">ENGINE MODE:</span>
            <span className="text-sky-400 font-bold">CENTRAL_SETTLEMENT</span>
          </div>
        </div>
      </div>

      {/* High-Level Institutional KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
        <div className="bg-slate-950 border border-slate-800 p-3.5 rounded shadow-sm">
          <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">Total Issued (Central Bank)</div>
          <div className="text-lg font-bold text-sky-400 font-mono mt-1">
            {MonetaryEngine.formatEuro(totalIssued)}
          </div>
          <div className="text-[10px] text-slate-500 font-mono mt-1 flex items-center space-x-1">
            <ArrowUpRight className="w-3 h-3 text-emerald-400 inline" />
            <span>Authorized Liabilities</span>
          </div>
        </div>

        <div className="bg-slate-950 border border-slate-800 p-3.5 rounded shadow-sm">
          <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">Active Circulating Supply</div>
          <div className="text-lg font-bold text-emerald-400 font-mono mt-1">
            {MonetaryEngine.formatEuro(totalCirculating)}
          </div>
          <div className="text-[10px] text-slate-500 font-mono mt-1">Wallets + Merchants + SE</div>
        </div>

        <div className="bg-slate-950 border border-slate-800 p-3.5 rounded shadow-sm">
          <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">PSP Omnibus Reserve</div>
          <div className="text-lg font-bold text-indigo-400 font-mono mt-1">
            {MonetaryEngine.formatEuro(psps.reduce((s, p) => s + p.omnibusBalance, 0))}
          </div>
          <div className="text-[10px] text-slate-500 font-mono mt-1">{psps.length} Certified Participants</div>
        </div>

        <div className="bg-slate-950 border border-slate-800 p-3.5 rounded shadow-sm">
          <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">Settlement Latency</div>
          <div className="text-lg font-bold text-amber-400 font-mono mt-1">14.2 ms</div>
          <div className="text-[10px] text-slate-500 font-mono mt-1">P99: 48.5 ms</div>
        </div>

        <div className="bg-slate-950 border border-slate-800 p-3.5 rounded shadow-sm">
          <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">Throughput</div>
          <div className="text-lg font-bold text-cyan-400 font-mono mt-1">42.8 TPS</div>
          <div className="text-[10px] text-slate-500 font-mono mt-1">Peak: 184 TPS</div>
        </div>

        <div className="bg-slate-950 border border-slate-800 p-3.5 rounded shadow-sm">
          <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">Settlement Finality</div>
          <div className="text-lg font-bold text-emerald-400 font-mono mt-1">99.88%</div>
          <div className="text-[10px] text-slate-500 font-mono mt-1">Deterministic Finality</div>
        </div>
      </div>

      {issuanceSuccessMsg && (
        <div className="bg-emerald-950/80 border border-emerald-800 text-emerald-300 p-3 rounded font-mono text-xs flex items-center space-x-2">
          <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{issuanceSuccessMsg}</span>
        </div>
      )}

      {/* Main Operations Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: National Central Banks Map & Status */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-slate-950 border border-slate-800 rounded p-4 shadow-sm">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
              <div className="flex items-center space-x-2">
                <Layers className="w-4 h-4 text-sky-400" />
                <h2 className="text-sm font-bold font-mono uppercase text-slate-200">
                  Eurosystem National Central Bank (NCB) Nodes
                </h2>
              </div>
              <span className="text-xs text-slate-500 font-mono">10 Active Euroarea Jurisdictions</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {ncbs.map((ncb) => (
                <div
                  key={ncb.id}
                  onClick={() => setSelectedNcb(ncb.code)}
                  className={`p-3 rounded border font-mono transition-all cursor-pointer ${
                    selectedNcb === ncb.code
                      ? 'bg-slate-900 border-sky-500 text-slate-100 shadow'
                      : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 text-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center space-x-2">
                      <span className="bg-slate-800 text-sky-400 font-bold px-1.5 py-0.5 rounded text-[10px]">
                        {ncb.code}
                      </span>
                      <span className="font-semibold text-slate-200">{ncb.name}</span>
                    </div>
                    <span className="inline-flex items-center space-x-1 text-[10px] text-emerald-400 bg-emerald-950/60 px-1.5 py-0.5 rounded border border-emerald-900">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                      <span>{ncb.status}</span>
                    </span>
                  </div>

                  <div className="mt-3 flex items-center justify-between text-xs">
                    <span className="text-slate-400">Issued Digital Euro:</span>
                    <span className="font-bold text-sky-400">{MonetaryEngine.formatEuro(ncb.issuedBalance)}</span>
                  </div>

                  <div className="mt-1 flex items-center justify-between text-[11px] text-slate-400">
                    <span>Connected PSPs: {ncb.activePSPCount}</span>
                    <span>Country: {ncb.country}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Central Double-Entry Ledger Journal Stream */}
          <div className="bg-slate-950 border border-slate-800 rounded p-4 shadow-sm">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
              <div className="flex items-center space-x-2">
                <Database className="w-4 h-4 text-emerald-400" />
                <h2 className="text-sm font-bold font-mono uppercase text-slate-200">
                  Central Ledger Double-Entry Audit Journal Feed
                </h2>
              </div>
              <span className="text-xs text-slate-500 font-mono">Immutable Event Stream</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left font-mono text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px] bg-slate-900/80">
                    <th className="py-2 px-2">Journal ID</th>
                    <th className="py-2 px-2">Tx Ref</th>
                    <th className="py-2 px-2">Description</th>
                    <th className="py-2 px-2 text-right">Debit (€)</th>
                    <th className="py-2 px-2 text-right">Credit (€)</th>
                    <th className="py-2 px-2 text-right">Timestamp</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {journalEntries.slice(0, 8).map((j) => (
                    <tr key={j.id} className="hover:bg-slate-900/60 transition-colors">
                      <td className="py-1.5 px-2 text-sky-400 text-[11px]">{j.id}</td>
                      <td className="py-1.5 px-2 text-slate-300 text-[11px]">{j.transactionId}</td>
                      <td className="py-1.5 px-2 text-slate-200 max-w-[220px] truncate">{j.description}</td>
                      <td className="py-1.5 px-2 text-right text-emerald-400">
                        {j.debit > 0 ? MonetaryEngine.formatEuro(j.debit) : '—'}
                      </td>
                      <td className="py-1.5 px-2 text-right text-indigo-400">
                        {j.credit > 0 ? MonetaryEngine.formatEuro(j.credit) : '—'}
                      </td>
                      <td className="py-1.5 px-2 text-right text-slate-500 text-[10px]">
                        {j.timestamp.substring(11, 19)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Right Column: Eurosystem Issuance & Redemption Workbench */}
        <div className="space-y-6">
          <div className="bg-slate-950 border border-slate-800 rounded p-4 shadow-sm">
            <div className="flex items-center space-x-2 border-b border-slate-800 pb-3 mb-4">
              <PlusCircle className="w-4 h-4 text-sky-400" />
              <h2 className="text-sm font-bold font-mono uppercase text-slate-200">
                Eurosystem Issuance Engine
              </h2>
            </div>

            <form onSubmit={handleIssuanceSubmit} className="space-y-4 font-mono text-xs">
              <div>
                <label className="block text-slate-400 mb-1">Issuing National Central Bank (NCB):</label>
                <select
                  value={selectedNcb}
                  onChange={(e) => setSelectedNcb(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 text-slate-100 p-2 rounded focus:outline-none focus:border-sky-500"
                >
                  {ncbs.map((ncb) => (
                    <option key={ncb.code} value={ncb.code}>
                      {ncb.code} — {ncb.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Target Payment Service Provider (PSP):</label>
                <select
                  value={selectedPsp}
                  onChange={(e) => setSelectedPsp(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 text-slate-100 p-2 rounded focus:outline-none focus:border-sky-500"
                >
                  {psps.map((psp) => (
                    <option key={psp.id} value={psp.id}>
                      {psp.legalName} ({psp.bic})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Issuance Amount (€ EUR):</label>
                <input
                  type="number"
                  value={issuanceAmountStr}
                  onChange={(e) => setIssuanceAmountStr(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 text-slate-100 p-2 rounded focus:outline-none focus:border-sky-500 font-bold"
                  placeholder="50000"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Pledged Collateral Reference:</label>
                <input
                  type="text"
                  value={collateralRef}
                  onChange={(e) => setCollateralRef(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 text-slate-100 p-2 rounded focus:outline-none focus:border-sky-500"
                />
              </div>

              <div className="p-3 bg-slate-900/80 border border-slate-800 text-[11px] text-slate-400 rounded space-y-1">
                <div className="font-semibold text-slate-300">Accounting Effect:</div>
                <div>• Debit: Eurosystem Central Bank Liability (+Money Created)</div>
                <div>• Credit: PSP Technical Omnibus Account (+PSP Reserve)</div>
              </div>

              <button
                type="submit"
                className="w-full bg-sky-600 hover:bg-sky-500 text-white font-bold py-2.5 px-4 rounded transition-all flex items-center justify-center space-x-2"
              >
                <PlusCircle className="w-4 h-4" />
                <span>EXECUTE ISSUANCE WORKFLOW</span>
              </button>
            </form>
          </div>

          {/* Redemption Workbench */}
          <div className="bg-slate-950 border border-slate-800 rounded p-4 shadow-sm">
            <div className="flex items-center space-x-2 border-b border-slate-800 pb-3 mb-4">
              <ArrowDownRight className="w-4 h-4 text-indigo-400" />
              <h2 className="text-sm font-bold font-mono uppercase text-slate-200">
                Redemption Engine (Digital Euro to Bank Deposit)
              </h2>
            </div>

            <form onSubmit={handleRedemptionSubmit} className="space-y-4 font-mono text-xs">
              <div>
                <label className="block text-slate-400 mb-1">Redeeming PSP Participant:</label>
                <select
                  value={selectedPsp}
                  onChange={(e) => setSelectedPsp(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 text-slate-100 p-2 rounded focus:outline-none focus:border-sky-500"
                >
                  {psps.map((psp) => (
                    <option key={psp.id} value={psp.id}>
                      {psp.legalName} — Omnibus: {MonetaryEngine.formatEuro(psp.omnibusBalance)}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Redemption Amount (€ EUR):</label>
                <input
                  type="number"
                  value={redemptionAmountStr}
                  onChange={(e) => setRedemptionAmountStr(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 text-slate-100 p-2 rounded focus:outline-none focus:border-sky-500 font-bold"
                  placeholder="25000"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-2.5 px-4 rounded transition-all flex items-center justify-center space-x-2"
              >
                <ArrowDownRight className="w-4 h-4" />
                <span>EXECUTE REDEMPTION TO COMMERCIAL MONEY</span>
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};
