import React from 'react';
import {
  Activity,
  Shield,
  Layers,
  Building2,
  Store,
  Wallet,
  WifiOff,
  Sliders,
  AlertTriangle,
  PlayCircle,
  BarChart3,
  Eye,
  FileText,
  Clock,
  CheckCircle2,
  Server,
} from 'lucide-react';
import { UserRole } from '../types/eurocore';

export type ViewTab =
  | 'control_centre'
  | 'psp_portal'
  | 'merchant_terminal'
  | 'consumer_wallet'
  | 'offline_nfc'
  | 'policy_lab'
  | 'compliance'
  | 'digital_twin'
  | 'analytics'
  | 'privacy_audit'
  | 'specs';

interface HeaderProps {
  activeTab: ViewTab;
  setActiveTab: (tab: ViewTab) => void;
  activeRole: UserRole;
  setActiveRole: (role: UserRole) => void;
  systemHealth: string;
  activeScenarioTitle?: string;
  simulationRunning: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  activeRole,
  setActiveRole,
  systemHealth,
  activeScenarioTitle,
  simulationRunning,
}) => {
  const tabs: { id: ViewTab; label: string; icon: React.ReactNode }[] = [
    { id: 'control_centre', label: 'Eurosystem Control Room', icon: <Building2 className="w-4 h-4" /> },
    { id: 'psp_portal', label: 'PSP Portal', icon: <Layers className="w-4 h-4" /> },
    { id: 'merchant_terminal', label: 'Merchant SoftPOS', icon: <Store className="w-4 h-4" /> },
    { id: 'consumer_wallet', label: 'Consumer Wallet', icon: <Wallet className="w-4 h-4" /> },
    { id: 'offline_nfc', label: 'Offline NFC Emulator', icon: <WifiOff className="w-4 h-4" /> },
    { id: 'policy_lab', label: 'Policy Lab', icon: <Sliders className="w-4 h-4" /> },
    { id: 'compliance', label: 'AML / Fraud Risk', icon: <AlertTriangle className="w-4 h-4" /> },
    { id: 'digital_twin', label: 'Digital Twin Scenarios', icon: <PlayCircle className="w-4 h-4" /> },
    { id: 'analytics', label: 'R Analytics Workbench', icon: <BarChart3 className="w-4 h-4" /> },
    { id: 'privacy_audit', label: 'Privacy & Audit Matrix', icon: <Eye className="w-4 h-4" /> },
    { id: 'specs', label: 'System Documentation', icon: <FileText className="w-4 h-4" /> },
  ];

  return (
    <header className="bg-slate-950 text-slate-100 border-b border-slate-800 sticky top-0 z-50 shadow-xl font-mono">
      {/* Top Banner Disclaimer & System Status */}
      <div className="bg-slate-900 border-b border-slate-800 px-4 py-1.5 flex flex-wrap items-center justify-between text-xs">
        <div className="flex items-center space-x-3">
          <span className="bg-sky-950 text-sky-400 font-bold border border-sky-800 px-2 py-0.5 rounded tracking-wider">
            EUROCORE
          </span>
          <span className="text-slate-400 font-sans hidden sm:inline">
            INDEPENDENT DIGITAL EURO INFRASTRUCTURE SIMULATOR
          </span>
        </div>

        <div className="flex items-center space-x-4 text-xs">
          <div className="flex items-center space-x-1.5 bg-emerald-950/60 border border-emerald-800/80 text-emerald-400 px-2 py-0.5 rounded">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <span className="font-semibold text-[11px]">{systemHealth}</span>
          </div>

          <div className="hidden lg:flex items-center space-x-1 text-slate-400 bg-slate-850 px-2 py-0.5 rounded border border-slate-800">
            <Clock className="w-3 h-3 text-sky-400" />
            <span>CET {new Date().toISOString().substring(11, 19)}</span>
          </div>

          {activeScenarioTitle && (
            <div className="hidden md:flex items-center space-x-1.5 text-amber-300 bg-amber-950/50 border border-amber-800/60 px-2 py-0.5 rounded text-[11px]">
              <Activity className="w-3.5 h-3.5 animate-pulse text-amber-400" />
              <span className="truncate max-w-[200px]">{activeScenarioTitle}</span>
            </div>
          )}

          {/* Role Switcher */}
          <div className="flex items-center space-x-1.5">
            <Shield className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={activeRole}
              onChange={(e) => setActiveRole(e.target.value as UserRole)}
              className="bg-slate-900 border border-slate-700 text-slate-200 text-xs rounded px-2 py-0.5 focus:outline-none focus:border-sky-500 cursor-pointer"
            >
              <option value="EUROSYSTEM_OPERATOR">Eurosystem Operator</option>
              <option value="PSP_OPERATOR">PSP Operator</option>
              <option value="MERCHANT_OPERATOR">Merchant Operator</option>
              <option value="CONSUMER">Consumer User</option>
              <option value="COMPLIANCE_ANALYST">Compliance Analyst</option>
              <option value="AUDITOR">Auditor</option>
              <option value="READ_ONLY_OBSERVER">Read-Only Observer</option>
            </select>
          </div>
        </div>
      </div>

      {/* Main Tab Navigation */}
      <nav className="flex space-x-1 px-3 pt-2 overflow-x-auto scrollbar-none border-t border-slate-900">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center space-x-2 px-3 py-2 text-xs font-medium rounded-t-md transition-all whitespace-nowrap border-t border-x ${
                isActive
                  ? 'bg-slate-900 text-sky-400 border-sky-500/80 border-b-2 border-b-sky-400 shadow-lg font-semibold'
                  : 'bg-slate-950 text-slate-400 border-transparent hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              <span className={isActive ? 'text-sky-400' : 'text-slate-500'}>{tab.icon}</span>
              <span>{tab.label}</span>
            </button>
          );
        })}
      </nav>
    </header>
  );
};
