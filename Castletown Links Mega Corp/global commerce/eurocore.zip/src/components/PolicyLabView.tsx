import React, { useState } from 'react';
import { Sliders, Shield, CheckCircle, AlertTriangle, Play, RefreshCw } from 'lucide-react';
import { PolicyConfiguration } from '../types/eurocore';
import { MonetaryEngine } from '../engine/monetary';
import { PolicyEngine } from '../engine/policy';

interface PolicyLabViewProps {
  policyConfig: PolicyConfiguration;
  onUpdatePolicyConfig: (newConfig: Partial<PolicyConfiguration>) => void;
  policyEngine: PolicyEngine;
}

export const PolicyLabView: React.FC<PolicyLabViewProps> = ({
  policyConfig,
  onUpdatePolicyConfig,
  policyEngine,
}) => {
  const [holdingLimitEuro, setHoldingLimitEuro] = useState<string>(
    (policyConfig.maxWalletHolding / 100).toString()
  );
  const [singleTxLimitEuro, setSingleTxLimitEuro] = useState<string>(
    (policyConfig.maxSingleTransaction / 100).toString()
  );
  const [offlineCapEuro, setOfflineCapEuro] = useState<string>(
    (policyConfig.maxOfflineHolding / 100).toString()
  );

  // Playground test state
  const [testAmountEuro, setTestAmountEuro] = useState<string>('3500.00');
  const [testCurrentBalanceEuro, setTestCurrentBalanceEuro] = useState<string>('500.00');
  const [testResult, setTestResult] = useState<ReturnType<PolicyEngine['evaluateOnlinePayment']> | null>(null);

  const handleSavePolicy = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdatePolicyConfig({
      maxWalletHolding: MonetaryEngine.parseEuroToMinor(holdingLimitEuro),
      maxSingleTransaction: MonetaryEngine.parseEuroToMinor(singleTxLimitEuro),
      maxOfflineHolding: MonetaryEngine.parseEuroToMinor(offlineCapEuro),
    });
    alert('Policy Engine rules updated in live memory.');
  };

  const handleRunPlaygroundTest = (e: React.FormEvent) => {
    e.preventDefault();
    const amountCents = MonetaryEngine.parseEuroToMinor(testAmountEuro);
    const balanceCents = MonetaryEngine.parseEuroToMinor(testCurrentBalanceEuro);
    const res = policyEngine.evaluateOnlinePayment(amountCents, balanceCents);
    setTestResult(res);
  };

  return (
    <div className="p-4 md:p-6 bg-slate-900 text-slate-100 min-h-[calc(100vh-80px)] font-sans space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-slate-800 pb-4 gap-4 font-mono">
        <div>
          <div className="flex items-center space-x-2">
            <Sliders className="w-6 h-6 text-sky-400" />
            <h1 className="text-xl font-bold tracking-tight">POLICY ENGINE & LEGISLATIVE LIMITS LABORATORY</h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Configurable Policy Rules • Holding Ceilings • Velocity Controls • Rejection Verdict Simulator
          </p>
        </div>

        <div className="bg-slate-950 border border-slate-800 px-3 py-1.5 rounded text-xs text-sky-400 font-bold">
          POLICY ENGINE v{policyConfig.version} (LIVE)
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 font-mono text-xs">
        {/* Rule Configurator Form */}
        <div className="bg-slate-950 border border-slate-800 rounded p-5 space-y-5 shadow-md">
          <div className="text-sm font-bold uppercase text-slate-200 border-b border-slate-800 pb-3 flex items-center space-x-2">
            <Shield className="w-4 h-4 text-sky-400" />
            <span>Eurosystem Policy Limits Configuration</span>
          </div>

          <form onSubmit={handleSavePolicy} className="space-y-4">
            <div>
              <label className="block text-slate-400 mb-1">
                Consumer Holding Limit Ceiling (€ EUR) [POL-HLD-01]:
              </label>
              <input
                type="number"
                value={holdingLimitEuro}
                onChange={(e) => setHoldingLimitEuro(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-slate-100 p-2.5 rounded font-bold"
              />
              <span className="text-[10px] text-slate-500">ECB Proposed Limit: €3,000 max holding</span>
            </div>

            <div>
              <label className="block text-slate-400 mb-1">
                Single Online Payment Limit (€ EUR) [POL-TX-01]:
              </label>
              <input
                type="number"
                value={singleTxLimitEuro}
                onChange={(e) => setSingleTxLimitEuro(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-slate-100 p-2.5 rounded font-bold"
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1">
                Offline Secure Element Max Capacity (€ EUR) [POL-OFF-01]:
              </label>
              <input
                type="number"
                value={offlineCapEuro}
                onChange={(e) => setOfflineCapEuro(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-slate-100 p-2.5 rounded font-bold"
              />
              <span className="text-[10px] text-slate-500">ECB Proposed Offline Cap: €500</span>
            </div>

            <button
              type="submit"
              className="w-full bg-sky-600 hover:bg-sky-500 text-white font-bold py-3 px-4 rounded transition-all text-xs flex items-center justify-center space-x-2"
            >
              <RefreshCw className="w-4 h-4" />
              <span>UPDATE POLICY ENGINE RULES & INCREMENT VERSION</span>
            </button>
          </form>
        </div>

        {/* Rejection Verdict Playground */}
        <div className="bg-slate-950 border border-slate-800 rounded p-5 space-y-5 shadow-md">
          <div className="text-sm font-bold uppercase text-slate-200 border-b border-slate-800 pb-3 flex items-center space-x-2">
            <Play className="w-4 h-4 text-emerald-400" />
            <span>Interactive Rejection Verdict Playground</span>
          </div>

          <form onSubmit={handleRunPlaygroundTest} className="space-y-4">
            <div>
              <label className="block text-slate-400 mb-1">Proposed Transaction Amount (€ EUR):</label>
              <input
                type="number"
                step="0.01"
                value={testAmountEuro}
                onChange={(e) => setTestAmountEuro(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-slate-100 p-2 rounded"
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1">Recipient Current Holding (€ EUR):</label>
              <input
                type="number"
                step="0.01"
                value={testCurrentBalanceEuro}
                onChange={(e) => setTestCurrentBalanceEuro(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-slate-100 p-2 rounded"
              />
            </div>

            <button
              type="submit"
              className="w-full bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold py-2.5 px-4 rounded transition-all flex items-center justify-center space-x-2"
            >
              <Play className="w-4 h-4" />
              <span>EVALUATE POLICY VERDICT</span>
            </button>
          </form>

          {testResult && (
            <div
              className={`p-4 rounded border space-y-2 ${
                testResult.isAllowed
                  ? 'bg-emerald-950/80 border-emerald-800 text-emerald-300'
                  : 'bg-rose-950/80 border-rose-800 text-rose-300'
              }`}
            >
              <div className="flex items-center space-x-2 font-bold text-sm">
                {testResult.isAllowed ? (
                  <>
                    <CheckCircle className="w-5 h-5 text-emerald-400" />
                    <span>VERDICT: ALLOWED</span>
                  </>
                ) : (
                  <>
                    <AlertTriangle className="w-5 h-5 text-rose-400" />
                    <span>VERDICT: REJECTED ({testResult.rejectionCode})</span>
                  </>
                )}
              </div>

              {!testResult.isAllowed && (
                <div className="space-y-1 text-xs">
                  <div>Policy ID Triggered: {testResult.policyId}</div>
                  <div>Explanation: {testResult.humanMessage}</div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
