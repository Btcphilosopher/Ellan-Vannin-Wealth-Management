import React, { useState } from 'react';
import { FileText, Shield, Layers, Database, Lock, CheckCircle, Terminal } from 'lucide-react';

export const SpecsView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'ARCH' | 'SECURITY' | 'API' | 'REGULATORY'>('ARCH');

  return (
    <div className="p-4 md:p-6 bg-slate-900 text-slate-100 min-h-[calc(100vh-80px)] font-mono text-xs space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-slate-800 pb-4 gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <FileText className="w-6 h-6 text-sky-400" />
            <h1 className="text-xl font-bold tracking-tight">EUROCORE TECHNICAL SPECIFICATIONS & ARCHITECTURE</h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Eurosystem Digital Euro Operating Environment • System Blueprint • Security Model • OpenAPI 3.0 Docs
          </p>
        </div>
      </div>

      {/* Sub-Tab Navigation */}
      <div className="flex space-x-2 border-b border-slate-800 pb-2">
        <button
          onClick={() => setActiveTab('ARCH')}
          className={`px-3 py-1.5 rounded font-bold transition-all ${
            activeTab === 'ARCH' ? 'bg-sky-600 text-white' : 'bg-slate-950 text-slate-400 hover:text-slate-200'
          }`}
        >
          System Architecture & Ledger
        </button>
        <button
          onClick={() => setActiveTab('SECURITY')}
          className={`px-3 py-1.5 rounded font-bold transition-all ${
            activeTab === 'SECURITY' ? 'bg-sky-600 text-white' : 'bg-slate-950 text-slate-400 hover:text-slate-200'
          }`}
        >
          Threat Model & Cryptography
        </button>
        <button
          onClick={() => setActiveTab('API')}
          className={`px-3 py-1.5 rounded font-bold transition-all ${
            activeTab === 'API' ? 'bg-sky-600 text-white' : 'bg-slate-950 text-slate-400 hover:text-slate-200'
          }`}
        >
          OpenAPI REST Endpoints
        </button>
        <button
          onClick={() => setActiveTab('REGULATORY')}
          className={`px-3 py-1.5 rounded font-bold transition-all ${
            activeTab === 'REGULATORY' ? 'bg-sky-600 text-white' : 'bg-slate-950 text-slate-400 hover:text-slate-200'
          }`}
        >
          Regulatory & Holding Limits
        </button>
      </div>

      {activeTab === 'ARCH' && (
        <div className="bg-slate-950 border border-slate-800 p-6 rounded space-y-4 text-slate-300 leading-relaxed">
          <div className="text-base font-bold text-sky-400 border-b border-slate-800 pb-2">
            1. Centralised Double-Entry Ledger Mechanics & Accounting Invariants
          </div>
          <p>
            EUROCORE implements a deterministic, centralized double-entry ledger architecture. Money is represented strictly as non-negative integer minor units (cents) to avoid floating-point binary rounding errors.
          </p>
          <div className="bg-slate-900 p-4 rounded border border-slate-800 space-y-2 text-xs font-mono">
            <div className="text-emerald-400 font-bold">CORE LEDGER INVARIANT:</div>
            <div>FOR ALL TRANSACTIONS T: SUM(DEBITS(T)) == SUM(CREDITS(T))</div>
            <div>FOR ALL ACCOUNTS A: BALANCE(A) == SUM(CREDITS(A)) - SUM(DEBITS(A))</div>
          </div>
          <p>
            Digital Euro liabilities are issued directly by Eurosystem National Central Banks (NCBs) into Payment Service Provider (PSP) Technical Omnibus Accounts. PSPs manage individual consumer digital euro wallets, with holding limits enforced by policy engines.
          </p>
        </div>
      )}

      {activeTab === 'SECURITY' && (
        <div className="bg-slate-950 border border-slate-800 p-6 rounded space-y-4 text-slate-300 leading-relaxed">
          <div className="text-base font-bold text-amber-400 border-b border-slate-800 pb-2">
            2. Threat Model & Security Posture
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div className="bg-slate-900 p-3.5 rounded border border-slate-800 space-y-1">
              <div className="text-sky-400 font-bold">Double-Spend Protection</div>
              <p className="text-slate-400">
                Online settlement uses mutex locks and idempotency hash tables. Concurrent transactions on the same account are serialized cleanly.
              </p>
            </div>

            <div className="bg-slate-900 p-3.5 rounded border border-slate-800 space-y-1">
              <div className="text-amber-400 font-bold">Offline NFC Hardware Security</div>
              <p className="text-slate-400">
                Offline payments utilize tamper-resistant Secure Elements (SE) enforcing monotonically increasing hardware counters and local Ed25519 signature envelopes.
              </p>
            </div>

            <div className="bg-slate-900 p-3.5 rounded border border-slate-800 space-y-1">
              <div className="text-emerald-400 font-bold">Replay Attack Detection</div>
              <p className="text-slate-400">
                Reconnection sync validates monotonic counter sequence against last recorded central state, rejecting duplicated or replayed offline envelopes.
              </p>
            </div>

            <div className="bg-slate-900 p-3.5 rounded border border-slate-800 space-y-1">
              <div className="text-rose-400 font-bold">Idempotency Key Collisions</div>
              <p className="text-slate-400">
                Duplicate HTTP posts return cached settlement receipts without executing secondary ledger movements.
              </p>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'API' && (
        <div className="bg-slate-950 border border-slate-800 p-6 rounded space-y-4 text-slate-300">
          <div className="text-base font-bold text-sky-400 border-b border-slate-800 pb-2">
            3. OpenAPI 3.0 REST Specification
          </div>
          <div className="bg-slate-900 p-4 rounded border border-slate-800 space-y-2 font-mono text-[11px]">
            <div>GET /api/v1/system/health — System health & ledger invariants</div>
            <div>GET /api/v1/system/metrics — Central bank circulating supply & throughput</div>
            <div>GET /api/v1/wallets — List citizen wallets and balances</div>
            <div>POST /api/v1/payments/p2p — Submit online P2P digital euro transfer</div>
            <div>POST /api/v1/payments/merchant — Merchant SoftPOS payment acceptance</div>
            <div>POST /api/v1/issuance/requests — Submit central bank issuance workflow</div>
            <div>POST /api/v1/offline/tap-payment — Execute NFC proximity tap emulation</div>
            <div>POST /api/v1/offline/synchronise — Sync offline envelopes to central ledger</div>
            <div>GET /api/v1/scenarios — Digital Twin scenario controls</div>
          </div>
        </div>
      )}

      {activeTab === 'REGULATORY' && (
        <div className="bg-slate-950 border border-slate-800 p-6 rounded space-y-4 text-slate-300">
          <div className="text-base font-bold text-emerald-400 border-b border-slate-800 pb-2">
            4. Regulatory Framework & Holding Limits
          </div>
          <p>
            To prevent excessive commercial bank deposit disintermediation during times of financial stress, the European Central Bank proposed a individual holding limit ceiling (e.g. €3,000 per citizen).
          </p>
          <p>
            A reverse-waterfall mechanism allows seamless auto-funding from a linked commercial bank account when incoming payments exceed holding ceilings or when wallet balances fall below threshold.
          </p>
        </div>
      )}
    </div>
  );
};
