import React, { useState } from 'react';
import { WifiOff, Cpu, Play, RefreshCw, CheckCircle, AlertTriangle, Terminal, Shield } from 'lucide-react';
import { DigitalWallet, OfflineWallet, OfflinePaymentEnvelope } from '../types/eurocore';
import { MonetaryEngine } from '../engine/monetary';
import { NfcSessionState } from '../engine/offline';

interface OfflineNfcViewProps {
  wallets: DigitalWallet[];
  offlineWallets: Map<string, OfflineWallet>;
  onExecuteNfcTap: (
    payerWalletId: string,
    payeeWalletId: string,
    amountEuro: number
  ) => NfcSessionState;
  onSyncOfflineQueue: () => { syncedCount: number; failedCount: number; reconciliationLog: string[] };
  pendingEnvelopes: OfflinePaymentEnvelope[];
}

export const OfflineNfcView: React.FC<OfflineNfcViewProps> = ({
  wallets,
  offlineWallets,
  onExecuteNfcTap,
  onSyncOfflineQueue,
  pendingEnvelopes,
}) => {
  const [payerWalletId, setPayerWalletId] = useState<string>(wallets[0]?.id || 'W-USR-DE-01');
  const [payeeWalletId, setPayeeWalletId] = useState<string>(wallets[1]?.id || 'W-USR-FR-02');
  const [tapAmountStr, setTapAmountStr] = useState<string>('12.50');

  const [activeSession, setActiveSession] = useState<NfcSessionState | null>(null);
  const [syncLog, setSyncLog] = useState<string[] | null>(null);

  const payerWallet = wallets.find((w) => w.id === payerWalletId);
  const payeeWallet = wallets.find((w) => w.id === payeeWalletId);
  const payerSE = offlineWallets.get(payerWalletId);
  const payeeSE = offlineWallets.get(payeeWalletId);

  const handleExecuteTap = (e: React.FormEvent) => {
    e.preventDefault();
    setSyncLog(null);
    const amountEuro = parseFloat(tapAmountStr);
    if (isNaN(amountEuro) || amountEuro <= 0) return;

    const state = onExecuteNfcTap(payerWalletId, payeeWalletId, amountEuro);
    setActiveSession(state);
  };

  const handleSyncClick = () => {
    const res = onSyncOfflineQueue();
    setSyncLog(res.reconciliationLog);
  };

  return (
    <div className="p-4 md:p-6 bg-slate-900 text-slate-100 min-h-[calc(100vh-80px)] font-mono text-xs space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-slate-800 pb-4 gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <WifiOff className="w-6 h-6 text-amber-400" />
            <h1 className="text-xl font-bold tracking-tight">OFFLINE PROXIMITY PAYMENT & HARDWARE SE EMULATOR</h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            NFC ISO/IEC 14443-4 APDU State Machine • Monotonic Transaction Counter & Ed25519 Local Signature Envelope
          </p>
        </div>

        <button
          onClick={handleSyncClick}
          className="bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold px-4 py-2.5 rounded flex items-center space-x-2 shadow-lg transition-all"
        >
          <RefreshCw className="w-4 h-4" />
          <span>SYNCHRONISE OFFLINE QUEUE TO CENTRAL LEDGER ({pendingEnvelopes.length})</span>
        </button>
      </div>

      {syncLog && (
        <div className="bg-slate-950 border border-amber-800 p-4 rounded space-y-2">
          <div className="text-amber-400 font-bold flex items-center space-x-2">
            <CheckCircle className="w-4 h-4" />
            <span>Central Ledger Reconnection & Synchronization Results</span>
          </div>
          <div className="space-y-1 font-mono text-[11px] text-slate-300">
            {syncLog.map((line, idx) => (
              <div key={idx} className="border-b border-slate-900 py-0.5">
                {line}
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Hardware Secure Element State Cards */}
        <div className="space-y-4">
          <div className="bg-slate-950 border border-slate-800 p-4 rounded space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-slate-400 font-bold">PAYER SECURE ELEMENT (SE-01)</span>
              <span className="bg-amber-950 text-amber-400 text-[10px] px-1.5 py-0.5 rounded border border-amber-800">
                ACTIVE
              </span>
            </div>
            <div className="space-y-1.5">
              <div className="flex justify-between text-slate-400">
                <span>SE Serial:</span>
                <span className="text-slate-200">{payerSE?.secureElementSerial}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Monotonic Counter:</span>
                <span className="text-amber-400 font-bold">#{payerSE?.transactionCounter}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Offline SE Balance:</span>
                <span className="text-emerald-400 font-bold">
                  {MonetaryEngine.formatEuro(payerSE?.offlineBalance || 0)}
                </span>
              </div>
            </div>
          </div>

          <div className="bg-slate-950 border border-slate-800 p-4 rounded space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-slate-400 font-bold">PAYEE SECURE ELEMENT (SE-02)</span>
              <span className="bg-amber-950 text-amber-400 text-[10px] px-1.5 py-0.5 rounded border border-amber-800">
                ACTIVE
              </span>
            </div>
            <div className="space-y-1.5">
              <div className="flex justify-between text-slate-400">
                <span>SE Serial:</span>
                <span className="text-slate-200">{payeeSE?.secureElementSerial}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Offline SE Balance:</span>
                <span className="text-emerald-400 font-bold">
                  {MonetaryEngine.formatEuro(payeeSE?.offlineBalance || 0)}
                </span>
              </div>
            </div>
          </div>

          {/* Trigger Tap Form */}
          <div className="bg-slate-950 border border-slate-800 p-4 rounded space-y-4">
            <div className="text-amber-400 font-bold border-b border-slate-800 pb-2">
              Execute NFC Proximity Tap
            </div>
            <form onSubmit={handleExecuteTap} className="space-y-3">
              <div>
                <label className="block text-slate-400 mb-1">Payer Device:</label>
                <select
                  value={payerWalletId}
                  onChange={(e) => setPayerWalletId(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 text-slate-100 p-2 rounded"
                >
                  {wallets.map((w) => (
                    <option key={w.id} value={w.id}>
                      {w.alias}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Payee Device:</label>
                <select
                  value={payeeWalletId}
                  onChange={(e) => setPayeeWalletId(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 text-slate-100 p-2 rounded"
                >
                  {wallets.map((w) => (
                    <option key={w.id} value={w.id}>
                      {w.alias}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Offline Tap Amount (€):</label>
                <input
                  type="number"
                  step="0.01"
                  value={tapAmountStr}
                  onChange={(e) => setTapAmountStr(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 text-slate-100 p-2 rounded font-bold"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold py-2.5 px-4 rounded flex items-center justify-center space-x-2 shadow"
              >
                <Play className="w-4 h-4" />
                <span>START PROXIMITY APDU EXCHANGE</span>
              </button>
            </form>
          </div>
        </div>

        {/* APDU Protocol Trace Terminal Output */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-slate-950 border border-slate-800 rounded p-4 h-full flex flex-col">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
              <div className="flex items-center space-x-2">
                <Terminal className="w-4 h-4 text-amber-400" />
                <span className="font-bold uppercase text-slate-200">ISO/IEC 14443-4 APDU Protocol Trace Log</span>
              </div>
              <span className="text-[10px] text-slate-500">13.56 MHz Carrier</span>
            </div>

            <div className="bg-slate-900/90 border border-slate-800 p-3 rounded font-mono text-[11px] space-y-2 flex-1 overflow-y-auto max-h-[420px]">
              {activeSession ? (
                activeSession.simulatedApduLog.map((log, idx) => (
                  <div key={idx} className="border-b border-slate-800/60 pb-1.5 space-y-0.5">
                    <div className="flex justify-between text-amber-400 font-bold">
                      <span>[{log.step}]</span>
                      <span className="text-slate-500 text-[10px]">{log.timestamp.substring(11, 19)}</span>
                    </div>
                    <div className="text-sky-300 font-mono">APDU HEX: {log.apduHex}</div>
                    <div className="text-slate-300">{log.description}</div>
                  </div>
                ))
              ) : (
                <div className="text-slate-500 italic py-8 text-center">
                  Execute an NFC Proximity Tap to inspect raw APDU command & response exchange trace.
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
