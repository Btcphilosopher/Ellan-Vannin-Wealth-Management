import React, { useState } from 'react';
import { BarChart3, Download, Share2, Layers, Cpu, Shield, FileText } from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend, CartesianGrid, LineChart, Line } from 'recharts';
import { AnalyticsEngine } from '../engine/analytics';
import { SystemAnalytics } from '../types/eurocore';
import { MonetaryEngine } from '../engine/monetary';

interface AnalyticsViewProps {
  analytics: SystemAnalytics;
}

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({ analytics }) => {
  const [activeTab, setActiveTab] = useState<'CHARTS' | 'NETWORK' | 'DEPOSIT_MIGRATION' | 'REPORT'>('CHARTS');
  const networkData = AnalyticsEngine.getNetworkGraphData();
  const reportText = AnalyticsEngine.generateResearchReport(analytics);

  const handleDownloadReport = () => {
    const blob = new Blob([reportText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `EUROCORE_Research_Report_${new Date().toISOString().substring(0, 10)}.txt`;
    a.click();
  };

  return (
    <div className="p-4 md:p-6 bg-slate-900 text-slate-100 min-h-[calc(100vh-80px)] font-mono text-xs space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-slate-800 pb-4 gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <BarChart3 className="w-6 h-6 text-sky-400" />
            <h1 className="text-xl font-bold tracking-tight">R-STYLE STATISTICAL ANALYTICS & DATA SCIENCE WORKBENCH</h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Eurosystem Quantitative Research • Settlement Latency Distributions • Network Topologies • Deposit Migration Models
          </p>
        </div>

        <button
          onClick={handleDownloadReport}
          className="bg-sky-600 hover:bg-sky-500 text-white font-bold px-3 py-2 rounded flex items-center space-x-2 shadow transition-all self-start md:self-auto"
        >
          <Download className="w-4 h-4" />
          <span>DOWNLOAD RESEARCH REPORT (.TXT)</span>
        </button>
      </div>

      {/* Sub-Tab Navigation */}
      <div className="flex space-x-2 border-b border-slate-800 pb-2">
        <button
          onClick={() => setActiveTab('CHARTS')}
          className={`px-3 py-1.5 rounded font-bold transition-all ${
            activeTab === 'CHARTS' ? 'bg-sky-600 text-white' : 'bg-slate-950 text-slate-400 hover:text-slate-200'
          }`}
        >
          Volume & Latency Profiles
        </button>
        <button
          onClick={() => setActiveTab('NETWORK')}
          className={`px-3 py-1.5 rounded font-bold transition-all ${
            activeTab === 'NETWORK' ? 'bg-sky-600 text-white' : 'bg-slate-950 text-slate-400 hover:text-slate-200'
          }`}
        >
          Network Topology Graph
        </button>
        <button
          onClick={() => setActiveTab('DEPOSIT_MIGRATION')}
          className={`px-3 py-1.5 rounded font-bold transition-all ${
            activeTab === 'DEPOSIT_MIGRATION' ? 'bg-sky-600 text-white' : 'bg-slate-950 text-slate-400 hover:text-slate-200'
          }`}
        >
          Deposit Migration Model
        </button>
        <button
          onClick={() => setActiveTab('REPORT')}
          className={`px-3 py-1.5 rounded font-bold transition-all ${
            activeTab === 'REPORT' ? 'bg-sky-600 text-white' : 'bg-slate-950 text-slate-400 hover:text-slate-200'
          }`}
        >
          Generated Research Report
        </button>
      </div>

      {activeTab === 'CHARTS' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Hourly Volume Chart */}
          <div className="bg-slate-950 border border-slate-800 p-4 rounded space-y-3">
            <div className="font-bold text-slate-200 uppercase border-b border-slate-800 pb-2">
              Hourly Transaction Volume (Online vs Offline SE)
            </div>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={analytics.hourlyVolumeProfile}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                  <XAxis dataKey="hour" stroke="#64748b" fontSize={10} />
                  <YAxis stroke="#64748b" fontSize={10} />
                  <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '11px' }} />
                  <Legend wrapperStyle={{ fontSize: '11px' }} />
                  <Bar dataKey="online" fill="#38bdf8" name="Online Central Settlement" />
                  <Bar dataKey="offline" fill="#fbbf24" name="Offline Hardware SE Tap" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Latency Distribution */}
          <div className="bg-slate-950 border border-slate-800 p-4 rounded space-y-3">
            <div className="font-bold text-slate-200 uppercase border-b border-slate-800 pb-2">
              Settlement Finality Latency Distribution (ms)
            </div>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={analytics.latencyDistribution}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                  <XAxis dataKey="bucketMs" stroke="#64748b" fontSize={10} />
                  <YAxis stroke="#64748b" fontSize={10} />
                  <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '11px' }} />
                  <Bar dataKey="count" fill="#34d399" name="Transaction Count" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'NETWORK' && (
        <div className="bg-slate-950 border border-slate-800 p-4 rounded space-y-4">
          <div className="font-bold text-slate-200 uppercase border-b border-slate-800 pb-2">
            Eurosystem Payment Network Topology Graph Data
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <div className="font-bold text-sky-400 mb-2">Network Nodes ({networkData.nodes.length})</div>
              <div className="bg-slate-900 p-3 rounded h-60 overflow-y-auto space-y-1">
                {networkData.nodes.map((node) => (
                  <div key={node.id} className="flex justify-between border-b border-slate-800/80 py-1">
                    <span className="text-slate-200 font-bold">{node.name}</span>
                    <span className="text-slate-400 text-[10px]">{node.type}</span>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <div className="font-bold text-indigo-400 mb-2">Network Links & Routing Flow ({networkData.links.length})</div>
              <div className="bg-slate-900 p-3 rounded h-60 overflow-y-auto space-y-1">
                {networkData.links.map((link, idx) => (
                  <div key={idx} className="flex justify-between border-b border-slate-800/80 py-1 text-[11px]">
                    <span className="text-slate-300">
                      {link.source} → {link.target}
                    </span>
                    <span className="text-emerald-400 font-bold">€{link.value}k/s</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'DEPOSIT_MIGRATION' && (
        <div className="bg-slate-950 border border-slate-800 p-4 rounded space-y-4">
          <div className="font-bold text-slate-200 uppercase border-b border-slate-800 pb-2">
            Commercial Bank Deposit Migration Sensitivity Analysis Model
          </div>
          <p className="text-slate-400 text-xs">
            Evaluates the hypothetical outflow of commercial retail bank deposits into central bank digital euro liabilities under varying holding limits.
          </p>

          <table className="w-full text-left font-mono text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px] bg-slate-900">
                <th className="py-2 px-3">Holding Ceiling (€)</th>
                <th className="py-2 px-3 text-right">Est. Commercial Outflow (€ Billions)</th>
                <th className="py-2 px-3 text-right">Bank Liquidity Impact Rating</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {analytics.depositMigrationModel.map((row, idx) => (
                <tr key={idx} className="hover:bg-slate-900">
                  <td className="py-2.5 px-3 font-bold text-sky-400">€{row.holdingLimitEur.toLocaleString()}</td>
                  <td className="py-2.5 px-3 text-right text-emerald-400 font-bold">€{row.estimatedDepositShiftBillions} Billion</td>
                  <td className="py-2.5 px-3 text-right font-bold text-amber-400">{row.bankLiquidityImpact}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {activeTab === 'REPORT' && (
        <div className="bg-slate-950 border border-slate-800 p-4 rounded space-y-3">
          <div className="flex justify-between items-center border-b border-slate-800 pb-2">
            <span className="font-bold text-slate-200 uppercase">Generated Executive Research Report</span>
            <button
              onClick={handleDownloadReport}
              className="bg-sky-600 hover:bg-sky-500 text-white font-bold px-3 py-1 rounded text-[11px]"
            >
              DOWNLOAD FILE
            </button>
          </div>
          <pre className="bg-slate-900 p-4 rounded text-slate-200 font-mono text-[11px] whitespace-pre-wrap overflow-x-auto leading-relaxed border border-slate-800">
            {reportText}
          </pre>
        </div>
      )}
    </div>
  );
};
