import React, { useState } from 'react';
import { AlertTriangle, ShieldAlert, CheckCircle, XCircle, Search, Filter } from 'lucide-react';
import { RiskAlert } from '../types/eurocore';

interface ComplianceViewProps {
  alerts: RiskAlert[];
  onUpdateAlertStatus: (alertId: string, status: RiskAlert['status'], note?: string) => void;
}

export const ComplianceView: React.FC<ComplianceViewProps> = ({ alerts, onUpdateAlertStatus }) => {
  const [selectedAlertId, setSelectedAlertId] = useState<string | null>(alerts[0]?.id || null);
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [analystNote, setAnalystNote] = useState<string>('');

  const filteredAlerts = alerts.filter((a) => (filterStatus === 'ALL' ? true : a.status === filterStatus));
  const selectedAlert = alerts.find((a) => a.id === selectedAlertId);

  const handleActionClick = (status: RiskAlert['status']) => {
    if (!selectedAlertId) return;
    onUpdateAlertStatus(selectedAlertId, status, analystNote);
    setAnalystNote('');
  };

  return (
    <div className="p-4 md:p-6 bg-slate-900 text-slate-100 min-h-[calc(100vh-80px)] font-mono text-xs space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-slate-800 pb-4 gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <AlertTriangle className="w-6 h-6 text-amber-400" />
            <h1 className="text-xl font-bold tracking-tight">AML / CFT & FRAUD COMPLIANCE WORKSTATION</h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Real-Time Synthetic Transaction Stream Monitoring • Rules 001–005 • Risk Case Triage & Regulatory SAR
          </p>
        </div>

        {/* Filter Status */}
        <div className="flex items-center space-x-2">
          <Filter className="w-4 h-4 text-slate-400" />
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="bg-slate-950 border border-slate-700 text-slate-100 p-2 rounded"
          >
            <option value="ALL">All Statuses ({alerts.length})</option>
            <option value="NEW">New Alerts</option>
            <option value="UNDER_REVIEW">Under Review</option>
            <option value="ESCALATED">Escalated</option>
            <option value="DISMISSED">Dismissed</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left List: Risk Alerts Stream */}
        <div className="lg:col-span-2 bg-slate-950 border border-slate-800 rounded p-4 space-y-3">
          <div className="font-bold text-slate-200 border-b border-slate-800 pb-2">
            Risk Alerts Feed ({filteredAlerts.length})
          </div>

          <div className="space-y-2">
            {filteredAlerts.map((alert) => (
              <div
                key={alert.id}
                onClick={() => setSelectedAlertId(alert.id)}
                className={`p-3 rounded border cursor-pointer transition-all ${
                  selectedAlertId === alert.id
                    ? 'bg-slate-900 border-amber-500 text-slate-100'
                    : 'bg-slate-900/60 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="font-bold text-amber-400">{alert.ruleId}</span>
                    <span className="font-semibold text-slate-200">{alert.ruleName}</span>
                  </div>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                      alert.severity === 'CRITICAL'
                        ? 'bg-rose-950 text-rose-400 border border-rose-800'
                        : alert.severity === 'HIGH'
                        ? 'bg-amber-950 text-amber-400 border border-amber-800'
                        : 'bg-sky-950 text-sky-400 border border-sky-800'
                    }`}
                  >
                    {alert.severity} (SCORE: {alert.riskScore})
                  </span>
                </div>

                <div className="mt-2 text-[11px] text-slate-400 line-clamp-1">{alert.evidence}</div>

                <div className="mt-2 flex items-center justify-between text-[10px] text-slate-500 border-t border-slate-800/80 pt-1.5">
                  <span>Subject: {alert.subjectWalletId}</span>
                  <span>Status: {alert.status}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Detail & Action Triage Box */}
        <div className="space-y-4">
          {selectedAlert ? (
            <div className="bg-slate-950 border border-slate-800 rounded p-4 space-y-4">
              <div className="border-b border-slate-800 pb-3">
                <div className="text-amber-400 font-bold text-sm">{selectedAlert.ruleName}</div>
                <div className="text-[11px] text-slate-400">Case ID: {selectedAlert.id}</div>
              </div>

              <div className="space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-400">Rule ID:</span>
                  <span className="text-slate-200">{selectedAlert.ruleId}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Severity Level:</span>
                  <span className="text-amber-400 font-bold">{selectedAlert.severity}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Calculated Risk Score:</span>
                  <span className="text-rose-400 font-bold">{selectedAlert.riskScore} / 100</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Subject Wallet ID:</span>
                  <span className="text-sky-400">{selectedAlert.subjectWalletId}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Subject PSP:</span>
                  <span className="text-slate-200">{selectedAlert.subjectPspId}</span>
                </div>
              </div>

              <div className="bg-slate-900 p-3 rounded border border-slate-800 text-[11px] text-slate-300">
                <div className="font-bold text-slate-400 mb-1">Evidence Trail:</div>
                <div>{selectedAlert.evidence}</div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Compliance Analyst Decision Memo:</label>
                <textarea
                  value={analystNote}
                  onChange={(e) => setAnalystNote(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 text-slate-100 p-2 rounded text-xs h-20"
                  placeholder="Enter notes for audit trail..."
                ></textarea>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => handleActionClick('DISMISSED')}
                  className="bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold py-2 rounded text-xs"
                >
                  DISMISS ALERT
                </button>
                <button
                  onClick={() => handleActionClick('UNDER_REVIEW')}
                  className="bg-sky-600 hover:bg-sky-500 text-white font-bold py-2 rounded text-xs"
                >
                  SET UNDER REVIEW
                </button>
                <button
                  onClick={() => handleActionClick('ESCALATED')}
                  className="col-span-2 bg-rose-600 hover:bg-rose-500 text-white font-bold py-2 rounded text-xs"
                >
                  ESCALATE & FILE SUSPICIOUS ACTIVITY REPORT (SAR)
                </button>
              </div>
            </div>
          ) : (
            <div className="bg-slate-950 border border-slate-800 rounded p-6 text-center text-slate-500 italic">
              Select a risk alert from the list to inspect evidence and execute compliance triage.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
