import React from 'react';
import { PlayCircle, Pause, RefreshCw, FastForward, Activity, AlertTriangle, Play } from 'lucide-react';
import { ScenarioDefinition, ScenarioRunState } from '../types/eurocore';
import { PRECONFIGURED_SCENARIOS } from '../engine/digitalTwin';
import { MonetaryEngine } from '../engine/monetary';

interface DigitalTwinViewProps {
  activeScenario: ScenarioDefinition;
  runState: ScenarioRunState;
  onSelectScenario: (scenarioId: string) => void;
  onControlAction: (action: 'start' | 'pause' | 'reset' | 'tick', speed?: number) => void;
}

export const DigitalTwinView: React.FC<DigitalTwinViewProps> = ({
  activeScenario,
  runState,
  onSelectScenario,
  onControlAction,
}) => {
  return (
    <div className="p-4 md:p-6 bg-slate-900 text-slate-100 min-h-[calc(100vh-80px)] font-mono text-xs space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-slate-800 pb-4 gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <PlayCircle className="w-6 h-6 text-amber-400" />
            <h1 className="text-xl font-bold tracking-tight">DIGITAL TWIN SCENARIO LABORATORY</h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Eurosystem Agent-Based Stress Test Environment • 10 Preconfigured Scenarios • Outage & Fraud Injections
          </p>
        </div>

        {/* Controls Bar */}
        <div className="flex items-center space-x-2">
          {runState.isRunning && !runState.isPaused ? (
            <button
              onClick={() => onControlAction('pause')}
              className="bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold px-3 py-2 rounded flex items-center space-x-1.5"
            >
              <Pause className="w-4 h-4" />
              <span>PAUSE</span>
            </button>
          ) : (
            <button
              onClick={() => onControlAction('start')}
              className="bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold px-3 py-2 rounded flex items-center space-x-1.5"
            >
              <Play className="w-4 h-4" />
              <span>START SIMULATION</span>
            </button>
          )}

          <button
            onClick={() => onControlAction('tick')}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold px-3 py-2 rounded"
          >
            STEP (+1s)
          </button>

          <button
            onClick={() => onControlAction('reset')}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold px-3 py-2 rounded"
          >
            RESET
          </button>

          {/* Speed Multiplier */}
          <div className="flex items-center space-x-1 bg-slate-950 border border-slate-800 px-2 py-1 rounded">
            <span className="text-slate-400 text-[10px]">SPEED:</span>
            {[1, 2, 5, 10].map((s) => (
              <button
                key={s}
                onClick={() => onControlAction('start', s)}
                className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                  runState.speedMultiplier === s ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {s}x
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Live Simulation Run State Telemetry */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <div className="bg-slate-950 border border-slate-800 p-3.5 rounded">
          <div className="text-[10px] text-slate-400 uppercase">Elapsed Simulation Time</div>
          <div className="text-lg font-bold text-sky-400 mt-1">{runState.elapsedSeconds}s / {activeScenario.durationSeconds}s</div>
        </div>

        <div className="bg-slate-950 border border-slate-800 p-3.5 rounded">
          <div className="text-[10px] text-slate-400 uppercase">Processed Transactions</div>
          <div className="text-lg font-bold text-slate-100 mt-1">{runState.processedTransactions.toLocaleString()}</div>
        </div>

        <div className="bg-slate-950 border border-slate-800 p-3.5 rounded">
          <div className="text-[10px] text-slate-400 uppercase">Settled vs Rejected</div>
          <div className="text-lg font-bold text-emerald-400 mt-1">
            {runState.settledTransactions.toLocaleString()} <span className="text-xs text-rose-400">({runState.rejectedTransactions})</span>
          </div>
        </div>

        <div className="bg-slate-950 border border-slate-800 p-3.5 rounded">
          <div className="text-[10px] text-slate-400 uppercase">Simulated Volume Settled</div>
          <div className="text-lg font-bold text-amber-400 mt-1">{MonetaryEngine.formatEuro(runState.totalVolume)}</div>
        </div>

        <div className="bg-slate-950 border border-slate-800 p-3.5 rounded">
          <div className="text-[10px] text-slate-400 uppercase">Mean Latency</div>
          <div className="text-lg font-bold text-cyan-400 mt-1">{runState.settlementLatencyMs} ms</div>
        </div>
      </div>

      {/* Active Scenario Card Details */}
      <div className="bg-slate-950 border border-amber-800 p-4 rounded space-y-3">
        <div className="flex items-center justify-between border-b border-amber-900/60 pb-2">
          <div className="flex items-center space-x-2">
            <span className="bg-amber-950 text-amber-400 border border-amber-800 font-bold px-2 py-0.5 rounded text-[10px]">
              {activeScenario.id}
            </span>
            <span className="text-sm font-bold text-slate-100">{activeScenario.title}</span>
          </div>
          <span className="text-[10px] text-slate-400">{activeScenario.category}</span>
        </div>

        <div className="text-xs text-slate-300">{activeScenario.description}</div>

        <div className="flex flex-wrap gap-2 pt-2 border-t border-slate-900">
          {activeScenario.specialConditions.map((cond, idx) => (
            <span key={idx} className="bg-slate-900 text-amber-300 border border-slate-800 px-2 py-1 rounded text-[10px]">
              • {cond}
            </span>
          ))}
        </div>
      </div>

      {/* Scenario Selection Grid (10 Scenarios) */}
      <div className="space-y-3">
        <div className="font-bold text-slate-200 uppercase text-xs">Available Preconfigured Eurosystem Scenarios</div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {PRECONFIGURED_SCENARIOS.map((scenario) => (
            <div
              key={scenario.id}
              onClick={() => onSelectScenario(scenario.id)}
              className={`p-3.5 rounded border cursor-pointer transition-all ${
                activeScenario.id === scenario.id
                  ? 'bg-slate-900 border-amber-500 text-slate-100 shadow-md'
                  : 'bg-slate-950 border-slate-800 hover:border-slate-700 text-slate-300'
              }`}
            >
              <div className="flex justify-between items-center text-xs">
                <span className="font-bold text-amber-400">{scenario.id}</span>
                <span className="bg-slate-900 text-slate-400 px-1.5 py-0.5 rounded text-[10px]">
                  {scenario.category}
                </span>
              </div>

              <div className="font-bold text-slate-200 mt-2 text-xs line-clamp-1">{scenario.title}</div>
              <div className="text-[11px] text-slate-400 mt-1 line-clamp-2">{scenario.description}</div>

              <div className="mt-3 flex justify-between text-[10px] text-slate-500 border-t border-slate-900 pt-2">
                <span>Wallets: {scenario.walletCount.toLocaleString()}</span>
                <span>Target TPS: {scenario.tpsTarget}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
