import React, { useState } from 'react';
import { Eye, Shield, Lock, CheckCircle, EyeOff, UserCheck } from 'lucide-react';
import { EUROCORE_PRIVACY_MATRIX, PrivacyEngine } from '../engine/privacy';
import { PaymentOrder, UserRole } from '../types/eurocore';

interface PrivacyAuditViewProps {
  samplePayment?: PaymentOrder;
}

export const PrivacyAuditView: React.FC<PrivacyAuditViewProps> = ({ samplePayment }) => {
  const [selectedRole, setSelectedRole] = useState<UserRole>('CONSUMER');

  const defaultPayment: PaymentOrder = samplePayment || {
    id: 'PAY-2030-99812',
    idempotencyKey: 'IDEM-99812-ECB',
    correlationId: 'CORR-99812-ECB',
    type: 'P2P',
    payerWalletId: 'W-USR-DE-01',
    payerAlias: 'maria.schmidt@eurocore.de',
    payerPspId: 'PSP-DE-DB',
    payeeWalletId: 'W-USR-FR-02',
    payeeAlias: 'jean.dupont@eurocore.fr',
    payeePspId: 'PSP-FR-BNP',
    amount: 3500, // €35.00
    currency: 'EUR',
    purpose: 'Shared dinner payment',
    reference: 'REF-DINNER-35',
    status: 'SETTLED',
    isOffline: false,
    createdAt: new Date().toISOString(),
    settledAt: new Date().toISOString(),
    auditTrail: [],
  };

  const redactedPayment = PrivacyEngine.redactPaymentForRole(defaultPayment, selectedRole);

  return (
    <div className="p-4 md:p-6 bg-slate-900 text-slate-100 min-h-[calc(100vh-80px)] font-mono text-xs space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-slate-800 pb-4 gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <Eye className="w-6 h-6 text-sky-400" />
            <h1 className="text-xl font-bold tracking-tight">PRIVACY MATRIX & FIELD-LEVEL REDACTION INSPECTOR</h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Zero-Knowledge Pseudonymity Rules • Field-Level Access Control Matrix across Eurosystem Roles
          </p>
        </div>

        {/* Role Selector for Redaction Tester */}
        <div className="flex items-center space-x-2">
          <span className="text-slate-400 font-bold">Inspect As Role:</span>
          <select
            value={selectedRole}
            onChange={(e) => setSelectedRole(e.target.value as UserRole)}
            className="bg-slate-950 border border-slate-700 text-slate-100 p-2 rounded font-bold"
          >
            <option value="CONSUMER">Consumer User</option>
            <option value="MERCHANT_OPERATOR">Merchant Operator</option>
            <option value="PSP_OPERATOR">PSP Operator</option>
            <option value="EUROSYSTEM_OPERATOR">Eurosystem Operator (Central Bank)</option>
            <option value="COMPLIANCE_ANALYST">Compliance Analyst</option>
            <option value="AUDITOR">Auditor</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Privacy Matrix Table */}
        <div className="bg-slate-950 border border-slate-800 rounded p-4 space-y-3">
          <div className="font-bold text-slate-200 uppercase border-b border-slate-800 pb-2 flex items-center space-x-2">
            <Shield className="w-4 h-4 text-sky-400" />
            <span>Eurosystem Regulatory Privacy Access Control Matrix</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left font-mono text-[11px] border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 uppercase text-[9px] bg-slate-900">
                  <th className="py-2 px-2">Data Field</th>
                  <th className="py-2 px-1 text-center">Consumer</th>
                  <th className="py-2 px-1 text-center">Merchant</th>
                  <th className="py-2 px-1 text-center">PSP</th>
                  <th className="py-2 px-1 text-center">Eurosystem</th>
                  <th className="py-2 px-1 text-center">Auditor</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {EUROCORE_PRIVACY_MATRIX.map((row, idx) => (
                  <tr key={idx} className="hover:bg-slate-900/60">
                    <td className="py-2 px-2 font-bold text-slate-200">{row.field}</td>
                    <td className="py-2 px-1 text-center text-emerald-400">{row.consumer}</td>
                    <td className="py-2 px-1 text-center text-sky-400">{row.merchant}</td>
                    <td className="py-2 px-1 text-center text-indigo-400">{row.psp}</td>
                    <td className="py-2 px-1 text-center text-amber-400">{row.eurosystem}</td>
                    <td className="py-2 px-1 text-center text-rose-400">{row.auditor}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Live Redaction Output Viewer */}
        <div className="bg-slate-950 border border-slate-800 rounded p-4 space-y-3">
          <div className="font-bold text-slate-200 uppercase border-b border-slate-800 pb-2 flex items-center justify-between">
            <span>Live Field Redaction Inspector ({selectedRole})</span>
            <span className="bg-sky-950 text-sky-400 border border-sky-800 px-2 py-0.5 rounded text-[10px]">
              ROLE_FILTER_ACTIVE
            </span>
          </div>

          <p className="text-slate-400 text-[11px]">
            This JSON represents the exact payload visible to a <span className="text-sky-400 font-bold">{selectedRole}</span>. Confidential consumer identities and memos are masked according to Eurosystem privacy regulations.
          </p>

          <pre className="bg-slate-900 p-4 rounded text-slate-200 font-mono text-[11px] overflow-x-auto border border-slate-800 leading-relaxed">
            {JSON.stringify(redactedPayment, null, 2)}
          </pre>
        </div>
      </div>
    </div>
  );
};
