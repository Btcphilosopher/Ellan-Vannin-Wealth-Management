import React, { useState } from 'react';
import { Store, QrCode, Smartphone, CheckCircle, RefreshCw, AlertCircle } from 'lucide-react';
import { MerchantOutlet, DigitalWallet, PaymentReceipt } from '../types/eurocore';
import { MonetaryEngine } from '../engine/monetary';

interface MerchantTerminalViewProps {
  merchants: MerchantOutlet[];
  wallets: DigitalWallet[];
  onExecuteMerchantPayment: (
    payerWalletId: string,
    merchantId: string,
    amountEuro: number,
    reference: string
  ) => { success: boolean; receipt?: PaymentReceipt; error?: string };
}

export const MerchantTerminalView: React.FC<MerchantTerminalViewProps> = ({
  merchants,
  wallets,
  onExecuteMerchantPayment,
}) => {
  const [selectedMerchantId, setSelectedMerchantId] = useState<string>(merchants[0]?.id || 'MCH-BER-01');
  const [selectedPayerWalletId, setSelectedPayerWalletId] = useState<string>(wallets[0]?.id || 'W-USR-DE-01');
  const [chargeAmountStr, setChargeAmountStr] = useState<string>('18.50');
  const [invoiceRef, setInvoiceRef] = useState<string>(`INV-${Math.floor(100000 + Math.random() * 900000)}`);
  const [lastReceipt, setLastReceipt] = useState<PaymentReceipt | null>(null);
  const [paymentError, setPaymentError] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  const selectedMerchant = merchants.find((m) => m.id === selectedMerchantId) || merchants[0];

  const handleTerminalCharge = (e: React.FormEvent) => {
    e.preventDefault();
    setPaymentError(null);
    setLastReceipt(null);
    setIsProcessing(true);

    const amountEuro = parseFloat(chargeAmountStr);
    if (isNaN(amountEuro) || amountEuro <= 0) {
      setPaymentError('Invalid charge amount');
      setIsProcessing(false);
      return;
    }

    setTimeout(() => {
      const result = onExecuteMerchantPayment(selectedPayerWalletId, selectedMerchantId, amountEuro, invoiceRef);
      setIsProcessing(false);
      if (result.success && result.receipt) {
        setLastReceipt(result.receipt);
        setInvoiceRef(`INV-${Math.floor(100000 + Math.random() * 900000)}`);
      } else {
        setPaymentError(result.error || 'Payment processing failed');
      }
    }, 600);
  };

  return (
    <div className="p-4 md:p-6 bg-slate-900 text-slate-100 min-h-[calc(100vh-80px)] font-sans space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-slate-800 pb-4 gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <Store className="w-6 h-6 text-sky-400" />
            <h1 className="text-xl font-bold font-mono tracking-tight">MERCHANT ACQUIRING & SOFTPOS TERMINAL</h1>
          </div>
          <p className="text-xs text-slate-400 mt-1 font-mono">
            Digital Euro Point-of-Sale Acceptance • Real-Time Zero-Fee Merchant Settlement
          </p>
        </div>

        {/* Merchant Outlet Switcher */}
        <div className="flex items-center space-x-2 font-mono text-xs">
          <span className="text-slate-400">Outlet:</span>
          <select
            value={selectedMerchantId}
            onChange={(e) => setSelectedMerchantId(e.target.value)}
            className="bg-slate-950 border border-slate-700 text-slate-100 p-2 rounded focus:outline-none focus:border-sky-500"
          >
            {merchants.map((m) => (
              <option key={m.id} value={m.id}>
                {m.brandName} ({m.outletLocation})
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 font-mono">
        {/* SoftPOS Terminal Interface */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-slate-950 border border-slate-800 rounded p-6 shadow-md max-w-xl mx-auto space-y-6">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div>
                <div className="text-lg font-bold text-slate-100">{selectedMerchant?.brandName}</div>
                <div className="text-xs text-slate-400">{selectedMerchant?.outletLocation}</div>
              </div>
              <div className="bg-sky-950 text-sky-400 border border-sky-800 px-2.5 py-1 rounded text-xs font-bold flex items-center space-x-1.5">
                <Smartphone className="w-3.5 h-3.5" />
                <span>SoftPOS EC-TERMINAL</span>
              </div>
            </div>

            <form onSubmit={handleTerminalCharge} className="space-y-5 text-xs">
              <div>
                <label className="block text-slate-400 mb-1">Enter Transaction Amount (€ EUR):</label>
                <div className="relative">
                  <span className="absolute left-3 top-3 text-lg text-slate-400 font-bold">€</span>
                  <input
                    type="number"
                    step="0.01"
                    value={chargeAmountStr}
                    onChange={(e) => setChargeAmountStr(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 text-slate-100 pl-8 p-3 rounded text-2xl font-bold focus:outline-none focus:border-sky-500"
                    placeholder="0.00"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Simulated Customer NFC Payer Wallet:</label>
                <select
                  value={selectedPayerWalletId}
                  onChange={(e) => setSelectedPayerWalletId(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 text-slate-100 p-2.5 rounded focus:outline-none focus:border-sky-500 text-xs"
                >
                  {wallets.map((w) => (
                    <option key={w.id} value={w.id}>
                      {w.alias} — Balance: {MonetaryEngine.formatEuro(w.onlineBalance)}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Merchant Invoice Reference:</label>
                <input
                  type="text"
                  value={invoiceRef}
                  onChange={(e) => setInvoiceRef(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 text-slate-100 p-2 rounded"
                />
              </div>

              <button
                type="submit"
                disabled={isProcessing}
                className="w-full bg-sky-600 hover:bg-sky-500 text-white font-bold py-3.5 px-4 rounded transition-all text-sm flex items-center justify-center space-x-2 shadow-lg disabled:opacity-50"
              >
                {isProcessing ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>EXECUTING CENTRAL SETTLEMENT...</span>
                  </>
                ) : (
                  <>
                    <QrCode className="w-4 h-4" />
                    <span>INITIATE SOFTPOS NFC / QR PAYMENT (€{parseFloat(chargeAmountStr || '0').toFixed(2)})</span>
                  </>
                )}
              </button>
            </form>

            {paymentError && (
              <div className="p-3 bg-rose-950/80 border border-rose-800 text-rose-300 rounded text-xs flex items-center space-x-2">
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                <span>{paymentError}</span>
              </div>
            )}

            {lastReceipt && (
              <div className="bg-emerald-950/60 border border-emerald-800 p-4 rounded text-xs space-y-2">
                <div className="flex items-center space-x-2 text-emerald-400 font-bold border-b border-emerald-900 pb-2">
                  <CheckCircle className="w-4 h-4" />
                  <span>PAYMENT SETTLED INSTANTLY IN CENTRAL LEDGER</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>Receipt ID:</span>
                  <span className="font-bold text-sky-400">{lastReceipt.id}</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>Payer:</span>
                  <span>{lastReceipt.payerAlias}</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>Amount Settled:</span>
                  <span className="font-bold text-emerald-400">
                    {MonetaryEngine.formatEuro(lastReceipt.amount)}
                  </span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>Audit Hash:</span>
                  <span className="font-mono text-[10px] text-slate-400 truncate max-w-[200px]">
                    {lastReceipt.settlementConfirmationHash}
                  </span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Outlet Summary & Turnover */}
        <div className="space-y-6">
          <div className="bg-slate-950 border border-slate-800 rounded p-4 space-y-4">
            <div className="border-b border-slate-800 pb-2">
              <div className="text-xs text-slate-400 uppercase">Today's Total Settled Turnover</div>
              <div className="text-2xl font-bold text-emerald-400 mt-1">
                {MonetaryEngine.formatEuro(selectedMerchant?.dailyTurnover || 0)}
              </div>
              <div className="text-[10px] text-slate-500 mt-1">Zero-fee Instant Central Settlement</div>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between text-slate-400">
                <span>Acquiring PSP:</span>
                <span className="text-sky-400 font-bold">{selectedMerchant?.acquiringPspId}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Merchant Category (MCC):</span>
                <span className="text-slate-200">{selectedMerchant?.categoryCode} (Retail/Food)</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Active SoftPOS Terminals:</span>
                <span className="text-slate-200">{selectedMerchant?.terminalCount} Terminals</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
