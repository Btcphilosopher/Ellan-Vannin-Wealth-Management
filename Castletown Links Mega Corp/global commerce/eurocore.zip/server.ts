import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { EurocoreStore } from './src/engine/store';
import { AnalyticsEngine } from './src/engine/analytics';
import { PrivacyEngine } from './src/engine/privacy';
import { UserRole } from './src/types/eurocore';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Initialize Eurocore Store Engine
  const store = new EurocoreStore();

  // ==========================================
  // REST API ROUTES (/api/v1)
  // ==========================================

  // System Health & Observability
  app.get('/api/v1/system/health', (req, res) => {
    res.json({
      status: 'HEALTHY',
      designation: 'EUROCORE — INDEPENDENT DIGITAL EURO INFRASTRUCTURE SIMULATOR',
      timestamp: new Date().toISOString(),
      components: {
        settlementEngine: 'OPERATIONAL',
        doubleEntryLedger: 'BALANCED_OK',
        issuanceEngine: 'OPERATIONAL',
        offlineNfcEmulator: 'OPERATIONAL',
        policyEngine: 'OPERATIONAL',
        digitalTwinLab: store.digitalTwin.getState().isRunning ? 'SCENARIO_RUNNING' : 'STANDBY',
      },
    });
  });

  // System Metrics
  app.get('/api/v1/system/metrics', (req, res) => {
    const totalIssued = store.ncbs.reduce((sum, n) => sum + n.issuedBalance, 0);
    const totalRedeemed = store.issuance.getRedemptionHistory().reduce((sum, r) => sum + r.amount, 0);
    const circulating = store.getTotalCirculatingSupply();

    const analytics = AnalyticsEngine.getSystemAnalytics(totalIssued, totalRedeemed, circulating, 38500000, 4089000);
    res.json(analytics);
  });

  // Eurosystem National Central Banks
  app.get('/api/v1/eurosystem/ncbs', (req, res) => {
    res.json(store.ncbs);
  });

  // Payment Service Providers
  app.get('/api/v1/psps', (req, res) => {
    res.json(store.psps);
  });

  // Wallets
  app.get('/api/v1/wallets', (req, res) => {
    res.json(store.wallets);
  });

  app.get('/api/v1/wallets/:id', (req, res) => {
    const wallet = store.wallets.find((w) => w.id === req.params.id);
    if (!wallet) {
      return res.status(404).json({ error: 'Wallet not found' });
    }
    const offW = store.offline.getOfflineWallet(wallet.id);
    res.json({ ...wallet, offlineWallet: offW });
  });

  // Merchants
  app.get('/api/v1/merchants', (req, res) => {
    res.json(store.merchants);
  });

  // Submit Online P2P Payment
  app.post('/api/v1/payments/p2p', (req, res) => {
    const { payerWalletId, payeeAlias, amountMinor, purpose, reference, idempotencyKey } = req.body;

    const payerWallet = store.wallets.find((w) => w.id === payerWalletId);
    if (!payerWallet) {
      return res.status(400).json({ error: 'Payer wallet not found' });
    }

    const payeeWallet = store.wallets.find((w) => w.alias.toLowerCase() === (payeeAlias || '').toLowerCase());
    if (!payeeWallet) {
      return res.status(400).json({ error: `Destination user alias '${payeeAlias}' not found in Eurosystem registry.` });
    }

    // Policy Check
    const policyResult = store.policy.evaluateOnlinePayment(
      amountMinor,
      payeeWallet.onlineBalance
    );

    if (!policyResult.isAllowed) {
      return res.status(422).json({
        error: 'PAYMENT_REJECTED',
        rejectionCode: policyResult.rejectionCode,
        policyId: policyResult.policyId,
        message: policyResult.humanMessage,
      });
    }

    // Submit to Settlement Engine
    const result = store.settlement.submitPayment(
      'P2P',
      amountMinor,
      payerWallet,
      payeeWallet,
      undefined,
      purpose || 'P2P Digital Euro Transfer',
      reference || `REF-${Math.floor(Math.random() * 900000 + 100000)}`,
      idempotencyKey || `IDEM-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`
    );

    if (!result.success) {
      return res.status(400).json({ error: result.rejectionReason });
    }

    // Risk Check Evaluation
    if (result.payment) {
      store.compliance.evaluatePaymentForRisk(result.payment, 3, 40000);
    }

    res.json({ payment: result.payment, receipt: result.receipt });
  });

  // Submit Merchant Payment (P2B / SoftPOS)
  app.post('/api/v1/payments/merchant', (req, res) => {
    const { payerWalletId, merchantId, amountMinor, reference, idempotencyKey } = req.body;

    const payerWallet = store.wallets.find((w) => w.id === payerWalletId);
    if (!payerWallet) {
      return res.status(400).json({ error: 'Payer wallet not found' });
    }

    const merchant = store.merchants.find((m) => m.id === merchantId);
    if (!merchant) {
      return res.status(400).json({ error: 'Merchant outlet not found' });
    }

    // Policy Check
    const policyResult = store.policy.evaluateOnlinePayment(amountMinor, 0);
    if (!policyResult.isAllowed) {
      return res.status(422).json({
        error: 'PAYMENT_REJECTED',
        rejectionCode: policyResult.rejectionCode,
        policyId: policyResult.policyId,
        message: policyResult.humanMessage,
      });
    }

    const result = store.settlement.submitPayment(
      'P2B',
      amountMinor,
      payerWallet,
      undefined,
      merchant,
      `Merchant Purchase at ${merchant.brandName}`,
      reference || `INV-${Math.floor(Math.random() * 900000 + 100000)}`,
      idempotencyKey || `IDEM-MERCH-${Date.now()}`
    );

    if (!result.success) {
      return res.status(400).json({ error: result.rejectionReason });
    }

    res.json({ payment: result.payment, receipt: result.receipt });
  });

  // Payment History
  app.get('/api/v1/payments/history', (req, res) => {
    const role = (req.query.role as UserRole) || 'CONSUMER';
    const rawPayments = store.settlement.getAllPayments(50);
    const redactedPayments = rawPayments.map((p) => PrivacyEngine.redactPaymentForRole(p, role));
    res.json(redactedPayments);
  });

  // Issuance Requests
  app.post('/api/v1/issuance/requests', (req, res) => {
    const { ncbCode, pspId, amountMinor, collateralRef } = req.body;
    const psp = store.psps.find((p) => p.id === pspId);
    if (!psp) {
      return res.status(400).json({ error: 'PSP not found' });
    }

    const result = store.issuance.executeIssuance(ncbCode || 'DE', psp, amountMinor, collateralRef || 'ECB-COLLATERAL-TEST');
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }
    res.json(result.request);
  });

  // Redemption Requests
  app.post('/api/v1/redemption/requests', (req, res) => {
    const { pspId, amountMinor, commercialBankBic } = req.body;
    const psp = store.psps.find((p) => p.id === pspId);
    if (!psp) {
      return res.status(400).json({ error: 'PSP not found' });
    }

    const result = store.redemption.executeRedemption(psp, amountMinor, commercialBankBic || psp.bic);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }
    res.json(result.request);
  });

  // Offline NFC Payment Proximity Emulation
  app.post('/api/v1/offline/tap-payment', (req, res) => {
    const { payerWalletId, payeeWalletId, amountMinor } = req.body;

    const sessionState = store.offline.executeNfcProximityPayment(payerWalletId, payeeWalletId, amountMinor);
    res.json(sessionState);
  });

  // Offline Synchronise Queue
  app.post('/api/v1/offline/synchronise', (req, res) => {
    const syncResult = store.offline.synchroniseOfflineQueue();
    res.json(syncResult);
  });

  // Risk & Compliance Alerts
  app.get('/api/v1/risk/alerts', (req, res) => {
    res.json(store.compliance.getAllAlerts());
  });

  app.post('/api/v1/risk/alerts/:id/status', (req, res) => {
    const { status, note } = req.body;
    const ok = store.compliance.updateAlertStatus(req.params.id, status, note);
    res.json({ success: ok });
  });

  // Policy Configurations
  app.get('/api/v1/policies', (req, res) => {
    res.json(store.policy.getConfig());
  });

  app.put('/api/v1/policies', (req, res) => {
    const updated = store.policy.updateConfig(req.body);
    res.json(updated);
  });

  // Digital Twin Scenarios
  app.get('/api/v1/scenarios', (req, res) => {
    res.json({
      activeScenario: store.digitalTwin.getActiveScenario(),
      runState: store.digitalTwin.getState(),
    });
  });

  app.post('/api/v1/scenarios/select', (req, res) => {
    const { scenarioId } = req.body;
    const sc = store.digitalTwin.selectScenario(scenarioId);
    if (!sc) {
      return res.status(400).json({ error: 'Scenario ID not found' });
    }
    res.json({ activeScenario: sc, runState: store.digitalTwin.getState() });
  });

  app.post('/api/v1/scenarios/control', (req, res) => {
    const { action, speed } = req.body; // 'start', 'pause', 'reset', 'tick'
    if (action === 'start') store.digitalTwin.start();
    if (action === 'pause') store.digitalTwin.pause();
    if (action === 'reset') store.digitalTwin.resetState();
    if (action === 'tick') store.digitalTwin.tick(1);
    if (speed) store.digitalTwin.setSpeed(speed);

    res.json({ runState: store.digitalTwin.getState() });
  });

  // Ledger Journal Logs & Accounts
  app.get('/api/v1/ledger/accounts', (req, res) => {
    res.json(store.ledger.getAllAccounts());
  });

  app.get('/api/v1/ledger/transactions', (req, res) => {
    res.json(store.ledger.getTransactionHistory());
  });

  // ==========================================
  // VITE / STATIC MIDDLEWARE SETUP
  // ==========================================
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[EUROCORE] Infrastructure Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
