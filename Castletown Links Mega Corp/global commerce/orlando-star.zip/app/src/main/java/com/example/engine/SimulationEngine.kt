package com.example.engine

import androidx.compose.runtime.mutableStateOf
import com.example.domain.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlin.math.*

object SimulationEngine {
    // Current state of the entire simulation
    data class SimState(
        val timeScale: Int = 1, // 1x, 5x, 10x, 30x
        val isPaused: Boolean = false,
        val simulationTimeMinutes: Int = 420, // Starts at 7:00 AM (420 minutes from midnight)
        val weather: WeatherState = WeatherState.CLEAR,
        val activeScenario: Scenario = Scenario.NORMAL_MORNING,
        val stations: Map<String, Station> = emptyMap(),
        val routes: Map<String, Route> = emptyMap(),
        val vehicles: List<Vehicle> = emptyList(),
        val alerts: List<Alert> = emptyList(),
        val incidents: List<Incident> = emptyList(),
        val parkAndRides: List<ParkAndRide> = emptyMap<String, ParkAndRide>().values.toList(),
        val userProfile: UserProfile = UserProfile(),
        val selectedStationId: String? = null,
        val activeJourneyPlan: JourneyPlan? = null,
        val liveJourneyProgress: Float = 0f, // 0.0 to 1.0 of the current segment
        val liveJourneySegmentIndex: Int = 0,
        val tickets: List<Ticket> = emptyList(),
        val networkOnTimePercentage: Float = 96.8f,
        val totalActivePassengers: Int = 12450
    )

    private val _state = MutableStateFlow(SimState())
    val state: StateFlow<SimState> = _state.asStateFlow()

    init {
        resetSimulation()
    }

    fun resetSimulation() {
        val initialStations = createSyntheticStations()
        val initialRoutes = createSyntheticRoutes()
        val initialParkAndRides = createSyntheticParkAndRides()
        val initialTickets = listOf(
            Ticket("TKT-01", "Day Pass", TicketState.ACTIVE, 4.50, validityString = "Today", qrCodePayload = "ORLANDO_STAR_DAY_PASS_01"),
            Ticket("TKT-02", "Single Ride", TicketState.PURCHASED, 2.00, validityString = "Valid 90 mins", qrCodePayload = "ORLANDO_STAR_SINGLE_02"),
            Ticket("TKT-03", "Stored Value ($20)", TicketState.AVAILABLE, 20.00, validityString = "No Expiry", qrCodePayload = "ORLANDO_STAR_STORED_03")
        )

        _state.value = SimState(
            stations = initialStations,
            routes = initialRoutes,
            parkAndRides = initialParkAndRides,
            vehicles = createInitialVehicles(initialRoutes, initialStations),
            alerts = createInitialAlerts(),
            incidents = createInitialIncidents(),
            tickets = initialTickets
        )
        recalculateStats()
    }

    fun setTimeScale(scale: Int) {
        _state.update { it.copy(timeScale = scale) }
    }

    fun togglePause() {
        _state.update { it.copy(isPaused = !it.isPaused) }
    }

    fun stepMinute() {
        tick(1)
    }

    fun selectStation(stationId: String?) {
        _state.update { it.copy(selectedStationId = stationId) }
    }

    fun setActiveJourney(plan: JourneyPlan?) {
        _state.update { it.copy(activeJourneyPlan = plan, liveJourneySegmentIndex = 0, liveJourneyProgress = 0f) }
    }

    fun advanceLiveJourney() {
        _state.update { s ->
            val plan = s.activeJourneyPlan ?: return@update s
            val nextIndex = s.liveJourneySegmentIndex + 1
            if (nextIndex >= plan.segments.size) {
                // Journey complete!
                s.copy(activeJourneyPlan = null, liveJourneySegmentIndex = 0, liveJourneyProgress = 0f)
            } else {
                s.copy(liveJourneySegmentIndex = nextIndex, liveJourneyProgress = 0f)
            }
        }
    }

    fun updateProfile(profile: UserProfile) {
        _state.update { it.copy(userProfile = profile) }
    }

    fun purchaseTicket(type: String, cost: Double) {
        _state.update { s ->
            val newTicket = Ticket(
                id = "TKT-${System.currentTimeMillis() % 10000}",
                type = type,
                state = TicketState.PURCHASED,
                simulatedCost = cost,
                validityString = if (type.contains("Day")) "Today" else "Valid 90 mins"
            )
            s.copy(tickets = s.tickets + newTicket)
        }
    }

    fun activateTicket(id: String) {
        _state.update { s ->
            val updated = s.tickets.map { t ->
                if (t.id == id) t.copy(state = TicketState.ACTIVE)
                else if (t.state == TicketState.ACTIVE && t.type != "Stored Value") t.copy(state = TicketState.PURCHASED) // Only one active day/single pass at a time
                else t
            }
            s.copy(tickets = updated)
        }
    }

    fun changeWeather(newWeather: WeatherState) {
        _state.update { s ->
            val newAlerts = s.alerts.toMutableList()
            if (newWeather == WeatherState.HEAVY_RAIN || newWeather == WeatherState.THUNDERSTORM || newWeather == WeatherState.TROPICAL_STORM) {
                newAlerts.add(
                    Alert(
                        id = "WXT-01",
                        title = "Severe Weather Warning",
                        description = "Tropical weather in Greater Orlando. LYNX speeds reduced by 30%. Walking times extended.",
                        severity = if (newWeather == WeatherState.TROPICAL_STORM) AlertSeverity.CRITICAL else AlertSeverity.MAJOR,
                        affectedRouteId = null,
                        timestamp = "Just Now"
                    )
                )
            } else {
                newAlerts.removeAll { it.id == "WXT-01" }
            }
            s.copy(weather = newWeather, alerts = newAlerts)
        }
    }

    // Trigger scenarios and propagate them!
    fun runScenario(scenario: Scenario) {
        resetSimulation() // clear to clean state first
        _state.update { it.copy(activeScenario = scenario) }

        when (scenario) {
            Scenario.RAIL_DELAY -> {
                // Train P302 delayed near Maitland
                _state.update { s ->
                    val updatedVehicles = s.vehicles.map { v ->
                        if (v.id == "P302") v.copy(delayMinutes = 12, status = VehicleStatus.DELAYED, speedMph = 15.0)
                        else v
                    }
                    val newAlert = Alert(
                        id = "ALT-RAIL-01",
                        title = "SunRail Northbound Delay",
                        description = "Train P302 is experiencing a 12-minute delay approaching Maitland due to a minor mechanical check.",
                        severity = AlertSeverity.MAJOR,
                        affectedRouteId = "SunRail-North",
                        timestamp = "07:05 AM"
                    )
                    s.copy(
                        vehicles = updatedVehicles,
                        alerts = s.alerts + newAlert,
                        networkOnTimePercentage = 84.5f
                    )
                }
            }
            Scenario.STATION_CLOSURE -> {
                // LYNX Central closed! All trains pass without stopping. Bus lines detour.
                _state.update { s ->
                    val updatedStations = s.stations.mapValues { (id, station) ->
                        if (id == "LYN-01") station.copy(accessibility = "CLOSED", amenities = listOf("CLOSED FOR MAINTENANCE"))
                        else station
                    }
                    val newAlert = Alert(
                        id = "ALT-STAT-01",
                        title = "LYNX Central Closed",
                        description = "LYNX Central station is closed due to a police investigation. SunRail trains will bypass LYNX Central. Bus routes detouring.",
                        severity = AlertSeverity.CRITICAL,
                        affectedRouteId = null,
                        affectedStationId = "LYN-01",
                        timestamp = "07:10 AM"
                    )
                    s.copy(
                        stations = updatedStations,
                        alerts = s.alerts + newAlert,
                        networkOnTimePercentage = 76.2f,
                        totalActivePassengers = 9800
                    )
                }
            }
            Scenario.BUS_BRIDGE -> {
                // Outage between Winter Park and LYNX Central. Activate replacement Bus Bridge!
                _state.update { s ->
                    val newAlerts = s.alerts + listOf(
                        Alert(
                            id = "ALT-BRIDGE-01",
                            title = "SunRail Service Interrupted",
                            description = "Track issue between Winter Park and LYNX Central. Rail services suspended in this segment. Alternative Bus Bridge activated.",
                            severity = AlertSeverity.CRITICAL,
                            affectedRouteId = "SunRail-North",
                            timestamp = "07:12 AM"
                        ),
                        Alert(
                            id = "ALT-BRIDGE-02",
                            title = "Bus Bridge Activated",
                            description = "Shuttle buses running directly between LYNX Central and Winter Park. Boarding at LYNX Central Bay 1 and Winter Park West Lot.",
                            severity = AlertSeverity.MAJOR,
                            affectedRouteId = "LYNX-BRIDGE",
                            timestamp = "07:12 AM"
                        )
                    )
                    // Create bus bridge vehicles
                    val bridgeBuses = listOf(
                        Vehicle(
                            id = "BRIDGE-01",
                            routeId = "LYNX-BRIDGE",
                            type = TransportMode.LYNX,
                            direction = "Northbound",
                            latitude = 28.5934,
                            longitude = -81.3630, // near Winter Park
                            speedMph = 30.0,
                            delayMinutes = 2,
                            passengerLoad = 48,
                            capacity = 60,
                            status = VehicleStatus.RUNNING,
                            currentStationId = "LYN-01",
                            nextStationId = "WPK-01"
                        ),
                        Vehicle(
                            id = "BRIDGE-02",
                            routeId = "LYNX-BRIDGE",
                            type = TransportMode.LYNX,
                            direction = "Southbound",
                            latitude = 28.5486,
                            longitude = -81.3814, // near LYNX Central
                            speedMph = 25.0,
                            delayMinutes = 0,
                            passengerLoad = 55,
                            capacity = 60,
                            status = VehicleStatus.BOARDING,
                            currentStationId = "WPK-01",
                            nextStationId = "LYN-01"
                        )
                    )
                    s.copy(
                        alerts = newAlerts,
                        vehicles = s.vehicles + bridgeBuses,
                        networkOnTimePercentage = 71.0f
                    )
                }
            }
            Scenario.DOWNTOWN_EVENT -> {
                // Big soccer match or concert at Exploria Stadium (EXP-01). Huge demand surge!
                _state.update { s ->
                    val updatedParkAndRides = s.parkAndRides.map { pr ->
                        if (pr.nearestStationId == "LYN-01" || pr.nearestStationId == "CHU-01") {
                            pr.copy(availableSpaces = (pr.totalSpaces * 0.08).toInt()) // 92% full
                        } else pr
                    }
                    val newAlert = Alert(
                        id = "ALT-EVT-01",
                        title = "Exploria Stadium Event Surge",
                        description = "Orlando City Soccer match tonight! Expect high boarding volumes and platform crowding at LYNX Central and Church Street stations.",
                        severity = AlertSeverity.INFO,
                        affectedRouteId = null,
                        timestamp = "07:00 AM"
                    )
                    s.copy(
                        parkAndRides = updatedParkAndRides,
                        alerts = s.alerts + newAlert,
                        totalActivePassengers = 21500,
                        networkOnTimePercentage = 94.2f
                    )
                }
            }
            Scenario.HEAVY_RAIN -> {
                changeWeather(WeatherState.HEAVY_RAIN)
            }
            Scenario.MAJOR_INCIDENT -> {
                // Vehicle failure at Altamonte Springs!
                _state.update { s ->
                    val newIncident = Incident(
                        id = "INC-1048",
                        type = "Vehicle Failure",
                        location = "Altamonte Springs",
                        severity = AlertSeverity.CRITICAL,
                        affectedVehicleId = "P302",
                        status = IncidentStatus.ACTIVE,
                        response = "Maintenance dispatched. LYNX Bus Bridge standby.",
                        timestamp = "07:15 AM"
                    )
                    val newAlert = Alert(
                        id = "ALT-INC-01",
                        title = "Major Incident: Vehicle Failure",
                        description = "Train P302 has failed mechanically at Altamonte Springs. Severe delays expected northbound. Avoid the line if possible.",
                        severity = AlertSeverity.CRITICAL,
                        affectedRouteId = "SunRail-North",
                        timestamp = "07:15 AM"
                    )
                    s.copy(
                        incidents = s.incidents + newIncident,
                        alerts = s.alerts + newAlert,
                        networkOnTimePercentage = 63.4f
                    )
                }
            }
            else -> {
                // NORMAL_MORNING
                _state.update { it.copy(networkOnTimePercentage = 96.8f, totalActivePassengers = 12450) }
            }
        }
    }

    fun handleIncidentAction(incidentId: String, action: String) {
        _state.update { s ->
            val updatedIncidents = s.incidents.map { inc ->
                if (inc.id == incidentId) {
                    when (action) {
                        "ACKNOWLEDGE" -> inc.copy(status = IncidentStatus.ACKNOWLEDGED, response = "Operator Acknowledged. Dispatching crew.")
                        "BRIDGE" -> inc.copy(response = "Activated Bus Bridge. LYNX Shuttle standby.", status = IncidentStatus.ACKNOWLEDGED)
                        "RESOLVE" -> inc.copy(status = IncidentStatus.RESOLVED, response = "Cleared. Normal operations resuming.")
                        else -> inc
                    }
                } else inc
            }
            // If resolved, remove corresponding alert
            val alerts = s.alerts.toMutableList()
            if (action == "RESOLVE") {
                alerts.removeAll { it.id == "ALT-INC-01" }
            }
            s.copy(incidents = updatedIncidents, alerts = alerts)
        }
    }

    // Core simulation tick!
    fun tick(minutesPassed: Int) {
        if (_state.value.isPaused) return

        _state.update { s ->
            val nextMinutes = (s.simulationTimeMinutes + minutesPassed) % 1440
            
            // 1. Move vehicles along their routes
            val updatedVehicles = s.vehicles.map { vehicle ->
                val route = s.routes[vehicle.routeId] ?: return@map vehicle
                if (vehicle.status == VehicleStatus.OUT_OF_SERVICE) return@map vehicle

                // Simulate movement based on route type
                val speedMod = s.weather.speedModifier
                val currentSpeed = if (vehicle.status == VehicleStatus.RUNNING) vehicle.speedMph * speedMod else 0.0

                // Progress station index
                var progress = vehicle.stationProgress + (0.01 * s.timeScale * speedMod)
                var currentId = vehicle.currentStationId
                var nextId = vehicle.nextStationId
                var status = vehicle.status

                if (progress >= 1.0) {
                    progress = 0.0
                    // Arrived at next station!
                    currentId = nextId
                    val stationIdx = route.stations.indexOf(nextId)
                    val nextIdx = if (stationIdx != -1) (stationIdx + 1) % route.stations.size else 0
                    nextId = route.stations[nextIdx]
                    status = VehicleStatus.AT_STATION
                } else if (progress > 0.0 && progress < 0.2) {
                    status = VehicleStatus.BOARDING
                } else if (progress >= 0.2 && progress < 0.8) {
                    status = VehicleStatus.RUNNING
                } else {
                    status = VehicleStatus.APPROACHING
                }

                // Smoothly calculate lat/lon based on progress between currentStation and nextStation
                val currentStation = s.stations[currentId ?: ""]
                val nextStation = s.stations[nextId ?: ""]
                
                var lat = vehicle.latitude
                var lon = vehicle.longitude
                if (currentStation != null && nextStation != null) {
                    lat = currentStation.latitude + (nextStation.latitude - currentStation.latitude) * progress
                    lon = currentStation.longitude + (nextStation.longitude - currentStation.longitude) * progress
                }

                // Delay check
                val randomDelay = if (Math.random() < s.weather.delayChance * s.timeScale * 0.1) 1 else 0
                val delay = vehicle.delayMinutes + randomDelay

                vehicle.copy(
                    latitude = lat,
                    longitude = lon,
                    stationProgress = progress,
                    currentStationId = currentId,
                    nextStationId = nextId,
                    status = if (delay > 5) VehicleStatus.DELAYED else status,
                    speedMph = if (status == VehicleStatus.RUNNING) vehicle.speedMph else 0.0,
                    delayMinutes = delay,
                    passengerLoad = clampLoad(vehicle.passengerLoad + (Math.random() * 6 - 3).toInt(), vehicle.capacity)
                )
            }

            // 2. Animate Park & Ride occupancy
            val updatedParkAndRides = s.parkAndRides.map { pr ->
                val delta = (Math.random() * 4 - 2).toInt()
                val occupied = pr.totalSpaces - pr.availableSpaces
                val nextOccupied = (occupied + delta).coerceIn(0, pr.totalSpaces)
                pr.copy(availableSpaces = pr.totalSpaces - nextOccupied)
            }

            // 3. Update live journey progress if active
            var currentSegIndex = s.liveJourneySegmentIndex
            var currentSegProgress = s.liveJourneyProgress + (0.05f * s.timeScale)
            var activePlan = s.activeJourneyPlan

            if (activePlan != null) {
                if (currentSegProgress >= 1.0f) {
                    currentSegProgress = 0f
                    currentSegIndex++
                    if (currentSegIndex >= activePlan.segments.size) {
                        activePlan = null // Journey completed!
                        currentSegIndex = 0
                    }
                }
            }

            s.copy(
                simulationTimeMinutes = nextMinutes,
                vehicles = updatedVehicles,
                parkAndRides = updatedParkAndRides,
                activeJourneyPlan = activePlan,
                liveJourneySegmentIndex = currentSegIndex,
                liveJourneyProgress = currentSegProgress
            )
        }
        recalculateStats()
    }

    private fun clampLoad(load: Int, max: Int): Int {
        return load.coerceIn((max * 0.1).toInt(), max)
    }

    private fun recalculateStats() {
        _state.update { s ->
            val totalDelay = s.vehicles.sumOf { it.delayMinutes }
            val delayedCount = s.vehicles.count { it.delayMinutes > 5 }
            val totalVehicles = s.vehicles.size.coerceAtLeast(1)
            val basePunctuality = 98.0f - (totalDelay.toFloat() / totalVehicles * 0.5f) - (delayedCount.toFloat() / totalVehicles * 8f)
            
            val loadFactor = if (s.activeScenario == Scenario.DOWNTOWN_EVENT) 1.5 else 1.0
            val activePassengers = (10000 + (s.vehicles.sumOf { it.passengerLoad } * 1.2) * loadFactor).toInt()

            s.copy(
                networkOnTimePercentage = basePunctuality.coerceIn(55.0f, 99.8f),
                totalActivePassengers = activePassengers
            )
        }
    }

    // Graph Network Creator
    private fun createSyntheticStations(): Map<String, Station> = listOf(
        Station("SAN-01", "Sanford", 28.7931, -81.2989, listOf("SunRail-North"), listOf("Parking", "EV Charger", "Restrooms", "Bike Storage"), busConnections = listOf("LYNX 34", "LYNX 46W"), address = "2720 W State Rd 46", platformCount = 2, nearbyDestinations = listOf("Downtown Sanford", "Lake Monroe")),
        Station("LMR-01", "Lake Mary", 28.7589, -81.3211, listOf("SunRail-North"), listOf("Parking", "EV Charger", "Restrooms"), busConnections = listOf("STAR Flex 07", "LYNX 45"), address = "2200 W Lake Mary Blvd", platformCount = 2, nearbyDestinations = listOf("Lake Mary High School", "Seminole State College")),
        Station("LWD-01", "Longwood", 28.7001, -81.3478, listOf("SunRail-North"), listOf("Parking", "Bike Storage"), busConnections = listOf("LYNX 434"), address = "149 Church Ave", platformCount = 2, nearbyDestinations = listOf("Longwood Historic District")),
        Station("ALT-01", "Altamonte Springs", 28.6612, -81.3654, listOf("SunRail-North"), listOf("Parking", "EV Charger"), busConnections = listOf("LYNX 436N"), address = "2741 Douglas Ave", platformCount = 2, nearbyDestinations = listOf("Altamonte Mall", "Cranes Roost Park")),
        Station("MTL-01", "Maitland", 28.6256, -81.3639, listOf("SunRail-North"), listOf("Parking", "Restrooms"), busConnections = listOf("LYNX 102"), address = "801 N Orlando Ave", platformCount = 2, nearbyDestinations = listOf("Maitland Art Center", "RDV Sportsplex")),
        Station("WPK-01", "Winter Park", 28.5986, -81.3512, listOf("SunRail-North"), listOf("Parking", "Restrooms", "Bike Locker"), busConnections = listOf("STAR Flex 08", "LYNX 102", "LYNX 9"), address = "148 W Morse Blvd", platformCount = 2, nearbyDestinations = listOf("Rollins College", "Park Avenue Retail")),
        Station("LYN-01", "LYNX Central", 28.5486, -81.3814, listOf("SunRail-North", "SunRail-South", "LYNX-11", "LYNX-311", "LYNX-50", "LYNX-21", "LYNX-104", "LYMMO-Orange"), listOf("Restrooms", "Ticketing", "Indoor Waiting", "Transit Police", "Bike Center"), busConnections = listOf("LYNX 11", "LYNX 50", "LYNX 21", "LYNX 104", "LYNX 311", "LYMMO Orange"), address = "455 N Garland Ave", platformCount = 4, nearbyDestinations = listOf("Downtown Orlando", "Amway Center", "City Hall")),
        Station("CHU-01", "Church Street", 28.5401, -81.3814, listOf("SunRail-South"), listOf("Restrooms"), busConnections = listOf("LYMMO Orange", "LYNX 11"), address = "99 W South St", platformCount = 2, nearbyDestinations = listOf("Dr. Phillips Center", "Exploria Stadium", "Wall Street Plaza")),
        Station("ORH-01", "Orlando Health", 28.5264, -81.3809, listOf("SunRail-South"), listOf("Parking", "Restrooms"), busConnections = listOf("LYNX 40"), address = "1400 Sligh Blvd", platformCount = 2, nearbyDestinations = listOf("Orlando Regional Medical Center", "Arnold Palmer Hospital")),
        Station("SLR-01", "Sand Lake Road", 28.4528, -81.3861, listOf("SunRail-South", "LYNX-11"), listOf("Parking", "EV Charger", "Restrooms"), busConnections = listOf("LYNX 11", "LYNX 111", "LYNX 42"), address = "8030 S Orange Ave", platformCount = 2, nearbyDestinations = listOf("Florida Mall", "Orlando Airport Connector")),
        Station("MDW-01", "Meadow Woods", 28.3756, -81.3722, listOf("SunRail-South"), listOf("Parking", "Bike Storage"), busConnections = listOf("LYNX 418"), address = "3000 Fairway Woods Blvd", platformCount = 2, nearbyDestinations = listOf("Meadow Woods Middle School")),
        Station("KIS-01", "Kissimmee", 28.2934, -81.4056, listOf("SunRail-South"), listOf("Parking", "Restrooms", "Bike Storage"), busConnections = listOf("LYNX 10", "LYNX 26", "Greyhound"), address = "111 E Dakota Ave", platformCount = 2, nearbyDestinations = listOf("Kissimmee Lakefront Park", "Osceola County Courthouse")),
        Station("POI-01", "Poinciana", 28.2256, -81.4722, listOf("SunRail-South"), listOf("Parking", "Restrooms"), busConnections = listOf("LYNX 603", "LYNX 604"), address = "5055 Old Tampa Hwy", platformCount = 2, nearbyDestinations = listOf("Poinciana Medical Center")),
        
        // POIs
        Station("MCO-01", "Orlando Int'l Airport (MCO)", 28.4312, -81.3081, listOf("LYNX-11", "LYNX-311"), listOf("Restrooms", "Airport Terminals", "Luggage Services", "Food Court"), busConnections = listOf("LYNX 11", "LYNX 111", "Brightline"), address = "1 Jeff Fuqua Blvd", platformCount = 1, nearbyDestinations = listOf("Terminals A, B & C", "Duty Free Shopping")),
        Station("UCF-01", "UCF Main Campus", 28.6024, -81.2001, listOf("LYNX-104"), listOf("Student Union", "Bike Racks"), busConnections = listOf("LYNX 104", "UCF Shuttle"), address = "4000 Central Florida Blvd", platformCount = 1, nearbyDestinations = listOf("Addition Financial Arena", "Bounce House Stadium")),
        Station("IDR-01", "International Drive", 28.4311, -81.4654, listOf("LYNX-50"), listOf("Trolley Connection"), busConnections = listOf("I-Ride Trolley"), address = "International Drive, Orlando", platformCount = 1, nearbyDestinations = listOf("OCCC", "SeaWorld", "Pointe Orlando")),
        Station("UNI-01", "Universal Studios", 28.4754, -81.4687, listOf("LYNX-21"), listOf("Restrooms", "Luggage Storage"), busConnections = listOf("LYNX 21", "Hotel Shuttle"), address = "Universal Blvd, Orlando", platformCount = 1, nearbyDestinations = listOf("CityWalk", "Universal Studios", "Islands of Adventure")),
        Station("DIS-01", "Disney Springs area", 28.3712, -81.5189, listOf("LYNX-50"), listOf("Restrooms", "EV Charging"), busConnections = listOf("LYNX 50", "Disney Transport"), address = "Disney Springs, Lake Buena Vista", platformCount = 1, nearbyDestinations = listOf("Disney Springs", "EPCOT", "Magic Kingdom"))
    ).associateBy { it.id }

    private fun createSyntheticRoutes(): Map<String, Route> = listOf(
        Route("SunRail-North", "SunRail North", TransportMode.SUNRAIL, listOf("POI-01", "KIS-01", "MDW-01", "SLR-01", "ORH-01", "CHU-01", "LYN-01", "WPK-01", "MTL-01", "ALT-01", "LWD-01", "LMR-01", "SAN-01"), frequencyMinutes = 30),
        Route("SunRail-South", "SunRail South", TransportMode.SUNRAIL, listOf("SAN-01", "LMR-01", "LWD-01", "ALT-01", "MTL-01", "WPK-01", "LYN-01", "CHU-01", "ORH-01", "SLR-01", "MDW-01", "KIS-01", "POI-01"), frequencyMinutes = 30),
        Route("LYNX-11", "LYNX Route 11", TransportMode.LYNX, listOf("LYN-01", "CHU-01", "SLR-01", "MCO-01"), frequencyMinutes = 20),
        Route("LYNX-311", "LYNX Express 311", TransportMode.LYNX, listOf("LYN-01", "MCO-01"), frequencyMinutes = 15),
        Route("LYNX-50", "LYNX Route 50", TransportMode.LYNX, listOf("LYN-01", "IDR-01", "DIS-01"), frequencyMinutes = 30),
        Route("LYNX-21", "LYNX Route 21", TransportMode.LYNX, listOf("LYN-01", "UNI-01"), frequencyMinutes = 20),
        Route("LYNX-104", "LYNX Route 104", TransportMode.LYNX, listOf("LYN-01", "UCF-01"), frequencyMinutes = 15),
        Route("LYMMO-Orange", "LYMMO Downtown Orange", TransportMode.LYMMO, listOf("LYN-01", "CHU-01", "LYN-01"), frequencyMinutes = 5),
        Route("STAR-Flex-07", "STAR Flex 07", TransportMode.MICROTRANSIT, listOf("LMR-01", "SAN-01"), frequencyMinutes = 10)
    ).associateBy { it.id }

    private fun createSyntheticParkAndRides(): List<ParkAndRide> = listOf(
        ParkAndRide("Sanford Park & Ride", 420, 290, true, true, "SAN-01"),
        ParkAndRide("Lake Mary Park & Ride", 1142, 384, true, true, "LMR-01"),
        ParkAndRide("Longwood Park & Ride", 350, 120, false, true, "LWD-01"),
        ParkAndRide("Altamonte Springs Park & Ride", 800, 240, true, false, "ALT-01"),
        ParkAndRide("Maitland Park & Ride", 510, 110, false, true, "MTL-01"),
        ParkAndRide("Winter Park Lot B", 180, 20, true, true, "WPK-01"),
        ParkAndRide("Sand Lake Road Parking", 620, 310, true, true, "SLR-01"),
        ParkAndRide("Kissimmee Intermodal Parking", 550, 210, true, true, "KIS-01")
    )

    private fun createInitialVehicles(routes: Map<String, Route>, stations: Map<String, Station>): List<Vehicle> {
        val list = mutableListOf<Vehicle>()
        // Northbound train P302
        list.add(
            Vehicle(
                id = "P302",
                routeId = "SunRail-North",
                type = TransportMode.SUNRAIL,
                direction = "Northbound",
                latitude = 28.6256,
                longitude = -81.3639,
                speedMph = 64.0,
                delayMinutes = 0,
                passengerLoad = 120,
                capacity = 300,
                status = VehicleStatus.RUNNING,
                currentStationId = "MTL-01",
                nextStationId = "ALT-01",
                stationProgress = 0.4
            )
        )
        // Southbound train P305
        list.add(
            Vehicle(
                id = "P305",
                routeId = "SunRail-South",
                type = TransportMode.SUNRAIL,
                direction = "Southbound",
                latitude = 28.5986,
                longitude = -81.3512,
                speedMph = 0.0,
                delayMinutes = 1,
                passengerLoad = 85,
                capacity = 300,
                status = VehicleStatus.AT_STATION,
                currentStationId = "WPK-01",
                nextStationId = "LYN-01",
                stationProgress = 0.0
            )
        )
        // LYNX Bus 4217 on Route 11
        list.add(
            Vehicle(
                id = "LYNX-4217",
                routeId = "LYNX-11",
                type = TransportMode.LYNX,
                direction = "Eastbound",
                latitude = 28.4528,
                longitude = -81.3861,
                speedMph = 35.0,
                delayMinutes = 4,
                passengerLoad = 22,
                capacity = 50,
                status = VehicleStatus.RUNNING,
                currentStationId = "SLR-01",
                nextStationId = "MCO-01",
                stationProgress = 0.5
            )
        )
        // LYNX Bus 4102 on Express 311
        list.add(
            Vehicle(
                id = "LYNX-4102",
                routeId = "LYNX-311",
                type = TransportMode.LYNX,
                direction = "Eastbound",
                latitude = 28.4801,
                longitude = -81.3402,
                speedMph = 45.0,
                delayMinutes = 0,
                passengerLoad = 15,
                capacity = 50,
                status = VehicleStatus.RUNNING,
                currentStationId = "LYN-01",
                nextStationId = "MCO-01",
                stationProgress = 0.7
            )
        )
        // STAR FLEX 07
        list.add(
            Vehicle(
                id = "FLEX-07",
                routeId = "STAR-Flex-07",
                type = TransportMode.MICROTRANSIT,
                direction = "Northbound",
                latitude = 28.7589,
                longitude = -81.3211,
                speedMph = 18.0,
                delayMinutes = 0,
                passengerLoad = 2,
                capacity = 8,
                status = VehicleStatus.BOARDING,
                currentStationId = "LMR-01",
                nextStationId = "SAN-01",
                stationProgress = 0.1
            )
        )
        return list
    }

    private fun createInitialAlerts(): List<Alert> = listOf(
        Alert(
            id = "ALT-01",
            title = "SunRail On-Time Operations",
            description = "All rail lines are currently running normal service across Central Florida.",
            severity = AlertSeverity.INFO,
            affectedRouteId = null,
            timestamp = "06:00 AM"
        )
    )

    private fun createInitialIncidents(): List<Incident> = emptyList()

    // -------------------------------------------------------------
    // SOPHISTICATED DYNAMIC DIJKSTRA ROUTING ENGINE
    // -------------------------------------------------------------

    data class GraphEdge(
        val toId: String,
        val mode: TransportMode,
        val routeId: String,
        val distanceMiles: Double,
        val baseDurationMinutes: Int,
        val simulatedFare: Double
    )

    fun calculateRoute(
        fromId: String,
        toId: String,
        accessibilityPreferences: Set<String> = emptySet(),
        travelPriority: String = "FASTEST"
    ): JourneyPlan {
        val stations = _state.value.stations
        val routes = _state.value.routes
        val weather = _state.value.weather
        val currentScenario = _state.value.activeScenario

        // Build the current network graph dynamically, respecting failures & disruptions!
        val graph = mutableMapOf<String, MutableList<GraphEdge>>()
        
        // Add all base rail & bus route edges
        routes.values.forEach { route ->
            // Skip rail if station is closed or we're on a segment outage (Scenarios)
            if (currentScenario == Scenario.STATION_CLOSURE && route.type == TransportMode.SUNRAIL && (fromId == "LYN-01" || toId == "LYN-01")) {
                // bypass closed station
                return@forEach
            }

            for (i in 0 until route.stations.size - 1) {
                val stA = route.stations[i]
                val stB = route.stations[i+1]
                
                // Segment calculations
                val distance = calculateDistance(stations[stA], stations[stB])
                val baseTime = (distance * 2.0 * 60.0).toInt().coerceAtLeast(3) // 30mph estimate
                val fare = if (route.type == TransportMode.SUNRAIL) 2.0 + (distance * 0.5) else 2.0

                val edge = GraphEdge(stB, route.type, route.id, distance, baseTime, fare)
                graph.getOrPut(stA) { mutableListOf() }.add(edge)
                
                // Add reciprocal edge for Southbound/Westbound
                val revEdge = GraphEdge(stA, route.type, route.id, distance, baseTime, fare)
                graph.getOrPut(stB) { mutableListOf() }.add(revEdge)
            }
        }

        // Add first/last-mile walking & cycling connections
        val allNodeIds = stations.keys.toList()
        for (i in allNodeIds.indices) {
            for (j in i + 1 until allNodeIds.size) {
                val stA = allNodeIds[i]
                val stB = allNodeIds[j]
                val nodeA = stations[stA]
                val nodeB = stations[stB]
                val distance = calculateDistance(nodeA, nodeB)

                // Only allow walking/cycling between nodes that are within 3.5 miles
                if (distance < 3.5) {
                    val walkTime = (distance * 15).toInt().coerceAtLeast(2) // 15 mins per mile walking
                    val cycleTime = (distance * 5).toInt().coerceAtLeast(1)  // 5 mins per mile cycling
                    
                    // Add Walk edges
                    graph.getOrPut(stA) { mutableListOf() }.add(GraphEdge(stB, TransportMode.WALK, "WALK", distance, walkTime, 0.0))
                    graph.getOrPut(stB) { mutableListOf() }.add(GraphEdge(stA, TransportMode.WALK, "WALK", distance, walkTime, 0.0))

                    // Add Cycle edges
                    graph.getOrPut(stA) { mutableListOf() }.add(GraphEdge(stB, TransportMode.CYCLE, "CYCLE", distance, cycleTime, 0.50))
                    graph.getOrPut(stB) { mutableListOf() }.add(GraphEdge(stA, TransportMode.CYCLE, "CYCLE", distance, cycleTime, 0.50))
                }
            }
        }

        // DIJKSTRA PATHFINDING WITH PRIORITY WEIGHTS
        val dist = mutableMapOf<String, Double>()
        val parent = mutableMapOf<String, GraphEdge?>()
        val visited = mutableSetOf<String>()

        allNodeIds.forEach { dist[it] = Double.MAX_VALUE }
        dist[fromId] = 0.0
        parent[fromId] = null

        while (true) {
            var u: String? = null
            var minDist = Double.MAX_VALUE
            for (node in allNodeIds) {
                if (!visited.contains(node) && (dist[node] ?: Double.MAX_VALUE) < minDist) {
                    minDist = dist[node] ?: Double.MAX_VALUE
                    u = node
                }
            }

            if (u == null || u == toId) break
            visited.add(u)

            val edges = graph[u] ?: emptyList()
            for (edge in edges) {
                if (visited.contains(edge.toId)) continue

                // ACCESSIBILITY CHECKS (CRITICAL)
                // If elevator failed at either u or edge.toId, and user has accessibility preference, add high penalty or reject edge
                var accessibilityCostMultiplier = 1.0
                if (accessibilityPreferences.contains("wheelchair") || accessibilityPreferences.contains("elevators_only")) {
                    val uStation = stations[u]
                    val vStation = stations[edge.toId]
                    if ((uStation != null && !uStation.isElevatorOperational) || (vStation != null && !vStation.isElevatorOperational)) {
                        accessibilityCostMultiplier = 1000.0 // Penalty that forces alternative routes!
                    }
                }

                // PRIORITY WEIGHTING
                val weight = when (travelPriority) {
                    "FASTEST" -> edge.baseDurationMinutes.toDouble() * (if (edge.mode == TransportMode.SUNRAIL) 0.8 else 1.0)
                    "FEWEST_TRANSFERS" -> edge.baseDurationMinutes.toDouble() + (if (parent[u]?.routeId != edge.routeId && parent[u] != null) 30.0 else 0.0) // heavy penalty on transfer
                    "LEAST_WALKING" -> if (edge.mode == TransportMode.WALK) edge.baseDurationMinutes.toDouble() * 3.0 else edge.baseDurationMinutes.toDouble()
                    "ACCESSIBLE" -> edge.baseDurationMinutes.toDouble() * accessibilityCostMultiplier
                    "LOWEST_FARE" -> edge.simulatedFare * 10.0 + edge.baseDurationMinutes.toDouble()
                    else -> edge.baseDurationMinutes.toDouble()
                }

                val currentDist = dist[u] ?: Double.MAX_VALUE
                val nextDist = currentDist + weight
                if (nextDist < (dist[edge.toId] ?: Double.MAX_VALUE)) {
                    dist[edge.toId] = nextDist
                    parent[edge.toId] = edge.copy(toId = u) // Store reverse for reconstruction
                }
            }
        }

        // Reconstruct path
        val segments = mutableListOf<JourneySegment>()
        var curr = toId
        while (curr != fromId) {
            val edge = parent[curr] ?: break
            val fromNodeId = edge.toId
            val toNodeId = curr
            
            val stFrom = stations[fromNodeId] ?: break
            val stTo = stations[toNodeId] ?: break

            val rName = if (edge.routeId == "WALK") "Walk" else if (edge.routeId == "CYCLE") "Cycle" else routes[edge.routeId]?.name ?: "Transit"
            
            val isElevatorFailed = !stFrom.isElevatorOperational || !stTo.isElevatorOperational
            
            segments.add(
                0, // Insert at head to reverse the back-to-front path
                JourneySegment(
                    fromStationId = fromNodeId,
                    fromStationName = stFrom.name,
                    toStationId = toNodeId,
                    toStationName = stTo.name,
                    mode = edge.mode,
                    routeName = rName,
                    durationMinutes = edge.baseDurationMinutes,
                    distanceMiles = edge.distanceMiles,
                    fareSimulated = edge.simulatedFare,
                    accessibility = if (stFrom.accessibility == "Fully Accessible" && stTo.accessibility == "Fully Accessible") "Fully Accessible" else "Limited Access",
                    realTimeStatus = if (isElevatorFailed) "Elevator Outage" else "Normal",
                    instructions = when (edge.mode) {
                        TransportMode.WALK -> "Walk ${String.format("%.1f", edge.distanceMiles)} mi to ${stTo.name}"
                        TransportMode.CYCLE -> "Ride bicycle ${String.format("%.1f", edge.distanceMiles)} mi to ${stTo.name}"
                        TransportMode.SUNRAIL -> "Board SunRail Northbound/Southbound train at Platform 1 to ${stTo.name}"
                        TransportMode.LYNX -> "Board LYNX Bus Line to ${stTo.name}"
                        else -> "Take ${rName} to ${stTo.name}"
                    },
                    elevatorStatus = if (isElevatorFailed) "Out of Service" else "Operational"
                )
            )
            curr = fromNodeId
        }

        // Fallback: If no path found (disconnected graph), create a simple synthetic trip
        if (segments.isEmpty()) {
            val stFrom = stations[fromId] ?: Station("DUMMY-1", "Downtown Orlando", 28.5383, -81.3792, emptyList(), emptyList())
            val stTo = stations[toId] ?: Station("DUMMY-2", "Orlando Int'l Airport (MCO)", 28.4312, -81.3081, emptyList(), emptyList())
            val distMiles = calculateDistance(stFrom, stTo)
            segments.add(
                JourneySegment(
                    fromStationId = fromId,
                    fromStationName = stFrom.name,
                    toStationId = toId,
                    toStationName = stTo.name,
                    mode = TransportMode.LYNX,
                    routeName = "LYNX 311 Express",
                    durationMinutes = 32,
                    distanceMiles = distMiles,
                    fareSimulated = 2.00,
                    accessibility = "Fully Accessible",
                    realTimeStatus = "On Time",
                    instructions = "Board LYNX Express 311 towards ${stTo.name}"
                )
            )
        }

        val totalDuration = segments.sumOf { it.durationMinutes }
        val walkingTime = segments.filter { it.mode == TransportMode.WALK }.sumOf { it.durationMinutes }
        val transfers = (segments.filter { it.mode != TransportMode.WALK && it.mode != TransportMode.CYCLE }.map { it.routeName }.distinct().size - 1).coerceAtLeast(0)
        val totalFare = segments.sumOf { it.fareSimulated }

        val alertAffected = segments.any { seg -> 
            _state.value.alerts.any { alert -> alert.affectedRouteId == seg.routeName || alert.affectedStationId == seg.fromStationId || alert.affectedStationId == seg.toStationId }
        }
        val alertMsg = if (alertAffected) {
            _state.value.alerts.firstOrNull { alert -> 
                segments.any { seg -> alert.affectedRouteId == seg.routeName || alert.affectedStationId == seg.fromStationId || alert.affectedStationId == seg.toStationId }
            }?.description
        } else null

        return JourneyPlan(
            id = "PLAN-${System.currentTimeMillis() % 10000}",
            originName = stations[fromId]?.name ?: "Origin",
            destinationName = stations[toId]?.name ?: "Destination",
            segments = segments,
            totalDurationMinutes = totalDuration,
            walkingTimeMinutes = walkingTime,
            transfersCount = transfers,
            simulatedFare = totalFare,
            reliabilityIndicator = if (alertAffected) "Low" else if (weather == WeatherState.HEAVY_RAIN || weather == WeatherState.THUNDERSTORM) "Medium" else "High",
            accessibility = if (segments.any { it.elevatorStatus == "Out of Service" }) "Not Wheelchair Friendly" else "Wheelchair Accessible",
            isAffectedByAlert = alertAffected,
            alertDetails = alertMsg
        )
    }

    private fun calculateDistance(stA: Station?, stB: Station?): Double {
        if (stA == null || stB == null) return 1.0
        val earthRadius = 3958.8 // miles
        val dLat = Math.toRadians(stB.latitude - stA.latitude)
        val dLon = Math.toRadians(stB.longitude - stA.longitude)
        val a = sin(dLat / 2).pow(2.0) +
                cos(Math.toRadians(stA.latitude)) * cos(Math.toRadians(stB.latitude)) *
                sin(dLon / 2).pow(2.0)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return earthRadius * c
    }
}
