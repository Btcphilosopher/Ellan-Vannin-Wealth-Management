package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.*
import com.example.engine.SimulationEngine
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MoreScreen() {
    val state by SimulationEngine.state.collectAsState()
    val scope = rememberCoroutineScope()
    
    // Sub-sections of More Screen
    var currentSubTab by remember { mutableStateOf("TICKETS") } // TICKETS, OPERATIONS, SIMULATION, STATIONS, ANALYTICS

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Top Sub-Tab Selector Row (Civic Airport Styling)
        ScrollableTabRow(
            selectedTabIndex = when (currentSubTab) {
                "TICKETS" -> 0
                "STATIONS" -> 1
                "OPERATIONS" -> 2
                "SIMULATION" -> 3
                "ANALYTICS" -> 4
                else -> 0
            },
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = Color.White
        ) {
            Tab(selected = currentSubTab == "TICKETS", onClick = { currentSubTab = "TICKETS" }) {
                Text("TICKETS", modifier = Modifier.padding(14.dp), fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
            Tab(selected = currentSubTab == "STATIONS", onClick = { currentSubTab = "STATIONS" }) {
                Text("STATIONS & TWIN", modifier = Modifier.padding(14.dp), fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
            Tab(selected = currentSubTab == "OPERATIONS", onClick = { currentSubTab = "OPERATIONS" }) {
                Text("COMMAND", modifier = Modifier.padding(14.dp), fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
            Tab(selected = currentSubTab == "SIMULATION", onClick = { currentSubTab = "SIMULATION" }) {
                Text("SIM LAB", modifier = Modifier.padding(14.dp), fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
            Tab(selected = currentSubTab == "ANALYTICS", onClick = { currentSubTab = "ANALYTICS" }) {
                Text("ANALYTICS", modifier = Modifier.padding(14.dp), fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f)
        ) {
            when (currentSubTab) {
                "TICKETS" -> TicketsTab(state)
                "STATIONS" -> StationsTab(state)
                "OPERATIONS" -> OperationsTab(state)
                "SIMULATION" -> SimulationTab(state)
                "ANALYTICS" -> AnalyticsTab(state)
            }
        }
    }
}

// -------------------------------------------------------------
// 1. MOBILE TICKETING SIMULATION TAB
// -------------------------------------------------------------
@Composable
fun TicketsTab(state: SimulationEngine.SimState) {
    val scrollState = rememberScrollState()
    var selectedTicketForViewing by remember { mutableStateOf<Ticket?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
            .padding(bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("MOBILE TICKETING SIMULATOR", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

        if (selectedTicketForViewing != null) {
            // HIGH FIDELITY ANIMATED DIGITAL TICKET VIEW
            val ticket = selectedTicketForViewing!!
            
            // Pulsing animation for active ticket security banner
            val infiniteTransition = rememberInfiniteTransition(label = "banner")
            val alphaAnim by infiniteTransition.animateFloat(
                initialValue = 0.4f,
                targetValue = 0.9f,
                animationSpec = infiniteRepeatable(
                    animation = tween(1200, easing = LinearEasing),
                    repeatMode = RepeatMode.Reverse
                ), label = "alpha"
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Security flashing background bar
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(12.dp)
                            .background(
                                Brush.horizontalGradient(
                                    listOf(
                                        MaterialTheme.colorScheme.tertiary,
                                        Color(0xFF4FA9D8)
                                    )
                                ),
                                RoundedCornerShape(6.dp)
                            )
                            .graphicsLayer(alpha = alphaAnim)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "ORLANDO STAR",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                        Box(
                            modifier = Modifier
                                .background(MaterialTheme.colorScheme.tertiary, RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                ticket.state.name,
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Divider(color = Color(0x30FFFFFF))

                    Text(
                        ticket.type.uppercase(),
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.tertiary
                    )

                    // Textual Simulated QR Code
                    Card(
                        modifier = Modifier
                            .size(160.dp)
                            .background(Color.White)
                            .padding(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        // Drawing a fake QR code grid visually
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val cellSize = size.width / 8f
                            for (r in 0..7) {
                                for (c in 0..7) {
                                    val isFilled = (r + c) % 2 == 0 || (r == 0 && c == 0) || (r == 7 && c == 7) || (r in 1..2 && c in 5..6)
                                    if (isFilled) {
                                        drawRect(
                                            color = Color.Black,
                                            topLeft = Offset(c * cellSize, r * cellSize),
                                            size = androidx.compose.ui.geometry.Size(cellSize, cellSize)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Text(
                        "PASSENGER: ${ticket.passengerName.uppercase()}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "VALIDITY: ${ticket.validityString}",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.LightGray
                    )
                    
                    Text(
                        "SIMULATED FARE ENGINE PASS",
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 8.sp,
                        color = Color(0x80FFFFFF)
                    )

                    Button(
                        onClick = { selectedTicketForViewing = null },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("BACK TO MY STAR PASSES", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            // PURCHASE SECTIONS AND TICKET VAULT LIST
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0xFFE5E7EB)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("PURCHASE SIMULATED PASS", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

                    TicketPurchaseRow("Single Ride Pass", "$2.00") { SimulationEngine.purchaseTicket("Single Ride", 2.00) }
                    TicketPurchaseRow("Day Pass", "$4.50") { SimulationEngine.purchaseTicket("Day Pass", 4.50) }
                    TicketPurchaseRow("Weekly Pass", "$18.00") { SimulationEngine.purchaseTicket("Weekly Pass", 18.00) }
                    TicketPurchaseRow("Monthly Commuter Pass", "$52.00") { SimulationEngine.purchaseTicket("Monthly Commuter", 52.00) }
                }
            }

            Text("MY STAR VAULT (${state.tickets.size} PASSES)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                state.tickets.forEach { ticket ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, Color(0xFFE5E7EB))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(ticket.type, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF0A2342))
                                Text("Validity: ${ticket.validityString}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .background(
                                                if (ticket.state == TicketState.ACTIVE) Color(0xFF1E5631) else Color(0xFFE5E7EB),
                                                RoundedCornerShape(4.dp)
                                            )
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            ticket.state.name,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontSize = 8.sp,
                                            color = if (ticket.state == TicketState.ACTIVE) Color.White else Color.Black,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Text("Cost: $${String.format("%.2f", ticket.simulatedCost)}", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                }
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (ticket.state == TicketState.PURCHASED) {
                                    Button(
                                        onClick = { SimulationEngine.activateTicket(ticket.id) },
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text("ACTIVATE", fontSize = 10.sp)
                                    }
                                }
                                Button(
                                    onClick = { selectedTicketForViewing = ticket },
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("VIEW QR", fontSize = 10.sp, color = Color.White)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TicketPurchaseRow(label: String, price: String, onBuy: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(label, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
            Text("Simulated Fare: $price", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
        }
        Button(
            onClick = onBuy,
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.testTag("buy_ticket_button")
        ) {
            Text("BUY", fontSize = 10.sp)
        }
    }
}

// -------------------------------------------------------------
// 2. STATION DIGITAL TWIN TAB
// -------------------------------------------------------------
@Composable
fun StationsTab(state: SimulationEngine.SimState) {
    var selectedStationId by remember { mutableStateOf("LYN-01") }
    var currentSubTab by remember { mutableStateOf("FACILITIES") } // FACILITIES, DEPARTURES, INFO
    val selectedStation = state.stations[selectedStationId] ?: return
    
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
            .padding(bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("STATION DIGITAL TWIN & REAL-TIME DIAGRAMS", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

        // Station Selector Dropdown Box
        var expanded by remember { mutableStateOf(false) }
        Box(modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(
                onClick = { expanded = true },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("STATION: ${selectedStation.name}", fontWeight = FontWeight.Bold)
                    Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                }
            }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                state.stations.values.sortedBy { it.name }.forEach { st ->
                    DropdownMenuItem(
                        text = { Text(st.name) },
                        onClick = {
                            selectedStationId = st.id
                            expanded = false
                        }
                    )
                }
            }
        }

        // Sub Tabs
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { currentSubTab = "FACILITIES" },
                colors = ButtonDefaults.buttonColors(containerColor = if (currentSubTab == "FACILITIES") MaterialTheme.colorScheme.primary else Color(0xFFE5E7EB)),
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("FACILITIES", fontSize = 11.sp, color = if (currentSubTab == "FACILITIES") Color.White else Color.Black)
            }
            Button(
                onClick = { currentSubTab = "INFO" },
                colors = ButtonDefaults.buttonColors(containerColor = if (currentSubTab == "INFO") MaterialTheme.colorScheme.primary else Color(0xFFE5E7EB)),
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("OVERVIEW & MAP", fontSize = 11.sp, color = if (currentSubTab == "INFO") Color.White else Color.Black)
            }
        }

        if (currentSubTab == "FACILITIES") {
            // DIGITAL TWIN ASSET LIST
            Text("DIGITAL TWIN STATUS MAP", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

            FacilityTwinStatusCard("PLATFORM 01 (Northbound / Eastbound)", "IN_SERVICE", "Platform clean. Signage fully active.")
            FacilityTwinStatusCard("PLATFORM 02 (Southbound / Westbound)", "IN_SERVICE", "Minor commuter queue. Platform security present.")
            FacilityTwinStatusCard("ELEVATOR 01 (East Entrance)", "IN_SERVICE", "Last inspection: Today 05:00 AM. Fully working.")
            
            // ELEVATOR 02 - Status matches simulation states
            val isElevatorOperational = selectedStation.isElevatorOperational
            FacilityTwinStatusCard(
                label = "ELEVATOR 02 (Platform Access)",
                status = if (isElevatorOperational) "IN_SERVICE" else "FAILED",
                description = if (isElevatorOperational) "Operational. Accessibility available." else "Out of service due to cable inspection failure. Wheelchair rerouting active in trip planner!"
            )

            FacilityTwinStatusCard("ESCALATOR 01 (Lobby Access)", "IN_SERVICE", "Vibration analysis normal.")
            FacilityTwinStatusCard("FARE GATEWAY BANK A", "IN_SERVICE", "All 6 ticket gates online and ticketing readers active.")
            FacilityTwinStatusCard("DIGITAL WAYFINDING SIGN B", "IN_SERVICE", "Next arrivals data feed active.")
        } else {
            // GENERAL INFO AND STATS
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0xFFE5E7EB)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(selectedStation.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF0A2342))
                    Text("Address: ${selectedStation.address}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    Text("Platforms: ${selectedStation.platformCount}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("AMENITIES", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text(selectedStation.amenities.joinToString(", "), style = MaterialTheme.typography.bodySmall, color = Color.DarkGray)

                    Spacer(modifier = Modifier.height(8.dp))
                    Text("BUS CONNECTIONS", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text(selectedStation.busConnections.joinToString(", ").ifEmpty { "None" }, style = MaterialTheme.typography.bodySmall, color = Color.DarkGray)

                    Spacer(modifier = Modifier.height(8.dp))
                    Text("NEARBY POIs", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text(selectedStation.nearbyDestinations.joinToString(", ").ifEmpty { "None" }, style = MaterialTheme.typography.bodySmall, color = Color.DarkGray)
                }
            }
        }
    }
}

@Composable
fun FacilityTwinStatusCard(label: String, status: String, description: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, Color(0xFFE5E7EB))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(label, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = Color(0xFF0A2342))
                Text(description, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
            }
            Box(
                modifier = Modifier
                    .background(if (status == "IN_SERVICE") Color(0xFF1E5631) else Color(0xFFEF4444), RoundedCornerShape(6.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(status, style = MaterialTheme.typography.labelSmall, fontSize = 8.sp, color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }
}

// -------------------------------------------------------------
// 3. OPERATIONS CONTROL CENTER (OCC) TAB
// -------------------------------------------------------------
@Composable
fun OperationsTab(state: SimulationEngine.SimState) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
            .padding(bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("STAR COMMAND · REGIONAL OPERATIONS CONTROL", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

        // Top command KPIs
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            KPICard("ACTIVE FLEET", state.vehicles.size.toString(), Icons.Default.DirectionsTransit, Modifier.weight(1f))
            KPICard("ON TIME %", "${String.format("%.1f", state.networkOnTimePercentage)}%", Icons.Default.Schedule, Modifier.weight(1f))
            KPICard("SIM PASSENGERS", state.totalActivePassengers.toString(), Icons.Default.Group, Modifier.weight(1f))
        }

        Text("ACTIVE INCIDENT CONTROL QUEUE (${state.incidents.count { it.status != IncidentStatus.RESOLVED }} ACTIVE)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

        val activeIncidents = state.incidents.filter { it.status != IncidentStatus.RESOLVED }
        if (activeIncidents.isEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, Color(0xFFE5E7EB))
            ) {
                Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF1E5631), modifier = Modifier.size(36.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("SYSTEMS GREEN", fontWeight = FontWeight.Bold, color = Color(0xFF1E5631))
                    Text("No operational incidents reported. All systems running normally.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                }
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                activeIncidents.forEach { incident ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, Color(0xFFEF4444))
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "INCIDENT #${incident.id}",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFEF4444)
                                )
                                Box(
                                    modifier = Modifier
                                        .background(Color(0xFFEF4444), RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        incident.severity.name,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontSize = 8.sp,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Text("Type: ${incident.type}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                            Text("Location: ${incident.location}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            Text("Affected: Train ${incident.affectedVehicleId ?: "None"}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            Text("Response actions: ${incident.response}", style = MaterialTheme.typography.bodySmall, color = Color.DarkGray, fontWeight = FontWeight.SemiBold)

                            Divider(modifier = Modifier.padding(vertical = 4.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (incident.status == IncidentStatus.ACTIVE) {
                                    Button(
                                        onClick = { SimulationEngine.handleIncidentAction(incident.id, "ACKNOWLEDGE") },
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.padding(end = 8.dp)
                                    ) {
                                        Text("ACKNOWLEDGE", fontSize = 10.sp)
                                    }
                                }
                                Button(
                                    onClick = { SimulationEngine.handleIncidentAction(incident.id, "RESOLVE") },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E5631)),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("RESOLVE", fontSize = 10.sp, color = Color.White)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun KPICard(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, Color(0xFFE5E7EB))
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
            Text(label, style = MaterialTheme.typography.labelSmall, fontSize = 8.sp, color = Color.Gray)
            Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, color = Color(0xFF0A2342))
        }
    }
}

// -------------------------------------------------------------
// 4. SIMULATION LAB TAB
// -------------------------------------------------------------
@Composable
fun SimulationTab(state: SimulationEngine.SimState) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
            .padding(bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("SIM LAB · DIGITAL TWIN CONTROL SYSTEM", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, Color(0xFFE5E7EB))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Text("TIME SCALE CONSOLE", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val scales = listOf(1, 5, 10, 30)
                    scales.forEach { scale ->
                        val isSelected = state.timeScale == scale
                        Button(
                            onClick = { SimulationEngine.setTimeScale(scale) },
                            colors = ButtonDefaults.buttonColors(containerColor = if (isSelected) MaterialTheme.colorScheme.primary else Color(0xFFE5E7EB)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("${scale}x", color = if (isSelected) Color.White else Color.Black)
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = { SimulationEngine.togglePause() },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(if (state.isPaused) Icons.Default.PlayArrow else Icons.Default.Pause, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(if (state.isPaused) "RESUME" else "PAUSE", color = Color.White)
                    }

                    Button(
                        onClick = { SimulationEngine.stepMinute() },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("STEP +1 MIN")
                    }
                }
            }
        }

        Text("INJECT OPERATIONAL SCENARIOS", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            ScenarioButton("NORMAL MORNING", "Normal Operations, clear schedule.") { SimulationEngine.runScenario(Scenario.NORMAL_MORNING) }
            ScenarioButton("TRAIN DELAY SCENARIO", "Train P302 suffers delayed approaching Maitland.") { SimulationEngine.runScenario(Scenario.RAIL_DELAY) }
            ScenarioButton("STATION CLOSURE DETOUR", "LYNX Central closed. SunRail bypassing, buses detouring.") { SimulationEngine.runScenario(Scenario.STATION_CLOSURE) }
            ScenarioButton("BUS BRIDGE RESPONSE", "Track shut down. Active LYNX replacement buses.") { SimulationEngine.runScenario(Scenario.BUS_BRIDGE) }
            ScenarioButton("DOWNTOWN SOCCER EVENT", "Exploria stadium match starts. Crowd surge & park-and-rides fill.") { SimulationEngine.runScenario(Scenario.DOWNTOWN_EVENT) }
            ScenarioButton("FLORIDA THUNDERSTORM", "Heavy afternoon storm downpours. Speed reduced, delays propagate.") { SimulationEngine.runScenario(Scenario.HEAVY_RAIN) }
            ScenarioButton("MAJOR MECHANICAL FAILURE", "P302 completely fails mechanically at Altamonte.") { SimulationEngine.runScenario(Scenario.MAJOR_INCIDENT) }
        }
    }
}

@Composable
fun ScenarioButton(title: String, desc: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("scenario_trigger_card"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, Color(0xFFE5E7EB))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = Color(0xFF0A2342))
            Text(desc, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
        }
    }
}

// -------------------------------------------------------------
// 5. REGIONAL ANALYTICS TAB
// -------------------------------------------------------------
@Composable
fun AnalyticsTab(state: SimulationEngine.SimState) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
            .padding(bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("REGIONAL MOBILITY DATA & PERFORMANCE ANALYTICS", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

        // Punctuality over routes bar chart (custom canvas rendering)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, Color(0xFFE5E7EB))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("PUNCTUALITY BY TRANSIT MODE", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color(0xFF0A2342))
                Spacer(modifier = Modifier.height(12.dp))

                BarChartRow("SunRail", 0.94f, Color(0xFF1E5631))
                BarChartRow("LYNX Bus", 0.88f, Color(0xFF0A2342))
                BarChartRow("LYMMO BRT", 0.98f, Color(0xFFD95A2B))
                BarChartRow("STAR Flex", 0.95f, Color(0xFF8B5CF6))
            }
        }

        // Peak Passenger load line chart (custom canvas rendering)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, Color(0xFFE5E7EB))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("DAILY PASSENGER HEATMAP BY HOUR", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color(0xFF0A2342))
                Spacer(modifier = Modifier.height(12.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp)
                        .background(Color(0xFFF9FAFB), RoundedCornerShape(8.dp))
                        .padding(8.dp)
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val points = listOf(
                            Offset(0.0f, size.height * 0.9f),   // 6 AM
                            Offset(0.15f * size.width, size.height * 0.2f),  // 8 AM (Peak)
                            Offset(0.3f * size.width, size.height * 0.6f),  // 11 AM
                            Offset(0.45f * size.width, size.height * 0.5f),  // 1 PM
                            Offset(0.6f * size.width, size.height * 0.7f),  // 3 PM
                            Offset(0.75f * size.width, size.height * 0.1f),  // 5 PM (Peak)
                            Offset(0.9f * size.width, size.height * 0.5f),  // 7 PM
                            Offset(1.0f * size.width, size.height * 0.95f)  // 9 PM
                        )

                        // Draw Grid lines
                        drawLine(
                            color = Color(0xFFE5E7EB),
                            start = Offset(0f, size.height * 0.2f),
                            end = Offset(size.width, size.height * 0.2f),
                            strokeWidth = 2f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                        )
                        drawLine(
                            color = Color(0xFFE5E7EB),
                            start = Offset(0f, size.height * 0.5f),
                            end = Offset(size.width, size.height * 0.5f),
                            strokeWidth = 2f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                        )

                        // Draw Line
                        for (i in 0 until points.size - 1) {
                            drawLine(
                                color = Color(0xFF0A2342),
                                start = points[i],
                                end = points[i+1],
                                strokeWidth = 6f
                            )
                        }

                        // Draw Point dots
                        points.forEach { pt ->
                            drawCircle(
                                color = Color(0xFFD95A2B),
                                radius = 8f,
                                center = pt
                            )
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("6AM", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                    Text("8AM (Peak)", style = MaterialTheme.typography.labelSmall, color = Color.Gray, fontWeight = FontWeight.Bold)
                    Text("12PM", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                    Text("5PM (Peak)", style = MaterialTheme.typography.labelSmall, color = Color.Gray, fontWeight = FontWeight.Bold)
                    Text("9PM", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                }
            }
        }
    }
}

@Composable
fun BarChartRow(label: String, fraction: Float, barColor: Color) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
            Text("${(fraction * 100).toInt()}%", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .background(Color(0xFFE5E7EB), RoundedCornerShape(4.dp))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(fraction)
                    .background(barColor, RoundedCornerShape(4.dp))
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
    }
}
