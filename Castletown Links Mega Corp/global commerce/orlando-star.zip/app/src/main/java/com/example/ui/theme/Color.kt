package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Orlando Star Custom Brand Palette
val DeepNavy = Color(0xFF0A2342)       // Primary civic/transit color
val FloridaGreen = Color(0xFF1E5631)   // Secondary nature/landscape green
val RestrainedOrange = Color(0xFFD95A2B) // Accent orange representing Florida sunshine & highways
val SkyBlue = Color(0xFF4FA9D8)        // Minor accent blue for routes/status
val WarmGrayBackground = Color(0xFFF4F5F7) // Screen background
val WarmGraySurface = Color(0xFFFFFFFF)    // Card background
val TextCharcoal = Color(0xFF111827)   // Body text
val TextMuted = Color(0xFF6B7280)      // Secondary/caption text
val BorderGray = Color(0xFFE5E7EB)     // Subtle separator border

val PrimaryDark = Color(0xFF1E293B)
val SecondaryDark = Color(0xFF22C55E)
val AccentDark = Color(0xFFF97316)
val BackgroundDark = Color(0xFF0F172A)
val SurfaceDark = Color(0xFF1E293B)
val TextLight = Color(0xFFF8FAFC)
val TextLightMuted = Color(0xFF94A3B8)

