package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.Station
import com.example.domain.TransportMode
import com.example.domain.Vehicle
import com.example.engine.SimulationEngine
import kotlin.math.roundToInt

@OptIn(ExperimentalTextApi::class)
@Composable
fun MapScreen() {
    val state by SimulationEngine.state.collectAsState()
    
    // Map view state
    var scale by remember { mutableStateOf(1.0f) }
    var offset by remember { mutableStateOf(Offset(0f, 0f)) }
    
    // Filter layers
    var showStations by remember { mutableStateOf(true) }
    var showVehicles by remember { mutableStateOf(true) }
    var showIncidents by remember { mutableStateOf(true) }
    var showCounties by remember { mutableStateOf(true) }
    
    // Selection state
    var selectedVehicle by remember { mutableStateOf<Vehicle?>(null) }
    var selectedStation by remember { mutableStateOf<Station?>(null) }

    val textMeasurer = rememberTextMeasurer()

    Box(modifier = Modifier.fillMaxSize()) {
        // transformable map area
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFE5E7EB)) // Soft warm gray base
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        offset += dragAmount
                    }
                }
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer(
                        scaleX = scale,
                        scaleY = scale,
                        translationX = offset.x,
                        translationY = offset.y
                    )
            ) {
                // Lat/lon mapping constants for Orlando area
                // Orlando coordinates: Lat 28.5383, Lon -81.3792
                // Sand Lake: Lat 28.4528, Lon -81.3861
                // Sanford: Lat 28.7931, Lon -81.2989
                val minLat = 28.15
                val maxLat = 28.85
                val minLon = -81.55
                val maxLon = -81.15

                fun latLonToOffset(lat: Double, lon: Double): Offset {
                    val x = ((lon - minLon) / (maxLon - minLon)) * size.width
                    // In canvas, Y increases downwards, so we invert Lat
                    val y = (1.0 - (lat - minLat) / (maxLat - minLat)) * size.height
                    return Offset(x.toFloat(), y.toFloat())
                }

                // 1. Draw County Boundaries
                if (showCounties) {
                    // Osceola (South)
                    drawRect(
                        color = Color(0x153B82F6),
                        topLeft = Offset(0f, size.height * 0.75f),
                        size = androidx.compose.ui.geometry.Size(size.width, size.height * 0.25f)
                    )
                    // Orange (Central)
                    drawRect(
                        color = Color(0x1010B981),
                        topLeft = Offset(0f, size.height * 0.35f),
                        size = androidx.compose.ui.geometry.Size(size.width, size.height * 0.40f)
                    )
                    // Seminole (North-East)
                    drawRect(
                        color = Color(0x15F59E0B),
                        topLeft = Offset(size.width * 0.3f, 0f),
                        size = androidx.compose.ui.geometry.Size(size.width * 0.7f, size.height * 0.35f)
                    )
                    // Lake (North-West)
                    drawRect(
                        color = Color(0x108B5CF6),
                        topLeft = Offset(0f, 0f),
                        size = androidx.compose.ui.geometry.Size(size.width * 0.3f, size.height * 0.35f)
                    )

                    // Draw County Labels
                    drawText(textMeasurer, "LAKE COUNTY", latLonToOffset(28.75, -81.50), style = TextStyle(color = Color(0xFF9CA3AF), fontSize = 10.sp, fontWeight = FontWeight.Bold))
                    drawText(textMeasurer, "SEMINOLE COUNTY", latLonToOffset(28.75, -81.22), style = TextStyle(color = Color(0xFF9CA3AF), fontSize = 10.sp, fontWeight = FontWeight.Bold))
                    drawText(textMeasurer, "ORANGE COUNTY", latLonToOffset(28.51, -81.45), style = TextStyle(color = Color(0xFF9CA3AF), fontSize = 10.sp, fontWeight = FontWeight.Bold))
                    drawText(textMeasurer, "OSCEOLA COUNTY", latLonToOffset(28.23, -81.42), style = TextStyle(color = Color(0xFF9CA3AF), fontSize = 10.sp, fontWeight = FontWeight.Bold))
                }

                // 2. Draw Transit Lines
                state.routes.values.forEach { route ->
                    val pathPoints = route.stations.mapNotNull { state.stations[it] }.map { latLonToOffset(it.latitude, it.longitude) }
                    
                    if (pathPoints.size > 1) {
                        val strokeColor = when (route.type) {
                            TransportMode.SUNRAIL -> Color(0xFF1E5631)
                            TransportMode.LYNX -> Color(0xFF0A2342)
                            TransportMode.LYMMO -> Color(0xFFD95A2B)
                            TransportMode.MICROTRANSIT -> Color(0xFF8B5CF6)
                            else -> Color.Gray
                        }

                        // Draw track lines
                        for (i in 0 until pathPoints.size - 1) {
                            if (route.type == TransportMode.SUNRAIL) {
                                // Draw railroad ties (dashed or dual color track)
                                drawLine(
                                    color = strokeColor,
                                    start = pathPoints[i],
                                    end = pathPoints[i+1],
                                    strokeWidth = 6f
                                )
                                drawLine(
                                    color = Color.White,
                                    start = pathPoints[i],
                                    end = pathPoints[i+1],
                                    strokeWidth = 2f,
                                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                                )
                            } else {
                                drawLine(
                                    color = strokeColor,
                                    start = pathPoints[i],
                                    end = pathPoints[i+1],
                                    strokeWidth = 4f
                                )
                            }
                        }
                    }
                }

                // 3. Draw Stations
                if (showStations) {
                    state.stations.values.forEach { station ->
                        val pos = latLonToOffset(station.latitude, station.longitude)
                        val isHub = station.id == "LYN-01" || station.id == "SLR-01" || station.id == "MCO-01"
                        
                        // Outer rim
                        drawCircle(
                            color = Color(0xFF0A2342),
                            radius = if (isHub) 14f else 9f,
                            center = pos
                        )
                        // Inner filled circle
                        drawCircle(
                            color = if (station.isElevatorOperational) Color.White else Color(0xFFEF4444),
                            radius = if (isHub) 9f else 5f,
                            center = pos
                        )

                        // Station name label (abbreviated/small)
                        drawText(
                            textMeasurer,
                            station.name,
                            pos + Offset(15f, -15f),
                            style = TextStyle(
                                color = Color(0xFF111827),
                                fontSize = 9.sp,
                                fontWeight = if (isHub) FontWeight.Bold else FontWeight.Normal
                            )
                        )
                    }
                }

                // 4. Draw Moving Vehicles
                if (showVehicles) {
                    state.vehicles.forEach { vehicle ->
                        val pos = latLonToOffset(vehicle.latitude, vehicle.longitude)
                        
                        val vehicleColor = when (vehicle.type) {
                            TransportMode.SUNRAIL -> Color(0xFF1E5631)
                            TransportMode.LYNX -> Color(0xFF0A2342)
                            TransportMode.LYMMO -> Color(0xFFD95A2B)
                            TransportMode.MICROTRANSIT -> Color(0xFF8B5CF6)
                            else -> Color.Gray
                        }

                        // Drawing vehicle marker
                        drawCircle(
                            color = Color.White,
                            radius = 16f,
                            center = pos
                        )
                        drawCircle(
                            color = vehicleColor,
                            radius = 12f,
                            center = pos
                        )

                        // Draw small text initial of vehicle inside
                        val label = when (vehicle.type) {
                            TransportMode.SUNRAIL -> "S"
                            TransportMode.LYNX -> "B"
                            TransportMode.LYMMO -> "L"
                            TransportMode.MICROTRANSIT -> "F"
                            else -> "V"
                        }
                        drawText(
                            textMeasurer,
                            label,
                            pos - Offset(5f, 10f),
                            style = TextStyle(color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        )
                    }
                }

                // 5. Draw Active Incident Indicators
                if (showIncidents) {
                    state.incidents.forEach { incident ->
                        val vehicle = state.vehicles.firstOrNull { it.id == incident.affectedVehicleId }
                        val pos = if (vehicle != null) {
                            latLonToOffset(vehicle.latitude, vehicle.longitude)
                        } else {
                            // Sanford area placeholder
                            latLonToOffset(28.7931, -81.2989)
                        }

                        // Pulse circle
                        drawCircle(
                            color = Color(0x30EF4444),
                            radius = 30f,
                            center = pos
                        )
                        drawCircle(
                            color = Color(0xFFEF4444),
                            radius = 8f,
                            center = pos
                        )
                    }
                }
            }
        }

        // Overlay: Floating Controls (Top Right)
        Column(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(16.dp)
                .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.9f), RoundedCornerShape(12.dp))
                .border(1.dp, Color(0xFFE5E7EB), RoundedCornerShape(12.dp))
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("MAP LAYERS", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            
            LayerToggleRow("Vehicles", showVehicles) { showVehicles = it }
            LayerToggleRow("Stations", showStations) { showStations = it }
            LayerToggleRow("Incidents", showIncidents) { showIncidents = it }
            LayerToggleRow("County Bounds", showCounties) { showCounties = it }

            Divider(modifier = Modifier.padding(vertical = 4.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IconButton(
                    onClick = { scale = (scale + 0.2f).coerceAtMost(3.0f) },
                    modifier = Modifier.size(36.dp).background(Color(0xFFF3F4F6), CircleShape)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Zoom In", tint = Color.Black)
                }
                IconButton(
                    onClick = { scale = (scale - 0.2f).coerceAtLeast(0.5f) },
                    modifier = Modifier.size(36.dp).background(Color(0xFFF3F4F6), CircleShape)
                ) {
                    Icon(Icons.Default.Remove, contentDescription = "Zoom Out", tint = Color.Black)
                }
                IconButton(
                    onClick = { scale = 1.0f; offset = Offset(0f,0f) },
                    modifier = Modifier.size(36.dp).background(Color(0xFFF3F4F6), CircleShape)
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = "Reset Zoom", tint = Color.Black)
                }
            }
        }

        // Overlay: Digital Twin Status Panel (Bottom Left/Bottom Center)
        Card(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(16.dp)
                .padding(bottom = 8.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            "ORLANDO STAR · DIGITAL TWIN",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            "CONCEPT PROTOTYPE · SYNTHETIC OPERATIONS",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.tertiary
                        )
                    }

                    // On-Time Indicator badge
                    Box(
                        modifier = Modifier
                            .background(Color(0xFF1E5631), RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            "ON-TIME: ${String.format("%.1f", state.networkOnTimePercentage)}%",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    MetricBox(
                        label = "ACTIVE VEHICLES",
                        value = state.vehicles.size.toString(),
                        icon = Icons.Default.DirectionsTransit
                    )
                    MetricBox(
                        label = "SIM PASSENGERS",
                        value = state.totalActivePassengers.toString(),
                        icon = Icons.Default.People
                    )
                    MetricBox(
                        label = "WEATHER STATE",
                        value = state.weather.label,
                        icon = when (state.weather) {
                            com.example.domain.WeatherState.CLEAR -> Icons.Default.LightMode
                            com.example.domain.WeatherState.HOT -> Icons.Default.WbSunny
                            else -> Icons.Default.Cloud
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun LayerToggleRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodySmall)
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.scale(0.7f)
        )
    }
}

// Helper to scale components
fun Modifier.scale(scale: Float): Modifier = graphicsLayer(scaleX = scale, scaleY = scale)

@Composable
fun MetricBox(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier
            .background(Color(0xFFF3F4F6), RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color(0xFF0A2342))
        Column {
            Text(label, style = MaterialTheme.typography.labelSmall, fontSize = 8.sp, color = Color.Gray)
            Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = Color(0xFF0A2342))
        }
    }
}
