package com.example.domain

import androidx.compose.ui.graphics.Color

enum class TransportMode(val label: String, val colorHex: String) {
    SUNRAIL("SunRail", "#1E5631"),       // Commuter Rail (Florida Green)
    LYNX("LYNX", "#0A2342"),             // Local Bus (Deep Navy)
    LYMMO("LYMMO", "#D95A2B"),           // Downtown Bus Rapid Transit (Sunshine Orange)
    NEIGHBORLINK("NeighborLink", "#4FA9D8"), // Flexible Transit (Sky Blue)
    MICROTRANSIT("STAR Flex", "#8B5CF6"),  // Premium Microtransit (Purple)
    WALK("Walk", "#6B7280"),             // First/Last Mile Pedestrian
    CYCLE("Cycle", "#10B981")            // Cycling Connection
}

enum class VehicleStatus(val label: String) {
    AT_STATION("At Station"),
    BOARDING("Boarding"),
    DEPARTING("Departing"),
    RUNNING("Running"),
    APPROACHING("Approaching"),
    ARRIVING("Arriving"),
    DWELLING("Dwelling"),
    DELAYED("Delayed"),
    OUT_OF_SERVICE("Out of Service")
}

enum class AlertSeverity {
    INFO, MINOR, MAJOR, CRITICAL
}

enum class IncidentStatus {
    ACTIVE, ACKNOWLEDGED, RESOLVED
}

enum class TicketState {
    AVAILABLE, PURCHASED, ACTIVE, EXPIRED, CANCELLED
}

enum class WeatherState(val label: String, val speedModifier: Double, val delayChance: Double) {
    CLEAR("Clear", 1.0, 0.02),
    HOT("Hot", 0.9, 0.05),
    RAIN("Rain", 0.8, 0.15),
    HEAVY_RAIN("Heavy Rain", 0.7, 0.30),
    THUNDERSTORM("Thunderstorm", 0.5, 0.50),
    TROPICAL_STORM("Tropical Storm", 0.3, 0.80)
}

enum class Scenario {
    NORMAL_MORNING,
    NORMAL_EVENING,
    AIRPORT_PEAK,
    DOWNTOWN_EVENT,
    HEAVY_RAIN,
    RAIL_DELAY,
    STATION_CLOSURE,
    BUS_BRIDGE,
    MAJOR_INCIDENT
}

data class Station(
    val id: String,
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val lineNames: List<String>,
    val amenities: List<String>,
    val accessibility: String = "Fully Accessible",
    val isElevatorOperational: Boolean = true,
    val busConnections: List<String> = emptyList(),
    val address: String = "Orlando, FL",
    val nearbyDestinations: List<String> = emptyList(),
    val platformCount: Int = 2
)

data class Route(
    val id: String,
    val name: String,
    val type: TransportMode,
    val stations: List<String>, // List of Station IDs
    val frequencyMinutes: Int = 15
)

data class Vehicle(
    val id: String,
    val routeId: String,
    val type: TransportMode,
    val direction: String,
    val latitude: Double,
    val longitude: Double,
    val speedMph: Double,
    val delayMinutes: Int,
    val passengerLoad: Int,
    val capacity: Int,
    val status: VehicleStatus,
    val currentStationId: String?,
    val nextStationId: String?,
    val stationProgress: Double = 0.0 // 0.0 to 1.0 between stations
)

data class JourneySegment(
    val fromStationId: String,
    val fromStationName: String,
    val toStationId: String,
    val toStationName: String,
    val mode: TransportMode,
    val routeName: String,
    val durationMinutes: Int,
    val distanceMiles: Double,
    val fareSimulated: Double,
    val accessibility: String,
    val realTimeStatus: String,
    val instructions: String,
    val elevatorStatus: String = "Operational"
)

data class JourneyPlan(
    val id: String,
    val originName: String,
    val destinationName: String,
    val segments: List<JourneySegment>,
    val totalDurationMinutes: Int,
    val walkingTimeMinutes: Int,
    val transfersCount: Int,
    val simulatedFare: Double,
    val reliabilityIndicator: String, // High, Medium, Low
    val accessibility: String,
    val isAffectedByAlert: Boolean = false,
    val alertDetails: String? = null
)

data class Alert(
    val id: String,
    val title: String,
    val description: String,
    val severity: AlertSeverity,
    val affectedRouteId: String?,
    val affectedStationId: String? = null,
    val timestamp: String
)

data class Incident(
    val id: String,
    val type: String,
    val location: String,
    val severity: AlertSeverity,
    val affectedVehicleId: String?,
    val status: IncidentStatus,
    val response: String,
    val timestamp: String
)

data class ParkAndRide(
    val facilityName: String,
    val totalSpaces: Int,
    val availableSpaces: Int,
    val evCharging: Boolean = true,
    val bikeParking: Boolean = true,
    val nearestStationId: String,
    val hourlyOccupancyHistory: List<Float> = emptyList()
)

data class Ticket(
    val id: String,
    val type: String, // Single Ride, Day Pass, Weekly Pass, Monthly Pass, Commuter Pass
    val state: TicketState,
    val simulatedCost: Double,
    val passengerName: String = "Demo User",
    val validityString: String,
    val qrCodePayload: String = "ORLANDO_STAR_VALID_PASS_#"
)

data class UserProfile(
    val name: String = "Elena Mercer",
    val homeStationId: String = "SAN-01", // Sanford
    val workStationId: String = "LYN-01", // LYNX Central
    val favoriteStations: List<String> = listOf("SAN-01", "LYN-01", "WPK-01"),
    val favoriteRoutes: List<String> = listOf("SunRail-North", "LYNX-11"),
    val accessibilityPreferences: Set<String> = emptySet(), // "wheelchair", "avoid_stairs", "elevators_only", "visual"
    val notificationPreferences: Boolean = true,
    val savedTrips: List<JourneyPlan> = emptyList()
)
