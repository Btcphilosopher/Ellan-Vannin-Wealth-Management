package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.JourneySegment
import com.example.domain.TransportMode
import com.example.engine.SimulationEngine

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlannerScreen(
    initialFromId: String? = null,
    initialToId: String? = null
) {
    val state by SimulationEngine.state.collectAsState()
    val scrollState = rememberScrollState()

    // Planner UI states
    var fromStationId by remember { mutableStateOf(initialFromId ?: "SAN-01") }
    var toStationId by remember { mutableStateOf(initialToId ?: "LYN-01") }
    var selectedPriority by remember { mutableStateOf("FASTEST") }
    var isWheelchairChecked by remember { mutableStateOf(false) }
    
    // Dropdown triggers
    var fromMenuExpanded by remember { mutableStateOf(false) }
    var toMenuExpanded by remember { mutableStateOf(false) }

    // Synchronize initials if navigated from Home
    LaunchedEffect(initialFromId, initialToId) {
        if (initialFromId != null) fromStationId = initialFromId
        if (initialToId != null) toStationId = initialToId
    }

    // Dynamic Route Calculation
    val calculatedPlan = remember(fromStationId, toStationId, selectedPriority, isWheelchairChecked, state.alerts, state.weather, state.activeScenario, state.stations) {
        val prefs = if (isWheelchairChecked) setOf("wheelchair", "elevators_only") else emptySet()
        SimulationEngine.calculateRoute(fromStationId, toStationId, prefs, selectedPriority)
    }

    if (state.activeJourneyPlan != null) {
        // -------------------------------------------------------------
        // LIVE JOURNEY MODE (SIMPLIFIED IN-TRIP SCREEN)
        // -------------------------------------------------------------
        val activePlan = state.activeJourneyPlan!!
        val currentIndex = state.liveJourneySegmentIndex
        val segment = activePlan.segments.getOrNull(currentIndex)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.primary) // Aerospace deep navy background for focus
                .padding(24.dp)
                .padding(bottom = 80.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Upper details
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "LIVE JOURNEY MODE",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.tertiary
                    )
                    
                    Box(
                        modifier = Modifier
                            .background(Color(0x30FFFFFF), RoundedCornerShape(20.dp))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            "${activePlan.totalDurationMinutes} min total",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Divider(color = Color(0x30FFFFFF))

                // Progress Indicator (WALK -> BOARD -> RIDE -> TRANSFER -> ARRIVE)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    activePlan.segments.forEachIndexed { idx, seg ->
                        val isPast = idx < currentIndex
                        val isCurrent = idx == currentIndex
                        val circleColor = when {
                            isCurrent -> MaterialTheme.colorScheme.tertiary
                            isPast -> Color(0xFF1E5631)
                            else -> Color(0x40FFFFFF)
                        }

                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .background(circleColor, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    when (seg.mode) {
                                        TransportMode.WALK -> Icons.Default.DirectionsWalk
                                        TransportMode.CYCLE -> Icons.Default.DirectionsBike
                                        TransportMode.SUNRAIL -> Icons.Default.DirectionsTransit
                                        else -> Icons.Default.DirectionsBus
                                    },
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Text(
                                if (idx == 0) "Start" else if (idx == activePlan.segments.size - 1) "Arrive" else "Way",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isCurrent) Color.White else Color(0x80FFFFFF)
                            )
                        }

                        if (idx < activePlan.segments.size - 1) {
                            Box(
                                modifier = Modifier
                                    .height(2.dp)
                                    .weight(1f)
                                    .background(if (isPast) Color(0xFF1E5631) else Color(0x30FFFFFF))
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // CURRENT STEP CARD
                if (segment != null) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Column(modifier = Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                            Text(
                                "NEXT ACTION",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )

                            Text(
                                segment.instructions,
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFF0A2342)
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Default.Schedule,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.tertiary
                                    )
                                    Text(
                                        "Duration: ${segment.durationMinutes} mins",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF0A2342)
                                    )
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Default.Signpost,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        "${String.format("%.1f", segment.distanceMiles)} mi",
                                        style = MaterialTheme.typography.bodyLarge,
                                        color = Color.Gray
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Lower controls
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = { SimulationEngine.advanceLiveJourney() },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        if (currentIndex == activePlan.segments.size - 1) "FINISH JOURNEY" else "NEXT SEGMENT",
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                OutlinedButton(
                    onClick = { SimulationEngine.setActiveJourney(null) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                    border = BorderStroke(1.dp, Color.White),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("END TRIP", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                }
            }
        }
    } else {
        // -------------------------------------------------------------
        // PLANNER VIEW (INPUTS AND RESULTS)
        // -------------------------------------------------------------
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(scrollState)
                .padding(16.dp)
                .padding(bottom = 80.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                "TRIP PLANNER",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.primary
            )

            // Station Selector Panel Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    // From Selector
                    Box {
                        OutlinedTextField(
                            value = state.stations[fromStationId]?.name ?: "Select Origin",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("FROM") },
                            leadingIcon = { Icon(Icons.Default.MyLocation, contentDescription = null, tint = MaterialTheme.colorScheme.secondary) },
                            trailingIcon = { Icon(Icons.Default.ArrowDropDown, contentDescription = null) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { fromMenuExpanded = true },
                            enabled = false, // capture click on box
                            colors = OutlinedTextFieldDefaults.colors(
                                disabledTextColor = MaterialTheme.colorScheme.onSurface,
                                disabledBorderColor = Color(0xFFD1D5DB),
                                disabledLabelColor = MaterialTheme.colorScheme.primary
                            )
                        )
                        DropdownMenu(
                            expanded = fromMenuExpanded,
                            onDismissRequest = { fromMenuExpanded = false }
                        ) {
                            state.stations.values.sortedBy { it.name }.forEach { station ->
                                DropdownMenuItem(
                                    text = { Text(station.name, fontWeight = FontWeight.Medium) },
                                    onClick = {
                                        fromStationId = station.id
                                        fromMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Swap Button
                    IconButton(
                        onClick = {
                            val temp = fromStationId
                            fromStationId = toStationId
                            toStationId = temp
                        },
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    ) {
                        Icon(Icons.Default.SwapVert, contentDescription = "Swap Locations", tint = MaterialTheme.colorScheme.tertiary)
                    }

                    // To Selector
                    Box {
                        OutlinedTextField(
                            value = state.stations[toStationId]?.name ?: "Select Destination",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("TO") },
                            leadingIcon = { Icon(Icons.Default.PinDrop, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary) },
                            trailingIcon = { Icon(Icons.Default.ArrowDropDown, contentDescription = null) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { toMenuExpanded = true },
                            enabled = false, // capture click on box
                            colors = OutlinedTextFieldDefaults.colors(
                                disabledTextColor = MaterialTheme.colorScheme.onSurface,
                                disabledBorderColor = Color(0xFFD1D5DB),
                                disabledLabelColor = MaterialTheme.colorScheme.primary
                            )
                        )
                        DropdownMenu(
                            expanded = toMenuExpanded,
                            onDismissRequest = { toMenuExpanded = false }
                        ) {
                            state.stations.values.sortedBy { it.name }.forEach { station ->
                                DropdownMenuItem(
                                    text = { Text(station.name, fontWeight = FontWeight.Medium) },
                                    onClick = {
                                        toStationId = station.id
                                        toMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Preferences Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = isWheelchairChecked,
                            onCheckedChange = { isWheelchairChecked = it }
                        )
                        Text(
                            "Wheelchair Accessible / Avoid Stairs",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            // Route Priority Scroll Row
            val priorities = listOf(
                "FASTEST" to "Fastest",
                "FEWEST_TRANSFERS" to "Fewest Transfers",
                "LEAST_WALKING" to "Least Walking",
                "ACCESSIBLE" to "Accessible Route",
                "LOWEST_FARE" to "Lowest Fare"
            )
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(priorities) { (id, label) ->
                    val isSelected = selectedPriority == id
                    val containerCol = if (isSelected) MaterialTheme.colorScheme.primary else Color(0xFFE5E7EB)
                    val contentCol = if (isSelected) Color.White else Color(0xFF4B5563)

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(containerCol)
                            .clickable { selectedPriority = id }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text(
                            label,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = contentCol
                        )
                    }
                }
            }

            // ALERTS/DISRUPTIONS WARNING IN ROUTE IF AFFECTED
            AnimatedVisibility(visible = calculatedPlan.isAffectedByAlert) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                            Text("ROUTE DISRUPTED", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                        }
                        Text(
                            calculatedPlan.alertDetails ?: "A service alert affects this journey segment.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
            }

            // calculated route metrics summary
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, Color(0xFFE5E7EB))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("SUGGESTED ROUTE", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Text(
                                "${calculatedPlan.totalDurationMinutes} min journey",
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFF0A2342)
                            )
                        }
                        
                        Box(
                            modifier = Modifier
                                .background(Color(0xFF1E5631), RoundedCornerShape(8.dp))
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                "SIMULATED FARE: $${String.format("%.2f", calculatedPlan.simulatedFare)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Key metrics bullets
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        BulletMetric(Icons.Default.DirectionsWalk, "Walk time", "${calculatedPlan.walkingTimeMinutes} min")
                        BulletMetric(Icons.Default.TransferWithinAStation, "Transfers", "${calculatedPlan.transfersCount}")
                        BulletMetric(Icons.Default.Shield, "Reliability", calculatedPlan.reliabilityIndicator)
                        BulletMetric(
                            if (calculatedPlan.accessibility.contains("Not")) Icons.Default.Block else Icons.Default.Accessible,
                            "Access",
                            if (calculatedPlan.accessibility.contains("Not")) "Stairs" else "Wheelchair"
                        )
                    }

                    Divider(color = Color(0xFFE5E7EB))

                    // TRIP TIMELINE STAGES (DWELLS AND WALKS)
                    Text(
                        "TRIP TIMELINE",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Column(
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        calculatedPlan.segments.forEachIndexed { index, segment ->
                            TimelineSegmentRow(segment = segment)
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Button(
                        onClick = { SimulationEngine.setActiveJourney(calculatedPlan) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("start_trip_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("START LIVE JOURNEY", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
fun BulletMetric(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(20.dp), tint = Color(0xFF0A2342))
        Text(label, style = MaterialTheme.typography.labelSmall, fontSize = 8.sp, color = Color.Gray)
        Text(value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = Color(0xFF0A2342))
    }
}

@Composable
fun TimelineSegmentRow(segment: JourneySegment) {
    val modeColor = when (segment.mode) {
        TransportMode.SUNRAIL -> Color(0xFF1E5631)
        TransportMode.LYNX -> Color(0xFF0A2342)
        TransportMode.LYMMO -> Color(0xFFD95A2B)
        TransportMode.MICROTRANSIT -> Color(0xFF8B5CF6)
        TransportMode.CYCLE -> Color(0xFF10B981)
        else -> Color.Gray
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.Top
    ) {
        // Vertical node marker
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(16.dp)
                    .background(modeColor, CircleShape)
            )
            Box(
                modifier = Modifier
                    .width(2.dp)
                    .height(36.dp)
                    .background(Color(0xFFD1D5DB))
            )
        }

        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    segment.fromStationName,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0A2342)
                )
                Text(
                    "${segment.durationMinutes} min",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.Gray
                )
            }

            Text(
                segment.instructions,
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray
            )

            // Elevator/Accessibility Status Flag
            if (segment.elevatorStatus == "Out of Service") {
                Row(
                    modifier = Modifier.padding(top = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Error,
                        contentDescription = "Elevator failed",
                        tint = Color(0xFFEF4444),
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        "Elevator Out of Service here",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFFEF4444),
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
