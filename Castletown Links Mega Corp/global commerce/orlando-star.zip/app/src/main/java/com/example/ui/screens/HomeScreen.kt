package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.AlertSeverity
import com.example.engine.SimulationEngine

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onNavigateToPlan: (fromId: String, toId: String) -> Unit,
    onNavigateToMore: () -> Unit
) {
    val state by SimulationEngine.state.collectAsState()
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(scrollState)
            .padding(16.dp)
            .padding(bottom = 80.dp), // Clear bottom bar insets
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // App Identity Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                // 4-Point Abstract Star Logo Vector
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.Star,
                        contentDescription = "Orlando Star Logo",
                        tint = MaterialTheme.colorScheme.tertiary,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Column {
                    Text(
                        "ORLANDO STAR",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        "CONCEPT PROTOTYPE · SYNTHETIC DATA",
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 8.sp,
                        color = MaterialTheme.colorScheme.tertiary
                    )
                }
            }
            
            // Weather Pill Quick Display
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f))
                    .clickable { onNavigateToMore() }
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        when (state.weather) {
                            com.example.domain.WeatherState.CLEAR -> Icons.Default.LightMode
                            com.example.domain.WeatherState.HOT -> Icons.Default.WbSunny
                            else -> Icons.Default.Cloud
                        },
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.tertiary,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        state.weather.label,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        // Friendly Greeting
        Column {
            Text(
                "Good morning, ${state.userProfile.name}",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                "Where are you going today?",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
            )
        }

        // "Where to?" Search Field Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("where_to_search_box"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFF3F4F6), RoundedCornerShape(12.dp))
                        .padding(12.dp)
                        .clickable { onNavigateToPlan("SAN-01", "MCO-01") } // Sanford to Airport by default
                ) {
                    Icon(Icons.Default.Search, contentDescription = "Search icon", tint = Color.Gray)
                    Text("Where to?", color = Color.Gray, style = MaterialTheme.typography.bodyLarge)
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    "QUICK DESTINATIONS",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                
                Spacer(modifier = Modifier.height(8.dp))

                // Scrollable row of quick locations
                val quickDestinations = listOf(
                    "Downtown Orlando" to "LYN-01",
                    "Airport MCO" to "MCO-01",
                    "Winter Park" to "WPK-01",
                    "Lake Mary" to "LMR-01",
                    "UCF Campus" to "UCF-01",
                    "Universal Area" to "UNI-01",
                    "Disney Springs" to "DIS-01"
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(end = 16.dp)
                ) {
                    items(quickDestinations) { dest ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.05f))
                                .clickable {
                                    // Navigate to plan with Home Station to Quick Destination
                                    onNavigateToPlan(state.userProfile.homeStationId, dest.second)
                                }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                dest.first,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        }

        // Active Alerts Banner (Propagated from engine)
        val criticalAlerts = state.alerts.filter { it.severity == AlertSeverity.CRITICAL || it.severity == AlertSeverity.MAJOR }
        AnimatedVisibility(visible = criticalAlerts.isNotEmpty()) {
            val alert = criticalAlerts.firstOrNull() ?: return@AnimatedVisibility
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Warning,
                        contentDescription = "Critical Alert",
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(28.dp)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "YOUR TRIP MAY BE AFFECTED",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                        Text(
                            alert.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.8f)
                        )
                    }
                }
            }
        }

        // NEXT DEPARTURES
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                "NEXT DEPARTURES",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            
            // LYNX Central Departure Card
            DepartureRowCard(
                stationName = "LYNX Central Hub",
                modeLabel = "SunRail Train",
                direction = "Northbound (P302)",
                timeRemaining = "6 min",
                modeColor = Color(0xFF1E5631),
                delayMinutes = state.vehicles.firstOrNull { it.id == "P302" }?.delayMinutes ?: 0
            )

            // Church Street Departure Card
            DepartureRowCard(
                stationName = "Church Street Station",
                modeLabel = "SunRail Train",
                direction = "Southbound (P305)",
                timeRemaining = "14 min",
                modeColor = Color(0xFF1E5631),
                delayMinutes = state.vehicles.firstOrNull { it.id == "P305" }?.delayMinutes ?: 0
            )

            // LYNX 11 Departure Card
            DepartureRowCard(
                stationName = "Sand Lake Road Station",
                modeLabel = "LYNX Bus 11",
                direction = "Eastbound (MCO Airport)",
                timeRemaining = "8 min",
                modeColor = Color(0xFF0A2342),
                delayMinutes = state.vehicles.firstOrNull { it.id == "LYNX-4217" }?.delayMinutes ?: 0
            )
        }

        // COMMUTE FAVORITE WIDGET
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                "MY FAVORITE COMMUTE",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateToPlan("SAN-01", "LYN-01") }, // Home to Work
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Work, contentDescription = "Work Commute", tint = MaterialTheme.colorScheme.primary)
                            Text(
                                "HOME → WORK",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Box(
                            modifier = Modifier
                                .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                "8 min left",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        "Sanford Station to LYNX Central",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.8f)
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            Icons.Default.DirectionsTransit,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            "SunRail South · 35 min total · $3.50 simulated fare",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DepartureRowCard(
    stationName: String,
    modeLabel: String,
    direction: String,
    timeRemaining: String,
    modeColor: Color,
    delayMinutes: Int
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, Color(0xFFE5E7EB))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .background(modeColor, RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            modeLabel,
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        stationName,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray,
                        fontWeight = FontWeight.Medium
                    )
                }
                
                Text(
                    direction,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0A2342)
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    timeRemaining,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Black,
                    color = if (delayMinutes > 5) Color(0xFFEF4444) else Color(0xFF1E5631)
                )
                if (delayMinutes > 0) {
                    Text(
                        "+$delayMinutes min delayed",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFEF4444),
                        fontWeight = FontWeight.Bold
                    )
                } else {
                    Text(
                        "On Time",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF1E5631)
                    )
                }
            }
        }
    }
}
