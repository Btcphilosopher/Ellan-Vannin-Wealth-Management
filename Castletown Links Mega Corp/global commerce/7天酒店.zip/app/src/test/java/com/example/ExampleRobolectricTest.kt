package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.SearchCriteria
import com.example.data.model.SortOption
import com.example.data.repository.HotelRepository
import kotlinx.coroutines.flow.flowOf
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("7天酒店", appName)
  }

  @Test
  fun `hotel repository returns verified branches`() {
    val mockSavedDao = object : com.example.data.local.SavedHotelDao {
      override fun getSavedHotelIdsFlow() = flowOf(emptyList<String>())
      override suspend fun isHotelSaved(hotelId: String) = false
      override suspend fun saveHotel(entity: com.example.data.local.SavedHotelEntity) {}
      override suspend fun removeSavedHotel(hotelId: String) {}
    }
    val repo = HotelRepository(mockSavedDao)

    // Test search by Shanghai
    val shanghaiHotels = repo.searchHotels(SearchCriteria(city = "上海"))
    assertTrue("Should find Shanghai branches", shanghaiHotels.isNotEmpty())

    // Test hotel details
    val hotel = repo.getHotelById("sh-01")
    assertNotNull(hotel)
    assertEquals("7天酒店·上海人民广场南京东路步行街店", hotel?.name)

    // Test rooms and inventory
    val rooms = repo.getRoomsForHotel("sh-01")
    assertTrue("Should have room types", rooms.isNotEmpty())
    val economyRoom = rooms.first { it.id == "sh-01-r1" }
    assertEquals(148, economyRoom.pricePerNight)

    // Test rate plans (95 discount for member)
    val plans = repo.getRatePlansForRoom(economyRoom)
    val memberPlan = plans.first { it.id.contains("member") }
    assertEquals((148 * 0.95).toInt(), memberPlan.price)
  }
}
