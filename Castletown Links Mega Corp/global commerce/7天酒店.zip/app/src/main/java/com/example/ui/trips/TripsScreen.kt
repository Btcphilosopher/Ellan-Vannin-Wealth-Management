package com.example.ui.trips

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.CalendarContract
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.Booking
import com.example.data.model.BookingStatus
import com.example.data.repository.BookingRepository
import com.example.ui.components.PriceDisplay
import com.example.ui.components.SevenDaysHeaderBar
import com.example.ui.components.StatusBadge
import com.example.ui.theme.BrandCharcoal
import com.example.ui.theme.BrandGreen
import com.example.ui.theme.BrandRed
import com.example.ui.theme.BrandYellowContainer
import com.example.ui.theme.BrandYellowPrimary
import com.example.ui.theme.NeutralBg
import com.example.ui.theme.NeutralBorder
import com.example.ui.theme.NeutralSurface
import com.example.ui.theme.NeutralTextMuted
import com.example.ui.theme.NeutralTextPrimary
import com.example.ui.theme.NeutralTextSecondary
import kotlinx.coroutines.launch

@Composable
fun TripsScreen(
    bookingRepository: BookingRepository,
    onBookNewTripClick: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val bookings by bookingRepository.allBookings.collectAsState(initial = emptyList())

    var selectedTab by remember { mutableStateOf("全部") }
    var bookingToCancel by remember { mutableStateOf<Booking?>(null) }
    var qrDialogBooking by remember { mutableStateOf<Booking?>(null) }

    val tabs = listOf("全部", "待出行", "已完成", "已取消")

    val filteredBookings = remember(bookings, selectedTab) {
        when (selectedTab) {
            "全部" -> bookings
            "待出行" -> bookings.filter { it.status == BookingStatus.CONFIRMED || it.status == BookingStatus.PENDING }
            "已完成" -> bookings.filter { it.status == BookingStatus.COMPLETED }
            "已取消" -> bookings.filter { it.status == BookingStatus.CANCELLED }
            else -> bookings
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NeutralBg)
            .testTag("trips_screen")
    ) {
        // Header
        SevenDaysHeaderBar(
            title = "我的行程",
            subtitle = "订房凭证 · 离线可查 · 自助入住",
            showLogo = true
        )

        // Offline Status Sync Notice
        Surface(
            color = Color(0xFFF3F4F6),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.CloudDone,
                    contentDescription = null,
                    tint = BrandGreen,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "所有已确认行程已本地持久化缓存，无网络环境依然可查",
                    fontSize = 11.sp,
                    color = NeutralTextSecondary
                )
            }
        }

        // Tabs Row
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .background(NeutralSurface)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(tabs) { tab ->
                val isSelected = selectedTab == tab
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (isSelected) BrandYellowPrimary else NeutralBg)
                        .clickable { selectedTab = tab }
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = tab,
                        fontSize = 13.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) BrandCharcoal else NeutralTextSecondary
                    )
                }
            }
        }

        if (filteredBookings.isEmpty()) {
            EmptyTripsView(onBookClick = onBookNewTripClick)
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(filteredBookings) { booking ->
                    TripBookingCard(
                        booking = booking,
                        onShowQr = { qrDialogBooking = booking },
                        onCancelClick = { bookingToCancel = booking },
                        onCopyRef = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = ClipData.newPlainText("订单号", booking.bookingReference)
                            clipboard.setPrimaryClip(clip)
                            Toast.makeText(context, "已复制订单编号: ${booking.bookingReference}", Toast.LENGTH_SHORT).show()
                        },
                        onNavigateToHotel = {
                            val uri = Uri.parse("geo:0,0?q=${Uri.encode(booking.hotelName + " " + booking.hotelAddress)}")
                            val intent = Intent(Intent.ACTION_VIEW, uri)
                            try {
                                context.startActivity(intent)
                            } catch (_: Exception) {
                                Toast.makeText(context, "目标地址: ${booking.hotelAddress}", Toast.LENGTH_LONG).show()
                            }
                        },
                        onAddToCalendar = {
                            val intent = Intent(Intent.ACTION_INSERT)
                                .setData(CalendarContract.Events.CONTENT_URI)
                                .putExtra(CalendarContract.Events.TITLE, "入住${booking.hotelName}")
                                .putExtra(CalendarContract.Events.EVENT_LOCATION, booking.hotelAddress)
                                .putExtra(CalendarContract.Events.DESCRIPTION, "7天酒店预订订单: ${booking.bookingReference}，房型: ${booking.roomTypeName}")
                            try {
                                context.startActivity(intent)
                            } catch (_: Exception) {
                                Toast.makeText(context, "已记录入驻日程: ${booking.checkInDate}", Toast.LENGTH_SHORT).show()
                            }
                        }
                    )
                }
                item {
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }
    }

    // Cancel Booking Dialog
    if (bookingToCancel != null) {
        val b = bookingToCancel!!
        AlertDialog(
            onDismissRequest = { bookingToCancel = null },
            title = { Text("确认取消预订？", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("订单号: ${b.bookingReference}", fontSize = 12.sp, color = NeutralTextSecondary)
                    Text("酒店: ${b.hotelName}", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("退款规则: ${b.cancellationPolicyDesc}。取消后系统将自动原路全额退款至原支付渠道，并释放房间库存。", fontSize = 12.sp, color = BrandCharcoal)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        scope.launch {
                            val res = bookingRepository.cancelBooking(b)
                            res.onSuccess {
                                Toast.makeText(context, "订单已取消，退款将自动原路返回", Toast.LENGTH_LONG).show()
                            }.onFailure {
                                Toast.makeText(context, "取消失败: ${it.message}", Toast.LENGTH_SHORT).show()
                            }
                            bookingToCancel = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BrandRed)
                ) {
                    Text("确认取消并退款")
                }
            },
            dismissButton = {
                TextButton(onClick = { bookingToCancel = null }) {
                    Text("保留行程")
                }
            }
        )
    }

    // QR Code Dialog
    if (qrDialogBooking != null) {
        val b = qrDialogBooking!!
        AlertDialog(
            onDismissRequest = { qrDialogBooking = null },
            title = { Text("自助办理入住", fontWeight = FontWeight.Bold) },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = BrandCharcoal,
                        modifier = Modifier.padding(vertical = 10.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.QrCode,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(110.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = b.checkInQrCode,
                                color = BrandYellowPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Text("请在前台自助机扫描此码，或报手机号快速取房卡", fontSize = 12.sp, color = NeutralTextSecondary)
                }
            },
            confirmButton = {
                Button(
                    onClick = { qrDialogBooking = null },
                    colors = ButtonDefaults.buttonColors(containerColor = BrandYellowPrimary, contentColor = BrandCharcoal)
                ) {
                    Text("完成")
                }
            }
        )
    }
}

@Composable
fun TripBookingCard(
    booking: Booking,
    onShowQr: () -> Unit,
    onCancelClick: () -> Unit,
    onCopyRef: () -> Unit,
    onNavigateToHotel: () -> Unit,
    onAddToCalendar: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("trip_card_${booking.bookingReference}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = NeutralSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header with status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "订单: ${booking.bookingReference}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = NeutralTextSecondary
                    )
                    IconButton(onClick = onCopyRef, modifier = Modifier.size(24.dp)) {
                        Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "复制", tint = NeutralTextMuted, modifier = Modifier.size(14.dp))
                    }
                }
                StatusBadge(status = booking.status)
            }

            Spacer(modifier = Modifier.height(8.dp))
            Divider(color = NeutralBorder, thickness = 0.8.dp)
            Spacer(modifier = Modifier.height(10.dp))

            // Hotel & Room summary
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top
            ) {
                Image(
                    painter = painterResource(id = booking.roomImageRes),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(70.dp)
                        .clip(RoundedCornerShape(8.dp))
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = booking.hotelName,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = NeutralTextPrimary
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${booking.roomTypeName} · ${booking.roomCount}间",
                        fontSize = 12.sp,
                        color = NeutralTextSecondary
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "入住日期: ${booking.checkInDate} 至 ${booking.checkOutDate} (${booking.nightsCount}晚)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = BrandCharcoal
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Address and Guest
            Text(
                text = "地址: ${booking.hotelAddress}",
                fontSize = 11.sp,
                color = NeutralTextSecondary
            )
            Text(
                text = "入住人: ${booking.guestName} · 总价 ¥${booking.totalPrice} (${booking.paymentMethod.labelZh})",
                fontSize = 11.sp,
                color = NeutralTextSecondary
            )

            Spacer(modifier = Modifier.height(12.dp))
            Divider(color = NeutralBorder, thickness = 0.8.dp)
            Spacer(modifier = Modifier.height(10.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Secondary actions
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = onNavigateToHotel,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Directions, contentDescription = null, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(text = "导航", fontSize = 11.sp)
                    }

                    OutlinedButton(
                        onClick = onAddToCalendar,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Icon(imageVector = Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(text = "日历", fontSize = 11.sp)
                    }
                }

                // Primary actions: Show QR or Cancel
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (booking.status == BookingStatus.CONFIRMED) {
                        TextButton(
                            onClick = onCancelClick,
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text(text = "取消预订", color = BrandRed, fontSize = 12.sp)
                        }

                        Button(
                            onClick = onShowQr,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = BrandYellowPrimary,
                                contentColor = BrandCharcoal
                            ),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Icon(imageVector = Icons.Default.QrCode, contentDescription = null, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(text = "入住码", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EmptyTripsView(
    onBookClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(70.dp)
                .clip(CircleShape)
                .background(BrandYellowContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Schedule,
                contentDescription = null,
                tint = BrandCharcoal,
                modifier = Modifier.size(36.dp)
            )
        }
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "暂无相关行程",
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            color = NeutralTextPrimary
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "立即预订7天酒店，开启好睡省钱的惬意旅程",
            fontSize = 13.sp,
            color = NeutralTextSecondary
        )
        Spacer(modifier = Modifier.height(20.dp))
        Button(
            onClick = onBookClick,
            colors = ButtonDefaults.buttonColors(
                containerColor = BrandYellowPrimary,
                contentColor = BrandCharcoal
            ),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text(text = "去预订酒店", fontWeight = FontWeight.Bold)
        }
    }
}
