package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardTravel
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Hotel
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SearchCriteria
import com.example.data.repository.BookingRepository
import com.example.data.repository.ExploreRepository
import com.example.data.repository.HotelRepository
import com.example.data.repository.UserRepository
import com.example.ui.account.AccountScreen
import com.example.ui.booking.BookingFlowScreen
import com.example.ui.detail.HotelDetailScreen
import com.example.ui.explore.ExploreScreen
import com.example.ui.home.HomeScreen
import com.example.ui.hotels.HotelsScreen
import com.example.ui.theme.BrandCharcoal
import com.example.ui.theme.BrandYellowPrimary
import com.example.ui.theme.NeutralBorder
import com.example.ui.theme.NeutralTextSecondary
import com.example.ui.trips.TripsScreen

sealed class NavigationTab(val route: String, val titleZh: String, val titleEn: String, val icon: ImageVector) {
    data object Home : NavigationTab("home", "首页", "Home", Icons.Default.Home)
    data object Hotels : NavigationTab("hotels", "酒店", "Hotels", Icons.Default.Hotel)
    data object Trips : NavigationTab("trips", "行程", "Trips", Icons.Default.CardTravel)
    data object Explore : NavigationTab("explore", "旅行", "Explore", Icons.Default.Explore)
    data object Account : NavigationTab("account", "我的", "My Account", Icons.Default.Person)
}

sealed class SubScreen {
    data class HotelDetail(val hotelId: String) : SubScreen()
    data class BookingFlow(val hotelId: String, val roomId: String, val ratePlanId: String? = null) : SubScreen()
}

@Composable
fun MainApp(
    hotelRepository: HotelRepository,
    bookingRepository: BookingRepository,
    exploreRepository: ExploreRepository,
    userRepository: UserRepository
) {
    var selectedTab by remember { mutableStateOf<NavigationTab>(NavigationTab.Home) }
    var currentSubScreen by remember { mutableStateOf<SubScreen?>(null) }
    var searchCriteria by remember { mutableStateOf(SearchCriteria()) }
    var exploreInitialCity by remember { mutableStateOf("shanghai") }

    val user by userRepository.userState.collectAsState()

    // Handle back button for sub-screens
    if (currentSubScreen != null) {
        BackHandler {
            currentSubScreen = null
        }
    }

    Scaffold(
        bottomBar = {
            if (currentSubScreen == null) {
                NavigationBar(
                    containerColor = BrandCharcoal,
                    tonalElevation = 8.dp,
                    modifier = Modifier.testTag("bottom_nav_bar")
                ) {
                    val tabs = listOf(
                        NavigationTab.Home,
                        NavigationTab.Hotels,
                        NavigationTab.Trips,
                        NavigationTab.Explore,
                        NavigationTab.Account
                    )
                    tabs.forEach { tab ->
                        val isSelected = selectedTab == tab
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { selectedTab = tab },
                            icon = {
                                Icon(
                                    imageVector = tab.icon,
                                    contentDescription = if (user.isEnglish) tab.titleEn else tab.titleZh,
                                    modifier = Modifier.size(22.dp)
                                )
                            },
                            label = {
                                Text(
                                    text = if (user.isEnglish) tab.titleEn else tab.titleZh,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = BrandCharcoal,
                                selectedTextColor = BrandYellowPrimary,
                                unselectedIconColor = Color(0xFF9CA3AF),
                                unselectedTextColor = Color(0xFF9CA3AF),
                                indicatorColor = BrandYellowPrimary
                            ),
                            modifier = Modifier.testTag("nav_tab_${tab.route}")
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (val sub = currentSubScreen) {
                is SubScreen.HotelDetail -> {
                    HotelDetailScreen(
                        hotelId = sub.hotelId,
                        hotelRepository = hotelRepository,
                        onBackClick = { currentSubScreen = null },
                        onBookRoomClick = { hotelId, roomId, planId ->
                            currentSubScreen = SubScreen.BookingFlow(hotelId, roomId, planId)
                        }
                    )
                }

                is SubScreen.BookingFlow -> {
                    BookingFlowScreen(
                        hotelId = sub.hotelId,
                        roomId = sub.roomId,
                        ratePlanId = sub.ratePlanId,
                        hotelRepository = hotelRepository,
                        bookingRepository = bookingRepository,
                        userRepository = userRepository,
                        onBackClick = { currentSubScreen = null },
                        onBookingSuccessToTrips = {
                            currentSubScreen = null
                            selectedTab = NavigationTab.Trips
                        },
                        onGoHome = {
                            currentSubScreen = null
                            selectedTab = NavigationTab.Home
                        }
                    )
                }

                null -> {
                    when (selectedTab) {
                        NavigationTab.Home -> {
                            HomeScreen(
                                hotelRepository = hotelRepository,
                                bookingRepository = bookingRepository,
                                onNavigateToSearch = { criteria ->
                                    searchCriteria = criteria
                                    selectedTab = NavigationTab.Hotels
                                },
                                onNavigateToHotelDetail = { hotelId ->
                                    currentSubScreen = SubScreen.HotelDetail(hotelId)
                                },
                                onNavigateToRoomBooking = { hotelId, roomId ->
                                    currentSubScreen = SubScreen.BookingFlow(hotelId, roomId)
                                },
                                onNavigateToTrips = {
                                    selectedTab = NavigationTab.Trips
                                },
                                onNavigateToExploreCity = { cityId ->
                                    exploreInitialCity = cityId
                                    selectedTab = NavigationTab.Explore
                                }
                            )
                        }

                        NavigationTab.Hotels -> {
                            HotelsScreen(
                                hotelRepository = hotelRepository,
                                initialCriteria = searchCriteria,
                                onHotelClick = { hotelId ->
                                    currentSubScreen = SubScreen.HotelDetail(hotelId)
                                }
                            )
                        }

                        NavigationTab.Trips -> {
                            TripsScreen(
                                bookingRepository = bookingRepository,
                                onBookNewTripClick = {
                                    selectedTab = NavigationTab.Hotels
                                }
                            )
                        }

                        NavigationTab.Explore -> {
                            ExploreScreen(
                                exploreRepository = exploreRepository,
                                initialCityId = exploreInitialCity
                            )
                        }

                        NavigationTab.Account -> {
                            AccountScreen(
                                userRepository = userRepository,
                                onNavigateToTrips = {
                                    selectedTab = NavigationTab.Trips
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
