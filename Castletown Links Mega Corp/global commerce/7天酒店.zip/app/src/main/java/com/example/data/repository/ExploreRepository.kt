package com.example.data.repository

import com.example.data.local.ItineraryDao
import com.example.data.local.ItineraryEntity
import com.example.data.model.Attraction
import com.example.data.model.DiningSpot
import com.example.data.model.ExploreCity
import com.example.data.model.ItineraryItem
import com.example.data.model.TransportTip
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class ExploreRepository(
    private val itineraryDao: ItineraryDao
) {
    val itineraryFlow: Flow<List<ItineraryItem>> = itineraryDao.getAllItineraryFlow().map { list ->
        list.map {
            ItineraryItem(
                id = it.id,
                city = it.city,
                tripDate = it.tripDate,
                timeSlot = it.timeSlot,
                title = it.title,
                category = it.category,
                notes = it.notes,
                isCompleted = it.isCompleted
            )
        }
    }

    suspend fun addItineraryItem(item: ItineraryItem) {
        itineraryDao.insertItem(
            ItineraryEntity(
                city = item.city,
                tripDate = item.tripDate,
                timeSlot = item.timeSlot,
                title = item.title,
                category = item.category,
                notes = item.notes,
                isCompleted = false
            )
        )
    }

    suspend fun toggleItineraryItem(item: ItineraryItem) {
        itineraryDao.updateItem(
            ItineraryEntity(
                id = item.id,
                city = item.city,
                tripDate = item.tripDate,
                timeSlot = item.timeSlot,
                title = item.title,
                category = item.category,
                notes = item.notes,
                isCompleted = !item.isCompleted
            )
        )
    }

    suspend fun deleteItineraryItem(id: Long) {
        itineraryDao.deleteItem(id)
    }

    fun getAllCities(): List<ExploreCity> = cityGuides

    fun getCityById(id: String): ExploreCity? = cityGuides.find { it.id == id }

    private val cityGuides = listOf(
        ExploreCity(
            id = "shanghai",
            name = "Shanghai",
            nameZh = "上海",
            tag = "魔都漫游 · 摩登与烟火",
            description = "海派文化交融之都，从外滩万国建筑博览群到陆家嘴摩天大楼，再到梧桐区静谧小弄堂，好住省钱也能畅玩经典路线。",
            hotelCount = 42,
            attractions = listOf(
                Attraction("外滩观景平台", "必游地标", "地铁2/10号线南京东路站", "饱览陆家嘴天际线与东方明珠灯光秀，夜景璀璨，全天免费开放", "免费开放"),
                Attraction("南京东路步行街", "老字号聚集", "地铁1/2/8号线人民广场站", "中国商业第一街，集聚沈大成、真老大房等百年传统名点", "免费逛街"),
                Attraction("豫园与城隍庙", "江南园林古风", "地铁10/14号线豫园站", "明代私家江南园林，周边九曲桥品茶尝南翔小笼包", "门票约30-40元")
            ),
            diningRecommendations = listOf(
                DiningSpot("大壶春 (四川中路店)", "非遗生煎 · 鲜肉大虾生煎包", "人均 ¥22", "距人民广场店步行10分钟"),
                DiningSpot("小绍兴白斩鸡", "上海经典白斩鸡与鸡粥", "人均 ¥38", "云南南路美食街"),
                DiningSpot("莱莱小笼", "蟹粉鲜肉小笼与纯蟹膏汤包", "人均 ¥45", "天津路老居民区")
            ),
            transportGuides = listOf(
                TransportTip("高铁抵达", "上海虹桥站 / 上海站", "虹桥枢纽乘坐地铁2号线直达人民广场与南京东路（约35分钟）；上海站乘地铁1号线仅3站即达"),
                TransportTip("机场接驳", "浦东机场 / 虹桥机场", "浦东机场乘2号线或磁浮列车快捷通达市区；虹桥机场紧邻虹桥高铁枢纽"),
                TransportTip("市区地铁", "大都会App / 乘车码", "上海地铁网络密集，各7天酒店分店均在地铁站步行500米圈内")
            )
        ),
        ExploreCity(
            id = "beijing",
            name = "Beijing",
            nameZh = "北京",
            tag = "千年古都 · 宏伟中轴线",
            description = "红墙金瓦与胡同胡同巷陌，天安门、故宫、天坛连缀起东方文明底蕴，住在前门老街，清晨看升旗无需赶早。",
            hotelCount = 38,
            attractions = listOf(
                Attraction("天安门广场 & 升旗仪式", "国家地标", "地铁2/8号线前门站", "迎着晨曦瞻仰庄严升旗仪式，记得提前1-9天实名预约", "免费 (需提前预约)"),
                Attraction("故宫博物院", "紫禁城宫殿群", "地铁1号线天安门东站", "六百年明清皇宫，建议中轴线+东西六宫经典半日游", "淡季40元/旺季60元"),
                Attraction("天坛公园", "祈年殿祈福", "地铁5号线天坛东门站", "明清皇帝祭天祈谷圣地，祈年殿圆形木构殿堂极具震撼力", "联票约28-34元")
            ),
            diningRecommendations = listOf(
                DiningSpot("门框胡同百年卤煮", "地道老北京卤煮火烧", "人均 ¥28", "前门大街旁胡同"),
                DiningSpot("四季民福烤鸭店", "酥脆特选烤鸭配荷叶饼", "人均 ¥110", "前门大栅栏附近"),
                DiningSpot("尹三豆汁", "传统老北京豆汁配焦圈", "人均 ¥12", "天坛北门附近")
            ),
            transportGuides = listOf(
                TransportTip("高铁抵达", "北京南站 / 北京西站", "北京南站乘地铁4号线换乘2号线到前门仅需15分钟；北京西站乘7号线直达"),
                TransportTip("大兴机场", "大兴机场快轨", "大兴机场线20分钟抵草桥站，无缝换乘19号线进二环"),
                TransportTip("交通卡", "亿通行App / 微信乘车码", "北京地铁公交扫码一码通乘，换乘方便")
            )
        ),
        ExploreCity(
            id = "chengdu",
            name = "Chengdu",
            nameZh = "成都",
            tag = "天府之国 · 慢生活与熊猫",
            description = "巴适安逸的生活节奏，春熙路太古里古今交融，品地道盖碗茶，吃麻辣串串香，邂逅憨态可掬的大熊猫。",
            hotelCount = 35,
            attractions = listOf(
                Attraction("成都大熊猫繁育研究基地", "国宝大熊猫", "地铁3号线熊猫大道站转接驳车", "近距离观赏大熊猫吃竹子、幼崽翻滚嬉戏，早上去更活跃", "门票约55元"),
                Attraction("春熙路 & 太古里", "时尚潮人地标", "地铁2/3号线春熙路站", "爬墙大熊猫雕塑打卡，大慈寺闹中取静喝盖碗茶", "免费游览"),
                Attraction("锦里古街 & 武侯祠", "三国蜀汉遗风", "地铁3号线高升桥站", "红墙竹影拍照极佳，入夜后大红灯笼亮起古韵悠然", "古街免费/武侯祠50元")
            ),
            diningRecommendations = listOf(
                DiningSpot("洞子口张老二凉粉", "甜水面 & 黄凉粉", "人均 ¥15", "文殊院老街"),
                DiningSpot("钢管厂五区小郡肝串串香", "麻辣牛肉串串与冷锅串串", "人均 ¥65", "春熙路分店"),
                DiningSpot("人民公园鹤鸣茶社", "传统盖碗茶配采耳", "人均 ¥30", "人民公园内")
            ),
            transportGuides = listOf(
                TransportTip("高铁抵达", "成都东站", "成都东站直接进入地铁2号线，直达春熙路站仅需12分钟"),
                TransportTip("天府机场", "地铁18号线快线", "天府机场乘18号线快车约37分钟到达火车南站，便捷换乘1/7号线"),
                TransportTip("出行建议", "天府通App", "成都地铁运营时间长，夜间打车起步价实惠")
            )
        ),
        ExploreCity(
            id = "guangzhou",
            name = "Guangzhou",
            nameZh = "广州",
            tag = "食在广州 · 花城越秀",
            description = "岭南早茶文化的故乡，晨起一盅两件，漫步沙面欧陆风情岛，夜晚仰望广州塔小蛮腰，好住不贵。",
            hotelCount = 32,
            attractions = listOf(
                Attraction("广州塔 (小蛮腰)", "现代城市之巅", "APM线/地铁3号线广州塔站", "中国第一高塔，珠江两岸璀璨夜色尽收眼底", "登塔150元起/广场外观免费"),
                Attraction("沙面岛", "欧陆建筑风情", "地铁1/6号线黄沙站", "百余座英法租界近代历史建筑，古树参天绿意盎然", "免费开放"),
                Attraction("北京路文化旅游区", "千年古道遗址", "地铁1/2号线公园前站", "透明玻璃下展示唐宋元明清千年叠石路面", "免费游览")
            ),
            diningRecommendations = listOf(
                DiningSpot("点都德 (聚福楼店)", "金沙海虾红米肠 & 百合酱蒸凤爪", "人均 ¥60", "体育西路商圈附近"),
                DiningSpot("南信牛奶甜品专家", "双皮奶 & 姜撞奶", "人均 ¥22", "第十甫路老街"),
                DiningSpot("达扬原味炖品", "原只椰子炖竹丝鸡", "人均 ¥25", "文明路老骑楼下")
            ),
            transportGuides = listOf(
                TransportTip("高铁抵达", "广州南站", "华南最大高铁枢纽，乘地铁2号线或7号线直通越秀及天河区"),
                TransportTip("白云机场", "地铁3号线北延段", "白云机场直通天河体育西路与珠江新城CBD"),
                TransportTip("便捷乘车", "广州地铁App / 羊城通", "APM线自动穿梭观光珠江新城与海心沙")
            )
        )
    )
}
