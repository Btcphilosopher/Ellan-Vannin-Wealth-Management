package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "bookings")
data class BookingEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bookingReference: String,
    val hotelId: String,
    val hotelName: String,
    val hotelAddress: String,
    val hotelPhone: String,
    val roomTypeId: String,
    val roomTypeName: String,
    val roomImageRes: Int,
    val checkInDate: String,
    val checkOutDate: String,
    val nightsCount: Int,
    val roomCount: Int,
    val guestName: String,
    val guestPhone: String,
    val specialRequests: String,
    val needInvoice: Boolean,
    val invoiceTitle: String,
    val totalPrice: Int,
    val nightlyRate: Int,
    val status: String, // PENDING, CONFIRMED, COMPLETED, CANCELLED
    val paymentMethod: String,
    val paidAt: String,
    val checkInQrCode: String,
    val cancellationPolicyDesc: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "saved_hotels")
data class SavedHotelEntity(
    @PrimaryKey val hotelId: String,
    val savedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "itinerary_items")
data class ItineraryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val city: String,
    val tripDate: String,
    val timeSlot: String,
    val title: String,
    val category: String,
    val notes: String,
    val isCompleted: Boolean = false
)

@Entity(tableName = "search_history")
data class SearchHistoryEntity(
    @PrimaryKey val query: String,
    val city: String,
    val searchedAt: Long = System.currentTimeMillis()
)
