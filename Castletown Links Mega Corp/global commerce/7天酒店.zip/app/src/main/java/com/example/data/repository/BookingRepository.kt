package com.example.data.repository

import com.example.data.local.BookingDao
import com.example.data.local.BookingEntity
import com.example.data.model.Booking
import com.example.data.model.BookingStatus
import com.example.data.model.PaymentMethod
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

class BookingRepository(
    private val bookingDao: BookingDao,
    private val hotelRepository: HotelRepository
) {
    val allBookings: Flow<List<Booking>> = bookingDao.getAllBookingsFlow().map { list ->
        list.map { it.toDomain() }
    }

    suspend fun getBookingById(id: Long): Booking? {
        return bookingDao.getBookingById(id)?.toDomain()
    }

    suspend fun getBookingByReference(ref: String): Booking? {
        return bookingDao.getBookingByReference(ref)?.toDomain()
    }

    /**
     * Creates a new booking. Revalidates inventory atomically.
     * Throws exception if rooms are sold out.
     */
    suspend fun createBooking(
        hotelId: String,
        hotelName: String,
        hotelAddress: String,
        hotelPhone: String,
        roomTypeId: String,
        roomTypeName: String,
        roomImageRes: Int,
        checkInDate: String,
        checkOutDate: String,
        nightsCount: Int,
        roomCount: Int,
        guestName: String,
        guestPhone: String,
        specialRequests: String,
        needInvoice: Boolean,
        invoiceTitle: String,
        nightlyRate: Int,
        paymentMethod: PaymentMethod,
        cancellationPolicyDesc: String
    ): Result<Booking> {
        // Step 1: Atomic Inventory Hold
        val holdSuccess = hotelRepository.tryHoldInventory(roomTypeId, roomCount)
        if (!holdSuccess) {
            return Result.failure(IllegalStateException("所选房型库存不足或已被预订完毕，请选择其他房型"))
        }

        // Step 2: Calculate total price
        val totalPrice = nightlyRate * nightsCount * roomCount

        // Step 3: Generate unique booking reference and check-in token
        val timeStamp = SimpleDateFormat("yyyyMMddHHmmss", Locale.getDefault()).format(Date())
        val randomSuffix = Random.nextInt(1000, 9999)
        val bookingRef = "7D$timeStamp$randomSuffix"
        val qrToken = "7D-CHECKIN-$bookingRef"
        val paidTimeString = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())

        val entity = BookingEntity(
            bookingReference = bookingRef,
            hotelId = hotelId,
            hotelName = hotelName,
            hotelAddress = hotelAddress,
            hotelPhone = hotelPhone,
            roomTypeId = roomTypeId,
            roomTypeName = roomTypeName,
            roomImageRes = roomImageRes,
            checkInDate = checkInDate,
            checkOutDate = checkOutDate,
            nightsCount = nightsCount,
            roomCount = roomCount,
            guestName = guestName,
            guestPhone = guestPhone,
            specialRequests = specialRequests,
            needInvoice = needInvoice,
            invoiceTitle = invoiceTitle,
            totalPrice = totalPrice,
            nightlyRate = nightlyRate,
            status = BookingStatus.CONFIRMED.name,
            paymentMethod = paymentMethod.name,
            paidAt = paidTimeString,
            checkInQrCode = qrToken,
            cancellationPolicyDesc = cancellationPolicyDesc
        )

        val insertedId = bookingDao.insertBooking(entity)
        val domain = entity.copy(id = insertedId).toDomain()
        return Result.success(domain)
    }

    /**
     * Cancels an existing booking and releases inventory back to pool.
     */
    suspend fun cancelBooking(booking: Booking, reason: String = "用户自助取消"): Result<Unit> {
        return try {
            bookingDao.updateStatus(booking.bookingReference, BookingStatus.CANCELLED.name)
            // Release inventory
            hotelRepository.releaseInventory(booking.roomTypeId, booking.roomCount)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun BookingEntity.toDomain(): Booking {
        val mappedStatus = try {
            BookingStatus.valueOf(status)
        } catch (_: Exception) {
            BookingStatus.CONFIRMED
        }
        val mappedMethod = try {
            PaymentMethod.valueOf(paymentMethod)
        } catch (_: Exception) {
            PaymentMethod.WECHAT_PAY
        }

        return Booking(
            id = id,
            bookingReference = bookingReference,
            hotelId = hotelId,
            hotelName = hotelName,
            hotelAddress = hotelAddress,
            hotelPhone = hotelPhone,
            roomTypeId = roomTypeId,
            roomTypeName = roomTypeName,
            roomImageRes = roomImageRes,
            checkInDate = checkInDate,
            checkOutDate = checkOutDate,
            nightsCount = nightsCount,
            roomCount = roomCount,
            guestName = guestName,
            guestPhone = guestPhone,
            specialRequests = specialRequests,
            needInvoice = needInvoice,
            invoiceTitle = invoiceTitle,
            totalPrice = totalPrice,
            nightlyRate = nightlyRate,
            status = mappedStatus,
            paymentMethod = mappedMethod,
            paidAt = paidAt,
            checkInQrCode = checkInQrCode,
            cancellationPolicyDesc = cancellationPolicyDesc,
            createdAt = createdAt
        )
    }
}
