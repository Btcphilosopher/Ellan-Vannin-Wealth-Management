package com.example.ui.account

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Help
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.HeadsetMic
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.UserRepository
import com.example.ui.components.SevenDaysBrandLogo
import com.example.ui.components.SevenDaysHeaderBar
import com.example.ui.theme.BrandCharcoal
import com.example.ui.theme.BrandGreen
import com.example.ui.theme.BrandRed
import com.example.ui.theme.BrandYellowContainer
import com.example.ui.theme.BrandYellowPrimary
import com.example.ui.theme.NeutralBg
import com.example.ui.theme.NeutralBorder
import com.example.ui.theme.NeutralSurface
import com.example.ui.theme.NeutralTextPrimary
import com.example.ui.theme.NeutralTextSecondary

@Composable
fun AccountScreen(
    userRepository: UserRepository,
    onNavigateToTrips: () -> Unit
) {
    val context = LocalContext.current
    val user by userRepository.userState.collectAsState()
    var showPrivacyDialog by remember { mutableStateOf(false) }
    var showMemberPerksDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(NeutralBg)
            .testTag("account_screen")
    ) {
        // Top Header
        item {
            SevenDaysHeaderBar(
                title = if (user.isEnglish) "My Account" else "个人中心",
                subtitle = if (user.isEnglish) "7 Days Hotel Member Club" else "7天星级会员 · 尊享好睡礼遇",
                showLogo = true
            )
        }

        // Member Card (Website style)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .clickable { showMemberPerksDialog = true },
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = BrandCharcoal),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(52.dp)
                                    .clip(CircleShape)
                                    .background(BrandYellowPrimary),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "7",
                                    fontSize = 30.sp,
                                    fontWeight = FontWeight.Black,
                                    color = BrandCharcoal
                                )
                            }
                            Spacer(modifier = Modifier.width(14.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = user.memberName,
                                        color = Color.White,
                                        fontSize = 17.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(
                                        shape = RoundedCornerShape(3.dp),
                                        color = BrandYellowPrimary
                                    ) {
                                        Text(
                                            text = "95折",
                                            color = BrandCharcoal,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "卡号: ${user.memberId} · ${user.phone}",
                                    color = Color(0xFFD1D5DB),
                                    fontSize = 12.sp
                                )
                            }
                        }

                        Icon(
                            imageVector = Icons.Default.Stars,
                            contentDescription = null,
                            tint = BrandYellowPrimary,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(18.dp))
                    Divider(color = Color(0xFF374151), thickness = 0.8.dp)
                    Spacer(modifier = Modifier.height(14.dp))

                    // Member Stats (Points, Discount, Coupons)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        MemberStatItem(
                            number = "${user.points}",
                            label = if (user.isEnglish) "Points" else "可用积分"
                        )
                        MemberStatItem(
                            number = "${user.discountPercent}折",
                            label = if (user.isEnglish) "Direct Discount" else "订房折扣"
                        )
                        MemberStatItem(
                            number = "${user.couponCount}张",
                            label = if (user.isEnglish) "Coupons" else "专享优惠券"
                        )
                    }
                }
            }
        }

        // Quick Order Hub
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = NeutralSurface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (user.isEnglish) "My Bookings" else "我的订单",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = NeutralTextPrimary
                        )
                        Text(
                            text = if (user.isEnglish) "All Trips →" else "全部行程 →",
                            fontSize = 12.sp,
                            color = NeutralTextSecondary,
                            modifier = Modifier.clickable { onNavigateToTrips() }
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        QuickActionItem(icon = Icons.Default.Assignment, label = "全部预订", onClick = onNavigateToTrips)
                        QuickActionItem(icon = Icons.Default.Receipt, label = "电子发票", onClick = {
                            Toast.makeText(context, "离店后可在对应订单详情一键下载开具", Toast.LENGTH_SHORT).show()
                        })
                        QuickActionItem(icon = Icons.Default.ConfirmationNumber, label = "优惠券包", onClick = {
                            Toast.makeText(context, "当前持有 4 张无门槛立减券", Toast.LENGTH_SHORT).show()
                        })
                        QuickActionItem(icon = Icons.Default.CardGiftcard, label = "积分商城", onClick = {
                            Toast.makeText(context, "当前 ${user.points} 积分，可兑换免费房晚或洗漱礼包", Toast.LENGTH_SHORT).show()
                        })
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(14.dp)) }

        // Settings and Preferences
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = NeutralSurface)
            ) {
                Column(modifier = Modifier.padding(vertical = 4.dp)) {
                    // Language Switcher
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { userRepository.toggleLanguage() }
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Language, contentDescription = null, tint = BrandCharcoal, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(text = "语言选择 / Language", fontSize = 14.sp, color = NeutralTextPrimary)
                        }
                        Text(
                            text = if (user.isEnglish) "English" else "简体中文",
                            fontSize = 13.sp,
                            color = BrandCharcoal,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Divider(color = NeutralBorder, thickness = 0.6.dp, modifier = Modifier.padding(horizontal = 16.dp))

                    // Customer Service Hotline
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:4008777777"))
                                try {
                                    context.startActivity(intent)
                                } catch (_: Exception) {
                                    Toast.makeText(context, "7天全国服务专线: 400-87-77777", Toast.LENGTH_SHORT).show()
                                }
                            }
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.HeadsetMic, contentDescription = null, tint = BrandCharcoal, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(text = "全国客房服务热线", fontSize = 14.sp, color = NeutralTextPrimary)
                        }
                        Text(text = "400-87-77777", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = BrandGreen)
                    }

                    Divider(color = NeutralBorder, thickness = 0.6.dp, modifier = Modifier.padding(horizontal = 16.dp))

                    // Privacy Policy & Terms
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showPrivacyDialog = true }
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.PrivacyTip, contentDescription = null, tint = BrandCharcoal, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(text = "隐私安全与服务协议", fontSize = 14.sp, color = NeutralTextPrimary)
                        }
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = Color(0xFF9CA3AF), modifier = Modifier.size(16.dp))
                    }
                }
            }
        }

        // App Version and Brand Footer
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "7天酒店 · 好睡 · 省钱 · 到哪都在",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = BrandCharcoal
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "版本 v1.0.0 (Build 2026.10) · © 2026 7天酒店 版权所有",
                    fontSize = 11.sp,
                    color = NeutralTextSecondary
                )
            }
        }
    }

    // Member Perks Dialog
    if (showMemberPerksDialog) {
        AlertDialog(
            onDismissRequest = { showMemberPerksDialog = false },
            title = { Text("7天星级会员特权", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("• 官方预订全房型直减 95折优惠", fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("• 延迟退房至 14:00 (视房态优先安排)", fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("• 入住赠送瓶装饮用水与封包清洁毛巾", fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("• 每消费1元累积10积分，积分全额抵扣房费", fontSize = 13.sp)
                }
            },
            confirmButton = {
                Button(
                    onClick = { showMemberPerksDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = BrandYellowPrimary, contentColor = BrandCharcoal)
                ) {
                    Text("我知道了")
                }
            }
        )
    }

    // Privacy Policy Dialog
    if (showPrivacyDialog) {
        AlertDialog(
            onDismissRequest = { showPrivacyDialog = false },
            title = { Text("隐私政策与合规声明", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text(
                        text = "本应用严格遵守《中华人民共和国个人信息保护法》及相关网络安全法规。仅在用户主动预订时收集必要的入住姓名与手机号，传输过程全链路采用TLS 1.3安全加密，绝不对第三方泄露或未经授权使用。",
                        fontSize = 12.sp,
                        color = NeutralTextPrimary,
                        lineHeight = 17.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { showPrivacyDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = BrandYellowPrimary, contentColor = BrandCharcoal)
                ) {
                    Text("已阅读并同意")
                }
            }
        )
    }
}

@Composable
fun MemberStatItem(
    number: String,
    label: String
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = number,
            fontSize = 18.sp,
            fontWeight = FontWeight.Black,
            color = BrandYellowPrimary
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            color = Color(0xFFD1D5DB)
        )
    }
}

@Composable
fun QuickActionItem(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable { onClick() }
            .padding(4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(BrandYellowContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = BrandCharcoal,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            color = NeutralTextPrimary
        )
    }
}
