package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface BookingDao {
    @Query("SELECT * FROM bookings ORDER BY createdAt DESC")
    fun getAllBookingsFlow(): Flow<List<BookingEntity>>

    @Query("SELECT * FROM bookings WHERE bookingReference = :ref LIMIT 1")
    suspend fun getBookingByReference(ref: String): BookingEntity?

    @Query("SELECT * FROM bookings WHERE id = :id LIMIT 1")
    suspend fun getBookingById(id: Long): BookingEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBooking(booking: BookingEntity): Long

    @Update
    suspend fun updateBooking(booking: BookingEntity)

    @Query("UPDATE bookings SET status = :status WHERE bookingReference = :ref")
    suspend fun updateStatus(ref: String, status: String)

    @Query("DELETE FROM bookings WHERE id = :id")
    suspend fun deleteBooking(id: Long)
}

@Dao
interface SavedHotelDao {
    @Query("SELECT hotelId FROM saved_hotels")
    fun getSavedHotelIdsFlow(): Flow<List<String>>

    @Query("SELECT EXISTS(SELECT 1 FROM saved_hotels WHERE hotelId = :hotelId)")
    suspend fun isHotelSaved(hotelId: String): Boolean

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveHotel(entity: SavedHotelEntity)

    @Query("DELETE FROM saved_hotels WHERE hotelId = :hotelId")
    suspend fun removeSavedHotel(hotelId: String)
}

@Dao
interface ItineraryDao {
    @Query("SELECT * FROM itinerary_items ORDER BY tripDate ASC, id ASC")
    fun getAllItineraryFlow(): Flow<List<ItineraryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItem(item: ItineraryEntity): Long

    @Update
    suspend fun updateItem(item: ItineraryEntity)

    @Query("DELETE FROM itinerary_items WHERE id = :id")
    suspend fun deleteItem(id: Long)
}

@Dao
interface SearchHistoryDao {
    @Query("SELECT * FROM search_history ORDER BY searchedAt DESC LIMIT 10")
    fun getRecentSearches(): Flow<List<SearchHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSearch(item: SearchHistoryEntity)

    @Query("DELETE FROM search_history")
    suspend fun clearHistory()
}
