package com.example.ui.explore

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DirectionsSubway
import androidx.compose.material.icons.filled.Fastfood
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Train
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Attraction
import com.example.data.model.DiningSpot
import com.example.data.model.ExploreCity
import com.example.data.model.ItineraryItem
import com.example.data.model.TransportTip
import com.example.data.repository.ExploreRepository
import com.example.ui.components.FeaturePill
import com.example.ui.components.SectionHeader
import com.example.ui.components.SevenDaysHeaderBar
import com.example.ui.theme.BrandCharcoal
import com.example.ui.theme.BrandGreen
import com.example.ui.theme.BrandRed
import com.example.ui.theme.BrandYellowContainer
import com.example.ui.theme.BrandYellowPrimary
import com.example.ui.theme.NeutralBg
import com.example.ui.theme.NeutralBorder
import com.example.ui.theme.NeutralSurface
import com.example.ui.theme.NeutralTextPrimary
import com.example.ui.theme.NeutralTextSecondary
import kotlinx.coroutines.launch

@Composable
fun ExploreScreen(
    exploreRepository: ExploreRepository,
    initialCityId: String = "shanghai"
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val cities = remember { exploreRepository.getAllCities() }
    var selectedCityId by remember { mutableStateOf(initialCityId) }
    val currentCity = remember(selectedCityId) {
        exploreRepository.getCityById(selectedCityId) ?: cities.first()
    }

    val itineraryList by exploreRepository.itineraryFlow.collectAsState(initial = emptyList())
    var showAddDialog by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(NeutralBg)
            .testTag("explore_screen")
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize()
        ) {
            // Header
            item {
                SevenDaysHeaderBar(
                    title = "旅行助手",
                    subtitle = "城市漫游指南 · 高铁地铁接驳 · 贴身随行笔记",
                    showLogo = true
                )
            }

            // City Selection Row
            item {
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(NeutralSurface)
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(cities) { city ->
                        val isSelected = city.id == currentCity.id
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (isSelected) BrandYellowPrimary else NeutralBg)
                                .clickable { selectedCityId = city.id }
                                .padding(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = city.nameZh,
                                fontSize = 13.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) BrandCharcoal else NeutralTextSecondary
                            )
                        }
                    }
                }
            }

            // City Overview Banner
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = BrandCharcoal)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${currentCity.nameZh} · ${currentCity.tag}",
                                color = BrandYellowPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = Color.White.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = "${currentCity.hotelCount} 家7天分店覆盖",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = currentCity.description,
                            color = Color(0xFFE5E7EB),
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )
                    }
                }
            }

            // High-Speed Rail & Metro Transit Guides
            item {
                SectionHeader(
                    title = "大交通与地铁接驳",
                    subtitle = "高铁站、机场往返7天分店极简路线"
                )
            }

            items(currentCity.transportGuides) { tip ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = NeutralSurface)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(BrandYellowContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (tip.type.contains("高铁")) Icons.Default.Train else Icons.Default.DirectionsSubway,
                                contentDescription = null,
                                tint = BrandCharcoal,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${tip.type} — ${tip.title}",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = NeutralTextPrimary
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = tip.description,
                                fontSize = 12.sp,
                                color = NeutralTextSecondary,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }
            }

            // Verified City Attractions
            item {
                SectionHeader(
                    title = "精选特色地标",
                    subtitle = "经典打卡点 · 邻近7天分店出行方便"
                )
            }

            items(currentCity.attractions) { attraction ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = NeutralSurface)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = attraction.name,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = NeutralTextPrimary
                            )
                            FeaturePill(text = attraction.ticketPrice, highlight = attraction.ticketPrice.contains("免费"))
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "交通: ${attraction.metroInfo}",
                            fontSize = 12.sp,
                            color = BrandGreen,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = attraction.description,
                            fontSize = 12.sp,
                            color = NeutralTextSecondary
                        )
                    }
                }
            }

            // Authentic Foodie Recommendations
            item {
                SectionHeader(
                    title = "地道老字号美食",
                    subtitle = "人均亲民 · 体验纯正市井风味"
                )
            }

            items(currentCity.diningRecommendations) { dining ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = NeutralSurface)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFFFF0ED)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Fastfood,
                                contentDescription = null,
                                tint = BrandRed,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = dining.name,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = NeutralTextPrimary
                            )
                            Text(
                                text = "${dining.specialty} · ${dining.distanceDesc}",
                                fontSize = 12.sp,
                                color = NeutralTextSecondary
                            )
                        }
                        Text(
                            text = dining.averageCost,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = BrandRed
                        )
                    }
                }
            }

            // Personal Itinerary Notes Section
            item {
                SectionHeader(
                    title = "随行行程清单",
                    subtitle = "记录待办事项与专属游览备忘录",
                    actionText = "+ 添加清单",
                    onActionClick = { showAddDialog = true }
                )
            }

            if (itineraryList.isEmpty()) {
                item {
                    Text(
                        text = "暂无随行清单，点击右上角快速添加",
                        fontSize = 12.sp,
                        color = NeutralTextSecondary,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                }
            } else {
                items(itineraryList) { item ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = NeutralSurface)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = {
                                    scope.launch { exploreRepository.toggleItineraryItem(item) }
                                }
                            ) {
                                Icon(
                                    imageVector = if (item.isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                    contentDescription = null,
                                    tint = if (item.isCompleted) BrandGreen else NeutralTextSecondary
                                )
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.title,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (item.isCompleted) Color(0xFF9CA3AF) else NeutralTextPrimary,
                                    textDecoration = if (item.isCompleted) androidx.compose.ui.text.style.TextDecoration.LineThrough else null
                                )
                                Text(
                                    text = "${item.city} · ${item.tripDate} ${item.timeSlot} [${item.category}]",
                                    fontSize = 11.sp,
                                    color = NeutralTextSecondary
                                )
                                if (item.notes.isNotEmpty()) {
                                    Text(
                                        text = item.notes,
                                        fontSize = 11.sp,
                                        color = Color(0xFF6B7280)
                                    )
                                }
                            }
                            IconButton(
                                onClick = {
                                    scope.launch { exploreRepository.deleteItineraryItem(item.id) }
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "删除",
                                    tint = Color(0xFF9CA3AF),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(60.dp))
            }
        }

        // Floating Action Button to Add Itinerary
        FloatingActionButton(
            onClick = { showAddDialog = true },
            containerColor = BrandYellowPrimary,
            contentColor = BrandCharcoal,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
                .testTag("add_itinerary_fab")
        ) {
            Icon(imageVector = Icons.Default.Add, contentDescription = "新增行程备忘")
        }
    }

    // Add Itinerary Dialog
    if (showAddDialog) {
        var title by remember { mutableStateOf("") }
        var timeSlot by remember { mutableStateOf("10:00") }
        var category by remember { mutableStateOf("景点") }
        var notes by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("新增行程清单", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("行程事项 (如：前往外滩看夜景)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = timeSlot,
                        onValueChange = { timeSlot = it },
                        label = { Text("计划时间 (如：14:30)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("详细备注 (如：带身份证/地铁直达)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (title.isNotBlank()) {
                            scope.launch {
                                exploreRepository.addItineraryItem(
                                    ItineraryItem(
                                        city = currentCity.nameZh,
                                        tripDate = "2026-10-18",
                                        timeSlot = timeSlot,
                                        title = title,
                                        category = category,
                                        notes = notes
                                    )
                                )
                                showAddDialog = false
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BrandYellowPrimary, contentColor = BrandCharcoal)
                ) {
                    Text("添加")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("取消")
                }
            }
        )
    }
}
