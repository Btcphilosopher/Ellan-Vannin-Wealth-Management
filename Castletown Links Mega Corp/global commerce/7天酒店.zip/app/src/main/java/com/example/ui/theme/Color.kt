package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// 7天酒店 (7 Days Hotel) Brand Color Palette
val BrandYellowPrimary = Color(0xFFFFCC00)      // Iconic 7 Days Brand Gold/Yellow
val BrandYellowDark = Color(0xFFE5B800)         // Pressed / darker state
val BrandYellowLight = Color(0xFFFFF7D6)        // Subtle container yellow
val BrandYellowContainer = Color(0xFFFFF0B3)

// Dark charcoal & neutral tones from brand header & web UI
val BrandCharcoal = Color(0xFF1A1D20)           // Dark bar and prominent titles
val BrandCharcoalLight = Color(0xFF282C32)
val BrandSurfaceDark = Color(0xFF141618)

// Functional & accent colors
val BrandRed = Color(0xFFF04438)                // Promotions, discounts, warnings
val BrandGreen = Color(0xFF12B76A)              // Free cancellation, confirmed badges
val BrandBlue = Color(0xFF007AFF)               // Navigation / links
val BrandOrange = Color(0xFFFF8A00)             // Member tags

// Neutral Light
val NeutralBg = Color(0xFFF7F8FA)               // Soft clean mobile background
val NeutralSurface = Color(0xFFFFFFFF)          // Card backgrounds
val NeutralBorder = Color(0xFFE5E7EB)           // Crisp dividers
val NeutralTextPrimary = Color(0xFF1F2329)      // Headings & primary copy
val NeutralTextSecondary = Color(0xFF646A73)    // Subtitles & amenities
val NeutralTextMuted = Color(0xFF9CA3AF)        // Placeholders & hints

// Dark theme colors
val DarkBackground = Color(0xFF111315)
val DarkSurface = Color(0xFF1A1D20)
val DarkSurfaceVariant = Color(0xFF24282D)
val DarkBorder = Color(0xFF2F343B)
val DarkTextPrimary = Color(0xFFF3F4F6)
val DarkTextSecondary = Color(0xFF9CA3AF)
