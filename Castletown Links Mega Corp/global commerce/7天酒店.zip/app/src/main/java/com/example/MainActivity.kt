package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.data.local.AppDatabase
import com.example.data.repository.BookingRepository
import com.example.data.repository.ExploreRepository
import com.example.data.repository.HotelRepository
import com.example.data.repository.UserRepository
import com.example.ui.MainApp
import com.example.ui.theme.BrandCharcoal
import com.example.ui.theme.SevenDaysHotelTheme

class MainActivity : ComponentActivity() {

    private lateinit var database: AppDatabase
    private lateinit var hotelRepository: HotelRepository
    private lateinit var bookingRepository: BookingRepository
    private lateinit var exploreRepository: ExploreRepository
    private lateinit var userRepository: UserRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Initialize local persistence & repositories
        database = AppDatabase.getInstance(applicationContext)
        hotelRepository = HotelRepository(database.savedHotelDao())
        bookingRepository = BookingRepository(database.bookingDao(), hotelRepository)
        exploreRepository = ExploreRepository(database.itineraryDao())
        userRepository = UserRepository()

        setContent {
            SevenDaysHotelTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = BrandCharcoal
                ) {
                    MainApp(
                        hotelRepository = hotelRepository,
                        bookingRepository = bookingRepository,
                        exploreRepository = exploreRepository,
                        userRepository = userRepository
                    )
                }
            }
        }
    }
}
