package com.example.ui.booking

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.Booking
import com.example.data.model.BookingStatus
import com.example.data.model.Hotel
import com.example.data.model.PaymentMethod
import com.example.data.model.RoomType
import com.example.data.repository.BookingRepository
import com.example.data.repository.HotelRepository
import com.example.data.repository.UserRepository
import com.example.ui.components.PriceDisplay
import com.example.ui.components.SevenDaysBrandLogo
import com.example.ui.components.SevenDaysHeaderBar
import com.example.ui.components.SevenDaysPrimaryButton
import com.example.ui.theme.BrandCharcoal
import com.example.ui.theme.BrandCharcoalLight
import com.example.ui.theme.BrandGreen
import com.example.ui.theme.BrandRed
import com.example.ui.theme.BrandYellowContainer
import com.example.ui.theme.BrandYellowPrimary
import com.example.ui.theme.NeutralBg
import com.example.ui.theme.NeutralBorder
import com.example.ui.theme.NeutralSurface
import com.example.ui.theme.NeutralTextMuted
import com.example.ui.theme.NeutralTextPrimary
import com.example.ui.theme.NeutralTextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun BookingFlowScreen(
    hotelId: String,
    roomId: String,
    ratePlanId: String? = null,
    hotelRepository: HotelRepository,
    bookingRepository: BookingRepository,
    userRepository: UserRepository,
    onBackClick: () -> Unit,
    onBookingSuccessToTrips: () -> Unit,
    onGoHome: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val hotel = remember(hotelId) { hotelRepository.getHotelById(hotelId) }
    val room = remember(roomId) { hotelRepository.getRoomTypeById(roomId) }

    // Form inputs
    var guestName by remember { mutableStateOf("张先生") }
    var guestPhone by remember { mutableStateOf("13800138000") }
    var specialRequests by remember { mutableStateOf("无烟房，尽量安排安静高楼层") }
    var needInvoice by remember { mutableStateOf(false) }
    var invoiceTitle by remember { mutableStateOf("") }
    var selectedPaymentMethod by remember { mutableStateOf(PaymentMethod.WECHAT_PAY) }
    var roomCount by remember { mutableIntStateOf(1) }
    var nightsCount by remember { mutableIntStateOf(1) }
    var checkInDate by remember { mutableStateOf("2026-10-18") }
    var checkOutDate by remember { mutableStateOf("2026-10-19") }

    // Processing & confirmation state
    var isSubmitting by remember { mutableStateOf(false) }
    var confirmedBooking by remember { mutableStateOf<Booking?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    if (hotel == null || room == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("预订信息加载失败")
        }
        return
    }

    // 95折 Member Discount Calculation
    val baseRate = room.pricePerNight
    val memberDiscountSavings = (baseRate * 0.05).toInt() * nightsCount * roomCount
    val totalOriginal = baseRate * nightsCount * roomCount
    val finalTotal = totalOriginal - memberDiscountSavings

    // If confirmation is reached, display the Confirmation View
    if (confirmedBooking != null) {
        BookingConfirmationView(
            booking = confirmedBooking!!,
            onGoToTrips = onBookingSuccessToTrips,
            onGoHome = onGoHome
        )
        return
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(NeutralBg)
            .testTag("booking_flow_screen")
    ) {
        // Header
        item {
            Surface(color = BrandCharcoal, modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "返回",
                            tint = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "确认订单",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }

        // Error message if any
        if (errorMessage != null) {
            item {
                Surface(
                    color = Color(0xFFFFEBEE),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = BrandRed)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = errorMessage!!, color = BrandRed, fontSize = 13.sp)
                    }
                }
            }
        }

        // Stay & Hotel Summary Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = NeutralSurface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = hotel.name,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = NeutralTextPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = hotel.address,
                        fontSize = 12.sp,
                        color = NeutralTextSecondary
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Divider(color = NeutralBorder, thickness = 0.8.dp)
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Image(
                            painter = painterResource(id = room.imageRes),
                            contentDescription = room.name,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(64.dp)
                                .clip(RoundedCornerShape(6.dp))
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = room.name,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = NeutralTextPrimary
                            )
                            Text(
                                text = "${room.bedInfo} · ${room.areaSqM}m²",
                                fontSize = 12.sp,
                                color = NeutralTextSecondary
                            )
                            Text(
                                text = "入住日期: $checkInDate 至 $checkOutDate ($nightsCount 晚)",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = BrandCharcoal
                            )
                        }
                    }
                }
            }
        }

        // Guest Information Form
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = NeutralSurface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "入住人信息",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = NeutralTextPrimary
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = guestName,
                        onValueChange = { guestName = it },
                        label = { Text("入住人姓名 (需与证件一致)") },
                        leadingIcon = {
                            Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = BrandCharcoal)
                        },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BrandYellowPrimary,
                            focusedLabelColor = BrandCharcoal
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("guest_name_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = guestPhone,
                        onValueChange = { guestPhone = it },
                        label = { Text("联系手机号 (用于接收订单确认)") },
                        leadingIcon = {
                            Icon(imageVector = Icons.Default.Phone, contentDescription = null, tint = BrandCharcoal)
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BrandYellowPrimary,
                            focusedLabelColor = BrandCharcoal
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("guest_phone_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = specialRequests,
                        onValueChange = { specialRequests = it },
                        label = { Text("特殊偏好要求 (选填)") },
                        placeholder = { Text("如：尽量安排无烟房、高楼层") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BrandYellowPrimary,
                            focusedLabelColor = BrandCharcoal
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Invoice Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "需要发票",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                color = NeutralTextPrimary
                            )
                            Text(
                                text = "离店后可在订单中心开具增值税电子发票",
                                fontSize = 11.sp,
                                color = NeutralTextSecondary
                            )
                        }
                        Switch(
                            checked = needInvoice,
                            onCheckedChange = { needInvoice = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = BrandCharcoal, checkedTrackColor = BrandYellowPrimary)
                        )
                    }

                    if (needInvoice) {
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = invoiceTitle,
                            onValueChange = { invoiceTitle = it },
                            label = { Text("发票抬头 (公司名称或个人)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }

        // Chinese Payment Method Selection
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = NeutralSurface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "选择支付方式",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = NeutralTextPrimary
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    PaymentOptionRow(
                        title = "微信支付",
                        subtitle = "亿万用户的首选支付方式",
                        iconDesc = "微信",
                        selected = selectedPaymentMethod == PaymentMethod.WECHAT_PAY,
                        onClick = { selectedPaymentMethod = PaymentMethod.WECHAT_PAY }
                    )

                    PaymentOptionRow(
                        title = "支付宝",
                        subtitle = "数亿用户的移动生活开放平台",
                        iconDesc = "支付宝",
                        selected = selectedPaymentMethod == PaymentMethod.ALIPAY,
                        onClick = { selectedPaymentMethod = PaymentMethod.ALIPAY }
                    )

                    PaymentOptionRow(
                        title = "云闪付 / 银联",
                        subtitle = "银行业统一移动支付APP",
                        iconDesc = "银联",
                        selected = selectedPaymentMethod == PaymentMethod.UNIONPAY,
                        onClick = { selectedPaymentMethod = PaymentMethod.UNIONPAY }
                    )

                    PaymentOptionRow(
                        title = "沙箱快捷测试支付 (模拟环境)",
                        subtitle = "仅供联调验证，不扣除真实资金",
                        iconDesc = "测试",
                        isSimulated = true,
                        selected = selectedPaymentMethod == PaymentMethod.TEST_PAY,
                        onClick = { selectedPaymentMethod = PaymentMethod.TEST_PAY }
                    )
                }
            }
        }

        // Price Breakdown Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = NeutralSurface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "费用明细",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = NeutralTextPrimary
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "房费小计 (¥$baseRate × $nightsCount 晚 × $roomCount 间)", fontSize = 13.sp, color = NeutralTextSecondary)
                        Text(text = "¥$totalOriginal", fontSize = 13.sp, color = NeutralTextPrimary)
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "7天星级会员专享95折", fontSize = 13.sp, color = BrandRed)
                            Spacer(modifier = Modifier.width(4.dp))
                            Surface(shape = RoundedCornerShape(2.dp), color = Color(0xFFFFEBEE)) {
                                Text(text = "立减", fontSize = 10.sp, color = BrandRed, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp))
                            }
                        }
                        Text(text = "-¥$memberDiscountSavings", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = BrandRed)
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Divider(color = NeutralBorder, thickness = 0.8.dp)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "应付总金额", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = NeutralTextPrimary)
                        PriceDisplay(price = finalTotal, fontSize = 24, unit = "")
                    }
                }
            }
        }

        // Action Pay Button
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Button(
                    onClick = {
                        if (guestName.isBlank()) {
                            errorMessage = "请填写入住人姓名"
                            return@Button
                        }
                        if (guestPhone.isBlank() || guestPhone.length < 8) {
                            errorMessage = "请填写正确的联系手机号"
                            return@Button
                        }

                        errorMessage = null
                        isSubmitting = true

                        scope.launch {
                            // Simulate secure network transaction & inventory reservation hold
                            delay(1000)

                            val result = bookingRepository.createBooking(
                                hotelId = hotel.id,
                                hotelName = hotel.name,
                                hotelAddress = hotel.address,
                                hotelPhone = hotel.phone,
                                roomTypeId = room.id,
                                roomTypeName = room.name,
                                roomImageRes = room.imageRes,
                                checkInDate = checkInDate,
                                checkOutDate = checkOutDate,
                                nightsCount = nightsCount,
                                roomCount = roomCount,
                                guestName = guestName,
                                guestPhone = guestPhone,
                                specialRequests = specialRequests,
                                needInvoice = needInvoice,
                                invoiceTitle = invoiceTitle,
                                nightlyRate = baseRate,
                                paymentMethod = selectedPaymentMethod,
                                cancellationPolicyDesc = room.cancelPolicy
                            )

                            isSubmitting = false
                            result.onSuccess { newBooking ->
                                userRepository.addPoints(finalTotal * 10)
                                confirmedBooking = newBooking
                            }.onFailure { err ->
                                errorMessage = err.message ?: "下单失败，请重试"
                            }
                        }
                    },
                    enabled = !isSubmitting,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = BrandYellowPrimary,
                        contentColor = BrandCharcoal
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("submit_booking_button")
                ) {
                    if (isSubmitting) {
                        CircularProgressIndicator(color = BrandCharcoal, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "正在安全锁定库存并处理支付...", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    } else {
                        Text(
                            text = "立即支付 ¥$finalTotal 并确认预订",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = BrandGreen, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "7天酒店官方加密通道 · ${room.cancelPolicy}",
                        fontSize = 11.sp,
                        color = NeutralTextSecondary
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun PaymentOptionRow(
    title: String,
    subtitle: String,
    iconDesc: String,
    selected: Boolean,
    isSimulated: Boolean = false,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(if (selected) Color(0xFFFFF9E6) else Color.Transparent)
            .clickable { onClick() }
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            shape = RoundedCornerShape(6.dp),
            color = if (isSimulated) Color(0xFF6B7280) else BrandCharcoal,
            modifier = Modifier.size(36.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(
                    text = iconDesc.take(2),
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = NeutralTextPrimary
                )
                if (isSimulated) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(shape = RoundedCornerShape(2.dp), color = Color(0xFFE5E7EB)) {
                        Text(
                            text = "测试沙箱",
                            fontSize = 9.sp,
                            color = Color(0xFF4B5563),
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                }
            }
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = NeutralTextSecondary
            )
        }
        RadioButton(
            selected = selected,
            onClick = onClick,
            colors = RadioButtonDefaults.colors(selectedColor = BrandCharcoal)
        )
    }
}

@Composable
fun BookingConfirmationView(
    booking: Booking,
    onGoToTrips: () -> Unit,
    onGoHome: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(NeutralBg)
            .testTag("booking_confirmation_view")
    ) {
        // Brand Header
        item {
            SevenDaysHeaderBar(
                title = "预订成功",
                subtitle = "7天酒店期待您的光临",
                showLogo = true
            )
        }

        // Success Hero Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = NeutralSurface),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFE8F5E9)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "成功",
                            tint = BrandGreen,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "预订已确认",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = NeutralTextPrimary
                    )
                    Text(
                        text = "订单编号: ${booking.bookingReference}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = NeutralTextSecondary
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                    Divider(color = NeutralBorder)
                    Spacer(modifier = Modifier.height(16.dp))

                    // QR Check-in Code Box
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = BrandCharcoal,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "到店自助极速入住码",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = BrandYellowPrimary
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Icon(
                                imageVector = Icons.Default.QrCode,
                                contentDescription = "入住二维码",
                                tint = Color.White,
                                modifier = Modifier.size(90.dp)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = booking.checkInQrCode,
                                fontSize = 11.sp,
                                color = Color(0xFFD1D5DB)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "报手机尾号后4位或出示此码办理入住",
                                fontSize = 11.sp,
                                color = Color(0xFF9CA3AF)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Booking Details list
                    DetailRow(label = "入住酒店", value = booking.hotelName)
                    DetailRow(label = "酒店地址", value = booking.hotelAddress)
                    DetailRow(label = "预订房型", value = booking.roomTypeName)
                    DetailRow(label = "入住日期", value = "${booking.checkInDate} 至 ${booking.checkOutDate} (${booking.nightsCount}晚)")
                    DetailRow(label = "入住人", value = "${booking.guestName} (${booking.guestPhone})")
                    DetailRow(label = "支付金额", value = "¥${booking.totalPrice} (已全额支付)")
                    DetailRow(label = "支付方式", value = booking.paymentMethod.labelZh)
                    DetailRow(label = "取消政策", value = booking.cancellationPolicyDesc)

                    Spacer(modifier = Modifier.height(20.dp))

                    // Action CTA Buttons
                    Button(
                        onClick = onGoToTrips,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = BrandYellowPrimary,
                            contentColor = BrandCharcoal
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("go_to_trips_button")
                    ) {
                        Text(text = "进入我的行程查看", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = onGoHome,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NeutralBg,
                            contentColor = NeutralTextPrimary
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                    ) {
                        Text(text = "返回首页", fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top
    ) {
        Text(text = label, fontSize = 12.sp, color = NeutralTextSecondary, modifier = Modifier.width(70.dp))
        Text(
            text = value,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            color = NeutralTextPrimary,
            modifier = Modifier.weight(1f)
        )
    }
}
