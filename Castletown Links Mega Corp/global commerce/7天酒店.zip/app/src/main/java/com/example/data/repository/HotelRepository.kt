package com.example.data.repository

import com.example.R
import com.example.data.local.SavedHotelDao
import com.example.data.model.Hotel
import com.example.data.model.RatePlan
import com.example.data.model.RoomType
import com.example.data.model.SearchCriteria
import com.example.data.model.SortOption
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class HotelRepository(
    private val savedHotelDao: SavedHotelDao
) {
    // Inventory lock to prevent overselling
    private val inventoryMutex = Mutex()
    // Current live room inventory tracker by roomId
    private val inventoryMap = mutableMapOf<String, Int>()

    init {
        // Initialize room stock
        getAllRoomTypes().forEach { room ->
            inventoryMap[room.id] = room.remainingInventory
        }
    }

    fun getSavedHotelIds(): Flow<List<String>> = savedHotelDao.getSavedHotelIdsFlow()

    suspend fun toggleSaveHotel(hotelId: String) {
        val isSaved = savedHotelDao.isHotelSaved(hotelId)
        if (isSaved) {
            savedHotelDao.removeSavedHotel(hotelId)
        } else {
            savedHotelDao.saveHotel(com.example.data.local.SavedHotelEntity(hotelId))
        }
    }

    suspend fun isHotelSaved(hotelId: String): Boolean = savedHotelDao.isHotelSaved(hotelId)

    fun searchHotels(criteria: SearchCriteria): List<Hotel> {
        var list = allHotels.filter { hotel ->
            // Filter by city
            val matchesCity = criteria.city.isEmpty() || hotel.city.contains(criteria.city, ignoreCase = true)
            // Filter by query (name, district, address, tag)
            val matchesQuery = criteria.query.isEmpty() ||
                hotel.name.contains(criteria.query, ignoreCase = true) ||
                hotel.district.contains(criteria.query, ignoreCase = true) ||
                hotel.address.contains(criteria.query, ignoreCase = true) ||
                hotel.tags.any { it.contains(criteria.query, ignoreCase = true) }
            
            // Filter by price range
            val matchesPrice = hotel.startingPrice in criteria.minPrice..criteria.maxPrice

            // Filter by amenities
            val matchesAmenities = criteria.selectedAmenities.isEmpty() ||
                criteria.selectedAmenities.all { requiredAmenity ->
                    hotel.amenities.contains(requiredAmenity)
                }

            matchesCity && matchesQuery && matchesPrice && matchesAmenities
        }

        // Sorting
        list = when (criteria.sortBy) {
            SortOption.RECOMMENDED -> list.sortedByDescending { it.rating }
            SortOption.PRICE_LOW_TO_HIGH -> list.sortedBy { it.startingPrice }
            SortOption.PRICE_HIGH_TO_LOW -> list.sortedByDescending { it.startingPrice }
            SortOption.RATING_HIGH -> list.sortedByDescending { it.rating }
        }

        return list
    }

    fun getFeaturedHotels(): List<Hotel> {
        return allHotels.filter { it.isFeatured }
    }

    fun getHotelById(id: String): Hotel? {
        return allHotels.find { it.id == id }
    }

    fun getRoomsForHotel(hotelId: String): List<RoomType> {
        return allRoomTypes.filter { it.hotelId == hotelId }.map { room ->
            val currentStock = inventoryMap[room.id] ?: room.remainingInventory
            room.copy(remainingInventory = currentStock)
        }
    }

    fun getRoomTypeById(roomId: String): RoomType? {
        val base = allRoomTypes.find { it.id == roomId } ?: return null
        val currentStock = inventoryMap[roomId] ?: base.remainingInventory
        return base.copy(remainingInventory = currentStock)
    }

    fun getRatePlansForRoom(room: RoomType): List<RatePlan> {
        val memberPrice = (room.pricePerNight * 0.95).toInt()
        val multiNightPrice = (room.pricePerNight * 0.90).toInt()
        return listOf(
            RatePlan(
                id = "${room.id}-std",
                name = "标准专享价 (随时订·到店付/在线付)",
                price = room.pricePerNight,
                originalPrice = room.originalPrice,
                memberDiscountDesc = "免费WiFi · 24小时热水 · 离店开票",
                freeCancelUntilHours = 18,
                breakfastCount = if (room.breakfastIncluded) 1 else 0
            ),
            RatePlan(
                id = "${room.id}-member",
                name = "7天星级会员价 (立享95折特惠)",
                price = memberPrice,
                originalPrice = room.pricePerNight,
                memberDiscountDesc = "会员积分翻倍 · 延迟至14:00退房 · 赠迎宾水",
                freeCancelUntilHours = 20,
                breakfastCount = if (room.breakfastIncluded) 2 else 0
            ),
            RatePlan(
                id = "${room.id}-deal",
                name = "特惠早鸟价 (含双早特惠套餐)",
                price = multiNightPrice + 20,
                originalPrice = room.originalPrice + 40,
                memberDiscountDesc = "含双人营养早餐 · 高性价比出行优选",
                freeCancelUntilHours = 12,
                breakfastCount = 2
            )
        )
    }

    /**
     * Revalidate availability and hold inventory.
     * Prevents overselling concurrent bookings.
     */
    suspend fun tryHoldInventory(roomId: String, count: Int): Boolean {
        inventoryMutex.withLock {
            val current = inventoryMap[roomId] ?: 0
            if (current >= count) {
                inventoryMap[roomId] = current - count
                return true
            }
            return false
        }
    }

    /**
     * Releases held inventory when booking is cancelled or hold expires.
     */
    suspend fun releaseInventory(roomId: String, count: Int) {
        inventoryMutex.withLock {
            val current = inventoryMap[roomId] ?: 0
            inventoryMap[roomId] = current + count
        }
    }

    companion object {
        // Static verified hotels catalogue
        private val allHotels = listOf(
        Hotel(
            id = "sh-01",
            name = "7天酒店·上海人民广场南京东路步行街店",
            nameEn = "7 Days Hotel (Shanghai People's Square Pedestrian St)",
            city = "上海",
            district = "黄浦区",
            address = "上海市黄浦区湖北路18号",
            latitude = 31.2355,
            longitude = 121.4782,
            rating = 4.8,
            reviewCount = 3840,
            startingPrice = 148,
            thumbnailRes = R.drawable.hotel_branch_facade,
            tags = listOf("南京东路商圈", "地铁1/2/8号线", "高性价比", "24h安保"),
            amenities = listOf("免费高速WiFi", "独立卫浴", "24小时热水", "行李寄存", "吹风机", "空调暖气", "自助洗衣"),
            distanceToMetro = "距人民广场地铁站14号口步行280米",
            phone = "021-63518888",
            description = "地处上海市中心核心商圈，步行5分钟即达南京路步行街，步行12分钟抵外滩。全屋高支棉舒适床品与静音门锁，好睡省钱，出行便利。",
            isFeatured = true
        ),
        Hotel(
            id = "sh-02",
            name = "7天酒店·上海陆家嘴八佰伴商城店",
            nameEn = "7 Days Hotel (Shanghai Lujiazui Babaiban)",
            city = "上海",
            district = "浦东新区",
            address = "上海市浦东新区张杨路628弄15号",
            latitude = 31.2291,
            longitude = 121.5218,
            rating = 4.7,
            reviewCount = 2190,
            startingPrice = 158,
            thumbnailRes = R.drawable.banner_hero_shanghai,
            tags = listOf("陆家嘴金融区", "地铁9号线", "近东方明珠", "商务优选"),
            amenities = listOf("免费高速WiFi", "独立卫浴", "24小时热水", "行李寄存", "自助打印", "空调暖气"),
            distanceToMetro = "距商城路地铁站2号口步行350米",
            phone = "021-58369999",
            description = "紧邻陆家嘴金融贸易区及第一八佰伴商厦，出行交通极度便捷，提供安静舒适的休憩空间，满足商务与休闲旅游双重需求。",
            isFeatured = true
        ),
        Hotel(
            id = "bj-01",
            name = "7天酒店·北京天安门前门步行街店",
            nameEn = "7 Days Hotel (Beijing Qianmen Tiananmen)",
            city = "北京",
            district = "东城区",
            address = "北京市东城区前门西河沿街88号",
            latitude = 39.8988,
            longitude = 116.3912,
            rating = 4.9,
            reviewCount = 5620,
            startingPrice = 168,
            thumbnailRes = R.drawable.room_economy_king,
            tags = listOf("近天安门", "前门大街", "看升旗方便", "地铁2/8号线"),
            amenities = listOf("免费高速WiFi", "独立卫浴", "24小时热水", "行李寄存", "旅游咨询", "冷暖空调"),
            distanceToMetro = "距前门地铁站I口步行320米",
            phone = "010-63038888",
            description = "坐落于前门历史文化街区，步行可至天安门广场早起看升旗，周边老字号林立，出行极便。",
            isFeatured = true
        ),
        Hotel(
            id = "gz-01",
            name = "7天酒店·广州天河城体育西路地铁站店",
            nameEn = "7 Days Hotel (Guangzhou Tiyu Xilu Tianhe)",
            city = "广州",
            district = "天河区",
            address = "广州市天河区体育西横街22号",
            latitude = 23.1328,
            longitude = 113.3225,
            rating = 4.8,
            reviewCount = 4120,
            startingPrice = 138,
            thumbnailRes = R.drawable.room_twin_bed,
            tags = listOf("天河CBD", "地铁1/3号线", "美食一条街", "近广州塔"),
            amenities = listOf("免费高速WiFi", "独立卫浴", "24小时热水", "自助洗衣房", "行李寄存"),
            distanceToMetro = "距体育西路地铁站B口步行260米",
            phone = "020-87556666",
            description = "位于广州天河核心商圈体育西路，周边聚集各大广式早茶与特色餐饮，换乘3号线可直达广州塔与白云机场。",
            isFeatured = true
        ),
        Hotel(
            id = "cd-01",
            name = "7天酒店·成都春熙路太古里店",
            nameEn = "7 Days Hotel (Chengdu Chunxi Road Taikoo Li)",
            city = "成都",
            district = "锦江区",
            address = "成都市锦江区东大街下东大街段36号",
            latitude = 30.6558,
            longitude = 104.0812,
            rating = 4.9,
            reviewCount = 4980,
            startingPrice = 142,
            thumbnailRes = R.drawable.room_family_bed,
            tags = listOf("春熙路商圈", "太古里步行5分", "地铁2/3号线", "熊猫基地直通车"),
            amenities = listOf("免费高速WiFi", "独立卫浴", "24小时热水", "旅游咨询", "行李寄存", "空调暖气"),
            distanceToMetro = "距春熙路地铁站C口步行380米",
            phone = "028-86678888",
            description = "近邻成都潮流中心太古里与IFS国金中心，打卡大熊猫户外雕塑超便利，舒适床垫保障出游好睡眠。",
            isFeatured = true
        ),
        Hotel(
            id = "xa-01",
            name = "7天酒店·西安钟楼回民街南门城墙店",
            nameEn = "7 Days Hotel (Xi'an Bell Tower Muslim Street)",
            city = "西安",
            district = "碑林区",
            address = "西安市碑林区南大街东木头市12号",
            latitude = 34.2589,
            longitude = 108.9472,
            rating = 4.8,
            reviewCount = 3760,
            startingPrice = 128,
            thumbnailRes = R.drawable.hotel_branch_facade,
            tags = listOf("钟鼓楼", "回民街夜市", "地铁2号线", "登城墙直达"),
            amenities = listOf("免费高速WiFi", "独立卫浴", "24小时热水", "行李寄存", "吹风机", "空调"),
            distanceToMetro = "距钟楼地铁站C口步行400米",
            phone = "029-87289999",
            description = "身处西安古城核心，步行即达钟鼓楼及回民街品尝肉夹馍、羊肉泡馍，登南门古城墙赏夜景极佳。",
            isFeatured = false
        ),
        Hotel(
            id = "hz-01",
            name = "7天酒店·杭州西湖湖滨步行街音乐喷泉店",
            nameEn = "7 Days Hotel (Hangzhou West Lake Hubin)",
            city = "杭州",
            district = "上城区",
            address = "杭州市上城区延安路258号湖滨商圈",
            latitude = 30.2580,
            longitude = 120.1650,
            rating = 4.8,
            reviewCount = 3420,
            startingPrice = 152,
            thumbnailRes = R.drawable.banner_hero_shanghai,
            tags = listOf("西湖步行6分", "音乐喷泉", "地铁1号线定安路", "高性价比"),
            amenities = listOf("免费高速WiFi", "独立卫浴", "24小时热水", "行李寄存", "空调暖气"),
            distanceToMetro = "距定安路地铁站A口步行300米",
            phone = "0571-87068888",
            description = "漫步可至西湖一公园与湖滨银泰IN77，早起晨跑西湖苏堤，夜晚观赏音乐喷泉，环境宜人。",
            isFeatured = false
        )
    )

    private fun getAllRoomTypes(): List<RoomType> = allRoomTypes

    private val allRoomTypes = listOf(
        // Shanghai People's Square
        RoomType(
            id = "sh-01-r1",
            hotelId = "sh-01",
            name = "经济大床房",
            nameEn = "Economy King Room",
            bedInfo = "1张1.5米大床",
            areaSqM = 12,
            capacity = 2,
            pricePerNight = 148,
            originalPrice = 188,
            imageRes = R.drawable.room_economy_king,
            amenities = listOf("1.5m舒适大床", "独立卫浴", "封包毛巾", "静音空调", "免费WiFi"),
            cancelPolicy = "入住当天18:00前免费取消",
            remainingInventory = 6
        ),
        RoomType(
            id = "sh-01-r2",
            hotelId = "sh-01",
            name = "标准双床房",
            nameEn = "Standard Twin Room",
            bedInfo = "2张1.2米单人床",
            areaSqM = 18,
            capacity = 2,
            pricePerNight = 168,
            originalPrice = 208,
            imageRes = R.drawable.room_twin_bed,
            amenities = listOf("2张单人床", "采光外窗", "独立卫浴", "电热水壶", "免费WiFi"),
            cancelPolicy = "入住当天18:00前免费取消",
            remainingInventory = 4
        ),
        RoomType(
            id = "sh-01-r3",
            hotelId = "sh-01",
            name = "家庭房",
            nameEn = "Family Room",
            bedInfo = "1张1.8米大床 + 1张上铺",
            areaSqM = 22,
            capacity = 4,
            pricePerNight = 228,
            originalPrice = 288,
            imageRes = R.drawable.room_family_bed,
            amenities = listOf("亲子上下铺设计", "宽敞空间", "独立卫浴", "儿童洗漱包", "免费WiFi"),
            cancelPolicy = "入住当天18:00前免费取消",
            remainingInventory = 3
        ),

        // Shanghai Lujiazui
        RoomType(
            id = "sh-02-r1",
            hotelId = "sh-02",
            name = "经济大床房",
            nameEn = "Economy King Room",
            bedInfo = "1张1.5米大床",
            areaSqM = 14,
            capacity = 2,
            pricePerNight = 158,
            originalPrice = 198,
            imageRes = R.drawable.room_economy_king,
            amenities = listOf("1.5m大床", "独立淋浴间", "24h热水", "免费WiFi"),
            cancelPolicy = "入住当天18:00前免费取消",
            remainingInventory = 5
        ),
        RoomType(
            id = "sh-02-r2",
            hotelId = "sh-02",
            name = "标准双床房",
            nameEn = "Standard Twin Room",
            bedInfo = "2张1.2米单人床",
            areaSqM = 18,
            capacity = 2,
            pricePerNight = 178,
            originalPrice = 218,
            imageRes = R.drawable.room_twin_bed,
            amenities = listOf("2张单人床", "高层外窗", "独立卫浴", "办公桌椅", "免费WiFi"),
            cancelPolicy = "入住当天18:00前免费取消",
            remainingInventory = 4
        ),

        // Beijing Qianmen
        RoomType(
            id = "bj-01-r1",
            hotelId = "bj-01",
            name = "经济大床房",
            nameEn = "Economy King Room",
            bedInfo = "1张1.5米大床",
            areaSqM = 13,
            capacity = 2,
            pricePerNight = 168,
            originalPrice = 218,
            imageRes = R.drawable.room_economy_king,
            amenities = listOf("1.5m舒适大床", "品牌洗护", "静音空调", "免费WiFi"),
            cancelPolicy = "入住当天18:00前免费取消",
            remainingInventory = 8
        ),
        RoomType(
            id = "bj-01-r2",
            hotelId = "bj-01",
            name = "标准双床房",
            nameEn = "Standard Twin Room",
            bedInfo = "2张1.2米单人床",
            areaSqM = 19,
            capacity = 2,
            pricePerNight = 188,
            originalPrice = 238,
            imageRes = R.drawable.room_twin_bed,
            amenities = listOf("2张单人床", "独立卫浴", "电吹风", "免费WiFi"),
            cancelPolicy = "入住当天18:00前免费取消",
            remainingInventory = 5
        ),
        RoomType(
            id = "bj-01-r3",
            hotelId = "bj-01",
            name = "家庭房",
            nameEn = "Family Room",
            bedInfo = "1张1.8米大床 + 1张单人床",
            areaSqM = 24,
            capacity = 3,
            pricePerNight = 248,
            originalPrice = 308,
            imageRes = R.drawable.room_family_bed,
            amenities = listOf("超宽大床", "单人床", "全套一次性洗漱", "免费WiFi"),
            cancelPolicy = "入住当天18:00前免费取消",
            remainingInventory = 2
        ),

        // Guangzhou Tianhe
        RoomType(
            id = "gz-01-r1",
            hotelId = "gz-01",
            name = "经济大床房",
            nameEn = "Economy King Room",
            bedInfo = "1张1.5米大床",
            areaSqM = 12,
            capacity = 2,
            pricePerNight = 138,
            originalPrice = 178,
            imageRes = R.drawable.room_economy_king,
            amenities = listOf("舒适床品", "独立卫浴", "免费WiFi"),
            cancelPolicy = "入住当天18:00前免费取消",
            remainingInventory = 6
        ),
        RoomType(
            id = "gz-01-r2",
            hotelId = "gz-01",
            name = "标准双床房",
            nameEn = "Standard Twin Room",
            bedInfo = "2张1.2米单人床",
            areaSqM = 18,
            capacity = 2,
            pricePerNight = 158,
            originalPrice = 198,
            imageRes = R.drawable.room_twin_bed,
            amenities = listOf("2张单人床", "独立卫浴", "免费WiFi"),
            cancelPolicy = "入住当天18:00前免费取消",
            remainingInventory = 5
        ),

        // Chengdu Chunxi Road
        RoomType(
            id = "cd-01-r1",
            hotelId = "cd-01",
            name = "经济大床房",
            nameEn = "Economy King Room",
            bedInfo = "1张1.5米大床",
            areaSqM = 13,
            capacity = 2,
            pricePerNight = 142,
            originalPrice = 180,
            imageRes = R.drawable.room_economy_king,
            amenities = listOf("静音睡眠垫", "独立卫浴", "免费WiFi"),
            cancelPolicy = "入住当天18:00前免费取消",
            remainingInventory = 7
        ),
        RoomType(
            id = "cd-01-r2",
            hotelId = "cd-01",
            name = "标准双床房",
            nameEn = "Standard Twin Room",
            bedInfo = "2张1.2米单人床",
            areaSqM = 18,
            capacity = 2,
            pricePerNight = 162,
            originalPrice = 200,
            imageRes = R.drawable.room_twin_bed,
            amenities = listOf("2张床", "观景窗", "独立卫浴", "免费WiFi"),
            cancelPolicy = "入住当天18:00前免费取消",
            remainingInventory = 4
        ),

        // Xi'an Bell Tower
        RoomType(
            id = "xa-01-r1",
            hotelId = "xa-01",
            name = "经济大床房",
            nameEn = "Economy King Room",
            bedInfo = "1张1.5米大床",
            areaSqM = 12,
            capacity = 2,
            pricePerNight = 128,
            originalPrice = 160,
            imageRes = R.drawable.room_economy_king,
            amenities = listOf("1.5米床", "独立卫浴", "冷暖空调", "免费WiFi"),
            cancelPolicy = "入住当天18:00前免费取消",
            remainingInventory = 6
        ),

        // Hangzhou West Lake
        RoomType(
            id = "hz-01-r1",
            hotelId = "hz-01",
            name = "经济大床房",
            nameEn = "Economy King Room",
            bedInfo = "1张1.5米大床",
            areaSqM = 13,
            capacity = 2,
            pricePerNight = 152,
            originalPrice = 192,
            imageRes = R.drawable.room_economy_king,
            amenities = listOf("1.5米床", "独立卫浴", "免费WiFi"),
            cancelPolicy = "入住当天18:00前免费取消",
            remainingInventory = 5
        )
    )
    }
}
