package com.example.ui.detail

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.Hotel
import com.example.data.model.RatePlan
import com.example.data.model.RoomType
import com.example.data.repository.HotelRepository
import com.example.ui.components.FeaturePill
import com.example.ui.components.PriceDisplay
import com.example.ui.components.SectionHeader
import com.example.ui.theme.BrandCharcoal
import com.example.ui.theme.BrandGreen
import com.example.ui.theme.BrandRed
import com.example.ui.theme.BrandYellowContainer
import com.example.ui.theme.BrandYellowPrimary
import com.example.ui.theme.NeutralBg
import com.example.ui.theme.NeutralBorder
import com.example.ui.theme.NeutralSurface
import com.example.ui.theme.NeutralTextMuted
import com.example.ui.theme.NeutralTextPrimary
import com.example.ui.theme.NeutralTextSecondary
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HotelDetailScreen(
    hotelId: String,
    hotelRepository: HotelRepository,
    onBackClick: () -> Unit,
    onBookRoomClick: (hotelId: String, roomId: String, ratePlanId: String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val hotel = remember(hotelId) { hotelRepository.getHotelById(hotelId) }
    val rooms = remember(hotelId) { hotelRepository.getRoomsForHotel(hotelId) }
    var isSaved by remember { mutableStateOf(false) }

    LaunchedEffect(hotelId) {
        isSaved = hotelRepository.isHotelSaved(hotelId)
    }

    if (hotel == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("酒店不存在或已下架")
        }
        return
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(NeutralBg)
            .testTag("hotel_detail_screen")
    ) {
        // Top Image Gallery with Back & Action Bar
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(230.dp)
            ) {
                Image(
                    painter = painterResource(id = hotel.thumbnailRes),
                    contentDescription = hotel.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Navigation Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 24.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onBackClick,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.5f))
                            .testTag("back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "返回",
                            tint = Color.White
                        )
                    }

                    Row {
                        IconButton(
                            onClick = {
                                scope.launch {
                                    hotelRepository.toggleSaveHotel(hotelId)
                                    isSaved = !isSaved
                                    Toast.makeText(
                                        context,
                                        if (isSaved) "已收藏至我的酒店" else "已取消收藏",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            },
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(Color.Black.copy(alpha = 0.5f))
                                .testTag("favorite_button")
                        ) {
                            Icon(
                                imageVector = if (isSaved) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                contentDescription = "收藏",
                                tint = if (isSaved) BrandRed else Color.White
                            )
                        }
                    }
                }
            }
        }

        // Hotel Info Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = NeutralSurface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = hotel.name,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = NeutralTextPrimary
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = hotel.nameEn,
                                fontSize = 11.sp,
                                color = NeutralTextMuted
                            )
                        }
                        // Score badge
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = BrandCharcoal
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Star,
                                    contentDescription = null,
                                    tint = BrandYellowPrimary,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = "${hotel.rating}",
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Metro & Address
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = null,
                            tint = BrandGreen,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = hotel.distanceToMetro,
                            fontSize = 13.sp,
                            color = NeutralTextSecondary
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "地址: ${hotel.address}",
                        fontSize = 12.sp,
                        color = NeutralTextSecondary
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Tags
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        hotel.tags.forEach { tag ->
                            FeaturePill(text = tag, highlight = tag.contains("地铁") || tag.contains("商圈"))
                        }
                    }
                }
            }
        }

        // Brand Policies Commitment Bar
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF9FAFB))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    PolicyItem(icon = Icons.Default.Schedule, title = "入住 14:00后", desc = "退房 12:00前")
                    PolicyItem(icon = Icons.Default.Security, title = "24h安保巡逻", desc = "刷卡进门更放心")
                    PolicyItem(icon = Icons.Default.Wifi, title = "千兆高速WiFi", desc = "全店免费覆盖")
                }
            }
        }

        // Room Selection Header
        item {
            SectionHeader(
                title = "选择预订房型",
                subtitle = "官方实时房态 · 下单即时确认"
            )
        }

        // Room Cards List
        items(rooms) { room ->
            val ratePlans = remember(room) { hotelRepository.getRatePlansForRoom(room) }
            RoomItemCard(
                room = room,
                ratePlans = ratePlans,
                onBookRatePlan = { planId ->
                    onBookRoomClick(hotel.id, room.id, planId)
                }
            )
        }

        // Hotel Description and Verified FAQ
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = NeutralSurface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "分店简介与设施",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = NeutralTextPrimary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = hotel.description,
                        fontSize = 13.sp,
                        color = NeutralTextSecondary,
                        lineHeight = 18.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "配套设施",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = NeutralTextPrimary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        hotel.amenities.forEach { amenity ->
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = NeutralBg,
                                border = androidx.compose.foundation.BorderStroke(1.dp, NeutralBorder)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = null,
                                        tint = BrandGreen,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = amenity,
                                        fontSize = 11.sp,
                                        color = NeutralTextPrimary
                                    )
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = Icons.Default.Call,
                            contentDescription = null,
                            tint = BrandCharcoal,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "分店前台热线: ${hotel.phone}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = BrandCharcoal
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun PolicyItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    desc: String
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = BrandCharcoal,
            modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = title, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = NeutralTextPrimary)
        Text(text = desc, fontSize = 10.sp, color = NeutralTextSecondary)
    }
}

@Composable
fun RoomItemCard(
    room: RoomType,
    ratePlans: List<RatePlan>,
    onBookRatePlan: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .testTag("room_item_card_${room.id}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = NeutralSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top
            ) {
                Image(
                    painter = painterResource(id = room.imageRes),
                    contentDescription = room.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(90.dp)
                        .clip(RoundedCornerShape(8.dp))
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = room.name,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = NeutralTextPrimary
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${room.bedInfo} · ${room.areaSqM}m² · 最多住${room.capacity}人",
                        fontSize = 12.sp,
                        color = NeutralTextSecondary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = room.cancelPolicy,
                        fontSize = 11.sp,
                        color = BrandGreen
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(3.dp),
                            color = if (room.remainingInventory <= 3) Color(0xFFFFEBEE) else Color(0xFFE8F5E9)
                        ) {
                            Text(
                                text = if (room.remainingInventory <= 3) "仅剩 ${room.remainingInventory} 间" else "房态充裕",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (room.remainingInventory <= 3) BrandRed else BrandGreen,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Divider(color = NeutralBorder, thickness = 0.8.dp)
            Spacer(modifier = Modifier.height(8.dp))

            // Rate Plans Section
            ratePlans.forEach { plan ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = plan.name,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = NeutralTextPrimary
                        )
                        Text(
                            text = plan.memberDiscountDesc,
                            fontSize = 11.sp,
                            color = NeutralTextSecondary
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Column(horizontalAlignment = Alignment.End) {
                        PriceDisplay(price = plan.price, originalPrice = plan.originalPrice, fontSize = 18)
                        Spacer(modifier = Modifier.height(4.dp))
                        Button(
                            onClick = { onBookRatePlan(plan.id) },
                            enabled = room.remainingInventory > 0,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = BrandYellowPrimary,
                                contentColor = BrandCharcoal
                            ),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier
                                .height(32.dp)
                                .testTag("book_plan_${plan.id}")
                        ) {
                            Text(
                                text = if (room.remainingInventory > 0) "预订" else "已订完",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}
