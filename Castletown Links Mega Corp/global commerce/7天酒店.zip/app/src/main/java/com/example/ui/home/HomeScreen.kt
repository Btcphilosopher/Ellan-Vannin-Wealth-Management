package com.example.ui.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CardMembership
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.NearMe
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.Booking
import com.example.data.model.Hotel
import com.example.data.model.RoomType
import com.example.data.model.SearchCriteria
import com.example.data.repository.BookingRepository
import com.example.data.repository.HotelRepository
import com.example.ui.components.FeaturePill
import com.example.ui.components.PriceDisplay
import com.example.ui.components.SectionHeader
import com.example.ui.components.SevenDaysBrandLogo
import com.example.ui.components.SevenDaysHeaderBar
import com.example.ui.theme.BrandCharcoal
import com.example.ui.theme.BrandCharcoalLight
import com.example.ui.theme.BrandGreen
import com.example.ui.theme.BrandRed
import com.example.ui.theme.BrandYellowContainer
import com.example.ui.theme.BrandYellowDark
import com.example.ui.theme.BrandYellowPrimary
import com.example.ui.theme.NeutralBg
import com.example.ui.theme.NeutralBorder
import com.example.ui.theme.NeutralSurface
import com.example.ui.theme.NeutralTextMuted
import com.example.ui.theme.NeutralTextPrimary
import com.example.ui.theme.NeutralTextSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeScreen(
    hotelRepository: HotelRepository,
    bookingRepository: BookingRepository,
    onNavigateToSearch: (SearchCriteria) -> Unit,
    onNavigateToHotelDetail: (String) -> Unit,
    onNavigateToRoomBooking: (hotelId: String, roomId: String) -> Unit,
    onNavigateToTrips: () -> Unit,
    onNavigateToExploreCity: (String) -> Unit
) {
    var searchCriteria by remember { mutableStateOf(SearchCriteria(city = "上海")) }
    val featuredHotels = remember { hotelRepository.getFeaturedHotels() }
    val bookings by bookingRepository.allBookings.collectAsState(initial = emptyList())
    val activeBooking = bookings.firstOrNull { it.status.name == "CONFIRMED" }

    val popularCities = listOf("上海", "北京", "广州", "深圳", "成都", "杭州", "南京", "武汉", "西安")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(NeutralBg)
            .testTag("home_screen")
    ) {
        // 1. Header Bar with 7 Days Logo
        item {
            SevenDaysHeaderBar(
                title = "7天酒店",
                subtitle = "好睡 · 省钱 · 到哪都在",
                showLogo = true
            )
        }

        // 2. Upcoming Active Booking Card (if user has a confirmed stay)
        if (activeBooking != null) {
            item {
                ActiveBookingBanner(
                    booking = activeBooking,
                    onClick = onNavigateToTrips
                )
            }
        }

        // 3. Hero Visual Banner (Website exact match)
        item {
            HeroBanner(
                onBookNowClick = {
                    onNavigateToSearch(searchCriteria)
                }
            )
        }

        // 4. Floating Dark Hotel Search Widget (Website exact match)
        item {
            SearchWidgetCard(
                criteria = searchCriteria,
                onCriteriaChange = { searchCriteria = it },
                onSearchClick = { onNavigateToSearch(searchCriteria) },
                popularCities = popularCities
            )
        }

        // 5. Brand 5 Value Promises (Website exact match)
        item {
            BrandCommitmentsSection()
        }

        // 6. Featured Room Types (精选房型 - Website exact match)
        item {
            SectionHeader(
                title = "精选房型",
                subtitle = "简约舒适 · 满足不同出行需求",
                actionText = "查看更多房型 →",
                onActionClick = { onNavigateToSearch(searchCriteria) }
            )
        }

        item {
            FeaturedRoomsRow(
                onRoomClick = { roomId ->
                    // Default to Shanghai flagship store for demo
                    val targetHotelId = "sh-01"
                    onNavigateToRoomBooking(targetHotelId, roomId)
                }
            )
        }

        // 7. Nationwide Network Banner (全国超过 500 家酒店)
        item {
            NationwideHotelBanner(
                onViewBranchesClick = {
                    onNavigateToSearch(searchCriteria.copy(city = ""))
                }
            )
        }

        // 8. Member Promotion & Hot City Matrix (Website exact match)
        item {
            MemberAndCitiesSection(
                popularCities = popularCities,
                onSelectCity = { city ->
                    searchCriteria = searchCriteria.copy(city = city)
                    onNavigateToSearch(searchCriteria.copy(city = city))
                },
                onExploreCity = onNavigateToExploreCity
            )
        }

        item {
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun ActiveBookingBanner(
    booking: Booking,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clickable { onClick() }
            .testTag("active_booking_banner"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = BrandCharcoal),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(BrandYellowPrimary),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.CalendarMonth,
                    contentDescription = null,
                    tint = BrandCharcoal,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "即将出行",
                        color = BrandYellowPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${booking.checkInDate} 入住",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Text(
                    text = booking.hotelName,
                    color = Color(0xFFE5E7EB),
                    fontSize = 13.sp,
                    maxLines = 1
                )
            }
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = "查看详情",
                tint = BrandYellowPrimary,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
fun HeroBanner(
    onBookNowClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(200.dp)
    ) {
        Image(
            painter = painterResource(id = R.drawable.banner_hero_shanghai),
            contentDescription = "7天酒店 舒适客房与上海天际线",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        // Semi-transparent gradient overlay for text readability
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.45f))
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "好睡 · 省钱 · 到哪都在",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Black
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "7天酒店 让每一次出行更简单",
                color = BrandYellowPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )
            Spacer(modifier = Modifier.height(14.dp))
            Button(
                onClick = onBookNowClick,
                colors = ButtonDefaults.buttonColors(
                    containerColor = BrandYellowPrimary,
                    contentColor = BrandCharcoal
                ),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.testTag("hero_book_now_button")
            ) {
                Text(
                    text = "立即预订 →",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SearchWidgetCard(
    criteria: SearchCriteria,
    onCriteriaChange: (SearchCriteria) -> Unit,
    onSearchClick: () -> Unit,
    popularCities: List<String>
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag("search_widget_card"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = BrandCharcoal),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // City / Destination Row
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(BrandCharcoalLight)
                    .padding(horizontal = 12.dp, vertical = 10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.LocationOn,
                    contentDescription = null,
                    tint = BrandYellowPrimary,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "目的地",
                        fontSize = 11.sp,
                        color = Color(0xFF9CA3AF)
                    )
                    Text(
                        text = criteria.city,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Quick City Chips
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                popularCities.take(6).forEach { city ->
                    val isSelected = criteria.city == city
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (isSelected) BrandYellowPrimary else BrandCharcoalLight)
                            .clickable { onCriteriaChange(criteria.copy(city = city)) }
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = city,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) BrandCharcoal else Color(0xFFD1D5DB)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Dates & Guests Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Dates Card
                Row(
                    modifier = Modifier
                        .weight(1.3f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(BrandCharcoalLight)
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.CalendarMonth,
                        contentDescription = null,
                        tint = BrandYellowPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "入住 - 离店",
                            fontSize = 10.sp,
                            color = Color(0xFF9CA3AF)
                        )
                        Text(
                            text = "${criteria.checkInDate.substring(5)} 至 ${criteria.checkOutDate.substring(5)}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }

                // Rooms & Guests
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(BrandCharcoalLight)
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = null,
                        tint = BrandYellowPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Text(
                            text = "房间及人数",
                            fontSize = 10.sp,
                            color = Color(0xFF9CA3AF)
                        )
                        Text(
                            text = "${criteria.rooms}间房 ${criteria.guests}人",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Search Hotel CTA Button
            Button(
                onClick = onSearchClick,
                colors = ButtonDefaults.buttonColors(
                    containerColor = BrandYellowPrimary,
                    contentColor = BrandCharcoal
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .testTag("search_hotels_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "搜索酒店",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun BrandCommitmentsSection() {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = NeutralSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 14.dp, horizontal = 8.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            CommitmentItem(
                icon = Icons.Default.MonetizationOn,
                title = "价格实惠",
                subtitle = "高性价比"
            )
            CommitmentItem(
                icon = Icons.Default.Security,
                title = "安全放心",
                subtitle = "24h安保"
            )
            CommitmentItem(
                icon = Icons.Default.Wifi,
                title = "免费WiFi",
                subtitle = "全店覆盖"
            )
            CommitmentItem(
                icon = Icons.Default.NearMe,
                title = "便捷位置",
                subtitle = "邻近地铁"
            )
            CommitmentItem(
                icon = Icons.Default.Headphones,
                title = "贴心服务",
                subtitle = "随时响应"
            )
        }
    }
}

@Composable
fun CommitmentItem(
    icon: ImageVector,
    title: String,
    subtitle: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.width(60.dp)
    ) {
        Box(
            modifier = Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(BrandYellowContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = BrandCharcoal,
                modifier = Modifier.size(18.dp)
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = title,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = NeutralTextPrimary
        )
        Text(
            text = subtitle,
            fontSize = 9.sp,
            color = NeutralTextSecondary
        )
    }
}

@Composable
fun FeaturedRoomsRow(
    onRoomClick: (String) -> Unit
) {
    val rooms = listOf(
        Triple("sh-01-r1", "经济大床房", Triple(R.drawable.room_economy_king, "1张1.5米大床 · 12m² · 1-2人", 148)),
        Triple("sh-01-r2", "标准双床房", Triple(R.drawable.room_twin_bed, "2张1.2米单人床 · 18m² · 2人", 168)),
        Triple("sh-01-r3", "家庭房", Triple(R.drawable.room_family_bed, "1张1.8米大床 + 1张上铺 · 22m² · 3-4人", 228))
    )

    LazyRow(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(rooms) { (roomId, name, details) ->
            val (imageRes, specs, price) = details
            Card(
                modifier = Modifier
                    .width(230.dp)
                    .clickable { onRoomClick(roomId) }
                    .testTag("featured_room_$roomId"),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = NeutralSurface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column {
                    Image(
                        painter = painterResource(id = imageRes),
                        contentDescription = name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                    )
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = name,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = NeutralTextPrimary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = specs,
                            fontSize = 11.sp,
                            color = NeutralTextSecondary,
                            maxLines = 1
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            PriceDisplay(price = price)
                            Button(
                                onClick = { onRoomClick(roomId) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = BrandYellowPrimary,
                                    contentColor = BrandCharcoal
                                ),
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier
                                    .height(30.dp)
                                    .testTag("book_button_$roomId")
                            ) {
                                Text(
                                    text = "预订",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NationwideHotelBanner(
    onViewBranchesClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .clickable { onViewBranchesClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E2838))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "全国超过 500 家酒店",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "覆盖主要城市 · 让旅途更轻松",
                    color = Color(0xFFD1D5DB),
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "查看分店 →",
                        color = BrandYellowPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            Image(
                painter = painterResource(id = R.drawable.hotel_branch_facade),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(70.dp)
                    .clip(RoundedCornerShape(8.dp))
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MemberAndCitiesSection(
    popularCities: List<String>,
    onSelectCity: (String) -> Unit,
    onExploreCity: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
    ) {
        // Member Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = BrandCharcoal)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(BrandYellowPrimary),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CardMembership,
                        contentDescription = null,
                        tint = BrandCharcoal,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "7天星级会员专享",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "注册即享 95折特惠 · 积分兑好礼",
                        color = BrandYellowPrimary,
                        fontSize = 12.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Popular City Guide Recommendation
        Text(
            text = "热门城市指南",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = NeutralTextPrimary
        )
        Spacer(modifier = Modifier.height(8.dp))
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            val cityMap = listOf(
                "shanghai" to "上海",
                "beijing" to "北京",
                "guangzhou" to "广州",
                "chengdu" to "成都"
            )
            cityMap.forEach { (cityId, cityName) ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(NeutralSurface)
                        .border(1.dp, NeutralBorder, RoundedCornerShape(8.dp))
                        .clickable { onExploreCity(cityId) }
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = cityName,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = NeutralTextPrimary
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "指南 →",
                            fontSize = 11.sp,
                            color = BrandYellowDark,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}
