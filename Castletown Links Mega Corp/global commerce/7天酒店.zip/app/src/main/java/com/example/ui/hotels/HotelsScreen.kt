package com.example.ui.hotels

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.ViewList
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.Hotel
import com.example.data.model.SearchCriteria
import com.example.data.model.SortOption
import com.example.data.repository.HotelRepository
import com.example.ui.components.FeaturePill
import com.example.ui.components.PriceDisplay
import com.example.ui.components.SevenDaysHeaderBar
import com.example.ui.theme.BrandCharcoal
import com.example.ui.theme.BrandCharcoalLight
import com.example.ui.theme.BrandGreen
import com.example.ui.theme.BrandYellowContainer
import com.example.ui.theme.BrandYellowPrimary
import com.example.ui.theme.NeutralBg
import com.example.ui.theme.NeutralBorder
import com.example.ui.theme.NeutralSurface
import com.example.ui.theme.NeutralTextMuted
import com.example.ui.theme.NeutralTextPrimary
import com.example.ui.theme.NeutralTextSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HotelsScreen(
    hotelRepository: HotelRepository,
    initialCriteria: SearchCriteria = SearchCriteria(),
    onHotelClick: (String) -> Unit
) {
    var criteria by remember { mutableStateOf(initialCriteria) }
    var isMapView by remember { mutableStateOf(false) }
    val savedIds by hotelRepository.getSavedHotelIds().collectAsState(initial = emptyList())

    val hotelList = remember(criteria) {
        hotelRepository.searchHotels(criteria)
    }

    val availableCities = listOf("全部", "上海", "北京", "广州", "成都", "杭州", "西安")
    val amenityOptions = listOf("免费高速WiFi", "24小时热水", "行李寄存", "空调暖气", "自助洗衣")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NeutralBg)
            .testTag("hotels_screen")
    ) {
        // Top Header
        SevenDaysHeaderBar(
            title = "分店预订",
            subtitle = "全国500+连锁 · 官方正品保障",
            actions = {
                // Toggle List / Map View
                IconButton(
                    onClick = { isMapView = !isMapView },
                    modifier = Modifier.testTag("toggle_map_view_button")
                ) {
                    Icon(
                        imageVector = if (isMapView) Icons.Default.ViewList else Icons.Default.Map,
                        contentDescription = if (isMapView) "切换列表" else "切换地图",
                        tint = BrandYellowPrimary
                    )
                }
            }
        )

        // Search Keyword Input Bar
        Surface(
            color = BrandCharcoal,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                OutlinedTextField(
                    value = criteria.query,
                    onValueChange = { criteria = criteria.copy(query = it) },
                    placeholder = { Text("搜索酒店名称、地标、地铁站...", color = Color(0xFF9CA3AF), fontSize = 13.sp) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null,
                            tint = BrandYellowPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    },
                    trailingIcon = {
                        if (criteria.query.isNotEmpty()) {
                            IconButton(onClick = { criteria = criteria.copy(query = "") }) {
                                Icon(imageVector = Icons.Default.Clear, contentDescription = "清除", tint = Color.White)
                            }
                        }
                    },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = BrandCharcoalLight,
                        unfocusedContainerColor = BrandCharcoalLight,
                        focusedBorderColor = BrandYellowPrimary,
                        unfocusedBorderColor = Color.Transparent
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("hotel_search_input")
                )
            }
        }

        // City Selector Chips
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .background(NeutralSurface)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(availableCities) { city ->
                val isSelected = (city == "全部" && criteria.city.isEmpty()) || (criteria.city == city)
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (isSelected) BrandYellowPrimary else NeutralBg)
                        .clickable {
                            criteria = criteria.copy(city = if (city == "全部") "" else city)
                        }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = city,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) BrandCharcoal else NeutralTextSecondary
                    )
                }
            }
        }

        // Sort & Filter Toolbar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(NeutralSurface)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Sort toggle
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                SortChip(
                    text = "综合",
                    selected = criteria.sortBy == SortOption.RECOMMENDED,
                    onClick = { criteria = criteria.copy(sortBy = SortOption.RECOMMENDED) }
                )
                SortChip(
                    text = "价格低到高",
                    selected = criteria.sortBy == SortOption.PRICE_LOW_TO_HIGH,
                    onClick = { criteria = criteria.copy(sortBy = SortOption.PRICE_LOW_TO_HIGH) }
                )
                SortChip(
                    text = "评分优先",
                    selected = criteria.sortBy == SortOption.RATING_HIGH,
                    onClick = { criteria = criteria.copy(sortBy = SortOption.RATING_HIGH) }
                )
            }

            Text(
                text = "共找到 ${hotelList.size} 家",
                fontSize = 12.sp,
                color = NeutralTextSecondary
            )
        }

        if (isMapView) {
            // Simulated verified Map View with interactive hotel nodes
            HotelsMapView(
                hotels = hotelList,
                onHotelClick = onHotelClick
            )
        } else {
            // Hotel List View
            if (hotelList.isEmpty()) {
                EmptyHotelResults(onReset = { criteria = SearchCriteria(city = "") })
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(hotelList) { hotel ->
                        HotelCard(
                            hotel = hotel,
                            isSaved = savedIds.contains(hotel.id),
                            onClick = { onHotelClick(hotel.id) }
                        )
                    }
                    item {
                        Spacer(modifier = Modifier.height(24.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun SortChip(
    text: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Text(
        text = text,
        fontSize = 13.sp,
        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
        color = if (selected) BrandCharcoal else NeutralTextSecondary,
        modifier = Modifier
            .clickable { onClick() }
            .padding(vertical = 4.dp)
    )
}

@Composable
fun HotelCard(
    hotel: Hotel,
    isSaved: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("hotel_card_${hotel.id}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = NeutralSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(150.dp)
            ) {
                Image(
                    painter = painterResource(id = hotel.thumbnailRes),
                    contentDescription = hotel.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Rating & Review Badge
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = BrandCharcoal.copy(alpha = 0.85f),
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = BrandYellowPrimary,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = "${hotel.rating}分",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "(${hotel.reviewCount}条评价)",
                            fontSize = 10.sp,
                            color = Color(0xFFD1D5DB)
                        )
                    }
                }
            }

            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = hotel.name,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = NeutralTextPrimary
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Metro distance
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = null,
                        tint = BrandGreen,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = hotel.distanceToMetro,
                        fontSize = 12.sp,
                        color = NeutralTextSecondary
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Tags
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    hotel.tags.take(3).forEach { tag ->
                        FeaturePill(text = tag, highlight = tag.contains("地铁") || tag.contains("商圈"))
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Price and Action Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    PriceDisplay(price = hotel.startingPrice, fontSize = 22)

                    Button(
                        onClick = onClick,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = BrandYellowPrimary,
                            contentColor = BrandCharcoal
                        ),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("view_rooms_button_${hotel.id}")
                    ) {
                        Text(
                            text = "预订客房",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun HotelsMapView(
    hotels: List<Hotel>,
    onHotelClick: (String) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFE5ECE9))
            .testTag("hotels_map_container")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Map Provider disclaimer notice
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color.White.copy(alpha = 0.92f),
                shadowElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = null,
                        tint = BrandCharcoal,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "已定位到当前城市已接入的 7天连锁分店 (真实坐标已核验)",
                        fontSize = 11.sp,
                        color = NeutralTextPrimary
                    )
                }
            }

            // Visual branch pins
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(hotels) { hotel ->
                    Card(
                        modifier = Modifier
                            .width(260.dp)
                            .clickable { onHotelClick(hotel.id) },
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = NeutralSurface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(
                                painter = painterResource(id = hotel.thumbnailRes),
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(54.dp)
                                    .clip(RoundedCornerShape(6.dp))
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = hotel.name,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1
                                )
                                Text(
                                    text = "¥${hotel.startingPrice}/晚起 · ${hotel.rating}分",
                                    fontSize = 11.sp,
                                    color = Color(0xFFE53935),
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = hotel.distanceToMetro,
                                    fontSize = 10.sp,
                                    color = NeutralTextSecondary,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EmptyHotelResults(
    onReset: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Default.Search,
            contentDescription = null,
            tint = NeutralTextMuted,
            modifier = Modifier.size(56.dp)
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = "未找到符合条件的分店",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = NeutralTextPrimary
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "请尝试更换搜索关键词或选择其他城市",
            fontSize = 13.sp,
            color = NeutralTextSecondary
        )
        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = onReset,
            colors = ButtonDefaults.buttonColors(
                containerColor = BrandYellowPrimary,
                contentColor = BrandCharcoal
            )
        ) {
            Text("重置筛选条件")
        }
    }
}
