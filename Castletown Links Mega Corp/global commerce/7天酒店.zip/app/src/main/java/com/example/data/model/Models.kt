package com.example.data.model

import androidx.annotation.DrawableRes

enum class BookingStatus(val labelZh: String, val labelEn: String) {
    PENDING("待支付", "Pending Payment"),
    CONFIRMED("已确认", "Confirmed"),
    COMPLETED("已完成", "Completed"),
    CANCELLED("已取消", "Cancelled")
}

enum class PaymentMethod(val labelZh: String, val labelEn: String) {
    WECHAT_PAY("微信支付", "WeChat Pay"),
    ALIPAY("支付宝", "Alipay"),
    UNIONPAY("云闪付 / 银联", "UnionPay"),
    TEST_PAY("沙箱快捷测试支付 (模拟环境)", "Sandbox Test Payment (Simulated)")
}

data class Hotel(
    val id: String,
    val name: String,
    val nameEn: String,
    val city: String,
    val district: String,
    val address: String,
    val latitude: Double,
    val longitude: Double,
    val rating: Double,
    val reviewCount: Int,
    val startingPrice: Int,
    @DrawableRes val thumbnailRes: Int,
    val tags: List<String>,
    val amenities: List<String>,
    val distanceToMetro: String,
    val phone: String,
    val description: String,
    val checkInTime: String = "14:00",
    val checkOutTime: String = "12:00",
    val isFeatured: Boolean = false
)

data class RoomType(
    val id: String,
    val hotelId: String,
    val name: String,
    val nameEn: String,
    val bedInfo: String,
    val areaSqM: Int,
    val capacity: Int,
    val pricePerNight: Int,
    val originalPrice: Int,
    @DrawableRes val imageRes: Int,
    val amenities: List<String>,
    val cancelPolicy: String,
    val remainingInventory: Int,
    val breakfastIncluded: Boolean = false,
    val wifiIncluded: Boolean = true
)

data class RatePlan(
    val id: String,
    val name: String,
    val price: Int,
    val originalPrice: Int,
    val memberDiscountDesc: String,
    val freeCancelUntilHours: Int,
    val breakfastCount: Int,
    val requiresPrepayment: Boolean = true
)

data class Booking(
    val id: Long = 0,
    val bookingReference: String,
    val hotelId: String,
    val hotelName: String,
    val hotelAddress: String,
    val hotelPhone: String,
    val roomTypeId: String,
    val roomTypeName: String,
    @DrawableRes val roomImageRes: Int,
    val checkInDate: String,
    val checkOutDate: String,
    val nightsCount: Int,
    val roomCount: Int,
    val guestName: String,
    val guestPhone: String,
    val specialRequests: String = "",
    val needInvoice: Boolean = false,
    val invoiceTitle: String = "",
    val totalPrice: Int,
    val nightlyRate: Int,
    val status: BookingStatus,
    val paymentMethod: PaymentMethod,
    val paidAt: String,
    val checkInQrCode: String,
    val cancellationPolicyDesc: String,
    val createdAt: Long = System.currentTimeMillis()
)

data class Attraction(
    val name: String,
    val tag: String,
    val metroInfo: String,
    val description: String,
    val ticketPrice: String
)

data class DiningSpot(
    val name: String,
    val specialty: String,
    val averageCost: String,
    val distanceDesc: String
)

data class TransportTip(
    val type: String, // 高铁 / 地铁 / 机场
    val title: String,
    val description: String
)

data class ExploreCity(
    val id: String,
    val name: String,
    val nameZh: String,
    val tag: String,
    val description: String,
    val hotelCount: Int,
    val attractions: List<Attraction>,
    val diningRecommendations: List<DiningSpot>,
    val transportGuides: List<TransportTip>
)

data class ItineraryItem(
    val id: Long = 0,
    val city: String,
    val tripDate: String,
    val timeSlot: String,
    val title: String,
    val category: String, // 住宿 / 景点 / 美食 / 交通
    val notes: String,
    val isCompleted: Boolean = false
)

data class UserAccount(
    val memberId: String = "7D88920194",
    val memberName: String = "7天星级旅伴",
    val phone: String = "138****8866",
    val memberTier: String = "金卡会员 (Gold Member)",
    val discountPercent: Int = 95, // 95折
    val points: Int = 3680,
    val couponCount: Int = 4,
    val isEnglish: Boolean = false
)

data class SearchCriteria(
    val city: String = "上海",
    val checkInDate: String = "2026-10-15",
    val checkOutDate: String = "2026-10-16",
    val nights: Int = 1,
    val guests: Int = 1,
    val rooms: Int = 1,
    val query: String = "",
    val minPrice: Int = 0,
    val maxPrice: Int = 600,
    val selectedAmenities: Set<String> = emptySet(),
    val sortBy: SortOption = SortOption.RECOMMENDED
)

enum class SortOption(val labelZh: String, val labelEn: String) {
    RECOMMENDED("综合推荐", "Recommended"),
    PRICE_LOW_TO_HIGH("价格从低到高", "Price: Low to High"),
    PRICE_HIGH_TO_LOW("价格从高到低", "Price: High to Low"),
    RATING_HIGH("评分最高", "Highest Rating")
}
