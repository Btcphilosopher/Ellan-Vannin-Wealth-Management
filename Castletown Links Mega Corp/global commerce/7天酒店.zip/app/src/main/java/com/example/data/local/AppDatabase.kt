package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        BookingEntity::class,
        SavedHotelEntity::class,
        ItineraryEntity::class,
        SearchHistoryEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun bookingDao(): BookingDao
    abstract fun savedHotelDao(): SavedHotelDao
    abstract fun itineraryDao(): ItineraryDao
    abstract fun searchHistoryDao(): SearchHistoryDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "sevendays_hotel_database.db"
                )
                .fallbackToDestructiveMigration()
                .addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        // Prepopulate default upcoming reservation and demo travel planner
                        CoroutineScope(Dispatchers.IO).launch {
                            val database = getInstance(context)
                            // Initial confirmed booking
                            database.bookingDao().insertBooking(
                                BookingEntity(
                                    bookingReference = "7D202610188942",
                                    hotelId = "sh-01",
                                    hotelName = "7天酒店·上海人民广场南京东路步行街店",
                                    hotelAddress = "上海市黄浦区湖北路18号 (近人民广场地铁站14号口)",
                                    hotelPhone = "021-63518888",
                                    roomTypeId = "sh-01-r1",
                                    roomTypeName = "经济大床房 (1张1.5米大床)",
                                    roomImageRes = R.drawable.room_economy_king,
                                    checkInDate = "2026-10-18",
                                    checkOutDate = "2026-10-20",
                                    nightsCount = 2,
                                    roomCount = 1,
                                    guestName = "张先生",
                                    guestPhone = "13800138000",
                                    specialRequests = "安排无烟高楼层安静房间",
                                    needInvoice = true,
                                    invoiceTitle = "上海星云科技有限公司",
                                    totalPrice = 296,
                                    nightlyRate = 148,
                                    status = "CONFIRMED",
                                    paymentMethod = "WECHAT_PAY",
                                    paidAt = "2026-10-13 10:25",
                                    checkInQrCode = "7D-CHECKIN-20261018-8942",
                                    cancellationPolicyDesc = "入住当天18:00前免费取消"
                                )
                            )

                            // Initial saved hotel
                            database.savedHotelDao().saveHotel(SavedHotelEntity("sh-01"))
                            database.savedHotelDao().saveHotel(SavedHotelEntity("bj-01"))

                            // Initial itinerary notes
                            database.itineraryDao().insertItem(
                                ItineraryEntity(
                                    city = "上海",
                                    tripDate = "2026-10-18",
                                    timeSlot = "14:30",
                                    title = "入住7天酒店人民广场店",
                                    category = "住宿",
                                    notes = "前台支持报手机尾号极速自助办理入住，凭身份证登记"
                                )
                            )
                            database.itineraryDao().insertItem(
                                ItineraryEntity(
                                    city = "上海",
                                    tripDate = "2026-10-18",
                                    timeSlot = "18:00",
                                    title = "漫步外滩及南京东路夜景",
                                    category = "景点",
                                    notes = "酒店步行约12分钟可达外滩观景平台，观赏陆家嘴灯光秀"
                                )
                            )
                            database.itineraryDao().insertItem(
                                ItineraryEntity(
                                    city = "上海",
                                    tripDate = "2026-10-19",
                                    timeSlot = "08:30",
                                    title = "品尝大壶春生煎包 & 鲜肉小笼",
                                    category = "美食",
                                    notes = "四川中路老字号，步行可达，人均20元实惠美味"
                                )
                            )
                        }
                    }
                })
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
