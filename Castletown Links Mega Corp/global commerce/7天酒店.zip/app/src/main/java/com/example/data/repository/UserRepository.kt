package com.example.data.repository

import com.example.data.model.UserAccount
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class UserRepository {
    private val _userState = MutableStateFlow(
        UserAccount(
            memberId = "7D88920194",
            memberName = "7天星级旅伴",
            phone = "138****8866",
            memberTier = "金卡会员",
            discountPercent = 95,
            points = 3680,
            couponCount = 4,
            isEnglish = false
        )
    )
    val userState: StateFlow<UserAccount> = _userState.asStateFlow()

    fun toggleLanguage() {
        _userState.update { current ->
            current.copy(isEnglish = !current.isEnglish)
        }
    }

    fun addPoints(added: Int) {
        _userState.update { current ->
            current.copy(points = current.points + added)
        }
    }

    fun updateProfile(name: String, phone: String) {
        _userState.update { current ->
            current.copy(memberName = name, phone = phone)
        }
    }
}
