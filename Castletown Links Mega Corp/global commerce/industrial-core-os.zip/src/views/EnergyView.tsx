/**
 * INDUSTRIAL CORE OS - Energiemanagementsystem (ISO 50001)
 * Überwacht elektrische Leistung, Spannung, Strom, Druckluft, Wärme, Spitzenlast & kWh/Stück.
 */

import React, { useState, useEffect } from 'react';
import { Zap, Activity, Flame, Wind, Gauge, TrendingUp } from 'lucide-react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import { analyticsEngine } from '../core/AnalyticsEngine';
import { EnergieMetriken } from '../types/industrial';

export const EnergyView: React.FC = () => {
  const [energie, setEnergie] = useState<EnergieMetriken>(analyticsEngine.getEnergieMetriken());
  const [trendDaten, setTrendDaten] = useState<
    { zeit: string; kw: number; druck: number }[]
  >([]);

  useEffect(() => {
    const interval = setInterval(() => {
      const met = analyticsEngine.getEnergieMetriken();
      setEnergie(met);

      const nowStr = new Date().toLocaleTimeString();
      setTrendDaten((prev) => [
        ...prev.slice(-19),
        {
          zeit: nowStr,
          kw: met.elektrischeLeistungKW,
          druck: met.druckluftBar,
        },
      ]);
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex-1 flex flex-col bg-slate-950 text-slate-200 overflow-y-auto p-4 gap-4 text-xs">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-lg flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Zap className="w-5 h-5 text-amber-400" />
          <div>
            <h2 className="font-bold text-sm text-slate-100">ENERGIEMANAGEMENT (ISO 50001)</h2>
            <p className="text-[11px] text-slate-400 font-mono">
              Elektrische Leistung, Peak Load, Druckluft &amp; kWh pro Produktionseinheit
            </p>
          </div>
        </div>

        <div className="bg-amber-950 text-amber-300 px-2.5 py-1 rounded border border-amber-800 text-[11px] font-mono font-bold">
          SPEZ. ENERGIEVERBRAUCH: {energie.kwhProStueck} kWh / Stück
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 font-mono">
        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-lg">
          <div className="text-[10px] text-slate-400 uppercase flex items-center justify-between">
            <span>Elektr. Leistung</span>
            <Zap className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <div className="text-xl font-bold text-amber-400 mt-1">
            {energie.elektrischeLeistungKW.toFixed(1)} kW
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">
            Spannung: {energie.spannungV}V | Strom: {energie.stromA}A
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-lg">
          <div className="text-[10px] text-slate-400 uppercase flex items-center justify-between">
            <span>Druckluftnetz</span>
            <Wind className="w-3.5 h-3.5 text-blue-400" />
          </div>
          <div className="text-xl font-bold text-blue-400 mt-1">
            {energie.druckluftBar.toFixed(1)} bar
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Nenndruck min. 6.0 bar</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-lg">
          <div className="text-[10px] text-slate-400 uppercase flex items-center justify-between">
            <span>Spitzenlast (Peak)</span>
            <TrendingUp className="w-3.5 h-3.5 text-rose-400" />
          </div>
          <div className="text-xl font-bold text-rose-400 mt-1">
            {energie.spitzenlastKW} kW
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">
            Grundlast: {energie.grundlastKW} kW
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-lg">
          <div className="text-[10px] text-slate-400 uppercase flex items-center justify-between">
            <span>Tages-Gesamtenergie</span>
            <Flame className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="text-xl font-bold text-emerald-400 mt-1">
            {energie.gesamtVerbrauchKWh} kWh
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Wärme: {energie.waermeKWh} kWh</div>
        </div>
      </div>

      {/* Recharts Area Chart */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-3">
        <div className="font-bold text-slate-200 border-b border-slate-800 pb-2 flex items-center justify-between">
          <span>Echtzeit Leistungs- &amp; Druckverlauf (Lastgang)</span>
          <span className="text-[10px] font-mono text-slate-400">1-Sekunden-Abtastung</span>
        </div>

        <div className="h-64 w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={trendDaten}>
              <defs>
                <linearGradient id="colorKw" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.8} />
                  <stop offset="95%" stopColor="#f59e0b" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="zeit" stroke="#94a3b8" fontSize={10} />
              <YAxis stroke="#94a3b8" fontSize={10} />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#0f172a',
                  borderColor: '#334155',
                  fontSize: '11px',
                }}
              />
              <Area
                type="monotone"
                dataKey="kw"
                name="Leistung (kW)"
                stroke="#f59e0b"
                fillOpacity={1}
                fill="url(#colorKw)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
