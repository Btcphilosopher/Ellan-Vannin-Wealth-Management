/**
 * INDUSTRIAL CORE OS - Historian & Zeitreihen-Trends
 * Hochleistungs-Zeitreihenanalyse mit Sekunden- und Subsekunden-Abtastung & Multi-Variable Tracking.
 */

import React, { useState, useEffect } from 'react';
import {
  LineChart as LineChartIcon,
  Download,
  Calendar,
  Layers,
  BarChart,
  RefreshCw,
} from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import { historianEngine } from '../core/HistorianEngine';
import { ZeitreihenDatenpunkt } from '../types/industrial';

export const HistorianView: React.FC = () => {
  const [daten, setDaten] = useState<{ zeit: string; speed: number; temp: number; kw: number }[]>([]);
  const [abtastRate, setAbtastRate] = useState<'1s' | '100ms'>('1s');

  useEffect(() => {
    const interval = setInterval(() => {
      const sp = historianEngine.getZeitreiheFuerVariable('DB1.DBD4_IstGeschwindigkeit', 30);
      const tm = historianEngine.getZeitreiheFuerVariable('DB1.DBD8_Lagertemperatur', 30);
      const kw = historianEngine.getZeitreiheFuerVariable('ENERGIE_ElektrischeLeistung', 30);

      const kombinierterVerlauf = sp.map((p, idx) => {
        return {
          zeit: new Date(p.msTimestamp).toLocaleTimeString(),
          speed: p.messwert,
          temp: tm[idx]?.messwert || 0,
          kw: kw[idx]?.messwert || 0,
        };
      });

      setDaten(kombinierterVerlauf);
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const handleExportCSV = () => {
    const header = 'Zeitstempel;Drehzahl_Umin;Temperatur_C;Leistung_kW\n';
    const rows = daten.map((d) => `${d.zeit};${d.speed};${d.temp};${d.kw}`).join('\n');
    const blob = new Blob([header + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Industrial_Historian_Export_${Date.now()}.csv`;
    a.click();
  };

  return (
    <div className="flex-1 flex flex-col bg-slate-950 text-slate-200 overflow-y-auto p-4 gap-4 text-xs">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-lg flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <LineChartIcon className="w-5 h-5 text-blue-400" />
          <div>
            <h2 className="font-bold text-sm text-slate-100">INDUSTRIELLER HISTORIAN &amp; ZEITREIHEN-TRENDS</h2>
            <p className="text-[11px] text-slate-400 font-mono">
              Prozesswert-Archivierung mit Millisekunden-Auflösung &amp; Ringpuffer-Retention
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setAbtastRate(abtastRate === '1s' ? '100ms' : '1s')}
            className="bg-slate-800 hover:bg-slate-700 text-slate-300 px-3 py-1.5 rounded border border-slate-700 font-mono text-[11px]"
          >
            Abtastung: {abtastRate}
          </button>
          <button
            onClick={handleExportCSV}
            className="bg-blue-600 hover:bg-blue-500 text-white font-bold px-3 py-1.5 rounded flex items-center gap-1.5 text-[11px]"
          >
            <Download className="w-3.5 h-3.5" />
            CSV Export
          </button>
        </div>
      </div>

      {/* Main Multi-Axis Chart */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-3">
        <div className="font-bold text-slate-200 border-b border-slate-800 pb-2 flex items-center justify-between">
          <span>Prozessdaten-Kurvenverlauf (Drehzahl / Temperatur / Leistung)</span>
          <span className="text-[10px] font-mono text-emerald-400">STATUS: RINGPUFFER ONLINE</span>
        </div>

        <div className="h-80 w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={daten}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="zeit" stroke="#94a3b8" fontSize={10} />
              <YAxis yAxisId="left" stroke="#38bdf8" fontSize={10} />
              <YAxis yAxisId="right" orientation="right" stroke="#f59e0b" fontSize={10} />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#0f172a',
                  borderColor: '#334155',
                  fontSize: '11px',
                }}
              />
              <Legend />
              <Line
                yAxisId="left"
                type="monotone"
                dataKey="speed"
                name="Drehzahl (U/min)"
                stroke="#38bdf8"
                dot={false}
                strokeWidth={2}
              />
              <Line
                yAxisId="right"
                type="monotone"
                dataKey="temp"
                name="Temperatur (°C)"
                stroke="#f59e0b"
                dot={false}
                strokeWidth={2}
              />
              <Line
                yAxisId="right"
                type="monotone"
                dataKey="kw"
                name="Leistung (kW)"
                stroke="#10b981"
                dot={false}
                strokeWidth={2}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
