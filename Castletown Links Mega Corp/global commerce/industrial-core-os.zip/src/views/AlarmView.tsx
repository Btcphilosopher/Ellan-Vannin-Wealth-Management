/**
 * INDUSTRIAL CORE OS - Alarm Server Management
 * Industrielle Alarmtabelle, Quittierung, Priorisierung und Historie.
 */

import React, { useState, useEffect } from 'react';
import {
  Bell,
  CheckCircle2,
  AlertOctagon,
  Filter,
  Check,
  FileSpreadsheet,
} from 'lucide-react';
import { alarmEngine } from '../core/AlarmEngine';
import { AlarmEintrag, AlarmPrioritaet, AlarmStatus } from '../types/industrial';

export const AlarmView: React.FC = () => {
  const [alarme, setAlarme] = useState<AlarmEintrag[]>(alarmEngine.getAlarme());
  const [filterPrioritaet, setFilterPrioritaet] = useState<string>('ALLE');

  useEffect(() => {
    const interval = setInterval(() => {
      setAlarme([...alarmEngine.getAlarme()]);
    }, 500);

    return () => clearInterval(interval);
  }, []);

  const handleQuittieren = (alarmId: string) => {
    alarmEngine.quittiereAlarm(alarmId);
    setAlarme([...alarmEngine.getAlarme()]);
  };

  const gefilterteAlarme = alarme.filter((a) => {
    if (filterPrioritaet === 'ALLE') return true;
    return a.prioritaet === filterPrioritaet;
  });

  return (
    <div className="flex-1 flex flex-col bg-slate-950 text-slate-200 overflow-y-auto p-4 gap-4 text-xs">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-lg flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Bell className="w-5 h-5 text-amber-400" />
          <div>
            <h2 className="font-bold text-sm text-slate-100">INDUSTRIELLES ALARMMANAGEMENT (IEC 62682 / ISA 18.2)</h2>
            <p className="text-[11px] text-slate-400 font-mono">
              Echtzeit Alarmserver, Quittierungs-Workflow &amp; Audit-Anbindung
            </p>
          </div>
        </div>

        {/* Filter Controls */}
        <div className="flex items-center gap-2">
          <Filter className="w-3.5 h-3.5 text-slate-400" />
          <span className="text-slate-400 font-mono">Priorität:</span>
          {['ALLE', 'KRITISCH', 'HOCH', 'MITTEL', 'NIEDRIG'].map((p) => (
            <button
              key={p}
              onClick={() => setFilterPrioritaet(p)}
              className={`px-2.5 py-1 rounded text-[11px] font-mono transition ${
                filterPrioritaet === p
                  ? 'bg-blue-600 text-white font-bold'
                  : 'bg-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      {/* Alarm Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
        <table className="w-full text-left border-collapse font-mono text-[11px]">
          <thead className="bg-slate-950 text-slate-400 uppercase text-[10px]">
            <tr>
              <th className="p-2.5 border-b border-slate-800">Alarm-ID</th>
              <th className="p-2.5 border-b border-slate-800">Zeitstempel</th>
              <th className="p-2.5 border-b border-slate-800">Anlage &amp; Komponente</th>
              <th className="p-2.5 border-b border-slate-800">Priorität</th>
              <th className="p-2.5 border-b border-slate-800">Status</th>
              <th className="p-2.5 border-b border-slate-800">Ursache &amp; Beschreibung</th>
              <th className="p-2.5 border-b border-slate-800">Quittiert Von</th>
              <th className="p-2.5 border-b border-slate-800 text-right">Aktion</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {gefilterteAlarme.map((a) => {
              let prioFarbe = 'text-slate-300';
              if (a.prioritaet === 'KRITISCH') prioFarbe = 'text-rose-400 font-bold bg-rose-950/60 px-1.5 py-0.5 rounded border border-rose-800';
              if (a.prioritaet === 'HOCH') prioFarbe = 'text-amber-400 font-bold bg-amber-950/60 px-1.5 py-0.5 rounded border border-amber-800';
              if (a.prioritaet === 'MITTEL') prioFarbe = 'text-blue-400 font-bold';

              return (
                <tr key={a.alarmId} className="hover:bg-slate-800/40">
                  <td className="p-2.5 font-bold text-slate-200">{a.alarmId}</td>
                  <td className="p-2.5 text-slate-400">{new Date(a.zeitstempel).toLocaleTimeString()}</td>
                  <td className="p-2.5">
                    <div className="font-bold text-slate-200">{a.anlage}</div>
                    <div className="text-[10px] text-slate-500">{a.komponente}</div>
                  </td>
                  <td className="p-2.5">
                    <span className={prioFarbe}>{a.prioritaet}</span>
                  </td>
                  <td className="p-2.5">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        a.status === 'QUITTIERT'
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                          : 'bg-rose-950 text-rose-300 border border-rose-800 animate-pulse'
                      }`}
                    >
                      {a.status}
                    </span>
                  </td>
                  <td className="p-2.5 max-w-xs">
                    <div className="text-slate-200 font-semibold">{a.ursache}</div>
                    <div className="text-[10px] text-slate-400 truncate">{a.beschreibung}</div>
                  </td>
                  <td className="p-2.5 text-slate-300">
                    {a.quittiertVonBenutzer ? (
                      <span className="text-emerald-400 font-semibold">
                        {a.quittiertVonBenutzer} ({new Date(a.quittiertZeitstempel!).toLocaleTimeString()})
                      </span>
                    ) : (
                      <span className="text-slate-600">OFFEN</span>
                    )}
                  </td>
                  <td className="p-2.5 text-right">
                    {!a.quittierungsStatus ? (
                      <button
                        onClick={() => handleQuittieren(a.alarmId)}
                        className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-2.5 py-1 rounded flex items-center gap-1.5 ml-auto text-[10px] shadow"
                      >
                        <Check className="w-3 h-3" />
                        Quittieren
                      </button>
                    ) : (
                      <span className="text-emerald-500 flex items-center gap-1 justify-end font-bold text-[10px]">
                        <CheckCircle2 className="w-3 h-3" />
                        Erledigt
                      </span>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
