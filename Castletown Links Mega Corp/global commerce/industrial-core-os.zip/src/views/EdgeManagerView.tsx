/**
 * INDUSTRIAL CORE OS - Industrial Edge Manager
 * Zentrale Verwaltung von Edge-Knoten, Docker-Container Applikationen und Remote-Deployments.
 */

import React, { useState } from 'react';
import {
  HardDrive,
  Box,
  Play,
  Square,
  RefreshCw,
  Plus,
  Activity,
  Cpu,
  Database,
  Terminal,
} from 'lucide-react';
import { edgeManagerEngine } from '../core/EdgeManagerEngine';
import { EdgeGeraet } from '../types/industrial';

export const EdgeManagerView: React.FC = () => {
  const [geraete, setGeraete] = useState<EdgeGeraet[]>(edgeManagerEngine.getGeraete());
  const [ausgewaehltesGeraetId, setAusgewaehltesGeraetId] = useState<string>('EDGE-NODE-01');
  const [neuesGeraetModal, setNeuesGeraetModal] = useState(false);
  const [neuerName, setNeuerName] = useState('');
  const [neueIp, setNeueIp] = useState('192.168.10.104');
  const [neuerStandort, setNeuerStandort] = useState('Werk Stuttgart - Halle 4');

  const handleSteuerung = (geraetId: string, appId: string, aktion: 'START' | 'STOP' | 'UPDATE') => {
    edgeManagerEngine.steuereApplikation(geraetId, appId, aktion);
    setGeraete([...edgeManagerEngine.getGeraete()]);
  };

  const handleNeuesGeraetRegistrieren = () => {
    if (!neuerName) return;
    edgeManagerEngine.registriereNeuesGeraet(neuerName, neueIp, neuerStandort);
    setGeraete([...edgeManagerEngine.getGeraete()]);
    setNeuesGeraetModal(false);
    setNeuerName('');
  };

  const aktivesGeraet = geraete.find((g) => g.geraetId === ausgewaehltesGeraetId) || geraete[0];

  return (
    <div className="flex-1 flex flex-col bg-slate-950 text-slate-200 overflow-y-auto p-4 gap-4 text-xs">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-lg flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <HardDrive className="w-5 h-5 text-teal-400" />
          <div>
            <h2 className="font-bold text-sm text-slate-100">INDUSTRIAL EDGE DEVICE &amp; APP MANAGER</h2>
            <p className="text-[11px] text-slate-400 font-mono">
              Containerized App Deployment auf IPC-Knoten &amp; Dezentrale OT/IT Orchestrierung
            </p>
          </div>
        </div>

        <button
          onClick={() => setNeuesGeraetModal(true)}
          className="bg-teal-600 hover:bg-teal-500 text-white font-bold px-3 py-1.5 rounded flex items-center gap-1.5 text-[11px] shadow"
        >
          <Plus className="w-3.5 h-3.5" />
          Neues Edge-Gerät registrieren
        </button>
      </div>

      <div className="grid grid-cols-12 gap-4">
        {/* SPALTE 1: GERÄTE-LISTE (4/12) */}
        <div className="col-span-12 md:col-span-4 space-y-2">
          <div className="font-bold text-slate-400 uppercase text-[11px] tracking-wider border-b border-slate-800 pb-1">
            Gekoppelte Industrial Edge Devices
          </div>

          <div className="space-y-2">
            {geraete.map((g) => (
              <div
                key={g.geraetId}
                onClick={() => setAusgewaehltesGeraetId(g.geraetId)}
                className={`p-3 rounded-lg border cursor-pointer transition ${
                  g.geraetId === ausgewaehltesGeraetId
                    ? 'bg-slate-800 border-teal-500 text-white shadow-lg'
                    : 'bg-slate-900/80 border-slate-800 hover:bg-slate-800/60 text-slate-300'
                }`}
              >
                <div className="flex items-center justify-between font-mono">
                  <span className="font-bold text-teal-300">{g.name}</span>
                  <span
                    className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${
                      g.status === 'ONLINE'
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                        : 'bg-amber-950 text-amber-400 border border-amber-800'
                    }`}
                  >
                    {g.status}
                  </span>
                </div>

                <div className="text-[10px] text-slate-400 font-mono mt-1">
                  {g.ipAdresse} | {g.standort}
                </div>

                <div className="grid grid-cols-3 gap-2 mt-2 pt-2 border-t border-slate-800/80 text-[10px] font-mono text-slate-400">
                  <div>CPU: <span className="font-bold text-slate-200">{g.cpuAuslastungProzent}%</span></div>
                  <div>RAM: <span className="font-bold text-slate-200">{g.ramAuslastungProzent}%</span></div>
                  <div>Apps: <span className="font-bold text-teal-400">{g.applikationen.length}</span></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* SPALTE 2: GERÄTEDETAILS & CONTAINER APPLIKATIONEN (8/12) */}
        <div className="col-span-12 md:col-span-8 bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-4">
          <div className="border-b border-slate-800 pb-2 flex items-center justify-between">
            <div>
              <h3 className="font-bold text-sm text-slate-100">{aktivesGeraet.name}</h3>
              <p className="text-[10px] text-slate-400 font-mono">
                {aktivesGeraet.geraetId} | Firmware: {aktivesGeraet.firmwareVersion} | IP: {aktivesGeraet.ipAdresse}
              </p>
            </div>
            <span className="text-[10px] font-mono bg-slate-800 text-teal-300 px-2.5 py-1 rounded border border-slate-700">
              Docker Engine v24.0.5
            </span>
          </div>

          <div className="space-y-2">
            <div className="font-semibold text-slate-300 text-xs">
              Installierte Edge Container Applikationen
            </div>

            <div className="space-y-2 font-mono">
              {aktivesGeraet.applikationen.length === 0 ? (
                <div className="p-4 bg-slate-950 rounded text-center text-slate-500 text-xs">
                  Keine Apps auf diesem Knoten installiert.
                </div>
              ) : (
                aktivesGeraet.applikationen.map((app) => (
                  <div
                    key={app.appId}
                    className="bg-slate-950 p-3 rounded border border-slate-800 flex flex-wrap items-center justify-between gap-3"
                  >
                    <div>
                      <div className="font-bold text-slate-100 flex items-center gap-2">
                        <Box className="w-3.5 h-3.5 text-teal-400" />
                        <span>{app.name}</span>
                        <span className="text-[10px] text-slate-500 font-normal">({app.version})</span>
                      </div>
                      <div className="text-[10px] text-slate-500 mt-0.5">
                        Container-ID: {app.dockerContainerId} | CPU: {app.cpuNutzungProzent}% | RAM: {app.speicherMB} MB
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          app.status === 'LAEUFT'
                            ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                            : app.status === 'FEHLER'
                            ? 'bg-rose-950 text-rose-400 border border-rose-800'
                            : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        {app.status}
                      </span>

                      <button
                        onClick={() => handleSteuerung(aktivesGeraet.geraetId, app.appId, 'START')}
                        className="bg-emerald-950 hover:bg-emerald-900 text-emerald-300 px-2 py-1 rounded text-[10px] border border-emerald-800"
                        title="Starten"
                      >
                        <Play className="w-3 h-3" />
                      </button>
                      <button
                        onClick={() => handleSteuerung(aktivesGeraet.geraetId, app.appId, 'STOP')}
                        className="bg-slate-800 hover:bg-slate-700 text-slate-300 px-2 py-1 rounded text-[10px] border border-slate-700"
                        title="Stoppen"
                      >
                        <Square className="w-3 h-3" />
                      </button>
                      <button
                        onClick={() => handleSteuerung(aktivesGeraet.geraetId, app.appId, 'UPDATE')}
                        className="bg-blue-950 hover:bg-blue-900 text-blue-300 px-2 py-1 rounded text-[10px] border border-blue-800"
                        title="App Update durchführen"
                      >
                        <RefreshCw className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>

      {/* MODAL FÜR NEUES EDGE GERÄT */}
      {neuesGeraetModal && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-lg max-w-md w-full p-5 text-slate-100 space-y-4">
            <div className="font-bold text-sm border-b border-slate-800 pb-2">
              Neues Industrial Edge Device registrieren
            </div>

            <div className="space-y-3 font-mono text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Gerätename / Hardware</label>
                <input
                  type="text"
                  value={neuerName}
                  onChange={(e) => setNeuerName(e.target.value)}
                  placeholder="z.B. Siemens Industrial Edge Box IPC327E"
                  className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">IP-Adresse (PROFINET / OT)</label>
                <input
                  type="text"
                  value={neueIp}
                  onChange={(e) => setNeueIp(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Standort / Halle</label>
                <input
                  type="text"
                  value={neuerStandort}
                  onChange={(e) => setNeuerStandort(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
              <button
                onClick={() => setNeuesGeraetModal(false)}
                className="bg-slate-800 text-slate-300 px-3 py-1.5 rounded"
              >
                Abbrechen
              </button>
              <button
                onClick={handleNeuesGeraetRegistrieren}
                className="bg-teal-600 text-white font-bold px-3 py-1.5 rounded"
              >
                Gerät Registrieren
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
