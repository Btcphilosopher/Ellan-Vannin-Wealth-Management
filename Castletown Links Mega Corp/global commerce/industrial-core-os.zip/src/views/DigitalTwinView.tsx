/**
 * INDUSTRIAL CORE OS - Digital Twin Manager & Asset States
 * Verbindet Echtzeit-Betriebsdaten mit Simulationsmodellen und Parametrierung.
 */

import React, { useState, useEffect } from 'react';
import {
  Box,
  Cpu,
  Activity,
  Wrench,
  Zap,
  Gauge,
  Thermometer,
  ShieldCheck,
  RotateCcw,
} from 'lucide-react';
import { assetEngine } from '../core/AssetEngine';
import { plcEngine } from '../core/PLCEngine';
import { DigitalerZwilling } from '../types/industrial';

export const DigitalTwinView: React.FC = () => {
  const [zwillinge, setZwillinge] = useState<DigitalerZwilling[]>(assetEngine.getAlleZwillinge());
  const [ausgewaehlterZwilling, setAusgewaehlterZwilling] = useState<DigitalerZwilling>(zwillinge[0]);
  const [speed, setSpeed] = useState<number>(1448);
  const [temp, setTemp] = useState<number>(52.4);

  useEffect(() => {
    const interval = setInterval(() => {
      const s = plcEngine.getVariableWert('DB1.DBD4') as number;
      const t = plcEngine.getVariableWert('DB1.DBD8') as number;
      setSpeed(s || 0);
      setTemp(t || 0);
    }, 500);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex-1 flex flex-col bg-slate-950 text-slate-200 overflow-y-auto p-4 gap-4 text-xs">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-lg flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Box className="w-5 h-5 text-purple-400" />
          <div>
            <h2 className="font-bold text-sm text-slate-100">DIGITALER ZWILLING (DIGITAL TWIN ENGINE)</h2>
            <p className="text-[11px] text-slate-400 font-mono">
              Echtzeit-Synchronisation zwischen physischer Anlage &amp; Simulations-Modell
            </p>
          </div>
        </div>

        <div className="bg-purple-950 text-purple-300 px-2.5 py-1 rounded border border-purple-800 text-[11px] font-mono font-bold">
          TWIN STATUS: ECHTZEIT KOPPLUNG AKTIV
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Left: Twin Asset Details Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-3">
          <div className="font-bold text-slate-200 border-b border-slate-800 pb-2">
            Asset-Spezifikation
          </div>

          <div className="space-y-2 font-mono text-[11px]">
            <div>
              <span className="text-slate-400">Asset-ID:</span>
              <div className="font-bold text-blue-400">{ausgewaehlterZwilling.assetId}</div>
            </div>
            <div>
              <span className="text-slate-400">Bezeichnung:</span>
              <div className="font-bold text-slate-100">{ausgewaehlterZwilling.name}</div>
            </div>
            <div>
              <span className="text-slate-400">Maschinentyp:</span>
              <div className="text-purple-300">{ausgewaehlterZwilling.typ}</div>
            </div>
            <div>
              <span className="text-slate-400">Physischer Standort:</span>
              <div className="text-slate-300">{ausgewaehlterZwilling.standort}</div>
            </div>
            <div>
              <span className="text-slate-400">Software &amp; Firmware:</span>
              <div className="text-teal-400">
                {ausgewaehlterZwilling.softwareversion} | {ausgewaehlterZwilling.firmwareversion}
              </div>
            </div>
          </div>
        </div>

        {/* Middle: Live Sensor Feeds */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-3">
          <div className="font-bold text-slate-200 border-b border-slate-800 pb-2 flex items-center justify-between">
            <span>Echtzeit Messwerte</span>
            <span className="text-[10px] text-slate-400 font-mono">Telemetry Sync</span>
          </div>

          <div className="grid grid-cols-2 gap-3 font-mono text-xs">
            <div className="bg-slate-950 p-3 rounded border border-slate-800">
              <div className="flex items-center gap-1.5 text-slate-400 text-[10px] uppercase">
                <Gauge className="w-3.5 h-3.5 text-blue-400" />
                <span>Drehzahl</span>
              </div>
              <div className="text-lg font-bold text-blue-400 mt-1">{speed.toFixed(0)} U/min</div>
            </div>

            <div className="bg-slate-950 p-3 rounded border border-slate-800">
              <div className="flex items-center gap-1.5 text-slate-400 text-[10px] uppercase">
                <Thermometer className="w-3.5 h-3.5 text-amber-400" />
                <span>Temperatur</span>
              </div>
              <div className="text-lg font-bold text-amber-400 mt-1">{temp.toFixed(1)} °C</div>
            </div>

            <div className="bg-slate-950 p-3 rounded border border-slate-800">
              <div className="flex items-center gap-1.5 text-slate-400 text-[10px] uppercase">
                <Activity className="w-3.5 h-3.5 text-purple-400" />
                <span>Vibration</span>
              </div>
              <div className="text-lg font-bold text-purple-300 mt-1">2.10 mm/s</div>
            </div>

            <div className="bg-slate-950 p-3 rounded border border-slate-800">
              <div className="flex items-center gap-1.5 text-slate-400 text-[10px] uppercase">
                <Zap className="w-3.5 h-3.5 text-emerald-400" />
                <span>Auslastung</span>
              </div>
              <div className="text-lg font-bold text-emerald-400 mt-1">88.5 %</div>
            </div>
          </div>
        </div>

        {/* Right: Wartung & Performance */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-3">
          <div className="font-bold text-slate-200 border-b border-slate-800 pb-2">
            Wartungs- &amp; Lebenszyklusdaten
          </div>

          <div className="space-y-2 font-mono text-[11px]">
            <div className="flex justify-between border-b border-slate-800 pb-1">
              <span className="text-slate-400">Betriebsstunden:</span>
              <span className="font-bold text-slate-200">
                {ausgewaehlterZwilling.wartungsdaten.betriebsstunden} Std
              </span>
            </div>
            <div className="flex justify-between border-b border-slate-800 pb-1">
              <span className="text-slate-400">MTBF (Mittl. Ausfallzeit):</span>
              <span className="font-bold text-emerald-400">
                {ausgewaehlterZwilling.wartungsdaten.mtbfStunden} Std
              </span>
            </div>
            <div className="flex justify-between border-b border-slate-800 pb-1">
              <span className="text-slate-400">MTTR (Reparaturdauer):</span>
              <span className="font-bold text-amber-400">
                {ausgewaehlterZwilling.wartungsdaten.mttrMinuten} Min
              </span>
            </div>
            <div className="flex justify-between pt-1">
              <span className="text-slate-400">Nächster Service:</span>
              <span className="font-bold text-blue-400">15.10.2026</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
