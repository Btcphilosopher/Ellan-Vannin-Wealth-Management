/**
 * INDUSTRIAL CORE OS - Cybersecurity & Audit Logging
 * Rollenbasierte Zugriffskontrolle (RBAC), Zertifikatsverwaltung & Unlöschbares Audit-Protokoll.
 */

import React, { useState } from 'react';
import {
  ShieldCheck,
  Lock,
  Key,
  FileText,
  UserCheck,
  Search,
  CheckCircle2,
  XCircle,
  ShieldAlert,
} from 'lucide-react';
import { securityEngine } from '../core/SecurityEngine';
import { BenutzerRolle, AuditLogEintrag } from '../types/industrial';

export const CybersecurityView: React.FC = () => {
  const [auditLogs, setAuditLogs] = useState<AuditLogEintrag[]>(securityEngine.getAuditLogs());
  const [suchBegriff, setSuchBegriff] = useState('');

  const rollenListe: { rolle: BenutzerRolle; beschreibung: string; rechte: string[] }[] = [
    {
      rolle: 'ADMINISTRATOR',
      beschreibung: 'Vollzugriff auf Systemkonfiguration, Sicherheitszertifikate & Benutzerverwaltung',
      rechte: ['ALLE_RECHTE', 'BENUTZER_VERWALTEN', 'ZERTIFIKATE_INSTALLIEREN'],
    },
    {
      rolle: 'ENGINEER',
      beschreibung: 'SPS-Programmierung, Hardwarekonfiguration & Prozessbausteine',
      rechte: ['SPS_EDITIEREN', 'HARDWARE_KONFIGURIEREN', 'FORCE_INTERVENTION'],
    },
    {
      rolle: 'BETRIEBSLEITER',
      beschreibung: 'Anlagenüberwachung, OEE-Analytics & Energieberichte',
      rechte: ['LESEN_PROZESSBILDER', 'EXPORT_ANALYTICS', 'EINSTELLUNG_OEE_ZIELE'],
    },
    {
      rolle: 'INBETRIEBNEHMER',
      beschreibung: 'Achseinrichtung, E/A-Tests & Parameterabgleich vor Ort',
      rechte: ['ACHSEN_JOGGEN', 'E_A_TEST', 'PARAMETRIERUNG'],
    },
    {
      rolle: 'INSTANDHALTER',
      beschreibung: 'Wartung, Alarmquittierung & Diagnosemessungen',
      rechte: ['ALARM_QUITTIEREN', 'DIAGNOSE_LESEN', 'SERVICE_INTERVALLE'],
    },
    {
      rolle: 'BEDIENER',
      beschreibung: 'Schichtbetrieb, Maschinenstart/Stopp & Gutteilquittierung',
      rechte: ['START_STOPP', 'ALARM_QUITTIEREN_LEICHT', 'STUECKZAHL_LESEN'],
    },
    {
      rolle: 'AUDITOR',
      beschreibung: 'Lesezugriff auf unlöschbare Audit-Protokolle & Compliance-Nachweise',
      rechte: ['LESEN_AUDIT_LOGS', 'EXPORT_COMPLIANCE'],
    },
  ];

  const gefilterteAuditLogs = auditLogs.filter(
    (l) =>
      l.benutzer.toLowerCase().includes(suchBegriff.toLowerCase()) ||
      l.aktion.toLowerCase().includes(suchBegriff.toLowerCase()) ||
      l.system.toLowerCase().includes(suchBegriff.toLowerCase())
  );

  return (
    <div className="flex-1 flex flex-col bg-slate-950 text-slate-200 overflow-y-auto p-4 gap-4 text-xs">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-lg flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-blue-400" />
          <div>
            <h2 className="font-bold text-sm text-slate-100">CYBERSECURITY &amp; AUDIT TRAIL (IEC 62443 / NIS-2)</h2>
            <p className="text-[11px] text-slate-400 font-mono">
              Security-by-Design, OT/IT Segmentierung &amp; Unlöschbares Revisions-Protokoll
            </p>
          </div>
        </div>

        <div className="bg-blue-950 text-blue-300 px-2.5 py-1 rounded border border-blue-800 text-[11px] font-mono font-bold">
          OT NETZWERKZONE: SECURE ENCLAVE ACTIVE
        </div>
      </div>

      {/* RBAC Rollen-Matrix */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-3">
        <div className="font-bold text-slate-200 border-b border-slate-800 pb-2">
          Rollenbasierte Zugriffskontrolle (RBAC 7-Rollen-Modell)
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 font-mono">
          {rollenListe.map((r) => (
            <div key={r.rolle} className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
              <div className="font-bold text-blue-400 text-xs flex items-center gap-1.5">
                <UserCheck className="w-3.5 h-3.5 text-blue-400" />
                <span>{r.rolle}</span>
              </div>
              <p className="text-[10px] text-slate-400 font-sans">{r.beschreibung}</p>
              <div className="flex flex-wrap gap-1 pt-1">
                {r.rechte.map((recht) => (
                  <span
                    key={recht}
                    className="bg-slate-900 text-slate-300 px-1.5 py-0.5 rounded text-[9px] border border-slate-700"
                  >
                    {recht}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* UNLÖSCHBARES AUDIT LOG PROTOKOLL (Section 17 Prompt Requirement) */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-emerald-400" />
            <span className="font-bold text-slate-200 text-sm">Unlöschbares Audit Protocol (Revisionssicher)</span>
          </div>

          {/* Search bar */}
          <div className="relative w-64">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-2 text-slate-500" />
            <input
              type="text"
              value={suchBegriff}
              onChange={(e) => setSuchBegriff(e.target.value)}
              placeholder="Audit-Protokoll durchsuchen..."
              className="w-full bg-slate-950 border border-slate-800 rounded pl-8 pr-3 py-1 text-xs text-slate-200 placeholder-slate-600 font-mono"
            />
          </div>
        </div>

        <div className="border border-slate-800 rounded overflow-hidden">
          <table className="w-full text-left border-collapse font-mono text-[11px]">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px]">
              <tr>
                <th className="p-2 border-b border-slate-800">Zeitstempel</th>
                <th className="p-2 border-b border-slate-800">Benutzer (Rolle)</th>
                <th className="p-2 border-b border-slate-800">System / Modul</th>
                <th className="p-2 border-b border-slate-800">Aktion</th>
                <th className="p-2 border-b border-slate-800">Objekt</th>
                <th className="p-2 border-b border-slate-800">Vorher / Nachher</th>
                <th className="p-2 border-b border-slate-800">Ergebnis</th>
                <th className="p-2 border-b border-slate-800">Client IP</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {gefilterteAuditLogs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-800/40">
                  <td className="p-2 text-slate-400">{new Date(log.zeit).toLocaleTimeString()}</td>
                  <td className="p-2">
                    <span className="font-bold text-slate-200">{log.benutzer}</span>
                    <span className="text-[9px] text-blue-400 ml-1">({log.rolle})</span>
                  </td>
                  <td className="p-2 text-purple-300">{log.system}</td>
                  <td className="p-2 text-amber-400 font-semibold">{log.aktion}</td>
                  <td className="p-2 text-slate-300">{log.objekt}</td>
                  <td className="p-2 text-slate-400 text-[10px]">
                    <span className="line-through">{log.vorherigerZustand}</span> &rarr;{' '}
                    <span className="text-emerald-300 font-semibold">{log.neuerZustand}</span>
                  </td>
                  <td className="p-2">
                    <span className="bg-emerald-950 text-emerald-400 px-1.5 py-0.5 rounded text-[10px] border border-emerald-800">
                      {log.ergebnis}
                    </span>
                  </td>
                  <td className="p-2 text-slate-500">{log.ipClient}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
