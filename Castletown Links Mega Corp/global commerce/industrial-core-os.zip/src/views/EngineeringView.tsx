/**
 * INDUSTRIAL CORE OS - Engineering Studio (TIA-Style 3-Spalten Layout)
 * Projektverwaltung, SPS-Programmierung, Hardware-Konfigurator, Variablen-Editor & Compiler/Diagnose
 */

import React, { useState } from 'react';
import {
  FolderTree,
  Cpu,
  Database,
  Code2,
  HardDrive,
  Play,
  CheckCircle2,
  AlertCircle,
  FileCode,
  ToggleLeft,
  ToggleRight,
  Plus,
  Save,
  RotateCcw,
} from 'lucide-react';
import { plcEngine } from '../core/PLCEngine';
import { securityEngine } from '../core/SecurityEngine';
import { SPSProjekt, SPSVariable, Funktionsbaustein } from '../types/industrial';

export const EngineeringView: React.FC = () => {
  const [projekt, setProjekt] = useState<SPSProjekt>(plcEngine.getProjekt());
  const [aktiverTab, setAktiverTab] = useState<'PROGRAMM' | 'HARDWARE' | 'VARIABLEN'>('PROGRAMM');
  const [ausgewaehlterBausteinId, setAusgewaehlterBausteinId] = useState<string>('OB1');
  const [compilerLogs, setCompilerLogs] = useState<string[]>([
    '[COMPILER] TIA Core Compiler v2.4.0 initialisiert.',
    '[INFO] CPU 1518-4 PN/DP Zielarchitektur geladen.',
    '[INFO] Baustein Main_Cyclic_OB1 erfolgreich verifiziert (0 Fehler, 0 Warnungen).',
  ]);
  const [isCompiling, setIsCompiling] = useState(false);

  // Variable Wert ändern
  const handleVariableWertAendern = (adresse: string, neuerWert: string) => {
    let parseVal: boolean | number | string = neuerWert;
    if (neuerWert === 'true') parseVal = true;
    if (neuerWert === 'false') parseVal = false;
    if (!isNaN(Number(neuerWert))) parseVal = Number(neuerWert);

    plcEngine.setVariableWert(adresse, parseVal);
    setProjekt({ ...plcEngine.getProjekt() });
  };

  const handleToggleForce = (adresse: string) => {
    plcEngine.toggleForceVariable(adresse);
    setProjekt({ ...plcEngine.getProjekt() });
  };

  const handleKompilieren = () => {
    setIsCompiling(true);
    setCompilerLogs((prev) => [...prev, `[BUILD ${new Date().toLocaleTimeString()}] Kompilierung gestartet...`]);

    setTimeout(() => {
      setCompilerLogs((prev) => [
        ...prev,
        '[PARSER] Überprüfe Bausteinhierarchie OB1 -> FB10 -> DB1...',
        '[TYPECHECK] Variablenadressierung E0.0 - E0.3 und A0.0 - A0.3 validiert.',
        '[OPTIMIZER] S-Kurven Motion-Logik optimiert.',
        '[SUCCESS] Kompilierung erfolgreich! Code-Größe: 42.8 KB (3.2% Speicher genutzt).',
      ]);
      setIsCompiling(false);
      securityEngine.registriereAuditEintrag(
        'ENGINEERING',
        'PROJEKT_KOMPILIERT',
        projekt.projektId,
        '-',
        'V2.4.0-BINARY',
        'ERFOLG'
      );
    }, 1200);
  };

  const aktuellerBaustein = projekt.bausteine.find((b) => b.id === ausgewaehlterBausteinId) || projekt.bausteine[0];

  return (
    <div className="flex-1 flex flex-col bg-slate-950 text-slate-200 overflow-hidden text-xs">
      {/* Studio Toolleiste */}
      <div className="bg-slate-900 border-b border-slate-800 px-4 py-2 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <span className="font-bold text-sm tracking-wide text-slate-100 flex items-center gap-2">
            <Cpu className="w-4 h-4 text-blue-400" />
            ENGINEERING STUDIO
          </span>
          <span className="bg-slate-800 px-2 py-0.5 rounded text-[11px] font-mono border border-slate-700 text-slate-300">
            {projekt.name} ({projekt.controllerTyp})
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleKompilieren}
            disabled={isCompiling}
            className="bg-blue-600 hover:bg-blue-500 disabled:bg-slate-800 text-white font-semibold px-3 py-1.5 rounded flex items-center gap-1.5 transition"
          >
            {isCompiling ? (
              <RotateCcw className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <CheckCircle2 className="w-3.5 h-3.5" />
            )}
            <span>{isCompiling ? 'Kompiliere...' : 'Kompilieren & Validieren'}</span>
          </button>
          <button
            onClick={() => {
              securityEngine.registriereAuditEintrag(
                'ENGINEERING',
                'PROJEKT_GESPEICHERT',
                projekt.projektId,
                '-',
                'OK',
                'ERFOLG'
              );
            }}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded border border-slate-700 flex items-center gap-1.5 transition"
          >
            <Save className="w-3.5 h-3.5 text-emerald-400" />
            <span>Projekt Speichern</span>
          </button>
        </div>
      </div>

      {/* 3-Spalten Hauptbereich (Section 6 Prompt Layout) */}
      <div className="flex-1 grid grid-cols-12 overflow-hidden divide-x divide-slate-800">
        
        {/* SPALTE 1: PROJEKT-BAUM & NAVIGATION (3/12) */}
        <div className="col-span-3 bg-slate-900/60 p-3 flex flex-col gap-3 overflow-y-auto">
          <div className="font-bold text-[11px] text-slate-400 uppercase tracking-wider flex items-center gap-1.5 border-b border-slate-800 pb-2">
            <FolderTree className="w-3.5 h-3.5 text-blue-400" />
            PROJEKT-HIERARCHIE
          </div>

          <div className="space-y-1 font-mono text-[11px]">
            <div className="font-semibold text-slate-200 flex items-center gap-1.5 p-1 bg-slate-800/80 rounded border border-slate-700">
              <Cpu className="w-3.5 h-3.5 text-emerald-400" />
              <span>{projekt.controllerTyp}</span>
            </div>

            <div className="pl-3 space-y-1 border-l border-slate-800 ml-2 mt-1">
              <div className="text-slate-400 font-semibold py-1">SPS-Programmbausteine</div>
              {projekt.bausteine.map((b) => (
                <button
                  key={b.id}
                  onClick={() => {
                    setAusgewaehlterBausteinId(b.id);
                    setAktiverTab('PROGRAMM');
                  }}
                  className={`w-full text-left px-2 py-1 rounded flex items-center gap-2 transition ${
                    ausgewaehlterBausteinId === b.id && aktiverTab === 'PROGRAMM'
                      ? 'bg-blue-600/30 text-blue-300 font-bold border border-blue-500/40'
                      : 'hover:bg-slate-800 text-slate-300'
                  }`}
                >
                  <FileCode className="w-3 h-3 text-amber-400" />
                  <span>{b.name}</span>
                  <span className="ml-auto text-[9px] bg-slate-800 px-1 rounded text-slate-400">
                    {b.typ}
                  </span>
                </button>
              ))}

              <div
                onClick={() => setAktiverTab('HARDWARE')}
                className={`cursor-pointer px-2 py-1 rounded flex items-center gap-2 transition ${
                  aktiverTab === 'HARDWARE'
                    ? 'bg-blue-600/30 text-blue-300 font-bold border border-blue-500/40'
                    : 'hover:bg-slate-800 text-slate-300'
                }`}
              >
                <HardDrive className="w-3 h-3 text-purple-400" />
                <span>Hardware-Konfiguration</span>
              </div>

              <div
                onClick={() => setAktiverTab('VARIABLEN')}
                className={`cursor-pointer px-2 py-1 rounded flex items-center gap-2 transition ${
                  aktiverTab === 'VARIABLEN'
                    ? 'bg-blue-600/30 text-blue-300 font-bold border border-blue-500/40'
                    : 'hover:bg-slate-800 text-slate-300'
                }`}
              >
                <Database className="w-3 h-3 text-teal-400" />
                <span>Variablen-Tabelle (E/A/M/DB)</span>
              </div>
            </div>
          </div>
        </div>

        {/* SPALTE 2: ENGINEERING ARBEITSBEREICH / CODE / HW / TAGS (6/12) */}
        <div className="col-span-6 bg-slate-950 p-4 flex flex-col gap-3 overflow-y-auto">
          {/* Main Tab Navigation */}
          <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
            <button
              onClick={() => setAktiverTab('PROGRAMM')}
              className={`px-3 py-1.5 rounded font-semibold text-xs flex items-center gap-1.5 transition ${
                aktiverTab === 'PROGRAMM'
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              <Code2 className="w-3.5 h-3.5" />
              SPS-Programm ({aktuellerBaustein.name})
            </button>
            <button
              onClick={() => setAktiverTab('HARDWARE')}
              className={`px-3 py-1.5 rounded font-semibold text-xs flex items-center gap-1.5 transition ${
                aktiverTab === 'HARDWARE'
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              <HardDrive className="w-3.5 h-3.5" />
              Hardware
            </button>
            <button
              onClick={() => setAktiverTab('VARIABLEN')}
              className={`px-3 py-1.5 rounded font-semibold text-xs flex items-center gap-1.5 transition ${
                aktiverTab === 'VARIABLEN'
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              <Database className="w-3.5 h-3.5" />
              Variablen
            </button>
          </div>

          {/* TAB 1: SPS-PROGRAMM & LADDER / ST NETZWERKE */}
          {aktiverTab === 'PROGRAMM' && (
            <div className="space-y-4">
              <div className="bg-slate-900 p-3 rounded border border-slate-800">
                <div className="font-bold text-slate-200 mb-1">{aktuellerBaustein.name} ({aktuellerBaustein.typ})</div>
                <div className="text-slate-400 text-[11px]">{aktuellerBaustein.beschreibung}</div>
              </div>

              {aktuellerBaustein.netzwerke.map((net) => (
                <div key={net.id} className="bg-slate-900 border border-slate-800 rounded p-3 font-mono text-xs space-y-2">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-1.5 font-sans">
                    <span className="font-bold text-blue-400">{net.titel}</span>
                    <span className="bg-slate-800 text-slate-300 px-1.5 py-0.5 rounded text-[10px]">
                      Typ: {net.logikTyp}
                    </span>
                  </div>

                  {net.logikTyp === 'KOP' ? (
                    <div className="bg-slate-950 p-3 rounded border border-slate-800/80 text-emerald-400 space-y-2">
                      <div className="text-slate-500 text-[10px]">// Kontaktplan-Logik (KOP) - Echtzeit-Abtastung</div>
                      <div className="flex items-center gap-3">
                        <span className="px-2 py-1 bg-slate-800 text-slate-200 rounded border border-slate-700">|--[ ]-- E0.0</span>
                        <span className="text-slate-500">&amp;&amp;</span>
                        <span className="px-2 py-1 bg-slate-800 text-slate-200 rounded border border-slate-700">|--[/]-- E0.2</span>
                        <span className="text-slate-500">==&gt;</span>
                        <span className="px-2 py-1 bg-emerald-950 text-emerald-300 rounded border border-emerald-700">( ) M0.0</span>
                      </div>
                    </div>
                  ) : (
                    <pre className="bg-slate-950 p-3 rounded border border-slate-800/80 text-slate-300 leading-relaxed font-mono whitespace-pre-wrap">
                      {net.code}
                    </pre>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* TAB 2: HARDWARE-KONFIGURATOR */}
          {aktiverTab === 'HARDWARE' && (
            <div className="space-y-3">
              <div className="font-bold text-slate-300 border-b border-slate-800 pb-2">
                PROFINET Baugruppenträger (Rack 0)
              </div>
              <div className="border border-slate-800 rounded overflow-hidden">
                <table className="w-full text-left border-collapse">
                  <thead className="bg-slate-900 text-slate-400 uppercase text-[10px] font-mono">
                    <tr>
                      <th className="p-2 border-b border-slate-800">Steckplatz</th>
                      <th className="p-2 border-b border-slate-800">Modul-Typ</th>
                      <th className="p-2 border-b border-slate-800">Bezeichnung</th>
                      <th className="p-2 border-b border-slate-800">IP / Adressbereich</th>
                      <th className="p-2 border-b border-slate-800">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
                    {projekt.hardwareModule.map((hw) => (
                      <tr key={hw.steckplatz} className="hover:bg-slate-900/50">
                        <td className="p-2 font-bold text-blue-400">Slot {hw.steckplatz}</td>
                        <td className="p-2 text-slate-200">{hw.modulTyp}</td>
                        <td className="p-2 text-slate-400">{hw.bezeichnung}</td>
                        <td className="p-2 text-slate-300">{hw.ipAdresse || 'E0.0 - A3.7'}</td>
                        <td className="p-2">
                          <span className="bg-emerald-950 text-emerald-400 px-1.5 py-0.5 rounded text-[10px] border border-emerald-800">
                            {hw.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 3: VARIABLEN-TABELLE */}
          {aktiverTab === 'VARIABLEN' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="font-bold text-slate-300">Symbolische Variablen-Tabelle</span>
                <span className="text-[10px] text-slate-500 font-mono">Eingänge / Ausgänge / Merker / DB</span>
              </div>
              <div className="border border-slate-800 rounded overflow-hidden">
                <table className="w-full text-left border-collapse">
                  <thead className="bg-slate-900 text-slate-400 uppercase text-[10px] font-mono">
                    <tr>
                      <th className="p-2 border-b border-slate-800">Adresse</th>
                      <th className="p-2 border-b border-slate-800">Symbol-Name</th>
                      <th className="p-2 border-b border-slate-800">Typ</th>
                      <th className="p-2 border-b border-slate-800">Wert</th>
                      <th className="p-2 border-b border-slate-800">Forciert</th>
                      <th className="p-2 border-b border-slate-800">Aktion</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
                    {projekt.variablen.map((v) => (
                      <tr key={v.adresse} className="hover:bg-slate-900/50">
                        <td className="p-2 font-bold text-amber-400">{v.adresse}</td>
                        <td className="p-2 text-slate-200">{v.symbolName}</td>
                        <td className="p-2 text-purple-400">{v.datentyp}</td>
                        <td className="p-2 font-bold text-slate-100">
                          {String(v.forciert ? v.forciertWert : v.wert)}
                        </td>
                        <td className="p-2">
                          {v.forciert ? (
                            <span className="bg-rose-950 text-rose-300 px-1.5 py-0.5 rounded text-[10px] border border-rose-800">
                              FORCIERT
                            </span>
                          ) : (
                            <span className="text-slate-600">NEIN</span>
                          )}
                        </td>
                        <td className="p-2">
                          <button
                            onClick={() => handleToggleForce(v.adresse)}
                            className="text-[10px] bg-slate-800 hover:bg-slate-700 text-slate-300 px-2 py-0.5 rounded border border-slate-700"
                          >
                            Force Toggle
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>

        {/* SPALTE 3: COMPILER & DIAGNOSE MONITOR (3/12) */}
        <div className="col-span-3 bg-slate-900/60 p-3 flex flex-col gap-3 overflow-hidden">
          <div className="font-bold text-[11px] text-slate-400 uppercase tracking-wider flex items-center gap-1.5 border-b border-slate-800 pb-2">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            DIAGNOSE & COMPILER-OUT
          </div>

          <div className="flex-1 bg-slate-950 p-2.5 rounded border border-slate-800 font-mono text-[10px] text-slate-300 overflow-y-auto space-y-1">
            {compilerLogs.map((log, idx) => (
              <div key={idx} className={log.includes('SUCCESS') ? 'text-emerald-400 font-bold' : log.includes('BUILD') ? 'text-blue-400' : ''}>
                {log}
              </div>
            ))}
          </div>

          {/* Quick Hardware Status Cards */}
          <div className="bg-slate-950 p-2.5 rounded border border-slate-800 space-y-2 text-[11px]">
            <div className="font-semibold text-slate-300">CPU-Speicherauslastung</div>
            <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
              <div className="bg-blue-500 h-full w-[18%]" />
            </div>
            <div className="flex justify-between text-[10px] text-slate-400 font-mono">
              <span>Arbeitsspeicher: 18.4 MB / 1024 MB</span>
              <span>1.8%</span>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
