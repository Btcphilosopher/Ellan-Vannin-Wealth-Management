/**
 * INDUSTRIAL CORE OS - Analytics & Julia Optimization Engine
 * OEE Kennzahlen, Statistische Anomaly-Detection & Julia Mathematische Optimierungsvorschläge.
 */

import React, { useState, useEffect } from 'react';
import {
  BarChart3,
  TrendingUp,
  Cpu,
  CheckCircle2,
  XCircle,
  Clock,
  Sparkles,
  Zap,
  Activity,
  FileText,
} from 'lucide-react';
import { analyticsEngine } from '../core/AnalyticsEngine';
import { OEEMetriken, OptimizationVorschlag } from '../types/industrial';

export const AnalyticsView: React.FC = () => {
  const [oee, setOee] = useState<OEEMetriken>(analyticsEngine.getOEEMetriken());
  const [vorschlaege, setVorschlaege] = useState<OptimizationVorschlag[]>(
    analyticsEngine.getJuliaVorschlaege()
  );

  useEffect(() => {
    const interval = setInterval(() => {
      setOee(analyticsEngine.getOEEMetriken());
      setVorschlaege([...analyticsEngine.getJuliaVorschlaege()]);
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const handleStatusAendern = (id: string, neuerStatus: OptimizationVorschlag['status']) => {
    analyticsEngine.aendereVorschlagStatus(id, neuerStatus);
    setVorschlaege([...analyticsEngine.getJuliaVorschlaege()]);
  };

  return (
    <div className="flex-1 flex flex-col bg-slate-950 text-slate-200 overflow-y-auto p-4 gap-4 text-xs">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-lg flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <BarChart3 className="w-5 h-5 text-purple-400" />
          <div>
            <h2 className="font-bold text-sm text-slate-100">OEE ANALYTICS &amp; JULIA MATH OPTIMIZER</h2>
            <p className="text-[11px] text-slate-400 font-mono">
              Overall Equipment Effectiveness (OEE) &amp; Statistische Optimierungsmodelle
            </p>
          </div>
        </div>

        <div className="bg-purple-950 text-purple-300 px-2.5 py-1 rounded border border-purple-800 text-[11px] font-mono font-bold">
          JULIA RUNTIME v1.10.2 ONLINE
        </div>
      </div>

      {/* OEE GAUGES & METRICS */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
        {/* Overall OEE */}
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg text-center space-y-1">
          <div className="text-[10px] text-slate-400 uppercase font-mono">Gesamtanlageneffektivität (OEE)</div>
          <div className="text-3xl font-bold text-purple-400 font-mono">{oee.oeeProzent}%</div>
          <div className="text-[10px] text-emerald-400 font-mono font-semibold">+2.4% über Zielvorgabe</div>
        </div>

        {/* Verfügbarkeit */}
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg text-center space-y-1">
          <div className="text-[10px] text-slate-400 uppercase font-mono">Verfügbarkeitsfaktor</div>
          <div className="text-2xl font-bold text-blue-400 font-mono">{oee.verfuegbarkeitProzent}%</div>
          <div className="text-[10px] text-slate-500 font-mono">Geplante Laufzeit: 99.2%</div>
        </div>

        {/* Leistung */}
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg text-center space-y-1">
          <div className="text-[10px] text-slate-400 uppercase font-mono">Leistungsfaktor</div>
          <div className="text-2xl font-bold text-emerald-400 font-mono">{oee.leistungProzent}%</div>
          <div className="text-[10px] text-slate-500 font-mono">Soll-Geschwindigkeit 1450 U/min</div>
        </div>

        {/* Qualität */}
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg text-center space-y-1">
          <div className="text-[10px] text-slate-400 uppercase font-mono">Qualitätsfaktor</div>
          <div className="text-2xl font-bold text-amber-400 font-mono">{oee.qualitaetProzent}%</div>
          <div className="text-[10px] text-slate-500 font-mono">Ausschussquote: {oee.ausschussQuoteProzent}%</div>
        </div>
      </div>

      {/* JULIA OPTIMIZATION PROPOSALS (Section 22 Prompt Requirement) */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-3">
        <div className="font-bold text-slate-200 border-b border-slate-800 pb-2 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-purple-400" />
            <span>Julia Mathematische Optimierungsvorschläge (Nicht-Invasive Empfehlungen)</span>
          </div>
          <span className="text-[10px] font-mono text-slate-400">
            Sicherheit: Keine direkte Aktorik-Ansteuerung (Geprüfte Vorschläge)
          </span>
        </div>

        <div className="space-y-3">
          {vorschlaege.map((v) => (
            <div
              key={v.id}
              className="bg-slate-950 p-4 rounded border border-slate-800 space-y-2 font-mono"
            >
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
                <div className="flex items-center gap-2 font-bold text-slate-200">
                  <span className="bg-purple-950 text-purple-300 px-2 py-0.5 rounded text-[10px] border border-purple-800">
                    Ziel: {v.ziel}
                  </span>
                  <span>{v.id}</span>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-[10px] text-slate-400">Konfidenz:</span>
                  <span className="font-bold text-emerald-400">{v.konfidenzProzent}%</span>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      v.status === 'UMGESETZT'
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                        : v.status === 'GEPRUEFT'
                        ? 'bg-blue-950 text-blue-300 border border-blue-800'
                        : 'bg-amber-950 text-amber-300 border border-amber-800'
                    }`}
                  >
                    {v.status}
                  </span>
                </div>
              </div>

              <p className="text-slate-300 font-sans text-xs">{v.empfehlungText}</p>

              <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-800/60 text-[11px]">
                <div>
                  <span className="text-slate-500">Ist-Wert:</span>{' '}
                  <span className="text-slate-300 line-through mr-3">{v.aktuellerWert}</span>
                  <span className="text-slate-500">Optimum:</span>{' '}
                  <span className="text-emerald-400 font-bold">{v.optimierterWert}</span>
                  <span className="text-amber-400 font-bold ml-3">({v.einsparungPotenzial})</span>
                </div>

                <div className="flex items-center gap-2">
                  {v.status === 'VORGESCHLAGEN' && (
                    <button
                      onClick={() => handleStatusAendern(v.id, 'GEPRUEFT')}
                      className="bg-blue-600 hover:bg-blue-500 text-white px-2.5 py-1 rounded text-[10px] font-bold shadow"
                    >
                      Als Geprüft markieren
                    </button>
                  )}
                  {v.status === 'GEPRUEFT' && (
                    <button
                      onClick={() => handleStatusAendern(v.id, 'UMGESETZT')}
                      className="bg-emerald-600 hover:bg-emerald-500 text-white px-2.5 py-1 rounded text-[10px] font-bold shadow"
                    >
                      Umsetzung bestätigen
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
