/**
 * INDUSTRIAL CORE OS - SCADA & Anlagenübersicht
 * Interaktive Prozessbilder, P&ID Diagramme und hierarchisches Anlagenmodell.
 */

import React, { useState, useEffect } from 'react';
import {
  Layers,
  ChevronRight,
  ChevronDown,
  Activity,
  Gauge,
  Thermometer,
  Zap,
  Box,
  AlertTriangle,
  RotateCw,
  CheckCircle2,
} from 'lucide-react';
import { assetEngine } from '../core/AssetEngine';
import { plcEngine } from '../core/PLCEngine';
import { AssetKnoten, DigitalerZwilling } from '../types/industrial';

export const ScadaView: React.FC = () => {
  const [hierarchie, setHierarchie] = useState<AssetKnoten>(assetEngine.getAnlagenHierarchie());
  const [ausgewaehltesAssetId, setAusgewaehltesAssetId] = useState<string>('AST-MAS-501');
  const [speed, setSpeed] = useState<number>(1448);
  const [temp, setTemp] = useState<number>(52.4);
  const [gutteile, setGutteile] = useState<number>(12450);

  useEffect(() => {
    const interval = setInterval(() => {
      const s = plcEngine.getVariableWert('DB1.DBD4') as number;
      const t = plcEngine.getVariableWert('DB1.DBD8') as number;
      const g = plcEngine.getVariableWert('DB1.DBD12') as number;
      setSpeed(s || 0);
      setTemp(t || 0);
      setGutteile(g || 0);
    }, 500);

    return () => clearInterval(interval);
  }, []);

  const renderAssetKnoten = (knoten: AssetKnoten) => {
    const isAusgewaehlt = knoten.id === ausgewaehltesAssetId;

    return (
      <div key={knoten.id} className="ml-2 font-mono text-xs">
        <div
          onClick={() => setAusgewaehltesAssetId(knoten.id)}
          className={`cursor-pointer px-2 py-1 rounded flex items-center justify-between transition my-0.5 ${
            isAusgewaehlt
              ? 'bg-blue-600/30 text-blue-300 font-bold border border-blue-500/40'
              : 'hover:bg-slate-800 text-slate-300'
          }`}
        >
          <div className="flex items-center gap-1.5 truncate">
            <span className="text-slate-500 text-[10px]">[{knoten.typ}]</span>
            <span className="truncate">{knoten.name}</span>
          </div>

          <span
            className={`w-2 h-2 rounded-full ${
              knoten.status === 'NORMAL'
                ? 'bg-emerald-500'
                : knoten.status === 'WARNUNG'
                ? 'bg-amber-500'
                : 'bg-rose-500'
            }`}
          />
        </div>

        {knoten.unterKnoten && knoten.unterKnoten.length > 0 && (
          <div className="pl-2 border-l border-slate-800 ml-1">
            {knoten.unterKnoten.map((child) => renderAssetKnoten(child))}
          </div>
        )}
      </div>
    );
  };

  const aktuellerZwilling = assetEngine.getDigitalenZwilling(ausgewaehltesAssetId);

  return (
    <div className="flex-1 flex flex-col bg-slate-950 text-slate-200 overflow-hidden text-xs">
      {/* Header */}
      <div className="bg-slate-900 border-b border-slate-800 px-4 py-2.5 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-blue-400" />
          <span className="font-bold text-sm tracking-wide text-slate-100">
            SCADA PROZESSBILDER & ANLAGEN-HIERARCHIE
          </span>
        </div>
        <div className="flex items-center gap-4 text-slate-400 font-mono text-[11px]">
          <span>HIERARCHIE-TIEFE: UNTERNEHMEN BIS KOMPONENTE</span>
          <span className="text-emerald-400 font-bold">ECHTZEIT-SYNCHRON</span>
        </div>
      </div>

      <div className="flex-1 grid grid-cols-12 divide-x divide-slate-800 overflow-hidden">
        
        {/* SPALTE 1: HIERARCHISCHES ANLAGENMODELL (4/12) */}
        <div className="col-span-4 bg-slate-900/60 p-3 overflow-y-auto flex flex-col gap-3">
          <div className="font-bold text-[11px] text-slate-400 uppercase tracking-wider border-b border-slate-800 pb-2">
            Anlagenstruktur Explorer
          </div>
          <div>{renderAssetKnoten(hierarchie)}</div>
        </div>

        {/* SPALTE 2: P&ID SCHALTPLAN & VISUALISIERUNG (8/12) */}
        <div className="col-span-8 bg-slate-950 p-4 flex flex-col gap-4 overflow-y-auto">
          {/* P&ID Diagramm Karte */}
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 relative overflow-hidden">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-4">
              <span className="font-bold text-slate-200 text-sm">
                P&amp;ID Prozessansicht: CNC 5-Achs Spindelfräszelle (M501)
              </span>
              <span className="bg-emerald-950 text-emerald-400 px-2 py-0.5 rounded text-[10px] font-mono border border-emerald-800 flex items-center gap-1">
                <RotateCw className="w-3 h-3 animate-spin text-emerald-400" />
                AUTOMATIK-TAKTLINIE
              </span>
            </div>

            {/* P&ID Vektor-Schema */}
            <div className="bg-slate-950 border border-slate-800/80 rounded-lg p-6 relative flex flex-col items-center justify-center min-h-[220px]">
              
              {/* Förderband Visualisierung */}
              <div className="w-full max-w-xl bg-slate-900 border-2 border-slate-700 h-14 rounded flex items-center justify-between px-4 relative overflow-hidden shadow-inner">
                {/* Rollen */}
                <div className="w-8 h-8 rounded-full border-2 border-slate-500 bg-slate-800 flex items-center justify-center animate-spin">
                  <div className="w-1 h-6 bg-slate-400" />
                </div>

                {/* Bauteile auf dem Band */}
                <div className="flex items-center gap-8 font-mono text-[10px]">
                  <div className="bg-blue-600 text-white px-2 py-1 rounded shadow animate-pulse">
                    Werkstück #12451
                  </div>
                  <div className="bg-slate-700 text-slate-300 px-2 py-1 rounded">
                    Werkstück #12450
                  </div>
                  <div className="bg-slate-700 text-slate-300 px-2 py-1 rounded">
                    Werkstück #12449
                  </div>
                </div>

                <div className="w-8 h-8 rounded-full border-2 border-slate-500 bg-slate-800 flex items-center justify-center animate-spin">
                  <div className="w-1 h-6 bg-slate-400" />
                </div>
              </div>

              {/* Spindel & Sensoren Indikatoren */}
              <div className="grid grid-cols-3 gap-4 w-full max-w-xl mt-6">
                <div className="bg-slate-900 border border-slate-800 p-3 rounded text-center">
                  <div className="text-[10px] text-slate-400 uppercase font-mono">Spindel Drehzahl</div>
                  <div className="text-base font-bold text-blue-400 font-mono mt-0.5">
                    {speed.toFixed(0)} U/min
                  </div>
                </div>

                <div className="bg-slate-900 border border-slate-800 p-3 rounded text-center">
                  <div className="text-[10px] text-slate-400 uppercase font-mono">Lagertemperatur</div>
                  <div className={`text-base font-bold font-mono mt-0.5 ${temp > 55 ? 'text-amber-400' : 'text-emerald-400'}`}>
                    {temp.toFixed(1)} °C
                  </div>
                </div>

                <div className="bg-slate-900 border border-slate-800 p-3 rounded text-center">
                  <div className="text-[10px] text-slate-400 uppercase font-mono">Gutteile Zähler</div>
                  <div className="text-base font-bold text-teal-400 font-mono mt-0.5">
                    {gutteile} Stk
                  </div>
                </div>
              </div>

            </div>
          </div>

          {/* Digital Twin Parameter Details Card */}
          {aktuellerZwilling && (
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-3">
              <div className="font-bold text-slate-200 border-b border-slate-800 pb-2 flex items-center justify-between">
                <span>Digitaler Zwilling: {aktuellerZwilling.name}</span>
                <span className="text-[11px] text-slate-400 font-mono">{aktuellerZwilling.assetId}</span>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                  <div className="text-slate-400 text-[10px] uppercase font-mono">Standort</div>
                  <div className="font-semibold text-slate-200 mt-0.5">{aktuellerZwilling.standort}</div>
                </div>
                <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                  <div className="text-slate-400 text-[10px] uppercase font-mono">Elektr. Leistung</div>
                  <div className="font-semibold text-amber-400 mt-0.5">
                    {aktuellerZwilling.energieverbrauch.leistungKW} kW
                  </div>
                </div>
                <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                  <div className="text-slate-400 text-[10px] uppercase font-mono">Firmware Version</div>
                  <div className="font-semibold text-purple-400 mt-0.5 font-mono">
                    {aktuellerZwilling.firmwareversion}
                  </div>
                </div>
                <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                  <div className="text-slate-400 text-[10px] uppercase font-mono">Betriebsstunden</div>
                  <div className="font-semibold text-emerald-400 mt-0.5 font-mono">
                    {aktuellerZwilling.wartungsdaten.betriebsstunden} Std
                  </div>
                </div>
              </div>
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
