/**
 * INDUSTRIAL CORE OS - Plugin System & System-Diagnose
 * Verwaltet modulare Plugins und strukturierte Industrie-Fehlermeldungen.
 */

import React, { useState } from 'react';
import {
  Plug,
  CheckCircle2,
  AlertTriangle,
  Info,
  Bug,
  ShieldAlert,
  Layers,
  Activity,
  ToggleLeft,
  ToggleRight,
} from 'lucide-react';
import { pluginEngine } from '../core/PluginEngine';
import { plcEngine } from '../core/PLCEngine';
import { PluginManifest, CoreSystemFehler } from '../types/industrial';

export const PluginsView: React.FC = () => {
  const [plugins, setPlugins] = useState<PluginManifest[]>(pluginEngine.getPlugins());
  const [systemFehler, setSystemFehler] = useState<CoreSystemFehler[]>(
    plcEngine.getFehlerHistorie()
  );

  const handleTogglePlugin = (pluginId: string) => {
    pluginEngine.togglePluginStatus(pluginId);
    setPlugins([...pluginEngine.getPlugins()]);
  };

  return (
    <div className="flex-1 flex flex-col bg-slate-950 text-slate-200 overflow-y-auto p-4 gap-4 text-xs">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-lg flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Plug className="w-5 h-5 text-teal-400" />
          <div>
            <h2 className="font-bold text-sm text-slate-100">PLUGIN SYSTEM &amp; SYSTEMDIAGNOSE</h2>
            <p className="text-[11px] text-slate-400 font-mono">
              Isolierte Erweiterungsschnittstellen &amp; Strukturierte Fehlerdiagnose (Keine stillen Fehler)
            </p>
          </div>
        </div>

        <div className="bg-teal-950 text-teal-300 px-2.5 py-1 rounded border border-teal-800 text-[11px] font-mono font-bold">
          PLUGIN ENGINE READY (v2.0 SDK)
        </div>
      </div>

      {/* PLUGINS MATRIX (Section 24 Prompt Requirement) */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-3">
        <div className="font-bold text-slate-200 border-b border-slate-800 pb-2">
          Registrierte Industrie-Plugins (Kern-Isolation Aktiv)
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 font-mono">
          {plugins.map((p) => (
            <div
              key={p.pluginId}
              className="bg-slate-950 p-3.5 rounded border border-slate-800 flex flex-col justify-between space-y-2"
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className="font-bold text-teal-300 text-xs">{p.name}</span>
                  <span
                    className={`px-2 py-0.5 rounded text-[9px] font-bold ${
                      p.status === 'AKTIV'
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {p.status}
                  </span>
                </div>

                <div className="text-[10px] text-slate-500 mt-0.5">
                  ID: {p.pluginId} | Ver: {p.version} | API: {p.apiVersion} | Typ: {p.typ}
                </div>

                <p className="text-slate-300 font-sans text-xs mt-2">{p.beschreibung}</p>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-[10px]">
                <div className="flex gap-1">
                  {p.berechtigungen.map((b) => (
                    <span
                      key={b}
                      className="bg-slate-900 text-slate-400 px-1.5 py-0.5 rounded border border-slate-800"
                    >
                      {b}
                    </span>
                  ))}
                </div>

                <button
                  onClick={() => handleTogglePlugin(p.pluginId)}
                  className="bg-slate-800 hover:bg-slate-700 text-slate-200 px-2 py-1 rounded border border-slate-700 text-[10px]"
                >
                  {p.status === 'AKTIV' ? 'Deaktivieren' : 'Aktivieren'}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* FEHLERDIAGNOSE MODEL (Section 25 Prompt Requirement) */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-3">
        <div className="font-bold text-slate-200 border-b border-slate-800 pb-2 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-400" />
            <span>Strukturierte Systemdiagnose (Fehlercodes &amp; Ursachenanalyse)</span>
          </div>
          <span className="text-[10px] font-mono text-slate-400">Keine stillen Fehler</span>
        </div>

        {systemFehler.length === 0 ? (
          <div className="bg-slate-950 p-6 rounded border border-slate-800 text-center font-mono text-slate-500">
            [OK] Keine aktiven System- oder Laufzeitfehler diagnostiziert.
          </div>
        ) : (
          <div className="space-y-3 font-mono">
            {systemFehler.map((f) => (
              <div
                key={f.diagnoseId}
                className="bg-slate-950 p-4 rounded border border-amber-800/60 space-y-2 text-xs"
              >
                <div className="flex items-center justify-between border-b border-slate-800 pb-1.5">
                  <div className="flex items-center gap-2 font-bold text-amber-400">
                    <span className="bg-amber-950 px-2 py-0.5 rounded border border-amber-800">
                      {f.fehlerCode}
                    </span>
                    <span>{f.komponente}</span>
                  </div>
                  <span className="text-slate-500 text-[10px]">
                    {new Date(f.zeitstempel).toLocaleTimeString()} | ID: {f.diagnoseId}
                  </span>
                </div>

                <div className="text-slate-200 font-semibold">{f.meldung}</div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 pt-2 border-t border-slate-800/80 text-[11px]">
                  <div>
                    <span className="text-slate-500">Technische Ursache:</span>
                    <div className="text-slate-400 font-mono mt-0.5">{f.technischeUrsache}</div>
                  </div>
                  <div>
                    <span className="text-slate-500">Handlungsempfehlung für Bediener:</span>
                    <div className="text-emerald-400 font-mono mt-0.5">{f.benutzerHinweis}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
