/**
 * INDUSTRIAL CORE OS - SPS Produktion & Echtzeit-Laufzeit Monitor
 * Visualisiert OB1 Ablauf, Taskklassen, Zykluszeiten, Jitter und Forciereingriffe.
 */

import React, { useState, useEffect } from 'react';
import {
  PlaySquare,
  Activity,
  Cpu,
  Clock,
  ToggleLeft,
  ToggleRight,
  AlertTriangle,
  CheckCircle2,
  ListOrdered,
  Gauge,
} from 'lucide-react';
import { plcEngine } from '../core/PLCEngine';
import { TaskMetrik, SPSVariable } from '../types/industrial';

export const ProductionView: React.FC = () => {
  const [taskMetriken, setTaskMetriken] = useState<TaskMetrik[]>(plcEngine.getTaskMetriken());
  const [variablen, setVariablen] = useState<SPSVariable[]>(plcEngine.getProjekt().variablen);

  useEffect(() => {
    const interval = setInterval(() => {
      setTaskMetriken([...plcEngine.getTaskMetriken()]);
      setVariablen([...plcEngine.getProjekt().variablen]);
    }, 400);

    return () => clearInterval(interval);
  }, []);

  const handleToggleForce = (adresse: string) => {
    plcEngine.toggleForceVariable(adresse);
    setVariablen([...plcEngine.getProjekt().variablen]);
  };

  return (
    <div className="flex-1 flex flex-col bg-slate-950 text-slate-200 overflow-y-auto p-4 gap-4 text-xs">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-lg flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <PlaySquare className="w-5 h-5 text-emerald-400" />
          <div>
            <h2 className="font-bold text-sm text-slate-100">SPS-LAUFZEIT & DETERMINISTISCHE TASK-KLASSEN</h2>
            <p className="text-[11px] text-slate-400 font-mono">
              OB1 Zyklisches Hauptprogramm &amp; Taskklassen-Diagnose
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 font-mono text-[11px]">
          <span className="bg-emerald-950 text-emerald-400 px-2.5 py-1 rounded border border-emerald-800 font-bold">
            CPU: DETERMINISTISCHER SIMULATIONSECHTZETMODUS
          </span>
        </div>
      </div>

      {/* OB1 ZYKLUS ABLAUF-DIAGRAMM (Section 7 Prompt Model) */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-3">
        <div className="font-bold text-slate-200 border-b border-slate-800 pb-2 flex items-center justify-between">
          <span>OB1 Zyklischer Ablaufzyklus</span>
          <span className="text-[10px] font-mono text-slate-400">Soll-Takt: 10.0 ms</span>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-6 gap-2 text-center font-mono text-[11px]">
          <div className="bg-slate-950 border border-slate-800 p-2.5 rounded text-blue-300">
            <div className="text-[9px] text-slate-500 uppercase font-bold">Schritt 1</div>
            <div className="font-semibold mt-1">Prozessdaten lesen</div>
          </div>
          <div className="bg-slate-950 border border-slate-800 p-2.5 rounded text-purple-300">
            <div className="text-[9px] text-slate-500 uppercase font-bold">Schritt 2</div>
            <div className="font-semibold mt-1">Sicherheit prüfen</div>
          </div>
          <div className="bg-slate-950 border border-slate-800 p-2.5 rounded text-amber-300">
            <div className="text-[9px] text-slate-500 uppercase font-bold">Schritt 3</div>
            <div className="font-semibold mt-1">Steuerlogik ausführen</div>
          </div>
          <div className="bg-slate-950 border border-slate-800 p-2.5 rounded text-teal-300">
            <div className="text-[9px] text-slate-500 uppercase font-bold">Schritt 4</div>
            <div className="font-semibold mt-1">Antriebe berechnen</div>
          </div>
          <div className="bg-slate-950 border border-slate-800 p-2.5 rounded text-emerald-300">
            <div className="text-[9px] text-slate-500 uppercase font-bold">Schritt 5</div>
            <div className="font-semibold mt-1">Ausgänge schreiben</div>
          </div>
          <div className="bg-slate-950 border border-slate-800 p-2.5 rounded text-indigo-300">
            <div className="text-[9px] text-slate-500 uppercase font-bold">Schritt 6</div>
            <div className="font-semibold mt-1">Diagnose aktualisieren</div>
          </div>
        </div>
      </div>

      {/* TASK KLASSEN TABELLE (Section 8 Prompt) */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-3">
        <div className="font-bold text-slate-200 border-b border-slate-800 pb-2">
          Priorisierte Taskklassen (Priorität / Zykluszeit / Jitter / Watchdog)
        </div>

        <div className="border border-slate-800 rounded overflow-hidden">
          <table className="w-full text-left border-collapse font-mono text-[11px]">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px]">
              <tr>
                <th className="p-2 border-b border-slate-800">Task Name</th>
                <th className="p-2 border-b border-slate-800">Klasse</th>
                <th className="p-2 border-b border-slate-800">Priorität</th>
                <th className="p-2 border-b border-slate-800">Soll / Ist (ms)</th>
                <th className="p-2 border-b border-slate-800">Jitter</th>
                <th className="p-2 border-b border-slate-800">Watchdog</th>
                <th className="p-2 border-b border-slate-800">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {taskMetriken.map((t) => (
                <tr key={t.id} className="hover:bg-slate-800/40">
                  <td className="p-2 font-bold text-slate-200">{t.name}</td>
                  <td className="p-2 text-purple-400">{t.klasse}</td>
                  <td className="p-2 text-amber-400 font-bold">Prio {t.prioritaet}</td>
                  <td className="p-2 text-slate-300">
                    {t.sollZykluszeitMs} ms / <span className="font-bold text-white">{t.istZykluszeitMs} ms</span>
                  </td>
                  <td className="p-2 text-blue-400">±{t.jitterMs} ms</td>
                  <td className="p-2 text-emerald-400">
                    {t.watchdogAktiv ? 'AKTIV (OK)' : 'INAKTIV'}
                  </td>
                  <td className="p-2">
                    <span
                      className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                        t.fehlerstatus === 'OK'
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                          : 'bg-rose-950 text-rose-400 border border-rose-800'
                      }`}
                    >
                      {t.fehlerstatus}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* DIGITALE EINGÄNGE / AUSGÄNGE FORCE CONTROL */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-3">
        <div className="font-bold text-slate-200 border-b border-slate-800 pb-2 flex items-center justify-between">
          <span>Prozessabbild der Eingänge (E) &amp; Ausgänge (A) - Force-Intervention</span>
          <span className="text-[10px] text-slate-400 font-mono">Echtzeit-SPS-Variablen</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Eingänge */}
          <div className="space-y-2">
            <div className="text-xs font-semibold text-blue-400 border-b border-slate-800 pb-1">
              Digitale Eingänge (E)
            </div>
            {variablen
              .filter((v) => v.adresse.startsWith('E'))
              .map((v) => (
                <div
                  key={v.adresse}
                  className="bg-slate-950 p-2 rounded border border-slate-800 flex items-center justify-between font-mono"
                >
                  <div>
                    <span className="font-bold text-amber-400 mr-2">{v.adresse}</span>
                    <span className="text-slate-300 text-[11px]">{v.symbolName}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span
                      className={`px-2 py-0.5 rounded font-bold text-[10px] ${
                        v.wert ? 'bg-emerald-950 text-emerald-400' : 'bg-slate-800 text-slate-500'
                      }`}
                    >
                      {v.wert ? 'HIGH' : 'LOW'}
                    </span>
                    <button
                      onClick={() => handleToggleForce(v.adresse)}
                      className={`px-2 py-0.5 rounded text-[10px] border transition ${
                        v.forciert
                          ? 'bg-rose-950 border-rose-700 text-rose-300 font-bold'
                          : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      {v.forciert ? 'FORCE AKTIV' : 'Force'}
                    </button>
                  </div>
                </div>
              ))}
          </div>

          {/* Ausgänge */}
          <div className="space-y-2">
            <div className="text-xs font-semibold text-emerald-400 border-b border-slate-800 pb-1">
              Digitale Ausgänge (A)
            </div>
            {variablen
              .filter((v) => v.adresse.startsWith('A'))
              .map((v) => (
                <div
                  key={v.adresse}
                  className="bg-slate-950 p-2 rounded border border-slate-800 flex items-center justify-between font-mono"
                >
                  <div>
                    <span className="font-bold text-emerald-400 mr-2">{v.adresse}</span>
                    <span className="text-slate-300 text-[11px]">{v.symbolName}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span
                      className={`px-2 py-0.5 rounded font-bold text-[10px] ${
                        v.wert ? 'bg-emerald-950 text-emerald-400' : 'bg-slate-800 text-slate-500'
                      }`}
                    >
                      {v.wert ? 'EIN' : 'AUS'}
                    </span>
                    <button
                      onClick={() => handleToggleForce(v.adresse)}
                      className={`px-2 py-0.5 rounded text-[10px] border transition ${
                        v.forciert
                          ? 'bg-rose-950 border-rose-700 text-rose-300 font-bold'
                          : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      {v.forciert ? 'FORCE AKTIV' : 'Force'}
                    </button>
                  </div>
                </div>
              ))}
          </div>
        </div>
      </div>
    </div>
  );
};
