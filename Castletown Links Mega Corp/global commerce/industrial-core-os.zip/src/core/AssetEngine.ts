/**
 * INDUSTRIAL CORE OS - Asset & SCADA Hierarchie Engine
 * Verwalte den Digitalen Zwilling und die hierarchische Anlagenstruktur.
 */

import { AssetKnoten, DigitalerZwilling } from '../types/industrial';

export class AssetEngine {
  private static instance: AssetEngine;

  private anlagenHierarchie: AssetKnoten = {
    id: 'AST-CORP-01',
    name: 'Industrial Enterprise Group AG',
    typ: 'Unternehmen',
    standort: 'Europa / Deutschland',
    status: 'NORMAL',
    beschreibung: 'Zentrale Unternehmensgruppe Industriestandorte',
    unterKnoten: [
      {
        id: 'AST-LOC-STGT',
        name: 'Standort Stuttgart Bad Cannstatt',
        typ: 'Standort',
        standort: 'Stuttgart',
        status: 'NORMAL',
        beschreibung: 'Hauptproduktions- und Technologiezentrum',
        unterKnoten: [
          {
            id: 'AST-WRK-01',
            name: 'Werk 01 - Hochpräzisionsfertigung',
            typ: 'Werk',
            standort: 'Stuttgart Werk 1',
            status: 'NORMAL',
            beschreibung: 'Automatisierte spanende Bearbeitung und Montage',
            unterKnoten: [
              {
                id: 'AST-BER-03',
                name: 'Produktionsbereich 03 - Getriebemontage',
                typ: 'Produktionsbereich',
                standort: 'Halle 3',
                status: 'NORMAL',
                beschreibung: 'Montagelinien für Industriegetriebe',
                unterKnoten: [
                  {
                    id: 'AST-LIN-01',
                    name: 'Montagelinie 01 - Automatikstanzung & Roboter',
                    typ: 'Linie',
                    standort: 'Halle 3 / Linie 1',
                    status: 'NORMAL',
                    beschreibung: 'Vollautomatisierte Hochgeschwindigkeits-Montagelinie',
                    unterKnoten: [
                      {
                        id: 'AST-ZEL-02',
                        name: 'Montagezelle B02 - Spindelfraesen',
                        typ: 'Zelle',
                        standort: 'Zelle B02',
                        status: 'WARNUNG',
                        beschreibung: 'CNC-Spindelfräszelle mit 5-Achs-Simultanbearbeitung',
                        unterKnoten: [
                          {
                            id: 'AST-MAS-501',
                            name: 'CNC-Bearbeitungszentrum Spindel-501',
                            typ: 'Maschine',
                            standort: 'Maschine M501',
                            status: 'WARNUNG',
                            beschreibung: '5-Achs Bearbeitungszentrum mit Werkzeugwechsler',
                            unterKnoten: [
                              {
                                id: 'AST-KOMP-01',
                                name: 'Hauptspindel HS-18K',
                                typ: 'Komponente',
                                standort: 'Spindelachse Z',
                                status: 'WARNUNG',
                                beschreibung: '18.000 U/min Präzisionsspindel mit Keramiklager',
                              },
                              {
                                id: 'AST-KOMP-02',
                                name: 'Hydraulikaggregat HA-250',
                                typ: 'Komponente',
                                standort: 'Untergestell',
                                status: 'NORMAL',
                                beschreibung: '250 bar Hydraulikdrucksystem für Spannfutter',
                              },
                            ],
                          },
                        ],
                      },
                    ],
                  },
                ],
              },
            ],
          },
        ],
      },
    ],
  };

  private digitaleZwillinge: Map<string, DigitalerZwilling> = new Map([
    [
      'AST-MAS-501',
      {
        assetId: 'AST-MAS-501',
        name: 'CNC-Bearbeitungszentrum Spindel-501',
        typ: 'Fräsmaschine / CNC 5-Achs',
        standort: 'Stuttgart / Werk 1 / Halle 3 / Linie 1 / Zelle B02',
        status: 'WARNUNG',
        parameter: {
          sollDrehzahl: 1450,
          maxTemperatur: 65,
          schmiermittelDruck: 6.2,
          vorschub: 850,
        },
        messwerte: {
          temperatur: 52.4,
          vibration: 2.1,
          druck: 6.1,
          drehzahl: 1448,
          auslastung: 88.5,
        },
        aktiveAlarmeAnzahl: 2,
        wartungsdaten: {
          letzteWartung: '2026-08-10T10:00:00Z',
          naechsteWartung: '2026-10-15T08:00:00Z',
          betriebsstunden: 14250,
          mtbfStunden: 480,
          mttrMinuten: 24,
        },
        energieverbrauch: {
          leistungKW: 185.4,
          tagesVerbrauchKWh: 1420,
          proStueckKWh: 0.18,
        },
        softwareversion: 'CORE-OS v2.4.0',
        firmwareversion: 'FW-CNC-9.4.1',
      },
    ],
  ]);

  private constructor() {}

  public static getInstance(): AssetEngine {
    if (!AssetEngine.instance) {
      AssetEngine.instance = new AssetEngine();
    }
    return AssetEngine.instance;
  }

  public getAnlagenHierarchie(): AssetKnoten {
    return this.anlagenHierarchie;
  }

  public getDigitalenZwilling(assetId: string): DigitalerZwilling | undefined {
    return this.digitaleZwillinge.get(assetId);
  }

  public getAlleZwillinge(): DigitalerZwilling[] {
    return Array.from(this.digitaleZwillinge.values());
  }
}

export const assetEngine = AssetEngine.getInstance();
