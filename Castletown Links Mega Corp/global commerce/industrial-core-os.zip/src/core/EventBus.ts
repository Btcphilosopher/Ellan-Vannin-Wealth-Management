/**
 * INDUSTRIAL CORE OS - Event Bus
 * Asynchroner, typisierter, beobachtbarer und fehlertoleranter industrieller Datenbus
 */

export interface EventMessage<T = unknown> {
  id: string;
  thema: string;
  sender: string;
  zeitstempel: string;
  version: string;
  daten: T;
}

type EventCallback<T = unknown> = (event: EventMessage<T>) => void;

export class IndustrialEventBus {
  private static instance: IndustrialEventBus;
  private listeners: Map<string, Set<EventCallback>> = new Map();
  private eventHistorie: EventMessage[] = [];
  private maxHistorieGroesse = 200;

  private constructor() {}

  public static getInstance(): IndustrialEventBus {
    if (!IndustrialEventBus.instance) {
      IndustrialEventBus.instance = new IndustrialEventBus();
    }
    return IndustrialEventBus.instance;
  }

  public abonnieren<T>(thema: string, callback: EventCallback<T>): () => void {
    if (!this.listeners.has(thema)) {
      this.listeners.set(thema, new Set());
    }
    const targetSet = this.listeners.get(thema)!;
    targetSet.add(callback as EventCallback);

    return () => {
      targetSet.delete(callback as EventCallback);
    };
  }

  public veroeffentlichen<T>(thema: string, sender: string, daten: T, version = '1.0'): void {
    const message: EventMessage<T> = {
      id: `EVT-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      thema,
      sender,
      zeitstempel: new Date().toISOString(),
      version,
      daten,
    };

    // Historie sichern
    this.eventHistorie.unshift(message);
    if (this.eventHistorie.length > this.maxHistorieGroesse) {
      this.eventHistorie.pop();
    }

    // Abonnenten benachrichtigen
    const callbacks = this.listeners.get(thema);
    if (callbacks) {
      callbacks.forEach((cb) => {
        try {
          cb(message);
        } catch (err) {
          console.error(`[EventBus] Fehler beim Aufrufen von Listener für Thema '${thema}':`, err);
        }
      });
    }

    // Globalen Wildcard-Listener benachrichtigen
    const wildcardCallbacks = this.listeners.get('*');
    if (wildcardCallbacks) {
      wildcardCallbacks.forEach((cb) => cb(message));
    }
  }

  public getHistorie(): EventMessage[] {
    return [...this.eventHistorie];
  }
}

export const eventBus = IndustrialEventBus.getInstance();
