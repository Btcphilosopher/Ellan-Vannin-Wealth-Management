/**
 * INDUSTRIAL CORE OS - Edge Manager Engine
 * Steuert Industrial Edge Geräte, Applikations-Deployments, Container-Logs & Gesundheitszustände
 */

import { EdgeGeraet } from '../types/industrial';
import { eventBus } from './EventBus';

export class EdgeManagerEngine {
  private static instance: EdgeManagerEngine;

  private edgeGeraete: EdgeGeraet[] = [
    {
      geraetId: 'EDGE-NODE-01',
      name: 'Siemens Industrial Edge Device IPC227E',
      ipAdresse: '192.168.10.101',
      standort: 'Werk Stuttgart - Halle 3 / Linie 1',
      status: 'ONLINE',
      firmwareVersion: 'IED-OS 2.1.0',
      cpuAuslastungProzent: 34,
      ramAuslastungProzent: 52,
      speicherAuslastungProzent: 41,
      letzterKontakt: new Date().toISOString(),
      applikationen: [
        {
          appId: 'APP-OEE-01',
          name: 'Industrial OEE Realtime Analytics',
          version: 'v3.2.1',
          status: 'LAEUFT',
          cpuNutzungProzent: 12,
          speicherMB: 280,
          dockerContainerId: 'cnt-oee-8f3a92',
        },
        {
          appId: 'APP-MQTT-02',
          name: 'High-Performance MQTT Broker',
          version: 'v2.0.4',
          status: 'LAEUFT',
          cpuNutzungProzent: 8,
          speicherMB: 120,
          dockerContainerId: 'cnt-mqtt-1b4e99',
        },
        {
          appId: 'APP-VISION-03',
          name: 'AI Optical Quality Inspector',
          version: 'v1.5.0',
          status: 'LAEUFT',
          cpuNutzungProzent: 14,
          speicherMB: 650,
          dockerContainerId: 'cnt-vision-7c2a11',
        },
      ],
    },
    {
      geraetId: 'EDGE-NODE-02',
      name: 'Industrial Edge Box Micro300',
      ipAdresse: '192.168.10.102',
      standort: 'Werk Stuttgart - Halle 3 / Linie 2',
      status: 'ONLINE',
      firmwareVersion: 'IED-OS 2.1.0',
      cpuAuslastungProzent: 21,
      ramAuslastungProzent: 38,
      speicherAuslastungProzent: 29,
      letzterKontakt: new Date().toISOString(),
      applikationen: [
        {
          appId: 'APP-OEE-01',
          name: 'Industrial OEE Realtime Analytics',
          version: 'v3.2.1',
          status: 'LAEUFT',
          cpuNutzungProzent: 10,
          speicherMB: 260,
          dockerContainerId: 'cnt-oee-3d1f02',
        },
        {
          appId: 'APP-ENERGY-04',
          name: 'Iso50001 Energy Monitor',
          version: 'v4.1.0',
          status: 'LAEUFT',
          cpuNutzungProzent: 6,
          speicherMB: 190,
          dockerContainerId: 'cnt-nrg-9a8821',
        },
      ],
    },
    {
      geraetId: 'EDGE-NODE-03',
      name: 'Industrial Edge Server Nanobox 840',
      ipAdresse: '192.168.10.103',
      standort: 'Werk München - Halle 1',
      status: 'WARNUNG',
      firmwareVersion: 'IED-OS 2.0.8',
      cpuAuslastungProzent: 88,
      ramAuslastungProzent: 91,
      speicherAuslastungProzent: 78,
      letzterKontakt: new Date().toISOString(),
      applikationen: [
        {
          appId: 'APP-PRED-05',
          name: 'Predictive Vibration Analytics',
          version: 'v2.8.0',
          status: 'FEHLER',
          cpuNutzungProzent: 0,
          speicherMB: 0,
          dockerContainerId: 'cnt-pred-003a7d',
        },
      ],
    },
  ];

  private constructor() {}

  public static getInstance(): EdgeManagerEngine {
    if (!EdgeManagerEngine.instance) {
      EdgeManagerEngine.instance = new EdgeManagerEngine();
    }
    return EdgeManagerEngine.instance;
  }

  public getGeraete(): EdgeGeraet[] {
    return this.edgeGeraete;
  }

  public steuereApplikation(geraetId: string, appId: string, aktion: 'START' | 'STOP' | 'UPDATE'): void {
    const geraet = this.edgeGeraete.find((g) => g.geraetId === geraetId);
    if (!geraet) return;

    const app = geraet.applikationen.find((a) => a.appId === appId);
    if (!app) return;

    if (aktion === 'START') {
      app.status = 'LAEUFT';
      app.cpuNutzungProzent = 12;
      app.speicherMB = 310;
    } else if (aktion === 'STOP') {
      app.status = 'GESTOPPT';
      app.cpuNutzungProzent = 0;
      app.speicherMB = 0;
    } else if (aktion === 'UPDATE') {
      app.status = 'AKTUALISIERUNG';
      setTimeout(() => {
        app.version = 'v3.3.0';
        app.status = 'LAEUFT';
        eventBus.veroeffentlichen('EDGE/UPDATE', 'EdgeManager', {
          geraetId,
          appId,
          neueVersion: 'v3.3.0',
        });
      }, 2000);
    }

    eventBus.veroeffentlichen('EDGE/STATUS_CHANGE', 'EdgeManager', {
      geraetId,
      appId,
      status: app.status,
    });
  }

  public registriereNeuesGeraet(name: string, ipAdresse: string, standort: string): EdgeGeraet {
    const neuesGeraet: EdgeGeraet = {
      geraetId: `EDGE-NODE-0${this.edgeGeraete.length + 1}`,
      name,
      ipAdresse,
      standort,
      status: 'ONLINE',
      firmwareVersion: 'IED-OS 2.1.0',
      cpuAuslastungProzent: 15,
      ramAuslastungProzent: 28,
      speicherAuslastungProzent: 20,
      letzterKontakt: new Date().toISOString(),
      applikationen: [],
    };

    this.edgeGeraete.push(neuesGeraet);
    return neuesGeraet;
  }
}

export const edgeManagerEngine = EdgeManagerEngine.getInstance();
