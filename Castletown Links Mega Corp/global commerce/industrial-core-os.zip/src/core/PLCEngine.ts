/**
 * INDUSTRIAL CORE OS - SPS-Abstraktion & Deterministische Laufzeit (PLCEngine)
 * Bietet zyklische Tasks, OB1-Ausführung, Eingänge/Ausgänge, Jitter-Messung & Watchdog
 */

import { SPSProjekt, SPSVariable, TaskMetrik, CoreSystemFehler } from '../types/industrial';
import { eventBus } from './EventBus';

export class PLCEngine {
  private static instance: PLCEngine;
  private isRunning = false;
  private intervalTimer: NodeJS.Timeout | null = null;
  private cycleCounter = 0;

  // Zykluszeiten und Jitter-Messung
  private lastTickTime = performance.now();
  private targetCycleMs = 10; // Soll OB1 = 10ms
  private actualCycleMs = 10;
  private jitterMs = 0.2;

  // Task-Klassen Metriken
  private taskMetriken: TaskMetrik[] = [
    {
      id: 'TASK-SAFETY',
      name: 'Safety-Ueberwachung',
      klasse: 'Sicherheitskritisch',
      prioritaet: 1,
      sollZykluszeitMs: 1,
      istZykluszeitMs: 1.02,
      jitterMs: 0.05,
      deadlineMs: 2,
      watchdogAktiv: true,
      fehlerstatus: 'OK',
      ausfuehrungenZaehler: 154200,
    },
    {
      id: 'TASK-OB1',
      name: 'Zyklisches Hauptprogramm OB1',
      klasse: 'Echtzeit',
      prioritaet: 2,
      sollZykluszeitMs: 10,
      istZykluszeitMs: 10.15,
      jitterMs: 0.35,
      deadlineMs: 15,
      watchdogAktiv: true,
      fehlerstatus: 'OK',
      ausfuehrungenZaehler: 89400,
    },
    {
      id: 'TASK-MOTION',
      name: 'Antriebs- & Achssteuerung',
      klasse: 'Steuerung',
      prioritaet: 3,
      sollZykluszeitMs: 10,
      istZykluszeitMs: 9.98,
      jitterMs: 0.12,
      deadlineMs: 12,
      watchdogAktiv: true,
      fehlerstatus: 'OK',
      ausfuehrungenZaehler: 89400,
    },
    {
      id: 'TASK-IO-SYNC',
      name: 'Prozessdaten I/O Synchronisation',
      klasse: 'Prozessdaten',
      prioritaet: 4,
      sollZykluszeitMs: 50,
      istZykluszeitMs: 49.8,
      jitterMs: 1.2,
      deadlineMs: 75,
      watchdogAktiv: true,
      fehlerstatus: 'OK',
      ausfuehrungenZaehler: 17880,
    },
    {
      id: 'TASK-DIAG',
      name: 'Systemdiagnose & Watchdog',
      klasse: 'Diagnose',
      prioritaet: 5,
      sollZykluszeitMs: 100,
      istZykluszeitMs: 100.4,
      jitterMs: 2.1,
      deadlineMs: 150,
      watchdogAktiv: true,
      fehlerstatus: 'OK',
      ausfuehrungenZaehler: 8940,
    },
  ];

  // Aktuelles SPS-Projekt State
  private projekt: SPSProjekt = {
    projektId: 'PRJ-CORE-001',
    name: 'Hauptfertigung_Linie1_TIA_Core',
    version: 'V2.4.0',
    erstelltAm: '2026-01-15T08:00:00Z',
    bearbeitetAm: new Date().toISOString(),
    controllerTyp: 'CPU 1518-4 PN/DP',
    status: 'RUN',
    variablen: [
      { adresse: 'E0.0', symbolName: 'NotAus_Quittiert', datentyp: 'BOOL', wert: true, kommentar: 'Not-Aus Schalter gesichert', forciert: false },
      { adresse: 'E0.1', symbolName: 'Lichtschranke_Einlauf', datentyp: 'BOOL', wert: true, kommentar: 'Bauteil im Einlauf erkannt', forciert: false },
      { adresse: 'E0.2', symbolName: 'Sensor_Druck_OK', datentyp: 'BOOL', wert: true, kommentar: 'Pneumatikdruck min 6 bar', forciert: false },
      { adresse: 'E0.3', symbolName: 'Start_Taster', datentyp: 'BOOL', wert: true, kommentar: 'Bediener-Startsignal', forciert: false },
      
      { adresse: 'A0.0', symbolName: 'Band_Motor_EIN', datentyp: 'BOOL', wert: true, kommentar: 'Hauptförderband Antrieb', forciert: false },
      { adresse: 'A0.1', symbolName: 'Hydraulik_Ventil_AUF', datentyp: 'BOOL', wert: true, kommentar: 'Hauptventil Druckversorgung', forciert: false },
      { adresse: 'A0.2', symbolName: 'Signalleuchte_Gruen', datentyp: 'BOOL', wert: true, kommentar: 'Anlage im Betrieb', forciert: false },
      { adresse: 'A0.3', symbolName: 'Signalleuchte_Rot', datentyp: 'BOOL', wert: false, kommentar: 'Sammelstörung', forciert: false },

      { adresse: 'M0.0', symbolName: 'Merker_Automatikbetrieb', datentyp: 'BOOL', wert: true, kommentar: 'Automatikmodus aktiv', forciert: false },
      { adresse: 'M0.1', symbolName: 'Merker_Takt_100ms', datentyp: 'BOOL', wert: false, kommentar: 'Taktmerker 100ms', forciert: false },
      { adresse: 'DB1.DBD0', symbolName: 'Soll_Geschwindigkeit', datentyp: 'REAL', wert: 1450.0, kommentar: 'Soll-Drehzahl U/min', forciert: false },
      { adresse: 'DB1.DBD4', symbolName: 'Ist_Geschwindigkeit', datentyp: 'REAL', wert: 1448.2, kommentar: 'Ist-Drehzahl U/min', forciert: false },
      { adresse: 'DB1.DBD8', symbolName: 'Temperatur_Lager_C', datentyp: 'REAL', wert: 48.5, kommentar: 'Spindellagertemperatur', forciert: false },
      { adresse: 'DB1.DBD12', symbolName: 'Teilezaehler_Gut', datentyp: 'DINT', wert: 12450, kommentar: 'Produzierte Gutteile', forciert: false },
      { adresse: 'DB1.DBD16', symbolName: 'Teilezaehler_Ausschuss', datentyp: 'DINT', wert: 32, kommentar: 'Ausschussteile', forciert: false },
    ],
    hardwareModule: [
      { steckplatz: 1, modulTyp: 'CPU 1518-4 PN/DP', bezeichnung: 'Zentralsteuerung PROFINET/PROFIBUS', ipAdresse: '192.168.1.10', status: 'OK' },
      { steckplatz: 2, modulTyp: 'DI 32x24VDC HF', bezeichnung: 'Digitale Eingabe 32-Kanal 24V', status: 'OK' },
      { steckplatz: 3, modulTyp: 'DQ 32x24VDC/0.5A ST', bezeichnung: 'Digitale Ausgabe 32-Kanal', status: 'OK' },
      { steckplatz: 4, modulTyp: 'AI 8xU/I/RTD/TC ST', bezeichnung: 'Analogeingabe 8-Kanal 16Bit', status: 'OK' },
      { steckplatz: 5, modulTyp: 'TM PosInput 2', bezeichnung: 'Inkrementalgeber / Achspositionsmodul', status: 'OK' },
    ],
    bausteine: [
      {
        id: 'OB1',
        name: 'Main_Cyclic_OB1',
        typ: 'OB',
        beschreibung: 'Zyklisches Hauptprogramm - Prozessdaten lesen, Logik ausführen, Ausgänge schreiben',
        eingaenge: ['E0.0', 'E0.1', 'E0.2', 'E0.3'],
        ausgaenge: ['A0.0', 'A0.1', 'A0.2', 'A0.3'],
        netzwerke: [
          {
            id: 1,
            titel: 'Netzwerk 1: Not-Aus und Sicherheitskontrolle',
            logikTyp: 'KOP',
            code: 'U "E0.0" (= NotAus_Quittiert)\nUN "E0.2" (= Sensor_Druck_OK)\n= "M0.0" (= Merker_Automatikbetrieb)',
            aktiv: true,
          },
          {
            id: 2,
            titel: 'Netzwerk 2: Bandantriebssteuerung',
            logikTyp: 'ST',
            code: 'IF Merker_Automatikbetrieb AND Start_Taster THEN\n  Band_Motor_EIN := TRUE;\n  Signalleuchte_Gruen := TRUE;\n  Signalleuchte_Rot := FALSE;\nELSE\n  Band_Motor_EIN := FALSE;\n  Signalleuchte_Gruen := FALSE;\n  Signalleuchte_Rot := TRUE;\nEND_IF;',
            aktiv: true,
          },
          {
            id: 3,
            titel: 'Netzwerk 3: Drehzahl-Regelung & Temperaturüberwachung',
            logikTyp: 'ST',
            code: 'Ist_Geschwindigkeit := Soll_Geschwindigkeit + (SIN(Takt) * 3.5);\nTemperatur_Lager_C := 45.0 + (Ist_Geschwindigkeit / 100.0) * 0.25;',
            aktiv: true,
          },
        ],
      },
    ],
  };

  private lastFehler: CoreSystemFehler[] = [];

  private constructor() {
    this.startEngine();
  }

  public static getInstance(): PLCEngine {
    if (!PLCEngine.instance) {
      PLCEngine.instance = new PLCEngine();
    }
    return PLCEngine.instance;
  }

  public startEngine(): void {
    if (this.isRunning) return;
    this.isRunning = true;
    this.projekt.status = 'RUN';

    this.intervalTimer = setInterval(() => {
      this.executeOB1Cycle();
    }, this.targetCycleMs);
  }

  public stopEngine(): void {
    this.isRunning = false;
    this.projekt.status = 'GESTOPPT';
    if (this.intervalTimer) {
      clearInterval(this.intervalTimer);
      this.intervalTimer = null;
    }
  }

  public executeOB1Cycle(): void {
    const now = performance.now();
    const elapsed = now - this.lastTickTime;
    this.lastTickTime = now;

    // Jitter & Zykluszeit
    this.actualCycleMs = elapsed;
    const currentJitter = Math.abs(elapsed - this.targetCycleMs);
    this.jitterMs = this.jitterMs * 0.8 + currentJitter * 0.2; // geglätteter Jitter

    this.cycleCounter++;

    // Zyklische Variablen-Simulation
    const sollSpeed = this.getVariableWert('DB1.DBD0') as number;
    const noise = (Math.sin(this.cycleCounter / 10) * 2.5) + (Math.random() * 0.8 - 0.4);
    const istSpeed = Math.max(0, sollSpeed + noise);
    this.setVariableWert('DB1.DBD4', parseFloat(istSpeed.toFixed(1)));

    // Temperatursimulation
    const temp = 42.0 + (istSpeed / 1450) * 12.0 + (Math.sin(this.cycleCounter / 50) * 1.5);
    this.setVariableWert('DB1.DBD8', parseFloat(temp.toFixed(1)));

    // Stückzahl-Fortschritt
    if (this.cycleCounter % 100 === 0) {
      const gut = (this.getVariableWert('DB1.DBD12') as number) + 1;
      this.setVariableWert('DB1.DBD12', gut);
    }

    // Task Metriken aktualisieren
    const ob1Task = this.taskMetriken.find((t) => t.id === 'TASK-OB1');
    if (ob1Task) {
      ob1Task.istZykluszeitMs = parseFloat(this.actualCycleMs.toFixed(2));
      ob1Task.jitterMs = parseFloat(this.jitterMs.toFixed(3));
      ob1Task.ausfuehrungenZaehler = this.cycleCounter;

      if (ob1Task.istZykluszeitMs > ob1Task.deadlineMs) {
        ob1Task.fehlerstatus = 'DEADLINE_VERPASST';
        this.erzeugeSystemFehler(
          'IC-RT-1042',
          'Echtzeit-Laufzeit',
          'WARNUNG',
          'SPS-Laufzeit',
          `Zykluszeit überschreitet Grenzwert (${ob1Task.istZykluszeitMs}ms > ${ob1Task.deadlineMs}ms)`,
          'Systemauslastung oder Unterbrechung in der Task-Queue',
          'Prüfen Sie die CPU-Auslastung und reduzieren Sie synchrone Task-Blöcke.'
        );
      } else {
        ob1Task.fehlerstatus = 'OK';
      }
    }

    // Telemetrie an Datenbus senden (jede Sekunde / 100 Ticks)
    if (this.cycleCounter % 20 === 0) {
      eventBus.veroeffentlichen('SPS/TELEMETRIE', 'PLCEngine', {
        cycleCounter: this.cycleCounter,
        actualCycleMs: this.actualCycleMs,
        jitterMs: this.jitterMs,
        speed: istSpeed,
        temp: temp,
        status: this.projekt.status,
      });
    }
  }

  public getProjekt(): SPSProjekt {
    return this.projekt;
  }

  public getTaskMetriken(): TaskMetrik[] {
    return this.taskMetriken;
  }

  public getVariableWert(adresse: string): boolean | number | string {
    const v = this.projekt.variablen.find((v) => v.adresse === adresse || v.symbolName === adresse);
    if (!v) return 0;
    return v.forciert ? v.forciertWert! : v.wert;
  }

  public setVariableWert(adresse: string, wert: boolean | number | string): void {
    const v = this.projekt.variablen.find((v) => v.adresse === adresse || v.symbolName === adresse);
    if (v) {
      if (v.forciert) {
        v.forciertWert = wert;
      } else {
        v.wert = wert;
      }
    }
  }

  public toggleForceVariable(adresse: string, forceWert?: boolean | number | string): void {
    const v = this.projekt.variablen.find((v) => v.adresse === adresse || v.symbolName === adresse);
    if (v) {
      v.forciert = !v.forciert;
      if (v.forciert) {
        v.forciertWert = forceWert !== undefined ? forceWert : v.wert;
      }
    }
  }

  public erzeugeSystemFehler(
    code: string,
    kategorie: CoreSystemFehler['kategorie'],
    schweregrad: CoreSystemFehler['schweregrad'],
    komponente: string,
    meldung: string,
    technischeUrsache: string,
    benutzerHinweis: string
  ): void {
    const fehler: CoreSystemFehler = {
      fehlerCode: code,
      kategorie,
      schweregrad,
      zeitstempel: new Date().toISOString(),
      komponente,
      meldung,
      technischeUrsache,
      benutzerHinweis,
      diagnoseId: `DIAG-${Date.now()}`,
    };
    this.lastFehler.unshift(fehler);
    if (this.lastFehler.length > 50) this.lastFehler.pop();

    eventBus.veroeffentlichen('SYSTEM/FEHLER', 'PLCEngine', fehler);
  }

  public getFehlerHistorie(): CoreSystemFehler[] {
    return this.lastFehler;
  }
}

export const plcEngine = PLCEngine.getInstance();
