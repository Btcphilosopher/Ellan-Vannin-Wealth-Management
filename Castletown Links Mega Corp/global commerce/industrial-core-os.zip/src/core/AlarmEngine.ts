/**
 * INDUSTRIAL CORE OS - Alarm Server Engine
 * Professionelles industrielles Alarmmanagement mit Alarmhistorie, Gruppen, Quittierung und Berichten.
 */

import { AlarmEintrag, AlarmPrioritaet, AlarmStatus } from '../types/industrial';
import { eventBus } from './EventBus';
import { securityEngine } from './SecurityEngine';

export class AlarmEngine {
  private static instance: AlarmEngine;

  private alarme: AlarmEintrag[] = [
    {
      alarmId: 'ALM-2026-101',
      zeitstempel: new Date(Date.now() - 900000).toISOString(),
      anlage: 'Werk Stuttgart / Linie 1',
      komponente: 'Hauptspindel_M01',
      prioritaet: 'KRITISCH',
      status: 'QUITTIERUNG_ERFORDERLICH',
      ursache: 'Spindellagertemperatur > 58°C Grenzwert überschritten',
      beschreibung: 'Übertemperatur im Hauptspindellager der Bearbeitungszelle B02',
      quittierungsStatus: false,
      gruppe: 'HARDWARE',
    },
    {
      alarmId: 'ALM-2026-102',
      zeitstempel: new Date(Date.now() - 1800000).toISOString(),
      anlage: 'Werk Stuttgart / Linie 1',
      komponente: 'Pneumatik_Druckregler',
      prioritaet: 'HOCH',
      status: 'AKTIV',
      ursache: 'Systemdruck unter 5.8 bar abgesunken',
      beschreibung: 'Druckabfall im Hauptversorgungsstrang Pneumatik',
      quittierungsStatus: false,
      gruppe: 'PROZESS',
    },
    {
      alarmId: 'ALM-2026-103',
      zeitstempel: new Date(Date.now() - 3600000).toISOString(),
      anlage: 'Werk München / Linie 2',
      komponente: 'PROFINET_Koppler_03',
      prioritaet: 'MITTEL',
      status: 'QUITTIERT',
      ursache: 'Paketverlust auf PROFINET Feldbus > 0.5%',
      beschreibung: 'Netzwerkverzögerung am Dezentralen I/O-Koppler Steckplatz 4',
      quittierungsStatus: true,
      quittiertVonBenutzer: 'b.koenig',
      quittiertZeitstempel: new Date(Date.now() - 3000000).toISOString(),
      gruppe: 'NETZWERK',
    },
    {
      alarmId: 'ALM-2026-104',
      zeitstempel: new Date(Date.now() - 7200000).toISOString(),
      anlage: 'Werk Stuttgart / Linie 1',
      komponente: 'Kühlaggregat_Zelle1',
      prioritaet: 'NIEDRIG',
      status: 'WIEDERHERGESTELLT',
      ursache: 'Kühlmittelfüllstand Warnschwelle erreicht',
      beschreibung: 'Wartungshinweis: Kühlmittel nachfüllen innerhalb von 48 Std',
      quittierungsStatus: true,
      quittiertVonBenutzer: 't.becker',
      quittiertZeitstempel: new Date(Date.now() - 6000000).toISOString(),
      wiederherstellungszeit: new Date(Date.now() - 5000000).toISOString(),
      gruppe: 'ENERGIE',
    },
  ];

  private constructor() {}

  public static getInstance(): AlarmEngine {
    if (!AlarmEngine.instance) {
      AlarmEngine.instance = new AlarmEngine();
    }
    return AlarmEngine.instance;
  }

  public getAlarme(): AlarmEintrag[] {
    return this.alarme;
  }

  public quittiereAlarm(alarmId: string): void {
    const alarm = this.alarme.find((a) => a.alarmId === alarmId);
    if (alarm) {
      const user = securityEngine.getAktuellerBenutzer();
      alarm.status = 'QUITTIERT';
      alarm.quittierungsStatus = true;
      alarm.quittiertVonBenutzer = user.benutzername;
      alarm.quittiertZeitstempel = new Date().toISOString();

      securityEngine.registriereAuditEintrag(
        'ALARM_SERVER',
        'ALARM_QUITTIERT',
        alarm.alarmId,
        'QUITTIERUNG_ERFORDERLICH',
        'QUITTIERT',
        'ERFOLG'
      );

      eventBus.veroeffentlichen('ALARM/QUITTIERT', 'AlarmEngine', {
        alarmId,
        benutzer: user.benutzername,
      });
    }
  }

  public erzeugeNeuenAlarm(
    anlage: string,
    komponente: string,
    prioritaet: AlarmPrioritaet,
    ursache: string,
    beschreibung: string,
    gruppe: AlarmEintrag['gruppe']
  ): AlarmEintrag {
    const neuerAlarm: AlarmEintrag = {
      alarmId: `ALM-2026-${100 + this.alarme.length + 1}`,
      zeitstempel: new Date().toISOString(),
      anlage,
      komponente,
      prioritaet,
      status: 'QUITTIERUNG_ERFORDERLICH',
      ursache,
      beschreibung,
      quittierungsStatus: false,
      gruppe,
    };

    this.alarme.unshift(neuerAlarm);

    eventBus.veroeffentlichen('ALARM/NEU', 'AlarmEngine', neuerAlarm);
    return neuerAlarm;
  }
}

export const alarmEngine = AlarmEngine.getInstance();
