/**
 * INDUSTRIAL CORE OS - Security & Audit Engine
 * Implementiert RBAC, Zertifikatsverwaltung, MFA, Netzwerkszonen und unlöschbares Audit-Log
 */

import { BenutzerProfil, BenutzerRolle, AuditLogEintrag } from '../types/industrial';
import { eventBus } from './EventBus';

export class SecurityEngine {
  private static instance: SecurityEngine;

  private aktuellerBenutzer: BenutzerProfil = {
    id: 'USR-8801',
    benutzername: 'e.schmidt',
    vollerName: 'Dipl.-Ing. Erich Schmidt',
    email: 'e.schmidt@industrial-core.com',
    rolle: 'ENGINEER',
    mfaAktiv: true,
    netzwerkZone: 'OT_SICHER',
    letzterLogin: new Date().toISOString(),
    zertifikatStatus: 'GUELTIG',
  };

  private verfuegbareBenutzer: BenutzerProfil[] = [
    {
      id: 'USR-8801',
      benutzername: 'e.schmidt',
      vollerName: 'Dipl.-Ing. Erich Schmidt',
      email: 'e.schmidt@industrial-core.com',
      rolle: 'ENGINEER',
      mfaAktiv: true,
      netzwerkZone: 'OT_SICHER',
      letzterLogin: '2026-09-22T08:15:00Z',
      zertifikatStatus: 'GUELTIG',
    },
    {
      id: 'USR-8802',
      benutzername: 'a.weber',
      vollerName: 'Dr. Anna Weber',
      email: 'a.weber@industrial-core.com',
      rolle: 'ADMINISTRATOR',
      mfaAktiv: true,
      netzwerkZone: 'OT_SICHER',
      letzterLogin: '2026-09-22T07:30:00Z',
      zertifikatStatus: 'GUELTIG',
    },
    {
      id: 'USR-8803',
      benutzername: 'm.hoffmann',
      vollerName: 'Michael Hoffmann',
      email: 'm.hoffmann@industrial-core.com',
      rolle: 'BETRIEBSLEITER',
      mfaAktiv: true,
      netzwerkZone: 'IT_VERWALTUNG',
      letzterLogin: '2026-09-21T16:20:00Z',
      zertifikatStatus: 'GUELTIG',
    },
    {
      id: 'USR-8804',
      benutzername: 'k.fischer',
      vollerName: 'Klaus Fischer',
      email: 'k.fischer@industrial-core.com',
      rolle: 'INBETRIEBNEHMER',
      mfaAktiv: false,
      netzwerkZone: 'OT_SICHER',
      letzterLogin: '2026-09-20T11:45:00Z',
      zertifikatStatus: 'ABGELAUFEN',
    },
    {
      id: 'USR-8805',
      benutzername: 't.becker',
      vollerName: 'Thomas Becker',
      email: 't.becker@industrial-core.com',
      rolle: 'INSTANDHALTER',
      mfaAktiv: true,
      netzwerkZone: 'OT_PFLANZ',
      letzterLogin: '2026-09-22T06:00:00Z',
      zertifikatStatus: 'GUELTIG',
    },
    {
      id: 'USR-8806',
      benutzername: 'b.koenig',
      vollerName: 'Bernd König',
      email: 'b.koenig@industrial-core.com',
      rolle: 'BEDIENER',
      mfaAktiv: false,
      netzwerkZone: 'OT_PFLANZ',
      letzterLogin: '2026-09-22T05:50:00Z',
      zertifikatStatus: 'GUELTIG',
    },
    {
      id: 'USR-8807',
      benutzername: 's.schuster',
      vollerName: 'Sabine Schuster',
      email: 's.schuster@industrial-core.com',
      rolle: 'AUDITOR',
      mfaAktiv: true,
      netzwerkZone: 'IT_VERWALTUNG',
      letzterLogin: '2026-09-19T14:10:00Z',
      zertifikatStatus: 'GUELTIG',
    },
  ];

  private auditLogs: AuditLogEintrag[] = [
    {
      id: 'AUD-9901',
      zeit: new Date(Date.now() - 3600000).toISOString(),
      benutzer: 'e.schmidt',
      rolle: 'ENGINEER',
      system: 'SPS_RUNTIME',
      aktion: 'OB1_BAUSTEIN_EDTIERT',
      objekt: 'Main_Cyclic_OB1 / Netz 2',
      vorherigerZustand: 'Soll_Geschwindigkeit = 1400',
      neuerZustand: 'Soll_Geschwindigkeit = 1450',
      ergebnis: 'ERFOLG',
      ipClient: '192.168.10.45',
    },
    {
      id: 'AUD-9902',
      zeit: new Date(Date.now() - 7200000).toISOString(),
      benutzer: 'a.weber',
      rolle: 'ADMINISTRATOR',
      system: 'SECURITY_MODULE',
      aktion: 'ZERTIFIKAT_RENOVIERT',
      objekt: 'CPU_1518_PROFINET_TLS_CERT',
      vorherigerZustand: 'Ablauf 2026-10-01',
      neuerZustand: 'Ablauf 2028-10-01',
      ergebnis: 'ERFOLG',
      ipClient: '192.168.10.12',
    },
    {
      id: 'AUD-9903',
      zeit: new Date(Date.now() - 14400000).toISOString(),
      benutzer: 'b.koenig',
      rolle: 'BEDIENER',
      system: 'ALARM_SERVER',
      aktion: 'ALARM_QUITTIERT',
      objekt: 'ALM-102_Druckabfall_Pneumatik',
      vorherigerZustand: 'QUITTIERUNG_ERFORDERLICH',
      neuerZustand: 'QUITTIERT',
      ergebnis: 'ERFOLG',
      ipClient: '192.168.10.88',
    },
  ];

  private constructor() {}

  public static getInstance(): SecurityEngine {
    if (!SecurityEngine.instance) {
      SecurityEngine.instance = new SecurityEngine();
    }
    return SecurityEngine.instance;
  }

  public getAktuellerBenutzer(): BenutzerProfil {
    return this.aktuellerBenutzer;
  }

  public wechsleBenutzer(benutzerId: string): void {
    const usr = this.verfuegbareBenutzer.find((u) => u.id === benutzerId);
    if (usr) {
      const alt = this.aktuellerBenutzer.benutzername;
      this.aktuellerBenutzer = { ...usr, letzterLogin: new Date().toISOString() };
      
      this.registriereAuditEintrag(
        'SECURITY_AUTH',
        'BENUTZER_WECHSEL',
        'Aktive_Sitzung',
        `Alter Benutzer: ${alt}`,
        `Neuer Benutzer: ${usr.benutzername} (${usr.rolle})`,
        'ERFOLG'
      );
    }
  }

  public getAlleBenutzer(): BenutzerProfil[] {
    return this.verfuegbareBenutzer;
  }

  public registriereAuditEintrag(
    system: string,
    aktion: string,
    objekt: string,
    vorherigerZustand: string,
    neuerZustand: string,
    ergebnis: 'ERFOLG' | 'FEHLER' | 'ABGELEHNT'
  ): void {
    const eintrag: AuditLogEintrag = {
      id: `AUD-${Date.now()}-${Math.floor(Math.random() * 100)}`,
      zeit: new Date().toISOString(),
      benutzer: this.aktuellerBenutzer.benutzername,
      rolle: this.aktuellerBenutzer.rolle,
      system,
      aktion,
      objekt,
      vorherigerZustand,
      neuerZustand,
      ergebnis,
      ipClient: '192.168.10.45',
    };

    this.auditLogs.unshift(eintrag);
    eventBus.veroeffentlichen('SECURITY/AUDIT', 'SecurityEngine', eintrag);
  }

  public getAuditLogs(): AuditLogEintrag[] {
    return [...this.auditLogs];
  }
}

export const securityEngine = SecurityEngine.getInstance();
