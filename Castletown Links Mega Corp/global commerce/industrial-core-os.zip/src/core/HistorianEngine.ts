/**
 * INDUSTRIAL CORE OS - Industrieller Zeitreihenspeicher (HistorianEngine)
 * Speichert Prozesswerte, Maschinenzustände, Energiedaten und Alarme mit Millisekunden- und Sekundenauflösung.
 */

import { ZeitreihenDatenpunkt } from '../types/industrial';
import { plcEngine } from './PLCEngine';

export class HistorianEngine {
  private static instance: HistorianEngine;
  private datenpunkte: ZeitreihenDatenpunkt[] = [];
  private maxPunkte = 1000;
  private timer: NodeJS.Timeout | null = null;

  private constructor() {
    this.startAufzeichnung();
  }

  public static getInstance(): HistorianEngine {
    if (!HistorianEngine.instance) {
      HistorianEngine.instance = new HistorianEngine();
    }
    return HistorianEngine.instance;
  }

  public startAufzeichnung(): void {
    if (this.timer) return;
    this.timer = setInterval(() => {
      this.erfasseDatenpunkte();
    }, 1000); // 1-Sekunden-Takt
  }

  private erfasseDatenpunkte(): void {
    const jetzt = new Date();
    const iso = jetzt.toISOString();
    const ms = jetzt.getTime();

    // 1. Ist-Geschwindigkeit
    const speed = plcEngine.getVariableWert('DB1.DBD4') as number;
    this.hinzufuegen({
      zeitstempel: iso,
      msTimestamp: ms,
      variablenId: 'DB1.DBD4_IstGeschwindigkeit',
      messwert: Number(speed) || 0,
      einheit: 'U/min',
      qualitaet: 'GUT',
    });

    // 2. Temperatursensor
    const temp = plcEngine.getVariableWert('DB1.DBD8') as number;
    this.hinzufuegen({
      zeitstempel: iso,
      msTimestamp: ms,
      variablenId: 'DB1.DBD8_Lagertemperatur',
      messwert: Number(temp) || 0,
      einheit: '°C',
      qualitaet: 'GUT',
    });

    // 3. Elektrische Leistung
    const leistung = 120 + (Number(speed) / 1450) * 85 + (Math.sin(ms / 5000) * 12);
    this.hinzufuegen({
      zeitstempel: iso,
      msTimestamp: ms,
      variablenId: 'ENERGIE_ElektrischeLeistung',
      messwert: parseFloat(leistung.toFixed(1)),
      einheit: 'kW',
      qualitaet: 'GUT',
    });

    // 4. Vibration
    const vib = 0.8 + (Number(temp) > 55 ? 2.5 : 0.4) + (Math.random() * 0.3);
    this.hinzufuegen({
      zeitstempel: iso,
      msTimestamp: ms,
      variablenId: 'VIBRATION_Hauptspindel',
      messwert: parseFloat(vib.toFixed(2)),
      einheit: 'mm/s',
      qualitaet: 'GUT',
    });
  }

  public hinzufuegen(punkt: ZeitreihenDatenpunkt): void {
    this.datenpunkte.push(punkt);
    if (this.datenpunkte.length > this.maxPunkte) {
      this.datenpunkte.shift();
    }
  }

  public getZeitreiheFuerVariable(variablenId: string, anzahl = 60): ZeitreihenDatenpunkt[] {
    return this.datenpunkte
      .filter((p) => p.variablenId === variablenId)
      .slice(-anzahl);
  }

  public getAlleDatenpunkte(): ZeitreihenDatenpunkt[] {
    return [...this.datenpunkte];
  }
}

export const historianEngine = HistorianEngine.getInstance();
