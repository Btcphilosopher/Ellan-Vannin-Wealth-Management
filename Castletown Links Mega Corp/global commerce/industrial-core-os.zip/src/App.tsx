/**
 * INDUSTRIAL CORE OS - Hauptanwendungs-Komponente
 * European Industrial Automation Platform
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Sidebar, ModulSchluessel } from './components/Sidebar';
import { NotAusModal } from './components/NotAusModal';
import { AuditDrawer } from './components/AuditDrawer';

import { EngineeringView } from './views/EngineeringView';
import { ScadaView } from './views/ScadaView';
import { ProductionView } from './views/ProductionView';
import { DigitalTwinView } from './views/DigitalTwinView';
import { EnergyView } from './views/EnergyView';
import { AlarmView } from './views/AlarmView';
import { HistorianView } from './views/HistorianView';
import { EdgeManagerView } from './views/EdgeManagerView';
import { AnalyticsView } from './views/AnalyticsView';
import { CybersecurityView } from './views/CybersecurityView';
import { PluginsView } from './views/PluginsView';

import { alarmEngine } from './core/AlarmEngine';
import { plcEngine } from './core/PLCEngine';

export default function App() {
  const [aktivesModul, setAktivesModul] = useState<ModulSchluessel>('engineering');
  const [auditDrawerOffen, setAuditDrawerOffen] = useState(false);
  const [notAusModalOffen, setNotAusModalOffen] = useState(false);
  const [aktiveAlarmeAnzahl, setAktiveAlarmeAnzahl] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      const ungequittiert = alarmEngine
        .getAlarme()
        .filter((a) => !a.quittierungsStatus).length;
      setAktiveAlarmeAnzahl(ungequittiert);
    }, 500);

    return () => clearInterval(interval);
  }, []);

  const handleNotAusTriggered = () => {
    plcEngine.stopEngine();
    setNotAusModalOffen(true);
  };

  return (
    <div className="h-screen w-screen flex flex-col bg-slate-950 text-slate-100 font-sans antialiased overflow-hidden select-none">
      {/* Top Header & Status Bar */}
      <Header
        onOpenAuditLog={() => setAuditDrawerOffen(true)}
        onNotAusTriggered={handleNotAusTriggered}
      />

      {/* Main Workspace (Sidebar + View Canvas) */}
      <div className="flex-1 flex overflow-hidden">
        <Sidebar
          aktivesModul={aktivesModul}
          onSelectModul={setAktivesModul}
          aktiveAlarmeAnzahl={aktiveAlarmeAnzahl}
        />

        <main className="flex-1 flex flex-col overflow-hidden relative bg-slate-950">
          {aktivesModul === 'engineering' && <EngineeringView />}
          {aktivesModul === 'scada' && <ScadaView />}
          {aktivesModul === 'production' && <ProductionView />}
          {aktivesModul === 'digital_twin' && <DigitalTwinView />}
          {aktivesModul === 'energy' && <EnergyView />}
          {aktivesModul === 'alarms' && <AlarmView />}
          {aktivesModul === 'historian' && <HistorianView />}
          {aktivesModul === 'edge' && <EdgeManagerView />}
          {aktivesModul === 'analytics' && <AnalyticsView />}
          {aktivesModul === 'security' && <CybersecurityView />}
          {aktivesModul === 'plugins' && <PluginsView />}
        </main>
      </div>

      {/* Emergency Stop & Audit Drawers */}
      <NotAusModal
        offen={notAusModalOffen}
        onSchliessen={() => setNotAusModalOffen(false)}
      />
      <AuditDrawer
        offen={auditDrawerOffen}
        onSchliessen={() => setAuditDrawerOffen(false)}
      />
    </div>
  );
}
