/**
 * INDUSTRIAL CORE OS - Typdefinitionen
 * Proprietäre europäische Industrieplattform
 */

// --- 1. PROJEKT & HIERARCHIE ---
export type AssetTyp = 
  | 'Unternehmen'
  | 'Standort'
  | 'Werk'
  | 'Produktionsbereich'
  | 'Linie'
  | 'Zelle'
  | 'Maschine'
  | 'Komponente';

export interface AssetKnoten {
  id: string;
  name: string;
  typ: AssetTyp;
  elternId?: string;
  standort: string;
  status: 'NORMAL' | 'WARNUNG' | 'STOERUNG' | 'INAKTIV';
  beschreibung: string;
  unterKnoten?: AssetKnoten[];
}

// --- 2. DIGITALER ZWILLING ---
export interface DigitalerZwilling {
  assetId: string;
  name: string;
  typ: string;
  standort: string;
  status: 'NORMAL' | 'WARNUNG' | 'STOERUNG' | 'INAKTIV';
  parameter: Record<string, number | string | boolean>;
  messwerte: {
    temperatur: number; // °C
    vibration: number;  // mm/s
    druck: number;      // bar
    drehzahl: number;   // U/min
    auslastung: number; // %
  };
  aktiveAlarmeAnzahl: number;
  wartungsdaten: {
    letzteWartung: string;
    naechsteWartung: string;
    betriebsstunden: number;
    mtbfStunden: number;
    mttrMinuten: number;
  };
  energieverbrauch: {
    leistungKW: number;
    tagesVerbrauchKWh: number;
    proStueckKWh: number;
  };
  softwareversion: string;
  firmwareversion: string;
}

// --- 3. ECHTZEIT TASK KLASSEN & DIAGNOSE ---
export type TaskKlasse = 
  | 'Sicherheitskritisch'
  | 'Echtzeit'
  | 'Steuerung'
  | 'Prozessdaten'
  | 'Diagnose'
  | 'Historian'
  | 'Analytics';

export interface TaskMetrik {
  id: string;
  name: string;
  klasse: TaskKlasse;
  prioritaet: number; // 1 (höchste) bis 7 (niedrigste)
  sollZykluszeitMs: number;
  istZykluszeitMs: number;
  jitterMs: number;
  deadlineMs: number;
  watchdogAktiv: boolean;
  fehlerstatus: 'OK' | 'WARNUNG' | 'DEADLINE_VERPASST' | 'WATCHDOG_FEHLER';
  ausfuehrungenZaehler: number;
}

// --- 4. SPS / CONTROLLER & ENGINEERING ---
export interface SPSVariable {
  adresse: string; // z.B. "E0.0", "A0.1", "M10.0", "DB1.DBD0"
  symbolName: string;
  datentyp: 'BOOL' | 'INT' | 'DINT' | 'REAL' | 'TIME' | 'STRING';
  wert: boolean | number | string;
  kommentar: string;
  forciert: boolean;
  forciertWert?: boolean | number | string;
}

export interface Funktionsbaustein {
  id: string;
  name: string; // z.B. "FB10_Bandsteuerung"
  typ: 'FB' | 'FC' | 'DB' | 'OB';
  beschreibung: string;
  eingaenge: string[];
  ausgaenge: string[];
  netzwerke: {
    id: number;
    titel: string;
    logikTyp: 'KOP' | 'FUP' | 'ST'; // Kontaktplan, Funktionsplan, Strukturierter Text
    code: string;
    aktiv: boolean;
  }[];
}

export interface SPSProjekt {
  projektId: string;
  name: string;
  version: string;
  erstelltAm: string;
  bearbeitetAm: string;
  controllerTyp: 'CPU 1518-4 PN/DP' | 'CPU 1515SP PC' | 'CORE-PLC-V3';
  status: 'GESTOPPT' | 'RUN' | 'SIMULATION' | 'FEHLER';
  variablen: SPSVariable[];
  bausteine: Funktionsbaustein[];
  hardwareModule: {
    steckplatz: number;
    modulTyp: string;
    bezeichnung: string;
    ipAdresse?: string;
    status: 'OK' | 'FEHLER';
  }[];
}

// --- 5. ALARM MANAGEMENT ---
export type AlarmPrioritaet = 'KRITISCH' | 'HOCH' | 'MITTEL' | 'NIEDRIG';
export type AlarmStatus = 'NORMAL' | 'AKTIV' | 'QUITTIERUNG_ERFORDERLICH' | 'QUITTIERT' | 'WIEDERHERGESTELLT';

export interface AlarmEintrag {
  alarmId: string;
  zeitstempel: string;
  anlage: string;
  komponente: string;
  prioritaet: AlarmPrioritaet;
  status: AlarmStatus;
  ursache: string;
  beschreibung: string;
  quittierungsStatus: boolean;
  quittiertVonBenutzer?: string;
  quittiertZeitstempel?: string;
  wiederherstellungszeit?: string;
  gruppe: 'SICHERHEIT' | 'PROZESS' | 'HARDWARE' | 'NETZWERK' | 'ENERGIE';
}

// --- 6. HISTORIAN & ZEITREIHEN ---
export interface ZeitreihenDatenpunkt {
  zeitstempel: string;
  msTimestamp: number;
  variablenId: string;
  messwert: number;
  einheit: string;
  qualitaet: 'GUT' | 'SCHLECHT' | 'SIMULIERT';
}

// --- 7. INDUSTRIAL EDGE ---
export interface EdgeApplikation {
  appId: string;
  name: string;
  version: string;
  status: 'LAEUFT' | 'GESTOPPT' | 'FEHLER' | 'AKTUALISIERUNG';
  cpuNutzungProzent: number;
  speicherMB: number;
  dockerContainerId: string;
}

export interface EdgeGeraet {
  geraetId: string;
  name: string;
  ipAdresse: string;
  standort: string;
  status: 'ONLINE' | 'OFFLINE' | 'WARNUNG';
  firmwareVersion: string;
  cpuAuslastungProzent: number;
  ramAuslastungProzent: number;
  speicherAuslastungProzent: number;
  applikationen: EdgeApplikation[];
  letzterKontakt: string;
}

// --- 8. CYBERSECURITY & BENUTZER ---
export type BenutzerRolle = 
  | 'ADMINISTRATOR'
  | 'ENGINEER'
  | 'BETRIEBSLEITER'
  | 'INBETRIEBNEHMER'
  | 'INSTANDHALTER'
  | 'BEDIENER'
  | 'AUDITOR';

export interface BenutzerProfil {
  id: string;
  benutzername: string;
  vollerName: string;
  email: string;
  rolle: BenutzerRolle;
  mfaAktiv: boolean;
  netzwerkZone: 'OT_SICHER' | 'OT_PFLANZ' | 'IT_VERWALTUNG';
  letzterLogin: string;
  zertifikatStatus: 'GUELTIG' | 'ABGELAUFEN' | 'WIRING';
}

export interface AuditLogEintrag {
  id: string;
  zeit: string;
  benutzer: string;
  rolle: BenutzerRolle;
  system: string;
  aktion: string;
  objekt: string;
  vorherigerZustand: string;
  neuerZustand: string;
  ergebnis: 'ERFOLG' | 'FEHLER' | 'ABGELEHNT';
  ipClient: string;
}

// --- 9. ENERGIE & ANALYTICS ---
export interface EnergieMetriken {
  elektrischeLeistungKW: number;
  spannungV: number;
  stromA: number;
  gesamtVerbrauchKWh: number;
  druckluftBar: number;
  waermeKWh: number;
  spitzenlastKW: number;
  grundlastKW: number;
  kwhProStueck: number;
}

export interface OEEMetriken {
  oeeProzent: number;
  verfuegbarkeitProzent: number;
  leistungProzent: number;
  qualitaetProzent: number;
  mtbfStunden: number;
  mttrMinuten: number;
  ausschussQuoteProzent: number;
  stillstandszeitMinuten: number;
  durchsatzStueckProStunde: number;
}

// --- 10. JULIA OPTIMIERUNG & PRÄDIKTIVE WARTUNG ---
export interface OptimizationVorschlag {
  id: string;
  ziel: 'Produktionsdurchsatz' | 'Energieverbrauch' | 'Maschinenlaufzeit' | 'Wartungsfenster';
  aktuellerWert: string;
  optimierterWert: string;
  einsparungPotenzial: string;
  empfehlungText: string;
  konfidenzProzent: number;
  status: 'VORGESCHLAGEN' | 'GEPRUEFT' | 'UMGESETZT' | 'VERWORFEN';
}

// --- 11. PLUGIN SYSTEM ---
export interface PluginManifest {
  pluginId: string;
  name: string;
  version: string;
  apiVersion: string;
  typ: 'SCADA_PLUGIN' | 'ENERGIE_PLUGIN' | 'ROBOTER_PLUGIN' | 'VISION_PLUGIN' | 'ANALYTICS_PLUGIN' | 'WARTUNG_PLUGIN';
  berechtigungen: string[];
  status: 'AKTIV' | 'INAKTIV' | 'FEHLER';
  healthCheck: 'HEALTHY' | 'UNHEALTHY';
  beschreibung: string;
}

// --- 12. FEHLERMODELL (KEINE STILLEN FEHLER) ---
export interface CoreSystemFehler {
  fehlerCode: string; // z.B. "IC-RT-1042"
  kategorie: 'Echtzeit-Laufzeit' | 'SPS-Steuerung' | 'Netzwerk' | 'Sicherheit' | 'Datenbank' | 'Hardware';
  schweregrad: 'INFO' | 'WARNUNG' | 'FEHLER' | 'KRITISCH';
  zeitstempel: string;
  komponente: string;
  meldung: string;
  technischeUrsache: string;
  benutzerHinweis: string;
  diagnoseId: string;
}
