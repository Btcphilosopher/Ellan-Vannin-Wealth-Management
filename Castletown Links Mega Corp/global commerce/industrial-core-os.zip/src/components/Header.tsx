/**
 * INDUSTRIAL CORE OS - Hauptheader & Statusleiste
 * Bietet Systemstatus (GRÜN/GELB/ROT), SPS-Laufzeitanzeige, Not-Aus, Benutzerwechsel und Audit-Anzeiger.
 */

import React, { useState, useEffect } from 'react';
import {
  Shield,
  Activity,
  AlertTriangle,
  Zap,
  User,
  Power,
  Clock,
  Cpu,
  CheckCircle,
  XCircle,
  FileText,
  RefreshCw,
  Bell,
} from 'lucide-react';
import { plcEngine } from '../core/PLCEngine';
import { securityEngine } from '../core/SecurityEngine';
import { alarmEngine } from '../core/AlarmEngine';
import { BenutzerProfil } from '../types/industrial';

interface HeaderProps {
  onOpenAuditLog: () => void;
  onNotAusTriggered: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenAuditLog, onNotAusTriggered }) => {
  const [spsStatus, setSpsStatus] = useState<'RUN' | 'GESTOPPT' | 'FEHLER'>('RUN');
  const [cycleMs, setCycleMs] = useState(10.1);
  const [jitterMs, setJitterMs] = useState(0.24);
  const [aktiverBenutzer, setAktiverBenutzer] = useState<BenutzerProfil>(
    securityEngine.getAktuellerBenutzer()
  );
  const [mussBenutzerModalOffen, setMussBenutzerModalOffen] = useState(false);
  const [aktiveAlarme, setAktiveAlarme] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      const prj = plcEngine.getProjekt();
      setSpsStatus(prj.status === 'RUN' ? 'RUN' : 'GESTOPPT');
      const ob1 = plcEngine.getTaskMetriken().find((t) => t.id === 'TASK-OB1');
      if (ob1) {
        setCycleMs(ob1.istZykluszeitMs);
        setJitterMs(ob1.jitterMs);
      }
      setAktiverBenutzer(securityEngine.getAktuellerBenutzer());
      const alarme = alarmEngine.getAlarme().filter((a) => !a.quittierungsStatus);
      setAktiveAlarme(alarme.length);
    }, 500);

    return () => clearInterval(interval);
  }, []);

  // System-Gesamtzustand Farbkodierung
  // GRÜN = Normalbetrieb, GELB = Warnung, ROT = Störung
  let systemStatusFarbe = 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
  let systemStatusLabel = 'NORMALBETRIEB';

  if (aktiveAlarme > 0) {
    systemStatusFarbe = 'bg-amber-500/20 text-amber-400 border-amber-500/30';
    systemStatusLabel = `${aktiveAlarme} ALARME AKTIV`;
  }
  if (spsStatus === 'GESTOPPT') {
    systemStatusFarbe = 'bg-rose-500/20 text-rose-400 border-rose-500/30';
    systemStatusLabel = 'STEUERUNG GESTOPPT';
  }

  return (
    <header className="bg-slate-900 border-b border-slate-800 px-4 py-2 text-slate-100 flex flex-wrap items-center justify-between gap-3 text-xs">
      {/* Brand & System Status */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded bg-blue-600 flex items-center justify-center font-bold text-white shadow-inner">
            IC
          </div>
          <div>
            <div className="font-bold tracking-wider text-slate-100 uppercase text-sm">
              INDUSTRIAL CORE OS
            </div>
            <div className="text-[10px] text-slate-400 font-mono">v2.4.0-PROD | CPU 1518-4 PN/DP</div>
          </div>
        </div>

        {/* Status Indikator Badge */}
        <div className={`px-2.5 py-1 rounded border flex items-center gap-1.5 font-semibold text-[11px] ${systemStatusFarbe}`}>
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-current opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-current"></span>
          </span>
          {systemStatusLabel}
        </div>
      </div>

      {/* SPS Real-Time Telemetry Metrics */}
      <div className="hidden lg:flex items-center gap-6 bg-slate-950/60 px-3 py-1.5 rounded border border-slate-800/80 font-mono text-[11px]">
        <div className="flex items-center gap-1.5 text-slate-300">
          <Activity className="w-3.5 h-3.5 text-blue-400" />
          <span>SPS Status:</span>
          <span className={spsStatus === 'RUN' ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
            {spsStatus}
          </span>
        </div>
        <div className="w-px h-3 bg-slate-800" />
        <div className="flex items-center gap-1.5 text-slate-300">
          <Clock className="w-3.5 h-3.5 text-amber-400" />
          <span>OB1 Zyklus:</span>
          <span className="text-slate-100 font-bold">{cycleMs.toFixed(2)} ms</span>
        </div>
        <div className="w-px h-3 bg-slate-800" />
        <div className="flex items-center gap-1.5 text-slate-300">
          <Cpu className="w-3.5 h-3.5 text-purple-400" />
          <span>Jitter:</span>
          <span className="text-slate-100 font-bold">±{jitterMs.toFixed(3)} ms</span>
        </div>
      </div>

      {/* Action Buttons & Active User */}
      <div className="flex items-center gap-2">
        {/* User Badge & Switcher */}
        <button
          onClick={() => setMussBenutzerModalOffen(true)}
          className="flex items-center gap-2 bg-slate-800 hover:bg-slate-700 text-slate-200 px-2.5 py-1.5 rounded border border-slate-700 transition"
          title="Benutzer wechseln / Rollen"
        >
          <User className="w-3.5 h-3.5 text-blue-400" />
          <span className="font-medium text-[11px]">{aktiverBenutzer.vollerName}</span>
          <span className="bg-blue-900/60 text-blue-300 px-1.5 py-0.5 rounded text-[9px] font-mono border border-blue-700/50">
            {aktiverBenutzer.rolle}
          </span>
        </button>

        {/* Audit Log Drawer Trigger */}
        <button
          onClick={onOpenAuditLog}
          className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 px-2.5 py-1.5 rounded border border-slate-700 transition"
          title="Audit Log öffnen"
        >
          <FileText className="w-3.5 h-3.5 text-slate-400" />
          <span className="hidden sm:inline text-[11px]">Audit Protocol</span>
        </button>

        {/* NOT-AUS Button */}
        <button
          onClick={onNotAusTriggered}
          className="flex items-center gap-1.5 bg-rose-600 hover:bg-rose-700 active:bg-rose-800 text-white font-bold px-3 py-1.5 rounded border border-rose-500 shadow-md transition tracking-wider uppercase text-[11px]"
          title="NOT-AUS SOFORTIGES ANHALTEN DER STEUERUNG"
        >
          <Power className="w-3.5 h-3.5" />
          <span>NOT-AUS</span>
        </button>
      </div>

      {/* Modal für Benutzerwechsel */}
      {mussBenutzerModalOffen && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-lg max-w-md w-full p-5 shadow-2xl text-slate-100">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
              <div className="flex items-center gap-2 font-bold text-sm">
                <Shield className="w-4 h-4 text-blue-400" />
                <span>Benutzer & Rolle auswählen</span>
              </div>
              <button
                onClick={() => setMussBenutzerModalOffen(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
              {securityEngine.getAlleBenutzer().map((u) => (
                <div
                  key={u.id}
                  onClick={() => {
                    securityEngine.wechsleBenutzer(u.id);
                    setAktiverBenutzer(securityEngine.getAktuellerBenutzer());
                    setMussBenutzerModalOffen(false);
                  }}
                  className={`p-3 rounded border cursor-pointer flex items-center justify-between transition ${
                    u.id === aktiverBenutzer.id
                      ? 'bg-blue-950/60 border-blue-500 text-white'
                      : 'bg-slate-800/60 border-slate-700/60 hover:bg-slate-800 text-slate-300'
                  }`}
                >
                  <div>
                    <div className="font-semibold text-xs">{u.vollerName}</div>
                    <div className="text-[10px] text-slate-400 font-mono">
                      {u.email} | Zone: {u.netzwerkZone}
                    </div>
                  </div>
                  <span className="bg-slate-900 px-2 py-0.5 rounded text-[10px] font-mono border border-slate-700 text-blue-400">
                    {u.rolle}
                  </span>
                </div>
              ))}
            </div>

            <div className="mt-4 pt-3 border-t border-slate-800 text-right">
              <button
                onClick={() => setMussBenutzerModalOffen(false)}
                className="bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded text-xs"
              >
                Schließen
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
