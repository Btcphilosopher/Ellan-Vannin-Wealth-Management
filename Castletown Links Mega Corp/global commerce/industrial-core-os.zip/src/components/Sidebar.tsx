/**
 * INDUSTRIAL CORE OS - Modul-Navigation (Sidebar)
 * Industrielle Navigation mit deutscher Terminologie und Informationsdichte.
 */

import React from 'react';
import {
  Cpu,
  Layers,
  PlaySquare,
  Box,
  Zap,
  Bell,
  LineChart,
  HardDrive,
  BarChart3,
  ShieldCheck,
  Plug,
} from 'lucide-react';

export type ModulSchluessel =
  | 'engineering'
  | 'scada'
  | 'production'
  | 'digital_twin'
  | 'energy'
  | 'alarms'
  | 'historian'
  | 'edge'
  | 'analytics'
  | 'security'
  | 'plugins';

interface SidebarProps {
  aktivesModul: ModulSchluessel;
  onSelectModul: (modul: ModulSchluessel) => void;
  aktiveAlarmeAnzahl: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  aktivesModul,
  onSelectModul,
  aktiveAlarmeAnzahl,
}) => {
  const moduleList: {
    schluessel: ModulSchluessel;
    titel: string;
    beschreibung: string;
    icon: React.FC<{ className?: string }>;
    badge?: number;
  }[] = [
    {
      schluessel: 'engineering',
      titel: 'Engineering Studio',
      beschreibung: 'SPS, HW-Konfigurator, Variablen',
      icon: Cpu,
    },
    {
      schluessel: 'scada',
      titel: 'Anlagenübersicht (SCADA)',
      beschreibung: 'Prozessbilder & Asset-Baum',
      icon: Layers,
    },
    {
      schluessel: 'production',
      titel: 'Produktion & SPS',
      beschreibung: 'OB1 Zyklus, Task-Klassen, I/O Force',
      icon: PlaySquare,
    },
    {
      schluessel: 'digital_twin',
      titel: 'Digitaler Zwilling',
      beschreibung: 'Maschinenzustand & Sensorik',
      icon: Box,
    },
    {
      schluessel: 'energy',
      titel: 'Energieüberwachung',
      beschreibung: 'Leistung, kWh/Stück, Peak-Load',
      icon: Zap,
    },
    {
      schluessel: 'alarms',
      titel: 'Alarmmanagement',
      beschreibung: 'Prioritäten, Quittierung, Berichte',
      icon: Bell,
      badge: aktiveAlarmeAnzahl,
    },
    {
      schluessel: 'historian',
      titel: 'Historian & Trends',
      beschreibung: 'Zeitreihen & Downsampling',
      icon: LineChart,
    },
    {
      schluessel: 'edge',
      titel: 'Industrial Edge',
      beschreibung: 'Geräte, Container Apps & Deploy',
      icon: HardDrive,
    },
    {
      schluessel: 'analytics',
      titel: 'Analytics & Julia',
      beschreibung: 'OEE, MTBF, KI-Wartung, Vorschläge',
      icon: BarChart3,
    },
    {
      schluessel: 'security',
      titel: 'Cybersecurity & Audit',
      beschreibung: 'RBAC, Zertifikate, Audit Protocol',
      icon: ShieldCheck,
    },
    {
      schluessel: 'plugins',
      titel: 'Plugins & Diagnose',
      beschreibung: 'Schnittstellen & Fehlercodes',
      icon: Plug,
    },
  ];

  return (
    <aside className="w-64 bg-slate-900 border-r border-slate-800 text-slate-300 flex flex-col shrink-0">
      <div className="p-3 border-b border-slate-800 text-[11px] font-semibold text-slate-400 tracking-wider uppercase">
        INDUSTRIE-MODULE
      </div>

      <nav className="flex-1 overflow-y-auto p-2 space-y-1">
        {moduleList.map((m) => {
          const IconComponent = m.icon;
          const isAktiv = aktivesModul === m.schluessel;

          return (
            <button
              key={m.schluessel}
              onClick={() => onSelectModul(m.schluessel)}
              className={`w-full text-left px-3 py-2.5 rounded text-xs flex items-center justify-between transition group ${
                isAktiv
                  ? 'bg-blue-600/20 text-blue-300 border border-blue-500/40 font-semibold shadow-inner'
                  : 'hover:bg-slate-800/80 text-slate-300 hover:text-white border border-transparent'
              }`}
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <IconComponent
                  className={`w-4 h-4 shrink-0 ${
                    isAktiv ? 'text-blue-400' : 'text-slate-400 group-hover:text-slate-200'
                  }`}
                />
                <div className="truncate">
                  <div className="truncate font-medium">{m.titel}</div>
                  <div className="text-[10px] text-slate-500 truncate font-mono">
                    {m.beschreibung}
                  </div>
                </div>
              </div>

              {m.badge !== undefined && m.badge > 0 && (
                <span className="shrink-0 bg-amber-500 text-slate-950 font-bold px-1.5 py-0.5 rounded-full text-[10px] shadow">
                  {m.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Footer Info */}
      <div className="p-3 border-t border-slate-800 bg-slate-950/40 text-[10px] text-slate-500 font-mono">
        <div>OT/IT-Zonen-Status: ISOLIERT</div>
        <div>IP: 192.168.10.10 / PROFINET</div>
      </div>
    </aside>
  );
};
