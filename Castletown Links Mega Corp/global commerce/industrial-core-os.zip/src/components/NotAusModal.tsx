/**
 * INDUSTRIAL CORE OS - NOT-AUS Notfall-Modal
 * Ermöglicht den sofortigen STOPP der Steuerung und geführte Re-Initialisierung.
 */

import React from 'react';
import { AlertOctagon, RefreshCw, ShieldAlert } from 'lucide-react';
import { plcEngine } from '../core/PLCEngine';
import { securityEngine } from '../core/SecurityEngine';

interface NotAusModalProps {
  offen: boolean;
  onSchliessen: () => void;
}

export const NotAusModal: React.FC<NotAusModalProps> = ({ offen, onSchliessen }) => {
  if (!offen) return null;

  const handleQuittierenUndNeustart = () => {
    plcEngine.startEngine();
    securityEngine.registriereAuditEintrag(
      'SPS_RUNTIME',
      'NOT_AUS_QUITTIRT_RESTART',
      'CPU_1518',
      'GESTOPPT (NOT-AUS)',
      'RUN (NORMALBETRIEB)',
      'ERFOLG'
    );
    onSchliessen();
  };

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900 border-2 border-rose-600 rounded-lg max-w-lg w-full p-6 shadow-2xl text-slate-100 animate-in fade-in zoom-in duration-200">
        <div className="flex items-center gap-3 text-rose-500 mb-4 border-b border-slate-800 pb-3">
          <AlertOctagon className="w-10 h-10 animate-bounce" />
          <div>
            <h2 className="text-xl font-bold tracking-wider uppercase text-rose-500">
              NOT-AUS AUSGELÖST!
            </h2>
            <p className="text-xs text-rose-300 font-mono">
              SPS-STEUERUNG SOFORT GESTOPPT (SICHERER ZUSTAND)
            </p>
          </div>
        </div>

        <div className="bg-rose-950/40 border border-rose-800/80 rounded p-4 mb-5 text-xs space-y-2 text-rose-200">
          <p className="font-semibold">Sicherheitskreis-Status:</p>
          <ul className="list-disc list-inside space-y-1 text-[11px] font-mono text-slate-300">
            <li>SPS-Hauptprogramm (OB1): GESTOPPT</li>
            <li>Antriebe & Aktoren: STROMFREE GESCHALTET</li>
            <li>Digitale & Analoge Ausgänge: FORCIERT AUF NULL</li>
            <li>Safety-Task (Prio 1): AKTIV (Sicherheitsüberwachung)</li>
          </ul>
        </div>

        <p className="text-xs text-slate-300 mb-6">
          Prüfen Sie vor dem Wiederanlauf die physische Sicherheitszone der Anlage. 
          Das Quittieren erfordert eine ausdrückliche Ingenieursbestätigung.
        </p>

        <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
          <button
            onClick={onSchliessen}
            className="bg-slate-800 hover:bg-slate-700 text-slate-300 px-4 py-2 rounded text-xs font-medium border border-slate-700"
          >
            Im Stop-Zustand bleiben
          </button>
          <button
            onClick={handleQuittierenUndNeustart}
            className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-4 py-2 rounded text-xs border border-emerald-500 flex items-center gap-2 shadow-lg"
          >
            <RefreshCw className="w-4 h-4" />
            Sicherheit quittieren & Anlauf starten
          </button>
        </div>
      </div>
    </div>
  );
};
