/**
 * INDUSTRIAL CORE OS - Audit Protocol Side Drawer
 * Zeigt das unlöschbare Audit-Log in einem schnellen Seiten-Drawer.
 */

import React, { useState } from 'react';
import { FileText, X, Search, ShieldCheck } from 'lucide-react';
import { securityEngine } from '../core/SecurityEngine';
import { AuditLogEintrag } from '../types/industrial';

interface AuditDrawerProps {
  offen: boolean;
  onSchliessen: () => void;
}

export const AuditDrawer: React.FC<AuditDrawerProps> = ({ offen, onSchliessen }) => {
  const [filter, setFilter] = useState('');
  if (!offen) return null;

  const logs = securityEngine.getAuditLogs().filter(
    (l) =>
      l.benutzer.toLowerCase().includes(filter.toLowerCase()) ||
      l.aktion.toLowerCase().includes(filter.toLowerCase()) ||
      l.system.toLowerCase().includes(filter.toLowerCase())
  );

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex justify-end">
      <div className="w-full max-w-xl bg-slate-900 border-l border-slate-800 text-slate-100 p-5 flex flex-col gap-4 shadow-2xl animate-in slide-in-from-right duration-200">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2 font-bold text-sm">
            <FileText className="w-4 h-4 text-emerald-400" />
            <span>Audit Protocol Drawer (Revisionssicher)</span>
          </div>
          <button onClick={onSchliessen} className="text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="relative">
          <Search className="w-3.5 h-3.5 absolute left-2.5 top-2 text-slate-500" />
          <input
            type="text"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            placeholder="Protokoll filtern..."
            className="w-full bg-slate-950 border border-slate-800 rounded pl-8 pr-3 py-1.5 text-xs text-slate-200 font-mono"
          />
        </div>

        <div className="flex-1 overflow-y-auto space-y-2 pr-1 font-mono text-xs">
          {logs.map((log) => (
            <div key={log.id} className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
              <div className="flex justify-between text-[10px] text-slate-500">
                <span>{new Date(log.zeit).toLocaleTimeString()}</span>
                <span className="text-blue-400 font-bold">{log.system}</span>
              </div>
              <div className="font-bold text-amber-400 text-[11px]">{log.aktion}</div>
              <div className="text-slate-300 text-[10px]">
                Benutzer: <span className="text-slate-100 font-semibold">{log.benutzer}</span> ({log.rolle})
              </div>
              <div className="text-slate-400 text-[10px] border-t border-slate-800/80 pt-1 mt-1">
                {log.vorherigerZustand} &rarr; <span className="text-emerald-400 font-semibold">{log.neuerZustand}</span>
              </div>
            </div>
          ))}
        </div>

        <div className="border-t border-slate-800 pt-3 text-right">
          <button
            onClick={onSchliessen}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 px-4 py-1.5 rounded text-xs"
          >
            Schließen
          </button>
        </div>
      </div>
    </div>
  );
};
