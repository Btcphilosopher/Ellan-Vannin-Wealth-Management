/**
 * INDUSTRIAL CORE OS - Full-Stack Express Server Entry Point
 * Bietet versionierte REST APIs, Server-Sent Events (SSE) für Telemetrie und Vite Dev-Middleware.
 */

import express, { Request, Response } from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';

import { plcEngine } from './src/core/PLCEngine';
import { alarmEngine } from './src/core/AlarmEngine';
import { assetEngine } from './src/core/AssetEngine';
import { historianEngine } from './src/core/HistorianEngine';
import { edgeManagerEngine } from './src/core/EdgeManagerEngine';
import { analyticsEngine } from './src/core/AnalyticsEngine';
import { securityEngine } from './src/core/SecurityEngine';
import { pluginEngine } from './src/core/PluginEngine';
import { eventBus } from './src/core/EventBus';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // --- REST API REST-SCHICHT v1 ---

  // 1. Health & System-Status
  app.get('/api/v1/health', (req: Request, res: Response) => {
    res.json({
      status: 'HEALTHY',
      system: 'INDUSTRIAL CORE OS',
      version: 'v2.4.0-PROD',
      zeitstempel: new Date().toISOString(),
      spsStatus: plcEngine.getProjekt().status,
      taskMetriken: plcEngine.getTaskMetriken(),
      aktiverBenutzer: securityEngine.getAktuellerBenutzer().benutzername,
    });
  });

  // 2. Assets & Digitaler Zwilling
  app.get('/api/v1/assets', (req: Request, res: Response) => {
    res.json({
      hierarchie: assetEngine.getAnlagenHierarchie(),
      zwillinge: assetEngine.getAlleZwillinge(),
    });
  });

  app.get('/api/v1/assets/:id', (req: Request, res: Response) => {
    const zwilling = assetEngine.getDigitalenZwilling(req.params.id);
    if (!zwilling) {
      res.status(404).json({ fehler: `Asset '${req.params.id}' nicht gefunden.` });
      return;
    }
    res.json(zwilling);
  });

  // 3. Alarme
  app.get('/api/v1/alarms', (req: Request, res: Response) => {
    res.json(alarmEngine.getAlarme());
  });

  app.post('/api/v1/alarms/:id/acknowledge', (req: Request, res: Response) => {
    alarmEngine.quittiereAlarm(req.params.id);
    res.json({ erfolg: true, message: `Alarm ${req.params.id} erfolgreich quittiert.` });
  });

  // 4. Events & Bus
  app.get('/api/v1/events', (req: Request, res: Response) => {
    res.json(eventBus.getHistorie());
  });

  // 5. Metriken & SPS-Diagnose
  app.get('/api/v1/metrics', (req: Request, res: Response) => {
    res.json({
      taskMetriken: plcEngine.getTaskMetriken(),
      oee: analyticsEngine.getOEEMetriken(),
      fehler: plcEngine.getFehlerHistorie(),
    });
  });

  // 6. Energie
  app.get('/api/v1/energy', (req: Request, res: Response) => {
    res.json(analyticsEngine.getEnergieMetriken());
  });

  // 7. Benutzer & RBAC
  app.get('/api/v1/users', (req: Request, res: Response) => {
    res.json({
      aktuellerBenutzer: securityEngine.getAktuellerBenutzer(),
      alleBenutzer: securityEngine.getAlleBenutzer(),
    });
  });

  app.post('/api/v1/users/switch', (req: Request, res: Response) => {
    const { id } = req.body;
    securityEngine.wechsleBenutzer(id);
    res.json({ erfolg: true, neuerBenutzer: securityEngine.getAktuellerBenutzer() });
  });

  // 8. SPS-Projekt & Engineering
  app.get('/api/v1/projects', (req: Request, res: Response) => {
    res.json(plcEngine.getProjekt());
  });

  app.post('/api/v1/projects/variable', (req: Request, res: Response) => {
    const { adresse, wert } = req.body;
    plcEngine.setVariableWert(adresse, wert);
    securityEngine.registriereAuditEintrag(
      'ENGINEERING',
      'SPS_VARIABLE_GEAENDERT',
      adresse,
      '-',
      String(wert),
      'ERFOLG'
    );
    res.json({ erfolg: true });
  });

  app.post('/api/v1/projects/force', (req: Request, res: Response) => {
    const { adresse, forceWert } = req.body;
    plcEngine.toggleForceVariable(adresse, forceWert);
    securityEngine.registriereAuditEintrag(
      'ENGINEERING',
      'SPS_VARIABLE_FORCIERT_TOGGLE',
      adresse,
      '-',
      String(forceWert),
      'ERFOLG'
    );
    res.json({ erfolg: true });
  });

  // 9. Deployments & Industrial Edge
  app.get('/api/v1/deployments', (req: Request, res: Response) => {
    res.json(edgeManagerEngine.getGeraete());
  });

  app.post('/api/v1/deployments/control', (req: Request, res: Response) => {
    const { geraetId, appId, aktion } = req.body;
    edgeManagerEngine.steuereApplikation(geraetId, appId, aktion);
    securityEngine.registriereAuditEintrag(
      'INDUSTRIAL_EDGE',
      `APP_${aktion}`,
      `${geraetId} / ${appId}`,
      '-',
      aktion,
      'ERFOLG'
    );
    res.json({ erfolg: true });
  });

  // 10. Plugins
  app.get('/api/v1/plugins', (req: Request, res: Response) => {
    res.json(pluginEngine.getPlugins());
  });

  app.post('/api/v1/plugins/:id/toggle', (req: Request, res: Response) => {
    pluginEngine.togglePluginStatus(req.params.id);
    res.json({ erfolg: true });
  });

  // 11. Audit Logs
  app.get('/api/v1/audit-logs', (req: Request, res: Response) => {
    res.json(securityEngine.getAuditLogs());
  });

  // 12. Server-Sent Events (SSE) Live Telemetrie Stream
  app.get('/api/v1/stream', (req: Request, res: Response) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    const unsubscribe = eventBus.abonnieren('*', (event) => {
      res.write(`data: ${JSON.stringify(event)}\n\n`);
    });

    req.on('close', () => {
      unsubscribe();
    });
  });

  // --- VITE MIDDLEWARE FÜR FRONTEND ---
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[INDUSTRIAL CORE OS] Server läuft auf http://localhost:${PORT}`);
  });
}

startServer();
