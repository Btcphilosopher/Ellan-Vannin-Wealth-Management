package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.formatCentsToCurrency
import com.example.data.model.Transaction
import com.example.data.model.TransactionType
import com.example.data.model.TransactionStatus
import com.example.data.model.TransactionCategory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read app name from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Nubank", appName)
    }

    @Test
    fun `test money precision format cents`() {
        val amountInCents = 12543L // R$ 125,43
        val formatted = formatCentsToCurrency(amountInCents)
        // Check for presence of digits and currency characters
        assertTrue(formatted.contains("125"))
        assertTrue(formatted.contains("43"))
    }

    @Test
    fun `test transaction formatting incoming`() {
        val tx = Transaction(
            id = "test-tx-1",
            timestamp = System.currentTimeMillis(),
            type = TransactionType.SALARY,
            amount = 500000L, // R$ 5.000,00
            status = TransactionStatus.COMPLETED,
            description = "Salário",
            merchant = "Lojas S.A.",
            category = TransactionCategory.SALARY,
            isIncoming = true
        )
        val formatted = tx.formatAmount()
        assertTrue(formatted.startsWith("+"))
        assertTrue(formatted.contains("5.000"))
    }

    @Test
    fun `test transaction formatting outgoing`() {
        val tx = Transaction(
            id = "test-tx-2",
            timestamp = System.currentTimeMillis(),
            type = TransactionType.DEBIT_CARD,
            amount = 8990L, // R$ 89,90
            status = TransactionStatus.COMPLETED,
            description = "Uber",
            merchant = "Uber",
            category = TransactionCategory.TRANSPORT,
            isIncoming = false
        )
        val formatted = tx.formatAmount()
        assertTrue(formatted.startsWith("-"))
        assertTrue(formatted.contains("89"))
    }
}
