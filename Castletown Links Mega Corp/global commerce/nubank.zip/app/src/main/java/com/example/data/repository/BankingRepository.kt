package com.example.data.repository

import android.content.Context
import androidx.room.Room
import com.example.data.local.AccountStateEntity
import com.example.data.local.BankingDao
import com.example.data.local.BankingDatabase
import com.example.data.local.CardEntity
import com.example.data.local.NotificationEntity
import com.example.data.local.TransactionEntity
import com.example.data.model.Card
import com.example.data.model.CustomerProfile
import com.example.data.model.InvestmentState
import com.example.data.model.LoanState
import com.example.data.model.Notification
import com.example.data.model.NotificationCategory
import com.example.data.model.Transaction
import com.example.data.model.TransactionCategory
import com.example.data.model.TransactionStatus
import com.example.data.model.TransactionType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.map
import java.util.UUID

class BankingRepository(private val context: Context) {

    private val db: BankingDatabase by lazy {
        Room.databaseBuilder(
            context.applicationContext,
            BankingDatabase::class.java,
            "nubank_banking_database"
        ).build()
    }

    private val dao: BankingDao by lazy { db.bankingDao() }

    // Read Flows
    val customerFlow: Flow<CustomerProfile> = dao.getAccountStateFlow().map { state ->
        state?.let {
            CustomerProfile(
                name = it.customerName,
                cpf = it.cpf,
                agency = it.agency,
                accountNumber = it.accountNumber,
                isBiometricsEnabled = it.isBiometricsEnabled,
                isLogged = it.isLogged
            )
        } ?: CustomerProfile(isLogged = false)
    }

    val balanceFlow: Flow<Long> = dao.getAccountStateFlow().map { it?.balance ?: 0L }
    
    val creditLimitFlow: Flow<Long> = dao.getAccountStateFlow().map { it?.creditLimit ?: 0L }
    val creditUsedFlow: Flow<Long> = dao.getAccountStateFlow().map { it?.creditUsed ?: 0L }
    val currentInvoiceFlow: Flow<Long> = dao.getAccountStateFlow().map { it?.currentInvoice ?: 0L }

    val investmentFlow: Flow<InvestmentState> = dao.getAccountStateFlow().map { state ->
        state?.let {
            InvestmentState(
                fixedIncome = it.investFixedIncome,
                funds = it.investFunds,
                treasury = it.investTreasury,
                stocks = it.investStocks,
                monthlyReturn = it.investMonthlyReturn,
                accumulatedReturn = it.investAccumulatedReturn
            )
        } ?: InvestmentState()
    }

    val loanFlow: Flow<LoanState> = dao.getAccountStateFlow().map { state ->
        state?.let {
            LoanState(
                requestedAmount = it.loanRequestedAmount,
                installments = it.loanInstallments,
                interestRate = it.loanInterestRate,
                totalCost = it.loanTotalCost,
                status = it.loanStatus
            )
        } ?: LoanState()
    }

    val transactionsFlow: Flow<List<Transaction>> = dao.getTransactionsFlow().map { list ->
        list.map {
            Transaction(
                id = it.id,
                timestamp = it.timestamp,
                type = it.type,
                amount = it.amount,
                status = it.status,
                description = it.description,
                merchant = it.merchant,
                category = it.category,
                isIncoming = it.isIncoming,
                details = it.details
            )
        }
    }

    val cardsFlow: Flow<List<Card>> = dao.getCardsFlow().map { list ->
        list.map {
            Card(
                id = it.id,
                type = it.type,
                number = it.number,
                expiry = it.expiry,
                cvv = it.cvv,
                status = it.status,
                isContactlessEnabled = it.isContactlessEnabled,
                cardholder = it.cardholder
            )
        }
    }

    val notificationsFlow: Flow<List<Notification>> = dao.getNotificationsFlow().map { list ->
        list.map {
            Notification(
                id = it.id,
                title = it.title,
                message = it.message,
                timestamp = it.timestamp,
                category = it.category,
                linkedTransactionId = it.linkedTransactionId,
                isRead = it.isRead
            )
        }
    }

    // Checking if DB needs seeding and performing it
    suspend fun checkAndSeedDatabase() {
        val state = dao.getAccountState()
        if (state == null) {
            seedInitialData()
        }
    }

    private suspend fun seedInitialData() {
        val now = System.currentTimeMillis()
        val oneHourAgo = now - 3600000
        val yesterday = now - 86400000
        val twoDaysAgo = now - 172800000
        val threeDaysAgo = now - 259200000

        // 1. Account State Seed
        val initialState = AccountStateEntity(
            id = 1,
            balance = 482736L, // R$ 4.827,36
            creditLimit = 800000L, // R$ 8.000,00 total limit
            creditUsed = 415783L, // R$ 4.157,83 used (leaves R$ 3.842,17 available)
            currentInvoice = 143872L, // R$ 1.438,72 current invoice
            
            // Loan fields (simulated default, not active)
            loanRequestedAmount = 500000L, // R$ 5.000,00
            loanInstallments = 12,
            loanInterestRate = 4.85,
            loanTotalCost = 675000L, // total with interest
            loanStatus = "NONE",

            // Investment fields
            investFixedIncome = 1000000L, // R$ 10.000,00
            investFunds = 400000L, // R$ 4.000,00
            investTreasury = 300000L, // R$ 3.000,00
            investStocks = 147283L, // R$ 1.472,83
            investMonthlyReturn = 18342L, // R$ 183,42
            investAccumulatedReturn = 128462L, // R$ 1.284,62

            customerName = "João Martins",
            cpf = "384.921.408-42",
            agency = "0001",
            accountNumber = "194827-3",
            isBiometricsEnabled = true,
            isLogged = false // user starts on login screen
        )
        dao.insertAccountState(initialState)

        // 2. Transactions Seed
        val initialTransactions = listOf(
            TransactionEntity(
                id = UUID.randomUUID().toString(),
                timestamp = now,
                type = TransactionType.DEBIT_CARD,
                amount = 12648L, // R$ 126,48
                status = TransactionStatus.COMPLETED,
                description = "Supermercado Central",
                merchant = "Supermercado Central",
                category = TransactionCategory.FOOD,
                isIncoming = false,
                details = "Compra no débito autorizada usando cartão físico com chip."
            ),
            TransactionEntity(
                id = UUID.randomUUID().toString(),
                timestamp = oneHourAgo,
                type = TransactionType.SALARY,
                amount = 520000L, // R$ 5.200,00
                status = TransactionStatus.COMPLETED,
                description = "Pagamento Salário",
                merchant = "Lojas Associadas S.A.",
                category = TransactionCategory.SALARY,
                isIncoming = true,
                details = "Transferência recebida via TED de Lojas Associadas S.A."
            ),
            TransactionEntity(
                id = UUID.randomUUID().toString(),
                timestamp = yesterday,
                type = TransactionType.PIX_RECEIVED,
                amount = 18000L, // R$ 180,00
                status = TransactionStatus.COMPLETED,
                description = "Pix de Roberta Santos",
                merchant = "Roberta Santos",
                category = TransactionCategory.OTHERS,
                isIncoming = true,
                details = "Pix recebido instantaneamente de Roberta Santos. Chave celular."
            ),
            TransactionEntity(
                id = UUID.randomUUID().toString(),
                timestamp = yesterday - 100000,
                type = TransactionType.CREDIT_CARD,
                amount = 3240L, // R$ 32,40
                status = TransactionStatus.COMPLETED,
                description = "Uber Tripp",
                merchant = "Uber",
                category = TransactionCategory.TRANSPORT,
                isIncoming = false,
                details = "Compra no cartão de crédito virtual final 4287."
            ),
            TransactionEntity(
                id = UUID.randomUUID().toString(),
                timestamp = twoDaysAgo,
                type = TransactionType.CREDIT_CARD,
                amount = 5590L, // R$ 55,90
                status = TransactionStatus.COMPLETED,
                description = "Netflix Premium",
                merchant = "Netflix",
                category = TransactionCategory.LEISURE,
                isIncoming = false,
                details = "Compra recorrente mensal no cartão de crédito virtual final 4287."
            ),
            TransactionEntity(
                id = UUID.randomUUID().toString(),
                timestamp = threeDaysAgo,
                type = TransactionType.CREDIT_CARD,
                amount = 14800L, // R$ 148,00
                status = TransactionStatus.COMPLETED,
                description = "Pizzaria Bela Napoli",
                merchant = "Pizzaria Napoli",
                category = TransactionCategory.FOOD,
                isIncoming = false,
                details = "Compra no cartão de crédito físico final 9015."
            )
        )
        dao.insertTransactions(initialTransactions)

        // 3. Cards Seed
        val initialCards = listOf(
            CardEntity(
                id = "physical_card_id",
                type = "PHYSICAL",
                number = "•••• •••• •••• 9015",
                expiry = "09/30",
                cvv = "•••",
                status = "ACTIVE",
                isContactlessEnabled = true,
                cardholder = "JOAO MARTINS"
            ),
            CardEntity(
                id = "virtual_card_id",
                type = "VIRTUAL",
                number = "•••• •••• •••• 4287",
                expiry = "12/32",
                cvv = "398",
                status = "ACTIVE",
                isContactlessEnabled = true,
                cardholder = "JOAO MARTINS"
            )
        )
        dao.insertCards(initialCards)

        // 4. Notifications Seed
        val initialNotifications = listOf(
            NotificationEntity(
                id = UUID.randomUUID().toString(),
                title = "Compra aprovada",
                message = "Compra no valor de R$ 126,48 no Supermercado Central realizada no débito.",
                timestamp = now,
                category = NotificationCategory.TRANSACTION,
                linkedTransactionId = null,
                isRead = false
            ),
            NotificationEntity(
                id = UUID.randomUUID().toString(),
                title = "Salário recebido",
                message = "Seu salário de R$ 5.200,00 já está disponível na sua conta.",
                timestamp = oneHourAgo,
                category = NotificationCategory.ACCOUNT,
                linkedTransactionId = null,
                isRead = false
            ),
            NotificationEntity(
                id = UUID.randomUUID().toString(),
                title = "Fatura aberta",
                message = "Sua fatura com vencimento em 10 de Outubro está disponível: R$ 1.438,72.",
                timestamp = yesterday,
                category = NotificationCategory.CARD,
                linkedTransactionId = null,
                isRead = false
            ),
            NotificationEntity(
                id = UUID.randomUUID().toString(),
                title = "Acesso seguro",
                message = "Seu dispositivo foi registrado com sucesso como dispositivo seguro.",
                timestamp = threeDaysAgo,
                category = NotificationCategory.SECURITY,
                linkedTransactionId = null,
                isRead = true
            )
        )
        dao.insertNotifications(initialNotifications)
    }

    // Operations called by simulation engine
    suspend fun saveAccountState(entity: AccountStateEntity) {
        dao.insertAccountState(entity)
    }

    suspend fun getAccountState(): AccountStateEntity? {
        return dao.getAccountState()
    }

    suspend fun saveTransaction(tx: TransactionEntity) {
        dao.insertTransaction(tx)
    }

    suspend fun saveNotification(notif: NotificationEntity) {
        dao.insertNotification(notif)
    }

    suspend fun setCardStatus(cardId: String, status: String) {
        dao.updateCardStatus(cardId, status)
    }

    suspend fun markNotificationAsRead(id: String) {
        dao.markNotificationRead(id)
    }

    suspend fun performReset() {
        dao.clearTransactions()
        dao.clearCards()
        dao.clearNotifications()
        seedInitialData()
    }
}
