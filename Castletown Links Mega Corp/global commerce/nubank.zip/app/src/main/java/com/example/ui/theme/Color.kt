package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Nubank Brand Colors
val NuPurple = Color(0xFF830AD1)
val NuPurpleLight = Color(0xFF9B32E1)
val NuPurpleDark = Color(0xFF5E049B)
val NuPurpleBg = Color(0xFF1E013A)

// Neutrals Light
val BgLight = Color(0xFFF5F6FA)
val SurfaceLight = Color(0xFFFFFFFF)
val OnBgLight = Color(0xFF111111)
val OnSurfaceLight = Color(0xFF191919)
val GrayTextLight = Color(0xFF76757A)
val BorderLight = Color(0xFFE2E4EB)

// Neutrals Dark
val BgDark = Color(0xFF0F0E13)
val SurfaceDark = Color(0xFF1A191E)
val OnBgDark = Color(0xFFF5F6FA)
val OnSurfaceDark = Color(0xFFFFFFFF)
val GrayTextDark = Color(0xFF9E9DA3)
val BorderDark = Color(0xFF2E2D33)

// Semantic Accents
val NuGreen = Color(0xFF00875A) // Balance increase, success
val NuGreenLight = Color(0xFF249D44)
val NuRed = Color(0xFFD32F2F) // Credit invoice, warnings
val NuBlue = Color(0xFF0099FF) // Informational/Virtual card accent
val ShimmerGray = Color(0xFFE1E1E1)
