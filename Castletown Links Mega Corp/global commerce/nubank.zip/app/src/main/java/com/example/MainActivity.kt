package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.foundation.BorderStroke
import androidx.compose.material3.OutlinedButton
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.components.NuButton
import com.example.ui.components.NuOutlineButton
import com.example.ui.screens.AccountScreen
import com.example.ui.screens.CardsScreen
import com.example.ui.screens.HelpChatScreen
import com.example.ui.screens.HelpScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.InvestmentsScreen
import com.example.ui.screens.InvoiceScreen
import com.example.ui.screens.LoansConfirmScreen
import com.example.ui.screens.LoansScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.NotificationsScreen
import com.example.ui.screens.PaymentsConfirmScreen
import com.example.ui.screens.PaymentsScreen
import com.example.ui.screens.PaymentsSuccessScreen
import com.example.ui.screens.PixReceiveAmountScreen
import com.example.ui.screens.PixReceiveCodeScreen
import com.example.ui.screens.PixScreen
import com.example.ui.screens.PixSendAmountScreen
import com.example.ui.screens.PixSendConfirmScreen
import com.example.ui.screens.PixSendSuccessScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.SecurityScreen
import com.example.ui.screens.SpendingAnalyticsScreen
import com.example.ui.screens.TransactionDetailScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NuPurple
import com.example.ui.theme.NuPurpleBg
import com.example.ui.theme.NuRed
import com.example.ui.viewmodel.BankingViewModel
import com.example.ui.viewmodel.Screen

class MainActivity : ComponentActivity() {

    private val viewModel: BankingViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val currentScreen by viewModel.currentScreen.collectAsState()
                val fraudMerchant by viewModel.showFraudDialog.collectAsState()

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = MaterialTheme.colorScheme.background
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(bottom = innerPadding.calculateBottomPadding())
                    ) {
                        // Main Navigation Switch Router
                        when (currentScreen) {
                            Screen.LOGIN -> LoginScreen(viewModel)
                            Screen.HOME -> HomeScreen(viewModel)
                            Screen.ACCOUNT -> AccountScreen(viewModel)
                            Screen.TRANSACTION_DETAIL -> TransactionDetailScreen(viewModel)
                            Screen.PIX -> PixScreen(viewModel)
                            Screen.PIX_SEND_AMOUNT -> PixSendAmountScreen(viewModel)
                            Screen.PIX_SEND_CONFIRM -> PixSendConfirmScreen(viewModel)
                            Screen.PIX_SEND_SUCCESS -> PixSendSuccessScreen(viewModel)
                            Screen.PIX_RECEIVE_AMOUNT -> PixReceiveAmountScreen(viewModel)
                            Screen.PIX_RECEIVE_CODE -> PixReceiveCodeScreen(viewModel)
                            Screen.PAYMENTS -> PaymentsScreen(viewModel)
                            Screen.PAYMENTS_CONFIRM -> PaymentsConfirmScreen(viewModel)
                            Screen.PAYMENTS_SUCCESS -> PaymentsSuccessScreen(viewModel)
                            Screen.CARDS -> CardsScreen(viewModel)
                            Screen.INVOICE -> InvoiceScreen(viewModel)
                            Screen.SPENDING_ANALYTICS -> SpendingAnalyticsScreen(viewModel)
                            Screen.INVESTMENTS -> InvestmentsScreen(viewModel)
                            Screen.LOANS -> LoansScreen(viewModel)
                            Screen.LOANS_CONFIRM -> LoansConfirmScreen(viewModel)
                            Screen.NOTIFICATIONS -> NotificationsScreen(viewModel)
                            Screen.SECURITY -> SecurityScreen(viewModel)
                            Screen.HELP -> HelpScreen(viewModel)
                            Screen.HELP_CHAT -> HelpChatScreen(viewModel)
                            Screen.PROFILE -> ProfileScreen(viewModel)
                            else -> LoginScreen(viewModel)
                        }

                        // Custom Fraud / Unusual Activity Security Alert Simulation
                        fraudMerchant?.let { merchant ->
                            SecurityFraudSimulationDialog(
                                merchant = merchant,
                                onConfirm = { viewModel.confirmFraudPurchase(true) },
                                onDecline = { viewModel.confirmFraudPurchase(false) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SecurityFraudSimulationDialog(
    merchant: String,
    onConfirm: () -> Unit,
    onDecline: () -> Unit
) {
    Dialog(onDismissRequest = { /* Force explicit customer answer */ }) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Warning Alert Visual
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(NuRed.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Alerta de Segurança",
                        tint = NuRed,
                        modifier = Modifier.size(28.dp)
                    )
                }

                Text(
                    text = "Aviso de Segurança",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Center
                )

                Text(
                    text = "Detectamos uma tentativa de compra incomum de R$ 1.550,00 no estabelecimento '$merchant'. Foi você quem realizou esta transação?",
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    lineHeight = 20.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onConfirm,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = NuPurple)
                    ) {
                        Text(text = "Sim, fui eu (Autorizar)", fontWeight = FontWeight.Bold, color = Color.White)
                    }

                    OutlinedButton(
                        onClick = onDecline,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = NuRed),
                        border = BorderStroke(1.dp, SolidColor(NuRed))
                    ) {
                        Text(text = "Não reconheço (Bloquear Cartão)", fontWeight = FontWeight.Bold, color = NuRed)
                    }
                }
            }
        }
    }
}
