package com.example.data.model

import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Transaction Type Enums
object TransactionType {
    const val PIX_SENT = "PIX_SENT"
    const val PIX_RECEIVED = "PIX_RECEIVED"
    const val DEBIT_CARD = "DEBIT_CARD"
    const val CREDIT_CARD = "CREDIT_CARD"
    const val TRANSFER_SENT = "TRANSFER_SENT"
    const val TRANSFER_RECEIVED = "TRANSFER_RECEIVED"
    const val BOLETO_PAYMENT = "BOLETO_PAYMENT"
    const val SALARY = "SALARY"
    const val DEPOSIT = "DEPOSIT"
}

// Transaction Status Enums
object TransactionStatus {
    const val PENDING = "PENDING"
    const val AUTHORIZED = "AUTHORIZED"
    const val COMPLETED = "COMPLETED"
    const val FAILED = "FAILED"
    const val REVERSED = "REVERSED"
    const val CANCELLED = "CANCELLED"
}

// Transaction Categories
object TransactionCategory {
    const val FOOD = "Alimentação"
    const val TRANSPORT = "Transporte"
    const val HOME = "Casa"
    const val LEISURE = "Lazer"
    const val SHOPPING = "Compras"
    const val SALARY = "Salário"
    const val REVENUE = "Rendimentos"
    const val OTHERS = "Outros"
}

// Notification Categories
object NotificationCategory {
    const val SECURITY = "Segurança"
    const val TRANSACTION = "Transações"
    const val CARD = "Cartão"
    const val ACCOUNT = "Conta"
    const val OFFER = "Ofertas"
}

// Core Domain Models
data class Transaction(
    val id: String,
    val timestamp: Long,
    val type: String,
    val amount: Long, // represented in integer cents
    val status: String,
    val description: String,
    val merchant: String,
    val category: String,
    val isIncoming: Boolean,
    val details: String = ""
) {
    fun formatAmount(): String {
        val amountDouble = amount.toDouble() / 100.0
        val formatter = NumberFormat.getCurrencyInstance(Locale("pt", "BR"))
        val formatted = formatter.format(amountDouble)
        return (if (isIncoming) "+" else "-") + " " + formatted
    }

    fun formatRawAmount(): String {
        val amountDouble = amount.toDouble() / 100.0
        val formatter = NumberFormat.getCurrencyInstance(Locale("pt", "BR"))
        return formatter.format(amountDouble)
    }

    fun formatDate(): String {
        val sdf = SimpleDateFormat("dd MMM yyyy", Locale("pt", "BR"))
        return sdf.format(Date(timestamp))
    }

    fun formatTime(): String {
        val sdf = SimpleDateFormat("HH:mm", Locale("pt", "BR"))
        return sdf.format(Date(timestamp))
    }
}

data class Card(
    val id: String,
    val type: String, // "PHYSICAL", "VIRTUAL"
    val number: String,
    val expiry: String,
    val cvv: String,
    val status: String, // "ACTIVE", "BLOCKED", "PROCESSING"
    val isContactlessEnabled: Boolean,
    val cardholder: String
)

data class Notification(
    val id: String,
    val title: String,
    val message: String,
    val timestamp: Long,
    val category: String,
    val linkedTransactionId: String? = null,
    val isRead: Boolean = false
) {
    fun formatTime(): String {
        val sdf = SimpleDateFormat("dd/MM - HH:mm", Locale("pt", "BR"))
        return sdf.format(Date(timestamp))
    }
}

data class InvestmentState(
    val fixedIncome: Long = 0L,
    val funds: Long = 0L,
    val treasury: Long = 0L,
    val stocks: Long = 0L,
    val monthlyReturn: Long = 0L,
    val accumulatedReturn: Long = 0L
) {
    val total: Long get() = fixedIncome + funds + treasury + stocks

    fun formatCurrency(value: Long): String {
        val doubleValue = value.toDouble() / 100.0
        val formatter = NumberFormat.getCurrencyInstance(Locale("pt", "BR"))
        return formatter.format(doubleValue)
    }
}

data class LoanState(
    val requestedAmount: Long = 0L,
    val installments: Int = 12,
    val interestRate: Double = 4.85, // 4.85% ao mês
    val totalCost: Long = 0L,
    val status: String = "NONE" // "NONE", "ACTIVE"
) {
    val installmentAmount: Long
        get() = if (installments > 0) totalCost / installments else 0L

    fun formatCurrency(value: Long): String {
        val doubleValue = value.toDouble() / 100.0
        val formatter = NumberFormat.getCurrencyInstance(Locale("pt", "BR"))
        return formatter.format(doubleValue)
    }
}

data class CustomerProfile(
    val name: String = "João Martins",
    val cpf: String = "384.921.408-42",
    val agency: String = "0001",
    val accountNumber: String = "194827-3",
    val isBiometricsEnabled: Boolean = true,
    val isLogged: Boolean = false
)

// Helper currency formatter
fun formatCentsToCurrency(amountInCents: Long): String {
    val doubleValue = amountInCents.toDouble() / 100.0
    val formatter = NumberFormat.getCurrencyInstance(Locale("pt", "BR"))
    return formatter.format(doubleValue)
}
