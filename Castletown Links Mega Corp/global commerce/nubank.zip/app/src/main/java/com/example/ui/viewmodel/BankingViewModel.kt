package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AccountStateEntity
import com.example.data.local.NotificationEntity
import com.example.data.local.TransactionEntity
import com.example.data.model.Card
import com.example.data.model.CustomerProfile
import com.example.data.model.InvestmentState
import com.example.data.model.LoanState
import com.example.data.model.Notification
import com.example.data.model.NotificationCategory
import com.example.data.model.Transaction
import com.example.data.model.TransactionCategory
import com.example.data.model.TransactionStatus
import com.example.data.model.TransactionType
import com.example.data.repository.BankingRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

enum class Screen {
    LOGIN,
    HOME,
    ACCOUNT,
    PIX,
    PIX_SEND_TARGET,
    PIX_SEND_AMOUNT,
    PIX_SEND_CONFIRM,
    PIX_SEND_SUCCESS,
    PIX_RECEIVE_AMOUNT,
    PIX_RECEIVE_CODE,
    PAYMENTS,
    PAYMENTS_BOLETO,
    PAYMENTS_CONFIRM,
    PAYMENTS_SUCCESS,
    CARDS,
    INVOICE,
    SPENDING_ANALYTICS,
    INVESTMENTS,
    LOANS,
    LOANS_SIMULATOR,
    LOANS_CONFIRM,
    NOTIFICATIONS,
    SECURITY,
    PROFILE,
    HELP,
    HELP_CHAT,
    TRANSACTION_DETAIL
}

// Support chat message structure
data class SupportMessage(
    val sender: String, // "USER" or "SUPPORT"
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

class BankingViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = BankingRepository(application)

    // Backstack navigation
    private val _navStack = MutableStateFlow<List<Screen>>(listOf(Screen.LOGIN))
    val navStack = _navStack.asStateFlow()

    val currentScreen: StateFlow<Screen> = MutableStateFlow(Screen.LOGIN).run {
        viewModelScope.launch {
            _navStack.collect { list ->
                value = list.lastOrNull() ?: Screen.LOGIN
            }
        }
        asStateFlow()
    }

    // Observing repository data
    val customer: StateFlow<CustomerProfile> = repository.customerFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = CustomerProfile(isLogged = false)
    )

    val balance: StateFlow<Long> = repository.balanceFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = 0L
    )

    val creditLimit: StateFlow<Long> = repository.creditLimitFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = 0L
    )

    val creditUsed: StateFlow<Long> = repository.creditUsedFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = 0L
    )

    val currentInvoice: StateFlow<Long> = repository.currentInvoiceFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = 0L
    )

    val investment: StateFlow<InvestmentState> = repository.investmentFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = InvestmentState()
    )

    val loan: StateFlow<LoanState> = repository.loanFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = LoanState()
    )

    val transactions: StateFlow<List<Transaction>> = repository.transactionsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val cards: StateFlow<List<Card>> = repository.cardsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val notifications: StateFlow<List<Notification>> = repository.notificationsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Flow simulation UI inputs/parameters
    var selectedTransaction: Transaction? = null
    
    // Pix Flow state
    var pixTargetName = ""
    var pixTargetCpf = ""
    var pixAmount: Long = 0L
    var pixSuccessTx: Transaction? = null

    // Payment Flow state
    var paymentBarcode = ""
    var paymentBeneficiary = "Concessionária de Água e Saneamento"
    var paymentAmount: Long = 0L
    var paymentDueDate = "10/10/2026"
    var paymentSuccessTx: Transaction? = null

    // Request Money State
    var requestAmount: Long = 0L
    var requestQrCodePayload = ""

    // Loan Flow state
    var loanRequestedSimulated: Long = 500000L // R$ 5.000,00 default
    var loanInstallmentsSimulated: Int = 12

    // Security fraud simulation state
    private val _showFraudDialog = MutableStateFlow<String?>(null) // Contains purchase description if active
    val showFraudDialog = _showFraudDialog.asStateFlow()
    private var pendingFraudPurchaseAmount: Long = 0L
    private var pendingFraudPurchaseMerchant = ""

    // Connection offline state
    private val _isOffline = MutableStateFlow(false)
    val isOffline = _isOffline.asStateFlow()

    // Hide financial values
    private val _hideBalances = MutableStateFlow(false)
    val hideBalances = _hideBalances.asStateFlow()

    // Conversational Support Chat State
    private val _chatMessages = MutableStateFlow<List<SupportMessage>>(listOf(
        SupportMessage("SUPPORT", "Olá! Sou o assistente virtual do Nubank. Como posso ajudar você hoje?")
    ))
    val chatMessages = _chatMessages.asStateFlow()

    init {
        viewModelScope.launch {
            repository.checkAndSeedDatabase()
        }
    }

    // Navigation Methods
    fun navigateTo(screen: Screen) {
        _navStack.update { it + screen }
    }

    fun popScreen(): Boolean {
        if (_navStack.value.size > 1) {
            _navStack.update { it.dropLast(1) }
            return true
        }
        return false
    }

    fun navigateHome() {
        _navStack.value = listOf(Screen.HOME)
    }

    fun toggleHideBalances() {
        _hideBalances.update { !it }
    }

    fun toggleOffline() {
        _isOffline.update { !it }
    }

    // Authentication Actions
    fun login(password: String, onResult: (Boolean) -> Unit) {
        // Any simple pin works, or standard pin 1234
        if (password.length >= 4) {
            viewModelScope.launch {
                val state = repository.getAccountState()
                if (state != null) {
                    repository.saveAccountState(state.copy(isLogged = true))
                    _navStack.value = listOf(Screen.HOME)
                    onResult(true)
                } else {
                    onResult(false)
                }
            }
        } else {
            onResult(false)
        }
    }

    fun logout() {
        viewModelScope.launch {
            val state = repository.getAccountState()
            if (state != null) {
                repository.saveAccountState(state.copy(isLogged = false))
            }
            _navStack.value = listOf(Screen.LOGIN)
        }
    }

    // Simulation: Perform a new physical or virtual card purchase
    fun simulateCardPurchase(amount: Long, merchant: String, category: String, onResult: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            val state = repository.getAccountState() ?: return@launch
            val available = state.creditLimit - state.creditUsed
            if (amount > available) {
                onResult(false, "Limite de crédito insuficiente.")
                return@launch
            }

            // Simulated Fraud Engine: High value purchases (> R$ 1.500,00) trigger a security review dialog
            if (amount >= 150000L) {
                pendingFraudPurchaseAmount = amount
                pendingFraudPurchaseMerchant = merchant
                _showFraudDialog.value = merchant
                onResult(true, "SECURITY_CHALLENGE")
                return@launch
            }

            executeCreditCardPurchase(state, amount, merchant, category)
            onResult(true, null)
        }
    }

    fun confirmFraudPurchase(approved: Boolean) {
        val merchant = pendingFraudPurchaseMerchant
        val amount = pendingFraudPurchaseAmount
        _showFraudDialog.value = null
        pendingFraudPurchaseAmount = 0L
        pendingFraudPurchaseMerchant = ""

        viewModelScope.launch {
            val state = repository.getAccountState() ?: return@launch
            if (approved) {
                executeCreditCardPurchase(state, amount, merchant, TransactionCategory.SHOPPING)
            } else {
                // Denied and block card for safety
                repository.setCardStatus("physical_card_id", "BLOCKED")
                repository.setCardStatus("virtual_card_id", "BLOCKED")

                // Add Security Alert
                val notif = NotificationEntity(
                    id = UUID.randomUUID().toString(),
                    title = "Cartão Bloqueado por Segurança",
                    message = "Detectamos uma tentativa de compra suspeita de R$ " + (amount / 100.0) + " em " + merchant + " e bloqueamos seus cartões por segurança.",
                    timestamp = System.currentTimeMillis(),
                    category = NotificationCategory.SECURITY,
                    linkedTransactionId = null,
                    isRead = false
                )
                repository.saveNotification(notif)
            }
        }
    }

    private suspend fun executeCreditCardPurchase(state: AccountStateEntity, amount: Long, merchant: String, category: String) {
        val now = System.currentTimeMillis()
        val updatedState = state.copy(
            creditUsed = state.creditUsed + amount,
            currentInvoice = state.currentInvoice + amount
        )
        repository.saveAccountState(updatedState)

        val txId = UUID.randomUUID().toString()
        val tx = TransactionEntity(
            id = txId,
            timestamp = now,
            type = TransactionType.CREDIT_CARD,
            amount = amount,
            status = TransactionStatus.COMPLETED,
            description = merchant,
            merchant = merchant,
            category = category,
            isIncoming = false,
            details = "Compra parcelada à vista autorizada com sucesso via chip/contactless."
        )
        repository.saveTransaction(tx)

        val notif = NotificationEntity(
            id = UUID.randomUUID().toString(),
            title = "Compra aprovada",
            message = "R$ " + String.format("%.2f", amount / 100.0) + " em " + merchant + " com cartão final 4287.",
            timestamp = now,
            category = NotificationCategory.CARD,
            linkedTransactionId = txId,
            isRead = false
        )
        repository.saveNotification(notif)
    }

    // Pix Enviar Flow
    fun startPixFlow(name: String, cpf: String) {
        pixTargetName = name
        pixTargetCpf = cpf
        pixAmount = 0L
        pixSuccessTx = null
        navigateTo(Screen.PIX_SEND_AMOUNT)
    }

    fun submitPixAmount(amount: Long, onResult: (Boolean, String?) -> Unit) {
        if (isOffline.value) {
            onResult(false, "Sem conexão de rede. Tente mais tarde.")
            return
        }
        viewModelScope.launch {
            val state = repository.getAccountState() ?: return@launch
            if (amount <= 0) {
                onResult(false, "O valor deve ser maior que zero.")
                return@launch
            }
            if (amount > state.balance) {
                onResult(false, "Saldo de conta insuficiente para realizar este Pix.")
                return@launch
            }
            pixAmount = amount
            navigateTo(Screen.PIX_SEND_CONFIRM)
            onResult(true, null)
        }
    }

    fun confirmPixPayment() {
        viewModelScope.launch {
            val state = repository.getAccountState() ?: return@launch
            val updatedState = state.copy(
                balance = state.balance - pixAmount
            )
            repository.saveAccountState(updatedState)

            val txId = UUID.randomUUID().toString()
            val tx = Transaction(
                id = txId,
                timestamp = System.currentTimeMillis(),
                type = TransactionType.PIX_SENT,
                amount = pixAmount,
                status = TransactionStatus.COMPLETED,
                description = "Pix para $pixTargetName",
                merchant = pixTargetName,
                category = TransactionCategory.OTHERS,
                isIncoming = false,
                details = "Pix enviado com sucesso. ID de autenticação: E" + UUID.randomUUID().toString().replace("-", "").uppercase()
            )

            pixSuccessTx = tx
            repository.saveTransaction(TransactionEntity(
                id = tx.id,
                timestamp = tx.timestamp,
                type = tx.type,
                amount = tx.amount,
                status = tx.status,
                description = tx.description,
                merchant = tx.merchant,
                category = tx.category,
                isIncoming = tx.isIncoming,
                details = tx.details
            ))

            val notif = NotificationEntity(
                id = UUID.randomUUID().toString(),
                title = "Pix enviado",
                message = "Seu Pix no valor de R$ " + String.format("%.2f", pixAmount / 100.0) + " para $pixTargetName foi enviado com sucesso.",
                timestamp = System.currentTimeMillis(),
                category = NotificationCategory.TRANSACTION,
                linkedTransactionId = txId,
                isRead = false
            )
            repository.saveNotification(notif)

            navigateTo(Screen.PIX_SEND_SUCCESS)
        }
    }

    // Pay Invoice (Fatura) Flow
    fun payCreditInvoice(amount: Long, onResult: (Boolean, String?) -> Unit) {
        if (isOffline.value) {
            onResult(false, "Sem conexão de rede. Tente mais tarde.")
            return
        }
        viewModelScope.launch {
            val state = repository.getAccountState() ?: return@launch
            if (amount <= 0L) {
                onResult(false, "Valor inválido para pagamento.")
                return@launch
            }
            if (amount > state.balance) {
                onResult(false, "Saldo em conta insuficiente para pagar esta fatura.")
                return@launch
            }

            val updatedState = state.copy(
                balance = state.balance - amount,
                creditUsed = maxOf(0L, state.creditUsed - amount),
                currentInvoice = maxOf(0L, state.currentInvoice - amount)
            )
            repository.saveAccountState(updatedState)

            val txId = UUID.randomUUID().toString()
            val tx = TransactionEntity(
                id = txId,
                timestamp = System.currentTimeMillis(),
                type = TransactionType.DEPOSIT,
                amount = amount,
                status = TransactionStatus.COMPLETED,
                description = "Pagamento de fatura",
                merchant = "Nubank",
                category = TransactionCategory.REVENUE,
                isIncoming = true,
                details = "Pagamento parcial ou total da fatura mensal do cartão de crédito realizado através de débito em conta."
            )
            repository.saveTransaction(tx)

            val notif = NotificationEntity(
                id = UUID.randomUUID().toString(),
                title = "Fatura paga",
                message = "Pagamento da fatura de R$ " + String.format("%.2f", amount / 100.0) + " processado. Limite restabelecido.",
                timestamp = System.currentTimeMillis(),
                category = NotificationCategory.CARD,
                linkedTransactionId = txId,
                isRead = false
            )
            repository.saveNotification(notif)

            onResult(true, null)
        }
    }

    // Boleto Payment Flow
    fun startBoletoFlow(barcode: String, onResult: (Boolean, String?) -> Unit) {
        if (barcode.replace(" ", "").length < 12) {
            onResult(false, "Código de barras inválido.")
            return
        }
        paymentBarcode = barcode
        paymentAmount = 14850L // R$ 148,50 default simulation amount
        paymentBeneficiary = "Light Serviços de Eletricidade S.A."
        paymentDueDate = "10/10/2026"
        paymentSuccessTx = null
        navigateTo(Screen.PAYMENTS_CONFIRM)
        onResult(true, null)
    }

    fun confirmBoletoPayment(onResult: (Boolean, String?) -> Unit) {
        if (isOffline.value) {
            onResult(false, "Sem conexão de rede.")
            return
        }
        viewModelScope.launch {
            val state = repository.getAccountState() ?: return@launch
            if (paymentAmount > state.balance) {
                onResult(false, "Saldo em conta insuficiente.")
                return@launch
            }

            val updatedState = state.copy(
                balance = state.balance - paymentAmount
            )
            repository.saveAccountState(updatedState)

            val txId = UUID.randomUUID().toString()
            val tx = Transaction(
                id = txId,
                timestamp = System.currentTimeMillis(),
                type = TransactionType.BOLETO_PAYMENT,
                amount = paymentAmount,
                status = TransactionStatus.COMPLETED,
                description = "Pagamento de Boleto",
                merchant = paymentBeneficiary,
                category = TransactionCategory.HOME,
                isIncoming = false,
                details = "Boleto liquidado via internet banking. Código de autenticação de transação bancária."
            )

            paymentSuccessTx = tx
            repository.saveTransaction(TransactionEntity(
                id = tx.id,
                timestamp = tx.timestamp,
                type = tx.type,
                amount = tx.amount,
                status = tx.status,
                description = tx.description,
                merchant = tx.merchant,
                category = tx.category,
                isIncoming = tx.isIncoming,
                details = tx.details
            ))

            val notif = NotificationEntity(
                id = UUID.randomUUID().toString(),
                title = "Boleto pago com sucesso",
                message = "O pagamento do boleto de R$ " + String.format("%.2f", paymentAmount / 100.0) + " para $paymentBeneficiary foi concluído.",
                timestamp = System.currentTimeMillis(),
                category = NotificationCategory.ACCOUNT,
                linkedTransactionId = txId,
                isRead = false
            )
            repository.saveNotification(notif)

            navigateTo(Screen.PAYMENTS_SUCCESS)
            onResult(true, null)
        }
    }

    // Money Request Flow
    fun generatePaymentRequest(amount: Long) {
        requestAmount = amount
        requestQrCodePayload = "00020101021226300014br.gov.bcb.pix0114+55384921408425204000053039865405" + amount + "5802BR5913JOAO MARTINS6009SAO PAULO62070503***"
        navigateTo(Screen.PIX_RECEIVE_CODE)
    }

    fun simulateReceivingPayment() {
        if (requestAmount <= 0) return
        viewModelScope.launch {
            val state = repository.getAccountState() ?: return@launch
            val updatedState = state.copy(
                balance = state.balance + requestAmount
            )
            repository.saveAccountState(updatedState)

            val txId = UUID.randomUUID().toString()
            val tx = TransactionEntity(
                id = txId,
                timestamp = System.currentTimeMillis(),
                type = TransactionType.PIX_RECEIVED,
                amount = requestAmount,
                status = TransactionStatus.COMPLETED,
                description = "Pix recebido de Cobrança",
                merchant = "Felipe Oliveira",
                category = TransactionCategory.REVENUE,
                isIncoming = true,
                details = "Pix recebido referente à cobrança gerada via QR Code."
            )
            repository.saveTransaction(tx)

            val notif = NotificationEntity(
                id = UUID.randomUUID().toString(),
                title = "Pix Cobrado Recebido",
                message = "Você recebeu um Pix de R$ " + String.format("%.2f", requestAmount / 100.0) + " referente à sua cobrança.",
                timestamp = System.currentTimeMillis(),
                category = NotificationCategory.TRANSACTION,
                linkedTransactionId = txId,
                isRead = false
            )
            repository.saveNotification(notif)

            requestAmount = 0L
            _navStack.value = listOf(Screen.HOME)
        }
    }

    // Card Management Actions
    fun toggleBlockCard(cardId: String) {
        viewModelScope.launch {
            val currentCards = cards.value
            val target = currentCards.find { it.id == cardId } ?: return@launch
            val newStatus = if (target.status == "ACTIVE") "BLOCKED" else "ACTIVE"
            repository.setCardStatus(cardId, newStatus)

            val notif = NotificationEntity(
                id = UUID.randomUUID().toString(),
                title = "Status do Cartão Alterado",
                message = "O cartão " + (if (target.type == "PHYSICAL") "físico" else "virtual") + " foi " + (if (newStatus == "ACTIVE") "desbloqueado" else "bloqueado") + " com sucesso.",
                timestamp = System.currentTimeMillis(),
                category = NotificationCategory.SECURITY,
                linkedTransactionId = null,
                isRead = false
            )
            repository.saveNotification(notif)
        }
    }

    // Limit adjustments
    fun adjustLimit(newLimit: Long) {
        viewModelScope.launch {
            val state = repository.getAccountState() ?: return@launch
            repository.saveAccountState(state.copy(creditLimit = newLimit))
        }
    }

    // Loans Flow Actions
    fun startLoanSimulation(amount: Long, installments: Int) {
        loanRequestedSimulated = amount
        loanInstallmentsSimulated = installments
        navigateTo(Screen.LOANS_CONFIRM)
    }

    fun confirmLoanContract() {
        viewModelScope.launch {
            val state = repository.getAccountState() ?: return@launch
            val finalCost = (loanRequestedSimulated * 1.35).toLong() // Simulated simple 35% compound/simple interest over installments

            val updatedState = state.copy(
                balance = state.balance + loanRequestedSimulated,
                loanRequestedAmount = loanRequestedSimulated,
                loanInstallments = loanInstallmentsSimulated,
                loanTotalCost = finalCost,
                loanStatus = "ACTIVE"
            )
            repository.saveAccountState(updatedState)

            val txId = UUID.randomUUID().toString()
            val tx = TransactionEntity(
                id = txId,
                timestamp = System.currentTimeMillis(),
                type = TransactionType.DEPOSIT,
                amount = loanRequestedSimulated,
                status = TransactionStatus.COMPLETED,
                description = "Crédito Empréstimo",
                merchant = "Nubank",
                category = TransactionCategory.REVENUE,
                isIncoming = true,
                details = "Empréstimo pessoal contratado e liberado em conta no valor de R$ " + String.format("%.2f", loanRequestedSimulated / 100.0) + "."
            )
            repository.saveTransaction(tx)

            val notif = NotificationEntity(
                id = UUID.randomUUID().toString(),
                title = "Empréstimo Contratado",
                message = "O valor de R$ " + String.format("%.2f", loanRequestedSimulated / 100.0) + " foi depositado na sua conta com sucesso.",
                timestamp = System.currentTimeMillis(),
                category = NotificationCategory.ACCOUNT,
                linkedTransactionId = txId,
                isRead = false
            )
            repository.saveNotification(notif)

            navigateTo(Screen.HOME)
        }
    }

    // Conversational Help Chat support responses
    fun sendSupportMessage(text: String) {
        if (text.isBlank()) return
        val userMsg = SupportMessage("USER", text)
        _chatMessages.update { it + userMsg }

        viewModelScope.launch {
            // Simulated virtual assist response based on keyword matching
            val responseText = when {
                text.contains("pix", ignoreCase = true) -> "Para enviar um Pix, toque na opção 'Pix' na tela inicial, digite a chave do contato, insira o valor desejado e confirme com seu PIN de segurança."
                text.contains("fatura", ignoreCase = true) || text.contains("cartão", ignoreCase = true) -> "Para pagar ou parcelar sua fatura, acesse a aba 'Cartão de crédito' e clique em 'Pagar fatura'. Você pode pagar usando o saldo de sua conta Nubank."
                text.contains("limite", ignoreCase = true) -> "Você pode ajustar seu limite de crédito na área do Cartão de Crédito tocando no botão 'Ajustar limite' e movendo o controle deslizante."
                text.contains("empréstimo", ignoreCase = true) -> "Disponibilizamos ofertas de empréstimo pessoal na aba 'Empréstimos'. Faça uma simulação do valor e número de parcelas desejado."
                text.contains("rendimento", ignoreCase = true) || text.contains("investir", ignoreCase = true) -> "Sua conta Nubank rende 100% do CDI. Você também pode acessar nossa aba de Investimentos para aplicar em Renda Fixa, Ações e Fundos."
                else -> "Entendi seu contato. Para essa solicitação, nossa equipe virtual recomenda verificar os guias detalhados na Central de Ajuda ou nos informar se deseja que expliquemos detalhadamente sobre Pix, Limites, Empréstimos ou Faturas."
            }
            
            // Add slight simulated delay
            kotlinx.coroutines.delay(1000)
            _chatMessages.update { it + SupportMessage("SUPPORT", responseText) }
        }
    }

    fun resetState() {
        viewModelScope.launch {
            repository.performReset()
            _navStack.value = listOf(Screen.LOGIN)
        }
    }

    fun markNotificationAsRead(id: String) {
        viewModelScope.launch {
            repository.markNotificationAsRead(id)
        }
    }
}
