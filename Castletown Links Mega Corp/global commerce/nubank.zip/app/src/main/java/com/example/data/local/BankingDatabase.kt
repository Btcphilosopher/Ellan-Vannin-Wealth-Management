package com.example.data.local

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

// 1. Account State Entity
@Entity(tableName = "account_state")
data class AccountStateEntity(
    @PrimaryKey val id: Int = 1,
    val balance: Long,
    val creditLimit: Long,
    val creditUsed: Long,
    val currentInvoice: Long,
    
    // Loan fields
    val loanRequestedAmount: Long,
    val loanInstallments: Int,
    val loanInterestRate: Double,
    val loanTotalCost: Long,
    val loanStatus: String,

    // Investment fields
    val investFixedIncome: Long,
    val investFunds: Long,
    val investTreasury: Long,
    val investStocks: Long,
    val investMonthlyReturn: Long,
    val investAccumulatedReturn: Long,

    // Customer fields
    val customerName: String,
    val cpf: String,
    val agency: String,
    val accountNumber: String,
    val isBiometricsEnabled: Boolean,
    val isLogged: Boolean
)

// 2. Transaction Entity
@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey val id: String,
    val timestamp: Long,
    val type: String,
    val amount: Long,
    val status: String,
    val description: String,
    val merchant: String,
    val category: String,
    val isIncoming: Boolean,
    val details: String
)

// 3. Card Entity
@Entity(tableName = "cards")
data class CardEntity(
    @PrimaryKey val id: String,
    val type: String,
    val number: String,
    val expiry: String,
    val cvv: String,
    val status: String,
    val isContactlessEnabled: Boolean,
    val cardholder: String
)

// 4. Notification Entity
@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey val id: String,
    val title: String,
    val message: String,
    val timestamp: Long,
    val category: String,
    val linkedTransactionId: String?,
    val isRead: Boolean
)

// DAO Interface
@Dao
interface BankingDao {
    @Query("SELECT * FROM account_state WHERE id = 1 LIMIT 1")
    fun getAccountStateFlow(): Flow<AccountStateEntity?>

    @Query("SELECT * FROM account_state WHERE id = 1 LIMIT 1")
    suspend fun getAccountState(): AccountStateEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAccountState(state: AccountStateEntity)

    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun getTransactionsFlow(): Flow<List<TransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(tx: TransactionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransactions(txs: List<TransactionEntity>)

    @Query("SELECT * FROM cards")
    fun getCardsFlow(): Flow<List<CardEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCard(card: CardEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCards(cards: List<CardEntity>)

    @Query("UPDATE cards SET status = :status WHERE id = :cardId")
    suspend fun updateCardStatus(cardId: String, status: String)

    @Query("SELECT * FROM notifications ORDER BY timestamp DESC")
    fun getNotificationsFlow(): Flow<List<NotificationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notif: NotificationEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotifications(notifs: List<NotificationEntity>)

    @Query("UPDATE notifications SET isRead = 1 WHERE id = :notifId")
    suspend fun markNotificationRead(notifId: String)

    @Query("DELETE FROM transactions")
    suspend fun clearTransactions()

    @Query("DELETE FROM cards")
    suspend fun clearCards()

    @Query("DELETE FROM notifications")
    suspend fun clearNotifications()
}

// Room Database Holder
@Database(
    entities = [
        AccountStateEntity::class,
        TransactionEntity::class,
        CardEntity::class,
        NotificationEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class BankingDatabase : RoomDatabase() {
    abstract fun bankingDao(): BankingDao
}
