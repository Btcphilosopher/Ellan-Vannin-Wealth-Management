package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Pix
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.ripple.rememberRipple
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Notification
import com.example.data.model.NotificationCategory
import com.example.data.model.Transaction
import com.example.data.model.TransactionCategory
import com.example.data.model.TransactionType
import com.example.data.model.formatCentsToCurrency
import com.example.ui.theme.NuBlue
import com.example.ui.theme.NuGreen
import com.example.ui.theme.NuPurple
import com.example.ui.theme.NuRed

// Primary filled button styled in Deep Purple
@Composable
fun NuButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    testTag: String = ""
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        colors = ButtonDefaults.buttonColors(
            containerColor = NuPurple,
            contentColor = Color.White,
            disabledContainerColor = NuPurple.copy(alpha = 0.5f),
            disabledContentColor = Color.White.copy(alpha = 0.7f)
        ),
        shape = RoundedCornerShape(24.dp),
        modifier = modifier
            .height(48.dp)
            .testTag(testTag)
    ) {
        Text(
            text = text,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
    }
}

// Outlined Button with Purple outline
@Composable
fun NuOutlineButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    testTag: String = ""
) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        colors = ButtonDefaults.outlinedButtonColors(
            contentColor = NuPurple
        ),
        border = ButtonDefaults.outlinedButtonBorder.copy(
            brush = androidx.compose.ui.graphics.SolidColor(if (enabled) NuPurple else NuPurple.copy(alpha = 0.5f))
        ),
        shape = RoundedCornerShape(24.dp),
        modifier = modifier
            .height(48.dp)
            .testTag(testTag)
    ) {
        Text(
            text = text,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

// Transaction List Item / Row
@Composable
fun TransactionRow(
    transaction: Transaction,
    onClick: () -> Unit,
    hideValues: Boolean = false,
    modifier: Modifier = Modifier
) {
    val icon = when (transaction.type) {
        TransactionType.PIX_SENT, TransactionType.PIX_RECEIVED -> Icons.Default.Pix
        TransactionType.DEBIT_CARD, TransactionType.CREDIT_CARD -> Icons.Default.CreditCard
        TransactionType.BOLETO_PAYMENT -> Icons.Default.ReceiptLong
        TransactionType.SALARY -> Icons.Default.TrendingUp
        else -> Icons.Default.ReceiptLong
    }

    val iconColor = when {
        transaction.isIncoming -> NuGreen
        transaction.type == TransactionType.CREDIT_CARD -> NuPurple
        else -> Color.Gray
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 14.dp, horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Icon Circle Background
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(iconColor.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = transaction.type,
                tint = iconColor,
                modifier = Modifier.size(20.dp)
            )
        }

        Spacer(modifier = Modifier.width(16.dp))

        // Transaction Details
        Column(
            modifier = Modifier.weight(1.0f)
        ) {
            Text(
                text = transaction.description,
                fontWeight = FontWeight.SemiBold,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "${transaction.formatDate()} • ${transaction.formatTime()}",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        // Value / Amount
        Text(
            text = if (hideValues) "R$ •••••" else transaction.formatAmount(),
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = if (transaction.isIncoming) NuGreen else MaterialTheme.colorScheme.onSurface
        )

        Spacer(modifier = Modifier.width(4.dp))

        Icon(
            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
            contentDescription = "Ver Detalhes",
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(20.dp)
        )
    }
}

// Compact Circular Segmented Chart (spending category)
@Composable
fun SpendingDonutChart(
    foodAmount: Long,
    transportAmount: Long,
    homeAmount: Long,
    leisureAmount: Long,
    shoppingAmount: Long,
    modifier: Modifier = Modifier,
    size: Dp = 140.dp
) {
    val total = foodAmount + transportAmount + homeAmount + leisureAmount + shoppingAmount
    val sweepAngles = if (total > 0) {
        listOf(
            (foodAmount.toFloat() / total) * 360f,
            (transportAmount.toFloat() / total) * 360f,
            (homeAmount.toFloat() / total) * 360f,
            (leisureAmount.toFloat() / total) * 360f,
            (shoppingAmount.toFloat() / total) * 360f
        )
    } else {
        listOf(360f, 0f, 0f, 0f, 0f)
    }

    val colors = listOf(
        NuRed, // Food
        NuPurple, // Transport
        NuBlue, // Home
        Color(0xFFFF9900), // Leisure
        Color(0xFFE040FB) // Shopping
    )

    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size)) {
            var startAngle = -90f
            val strokeWidth = 14.dp.toPx()

            if (total == 0L) {
                drawArc(
                    color = Color.LightGray,
                    startAngle = 0f,
                    sweepAngle = 360f,
                    useCenter = false,
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                )
            } else {
                for (i in sweepAngles.indices) {
                    val sweep = sweepAngles[i]
                    if (sweep > 0) {
                        drawArc(
                            color = colors[i],
                            startAngle = startAngle,
                            sweepAngle = sweep - 2f, // Add spacing gap
                            useCenter = false,
                            style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
                            size = Size(this.size.width - strokeWidth, this.size.height - strokeWidth),
                            topLeft = Offset(strokeWidth / 2, strokeWidth / 2)
                        )
                        startAngle += sweep
                    }
                }
            }
        }

        // Center Content
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "Total",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = formatCentsToCurrency(total),
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

// Pix horizontal action item
@Composable
fun QuickActionItem(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = ""
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(8.dp)
            .testTag(testTag)
    ) {
        Box(
            modifier = Modifier
                .size(60.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.size(24.dp)
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

// Notification Alert Row
@Composable
fun NotificationRow(
    notification: Notification,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val unreadColor = if (!notification.isRead) NuPurple.copy(alpha = 0.05f) else Color.Transparent

    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(unreadColor)
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.Top
    ) {
        // Icon Circle
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(
                    when (notification.category) {
                        NotificationCategory.SECURITY -> NuRed.copy(alpha = 0.1f)
                        NotificationCategory.CARD -> NuPurple.copy(alpha = 0.1f)
                        else -> NuBlue.copy(alpha = 0.1f)
                    }
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = when (notification.category) {
                    NotificationCategory.SECURITY -> Icons.Default.Lock
                    NotificationCategory.CARD -> Icons.Default.CreditCard
                    NotificationCategory.TRANSACTION -> Icons.Default.Pix
                    else -> Icons.Default.Notifications
                },
                contentDescription = null,
                tint = when (notification.category) {
                    NotificationCategory.SECURITY -> NuRed
                    NotificationCategory.CARD -> NuPurple
                    else -> NuBlue
                },
                modifier = Modifier.size(18.dp)
            )
        }

        Spacer(modifier = Modifier.width(16.dp))

        Column(
            modifier = Modifier.weight(1.0f)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = notification.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = notification.formatTime(),
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = notification.message,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 18.sp
            )
        }
    }
}

// PIN Input Verification Component
@Composable
fun PinEntryRow(
    pinLength: Int = 4,
    enteredPin: String,
    onPinChanged: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        for (i in 0 until pinLength) {
            val isFilled = i < enteredPin.length
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .padding(4.dp)
                    .clip(CircleShape)
                    .background(if (isFilled) NuPurple else MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                // Empty circle or filled circle
            }
            if (i < pinLength - 1) {
                Spacer(modifier = Modifier.width(16.dp))
            }
        }
    }
}
