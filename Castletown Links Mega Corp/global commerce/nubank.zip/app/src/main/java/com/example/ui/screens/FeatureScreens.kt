package com.example.ui.screens

import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Notification
import com.example.data.model.Transaction
import com.example.data.model.TransactionCategory
import com.example.data.model.TransactionType
import com.example.data.model.formatCentsToCurrency
import com.example.ui.components.NuButton
import com.example.ui.components.NuOutlineButton
import com.example.ui.components.PinEntryRow
import com.example.ui.components.SpendingDonutChart
import com.example.ui.components.TransactionRow
import com.example.ui.theme.NuBlue
import com.example.ui.theme.NuGreen
import com.example.ui.theme.NuGreenLight
import com.example.ui.theme.NuPurple
import com.example.ui.theme.NuPurpleBg
import com.example.ui.theme.NuPurpleDark
import com.example.ui.theme.NuPurpleLight
import com.example.ui.theme.NuRed
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.foundation.layout.widthIn
import com.example.ui.viewmodel.BankingViewModel
import com.example.ui.viewmodel.Screen

// Screen Header standard layout
@Composable
fun ScreenHeader(
    title: String,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    actions: @Composable (RowScope.() -> Unit) = {}
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .height(56.dp)
            .padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = onBack,
            modifier = Modifier.size(48.dp)
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Voltar",
                tint = MaterialTheme.colorScheme.onBackground
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = title,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.weight(1.0f)
        )
        Row(content = actions)
    }
}

interface RowScope {
    @Composable
    fun action(content: @Composable () -> Unit)
}

// Concrete row scope
class RowScopeImpl : RowScope {
    @Composable
    override fun action(content: @Composable () -> Unit) {
        content()
    }
}

@Composable
fun Row(modifier: Modifier = Modifier, content: @Composable RowScope.() -> Unit) {
    // Standard compose layout
}

// ==========================================
// 1. CONTA (ACCOUNT SCREEN)
// ==========================================
@Composable
fun AccountScreen(viewModel: BankingViewModel) {
    BackHandler { viewModel.popScreen() }

    val balance by viewModel.balance.collectAsState()
    val transactions by viewModel.transactions.collectAsState()
    val hideValues by viewModel.hideBalances.collectAsState()

    var selectedFilter by remember { mutableStateOf("Todas") }
    val filters = listOf("Todas", "Entradas", "Saídas", "Pix", "Cartão")

    val filteredTransactions = remember(transactions, selectedFilter) {
        when (selectedFilter) {
            "Entradas" -> transactions.filter { it.isIncoming }
            "Saídas" -> transactions.filter { !it.isIncoming }
            "Pix" -> transactions.filter { it.type == TransactionType.PIX_SENT || it.type == TransactionType.PIX_RECEIVED }
            "Cartão" -> transactions.filter { it.type == TransactionType.CREDIT_CARD || it.type == TransactionType.DEBIT_CARD }
            else -> transactions
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        ScreenHeader(
            title = "Conta",
            onBack = { viewModel.popScreen() }
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize()
        ) {
            // Balance Card Block
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp)
                    ) {
                        Text(
                            text = "Saldo disponível",
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (hideValues) "R$ •••••" else formatCentsToCurrency(balance),
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Rendimento estimado",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "100% do CDI",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = NuGreen
                            )
                        }
                    }
                }
            }

            // Quick Filters Header
            item {
                Text(
                    text = "Histórico de transações",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    filters.forEach { filter ->
                        val isSelected = filter == selectedFilter
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(if (isSelected) NuPurple else MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { selectedFilter = filter }
                                .padding(horizontal = 16.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = filter,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
            }

            // Transaction Rows
            if (filteredTransactions.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(48.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Nenhuma movimentação encontrada.",
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 14.sp
                        )
                    }
                }
            } else {
                items(filteredTransactions) { tx ->
                    TransactionRow(
                        transaction = tx,
                        hideValues = hideValues,
                        onClick = {
                            viewModel.selectedTransaction = tx
                            viewModel.navigateTo(Screen.TRANSACTION_DETAIL)
                        }
                    )
                    HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.padding(horizontal = 16.dp))
                }
            }
        }
    }
}

// ==========================================
// 2. TRANSACTION DETAIL SCREEN
// ==========================================
@Composable
fun TransactionDetailScreen(viewModel: BankingViewModel) {
    BackHandler { viewModel.popScreen() }
    val context = LocalContext.current
    val tx = viewModel.selectedTransaction ?: return

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        ScreenHeader(
            title = "Detalhe da Transação",
            onBack = { viewModel.popScreen() }
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Receipt Header Visual
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(NuPurple.copy(alpha = 0.1f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = NuPurple,
                        modifier = Modifier.size(36.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = tx.merchant,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = tx.formatRawAmount(),
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (tx.isIncoming) NuGreen else MaterialTheme.colorScheme.onBackground
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = tx.status.replace("COMPLETED", "Transação Concluída"),
                    fontSize = 13.sp,
                    color = NuGreen,
                    fontWeight = FontWeight.SemiBold
                )

                Spacer(modifier = Modifier.height(32.dp))

                // Detail Box
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        DetailRow(label = "Categoria", value = tx.category)
                        DetailRow(label = "Tipo", value = tx.type.replace("_", " "))
                        DetailRow(label = "Data", value = tx.formatDate())
                        DetailRow(label = "Hora", value = tx.formatTime())
                        DetailRow(label = "ID Transação", value = tx.id.take(18) + "...")
                        
                        HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.padding(vertical = 4.dp))
                        
                        Text(
                            text = tx.details,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 18.sp
                        )
                    }
                }
            }

            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                NuButton(
                    text = "Compartilhar Comprovante",
                    onClick = {
                        val sendIntent: Intent = Intent().apply {
                            action = Intent.ACTION_SEND
                            putExtra(Intent.EXTRA_TEXT, "Comprovante Nubank: Enviado R$ ${tx.formatRawAmount()} para ${tx.merchant} em ${tx.formatDate()}")
                            type = "text/plain"
                        }
                        val shareIntent = Intent.createChooser(sendIntent, null)
                        context.startActivity(shareIntent)
                    },
                    modifier = Modifier.fillMaxWidth()
                )

                NuOutlineButton(
                    text = "Contestar Compra",
                    onClick = {
                        Toast.makeText(context, "Operação de contestação enviada para análise de segurança.", Toast.LENGTH_LONG).show()
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
    }
}

// ==========================================
// 3. PIX EXPERIENCE (DASHBOARD & SEND/RECEIVE FLOWS)
// ==========================================
@Composable
fun PixScreen(viewModel: BankingViewModel) {
    BackHandler { viewModel.popScreen() }

    val balance by viewModel.balance.collectAsState()
    val isOffline by viewModel.isOffline.collectAsState()
    val hideValues by viewModel.hideBalances.collectAsState()

    var contactName by remember { mutableStateOf("") }
    var contactCpf by remember { mutableStateOf("") }
    var inputError by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        ScreenHeader(
            title = "Área Pix",
            onBack = { viewModel.popScreen() }
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header Balance Info
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "Saldo disponível para Pix", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                text = if (hideValues) "R$ •••••" else formatCentsToCurrency(balance),
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        if (isOffline) {
                            Icon(imageVector = Icons.Default.WifiOff, contentDescription = "Sem conexão", tint = NuRed)
                        }
                    }
                }
            }

            // Quick Pix options
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable {
                        viewModel.generatePaymentRequest(15000L) // generate simulated R$ 150,00 Pix
                    }) {
                        Box(modifier = Modifier.size(54.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
                            Icon(imageVector = Icons.Default.QrCode, contentDescription = null, tint = NuPurple)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "Cobrar Pix", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable {
                        viewModel.navigateTo(Screen.PIX_RECEIVE_AMOUNT)
                    }) {
                        Box(modifier = Modifier.size(54.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = null, tint = NuPurple)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "Receber Pix", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Send Pix Form
            item {
                Text(
                    text = "Enviar Pix",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Para quem você deseja transferir?",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            item {
                OutlinedTextField(
                    value = contactName,
                    onValueChange = { contactName = it; inputError = null },
                    label = { Text("Nome do recebedor") },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NuPurple, cursorColor = NuPurple),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                )
            }

            item {
                OutlinedTextField(
                    value = contactCpf,
                    onValueChange = { contactCpf = it; inputError = null },
                    label = { Text("CPF ou Chave Pix") },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NuPurple, cursorColor = NuPurple),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                
                if (inputError != null) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = inputError!!, color = NuRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            item {
                NuButton(
                    text = "Continuar para Valor",
                    onClick = {
                        if (contactName.isBlank() || contactCpf.length < 5) {
                            inputError = "Por favor, preencha os dados de destino corretamente."
                        } else {
                            viewModel.startPixFlow(contactName, contactCpf)
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "continue_pix_button"
                )
            }
        }
    }
}

// PIX AMOUNT SCREEN
@Composable
fun PixSendAmountScreen(viewModel: BankingViewModel) {
    BackHandler { viewModel.popScreen() }

    var inputAmountStr by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        ScreenHeader(
            title = "Valor do Pix",
            onBack = { viewModel.popScreen() }
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Quanto você quer transferir?",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Enviar para ${viewModel.pixTargetName}",
                    fontSize = 14.sp,
                    color = NuPurple,
                    fontWeight = FontWeight.SemiBold
                )

                Spacer(modifier = Modifier.height(32.dp))

                OutlinedTextField(
                    value = inputAmountStr,
                    onValueChange = { inputAmountStr = it; errorMsg = null },
                    label = { Text("Valor em Reais (ex: 25.50)") },
                    prefix = { Text("R$ ") },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NuPurple, cursorColor = NuPurple),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )

                if (errorMsg != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = errorMsg!!, color = NuRed, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }

            NuButton(
                text = "Revisar Pix",
                onClick = {
                    val floatVal = inputAmountStr.replace(",", ".").toFloatOrNull()
                    if (floatVal == null || floatVal <= 0f) {
                        errorMsg = "Digite um valor de transferência válido."
                    } else {
                        val centsVal = (floatVal * 100f).toLong()
                        viewModel.submitPixAmount(centsVal) { success, reason ->
                            if (!success) {
                                errorMsg = reason
                            }
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

// PIX CONFIRMATION & IDENTITY PIN CHECK SCREEN
@Composable
fun PixSendConfirmScreen(viewModel: BankingViewModel) {
    BackHandler { viewModel.popScreen() }

    var enteredPin by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        ScreenHeader(
            title = "Confirmar Pix",
            onBack = { viewModel.popScreen() }
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Insira seu PIN de segurança",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Para confirmar o Pix no valor de:",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = formatCentsToCurrency(viewModel.pixAmount),
                    fontSize = 36.sp,
                    fontWeight = FontWeight.Bold,
                    color = NuPurple
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Destinatário: ${viewModel.pixTargetName}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(32.dp))

                // Custom Visual Pin Entry
                PinEntryRow(
                    enteredPin = enteredPin,
                    onPinChanged = { enteredPin = it }
                )

                if (pinError) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(text = "PIN incorreto. Tente novamente.", color = NuRed, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }

                Spacer(modifier = Modifier.height(32.dp))

                // Keyboard simulator buttons inside UI to satisfy standard layouts
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    listOf("1", "2", "3").forEach { num ->
                        OutlinedKeyButton(text = num) { if (enteredPin.length < 4) enteredPin += num }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    listOf("4", "5", "6").forEach { num ->
                        OutlinedKeyButton(text = num) { if (enteredPin.length < 4) enteredPin += num }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    listOf("7", "8", "9").forEach { num ->
                        OutlinedKeyButton(text = num) { if (enteredPin.length < 4) enteredPin += num }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    OutlinedKeyButton(text = "Limpar") { enteredPin = "" }
                    OutlinedKeyButton(text = "0") { if (enteredPin.length < 4) enteredPin += "0" }
                    OutlinedKeyButton(text = "X") { if (enteredPin.isNotEmpty()) enteredPin = enteredPin.dropLast(1) }
                }
            }

            NuButton(
                text = "Confirmar Envio",
                onClick = {
                    if (enteredPin.length < 4) {
                        pinError = true
                    } else {
                        viewModel.confirmPixPayment()
                    }
                },
                enabled = enteredPin.length == 4,
                modifier = Modifier.fillMaxWidth(),
                testTag = "confirm_pix_transaction"
            )
        }
    }
}

@Composable
fun OutlinedKeyButton(text: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(64.dp)
            .clip(CircleShape)
            .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text = text, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
    }
}

// PIX SUCCESS RECEIPT
@Composable
fun PixSendSuccessScreen(viewModel: BankingViewModel) {
    BackHandler { viewModel.navigateHome() }
    val context = LocalContext.current
    val tx = viewModel.pixSuccessTx ?: return

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        ScreenHeader(
            title = "Comprovante Pix",
            onBack = { viewModel.navigateHome() }
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(NuGreenLight.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = NuGreen,
                        modifier = Modifier.size(40.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Pix enviado!",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = NuGreen
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = formatCentsToCurrency(tx.amount),
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )

                Spacer(modifier = Modifier.height(32.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        DetailRow(label = "Para", value = viewModel.pixTargetName)
                        DetailRow(label = "CPF", value = viewModel.pixTargetCpf)
                        DetailRow(label = "Data", value = tx.formatDate())
                        DetailRow(label = "Hora", value = tx.formatTime())
                        DetailRow(label = "ID Transação", value = tx.id.take(20) + "...")
                        DetailRow(label = "Instituição", value = "Nubank S.A.")
                    }
                }
            }

            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                NuButton(
                    text = "Compartilhar Comprovante",
                    onClick = {
                        val sendIntent = Intent().apply {
                            action = Intent.ACTION_SEND
                            putExtra(Intent.EXTRA_TEXT, "Comprovante Pix: Enviado ${tx.formatRawAmount()} para ${viewModel.pixTargetName} via Nubank.")
                            type = "text/plain"
                        }
                        context.startActivity(Intent.createChooser(sendIntent, null))
                    },
                    modifier = Modifier.fillMaxWidth()
                )

                NuOutlineButton(
                    text = "Ir para Início",
                    onClick = { viewModel.navigateHome() },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

// COBRAR RECEIVE FLOW (CHOOSE AMOUNT)
@Composable
fun PixReceiveAmountScreen(viewModel: BankingViewModel) {
    BackHandler { viewModel.popScreen() }

    var inputStr by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        ScreenHeader(
            title = "Receber Pix",
            onBack = { viewModel.popScreen() }
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Qual valor você quer receber?",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Será gerado um QR Code e código Copia e Cola.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(32.dp))

                OutlinedTextField(
                    value = inputStr,
                    onValueChange = { inputStr = it; errorMsg = null },
                    label = { Text("Valor a cobrar") },
                    prefix = { Text("R$ ") },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NuPurple, cursorColor = NuPurple),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )

                if (errorMsg != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = errorMsg!!, color = NuRed, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }

            NuButton(
                text = "Gerar Código Pix",
                onClick = {
                    val floatVal = inputStr.replace(",", ".").toFloatOrNull()
                    if (floatVal == null || floatVal <= 0) {
                        errorMsg = "Digite um valor válido para cobrança."
                    } else {
                        val cents = (floatVal * 100f).toLong()
                        viewModel.generatePaymentRequest(cents)
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

// GENERATED QR CODE DISPLAY
@Composable
fun PixReceiveCodeScreen(viewModel: BankingViewModel) {
    BackHandler { viewModel.popScreen() }

    val clipboardManager = LocalClipboardManager.current
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        ScreenHeader(
            title = "Código de Cobrança",
            onBack = { viewModel.popScreen() }
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Tudo pronto! Apresente o código",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(16.dp))

                // Simulated QR Code Visual Box
                Box(
                    modifier = Modifier
                        .size(200.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.White)
                        .border(2.dp, NuPurple, RoundedCornerShape(12.dp))
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        // Drawing simple decorative grid dots resembling a QR Code
                        val size = this.size.width
                        val cells = 15
                        val cellSize = size / cells
                        for (r in 0 until cells) {
                            for (c in 0 until cells) {
                                if ((r == 0 && c < 4) || (r < 4 && c == 0) || (r == 3 && c < 4) || (r < 4 && c == 3) ||
                                    (r == 0 && c > cells - 5) || (r < 4 && c == cells - 1) || (r == 3 && c > cells - 5) ||
                                    (r == cells - 4 && c < 4) || (r > cells - 5 && c == 0) || (r == cells - 1 && c < 4) ||
                                    ((r + c) % 3 == 0 && r > 4 && r < cells - 4 && c > 4)
                                ) {
                                    drawRect(
                                        color = NuPurpleBg,
                                        topLeft = Offset(c * cellSize, r * cellSize),
                                        size = Size(cellSize, cellSize)
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = formatCentsToCurrency(viewModel.requestAmount),
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold,
                    color = NuPurple
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Aguardando pagamento...",
                    fontSize = 13.sp,
                    color = NuGreen,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                NuButton(
                    text = "Copiar Pix Copia e Cola",
                    onClick = {
                        clipboardManager.setText(AnnotatedString(viewModel.requestQrCodePayload))
                        Toast.makeText(context, "Código copiado para a área de transferência!", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.fillMaxWidth()
                )

                NuOutlineButton(
                    text = "Simular Recebimento (Pago)",
                    onClick = {
                        viewModel.simulateReceivingPayment()
                        Toast.makeText(context, "Simulação: Cliente Felipe Oliveira pagou sua cobrança!", Toast.LENGTH_LONG).show()
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

// ==========================================
// 4. PAYMENTS (BOLETO BARCODE FLOW)
// ==========================================
@Composable
fun PaymentsScreen(viewModel: BankingViewModel) {
    BackHandler { viewModel.popScreen() }

    var inputCode by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        ScreenHeader(
            title = "Pagamentos",
            onBack = { viewModel.popScreen() }
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Pagar com Boleto",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Digite o código de barras do seu boleto ou conta de consumo.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(24.dp))

                OutlinedTextField(
                    value = inputCode,
                    onValueChange = { inputCode = it; errorMsg = null },
                    label = { Text("Código de barras (apenas números)") },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NuPurple, cursorColor = NuPurple),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )

                if (errorMsg != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = errorMsg!!, color = NuRed, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(32.dp))

                // Simulated scanning shortcut
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { inputCode = "836100000018 485001381204 429184827365" },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = NuPurple)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(text = "Dica de Simulação", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text(text = "Toque aqui para colar um código de barras de conta de consumo válido.", fontSize = 11.sp)
                        }
                    }
                }
            }

            NuButton(
                text = "Confirmar Boleto",
                onClick = {
                    val codeClean = inputCode.replace(" ", "").replace("-", "")
                    if (codeClean.length < 10) {
                        errorMsg = "Código de barras inválido. Insira todos os dígitos."
                    } else {
                        viewModel.startBoletoFlow(codeClean) { ok, reason ->
                            if (!ok) {
                                errorMsg = reason
                            }
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

// CONFIRM BOLETO CHECKOUT DETAILS
@Composable
fun PaymentsConfirmScreen(viewModel: BankingViewModel) {
    BackHandler { viewModel.popScreen() }

    var inputPin by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        ScreenHeader(
            title = "Confirmar Pagamento",
            onBack = { viewModel.popScreen() }
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Revisar dados da conta",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(16.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        DetailRow(label = "Beneficiário", value = viewModel.paymentBeneficiary)
                        DetailRow(label = "Valor", value = formatCentsToCurrency(viewModel.paymentAmount))
                        DetailRow(label = "Vencimento", value = viewModel.paymentDueDate)
                        DetailRow(label = "Forma de pagamento", value = "Saldo de Conta do Nubank")
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                OutlinedTextField(
                    value = inputPin,
                    onValueChange = { inputPin = it; errorMsg = null },
                    label = { Text("PIN de confirmação (4 dígitos)") },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NuPurple, cursorColor = NuPurple),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                )

                if (errorMsg != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = errorMsg!!, color = NuRed, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }

            NuButton(
                text = "Pagar Agora",
                onClick = {
                    if (inputPin.length < 4) {
                        errorMsg = "PIN inválido."
                    } else {
                        viewModel.confirmBoletoPayment { ok, reason ->
                            if (!ok) {
                                errorMsg = reason
                            }
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

// BOLETO PAYMENT SUCCESS
@Composable
fun PaymentsSuccessScreen(viewModel: BankingViewModel) {
    BackHandler { viewModel.navigateHome() }
    val context = LocalContext.current
    val tx = viewModel.paymentSuccessTx ?: return

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        ScreenHeader(
            title = "Comprovante de Pagamento",
            onBack = { viewModel.navigateHome() }
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(NuGreenLight.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = NuGreen, modifier = Modifier.size(40.dp))
                }
                Spacer(modifier = Modifier.height(16.dp))
                Text(text = "Pagamento Concluído!", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = NuGreen)
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = formatCentsToCurrency(tx.amount), fontSize = 32.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)

                Spacer(modifier = Modifier.height(32.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        DetailRow(label = "Para", value = viewModel.paymentBeneficiary)
                        DetailRow(label = "Data de Liquidação", value = tx.formatDate())
                        DetailRow(label = "Código de Autenticação", value = tx.id)
                    }
                }
            }

            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                NuButton(
                    text = "Compartilhar Comprovante",
                    onClick = {
                        val shareIntent = Intent().apply {
                            action = Intent.ACTION_SEND
                            putExtra(Intent.EXTRA_TEXT, "Comprovante de pagamento de boleto Nubank: Liquidado R$ ${tx.formatRawAmount()} para ${viewModel.paymentBeneficiary}.")
                            type = "text/plain"
                        }
                        context.startActivity(Intent.createChooser(shareIntent, null))
                    },
                    modifier = Modifier.fillMaxWidth()
                )

                NuOutlineButton(
                    text = "Concluir",
                    onClick = { viewModel.navigateHome() },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

// ==========================================
// 5. CARDS (VIRTUAL & PHYSICAL MANAGEMENT)
// ==========================================
@Composable
fun CardsScreen(viewModel: BankingViewModel) {
    BackHandler { viewModel.popScreen() }

    val cards by viewModel.cards.collectAsState()
    val limitTotal by viewModel.creditLimit.collectAsState()
    val limitUsed by viewModel.creditUsed.collectAsState()
    val invoice by viewModel.currentInvoice.collectAsState()
    val hideValues by viewModel.hideBalances.collectAsState()

    val clipboardManager = LocalClipboardManager.current
    val context = LocalContext.current

    val limitAvailable = maxOf(0L, limitTotal - limitUsed)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        ScreenHeader(
            title = "Meus Cartões",
            onBack = { viewModel.popScreen() }
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Credit Progress Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp)
                    ) {
                        Text(text = "Limite de Crédito", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(text = "Limite Disponível", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    text = if (hideValues) "R$ •••••" else formatCentsToCurrency(limitAvailable),
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = NuGreen
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(text = "Limite Utilizado", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    text = if (hideValues) "R$ •••••" else formatCentsToCurrency(limitUsed),
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = NuRed
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Custom Limit Slider/Progress visual
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            val ratio = if (limitTotal > 0) limitUsed.toFloat() / limitTotal.toFloat() else 0f
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .fillMaxWidth(ratio)
                                    .background(NuPurple)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            NuOutlineButton(
                                text = "Ajustar Limite",
                                onClick = { viewModel.navigateTo(Screen.SECURITY) },
                                modifier = Modifier.weight(1.0f)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            NuButton(
                                text = "Pagar Fatura",
                                onClick = { viewModel.navigateTo(Screen.INVOICE) },
                                modifier = Modifier.weight(1.0f)
                            )
                        }
                    }
                }
            }

            // Cards Listing
            items(cards) { card ->
                val isBlocked = card.status == "BLOCKED"
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = if (isBlocked) MaterialTheme.colorScheme.surfaceVariant else NuPurpleBg),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (card.type == "PHYSICAL") "CARTÃO FÍSICO" else "CARTÃO VIRTUAL",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = if (isBlocked) Color.Gray else NuPurpleLight
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isBlocked) NuRed.copy(alpha = 0.15f) else NuGreen.copy(alpha = 0.15f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = if (isBlocked) "BLOQUEADO" else "ATIVO",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isBlocked) NuRed else NuGreen
                                )
                            }
                        }

                        Column {
                            Text(
                                text = card.number,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isBlocked) Color.DarkGray else Color.White
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = "Validade: ${card.expiry}", fontSize = 12.sp, color = Color.LightGray)
                                Text(text = "CVV: ${card.cvv}", fontSize = 12.sp, color = Color.LightGray)
                            }
                        }

                        Text(text = card.cardholder, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)

                        HorizontalDivider(color = Color.White.copy(alpha = 0.12f))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            IconButton(
                                onClick = {
                                    clipboardManager.setText(AnnotatedString(card.number.replace("•", "").trim()))
                                    Toast.makeText(context, "Número do cartão copiado!", Toast.LENGTH_SHORT).show()
                                },
                                enabled = !isBlocked,
                                modifier = Modifier.size(48.dp)
                            ) {
                                Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copiar", tint = if (isBlocked) Color.Gray else Color.White)
                            }

                            NuOutlineButton(
                                text = if (isBlocked) "Desbloquear" else "Bloquear",
                                onClick = { viewModel.toggleBlockCard(card.id) },
                                modifier = Modifier.width(140.dp)
                            )
                        }
                    }
                }
            }

            // Simulated Purchase Shortcut inside UI
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(text = "Simular Compra no Cartão", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text(text = "Toque nos botões abaixo para simular compras de teste na fatura.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            NuButton(
                                text = "Comprar R$ 86,90",
                                onClick = {
                                    viewModel.simulateCardPurchase(8690L, "Mercado Livre S.A.", TransactionCategory.SHOPPING) { ok, err ->
                                        if (ok) Toast.makeText(context, "Compra de R$ 86,90 autorizada!", Toast.LENGTH_SHORT).show()
                                        else Toast.makeText(context, err ?: "Erro ao autorizar", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier.weight(1.0f)
                            )
                            NuButton(
                                text = "Comprar R$ 1.550,00",
                                onClick = {
                                    viewModel.simulateCardPurchase(155000L, "Joalheria Premium", TransactionCategory.SHOPPING) { ok, err ->
                                        if (err == "SECURITY_CHALLENGE") {
                                            // Handled by VM fraud engine
                                        }
                                    }
                                },
                                modifier = Modifier.weight(1.0f)
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

// ==========================================
// 6. INVOICE (FATURA ACTUAL)
// ==========================================
@Composable
fun InvoiceScreen(viewModel: BankingViewModel) {
    BackHandler { viewModel.popScreen() }

    val invoice by viewModel.currentInvoice.collectAsState()
    val balance by viewModel.balance.collectAsState()
    val transactions by viewModel.transactions.collectAsState()
    val hideValues by viewModel.hideBalances.collectAsState()

    val context = LocalContext.current

    val creditCardTxs = remember(transactions) {
        transactions.filter { it.type == TransactionType.CREDIT_CARD }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        ScreenHeader(
            title = "Fatura Atual",
            onBack = { viewModel.popScreen() }
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize()
        ) {
            // Invoice Summary Banner
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "Fatura de Outubro", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (hideValues) "R$ •••••" else formatCentsToCurrency(invoice),
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Bold,
                            color = NuRed
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = "Fecha em 05 Out • Vence em 10 Out", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                        Spacer(modifier = Modifier.height(16.dp))

                        NuButton(
                            text = "Pagar Fatura com Saldo",
                            onClick = {
                                if (invoice <= 0L) {
                                    Toast.makeText(context, "Sua fatura já está zerada!", Toast.LENGTH_SHORT).show()
                                } else {
                                    viewModel.payCreditInvoice(invoice) { ok, err ->
                                        if (ok) Toast.makeText(context, "Fatura liquidada com sucesso!", Toast.LENGTH_SHORT).show()
                                        else Toast.makeText(context, err ?: "Erro ao pagar", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            enabled = invoice > 0,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            // Transactions Title
            item {
                Text(
                    text = "Lançamentos na fatura",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
                HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
            }

            // Purchases list
            if (creditCardTxs.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(48.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "Nenhum lançamento nesta fatura.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                    }
                }
            } else {
                items(creditCardTxs) { tx ->
                    TransactionRow(
                        transaction = tx,
                        hideValues = hideValues,
                        onClick = {
                            viewModel.selectedTransaction = tx
                            viewModel.navigateTo(Screen.TRANSACTION_DETAIL)
                        }
                    )
                    HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.padding(horizontal = 16.dp))
                }
            }
        }
    }
}

// ==========================================
// 7. SPENDING ANALYTICS (SEUS GASTOS)
// ==========================================
@Composable
fun SpendingAnalyticsScreen(viewModel: BankingViewModel) {
    BackHandler { viewModel.popScreen() }

    val transactions by viewModel.transactions.collectAsState()

    // Aggregate category expenses
    val foodSum = remember(transactions) { transactions.filter { it.category == TransactionCategory.FOOD && !it.isIncoming }.sumOf { it.amount } }
    val transportSum = remember(transactions) { transactions.filter { it.category == TransactionCategory.TRANSPORT && !it.isIncoming }.sumOf { it.amount } }
    val homeSum = remember(transactions) { transactions.filter { it.category == TransactionCategory.HOME && !it.isIncoming }.sumOf { it.amount } }
    val leisureSum = remember(transactions) { transactions.filter { it.category == TransactionCategory.LEISURE && !it.isIncoming }.sumOf { it.amount } }
    val shoppingSum = remember(transactions) { transactions.filter { it.category == TransactionCategory.SHOPPING && !it.isIncoming }.sumOf { it.amount } }

    val totalSpent = foodSum + transportSum + homeSum + leisureSum + shoppingSum

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        ScreenHeader(
            title = "Análise de Gastos",
            onBack = { viewModel.popScreen() }
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Seus gastos",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Resumo mensal categorizado de despesas",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Donut Chart Display
            item {
                SpendingDonutChart(
                    foodAmount = foodSum,
                    transportAmount = transportSum,
                    homeAmount = homeSum,
                    leisureAmount = leisureSum,
                    shoppingAmount = shoppingSum,
                    modifier = Modifier.padding(vertical = 16.dp)
                )
            }

            // Category list Breakdown
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        CategoryProgressRow(name = "Alimentação", amount = foodSum, total = totalSpent, color = NuRed)
                        CategoryProgressRow(name = "Transporte", amount = transportSum, total = totalSpent, color = NuPurple)
                        CategoryProgressRow(name = "Casa", amount = homeSum, total = totalSpent, color = NuBlue)
                        CategoryProgressRow(name = "Lazer", amount = leisureSum, total = totalSpent, color = Color(0xFFFF9900))
                        CategoryProgressRow(name = "Compras", amount = shoppingSum, total = totalSpent, color = Color(0xFFE040FB))
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
fun CategoryProgressRow(name: String, amount: Long, total: Long, color: Color) {
    val ratio = if (total > 0L) amount.toFloat() / total.toFloat() else 0f
    val percent = (ratio * 100f).toInt()

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(color))
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = name, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
            }
            Text(text = "${formatCentsToCurrency(amount)} ($percent%)", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
        }
        Spacer(modifier = Modifier.height(4.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(ratio)
                    .background(color)
            )
        }
    }
}

// ==========================================
// 8. INVESTMENTS (YIELD & BALANCES SCREEN)
// ==========================================
@Composable
fun InvestmentsScreen(viewModel: BankingViewModel) {
    BackHandler { viewModel.popScreen() }

    val investState by viewModel.investment.collectAsState()
    val hideValues by viewModel.hideBalances.collectAsState()

    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        ScreenHeader(
            title = "Investimentos",
            onBack = { viewModel.popScreen() }
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Patrimony Info
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = NuPurpleBg)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp)
                    ) {
                        Text(text = "Patrimônio Total", fontSize = 13.sp, color = Color.LightGray)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (hideValues) "R$ •••••" else investState.formatCurrency(investState.total),
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        
                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(text = "Rendimento no mês", fontSize = 11.sp, color = Color.LightGray)
                                Text(text = if (hideValues) "R$ ••" else "+ " + investState.formatCurrency(investState.monthlyReturn), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = NuGreenLight)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(text = "Rendimento acumulado", fontSize = 11.sp, color = Color.LightGray)
                                Text(text = if (hideValues) "R$ ••" else "+ " + investState.formatCurrency(investState.accumulatedReturn), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = NuGreenLight)
                            }
                        }
                    }
                }
            }

            // Products Header
            item {
                Text(
                    text = "Produtos de Investimento",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }

            // Products cards
            item {
                InvestmentProductRow(name = "Renda Fixa (CDI)", yield = "100% CDI", amount = investState.fixedIncome, hide = hideValues) {
                    Toast.makeText(context, "Resgate de investimento disponível sob liquidez diária.", Toast.LENGTH_SHORT).show()
                }
            }
            item {
                InvestmentProductRow(name = "Tesouro Direto", yield = "Selic + 0.15%", amount = investState.treasury, hide = hideValues) {
                    Toast.makeText(context, "Resgate solicitado enviado para liquidação D+1.", Toast.LENGTH_SHORT).show()
                }
            }
            item {
                InvestmentProductRow(name = "Ações & Fundos", yield = "Variável", amount = investState.stocks + investState.funds, hide = hideValues) {
                    Toast.makeText(context, "Mercado de ações oscilante. Investimento em renda variável.", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}

@Composable
fun InvestmentProductRow(name: String, yield: String, amount: Long, hide: Boolean, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(text = name, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                Text(text = "Rentabilidade: $yield", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(
                text = if (hide) "R$ •••••" else formatCentsToCurrency(amount),
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

// ==========================================
// 9. LOANS (PERSONAL SIMULATOR)
// ==========================================
@Composable
fun LoansScreen(viewModel: BankingViewModel) {
    BackHandler { viewModel.popScreen() }

    val loanState by viewModel.loan.collectAsState()
    val balance by viewModel.balance.collectAsState()
    val hideValues by viewModel.hideBalances.collectAsState()

    val context = LocalContext.current

    var selectedSimAmount by remember { mutableStateOf(500000L) } // default R$ 5.000,00
    var selectedInstallments by remember { mutableStateOf(12) }

    val monthlyRate = 4.85 // 4.85% ao mês
    val calculatedTotalCost = remember(selectedSimAmount, selectedInstallments) {
        (selectedSimAmount * (1.0 + (monthlyRate / 100.0) * selectedInstallments)).toLong()
    }
    val calculatedInstallment = calculatedTotalCost / selectedInstallments

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        ScreenHeader(
            title = "Empréstimos",
            onBack = { viewModel.popScreen() }
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Check active loan state
            if (loanState.status == "ACTIVE") {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = NuPurpleBg)
                    ) {
                        Column(modifier = Modifier.padding(20.dp)) {
                            Text(text = "Seu Empréstimo Ativo", fontSize = 13.sp, color = Color.LightGray)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = formatCentsToCurrency(loanState.requestedAmount),
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            DetailRow(label = "Parcelas", value = "${loanState.installments}x de ${formatCentsToCurrency(loanState.installmentAmount)}")
                            DetailRow(label = "Taxa", value = "${loanState.interestRate}% ao mês")
                            DetailRow(label = "Custo Total Contratado", value = formatCentsToCurrency(loanState.totalCost))
                        }
                    }
                }
            } else {
                item {
                    Text(
                        text = "Simular Empréstimo Pessoal",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "Ajuste o valor e o número de parcelas desejado abaixo:",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Slider Simulator Amount
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = "Quanto você precisa?", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(text = formatCentsToCurrency(selectedSimAmount), fontSize = 18.sp, fontWeight = FontWeight.Bold, color = NuPurple)
                            }

                            Slider(
                                value = selectedSimAmount.toFloat(),
                                onValueChange = { selectedSimAmount = ((it / 50000).toInt() * 50000L).coerceIn(100000L, 2000000L) },
                                valueRange = 100000f..2000000f, // R$ 1.000,00 to R$ 20.000,00
                                colors = SliderDefaults.colors(
                                    thumbColor = NuPurple,
                                    activeTrackColor = NuPurple,
                                    inactiveTrackColor = MaterialTheme.colorScheme.surfaceVariant
                                )
                            )
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(text = "R$ 1.000", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(text = "R$ 20.000", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }

                // Installments Row selector
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(text = "Em quantas parcelas deseja pagar?", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceEvenly
                            ) {
                                listOf(6, 12, 18, 24).forEach { inst ->
                                    val isSel = inst == selectedInstallments
                                    Box(
                                        modifier = Modifier
                                            .clip(CircleShape)
                                            .background(if (isSel) NuPurple else MaterialTheme.colorScheme.surfaceVariant)
                                            .clickable { selectedInstallments = inst }
                                            .padding(horizontal = 16.dp, vertical = 8.dp)
                                    ) {
                                        Text(text = "${inst}x", color = if (isSel) Color.White else MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }

                // Summary Cost Review
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(text = "Custo do Empréstimo", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            DetailRow(label = "Valor da Parcela", value = "${selectedInstallments}x de ${formatCentsToCurrency(calculatedInstallment)}")
                            DetailRow(label = "Taxa de Juros", value = "$monthlyRate% ao mês")
                            DetailRow(label = "Custo Total Financeiro", value = formatCentsToCurrency(calculatedTotalCost))
                        }
                    }
                }

                // Contract Action button
                item {
                    NuButton(
                        text = "Contratar Empréstimo",
                        onClick = {
                            viewModel.startLoanSimulation(selectedSimAmount, selectedInstallments)
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}

// LOAN CONTRACT CONFIRMATION DIALOG/SCREEN
@Composable
fun LoansConfirmScreen(viewModel: BankingViewModel) {
    BackHandler { viewModel.popScreen() }

    val requested = viewModel.loanRequestedSimulated
    val installments = viewModel.loanInstallmentsSimulated
    val rate = 4.85
    val totalCost = (requested * (1.0 + (rate / 100.0) * installments)).toLong()
    val instAmount = totalCost / installments

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        ScreenHeader(
            title = "Contrato de Empréstimo",
            onBack = { viewModel.popScreen() }
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(NuPurple.copy(alpha = 0.1f))
                        .align(Alignment.CenterHorizontally),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = NuPurple)
                }
                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Por favor, revise o contrato cuidadosamente.",
                    textAlign = TextAlign.Center,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(24.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        DetailRow(label = "Valor Liberado em Conta", value = formatCentsToCurrency(requested))
                        DetailRow(label = "Número de Parcelas", value = "${installments}x")
                        DetailRow(label = "Valor de cada Parcela", value = formatCentsToCurrency(instAmount))
                        DetailRow(label = "Taxa de juros efetiva", value = "$rate% a.m.")
                        DetailRow(label = "Custo Efetivo Total (CET)", value = formatCentsToCurrency(totalCost))
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Ao confirmar, o valor será depositado imediatamente na sua conta corrente e as parcelas debitadas mensalmente na data de vencimento.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 16.sp
                )
            }

            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                NuButton(
                    text = "Confirmar Contratação",
                    onClick = {
                        viewModel.confirmLoanContract()
                    },
                    modifier = Modifier.fillMaxWidth()
                )
                NuOutlineButton(
                    text = "Cancelar",
                    onClick = { viewModel.popScreen() },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

// ==========================================
// 10. NOTIFICATIONS CENTRE
// ==========================================
@Composable
fun NotificationsScreen(viewModel: BankingViewModel) {
    BackHandler { viewModel.popScreen() }

    val notifications by viewModel.notifications.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        ScreenHeader(
            title = "Notificações",
            onBack = { viewModel.popScreen() }
        )

        if (notifications.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(48.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(text = "Nenhuma notificação por aqui.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
            }
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(notifications) { notif ->
                    com.example.ui.components.NotificationRow(
                        notification = notif,
                        onClick = { viewModel.markNotificationAsRead(notif.id) }
                    )
                    HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
                }
            }
        }
    }
}

// ==========================================
// 11. SECURITY CENTRE
// ==========================================
@Composable
fun SecurityScreen(viewModel: BankingViewModel) {
    BackHandler { viewModel.popScreen() }

    val profile by viewModel.customer.collectAsState()
    val limitTotal by viewModel.creditLimit.collectAsState()

    val context = LocalContext.current
    var inputLimitStr by remember { mutableStateOf("") }
    var changeSuccess by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        ScreenHeader(
            title = "Segurança & Limites",
            onBack = { viewModel.popScreen() }
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // General Info Security status
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(text = "Proteção Ativa", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = NuPurple)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "Seu aplicativo está protegido pela criptografia de ponta-a-ponta do Nubank.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            // Adjustment limits form
            item {
                Text(text = "Ajustar Limite Diário de Crédito", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(text = "Limite diário atual: ${formatCentsToCurrency(limitTotal)}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = inputLimitStr,
                    onValueChange = { inputLimitStr = it; changeSuccess = false },
                    label = { Text("Novo limite desejado") },
                    prefix = { Text("R$ ") },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NuPurple, cursorColor = NuPurple),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )

                AnimatedVisibility(visible = changeSuccess) {
                    Text(text = "Limite atualizado com sucesso!", color = NuGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                Spacer(modifier = Modifier.height(12.dp))

                NuButton(
                    text = "Salvar Novo Limite",
                    onClick = {
                        val floatVal = inputLimitStr.replace(",", ".").toFloatOrNull()
                        if (floatVal == null || floatVal <= 0) {
                            Toast.makeText(context, "Insira um valor limite válido.", Toast.LENGTH_SHORT).show()
                        } else {
                            val cents = (floatVal * 100f).toLong()
                            viewModel.adjustLimit(cents)
                            changeSuccess = true
                            inputLimitStr = ""
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Biometrics status
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "Acesso por Biometria", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(text = "Impressão digital cadastrada habilitada.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(NuGreen.copy(alpha = 0.15f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(text = "ATIVO", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = NuGreen)
                        }
                    }
                }
            }

            // Connected Devices
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(text = "Dispositivos Autorizados", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "• Este smartphone (Smartphone Seguro)", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = NuPurple)
                        Text(text = "• Navegador Web Chrome OS (DeX)", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

// ==========================================
// 12. HELP CENTRE & SUPPORT CONVERSATIONAL CHAT
// ==========================================
@Composable
fun HelpScreen(viewModel: BankingViewModel) {
    BackHandler { viewModel.popScreen() }

    val context = LocalContext.current
    val helpTopics = listOf(
        "Como funciona o Pix?",
        "Status de limite e faturas",
        "Contratar empréstimos",
        "Rendimento de investimentos",
        "Como contestar uma compra?",
        "Segurança da conta"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        ScreenHeader(
            title = "Central de Ajuda",
            onBack = { viewModel.popScreen() }
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    text = "Como podemos ajudar você?",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            }

            items(helpTopics) { topic ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            viewModel.navigateTo(Screen.HELP_CHAT)
                            viewModel.sendSupportMessage("Preciso de ajuda com: $topic")
                        },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = topic, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, tint = NuPurple, modifier = Modifier.size(16.dp))
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))
                NuButton(
                    text = "Falar com Atendimento Virtual",
                    onClick = { viewModel.navigateTo(Screen.HELP_CHAT) },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

// CONVERSATIONAL CHAT WITH MANUAL KEYBOARD SIMULATOR
@Composable
fun HelpChatScreen(viewModel: BankingViewModel) {
    BackHandler { viewModel.popScreen() }

    val messages by viewModel.chatMessages.collectAsState()
    var inputTxt by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .navigationBarsPadding()
    ) {
        ScreenHeader(
            title = "Atendimento Virtual",
            onBack = { viewModel.popScreen() }
        )

        LazyColumn(
            modifier = Modifier
                .weight(1.0f)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(messages) { msg ->
                val isUser = msg.sender == "USER"
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                ) {
                    Box(
                        modifier = Modifier
                            .clip(
                                RoundedCornerShape(
                                    topStart = 16.dp,
                                    topEnd = 16.dp,
                                    bottomStart = if (isUser) 16.dp else 0.dp,
                                    bottomEnd = if (isUser) 0.dp else 16.dp
                                )
                            )
                            .background(if (isUser) NuPurple else MaterialTheme.colorScheme.surfaceVariant)
                            .padding(14.dp)
                            .widthIn(max = 280.dp)
                    ) {
                        Text(
                            text = msg.text,
                            fontSize = 14.sp,
                            color = if (isUser) Color.White else MaterialTheme.colorScheme.onSurface,
                            lineHeight = 18.sp
                        )
                    }
                }
            }
        }

        // Chat Input Row
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = inputTxt,
                    onValueChange = { inputTxt = it },
                    label = { Text("Mensagem...") },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NuPurple, cursorColor = NuPurple),
                    modifier = Modifier.weight(1.0f),
                    shape = RoundedCornerShape(20.dp)
                )

                Spacer(modifier = Modifier.width(8.dp))

                IconButton(
                    onClick = {
                        if (inputTxt.isNotBlank()) {
                            viewModel.sendSupportMessage(inputTxt)
                            inputTxt = ""
                        }
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(NuPurple),
                    enabled = inputTxt.isNotBlank()
                ) {
                    Icon(imageVector = Icons.Default.Send, contentDescription = "Enviar", tint = Color.White, modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}

// ==========================================
// 13. PROFILE SCREEN
// ==========================================
@Composable
fun ProfileScreen(viewModel: BankingViewModel) {
    BackHandler { viewModel.popScreen() }

    val customer by viewModel.customer.collectAsState()
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        ScreenHeader(
            title = "Meu Perfil",
            onBack = { viewModel.popScreen() }
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Spacer(modifier = Modifier.height(16.dp))
                // Profile Avatar Placeholder
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(NuPurple),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = customer.name.take(2).uppercase(),
                        fontWeight = FontWeight.Bold,
                        fontSize = 28.sp,
                        color = Color.White
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = customer.name,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = MaterialTheme.colorScheme.onBackground
                )

                Text(
                    text = "Cliente desde 2020",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Documents List Info
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(text = "Dados Pessoais", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = NuPurple)
                        DetailRow(label = "CPF", value = customer.cpf)
                        DetailRow(label = "Agência", value = customer.agency)
                        DetailRow(label = "Conta Corrente", value = customer.accountNumber)
                        DetailRow(label = "Banco", value = "0260 - Nu Pagamentos S.A.")
                    }
                }
            }

            // Simulated Reset state
            item {
                NuOutlineButton(
                    text = "Reiniciar Dados (Reset)",
                    onClick = {
                        viewModel.resetState()
                        Toast.makeText(context, "Dados restaurados ao padrão!", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Logout Action Button
            item {
                NuButton(
                    text = "Sair do Aplicativo",
                    onClick = { viewModel.logout() },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
}
