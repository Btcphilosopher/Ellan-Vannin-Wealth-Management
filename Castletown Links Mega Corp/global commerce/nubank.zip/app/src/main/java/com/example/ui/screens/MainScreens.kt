package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Pix
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.formatCentsToCurrency
import com.example.ui.components.NuButton
import com.example.ui.components.QuickActionItem
import com.example.ui.components.TransactionRow
import com.example.ui.theme.NuBlue
import com.example.ui.theme.NuGreen
import com.example.ui.theme.NuPurple
import com.example.ui.theme.NuPurpleBg
import com.example.ui.theme.NuPurpleLight
import com.example.ui.theme.NuRed
import com.example.ui.viewmodel.BankingViewModel
import com.example.ui.viewmodel.Screen
import androidx.compose.material.icons.automirrored.filled.Send

// ==========================================
// A. LOGIN SCREEN
// ==========================================
@Composable
fun LoginScreen(viewModel: BankingViewModel) {
    var cpfInput by remember { mutableStateOf("384.921.408-42") }
    var pinInput by remember { mutableStateOf("") }
    var loginError by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NuPurpleBg)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Upper logo and greeting
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(top = 48.dp)
        ) {
            // Nu Purple stylized logo placeholder
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "nu",
                    fontSize = 44.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Seu dinheiro, simples.",
                color = Color.White.copy(alpha = 0.8f),
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold
            )
        }

        // Credentials input form
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Olá, João Martins",
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Start
            )

            OutlinedTextField(
                value = cpfInput,
                onValueChange = { cpfInput = it },
                label = { Text("CPF", color = Color.White.copy(alpha = 0.7f)) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color.White,
                    unfocusedBorderColor = Color.White.copy(alpha = 0.5f),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedLabelColor = Color.White,
                    cursorColor = Color.White
                ),
                modifier = Modifier.fillMaxWidth().testTag("cpf_input"),
                shape = RoundedCornerShape(8.dp),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )

            OutlinedTextField(
                value = pinInput,
                onValueChange = { pinInput = it },
                label = { Text("Senha PIN (4 dígitos)", color = Color.White.copy(alpha = 0.7f)) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color.White,
                    unfocusedBorderColor = Color.White.copy(alpha = 0.5f),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedLabelColor = Color.White,
                    cursorColor = Color.White
                ),
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth().testTag("pin_input"),
                shape = RoundedCornerShape(8.dp),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
            )

            if (loginError != null) {
                Text(
                    text = loginError!!,
                    color = Color.Red,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // Action Buttons
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            NuButton(
                text = "Entrar",
                onClick = {
                    if (pinInput.isBlank()) {
                        loginError = "Digite seu PIN de 4 dígitos."
                    } else {
                        viewModel.login(pinInput) { ok ->
                            if (!ok) loginError = "PIN inválido. Tente novamente."
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                testTag = "login_submit_button"
            )

            // Biometric quick access row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        viewModel.login("1234") { ok ->
                            if (ok) Toast.makeText(context, "Acesso biométrico autorizado!", Toast.LENGTH_SHORT).show()
                        }
                    }
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.LockOpen,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Entrar com biometria",
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

// ==========================================
// B. HOME MAIN SCREEN
// ==========================================
@Composable
fun HomeScreen(viewModel: BankingViewModel) {
    val customer by viewModel.customer.collectAsState()
    val balance by viewModel.balance.collectAsState()
    val limitAvailable by viewModel.creditLimit.collectAsState()
    val creditUsed by viewModel.creditUsed.collectAsState()
    val currentInvoice by viewModel.currentInvoice.collectAsState()
    val transactions by viewModel.transactions.collectAsState()
    val notifications by viewModel.notifications.collectAsState()
    val hideValues by viewModel.hideBalances.collectAsState()
    val isOffline by viewModel.isOffline.collectAsState()

    val context = LocalContext.current
    val hasUnreadNotif = remember(notifications) { notifications.any { !it.isRead } }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // 1. Header Greeting Bar (Nu Purple Background Header)
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(NuPurple)
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 20.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Avatar profile button
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.2f))
                                .clickable { viewModel.navigateTo(Screen.PROFILE) },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = "Meu Perfil",
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        // Right icons (Visibility, Help, Notifications)
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { viewModel.toggleHideBalances() }) {
                                Icon(
                                    imageVector = if (hideValues) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = "Ocultar Valores",
                                    tint = Color.White
                                )
                            }
                            IconButton(onClick = { viewModel.navigateTo(Screen.HELP) }) {
                                Icon(
                                    imageVector = Icons.Default.HelpOutline,
                                    contentDescription = "Ajuda",
                                    tint = Color.White
                                )
                            }

                            // Notification with unread dot indicator
                            IconButton(onClick = { viewModel.navigateTo(Screen.NOTIFICATIONS) }) {
                                if (hasUnreadNotif) {
                                    Icon(
                                        imageVector = Icons.Default.NotificationsActive,
                                        contentDescription = "Notificações",
                                        tint = Color.White
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.Notifications,
                                        contentDescription = "Notificações",
                                        tint = Color.White
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Text(
                        text = "Olá, ${customer.name}",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Offline Network Connection banner
        if (isOffline) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(NuRed)
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Sem conexão • Algumas operações Pix/Pagamento indisponíveis",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // 2. Conta Card (Balance block)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp, start = 16.dp, end = 16.dp)
                    .clickable { viewModel.navigateTo(Screen.ACCOUNT) },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Conta",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Icon(
                            imageVector = Icons.Default.Person, // small arrow
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (hideValues) "R$ •••••" else formatCentsToCurrency(balance),
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        // 3. Horizontal Quick Action Row
        item {
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp, horizontal = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                item {
                    QuickActionItem(
                        icon = Icons.Default.Pix,
                        label = "Pix",
                        onClick = { viewModel.navigateTo(Screen.PIX) },
                        testTag = "quick_pix_action"
                    )
                }
                item {
                    QuickActionItem(
                        icon = Icons.Default.ReceiptLong,
                        label = "Pagar",
                        onClick = { viewModel.navigateTo(Screen.PAYMENTS) },
                        testTag = "quick_pay_action"
                    )
                }
                item {
                    QuickActionItem(
                        icon = Icons.AutoMirrored.Filled.Send,
                        label = "Transferir",
                        onClick = { viewModel.navigateTo(Screen.PIX) }
                    )
                }
                item {
                    QuickActionItem(
                        icon = Icons.Default.CreditCard,
                        label = "Cartões",
                        onClick = { viewModel.navigateTo(Screen.CARDS) },
                        testTag = "quick_cards_action"
                    )
                }
                item {
                    QuickActionItem(
                        icon = Icons.Default.Analytics,
                        label = "Gastos",
                        onClick = { viewModel.navigateTo(Screen.SPENDING_ANALYTICS) }
                    )
                }
                item {
                    QuickActionItem(
                        icon = Icons.Default.TrendingUp,
                        label = "Investir",
                        onClick = { viewModel.navigateTo(Screen.INVESTMENTS) }
                    )
                }
                item {
                    QuickActionItem(
                        icon = Icons.Default.MonetizationOn,
                        label = "Empréstimos",
                        onClick = { viewModel.navigateTo(Screen.LOANS) }
                    )
                }
            }
        }

        // 4. Meus Cartões shortcut bar
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .clickable { viewModel.navigateTo(Screen.CARDS) },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.CreditCard,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Text(
                        text = "Meus cartões",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        // 5. Credit Card Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp, start = 16.dp, end = 16.dp)
                    .clickable { viewModel.navigateTo(Screen.INVOICE) },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Cartão de crédito",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Fatura atual",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = if (hideValues) "R$ •••••" else formatCentsToCurrency(currentInvoice),
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = NuRed
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Limite disponível: " + if (hideValues) "R$ •••••" else formatCentsToCurrency(maxOf(0L, limitAvailable - creditUsed)),
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // 6. Security Center Banner (Demonstration simulation option)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp, start = 16.dp, end = 16.dp)
                    .clickable { viewModel.navigateTo(Screen.SECURITY) },
                colors = CardDefaults.cardColors(containerColor = NuPurpleBg.copy(alpha = 0.05f))
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = null,
                        tint = NuPurple
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(
                            text = "Modo de Segurança",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "Ajustar limites de transação e gerenciar conexões.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // 7. Recent Transactions section
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 24.dp, start = 16.dp, end = 16.dp, bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Últimas movimentações",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Ver tudo",
                    color = NuPurple,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { viewModel.navigateTo(Screen.ACCOUNT) }
                )
            }
        }

        // Show top 3 recent transactions
        val recentTxs = transactions.take(3)
        if (recentTxs.isEmpty()) {
            item {
                Text(
                    text = "Nenhuma transação registrada.",
                    color = Color.Gray,
                    modifier = Modifier.padding(16.dp),
                    fontSize = 13.sp
                )
            }
        } else {
            items(recentTxs) { tx ->
                TransactionRow(
                    transaction = tx,
                    hideValues = hideValues,
                    onClick = {
                        viewModel.selectedTransaction = tx
                        viewModel.navigateTo(Screen.TRANSACTION_DETAIL)
                    }
                )
            }
        }

        // Bottom space spacer
        item {
            Spacer(modifier = Modifier.height(48.dp))
        }
    }
}
