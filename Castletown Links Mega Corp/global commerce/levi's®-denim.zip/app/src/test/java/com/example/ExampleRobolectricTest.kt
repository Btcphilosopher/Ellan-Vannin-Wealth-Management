package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.core.model.FitEngine
import com.example.core.model.RepairStatus
import com.example.core.model.RiseType
import com.example.core.model.StretchType
import com.example.core.model.UserFitInput
import com.example.core.repository.MembershipRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context verify app name`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("LEVI'S®", appName)
    }

    @Test
    fun `test FitEngine recommendations returns 501 high score for straight mid rise input`() {
        val input = UserFitInput(
            categoryGender = "Men",
            waistInches = 32,
            inseamInches = 32,
            preferredRise = RiseType.MID,
            preferredSilhouette = "Straight",
            desiredLooseness = "Regular",
            stretchPreference = StretchType.NON_STRETCH,
            currentFaveFit = "501 Original"
        )

        val recommendations = FitEngine.calculateRecommendations(input)

        assertTrue(recommendations.isNotEmpty())
        val topRecommendation = recommendations.first()
        assertNotNull(topRecommendation)
        assertTrue(topRecommendation.fitScore >= 85)
    }

    @Test
    fun `test MembershipRepository points conversion logic`() {
        val repo = MembershipRepository()
        val points = repo.calculatePointsForSpend( spendAmount = 100.0, conversionRate = 100)
        assertEquals(10000, points)

        val discount = repo.calculateDiscountFromPoints(points = 2840, pointsPerUnit = 1000, valuePerUnit = 10.0)
        assertEquals(20.0, discount, 0.01)
    }

    @Test
    fun `test RepairStatus state machine transitions`() {
        val statuses = RepairStatus.entries.toTypedArray()
        assertEquals(RepairStatus.SUBMITTED, statuses[0])
        assertEquals(RepairStatus.ASSESSED, statuses[1])
        assertEquals(RepairStatus.QUOTED, statuses[2])
        assertEquals(RepairStatus.COLLECTED, statuses[statuses.size - 1])
    }
}
