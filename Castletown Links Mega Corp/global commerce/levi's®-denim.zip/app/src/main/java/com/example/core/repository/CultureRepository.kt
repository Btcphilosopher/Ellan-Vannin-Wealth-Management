package com.example.core.repository

import com.example.core.model.ArchiveEvent
import com.example.core.model.EditorialStory
import com.example.core.model.StyleOutfit

class CultureRepository {

    fun getEditorialStories(): List<EditorialStory> = listOf(
        EditorialStory(
            id = "story_501_history",
            title = "The Evolution of the 501® Jean",
            subtitle = "From copper rivets in 1873 to global culture icon.",
            author = "Levi's® Archival Historian",
            date = "OCTOBER 2026",
            category = "DENIM HERITAGE",
            imageUrl = "hero_501_banner_1793051553057.jpg",
            bodyText = "On May 20, 1873, Levi Strauss and Jacob Davis were granted a US patent for placing copper rivets on work trousers. That day marks the official birth of the blue jean. Over 150 years later, the 501® remains the single most influential piece of clothing in human history.",
            featuredProductIds = listOf("jean_501_dark", "jean_501_medium")
        ),
        EditorialStory(
            id = "story_tailor_art",
            title = "Crafting Character: Inside the Regent St Tailor Shop",
            subtitle = "Chainstitch embroidery, sashiko repairs, and custom distressing.",
            author = "Master Tailor Marcus Vance",
            date = "OCTOBER 2026",
            category = "TAILOR & REPAIR",
            imageUrl = "tailor_shop_hero_1793051566416.jpg",
            bodyText = "Every pair of Levi's tells a story through fades, creases, and repairs. Our Tailor Shops preserve that character while customising garments to fit your evolving life.",
            featuredProductIds = listOf("trucker_jacket_orig")
        ),
        EditorialStory(
            id = "story_skate_music",
            title = "Raw Denim & Subculture Soundtracks",
            subtitle = "How 90s skateboarding and punk rock made loose denim essential.",
            author = "Cultural Editor Maya Lin",
            date = "SEPTEMBER 2026",
            category = "MUSIC & CULTURE",
            imageUrl = "hero_501_banner_1793051553057.jpg",
            bodyText = "From San Francisco's Embarcadero to London's underground music venues, denim has always provided the uniform for rebellion and creative expression.",
            featuredProductIds = listOf("jean_568_loose")
        )
    )

    fun getArchiveTimeline(): List<ArchiveEvent> = listOf(
        ArchiveEvent(
            year = "1873",
            title = "The Patent Granted",
            era = "Gold Rush Workwear",
            summary = "Patent No. 139,121 granted for copper-riveted waist overalls. The Two Horse Pull leather patch is introduced.",
            iconicFitCode = "501",
            imageUrl = "hero_501_banner_1793051553057.jpg"
        ),
        ArchiveEvent(
            year = "1934",
            title = "First Lady Levi's® Jeans",
            era = "Pioneer Women",
            summary = "Levi's creates Lot 701, the world's first blue jean designed specifically for women.",
            iconicFitCode = "701",
            imageUrl = "hero_501_banner_1793051553057.jpg"
        ),
        ArchiveEvent(
            year = "1936",
            title = "The Red Tab™ Born",
            era = "Brand Identity",
            summary = "The tiny red cloth tab with LEVI'S embroidered in white capital letters is sewn onto the right back pocket.",
            iconicFitCode = "501",
            imageUrl = "hero_501_banner_1793051553057.jpg"
        ),
        ArchiveEvent(
            year = "1967",
            title = "Summer of Love & 505™",
            era = "Counterculture Revolution",
            summary = "The 505™ Regular Fit zip-fly jean and Type III Trucker Jacket become the uniform of Woodstock and San Francisco.",
            iconicFitCode = "505",
            imageUrl = "hero_501_banner_1793051553057.jpg"
        ),
        ArchiveEvent(
            year = "1990s",
            title = "Skate & Loose Denim",
            era = "Streetwear & Grunge",
            summary = "Slouched 568™ and baggy 569™ denim dominate street culture, hip-hop, and skateboarding.",
            iconicFitCode = "568",
            imageUrl = "hero_501_banner_1793051553057.jpg"
        ),
        ArchiveEvent(
            year = "2026",
            title = "Denim Operating System",
            era = "Modern Digital Ecosystem",
            summary = "Levi's launches complete circular denim architecture: Discover, Customise, Wear, Repair, and Archive.",
            iconicFitCode = "501",
            imageUrl = "hero_501_banner_1793051553057.jpg"
        )
    )

    fun getStyleOutfits(): List<StyleOutfit> = listOf(
        StyleOutfit(
            id = "style_california_workwear",
            name = "California Workwear",
            occasion = "Casual Weekend",
            era = "Modern Workwear",
            subculture = "San Francisco Heritage",
            productIds = listOf("jean_501_dark", "trucker_jacket_orig", "tee_housemark_logo"),
            imageUrl = "hero_501_banner_1793051553057.jpg",
            description = "Raw 501® Original Jeans paired with classic Rigid Trucker Jacket and white organic cotton tee."
        ),
        StyleOutfit(
            id = "style_90s_skate",
            name = "90s Loose Skate",
            occasion = "Streetwear",
            era = "1990s",
            subculture = "Skate & Music",
            productIds = listOf("jean_568_loose", "tee_housemark_logo"),
            imageUrl = "hero_501_banner_1793051553057.jpg",
            description = "Loose 568™ vintage wash denim stacked over sneakers with an oversized boxy t-shirt."
        ),
        StyleOutfit(
            id = "style_tailored_smart",
            name = "Tailored Selvedge Smart",
            occasion = "Evening / Creative Office",
            era = "Contemporary",
            subculture = "Minimalist",
            productIds = listOf("jean_512_taper", "shirt_barstow_western"),
            imageUrl = "hero_501_banner_1793051553057.jpg",
            description = "Sharp 512™ Slim Taper in dark indigo with tucked Barstow Western denim shirt and leather boots."
        )
    )
}
