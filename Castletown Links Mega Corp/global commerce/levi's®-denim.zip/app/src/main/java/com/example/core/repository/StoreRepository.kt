package com.example.core.repository

import com.example.core.model.StoreLocation

class StoreRepository {

    private val stores = listOf(
        StoreLocation(
            id = "store_regent_st",
            name = "Levi's® Store Regent Street & Tailor Shop",
            address = "174 Regent St, Mayfair",
            city = "London, W1B 5PH",
            distanceKm = 1.2,
            openingHours = "10:00 AM - 8:00 PM",
            phone = "+44 20 7287 5001",
            hasTailorShop = true,
            hasRepairStation = true,
            imageUrl = "tailor_shop_hero_1793051566416.jpg"
        ),
        StoreLocation(
            id = "store_covent_garden",
            name = "Levi's® Covent Garden",
            address = "18 Long Acre",
            city = "London, WC2E 9LH",
            distanceKm = 2.4,
            openingHours = "10:00 AM - 7:30 PM",
            phone = "+44 20 7836 2901",
            hasTailorShop = true,
            hasRepairStation = true,
            imageUrl = "tailor_shop_hero_1793051566416.jpg"
        ),
        StoreLocation(
            id = "store_sf_flagship",
            name = "Levi's® San Francisco Flagship",
            address = "815 Market St",
            city = "San Francisco, CA 94103",
            distanceKm = 0.8,
            openingHours = "10:00 AM - 9:00 PM",
            phone = "+1 415 501 5010",
            hasTailorShop = true,
            hasRepairStation = true,
            imageUrl = "tailor_shop_hero_1793051566416.jpg"
        ),
        StoreLocation(
            id = "store_ny_soho",
            name = "Levi's® SoHo Tailor Shop",
            address = "495 Broadway",
            city = "New York, NY 10012",
            distanceKm = 3.5,
            openingHours = "11:00 AM - 8:00 PM",
            phone = "+1 212 226 5010",
            hasTailorShop = true,
            hasRepairStation = true,
            imageUrl = "tailor_shop_hero_1793051566416.jpg"
        )
    )

    fun getStores(): List<StoreLocation> = stores

    fun getStoreById(id: String): StoreLocation? = stores.find { it.id == id }

    fun lookupBarcode(barcode: String): BarcodeResult {
        // Barcode resolver (EAN/UPC mapping to 501 or scanned garment)
        return when {
            barcode.endsWith("501") || barcode.contains("501") -> BarcodeResult(
                productId = "jean_501_dark",
                title = "501® Original Jeans (Dark Indigo)",
                fitCode = "501",
                price = "£100.00",
                stockStatus = "In Stock (Sizes 28-38 available)"
            )
            barcode.endsWith("511") || barcode.contains("511") -> BarcodeResult(
                productId = "jean_511_slim",
                title = "511™ Slim Fit Jeans",
                fitCode = "511",
                price = "£90.00",
                stockStatus = "In Stock (4 pairs remaining)"
            )
            else -> BarcodeResult(
                productId = "jean_501_medium",
                title = "501® Original Jeans (Stonewash)",
                fitCode = "501",
                price = "£95.00",
                stockStatus = "In Stock at Regent St Tailor Shop"
            )
        }
    }
}

data class BarcodeResult(
    val productId: String,
    val title: String,
    val fitCode: String,
    val price: String,
    val stockStatus: String
)
