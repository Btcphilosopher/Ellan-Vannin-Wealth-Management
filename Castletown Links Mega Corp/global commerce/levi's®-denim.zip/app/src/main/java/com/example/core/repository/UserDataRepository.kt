package com.example.core.repository

import com.example.core.database.AppointmentDao
import com.example.core.database.AppointmentEntity
import com.example.core.database.CartDao
import com.example.core.database.CartEntity
import com.example.core.database.FitProfileDao
import com.example.core.database.FitProfileEntity
import com.example.core.database.RepairDao
import com.example.core.database.RepairEntity
import com.example.core.database.WardrobeDao
import com.example.core.database.WardrobeEntity
import com.example.core.database.WishlistDao
import com.example.core.database.WishlistEntity
import com.example.core.model.Appointment
import com.example.core.model.CartItem
import com.example.core.model.RepairRequest
import com.example.core.model.RepairStatus
import com.example.core.model.UserFitInput
import com.example.core.model.WardrobeItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID

class UserDataRepository(
    private val cartDao: CartDao,
    private val wishlistDao: WishlistDao,
    private val wardrobeDao: WardrobeDao,
    private val repairDao: RepairDao,
    private val appointmentDao: AppointmentDao,
    private val fitProfileDao: FitProfileDao,
    private val denimRepository: DenimRepository
) {

    // CART
    val cartItems: Flow<List<CartItem>> = cartDao.getCartItems().map { entities ->
        entities.mapNotNull { entity ->
            val product = denimRepository.getProductById(entity.productId)
            if (product != null) {
                CartItem(
                    id = entity.id,
                    product = product,
                    waist = entity.waist,
                    length = entity.length,
                    quantity = entity.quantity
                )
            } else null
        }
    }

    suspend fun addToCart(productId: String, waist: Int, length: Int, quantity: Int = 1) {
        val cartId = "cart_${productId}_${waist}_${length}"
        val entity = CartEntity(
            id = cartId,
            productId = productId,
            waist = waist,
            length = length,
            quantity = quantity
        )
        cartDao.insertOrUpdateItem(entity)
    }

    suspend fun removeFromCart(cartId: String) {
        cartDao.deleteCartItem(cartId)
    }

    suspend fun clearCart() {
        cartDao.clearCart()
    }

    // WISHLIST
    fun isWishlisted(productId: String): Flow<Boolean> = wishlistDao.isWishlisted(productId)

    val wishlistedProducts = wishlistDao.getWishlistItems().map { entities ->
        entities.mapNotNull { entity ->
            denimRepository.getProductById(entity.productId)
        }
    }

    suspend fun toggleWishlist(productId: String, currentIsWishlisted: Boolean) {
        if (currentIsWishlisted) {
            wishlistDao.removeFromWishlist(productId)
        } else {
            wishlistDao.addToWishlist(WishlistEntity(productId = productId))
        }
    }

    // WARDROBE
    val wardrobeItems: Flow<List<WardrobeItem>> = wardrobeDao.getWardrobeItems().map { entities ->
        entities.map { entity ->
            WardrobeItem(
                id = entity.id,
                productId = entity.productId,
                productName = entity.productName,
                fitCode = entity.fitCode,
                sizeLabel = entity.sizeLabel,
                washName = entity.washName,
                purchaseDate = entity.purchaseDate,
                ageMonths = entity.ageMonths,
                wearCount = entity.wearCount,
                repairCount = entity.repairCount,
                washCount = entity.washCount,
                photoUrl = entity.photoUrl,
                notes = entity.notes
            )
        }
    }

    suspend fun addWardrobeItem(item: WardrobeItem) {
        val entity = WardrobeEntity(
            id = item.id,
            productId = item.productId,
            productName = item.productName,
            fitCode = item.fitCode,
            sizeLabel = item.sizeLabel,
            washName = item.washName,
            purchaseDate = item.purchaseDate,
            ageMonths = item.ageMonths,
            wearCount = item.wearCount,
            repairCount = item.repairCount,
            washCount = item.washCount,
            photoUrl = item.photoUrl,
            notes = item.notes
        )
        wardrobeDao.insertWardrobeItem(entity)
    }

    suspend fun incrementWear(id: String) = wardrobeDao.incrementWear(id)
    suspend fun incrementWash(id: String) = wardrobeDao.incrementWash(id)

    // REPAIRS
    val repairRequests: Flow<List<RepairRequest>> = repairDao.getRepairRequests().map { entities ->
        entities.map { entity ->
            RepairRequest(
                id = entity.id,
                garmentName = entity.garmentName,
                purchaseDate = entity.purchaseDate,
                damageType = entity.damageType,
                photoUrl = entity.photoUrl,
                serviceRequested = entity.serviceRequested,
                storeName = entity.storeName,
                status = runCatching { RepairStatus.valueOf(entity.status) }.getOrDefault(RepairStatus.SUBMITTED),
                estimatedCompletionDate = entity.estimatedCompletionDate,
                quotedPrice = entity.quotedPrice,
                notes = entity.notes
            )
        }
    }

    suspend fun submitRepairRequest(request: RepairRequest) {
        val entity = RepairEntity(
            id = request.id,
            garmentName = request.garmentName,
            purchaseDate = request.purchaseDate,
            damageType = request.damageType,
            photoUrl = request.photoUrl,
            serviceRequested = request.serviceRequested,
            storeName = request.storeName,
            status = request.status.name,
            estimatedCompletionDate = request.estimatedCompletionDate,
            quotedPrice = request.quotedPrice,
            notes = request.notes
        )
        repairDao.insertRepairRequest(entity)
    }

    suspend fun updateRepairStatus(id: String, status: RepairStatus) {
        repairDao.updateRepairStatus(id, status.name)
    }

    // APPOINTMENTS
    val appointments: Flow<List<Appointment>> = appointmentDao.getAppointments().map { entities ->
        entities.map { entity ->
            Appointment(
                id = entity.id,
                storeName = entity.storeName,
                serviceName = entity.serviceName,
                date = entity.date,
                timeSlot = entity.timeSlot,
                garmentName = entity.garmentName,
                status = entity.status
            )
        }
    }

    suspend fun bookAppointment(appointment: Appointment) {
        val entity = AppointmentEntity(
            id = appointment.id,
            storeName = appointment.storeName,
            serviceName = appointment.serviceName,
            date = appointment.date,
            timeSlot = appointment.timeSlot,
            garmentName = appointment.garmentName,
            status = appointment.status
        )
        appointmentDao.insertAppointment(entity)
    }

    // FIT PROFILE
    val savedFitProfile: Flow<UserFitInput?> = fitProfileDao.getFitProfile().map { entity ->
        entity?.let {
            UserFitInput(
                categoryGender = it.categoryGender,
                heightCm = it.heightCm,
                waistInches = it.waistInches,
                inseamInches = it.inseamInches,
                currentFaveFit = it.currentFaveFit,
                desiredLooseness = it.desiredLooseness,
                typicalFootwear = it.typicalFootwear,
                stylePreference = it.stylePreference
            )
        }
    }

    suspend fun saveFitProfile(profile: UserFitInput) {
        val entity = FitProfileEntity(
            id = 1,
            categoryGender = profile.categoryGender,
            heightCm = profile.heightCm,
            waistInches = profile.waistInches,
            inseamInches = profile.inseamInches,
            preferredRise = profile.preferredRise.name,
            preferredLeg = profile.preferredLeg.name,
            preferredSilhouette = profile.preferredSilhouette,
            currentFaveFit = profile.currentFaveFit,
            desiredLooseness = profile.desiredLooseness,
            stretchPreference = profile.stretchPreference.name,
            typicalFootwear = profile.typicalFootwear,
            stylePreference = profile.stylePreference
        )
        fitProfileDao.saveFitProfile(entity)
    }
}
