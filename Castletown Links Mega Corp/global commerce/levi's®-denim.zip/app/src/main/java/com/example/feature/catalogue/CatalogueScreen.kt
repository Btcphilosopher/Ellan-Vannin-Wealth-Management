package com.example.feature.catalogue

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.core.designsystem.DeepIndigo
import com.example.core.designsystem.DenimBlue
import com.example.core.designsystem.FitCodePatch
import com.example.core.designsystem.LevisRed
import com.example.core.designsystem.LevisRedLight
import com.example.core.designsystem.OffWhite
import com.example.core.designsystem.PureWhite
import com.example.core.designsystem.RawDenim
import com.example.core.model.Product
import com.example.core.model.ProductCategory

@Composable
fun CatalogueScreen(
    products: List<Product>,
    onProductClick: (String) -> Unit,
    onSearchQueryChange: (String) -> Unit,
    initialQuery: String = ""
) {
    var selectedCategoryIndex by remember { mutableIntStateOf(0) }
    var searchQuery by remember { mutableStateOf(initialQuery) }
    var selectedFitFilter by remember { mutableStateOf<String?>(null) }

    val categories = listOf("ALL DENIM") + ProductCategory.entries.map { it.displayName }
    val fitFilters = listOf("501", "505", "511", "512", "514", "502", "568", "569", "555")

    val filteredProducts = products.filter { product ->
        val matchesCategory = if (selectedCategoryIndex == 0) true
        else product.category.displayName == categories[selectedCategoryIndex]

        val matchesFit = if (selectedFitFilter == null) true
        else product.fitCode == selectedFitFilter

        val matchesQuery = if (searchQuery.isBlank()) true
        else product.title.contains(searchQuery, ignoreCase = true) ||
                product.fitCode.contains(searchQuery, ignoreCase = true) ||
                product.subtitle.contains(searchQuery, ignoreCase = true)

        matchesCategory && matchesFit && matchesQuery
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepIndigo)
    ) {
        // Search Bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = {
                    searchQuery = it
                    onSearchQueryChange(it)
                },
                placeholder = { Text("Search 501, Trucker, Black Denim...", color = OffWhite.copy(alpha = 0.5f)) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = OffWhite) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = DenimBlue,
                    unfocusedContainerColor = DenimBlue,
                    focusedBorderColor = LevisRed,
                    unfocusedBorderColor = DenimBlue,
                    focusedTextColor = PureWhite,
                    unfocusedTextColor = PureWhite
                ),
                shape = RoundedCornerShape(8.dp)
            )
        }

        // Category Tabs
        ScrollableTabRow(
            selectedTabIndex = selectedCategoryIndex,
            containerColor = DeepIndigo,
            contentColor = PureWhite,
            edgePadding = 16.dp,
            indicator = { tabPositions ->
                if (selectedCategoryIndex < tabPositions.size) {
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedCategoryIndex]),
                        color = LevisRed
                    )
                }
            }
        ) {
            categories.forEachIndexed { index, title ->
                Tab(
                    selected = selectedCategoryIndex == index,
                    onClick = { selectedCategoryIndex = index },
                    text = {
                        Text(
                            text = title.uppercase(),
                            fontWeight = if (selectedCategoryIndex == index) FontWeight.Black else FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                )
            }
        }

        // Fit Chips Filter
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                FilterChip(
                    selected = selectedFitFilter == null,
                    onClick = { selectedFitFilter = null },
                    label = { Text("ALL FITS") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = LevisRed,
                        selectedLabelColor = PureWhite,
                        containerColor = DenimBlue,
                        labelColor = OffWhite
                    )
                )
            }
            items(fitFilters) { fit ->
                FilterChip(
                    selected = selectedFitFilter == fit,
                    onClick = { selectedFitFilter = if (selectedFitFilter == fit) null else fit },
                    label = { Text("LOT $fit") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = LevisRed,
                        selectedLabelColor = PureWhite,
                        containerColor = DenimBlue,
                        labelColor = OffWhite
                    )
                )
            }
        }

        // Catalogue Grid
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(filteredProducts) { product ->
                CatalogueProductGridItem(
                    product = product,
                    onClick = { onProductClick(product.id) }
                )
            }
        }
    }
}

@Composable
private fun CatalogueProductGridItem(
    product: Product,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = RawDenim),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(170.dp)
                    .background(DeepIndigo, shape = RoundedCornerShape(6.dp)),
                contentAlignment = Alignment.TopEnd
            ) {
                AsyncImage(
                    model = ImageRequest.Builder(LocalContext.current)
                        .data("file:///android_asset/hero_501_banner.jpg")
                        .fallback(com.example.R.drawable.hero_501_banner_1793051553057)
                        .error(com.example.R.drawable.hero_501_banner_1793051553057)
                        .build(),
                    contentDescription = product.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                FitCodePatch(
                    fitCode = product.fitCode,
                    modifier = Modifier.padding(6.dp)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = product.title,
                color = PureWhite,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                maxLines = 1
            )
            Text(
                text = product.subtitle,
                color = OffWhite.copy(alpha = 0.7f),
                fontSize = 11.sp,
                maxLines = 1
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "£${product.price.toInt()}.00",
                    color = LevisRedLight,
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp
                )
                Text(
                    text = product.stretch.displayName.take(10),
                    color = OffWhite.copy(alpha = 0.5f),
                    fontSize = 9.sp
                )
            }
        }
    }
}
