package com.example.core.repository

import com.example.core.model.TailorServiceItem

class TailorRepository {

    fun getTailorServices(): List<TailorServiceItem> = listOf(
        TailorServiceItem(
            id = "serv_hemming",
            title = "Chainstitch Hemming",
            category = "Alteration",
            priceText = "£15.00 / $18.00",
            estimatedMinutes = 20,
            description = "Original Union Special chainstitch machine hemming with authentic roping effect.",
            iconName = "ContentCut"
        ),
        TailorServiceItem(
            id = "serv_tapering",
            title = "Leg Tapering",
            category = "Alteration",
            priceText = "£25.00 / $30.00",
            estimatedMinutes = 45,
            description = "Custom slimming from knee to hem maintaining selvedge inseam.",
            iconName = "Straighten"
        ),
        TailorServiceItem(
            id = "serv_repair",
            title = "Darning & Sashiko Repair",
            category = "Repair",
            priceText = "£20.00 - £40.00",
            estimatedMinutes = 60,
            description = "Authentic Japanese Sashiko stitching or structural thread darning for blown knees/crotch.",
            iconName = "Build"
        ),
        TailorServiceItem(
            id = "serv_patches",
            title = "Custom Leather & Felt Patches",
            category = "Customisation",
            priceText = "£10.00 / $12.00",
            estimatedMinutes = 15,
            description = "Exclusive Levi's archival patches stitched onto waistband or back pockets.",
            iconName = "Sell"
        ),
        TailorServiceItem(
            id = "serv_embroidery",
            title = "Monogram & Chainstitch Embroidery",
            category = "Customisation",
            priceText = "£18.00 / $22.00",
            estimatedMinutes = 30,
            description = "Personalised initials, dates or icons hand-drawn with vintage embroidery machine.",
            iconName = "Edit"
        )
    )
}
