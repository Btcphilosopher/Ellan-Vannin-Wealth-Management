package com.example.feature.fit

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.designsystem.DeepIndigo
import com.example.core.designsystem.DenimBlue
import com.example.core.designsystem.FitCodePatch
import com.example.core.designsystem.LevisRed
import com.example.core.designsystem.LevisRedLight
import com.example.core.designsystem.OffWhite
import com.example.core.designsystem.PureWhite
import com.example.core.designsystem.RawDenim
import com.example.core.model.FitEngine

@Composable
fun FitComparisonScreen(
    onBackClick: () -> Unit,
    onSelectFitToShop: (String) -> Unit
) {
    val allFits = FitEngine.FIT_COMPARISON_SPECS
    var selectedFitCodes by remember { mutableStateOf(setOf("501", "511", "568")) }
    var sliderValue by remember { mutableFloatStateOf(1f) } // 0=Slim, 1=Straight, 2=Relaxed, 3=Loose

    val filteredBySlider = allFits.filter { spec ->
        when (sliderValue.toInt()) {
            0 -> spec.silhouetteCategory == "Slim"
            1 -> spec.silhouetteCategory == "Straight"
            2 -> spec.silhouetteCategory == "Relaxed"
            else -> spec.silhouetteCategory == "Loose"
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepIndigo),
        contentPadding = PaddingValues(16.dp)
    ) {
        // TOP BAR
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBackClick) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = PureWhite)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "VISUAL FIT COMPARISON ENGINE",
                    color = PureWhite,
                    fontWeight = FontWeight.Black,
                    fontSize = 18.sp
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // SILHOUETTE SLIDER (SLIM | STRAIGHT | RELAXED | LOOSE)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = RawDenim)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "EXPLORE SILHOUETTE SPECTRUM",
                        color = LevisRed,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.5.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        listOf("SLIM", "STRAIGHT", "RELAXED", "LOOSE").forEachIndexed { index, label ->
                            Text(
                                text = label,
                                color = if (sliderValue.toInt() == index) LevisRedLight else OffWhite.copy(alpha = 0.6f),
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Slider(
                        value = sliderValue,
                        onValueChange = { sliderValue = it },
                        valueRange = 0f..3f,
                        steps = 2,
                        colors = SliderDefaults.colors(
                            thumbColor = LevisRed,
                            activeTrackColor = LevisRed,
                            inactiveTrackColor = DenimBlue
                        )
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // FIT SELECTOR TOGGLES
        item {
            Text(
                text = "SELECT FITS TO COMPARE SIDE-BY-SIDE",
                color = PureWhite,
                fontWeight = FontWeight.Black,
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(allFits) { spec ->
                    val isSelected = selectedFitCodes.contains(spec.fitCode)
                    Box(
                        modifier = Modifier
                            .background(
                                if (isSelected) LevisRed else DenimBlue,
                                shape = RoundedCornerShape(4.dp)
                            )
                            .clickable {
                                selectedFitCodes = if (isSelected) {
                                    if (selectedFitCodes.size > 1) selectedFitCodes - spec.fitCode else selectedFitCodes
                                } else {
                                    selectedFitCodes + spec.fitCode
                                }
                            }
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = "LOT ${spec.fitCode}",
                            color = PureWhite,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // MATRIX COMPARISON CARDS
        items(allFits.filter { selectedFitCodes.contains(it.fitCode) }) { spec ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
                    .clickable { onSelectFitToShop(spec.fitCode) },
                colors = CardDefaults.cardColors(containerColor = RawDenim),
                shape = RoundedCornerShape(8.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            FitCodePatch(fitCode = spec.fitCode)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = spec.name,
                                color = PureWhite,
                                fontWeight = FontWeight.Black,
                                fontSize = 18.sp
                            )
                        }
                        Text(
                            text = "SHOP FIT",
                            color = LevisRed,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = spec.tagline,
                        color = OffWhite.copy(alpha = 0.8f),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(DeepIndigo, shape = RoundedCornerShape(6.dp))
                            .padding(12.dp)
                    ) {
                        CompareMetricRow("RISE", spec.rise)
                        CompareMetricRow("SEAT & THIGH", "${spec.seat} • ${spec.thigh}")
                        CompareMetricRow("KNEE & LEG OPENING", "${spec.knee} • ${spec.legOpening}")
                        CompareMetricRow("STRETCH LEVEL", spec.stretch)
                        CompareMetricRow("RECOMMENDED STYLING", spec.typicalStyling)
                    }
                }
            }
        }
    }
}

@Composable
private fun CompareMetricRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = OffWhite.copy(alpha = 0.6f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Text(text = value, color = PureWhite, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}
