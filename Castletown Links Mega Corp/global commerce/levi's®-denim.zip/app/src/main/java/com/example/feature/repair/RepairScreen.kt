package com.example.feature.repair

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.designsystem.DeepIndigo
import com.example.core.designsystem.DenimBlue
import com.example.core.designsystem.LeatherTan
import com.example.core.designsystem.LevisRed
import com.example.core.designsystem.LevisRedLight
import com.example.core.designsystem.OffWhite
import com.example.core.designsystem.PureWhite
import com.example.core.designsystem.RawDenim
import com.example.core.designsystem.RedTabBadge
import com.example.core.model.RepairRequest
import com.example.core.model.RepairStatus

@Composable
fun RepairScreen(
    activeRepairs: List<RepairRequest>,
    onSubmitRepair: (RepairRequest) -> Unit,
    onAdvanceStatus: (String, RepairStatus) -> Unit
) {
    var garmentName by remember { mutableStateOf("501® Original Jeans (Dark Indigo)") }
    var selectedDamage by remember { mutableStateOf("Knee Rip / Blowout") }
    var selectedService by remember { mutableStateOf("Sashiko Reinforcement Stitch") }
    var selectedStore by remember { mutableStateOf("Regent St Tailor Shop") }
    var notes by remember { mutableStateOf("Left knee rip needs structural darning.") }

    val damageTypes = listOf("Knee Rip / Blowout", "Crotch Wear Tear", "Hem Fraying", "Button / Zip Broken", "Pocket Lining Rip")
    val services = listOf("Sashiko Reinforcement Stitch", "Structural Darning", "Zipper Replacement", "Original Hem Re-attach")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepIndigo),
        contentPadding = PaddingValues(16.dp)
    ) {
        item {
            RedTabBadge(text = "CIRCULAR DENIM REPAIR")
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "REPAIR YOUR LEVI'S®",
                color = PureWhite,
                fontWeight = FontWeight.Black,
                fontSize = 28.sp,
                letterSpacing = (-0.5).sp
            )
            Text(
                text = "Don't throw them away. Extend the lifespan of your denim.",
                color = OffWhite.copy(alpha = 0.8f),
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.height(20.dp))
        }

        // ACTIVE REPAIR STATE TRACKER
        if (activeRepairs.isNotEmpty()) {
            item {
                Text(
                    text = "ACTIVE REPAIR REQUESTS & STATUS",
                    color = LevisRed,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.5.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
            }

            items(activeRepairs) { repair ->
                RepairStateTrackerCard(
                    repair = repair,
                    onAdvanceClick = { nextStatus ->
                        onAdvanceStatus(repair.id, nextStatus)
                    }
                )
            }

            item { Spacer(modifier = Modifier.height(20.dp)) }
        }

        // NEW REPAIR REQUEST FORM
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = RawDenim),
                shape = RoundedCornerShape(8.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "NEW REPAIR REQUEST",
                        color = PureWhite,
                        fontWeight = FontWeight.Black,
                        fontSize = 16.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Text("GARMENT TITLE", color = OffWhite.copy(alpha = 0.7f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = garmentName,
                        onValueChange = { garmentName = it },
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = DenimBlue,
                            unfocusedContainerColor = DenimBlue,
                            focusedBorderColor = LevisRed,
                            unfocusedBorderColor = DenimBlue,
                            focusedTextColor = PureWhite,
                            unfocusedTextColor = PureWhite
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    Text("TYPE OF DAMAGE", color = OffWhite.copy(alpha = 0.7f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    damageTypes.forEach { damage ->
                        val isSelected = damage == selectedDamage
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp)
                                .clickable { selectedDamage = damage },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = if (isSelected) LevisRed else OffWhite.copy(alpha = 0.3f),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(damage, color = PureWhite, fontSize = 13.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Button(
                        onClick = {
                            onSubmitRepair(
                                RepairRequest(
                                    garmentName = garmentName,
                                    purchaseDate = "March 2025",
                                    damageType = selectedDamage,
                                    serviceRequested = selectedService,
                                    storeName = selectedStore,
                                    status = RepairStatus.SUBMITTED,
                                    notes = notes
                                )
                            )
                        },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = LevisRed)
                    ) {
                        Text("SUBMIT REPAIR REQUEST", color = PureWhite, fontWeight = FontWeight.Black)
                    }
                }
            }
        }
    }
}

@Composable
private fun RepairStateTrackerCard(
    repair: RepairRequest,
    onAdvanceClick: (RepairStatus) -> Unit
) {
    val statuses = RepairStatus.entries.toTypedArray()
    val currentIndex = statuses.indexOf(repair.status)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp),
        colors = CardDefaults.cardColors(containerColor = RawDenim),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(repair.garmentName, color = PureWhite, fontWeight = FontWeight.Black, fontSize = 16.sp)
                Text(repair.status.displayName, color = LevisRedLight, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
            Text("Damage: ${repair.damageType} • Store: ${repair.storeName}", color = OffWhite.copy(alpha = 0.7f), fontSize = 12.sp)

            Spacer(modifier = Modifier.height(12.dp))

            // Progress state steps
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                statuses.forEachIndexed { index, st ->
                    val isDone = index <= currentIndex
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(6.dp)
                            .padding(horizontal = 2.dp)
                            .background(if (isDone) LevisRed else DenimBlue, shape = RoundedCornerShape(2.dp))
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Quoted Price: £${repair.quotedPrice.toInt()}.00", color = LeatherTan, fontWeight = FontWeight.Bold, fontSize = 13.sp)

                if (currentIndex < statuses.size - 1) {
                    val nextStatus = statuses[currentIndex + 1]
                    Button(
                        onClick = { onAdvanceClick(nextStatus) },
                        colors = ButtonDefaults.buttonColors(containerColor = DenimBlue),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text("SIMULATE: ${nextStatus.displayName.uppercase()}", color = PureWhite, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
