package com.example.core.model

object FitEngine {

    val FIT_COMPARISON_SPECS = listOf(
        FitComparisonSpec(
            fitCode = "501",
            name = "501® Original",
            tagline = "The blueprint for all jeans.",
            rise = "Mid Rise (11.25\")",
            seat = "Regular Through Seat",
            thigh = "Straight Through Thigh",
            knee = "Straight (16.5\")",
            legOpening = "16.5\" Straight Leg",
            silhouetteCategory = "Straight",
            stretch = "Non-Stretch / Rigid 100% Cotton",
            typicalStyling = "Tucked T-shirt, Leather Jacket, Boots, Casual Wear",
            description = "The world's most famous jean. Button fly, straight leg, sits at waist."
        ),
        FitComparisonSpec(
            fitCode = "505",
            name = "505™ Regular Fit",
            tagline = "Classic zip-fly straight jean.",
            rise = "Mid Rise (11\")",
            seat = "Extra Room Through Seat",
            thigh = "Regular Thigh",
            knee = "Straight (16.75\")",
            legOpening = "16.5\" Leg Opening",
            silhouetteCategory = "Straight",
            stretch = "Low to Non-Stretch",
            typicalStyling = "Workshirt, Denim Jacket, Work Boots",
            description = "Created in 1967. Famous zip-fly straight fit with slightly more room in the seat."
        ),
        FitComparisonSpec(
            fitCode = "511",
            name = "511™ Slim Fit",
            tagline = "Modern slim with room to move.",
            rise = "Low-Mid Rise (10.25\")",
            seat = "Slim Through Seat",
            thigh = "Slim Thigh",
            knee = "Slim (15.25\")",
            legOpening = "14.5\" Slim Leg",
            silhouetteCategory = "Slim",
            stretch = "Medium Stretch / Flex",
            typicalStyling = "Graphic Tee, Fitted Hoodie, Low-top Sneakers",
            description = "A modern classic slim fit. Tailored feel without feeling tight."
        ),
        FitComparisonSpec(
            fitCode = "512",
            name = "512™ Slim Taper",
            tagline = "Tailored taper for a sharp look.",
            rise = "Mid Rise (10.75\")",
            seat = "Slim Seat & Thigh",
            thigh = "Narrow Thigh",
            knee = "Tapered (14.5\")",
            legOpening = "12.75\" Narrow Taper",
            silhouetteCategory = "Slim",
            stretch = "Comfort Stretch",
            typicalStyling = "Oxford Shirt, Blazer, Chelsea Boots",
            description = "Sits between a slim and a tailor-cut taper. Perfect to showcase footwear."
        ),
        FitComparisonSpec(
            fitCode = "514",
            name = "514™ Straight Fit",
            tagline = "Versatile low-rise straight fit.",
            rise = "Low Rise (10.25\")",
            seat = "Regular Seat",
            thigh = "Regular Thigh",
            knee = "Straight (17\")",
            legOpening = "16.5\" Straight Leg",
            silhouetteCategory = "Straight",
            stretch = "Low / Medium Stretch",
            typicalStyling = "Casual Flannel, Leather Belt, Boots",
            description = "Ideal for medium-to-athletic builds wanting a lower rise and comfortable straight leg."
        ),
        FitComparisonSpec(
            fitCode = "502",
            name = "502™ Taper",
            tagline = "Refined taper with comfortable thigh.",
            rise = "Mid Rise (10.75\")",
            seat = "Regular Seat",
            thigh = "Roomy Thigh",
            knee = "Gently Tapered (15.5\")",
            legOpening = "14.5\" Tapered Leg",
            silhouetteCategory = "Straight",
            stretch = "Flex Stretch",
            typicalStyling = "Sweatshirt, Bomber Jacket, High-top Sneakers",
            description = "Extra comfort in the thigh with a clean, modern taper down to the ankle."
        ),
        FitComparisonSpec(
            fitCode = "568",
            name = "568™ Loose Straight",
            tagline = "Nostalgic '90s loose silhouette.",
            rise = "Mid-High Rise (11.75\")",
            seat = "Full Loose Seat",
            thigh = "Wide Thigh",
            knee = "Loose (19\")",
            legOpening = "18.5\" Loose Leg",
            silhouetteCategory = "Loose",
            stretch = "100% Heavyweight Cotton",
            typicalStyling = "Oversized Hoodie, Vintage Skate Tee, Chunky Sneakers",
            description = "Inspired by 90s streetwear culture. Wide, slouched fit with authentic stack."
        ),
        FitComparisonSpec(
            fitCode = "569",
            name = "569™ Loose Straight",
            tagline = "Maximum room and effortless drape.",
            rise = "Low-Mid Rise (11.5\")",
            seat = "Extra Loose Seat",
            thigh = "Extra Loose Thigh",
            knee = "Wide (19.5\")",
            legOpening = "18.5\" Leg Opening",
            silhouetteCategory = "Loose",
            stretch = "Non-Stretch Cotton",
            typicalStyling = "Workwear Jacket, Heavy Boots",
            description = "Roomy from hip to hem for ultimate mobility and relaxed workwear styling."
        ),
        FitComparisonSpec(
            fitCode = "555",
            name = "555™ Relaxed Fit",
            tagline = "Relaxed vintage cut with subtle taper.",
            rise = "Mid-High Rise (11.5\")",
            seat = "Relaxed Seat",
            thigh = "Relaxed Thigh",
            knee = "Relaxed (17.5\")",
            legOpening = "16\" Gentle Taper",
            silhouetteCategory = "Relaxed",
            stretch = "Non-Stretch / Soft Wash",
            typicalStyling = "Vintage Sweater, Loafers",
            description = "Relaxed 80s aesthetic with a comfortable waist and subtle vintage taper."
        )
    )

    fun calculateRecommendations(input: UserFitInput): List<FitRecommendation> {
        val recommendations = mutableListOf<FitRecommendation>()

        val userSilhouette = input.preferredSilhouette.lowercase()
        val userLooseness = input.desiredLooseness.lowercase()
        val userRise = input.preferredRise
        val userStretch = input.stretchPreference

        val fitSpecs = FIT_COMPARISON_SPECS

        for (spec in fitSpecs) {
            var score = 70 // baseline score

            // Silhouette matching
            if (spec.silhouetteCategory.lowercase() == userSilhouette) {
                score += 15
            } else if (userSilhouette == "relaxed" && spec.silhouetteCategory == "Straight") {
                score += 8
            } else if (userSilhouette == "loose" && (spec.silhouetteCategory == "Loose" || spec.silhouetteCategory == "Relaxed")) {
                score += 12
            }

            // Looseness match
            if (userLooseness == "snug" && spec.silhouetteCategory == "Slim") score += 10
            if (userLooseness == "regular" && spec.silhouetteCategory == "Straight") score += 10
            if (userLooseness == "roomy" && (spec.silhouetteCategory == "Relaxed" || spec.fitCode == "502")) score += 10
            if (userLooseness == "baggy" && spec.silhouetteCategory == "Loose") score += 12

            // Rise matching
            when (userRise) {
                RiseType.LOW -> if (spec.rise.contains("Low", ignoreCase = true)) score += 8
                RiseType.MID -> if (spec.rise.contains("Mid", ignoreCase = true)) score += 8
                RiseType.HIGH -> if (spec.rise.contains("High", ignoreCase = true)) score += 8
            }

            // Stretch match
            when (userStretch) {
                StretchType.NON_STRETCH -> if (spec.stretch.contains("Non-Stretch", ignoreCase = true) || spec.stretch.contains("100%", ignoreCase = true)) score += 7
                StretchType.HIGH_STRETCH -> if (spec.stretch.contains("Stretch", ignoreCase = true) || spec.stretch.contains("Flex", ignoreCase = true)) score += 7
                else -> score += 3
            }

            // Current fave boost
            if (input.currentFaveFit.contains(spec.fitCode, ignoreCase = true)) {
                score += 8
            }

            // Cap at 98
            score = score.coerceIn(65, 98)

            val confidence = when {
                score >= 90 -> "Match Score: 98% • Exceptional Match"
                score >= 82 -> "Match Score: $score% • Recommended Fit"
                else -> "Match Score: $score% • Alternative Silhouette"
            }

            val rationale = buildString {
                append("Recommended because you prefer a ")
                append(spec.silhouetteCategory.lowercase())
                append(" leg with ")
                append(spec.rise.lowercase())
                append(" and ")
                append(userLooseness)
                append(" room through thigh.")
            }

            var recommendedWaist = input.waistInches
            var recommendedInseam = input.inseamInches

            // Adjust sizing according to stretch and fit characteristics
            if (spec.stretch.contains("Non-Stretch") && userLooseness == "roomy") {
                recommendedWaist += 1
            }

            recommendations.add(
                FitRecommendation(
                    fitCode = spec.fitCode,
                    fitName = spec.name,
                    fitScore = score,
                    confidenceLabel = confidence,
                    whyItFits = rationale,
                    silhouette = spec.silhouetteCategory,
                    rise = spec.rise,
                    stretchLevel = spec.stretch,
                    recommendedWaist = recommendedWaist,
                    recommendedInseam = recommendedInseam,
                    sampleProductId = "jean_${spec.fitCode.lowercase()}_dark"
                )
            )
        }

        return recommendations.sortedByDescending { it.fitScore }
    }
}
