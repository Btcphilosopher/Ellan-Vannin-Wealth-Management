package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.core.database.AppDatabase
import com.example.core.designsystem.LevisTheme
import com.example.core.repository.CultureRepository
import com.example.core.repository.DenimRepository
import com.example.core.repository.MembershipRepository
import com.example.core.repository.StoreRepository
import com.example.core.repository.TailorRepository
import com.example.core.repository.UserDataRepository
import com.example.navigation.LevisMainContainer

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val appDatabase = AppDatabase.getInstance(applicationContext)
        val denimRepository = DenimRepository()
        val tailorRepository = TailorRepository()
        val storeRepository = StoreRepository()
        val membershipRepository = MembershipRepository()
        val cultureRepository = CultureRepository()

        val userDataRepository = UserDataRepository(
            cartDao = appDatabase.cartDao(),
            wishlistDao = appDatabase.wishlistDao(),
            wardrobeDao = appDatabase.wardrobeDao(),
            repairDao = appDatabase.repairDao(),
            appointmentDao = appDatabase.appointmentDao(),
            fitProfileDao = appDatabase.fitProfileDao(),
            denimRepository = denimRepository
        )

        setContent {
            LevisTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    LevisMainContainer(
                        denimRepository = denimRepository,
                        tailorRepository = tailorRepository,
                        storeRepository = storeRepository,
                        membershipRepository = membershipRepository,
                        cultureRepository = cultureRepository,
                        userDataRepository = userDataRepository
                    )
                }
            }
        }
    }
}
