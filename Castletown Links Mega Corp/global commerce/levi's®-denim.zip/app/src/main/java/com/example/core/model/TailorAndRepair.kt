package com.example.core.model

import java.util.UUID

enum class RepairStatus(val displayName: String) {
    SUBMITTED("Submitted"),
    ASSESSED("Assessed by Tailor"),
    QUOTED("Quoted"),
    APPROVED("Approved by Customer"),
    IN_REPAIR("In Repair"),
    READY("Ready for Pickup"),
    COLLECTED("Completed & Collected")
}

data class RepairRequest(
    val id: String = UUID.randomUUID().toString(),
    val garmentName: String,
    val purchaseDate: String,
    val damageType: String, // "Rip/Tear", "Crotch Wear", "Knee Wear", "Hem Damage", "Button/Zip", "Alteration"
    val photoUrl: String? = null,
    val serviceRequested: String,
    val storeName: String,
    val status: RepairStatus = RepairStatus.SUBMITTED,
    val estimatedCompletionDate: String = "3-5 Working Days",
    val quotedPrice: Double = 25.00,
    val notes: String = ""
)

data class CustomisationOption(
    val patchName: String = "Classic Two Horse Pull",
    val threadColor: String = "Golden Orange Stitch",
    val embroideryText: String = "LEVI'S",
    val symbol: String = "Red Tab Diamond",
    val placementLocation: String = "Back Pocket Right"
)

data class Appointment(
    val id: String = UUID.randomUUID().toString(),
    val storeName: String,
    val serviceName: String, // "Hemming", "Tapering", "Custom Embroidery", "General Repair"
    val date: String,
    val timeSlot: String,
    val garmentName: String,
    val status: String = "Confirmed"
)

data class TailorServiceItem(
    val id: String,
    val title: String,
    val category: String,
    val priceText: String,
    val estimatedMinutes: Int,
    val description: String,
    val iconName: String
)
