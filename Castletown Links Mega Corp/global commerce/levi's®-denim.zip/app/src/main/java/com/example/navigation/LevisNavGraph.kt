package com.example.navigation

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.core.designsystem.DeepIndigo
import com.example.core.designsystem.DenimBlue
import com.example.core.designsystem.LevisRed
import com.example.core.designsystem.LevisTopAppBar
import com.example.core.designsystem.OffWhite
import com.example.core.designsystem.PureWhite
import com.example.core.model.Appointment
import com.example.core.model.RepairRequest
import com.example.core.model.RepairStatus
import com.example.core.model.WardrobeItem
import com.example.core.repository.CultureRepository
import com.example.core.repository.DenimRepository
import com.example.core.repository.MembershipRepository
import com.example.core.repository.StoreRepository
import com.example.core.repository.TailorRepository
import com.example.core.repository.UserDataRepository
import com.example.feature.cart.CartScreen
import com.example.feature.catalogue.CatalogueScreen
import com.example.feature.catalogue.ProductDetailScreen
import com.example.feature.culture.CultureScreen
import com.example.feature.fit.DenimProfileScreen
import com.example.feature.fit.FitComparisonScreen
import com.example.feature.fit.FitFinderScreen
import com.example.feature.home.HomeScreen
import com.example.feature.membership.ExclusiveDropsScreen
import com.example.feature.membership.RedTabScreen
import com.example.feature.repair.RepairScreen
import com.example.feature.stores.BarcodeScannerScreen
import com.example.feature.stores.StoreLocatorScreen
import com.example.feature.styling.StyleEngineScreen
import com.example.feature.tailor.TailorShopScreen
import com.example.feature.wardrobe.WardrobeScreen
import kotlinx.coroutines.launch

enum class LevisNavTab(val title: String, val icon: ImageVector) {
    HOME("HOME", Icons.Default.Home),
    SHOP("SHOP", Icons.Default.ShoppingBag),
    FITS("FITS", Icons.Default.Explore),
    TAILOR("TAILOR", Icons.Default.ContentCut),
    ACCOUNT("RED TAB", Icons.Default.Person)
}

enum class LevisSubScreen {
    NONE,
    PRODUCT_DETAIL,
    FIT_FINDER,
    FIT_COMPARISON,
    DENIM_PROFILE,
    BARCODE_SCANNER,
    REPAIR_REQUEST,
    EXCLUSIVE_DROPS,
    WARDROBE,
    CULTURE,
    STYLE_ENGINE,
    CART
}

@Composable
fun LevisMainContainer(
    denimRepository: DenimRepository,
    tailorRepository: TailorRepository,
    storeRepository: StoreRepository,
    membershipRepository: MembershipRepository,
    cultureRepository: CultureRepository,
    userDataRepository: UserDataRepository
) {
    var selectedTab by remember { mutableStateOf(LevisNavTab.HOME) }
    var currentSubScreen by remember { mutableStateOf(LevisSubScreen.NONE) }
    var activeProductId by remember { mutableStateOf<String?>(null) }
    var searchQuery by remember { mutableStateOf("") }

    val coroutineScope = rememberCoroutineScope()
    val cartItems by userDataRepository.cartItems.collectAsState(initial = emptyList())
    val wishlistedProducts by userDataRepository.wishlistedProducts.collectAsState(initial = emptyList())
    val wardrobeItems by userDataRepository.wardrobeItems.collectAsState(initial = emptyList())
    val repairRequests by userDataRepository.repairRequests.collectAsState(initial = emptyList())
    val userFitProfile by userDataRepository.savedFitProfile.collectAsState(initial = null)

    Scaffold(
        topBar = {
            LevisTopAppBar(
                onSearchClick = {
                    selectedTab = LevisNavTab.SHOP
                    currentSubScreen = LevisSubScreen.NONE
                },
                onWishlistClick = {
                    selectedTab = LevisNavTab.SHOP
                    currentSubScreen = LevisSubScreen.NONE
                },
                onBagClick = {
                    currentSubScreen = LevisSubScreen.CART
                },
                bagCount = cartItems.sumOf { it.quantity }
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = DeepIndigo,
                contentColor = PureWhite
            ) {
                LevisNavTab.entries.forEach { tab ->
                    val isSelected = selectedTab == tab && currentSubScreen == LevisSubScreen.NONE
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = {
                            selectedTab = tab
                            currentSubScreen = LevisSubScreen.NONE
                        },
                        icon = { Icon(tab.icon, contentDescription = tab.title) },
                        label = {
                            Text(
                                text = tab.title,
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = PureWhite,
                            selectedTextColor = LevisRed,
                            indicatorColor = LevisRed,
                            unselectedIconColor = OffWhite.copy(alpha = 0.6f),
                            unselectedTextColor = OffWhite.copy(alpha = 0.6f)
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(DeepIndigo)
        ) {
            Crossfade(targetState = currentSubScreen to selectedTab, label = "ScreenTransition") { (sub, tab) ->
                when {
                    sub == LevisSubScreen.PRODUCT_DETAIL && activeProductId != null -> {
                        val product = denimRepository.getProductById(activeProductId!!)
                        if (product != null) {
                            val isWishlisted = wishlistedProducts.any { it.id == product.id }
                            ProductDetailScreen(
                                product = product,
                                isWishlisted = isWishlisted,
                                onBackClick = { currentSubScreen = LevisSubScreen.NONE },
                                onAddToCart = { waist, length ->
                                    coroutineScope.launch {
                                        userDataRepository.addToCart(product.id, waist, length)
                                    }
                                },
                                onToggleWishlist = {
                                    coroutineScope.launch {
                                        userDataRepository.toggleWishlist(product.id, isWishlisted)
                                    }
                                },
                                onFindMySizeClick = { currentSubScreen = LevisSubScreen.FIT_FINDER },
                                onFindInStoreClick = { currentSubScreen = LevisSubScreen.BARCODE_SCANNER },
                                onCustomiseClick = { selectedTab = LevisNavTab.TAILOR; currentSubScreen = LevisSubScreen.NONE }
                            )
                        }
                    }

                    sub == LevisSubScreen.FIT_FINDER -> {
                        FitFinderScreen(
                            onSaveProfileAndShop = { input ->
                                coroutineScope.launch { userDataRepository.saveFitProfile(input) }
                            },
                            onProductClick = { prodId ->
                                activeProductId = prodId
                                currentSubScreen = LevisSubScreen.PRODUCT_DETAIL
                            },
                            onCompareFitsClick = { currentSubScreen = LevisSubScreen.FIT_COMPARISON },
                            onCloseClick = { currentSubScreen = LevisSubScreen.NONE }
                        )
                    }

                    sub == LevisSubScreen.FIT_COMPARISON -> {
                        FitComparisonScreen(
                            onBackClick = { currentSubScreen = LevisSubScreen.NONE },
                            onSelectFitToShop = { fitCode ->
                                selectedTab = LevisNavTab.SHOP
                                currentSubScreen = LevisSubScreen.NONE
                            }
                        )
                    }

                    sub == LevisSubScreen.BARCODE_SCANNER -> {
                        BarcodeScannerScreen(
                            onBackClick = { currentSubScreen = LevisSubScreen.NONE },
                            onBarcodeScanned = { code -> storeRepository.lookupBarcode(code) },
                            onProductClick = { prodId ->
                                activeProductId = prodId
                                currentSubScreen = LevisSubScreen.PRODUCT_DETAIL
                            }
                        )
                    }

                    sub == LevisSubScreen.REPAIR_REQUEST -> {
                        RepairScreen(
                            activeRepairs = repairRequests,
                            onSubmitRepair = { req ->
                                coroutineScope.launch { userDataRepository.submitRepairRequest(req) }
                            },
                            onAdvanceStatus = { id, nextStatus ->
                                coroutineScope.launch { userDataRepository.updateRepairStatus(id, nextStatus) }
                            }
                        )
                    }

                    sub == LevisSubScreen.EXCLUSIVE_DROPS -> {
                        ExclusiveDropsScreen(
                            drops = membershipRepository.getExclusiveDrops(),
                            onBackClick = { currentSubScreen = LevisSubScreen.NONE }
                        )
                    }

                    sub == LevisSubScreen.CART -> {
                        CartScreen(
                            items = cartItems,
                            onRemoveItem = { cartId ->
                                coroutineScope.launch { userDataRepository.removeFromCart(cartId) }
                            },
                            onCheckoutClick = {
                                coroutineScope.launch { userDataRepository.clearCart() }
                                currentSubScreen = LevisSubScreen.NONE
                            },
                            onShopMoreClick = {
                                selectedTab = LevisNavTab.SHOP
                                currentSubScreen = LevisSubScreen.NONE
                            }
                        )
                    }

                    // BOTTOM TAB SCREENS
                    tab == LevisNavTab.HOME -> {
                        HomeScreen(
                            iconicProducts = denimRepository.getIconicProducts(),
                            stories = cultureRepository.getEditorialStories(),
                            onProductClick = { prodId ->
                                activeProductId = prodId
                                currentSubScreen = LevisSubScreen.PRODUCT_DETAIL
                            },
                            onFitFinderClick = { currentSubScreen = LevisSubScreen.FIT_FINDER },
                            onTailorClick = { selectedTab = LevisNavTab.TAILOR },
                            onRepairClick = { currentSubScreen = LevisSubScreen.REPAIR_REQUEST },
                            onRedTabClick = { selectedTab = LevisNavTab.ACCOUNT },
                            onArchiveClick = { currentSubScreen = LevisSubScreen.CULTURE },
                            onScannerClick = { currentSubScreen = LevisSubScreen.BARCODE_SCANNER }
                        )
                    }

                    tab == LevisNavTab.SHOP -> {
                        CatalogueScreen(
                            products = denimRepository.getAllProducts(),
                            onProductClick = { prodId ->
                                activeProductId = prodId
                                currentSubScreen = LevisSubScreen.PRODUCT_DETAIL
                            },
                            onSearchQueryChange = { searchQuery = it },
                            initialQuery = searchQuery
                        )
                    }

                    tab == LevisNavTab.FITS -> {
                        FitComparisonScreen(
                            onBackClick = { selectedTab = LevisNavTab.HOME },
                            onSelectFitToShop = { fitCode ->
                                selectedTab = LevisNavTab.SHOP
                            }
                        )
                    }

                    tab == LevisNavTab.TAILOR -> {
                        TailorShopScreen(
                            services = tailorRepository.getTailorServices(),
                            onBookAppointment = { appt ->
                                coroutineScope.launch { userDataRepository.bookAppointment(appt) }
                            },
                            onOpenRepairClick = { currentSubScreen = LevisSubScreen.REPAIR_REQUEST }
                        )
                    }

                    tab == LevisNavTab.ACCOUNT -> {
                        RedTabScreen(
                            member = membershipRepository.getMemberProfile(),
                            vouchers = membershipRepository.getVouchers(),
                            onOpenDropsClick = { currentSubScreen = LevisSubScreen.EXCLUSIVE_DROPS }
                        )
                    }
                }
            }
        }
    }
}
