package com.example.core.model

import java.util.UUID

data class RedTabMember(
    val memberName: String = "Levi Strauss",
    val memberId: String = "RT-87309124",
    val barcodeValue: String = "9301283910283",
    val pointsBalance: Int = 2840,
    val tierName: String = "RED TAB™ GOLD",
    val joinedYear: String = "2024",
    val availableVoucherCount: Int = 3
)

data class Voucher(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val discountText: String,
    val code: String,
    val pointsRequired: Int = 1000,
    val expiryDate: String,
    val isRedeemed: Boolean = false
)

data class ExclusiveDrop(
    val id: String,
    val title: String,
    val collectionName: String,
    val releaseDate: String,
    val isEarlyAccess: Boolean,
    val description: String,
    val imageUrl: String,
    val stockStatus: String = "Dropping Soon"
)

data class StoreLocation(
    val id: String,
    val name: String,
    val address: String,
    val city: String,
    val distanceKm: Double,
    val openingHours: String,
    val phone: String,
    val hasTailorShop: Boolean = true,
    val hasRepairStation: Boolean = true,
    val imageUrl: String
)

data class EditorialStory(
    val id: String,
    val title: String,
    val subtitle: String,
    val author: String,
    val date: String,
    val category: String, // "MUSIC", "ART", "WORKWEAR", "501 HISTORY"
    val imageUrl: String,
    val bodyText: String,
    val featuredProductIds: List<String> = emptyList()
)

data class ArchiveEvent(
    val year: String,
    val title: String,
    val era: String,
    val summary: String,
    val iconicFitCode: String,
    val imageUrl: String
)

data class StyleOutfit(
    val id: String,
    val name: String,
    val occasion: String,
    val era: String,
    val subculture: String,
    val productIds: List<String>,
    val imageUrl: String,
    val description: String
)

data class WardrobeItem(
    val id: String = UUID.randomUUID().toString(),
    val productId: String,
    val productName: String,
    val fitCode: String,
    val sizeLabel: String,
    val washName: String,
    val purchaseDate: String,
    val ageMonths: Int,
    val wearCount: Int,
    val repairCount: Int,
    val washCount: Int,
    val photoUrl: String,
    val notes: String = ""
)

data class CartItem(
    val id: String = UUID.randomUUID().toString(),
    val product: Product,
    val waist: Int,
    val length: Int,
    val quantity: Int = 1,
    val customisation: CustomisationOption? = null
)

data class Order(
    val id: String,
    val orderDate: String,
    val items: List<CartItem>,
    val totalAmount: Double,
    val discountAmount: Double,
    val rewardsUsed: Double,
    val status: String, // "CREATED", "PAID", "DISPATCHED", "DELIVERED"
    val trackingNumber: String
)
