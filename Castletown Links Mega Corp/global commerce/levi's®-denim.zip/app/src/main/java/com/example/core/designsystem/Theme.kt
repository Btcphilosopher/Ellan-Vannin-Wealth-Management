package com.example.core.designsystem

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// LEVI'S® Color Palette
val DeepIndigo = Color(0xFF0B132B)
val DenimBlue = Color(0xFF1C3144)
val WashedBlue = Color(0xFF3A6073)
val LightDenim = Color(0xFF8DA9C4)
val RawDenim = Color(0xFF162447)
val LevisRed = Color(0xFFC8102E)
val LevisRedLight = Color(0xFFE53935)
val OffWhite = Color(0xFFF7F7F5)
val PureWhite = Color(0xFFFFFFFF)
val LeatherTan = Color(0xFFC48B5B)
val IndustrialCharcoal = Color(0xFF1E1E1E)
val CharcoalGray = Color(0xFF2B2B2B)
val MutedGray = Color(0xFF757575)
val LightGray = Color(0xFFE8E8E6)

private val LightColorScheme = lightColorScheme(
    primary = DeepIndigo,
    onPrimary = PureWhite,
    primaryContainer = DenimBlue,
    onPrimaryContainer = PureWhite,
    secondary = LevisRed,
    onSecondary = PureWhite,
    secondaryContainer = Color(0xFFFFEBEE),
    onSecondaryContainer = LevisRed,
    tertiary = LeatherTan,
    onTertiary = PureWhite,
    background = OffWhite,
    onBackground = IndustrialCharcoal,
    surface = PureWhite,
    onSurface = IndustrialCharcoal,
    surfaceVariant = LightGray,
    onSurfaceVariant = CharcoalGray,
    outline = MutedGray,
    outlineVariant = LightGray
)

private val DarkColorScheme = darkColorScheme(
    primary = OffWhite,
    onPrimary = DeepIndigo,
    primaryContainer = DenimBlue,
    onPrimaryContainer = PureWhite,
    secondary = LevisRed,
    onSecondary = PureWhite,
    secondaryContainer = Color(0xFF5C000B),
    onSecondaryContainer = OffWhite,
    tertiary = LeatherTan,
    onTertiary = IndustrialCharcoal,
    background = DeepIndigo,
    onBackground = OffWhite,
    surface = RawDenim,
    onSurface = OffWhite,
    surfaceVariant = DenimBlue,
    onSurfaceVariant = LightDenim,
    outline = MutedGray,
    outlineVariant = WashedBlue
)

val LevisTypography = Typography(
    displayLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Black,
        fontSize = 32.sp,
        lineHeight = 38.sp,
        letterSpacing = (-0.5).sp
    ),
    displayMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 26.sp,
        lineHeight = 32.sp
    ),
    displaySmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 22.sp,
        lineHeight = 28.sp
    ),
    headlineLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 20.sp,
        lineHeight = 26.sp
    ),
    headlineMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 18.sp,
        lineHeight = 24.sp
    ),
    headlineSmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp,
        lineHeight = 22.sp
    ),
    titleLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 16.sp,
        lineHeight = 22.sp,
        letterSpacing = 0.5.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp,
        lineHeight = 22.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp,
        lineHeight = 18.sp
    ),
    labelLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 13.sp,
        lineHeight = 16.sp,
        letterSpacing = 1.sp
    ),
    labelSmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 10.sp,
        lineHeight = 14.sp,
        letterSpacing = 1.5.sp
    )
)

@Composable
fun LevisTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = LevisTypography,
        content = content
    )
}
