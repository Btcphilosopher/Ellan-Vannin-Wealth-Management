package com.example.core.repository

import com.example.core.model.ExclusiveDrop
import com.example.core.model.RedTabMember
import com.example.core.model.Voucher

class MembershipRepository {

    fun getMemberProfile(): RedTabMember = RedTabMember(
        memberName = "Levi Strauss",
        memberId = "RT-87309124",
        barcodeValue = "9301283910283",
        pointsBalance = 2840,
        tierName = "RED TAB™ GOLD MEMBER",
        joinedYear = "2024",
        availableVoucherCount = 2
    )

    fun getVouchers(): List<Voucher> = listOf(
        Voucher(
            id = "vouch_10_off",
            title = "£10 Off Any Denim Purchase",
            discountText = "£10.00 VOUCHER",
            code = "REDTAB10",
            pointsRequired = 1000,
            expiryDate = "Valid until 31 Dec 2026"
        ),
        Voucher(
            id = "vouch_free_tailor",
            title = "Free Chainstitch Hemming at Tailor Shop",
            discountText = "FREE TAILORING",
            code = "HEM2026",
            pointsRequired = 500,
            expiryDate = "Valid until 30 Nov 2026"
        ),
        Voucher(
            id = "vouch_birthday",
            title = "Birthday Benefit: 20% Off Order",
            discountText = "20% OFF",
            code = "BDAY2026",
            pointsRequired = 0,
            expiryDate = "Valid during Birthday Month"
        )
    )

    fun getExclusiveDrops(): List<ExclusiveDrop> = listOf(
        ExclusiveDrop(
            id = "drop_501_1955",
            title = "1955 501® LVC Custom Reproduction",
            collectionName = "Levi's® Vintage Clothing",
            releaseDate = "FRI 30 OCT • 09:00 AM",
            isEarlyAccess = true,
            description = "Hand-crafted 13.75oz selvedge denim from Japan with 1955 zinc button fly and leather patch.",
            imageUrl = "hero_501_banner_1793051553057.jpg",
            stockStatus = "Member Early Access Open"
        ),
        ExclusiveDrop(
            id = "drop_skate_trucker",
            title = "Levi's® Skateboarding Heavy Canvas Trucker",
            collectionName = "Skate & Workwear",
            releaseDate = "MON 2 NOV • 10:00 AM",
            isEarlyAccess = false,
            description = "Reinforced Cordura® denim with triple-needle stitching for high abrasion resistance.",
            imageUrl = "hero_501_banner_1793051553057.jpg",
            stockStatus = "Dropping Soon"
        )
    )

    fun calculatePointsForSpend(spendAmount: Double, conversionRate: Int = 100): Int {
        return (spendAmount * conversionRate).toInt()
    }

    fun calculateDiscountFromPoints(points: Int, pointsPerUnit: Int = 1000, valuePerUnit: Double = 10.0): Double {
        val units = points / pointsPerUnit
        return units * valuePerUnit
    }
}
