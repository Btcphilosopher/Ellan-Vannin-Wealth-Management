package com.example.feature.catalogue

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.core.designsystem.DeepIndigo
import com.example.core.designsystem.DenimBlue
import com.example.core.designsystem.FitCodePatch
import com.example.core.designsystem.LeatherTan
import com.example.core.designsystem.LevisRed
import com.example.core.designsystem.LevisRedLight
import com.example.core.designsystem.OffWhite
import com.example.core.designsystem.PureWhite
import com.example.core.designsystem.RawDenim
import com.example.core.designsystem.RedTabBadge
import com.example.core.model.Product

@Composable
fun ProductDetailScreen(
    product: Product,
    isWishlisted: Boolean,
    onBackClick: () -> Unit,
    onAddToCart: (Int, Int) -> Unit,
    onToggleWishlist: () -> Unit,
    onFindMySizeClick: () -> Unit,
    onFindInStoreClick: () -> Unit,
    onCustomiseClick: () -> Unit
) {
    var selectedWaist by remember { mutableIntStateOf(product.availableWaists.firstOrNull() ?: 32) }
    var selectedLength by remember { mutableIntStateOf(product.availableLengths.firstOrNull() ?: 32) }
    var addedToBagMessage by remember { androidx.compose.runtime.mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepIndigo)
    ) {
        // TOP IMAGE BANNER WITH BACK AND WISHLIST BUTTONS
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(380.dp)
            ) {
                AsyncImage(
                    model = ImageRequest.Builder(LocalContext.current)
                        .data("file:///android_asset/hero_501_banner.jpg")
                        .fallback(com.example.R.drawable.hero_501_banner_1793051553057)
                        .error(com.example.R.drawable.hero_501_banner_1793051553057)
                        .build(),
                    contentDescription = product.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onBackClick,
                        modifier = Modifier
                            .background(DeepIndigo.copy(alpha = 0.7f), shape = RoundedCornerShape(20.dp))
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = PureWhite)
                    }

                    IconButton(
                        onClick = onToggleWishlist,
                        modifier = Modifier
                            .background(DeepIndigo.copy(alpha = 0.7f), shape = RoundedCornerShape(20.dp))
                    ) {
                        Icon(
                            imageVector = if (isWishlisted) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                            contentDescription = "Save",
                            tint = if (isWishlisted) LevisRed else PureWhite
                        )
                    }
                }

                FitCodePatch(
                    fitCode = product.fitCode,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(16.dp)
                )
            }
        }

        // TITLE & PRICE
        item {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        RedTabBadge(text = product.fitName.uppercase())
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = product.title,
                            color = PureWhite,
                            fontWeight = FontWeight.Black,
                            fontSize = 26.sp,
                            letterSpacing = (-0.5).sp
                        )
                        Text(
                            text = product.subtitle,
                            color = OffWhite.copy(alpha = 0.7f),
                            fontSize = 14.sp
                        )
                    }
                    Text(
                        text = "£${product.price.toInt()}.00",
                        color = LevisRedLight,
                        fontWeight = FontWeight.Black,
                        fontSize = 24.sp
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // FIND MY SIZE RECOMMENDATION LINK
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(onClick = onFindMySizeClick),
                    color = DenimBlue,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Explore,
                            contentDescription = null,
                            tint = LevisRed,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "UNSURE OF SIZE? USE LEVI'S® FIT FINDER",
                            color = PureWhite,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            letterSpacing = 0.5.sp
                        )
                    }
                }
            }
        }

        // WAIST SELECTOR
        item {
            Column(modifier = Modifier.padding(horizontal = 20.dp)) {
                Text(
                    text = "SELECT WAIST: ${selectedWaist}\"",
                    color = OffWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(product.availableWaists) { waist ->
                        val isSelected = waist == selectedWaist
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .background(
                                    if (isSelected) LevisRed else DenimBlue,
                                    shape = RoundedCornerShape(4.dp)
                                )
                                .border(
                                    1.dp,
                                    if (isSelected) LevisRed else OffWhite.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(4.dp)
                                )
                                .clickable { selectedWaist = waist },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "$waist",
                                color = PureWhite,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
        }

        // LENGTH SELECTOR
        item {
            Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 14.dp)) {
                Text(
                    text = "SELECT LENGTH (INSEAM): ${selectedLength}\"",
                    color = OffWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(product.availableLengths) { length ->
                        val isSelected = length == selectedLength
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .background(
                                    if (isSelected) LevisRed else DenimBlue,
                                    shape = RoundedCornerShape(4.dp)
                                )
                                .border(
                                    1.dp,
                                    if (isSelected) LevisRed else OffWhite.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(4.dp)
                                )
                                .clickable { selectedLength = length },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "L$length",
                                color = PureWhite,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
        }

        // ADD TO BAG BUTTON
        item {
            Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
                Button(
                    onClick = {
                        onAddToCart(selectedWaist, selectedLength)
                        addedToBagMessage = true
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = LevisRed),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.ShoppingBag, contentDescription = null, tint = PureWhite)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (addedToBagMessage) "ADDED TO BAG! (${selectedWaist}W x ${selectedLength}L)" else "ADD TO BAG • £${product.price.toInt()}.00",
                            color = PureWhite,
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp,
                            letterSpacing = 0.5.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onFindInStoreClick,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Icon(Icons.Default.LocationOn, contentDescription = null, tint = OffWhite, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("FIND IN STORE", color = OffWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = onCustomiseClick,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Icon(Icons.Default.ContentCut, contentDescription = null, tint = LeatherTan, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("CUSTOMISE", color = LeatherTan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // FABRIC ENGINE & SPECIFICATIONS BREAKDOWN
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                colors = CardDefaults.cardColors(containerColor = RawDenim),
                shape = RoundedCornerShape(8.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "DENIM SPECIFICATIONS",
                        color = LevisRed,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.5.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    SpecRow("LOT FIT", product.fitName)
                    SpecRow("RISE", product.rise.displayName)
                    SpecRow("LEG SILHOUETTE", product.leg.displayName)
                    SpecRow("STRETCH", product.stretch.displayName)
                    SpecRow("COMPOSITION", "${product.fabricSpec.cottonPercentage}% Cotton, ${product.fabricSpec.elastanePercentage}% Elastane")
                    SpecRow("DENIM WEIGHT", product.fabricSpec.weightLabel)
                    SpecRow("WEAVE & FINISH", "${product.fabricSpec.weave} • ${product.fabricSpec.finish}")
                    SpecRow("COTTON ORIGIN", product.fabricSpec.originMetadata)
                    SpecRow("CARE", product.fabricSpec.careInstructions)
                }
            }
        }

        // DESCRIPTION
        item {
            Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp)) {
                Text(
                    text = "THE GARMENT",
                    color = PureWhite,
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = product.description,
                    color = OffWhite.copy(alpha = 0.8f),
                    fontSize = 14.sp,
                    lineHeight = 20.sp
                )
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun SpecRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = OffWhite.copy(alpha = 0.6f), fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Text(text = value, color = PureWhite, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}
