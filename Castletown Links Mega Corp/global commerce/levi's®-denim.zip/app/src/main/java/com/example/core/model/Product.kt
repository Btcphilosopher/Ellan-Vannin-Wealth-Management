package com.example.core.model

import java.util.UUID

enum class ProductCategory(val displayName: String) {
    JEANS("Jeans"),
    TRUCKER_JACKETS("Trucker Jackets"),
    DENIM_SHIRTS("Denim Shirts"),
    JACKETS("Jackets"),
    TOPS("Tops"),
    TSHIRTS("T-Shirts"),
    SWEATSHIRTS("Sweatshirts"),
    OUTERWEAR("Outerwear"),
    ACCESSORIES("Accessories"),
    SHOES("Shoes"),
    KIDS("Kids")
}

enum class FitCategory(val code: String, val displayName: String, val silhouette: String) {
    FIT_501("501", "501® Original", "Straight"),
    FIT_505("505", "505™ Regular Fit", "Straight"),
    FIT_511("511", "511™ Slim Fit", "Slim"),
    FIT_512("512", "512™ Slim Taper", "Slim Taper"),
    FIT_514("514", "514™ Straight Fit", "Straight"),
    FIT_502("502", "502™ Taper", "Taper"),
    FIT_568("568", "568™ Loose Straight", "Loose"),
    FIT_569("569", "569™ Loose Straight", "Loose"),
    FIT_555("555", "555™ Relaxed Fit", "Relaxed"),
    TRUCKER("TRUCKER", "Trucker Jacket Fit", "Classic Outerwear")
}

enum class WashType(val displayName: String, val colorHex: Long) {
    RAW("Raw Denim", 0xFF0B132B),
    RIGID("Rigid Dark", 0xFF162447),
    DARK_INDIGO("Dark Indigo", 0xFF1C3144),
    MID_BLUE("Mid Blue", 0xFF3A6073),
    LIGHT_BLUE("Light Blue", 0xFF8DA9C4),
    STONEWASH("Stonewash", 0xFF6C8EBF),
    ACID_WASH("Acid Wash", 0xFFA0B2C6),
    BLACK("Black Denim", 0xFF1E1E1E),
    GREY("Washed Grey", 0xFF4A4A4A),
    WHITE("Off White", 0xFFF0EFEA),
    VINTAGE("Vintage Fade", 0xFF5C7893)
}

enum class RiseType(val displayName: String) {
    LOW("Low Rise"),
    MID("Mid Rise"),
    HIGH("High Rise")
}

enum class StretchType(val displayName: String) {
    NON_STRETCH("Non-Stretch (100% Cotton)"),
    LOW_STRETCH("Low Stretch"),
    MEDIUM_STRETCH("Medium Stretch"),
    HIGH_STRETCH("High Stretch")
}

enum class LegType(val displayName: String) {
    SLIM("Slim Leg"),
    STRAIGHT("Straight Leg"),
    TAPERED("Tapered Leg"),
    WIDE("Wide Leg"),
    LOOSE("Loose Leg"),
    BOOTCUT("Bootcut")
}

data class FabricSpec(
    val cottonPercentage: Int = 100,
    val elastanePercentage: Int = 0,
    val recycledContentPercentage: Int = 15,
    val weightLabel: String = "12.5 oz Medium Weight",
    val weave: String = "Right-hand twill",
    val finish: String = "Sanforized",
    val originMetadata: String = "Cone Denim / Premium Cotton",
    val careInstructions: String = "Machine wash cold inside out with like colours. Do not tumble dry."
)

data class Variant(
    val id: String = UUID.randomUUID().toString(),
    val productId: String,
    val waist: Int,
    val length: Int,
    val sizeLabel: String = "${waist}W x ${length}L",
    val stockCount: Int = 12
)

data class Product(
    val id: String,
    val title: String,
    val subtitle: String,
    val category: ProductCategory,
    val fitCode: String,
    val fitName: String,
    val price: Double,
    val originalPrice: Double? = null,
    val wash: WashType,
    val rise: RiseType = RiseType.MID,
    val stretch: StretchType = StretchType.NON_STRETCH,
    val leg: LegType = LegType.STRAIGHT,
    val fabricSpec: FabricSpec = FabricSpec(),
    val imageUrl: String,
    val detailImages: List<String> = emptyList(),
    val description: String,
    val details: List<String> = emptyList(),
    val isIconic: Boolean = false,
    val isExclusive: Boolean = false,
    val isNew: Boolean = false,
    val collectionName: String? = null,
    val availableWaists: List<Int> = listOf(28, 29, 30, 31, 32, 33, 34, 36, 38),
    val availableLengths: List<Int> = listOf(30, 32, 34, 36)
)
