package com.example.feature.fit

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.designsystem.DeepIndigo
import com.example.core.designsystem.FitCodePatch
import com.example.core.designsystem.LeatherTan
import com.example.core.designsystem.LevisRed
import com.example.core.designsystem.OffWhite
import com.example.core.designsystem.PureWhite
import com.example.core.designsystem.RawDenim
import com.example.core.designsystem.RedTabBadge
import com.example.core.model.UserFitInput

@Composable
fun DenimProfileScreen(
    profile: UserFitInput?,
    onOpenFitFinderClick: () -> Unit,
    onCompareFitsClick: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepIndigo)
            .padding(16.dp)
    ) {
        item {
            RedTabBadge(text = "DENIM PROFILE")
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "MY DENIM SIZING & PREFERENCES",
                color = PureWhite,
                fontWeight = FontWeight.Black,
                fontSize = 22.sp
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        if (profile == null) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = RawDenim)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "NO FIT PROFILE SAVED YET",
                            color = PureWhite,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Take the 7-step Levi's Fit Finder quiz to establish your personalized denim sizing, rise, stretch and silhouette specifications.",
                            color = OffWhite.copy(alpha = 0.8f),
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = onOpenFitFinderClick,
                            colors = ButtonDefaults.buttonColors(containerColor = LevisRed)
                        ) {
                            Text("START FIT FINDER", color = PureWhite, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        } else {
            // SAVED FIT SIZES PER ICONIC LOT
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = RawDenim)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "MY SAVED LOT SIZES",
                            color = LevisRed,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.5.sp
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        SizeLotRow("MY 501® SIZE", "${profile.waistInches}W x ${profile.inseamInches}L", "Rigid 100% Cotton")
                        SizeLotRow("MY 505™ SIZE", "${profile.waistInches}W x ${profile.inseamInches}L", "Zip-Fly Regular")
                        SizeLotRow("MY 511™ SIZE", "${profile.waistInches}W x ${profile.inseamInches}L", "Slim Stretch")
                        SizeLotRow("MY TRUCKER SIZE", "LARGE (42)", "Original Trucker Jacket")
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = RawDenim)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "PREFERENCE PROFILE",
                            color = LevisRed,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.5.sp
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        ProfileMetric("GENDER / CATEGORY", profile.categoryGender)
                        ProfileMetric("HEIGHT & WAIST", "${profile.heightCm} cm • ${profile.waistInches}\" Waist")
                        ProfileMetric("PREFERRED RISE", profile.preferredRise.displayName)
                        ProfileMetric("PREFERRED SILHOUETTE", "${profile.preferredSilhouette} (${profile.desiredLooseness} room)")
                        ProfileMetric("STRETCH TOLERANCE", profile.stretchPreference.displayName)
                        ProfileMetric("STYLING FOOTWEAR", profile.typicalFootwear)
                    }
                }
            }

            item {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = onOpenFitFinderClick,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = LevisRed)
                    ) {
                        Text("RETAKE FIT FINDER", color = PureWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = onCompareFitsClick,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = RawDenim)
                    ) {
                        Text("COMPARE FITS", color = PureWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun SizeLotRow(lotLabel: String, sizeValue: String, detail: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(lotLabel, color = PureWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(detail, color = OffWhite.copy(alpha = 0.6f), fontSize = 11.sp)
        }
        Text(sizeValue, color = LeatherTan, fontWeight = FontWeight.Black, fontSize = 14.sp)
    }
}

@Composable
private fun ProfileMetric(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = OffWhite.copy(alpha = 0.6f), fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Text(value, color = PureWhite, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}
