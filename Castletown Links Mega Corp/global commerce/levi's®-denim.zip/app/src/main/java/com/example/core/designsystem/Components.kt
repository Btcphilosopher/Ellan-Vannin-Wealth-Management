package com.example.core.designsystem

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.CustomisationOption

@Composable
fun LevisTopAppBar(
    onSearchClick: () -> Unit,
    onWishlistClick: () -> Unit,
    onBagClick: () -> Unit,
    bagCount: Int = 0,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = DeepIndigo,
        shadowElevation = 4.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Red Tab Emblem
                Box(
                    modifier = Modifier
                        .background(LevisRed)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "LEVI'S®",
                        color = PureWhite,
                        fontWeight = FontWeight.Black,
                        fontSize = 15.sp,
                        letterSpacing = 1.sp
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "DENIM OS",
                    color = OffWhite.copy(alpha = 0.7f),
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    letterSpacing = 2.sp
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onSearchClick) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search Catalogue",
                        tint = OffWhite
                    )
                }
                IconButton(onClick = onWishlistClick) {
                    Icon(
                        imageVector = Icons.Default.BookmarkBorder,
                        contentDescription = "Saved Denim",
                        tint = OffWhite
                    )
                }
                IconButton(onClick = onBagClick) {
                    BadgedBox(
                        badge = {
                            if (bagCount > 0) {
                                Badge(containerColor = LevisRed, contentColor = PureWhite) {
                                    Text(bagCount.toString())
                                }
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.ShoppingBag,
                            contentDescription = "Shopping Bag",
                            tint = OffWhite
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun RedTabBadge(
    modifier: Modifier = Modifier,
    text: String = "RED TAB™"
) {
    Box(
        modifier = modifier
            .background(LevisRed)
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            text = text,
            color = PureWhite,
            fontWeight = FontWeight.Black,
            fontSize = 10.sp,
            letterSpacing = 1.2.sp
        )
    }
}

@Composable
fun FitCodePatch(
    fitCode: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .background(LeatherTan, shape = RoundedCornerShape(2.dp))
            .border(1.dp, Color(0xFF8C5A30), shape = RoundedCornerShape(2.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = "LOT $fitCode",
            color = Color(0xFF3D2310),
            fontWeight = FontWeight.Black,
            fontSize = 11.sp,
            letterSpacing = 1.sp
        )
    }
}

@Composable
fun FitScoreCard(
    score: Int,
    confidenceLabel: String,
    whyItFits: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = DenimBlue),
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .background(DeepIndigo, shape = CircleShape)
                    .border(3.dp, LevisRed, shape = CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "$score%",
                        color = PureWhite,
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp
                    )
                    Text(
                        text = "MATCH",
                        color = OffWhite.copy(alpha = 0.7f),
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = confidenceLabel,
                    color = LevisRedLight,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = whyItFits,
                    color = OffWhite,
                    fontSize = 13.sp,
                    lineHeight = 17.sp
                )
            }
        }
    }
}

@Composable
fun GarmentCustomisationCanvas2D(
    customisation: CustomisationOption,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(220.dp)
            .background(RawDenim, shape = RoundedCornerShape(8.dp))
            .border(1.dp, WashedBlue, shape = RoundedCornerShape(8.dp)),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasWidth = size.width
            val canvasHeight = size.height

            // Draw Jean Back Pocket Outline
            val path = Path().apply {
                moveTo(canvasWidth * 0.3f, canvasHeight * 0.15f)
                lineTo(canvasWidth * 0.7f, canvasHeight * 0.15f)
                lineTo(canvasWidth * 0.7f, canvasHeight * 0.70f)
                lineTo(canvasWidth * 0.5f, canvasHeight * 0.90f)
                lineTo(canvasWidth * 0.3f, canvasHeight * 0.70f)
                close()
            }

            // Fill Pocket Denim
            drawPath(path, color = Color(0xFF1C3144))
            // Arcuate Stitching (Signature Levi's Pocket Arc)
            drawPath(
                path = path,
                color = Color(0xFFD4AF37), // Golden Orange Stitch
                style = Stroke(width = 4f)
            )

            // Inner Arcuate double stitch curve
            val arcPath = Path().apply {
                moveTo(canvasWidth * 0.32f, canvasHeight * 0.40f)
                quadraticTo(
                    canvasWidth * 0.41f, canvasHeight * 0.60f,
                    canvasWidth * 0.50f, canvasHeight * 0.45f
                )
                quadraticTo(
                    canvasWidth * 0.59f, canvasHeight * 0.60f,
                    canvasWidth * 0.68f, canvasHeight * 0.40f
                )
            }
            drawPath(arcPath, color = Color(0xFFD4AF37), style = Stroke(width = 3f))

            // Draw Red Tab on side of pocket
            drawRect(
                color = Color(0xFFC8102E),
                topLeft = Offset(canvasWidth * 0.70f, canvasHeight * 0.35f),
                size = Size(canvasWidth * 0.03f, canvasHeight * 0.12f)
            )
        }

        // Customisation Overlays (Text & Patch Preview)
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(top = 10.dp)
        ) {
            Box(
                modifier = Modifier
                    .background(LeatherTan, shape = RoundedCornerShape(2.dp))
                    .padding(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text(
                    text = customisation.patchName.uppercase(),
                    color = Color(0xFF2E1B0E),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Black
                )
            }
            Spacer(modifier = Modifier.height(18.dp))
            Text(
                text = customisation.embroideryText.ifEmpty { "CUSTOM TEXT" },
                color = Color(0xFFFFD700), // Golden Thread
                fontWeight = FontWeight.Black,
                fontSize = 18.sp,
                letterSpacing = 2.sp
            )
            Text(
                text = "• ${customisation.placementLocation} •",
                color = OffWhite.copy(alpha = 0.8f),
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun DigitalMembershipCardView(
    memberName: String,
    memberId: String,
    points: Int,
    tierName: String,
    barcodeValue: String,
    onFlipClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .height(200.dp)
            .shadow(8.dp, shape = RoundedCornerShape(12.dp))
            .clickable(onClick = onFlipClick),
        colors = CardDefaults.cardColors(containerColor = RawDenim),
        shape = RoundedCornerShape(12.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .border(2.dp, LevisRed, shape = RoundedCornerShape(12.dp))
                .padding(20.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RedTabBadge(text = "RED TAB™")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = tierName,
                            color = OffWhite,
                            fontWeight = FontWeight.Black,
                            fontSize = 12.sp,
                            letterSpacing = 1.sp
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.QrCode,
                        contentDescription = "Scan Membership",
                        tint = PureWhite,
                        modifier = Modifier.size(28.dp)
                    )
                }

                Column {
                    Text(
                        text = "MEMBER",
                        color = OffWhite.copy(alpha = 0.6f),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp
                    )
                    Text(
                        text = memberName.uppercase(),
                        color = PureWhite,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "ID: $memberId",
                        color = LightDenim,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Column {
                        Text(
                            text = "POINTS BALANCE",
                            color = OffWhite.copy(alpha = 0.6f),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "$points PTS",
                            color = LevisRedLight,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Text(
                        text = "TAP TO REVEAL BARCODE",
                        color = OffWhite.copy(alpha = 0.7f),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }
            }
        }
    }
}
