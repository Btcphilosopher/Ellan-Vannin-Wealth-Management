package com.example.core.model

data class UserFitInput(
    val categoryGender: String = "Men", // "Men", "Women", "Unisex"
    val heightCm: Int = 180,
    val waistInches: Int = 32,
    val inseamInches: Int = 32,
    val preferredRise: RiseType = RiseType.MID,
    val preferredLeg: LegType = LegType.STRAIGHT,
    val preferredSilhouette: String = "Straight", // "Slim", "Straight", "Relaxed", "Loose"
    val currentFaveFit: String = "501 Original",
    val desiredLooseness: String = "Regular", // "Snug", "Regular", "Roomy", "Baggy"
    val stretchPreference: StretchType = StretchType.NON_STRETCH,
    val typicalFootwear: String = "Boots / Sneakers",
    val stylePreference: String = "Workwear"
)

data class FitRecommendation(
    val fitCode: String,
    val fitName: String,
    val fitScore: Int, // e.g. 94%
    val confidenceLabel: String, // "High Confidence", "Best Match"
    val whyItFits: String,
    val silhouette: String,
    val rise: String,
    val stretchLevel: String,
    val recommendedWaist: Int,
    val recommendedInseam: Int,
    val sampleProductId: String? = null
)

data class FitComparisonSpec(
    val fitCode: String,
    val name: String,
    val tagline: String,
    val rise: String,
    val seat: String,
    val thigh: String,
    val knee: String,
    val legOpening: String,
    val silhouetteCategory: String, // "Slim", "Straight", "Relaxed", "Loose"
    val stretch: String,
    val typicalStyling: String,
    val description: String
)
