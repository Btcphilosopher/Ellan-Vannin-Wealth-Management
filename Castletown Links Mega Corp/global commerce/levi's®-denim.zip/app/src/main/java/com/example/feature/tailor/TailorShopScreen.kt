package com.example.feature.tailor

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Sell
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.designsystem.DeepIndigo
import com.example.core.designsystem.DenimBlue
import com.example.core.designsystem.GarmentCustomisationCanvas2D
import com.example.core.designsystem.LeatherTan
import com.example.core.designsystem.LevisRed
import com.example.core.designsystem.OffWhite
import com.example.core.designsystem.PureWhite
import com.example.core.designsystem.RawDenim
import com.example.core.designsystem.RedTabBadge
import com.example.core.model.Appointment
import com.example.core.model.CustomisationOption
import com.example.core.model.TailorServiceItem

@Composable
fun TailorShopScreen(
    services: List<TailorServiceItem>,
    onBookAppointment: (Appointment) -> Unit,
    onOpenRepairClick: () -> Unit
) {
    var embroideryText by remember { mutableStateOf("LEVI'S 1873") }
    var selectedPatch by remember { mutableStateOf("Two Horse Pull Leather") }
    var selectedPlacement by remember { mutableStateOf("Back Pocket Right") }
    var appointmentBookedMessage by remember { mutableStateOf(false) }

    val patches = listOf("Two Horse Pull Leather", "Red Tab Felt", "Archival San Francisco", "Selvedge Denim")
    val placements = listOf("Back Pocket Right", "Back Pocket Left", "Waistband Center", "Front Coin Pocket")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepIndigo),
        contentPadding = PaddingValues(16.dp)
    ) {
        item {
            RedTabBadge(text = "LEVI'S® TAILOR SHOP")
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "MAKE IT YOURS",
                color = PureWhite,
                fontWeight = FontWeight.Black,
                fontSize = 28.sp,
                letterSpacing = (-0.5).sp
            )
            Text(
                text = "Chainstitch hemming, custom patches, embroidery, and alterations.",
                color = OffWhite.copy(alpha = 0.8f),
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.height(20.dp))
        }

        // 2D GARMENT CUSTOMISATION CANVAS PREVIEW
        item {
            Text(
                text = "2D GARMENT CUSTOMISATION PREVIEW",
                color = LevisRed,
                fontSize = 11.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.5.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            GarmentCustomisationCanvas2D(
                customisation = CustomisationOption(
                    patchName = selectedPatch,
                    embroideryText = embroideryText,
                    placementLocation = selectedPlacement
                )
            )

            Spacer(modifier = Modifier.height(16.dp))
        }

        // CUSTOMISATION FORM
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 20.dp),
                colors = CardDefaults.cardColors(containerColor = RawDenim),
                shape = RoundedCornerShape(8.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "CUSTOM EMBROIDERY TEXT",
                        color = PureWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    OutlinedTextField(
                        value = embroideryText,
                        onValueChange = { embroideryText = it },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = DenimBlue,
                            unfocusedContainerColor = DenimBlue,
                            focusedBorderColor = LevisRed,
                            unfocusedBorderColor = DenimBlue,
                            focusedTextColor = PureWhite,
                            unfocusedTextColor = PureWhite
                        ),
                        shape = RoundedCornerShape(4.dp)
                    )

                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "SELECT ARCHIVAL PATCH",
                        color = PureWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        patches.take(2).forEach { patch ->
                            val isSelected = patch == selectedPatch
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(if (isSelected) LevisRed else DenimBlue, shape = RoundedCornerShape(4.dp))
                                    .clickable { selectedPatch = patch }
                                    .padding(vertical = 10.dp, horizontal = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(patch, color = PureWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = {
                            onBookAppointment(
                                Appointment(
                                    storeName = "Regent St Tailor Shop",
                                    serviceName = "Customisation ($selectedPatch)",
                                    date = "FRI 30 OCT",
                                    timeSlot = "14:00 PM",
                                    garmentName = "501® Original Jeans"
                                )
                            )
                            appointmentBookedMessage = true
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = LevisRed),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = if (appointmentBookedMessage) "APPOINTMENT BOOKED!" else "BOOK TAILOR SHOP APPOINTMENT",
                            color = PureWhite,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            }
        }

        // SERVICES LIST
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "TAILOR SHOP SERVICES",
                    color = PureWhite,
                    fontWeight = FontWeight.Black,
                    fontSize = 18.sp
                )
                Text(
                    text = "NEED A REPAIR?",
                    color = LevisRed,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable(onClick = onOpenRepairClick)
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
        }

        items(services) { service ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                colors = CardDefaults.cardColors(containerColor = RawDenim),
                shape = RoundedCornerShape(8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCut,
                        contentDescription = null,
                        tint = LeatherTan,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(service.title, color = PureWhite, fontWeight = FontWeight.Black, fontSize = 16.sp)
                        Text(service.description, color = OffWhite.copy(alpha = 0.7f), fontSize = 12.sp, lineHeight = 16.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("${service.priceText} • ~${service.estimatedMinutes} mins", color = LevisRed, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
