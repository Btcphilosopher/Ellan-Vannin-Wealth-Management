package com.example.feature.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.core.designsystem.DeepIndigo
import com.example.core.designsystem.DenimBlue
import com.example.core.designsystem.FitCodePatch
import com.example.core.designsystem.LeatherTan
import com.example.core.designsystem.LevisRed
import com.example.core.designsystem.LevisRedLight
import com.example.core.designsystem.OffWhite
import com.example.core.designsystem.PureWhite
import com.example.core.designsystem.RawDenim
import com.example.core.designsystem.RedTabBadge
import com.example.core.model.EditorialStory
import com.example.core.model.Product

@Composable
fun HomeScreen(
    iconicProducts: List<Product>,
    stories: List<EditorialStory>,
    onProductClick: (String) -> Unit,
    onFitFinderClick: () -> Unit,
    onTailorClick: () -> Unit,
    onRepairClick: () -> Unit,
    onRedTabClick: () -> Unit,
    onArchiveClick: () -> Unit,
    onScannerClick: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepIndigo),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        // HERO BANNER
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(340.dp)
            ) {
                AsyncImage(
                    model = ImageRequest.Builder(LocalContext.current)
                        .data("file:///android_asset/hero_501_banner.jpg")
                        .fallback(com.example.R.drawable.hero_501_banner_1793051553057)
                        .error(com.example.R.drawable.hero_501_banner_1793051553057)
                        .build(),
                    contentDescription = "501 Original Denim Hero",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Overlay gradient
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    DeepIndigo.copy(alpha = 0.85f),
                                    DeepIndigo
                                )
                            )
                        )
                )

                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(20.dp)
                ) {
                    RedTabBadge(text = "THE ORIGINAL SINCE 1873")
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "THE 501® JEAN",
                        color = PureWhite,
                        fontWeight = FontWeight.Black,
                        fontSize = 32.sp,
                        letterSpacing = (-0.5).sp
                    )
                    Text(
                        text = "Straight fit. Button fly. Uncompromising denim.",
                        color = OffWhite.copy(alpha = 0.8f),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Row {
                        Button(
                            onClick = { onProductClick("jean_501_dark") },
                            colors = ButtonDefaults.buttonColors(containerColor = LevisRed),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text("SHOP 501®", color = PureWhite, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        OutlinedButton(
                            onClick = onFitFinderClick,
                            shape = RoundedCornerShape(4.dp),
                            border = ButtonDefaults.outlinedButtonBorder.copy(brush = Brush.horizontalGradient(listOf(OffWhite, OffWhite)))
                        ) {
                            Text("FIND YOUR FIT", color = OffWhite, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // QUICK ACTION TILES (FIT FINDER, SCANNER, TAILOR, REPAIR)
        item {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "DENIM OPERATING SYSTEM",
                    color = LevisRed,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 2.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    TileButton(
                        title = "FIT FINDER",
                        subtitle = "Find Your Fit",
                        icon = Icons.Default.Explore,
                        onClick = onFitFinderClick,
                        modifier = Modifier.weight(1f)
                    )
                    TileButton(
                        title = "SCAN BARCODE",
                        subtitle = "In-Store Scanner",
                        icon = Icons.Default.QrCodeScanner,
                        onClick = onScannerClick,
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    TileButton(
                        title = "TAILOR SHOP",
                        subtitle = "Customise",
                        icon = Icons.Default.ContentCut,
                        onClick = onTailorClick,
                        modifier = Modifier.weight(1f)
                    )
                    TileButton(
                        title = "REPAIR DENIM",
                        subtitle = "Circular Repair",
                        icon = Icons.Default.Build,
                        onClick = onRepairClick,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // ICONIC FITS CAROUSEL
        item {
            Column(modifier = Modifier.padding(vertical = 12.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "ICONIC LEVI'S® FITS",
                        color = PureWhite,
                        fontWeight = FontWeight.Black,
                        fontSize = 20.sp,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "SEE ALL",
                        color = LevisRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { onFitFinderClick() }
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(iconicProducts) { product ->
                        HomeProductCard(
                            product = product,
                            onClick = { onProductClick(product.id) }
                        )
                    }
                }
            }
        }

        // TAILOR & REPAIR CIRCULAR PHILOSOPHY CARD
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .clickable(onClick = onTailorClick),
                colors = CardDefaults.cardColors(containerColor = RawDenim),
                shape = RoundedCornerShape(8.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.ContentCut,
                            contentDescription = null,
                            tint = LeatherTan,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "LEVI'S® TAILOR SHOP",
                            color = PureWhite,
                            fontWeight = FontWeight.Black,
                            fontSize = 18.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "BUY → WEAR → ALTER → REPAIR → CUSTOMISE → KEEP",
                        color = LevisRed,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Chainstitch hemming, sashiko repairs, custom leather patches and embroidery at your nearest Levi's Tailor Shop.",
                        color = OffWhite.copy(alpha = 0.8f),
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )
                }
            }
        }

        // RED TAB MEMBERSHIP CARD
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .clickable(onClick = onRedTabClick),
                colors = CardDefaults.cardColors(containerColor = DenimBlue),
                shape = RoundedCornerShape(8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        RedTabBadge(text = "RED TAB™ MEMBER ACCESS")
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "2,840 POINTS • GOLD TIER",
                            color = PureWhite,
                            fontWeight = FontWeight.Black,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "Free shipping, birthday rewards & exclusive drop invites",
                            color = OffWhite.copy(alpha = 0.8f),
                            fontSize = 12.sp
                        )
                    }
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "Red Tab",
                        tint = LevisRed,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
        }

        // DENIM STORIES / ARCHIVE SECTION
        item {
            Column(modifier = Modifier.padding(16.dp)) {
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "LEVI'S® STORIES & ARCHIVE",
                        color = PureWhite,
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp
                    )
                    Text(
                        text = "EXPLORE",
                        color = LevisRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { onArchiveClick() }
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))

                stories.take(2).forEach { story ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp)
                            .clickable { onArchiveClick() },
                        colors = CardDefaults.cardColors(containerColor = RawDenim),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = story.category,
                                color = LevisRed,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.5.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = story.title,
                                color = PureWhite,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = story.subtitle,
                                color = OffWhite.copy(alpha = 0.7f),
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TileButton(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.clickable(onClick = onClick),
        color = DenimBlue,
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = LevisRed,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = title,
                    color = PureWhite,
                    fontWeight = FontWeight.Black,
                    fontSize = 13.sp
                )
                Text(
                    text = subtitle,
                    color = OffWhite.copy(alpha = 0.7f),
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
private fun HomeProductCard(
    product: Product,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .width(180.dp)
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = RawDenim),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .background(DeepIndigo, shape = RoundedCornerShape(6.dp)),
                contentAlignment = Alignment.TopEnd
            ) {
                AsyncImage(
                    model = ImageRequest.Builder(LocalContext.current)
                        .data("file:///android_asset/hero_501_banner.jpg")
                        .fallback(com.example.R.drawable.hero_501_banner_1793051553057)
                        .error(com.example.R.drawable.hero_501_banner_1793051553057)
                        .build(),
                    contentDescription = product.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                FitCodePatch(
                    fitCode = product.fitCode,
                    modifier = Modifier.padding(8.dp)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = product.fitName,
                color = PureWhite,
                fontWeight = FontWeight.Black,
                fontSize = 15.sp
            )
            Text(
                text = product.subtitle,
                color = OffWhite.copy(alpha = 0.7f),
                fontSize = 12.sp,
                maxLines = 1
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "£${product.price.toInt()}.00",
                color = LevisRedLight,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
        }
    }
}
