package com.example.feature.membership

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.designsystem.DeepIndigo
import com.example.core.designsystem.DigitalMembershipCardView
import com.example.core.designsystem.LeatherTan
import com.example.core.designsystem.LevisRed
import com.example.core.designsystem.LevisRedLight
import com.example.core.designsystem.OffWhite
import com.example.core.designsystem.PureWhite
import com.example.core.designsystem.RawDenim
import com.example.core.designsystem.RedTabBadge
import com.example.core.model.RedTabMember
import com.example.core.model.Voucher

@Composable
fun RedTabScreen(
    member: RedTabMember,
    vouchers: List<Voucher>,
    onOpenDropsClick: () -> Unit
) {
    var showBarcodeModal by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepIndigo),
        contentPadding = PaddingValues(16.dp)
    ) {
        item {
            RedTabBadge(text = "RED TAB™ PROGRAMME")
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "MY RED TAB™ MEMBERSHIP",
                color = PureWhite,
                fontWeight = FontWeight.Black,
                fontSize = 24.sp
            )
            Spacer(modifier = Modifier.height(16.dp))

            // DIGITAL MEMBERSHIP CARD
            DigitalMembershipCardView(
                memberName = member.memberName,
                memberId = member.memberId,
                points = member.pointsBalance,
                tierName = member.tierName,
                barcodeValue = member.barcodeValue,
                onFlipClick = { showBarcodeModal = !showBarcodeModal }
            )

            if (showBarcodeModal) {
                Spacer(modifier = Modifier.height(12.dp))
                Card(colors = CardDefaults.cardColors(containerColor = RawDenim)) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("BARCODE FOR IN-STORE SCANNING", color = LevisRed, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(member.barcodeValue, color = PureWhite, fontWeight = FontWeight.Black, fontSize = 22.sp, letterSpacing = 3.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }

        // EXCLUSIVE DROPS ENTRY
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 20.dp),
                colors = CardDefaults.cardColors(containerColor = RawDenim)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("EXCLUSIVE DROPS & EARLY ACCESS", color = PureWhite, fontWeight = FontWeight.Black, fontSize = 16.sp)
                        Text("LVC reproductions, Japanese selvedge & collaborations.", color = OffWhite.copy(alpha = 0.8f), fontSize = 12.sp)
                    }
                    Button(
                        onClick = onOpenDropsClick,
                        colors = ButtonDefaults.buttonColors(containerColor = LevisRed)
                    ) {
                        Text("VIEW DROPS", color = PureWhite, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // REWARDS ACCOUNT & VOUCHERS
        item {
            Text(
                text = "AVAILABLE VOUCHERS & REWARDS",
                color = LevisRed,
                fontSize = 11.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.5.sp
            )
            Spacer(modifier = Modifier.height(10.dp))
        }

        items(vouchers) { voucher ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                colors = CardDefaults.cardColors(containerColor = RawDenim)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(voucher.discountText, color = LeatherTan, fontWeight = FontWeight.Black, fontSize = 18.sp)
                        Text(voucher.title, color = PureWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(voucher.expiryDate, color = OffWhite.copy(alpha = 0.6f), fontSize = 11.sp)
                    }
                    Button(
                        onClick = { },
                        colors = ButtonDefaults.buttonColors(containerColor = LevisRed),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text("APPLY", color = PureWhite, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}
