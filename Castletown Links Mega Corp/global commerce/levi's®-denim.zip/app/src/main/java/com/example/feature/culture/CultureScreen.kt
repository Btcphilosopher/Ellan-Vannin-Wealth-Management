package com.example.feature.culture

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.designsystem.DeepIndigo
import com.example.core.designsystem.FitCodePatch
import com.example.core.designsystem.LeatherTan
import com.example.core.designsystem.LevisRed
import com.example.core.designsystem.OffWhite
import com.example.core.designsystem.PureWhite
import com.example.core.designsystem.RawDenim
import com.example.core.designsystem.RedTabBadge
import com.example.core.model.ArchiveEvent
import com.example.core.model.EditorialStory

@Composable
fun CultureScreen(
    stories: List<EditorialStory>,
    archiveTimeline: List<ArchiveEvent>,
    onStoryClick: (EditorialStory) -> Unit,
    onShopFitClick: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepIndigo),
        contentPadding = PaddingValues(16.dp)
    ) {
        item {
            RedTabBadge(text = "CULTURE & ARCHIVE")
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "LEVI'S® STORIES & HERITAGE",
                color = PureWhite,
                fontWeight = FontWeight.Black,
                fontSize = 26.sp
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        // EDITORIAL STORIES
        item {
            Text("EDITORIAL PUBLICATIONS", color = LevisRed, fontSize = 11.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
            Spacer(modifier = Modifier.height(10.dp))
        }

        items(stories) { story ->
            Card(
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp).clickable { onStoryClick(story) },
                colors = CardDefaults.cardColors(containerColor = RawDenim)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(story.category, color = LevisRed, fontSize = 10.sp, fontWeight = FontWeight.Black)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(story.title, color = PureWhite, fontWeight = FontWeight.Black, fontSize = 18.sp)
                    Text("By ${story.author} • ${story.date}", color = OffWhite.copy(alpha = 0.6f), fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(story.bodyText, color = OffWhite.copy(alpha = 0.8f), fontSize = 13.sp, lineHeight = 18.sp)
                }
            }
        }

        // INTERACTIVE TIMELINE ARCHIVE
        item {
            Spacer(modifier = Modifier.height(12.dp))
            Text("THE LEVI'S® ARCHIVE (1873 - 2026)", color = LevisRed, fontSize = 11.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
            Spacer(modifier = Modifier.height(10.dp))
        }

        items(archiveTimeline) { event ->
            Card(
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                colors = CardDefaults.cardColors(containerColor = RawDenim)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(event.year, color = LeatherTan, fontWeight = FontWeight.Black, fontSize = 22.sp)
                        FitCodePatch(fitCode = event.iconicFitCode)
                    }
                    Text(event.title, color = PureWhite, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(event.era, color = OffWhite.copy(alpha = 0.7f), fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(event.summary, color = OffWhite.copy(alpha = 0.8f), fontSize = 13.sp, lineHeight = 17.sp)

                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = { onShopFitClick(event.iconicFitCode) },
                        colors = ButtonDefaults.buttonColors(containerColor = LevisRed),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text("SHOP MODERN ${event.iconicFitCode} FIT", color = PureWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
