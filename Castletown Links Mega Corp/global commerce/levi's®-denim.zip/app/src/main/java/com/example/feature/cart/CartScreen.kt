package com.example.feature.cart

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.designsystem.DeepIndigo
import com.example.core.designsystem.DenimBlue
import com.example.core.designsystem.FitCodePatch
import com.example.core.designsystem.LeatherTan
import com.example.core.designsystem.LevisRed
import com.example.core.designsystem.LevisRedLight
import com.example.core.designsystem.OffWhite
import com.example.core.designsystem.PureWhite
import com.example.core.designsystem.RawDenim
import com.example.core.designsystem.RedTabBadge
import com.example.core.model.CartItem

@Composable
fun CartScreen(
    items: List<CartItem>,
    onRemoveItem: (String) -> Unit,
    onCheckoutClick: () -> Unit,
    onShopMoreClick: () -> Unit
) {
    val subtotal = items.sumOf { it.product.price * it.quantity }
    var rewardsApplied by remember { mutableStateOf(false) }
    val discount = if (rewardsApplied) 10.0 else 0.0
    val total = (subtotal - discount).coerceAtLeast(0.0)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepIndigo),
        contentPadding = PaddingValues(16.dp)
    ) {
        item {
            RedTabBadge(text = "SHOPPING BAG")
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "YOUR LEVI'S® BAG (${items.size})",
                color = PureWhite,
                fontWeight = FontWeight.Black,
                fontSize = 24.sp
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        if (items.isEmpty()) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = RawDenim)) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("YOUR BAG IS EMPTY", color = PureWhite, fontWeight = FontWeight.Black, fontSize = 18.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Explore 501® Original, Trucker Jackets, and find your fit.", color = OffWhite.copy(alpha = 0.8f), fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(onClick = onShopMoreClick, colors = ButtonDefaults.buttonColors(containerColor = LevisRed)) {
                            Text("EXPLORE DENIM CATALOGUE", color = PureWhite, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        } else {
            items(items) { item ->
                Card(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                    colors = CardDefaults.cardColors(containerColor = RawDenim),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                FitCodePatch(fitCode = item.product.fitCode)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(item.product.title, color = PureWhite, fontWeight = FontWeight.Black, fontSize = 15.sp)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Size: ${item.waist}W x ${item.length}L • Qty: ${item.quantity}", color = OffWhite.copy(alpha = 0.8f), fontSize = 12.sp)
                            Text("£${item.product.price.toInt()}.00 each", color = LevisRedLight, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }

                        IconButton(onClick = { onRemoveItem(item.id) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Remove", tint = OffWhite.copy(alpha = 0.6f))
                        }
                    }
                }
            }

            // REWARDS APPLICATION
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                    colors = CardDefaults.cardColors(containerColor = RawDenim)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("RED TAB™ REWARDS DISCOUNT", color = LevisRed, fontWeight = FontWeight.Black, fontSize = 11.sp, letterSpacing = 1.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Apply 1,000 Points (£10 Voucher)", color = PureWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Button(
                                onClick = { rewardsApplied = !rewardsApplied },
                                colors = ButtonDefaults.buttonColors(containerColor = if (rewardsApplied) LevisRed else DenimBlue)
                            ) {
                                Text(if (rewardsApplied) "APPLIED (-£10)" else "APPLY VOUCHER", color = PureWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // ORDER SUMMARY
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 20.dp),
                    colors = CardDefaults.cardColors(containerColor = RawDenim)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("ORDER SUMMARY", color = PureWhite, fontWeight = FontWeight.Black, fontSize = 16.sp)
                        Spacer(modifier = Modifier.height(10.dp))

                        SummaryRow("Subtotal", "£${subtotal.toInt()}.00")
                        SummaryRow("Red Tab™ Discount", if (rewardsApplied) "-£10.00" else "£0.00")
                        SummaryRow("Standard Delivery", "FREE (Red Tab Member)")
                        Spacer(modifier = Modifier.height(8.dp))
                        SummaryRow("TOTAL", "£${total.toInt()}.00", isBold = true)

                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = onCheckoutClick,
                            modifier = Modifier.fillMaxWidth().height(50.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = LevisRed)
                        ) {
                            Text("PROCEED TO CHECKOUT • £${total.toInt()}.00", color = PureWhite, fontWeight = FontWeight.Black)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SummaryRow(label: String, value: String, isBold: Boolean = false) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = if (isBold) PureWhite else OffWhite.copy(alpha = 0.7f), fontWeight = if (isBold) FontWeight.Black else FontWeight.Medium, fontSize = 13.sp)
        Text(value, color = if (isBold) LevisRedLight else PureWhite, fontWeight = if (isBold) FontWeight.Black else FontWeight.Bold, fontSize = 14.sp)
    }
}
