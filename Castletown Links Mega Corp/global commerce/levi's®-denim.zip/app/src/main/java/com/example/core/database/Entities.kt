package com.example.core.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cart_items")
data class CartEntity(
    @PrimaryKey val id: String,
    val productId: String,
    val waist: Int,
    val length: Int,
    val quantity: Int,
    val customisationJson: String? = null
)

@Entity(tableName = "wishlist_items")
data class WishlistEntity(
    @PrimaryKey val productId: String,
    val addedTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "wardrobe_items")
data class WardrobeEntity(
    @PrimaryKey val id: String,
    val productId: String,
    val productName: String,
    val fitCode: String,
    val sizeLabel: String,
    val washName: String,
    val purchaseDate: String,
    val ageMonths: Int,
    val wearCount: Int,
    val repairCount: Int,
    val washCount: Int,
    val photoUrl: String,
    val notes: String
)

@Entity(tableName = "repair_requests")
data class RepairEntity(
    @PrimaryKey val id: String,
    val garmentName: String,
    val purchaseDate: String,
    val damageType: String,
    val photoUrl: String?,
    val serviceRequested: String,
    val storeName: String,
    val status: String,
    val estimatedCompletionDate: String,
    val quotedPrice: Double,
    val notes: String
)

@Entity(tableName = "appointments")
data class AppointmentEntity(
    @PrimaryKey val id: String,
    val storeName: String,
    val serviceName: String,
    val date: String,
    val timeSlot: String,
    val garmentName: String,
    val status: String
)

@Entity(tableName = "user_fit_profile")
data class FitProfileEntity(
    @PrimaryKey val id: Int = 1,
    val categoryGender: String,
    val heightCm: Int,
    val waistInches: Int,
    val inseamInches: Int,
    val preferredRise: String,
    val preferredLeg: String,
    val preferredSilhouette: String,
    val currentFaveFit: String,
    val desiredLooseness: String,
    val stretchPreference: String,
    val typicalFootwear: String,
    val stylePreference: String
)
