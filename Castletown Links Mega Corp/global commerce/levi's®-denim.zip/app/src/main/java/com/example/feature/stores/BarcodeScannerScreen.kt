package com.example.feature.stores

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.designsystem.DeepIndigo
import com.example.core.designsystem.DenimBlue
import com.example.core.designsystem.FitCodePatch
import com.example.core.designsystem.LevisRed
import com.example.core.designsystem.LevisRedLight
import com.example.core.designsystem.OffWhite
import com.example.core.designsystem.PureWhite
import com.example.core.designsystem.RawDenim
import com.example.core.designsystem.RedTabBadge
import com.example.core.repository.BarcodeResult

@Composable
fun BarcodeScannerScreen(
    onBackClick: () -> Unit,
    onBarcodeScanned: (String) -> BarcodeResult,
    onProductClick: (String) -> Unit
) {
    var manualBarcode by remember { mutableStateOf("EAN-501-9301283") }
    var scanResult by remember { mutableStateOf<BarcodeResult?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepIndigo)
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBackClick) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = PureWhite)
            }
            Spacer(modifier = Modifier.width(8.dp))
            RedTabBadge(text = "IN-STORE MODE")
        }

        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = "SCAN LEVI'S® BARCODE / EAN",
            color = PureWhite,
            fontWeight = FontWeight.Black,
            fontSize = 22.sp
        )
        Text(
            text = "Point camera at pocket hangtag or type UPC code below",
            color = OffWhite.copy(alpha = 0.8f),
            fontSize = 13.sp
        )

        Spacer(modifier = Modifier.height(20.dp))

        // CAMERA SCANNER SIMULATION FRAME
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(220.dp)
                .background(RawDenim, shape = RoundedCornerShape(12.dp))
                .border(2.dp, LevisRed, shape = RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.QrCodeScanner,
                    contentDescription = "Scanning",
                    tint = LevisRedLight,
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "ALIGN BARCODE IN FRAME",
                    color = PureWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    letterSpacing = 1.5.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // MANUAL SKU / BARCODE INPUT
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = RawDenim)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("MANUAL BARCODE / SKU LOOKUP", color = PureWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = manualBarcode,
                    onValueChange = { manualBarcode = it },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = DenimBlue,
                        unfocusedContainerColor = DenimBlue,
                        focusedBorderColor = LevisRed,
                        unfocusedBorderColor = DenimBlue,
                        focusedTextColor = PureWhite,
                        unfocusedTextColor = PureWhite
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = {
                        scanResult = onBarcodeScanned(manualBarcode)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = LevisRed)
                ) {
                    Text("SIMULATE BARCODE SCAN", color = PureWhite, fontWeight = FontWeight.Bold)
                }
            }
        }

        // SCANNED PRODUCT RESULT
        scanResult?.let { result ->
            Spacer(modifier = Modifier.height(16.dp))
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onProductClick(result.productId) },
                colors = CardDefaults.cardColors(containerColor = RawDenim),
                shape = RoundedCornerShape(8.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FitCodePatch(fitCode = result.fitCode)
                        Text(result.price, color = LevisRedLight, fontWeight = FontWeight.Black, fontSize = 16.sp)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(result.title, color = PureWhite, fontWeight = FontWeight.Black, fontSize = 16.sp)
                    Text("In-Store Status: ${result.stockStatus}", color = OffWhite.copy(alpha = 0.8f), fontSize = 12.sp)

                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = { onProductClick(result.productId) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = LevisRed)
                    ) {
                        Text("VIEW PRODUCT DETAILS & SIZES", color = PureWhite, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
