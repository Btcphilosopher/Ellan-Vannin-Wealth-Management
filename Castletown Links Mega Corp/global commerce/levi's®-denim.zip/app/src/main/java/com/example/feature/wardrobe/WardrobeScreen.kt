package com.example.feature.wardrobe

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.designsystem.DeepIndigo
import com.example.core.designsystem.DenimBlue
import com.example.core.designsystem.FitCodePatch
import com.example.core.designsystem.LeatherTan
import com.example.core.designsystem.LevisRed
import com.example.core.designsystem.LevisRedLight
import com.example.core.designsystem.OffWhite
import com.example.core.designsystem.PureWhite
import com.example.core.designsystem.RawDenim
import com.example.core.designsystem.RedTabBadge
import com.example.core.model.WardrobeItem

@Composable
fun WardrobeScreen(
    items: List<WardrobeItem>,
    onItemClick: (WardrobeItem) -> Unit,
    onAddGarmentClick: () -> Unit,
    onIncrementWear: (String) -> Unit,
    onIncrementWash: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepIndigo),
        contentPadding = PaddingValues(16.dp)
    ) {
        item {
            RedTabBadge(text = "MY DIGITAL ARCHIVE")
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "MY LEVI'S® WARDROBE",
                color = PureWhite,
                fontWeight = FontWeight.Black,
                fontSize = 26.sp
            )
            Text(
                text = "Track age, wears, washes, repairs and fade character.",
                color = OffWhite.copy(alpha = 0.8f),
                fontSize = 13.sp
            )
            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = onAddGarmentClick,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = LevisRed)
            ) {
                Text("REGISTER NEW GARMENT TO WARDROBE", color = PureWhite, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        if (items.isEmpty()) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = RawDenim)) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("NO DENIM REGISTERED YET", color = PureWhite, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Add your 501® or Trucker jacket to track age, wear count, and fade story.", color = OffWhite.copy(alpha = 0.7f), fontSize = 12.sp)
                    }
                }
            }
        }

        items(items) { item ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 14.dp)
                    .clickable { onItemClick(item) },
                colors = CardDefaults.cardColors(containerColor = RawDenim),
                shape = RoundedCornerShape(8.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            FitCodePatch(fitCode = item.fitCode)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(item.productName, color = PureWhite, fontWeight = FontWeight.Black, fontSize = 16.sp)
                        }
                        Text(item.sizeLabel, color = LeatherTan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Wash: ${item.washName} • Purchased: ${item.purchaseDate}", color = OffWhite.copy(alpha = 0.8f), fontSize = 12.sp)

                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("AGE", color = OffWhite.copy(alpha = 0.6f), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Text("${item.ageMonths} MONTHS", color = PureWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Column {
                            Text("WEARS", color = OffWhite.copy(alpha = 0.6f), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Text("${item.wearCount} WEARS", color = LevisRedLight, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Column {
                            Text("WASHES", color = OffWhite.copy(alpha = 0.6f), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Text("${item.washCount} WASHES", color = PureWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Column {
                            Text("REPAIRS", color = OffWhite.copy(alpha = 0.6f), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Text("${item.repairCount} REPAIRS", color = PureWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { onIncrementWear(item.id) },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = DenimBlue)
                        ) {
                            Text("+1 WEAR TODAY", color = PureWhite, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = { onIncrementWash(item.id) },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = DenimBlue)
                        ) {
                            Text("+1 WASH", color = PureWhite, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
