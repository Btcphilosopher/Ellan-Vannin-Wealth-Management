package com.example.feature.fit

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.designsystem.DeepIndigo
import com.example.core.designsystem.DenimBlue
import com.example.core.designsystem.FitScoreCard
import com.example.core.designsystem.LevisRed
import com.example.core.designsystem.LevisRedLight
import com.example.core.designsystem.OffWhite
import com.example.core.designsystem.PureWhite
import com.example.core.designsystem.RawDenim
import com.example.core.designsystem.RedTabBadge
import com.example.core.model.FitEngine
import com.example.core.model.FitRecommendation
import com.example.core.model.LegType
import com.example.core.model.RiseType
import com.example.core.model.StretchType
import com.example.core.model.UserFitInput

@Composable
fun FitFinderScreen(
    onSaveProfileAndShop: (UserFitInput) -> Unit,
    onProductClick: (String) -> Unit,
    onCompareFitsClick: () -> Unit,
    onCloseClick: () -> Unit
) {
    var step by remember { mutableIntStateOf(1) }

    // User fit choices
    var categoryGender by remember { mutableStateOf("Men") }
    var heightCm by remember { mutableIntStateOf(180) }
    var waistInches by remember { mutableIntStateOf(32) }
    var inseamInches by remember { mutableIntStateOf(32) }
    var preferredRise by remember { mutableStateOf(RiseType.MID) }
    var preferredLeg by remember { mutableStateOf(LegType.STRAIGHT) }
    var preferredSilhouette by remember { mutableStateOf("Straight") }
    var currentFaveFit by remember { mutableStateOf("501 Original") }
    var desiredLooseness by remember { mutableStateOf("Regular") }
    var stretchPreference by remember { mutableStateOf(StretchType.NON_STRETCH) }
    var typicalFootwear by remember { mutableStateOf("Boots / Sneakers") }

    var recommendations by remember { mutableStateOf<List<FitRecommendation>>(emptyList()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepIndigo)
            .padding(16.dp)
    ) {
        // TOP HEADER
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = {
                    if (step > 1 && step <= 7) step-- else onCloseClick()
                }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = PureWhite)
                }
                Spacer(modifier = Modifier.width(8.dp))
                RedTabBadge(text = "LEVI'S® FIT FINDER")
            }

            Text(
                text = if (step <= 7) "STEP $step OF 7" else "YOUR FIT PROFILE",
                color = LevisRed,
                fontWeight = FontWeight.Black,
                fontSize = 12.sp,
                letterSpacing = 1.sp
            )
        }

        if (step <= 7) {
            Spacer(modifier = Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { step / 7f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp),
                color = LevisRed,
                trackColor = DenimBlue
            )
            Spacer(modifier = Modifier.height(20.dp))
        }

        // STEP CONTENT
        when (step) {
            1 -> Step1CategoryAndHeight(
                gender = categoryGender,
                onGenderSelect = { categoryGender = it },
                waist = waistInches,
                onWaistSelect = { waistInches = it },
                inseam = inseamInches,
                onInseamSelect = { inseamInches = it },
                onNext = { step = 2 }
            )
            2 -> Step2RisePreference(
                selected = preferredRise,
                onSelect = { preferredRise = it },
                onNext = { step = 3 }
            )
            3 -> Step3SilhouettePreference(
                selected = preferredSilhouette,
                onSelect = { preferredSilhouette = it },
                onNext = { step = 4 }
            )
            4 -> Step4LoosenessPreference(
                selected = desiredLooseness,
                onSelect = { desiredLooseness = it },
                onNext = { step = 5 }
            )
            5 -> Step5StretchPreference(
                selected = stretchPreference,
                onSelect = { stretchPreference = it },
                onNext = { step = 6 }
            )
            6 -> Step6CurrentFaveAndFootwear(
                fave = currentFaveFit,
                onFaveSelect = { currentFaveFit = it },
                footwear = typicalFootwear,
                onFootwearSelect = { typicalFootwear = it },
                onNext = { step = 7 }
            )
            7 -> Step7ReviewAndCalculate(
                userInput = UserFitInput(
                    categoryGender = categoryGender,
                    heightCm = heightCm,
                    waistInches = waistInches,
                    inseamInches = inseamInches,
                    preferredRise = preferredRise,
                    preferredLeg = preferredLeg,
                    preferredSilhouette = preferredSilhouette,
                    currentFaveFit = currentFaveFit,
                    desiredLooseness = desiredLooseness,
                    stretchPreference = stretchPreference,
                    typicalFootwear = typicalFootwear
                ),
                onCalculate = {
                    val input = UserFitInput(
                        categoryGender = categoryGender,
                        heightCm = heightCm,
                        waistInches = waistInches,
                        inseamInches = inseamInches,
                        preferredRise = preferredRise,
                        preferredLeg = preferredLeg,
                        preferredSilhouette = preferredSilhouette,
                        currentFaveFit = currentFaveFit,
                        desiredLooseness = desiredLooseness,
                        stretchPreference = stretchPreference,
                        typicalFootwear = typicalFootwear
                    )
                    recommendations = FitEngine.calculateRecommendations(input)
                    onSaveProfileAndShop(input)
                    step = 8 // Results step
                }
            )
            8 -> Step8FitResults(
                recommendations = recommendations,
                onProductClick = onProductClick,
                onCompareFitsClick = onCompareFitsClick
            )
        }
    }
}

@Composable
private fun Step1CategoryAndHeight(
    gender: String,
    onGenderSelect: (String) -> Unit,
    waist: Int,
    onWaistSelect: (Int) -> Unit,
    inseam: Int,
    onInseamSelect: (Int) -> Unit,
    onNext: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Text(
            text = "WHAT CATEGORY & SIZING DO YOU WEAR?",
            color = PureWhite,
            fontWeight = FontWeight.Black,
            fontSize = 20.sp
        )
        Spacer(modifier = Modifier.height(16.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf("Men", "Women", "Unisex").forEach { g ->
                val isSelected = g == gender
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .background(if (isSelected) LevisRed else DenimBlue, shape = RoundedCornerShape(4.dp))
                        .clickable { onGenderSelect(g) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = g, color = PureWhite, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
        Text(text = "TYPICAL WAIST SIZE: ${waist}\"", color = OffWhite, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(28, 30, 31, 32, 33, 34, 36, 38).forEach { w ->
                val isSelected = w == waist
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .background(if (isSelected) LevisRed else DenimBlue, shape = RoundedCornerShape(4.dp))
                        .clickable { onWaistSelect(w) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "$w", color = PureWhite, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
        Text(text = "TYPICAL INSEAM / LENGTH: L${inseam}\"", color = OffWhite, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(30, 32, 34, 36).forEach { l ->
                val isSelected = l == inseam
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .background(if (isSelected) LevisRed else DenimBlue, shape = RoundedCornerShape(4.dp))
                        .clickable { onInseamSelect(l) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "L$l", color = PureWhite, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.weight(1f))
        Button(
            onClick = onNext,
            modifier = Modifier.fillMaxWidth().height(50.dp),
            colors = ButtonDefaults.buttonColors(containerColor = LevisRed)
        ) {
            Text("NEXT: PREFERRED RISE", color = PureWhite, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun Step2RisePreference(
    selected: RiseType,
    onSelect: (RiseType) -> Unit,
    onNext: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Text("WHAT RISE DO YOU PREFER?", color = PureWhite, fontWeight = FontWeight.Black, fontSize = 20.sp)
        Spacer(modifier = Modifier.height(16.dp))

        RiseType.entries.forEach { rise ->
            val isSelected = rise == selected
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
                    .clickable { onSelect(rise) },
                colors = CardDefaults.cardColors(containerColor = if (isSelected) RawDenim else DenimBlue),
                border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, LevisRed) else null
            ) {
                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(rise.displayName, color = PureWhite, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text(
                            when (rise) {
                                RiseType.LOW -> "Sits below waist, casual slouched feel."
                                RiseType.MID -> "Sits at natural waist, timeless Levi's standard."
                                RiseType.HIGH -> "Sits high above waist, retro vintage coverage."
                            },
                            color = OffWhite.copy(alpha = 0.7f),
                            fontSize = 12.sp
                        )
                    }
                    if (isSelected) Icon(Icons.Default.CheckCircle, contentDescription = null, tint = LevisRed)
                }
            }
        }

        Spacer(modifier = Modifier.weight(1f))
        Button(onClick = onNext, modifier = Modifier.fillMaxWidth().height(50.dp), colors = ButtonDefaults.buttonColors(containerColor = LevisRed)) {
            Text("NEXT: SILHOUETTE", color = PureWhite, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun Step3SilhouettePreference(
    selected: String,
    onSelect: (String) -> Unit,
    onNext: () -> Unit
) {
    val silhouettes = listOf("Slim", "Straight", "Relaxed", "Loose")
    Column(modifier = Modifier.fillMaxSize()) {
        Text("WHAT LEG SILHOUETTE ARE YOU LOOKING FOR?", color = PureWhite, fontWeight = FontWeight.Black, fontSize = 20.sp)
        Spacer(modifier = Modifier.height(16.dp))

        silhouettes.forEach { sil ->
            val isSelected = sil == selected
            Card(
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp).clickable { onSelect(sil) },
                colors = CardDefaults.cardColors(containerColor = if (isSelected) RawDenim else DenimBlue),
                border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, LevisRed) else null
            ) {
                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(sil.uppercase(), color = PureWhite, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f))
                    if (isSelected) Icon(Icons.Default.CheckCircle, contentDescription = null, tint = LevisRed)
                }
            }
        }

        Spacer(modifier = Modifier.weight(1f))
        Button(onClick = onNext, modifier = Modifier.fillMaxWidth().height(50.dp), colors = ButtonDefaults.buttonColors(containerColor = LevisRed)) {
            Text("NEXT: LOOSENESS", color = PureWhite, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun Step4LoosenessPreference(
    selected: String,
    onSelect: (String) -> Unit,
    onNext: () -> Unit
) {
    val options = listOf("Snug", "Regular", "Roomy", "Baggy")
    Column(modifier = Modifier.fillMaxSize()) {
        Text("HOW MUCH ROOM THROUGH THE SEAT & THIGH?", color = PureWhite, fontWeight = FontWeight.Black, fontSize = 20.sp)
        Spacer(modifier = Modifier.height(16.dp))

        options.forEach { opt ->
            val isSelected = opt == selected
            Card(
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp).clickable { onSelect(opt) },
                colors = CardDefaults.cardColors(containerColor = if (isSelected) RawDenim else DenimBlue),
                border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, LevisRed) else null
            ) {
                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(opt, color = PureWhite, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f))
                    if (isSelected) Icon(Icons.Default.CheckCircle, contentDescription = null, tint = LevisRed)
                }
            }
        }

        Spacer(modifier = Modifier.weight(1f))
        Button(onClick = onNext, modifier = Modifier.fillMaxWidth().height(50.dp), colors = ButtonDefaults.buttonColors(containerColor = LevisRed)) {
            Text("NEXT: STRETCH", color = PureWhite, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun Step5StretchPreference(
    selected: StretchType,
    onSelect: (StretchType) -> Unit,
    onNext: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Text("STRETCH PREFERENCE", color = PureWhite, fontWeight = FontWeight.Black, fontSize = 20.sp)
        Spacer(modifier = Modifier.height(16.dp))

        StretchType.entries.forEach { stretch ->
            val isSelected = stretch == selected
            Card(
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp).clickable { onSelect(stretch) },
                colors = CardDefaults.cardColors(containerColor = if (isSelected) RawDenim else DenimBlue),
                border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, LevisRed) else null
            ) {
                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(stretch.displayName, color = PureWhite, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.weight(1f))
                    if (isSelected) Icon(Icons.Default.CheckCircle, contentDescription = null, tint = LevisRed)
                }
            }
        }

        Spacer(modifier = Modifier.weight(1f))
        Button(onClick = onNext, modifier = Modifier.fillMaxWidth().height(50.dp), colors = ButtonDefaults.buttonColors(containerColor = LevisRed)) {
            Text("NEXT: CURRENT FAVORITE", color = PureWhite, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun Step6CurrentFaveAndFootwear(
    fave: String,
    onFaveSelect: (String) -> Unit,
    footwear: String,
    onFootwearSelect: (String) -> Unit,
    onNext: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Text("WHAT IS YOUR CURRENT FAVORITE FIT?", color = PureWhite, fontWeight = FontWeight.Black, fontSize = 18.sp)
        Spacer(modifier = Modifier.height(12.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("501 Original", "505 Regular", "511 Slim", "568 Loose").forEach { item ->
                val isSelected = item == fave
                Box(
                    modifier = Modifier.weight(1f).height(40.dp).background(if (isSelected) LevisRed else DenimBlue, shape = RoundedCornerShape(4.dp)).clickable { onFaveSelect(item) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(item, color = PureWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
        Text("TYPICAL FOOTWEAR STYLING?", color = PureWhite, fontWeight = FontWeight.Black, fontSize = 18.sp)
        Spacer(modifier = Modifier.height(12.dp))

        listOf("Boots / Workwear", "Low-top Sneakers", "Chunky / Skate Shoes", "Dress Shoes / Loafers").forEach { fw ->
            val isSelected = fw == footwear
            Card(
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp).clickable { onFootwearSelect(fw) },
                colors = CardDefaults.cardColors(containerColor = if (isSelected) RawDenim else DenimBlue)
            ) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(fw, color = PureWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.weight(1f))
                    if (isSelected) Icon(Icons.Default.CheckCircle, contentDescription = null, tint = LevisRed)
                }
            }
        }

        Spacer(modifier = Modifier.weight(1f))
        Button(onClick = onNext, modifier = Modifier.fillMaxWidth().height(50.dp), colors = ButtonDefaults.buttonColors(containerColor = LevisRed)) {
            Text("CALCULATE MY FIT PROFILE", color = PureWhite, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun Step7ReviewAndCalculate(
    userInput: UserFitInput,
    onCalculate: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Text("SUMMARY OF YOUR PREFERENCES", color = PureWhite, fontWeight = FontWeight.Black, fontSize = 20.sp)
        Spacer(modifier = Modifier.height(16.dp))

        Card(colors = CardDefaults.cardColors(containerColor = RawDenim)) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("SIZING: ${userInput.waistInches}W x ${userInput.inseamInches}L (${userInput.categoryGender})", color = PureWhite, fontWeight = FontWeight.Bold)
                Text("SILHOUETTE: ${userInput.preferredSilhouette} (${userInput.desiredLooseness} room)", color = OffWhite)
                Text("RISE & STRETCH: ${userInput.preferredRise.displayName} • ${userInput.stretchPreference.displayName}", color = OffWhite)
                Text("STYLING: ${userInput.typicalFootwear}", color = OffWhite)
            }
        }

        Spacer(modifier = Modifier.weight(1f))
        Button(
            onClick = onCalculate,
            modifier = Modifier.fillMaxWidth().height(54.dp),
            colors = ButtonDefaults.buttonColors(containerColor = LevisRed)
        ) {
            Text("GENERATE DETERMINISTIC FIT MATCHES", color = PureWhite, fontWeight = FontWeight.Black, fontSize = 14.sp)
        }
    }
}

@Composable
private fun Step8FitResults(
    recommendations: List<FitRecommendation>,
    onProductClick: (String) -> Unit,
    onCompareFitsClick: () -> Unit
) {
    LazyColumn(modifier = Modifier.fillMaxSize()) {
        item {
            Text("YOUR RECOMMENDED LEVI'S® FITS", color = PureWhite, fontWeight = FontWeight.Black, fontSize = 22.sp)
            Text("Engineered by Levi's Fit Engine", color = LevisRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = onCompareFitsClick,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = DenimBlue)
            ) {
                Text("COMPARE FITS SIDE-BY-SIDE", color = PureWhite, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        items(recommendations) { rec ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 14.dp)
                    .clickable { rec.sampleProductId?.let { onProductClick(it) } },
                colors = CardDefaults.cardColors(containerColor = RawDenim),
                shape = RoundedCornerShape(8.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(rec.fitName, color = PureWhite, fontWeight = FontWeight.Black, fontSize = 18.sp)
                        RedTabBadge(text = "${rec.fitScore}% MATCH")
                    }
                    Spacer(modifier = Modifier.height(8.dp))

                    FitScoreCard(
                        score = rec.fitScore,
                        confidenceLabel = rec.confidenceLabel,
                        whyItFits = rec.whyItFits
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "RECOMMENDED SIZE: ${rec.recommendedWaist}W x ${rec.recommendedInseam}L",
                        color = LevisRedLight,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}
