package com.example.core.repository

import com.example.core.model.FabricSpec
import com.example.core.model.FitCategory
import com.example.core.model.LegType
import com.example.core.model.Product
import com.example.core.model.ProductCategory
import com.example.core.model.RiseType
import com.example.core.model.StretchType
import com.example.core.model.WashType

class DenimRepository {

    private val products: List<Product> by lazy {
        generateSyntheticProducts()
    }

    fun getAllProducts(): List<Product> = products

    fun getProductById(id: String): Product? = products.find { it.id == id }

    fun getIconicProducts(): List<Product> = products.filter { it.isIconic }

    fun getProductsByCategory(category: ProductCategory): List<Product> =
        products.filter { it.category == category }

    fun getProductsByFitCode(fitCode: String): List<Product> =
        products.filter { it.fitCode == fitCode }

    fun searchProducts(query: String): List<Product> {
        if (query.isBlank()) return products
        val q = query.lowercase().trim()
        return products.filter {
            it.title.lowercase().contains(q) ||
                    it.fitCode.lowercase().contains(q) ||
                    it.wash.displayName.lowercase().contains(q) ||
                    it.category.displayName.lowercase().contains(q) ||
                    it.description.lowercase().contains(q)
        }
    }

    fun filterProducts(
        category: ProductCategory? = null,
        fitCode: String? = null,
        wash: WashType? = null,
        rise: RiseType? = null,
        stretch: StretchType? = null,
        minPrice: Double? = null,
        maxPrice: Double? = null
    ): List<Product> {
        return products.filter { product ->
            (category == null || product.category == category) &&
                    (fitCode == null || product.fitCode == fitCode) &&
                    (wash == null || product.wash == wash) &&
                    (rise == null || product.rise == rise) &&
                    (stretch == null || product.stretch == stretch) &&
                    (minPrice == null || product.price >= minPrice) &&
                    (maxPrice == null || product.price <= maxPrice)
        }
    }

    private fun generateSyntheticProducts(): List<Product> {
        val list = mutableListOf<Product>()

        // 501® Original Jeans (Iconic)
        list.add(
            Product(
                id = "jean_501_dark",
                title = "501® Original Jeans",
                subtitle = "Dark Indigo Wash",
                category = ProductCategory.JEANS,
                fitCode = "501",
                fitName = "501® Original",
                price = 100.00,
                originalPrice = 110.00,
                wash = WashType.DARK_INDIGO,
                rise = RiseType.MID,
                stretch = StretchType.NON_STRETCH,
                leg = LegType.STRAIGHT,
                fabricSpec = FabricSpec(
                    cottonPercentage = 100,
                    elastanePercentage = 0,
                    weightLabel = "14.25 oz Heavyweight Cone Denim",
                    originMetadata = "Cone Mills / Premium Raw Cotton"
                ),
                imageUrl = "hero_501_banner_1793051553057.jpg",
                description = "Since we invented it in 1873, the 501® Jean has been a blank canvas for self-expression. True to the original, it features our iconic straight fit and signature button fly.",
                details = listOf(
                    "Iconic straight fit with button fly",
                    "Sits at the waist with a 11.25\" rise",
                    "100% premium cotton non-stretch denim",
                    "Red Tab™ on back pocket & Two Horse Pull patch"
                ),
                isIconic = true,
                isNew = false
            )
        )

        list.add(
            Product(
                id = "jean_501_medium",
                title = "501® Original Jeans",
                subtitle = "Medium Stonewash",
                category = ProductCategory.JEANS,
                fitCode = "501",
                fitName = "501® Original",
                price = 95.00,
                wash = WashType.MID_BLUE,
                rise = RiseType.MID,
                stretch = StretchType.NON_STRETCH,
                leg = LegType.STRAIGHT,
                imageUrl = "hero_501_banner_1793051553057.jpg",
                description = "Authentic stonewashed 501® with vintage character and soft hand-feel.",
                isIconic = true
            )
        )

        list.add(
            Product(
                id = "jean_501_black",
                title = "501® Original Jeans",
                subtitle = "Black Rigid",
                category = ProductCategory.JEANS,
                fitCode = "501",
                fitName = "501® Original",
                price = 105.00,
                wash = WashType.BLACK,
                rise = RiseType.MID,
                stretch = StretchType.NON_STRETCH,
                leg = LegType.STRAIGHT,
                imageUrl = "hero_501_banner_1793051553057.jpg",
                description = "Sleek jet-black rigid denim 501® with nickel hardware.",
                isIconic = true
            )
        )

        // 505™ Regular Fit
        list.add(
            Product(
                id = "jean_505_dark",
                title = "505™ Regular Fit Jeans",
                subtitle = "Rinse Indigo",
                category = ProductCategory.JEANS,
                fitCode = "505",
                fitName = "505™ Regular Fit",
                price = 85.00,
                wash = WashType.DARK_INDIGO,
                rise = RiseType.MID,
                stretch = StretchType.LOW_STRETCH,
                leg = LegType.STRAIGHT,
                imageUrl = "hero_501_banner_1793051553057.jpg",
                description = "Classic zip-fly straight fit created in 1967. Extra room through seat and thigh.",
                isIconic = true
            )
        )

        // 511™ Slim Fit
        list.add(
            Product(
                id = "jean_511_slim",
                title = "511™ Slim Fit Jeans",
                subtitle = "Clean Dark Wash",
                category = ProductCategory.JEANS,
                fitCode = "511",
                fitName = "511™ Slim Fit",
                price = 90.00,
                wash = WashType.DARK_INDIGO,
                rise = RiseType.MID,
                stretch = StretchType.MEDIUM_STRETCH,
                leg = LegType.SLIM,
                imageUrl = "hero_501_banner_1793051553057.jpg",
                description = "A modern slim with room to move. Tailored look without feeling restrictive.",
                isIconic = true
            )
        )

        // 512™ Slim Taper
        list.add(
            Product(
                id = "jean_512_taper",
                title = "512™ Slim Tapered Jeans",
                subtitle = "Bi-Stretch Mid Blue",
                category = ProductCategory.JEANS,
                fitCode = "512",
                fitName = "512™ Slim Taper",
                price = 95.00,
                wash = WashType.MID_BLUE,
                rise = RiseType.MID,
                stretch = StretchType.HIGH_STRETCH,
                leg = LegType.TAPERED,
                imageUrl = "hero_501_banner_1793051553057.jpg",
                description = "Slim through seat and thigh with a sharp narrow taper down to the ankle."
            )
        )

        // 502™ Taper
        list.add(
            Product(
                id = "jean_502_flex",
                title = "502™ Tapered Flex Jeans",
                subtitle = "Stonewash Flex",
                category = ProductCategory.JEANS,
                fitCode = "502",
                fitName = "502™ Taper",
                price = 90.00,
                wash = WashType.STONEWASH,
                rise = RiseType.MID,
                stretch = StretchType.MEDIUM_STRETCH,
                leg = LegType.TAPERED,
                imageUrl = "hero_501_banner_1793051553057.jpg",
                description = "Roomy in the thigh with a clean, versatile taper. Levi's Flex technology."
            )
        )

        // 568™ Loose Straight
        list.add(
            Product(
                id = "jean_568_loose",
                title = "568™ Loose Straight Jeans",
                subtitle = "Vintage Light Wash",
                category = ProductCategory.JEANS,
                fitCode = "568",
                fitName = "568™ Loose Straight",
                price = 110.00,
                wash = WashType.LIGHT_BLUE,
                rise = RiseType.HIGH,
                stretch = StretchType.NON_STRETCH,
                leg = LegType.LOOSE,
                imageUrl = "hero_501_banner_1793051553057.jpg",
                description = "Inspired by 90s slouched skate culture. Relaxed waist, wide thigh, straight leg.",
                isNew = true
            )
        )

        // Trucker Jackets
        list.add(
            Product(
                id = "trucker_jacket_orig",
                title = "Original Trucker Jacket",
                subtitle = "Rigid Dark Indigo",
                category = ProductCategory.TRUCKER_JACKETS,
                fitCode = "TRUCKER",
                fitName = "Original Trucker",
                price = 120.00,
                wash = WashType.RIGID,
                rise = RiseType.MID,
                stretch = StretchType.NON_STRETCH,
                leg = LegType.STRAIGHT,
                imageUrl = "hero_501_banner_1793051553057.jpg",
                description = "The original denim jacket since 1967. Point collar, welt side pockets, waist adjusters.",
                isIconic = true
            )
        )

        list.add(
            Product(
                id = "trucker_jacket_sherpa",
                title = "Sherpa Trucker Jacket",
                subtitle = "Fleece Lined Stonewash",
                category = ProductCategory.TRUCKER_JACKETS,
                fitCode = "TRUCKER",
                fitName = "Relaxed Sherpa",
                price = 140.00,
                wash = WashType.STONEWASH,
                rise = RiseType.MID,
                stretch = StretchType.NON_STRETCH,
                imageUrl = "hero_501_banner_1793051553057.jpg",
                description = "Cozy sherpa fleece lining on body and collar with insulated sleeve lining."
            )
        )

        // Tops & Shirts
        list.add(
            Product(
                id = "shirt_barstow_western",
                title = "Barstow Western Denim Shirt",
                subtitle = "Red Tab™ Classic",
                category = ProductCategory.DENIM_SHIRTS,
                fitCode = "WESTERN",
                fitName = "Standard Western",
                price = 75.00,
                wash = WashType.MID_BLUE,
                imageUrl = "hero_501_banner_1793051553057.jpg",
                description = "Authentic western detail with curved hem, pearl snap buttons, and point yoke."
            )
        )

        list.add(
            Product(
                id = "tee_housemark_logo",
                title = "Housemark Graphic T-Shirt",
                subtitle = "Heavyweight Organic Cotton",
                category = ProductCategory.TSHIRTS,
                fitCode = "REGULAR",
                fitName = "Standard Fit Tee",
                price = 35.00,
                wash = WashType.WHITE,
                imageUrl = "hero_501_banner_1793051553057.jpg",
                description = "Soft organic jersey with iconic Levi's Batwing logo screenprinted on chest."
            )
        )

        // Generate synthetic variations up to 150 items systematically
        val fits = listOf("501", "505", "511", "512", "514", "502", "568", "569", "555")
        val washes = WashType.entries.toTypedArray()
        var count = list.size

        for (i in 1..140) {
            val fit = fits[i % fits.size]
            val wash = washes[i % washes.size]
            val cat = when (i % 6) {
                0 -> ProductCategory.JEANS
                1 -> ProductCategory.TRUCKER_JACKETS
                2 -> ProductCategory.DENIM_SHIRTS
                3 -> ProductCategory.TSHIRTS
                4 -> ProductCategory.OUTERWEAR
                else -> ProductCategory.ACCESSORIES
            }
            count++
            list.add(
                Product(
                    id = "synth_prod_$count",
                    title = if (cat == ProductCategory.JEANS) "Levi's® $fit Jeans" else "Levi's® Denim ${cat.displayName} #$count",
                    subtitle = "${wash.displayName} • ${fit} Fit",
                    category = cat,
                    fitCode = fit,
                    fitName = "Levi's $fit",
                    price = 45.0 + (i * 2.5 % 90),
                    wash = wash,
                    rise = RiseType.entries[i % 3],
                    stretch = StretchType.entries[i % 4],
                    leg = LegType.entries[i % 6],
                    imageUrl = "hero_501_banner_1793051553057.jpg",
                    description = "Premium crafted garment with signature red tab detailing and authentic construction."
                )
            )
        }

        return list
    }
}
