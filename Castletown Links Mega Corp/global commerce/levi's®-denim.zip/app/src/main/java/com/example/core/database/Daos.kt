package com.example.core.database

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface CartDao {
    @Query("SELECT * FROM cart_items")
    fun getCartItems(): Flow<List<CartEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateItem(item: CartEntity)

    @Query("DELETE FROM cart_items WHERE id = :id")
    suspend fun deleteCartItem(id: String)

    @Query("DELETE FROM cart_items")
    suspend fun clearCart()
}

@Dao
interface WishlistDao {
    @Query("SELECT * FROM wishlist_items")
    fun getWishlistItems(): Flow<List<WishlistEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM wishlist_items WHERE productId = :productId)")
    fun isWishlisted(productId: String): Flow<Boolean>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addToWishlist(item: WishlistEntity)

    @Query("DELETE FROM wishlist_items WHERE productId = :productId")
    suspend fun removeFromWishlist(productId: String)
}

@Dao
interface WardrobeDao {
    @Query("SELECT * FROM wardrobe_items ORDER BY ageMonths DESC")
    fun getWardrobeItems(): Flow<List<WardrobeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWardrobeItem(item: WardrobeEntity)

    @Query("UPDATE wardrobe_items SET wearCount = wearCount + 1 WHERE id = :id")
    suspend fun incrementWear(id: String)

    @Query("UPDATE wardrobe_items SET washCount = washCount + 1 WHERE id = :id")
    suspend fun incrementWash(id: String)
}

@Dao
interface RepairDao {
    @Query("SELECT * FROM repair_requests ORDER BY id DESC")
    fun getRepairRequests(): Flow<List<RepairEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRepairRequest(repair: RepairEntity)

    @Query("UPDATE repair_requests SET status = :status WHERE id = :id")
    suspend fun updateRepairStatus(id: String, status: String)
}

@Dao
interface AppointmentDao {
    @Query("SELECT * FROM appointments ORDER BY id DESC")
    fun getAppointments(): Flow<List<AppointmentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAppointment(appointment: AppointmentEntity)
}

@Dao
interface FitProfileDao {
    @Query("SELECT * FROM user_fit_profile WHERE id = 1")
    fun getFitProfile(): Flow<FitProfileEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveFitProfile(profile: FitProfileEntity)
}
