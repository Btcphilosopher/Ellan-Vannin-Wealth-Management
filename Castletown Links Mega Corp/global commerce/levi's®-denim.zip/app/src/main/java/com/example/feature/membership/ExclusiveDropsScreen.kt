package com.example.feature.membership

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.designsystem.DeepIndigo
import com.example.core.designsystem.LevisRed
import com.example.core.designsystem.OffWhite
import com.example.core.designsystem.PureWhite
import com.example.core.designsystem.RawDenim
import com.example.core.designsystem.RedTabBadge
import com.example.core.model.ExclusiveDrop

@Composable
fun ExclusiveDropsScreen(
    drops: List<ExclusiveDrop>,
    onBackClick: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepIndigo),
        contentPadding = PaddingValues(16.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBackClick) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = PureWhite)
                }
                Spacer(modifier = Modifier.width(8.dp))
                RedTabBadge(text = "RED TAB™ DROPS")
            }

            Spacer(modifier = Modifier.height(12.dp))
            Text("MEMBER EXCLUSIVE DROPS & LAUNCHES", color = PureWhite, fontWeight = FontWeight.Black, fontSize = 22.sp)
            Text("Limited quantities, archival reproductions and collaborator releases.", color = OffWhite.copy(alpha = 0.8f), fontSize = 13.sp)
            Spacer(modifier = Modifier.height(20.dp))
        }

        items(drops) { drop ->
            Card(
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                colors = CardDefaults.cardColors(containerColor = RawDenim)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(drop.collectionName.uppercase(), color = LevisRed, fontSize = 11.sp, fontWeight = FontWeight.Black)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(drop.title, color = PureWhite, fontWeight = FontWeight.Black, fontSize = 18.sp)
                    Text(drop.releaseDate, color = OffWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(drop.description, color = OffWhite.copy(alpha = 0.8f), fontSize = 13.sp, lineHeight = 18.sp)

                    Spacer(modifier = Modifier.height(14.dp))
                    Button(
                        onClick = { },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = LevisRed)
                    ) {
                        Text("SET LAUNCH REMINDER", color = PureWhite, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
