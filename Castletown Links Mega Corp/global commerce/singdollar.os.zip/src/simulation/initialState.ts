/**
 * SINGDOLLAR.OS — Initial Deterministic Dataset
 * Fictional Research Prototype inspired by MAS Project Orchid concepts.
 */

import { Account, PBMConfig, Transaction, AuditEvent, RiskFlag, CrossBorderLeg, SystemMetrics } from '../types';

export const INITIAL_ACCOUNTS: Account[] = [
  {
    id: 'acc-mas-issuance',
    entityId: 'ent-mas',
    entityName: 'Monetary Authority of Singapore (Simulated CB)',
    entityType: 'CENTRAL_BANK',
    accountType: 'CENTRAL_BANK_ISSUANCE',
    balances: {
      unrestrictedCBDC: 5000000000,
      wholesaleCBDC: 10000000000,
      tokenisedDeposits: {},
      stablecoins: 0,
      pbmRestricted: 0,
    },
    pendingReserve: 0,
    riskStatus: 'LOW',
    deviceSession: { deviceId: 'HSM-MAS-SG-01', ipLocation: 'Singapore Downtown', authMethod: 'HARDWARE_HSM' }
  },
  {
    id: 'acc-dbs-reserve',
    entityId: 'ent-dbs',
    entityName: 'DBS Bank Ltd (Simulated Bank A)',
    entityType: 'COMMERCIAL_BANK',
    accountType: 'COMMERCIAL_BANK_RESERVE',
    balances: {
      unrestrictedCBDC: 450000000,
      wholesaleCBDC: 1200000000,
      tokenisedDeposits: { 'DBS Tokenised SGD': 850000000 },
      stablecoins: 50000000,
      pbmRestricted: 0,
    },
    pendingReserve: 0,
    riskStatus: 'LOW',
    deviceSession: { deviceId: 'BANK-DBS-CORE-01', ipLocation: 'Marina Bay Financial Centre', authMethod: 'CORPORATE_PKI' }
  },
  {
    id: 'acc-ocbc-reserve',
    entityId: 'ent-ocbc',
    entityName: 'OCBC Bank (Simulated Bank B)',
    entityType: 'COMMERCIAL_BANK',
    accountType: 'COMMERCIAL_BANK_RESERVE',
    balances: {
      unrestrictedCBDC: 320000000,
      wholesaleCBDC: 850000000,
      tokenisedDeposits: { 'OCBC Tokenised SGD': 620000000 },
      stablecoins: 25000000,
      pbmRestricted: 0,
    },
    pendingReserve: 0,
    riskStatus: 'LOW',
    deviceSession: { deviceId: 'BANK-OCBC-CORE-02', ipLocation: 'Chulia Street SG', authMethod: 'CORPORATE_PKI' }
  },
  {
    id: 'acc-uob-reserve',
    entityId: 'ent-uob',
    entityName: 'United Overseas Bank (Simulated Bank C)',
    entityType: 'COMMERCIAL_BANK',
    accountType: 'COMMERCIAL_BANK_RESERVE',
    balances: {
      unrestrictedCBDC: 280000000,
      wholesaleCBDC: 700000000,
      tokenisedDeposits: { 'UOB Tokenised SGD': 510000000 },
      stablecoins: 20000000,
      pbmRestricted: 0,
    },
    pendingReserve: 0,
    riskStatus: 'LOW',
    deviceSession: { deviceId: 'BANK-UOB-CORE-03', ipLocation: 'Raffles Place SG', authMethod: 'CORPORATE_PKI' }
  },
  {
    id: 'acc-govtech-cdc',
    entityId: 'ent-govtech',
    entityName: 'CDC Vouchers Council (Gov Disbursement)',
    entityType: 'GOVERNMENT_AGENCY',
    accountType: 'GOV_DISBURSEMENT',
    balances: {
      unrestrictedCBDC: 200000000,
      wholesaleCBDC: 0,
      tokenisedDeposits: {},
      stablecoins: 0,
      pbmRestricted: 50000000,
    },
    pendingReserve: 0,
    riskStatus: 'LOW',
    deviceSession: { deviceId: 'GOV-CDC-NODE-01', ipLocation: 'Mapletree Business City', authMethod: 'SINGPASS_BIOMETRIC' }
  },
  {
    id: 'acc-ssg-skillsfuture',
    entityId: 'ent-ssg',
    entityName: 'SkillsFuture Singapore (SSG)',
    entityType: 'GOVERNMENT_AGENCY',
    accountType: 'GOV_DISBURSEMENT',
    balances: {
      unrestrictedCBDC: 150000000,
      wholesaleCBDC: 0,
      tokenisedDeposits: {},
      stablecoins: 0,
      pbmRestricted: 30000000,
    },
    pendingReserve: 0,
    riskStatus: 'LOW',
    deviceSession: { deviceId: 'SSG-GOV-NODE-02', ipLocation: 'Paya Lebar Quarter', authMethod: 'CORPORATE_PKI' }
  },
  // Residents
  {
    id: 'acc-tan-ah-kow',
    entityId: 'ent-res-01',
    entityName: 'Tan Ah Kow (Resident - Ang Mo Kio)',
    entityType: 'RESIDENT',
    accountType: 'CUSTOMER_RETAIL',
    balances: {
      unrestrictedCBDC: 1250.50,
      wholesaleCBDC: 0,
      tokenisedDeposits: { 'DBS Tokenised SGD': 3420.00 },
      stablecoins: 100.00,
      pbmRestricted: 200.00, // CDC voucher
    },
    pendingReserve: 0,
    riskStatus: 'LOW',
    deviceSession: { deviceId: 'IPHONE-15-PRO-SG01', ipLocation: 'Ang Mo Kio Ave 3', authMethod: 'SINGPASS_BIOMETRIC' }
  },
  {
    id: 'acc-priya-sharma',
    entityId: 'ent-res-02',
    entityName: 'Priya Sharma (Resident - Tampines)',
    entityType: 'RESIDENT',
    accountType: 'CUSTOMER_RETAIL',
    balances: {
      unrestrictedCBDC: 840.00,
      wholesaleCBDC: 0,
      tokenisedDeposits: { 'OCBC Tokenised SGD': 5210.00 },
      stablecoins: 0,
      pbmRestricted: 700.00, // CDC + SkillsFuture
    },
    pendingReserve: 0,
    riskStatus: 'LOW',
    deviceSession: { deviceId: 'PIXEL-8-SG02', ipLocation: 'Tampines St 81', authMethod: 'SINGPASS_BIOMETRIC' }
  },
  {
    id: 'acc-marcus-lim',
    entityId: 'ent-res-03',
    entityName: 'Marcus Lim (Resident - Jurong West)',
    entityType: 'RESIDENT',
    accountType: 'CUSTOMER_RETAIL',
    balances: {
      unrestrictedCBDC: 310.20,
      wholesaleCBDC: 0,
      tokenisedDeposits: { 'UOB Tokenised SGD': 1890.50 },
      stablecoins: 0,
      pbmRestricted: 200.00,
    },
    pendingReserve: 0,
    riskStatus: 'LOW',
    deviceSession: { deviceId: 'SAMSUNG-S24-SG03', ipLocation: 'Jurong West St 64', authMethod: 'SINGPASS_BIOMETRIC' }
  },
  // Merchants
  {
    id: 'acc-fairprice-supermarket',
    entityId: 'ent-merch-01',
    entityName: 'NTUC FairPrice Supermarket Hub',
    entityType: 'MERCHANT',
    accountType: 'MERCHANT_SETTLEMENT',
    balances: {
      unrestrictedCBDC: 184500.00,
      wholesaleCBDC: 0,
      tokenisedDeposits: { 'DBS Tokenised SGD': 1250000.00 },
      stablecoins: 0,
      pbmRestricted: 0,
    },
    pendingReserve: 0,
    riskStatus: 'LOW',
    deviceSession: { deviceId: 'POS-FAIRPRICE-AMK-01', ipLocation: 'Ang Mo Kio Hub', authMethod: 'QR_NFC' }
  },
  {
    id: 'acc-sheng-siong',
    entityId: 'ent-merch-02',
    entityName: 'Sheng Siong Supermarket Bedok',
    entityType: 'MERCHANT',
    accountType: 'MERCHANT_SETTLEMENT',
    balances: {
      unrestrictedCBDC: 98200.00,
      wholesaleCBDC: 0,
      tokenisedDeposits: { 'OCBC Tokenised SGD': 640000.00 },
      stablecoins: 0,
      pbmRestricted: 0,
    },
    pendingReserve: 0,
    riskStatus: 'LOW',
    deviceSession: { deviceId: 'POS-SHENGSIONG-BDK-02', ipLocation: 'Bedok North', authMethod: 'QR_NFC' }
  },
  {
    id: 'acc-singapore-polytechnic',
    entityId: 'ent-train-01',
    entityName: 'Singapore Polytechnic (Academy of Continuing Ed)',
    entityType: 'TRAINING_PROVIDER',
    accountType: 'MERCHANT_SETTLEMENT',
    balances: {
      unrestrictedCBDC: 450000.00,
      wholesaleCBDC: 0,
      tokenisedDeposits: { 'UOB Tokenised SGD': 2100000.00 },
      stablecoins: 0,
      pbmRestricted: 0,
    },
    pendingReserve: 0,
    riskStatus: 'LOW',
    deviceSession: { deviceId: 'SP-ACE-PORTAL-01', ipLocation: 'Dover Road SG', authMethod: 'CORPORATE_PKI' }
  },
  {
    id: 'acc-techcraft-sme',
    entityId: 'ent-sme-01',
    entityName: 'TechCraft Solutions SG (SME)',
    entityType: 'MERCHANT',
    accountType: 'MERCHANT_SETTLEMENT',
    balances: {
      unrestrictedCBDC: 65000.00,
      wholesaleCBDC: 0,
      tokenisedDeposits: { 'DBS Tokenised SGD': 480000.00 },
      stablecoins: 15000.00,
      pbmRestricted: 0,
    },
    pendingReserve: 0,
    riskStatus: 'LOW',
    deviceSession: { deviceId: 'TECHCRAFT-HQ-01', ipLocation: 'One-North SG', authMethod: 'CORPORATE_PKI' }
  }
];

export const INITIAL_PBMS: PBMConfig[] = [
  {
    id: 'pbm-cdc-2026-tan',
    name: '2026 CDC Household Voucher (Tan Ah Kow)',
    principalAmount: 200,
    currency: 'SGD',
    issuerId: 'ent-govtech',
    issuerName: 'CDC Vouchers Council',
    beneficiaryClass: 'SINGAPORE_CITIZEN_HOUSEHOLD',
    permittedMerchantIds: ['acc-fairprice-supermarket', 'acc-sheng-siong'],
    permittedCategories: ['GROCERIES_HOUSEHOLD', 'HAWKER_FOOD'],
    geographicConstraints: ['SINGAPORE_ALL'],
    validFrom: '2026-01-01T00:00:00Z',
    validTo: '2026-12-31T23:59:59Z',
    maxTxAmount: 100,
    transferable: false,
    releaseConditions: ['MERCHANT_IN_APPROVED_LIST', 'CATEGORY_MATCH_GROCERY'],
    status: 'ACTIVE',
    originalBalance: 200,
    remainingBalance: 200,
    underlyingInstrumentType: 'CBDC_RETAIL',
    creationTimestamp: '2026-01-01T08:00:00Z',
  },
  {
    id: 'pbm-skillsfuture-priya',
    name: 'SkillsFuture Training Grant (Priya Sharma)',
    principalAmount: 500,
    currency: 'SGD',
    issuerId: 'ent-ssg',
    issuerName: 'SkillsFuture Singapore',
    beneficiaryClass: 'SINGAPOREAN_ADULT_25_ABOVE',
    permittedMerchantIds: ['acc-singapore-polytechnic'],
    permittedCategories: ['EDUCATION_TRAINING'],
    geographicConstraints: ['SINGAPORE_ACCREDITED'],
    validFrom: '2026-01-01T00:00:00Z',
    validTo: '2026-09-30T23:59:59Z',
    maxTxAmount: 500,
    transferable: false,
    releaseConditions: ['ACCREDITED_PROVIDER', 'ATTENDANCE_VERIFIED_75_PERCENT'],
    status: 'ACTIVE',
    originalBalance: 500,
    remainingBalance: 500,
    underlyingInstrumentType: 'CBDC_RETAIL',
    creationTimestamp: '2026-02-15T09:30:00Z',
  },
  {
    id: 'pbm-expired-demo',
    name: 'Heartland Merchant Voucher (Expired Sample)',
    principalAmount: 50,
    currency: 'SGD',
    issuerId: 'ent-govtech',
    issuerName: 'CDC Vouchers Council',
    beneficiaryClass: 'SINGAPORE_RESIDENT',
    permittedMerchantIds: ['acc-sheng-siong'],
    permittedCategories: ['GROCERIES_HOUSEHOLD'],
    geographicConstraints: ['SINGAPORE_EAST'],
    validFrom: '2026-01-01T00:00:00Z',
    validTo: '2026-03-01T00:00:00Z', // Expired
    maxTxAmount: 50,
    transferable: false,
    releaseConditions: ['MERCHANT_APPROVED'],
    status: 'EXPIRED',
    originalBalance: 50,
    remainingBalance: 50,
    underlyingInstrumentType: 'CBDC_RETAIL',
    creationTimestamp: '2026-01-01T08:00:00Z',
  }
];

export const INITIAL_TRANSACTIONS: Transaction[] = [
  {
    id: 'tx-20260920-001',
    idempotencyKey: 'idemp-001-cdc-fairprice',
    timestamp: '2026-09-20T08:14:22Z',
    payerId: 'acc-tan-ah-kow',
    payerName: 'Tan Ah Kow',
    payeeId: 'acc-fairprice-supermarket',
    payeeName: 'NTUC FairPrice Supermarket Hub',
    amount: 42.50,
    currency: 'SGD',
    instrumentType: 'PBM_WRAPPER',
    pbmId: 'pbm-cdc-2026-tan',
    pbmName: '2026 CDC Household Voucher',
    category: 'GROCERIES_HOUSEHOLD',
    paymentChannel: 'QR_SGQR',
    status: 'SETTLED',
    settlementStatus: 'FINALIZED',
    failureCode: 'NONE',
    policyResult: { passed: true, ruleChecked: 'CDC_APPROVED_MERCHANT_LIST', details: 'Merchant NTUC FairPrice validated in grocery category.' },
    riskResult: { flagged: false, score: 2 },
    lifecycle: [
      { step: 'INITIATED', timestamp: '2026-09-20T08:14:22.010Z', status: 'PASSED', detail: 'SGQR scanned at POS-FAIRPRICE-AMK-01' },
      { step: 'AUTHENTICATED', timestamp: '2026-09-20T08:14:22.025Z', status: 'PASSED', detail: 'Singpass Biometric verified' },
      { step: 'POLICY_CHECKED', timestamp: '2026-09-20T08:14:22.040Z', status: 'PASSED', detail: 'PBM wrapper conditions fulfilled' },
      { step: 'FUNDS_RESERVED', timestamp: '2026-09-20T08:14:22.055Z', status: 'PASSED', detail: 'SGD 42.50 reserved from underlying CBDC' },
      { step: 'SETTLED', timestamp: '2026-09-20T08:14:22.080Z', status: 'PASSED', detail: 'SGD 42.50 unlocked to merchant unrestricted account' },
      { step: 'RECEIPT_ISSUED', timestamp: '2026-09-20T08:14:22.095Z', status: 'PASSED', detail: 'Digital receipt generated' }
    ],
    auditRef: 'AUD-EVENT-8801',
    settlementTimeMs: 85
  },
  {
    id: 'tx-20260920-002',
    idempotencyKey: 'idemp-002-expired-test',
    timestamp: '2026-09-20T08:18:05Z',
    payerId: 'acc-marcus-lim',
    payerName: 'Marcus Lim',
    payeeId: 'acc-sheng-siong',
    payeeName: 'Sheng Siong Supermarket Bedok',
    amount: 50.00,
    currency: 'SGD',
    instrumentType: 'PBM_WRAPPER',
    pbmId: 'pbm-expired-demo',
    pbmName: 'Heartland Merchant Voucher (Expired Sample)',
    category: 'GROCERIES_HOUSEHOLD',
    paymentChannel: 'NFC_CONTACTLESS',
    status: 'FAILED',
    settlementStatus: 'REJECTED',
    failureCode: 'EXPIRED_PBM',
    failureReason: 'PBM validity ended on 2026-03-01T00:00:00Z. Voucher cannot be redeemed.',
    policyResult: { passed: false, ruleChecked: 'PBM_VALIDITY_WINDOW', details: 'Transaction timestamp is after expiry window.' },
    riskResult: { flagged: false, score: 5 },
    lifecycle: [
      { step: 'INITIATED', timestamp: '2026-09-20T08:18:05.010Z', status: 'PASSED', detail: 'NFC tap detected' },
      { step: 'AUTHENTICATED', timestamp: '2026-09-20T08:18:05.020Z', status: 'PASSED', detail: 'Device pin passed' },
      { step: 'POLICY_CHECKED', timestamp: '2026-09-20T08:18:05.035Z', status: 'FAILED', detail: 'PBM expired on 2026-03-01' }
    ],
    auditRef: 'AUD-EVENT-8802',
    settlementTimeMs: 25
  }
];

export const INITIAL_AUDIT_LOGS: AuditEvent[] = [
  {
    id: 'AUD-EVENT-8800',
    timestamp: '2026-01-01T08:00:00Z',
    eventType: 'MONEY_ISSUED',
    sourceService: 'monetary_engine',
    correlationId: 'CORR-MINT-001',
    relatedEntityId: 'ent-mas',
    beforeSummary: 'MAS Wholesale Supply: SGD 8,000,000,000',
    afterSummary: 'MAS Wholesale Supply: SGD 10,000,000,000 (+SGD 2B)',
    details: { issuer: 'Monetary Authority of Singapore', reason: 'Annual Wholesale Liquidity Allocation' }
  },
  {
    id: 'AUD-EVENT-8801',
    timestamp: '2026-09-20T08:14:22Z',
    eventType: 'PBM_EXECUTED',
    sourceService: 'purpose_bound_money',
    correlationId: 'CORR-TX-20260920-001',
    relatedEntityId: 'acc-tan-ah-kow',
    beforeSummary: 'PBM Balance: SGD 200.00',
    afterSummary: 'PBM Balance: SGD 157.50 (-SGD 42.50 released to NTUC FairPrice)',
    details: { pbmId: 'pbm-cdc-2026-tan', payee: 'NTUC FairPrice' }
  }
];

export const INITIAL_RISK_FLAGS: RiskFlag[] = [
  {
    id: 'RISK-101',
    txId: 'tx-20260920-099',
    timestamp: '2026-09-20T07:45:10Z',
    trigger: 'LARGE_VALUE',
    severity: 'HIGH',
    payerName: 'TechCraft Solutions SG (SME)',
    amount: 150000.00,
    explainableReason: 'Single transfer exceeds SME 24-hour baseline velocity threshold ($50,000) by 3x.',
    status: 'PENDING_REVIEW'
  }
];

export const INITIAL_METRICS: SystemMetrics = {
  totalIssuedCBDC: 5000000000,
  totalWholesaleCBDC: 10000000000,
  totalTokenisedDeposits: 1980000000,
  totalStablecoins: 95000000,
  totalPBMValue: 80200000,
  activeWallets: 12450,
  participatingInstitutions: 14,
  tpsCurrent: 48,
  tpsPeak: 240,
  avgSettlementMs: 78,
  failedTxCount: 1,
  lockedFunds: 50000,
  merchantVolume24h: 3420500.00,
  systemHealth: 'HEALTHY',
  queueDepth: 0,
  ledgerInvariantsValid: true,
};
