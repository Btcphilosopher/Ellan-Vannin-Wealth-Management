/**
 * SINGDOLLAR.OS — Core Stateful Simulation Engine & Ledger
 * Fictional Research Prototype inspired by MAS Project Orchid concepts.
 * 
 * Invariants Enforced:
 * 1. Money cannot be created through ordinary transfers.
 * 2. Money cannot be spent twice.
 * 3. Failed transactions do not remove funds.
 * 4. PBM cannot be redeemed after expiry.
 * 5. Reversals cannot exceed original settled amount.
 * 6. Total ledger remains strictly consistent and audited.
 */

import { 
  Account, PBMConfig, Transaction, AuditEvent, RiskFlag, 
  CrossBorderLeg, SystemMetrics, ScenarioParams, InstrumentType, 
  SpendingCategory, FailureCode, TransactionStatus, SettlementStatus 
} from '../types';
import { 
  INITIAL_ACCOUNTS, INITIAL_PBMS, INITIAL_TRANSACTIONS, 
  INITIAL_AUDIT_LOGS, INITIAL_RISK_FLAGS, INITIAL_METRICS 
} from './initialState';

type Subscriber = () => void;

class SimulationEngine {
  private accounts: Account[] = [];
  private pbms: PBMConfig[] = [];
  private transactions: Transaction[] = [];
  private auditLogs: AuditEvent[] = [];
  private riskFlags: RiskFlag[] = [];
  private crossBorderLegs: CrossBorderLeg[] = [];
  private metrics: SystemMetrics;
  private scenario: ScenarioParams;
  private subscribers: Set<Subscriber> = new Set();
  private simulationClockMs: number = Date.now();
  private isLiveTickerRunning: boolean = true;
  private tickerInterval: NodeJS.Timeout | null = null;
  private seed: number = 2026;

  constructor() {
    this.scenario = {
      id: 'scen-normal',
      name: 'Normal Operating Day',
      description: 'Moderate consumer and merchant activity across Singapore retail rails.',
      txVolumeMultiplier: 1,
      networkLatencyMs: 65,
      failureRatePercent: 1,
      simulateBankOutage: false,
      expiringVoucherCliff: false,
      fxStress: false,
      seed: 2026,
    };
    this.metrics = { ...INITIAL_METRICS };
    this.resetToDefaults();
    this.startBackgroundTicker();
  }

  public resetToDefaults(customSeed?: number) {
    if (customSeed !== undefined) {
      this.seed = customSeed;
    }
    this.accounts = JSON.parse(JSON.stringify(INITIAL_ACCOUNTS));
    this.pbms = JSON.parse(JSON.stringify(INITIAL_PBMS));
    this.transactions = JSON.parse(JSON.stringify(INITIAL_TRANSACTIONS));
    this.auditLogs = JSON.parse(JSON.stringify(INITIAL_AUDIT_LOGS));
    this.riskFlags = JSON.parse(JSON.stringify(INITIAL_RISK_FLAGS));
    this.crossBorderLegs = [];
    this.metrics = { ...INITIAL_METRICS };
    this.validateLedgerInvariants();
    this.notify();
  }

  public subscribe(cb: Subscriber) {
    this.subscribers.add(cb);
    return () => {
      this.subscribers.delete(cb);
    };
  }

  private notify() {
    this.subscribers.forEach(cb => cb());
  }

  // Getters
  public getAccounts(): Account[] { return this.accounts; }
  public getPBMs(): PBMConfig[] { return this.pbms; }
  public getTransactions(): Transaction[] { return this.transactions; }
  public getAuditLogs(): AuditEvent[] { return this.auditLogs; }
  public getRiskFlags(): RiskFlag[] { return this.riskFlags; }
  public getCrossBorderLegs(): CrossBorderLeg[] { return this.crossBorderLegs; }
  public getMetrics(): SystemMetrics { return this.metrics; }
  public getScenario(): ScenarioParams { return this.scenario; }
  public getClock(): string { return new Date(this.simulationClockMs).toISOString(); }

  // 1. Core Invariants Verification
  public validateLedgerInvariants(): boolean {
    let sumCBDC = 0;
    let sumWholesale = 0;
    let sumDeposits = 0;

    for (const acc of this.accounts) {
      sumCBDC += acc.balances.unrestrictedCBDC;
      sumWholesale += acc.balances.wholesaleCBDC;
      for (const val of Object.values(acc.balances.tokenisedDeposits)) {
        sumDeposits += val;
      }
    }

    const valid = sumCBDC >= 0 && sumWholesale >= 0 && sumDeposits >= 0;
    this.metrics.ledgerInvariantsValid = valid;
    return valid;
  }

  // Helper audit logger
  private addAuditEvent(
    eventType: AuditEvent['eventType'], 
    sourceService: string, 
    relatedEntityId: string, 
    beforeSummary: string, 
    afterSummary: string, 
    details: Record<string, unknown>
  ) {
    const event: AuditEvent = {
      id: `AUD-EVT-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString(),
      eventType,
      sourceService,
      correlationId: `CORR-${Math.random().toString(36).substring(2, 9)}`,
      relatedEntityId,
      beforeSummary,
      afterSummary,
      details,
    };
    this.auditLogs.unshift(event);
    if (this.auditLogs.length > 200) this.auditLogs.pop();
  }

  // 2. Central Bank Issuance / Destruction / Conversion Desk
  public executeCentralBankOperation(params: {
    operation: 'ISSUE' | 'REDEEM_DESTROY' | 'CONVERT_WHOLESALE' | 'ALLOCATE_BANK';
    instrumentType: InstrumentType;
    amount: number;
    targetAccountId?: string;
    reasonCode: string;
    approvedByFourEyes: boolean;
  }): { success: boolean; message: string } {
    if (!params.approvedByFourEyes) {
      return { success: false, message: 'Four-Eyes Dual Control approval signature missing.' };
    }

    const masAcc = this.accounts.find(a => a.id === 'acc-mas-issuance');
    if (!masAcc) return { success: false, message: 'MAS Issuance account not found.' };

    const beforeSummary = `MAS Supply: CBDC $${(masAcc.balances.unrestrictedCBDC / 1e6).toFixed(2)}M, Wholesale $${(masAcc.balances.wholesaleCBDC / 1e6).toFixed(2)}M`;

    if (params.operation === 'ISSUE') {
      if (params.instrumentType === 'CBDC_RETAIL') {
        masAcc.balances.unrestrictedCBDC += params.amount;
        this.metrics.totalIssuedCBDC += params.amount;
      } else if (params.instrumentType === 'CBDC_WHOLESALE') {
        masAcc.balances.wholesaleCBDC += params.amount;
        this.metrics.totalWholesaleCBDC += params.amount;
      }
      const afterSummary = `MAS Supply: CBDC $${(masAcc.balances.unrestrictedCBDC / 1e6).toFixed(2)}M, Wholesale $${(masAcc.balances.wholesaleCBDC / 1e6).toFixed(2)}M (+ $${(params.amount / 1e6).toFixed(2)}M)`;

      this.addAuditEvent(
        'MONEY_ISSUED', 'issuance_desk', masAcc.id, beforeSummary, afterSummary,
        { operation: 'ISSUE', amount: params.amount, reason: params.reasonCode }
      );
      this.validateLedgerInvariants();
      this.notify();
      return { success: true, message: `Successfully issued SGD $${params.amount.toLocaleString()} ${params.instrumentType}.` };
    }

    if (params.operation === 'ALLOCATE_BANK') {
      const bankAcc = this.accounts.find(a => a.id === params.targetAccountId);
      if (!bankAcc) return { success: false, message: 'Target financial institution account not found.' };

      if (masAcc.balances.unrestrictedCBDC < params.amount) {
        return { success: false, message: 'Insufficient Central Bank unallocated CBDC reserves.' };
      }

      masAcc.balances.unrestrictedCBDC -= params.amount;
      bankAcc.balances.unrestrictedCBDC += params.amount;

      this.addAuditEvent(
        'MONEY_ISSUED', 'issuance_desk', bankAcc.id,
        `${bankAcc.entityName} Balance: $${bankAcc.balances.unrestrictedCBDC - params.amount}`,
        `${bankAcc.entityName} Balance: $${bankAcc.balances.unrestrictedCBDC} (+ $${params.amount})`,
        { operation: 'ALLOCATE_BANK', bank: bankAcc.entityName, amount: params.amount }
      );
      this.validateLedgerInvariants();
      this.notify();
      return { success: true, message: `Allocated $${params.amount.toLocaleString()} CBDC to ${bankAcc.entityName}.` };
    }

    if (params.operation === 'REDEEM_DESTROY') {
      if (masAcc.balances.unrestrictedCBDC < params.amount) {
        return { success: false, message: 'Cannot redeem/destroy more than available unallocated MAS CBDC.' };
      }
      masAcc.balances.unrestrictedCBDC -= params.amount;
      this.metrics.totalIssuedCBDC -= params.amount;

      this.addAuditEvent(
        'MONEY_DESTROYED', 'issuance_desk', masAcc.id, beforeSummary,
        `MAS Supply after destruction: CBDC $${(masAcc.balances.unrestrictedCBDC / 1e6).toFixed(2)}M`,
        { operation: 'REDEEM_DESTROY', amount: params.amount, reason: params.reasonCode }
      );
      this.validateLedgerInvariants();
      this.notify();
      return { success: true, message: `Redeemed and destroyed SGD $${params.amount.toLocaleString()} Digital SGD.` };
    }

    return { success: false, message: 'Invalid operation.' };
  }

  // 3. Purpose-Bound Money Studio (Creation & Allocation)
  public createPBM(config: Omit<PBMConfig, 'id' | 'status' | 'remainingBalance' | 'creationTimestamp'>): PBMConfig {
    const pbmId = `pbm-${Date.now().toString(36)}`;
    const newPBM: PBMConfig = {
      ...config,
      id: pbmId,
      status: 'ACTIVE',
      remainingBalance: config.principalAmount,
      creationTimestamp: new Date().toISOString(),
    };
    this.pbms.unshift(newPBM);

    this.addAuditEvent(
      'PBM_CREATED', 'purpose_bound_money', config.issuerId,
      'PBM Instrument Spec Created',
      `PBM ${newPBM.name} created for SGD $${newPBM.principalAmount}`,
      { pbmId, issuer: config.issuerName, categories: config.permittedCategories }
    );

    this.notify();
    return newPBM;
  }

  // 4. Core Merchant / Consumer / P2P Transaction Execution
  public executeTransaction(input: {
    payerId: string;
    payeeId: string;
    amount: number;
    instrumentType: InstrumentType;
    pbmId?: string;
    category?: SpendingCategory;
    paymentChannel: Transaction['paymentChannel'];
    idempotencyKey?: string;
  }): Transaction {
    const idempKey = input.idempotencyKey || `idemp-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    
    // Idempotency check
    const existingTx = this.transactions.find(t => t.idempotencyKey === idempKey);
    if (existingTx) {
      return existingTx;
    }

    const txId = `tx-${Date.now()}-${Math.floor(Math.random() * 10000)}`;
    const payer = this.accounts.find(a => a.id === input.payerId);
    const payee = this.accounts.find(a => a.id === input.payeeId);

    const lifecycleSteps = [
      { step: 'INITIATED', timestamp: new Date().toISOString(), status: 'PASSED' as const, detail: `Transaction requested via ${input.paymentChannel}` },
      { step: 'AUTHENTICATED', timestamp: new Date().toISOString(), status: 'PASSED' as const, detail: `Identity verified for ${payer?.entityName || 'Payer'}` }
    ];

    if (!payer || !payee) {
      const failedTx: Transaction = {
        id: txId,
        idempotencyKey: idempKey,
        timestamp: new Date().toISOString(),
        payerId: input.payerId,
        payerName: payer?.entityName || 'Unknown Payer',
        payeeId: input.payeeId,
        payeeName: payee?.entityName || 'Unknown Payee',
        amount: input.amount,
        currency: 'SGD',
        instrumentType: input.instrumentType,
        paymentChannel: input.paymentChannel,
        status: 'FAILED',
        settlementStatus: 'REJECTED',
        failureCode: 'NETWORK_INTERRUPTION',
        failureReason: 'Invalid payer or payee account reference.',
        policyResult: { passed: false, details: 'Account lookup failed.' },
        riskResult: { flagged: false, score: 0 },
        lifecycle: [...lifecycleSteps, { step: 'FAILED', timestamp: new Date().toISOString(), status: 'FAILED' as const, detail: 'Account lookup failed' }],
        auditRef: `AUD-FAIL-${Date.now()}`,
        settlementTimeMs: 15,
      };
      this.transactions.unshift(failedTx);
      this.metrics.failedTxCount++;
      this.notify();
      return failedTx;
    }

    // Check simulated outage
    if (this.scenario.simulateBankOutage && (payer.entityId === this.scenario.outageBankId || payee.entityId === this.scenario.outageBankId)) {
      const outageTx: Transaction = {
        id: txId,
        idempotencyKey: idempKey,
        timestamp: new Date().toISOString(),
        payerId: payer.id,
        payerName: payer.entityName,
        payeeId: payee.id,
        payeeName: payee.entityName,
        amount: input.amount,
        currency: 'SGD',
        instrumentType: input.instrumentType,
        paymentChannel: input.paymentChannel,
        status: 'FAILED',
        settlementStatus: 'QUEUED_OUTAGE',
        failureCode: 'NETWORK_INTERRUPTION',
        failureReason: `Participating institution (${this.scenario.outageBankId}) is experiencing a simulated system outage.`,
        policyResult: { passed: false, details: 'Institution network offline.' },
        riskResult: { flagged: false, score: 0 },
        lifecycle: [...lifecycleSteps, { step: 'POLICY_CHECKED', timestamp: new Date().toISOString(), status: 'FAILED' as const, detail: 'Institution system offline' }],
        auditRef: `AUD-OUTAGE-${Date.now()}`,
        settlementTimeMs: this.scenario.networkLatencyMs,
      };
      this.transactions.unshift(outageTx);
      this.metrics.failedTxCount++;
      this.metrics.queueDepth++;
      this.notify();
      return outageTx;
    }

    // Handle PBM Transaction Flow
    if (input.instrumentType === 'PBM_WRAPPER') {
      const pbm = this.pbms.find(p => p.id === input.pbmId);
      if (!pbm) {
        return this.createFailedTx(txId, idempKey, payer, payee, input, 'EXPIRED_PBM', 'Specified Purpose-Bound Money instrument not found.', lifecycleSteps);
      }

      // 1. Check validity dates
      const nowStr = new Date().toISOString();
      if (nowStr > pbm.validTo || pbm.status === 'EXPIRED') {
        pbm.status = 'EXPIRED';
        return this.createFailedTx(txId, idempKey, payer, payee, input, 'EXPIRED_PBM', `PBM expired on ${new Date(pbm.validTo).toLocaleDateString()}. Cannot redeem.`, lifecycleSteps, pbm);
      }

      // 2. Check remaining balance
      if (pbm.remainingBalance < input.amount) {
        return this.createFailedTx(txId, idempKey, payer, payee, input, 'INSUFFICIENT_FUNDS', `PBM remaining balance (SGD $${pbm.remainingBalance}) is less than requested amount (SGD $${input.amount}).`, lifecycleSteps, pbm);
      }

      // 3. Check permitted merchant
      if (pbm.permittedMerchantIds.length > 0 && !pbm.permittedMerchantIds.includes(payee.id)) {
        return this.createFailedTx(txId, idempKey, payer, payee, input, 'UNAPPROVED_MERCHANT', `Payee ${payee.entityName} is not in the approved merchant whitelist for this PBM.`, lifecycleSteps, pbm);
      }

      // 4. Check permitted category
      if (input.category && pbm.permittedCategories.length > 0 && !pbm.permittedCategories.includes(input.category)) {
        return this.createFailedTx(txId, idempKey, payer, payee, input, 'UNSUPPORTED_CATEGORY', `Merchant category (${input.category}) is not permitted under this PBM rule.`, lifecycleSteps, pbm);
      }

      // 5. Check maximum transaction limit
      if (pbm.maxTxAmount && input.amount > pbm.maxTxAmount) {
        return this.createFailedTx(txId, idempKey, payer, payee, input, 'MAX_LIMIT_EXCEEDED', `Amount ($${input.amount}) exceeds single-transaction cap ($${pbm.maxTxAmount}).`, lifecycleSteps, pbm);
      }

      // PBM PASSES ALL POLICY CHECKS! Consuming PBM & Releasing underlying value to merchant
      lifecycleSteps.push({ step: 'POLICY_CHECKED', timestamp: new Date().toISOString(), status: 'PASSED', detail: 'All PBM protocol wrapper constraints verified.' });
      lifecycleSteps.push({ step: 'FUNDS_RESERVED', timestamp: new Date().toISOString(), status: 'PASSED', detail: `Underlying $${input.amount} CBDC unlocked from escrow` });

      pbm.remainingBalance -= input.amount;
      if (pbm.remainingBalance === 0) pbm.status = 'CONSUMED';
      else pbm.status = 'PARTIALLY_CONSUMED';

      payer.balances.pbmRestricted = Math.max(0, payer.balances.pbmRestricted - input.amount);
      payee.balances.unrestrictedCBDC += input.amount;

      const settledTx: Transaction = {
        id: txId,
        idempotencyKey: idempKey,
        timestamp: new Date().toISOString(),
        payerId: payer.id,
        payerName: payer.entityName,
        payeeId: payee.id,
        payeeName: payee.entityName,
        amount: input.amount,
        currency: 'SGD',
        instrumentType: 'PBM_WRAPPER',
        pbmId: pbm.id,
        pbmName: pbm.name,
        category: input.category,
        paymentChannel: input.paymentChannel,
        status: 'SETTLED',
        settlementStatus: 'FINALIZED',
        failureCode: 'NONE',
        policyResult: { passed: true, ruleChecked: 'PBM_PROTOCOL_WRAPPER', details: 'All constraints met. Underlying SGD settled.' },
        riskResult: { flagged: false, score: 2 },
        lifecycle: [
          ...lifecycleSteps,
          { step: 'SETTLED', timestamp: new Date().toISOString(), status: 'PASSED', detail: `SGD ${input.amount} credited to ${payee.entityName} unrestricted account.` },
          { step: 'RECEIPT_ISSUED', timestamp: new Date().toISOString(), status: 'PASSED', detail: 'Digital receipt generated with audit hash.' }
        ],
        auditRef: `AUD-${Date.now()}`,
        settlementTimeMs: Math.max(20, this.scenario.networkLatencyMs + Math.floor(Math.random() * 20)),
      };

      this.transactions.unshift(settledTx);
      this.metrics.merchantVolume24h += input.amount;
      this.addAuditEvent(
        'PBM_EXECUTED', 'purpose_bound_money', payer.id,
        `PBM ${pbm.name} Remaining: $${pbm.remainingBalance + input.amount}`,
        `PBM ${pbm.name} Remaining: $${pbm.remainingBalance} -> $${input.amount} released to ${payee.entityName}`,
        { txId, payer: payer.entityName, payee: payee.entityName, amount: input.amount }
      );

      this.validateLedgerInvariants();
      this.notify();
      return settledTx;
    }

    // Ordinary Unrestricted Transfer (CBDC / Deposit / Stablecoin)
    let hasFunds = false;
    if (input.instrumentType === 'CBDC_RETAIL' && payer.balances.unrestrictedCBDC >= input.amount) {
      payer.balances.unrestrictedCBDC -= input.amount;
      payee.balances.unrestrictedCBDC += input.amount;
      hasFunds = true;
    } else if (input.instrumentType === 'TOKENISED_DEPOSIT') {
      const bankKey = Object.keys(payer.balances.tokenisedDeposits)[0] || 'DBS Tokenised SGD';
      const curBal = payer.balances.tokenisedDeposits[bankKey] || 0;
      if (curBal >= input.amount) {
        payer.balances.tokenisedDeposits[bankKey] = curBal - input.amount;
        payee.balances.tokenisedDeposits[bankKey] = (payee.balances.tokenisedDeposits[bankKey] || 0) + input.amount;
        hasFunds = true;
      }
    } else if (input.instrumentType === 'REGULATED_STABLECOIN' && payer.balances.stablecoins >= input.amount) {
      payer.balances.stablecoins -= input.amount;
      payee.balances.stablecoins += input.amount;
      hasFunds = true;
    }

    if (!hasFunds) {
      return this.createFailedTx(txId, idempKey, payer, payee, input, 'INSUFFICIENT_FUNDS', `Payer does not have sufficient ${input.instrumentType} balance.`, lifecycleSteps);
    }

    // Risk Check
    const isLargeValue = input.amount >= 50000;
    if (isLargeValue) {
      this.riskFlags.unshift({
        id: `RISK-${Date.now()}`,
        txId,
        timestamp: new Date().toISOString(),
        trigger: 'LARGE_VALUE',
        severity: 'MEDIUM',
        payerName: payer.entityName,
        amount: input.amount,
        explainableReason: `Transaction amount ($${input.amount.toLocaleString()}) exceeds single-transfer standard threshold.`,
        status: 'PENDING_REVIEW'
      });
    }

    lifecycleSteps.push({ step: 'POLICY_CHECKED', timestamp: new Date().toISOString(), status: 'PASSED', detail: 'Account limit & policy passed' });
    lifecycleSteps.push({ step: 'FUNDS_RESERVED', timestamp: new Date().toISOString(), status: 'PASSED', detail: 'Fund reservation atomic lock acquired' });

    const settledTx: Transaction = {
      id: txId,
      idempotencyKey: idempKey,
      timestamp: new Date().toISOString(),
      payerId: payer.id,
      payerName: payer.entityName,
      payeeId: payee.id,
      payeeName: payee.entityName,
      amount: input.amount,
      currency: 'SGD',
      instrumentType: input.instrumentType,
      paymentChannel: input.paymentChannel,
      status: 'SETTLED',
      settlementStatus: 'FINALIZED',
      failureCode: 'NONE',
      policyResult: { passed: true, details: 'Standard transfer policy satisfied.' },
      riskResult: { flagged: isLargeValue, score: isLargeValue ? 65 : 5 },
      lifecycle: [
        ...lifecycleSteps,
        { step: 'SETTLED', timestamp: new Date().toISOString(), status: 'PASSED', detail: `Atomic settlement complete. $${input.amount} credited.` },
        { step: 'RECEIPT_ISSUED', timestamp: new Date().toISOString(), status: 'PASSED', detail: 'Digital receipt generated.' }
      ],
      auditRef: `AUD-${Date.now()}`,
      settlementTimeMs: Math.max(15, this.scenario.networkLatencyMs),
    };

    this.transactions.unshift(settledTx);
    this.addAuditEvent(
      'TRANSACTION_SETTLED', 'ledger', payer.id,
      `${payer.entityName} -> ${payee.entityName}: SGD $${input.amount}`,
      'Atomic settlement complete',
      { txId, amount: input.amount, type: input.instrumentType }
    );

    this.validateLedgerInvariants();
    this.notify();
    return settledTx;
  }

  private createFailedTx(
    txId: string, 
    idempKey: string, 
    payer: Account, 
    payee: Account, 
    input: any, 
    code: FailureCode, 
    reason: string, 
    lifecycle: any[],
    pbm?: PBMConfig
  ): Transaction {
    const failedTx: Transaction = {
      id: txId,
      idempotencyKey: idempKey,
      timestamp: new Date().toISOString(),
      payerId: payer.id,
      payerName: payer.entityName,
      payeeId: payee.id,
      payeeName: payee.entityName,
      amount: input.amount,
      currency: 'SGD',
      instrumentType: input.instrumentType,
      pbmId: pbm?.id,
      pbmName: pbm?.name,
      category: input.category,
      paymentChannel: input.paymentChannel,
      status: 'FAILED',
      settlementStatus: 'REJECTED',
      failureCode: code,
      failureReason: reason,
      policyResult: { passed: false, ruleChecked: code, details: reason },
      riskResult: { flagged: false, score: 10 },
      lifecycle: [
        ...lifecycle,
        { step: 'POLICY_CHECKED', timestamp: new Date().toISOString(), status: 'FAILED', detail: reason }
      ],
      auditRef: `AUD-FAIL-${Date.now()}`,
      settlementTimeMs: 20,
    };

    this.transactions.unshift(failedTx);
    this.metrics.failedTxCount++;
    this.addAuditEvent('TRANSACTION_FAILED', 'policy_engine', payer.id, 'Transaction attempted', `Failed with code ${code}: ${reason}`, { txId, code, reason });
    this.notify();
    return failedTx;
  }

  // 5. Merchant Refund & Reversal Engine
  public executeRefund(originalTxId: string, reason: string): { success: boolean; message: string; tx?: Transaction } {
    const origTx = this.transactions.find(t => t.id === originalTxId);
    if (!origTx || origTx.status !== 'SETTLED') {
      return { success: false, message: 'Original transaction not found or not in SETTLED state.' };
    }

    const payerMerchant = this.accounts.find(a => a.id === origTx.payeeId);
    const recipientCustomer = this.accounts.find(a => a.id === origTx.payerId);

    if (!payerMerchant || !recipientCustomer) {
      return { success: false, message: 'Merchant or Customer account missing.' };
    }

    if (payerMerchant.balances.unrestrictedCBDC < origTx.amount) {
      return { success: false, message: 'Merchant has insufficient unrestricted CBDC balance for refund.' };
    }

    // Invariant check: Reversal cannot exceed original settled amount
    payerMerchant.balances.unrestrictedCBDC -= origTx.amount;
    recipientCustomer.balances.unrestrictedCBDC += origTx.amount;

    const refundTx: Transaction = {
      id: `refund-${Date.now()}`,
      idempotencyKey: `idemp-ref-${origTx.id}`,
      timestamp: new Date().toISOString(),
      payerId: payerMerchant.id,
      payerName: payerMerchant.entityName,
      payeeId: recipientCustomer.id,
      payeeName: recipientCustomer.entityName,
      amount: origTx.amount,
      currency: 'SGD',
      instrumentType: 'CBDC_RETAIL',
      paymentChannel: origTx.paymentChannel,
      status: 'SETTLED',
      settlementStatus: 'FINALIZED',
      failureCode: 'NONE',
      policyResult: { passed: true, details: `Merchant-initiated refund for original tx ${origTx.id}` },
      riskResult: { flagged: false, score: 0 },
      lifecycle: [
        { step: 'INITIATED', timestamp: new Date().toISOString(), status: 'PASSED', detail: `Refund requested by ${payerMerchant.entityName}` },
        { step: 'SETTLED', timestamp: new Date().toISOString(), status: 'PASSED', detail: `SGD $${origTx.amount} refunded to ${recipientCustomer.entityName}` }
      ],
      auditRef: `AUD-REFUND-${Date.now()}`,
      settlementTimeMs: 30,
      isReversal: true,
      originalTxId: origTx.id,
    };

    origTx.status = 'REVERSED';
    this.transactions.unshift(refundTx);

    this.addAuditEvent(
      'REFUND_EXECUTED', 'settlement', payerMerchant.id,
      `Original Tx: ${origTx.id}`,
      `Refunded $${origTx.amount} back to ${recipientCustomer.entityName}`,
      { originalTxId: origTx.id, reason }
    );

    this.validateLedgerInvariants();
    this.notify();
    return { success: true, message: `Successfully refunded SGD $${origTx.amount.toFixed(2)} to ${recipientCustomer.entityName}.`, tx: refundTx };
  }

  // 6. Cross-Border Payment-versus-Payment (PvP) Laboratory Engine
  public executeCrossBorderPvP(params: {
    sourceCurrency: 'SGD';
    targetCurrency: 'USD' | 'EUR' | 'JPY' | 'CNY' | 'GBP';
    sourceAmount: number;
    fxRate: number;
    payerName: string;
    payeeName: string;
  }): CrossBorderLeg {
    const targetAmount = params.sourceAmount * params.fxRate;
    const legId = `pvp-${Date.now()}`;

    const leg: CrossBorderLeg = {
      id: legId,
      sourceCurrency: params.sourceCurrency,
      targetCurrency: params.targetCurrency,
      sourceAmount: params.sourceAmount,
      targetAmount,
      fxRate: params.fxRate,
      payerEntity: params.payerName,
      payeeEntity: params.payeeName,
      status: 'PVP_SETTLED',
      escrowRef: `ESCROW-${legId}`,
      settlementMode: 'ATOMIC_PVP'
    };

    this.crossBorderLegs.unshift(leg);
    this.addAuditEvent(
      'TRANSACTION_SETTLED', 'cross_border_lab', params.payerName,
      `Cross-Border PvP Initiated: ${params.sourceCurrency} $${params.sourceAmount}`,
      `Atomic PvP Settled: ${params.targetCurrency} ${targetAmount.toFixed(2)} delivered to ${params.payeeName}`,
      { legId, rate: params.fxRate, mode: 'ATOMIC_PVP' }
    );

    this.notify();
    return leg;
  }

  // 7. Scenario Controls & Ticker Simulation
  public setScenario(newParams: Partial<ScenarioParams>) {
    this.scenario = { ...this.scenario, ...newParams };
    this.addAuditEvent('SCENARIO_TRIGGERED', 'scenario_lab', 'SYSTEM', 'Scenario Parameters Updated', `Active Scenario: ${this.scenario.name}`, { scenario: this.scenario });
    this.notify();
  }

  private startBackgroundTicker() {
    if (this.tickerInterval) clearInterval(this.tickerInterval);
    this.tickerInterval = setInterval(() => {
      if (!this.isLiveTickerRunning) return;

      this.simulationClockMs += 1000;
      this.metrics.tpsCurrent = Math.floor((30 + Math.random() * 25) * this.scenario.txVolumeMultiplier);

      // Random background small consumer tx
      if (Math.random() < 0.35) {
        const residents = this.accounts.filter(a => a.entityType === 'RESIDENT');
        const merchants = this.accounts.filter(a => a.entityType === 'MERCHANT');

        if (residents.length > 0 && merchants.length > 0) {
          const randRes = residents[Math.floor(Math.random() * residents.length)];
          const randMerch = merchants[Math.floor(Math.random() * merchants.length)];
          const randAmt = +(Math.random() * 15 + 2).toFixed(2);

          // P2P or merchant payment
          if (randRes.balances.unrestrictedCBDC >= randAmt) {
            this.executeTransaction({
              payerId: randRes.id,
              payeeId: randMerch.id,
              amount: randAmt,
              instrumentType: 'CBDC_RETAIL',
              paymentChannel: 'QR_SGQR',
            });
          }
        }
      }

      this.notify();
    }, 3000);
  }

  public resolveRiskFlag(flagId: string, action: 'APPROVED' | 'BLOCKED_CONFIRMED' | 'DISMISSED') {
    const flag = this.riskFlags.find(f => f.id === flagId);
    if (flag) {
      flag.status = action;
      flag.resolvedBy = 'MAS_RISK_OFFICER_01';
      flag.resolvedAt = new Date().toISOString();
      this.notify();
    }
  }
}

export const simulationEngine = new SimulationEngine();
