/**
 * SINGDOLLAR.OS — 05. Purpose-Bound Money (PBM) Rule Studio
 */

import React, { useState } from 'react';
import { simulationEngine } from '../../simulation/engine';
import { PBMConfig, SpendingCategory, Account } from '../../types';
import { Code2, Play, AlertTriangle, Check, Copy, Sparkles, Sliders, Layers } from 'lucide-react';

interface PBMStudioProps {
  accounts: Account[];
  pbms: PBMConfig[];
  darkMode: boolean;
}

export const PBMStudio: React.FC<PBMStudioProps> = ({ accounts, pbms, darkMode }) => {
  const [name, setName] = useState<string>('National Senior Citizen Health Voucher');
  const [amount, setAmount] = useState<number>(150);
  const [beneficiaryClass, setBeneficiaryClass] = useState<string>('SINGAPORE_CITIZEN_60_ABOVE');
  const [selectedCategories, setSelectedCategories] = useState<SpendingCategory[]>(['HEALTHCARE_MEDICAL', 'GROCERIES_HOUSEHOLD']);
  const [validFrom, setValidFrom] = useState<string>('2026-01-01');
  const [validTo, setValidTo] = useState<string>('2026-12-31');
  const [maxTxAmount, setMaxTxAmount] = useState<number>(75);
  const [transferable, setTransferable] = useState<boolean>(false);
  const [geoScope, setGeoScope] = useState<string>('SINGAPORE_ALL');

  // Test Simulator state
  const [testAmount, setTestAmount] = useState<number>(50);
  const [testCategory, setTestCategory] = useState<SpendingCategory>('HEALTHCARE_MEDICAL');
  const [testMerchantType, setTestMerchantType] = useState<'APPROVED' | 'UNAPPROVED'>('APPROVED');
  const [testResult, setTestResult] = useState<{ passed: boolean; reason: string } | null>(null);

  const toggleCategory = (cat: SpendingCategory) => {
    if (selectedCategories.includes(cat)) {
      setSelectedCategories(selectedCategories.filter(c => c !== cat));
    } else {
      setSelectedCategories([...selectedCategories, cat]);
    }
  };

  // Human Readable Summary Generation
  const humanReadableSummary = `SGD ${amount} may be spent by eligible ${beneficiaryClass.toLowerCase().replace(/_/g, ' ')} at approved ${
    selectedCategories.map(c => c.toLowerCase().replace(/_/g, ' ')).join(' & ')
  } merchants in ${geoScope} until ${new Date(validTo).toLocaleDateString('en-SG', { day: 'numeric', month: 'long', year: 'numeric' })}. Maximum single transaction cap is SGD $${maxTxAmount}. Transferability: ${transferable ? 'Permitted' : 'Prohibited'}.`;

  // Machine Readable JSON
  const machineJson = JSON.stringify({
    protocol: 'MAS_PROJECT_ORCHID_PBM_V3',
    principal_amount: amount,
    currency: 'SGD',
    beneficiary_class: beneficiaryClass,
    permitted_categories: selectedCategories,
    max_transaction_cap: maxTxAmount,
    validity: { from: `${validFrom}T00:00:00Z`, to: `${validTo}T23:59:59Z` },
    transferable,
    release_conditions: ['MERCHANT_WHITELIST_MATCH', 'CATEGORY_VERIFIED', 'VALIDITY_WINDOW_ACTIVE']
  }, null, 2);

  const handleTestRun = () => {
    // Evaluate logic
    if (testAmount > maxTxAmount) {
      setTestResult({ passed: false, reason: `Rejected: Requested transaction amount ($${testAmount}) exceeds PBM cap ($${maxTxAmount}).` });
      return;
    }

    if (!selectedCategories.includes(testCategory)) {
      setTestResult({ passed: false, reason: `Rejected: Category '${testCategory}' is not permitted under configured PBM rule.` });
      return;
    }

    if (testMerchantType === 'UNAPPROVED') {
      setTestResult({ passed: false, reason: `Rejected: Merchant is not registered in the approved PBM category whitelist.` });
      return;
    }

    setTestResult({ passed: true, reason: `Passed: All PBM wrapper conditions satisfied! SGD $${testAmount} underlying value released to merchant.` });
  };

  const handlePublishPBM = () => {
    const govAcc = accounts.find(a => a.entityType === 'GOVERNMENT_AGENCY') || accounts[0];
    simulationEngine.createPBM({
      name,
      principalAmount: amount,
      currency: 'SGD',
      issuerId: govAcc.id,
      issuerName: govAcc.entityName,
      beneficiaryClass,
      permittedMerchantIds: [],
      permittedCategories: selectedCategories,
      geographicConstraints: [geoScope],
      validFrom: `${validFrom}T00:00:00Z`,
      validTo: `${validTo}T23:59:59Z`,
      maxTxAmount,
      transferable,
      releaseConditions: ['MERCHANT_WHITELIST_MATCH', 'CATEGORY_VERIFIED'],
      originalBalance: amount,
      underlyingInstrumentType: 'CBDC_RETAIL',
    });
    alert(`PBM Rule '${name}' published to ledger successfully!`);
  };

  return (
    <div className="space-y-6 font-mono text-xs">
      {/* Top Banner */}
      <div className={`p-4 rounded border ${darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'}`}>
        <div className="flex flex-wrap items-center justify-between gap-4 pb-3 border-b border-neutral-200 dark:border-neutral-800">
          <div className="flex items-center gap-2">
            <Code2 className="w-5 h-5 text-[#7A5C90]" />
            <div>
              <h2 className="text-sm font-bold uppercase">PURPOSE-BOUND MONEY (PBM) RULE STUDIO & POLICY SYNTHESIZER</h2>
              <p className="text-[11px] text-neutral-500">
                Design and test protocol wrappers that bind specific logic onto digital Singapore dollars.
              </p>
            </div>
          </div>

          <button
            onClick={handlePublishPBM}
            className="px-3.5 py-2 rounded bg-[#C8102E] text-white font-bold hover:bg-[#a00c24] flex items-center gap-1.5"
          >
            <Sparkles className="w-4 h-4" />
            <span>PUBLISH PBM WRAPPER TO LEDGER</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Left Rule Form Builder, Right Real-Time Summaries & Test Harness */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Form: Visual Rule Configurator */}
        <div className={`p-4 rounded border space-y-4 ${
          darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'
        }`}>
          <h3 className="text-xs font-bold uppercase text-neutral-500 border-b pb-2 dark:border-neutral-800 flex items-center gap-2">
            <Sliders className="w-4 h-4 text-[#C8102E]" />
            WRAPPER SPECIFICATION CONFIGURATOR
          </h3>

          <div>
            <label className="block text-neutral-500 mb-1">PBM PROGRAMME NAME:</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full p-2 rounded border bg-neutral-50 dark:bg-neutral-900 border-neutral-300 dark:border-neutral-700 font-bold text-xs"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-neutral-500 mb-1">PRINCIPAL VALUE (SGD):</label>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value))}
                className="w-full p-2 rounded border bg-neutral-50 dark:bg-neutral-900 border-neutral-300 dark:border-neutral-700 font-bold"
              />
            </div>

            <div>
              <label className="block text-neutral-500 mb-1">MAX TX CAP (SGD):</label>
              <input
                type="number"
                value={maxTxAmount}
                onChange={(e) => setMaxTxAmount(Number(e.target.value))}
                className="w-full p-2 rounded border bg-neutral-50 dark:bg-neutral-900 border-neutral-300 dark:border-neutral-700 font-bold"
              />
            </div>
          </div>

          <div>
            <label className="block text-neutral-500 mb-1">PERMITTED SPENDING CATEGORIES:</label>
            <div className="flex flex-wrap gap-2 pt-1">
              {(['GROCERIES_HOUSEHOLD', 'HEALTHCARE_MEDICAL', 'EDUCATION_TRAINING', 'HAWKER_FOOD', 'PUBLIC_TRANSPORT'] as SpendingCategory[]).map(cat => {
                const isSel = selectedCategories.includes(cat);
                return (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => toggleCategory(cat)}
                    className={`px-2.5 py-1 rounded text-[10px] font-bold border transition ${
                      isSel
                        ? 'bg-[#7A5C90] text-white border-[#7A5C90]'
                        : 'bg-neutral-100 dark:bg-neutral-900 text-neutral-600 dark:text-neutral-400 border-neutral-300 dark:border-neutral-700'
                    }`}
                  >
                    {cat}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-neutral-500 mb-1">VALID FROM:</label>
              <input
                type="date"
                value={validFrom}
                onChange={(e) => setValidFrom(e.target.value)}
                className="w-full p-2 rounded border bg-neutral-50 dark:bg-neutral-900 border-neutral-300 dark:border-neutral-700"
              />
            </div>

            <div>
              <label className="block text-neutral-500 mb-1">VALID UNTIL (EXPIRY):</label>
              <input
                type="date"
                value={validTo}
                onChange={(e) => setValidTo(e.target.value)}
                className="w-full p-2 rounded border bg-neutral-50 dark:bg-neutral-900 border-neutral-300 dark:border-neutral-700 font-bold text-red-500"
              />
            </div>
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-neutral-200 dark:border-neutral-800">
            <span className="text-neutral-500">TRANSFERABLE BETWEEN RESIDENTS:</span>
            <input
              type="checkbox"
              checked={transferable}
              onChange={(e) => setTransferable(e.target.checked)}
              className="accent-[#C8102E] w-4 h-4 cursor-pointer"
            />
          </div>
        </div>

        {/* Right Column: Output Human Summary, Machine JSON, and Interactive Test Simulator */}
        <div className="space-y-6">
          {/* Human Readable Summary Box */}
          <div className={`p-4 rounded border ${darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'}`}>
            <h4 className="text-xs font-bold uppercase text-neutral-500 border-b pb-2 mb-3 dark:border-neutral-800">
              HUMAN-READABLE POLICY SPECIFICATION
            </h4>
            <div className="p-3 bg-neutral-50 dark:bg-neutral-900/80 rounded border border-neutral-200 dark:border-neutral-800 text-xs leading-relaxed text-neutral-800 dark:text-neutral-200 font-sans">
              "{humanReadableSummary}"
            </div>
          </div>

          {/* Machine JSON Representation */}
          <div className={`p-4 rounded border ${darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'}`}>
            <h4 className="text-xs font-bold uppercase text-neutral-500 border-b pb-2 mb-3 dark:border-neutral-800 flex justify-between">
              <span>MACHINE-READABLE PROTOCOL JSON</span>
              <span className="text-[10px] text-purple-500">MAS-ORCHID-SCHEMA</span>
            </h4>
            <pre className="p-3 bg-[#111113] text-emerald-400 rounded text-[10px] font-mono overflow-x-auto max-h-36">
              {machineJson}
            </pre>
          </div>

          {/* Interactive Test Transaction Harness */}
          <div className={`p-4 rounded border space-y-3 ${darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'}`}>
            <h4 className="text-xs font-bold uppercase text-neutral-500 border-b pb-2 dark:border-neutral-800 flex items-center gap-2">
              <Play className="w-4 h-4 text-emerald-500" />
              INTERACTIVE RULE EVALUATION SIMULATOR
            </h4>

            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="block text-neutral-500 text-[10px] mb-1">TEST AMOUNT:</label>
                <input
                  type="number"
                  value={testAmount}
                  onChange={(e) => setTestAmount(Number(e.target.value))}
                  className="w-full p-1.5 rounded border bg-neutral-50 dark:bg-neutral-900 border-neutral-300 dark:border-neutral-700 font-bold"
                />
              </div>

              <div>
                <label className="block text-neutral-500 text-[10px] mb-1">TEST CATEGORY:</label>
                <select
                  value={testCategory}
                  onChange={(e) => setTestCategory(e.target.value as any)}
                  className="w-full p-1.5 rounded border bg-neutral-50 dark:bg-neutral-900 border-neutral-300 dark:border-neutral-700 text-[11px]"
                >
                  <option value="HEALTHCARE_MEDICAL">Healthcare</option>
                  <option value="GROCERIES_HOUSEHOLD">Groceries</option>
                  <option value="GENERAL_RETAIL">General Retail</option>
                  <option value="EDUCATION_TRAINING">Education</option>
                </select>
              </div>

              <div>
                <label className="block text-neutral-500 text-[10px] mb-1">MERCHANT TYPE:</label>
                <select
                  value={testMerchantType}
                  onChange={(e) => setTestMerchantType(e.target.value as any)}
                  className="w-full p-1.5 rounded border bg-neutral-50 dark:bg-neutral-900 border-neutral-300 dark:border-neutral-700 text-[11px]"
                >
                  <option value="APPROVED">APPROVED WHITELIST</option>
                  <option value="UNAPPROVED">UNAPPROVED STORE</option>
                </select>
              </div>
            </div>

            <button
              onClick={handleTestRun}
              className="w-full py-2 rounded bg-[#7A5C90] text-white font-bold hover:bg-[#624775] transition"
            >
              SIMULATE RULE EVALUATION
            </button>

            {testResult && (
              <div className={`p-3 rounded border font-bold text-xs ${
                testResult.passed
                  ? 'bg-emerald-500/10 border-emerald-500 text-emerald-600 dark:text-emerald-400'
                  : 'bg-red-500/10 border-red-500 text-red-600 dark:text-red-400'
              }`}>
                {testResult.reason}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
