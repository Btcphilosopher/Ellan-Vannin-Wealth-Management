/**
 * SINGDOLLAR.OS — 10. Simulation and Scenario Laboratory
 */

import React from 'react';
import { simulationEngine } from '../../simulation/engine';
import { ScenarioParams } from '../../types';
import { Sliders, Play, RefreshCw, AlertTriangle, Cpu, Zap } from 'lucide-react';

interface ScenarioLabProps {
  scenario: ScenarioParams;
  darkMode: boolean;
}

export const ScenarioLab: React.FC<ScenarioLabProps> = ({ scenario, darkMode }) => {
  const applyPreset = (presetName: string) => {
    if (presetName === 'NORMAL') {
      simulationEngine.setScenario({
        name: 'Normal Operating Day',
        description: 'Standard retail and wholesale transaction baseline across Singapore.',
        txVolumeMultiplier: 1,
        networkLatencyMs: 65,
        failureRatePercent: 1,
        simulateBankOutage: false,
      });
    } else if (presetName === 'VOUCHER_DISTRIBUTION') {
      simulationEngine.setScenario({
        name: 'National CDC Voucher Distribution (100,000 Recipients)',
        description: 'Simulates government disbursement batch issuing 100,000 PBM vouchers.',
        txVolumeMultiplier: 4.5,
        networkLatencyMs: 95,
        failureRatePercent: 2,
        simulateBankOutage: false,
      });
    } else if (presetName === 'HOLIDAY_SURGE') {
      simulationEngine.setScenario({
        name: 'Retail Payment Holiday Surge (Chinese New Year Peak)',
        description: 'High transaction concurrency across merchant POS terminals.',
        txVolumeMultiplier: 8,
        networkLatencyMs: 140,
        failureRatePercent: 3,
        simulateBankOutage: false,
      });
    } else if (presetName === 'BANK_OUTAGE') {
      simulationEngine.setScenario({
        name: 'Settlement Disruption (Bank B Outage)',
        description: 'Simulates temporary network outage at OCBC Bank causing queue buildup.',
        txVolumeMultiplier: 2,
        networkLatencyMs: 250,
        failureRatePercent: 15,
        simulateBankOutage: true,
        outageBankId: 'ent-ocbc',
      });
    }
  };

  return (
    <div className="space-y-6 font-mono text-xs">
      {/* Top Banner */}
      <div className={`p-4 rounded border ${darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'}`}>
        <div className="flex flex-wrap items-center justify-between gap-4 pb-3 border-b border-neutral-200 dark:border-neutral-800">
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-[#C8102E]" />
            <div>
              <h2 className="text-sm font-bold uppercase">SIMULATION & STRESS-TEST SCENARIO LABORATORY</h2>
              <p className="text-[11px] text-neutral-500">
                Inject Failures, Tweak Throughput Multipliers, and Test System Resiliency
              </p>
            </div>
          </div>

          <span className="px-2.5 py-1 rounded bg-amber-500 text-black font-bold text-xs flex items-center gap-1.5">
            <Zap className="w-4 h-4" />
            <span>ACTIVE: {scenario.name}</span>
          </span>
        </div>
      </div>

      {/* Preset Scenarios Buttons Grid */}
      <div className={`p-4 rounded border space-y-3 ${darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'}`}>
        <h3 className="text-xs font-bold uppercase text-neutral-500 border-b pb-2 dark:border-neutral-800">
          PRESET MONETARY SCENARIO TEMPLATES
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
          <button
            onClick={() => applyPreset('NORMAL')}
            className="p-3 rounded border text-left bg-neutral-50 dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800 hover:border-[#C8102E] transition space-y-1"
          >
            <div className="font-bold text-xs text-emerald-600 dark:text-emerald-400">1. NORMAL OPERATING DAY</div>
            <p className="text-[10px] text-neutral-400">Baseline consumer merchant traffic (48 TPS average).</p>
          </button>

          <button
            onClick={() => applyPreset('VOUCHER_DISTRIBUTION')}
            className="p-3 rounded border text-left bg-neutral-50 dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800 hover:border-[#C8102E] transition space-y-1"
          >
            <div className="font-bold text-xs text-purple-600 dark:text-purple-400">2. CDC VOUCHER MASS ISSUE</div>
            <p className="text-[10px] text-neutral-400">100,000 PBM allocations issued simultaneously.</p>
          </button>

          <button
            onClick={() => applyPreset('HOLIDAY_SURGE')}
            className="p-3 rounded border text-left bg-neutral-50 dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800 hover:border-[#C8102E] transition space-y-1"
          >
            <div className="font-bold text-xs text-amber-600 dark:text-amber-400">3. RETAIL HOLIDAY SURGE</div>
            <p className="text-[10px] text-neutral-400">8x transaction volume burst across heartland shops.</p>
          </button>

          <button
            onClick={() => applyPreset('BANK_OUTAGE')}
            className="p-3 rounded border text-left bg-neutral-50 dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800 hover:border-[#C8102E] transition space-y-1"
          >
            <div className="font-bold text-xs text-red-500">4. BANK OUTAGE DISRUPT</div>
            <p className="text-[10px] text-neutral-400">OCBC node failure simulation &rarr; queue spikes.</p>
          </button>
        </div>
      </div>

      {/* Manual Parameters Slider Controls */}
      <div className={`p-4 rounded border space-y-4 ${darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'}`}>
        <h3 className="text-xs font-bold uppercase text-neutral-500 border-b pb-2 dark:border-neutral-800">
          FINE-GRAINED PARAMETER CONTROLS
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <div className="flex justify-between mb-1 font-bold">
              <span>TRANSACTION VOLUME MULTIPLIER:</span>
              <span className="text-[#C8102E]">{scenario.txVolumeMultiplier}x</span>
            </div>
            <input
              type="range"
              min="1"
              max="10"
              step="0.5"
              value={scenario.txVolumeMultiplier}
              onChange={(e) => simulationEngine.setScenario({ txVolumeMultiplier: Number(e.target.value) })}
              className="w-full accent-[#C8102E] cursor-pointer"
            />
          </div>

          <div>
            <div className="flex justify-between mb-1 font-bold">
              <span>NETWORK LATENCY INJECTION:</span>
              <span className="text-amber-500">{scenario.networkLatencyMs} ms</span>
            </div>
            <input
              type="range"
              min="20"
              max="500"
              step="10"
              value={scenario.networkLatencyMs}
              onChange={(e) => simulationEngine.setScenario({ networkLatencyMs: Number(e.target.value) })}
              className="w-full accent-amber-500 cursor-pointer"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
