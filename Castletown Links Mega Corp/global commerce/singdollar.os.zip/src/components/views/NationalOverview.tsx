/**
 * SINGDOLLAR.OS — 01. National Overview Module
 */

import React from 'react';
import { SystemMetrics, Transaction, Account } from '../../types';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { Activity, Landmark, ShieldCheck, CreditCard, Layers, ArrowUpRight, ArrowDownRight, Server, Clock } from 'lucide-react';

interface NationalOverviewProps {
  metrics: SystemMetrics;
  transactions: Transaction[];
  accounts: Account[];
  darkMode: boolean;
}

export const NationalOverview: React.FC<NationalOverviewProps> = ({
  metrics,
  transactions,
  accounts,
  darkMode
}) => {
  // Chart synthetic throughput data
  const chartData = [
    { time: '08:00', tps: 32, latency: 65 },
    { time: '08:05', tps: 45, latency: 70 },
    { time: '08:10', tps: 58, latency: 78 },
    { time: '08:15', tps: metrics.tpsCurrent, latency: metrics.avgSettlementMs },
    { time: '08:20', tps: metrics.tpsCurrent + 12, latency: 82 },
    { time: '08:25', tps: metrics.tpsCurrent - 5, latency: 75 },
  ];

  const totalMonetaryBase = metrics.totalIssuedCBDC + metrics.totalWholesaleCBDC + metrics.totalTokenisedDeposits + metrics.totalStablecoins;

  return (
    <div className="space-y-6">
      {/* Top Banner Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
        <div className={`p-3 rounded border font-mono ${darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'}`}>
          <div className="text-[10px] text-neutral-500 uppercase tracking-wider">TOTAL MONETARY ISSUANCE</div>
          <div className="text-lg font-bold text-emerald-600 dark:text-emerald-400 mt-1">
            S$ {(totalMonetaryBase / 1e9).toFixed(3)}B
          </div>
          <div className="text-[10px] text-neutral-400 mt-0.5 flex items-center gap-1">
            <ArrowUpRight className="w-3 h-3 text-emerald-500" />
            <span>Sum of all simulated rails</span>
          </div>
        </div>

        <div className={`p-3 rounded border font-mono ${darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'}`}>
          <div className="text-[10px] text-neutral-500 uppercase tracking-wider">RETAIL CBDC (MAS)</div>
          <div className="text-lg font-bold mt-1">
            S$ {(metrics.totalIssuedCBDC / 1e6).toFixed(1)}M
          </div>
          <div className="text-[10px] text-neutral-400 mt-0.5">Direct Central Bank Liability</div>
        </div>

        <div className={`p-3 rounded border font-mono ${darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'}`}>
          <div className="text-[10px] text-neutral-500 uppercase tracking-wider">TOKENISED DEPOSITS</div>
          <div className="text-lg font-bold text-sky-600 dark:text-sky-400 mt-1">
            S$ {(metrics.totalTokenisedDeposits / 1e6).toFixed(1)}M
          </div>
          <div className="text-[10px] text-neutral-400 mt-0.5">DBS, OCBC, UOB Commercial</div>
        </div>

        <div className={`p-3 rounded border font-mono ${darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'}`}>
          <div className="text-[10px] text-neutral-500 uppercase tracking-wider">PURPOSE-BOUND VALUE</div>
          <div className="text-lg font-bold text-[#7A5C90] dark:text-[#9370DB] mt-1">
            S$ {(metrics.totalPBMValue / 1e6).toFixed(2)}M
          </div>
          <div className="text-[10px] text-neutral-400 mt-0.5">CDC, SkillsFuture, Vouchers</div>
        </div>

        <div className={`p-3 rounded border font-mono ${darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'}`}>
          <div className="text-[10px] text-neutral-500 uppercase tracking-wider">ACTIVE WALLETS / NODES</div>
          <div className="text-lg font-bold mt-1">
            {metrics.activeWallets.toLocaleString()}
          </div>
          <div className="text-[10px] text-neutral-400 mt-0.5">{metrics.participatingInstitutions} Institutions</div>
        </div>

        <div className={`p-3 rounded border font-mono ${darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'}`}>
          <div className="text-[10px] text-neutral-500 uppercase tracking-wider">AVG SETTLEMENT LATENCY</div>
          <div className="text-lg font-bold text-emerald-500 mt-1">
            {metrics.avgSettlementMs} ms
          </div>
          <div className="text-[10px] text-neutral-400 mt-0.5">Atomic Finality</div>
        </div>
      </div>

      {/* Main Grid Section: Flow Diagram & Realtime Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column (2 cols): Monetary Flow SVG Architecture */}
        <div className={`lg:col-span-2 p-4 rounded border ${darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'}`}>
          <div className="flex items-center justify-between pb-3 mb-4 border-b border-neutral-200 dark:border-neutral-800">
            <div>
              <h3 className="font-mono text-sm font-bold flex items-center gap-2">
                <Layers className="w-4 h-4 text-[#C8102E]" />
                SINGAPORE DIGITAL MONETARY ARCHITECTURE & FLOWS
              </h3>
              <p className="text-xs text-neutral-500 font-mono">
                Project Orchid Inspired Separation: Central Bank Money vs Tokenised Commercial Deposits vs PBM Wrappers
              </p>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 rounded">
              DETERMINISTIC
            </span>
          </div>

          {/* SVG Diagram */}
          <div className="relative border rounded p-4 bg-neutral-50 dark:bg-neutral-900/50 border-neutral-200 dark:border-neutral-800 font-mono text-xs">
            <div className="grid grid-cols-3 gap-4 text-center">
              {/* Box 1: Issuance Tier */}
              <div className="p-3 bg-red-500/10 border border-red-500/30 rounded">
                <div className="text-red-600 dark:text-red-400 font-bold mb-1">TIER 1: MAS ISSUANCE</div>
                <div className="text-[11px] text-neutral-600 dark:text-neutral-400 space-y-1">
                  <div>Retail CBDC</div>
                  <div>Wholesale Settlement SGD</div>
                </div>
              </div>

              {/* Box 2: Intermediary Banks */}
              <div className="p-3 bg-sky-500/10 border border-sky-500/30 rounded">
                <div className="text-sky-600 dark:text-sky-400 font-bold mb-1">TIER 2: BANKS & STABLECOINS</div>
                <div className="text-[11px] text-neutral-600 dark:text-neutral-400 space-y-1">
                  <div>DBS / OCBC / UOB Tokens</div>
                  <div>XSGD Stablecoins</div>
                </div>
              </div>

              {/* Box 3: Programmable Wrapper */}
              <div className="p-3 bg-purple-500/10 border border-purple-500/30 rounded">
                <div className="text-purple-600 dark:text-purple-400 font-bold mb-1">TIER 3: PBM WRAPPER</div>
                <div className="text-[11px] text-neutral-600 dark:text-neutral-400 space-y-1">
                  <div>CDC Vouchers ($200)</div>
                  <div>SkillsFuture ($500)</div>
                </div>
              </div>
            </div>

            {/* Arrows Visualiser */}
            <div className="my-4 text-center text-neutral-400 text-[10px] flex items-center justify-around">
              <span>↓ Direct Central Bank Claim</span>
              <span>↓ Bank Balance Sheet Backing</span>
              <span>↓ Condition Contract Release</span>
            </div>

            <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded text-center">
              <div className="text-emerald-600 dark:text-emerald-400 font-bold mb-1">
                END-USER RETAIL RECIPIENTS & MERCHANTS
              </div>
              <p className="text-[11px] text-neutral-600 dark:text-neutral-400">
                Merchants receive unrestricted, final simulated settlement SGD upon PBM condition verification.
              </p>
            </div>
          </div>

          {/* Realtime Throughput Chart */}
          <div className="mt-6 pt-4 border-t border-neutral-200 dark:border-neutral-800">
            <h4 className="font-mono text-xs font-semibold text-neutral-500 mb-3 uppercase">
              REAL-TIME TRANSACTION THROUGHPUT (TPS)
            </h4>
            <div className="h-40 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData}>
                  <defs>
                    <linearGradient id="colorTps" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#C8102E" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="#C8102E" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="time" stroke="#888888" fontSize={10} tickLine={false} />
                  <YAxis stroke="#888888" fontSize={10} tickLine={false} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: darkMode ? '#1A1A1E' : '#FFFFFF', borderColor: '#888888', fontSize: '12px' }}
                  />
                  <Area type="monotone" dataKey="tps" stroke="#C8102E" fillOpacity={1} fill="url(#colorTps)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Right Column: Live Ticker Stream & Queue Status */}
        <div className="space-y-6">
          <div className={`p-4 rounded border ${darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'}`}>
            <h3 className="font-mono text-xs font-bold text-neutral-500 uppercase pb-2 mb-3 border-b border-neutral-200 dark:border-neutral-800 flex items-center justify-between">
              <span>LIVE SETTLEMENT TICKER</span>
              <Activity className="w-3.5 h-3.5 text-emerald-500 animate-pulse" />
            </h3>

            <div className="space-y-2 max-h-[380px] overflow-y-auto pr-1">
              {transactions.slice(0, 8).map((tx) => (
                <div
                  key={tx.id}
                  className="p-2.5 rounded border text-xs font-mono space-y-1 bg-neutral-50 dark:bg-neutral-900/60 border-neutral-200 dark:border-neutral-800/80"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-semibold truncate max-w-[140px] text-neutral-800 dark:text-neutral-200">
                      {tx.payerName}
                    </span>
                    <span className="text-emerald-600 dark:text-emerald-400 font-bold">
                      S$ {tx.amount.toFixed(2)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[10px] text-neutral-500">
                    <span>→ {tx.payeeName}</span>
                    <span className={`px-1 py-0.2 rounded font-bold ${
                      tx.status === 'SETTLED' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' : 'bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300'
                    }`}>
                      {tx.status}
                    </span>
                  </div>
                  <div className="text-[9px] text-neutral-400 flex justify-between pt-0.5">
                    <span>Channel: {tx.paymentChannel}</span>
                    <span>{tx.settlementTimeMs}ms</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className={`p-4 rounded border font-mono text-xs space-y-2 ${darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'}`}>
            <div className="text-neutral-500 font-bold text-[11px] uppercase">SETTLEMENT QUEUE STATUS</div>
            <div className="flex items-center justify-between py-1 border-b border-neutral-200 dark:border-neutral-800">
              <span className="text-neutral-400">Queue Depth:</span>
              <span className="font-semibold">{metrics.queueDepth} txs</span>
            </div>
            <div className="flex items-center justify-between py-1 border-b border-neutral-200 dark:border-neutral-800">
              <span className="text-neutral-400">System Health:</span>
              <span className="text-emerald-500 font-semibold">{metrics.systemHealth}</span>
            </div>
            <div className="flex items-center justify-between py-1">
              <span className="text-neutral-400">Failed Txs (Session):</span>
              <span className="text-red-500 font-semibold">{metrics.failedTxCount}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
