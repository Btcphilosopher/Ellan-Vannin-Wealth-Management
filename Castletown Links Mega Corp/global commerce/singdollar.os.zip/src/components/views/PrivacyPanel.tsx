/**
 * SINGDOLLAR.OS — 09. Privacy and User Control
 */

import React, { useState } from 'react';
import { Lock, Eye, EyeOff, ShieldCheck, Key } from 'lucide-react';

interface PrivacyPanelProps {
  darkMode: boolean;
}

export const PrivacyPanel: React.FC<PrivacyPanelProps> = ({ darkMode }) => {
  const [dataMinimisation, setDataMinimisation] = useState<boolean>(true);
  const [usePseudonyms, setUsePseudonyms] = useState<boolean>(true);
  const [zkProofVerified, setZkProofVerified] = useState<boolean>(false);

  return (
    <div className="space-y-6 font-mono text-xs">
      {/* Top Banner */}
      <div className={`p-4 rounded border ${darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'}`}>
        <div className="flex items-center gap-2 pb-3 border-b border-neutral-200 dark:border-neutral-800">
          <Lock className="w-5 h-5 text-[#C8102E]" />
          <div>
            <h2 className="text-sm font-bold uppercase">PRIVACY & DATA MINIMISATION ARCHITECTURE</h2>
            <p className="text-[11px] text-neutral-500">
              Conceptual Models for Selective Disclosure and Pseudonymous Settlement
            </p>
          </div>
        </div>
      </div>

      {/* Access Matrix Table */}
      <div className={`p-4 rounded border ${darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'}`}>
        <h3 className="text-xs font-bold uppercase text-neutral-500 border-b pb-3 mb-4 dark:border-neutral-800">
          STAKEHOLDER DATA VISIBILITY ACCESS MATRIX
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse font-mono text-[11px]">
            <thead>
              <tr className="border-b border-neutral-300 dark:border-neutral-800 text-neutral-500">
                <th className="py-2 px-3">DATA FIELD</th>
                <th className="py-2 px-3">MERCHANT</th>
                <th className="py-2 px-3">COMMERCIAL BANK</th>
                <th className="py-2 px-3">CENTRAL BANK (MAS)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-200 dark:divide-neutral-800">
              <tr>
                <td className="py-2.5 px-3 font-bold">Payer Singpass Identity</td>
                <td className="py-2.5 px-3 text-red-500 font-bold flex items-center gap-1">
                  <EyeOff className="w-3.5 h-3.5" /> HIDDEN (PSEUDONYM)
                </td>
                <td className="py-2.5 px-3 text-amber-500">KYC VERIFIED ONLY</td>
                <td className="py-2.5 px-3 text-neutral-400">ENCRYPTED AT REST</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-bold">PBM Eligibility Proof</td>
                <td className="py-2.5 px-3 text-emerald-500 font-bold flex items-center gap-1">
                  <Eye className="w-3.5 h-3.5" /> VERIFIED (PASS/FAIL)
                </td>
                <td className="py-2.5 px-3 text-emerald-500">VERIFIED</td>
                <td className="py-2.5 px-3 text-emerald-500">AGGREGATE AUDIT</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-bold">Basket Items / Receipts</td>
                <td className="py-2.5 px-3 text-emerald-500">LOCAL POS ONLY</td>
                <td className="py-2.5 px-3 text-red-500 font-bold">REDACTED</td>
                <td className="py-2.5 px-3 text-red-500 font-bold">REDACTED</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Selective Disclosure Interactive Demo */}
      <div className={`p-4 rounded border space-y-4 ${darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'}`}>
        <h3 className="text-xs font-bold uppercase text-neutral-500 border-b pb-2 dark:border-neutral-800 flex items-center gap-2">
          <Key className="w-4 h-4 text-emerald-500" />
          SELECTIVE DISCLOSURE PROOF DEMONSTRATOR
        </h3>

        <p className="text-neutral-400 text-[11px]">
          Demonstrates how a resident can prove age eligibility (e.g. Senior Citizen &gt; 60) to unlock a PBM voucher without revealing their exact birthdate or NRIC.
        </p>

        <button
          onClick={() => setZkProofVerified(true)}
          className="px-4 py-2 rounded bg-[#7A5C90] text-white font-bold hover:bg-[#624775] transition"
        >
          GENERATE & VERIFY ZERO-KNOWLEDGE AGE PROOF
        </button>

        {zkProofVerified && (
          <div className="p-3 bg-emerald-500/10 border border-emerald-500/40 rounded space-y-1 text-emerald-600 dark:text-emerald-400 font-bold text-xs">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-500" />
              <span>PROOF VERIFIED: AGE &gt; 60 SATISFIED</span>
            </div>
            <p className="text-[10px] text-neutral-400 font-normal">
              Actual NRIC/Birthdate remains strictly private on user device. Cryptographic commitment signature accepted by ledger.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
