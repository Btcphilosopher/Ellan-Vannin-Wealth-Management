/**
 * SINGDOLLAR.OS — 03. Wallet and Account Explorer Module
 */

import React, { useState } from 'react';
import { simulationEngine } from '../../simulation/engine';
import { Account, Transaction, InstrumentType } from '../../types';
import { Wallet, Smartphone, ShieldCheck, ArrowUpRight, ArrowDownRight, Search, RefreshCw, Send, AlertTriangle } from 'lucide-react';

interface WalletExplorerProps {
  accounts: Account[];
  transactions: Transaction[];
  darkMode: boolean;
}

export const WalletExplorer: React.FC<WalletExplorerProps> = ({ accounts, transactions, darkMode }) => {
  const [selectedAccId, setSelectedAccId] = useState<string>(accounts[6]?.id || accounts[0]?.id); // Tan Ah Kow default
  const [filterType, setFilterType] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Transfer drawer modal form state
  const [showTransferModal, setShowTransferModal] = useState<boolean>(false);
  const [transferPayeeId, setTransferPayeeId] = useState<string>(accounts[9]?.id || '');
  const [transferAmount, setTransferAmount] = useState<number>(25.00);
  const [transferInstrument, setTransferInstrument] = useState<InstrumentType>('CBDC_RETAIL');
  const [transferChannel, setTransferChannel] = useState<Transaction['paymentChannel']>('QR_SGQR');
  const [transferResult, setTransferResult] = useState<Transaction | null>(null);

  const selectedAccount = accounts.find(a => a.id === selectedAccId) || accounts[0];

  const filteredAccounts = accounts.filter(a => {
    const matchesType = filterType === 'ALL' || a.entityType === filterType;
    const matchesSearch = a.entityName.toLowerCase().includes(searchQuery.toLowerCase()) || a.id.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesType && matchesSearch;
  });

  const accountTransactions = transactions.filter(t => t.payerId === selectedAccount.id || t.payeeId === selectedAccount.id);

  const handleSendTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    const res = simulationEngine.executeTransaction({
      payerId: selectedAccount.id,
      payeeId: transferPayeeId,
      amount: transferAmount,
      instrumentType: transferInstrument,
      paymentChannel: transferChannel,
    });
    setTransferResult(res);
  };

  return (
    <div className="space-y-6 font-mono text-xs">
      {/* Top Filter & Search Bar */}
      <div className={`p-4 rounded border flex flex-wrap items-center justify-between gap-4 ${
        darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'
      }`}>
        <div className="flex items-center gap-3 flex-1 min-w-[260px]">
          <Search className="w-4 h-4 text-neutral-400" />
          <input
            type="text"
            placeholder="Search Resident, Merchant, Bank or Account ID..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-transparent outline-none text-xs"
          />
        </div>

        <div className="flex items-center gap-2">
          <span className="text-neutral-500 text-[11px]">ENTITY FILTER:</span>
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="p-1.5 rounded border bg-neutral-50 dark:bg-neutral-900 border-neutral-300 dark:border-neutral-700"
          >
            <option value="ALL">ALL ENTITIES</option>
            <option value="RESIDENT">RESIDENTS</option>
            <option value="MERCHANT">MERCHANTS</option>
            <option value="COMMERCIAL_BANK">COMMERCIAL BANKS</option>
            <option value="GOVERNMENT_AGENCY">GOVERNMENT AGENCIES</option>
            <option value="TRAINING_PROVIDER">TRAINING PROVIDERS</option>
          </select>
        </div>
      </div>

      {/* Main Split Grid: Left Account List, Right Detailed Profile Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Account Selection List */}
        <div className={`p-4 rounded border space-y-2 max-h-[600px] overflow-y-auto ${
          darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'
        }`}>
          <div className="text-[10px] text-neutral-500 uppercase tracking-widest pb-2 border-b border-neutral-200 dark:border-neutral-800">
            ACCOUNT REGISTRY ({filteredAccounts.length})
          </div>

          {filteredAccounts.map(acc => {
            const isSelected = acc.id === selectedAccount.id;
            const totalBalance = acc.balances.unrestrictedCBDC + 
              Object.values(acc.balances.tokenisedDeposits).reduce((a, b) => a + b, 0) + 
              acc.balances.stablecoins + acc.balances.pbmRestricted;

            return (
              <button
                key={acc.id}
                onClick={() => setSelectedAccId(acc.id)}
                className={`w-full p-3 rounded border text-left transition-all space-y-1 ${
                  isSelected
                    ? 'bg-[#C8102E] text-white border-[#C8102E]'
                    : darkMode
                    ? 'bg-neutral-900/50 border-neutral-800 hover:bg-neutral-800/80'
                    : 'bg-neutral-50 border-neutral-200 hover:bg-neutral-100'
                }`}
              >
                <div className="flex items-center justify-between font-bold">
                  <span className="truncate max-w-[170px]">{acc.entityName}</span>
                  <span className="text-[10px] opacity-80">{acc.entityType}</span>
                </div>
                <div className="flex items-center justify-between text-[11px] opacity-90">
                  <span>Balance: S$ {totalBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                  <span className={`px-1 py-0.2 rounded text-[9px] font-bold ${
                    isSelected ? 'bg-white/20 text-white' : 'bg-emerald-500/20 text-emerald-600 dark:text-emerald-400'
                  }`}>
                    {acc.riskStatus}
                  </span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Right Column (2 cols): Account Inspector & Actions */}
        <div className="lg:col-span-2 space-y-6">
          {/* Identity & Session Header */}
          <div className={`p-4 rounded border ${darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'}`}>
            <div className="flex flex-wrap items-center justify-between gap-4 pb-3 mb-4 border-b border-neutral-200 dark:border-neutral-800">
              <div>
                <h3 className="text-base font-bold flex items-center gap-2">
                  <Wallet className="w-5 h-5 text-[#C8102E]" />
                  {selectedAccount.entityName}
                </h3>
                <span className="text-[10px] text-neutral-500 font-mono">ACCOUNT ID: {selectedAccount.id}</span>
              </div>

              <button
                onClick={() => { setTransferResult(null); setShowTransferModal(true); }}
                className="px-3 py-1.5 rounded bg-[#C8102E] text-white font-bold hover:bg-[#a00c24] flex items-center gap-1.5"
              >
                <Send className="w-3.5 h-3.5" />
                <span>SIMULATE TRANSFER FROM THIS WALLET</span>
              </button>
            </div>

            {/* Balances Breakdown Cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div className="p-3 rounded border bg-neutral-50 dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800">
                <span className="text-neutral-500 text-[10px]">RETAIL CBDC</span>
                <div className="text-sm font-bold mt-1 text-emerald-600 dark:text-emerald-400">
                  S$ {selectedAccount.balances.unrestrictedCBDC.toFixed(2)}
                </div>
              </div>

              <div className="p-3 rounded border bg-neutral-50 dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800">
                <span className="text-neutral-500 text-[10px]">TOKENISED DEPOSITS</span>
                <div className="text-sm font-bold mt-1 text-sky-600 dark:text-sky-400">
                  S$ {Object.values(selectedAccount.balances.tokenisedDeposits).reduce((a, b) => a + b, 0).toFixed(2)}
                </div>
              </div>

              <div className="p-3 rounded border bg-neutral-50 dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800">
                <span className="text-neutral-500 text-[10px]">STABLECOINS</span>
                <div className="text-sm font-bold mt-1">
                  S$ {selectedAccount.balances.stablecoins.toFixed(2)}
                </div>
              </div>

              <div className="p-3 rounded border bg-neutral-50 dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800">
                <span className="text-neutral-500 text-[10px]">PBM RESTRICTED VALUE</span>
                <div className="text-sm font-bold mt-1 text-[#7A5C90] dark:text-[#9370DB]">
                  S$ {selectedAccount.balances.pbmRestricted.toFixed(2)}
                </div>
              </div>
            </div>

            {/* Device & Security Meta */}
            <div className="mt-4 pt-3 border-t border-neutral-200 dark:border-neutral-800 flex flex-wrap items-center justify-between text-[11px] text-neutral-500">
              <div className="flex items-center gap-2">
                <Smartphone className="w-3.5 h-3.5" />
                <span>DEVICE: {selectedAccount.deviceSession.deviceId} ({selectedAccount.deviceSession.ipLocation})</span>
              </div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                <span>AUTH: {selectedAccount.deviceSession.authMethod}</span>
              </div>
            </div>
          </div>

          {/* Transaction History for this Wallet */}
          <div className={`p-4 rounded border ${darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'}`}>
            <h4 className="font-bold text-xs uppercase mb-3 pb-2 border-b border-neutral-200 dark:border-neutral-800 text-neutral-500">
              LEDGER AUDIT TRAIL FOR {selectedAccount.entityName} ({accountTransactions.length} RECORDED)
            </h4>

            <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
              {accountTransactions.length === 0 ? (
                <div className="text-center py-6 text-neutral-500">No transaction activity recorded for this entity yet.</div>
              ) : (
                accountTransactions.map(tx => {
                  const isOutgoing = tx.payerId === selectedAccount.id;
                  return (
                    <div key={tx.id} className="p-2.5 rounded border bg-neutral-50 dark:bg-neutral-900/60 border-neutral-200 dark:border-neutral-800 flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        {isOutgoing ? (
                          <ArrowUpRight className="w-4 h-4 text-red-500" />
                        ) : (
                          <ArrowDownRight className="w-4 h-4 text-emerald-500" />
                        )}
                        <div>
                          <div className="font-semibold text-neutral-800 dark:text-neutral-200">
                            {isOutgoing ? `To: ${tx.payeeName}` : `From: ${tx.payerName}`}
                          </div>
                          <div className="text-[10px] text-neutral-500">
                            Channel: {tx.paymentChannel} | Type: {tx.instrumentType}
                          </div>
                        </div>
                      </div>

                      <div className="text-right font-mono">
                        <div className={`font-bold ${isOutgoing ? 'text-red-500' : 'text-emerald-500'}`}>
                          {isOutgoing ? '-' : '+'} S$ {tx.amount.toFixed(2)}
                        </div>
                        <div className="text-[9px] text-neutral-400">{new Date(tx.timestamp).toLocaleTimeString()}</div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Transfer Simulation Modal */}
      {showTransferModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className={`w-full max-w-lg p-6 rounded-lg border shadow-xl font-mono text-xs space-y-4 ${
            darkMode ? 'bg-[#1A1A1E] border-neutral-700 text-neutral-100' : 'bg-white border-neutral-300 text-neutral-900'
          }`}>
            <div className="flex items-center justify-between border-b pb-3">
              <span className="font-bold text-sm text-[#C8102E] flex items-center gap-2">
                <Send className="w-4 h-4" />
                TRANSFER SIMULATOR
              </span>
              <button onClick={() => setShowTransferModal(false)} className="text-neutral-400 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleSendTransfer} className="space-y-3">
              <div>
                <label className="block text-neutral-500 mb-1">PAYER (SENDER):</label>
                <input
                  type="text"
                  disabled
                  value={`${selectedAccount.entityName} (Available: S$ ${selectedAccount.balances.unrestrictedCBDC.toFixed(2)})`}
                  className="w-full p-2 rounded border bg-neutral-100 dark:bg-neutral-800 text-neutral-400"
                />
              </div>

              <div>
                <label className="block text-neutral-500 mb-1">PAYEE (RECIPIENT):</label>
                <select
                  value={transferPayeeId}
                  onChange={(e) => setTransferPayeeId(e.target.value)}
                  className="w-full p-2 rounded border bg-neutral-50 dark:bg-neutral-900 border-neutral-300 dark:border-neutral-700"
                >
                  {accounts.filter(a => a.id !== selectedAccount.id).map(a => (
                    <option key={a.id} value={a.id}>{a.entityName} ({a.entityType})</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-neutral-500 mb-1">AMOUNT (SGD):</label>
                  <input
                    type="number"
                    step="0.50"
                    value={transferAmount}
                    onChange={(e) => setTransferAmount(Number(e.target.value))}
                    className="w-full p-2 rounded border bg-neutral-50 dark:bg-neutral-900 border-neutral-300 dark:border-neutral-700 font-bold"
                  />
                </div>

                <div>
                  <label className="block text-neutral-500 mb-1">RAIL INSTRUMENT:</label>
                  <select
                    value={transferInstrument}
                    onChange={(e) => setTransferInstrument(e.target.value as any)}
                    className="w-full p-2 rounded border bg-neutral-50 dark:bg-neutral-900 border-neutral-300 dark:border-neutral-700"
                  >
                    <option value="CBDC_RETAIL">Retail CBDC</option>
                    <option value="TOKENISED_DEPOSIT">Tokenised Commercial Deposit</option>
                    <option value="REGULATED_STABLECOIN">Regulated Stablecoin</option>
                  </select>
                </div>
              </div>

              {transferResult && (
                <div className={`p-3 rounded border ${
                  transferResult.status === 'SETTLED' ? 'bg-emerald-500/10 border-emerald-500 text-emerald-600 dark:text-emerald-400' : 'bg-red-500/10 border-red-500 text-red-600 dark:text-red-400'
                }`}>
                  <div className="font-bold">Result: {transferResult.status} ({transferResult.settlementStatus})</div>
                  <p className="text-[11px] text-neutral-400 mt-1">{transferResult.policyResult.details || transferResult.failureReason}</p>
                </div>
              )}

              <div className="flex items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowTransferModal(false)}
                  className="w-1/2 py-2 rounded border border-neutral-300 dark:border-neutral-700 hover:bg-neutral-100 dark:hover:bg-neutral-800"
                >
                  CLOSE
                </button>
                <button
                  type="submit"
                  className="w-1/2 py-2 rounded bg-[#C8102E] text-white font-bold hover:bg-[#a00c24]"
                >
                  EXECUTE TRANSACTION
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
