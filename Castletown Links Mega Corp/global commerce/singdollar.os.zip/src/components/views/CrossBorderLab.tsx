/**
 * SINGDOLLAR.OS — 07. Cross-Border Digital-Money Laboratory
 */

import React, { useState } from 'react';
import { simulationEngine } from '../../simulation/engine';
import { CrossBorderLeg } from '../../types';
import { Globe, ArrowRightLeft, ShieldCheck, RefreshCw, Layers } from 'lucide-react';

interface CrossBorderLabProps {
  crossBorderLegs: CrossBorderLeg[];
  darkMode: boolean;
}

export const CrossBorderLab: React.FC<CrossBorderLabProps> = ({ crossBorderLegs, darkMode }) => {
  const [targetCurrency, setTargetCurrency] = useState<'USD' | 'EUR' | 'JPY' | 'CNY' | 'GBP'>('JPY');
  const [sgdAmount, setSgdAmount] = useState<number>(100000);
  const [payerName, setPayerName] = useState<string>('TechCraft Solutions SG');
  const [payeeName, setPayeeName] = useState<string>('Tokyo Micro Components Inc.');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [lastLeg, setLastLeg] = useState<CrossBorderLeg | null>(null);

  // Synthetic FX Rates relative to SGD 1.00
  const fxRates: Record<string, number> = {
    USD: 0.76,
    EUR: 0.69,
    JPY: 114.50,
    CNY: 5.42,
    GBP: 0.58,
  };

  const currentFxRate = fxRates[targetCurrency];
  const convertedAmount = sgdAmount * currentFxRate;

  const handleExecutePvP = () => {
    setIsProcessing(true);
    setTimeout(() => {
      const leg = simulationEngine.executeCrossBorderPvP({
        sourceCurrency: 'SGD',
        targetCurrency,
        sourceAmount: sgdAmount,
        fxRate: currentFxRate,
        payerName,
        payeeName,
      });
      setLastLeg(leg);
      setIsProcessing(false);
    }, 700);
  };

  return (
    <div className="space-y-6 font-mono text-xs">
      {/* Top Banner */}
      <div className={`p-4 rounded border ${darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'}`}>
        <div className="flex flex-wrap items-center justify-between gap-4 pb-3 border-b border-neutral-200 dark:border-neutral-800">
          <div className="flex items-center gap-2">
            <Globe className="w-5 h-5 text-[#C8102E]" />
            <div>
              <h2 className="text-sm font-bold uppercase">CROSS-BORDER MULTI-CURRENCY SETTLEMENT LABORATORY</h2>
              <p className="text-[11px] text-neutral-500">
                Payment-versus-Payment (PvP) Atomic Settlement & Liquidity Escrow Corridor
              </p>
            </div>
          </div>
          <span className="px-2 py-0.5 text-[10px] rounded bg-[#7A5C90] text-white font-bold">
            SYNTHETIC FX CORRIDOR
          </span>
        </div>

        {/* Live Synthetic FX Ticker Bar */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mt-4 text-center">
          {Object.entries(fxRates).map(([curr, rate]) => (
            <div key={curr} className="p-2 rounded bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800">
              <span className="text-neutral-500 text-[10px]">1 SGD = </span>
              <span className="font-bold text-emerald-500">{rate} {curr}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Main Form & PvP Lifecycle Comparison */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Form: Initiate PvP Corridor Transfer */}
        <div className={`p-4 rounded border space-y-4 ${
          darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'
        }`}>
          <h3 className="text-xs font-bold uppercase text-neutral-500 border-b pb-2 dark:border-neutral-800 flex items-center gap-2">
            <ArrowRightLeft className="w-4 h-4 text-[#C8102E]" />
            INITIATE ATOMIC PvP CROSS-BORDER CORRIDOR
          </h3>

          <div>
            <label className="block text-neutral-500 mb-1">SINGAPORE SENDER (PAYER):</label>
            <input
              type="text"
              value={payerName}
              onChange={(e) => setPayerName(e.target.value)}
              className="w-full p-2 rounded border bg-neutral-50 dark:bg-neutral-900 border-neutral-300 dark:border-neutral-700 font-bold"
            />
          </div>

          <div>
            <label className="block text-neutral-500 mb-1">OVERSEAS COUNTERPARTY (PAYEE):</label>
            <input
              type="text"
              value={payeeName}
              onChange={(e) => setPayeeName(e.target.value)}
              className="w-full p-2 rounded border bg-neutral-50 dark:bg-neutral-900 border-neutral-300 dark:border-neutral-700 font-bold"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-neutral-500 mb-1">SOURCE AMOUNT (SGD):</label>
              <input
                type="number"
                step="5000"
                value={sgdAmount}
                onChange={(e) => setSgdAmount(Number(e.target.value))}
                className="w-full p-2 rounded border bg-neutral-50 dark:bg-neutral-900 border-neutral-300 dark:border-neutral-700 font-bold text-sm"
              />
            </div>

            <div>
              <label className="block text-neutral-500 mb-1">TARGET CURRENCY:</label>
              <select
                value={targetCurrency}
                onChange={(e) => setTargetCurrency(e.target.value as any)}
                className="w-full p-2 rounded border bg-neutral-50 dark:bg-neutral-900 border-neutral-300 dark:border-neutral-700 font-bold text-sm"
              >
                <option value="JPY">JPY (Japanese Yen)</option>
                <option value="USD">USD (US Dollar)</option>
                <option value="EUR">EUR (Euro)</option>
                <option value="CNY">CNY (Chinese Yuan)</option>
                <option value="GBP">GBP (British Pound)</option>
              </select>
            </div>
          </div>

          <div className="p-3 bg-neutral-50 dark:bg-neutral-900 rounded border border-neutral-200 dark:border-neutral-800 space-y-1">
            <div className="flex justify-between text-[11px]">
              <span className="text-neutral-500">Calculated Payout:</span>
              <span className="font-bold text-emerald-500">{convertedAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })} {targetCurrency}</span>
            </div>
            <div className="flex justify-between text-[10px] text-neutral-400">
              <span>Applied Rate: 1 SGD = {currentFxRate} {targetCurrency}</span>
              <span>Settlement Mode: ATOMIC_PVP</span>
            </div>
          </div>

          <button
            onClick={handleExecutePvP}
            disabled={isProcessing}
            className="w-full py-3 rounded bg-[#C8102E] text-white font-bold hover:bg-[#a00c24] transition flex items-center justify-center gap-2"
          >
            {isProcessing ? (
              <span>LOCKING ESCROW LEGS & EXECUTING PvP...</span>
            ) : (
              <span>EXECUTE ATOMIC PvP SETTLEMENT</span>
            )}
          </button>
        </div>

        {/* Right Column: Comparative Analysis & PvP Corridor Execution Proof */}
        <div className="space-y-6">
          {/* Active Leg Proof Box */}
          <div className={`p-4 rounded border ${darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'}`}>
            <h4 className="text-xs font-bold uppercase text-neutral-500 border-b pb-2 mb-3 dark:border-neutral-800 flex justify-between">
              <span>ATOMIC PvP ESCROW EXECUTION PROOF</span>
              <ShieldCheck className="w-4 h-4 text-emerald-500" />
            </h4>

            {!lastLeg ? (
              <div className="text-center py-10 text-neutral-500">
                Execute a cross-border transaction to view simultaneous dual-leg escrow locking and atomic finality verification.
              </div>
            ) : (
              <div className="space-y-3">
                <div className="p-3 bg-emerald-500/10 border border-emerald-500/40 rounded space-y-1.5 text-emerald-700 dark:text-emerald-300">
                  <div className="font-bold flex justify-between">
                    <span>LEG STATUS: {lastLeg.status}</span>
                    <span>{lastLeg.id}</span>
                  </div>
                  <div className="text-xs">
                    SGD $${lastLeg.sourceAmount.toLocaleString()} → {lastLeg.targetCurrency} {lastLeg.targetAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </div>
                  <div className="text-[10px] text-neutral-400">Escrow Ref: {lastLeg.escrowRef}</div>
                </div>
              </div>
            )}
          </div>

          {/* Sequential vs Atomic PvP Comparison */}
          <div className={`p-4 rounded border ${darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'}`}>
            <h4 className="text-xs font-bold uppercase text-neutral-500 border-b pb-2 mb-3 dark:border-neutral-800">
              SEQUENTIAL SETTLEMENT VS ATOMIC PvP COMPARISON
            </h4>

            <div className="grid grid-cols-2 gap-3 text-[11px]">
              <div className="p-3 bg-red-500/10 border border-red-500/30 rounded space-y-1">
                <div className="font-bold text-red-500">LEGACY SEQUENTIAL</div>
                <div className="text-[10px] text-neutral-400">
                  • High Herstatt counterparty risk<br />
                  • T+2 settlement lag<br />
                  • FX pre-funding capital drag
                </div>
              </div>

              <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded space-y-1">
                <div className="font-bold text-emerald-500">SIMULATED ATOMIC PvP</div>
                <div className="text-[10px] text-neutral-400">
                  • Zero principal risk (Dual lock)<br />
                  • Sub-second atomic delivery<br />
                  • Optimized liquidity utilization
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
