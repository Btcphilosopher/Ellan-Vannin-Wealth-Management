/**
 * SINGDOLLAR.OS — 02. Digital-Money Issuance Desk
 */

import React, { useState } from 'react';
import { simulationEngine } from '../../simulation/engine';
import { Account, AuditEvent, InstrumentType } from '../../types';
import { Banknote, ShieldCheck, ArrowRightLeft, AlertTriangle, FileText, Lock } from 'lucide-react';

interface IssuanceDeskProps {
  accounts: Account[];
  auditLogs: AuditEvent[];
  darkMode: boolean;
}

export const IssuanceDesk: React.FC<IssuanceDeskProps> = ({ accounts, auditLogs, darkMode }) => {
  const [operation, setOperation] = useState<'ISSUE' | 'REDEEM_DESTROY' | 'ALLOCATE_BANK'>('ISSUE');
  const [instrumentType, setInstrumentType] = useState<InstrumentType>('CBDC_RETAIL');
  const [amount, setAmount] = useState<number>(10000000);
  const [targetAccountId, setTargetAccountId] = useState<string>('acc-dbs-reserve');
  const [reasonCode, setReasonCode] = useState<string>('ANNUAL_LIQUIDITY_BUFFER_2026');
  
  // Four-eyes modal state
  const [showModal, setShowModal] = useState<boolean>(false);
  const [officerOne, setOfficerOne] = useState<string>('MAS_CHIEF_MONETARY_OFFICER');
  const [officerTwoPass, setOfficerTwoPass] = useState<string>('');
  const [feedback, setFeedback] = useState<{ success: boolean; message: string } | null>(null);

  const masAccount = accounts.find(a => a.id === 'acc-mas-issuance');
  const bankAccounts = accounts.filter(a => a.entityType === 'COMMERCIAL_BANK' || a.entityType === 'GOVERNMENT_AGENCY');

  const handleInitiate = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    setShowModal(true);
  };

  const handleConfirmFourEyes = () => {
    if (!officerTwoPass) {
      setFeedback({ success: false, message: 'Secondary Officer PIN/Passkey required.' });
      return;
    }

    const res = simulationEngine.executeCentralBankOperation({
      operation,
      instrumentType,
      amount,
      targetAccountId,
      reasonCode,
      approvedByFourEyes: true,
    });

    setFeedback(res);
    if (res.success) {
      setShowModal(false);
      setOfficerTwoPass('');
    }
  };

  return (
    <div className="space-y-6">
      {/* Central Bank Balance Sheet Overview Header */}
      <div className={`p-4 rounded border font-mono ${darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'}`}>
        <div className="flex flex-wrap items-center justify-between gap-4 pb-3 mb-4 border-b border-neutral-200 dark:border-neutral-800">
          <div>
            <h2 className="text-sm font-bold flex items-center gap-2">
              <Banknote className="w-4 h-4 text-[#C8102E]" />
              CENTRAL BANK MONETARY BALANCE SHEET (SIMULATED MAS)
            </h2>
            <p className="text-xs text-neutral-500">
              Authority to Mint, Burn, and Allocate Digital Singapore Dollar Liabilities
            </p>
          </div>
          <span className="px-2.5 py-1 text-xs rounded font-bold bg-[#C8102E] text-white">
            FOUR-EYES PROTOCOL ACTIVE
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="p-3 bg-neutral-50 dark:bg-neutral-900 rounded border border-neutral-200 dark:border-neutral-800">
            <span className="text-neutral-500">Retail CBDC Supply (Direct Claim):</span>
            <div className="text-lg font-bold text-emerald-600 dark:text-emerald-400 mt-1">
              S$ {((masAccount?.balances.unrestrictedCBDC || 0) / 1e6).toFixed(2)} Million
            </div>
          </div>
          <div className="p-3 bg-neutral-50 dark:bg-neutral-900 rounded border border-neutral-200 dark:border-neutral-800">
            <span className="text-neutral-500">Wholesale Settlement Reserve:</span>
            <div className="text-lg font-bold text-sky-600 dark:text-sky-400 mt-1">
              S$ {((masAccount?.balances.wholesaleCBDC || 0) / 1e6).toFixed(2)} Million
            </div>
          </div>
          <div className="p-3 bg-neutral-50 dark:bg-neutral-900 rounded border border-neutral-200 dark:border-neutral-800">
            <span className="text-neutral-500">Legal Status Disclaimer:</span>
            <div className="text-[11px] text-neutral-400 mt-1">
              Simulated Central Bank Money — Fictional Research Unit
            </div>
          </div>
        </div>
      </div>

      {/* Main Operations & Audit Log Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 font-mono text-xs">
        {/* Left Form: Issuance Operations Control */}
        <div className={`p-4 rounded border ${darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'}`}>
          <h3 className="text-sm font-bold pb-2 mb-4 border-b border-neutral-200 dark:border-neutral-800 uppercase flex items-center gap-2">
            <ArrowRightLeft className="w-4 h-4 text-[#7A5C90]" />
            MINT / ALLOCATE / DESTROY CONTROLS
          </h3>

          <form onSubmit={handleInitiate} className="space-y-4">
            <div>
              <label className="block text-neutral-500 mb-1">OPERATION TYPE:</label>
              <select
                value={operation}
                onChange={(e) => setOperation(e.target.value as any)}
                className="w-full p-2 rounded border bg-neutral-50 dark:bg-neutral-900 border-neutral-300 dark:border-neutral-700"
              >
                <option value="ISSUE">MINT NEW CENTRAL BANK MONEY (ISSUE)</option>
                <option value="ALLOCATE_BANK">ALLOCATE RESERVES TO COMMERCIAL BANK / GOV</option>
                <option value="REDEEM_DESTROY">REDEEM & DESTROY (REDUCE MONETARY BASE)</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-neutral-500 mb-1">INSTRUMENT TYPE:</label>
                <select
                  value={instrumentType}
                  onChange={(e) => setInstrumentType(e.target.value as any)}
                  className="w-full p-2 rounded border bg-neutral-50 dark:bg-neutral-900 border-neutral-300 dark:border-neutral-700"
                >
                  <option value="CBDC_RETAIL">Retail CBDC (Direct Liability)</option>
                  <option value="CBDC_WHOLESALE">Wholesale Settlement SGD</option>
                </select>
              </div>

              <div>
                <label className="block text-neutral-500 mb-1">AMOUNT (SGD):</label>
                <input
                  type="number"
                  step="100000"
                  value={amount}
                  onChange={(e) => setAmount(Number(e.target.value))}
                  className="w-full p-2 rounded border bg-neutral-50 dark:bg-neutral-900 border-neutral-300 dark:border-neutral-700 font-bold"
                />
              </div>
            </div>

            {operation === 'ALLOCATE_BANK' && (
              <div>
                <label className="block text-neutral-500 mb-1">RECIPIENT INSTITUTION ACCOUNT:</label>
                <select
                  value={targetAccountId}
                  onChange={(e) => setTargetAccountId(e.target.value)}
                  className="w-full p-2 rounded border bg-neutral-50 dark:bg-neutral-900 border-neutral-300 dark:border-neutral-700"
                >
                  {bankAccounts.map(acc => (
                    <option key={acc.id} value={acc.id}>
                      {acc.entityName} ({acc.accountType})
                    </option>
                  ))}
                </select>
              </div>
            )}

            <div>
              <label className="block text-neutral-500 mb-1">REASON / REGULATORY POLICY CODE:</label>
              <input
                type="text"
                value={reasonCode}
                onChange={(e) => setReasonCode(e.target.value)}
                className="w-full p-2 rounded border bg-neutral-50 dark:bg-neutral-900 border-neutral-300 dark:border-neutral-700"
              />
            </div>

            {feedback && (
              <div className={`p-3 rounded border ${feedback.success ? 'bg-emerald-500/10 border-emerald-500 text-emerald-600 dark:text-emerald-400' : 'bg-red-500/10 border-red-500 text-red-600 dark:text-red-400'}`}>
                {feedback.message}
              </div>
            )}

            <button
              type="submit"
              className="w-full py-2.5 rounded bg-[#C8102E] text-white font-bold hover:bg-[#a00c24] transition flex items-center justify-center gap-2"
            >
              <Lock className="w-4 h-4" />
              <span>STAGE OPERATION & TRIGGER FOUR-EYES APPROVAL</span>
            </button>
          </form>
        </div>

        {/* Right Column: Issuance Timeline Audit Stream */}
        <div className={`p-4 rounded border ${darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'}`}>
          <h3 className="text-sm font-bold pb-2 mb-4 border-b border-neutral-200 dark:border-neutral-800 uppercase flex items-center gap-2">
            <FileText className="w-4 h-4 text-emerald-500" />
            IMMUTABLE ISSUANCE TIMELINE AUDIT STREAM
          </h3>

          <div className="space-y-3 max-h-[380px] overflow-y-auto pr-1">
            {auditLogs
              .filter(l => l.eventType === 'MONEY_ISSUED' || l.eventType === 'MONEY_DESTROYED')
              .map(log => (
                <div key={log.id} className="p-3 rounded border bg-neutral-50 dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800 space-y-1">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-bold text-[#C8102E]">{log.eventType}</span>
                    <span className="text-neutral-400">{new Date(log.timestamp).toLocaleTimeString()}</span>
                  </div>
                  <div className="text-neutral-300 font-semibold">{log.afterSummary}</div>
                  <div className="text-[10px] text-neutral-500">Reason: {(log.details as any)?.reason || 'N/A'}</div>
                </div>
              ))}
          </div>
        </div>
      </div>

      {/* Four-Eyes Approval Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className={`w-full max-w-md p-6 rounded-lg border shadow-xl font-mono text-xs space-y-4 ${
            darkMode ? 'bg-[#1A1A1E] border-neutral-700 text-neutral-100' : 'bg-white border-neutral-300 text-neutral-900'
          }`}>
            <div className="flex items-center justify-between border-b pb-3">
              <span className="font-bold text-sm text-[#C8102E] flex items-center gap-2">
                <ShieldCheck className="w-5 h-5" />
                FOUR-EYES DUAL CONTROL CONFIRMATION
              </span>
              <button onClick={() => setShowModal(false)} className="text-neutral-400 hover:text-white">✕</button>
            </div>

            <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded text-amber-600 dark:text-amber-400 space-y-1">
              <div className="font-bold flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4" />
                CRITICAL MONETARY ACTION
              </div>
              <p className="text-[11px]">
                Operation: {operation} | Amount: SGD ${amount.toLocaleString()} ({instrumentType})
              </p>
            </div>

            <div>
              <label className="block text-neutral-500 mb-1">PRIMARY OFFICER SIGNATURE:</label>
              <input
                type="text"
                disabled
                value={officerOne}
                className="w-full p-2 rounded border bg-neutral-100 dark:bg-neutral-800 text-neutral-400"
              />
            </div>

            <div>
              <label className="block text-neutral-500 mb-1">SECONDARY AUTHORIZING OFFICER PIN / AUTH:</label>
              <input
                type="password"
                placeholder="Enter 6-digit Security PIN"
                value={officerTwoPass}
                onChange={(e) => setOfficerTwoPass(e.target.value)}
                className="w-full p-2 rounded border bg-neutral-50 dark:bg-neutral-900 border-neutral-300 dark:border-neutral-700"
              />
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={() => setShowModal(false)}
                className="w-1/2 py-2 rounded border border-neutral-300 dark:border-neutral-700 hover:bg-neutral-100 dark:hover:bg-neutral-800"
              >
                CANCEL
              </button>
              <button
                onClick={handleConfirmFourEyes}
                className="w-1/2 py-2 rounded bg-[#C8102E] text-white font-bold hover:bg-[#a00c24]"
              >
                AUTHORISE & EXECUTE
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
