/**
 * SINGDOLLAR.OS — 04. Merchant Payment Terminal Simulator
 */

import React, { useState } from 'react';
import { simulationEngine } from '../../simulation/engine';
import { Account, PBMConfig, Transaction, SpendingCategory } from '../../types';
import { Store, QrCode, Wifi, CheckCircle2, XCircle, AlertCircle, RefreshCcw, ShieldCheck, DollarSign } from 'lucide-react';

interface MerchantTerminalProps {
  accounts: Account[];
  pbms: PBMConfig[];
  darkMode: boolean;
}

export const MerchantTerminal: React.FC<MerchantTerminalProps> = ({ accounts, pbms, darkMode }) => {
  const merchants = accounts.filter(a => a.entityType === 'MERCHANT' || a.entityType === 'TRAINING_PROVIDER');
  const residents = accounts.filter(a => a.entityType === 'RESIDENT');

  const [selectedMerchantId, setSelectedMerchantId] = useState<string>(merchants[0]?.id || '');
  const [selectedResidentId, setSelectedResidentId] = useState<string>(residents[0]?.id || '');
  const [amount, setAmount] = useState<number>(42.50);
  const [category, setCategory] = useState<SpendingCategory>('GROCERIES_HOUSEHOLD');
  const [paymentChannel, setPaymentChannel] = useState<'QR_SGQR' | 'NFC_CONTACTLESS'>('QR_SGQR');
  const [usePBM, setUsePBM] = useState<boolean>(true);
  const [selectedPBMId, setSelectedPBMId] = useState<string>(pbms[0]?.id || '');

  // Active transaction lifecycle result state
  const [activeTx, setActiveTx] = useState<Transaction | null>(null);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [offlineMode, setOfflineMode] = useState<boolean>(false);
  const [refundMessage, setRefundMessage] = useState<string | null>(null);

  const selectedMerchant = merchants.find(m => m.id === selectedMerchantId);
  const selectedResident = residents.find(r => r.id === selectedResidentId);
  const selectedPBM = pbms.find(p => p.id === selectedPBMId);

  const handleCheckout = () => {
    setIsProcessing(true);
    setRefundMessage(null);

    setTimeout(() => {
      const res = simulationEngine.executeTransaction({
        payerId: selectedResidentId,
        payeeId: selectedMerchantId,
        amount,
        instrumentType: usePBM ? 'PBM_WRAPPER' : 'CBDC_RETAIL',
        pbmId: usePBM ? selectedPBMId : undefined,
        category,
        paymentChannel,
      });

      setActiveTx(res);
      setIsProcessing(false);
    }, 600);
  };

  const handleRefundCurrent = () => {
    if (!activeTx || activeTx.status !== 'SETTLED') return;
    const res = simulationEngine.executeRefund(activeTx.id, 'Customer merchant POS return request');
    setRefundMessage(res.message);
    if (res.success && res.tx) {
      setActiveTx(res.tx);
    }
  };

  return (
    <div className="space-y-6 font-mono text-xs">
      {/* Top Header Terminal Controls */}
      <div className={`p-4 rounded border ${darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'}`}>
        <div className="flex flex-wrap items-center justify-between gap-4 pb-3 border-b border-neutral-200 dark:border-neutral-800">
          <div className="flex items-center gap-2">
            <Store className="w-5 h-5 text-[#C8102E]" />
            <div>
              <h2 className="text-sm font-bold uppercase">POINT-OF-SALE (POS) CHECKOUT TERMINAL SIMULATOR</h2>
              <p className="text-[11px] text-neutral-500">
                PBM Protocol Wrapper Verification & Instant Settlement Rail Engine
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setOfflineMode(!offlineMode)}
              className={`px-3 py-1.5 rounded font-bold transition flex items-center gap-1.5 ${
                offlineMode
                  ? 'bg-amber-500 text-black'
                  : 'bg-neutral-200 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300'
              }`}
            >
              <Wifi className="w-3.5 h-3.5" />
              <span>{offlineMode ? 'OFFLINE QUEUE MODE (LIMIT $100)' : 'ONLINE REAL-TIME SETTLED'}</span>
            </button>
          </div>
        </div>

        {/* Configuration Bar */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-4">
          <div>
            <label className="block text-neutral-500 mb-1">MERCHANT TERMINAL:</label>
            <select
              value={selectedMerchantId}
              onChange={(e) => setSelectedMerchantId(e.target.value)}
              className="w-full p-2 rounded border bg-neutral-50 dark:bg-neutral-900 border-neutral-300 dark:border-neutral-700"
            >
              {merchants.map(m => (
                <option key={m.id} value={m.id}>{m.entityName}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-neutral-500 mb-1">CUSTOMER (SHOPPER):</label>
            <select
              value={selectedResidentId}
              onChange={(e) => setSelectedResidentId(e.target.value)}
              className="w-full p-2 rounded border bg-neutral-50 dark:bg-neutral-900 border-neutral-300 dark:border-neutral-700"
            >
              {residents.map(r => (
                <option key={r.id} value={r.id}>{r.entityName}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-neutral-500 mb-1">CHECKOUT AMOUNT (SGD):</label>
            <input
              type="number"
              step="1.00"
              value={amount}
              onChange={(e) => setAmount(Number(e.target.value))}
              className="w-full p-2 rounded border bg-neutral-50 dark:bg-neutral-900 border-neutral-300 dark:border-neutral-700 font-bold text-sm"
            />
          </div>

          <div>
            <label className="block text-neutral-500 mb-1">ITEM SPENDING CATEGORY:</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as any)}
              className="w-full p-2 rounded border bg-neutral-50 dark:bg-neutral-900 border-neutral-300 dark:border-neutral-700"
            >
              <option value="GROCERIES_HOUSEHOLD">Groceries & Household</option>
              <option value="EDUCATION_TRAINING">Education & Courses</option>
              <option value="HAWKER_FOOD">Hawker Food</option>
              <option value="HEALTHCARE_MEDICAL">Healthcare</option>
              <option value="GENERAL_RETAIL">General Retail</option>
            </select>
          </div>
        </div>
      </div>

      {/* Main Terminal View: Payment Method Selection & Lifecycle Visualizer */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Column: POS Terminal Display & Trigger */}
        <div className={`p-4 rounded border space-y-4 ${
          darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'
        }`}>
          <div className="text-xs font-bold uppercase text-neutral-500 border-b pb-2 dark:border-neutral-800 flex justify-between">
            <span>PAYMENT INSTRUMENT SELECTION</span>
            <span className="text-emerald-500 font-bold">SGQR NETS READY</span>
          </div>

          <div className="space-y-3">
            <div className="flex items-center gap-4">
              <label className="flex items-center gap-2 cursor-pointer font-bold">
                <input
                  type="radio"
                  name="instrumentTypeChoice"
                  checked={usePBM}
                  onChange={() => setUsePBM(true)}
                  className="accent-[#C8102E]"
                />
                <span>ATTACH PURPOSE-BOUND MONEY (PBM VOUCHER)</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer text-neutral-400">
                <input
                  type="radio"
                  name="instrumentTypeChoice"
                  checked={!usePBM}
                  onChange={() => setUsePBM(false)}
                  className="accent-[#C8102E]"
                />
                <span>UNRESTRICTED RETAIL CBDC</span>
              </label>
            </div>

            {usePBM && (
              <div className="p-3 bg-purple-500/10 border border-purple-500/30 rounded space-y-2">
                <label className="block text-purple-600 dark:text-purple-400 font-bold">
                  SELECT PBM INSTRUMENT TO PRESENT:
                </label>
                <select
                  value={selectedPBMId}
                  onChange={(e) => setSelectedPBMId(e.target.value)}
                  className="w-full p-2 rounded border bg-neutral-50 dark:bg-neutral-900 border-neutral-300 dark:border-neutral-700 font-bold"
                >
                  {pbms.map(p => (
                    <option key={p.id} value={p.id}>
                      {p.name} (Bal: S$ {p.remainingBalance} | Status: {p.status})
                    </option>
                  ))}
                </select>

                {selectedPBM && (
                  <div className="text-[10px] text-neutral-400 space-y-1 pt-1 border-t border-purple-500/20">
                    <div>Valid To: {new Date(selectedPBM.validTo).toLocaleDateString()}</div>
                    <div>Permitted Categories: {selectedPBM.permittedCategories.join(', ')}</div>
                  </div>
                )}
              </div>
            )}

            {/* Payment Channel Toggle */}
            <div className="grid grid-cols-2 gap-3 pt-2">
              <button
                type="button"
                onClick={() => setPaymentChannel('QR_SGQR')}
                className={`p-3 rounded border flex items-center justify-center gap-2 font-bold transition ${
                  paymentChannel === 'QR_SGQR'
                    ? 'bg-[#C8102E] text-white border-[#C8102E]'
                    : 'bg-neutral-50 dark:bg-neutral-900 border-neutral-300 dark:border-neutral-700'
                }`}
              >
                <QrCode className="w-4 h-4" />
                <span>SGQR SCAN</span>
              </button>

              <button
                type="button"
                onClick={() => setPaymentChannel('NFC_CONTACTLESS')}
                className={`p-3 rounded border flex items-center justify-center gap-2 font-bold transition ${
                  paymentChannel === 'NFC_CONTACTLESS'
                    ? 'bg-[#C8102E] text-white border-[#C8102E]'
                    : 'bg-neutral-50 dark:bg-neutral-900 border-neutral-300 dark:border-neutral-700'
                }`}
              >
                <Wifi className="w-4 h-4" />
                <span>NFC TAP & PAY</span>
              </button>
            </div>

            <button
              onClick={handleCheckout}
              disabled={isProcessing}
              className="w-full py-3 rounded bg-[#C8102E] text-white font-bold text-sm hover:bg-[#a00c24] transition flex items-center justify-center gap-2 shadow-md"
            >
              {isProcessing ? (
                <span>EVALUATING PBM POLICY RULES...</span>
              ) : (
                <span>PRESENT & CHARGE S$ {amount.toFixed(2)} SGD</span>
              )}
            </button>
          </div>
        </div>

        {/* Right Column: Interactive Step-by-Step Payment Lifecycle Visualizer */}
        <div className={`p-4 rounded border ${darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'}`}>
          <h3 className="text-xs font-bold uppercase text-neutral-500 border-b pb-2 mb-4 dark:border-neutral-800 flex justify-between">
            <span>TRANSACTION LIFECYCLE TRACKER</span>
            {activeTx && (
              <span className={`font-bold ${activeTx.status === 'SETTLED' ? 'text-emerald-500' : 'text-red-500'}`}>
                STATUS: {activeTx.status}
              </span>
            )}
          </h3>

          {!activeTx ? (
            <div className="text-center py-12 text-neutral-500">
              Initiate a checkout charge above to inspect step-by-step policy verification and settlement finality.
            </div>
          ) : (
            <div className="space-y-4">
              {/* Lifecycle Steps Stream */}
              <div className="space-y-2">
                {activeTx.lifecycle.map((step, idx) => (
                  <div
                    key={idx}
                    className={`p-2.5 rounded border flex items-start gap-3 ${
                      step.status === 'PASSED'
                        ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-600 dark:text-emerald-400'
                        : 'bg-red-500/10 border-red-500/40 text-red-600 dark:text-red-400'
                    }`}
                  >
                    {step.status === 'PASSED' ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0 mt-0.5" />
                    ) : (
                      <XCircle className="w-4 h-4 text-red-500 flex-shrink-0 mt-0.5" />
                    )}
                    <div className="flex-1">
                      <div className="flex items-center justify-between font-bold text-[11px]">
                        <span>STEP {idx + 1}: {step.step}</span>
                        <span className="text-[9px] opacity-70">{new Date(step.timestamp).toLocaleTimeString()}</span>
                      </div>
                      <p className="text-[10px] opacity-90 mt-0.5">{step.detail}</p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Failure Reasons if failed */}
              {activeTx.status === 'FAILED' && (
                <div className="p-3 bg-red-500/10 border border-red-500/40 rounded text-red-600 dark:text-red-400 space-y-1">
                  <div className="font-bold flex items-center gap-1.5">
                    <AlertCircle className="w-4 h-4" />
                    FAILURE CODE: {activeTx.failureCode}
                  </div>
                  <p className="text-[11px]">{activeTx.failureReason}</p>
                </div>
              )}

              {/* Receipt & Refund Actions if settled */}
              {activeTx.status === 'SETTLED' && (
                <div className="p-3 bg-emerald-500/10 border border-emerald-500/40 rounded space-y-2 text-emerald-700 dark:text-emerald-300">
                  <div className="flex items-center justify-between font-bold">
                    <span className="flex items-center gap-1.5">
                      <ShieldCheck className="w-4 h-4" />
                      UNRESTRICTED SETTLEMENT RELEASED TO MERCHANT
                    </span>
                    <span>S$ {activeTx.amount.toFixed(2)}</span>
                  </div>
                  <p className="text-[10px] text-neutral-400">
                    Audit Ref: {activeTx.auditRef} | Finality Latency: {activeTx.settlementTimeMs}ms
                  </p>

                  <button
                    onClick={handleRefundCurrent}
                    className="mt-2 w-full py-1.5 rounded border border-emerald-500 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-500/20 font-bold text-[11px] flex items-center justify-center gap-1"
                  >
                    <RefreshCcw className="w-3.5 h-3.5" />
                    <span>ISSUE MERCHANT REFUND (REVERSED LEDGER)</span>
                  </button>
                </div>
              )}

              {refundMessage && (
                <div className="p-2.5 rounded bg-sky-500/10 border border-sky-500 text-sky-600 dark:text-sky-400 text-[11px] font-bold">
                  {refundMessage}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
