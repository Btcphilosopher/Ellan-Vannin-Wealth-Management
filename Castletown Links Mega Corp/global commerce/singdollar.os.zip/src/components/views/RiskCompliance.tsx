/**
 * SINGDOLLAR.OS — 08. Risk, Compliance & Safety Layer
 */

import React, { useState } from 'react';
import { simulationEngine } from '../../simulation/engine';
import { RiskFlag } from '../../types';
import { ShieldAlert, AlertTriangle, CheckCircle, XCircle, Search } from 'lucide-react';

interface RiskComplianceProps {
  riskFlags: RiskFlag[];
  darkMode: boolean;
}

export const RiskCompliance: React.FC<RiskComplianceProps> = ({ riskFlags, darkMode }) => {
  const [filterSeverity, setFilterSeverity] = useState<string>('ALL');

  const filteredFlags = riskFlags.filter(f => {
    if (filterSeverity === 'ALL') return true;
    return f.severity === filterSeverity;
  });

  const handleResolve = (flagId: string, action: 'APPROVED' | 'BLOCKED_CONFIRMED' | 'DISMISSED') => {
    simulationEngine.resolveRiskFlag(flagId, action);
  };

  return (
    <div className="space-y-6 font-mono text-xs">
      {/* Top Banner */}
      <div className={`p-4 rounded border ${darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'}`}>
        <div className="flex flex-wrap items-center justify-between gap-4 pb-3 border-b border-neutral-200 dark:border-neutral-800">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-[#C8102E]" />
            <div>
              <h2 className="text-sm font-bold uppercase">TRANSPARENT RULE-BASED RISK & COMPLIANCE ENGINE</h2>
              <p className="text-[11px] text-neutral-500">
                Velocity Monitors, Sanctions Screening Placeholder & Manual Review Review Queue
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-neutral-500 text-[11px]">SEVERITY FILTER:</span>
            <select
              value={filterSeverity}
              onChange={(e) => setFilterSeverity(e.target.value)}
              className="p-1.5 rounded border bg-neutral-50 dark:bg-neutral-900 border-neutral-300 dark:border-neutral-700 font-bold"
            >
              <option value="ALL">ALL SEVERITIES</option>
              <option value="HIGH">HIGH / CRITICAL</option>
              <option value="MEDIUM">MEDIUM</option>
              <option value="LOW">LOW</option>
            </select>
          </div>
        </div>
      </div>

      {/* Manual Review Queue List */}
      <div className={`p-4 rounded border ${darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'}`}>
        <h3 className="text-xs font-bold uppercase text-neutral-500 border-b pb-3 mb-4 dark:border-neutral-800 flex justify-between">
          <span>COMPLIANCE REVIEW QUEUE ({filteredFlags.length} INCIDENTS)</span>
          <span className="text-red-500 font-bold">SYNTHETIC MONITORING DATA ONLY</span>
        </h3>

        <div className="space-y-3">
          {filteredFlags.length === 0 ? (
            <div className="text-center py-12 text-neutral-500">No active compliance flags requiring review.</div>
          ) : (
            filteredFlags.map(flag => (
              <div
                key={flag.id}
                className="p-3.5 rounded border bg-neutral-50 dark:bg-neutral-900/80 border-neutral-200 dark:border-neutral-800 space-y-2"
              >
                <div className="flex flex-wrap items-center justify-between gap-2 font-bold text-xs">
                  <div className="flex items-center gap-2">
                    <span className={`px-2 py-0.5 rounded text-[10px] uppercase font-mono ${
                      flag.severity === 'HIGH' || flag.severity === 'CRITICAL' ? 'bg-red-500 text-white animate-pulse' : 'bg-amber-500/20 text-amber-600 dark:text-amber-400'
                    }`}>
                      {flag.severity} RISK
                    </span>
                    <span className="text-neutral-800 dark:text-neutral-200">{flag.payerName}</span>
                  </div>

                  <span className="text-emerald-600 dark:text-emerald-400">
                    S$ {flag.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </span>
                </div>

                <p className="text-[11px] text-neutral-600 dark:text-neutral-400 font-sans">
                  <strong className="font-mono text-red-500">Trigger [{flag.trigger}]:</strong> {flag.explainableReason}
                </p>

                <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-neutral-200 dark:border-neutral-800/60">
                  <div className="text-[10px] text-neutral-400">
                    Flag ID: {flag.id} | Timestamp: {new Date(flag.timestamp).toLocaleTimeString()}
                  </div>

                  {flag.status === 'PENDING_REVIEW' ? (
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleResolve(flag.id, 'APPROVED')}
                        className="px-2.5 py-1 rounded bg-emerald-600 text-white font-bold hover:bg-emerald-700 text-[10px]"
                      >
                        APPROVE & RELEASE
                      </button>
                      <button
                        onClick={() => handleResolve(flag.id, 'BLOCKED_CONFIRMED')}
                        className="px-2.5 py-1 rounded bg-red-600 text-white font-bold hover:bg-red-700 text-[10px]"
                      >
                        BLOCK & REJECT
                      </button>
                    </div>
                  ) : (
                    <span className="px-2 py-0.5 rounded bg-neutral-200 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 font-bold text-[10px]">
                      RESOLVED: {flag.status} BY {flag.resolvedBy}
                    </span>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
