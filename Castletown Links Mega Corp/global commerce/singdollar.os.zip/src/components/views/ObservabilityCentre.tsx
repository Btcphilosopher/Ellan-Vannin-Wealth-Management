/**
 * SINGDOLLAR.OS — 11. Observability and Audit Centre
 */

import React, { useState } from 'react';
import { simulationEngine } from '../../simulation/engine';
import { AuditEvent, SystemMetrics } from '../../types';
import { LineChart, ShieldCheck, FileText, Search, Download } from 'lucide-react';

interface ObservabilityCentreProps {
  auditLogs: AuditEvent[];
  metrics: SystemMetrics;
  darkMode: boolean;
}

export const ObservabilityCentre: React.FC<ObservabilityCentreProps> = ({ auditLogs, metrics, darkMode }) => {
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filteredLogs = auditLogs.filter(log => {
    return log.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.eventType.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.beforeSummary.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.afterSummary.toLowerCase().includes(searchQuery.toLowerCase());
  });

  const handleVerifyInvariants = () => {
    const valid = simulationEngine.validateLedgerInvariants();
    alert(valid ? 'LEDGER INVARIANTS VERIFIED: Monetary supply conserved across all simulated accounts.' : 'INVARIANT FAILURE DETECTED!');
  };

  return (
    <div className="space-y-6 font-mono text-xs">
      {/* Top Banner */}
      <div className={`p-4 rounded border ${darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'}`}>
        <div className="flex flex-wrap items-center justify-between gap-4 pb-3 border-b border-neutral-200 dark:border-neutral-800">
          <div className="flex items-center gap-2">
            <LineChart className="w-5 h-5 text-[#C8102E]" />
            <div>
              <h2 className="text-sm font-bold uppercase">OPERATIONAL OBSERVABILITY & AUDIT CENTRE</h2>
              <p className="text-[11px] text-neutral-500">
                Append-Only Immutable Event Stream, Correlation ID Tracing & Conservation Verification
              </p>
            </div>
          </div>

          <button
            onClick={handleVerifyInvariants}
            className="px-3.5 py-1.5 rounded bg-emerald-600 text-white font-bold hover:bg-emerald-700 flex items-center gap-1.5"
          >
            <ShieldCheck className="w-4 h-4" />
            <span>RUN LEDGER INVARIANT VERIFIER</span>
          </button>
        </div>

        {/* Search Bar */}
        <div className="flex items-center gap-2 mt-3 pt-2">
          <Search className="w-4 h-4 text-neutral-400" />
          <input
            type="text"
            placeholder="Search audit logs by Event ID, Correlation ID, or Summary..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-transparent outline-none text-xs"
          />
        </div>
      </div>

      {/* Audit Log Stream Table */}
      <div className={`p-4 rounded border ${darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'}`}>
        <h3 className="text-xs font-bold uppercase text-neutral-500 border-b pb-3 mb-4 dark:border-neutral-800 flex justify-between">
          <span>APPEND-ONLY IMMUTABLE AUDIT LOG ({filteredLogs.length} EVENTS)</span>
          <span className="text-emerald-500">CORRELATION TRACEABLE</span>
        </h3>

        <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
          {filteredLogs.map(log => (
            <div
              key={log.id}
              className="p-3 rounded border bg-neutral-50 dark:bg-neutral-900/80 border-neutral-200 dark:border-neutral-800 font-mono text-xs space-y-1"
            >
              <div className="flex items-center justify-between text-[11px]">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-[#C8102E]">{log.eventType}</span>
                  <span className="text-neutral-400">[{log.sourceService}]</span>
                </div>
                <span className="text-neutral-500 text-[10px]">{new Date(log.timestamp).toLocaleTimeString()}</span>
              </div>

              <div className="font-semibold text-neutral-800 dark:text-neutral-200">{log.afterSummary}</div>
              <div className="text-[10px] text-neutral-400">
                Event ID: {log.id} | Corr ID: {log.correlationId} | Entity: {log.relatedEntityId}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
