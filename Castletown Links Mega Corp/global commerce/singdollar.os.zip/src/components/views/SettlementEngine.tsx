/**
 * SINGDOLLAR.OS — 06. Payment and Settlement Engine Module
 */

import React, { useState } from 'react';
import { Transaction } from '../../types';
import { ArrowLeftRight, Play, CheckCircle2, RefreshCw, Layers, ShieldCheck } from 'lucide-react';

interface SettlementEngineProps {
  transactions: Transaction[];
  darkMode: boolean;
}

export const SettlementEngine: React.FC<SettlementEngineProps> = ({ transactions, darkMode }) => {
  const [selectedTx, setSelectedTx] = useState<Transaction | null>(null);
  const [filterStatus, setFilterStatus] = useState<string>('ALL');

  const filteredTxs = transactions.filter(t => {
    if (filterStatus === 'ALL') return true;
    return t.status === filterStatus || t.settlementStatus === filterStatus;
  });

  return (
    <div className="space-y-6 font-mono text-xs">
      {/* Top Header */}
      <div className={`p-4 rounded border ${darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'}`}>
        <div className="flex flex-wrap items-center justify-between gap-4 pb-3 border-b border-neutral-200 dark:border-neutral-800">
          <div className="flex items-center gap-2">
            <ArrowLeftRight className="w-5 h-5 text-[#C8102E]" />
            <div>
              <h2 className="text-sm font-bold uppercase">PAYMENT & SETTLEMENT QUEUE MONITOR</h2>
              <p className="text-[11px] text-neutral-500">
                Atomic Transfer Verification, Idempotency Checks & Transaction Replay Engine
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-neutral-500 text-[11px]">STATUS FILTER:</span>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="p-1.5 rounded border bg-neutral-50 dark:bg-neutral-900 border-neutral-300 dark:border-neutral-700 font-bold"
            >
              <option value="ALL">ALL STATUSES</option>
              <option value="SETTLED">SETTLED (FINALIZED)</option>
              <option value="FAILED">FAILED / REJECTED</option>
              <option value="REVERSED">REVERSED (REFUNDED)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Main Grid: Queue Stream & Transaction Replay Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column (2 cols): Settlement Queue Table */}
        <div className={`lg:col-span-2 p-4 rounded border space-y-3 ${
          darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'
        }`}>
          <div className="text-xs font-bold uppercase text-neutral-500 border-b pb-2 dark:border-neutral-800 flex justify-between">
            <span>SETTLEMENT LEDGER ENTRIES ({filteredTxs.length})</span>
            <span className="text-emerald-500">IDEMPOTENCY VERIFIED</span>
          </div>

          <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
            {filteredTxs.map(tx => {
              const isSelected = selectedTx?.id === tx.id;
              return (
                <div
                  key={tx.id}
                  onClick={() => setSelectedTx(tx)}
                  className={`p-3 rounded border cursor-pointer transition space-y-1.5 ${
                    isSelected
                      ? 'bg-neutral-800 text-white border-[#C8102E]'
                      : darkMode
                      ? 'bg-neutral-900/60 border-neutral-800 hover:bg-neutral-800/80'
                      : 'bg-neutral-50 border-neutral-200 hover:bg-neutral-100'
                  }`}
                >
                  <div className="flex items-center justify-between font-bold text-xs">
                    <span className="truncate max-w-[200px]">{tx.payerName} → {tx.payeeName}</span>
                    <span className="text-emerald-600 dark:text-emerald-400">S$ {tx.amount.toFixed(2)}</span>
                  </div>

                  <div className="flex items-center justify-between text-[10px] text-neutral-400">
                    <span>Tx ID: {tx.id}</span>
                    <span className={`px-1.5 py-0.2 rounded font-bold ${
                      tx.status === 'SETTLED' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' : 'bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300'
                    }`}>
                      {tx.status} ({tx.settlementStatus})
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-[9px] text-neutral-500 pt-0.5 border-t border-neutral-700/30">
                    <span>Channel: {tx.paymentChannel} | Instrument: {tx.instrumentType}</span>
                    <span>Latency: {tx.settlementTimeMs}ms</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Transaction Replay & Lifecycle Inspector */}
        <div className={`p-4 rounded border ${darkMode ? 'bg-[#1A1A1E] border-neutral-800' : 'bg-white border-neutral-200'}`}>
          <h3 className="text-xs font-bold uppercase text-neutral-500 border-b pb-2 mb-4 dark:border-neutral-800 flex items-center justify-between">
            <span>TRANSACTION REPLAY & TRACE</span>
            <Play className="w-4 h-4 text-[#C8102E]" />
          </h3>

          {!selectedTx ? (
            <div className="text-center py-16 text-neutral-500">
              Select any transaction from the settlement queue to replay its lifecycle steps and inspect audit references.
            </div>
          ) : (
            <div className="space-y-4">
              <div className="p-3 bg-neutral-50 dark:bg-neutral-900 rounded border border-neutral-200 dark:border-neutral-800 space-y-1">
                <div className="font-bold text-xs text-[#C8102E]">{selectedTx.id}</div>
                <div>Amount: S$ {selectedTx.amount.toFixed(2)} SGD ({selectedTx.instrumentType})</div>
                <div className="text-[10px] text-neutral-400">Idempotency Key: {selectedTx.idempotencyKey}</div>
                <div className="text-[10px] text-neutral-400">Audit Reference: {selectedTx.auditRef}</div>
              </div>

              <div className="space-y-2">
                <span className="text-[10px] font-bold text-neutral-500 uppercase">REPLAY STEP SEQUENCE:</span>
                {selectedTx.lifecycle.map((step, idx) => (
                  <div key={idx} className="p-2 rounded border bg-neutral-900 border-neutral-800 text-[11px] space-y-0.5">
                    <div className="flex items-center justify-between font-bold text-emerald-400">
                      <span>STEP {idx + 1}: {step.step}</span>
                      <span className="text-[9px] text-neutral-400">{new Date(step.timestamp).toLocaleTimeString()}</span>
                    </div>
                    <p className="text-[10px] text-neutral-300">{step.detail}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
