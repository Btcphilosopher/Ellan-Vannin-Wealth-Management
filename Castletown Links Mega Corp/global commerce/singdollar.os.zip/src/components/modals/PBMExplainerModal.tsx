/**
 * SINGDOLLAR.OS — PBM Orchid Educational Explainer Modal
 */

import React from 'react';
import { Lock, Info, CheckCircle2 } from 'lucide-react';

interface PBMExplainerModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
}

export const PBMExplainerModal: React.FC<PBMExplainerModalProps> = ({ isOpen, onClose, darkMode }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className={`w-full max-w-2xl p-6 rounded-lg border shadow-2xl font-mono text-xs space-y-4 ${
        darkMode ? 'bg-[#1A1A1E] border-neutral-700 text-neutral-100' : 'bg-white border-neutral-300 text-neutral-900'
      }`}>
        <div className="flex items-center justify-between border-b pb-3 border-neutral-200 dark:border-neutral-800">
          <span className="font-bold text-sm text-[#C8102E] flex items-center gap-2">
            <Lock className="w-5 h-5 text-[#7A5C90]" />
            MAS PROJECT ORCHID: PURPOSE-BOUND MONEY (PBM) CONCEPT
          </span>
          <button onClick={onClose} className="text-neutral-400 hover:text-white text-base">✕</button>
        </div>

        <div className="space-y-3 leading-relaxed text-neutral-300 font-sans">
          <p className="font-bold text-sm text-neutral-100 font-mono">
            Why Purpose-Bound Money is NOT simply "money with arbitrary restrictions":
          </p>

          <p>
            In traditional financial systems, restricted money (such as merchant gift cards or closed-loop vouchers) locks capital inside proprietary walled gardens. The merchant holds floating liabilities, and the voucher cannot settle atomically in central-bank money.
          </p>

          <div className="p-3 bg-purple-500/10 border border-purple-500/30 rounded space-y-1 font-mono text-[11px] text-purple-600 dark:text-purple-300">
            <div className="font-bold uppercase">The Decoupled PBM Protocol Layer:</div>
            <div>1. <strong>Underlying Money Token:</strong> Unrestricted Central Bank Digital Currency (CBDC) or Tokenised Commercial Deposit.</div>
            <div>2. <strong>Protocol Wrapper Contract:</strong> Encapsulates spending conditions (merchant whitelist, category, validity window).</div>
          </div>

          <p>
            When spending conditions are verified by the smart contract wrapper:
          </p>

          <ul className="space-y-1 text-[11px] font-mono text-emerald-600 dark:text-emerald-400">
            <li className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0" />
              <span>1. The PBM protocol wrapper is consumed / burned.</span>
            </li>
            <li className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0" />
              <span>2. The underlying value is instantly unlocked from escrow.</span>
            </li>
            <li className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0" />
              <span>3. The merchant receives standard, unencumbered, unrestricted settlement money.</span>
            </li>
          </ul>

          <div className="p-3 bg-neutral-900 border border-neutral-800 rounded text-[10px] text-neutral-400 font-mono">
            Reference: Monetary Authority of Singapore (MAS) Project Orchid Whitepaper on Purpose-Bound Money Standards.
          </div>
        </div>

        <div className="pt-2 text-right">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded bg-[#C8102E] text-white font-bold hover:bg-[#a00c24] font-mono"
          >
            UNDERSTOOD & ACKNOWLEDGED
          </button>
        </div>
      </div>
    </div>
  );
};
