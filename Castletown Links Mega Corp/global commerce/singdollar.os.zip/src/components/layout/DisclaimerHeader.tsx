/**
 * SINGDOLLAR.OS — Mandatory Disclaimer Banner
 */

import React from 'react';
import { ShieldAlert, Info } from 'lucide-react';

export const DisclaimerHeader: React.FC = () => {
  return (
    <div className="bg-[#1A1A1E] text-neutral-100 border-b border-neutral-800 px-4 py-2 text-xs font-mono flex flex-wrap items-center justify-between gap-2 shadow-sm select-none">
      <div className="flex items-center gap-2">
        <span className="inline-flex items-center justify-center w-4 h-4 rounded bg-[#C8102E] text-white text-[10px] font-bold">
          !
        </span>
        <span className="font-semibold tracking-wider text-[#C8102E] uppercase">
          FICTIONAL RESEARCH PROTOTYPE
        </span>
        <span className="text-neutral-400 hidden sm:inline">—</span>
        <span className="text-neutral-300 font-sans">
          NOT ISSUED OR ENDORSED BY MAS OR THE GOVERNMENT OF SINGAPORE
        </span>
      </div>
      <div className="flex items-center gap-3 text-neutral-400 text-[11px] font-mono">
        <span className="inline-flex items-center gap-1">
          <Info className="w-3.5 h-3.5 text-[#7A5C90]" />
          Project Orchid Experimental Framework Model
        </span>
        <span className="bg-neutral-800 px-2 py-0.5 rounded text-neutral-300 font-mono text-[10px] border border-neutral-700">
          SEED: 2026-DETERMINISTIC
        </span>
      </div>
    </div>
  );
};
