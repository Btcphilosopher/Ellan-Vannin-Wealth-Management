/**
 * SINGDOLLAR.OS — Persistent Supermodernist Left Navigation
 */

import React from 'react';
import { 
  Building2, Wallet, Store, Code2, ArrowLeftRight, Globe, 
  ShieldAlert, Lock, Sliders, LineChart, Banknote 
} from 'lucide-react';

export type NavTab = 
  | 'overview'
  | 'issuance'
  | 'wallets'
  | 'terminal'
  | 'pbm_studio'
  | 'settlement'
  | 'cross_border'
  | 'risk'
  | 'privacy'
  | 'scenario'
  | 'observability';

interface SidebarNavProps {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  pendingRiskCount: number;
  activePbmCount: number;
  darkMode: boolean;
}

export const SidebarNav: React.FC<SidebarNavProps> = ({
  activeTab,
  setActiveTab,
  pendingRiskCount,
  activePbmCount,
  darkMode
}) => {
  const navItems: { id: NavTab; label: string; num: string; icon: React.ReactNode; badge?: number | string }[] = [
    { id: 'overview', label: 'National Overview', num: '01', icon: <Building2 className="w-4 h-4" /> },
    { id: 'issuance', label: 'Issuance Desk', num: '02', icon: <Banknote className="w-4 h-4" /> },
    { id: 'wallets', label: 'Wallet Explorer', num: '03', icon: <Wallet className="w-4 h-4" /> },
    { id: 'terminal', label: 'Merchant POS Terminal', num: '04', icon: <Store className="w-4 h-4" /> },
    { id: 'pbm_studio', label: 'PBM Rule Studio', num: '05', icon: <Code2 className="w-4 h-4" />, badge: activePbmCount },
    { id: 'settlement', label: 'Settlement Engine', num: '06', icon: <ArrowLeftRight className="w-4 h-4" /> },
    { id: 'cross_border', label: 'Cross-Border Lab', num: '07', icon: <Globe className="w-4 h-4" /> },
    { id: 'risk', label: 'Risk & Compliance', num: '08', icon: <ShieldAlert className="w-4 h-4" />, badge: pendingRiskCount > 0 ? pendingRiskCount : undefined },
    { id: 'privacy', label: 'Privacy & Control', num: '09', icon: <Lock className="w-4 h-4" /> },
    { id: 'scenario', label: 'Scenario Laboratory', num: '10', icon: <Sliders className="w-4 h-4" /> },
    { id: 'observability', label: 'Observability & Audit', num: '11', icon: <LineChart className="w-4 h-4" /> },
  ];

  return (
    <aside className={`w-64 flex-shrink-0 border-r flex flex-col justify-between transition-colors select-none ${
      darkMode ? 'bg-[#18181C] border-neutral-800 text-neutral-200' : 'bg-neutral-50 border-neutral-200 text-neutral-800'
    }`}>
      <div className="py-3 px-2">
        <div className="px-3 pb-2 mb-2 border-b border-neutral-200 dark:border-neutral-800 text-[10px] font-mono tracking-widest text-neutral-400 uppercase">
          OPERATIONAL MODULES
        </div>

        <nav className="space-y-1">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2 rounded text-xs font-mono transition-all text-left group ${
                  isActive
                    ? 'bg-[#C8102E] text-white font-semibold shadow-sm'
                    : darkMode
                    ? 'text-neutral-300 hover:bg-neutral-800/80 hover:text-white'
                    : 'text-neutral-700 hover:bg-neutral-200/70 hover:text-neutral-900'
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <span className={`text-[10px] ${isActive ? 'text-white/80' : 'text-neutral-400 font-normal'}`}>
                    {item.num}
                  </span>
                  <span className={isActive ? 'text-white' : 'text-neutral-400 group-hover:text-neutral-600 dark:group-hover:text-neutral-300'}>
                    {item.icon}
                  </span>
                  <span className="truncate">{item.label}</span>
                </div>

                {item.badge !== undefined && (
                  <span className={`px-1.5 py-0.2 text-[10px] rounded font-bold font-mono ${
                    isActive
                      ? 'bg-white text-[#C8102E]'
                      : typeof item.badge === 'number' && item.id === 'risk'
                      ? 'bg-red-500 text-white animate-pulse'
                      : 'bg-neutral-200 dark:bg-neutral-700 text-neutral-700 dark:text-neutral-300'
                  }`}>
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Footer Institution info */}
      <div className="p-3 border-t border-neutral-200 dark:border-neutral-800 text-[11px] font-mono text-neutral-500 space-y-1">
        <div className="flex items-center justify-between">
          <span>MONETARY REGIME:</span>
          <span className="font-semibold text-neutral-700 dark:text-neutral-300">SINGAPORE SGD</span>
        </div>
        <div className="flex items-center justify-between">
          <span>ARCHETYPE:</span>
          <span className="text-[#7A5C90] dark:text-[#9370DB] font-semibold">SUPERMODERNIST</span>
        </div>
        <div className="mt-2 pt-2 border-t border-neutral-200 dark:border-neutral-800/60 text-[9px] text-neutral-400 leading-tight">
          Experimental platform inspired by MAS Orchid documentation.
        </div>
      </div>
    </aside>
  );
};
