/**
 * SINGDOLLAR.OS — Top Operational Navbar
 */

import React, { useState, useEffect } from 'react';
import { simulationEngine } from '../../simulation/engine';
import { SystemMetrics, ScenarioParams } from '../../types';
import { Activity, ShieldCheck, RefreshCw, Sun, Moon, Cpu, Server, Lock } from 'lucide-react';

interface TopNavbarProps {
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
  onOpenExplainer: () => void;
}

export const TopNavbar: React.FC<TopNavbarProps> = ({ darkMode, setDarkMode, onOpenExplainer }) => {
  const [metrics, setMetrics] = useState<SystemMetrics>(simulationEngine.getMetrics());
  const [scenario, setScenario] = useState<ScenarioParams>(simulationEngine.getScenario());
  const [clock, setClock] = useState<string>(simulationEngine.getClock());

  useEffect(() => {
    const unsubscribe = simulationEngine.subscribe(() => {
      setMetrics({ ...simulationEngine.getMetrics() });
      setScenario({ ...simulationEngine.getScenario() });
      setClock(simulationEngine.getClock());
    });
    return () => unsubscribe();
  }, []);

  const handleReset = () => {
    simulationEngine.resetToDefaults(2026);
  };

  return (
    <header className={`h-14 border-b flex items-center justify-between px-4 transition-colors select-none ${
      darkMode ? 'bg-[#141417] text-neutral-100 border-neutral-800' : 'bg-white text-neutral-900 border-neutral-200'
    }`}>
      {/* Left Branding & Title */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-[#C8102E] rounded flex items-center justify-center font-bold text-white text-sm font-mono tracking-tighter shadow-sm">
            S$
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold tracking-tight text-sm font-mono">SINGDOLLAR.OS</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded font-mono font-medium bg-neutral-200 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300">
                v3.6-LAB
              </span>
            </div>
            <p className="text-[10px] text-neutral-500 font-mono leading-none">
              Supermodernist Programmable Money Infrastructure
            </p>
          </div>
        </div>

        <div className="h-6 w-[1px] bg-neutral-300 dark:bg-neutral-800 mx-2 hidden md:block" />

        <button
          onClick={onOpenExplainer}
          className="hidden lg:flex items-center gap-1.5 text-xs text-[#7A5C90] dark:text-[#9370DB] hover:underline font-mono"
        >
          <Lock className="w-3.5 h-3.5" />
          <span>Project Orchid PBM Model</span>
        </button>
      </div>

      {/* Middle System Metrics */}
      <div className="hidden lg:flex items-center gap-6 font-mono text-xs">
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-emerald-500 animate-pulse" />
          <span className="text-neutral-500">TPS:</span>
          <span className="font-semibold">{metrics.tpsCurrent}</span>
          <span className="text-[10px] text-neutral-400">/sec</span>
        </div>

        <div className="flex items-center gap-2">
          <Cpu className="w-4 h-4 text-sky-500" />
          <span className="text-neutral-500">Latency:</span>
          <span className="font-semibold">{metrics.avgSettlementMs}ms</span>
        </div>

        <div className="flex items-center gap-2">
          <ShieldCheck className={`w-4 h-4 ${metrics.ledgerInvariantsValid ? 'text-emerald-500' : 'text-red-500'}`} />
          <span className="text-neutral-500">Ledger Invariants:</span>
          <span className={`font-semibold ${metrics.ledgerInvariantsValid ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600'}`}>
            {metrics.ledgerInvariantsValid ? 'CONSERVED' : 'INVARIANT_FAILURE'}
          </span>
        </div>

        <div className="flex items-center gap-2 bg-neutral-100 dark:bg-neutral-900 px-2.5 py-1 rounded border border-neutral-200 dark:border-neutral-800">
          <Server className="w-3.5 h-3.5 text-amber-500" />
          <span className="text-neutral-500 text-[11px]">SCENARIO:</span>
          <span className="font-semibold text-[11px] truncate max-w-[130px]">{scenario.name}</span>
        </div>
      </div>

      {/* Right Controls */}
      <div className="flex items-center gap-3">
        <div className="font-mono text-xs text-neutral-500 hidden sm:block">
          {clock.replace('T', ' ').replace('Z', ' UTC')}
        </div>

        <button
          onClick={handleReset}
          title="Reset Simulation Ledger to Default Seed"
          className="flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded border border-neutral-300 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 hover:bg-neutral-100 dark:hover:bg-neutral-700 transition font-mono"
        >
          <RefreshCw className="w-3.5 h-3.5 text-neutral-500" />
          <span className="hidden sm:inline">Reset Ledger</span>
        </button>

        <button
          onClick={() => setDarkMode(!darkMode)}
          title="Toggle Theme"
          className="p-1.5 rounded border border-neutral-300 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 hover:bg-neutral-100 dark:hover:bg-neutral-700 transition"
        >
          {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-neutral-600" />}
        </button>
      </div>
    </header>
  );
};
