/**
 * SINGDOLLAR.OS — Main Application Component
 * A Supermodernist Digital Singapore Dollar & Programmable-Money Laboratory
 * FICTIONAL RESEARCH PROTOTYPE — NOT ISSUED OR ENDORSED BY MAS OR THE GOVERNMENT OF SINGAPORE
 */

import React, { useState, useEffect } from 'react';
import { simulationEngine } from './simulation/engine';
import { NavTab, SidebarNav } from './components/layout/SidebarNav';
import { TopNavbar } from './components/layout/TopNavbar';
import { DisclaimerHeader } from './components/layout/DisclaimerHeader';

// Views
import { NationalOverview } from './components/views/NationalOverview';
import { IssuanceDesk } from './components/views/IssuanceDesk';
import { WalletExplorer } from './components/views/WalletExplorer';
import { MerchantTerminal } from './components/views/MerchantTerminal';
import { PBMStudio } from './components/views/PBMStudio';
import { SettlementEngine } from './components/views/SettlementEngine';
import { CrossBorderLab } from './components/views/CrossBorderLab';
import { RiskCompliance } from './components/views/RiskCompliance';
import { PrivacyPanel } from './components/views/PrivacyPanel';
import { ScenarioLab } from './components/views/ScenarioLab';
import { ObservabilityCentre } from './components/views/ObservabilityCentre';

// Modals
import { PBMExplainerModal } from './components/modals/PBMExplainerModal';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('overview');
  const [darkMode, setDarkMode] = useState<boolean>(true);
  const [showExplainer, setShowExplainer] = useState<boolean>(false);

  // Engine state subscriptions
  const [accounts, setAccounts] = useState(simulationEngine.getAccounts());
  const [pbms, setPbms] = useState(simulationEngine.getPBMs());
  const [transactions, setTransactions] = useState(simulationEngine.getTransactions());
  const [auditLogs, setAuditLogs] = useState(simulationEngine.getAuditLogs());
  const [riskFlags, setRiskFlags] = useState(simulationEngine.getRiskFlags());
  const [crossBorderLegs, setCrossBorderLegs] = useState(simulationEngine.getCrossBorderLegs());
  const [metrics, setMetrics] = useState(simulationEngine.getMetrics());
  const [scenario, setScenario] = useState(simulationEngine.getScenario());

  useEffect(() => {
    const unsubscribe = simulationEngine.subscribe(() => {
      setAccounts([...simulationEngine.getAccounts()]);
      setPbms([...simulationEngine.getPBMs()]);
      setTransactions([...simulationEngine.getTransactions()]);
      setAuditLogs([...simulationEngine.getAuditLogs()]);
      setRiskFlags([...simulationEngine.getRiskFlags()]);
      setCrossBorderLegs([...simulationEngine.getCrossBorderLegs()]);
      setMetrics({ ...simulationEngine.getMetrics() });
      setScenario({ ...simulationEngine.getScenario() });
    });
    return () => unsubscribe();
  }, []);

  // Sync html dark class
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const pendingRiskCount = riskFlags.filter(f => f.status === 'PENDING_REVIEW').length;
  const activePbmCount = pbms.filter(p => p.status === 'ACTIVE' || p.status === 'PARTIALLY_CONSUMED').length;

  return (
    <div className={`min-h-screen flex flex-col font-sans transition-colors ${
      darkMode ? 'bg-[#101013] text-neutral-100' : 'bg-neutral-100 text-neutral-900'
    }`}>
      {/* 1. Mandatory Disclaimer Header */}
      <DisclaimerHeader />

      {/* 2. Top System Operational Navbar */}
      <TopNavbar
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        onOpenExplainer={() => setShowExplainer(true)}
      />

      {/* 3. Main Workspace Layout */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Navigation */}
        <SidebarNav
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          pendingRiskCount={pendingRiskCount}
          activePbmCount={activePbmCount}
          darkMode={darkMode}
        />

        {/* Central Active View Workspace */}
        <main className="flex-1 overflow-y-auto p-4 md:p-6">
          <div className="max-w-7xl mx-auto space-y-6">
            {activeTab === 'overview' && (
              <NationalOverview
                metrics={metrics}
                transactions={transactions}
                accounts={accounts}
                darkMode={darkMode}
              />
            )}

            {activeTab === 'issuance' && (
              <IssuanceDesk
                accounts={accounts}
                auditLogs={auditLogs}
                darkMode={darkMode}
              />
            )}

            {activeTab === 'wallets' && (
              <WalletExplorer
                accounts={accounts}
                transactions={transactions}
                darkMode={darkMode}
              />
            )}

            {activeTab === 'terminal' && (
              <MerchantTerminal
                accounts={accounts}
                pbms={pbms}
                darkMode={darkMode}
              />
            )}

            {activeTab === 'pbm_studio' && (
              <PBMStudio
                accounts={accounts}
                pbms={pbms}
                darkMode={darkMode}
              />
            )}

            {activeTab === 'settlement' && (
              <SettlementEngine
                transactions={transactions}
                darkMode={darkMode}
              />
            )}

            {activeTab === 'cross_border' && (
              <CrossBorderLab
                crossBorderLegs={crossBorderLegs}
                darkMode={darkMode}
              />
            )}

            {activeTab === 'risk' && (
              <RiskCompliance
                riskFlags={riskFlags}
                darkMode={darkMode}
              />
            )}

            {activeTab === 'privacy' && (
              <PrivacyPanel
                darkMode={darkMode}
              />
            )}

            {activeTab === 'scenario' && (
              <ScenarioLab
                scenario={scenario}
                darkMode={darkMode}
              />
            )}

            {activeTab === 'observability' && (
              <ObservabilityCentre
                auditLogs={auditLogs}
                metrics={metrics}
                darkMode={darkMode}
              />
            )}
          </div>
        </main>
      </div>

      {/* Educational PBM Explainer Modal */}
      <PBMExplainerModal
        isOpen={showExplainer}
        onClose={() => setShowExplainer(false)}
        darkMode={darkMode}
      />
    </div>
  );
}
