/**
 * SINGDOLLAR.OS — Domain Types & Data Specifications
 * Fictional Research Prototype — Not issued or endorsed by MAS or the Government of Singapore.
 */

export type InstrumentType = 
  | 'CBDC_RETAIL'            // Direct Central Bank Liability for Retail
  | 'CBDC_WHOLESALE'         // Central Bank Wholesale Settlement Money
  | 'TOKENISED_DEPOSIT'      // Commercial Bank Tokenised Deposit (DBS, OCBC, UOB)
  | 'REGULATED_STABLECOIN'   // MAS-Regulated Single-Currency Stablecoin (e.g., XSGD)
  | 'PBM_WRAPPER';           // Purpose-Bound Money Wrapper (Condition Enforcer)

export type EntityType = 
  | 'CENTRAL_BANK'           // Monetary Authority of Singapore (Simulated)
  | 'COMMERCIAL_BANK'        // DBS, OCBC, UOB
  | 'GOVERNMENT_AGENCY'      // GovTech, MOF, SSG, CDC Council
  | 'RESIDENT'               // Singapore Citizen / Resident
  | 'MERCHANT'               // Retailers, Supermarkets, Hawker Stalls, SMEs
  | 'MNC'                    // Multinational Corporations
  | 'TRAINING_PROVIDER'      // SkillsFuture Accredited Institution
  | 'CHARITY';               // Non-Profit / NGO

export type AccountType = 
  | 'CUSTOMER_RETAIL'
  | 'COMMERCIAL_BANK_RESERVE'
  | 'INSTITUTIONAL_SETTLEMENT'
  | 'GOV_DISBURSEMENT'
  | 'MERCHANT_SETTLEMENT'
  | 'CENTRAL_BANK_ISSUANCE'
  | 'ESCROW_HOLDING';

export type TransactionStatus = 
  | 'INITIATED'
  | 'AUTHENTICATED'
  | 'POLICY_CHECKED'
  | 'FUNDS_RESERVED'
  | 'SETTLED'
  | 'FAILED'
  | 'REVERSED'
  | 'UNDER_REVIEW';

export type SettlementStatus = 
  | 'PENDING'
  | 'PROCESSING'
  | 'FINALIZED'
  | 'REJECTED'
  | 'QUEUED_OUTAGE';

export type FailureCode = 
  | 'INSUFFICIENT_FUNDS'
  | 'EXPIRED_PBM'
  | 'UNAPPROVED_MERCHANT'
  | 'UNSUPPORTED_CATEGORY'
  | 'GEOGRAPHIC_RESTRICTION'
  | 'MAX_LIMIT_EXCEEDED'
  | 'DUPLICATE_IDEMPOTENCY'
  | 'NETWORK_INTERRUPTION'
  | 'RISK_REVIEW_HOLD'
  | 'SETTLEMENT_TIMEOUT'
  | 'TRANSFERABILITY_VIOLATION'
  | 'NONE';

export type SpendingCategory = 
  | 'GROCERIES_HOUSEHOLD'
  | 'EDUCATION_TRAINING'
  | 'HAWKER_FOOD'
  | 'HEALTHCARE_MEDICAL'
  | 'PUBLIC_TRANSPORT'
  | 'GENERAL_RETAIL'
  | 'CROSS_BORDER_SUPPLY';

export interface PBMConfig {
  id: string;
  name: string;
  principalAmount: number;
  currency: 'SGD';
  issuerId: string;
  issuerName: string;
  beneficiaryClass: string;
  permittedMerchantIds: string[]; // empty = all approved in category
  permittedCategories: SpendingCategory[];
  geographicConstraints: string[]; // e.g., ["SINGAPORE_ALL", "HEARTLAND_SHOPS"]
  validFrom: string;
  validTo: string;
  maxTxAmount?: number;
  transferable: boolean;
  releaseConditions: string[]; // e.g. ["ATTENDANCE_VERIFIED", "RECEIPT_MATCHED"]
  status: 'ACTIVE' | 'PARTIALLY_CONSUMED' | 'CONSUMED' | 'EXPIRED' | 'REVOKED';
  originalBalance: number;
  remainingBalance: number;
  underlyingInstrumentType: InstrumentType;
  creationTimestamp: string;
}

export interface Account {
  id: string;
  entityId: string;
  entityName: string;
  entityType: EntityType;
  accountType: AccountType;
  balances: {
    unrestrictedCBDC: number;
    wholesaleCBDC: number;
    tokenisedDeposits: { [bankName: string]: number };
    stablecoins: number;
    pbmRestricted: number;
  };
  pendingReserve: number;
  riskStatus: 'LOW' | 'MEDIUM' | 'HIGH' | 'SUSPENDED';
  deviceSession: {
    deviceId: string;
    ipLocation: string;
    authMethod: 'SINGPASS_BIOMETRIC' | 'CORPORATE_PKI' | 'HARDWARE_HSM' | 'QR_NFC';
  };
}

export interface TransactionStep {
  step: string;
  timestamp: string;
  status: 'PASSED' | 'FAILED' | 'SKIPPED';
  detail: string;
}

export interface Transaction {
  id: string;
  idempotencyKey: string;
  timestamp: string;
  payerId: string;
  payerName: string;
  payeeId: string;
  payeeName: string;
  amount: number;
  currency: 'SGD' | 'USD' | 'EUR' | 'JPY' | 'CNY' | 'GBP';
  instrumentType: InstrumentType;
  pbmId?: string;
  pbmName?: string;
  category?: SpendingCategory;
  paymentChannel: 'QR_SGQR' | 'NFC_CONTACTLESS' | 'P2P_FAST' | 'WHOLESALE_RTGS' | 'CROSS_BORDER_PVP';
  status: TransactionStatus;
  settlementStatus: SettlementStatus;
  failureCode: FailureCode;
  failureReason?: string;
  policyResult: {
    passed: boolean;
    ruleChecked?: string;
    details?: string;
  };
  riskResult: {
    flagged: boolean;
    score: number;
    trigger?: string;
  };
  lifecycle: TransactionStep[];
  auditRef: string;
  settlementTimeMs: number;
  isReversal?: boolean;
  originalTxId?: string;
}

export interface AuditEvent {
  id: string;
  timestamp: string;
  eventType: 
    | 'MONEY_ISSUED'
    | 'MONEY_REDEEMED'
    | 'MONEY_DESTROYED'
    | 'PBM_CREATED'
    | 'PBM_ALLOCATED'
    | 'PBM_EXECUTED'
    | 'PBM_EXPIRED'
    | 'TRANSACTION_SETTLED'
    | 'TRANSACTION_FAILED'
    | 'REFUND_EXECUTED'
    | 'SETTLEMENT_OUTAGE_SIMULATED'
    | 'RISK_FLAG_RAISED'
    | 'SCENARIO_TRIGGERED';
  sourceService: string;
  correlationId: string;
  relatedEntityId: string;
  beforeSummary: string;
  afterSummary: string;
  details: Record<string, unknown>;
}

export interface RiskFlag {
  id: string;
  txId: string;
  timestamp: string;
  trigger: 'HIGH_VELOCITY' | 'LARGE_VALUE' | 'SANCTIONS_SCREENING' | 'DEVICE_ANOMALY' | 'GEOGRAPHIC_MISMATCH' | 'UNUSUAL_PATTERN';
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  payerName: string;
  amount: number;
  explainableReason: string;
  status: 'PENDING_REVIEW' | 'APPROVED' | 'BLOCKED_CONFIRMED' | 'DISMISSED';
  resolvedBy?: string;
  resolvedAt?: string;
}

export interface CrossBorderLeg {
  id: string;
  sourceCurrency: string;
  targetCurrency: string;
  sourceAmount: number;
  targetAmount: number;
  fxRate: number;
  payerEntity: string;
  payeeEntity: string;
  status: 'ESCROW_LOCKED' | 'CONVERTED' | 'PVP_SETTLED' | 'FAILED_LEG_REFUNDED';
  escrowRef: string;
  settlementMode: 'ATOMIC_PVP' | 'SEQUENTIAL';
}

export interface SystemMetrics {
  totalIssuedCBDC: number;
  totalWholesaleCBDC: number;
  totalTokenisedDeposits: number;
  totalStablecoins: number;
  totalPBMValue: number;
  activeWallets: number;
  participatingInstitutions: number;
  tpsCurrent: number;
  tpsPeak: number;
  avgSettlementMs: number;
  failedTxCount: number;
  lockedFunds: number;
  merchantVolume24h: number;
  systemHealth: 'HEALTHY' | 'DEGRADED_OUTAGE' | 'HIGH_LATENCY' | 'MAINTENANCE';
  queueDepth: number;
  ledgerInvariantsValid: boolean;
}

export interface ScenarioParams {
  id: string;
  name: string;
  description: string;
  txVolumeMultiplier: number;
  networkLatencyMs: number;
  failureRatePercent: number;
  simulateBankOutage: boolean;
  outageBankId?: string;
  expiringVoucherCliff: boolean;
  fxStress: boolean;
  seed: number;
}
