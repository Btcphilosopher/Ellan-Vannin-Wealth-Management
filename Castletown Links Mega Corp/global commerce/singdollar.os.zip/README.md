# SINGDOLLAR.OS
### A Supermodernist Digital Singapore Dollar & Programmable-Money Laboratory

> **FICTIONAL RESEARCH PROTOTYPE — NOT ISSUED OR ENDORSED BY MAS OR THE GOVERNMENT OF SINGAPORE**
> This application is an experimental, simulation-first software platform inspired by publicly documented concepts from Singapore’s **Project Orchid**. It does not imply that Singapore currently operates a retail CBDC, nor is it connected to real monetary payment rails.

---

## 1. Product Vision & Principles

`SINGDOLLAR.OS` is a high-integrity digital-money laboratory designed for exploring how a future digital Singapore dollar might function across retail payments, institutional settlement, programmable vouchers (Purpose-Bound Money), tokenised deposits, and cross-border financial infrastructure.

### Architectural Visual Language:
- **Palette**: White/Chalk, Graphite (`#1A1A1E`), Deep Red (`#C8102E` - Singapore Crimson), Warm Silver, and Muted Orchid (`#7A5C90`).
- **Precision**: Changi Airport-grade information density, strong typographic hierarchy, fine 1px borders, and responsive institutional workspaces.
- **Strictly Avoided**: Generic crypto aesthetics, neon gradients, floating holograms, meme-coin imagery, unreadable charts, or simplistic wallet-only views.

---

## 2. Core Technical Architecture & Monorepo Design

The application utilizes a deterministic state engine built with TypeScript, React, Vite, and Tailwind CSS.

- **Stateful Ledger Engine**: Append-only audit logs with correlation ID tracing and atomic state updates.
- **Monetary Invariants**: Enforces conservation of money (money cannot be created via ordinary transfers, double spending is cryptographically blocked, failed transactions do not remove funds, and reversals cannot exceed original settled amounts).
- **Purpose-Bound Money (PBM) Protocol Layer**: Implements decoupled smart-contract wrapper rules (principal amount, validity window, merchant whitelists, permitted categories, max transaction limits). Upon condition fulfillment, underlying unrestricted CBDC is released to the merchant's settlement account.

---

## 3. Key Operational Modules

1. **National Overview**: Total issuance metrics across CBDC, Wholesale SGD, Tokenised Deposits, and PBM value, real-time TPS chart, monetary flow architecture, and settlement queue indicators.
2. **Digital-Money Issuance Desk**: Central Bank mint/burn/convert controls with Four-Eyes Dual Control approval protocol and balance sheet view.
3. **Wallet and Account Explorer**: Account registry for Residents, Merchants, Banks, Government Agencies, SMEs, and Training Providers with device session tracking and transfer simulation.
4. **Merchant POS Payment Terminal**: SGQR and NFC payment simulator, PBM eligibility evaluator, offline queueing mode, and step-by-step transaction lifecycle visualizer.
5. **Purpose-Bound Money Studio**: Visual rule configurator, human-readable summary generator, machine-readable JSON exporter, and interactive rule evaluation simulator.
6. **Payment & Settlement Engine**: Atomic transfer queue, idempotency key verification, fund reservations, and transaction replay runner.
7. **Cross-Border Laboratory**: Synthetic multi-currency FX corridor (SGD, USD, EUR, JPY, CNY, GBP) demonstrating Payment-versus-Payment (PvP) atomic settlement.
8. **Risk, Compliance & Safety Layer**: Rule-based risk engine for velocity caps and large-value transfers with an interactive manual review queue.
9. **Privacy & User Control**: Stakeholder data visibility access matrix and selective disclosure zero-knowledge proof demonstrator.
10. **Simulation & Scenario Lab**: Stress-testing engine for volume surges, bank outages, and expiring voucher cliffs.
11. **Observability & Audit Centre**: Immutable event log stream with correlation ID tracing and ledger invariant verifier.

---

## 4. Product Honesty Disclaimer

- **Research Prototype Only**: This is an educational and research prototype.
- **No Real Legal Tender**: It is not connected to MAS, Singapore’s banking system, or real payment rails, and does not issue legal tender.
- **Illustrative Rules & Metrics**: All performance metrics, exchange rates, and policy rules are synthetic and deterministic.
