package com.example.data

import com.example.R

object WineryData {

    val wines = listOf(
        Wine(
            id = "feteasca_neagra_2021",
            name = "Fetească Neagră",
            vintage = "2021",
            price = 24.0,
            grape = "Fetească Neagră",
            type = "Red",
            abv = "13.8%",
            rating = 4.9f,
            description = "A structured and noble Moldovan red wine with rich dark fruit character, restrained oak maturation, and a velvety long finish. Crafted from indigenous grapes grown in the Codru region.",
            aroma = "Intense aromas of dark sweet cherries, wild plums, and a subtle touch of black pepper with toasted oak.",
            palate = "Full-bodied with balanced acidity, round elegant tannins, and complex layers of red forest berries.",
            finish = "Long, lingering, with elements of fine dark chocolate and warm vanilla spices.",
            servingTemp = "16–18°C",
            foodPairings = listOf("Traditional Moldovan placinte with meat", "Grilled lamb chops", "Aged sheep cheeses", "Beef tenderloin"),
            imageResId = R.drawable.img_wine_bottle_1790841720211,
            isReserve = false
        ),
        Wine(
            id = "cabernet_sauvignon_2020",
            name = "Cabernet Sauvignon",
            vintage = "2020",
            price = 28.0,
            grape = "Cabernet Sauvignon",
            type = "Red",
            abv = "14.2%",
            rating = 4.8f,
            description = "A classic cellar masterpiece. Deep ruby red, intense and robust, showing the incredible potential of Cabernet Sauvignon matured in the constant temperature of Mileștii Mici's limestone vault.",
            aroma = "Blackberry, black currant, sweet cedar wood, and dry tobacco leaves.",
            palate = "Muscular and bold, featuring ripe structured tannins, high extraction, and beautiful acidity.",
            finish = "Dry, powerful, with a smoky oak and dark berry retreat.",
            servingTemp = "17–19°C",
            foodPairings = listOf("Dry-aged ribeye steak", "Roasted wild boar", "Slow-roasted venison", "Rich tomato-based stews"),
            imageResId = R.drawable.img_wine_bottle_1790841720211,
            isReserve = true
        ),
        Wine(
            id = "chardonnay_2022",
            name = "Chardonnay",
            vintage = "2022",
            price = 19.0,
            grape = "Chardonnay",
            type = "White",
            abv = "12.8%",
            rating = 4.7f,
            description = "Fresh and elegant, this Chardonnay captures the sunny slopes of southern Moldova. It undergoes partial barrel fermentation to give it a rich mouthfeel while keeping its mineral energy alive.",
            aroma = "Ripe yellow apples, white peaches, fresh butter, and toasted hazelnuts.",
            palate = "Creamy but crisp, with pleasant acidity and notes of vanilla custard and lemon zest.",
            finish = "Clean, refreshing, with a distinct wet-stone mineral finish.",
            servingTemp = "10–12°C",
            foodPairings = listOf("Creamy seafood pasta", "Pan-seared sea bass", "Roasted chicken with herbs", "Mild goat cheese"),
            imageResId = R.drawable.img_wine_bottle_1790841720211,
            isReserve = false
        ),
        Wine(
            id = "merlot_2021",
            name = "Merlot",
            vintage = "2021",
            price = 23.0,
            grape = "Merlot",
            type = "Red",
            abv = "13.5%",
            rating = 4.6f,
            description = "An exceptionally smooth and round Merlot. Matured for 12 months in classic French oak barrels, it exhibits a beautiful harmony between red fruits and warm woodland floor elements.",
            aroma = "Red plums, dark cocoa, sweet licorice, and a breath of fresh mint.",
            palate = "Soft, medium-bodied, with silky tannins and a juicy cherry mouthfeel.",
            finish = "Smooth and approachable with gentle oak sweet spice.",
            servingTemp = "16–18°C",
            foodPairings = listOf("Roasted duck breast", "Pork tenderloin with plum sauce", "Mushroom risotto", "Grilled vegetables"),
            imageResId = R.drawable.img_wine_bottle_1790841720211,
            isReserve = false
        ),
        Wine(
            id = "pinot_noir_2020",
            name = "Pinot Noir",
            vintage = "2020",
            price = 26.0,
            grape = "Pinot Noir",
            type = "Red",
            abv = "13.0%",
            rating = 4.7f,
            description = "A delicate and complex Pinot Noir, boasting light translucent ruby color and sophisticated earthiness. Maturing inside the damp limestone vaults gives it an incredibly rare forest-floor complexity.",
            aroma = "Wild strawberries, wet earth, dried autumn leaves, and a touch of cloves.",
            palate = "Light-to-medium-bodied, vibrant acidity, fine-grained tannins, and sour cherry notes.",
            finish = "Highly elegant, dry, with red tea and earthy forest-floor echoes.",
            servingTemp = "14–16°C",
            foodPairings = listOf("Truffle pasta", "Roasted pheasant or quail", "Salmon steak", "Mushroom fricassee"),
            imageResId = R.drawable.img_wine_bottle_1790841720211,
            isReserve = false
        ),
        Wine(
            id = "reserve_collection_2018",
            name = "Reserve Collection (Codru)",
            vintage = "2018",
            price = 45.0,
            grape = "Cabernet Sauvignon & Merlot",
            type = "Red",
            abv = "14.5%",
            rating = 4.9f,
            description = "A legendary blend of Cabernet Sauvignon and Merlot, aged for over 3 years in oak casks, then stored in the deep Golden Collection of Mileștii Mici. A collectors' favorite exhibiting unparalleled tertiary characteristics.",
            aroma = "Dried figs, prunes, leather, cigar box, and dark balsamic notes.",
            palate = "Rich and concentrated, perfectly integrated noble wood, deep dark fruit flavors, and velvet texture.",
            finish = "Gigantic finish, dry, leaving a luxurious trail of spice, tobacco, and espresso.",
            servingTemp = "18–20°C",
            foodPairings = listOf("Prime rib roast with rosemary", "Venison Wellington", "Extra mature hard cheeses", "Rich dark chocolate dessert"),
            imageResId = R.drawable.img_wine_bottle_1790841720211,
            isReserve = true
        ),
        Wine(
            id = "feteasca_alba_2022",
            name = "Fetească Albă",
            vintage = "2022",
            price = 22.0,
            grape = "Fetească Albă",
            type = "White",
            abv = "12.5%",
            rating = 4.8f,
            description = "Light, floral, and deeply cultural. Made from the indigenous Fetească Albă grape, this wine represents the delicate perfume of Moldovan spring fields and ancient agricultural traditions.",
            aroma = "White acacia flowers, green grapes, fresh lime, and sweet meadow grass.",
            palate = "Vibrant, thin and elegant, with refreshing minerality and white-fleshed fruit tastes.",
            finish = "Crisp, floral, leaving a mouth-watering lime zest trace.",
            servingTemp = "8–10°C",
            foodPairings = listOf("Traditional Moldovan mamaliga with sour cream", "Fresh river trout", "Summer salads", "Feta cheese"),
            imageResId = R.drawable.img_wine_bottle_1790841720211,
            isReserve = false
        ),
        Wine(
            id = "spumant_clasic_2020",
            name = "Spumant Clasic",
            vintage = "2020",
            price = 32.0,
            grape = "Chardonnay & Pinot Blanc",
            type = "Sparkling",
            abv = "12.0%",
            rating = 4.9f,
            description = "Produced using the strict traditional Method Champenoise, and fermented in the bottle inside our limestone cellars for 30 months. Displays a fine, persistent perlage and incredible bready depth.",
            aroma = "Freshly baked brioche, green apples, toasted almonds, and citrus peel.",
            palate = "Creamy texture, active bubble stream, high crisp acidity with rich lemon mousse layers.",
            finish = "Long and mineral, with elegant hazelnut and buttered toast flavors.",
            servingTemp = "6–8°C",
            foodPairings = listOf("Fresh oysters", "Caviar blinis", "Creamy Brie cheese", "Light fruit tarts"),
            imageResId = R.drawable.img_wine_bottle_1790841720211,
            isReserve = true
        )
    )

    val collections = listOf(
        WineCollection(
            id = "moldova_collection",
            name = "The Moldova Collection",
            motto = "VINURI DIN SUBTERAN",
            description = "Curated selections celebrating the ancient, rich, and unique indigenous grape varieties of Moldova. Taste the historic clay and limestone terroir.",
            wineIds = listOf("feteasca_neagra_2021", "feteasca_alba_2022")
        ),
        WineCollection(
            id = "cellar_collection",
            name = "The Cellar Selection",
            motto = "PRESERVED BENEATH EARTH",
            description = "Wines chosen directly from our legendary subterranean limestone streets, where a constant temperature of 12-14°C guarantees unique aging excellence.",
            wineIds = listOf("merlot_2021", "pinot_noir_2020", "chardonnay_2022")
        ),
        WineCollection(
            id = "reserve_collection",
            name = "Milestii Mici Reserve",
            motto = "THE GOLDEN VAULTS",
            description = "Highly exclusive, fully matured vintages of extraordinary structure and depth. Kept in the Golden Collection for years, selected by our chief winemaker.",
            wineIds = listOf("cabernet_sauvignon_2020", "reserve_collection_2018", "spumant_clasic_2020")
        )
    )

    val giftBoxes = listOf(
        GiftBox(
            id = "moldova_discovery_set",
            name = "Moldova Discovery Set",
            price = 75.0,
            bottlesCount = 3,
            winesIncluded = listOf("Fetească Neagră 2021", "Fetească Albă 2022", "Cabernet Sauvignon 2020"),
            description = "A luxurious collection of three bottles that serves as the perfect introduction to Moldovan fine wine culture. Packaged in a beautiful handcrafted local limestone-grey wooden box."
        ),
        GiftBox(
            id = "cellar_reserve_set",
            name = "Cellar Reserve Selection",
            price = 180.0,
            bottlesCount = 6,
            winesIncluded = listOf("Reserve Collection 2018 (x2)", "Cabernet Sauvignon 2020 (x2)", "Spumant Clasic 2020 (x2)"),
            description = "Six ultra-premium bottles representing the pinnacle of Mileștii Mici aging craft. Housed in a dark-stained premium European oak chest with brass fittings."
        )
    )

    val tours = listOf(
        CellarTour(
            id = "classic_tour",
            name = "The Limestone Tunnels Walk",
            duration = "1.5 Hours",
            languages = listOf("RO", "EN", "RU"),
            price = 35.0,
            availability = "Daily, 10:00 - 18:00",
            description = "A guided exploration walking through the legendary underground streets named after grape varieties. Discover the historic barrels and the secrets of natural climate control.",
            highlight = "Guided limestone vault walk & 1 wine tasting sample."
        ),
        CellarTour(
            id = "royal_tasting",
            name = "Golden Collection Premium Tasting",
            duration = "2.5 Hours",
            languages = listOf("RO", "EN", "FR"),
            price = 85.0,
            availability = "Wednesday - Sunday, 14:00 & 17:00",
            description = "Gain access to the protected Golden Collection vaults, containing over 1.5 million historic bottles (Guinness World Record). Followed by an elite masterclass tasting.",
            highlight = "Guinness Record cellar vault entry, tasting of 5 premium Reserve wines, gourmet Moldovan pairing board."
        ),
        CellarTour(
            id = "underground_gastronomy",
            name = "Underground City Banquet",
            duration = "3.5 Hours",
            languages = listOf("RO", "EN"),
            price = 150.0,
            availability = "Friday & Saturday, 19:00",
            description = "An immersive culinary journey set deep inside the limestone banqueting halls. Live local music, a 5-course premium Moldovan menu, and unlimited matching wines.",
            highlight = "5-course premium dinner in the historic banqueting hall, live traditional musicians, and continuous wine pairing."
        )
    )

    val storyChapters = listOf(
        StoryChapter(
            id = "origin",
            title = "The Limestone Womb",
            year = "1969",
            subtitle = "From Mine to Cellar",
            content = "Originally established in 1969 as a site for high-grade white limestone extraction, the subterranean corridors of Mileștii Mici were quickly identified by winemakers as a natural marvel. The porous limestone vaults acted as a perfect sponge, maintaining a constant natural temperature of 12-14°C and a humidity level of 85-95% year-round—optimal parameters for slowly maturing premium European wine."
        ),
        StoryChapter(
            id = "guinness",
            title = "A Guinness World Record",
            year = "2005",
            subtitle = "The Golden Collection",
            content = "In August 2005, the Mileștii Mici Golden Collection was officially recognized by the Guinness Book of World Records as the largest wine collection in the world by bottle count. Housing over 1.5 million premium bottles in architectural limestone niches, this subterranean treasure contains vintages dating back to the late 20th century, representing the pride of Moldovan viticulture."
        ),
        StoryChapter(
            id = "streets",
            title = "A Subterranean City",
            year = "Today",
            subtitle = "200 Kilometers of Wine",
            content = "Stretching across 200 kilometers of underground roadways, with over 55 kilometers actively dedicated to wine storage, Mileștii Mici functions as a full underground city. Guests navigate streets named 'Cabernet', 'Chardonnay', 'Fetească', or 'Aligoté' on cars or bikes, matching the grape varieties stored in the corresponding tunnels. It is a monument of European wine civilization."
        )
    )

    val cellarAreas = listOf(
        CellarArea(
            id = "cabernet_street",
            name = "Strada Cabernet Sauvignon",
            streetName = "Cabernet Street",
            depth = "65 Meters Underground",
            description = "The central artery dedicated to maturing heavy oak-matured red wines. Holds over 400 giant oak casks containing our finest Cabernet Sauvignon.",
            highlight = "Aroma of toasted vanilla and aged grape skins permeates this damp stone gallery.",
            relativeX = 0.25f,
            relativeY = 0.35f
        ),
        CellarArea(
            id = "golden_vaults",
            name = "Colecția de Aur (Golden Vaults)",
            streetName = "The Guinness Record Vaults",
            depth = "80 Meters Underground",
            description = "The sacred core of the winery where the world's largest wine collection rests. Locked behind historic iron gates, each bottle is catalogued by hand.",
            highlight = "Home to 1.5 million vintage bottles covered in natural noble cellar mold and historic dust.",
            relativeX = 0.50f,
            relativeY = 0.65f
        ),
        CellarArea(
            id = "tasting_halls",
            name = "Sălile de Degustare",
            streetName = "Banqueting & Tasting Halls",
            depth = "60 Meters Underground",
            description = "Carved directly into the white limestone rock, these halls are styled with local oak furniture, traditional Moldovan carpets, and water fountains.",
            highlight = "Acoustic chambers where Moldovan traditional music resonates beautifully off the stone walls.",
            relativeX = 0.75f,
            relativeY = 0.40f
        ),
        CellarArea(
            id = "sparkling_gallery",
            name = "Galeria Vinului Spumant",
            streetName = "Sparkling Wine Street",
            depth = "55 Meters Underground",
            description = "A quiet, cooler zone dedicated to the Method Champenoise. Bottles are angled in wooden pupitres and turned by hand (riddling) daily.",
            highlight = "Thousands of sparkling bottles slowly sleeping in horizontal stone corridors.",
            relativeX = 0.38f,
            relativeY = 0.82f
        )
    )
}
