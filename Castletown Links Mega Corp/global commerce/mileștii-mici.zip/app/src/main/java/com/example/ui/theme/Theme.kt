package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
  primary = DarkPrimary,
  secondary = DarkSecondary,
  tertiary = DarkTertiary,
  background = DarkBackground,
  surface = DarkSurface,
  onPrimary = DarkOnPrimary,
  onSecondary = DarkOnSecondary,
  onBackground = DarkOnBackground,
  onSurface = DarkOnSurface,
  onTertiary = DarkOnTertiary,
  surfaceVariant = DarkSurfaceVariant,
  onSurfaceVariant = DarkOnSurfaceVariant
)

@Composable
fun MyApplicationTheme(
  content: @Composable () -> Unit,
) {
  // Always use our stunning custom DarkColorScheme to preserve the premium cellar aesthetic
  MaterialTheme(
    colorScheme = DarkColorScheme,
    typography = Typography,
    content = content
  )
}
