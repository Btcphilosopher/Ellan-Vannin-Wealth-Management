package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.*
import com.example.R
import com.example.data.*
import com.example.ui.theme.CellarBurgundy
import com.example.ui.theme.DarkWineRed
import com.example.ui.theme.MutedBrass
import com.example.ui.theme.WarmLimestone

// Reusable local constant colors
val ColorAgedIvory = Color(0xFFFBF9F4)
val DarkGreySurface = Color(0xFF141212)

// ==========================================
// 1. HOME SCREEN
// ==========================================
@Composable
fun HomeScreen(viewModel: WineryViewModel) {
    val lang by viewModel.selectedLanguage.collectAsState()
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .background(Color(0xFF0F0E0E))
    ) {
        // Hero Image Section
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(420.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_cellar_hero_1790841702076),
                contentDescription = "Mileștii Mici Limestone Cellar",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )

            // Dark premium overlay
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Black.copy(alpha = 0.5f),
                                Color.Black.copy(alpha = 0.2f),
                                Color(0xFF0F0E0E)
                            )
                        )
                    )
            )

            // Content Overlay
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                verticalArrangement = Arrangement.Bottom,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "MILEȘTII MICI",
                    style = MaterialTheme.typography.displayMedium,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold,
                    color = ColorAgedIvory,
                    letterSpacing = 2.sp,
                    textAlign = TextAlign.Center
                )

                Text(
                    text = if (lang == Language.RO) "ORAȘUL SUBTERAN AL VINULUI" else "THE CELLAR BENEATH MOLDOVA",
                    style = MaterialTheme.typography.titleMedium,
                    color = MutedBrass,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 3.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 4.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = if (lang == Language.RO)
                        "Vinuri de colecție, păstrate în mod natural în galerii de calcar la o adâncime de 80 de metri."
                    else
                        "Fine Moldovan wines, preserved naturally in limestone vaults 80 meters beneath the earth.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = WarmLimestone,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.widthIn(max = 340.dp)
                )

                Spacer(modifier = Modifier.height(24.dp))

                // CTA row
                Row(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = { viewModel.navigateTo(Screen.SHOP) },
                        colors = ButtonDefaults.buttonColors(containerColor = CellarBurgundy),
                        shape = RoundedCornerShape(2.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(46.dp)
                            .testTag("hero_shop_cta")
                    ) {
                        Text(
                            text = if (lang == Language.RO) "MAGAZIN" else "SHOP COLLECTION",
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp,
                            color = ColorAgedIvory
                        )
                    }

                    OutlinedButton(
                        onClick = { viewModel.navigateTo(Screen.CELLAR) },
                        shape = RoundedCornerShape(2.dp),
                        border = BorderStroke(1.dp, MutedBrass),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MutedBrass),
                        modifier = Modifier
                            .weight(1f)
                            .height(46.dp)
                            .testTag("hero_cellar_cta")
                    ) {
                        Text(
                            text = if (lang == Language.RO) "HARTĂ CRAMĂ" else "EXPLORE CELLARS",
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Quick Navigation Tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            val navItems = listOf(
                Triple(if (lang == Language.RO) "VINURI" else "WINES", Screen.SHOP, Icons.Default.WineBar),
                Triple(if (lang == Language.RO) "COLECȚII" else "COLLECTIONS", Screen.COLLECTIONS, Icons.Default.AutoAwesome),
                Triple(if (lang == Language.RO) "CRAMĂ" else "THE CELLARS", Screen.CELLAR, Icons.Default.Map),
                Triple(if (lang == Language.RO) "VIZITEAZĂ" else "VISIT", Screen.VISIT, Icons.Default.ConfirmationNumber)
            )
            navItems.forEach { (title, screen, icon) ->
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { viewModel.navigateTo(screen) }
                        .padding(vertical = 8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .background(Color(0xFF1B1919), CircleShape)
                            .border(1.dp, MutedBrass.copy(alpha = 0.2f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = title,
                            tint = MutedBrass,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = title,
                        style = MaterialTheme.typography.labelSmall,
                        color = WarmLimestone,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        // History Section "A CITY OF WINE"
        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
            Text(
                text = if (lang == Language.RO) "O CETATE SUBTERANĂ" else "A CITY OF WINE",
                style = MaterialTheme.typography.headlineMedium,
                fontFamily = FontFamily.Serif,
                color = ColorAgedIvory,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = if (lang == Language.RO) "Istoria și legendele complexului Mileștii Mici" else "The rich history and legends of Mileștii Mici cellars",
                style = MaterialTheme.typography.bodySmall,
                color = MutedBrass,
                fontStyle = FontStyle.Italic
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Horizon stories
            WineryData.storyChapters.forEach { chapter ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF141212), shape = RoundedCornerShape(4.dp))
                        .border(1.dp, MutedBrass.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                        .padding(16.dp)
                        .padding(bottom = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = chapter.subtitle.uppercase(),
                            style = MaterialTheme.typography.labelMedium,
                            color = MutedBrass,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        if (chapter.year != null) {
                            Text(
                                text = chapter.year,
                                style = MaterialTheme.typography.titleLarge,
                                color = CellarBurgundy,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Serif
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = chapter.title,
                        style = MaterialTheme.typography.titleLarge,
                        color = ColorAgedIvory,
                        fontFamily = FontFamily.Serif
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = chapter.content,
                        style = MaterialTheme.typography.bodyMedium,
                        color = WarmLimestone.copy(alpha = 0.8f),
                        lineHeight = 20.sp
                    )
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Moldova Terroir Showcase banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { viewModel.navigateTo(Screen.MOLDOVA) }
                .padding(16.dp)
                .background(Color(0xFF1F1212), RoundedCornerShape(4.dp))
                .border(1.dp, CellarBurgundy.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                .padding(20.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (lang == Language.RO) "CODRENI TERROIR" else "MOLDOVAN HERITAGE",
                        style = MaterialTheme.typography.labelMedium,
                        color = MutedBrass,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = if (lang == Language.RO) "De Ce Calcarul?" else "Why Limestone Matters",
                        style = MaterialTheme.typography.titleLarge,
                        color = ColorAgedIvory,
                        fontFamily = FontFamily.Serif,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                    Text(
                        text = if (lang == Language.RO) "Află secretul geologic care face vinurile noastre unice." else "Discover the geological sponge secret keeping the bottles alive.",
                        style = MaterialTheme.typography.bodySmall,
                        color = WarmLimestone.copy(alpha = 0.7f),
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Icon(
                    imageVector = Icons.Default.ArrowForward,
                    contentDescription = null,
                    tint = MutedBrass,
                    modifier = Modifier.size(24.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        WineryFooter(lang = lang)
    }
}


// ==========================================
// 2. SHOP SCREEN
// ==========================================
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ShopScreen(viewModel: WineryViewModel) {
    val lang by viewModel.selectedLanguage.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val filterType by viewModel.filterType.collectAsState()
    val filterGrape by viewModel.filterGrape.collectAsState()
    val filterVintage by viewModel.filterVintage.collectAsState()
    val maxPrice by viewModel.maxPrice.collectAsState()

    BackHandler {
        viewModel.navigateBack()
    }

    // Filter logic
    val filteredWines = WineryData.wines.filter { wine ->
        val matchQuery = searchQuery.isEmpty() ||
                wine.name.contains(searchQuery, ignoreCase = true) ||
                wine.grape.contains(searchQuery, ignoreCase = true) ||
                wine.vintage.contains(searchQuery, ignoreCase = true) ||
                wine.type.contains(searchQuery, ignoreCase = true)

        val matchType = filterType == null || wine.type == filterType
        val matchGrape = filterGrape == null || wine.grape == filterGrape
        val matchVintage = filterVintage == null || wine.vintage == filterVintage
        val matchPrice = wine.price <= maxPrice

        matchQuery && matchType && matchGrape && matchVintage && matchPrice
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F0E0E))
    ) {
        // Search & Filter Header
        Column(
            modifier = Modifier
                .background(Color(0xFF070606))
                .padding(16.dp)
        ) {
            Text(
                text = if (lang == Language.RO) "COLECȚIA DE VINURI" else "THE CELLAR COLLECTION",
                style = MaterialTheme.typography.headlineMedium,
                fontFamily = FontFamily.Serif,
                color = ColorAgedIvory,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
            Text(
                text = if (lang == Language.RO) "Vinuri fine selecționate direct din adâncuri." else "Selected premium bottles straight from our subterranean tunnels.",
                style = MaterialTheme.typography.bodySmall,
                color = WarmLimestone
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Search Bar
            TextField(
                value = searchQuery,
                onValueChange = { viewModel.updateSearchQuery(it) },
                placeholder = {
                    Text(
                        text = if (lang == Language.RO) "Caută fetească, vintage 2021..." else "Search fetească, vintage 2021...",
                        color = WarmLimestone.copy(alpha = 0.5f)
                    )
                },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = MutedBrass) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear", tint = MutedBrass)
                        }
                    }
                },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color(0xFF1B1919),
                    unfocusedContainerColor = Color(0xFF1B1919),
                    focusedTextColor = ColorAgedIvory,
                    unfocusedTextColor = ColorAgedIvory,
                    cursorColor = MutedBrass,
                    focusedIndicatorColor = MutedBrass,
                    unfocusedIndicatorColor = Color.Transparent
                ),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("shop_search_input")
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Active Filter Labels or Toggles
            Text(
                text = if (lang == Language.RO) "Filtrează după tip de vin:" else "Filter by type:",
                style = MaterialTheme.typography.labelSmall,
                color = MutedBrass,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Type Filter Row
            val types = listOf("Red", "White", "Rosé", "Sparkling")
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                types.forEach { type ->
                    val isSelected = filterType == type
                    Box(
                        modifier = Modifier
                            .background(
                                color = if (isSelected) CellarBurgundy else Color(0xFF1B1919),
                                shape = RoundedCornerShape(4.dp)
                            )
                            .border(
                                width = 1.dp,
                                color = if (isSelected) MutedBrass else Color.Transparent,
                                shape = RoundedCornerShape(4.dp)
                            )
                            .clickable {
                                if (isSelected) viewModel.setFilterType(null)
                                else viewModel.setFilterType(type)
                            }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = if (lang == Language.RO) {
                                when (type) {
                                    "Red" -> "Roșu"
                                    "White" -> "Alb"
                                    "Rosé" -> "Rosé"
                                    "Sparkling" -> "Spumant"
                                    else -> type
                                }
                            } else type,
                            style = MaterialTheme.typography.labelMedium,
                            color = if (isSelected) ColorAgedIvory else WarmLimestone,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Clear filter button
            if (filterType != null || filterGrape != null || filterVintage != null || searchQuery.isNotEmpty()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = {
                        viewModel.clearFilters()
                        viewModel.updateSearchQuery("")
                    }) {
                        Text(
                            text = if (lang == Language.RO) "Resetează filtrele" else "Clear filters",
                            color = MutedBrass,
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                }
            }
        }

        // Product Grid
        if (filteredWines.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.FilterListOff,
                        contentDescription = null,
                        tint = MutedBrass.copy(alpha = 0.3f),
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = if (lang == Language.RO) "Niciun vin potrivit." else "No wines match your criteria.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = WarmLimestone
                    )
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier
                    .weight(1f)
                    .padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredWines) { wine ->
                    WineProductCard(wine = wine, lang = lang, onCardClick = {
                        viewModel.selectWine(wine.id)
                    }, onAddToCart = {
                        viewModel.addToCart(wine, 1)
                    })
                }
            }
        }
    }
}

@Composable
fun WineProductCard(
    wine: Wine,
    lang: Language,
    onCardClick: () -> Unit,
    onAddToCart: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onCardClick)
            .testTag("wine_card_${wine.id}"),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF141212)),
        shape = RoundedCornerShape(2.dp),
        border = BorderStroke(1.dp, MutedBrass.copy(alpha = 0.1f))
    ) {
        Column {
            // Picture area with Limestone overlay style
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(170.dp)
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0xFF1B1919), Color(0xFF231F1F))
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_wine_bottle_1790841720211),
                    contentDescription = wine.name,
                    modifier = Modifier
                        .fillMaxHeight()
                        .padding(vertical = 12.dp),
                    contentScale = ContentScale.Fit
                )

                // Vintage badge
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(8.dp)
                        .background(CellarBurgundy, RoundedCornerShape(2.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = wine.vintage,
                        style = MaterialTheme.typography.labelSmall,
                        color = ColorAgedIvory,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Reserve label
                if (wine.isReserve) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(8.dp)
                            .background(MutedBrass, RoundedCornerShape(2.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (lang == Language.RO) "RESERVĂ" else "RESERVE",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFF0F0E0E),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Info Area
            Column(
                modifier = Modifier
                    .padding(12.dp)
                    .fillMaxWidth()
            ) {
                Text(
                    text = wine.name.uppercase(),
                    style = MaterialTheme.typography.titleMedium,
                    fontFamily = FontFamily.Serif,
                    color = ColorAgedIvory,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = wine.grape,
                    style = MaterialTheme.typography.bodySmall,
                    color = WarmLimestone.copy(alpha = 0.7f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "€${String.format("%.2f", wine.price)}",
                        style = MaterialTheme.typography.titleMedium,
                        color = MutedBrass,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = wine.bottleSize,
                        style = MaterialTheme.typography.labelSmall,
                        color = WarmLimestone.copy(alpha = 0.5f)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        onAddToCart()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(36.dp)
                        .testTag("add_to_cart_btn_${wine.id}"),
                    colors = ButtonDefaults.buttonColors(containerColor = CellarBurgundy),
                    shape = RoundedCornerShape(2.dp),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text(
                        text = if (lang == Language.RO) "ADĂUGĂ ÎN COȘ" else "ADD TO CART",
                        style = MaterialTheme.typography.labelMedium,
                        color = ColorAgedIvory,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}


// ==========================================
// 3. PRODUCT DETAILS SCREEN
// ==========================================
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProductDetailsScreen(viewModel: WineryViewModel) {
    val lang by viewModel.selectedLanguage.collectAsState()
    val wineId by viewModel.selectedWineId.collectAsState()
    val wishlist by viewModel.wishlist.collectAsState()
    val scrollState = rememberScrollState()

    BackHandler {
        viewModel.navigateBack()
    }

    val wine = WineryData.wines.firstOrNull { it.id == wineId } ?: WineryData.wines[0]
    val isInWishlist = wishlist.contains(wine.id)

    var quantity by remember { mutableStateOf(1) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .background(Color(0xFF0F0E0E))
    ) {
        // Back navigation header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { viewModel.navigateBack() },
                modifier = Modifier.testTag("details_back")
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = MutedBrass)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = (if (lang == Language.RO) "ÎNAPOI LA COLECȚIE" else "BACK TO COLLECTION"),
                style = MaterialTheme.typography.labelLarge,
                color = MutedBrass,
                letterSpacing = 1.sp
            )
        }

        // Layout adapts beautifully
        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
            // Photo Container
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(340.dp)
                    .background(Color(0xFF141212), shape = RoundedCornerShape(4.dp))
                    .border(1.dp, MutedBrass.copy(alpha = 0.1f), RoundedCornerShape(4.dp)),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_wine_bottle_1790841720211),
                    contentDescription = wine.name,
                    modifier = Modifier
                        .fillMaxHeight()
                        .padding(24.dp),
                    contentScale = ContentScale.Fit
                )

                // Ratings Badge
                Row(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(16.dp)
                        .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(10.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Star, contentDescription = null, tint = MutedBrass, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = wine.rating.toString(),
                        style = MaterialTheme.typography.labelMedium,
                        color = ColorAgedIvory,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Main Info Panel
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = wine.name.uppercase(),
                            style = MaterialTheme.typography.displaySmall,
                            fontFamily = FontFamily.Serif,
                            color = ColorAgedIvory,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${wine.vintage} · ${wine.origin}",
                            style = MaterialTheme.typography.titleMedium,
                            color = MutedBrass,
                            fontStyle = FontStyle.Italic
                        )
                    }

                    // Wishlist Icon toggler
                    IconButton(
                        onClick = { viewModel.toggleWishlist(wine.id) },
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("wishlist_toggle_details")
                    ) {
                        Icon(
                            imageVector = if (isInWishlist) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                            contentDescription = "Save",
                            tint = if (isInWishlist) CellarBurgundy else MutedBrass,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Price display
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "€${String.format("%.2f", wine.price)}",
                        style = MaterialTheme.typography.displaySmall,
                        color = MutedBrass,
                        fontWeight = FontWeight.Bold
                    )

                    // Bottle technical detail tags
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Box(
                            modifier = Modifier
                                .background(Color(0xFF1F1212), RoundedCornerShape(4.dp))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(text = wine.bottleSize, color = WarmLimestone, style = MaterialTheme.typography.labelSmall)
                        }
                        Box(
                            modifier = Modifier
                                .background(Color(0xFF1B1919), RoundedCornerShape(4.dp))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(text = wine.abv, color = WarmLimestone, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Divider(color = MutedBrass.copy(alpha = 0.15f))
                Spacer(modifier = Modifier.height(16.dp))

                // Description
                Text(
                    text = wine.description,
                    style = MaterialTheme.typography.bodyLarge,
                    color = WarmLimestone.copy(alpha = 0.9f),
                    lineHeight = 24.sp
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Quantity selector & Add to Cart
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Qty box
                    Row(
                        modifier = Modifier
                            .background(Color(0xFF141212), RoundedCornerShape(4.dp))
                            .border(1.dp, MutedBrass.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { if (quantity > 1) quantity-- },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.Default.Remove, contentDescription = "Minus", tint = MutedBrass)
                        }
                        Text(
                            text = quantity.toString(),
                            style = MaterialTheme.typography.titleMedium,
                            color = ColorAgedIvory,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.widthIn(min = 24.dp),
                            textAlign = TextAlign.Center
                        )
                        IconButton(
                            onClick = { quantity++ },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Plus", tint = MutedBrass)
                        }
                    }

                    // Secure order trigger button
                    Button(
                        onClick = {
                            viewModel.addToCart(wine, quantity)
                            viewModel.setCartOpen(true) // Open the drawer directly!
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("add_to_cart_details"),
                        colors = ButtonDefaults.buttonColors(containerColor = CellarBurgundy),
                        shape = RoundedCornerShape(2.dp)
                    ) {
                        Text(
                            text = if (lang == Language.RO) "ADAUGĂ ÎN COȘ — €${String.format("%.2f", wine.price * quantity)}" else "ADD TO CART — €${String.format("%.2f", wine.price * quantity)}",
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp,
                            color = ColorAgedIvory
                        )
                    }
                }

                Spacer(modifier = Modifier.height(32.dp))

                // TECHNICAL DETAILS PANEL (Tasting & Serving)
                Text(
                    text = if (lang == Language.RO) "FIȘĂ TEHNICĂ" else "WINE SPECIFICATIONS",
                    style = MaterialTheme.typography.titleLarge,
                    fontFamily = FontFamily.Serif,
                    color = ColorAgedIvory,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Tasting Notes sub-grid
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF141212), shape = RoundedCornerShape(4.dp))
                        .border(1.dp, MutedBrass.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Column {
                        Text(text = if (lang == Language.RO) "AROMĂ (Aroma)" else "AROMA NOTES", style = MaterialTheme.typography.labelSmall, color = MutedBrass, fontWeight = FontWeight.Bold)
                        Text(text = wine.aroma, style = MaterialTheme.typography.bodyMedium, color = WarmLimestone)
                    }
                    Divider(color = MutedBrass.copy(alpha = 0.1f))
                    Column {
                        Text(text = if (lang == Language.RO) "PALAT (Palate)" else "PALATE CHARACTER", style = MaterialTheme.typography.labelSmall, color = MutedBrass, fontWeight = FontWeight.Bold)
                        Text(text = wine.palate, style = MaterialTheme.typography.bodyMedium, color = WarmLimestone)
                    }
                    Divider(color = MutedBrass.copy(alpha = 0.1f))
                    Column {
                        Text(text = if (lang == Language.RO) "POST-GUST (Finish)" else "FINISH", style = MaterialTheme.typography.labelSmall, color = MutedBrass, fontWeight = FontWeight.Bold)
                        Text(text = wine.finish, style = MaterialTheme.typography.bodyMedium, color = WarmLimestone)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Serving Instructions
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF1B1B15), shape = RoundedCornerShape(4.dp))
                        .border(1.dp, MutedBrass.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                        .padding(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Thermostat, contentDescription = null, tint = MutedBrass, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = if (lang == Language.RO) "TEMPERATURA DE SERVIRE" else "SERVING TEMPERATURE",
                                style = MaterialTheme.typography.labelSmall,
                                color = MutedBrass,
                                fontWeight = FontWeight.Bold
                            )
                            Text(text = wine.servingTemp, style = MaterialTheme.typography.bodyMedium, color = ColorAgedIvory, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Divider(color = MutedBrass.copy(alpha = 0.1f))
                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = if (lang == Language.RO) "RECOMANDĂRI GASTRONOMICE" else "FOOD PAIRING RECOMMENDATIONS",
                        style = MaterialTheme.typography.labelSmall,
                        color = MutedBrass,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    wine.foodPairings.forEach { pairing ->
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
                            Icon(imageVector = Icons.Default.Restaurant, contentDescription = null, tint = MutedBrass, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = pairing, style = MaterialTheme.typography.bodyMedium, color = WarmLimestone)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(32.dp))
        WineryFooter(lang = lang)
    }
}


// ==========================================
// 4. COLLECTIONS & GIFT SETS SCREEN
// ==========================================
@Composable
fun CollectionsScreen(viewModel: WineryViewModel) {
    val lang by viewModel.selectedLanguage.collectAsState()
    val scrollState = rememberScrollState()

    BackHandler {
        viewModel.navigateBack()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .background(Color(0xFF0F0E0E))
    ) {
        // Banner Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .background(Color(0xFF141212)),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_cellar_hero_1790841702076),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.7f))
            )
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = if (lang == Language.RO) "COLECȚII CURATE" else "CURATED COLLECTIONS",
                    style = MaterialTheme.typography.headlineLarge,
                    fontFamily = FontFamily.Serif,
                    color = ColorAgedIvory,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = if (lang == Language.RO) "Selecții speciale din pivniță" else "Exquisite box sets and collection themes",
                    style = MaterialTheme.typography.bodySmall,
                    color = MutedBrass,
                    fontStyle = FontStyle.Italic
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Curated Collections display
        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
            WineryData.collections.forEach { coll ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 28.dp)
                        .background(Color(0xFF141212), shape = RoundedCornerShape(4.dp))
                        .border(1.dp, MutedBrass.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                        .padding(20.dp)
                ) {
                    Text(
                        text = coll.motto,
                        style = MaterialTheme.typography.labelSmall,
                        color = MutedBrass,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    )
                    Text(
                        text = coll.name,
                        style = MaterialTheme.typography.titleLarge,
                        fontFamily = FontFamily.Serif,
                        color = ColorAgedIvory,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                    Text(
                        text = coll.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = WarmLimestone.copy(alpha = 0.8f),
                        modifier = Modifier.padding(top = 8.dp),
                        lineHeight = 20.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Horizontal carousel of wines in this collection
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        val matchingWines = WineryData.wines.filter { it.id in coll.wineIds }
                        items(matchingWines) { wine ->
                            Box(
                                modifier = Modifier
                                    .width(180.dp)
                                    .background(Color(0xFF1F1B1B), RoundedCornerShape(4.dp))
                                    .border(1.dp, MutedBrass.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                                    .clickable { viewModel.selectWine(wine.id) }
                                    .padding(12.dp)
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(100.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Image(
                                            painter = painterResource(id = R.drawable.img_wine_bottle_1790841720211),
                                            contentDescription = null,
                                            modifier = Modifier.fillMaxHeight(),
                                            contentScale = ContentScale.Fit
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = wine.name,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = ColorAgedIvory,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = wine.vintage,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MutedBrass
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "€${wine.price}",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MutedBrass,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        Divider(color = MutedBrass.copy(alpha = 0.15f), modifier = Modifier.padding(horizontal = 16.dp))
        Spacer(modifier = Modifier.height(24.dp))

        // SECTION: GIFT BOXES
        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
            Text(
                text = if (lang == Language.RO) "CADOURI PREMIUM" else "LUXURY GIFT CHESTS",
                style = MaterialTheme.typography.headlineMedium,
                fontFamily = FontFamily.Serif,
                color = ColorAgedIvory,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = if (lang == Language.RO) "Ambalate în cutii din lemn sculptat cu fitinguri din alamă." else "Crafted wooden boxes and custom presentation configurations.",
                style = MaterialTheme.typography.bodySmall,
                color = MutedBrass
            )

            Spacer(modifier = Modifier.height(16.dp))

            WineryData.giftBoxes.forEach { box ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 20.dp)
                        .background(Color(0xFF141212), shape = RoundedCornerShape(4.dp))
                        .border(1.dp, MutedBrass.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = box.name.uppercase(),
                            style = MaterialTheme.typography.titleLarge,
                            fontFamily = FontFamily.Serif,
                            color = ColorAgedIvory,
                            fontWeight = FontWeight.Bold
                        )
                        Icon(imageVector = Icons.Default.CardGiftcard, contentDescription = null, tint = MutedBrass)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = box.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = WarmLimestone.copy(alpha = 0.8f),
                        lineHeight = 20.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // List wines included
                    Text(
                        text = (if (lang == Language.RO) "Include:" else "Includes:"),
                        style = MaterialTheme.typography.labelSmall,
                        color = MutedBrass,
                        fontWeight = FontWeight.Bold
                    )
                    box.winesIncluded.forEach { wName ->
                        Text(
                            text = " · $wName",
                            style = MaterialTheme.typography.bodyMedium,
                            color = WarmLimestone
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "€${box.price}",
                            style = MaterialTheme.typography.headlineSmall,
                            color = MutedBrass,
                            fontWeight = FontWeight.Bold
                        )

                        Button(
                            onClick = {
                                viewModel.addGiftBoxToCart(box)
                                viewModel.setCartOpen(true)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CellarBurgundy),
                            shape = RoundedCornerShape(2.dp)
                        ) {
                            Text(
                                text = if (lang == Language.RO) "+ ADAUGĂ CADOU" else "+ ADD GIFT SET",
                                style = MaterialTheme.typography.labelMedium,
                                color = ColorAgedIvory,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        WineryFooter(lang = lang)
    }
}


// ==========================================
// 5. INTERACTIVE CELLAR MAP SCREEN
// ==========================================
@Composable
fun CellarMapScreen(viewModel: WineryViewModel) {
    val lang by viewModel.selectedLanguage.collectAsState()
    var selectedArea by remember { mutableStateOf<CellarArea?>(WineryData.cellarAreas[1]) }

    BackHandler {
        viewModel.navigateBack()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F0E0E))
    ) {
        // Map Title Header
        Column(
            modifier = Modifier
                .background(Color(0xFF070606))
                .padding(16.dp)
        ) {
            Text(
                text = if (lang == Language.RO) "HARTA CRĂMII SUBTERANE" else "SUBTERAN RECORDIAN MAP",
                style = MaterialTheme.typography.headlineMedium,
                fontFamily = FontFamily.Serif,
                color = ColorAgedIvory,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = if (lang == Language.RO) "Interacționează cu străzile din pivniță sculptate în piatră." else "Interactive architectural representation of the limestone corridors.",
                style = MaterialTheme.typography.bodySmall,
                color = WarmLimestone
            )
        }

        // Draw Interactive Architectural Diagram using Canvas
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(Color(0xFF0A0909))
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp)
            ) {
                val canvasWidth = size.width
                val canvasHeight = size.height

                // Draw limestone layout tunnel roads (curved paths)
                val path1 = Path().apply {
                    moveTo(canvasWidth * 0.1f, canvasHeight * 0.2f)
                    quadraticTo(canvasWidth * 0.4f, canvasHeight * 0.15f, canvasWidth * 0.8f, canvasHeight * 0.35f)
                    quadraticTo(canvasWidth * 0.9f, canvasHeight * 0.6f, canvasWidth * 0.5f, canvasHeight * 0.8f)
                    quadraticTo(canvasWidth * 0.2f, canvasHeight * 0.9f, canvasWidth * 0.15f, canvasHeight * 0.5f)
                    close()
                }

                val path2 = Path().apply {
                    moveTo(canvasWidth * 0.3f, canvasHeight * 0.4f)
                    lineTo(canvasWidth * 0.7f, canvasHeight * 0.4f)
                    lineTo(canvasWidth * 0.7f, canvasHeight * 0.7f)
                    lineTo(canvasWidth * 0.3f, canvasHeight * 0.7f)
                    close()
                }

                // Draw Tunnels
                drawPath(
                    path = path1,
                    color = MutedBrass.copy(alpha = 0.25f),
                    style = Stroke(width = 4.dp.toPx())
                )
                drawPath(
                    path = path2,
                    color = CellarBurgundy.copy(alpha = 0.25f),
                    style = Stroke(width = 3.dp.toPx())
                )

                // Grid ticks mimicking blueprints
                val tickStepX = canvasWidth / 8
                val tickStepY = canvasHeight / 8
                for (i in 1..7) {
                    drawLine(
                        color = MutedBrass.copy(alpha = 0.05f),
                        start = Offset(tickStepX * i, 0f),
                        end = Offset(tickStepX * i, canvasHeight),
                        strokeWidth = 1f
                    )
                    drawLine(
                        color = MutedBrass.copy(alpha = 0.05f),
                        start = Offset(0f, tickStepY * i),
                        end = Offset(canvasWidth, tickStepY * i),
                        strokeWidth = 1f
                    )
                }
            }

            // Overlay active interactive pins
            WineryData.cellarAreas.forEach { area ->
                val isSelected = selectedArea?.id == area.id
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp)
                ) {
                    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                        val xPos = maxWidth * area.relativeX
                        val yPos = maxHeight * area.relativeY

                        Box(
                            modifier = Modifier
                                .offset(x = xPos - 20.dp, y = yPos - 20.dp)
                                .size(40.dp)
                                .background(
                                    if (isSelected) CellarBurgundy else Color(0xFF1B1919),
                                    shape = CircleShape
                                )
                                .border(
                                    width = 2.dp,
                                    color = if (isSelected) MutedBrass else MutedBrass.copy(alpha = 0.4f),
                                    shape = CircleShape
                                )
                                .clickable { selectedArea = area }
                                .testTag("map_pin_${area.id}"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isSelected) Icons.Default.LocationOn else Icons.Outlined.WineBar,
                                contentDescription = area.name,
                                tint = if (isSelected) ColorAgedIvory else MutedBrass,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }

        // Selected Area Information Board
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF141212))
                .border(BorderStroke(1.dp, MutedBrass.copy(alpha = 0.2f)))
                .padding(20.dp)
                .testTag("map_info_panel")
        ) {
            selectedArea?.let { area ->
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = area.name.uppercase(),
                                style = MaterialTheme.typography.titleMedium,
                                color = ColorAgedIvory,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Serif
                            )
                            Text(
                                text = area.streetName,
                                style = MaterialTheme.typography.labelSmall,
                                color = MutedBrass,
                                letterSpacing = 1.sp
                            )
                        }

                        Box(
                            modifier = Modifier
                                .background(Color(0xFF1B1919), RoundedCornerShape(4.dp))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(text = area.depth, color = WarmLimestone, style = MaterialTheme.typography.labelSmall)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = area.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = WarmLimestone.copy(alpha = 0.9f),
                        lineHeight = 20.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Divider(color = MutedBrass.copy(alpha = 0.1f))
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = MutedBrass, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = area.highlight,
                            style = MaterialTheme.typography.bodySmall,
                            color = MutedBrass,
                            fontStyle = FontStyle.Italic
                        )
                    }
                }
            }
        }
    }
}


// ==========================================
// 6. VISIT & TOURS SCREEN
// ==========================================
@Composable
fun VisitScreen(viewModel: WineryViewModel) {
    val lang by viewModel.selectedLanguage.collectAsState()
    val scrollState = rememberScrollState()
    val bookings by viewModel.bookings.collectAsState()

    var showSuccessDialog by remember { mutableStateOf(false) }
    var selectedTourName by remember { mutableStateOf("") }

    BackHandler {
        viewModel.navigateBack()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .background(Color(0xFF0F0E0E))
    ) {
        // Banner Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_cellar_hero_1790841702076),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.7f))
            )
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = if (lang == Language.RO) "VIZITEAZĂ CRAMA" else "VISIT MILEȘTII MICI",
                    style = MaterialTheme.typography.headlineLarge,
                    fontFamily = FontFamily.Serif,
                    color = ColorAgedIvory,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (lang == Language.RO) "Planifică o călătorie legendară în adâncuri" else "Book an extraordinary underground journey",
                    style = MaterialTheme.typography.bodySmall,
                    color = MutedBrass,
                    fontStyle = FontStyle.Italic
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Bookings state list if any
        if (bookings.isNotEmpty()) {
            Column(
                modifier = Modifier
                    .padding(horizontal = 16.dp)
                    .fillMaxWidth()
                    .background(Color(0xFF1B1B15), shape = RoundedCornerShape(4.dp))
                    .border(1.dp, MutedBrass.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
                    .padding(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Event, contentDescription = null, tint = MutedBrass)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (lang == Language.RO) "REZERVĂRI ACTIVE" else "YOUR ACTIVE BOOKINGS",
                        style = MaterialTheme.typography.titleMedium,
                        color = ColorAgedIvory,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
                bookings.forEach { tour ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = tour.name, style = MaterialTheme.typography.bodyMedium, color = ColorAgedIvory, fontWeight = FontWeight.Bold)
                            Text(text = "Scheduled · ${tour.availability}", style = MaterialTheme.typography.bodySmall, color = WarmLimestone)
                        }
                        IconButton(onClick = { viewModel.cancelBooking(tour) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Cancel", tint = Color.Red.copy(alpha = 0.7f))
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }

        // Tour selections
        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
            Text(
                text = if (lang == Language.RO) "TURURI GHIDATE" else "SELECT AN EXPERIENCE",
                style = MaterialTheme.typography.titleLarge,
                fontFamily = FontFamily.Serif,
                color = ColorAgedIvory,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(16.dp))

            WineryData.tours.forEach { tour ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 20.dp)
                        .background(Color(0xFF141212), shape = RoundedCornerShape(4.dp))
                        .border(1.dp, MutedBrass.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                        .padding(20.dp)
                ) {
                    Text(
                        text = tour.name.uppercase(),
                        style = MaterialTheme.typography.titleMedium,
                        color = ColorAgedIvory,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = tour.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = WarmLimestone.copy(alpha = 0.8f),
                        lineHeight = 20.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Duration, languages, availability tags
                    Column(
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF1B1919), RoundedCornerShape(2.dp))
                            .padding(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Schedule, contentDescription = null, tint = MutedBrass, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = "Duration: ${tour.duration}", style = MaterialTheme.typography.bodySmall, color = WarmLimestone)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Language, contentDescription = null, tint = MutedBrass, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = "Languages: ${tour.languages.joinToString(", ")}", style = MaterialTheme.typography.bodySmall, color = WarmLimestone)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.CalendarMonth, contentDescription = null, tint = MutedBrass, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = "Availability: ${tour.availability}", style = MaterialTheme.typography.bodySmall, color = WarmLimestone)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "€${tour.price} / person",
                            style = MaterialTheme.typography.titleMedium,
                            color = MutedBrass,
                            fontWeight = FontWeight.Bold
                        )

                        val isBooked = bookings.contains(tour)
                        Button(
                            onClick = {
                                if (!isBooked) {
                                    viewModel.bookTour(tour)
                                    selectedTourName = tour.name
                                    showSuccessDialog = true
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isBooked) Color(0xFF1B1919) else CellarBurgundy
                            ),
                            shape = RoundedCornerShape(2.dp),
                            enabled = !isBooked,
                            modifier = Modifier.testTag("book_btn_${tour.id}")
                        ) {
                            Text(
                                text = if (isBooked)
                                    (if (lang == Language.RO) "REZERVAT" else "BOOKED")
                                else
                                    (if (lang == Language.RO) "REZERVEAZĂ" else "PLAN VISIT"),
                                fontWeight = FontWeight.Bold,
                                color = if (isBooked) WarmLimestone.copy(alpha = 0.5f) else ColorAgedIvory
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        WineryFooter(lang = lang)
    }

    // Success dialog
    if (showSuccessDialog) {
        AlertDialog(
            onDismissRequest = { showSuccessDialog = false },
            title = {
                Text(
                    text = if (lang == Language.RO) "TUR REZERVAT!" else "TOUR BOOKED!",
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold,
                    color = MutedBrass
                )
            },
            text = {
                Text(
                    text = if (lang == Language.RO)
                        "Rezervarea dumneavoastră pentru '$selectedTourName' a fost trimisă cu succes. Detaliile booking-ului și instrucțiunile de vizită au fost salvate în cont."
                    else
                        "Your reservation for '$selectedTourName' was registered. Booking details and cellar entry instructions have been saved.",
                    color = WarmLimestone
                )
            },
            confirmButton = {
                TextButton(onClick = { showSuccessDialog = false }) {
                    Text(text = "OK", color = MutedBrass, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color(0xFF141212),
            textContentColor = WarmLimestone
        )
    }
}


// ==========================================
// 7. MOLDOVA EDITORIAL SCREEN
// ==========================================
@Composable
fun MoldovaScreen(viewModel: WineryViewModel) {
    val lang by viewModel.selectedLanguage.collectAsState()
    val scrollState = rememberScrollState()

    BackHandler {
        viewModel.navigateBack()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .background(Color(0xFF0F0E0E))
    ) {
        // Hero Photo header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(240.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_cellar_hero_1790841702076),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color.Black.copy(alpha = 0.7f), Color(0xFF0F0E0E))
                        )
                    )
            )
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                verticalArrangement = Arrangement.Bottom
            ) {
                Text(
                    text = if (lang == Language.RO) "MOLDOVA" else "FROM MOLDOVA WITH PRIDE",
                    style = MaterialTheme.typography.labelSmall,
                    color = MutedBrass,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 3.sp
                )
                Text(
                    text = if (lang == Language.RO) "Legenda Terroir-ului" else "The Terroir of Legend",
                    style = MaterialTheme.typography.displayMedium,
                    fontFamily = FontFamily.Serif,
                    color = ColorAgedIvory,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
            Text(
                text = if (lang == Language.RO) "DE CE CLIMATUL DIN SUBTERAN?" else "THE GEOLOGY OF MILEȘTII MICI",
                style = MaterialTheme.typography.titleLarge,
                fontFamily = FontFamily.Serif,
                color = MutedBrass,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = if (lang == Language.RO)
                    "Moldova are o tradiție viticolă de peste 5000 de ani. Solul cernoziom bogat, combinat cu clima caldă temperat-continentală, oferă condiții perfecte pentru struguri. Totuși, secretul conservării pe termen lung rezidă în structura geologică unică din Mileștii Mici."
                else
                    "Moldova holds over 5,000 years of active winemaking tradition. The rich black soil (chernozem) combined with a moderate continental climate provides perfect grape growing conditions. However, the secret of long-term aging lies inside the unique geological structure of Mileștii Mici.",
                style = MaterialTheme.typography.bodyLarge,
                color = WarmLimestone,
                lineHeight = 24.sp
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Subsections on limestone & tradition
            val points = listOf(
                Pair(
                    if (lang == Language.RO) "Sponge de Calcar" else "Limestone Climate Sponge",
                    if (lang == Language.RO) "Pereții naturali de calcar absoarb umezeala de prisos și o eliberează când aerul devine uscat, menținând un raport perfect de 85-95%." else "Natural porous white limestone walls absorb excessive humidity and release it back as the air dries, locking a perfect natural 85-95% relative ratio."
                ),
                Pair(
                    if (lang == Language.RO) "Soiuri Autohtone" else "Indigenous Grape Varieties",
                    if (lang == Language.RO) "Struguri legendar precum Feteasca Neagră, Feteasca Albă, Rara Neagră creează arome unice de prune afumate, ierburi sălbatice și flori de salcâm." else "Legendary local grapes like Feteasca Neagră and Feteasca Albă establish unmatched flavor notes of dark smoked plums, wild country herbs, and sweet acacia."
                ),
                Pair(
                    if (lang == Language.RO) "Colecția de Aur Record" else "The Guinness Vault Heritage",
                    if (lang == Language.RO) "Niciun alt loc de pe pământ nu posedă o asemenea concentrare de vinuri istorice sub pământ, catalogate sticlă cu sticlă." else "No other place on earth controls such deep historical wine assets catalogued bottle by bottle in underground stone streets."
                )
            )

            points.forEach { (title, desc) ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                        .background(Color(0xFF141212), shape = RoundedCornerShape(4.dp))
                        .padding(16.dp)
                ) {
                    Text(text = title, style = MaterialTheme.typography.titleMedium, color = ColorAgedIvory, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = desc, style = MaterialTheme.typography.bodyMedium, color = WarmLimestone.copy(alpha = 0.8f), lineHeight = 20.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        WineryFooter(lang = lang)
    }
}


// ==========================================
// 8. WISHLIST SCREEN
// ==========================================
@Composable
fun WishlistScreen(viewModel: WineryViewModel) {
    val lang by viewModel.selectedLanguage.collectAsState()
    val wishlist by viewModel.wishlist.collectAsState()

    BackHandler {
        viewModel.navigateBack()
    }

    val savedWines = WineryData.wines.filter { it.id in wishlist }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F0E0E))
    ) {
        Column(
            modifier = Modifier
                .background(Color(0xFF070606))
                .padding(16.dp)
        ) {
            Text(
                text = if (lang == Language.RO) "VINURI SALVATE" else "YOUR WISHLIST",
                style = MaterialTheme.typography.headlineMedium,
                fontFamily = FontFamily.Serif,
                color = ColorAgedIvory,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = if (lang == Language.RO) "Sticlele tale preferate din cramă." else "Your selected premium bottles saved to your cellar.",
                style = MaterialTheme.typography.bodySmall,
                color = WarmLimestone
            )
        }

        if (savedWines.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Outlined.FavoriteBorder,
                        contentDescription = null,
                        tint = MutedBrass.copy(alpha = 0.3f),
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = if (lang == Language.RO) "Niciun vin salvat încă." else "Your wishlist is empty.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = WarmLimestone
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (lang == Language.RO) "Apasă pe inimă pe pagina produsului." else "Tap the heart icon on any product page to save it.",
                        style = MaterialTheme.typography.bodySmall,
                        color = WarmLimestone.copy(alpha = 0.5f)
                    )
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier
                    .weight(1f)
                    .padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(savedWines) { wine ->
                    WineProductCard(wine = wine, lang = lang, onCardClick = {
                        viewModel.selectWine(wine.id)
                    }, onAddToCart = {
                        viewModel.addToCart(wine, 1)
                    })
                }
            }
        }
    }
}


// ==========================================
// 9. ACCOUNT SCREEN
// ==========================================
@Composable
fun AccountScreen(viewModel: WineryViewModel) {
    val lang by viewModel.selectedLanguage.collectAsState()
    val orders by viewModel.orders.collectAsState()
    val scrollState = rememberScrollState()

    BackHandler {
        viewModel.navigateBack()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .background(Color(0xFF0F0E0E))
    ) {
        // Account Dashboard Header
        Column(
            modifier = Modifier
                .background(Color(0xFF070606))
                .padding(24.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .background(CellarBurgundy, CircleShape)
                    .border(2.dp, MutedBrass, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "MM",
                    style = MaterialTheme.typography.headlineLarge,
                    color = ColorAgedIvory,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Elite Collector",
                style = MaterialTheme.typography.titleLarge,
                color = ColorAgedIvory,
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "collector@milestiimici.com",
                style = MaterialTheme.typography.bodySmall,
                color = MutedBrass
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Orders section
        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
            Text(
                text = if (lang == Language.RO) "ISTORIC COMENZI" else "ORDER HISTORY",
                style = MaterialTheme.typography.titleLarge,
                fontFamily = FontFamily.Serif,
                color = ColorAgedIvory,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(12.dp))

            orders.forEach { order ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                        .background(Color(0xFF141212), shape = RoundedCornerShape(4.dp))
                        .border(1.dp, MutedBrass.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = order.orderId, style = MaterialTheme.typography.bodyMedium, color = ColorAgedIvory, fontWeight = FontWeight.Bold)
                            Text(text = order.date, style = MaterialTheme.typography.bodySmall, color = WarmLimestone)
                        }

                        // Status Badge
                        Box(
                            modifier = Modifier
                                .background(
                                    if (order.status == "Delivered") Color(0xFF1B2B20) else Color(0xFF262121),
                                    RoundedCornerShape(4.dp)
                                )
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = order.status,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (order.status == "Delivered") Color.Green else MutedBrass,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Divider(color = MutedBrass.copy(alpha = 0.1f))
                    Spacer(modifier = Modifier.height(12.dp))

                    // Items brief
                    order.items.forEach { item ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "${item.wine.name} x ${item.quantity}", style = MaterialTheme.typography.bodyMedium, color = WarmLimestone)
                            Text(text = "€${String.format("%.2f", item.wine.price * item.quantity)}", style = MaterialTheme.typography.bodyMedium, color = ColorAgedIvory)
                        }
                    }
                    order.giftBoxes.forEach { item ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "${item.giftBox.name} x ${item.quantity}", style = MaterialTheme.typography.bodyMedium, color = WarmLimestone)
                            Text(text = "€${String.format("%.2f", item.giftBox.price * item.quantity)}", style = MaterialTheme.typography.bodyMedium, color = ColorAgedIvory)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Divider(color = MutedBrass.copy(alpha = 0.1f))
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = if (lang == Language.RO) "Total (incl. livrare)" else "Total (incl. shipping)", style = MaterialTheme.typography.bodyMedium, color = MutedBrass, fontWeight = FontWeight.Bold)
                        Text(text = "€${String.format("%.2f", order.total)}", style = MaterialTheme.typography.bodyMedium, color = MutedBrass, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        WineryFooter(lang = lang)
    }
}


// ==========================================
// 10. CHECKOUT SCREEN (Delivery & Payment Steps)
// ==========================================
@Composable
fun CheckoutScreen(viewModel: WineryViewModel) {
    val lang by viewModel.selectedLanguage.collectAsState()
    val step by viewModel.checkoutStep.collectAsState()
    val deliveryInfo by viewModel.deliveryInfo.collectAsState()
    val paymentInfo by viewModel.paymentInfo.collectAsState()
    val subtotal = viewModel.getSubtotal()
    val shipping = viewModel.getShippingCost()
    val total = subtotal + shipping

    val scrollState = rememberScrollState()

    BackHandler {
        if (step > 1) {
            viewModel.setCheckoutStep(step - 1)
        } else {
            viewModel.navigateBack()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .background(Color(0xFF0F0E0E))
    ) {
        // Checkout Header
        Column(
            modifier = Modifier
                .background(Color(0xFF070606))
                .padding(16.dp)
        ) {
            Text(
                text = if (lang == Language.RO) "FINALIZARE COMANDĂ" else "SECURE CHECKOUT",
                style = MaterialTheme.typography.headlineMedium,
                fontFamily = FontFamily.Serif,
                color = ColorAgedIvory,
                fontWeight = FontWeight.Bold
            )
            Row(
                modifier = Modifier.padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = if (lang == Language.RO) "1. DETALII LIVRARE" else "1. DELIVERY DETAILS",
                    color = if (step == 1) MutedBrass else WarmLimestone.copy(alpha = 0.5f),
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.labelMedium
                )
                Text(
                    text = "→",
                    color = WarmLimestone.copy(alpha = 0.5f)
                )
                Text(
                    text = if (lang == Language.RO) "2. PLATĂ securizată" else "2. PAYMENT SECURITY",
                    color = if (step == 2) MutedBrass else WarmLimestone.copy(alpha = 0.5f),
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.labelMedium
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
            if (step == 1) {
                // STEP 1: DELIVERY FORM
                Text(
                    text = if (lang == Language.RO) "ADRESA DE LIVRARE" else "SHIPPING DESTINATION",
                    style = MaterialTheme.typography.titleMedium,
                    color = ColorAgedIvory,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Input fields
                WineryTextField(
                    value = deliveryInfo.name,
                    onValueChange = { viewModel.updateDeliveryInfo(deliveryInfo.copy(name = it)) },
                    label = if (lang == Language.RO) "Nume Complet" else "Full Name",
                    testTag = "checkout_name"
                )
                WineryTextField(
                    value = deliveryInfo.address,
                    onValueChange = { viewModel.updateDeliveryInfo(deliveryInfo.copy(address = it)) },
                    label = if (lang == Language.RO) "Adresă stradă" else "Street Address",
                    testTag = "checkout_address"
                )
                WineryTextField(
                    value = deliveryInfo.city,
                    onValueChange = { viewModel.updateDeliveryInfo(deliveryInfo.copy(city = it)) },
                    label = if (lang == Language.RO) "Oraș" else "City",
                    testTag = "checkout_city"
                )
                WineryTextField(
                    value = deliveryInfo.postcode,
                    onValueChange = { viewModel.updateDeliveryInfo(deliveryInfo.copy(postcode = it)) },
                    label = if (lang == Language.RO) "Cod Poștal" else "Postcode",
                    keyboardType = KeyboardType.Number,
                    testTag = "checkout_postcode"
                )
                WineryTextField(
                    value = deliveryInfo.phone,
                    onValueChange = { viewModel.updateDeliveryInfo(deliveryInfo.copy(phone = it)) },
                    label = if (lang == Language.RO) "Număr Telefon" else "Phone Number",
                    keyboardType = KeyboardType.Phone,
                    testTag = "checkout_phone"
                )
                WineryTextField(
                    value = deliveryInfo.email,
                    onValueChange = { viewModel.updateDeliveryInfo(deliveryInfo.copy(email = it)) },
                    label = "Email",
                    keyboardType = KeyboardType.Email,
                    testTag = "checkout_email"
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Shipping options
                Text(
                    text = if (lang == Language.RO) "OPȚIUNE EXPEDIERE" else "SHIPPING METHOD",
                    style = MaterialTheme.typography.labelSmall,
                    color = MutedBrass,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(
                                if (deliveryInfo.shippingType == "Standard") Color(0xFF1B1B15) else Color(0xFF141212),
                                shape = RoundedCornerShape(4.dp)
                            )
                            .border(
                                1.dp,
                                if (deliveryInfo.shippingType == "Standard") MutedBrass else Color.Transparent,
                                RoundedCornerShape(4.dp)
                            )
                            .clickable { viewModel.updateDeliveryInfo(deliveryInfo.copy(shippingType = "Standard")) }
                            .padding(12.dp)
                    ) {
                        Column {
                            Text(text = "Standard", style = MaterialTheme.typography.bodyMedium, color = ColorAgedIvory, fontWeight = FontWeight.Bold)
                            Text(text = "3-5 days · €8.00", style = MaterialTheme.typography.bodySmall, color = WarmLimestone)
                        }
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(
                                if (deliveryInfo.shippingType == "Express") Color(0xFF1B1B15) else Color(0xFF141212),
                                shape = RoundedCornerShape(4.dp)
                            )
                            .border(
                                1.dp,
                                if (deliveryInfo.shippingType == "Express") MutedBrass else Color.Transparent,
                                RoundedCornerShape(4.dp)
                            )
                            .clickable { viewModel.updateDeliveryInfo(deliveryInfo.copy(shippingType = "Express")) }
                            .padding(12.dp)
                    ) {
                        Column {
                            Text(text = "Express", style = MaterialTheme.typography.bodyMedium, color = ColorAgedIvory, fontWeight = FontWeight.Bold)
                            Text(text = "Next day · €15.00", style = MaterialTheme.typography.bodySmall, color = WarmLimestone)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(32.dp))

                Button(
                    onClick = {
                        if (deliveryInfo.name.isNotEmpty() && deliveryInfo.address.isNotEmpty()) {
                            viewModel.setCheckoutStep(2)
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("checkout_continue_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = CellarBurgundy),
                    shape = RoundedCornerShape(2.dp),
                    enabled = deliveryInfo.name.isNotEmpty() && deliveryInfo.address.isNotEmpty()
                ) {
                    Text(
                        text = if (lang == Language.RO) "CONTINUĂ SPRE PLATĂ" else "CONTINUE TO PAYMENT",
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        color = ColorAgedIvory
                    )
                }

            } else if (step == 2) {
                // STEP 2: SECURE PAYMENT FORM
                Text(
                    text = if (lang == Language.RO) "DETALII PLATĂ SECURIZATĂ" else "SECURE PAYMENT PROTOCOL",
                    style = MaterialTheme.typography.titleMedium,
                    color = ColorAgedIvory,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Payment alternatives
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val pTypes = listOf("Visa", "Mastercard", "Apple Pay", "Google Pay")
                    pTypes.forEach { pt ->
                        val isSel = paymentInfo.cardType == pt
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(
                                    if (isSel) Color(0xFF1B1B15) else Color(0xFF141212),
                                    shape = RoundedCornerShape(4.dp)
                                )
                                .border(
                                    1.dp,
                                    if (isSel) MutedBrass else Color.Transparent,
                                    RoundedCornerShape(4.dp)
                                )
                                .clickable { viewModel.updatePaymentInfo(paymentInfo.copy(cardType = pt)) }
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = pt,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isSel) ColorAgedIvory else WarmLimestone.copy(alpha = 0.6f),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                WineryTextField(
                    value = paymentInfo.cardNumber,
                    onValueChange = { viewModel.updatePaymentInfo(paymentInfo.copy(cardNumber = it)) },
                    label = if (lang == Language.RO) "Număr Card" else "Card Number",
                    keyboardType = KeyboardType.Number,
                    testTag = "checkout_card_num"
                )

                WineryTextField(
                    value = paymentInfo.cardName,
                    onValueChange = { viewModel.updatePaymentInfo(paymentInfo.copy(cardName = it)) },
                    label = if (lang == Language.RO) "Nume Deținător Card" else "Name on Card",
                    testTag = "checkout_card_name"
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Box(modifier = Modifier.weight(1f)) {
                        WineryTextField(
                            value = paymentInfo.expiry,
                            onValueChange = { viewModel.updatePaymentInfo(paymentInfo.copy(expiry = it)) },
                            label = "MM/YY",
                            keyboardType = KeyboardType.Number,
                            testTag = "checkout_card_expiry"
                        )
                    }
                    Box(modifier = Modifier.weight(1f)) {
                        WineryTextField(
                            value = paymentInfo.cvv,
                            onValueChange = { viewModel.updatePaymentInfo(paymentInfo.copy(cvv = it)) },
                            label = "CVV",
                            keyboardType = KeyboardType.Number,
                            testTag = "checkout_card_cvv"
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Security disclaimer
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF1B1B15), shape = RoundedCornerShape(4.dp))
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = MutedBrass, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (lang == Language.RO) "Datele dumneavoastră sunt complet securizate. Conexiune criptată SSL 256-bit." else "Your information is fully secure. Protected by SSL 256-bit encryption.",
                        style = MaterialTheme.typography.bodySmall,
                        color = WarmLimestone,
                        lineHeight = 16.sp,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))
                Divider(color = MutedBrass.copy(alpha = 0.15f))
                Spacer(modifier = Modifier.height(16.dp))

                // Summary calculations
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Subtotal", style = MaterialTheme.typography.bodyMedium, color = WarmLimestone)
                        Text(text = "€${String.format("%.2f", subtotal)}", style = MaterialTheme.typography.bodyMedium, color = ColorAgedIvory)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Shipping (${deliveryInfo.shippingType})", style = MaterialTheme.typography.bodyMedium, color = WarmLimestone)
                        Text(text = "€${String.format("%.2f", shipping)}", style = MaterialTheme.typography.bodyMedium, color = ColorAgedIvory)
                    }
                    Divider(color = MutedBrass.copy(alpha = 0.1f), modifier = Modifier.padding(vertical = 4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "TOTAL", style = MaterialTheme.typography.titleMedium, color = MutedBrass, fontWeight = FontWeight.Bold)
                        Text(text = "€${String.format("%.2f", total)}", style = MaterialTheme.typography.titleMedium, color = MutedBrass, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(32.dp))

                Button(
                    onClick = {
                        if (paymentInfo.cardNumber.isNotEmpty() && paymentInfo.cvv.isNotEmpty()) {
                            viewModel.placeOrder()
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("checkout_place_order_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = CellarBurgundy),
                    shape = RoundedCornerShape(2.dp),
                    enabled = paymentInfo.cardNumber.isNotEmpty() && paymentInfo.cvv.isNotEmpty()
                ) {
                    Text(
                        text = if (lang == Language.RO) "PLASEAZĂ COMANDA — €${String.format("%.2f", total)}" else "PLACE ORDER — €${String.format("%.2f", total)}",
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        color = ColorAgedIvory
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(32.dp))
        WineryFooter(lang = lang)
    }
}

@Composable
fun WineryTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    keyboardType: KeyboardType = KeyboardType.Text,
    testTag: String
) {
    TextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(text = label, color = WarmLimestone.copy(alpha = 0.6f)) },
        colors = TextFieldDefaults.colors(
            focusedContainerColor = Color(0xFF141212),
            unfocusedContainerColor = Color(0xFF141212),
            focusedTextColor = ColorAgedIvory,
            unfocusedTextColor = ColorAgedIvory,
            cursorColor = MutedBrass,
            focusedIndicatorColor = MutedBrass,
            unfocusedIndicatorColor = Color.Transparent
        ),
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        singleLine = true,
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp)
            .testTag(testTag)
    )
}


// ==========================================
// 11. CONFIRMATION SCREEN
// ==========================================
@Composable
fun ConfirmationScreen(viewModel: WineryViewModel) {
    val lang by viewModel.selectedLanguage.collectAsState()
    val order by viewModel.lastConfirmedOrder.collectAsState()

    BackHandler {
        viewModel.navigateTo(Screen.HOME)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F0E0E))
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .widthIn(max = 450.dp)
                .background(Color(0xFF141212), shape = RoundedCornerShape(4.dp))
                .border(1.dp, MutedBrass.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                .padding(32.dp)
        ) {
            Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = "Success",
                tint = MutedBrass,
                modifier = Modifier.size(64.dp)
            )

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = if (lang == Language.RO) "COMANDĂ CONFIRMATĂ!" else "ORDER CONFIRMED!",
                style = MaterialTheme.typography.headlineMedium,
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Bold,
                color = ColorAgedIvory,
                textAlign = TextAlign.Center
            )

            Text(
                text = if (lang == Language.RO) "Mulțumim. Vinul tău pleacă din pivniță." else "Thank you. Your wine is leaving the cellar.",
                style = MaterialTheme.typography.bodyMedium,
                color = MutedBrass,
                fontStyle = FontStyle.Italic,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))
            Divider(color = MutedBrass.copy(alpha = 0.15f))
            Spacer(modifier = Modifier.height(16.dp))

            order?.let { ord ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = if (lang == Language.RO) "NUMĂR COMANDĂ:" else "ORDER ID:",
                        style = MaterialTheme.typography.labelSmall,
                        color = WarmLimestone.copy(alpha = 0.5f),
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = ord.orderId,
                        style = MaterialTheme.typography.titleLarge,
                        color = ColorAgedIvory,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = if (lang == Language.RO) "LIVRARE ESTIMATĂ:" else "ESTIMATED DELIVERY:",
                        style = MaterialTheme.typography.labelSmall,
                        color = WarmLimestone.copy(alpha = 0.5f),
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "3-5 business days",
                        style = MaterialTheme.typography.bodyMedium,
                        color = WarmLimestone,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                    Divider(color = MutedBrass.copy(alpha = 0.1f))
                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Total Paid: €${String.format("%.2f", ord.total)}",
                        style = MaterialTheme.typography.titleMedium,
                        color = MutedBrass,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            Button(
                onClick = {
                    viewModel.navigateTo(Screen.ACCOUNT)
                },
                colors = ButtonDefaults.buttonColors(containerColor = CellarBurgundy),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("conf_view_order_btn"),
                shape = RoundedCornerShape(2.dp)
            ) {
                Text(
                    text = if (lang == Language.RO) "VEZI COMANDA" else "VIEW ORDER HISTORY",
                    fontWeight = FontWeight.Bold,
                    color = ColorAgedIvory
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedButton(
                onClick = {
                    viewModel.navigateTo(Screen.SHOP)
                },
                border = BorderStroke(1.dp, MutedBrass),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MutedBrass),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("conf_continue_shopping_btn"),
                shape = RoundedCornerShape(2.dp)
            ) {
                Text(
                    text = if (lang == Language.RO) "CONTINUĂ CUMPĂRĂTURILE" else "CONTINUE SHOPPING",
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
