package com.example.data

import androidx.compose.runtime.Immutable

@Immutable
data class Wine(
    val id: String,
    val name: String,
    val vintage: String,
    val origin: String = "Mileștii Mici, Moldova",
    val bottleSize: String = "750 ml",
    val price: Double,
    val grape: String,
    val type: String, // Red, White, Rosé, Sparkling, Dessert
    val abv: String = "13.5%",
    val rating: Float = 4.8f,
    val description: String,
    val aroma: String,
    val palate: String,
    val finish: String,
    val servingTemp: String = "16–18°C",
    val foodPairings: List<String>,
    val imageResId: Int? = null,
    val isReserve: Boolean = false
)

@Immutable
data class WineCollection(
    val id: String,
    val name: String,
    val description: String,
    val wineIds: List<String>,
    val motto: String
)

@Immutable
data class GiftBox(
    val id: String,
    val name: String,
    val price: Double,
    val bottlesCount: Int,
    val winesIncluded: List<String>,
    val description: String
)

@Immutable
data class CellarTour(
    val id: String,
    val name: String,
    val duration: String,
    val languages: List<String>,
    val price: Double,
    val availability: String,
    val description: String,
    val highlight: String
)

@Immutable
data class CartItem(
    val wine: Wine,
    val quantity: Int
)

@Immutable
data class GiftBoxCartItem(
    val giftBox: GiftBox,
    val quantity: Int
)

@Immutable
data class PastOrder(
    val orderId: String,
    val date: String,
    val items: List<CartItem>,
    val giftBoxes: List<GiftBoxCartItem>,
    val subtotal: Double,
    val shipping: Double,
    val total: Double,
    val status: String,
    val deliveryAddress: String
)

@Immutable
data class StoryChapter(
    val id: String,
    val title: String,
    val year: String?,
    val content: String,
    val subtitle: String
)

@Immutable
data class CellarArea(
    val id: String,
    val name: String,
    val streetName: String, // Many tunnels in Milestii Mici are named after wine grapes!
    val depth: String,
    val temperature: String = "12-14°C",
    val description: String,
    val highlight: String,
    val relativeX: Float, // For map UI positioning
    val relativeY: Float
)
