package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Winery Color Palette
val CellarBurgundy = Color(0xFF58111A)
val DarkWineRed = Color(0xFF30070B)
val AlmostBlackCharcoal = Color(0xFF121212)
val CellarBackground = Color(0xFF0F0E0E)
val WarmLimestone = Color(0xFFDCD6BD)
val AgedIvory = Color(0xFFFBF9F4)
val MutedBrass = Color(0xFFC2A679)
val DeepForestGreen = Color(0xFF1B2B20)
val NaturalCopper = Color(0xFFBE6E34)

// Material 3 Dark theme mapping
val DarkPrimary = CellarBurgundy
val DarkSecondary = MutedBrass
val DarkTertiary = WarmLimestone
val DarkBackground = CellarBackground
val DarkSurface = Color(0xFF181616)
val DarkOnPrimary = AgedIvory
val DarkOnSecondary = CellarBackground
val DarkOnBackground = AgedIvory
val DarkOnSurface = AgedIvory
val DarkOnTertiary = CellarBackground
val DarkSurfaceVariant = Color(0xFF262121)
val DarkOnSurfaceVariant = WarmLimestone

