package com.example

import androidx.lifecycle.ViewModel
import com.example.data.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.random.Random

enum class Screen {
    HOME,
    SHOP,
    COLLECTIONS,
    CELLAR,
    VISIT,
    MOLDOVA,
    ACCOUNT,
    WISHLIST,
    PRODUCT_DETAILS,
    CHECKOUT,
    CONFIRMATION
}

enum class Language {
    RO, EN
}

data class DeliveryInfo(
    val name: String = "",
    val address: String = "",
    val city: String = "",
    val country: String = "Moldova",
    val postcode: String = "",
    val phone: String = "",
    val email: String = "",
    val shippingType: String = "Standard" // Standard (€8) or Express (€15)
)

data class PaymentInfo(
    val cardType: String = "Visa", // Visa, Mastercard, Apple Pay, Google Pay
    val cardNumber: String = "",
    val cardName: String = "",
    val expiry: String = "",
    val cvv: String = ""
)

class WineryViewModel : ViewModel() {

    // Age Gate state
    private val _isAgeVerified = MutableStateFlow(false)
    val isAgeVerified: StateFlow<Boolean> = _isAgeVerified.asStateFlow()

    // Language state
    private val _selectedLanguage = MutableStateFlow(Language.RO)
    val selectedLanguage: StateFlow<Language> = _selectedLanguage.asStateFlow()

    // Navigation state
    private val _currentScreen = MutableStateFlow(Screen.HOME)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val screenStack = mutableListOf<Screen>()

    // Selected product details
    private val _selectedWineId = MutableStateFlow<String?>("feteasca_neagra_2021")
    val selectedWineId: StateFlow<String?> = _selectedWineId.asStateFlow()

    // Shop filters
    private val _filterType = MutableStateFlow<String?>(null)
    val filterType: StateFlow<String?> = _filterType.asStateFlow()

    private val _filterGrape = MutableStateFlow<String?>(null)
    val filterGrape: StateFlow<String?> = _filterGrape.asStateFlow()

    private val _filterVintage = MutableStateFlow<String?>(null)
    val filterVintage: StateFlow<String?> = _filterVintage.asStateFlow()

    private val _maxPrice = MutableStateFlow(60.0f)
    val maxPrice: StateFlow<Float> = _maxPrice.asStateFlow()

    // Global Search Query
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // E-commerce state
    private val _cart = MutableStateFlow<List<CartItem>>(emptyList())
    val cart: StateFlow<List<CartItem>> = _cart.asStateFlow()

    private val _giftBoxCart = MutableStateFlow<List<GiftBoxCartItem>>(emptyList())
    val giftBoxCart: StateFlow<List<GiftBoxCartItem>> = _giftBoxCart.asStateFlow()

    private val _wishlist = MutableStateFlow<Set<String>>(emptySet())
    val wishlist: StateFlow<Set<String>> = _wishlist.asStateFlow()

    // Simulated orders
    private val _orders = MutableStateFlow<List<PastOrder>>(listOf(
        PastOrder(
            orderId = "MM-2026-0941",
            date = "12 Sept 2026",
            items = listOf(
                CartItem(WineryData.wines[2], 1), // Chardonnay
                CartItem(WineryData.wines[4], 1)  // Pinot Noir
            ),
            giftBoxes = emptyList(),
            subtotal = 45.0,
            shipping = 8.0,
            total = 53.0,
            status = "Delivered",
            deliveryAddress = "Str. Stefan cel Mare 1, Chisinau, Moldova"
        )
    ))
    val orders: StateFlow<List<PastOrder>> = _orders.asStateFlow()

    // Tour bookings
    private val _bookings = MutableStateFlow<List<CellarTour>>(emptyList())
    val bookings: StateFlow<List<CellarTour>> = _bookings.asStateFlow()

    // Checkout Flow States
    private val _checkoutStep = MutableStateFlow(1) // 1 = Delivery, 2 = Payment, 3 = Confirmation
    val checkoutStep: StateFlow<Int> = _checkoutStep.asStateFlow()

    private val _deliveryInfo = MutableStateFlow(DeliveryInfo())
    val deliveryInfo: StateFlow<DeliveryInfo> = _deliveryInfo.asStateFlow()

    private val _paymentInfo = MutableStateFlow(PaymentInfo())
    val paymentInfo: StateFlow<PaymentInfo> = _paymentInfo.asStateFlow()

    private val _lastConfirmedOrder = MutableStateFlow<PastOrder?>(null)
    val lastConfirmedOrder: StateFlow<PastOrder?> = _lastConfirmedOrder.asStateFlow()

    // Cart Drawer Visibility
    private val _isCartOpen = MutableStateFlow(false)
    val isCartOpen: StateFlow<Boolean> = _isCartOpen.asStateFlow()

    // Age verification trigger
    fun verifyAge(isLegal: Boolean) {
        if (isLegal) {
            _isAgeVerified.value = true
        }
    }

    // Toggle Language
    fun toggleLanguage() {
        _selectedLanguage.value = if (_selectedLanguage.value == Language.RO) Language.EN else Language.RO
    }

    // Navigation triggers
    fun navigateTo(screen: Screen) {
        if (_currentScreen.value != screen) {
            screenStack.add(_currentScreen.value)
            _currentScreen.value = screen
        }
    }

    fun navigateBack(): Boolean {
        if (screenStack.isNotEmpty()) {
            val prev = screenStack.removeAt(screenStack.size - 1)
            _currentScreen.value = prev
            return true
        }
        return false
    }

    // Details navigation helper
    fun selectWine(wineId: String) {
        _selectedWineId.value = wineId
        navigateTo(Screen.PRODUCT_DETAILS)
    }

    // Filters handling
    fun setFilterType(type: String?) {
        _filterType.value = type
    }

    fun setFilterGrape(grape: String?) {
        _filterGrape.value = grape
    }

    fun setFilterVintage(vintage: String?) {
        _filterVintage.value = vintage
    }

    fun setMaxPrice(price: Float) {
        _maxPrice.value = price
    }

    fun clearFilters() {
        _filterType.value = null
        _filterGrape.value = null
        _filterVintage.value = null
        _maxPrice.value = 60.0f
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    // Cart management
    fun addToCart(wine: Wine, quantity: Int = 1) {
        val current = _cart.value.toMutableList()
        val index = current.indexOfFirst { it.wine.id == wine.id }
        if (index >= 0) {
            current[index] = current[index].copy(quantity = current[index].quantity + quantity)
        } else {
            current.add(CartItem(wine, quantity))
        }
        _cart.value = current
    }

    fun removeOneFromCart(wine: Wine) {
        val current = _cart.value.toMutableList()
        val index = current.indexOfFirst { it.wine.id == wine.id }
        if (index >= 0) {
            val item = current[index]
            if (item.quantity > 1) {
                current[index] = item.copy(quantity = item.quantity - 1)
            } else {
                current.removeAt(index)
            }
            _cart.value = current
        }
    }

    fun clearCart() {
        _cart.value = emptyList()
        _giftBoxCart.value = emptyList()
    }

    // Gift box cart management
    fun addGiftBoxToCart(giftBox: GiftBox) {
        val current = _giftBoxCart.value.toMutableList()
        val index = current.indexOfFirst { it.giftBox.id == giftBox.id }
        if (index >= 0) {
            current[index] = current[index].copy(quantity = current[index].quantity + 1)
        } else {
            current.add(GiftBoxCartItem(giftBox, 1))
        }
        _giftBoxCart.value = current
    }

    fun removeGiftBoxFromCart(giftBox: GiftBox) {
        val current = _giftBoxCart.value.toMutableList()
        val index = current.indexOfFirst { it.giftBox.id == giftBox.id }
        if (index >= 0) {
            val item = current[index]
            if (item.quantity > 1) {
                current[index] = item.copy(quantity = item.quantity - 1)
            } else {
                current.removeAt(index)
            }
            _giftBoxCart.value = current
        }
    }

    // Wishlist management
    fun toggleWishlist(wineId: String) {
        val current = _wishlist.value.toMutableSet()
        if (current.contains(wineId)) {
            current.remove(wineId)
        } else {
            current.add(wineId)
        }
        _wishlist.value = current
    }

    // Cart Drawer Toggle
    fun setCartOpen(open: Boolean) {
        _isCartOpen.value = open
    }

    // Tour bookings
    fun bookTour(tour: CellarTour) {
        val current = _bookings.value.toMutableList()
        if (!current.contains(tour)) {
            current.add(tour)
            _bookings.value = current
        }
    }

    fun cancelBooking(tour: CellarTour) {
        val current = _bookings.value.toMutableList()
        current.remove(tour)
        _bookings.value = current
    }

    // Checkout Flow API
    fun updateDeliveryInfo(info: DeliveryInfo) {
        _deliveryInfo.value = info
    }

    fun updatePaymentInfo(info: PaymentInfo) {
        _paymentInfo.value = info
    }

    fun setCheckoutStep(step: Int) {
        _checkoutStep.value = step
    }

    fun placeOrder() {
        val sub = getSubtotal()
        val ship = getShippingCost()
        val tot = sub + ship
        val addressStr = "${_deliveryInfo.value.address}, ${_deliveryInfo.value.city}, ${_deliveryInfo.value.country}"
        
        val randomNum = Random.nextInt(1000, 9999)
        val newOrderId = "MM-2026-$randomNum"

        val newOrder = PastOrder(
            orderId = newOrderId,
            date = "01 Oct 2026",
            items = _cart.value,
            giftBoxes = _giftBoxCart.value,
            subtotal = sub,
            shipping = ship,
            total = tot,
            status = "Processing",
            deliveryAddress = addressStr
        )

        _lastConfirmedOrder.value = newOrder
        
        // Add to history
        val updatedOrders = _orders.value.toMutableList()
        updatedOrders.add(0, newOrder)
        _orders.value = updatedOrders

        // Clear cart
        clearCart()
        setCheckoutStep(3)
        navigateTo(Screen.CONFIRMATION)
    }

    // Calculations
    fun getSubtotal(): Double {
        var sum = 0.0
        for (item in _cart.value) {
            sum += item.wine.price * item.quantity
        }
        for (item in _giftBoxCart.value) {
            sum += item.giftBox.price * item.quantity
        }
        return sum
    }

    fun getShippingCost(): Double {
        if (getSubtotal() == 0.0) return 0.0
        return if (_deliveryInfo.value.shippingType == "Express") 15.0 else 8.0
    }
}
