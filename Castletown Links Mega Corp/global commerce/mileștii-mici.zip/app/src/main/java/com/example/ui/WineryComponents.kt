package com.example.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.Language
import com.example.R
import com.example.Screen
import com.example.WineryViewModel
import com.example.data.CartItem
import com.example.data.GiftBoxCartItem
import com.example.data.WineryData
import com.example.ui.theme.CellarBurgundy
import com.example.ui.theme.MutedBrass
import com.example.ui.theme.WarmLimestone

@Composable
fun WineryHeader(
    viewModel: WineryViewModel,
    modifier: Modifier = Modifier
) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val lang by viewModel.selectedLanguage.collectAsState()
    val cart by viewModel.cart.collectAsState()
    val giftCart by viewModel.giftBoxCart.collectAsState()
    val cartCount = cart.sumOf { it.quantity } + giftCart.sumOf { it.quantity }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF070606),
                        Color(0xFF0F0E0E).copy(alpha = 0.95f)
                    )
                )
            )
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left menu / brand secondary
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.clickable { viewModel.navigateTo(Screen.HOME) }
            ) {
                Column {
                    Text(
                        text = "MILEȘTII MICI",
                        style = MaterialTheme.typography.titleLarge,
                        color = AgedIvoryLocal,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp,
                        fontFamily = FontFamily.Serif
                    )
                    Text(
                        text = "MOLDOVA",
                        style = MaterialTheme.typography.labelMedium,
                        color = MutedBrass,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 3.sp
                    )
                }
            }

            // Right controls
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Language selector
                TextButton(
                    onClick = { viewModel.toggleLanguage() },
                    colors = ButtonDefaults.textButtonColors(contentColor = MutedBrass),
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("language_toggle")
                ) {
                    Text(
                        text = if (lang == Language.RO) "EN" else "RO",
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }

                // Wishlist Icon
                IconButton(
                    onClick = { viewModel.navigateTo(Screen.WISHLIST) },
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("wishlist_button")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.FavoriteBorder,
                        contentDescription = if (lang == Language.RO) "Salvate" else "Saved",
                        tint = if (currentScreen == Screen.WISHLIST) CellarBurgundy else MutedBrass
                    )
                }

                // Cart Icon with badge
                Box(
                    modifier = Modifier
                        .clickable { viewModel.setCartOpen(true) }
                        .padding(8.dp)
                        .testTag("cart_trigger")
                ) {
                    Icon(
                        imageVector = Icons.Filled.ShoppingBag,
                        contentDescription = if (lang == Language.RO) "Coș" else "Cart",
                        tint = MutedBrass,
                        modifier = Modifier.size(26.dp)
                    )
                    if (cartCount > 0) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .offset(x = 4.dp, y = (-4).dp)
                                .background(CellarBurgundy, shape = RoundedCornerShape(10.dp))
                                .padding(horizontal = 5.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = cartCount.toString(),
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CartDrawer(
    viewModel: WineryViewModel,
    onCheckoutClick: () -> Unit
) {
    val isOpen by viewModel.isCartOpen.collectAsState()
    val lang by viewModel.selectedLanguage.collectAsState()
    val cartItems by viewModel.cart.collectAsState()
    val giftCartItems by viewModel.giftBoxCart.collectAsState()
    val subtotal = viewModel.getSubtotal()

    if (isOpen) {
        ModalBottomSheet(
            onDismissRequest = { viewModel.setCartOpen(false) },
            containerColor = Color(0xFF141212),
            contentColor = AgedIvoryLocal,
            dragHandle = { BottomSheetDefaults.DragHandle(color = MutedBrass.copy(alpha = 0.5f)) }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxHeight(0.85f)
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                // Title
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (lang == Language.RO) "COȘUL TĂU" else "YOUR CELLAR CART",
                        style = MaterialTheme.typography.headlineMedium,
                        fontFamily = FontFamily.Serif,
                        color = MutedBrass,
                        letterSpacing = 1.sp
                    )
                    TextButton(onClick = { viewModel.clearCart() }) {
                        Text(
                            text = if (lang == Language.RO) "Golește" else "Clear All",
                            color = Color.Red.copy(alpha = 0.7f),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                if (cartItems.isEmpty() && giftCartItems.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Outlined.ShoppingBag,
                                contentDescription = null,
                                tint = MutedBrass.copy(alpha = 0.3f),
                                modifier = Modifier.size(64.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = if (lang == Language.RO) "Pivnița ta este goală." else "Your cellar is empty.",
                                style = MaterialTheme.typography.bodyLarge,
                                color = WarmLimestone
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (lang == Language.RO) "Adaugă vinuri fine din subteran." else "Add fine wines from beneath the earth.",
                                style = MaterialTheme.typography.bodySmall,
                                color = WarmLimestone.copy(alpha = 0.6f)
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        items(cartItems) { item ->
                            CartItemRow(item, onAdd = {
                                viewModel.addToCart(item.wine, 1)
                            }, onRemove = {
                                viewModel.removeOneFromCart(item.wine)
                            })
                        }
                        items(giftCartItems) { item ->
                            GiftBoxCartItemRow(item, onAdd = {
                                viewModel.addGiftBoxToCart(item.giftBox)
                            }, onRemove = {
                                viewModel.removeGiftBoxFromCart(item.giftBox)
                            })
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Divider(color = MutedBrass.copy(alpha = 0.2f))
                    Spacer(modifier = Modifier.height(16.dp))

                    // Calculations
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = if (lang == Language.RO) "Subtotal" else "Subtotal",
                            style = MaterialTheme.typography.bodyLarge,
                            color = WarmLimestone
                        )
                        Text(
                            text = "€${String.format("%.2f", subtotal)}",
                            style = MaterialTheme.typography.bodyLarge,
                            color = AgedIvoryLocal,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Button(
                        onClick = {
                            viewModel.setCartOpen(false)
                            onCheckoutClick()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("checkout_button_drawer"),
                        colors = ButtonDefaults.buttonColors(containerColor = CellarBurgundy),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = if (lang == Language.RO) "FINALIZEAZĂ COMANDA" else "SECURE CHECKOUT",
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp,
                            color = AgedIvoryLocal
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CartItemRow(
    item: CartItem,
    onAdd: () -> Unit,
    onRemove: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF1B1919), shape = RoundedCornerShape(4.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Thumbnail
        Box(
            modifier = Modifier
                .size(60.dp)
                .background(Color(0xFF262121), shape = RoundedCornerShape(2.dp)),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_wine_bottle_1790841720211),
                contentDescription = item.wine.name,
                modifier = Modifier
                    .fillMaxHeight()
                    .padding(4.dp),
                contentScale = ContentScale.Fit
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        // Info
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = item.wine.name.uppercase(),
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = AgedIvoryLocal
            )
            Text(
                text = "${item.wine.vintage} · ${item.wine.bottleSize}",
                style = MaterialTheme.typography.bodySmall,
                color = WarmLimestone
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "€${String.format("%.2f", item.wine.price)}",
                style = MaterialTheme.typography.bodyMedium,
                color = MutedBrass,
                fontWeight = FontWeight.Bold
            )
        }

        // Qty controllers
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            IconButton(
                onClick = onRemove,
                modifier = Modifier
                    .size(32.dp)
                    .border(1.dp, MutedBrass.copy(alpha = 0.5f), RoundedCornerShape(2.dp))
            ) {
                Icon(
                    imageVector = Icons.Default.Remove,
                    contentDescription = "Decrease",
                    tint = MutedBrass,
                    modifier = Modifier.size(16.dp)
                )
            }

            Text(
                text = item.quantity.toString(),
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = AgedIvoryLocal,
                modifier = Modifier.widthIn(min = 16.dp),
                textAlign = TextAlign.Center
            )

            IconButton(
                onClick = onAdd,
                modifier = Modifier
                    .size(32.dp)
                    .border(1.dp, MutedBrass.copy(alpha = 0.5f), RoundedCornerShape(2.dp))
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Increase",
                    tint = MutedBrass,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
fun GiftBoxCartItemRow(
    item: GiftBoxCartItem,
    onAdd: () -> Unit,
    onRemove: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF1B1919), shape = RoundedCornerShape(4.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Thumbnail
        Box(
            modifier = Modifier
                .size(60.dp)
                .background(Color(0xFF262121), shape = RoundedCornerShape(2.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.CardGiftcard,
                contentDescription = null,
                tint = MutedBrass,
                modifier = Modifier.size(32.dp)
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        // Info
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = item.giftBox.name.uppercase(),
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = AgedIvoryLocal
            )
            Text(
                text = "Premium Packaging (${item.giftBox.bottlesCount} bottles)",
                style = MaterialTheme.typography.bodySmall,
                color = WarmLimestone
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "€${String.format("%.2f", item.giftBox.price)}",
                style = MaterialTheme.typography.bodyMedium,
                color = MutedBrass,
                fontWeight = FontWeight.Bold
            )
        }

        // Qty controllers
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            IconButton(
                onClick = onRemove,
                modifier = Modifier
                    .size(32.dp)
                    .border(1.dp, MutedBrass.copy(alpha = 0.5f), RoundedCornerShape(2.dp))
            ) {
                Icon(
                    imageVector = Icons.Default.Remove,
                    contentDescription = "Decrease",
                    tint = MutedBrass,
                    modifier = Modifier.size(16.dp)
                )
            }

            Text(
                text = item.quantity.toString(),
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = AgedIvoryLocal,
                modifier = Modifier.widthIn(min = 16.dp),
                textAlign = TextAlign.Center
            )

            IconButton(
                onClick = onAdd,
                modifier = Modifier
                    .size(32.dp)
                    .border(1.dp, MutedBrass.copy(alpha = 0.5f), RoundedCornerShape(2.dp))
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Increase",
                    tint = MutedBrass,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
fun AgeGateScreen(
    viewModel: WineryViewModel,
    onExitClick: () -> Unit
) {
    val lang by viewModel.selectedLanguage.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF070606))
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .widthIn(max = 450.dp)
                .border(1.dp, MutedBrass.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
                .background(Color(0xFF0F0E0E))
                .padding(32.dp)
        ) {
            // Logo Icon
            Icon(
                imageVector = Icons.Filled.LocalActivity,
                contentDescription = null,
                tint = MutedBrass,
                modifier = Modifier.size(54.dp)
            )

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "MILEȘTII MICI",
                style = MaterialTheme.typography.headlineLarge,
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Bold,
                color = AgedIvoryLocal,
                letterSpacing = 2.sp,
                textAlign = TextAlign.Center
            )

            Text(
                text = "MOLDOVA",
                style = MaterialTheme.typography.labelLarge,
                color = MutedBrass,
                letterSpacing = 4.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(16.dp))
            Divider(color = MutedBrass.copy(alpha = 0.2f), thickness = 1.dp)
            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = if (lang == Language.RO)
                    "Trebuie să aveți vârsta legală pentru consumul de alcool în țara dumneavoastră pentru a intra în pivnițele noastre virtuale."
                else
                    "You must be of legal drinking age in your jurisdiction to enter our virtual limestone cellars.",
                style = MaterialTheme.typography.bodyMedium,
                color = WarmLimestone,
                textAlign = TextAlign.Center,
                lineHeight = 22.sp
            )

            Spacer(modifier = Modifier.height(32.dp))

            // CTA Buttons
            Button(
                onClick = { viewModel.verifyAge(true) },
                colors = ButtonDefaults.buttonColors(containerColor = CellarBurgundy),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("age_gate_confirm"),
                shape = RoundedCornerShape(2.dp)
            ) {
                Text(
                    text = if (lang == Language.RO) "SUNT MAJOR" else "I AM OF LEGAL AGE",
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    color = AgedIvoryLocal
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedButton(
                onClick = onExitClick,
                colors = ButtonDefaults.outlinedButtonColors(contentColor = WarmLimestone),
                border = ButtonDefaults.outlinedButtonBorder.copy(
                    brush = Brush.linearGradient(listOf(WarmLimestone.copy(alpha = 0.5f), WarmLimestone.copy(alpha = 0.5f)))
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("age_gate_exit"),
                shape = RoundedCornerShape(2.dp)
            ) {
                Text(
                    text = if (lang == Language.RO) "IEȘIRE" else "EXIT",
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = if (lang == Language.RO) "Bucurați-vă de vin cu moderație." else "Enjoy wine responsibly.",
                style = MaterialTheme.typography.labelSmall,
                color = WarmLimestone.copy(alpha = 0.4f),
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun WineryFooter(
    lang: Language,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(Color(0xFF080707))
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Divider(color = MutedBrass.copy(alpha = 0.15f), thickness = 1.dp)
        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "MILEȘTII MICI",
            style = MaterialTheme.typography.titleMedium,
            color = AgedIvoryLocal,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Serif,
            letterSpacing = 2.sp
        )
        Text(
            text = "VINURI DIN SUBTERAN",
            style = MaterialTheme.typography.labelSmall,
            color = MutedBrass,
            letterSpacing = 3.sp
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = if (lang == Language.RO)
                "Un monument istoric al culturii vinului, conservat natural în inima Moldovei din 1969."
            else
                "A historic monument of wine culture, naturally preserved in the heart of Moldova since 1969.",
            style = MaterialTheme.typography.bodySmall,
            color = WarmLimestone.copy(alpha = 0.6f),
            textAlign = TextAlign.Center,
            modifier = Modifier.widthIn(max = 300.dp)
        )

        Spacer(modifier = Modifier.height(24.dp))

        Row(
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.padding(bottom = 12.dp)
        ) {
            Text(
                text = "MM-2026",
                style = MaterialTheme.typography.labelSmall,
                color = MutedBrass
            )
            Text(
                text = if (lang == Language.RO) "CHIȘINĂU, MOLDOVA" else "CHISINAU, MOLDOVA",
                style = MaterialTheme.typography.labelSmall,
                color = WarmLimestone.copy(alpha = 0.4f)
            )
        }

        Text(
            text = "© 2026 Mileștii Mici Winery. " + (if (lang == Language.RO) "Toate drepturile rezervate." else "All rights reserved."),
            style = MaterialTheme.typography.labelSmall,
            color = WarmLimestone.copy(alpha = 0.3f),
            textAlign = TextAlign.Center
        )
    }
}

// Local local values
val AgedIvoryLocal = Color(0xFFFBF9F4)
