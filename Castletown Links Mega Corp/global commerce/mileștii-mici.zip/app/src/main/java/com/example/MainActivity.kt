package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.CellarBurgundy
import com.example.ui.theme.MutedBrass

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                // Initialize premium view model inside the scope
                val viewModel = remember { WineryViewModel() }
                val isAgeVerified by viewModel.isAgeVerified.collectAsState()
                val currentScreen by viewModel.currentScreen.collectAsState()
                val lang by viewModel.selectedLanguage.collectAsState()

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        if (isAgeVerified) {
                            WineryBottomNavigation(viewModel = viewModel)
                        }
                    },
                    containerColor = Color(0xFF0F0E0E)
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(bottom = innerPadding.calculateBottomPadding())
                    ) {
                        if (!isAgeVerified) {
                            AgeGateScreen(
                                viewModel = viewModel,
                                onExitClick = { finishAffinity() }
                            )
                        } else {
                            Column(modifier = Modifier.fillMaxSize()) {
                                // Reusable Header
                                WineryHeader(viewModel = viewModel)

                                // Crossfade animation between screens
                                AnimatedContent(
                                    targetState = currentScreen,
                                    transitionSpec = {
                                        fadeIn(animationSpec = tween(300)) togetherWith
                                                fadeOut(animationSpec = tween(300))
                                    },
                                    label = "screen_transition",
                                    modifier = Modifier.weight(1f)
                                ) { screen ->
                                    when (screen) {
                                        Screen.HOME -> HomeScreen(viewModel)
                                        Screen.SHOP -> ShopScreen(viewModel)
                                        Screen.COLLECTIONS -> CollectionsScreen(viewModel)
                                        Screen.CELLAR -> CellarMapScreen(viewModel)
                                        Screen.VISIT -> VisitScreen(viewModel)
                                        Screen.MOLDOVA -> MoldovaScreen(viewModel)
                                        Screen.ACCOUNT -> AccountScreen(viewModel)
                                        Screen.WISHLIST -> WishlistScreen(viewModel)
                                        Screen.PRODUCT_DETAILS -> ProductDetailsScreen(viewModel)
                                        Screen.CHECKOUT -> CheckoutScreen(viewModel)
                                        Screen.CONFIRMATION -> ConfirmationScreen(viewModel)
                                    }
                                }
                            }

                            // Slide-in Cart Drawer Overlay
                            CartDrawer(
                                viewModel = viewModel,
                                onCheckoutClick = {
                                    viewModel.navigateTo(Screen.CHECKOUT)
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WineryBottomNavigation(viewModel: WineryViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val lang by viewModel.selectedLanguage.collectAsState()

    // Bottom Navigation specs
    val navItems = listOf(
        Triple(if (lang == Language.RO) "ACASĂ" else "HOME", Screen.HOME, Icons.Default.Home),
        Triple(if (lang == Language.RO) "MAGAZIN" else "SHOP", Screen.SHOP, Icons.Default.WineBar),
        Triple(if (lang == Language.RO) "CRAMĂ" else "CELLAR", Screen.CELLAR, Icons.Default.Map),
        Triple(if (lang == Language.RO) "COȘ" else "CART", null, Icons.Default.ShoppingBag),
        Triple(if (lang == Language.RO) "CONT" else "ACCOUNT", Screen.ACCOUNT, Icons.Default.Person)
    )

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding(),
        color = Color(0xFF070606),
        tonalElevation = 8.dp
    ) {
        Column {
            Divider(color = MutedBrass.copy(alpha = 0.15f), thickness = 0.5.dp)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(58.dp)
                    .padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                navItems.forEach { (label, screen, icon) ->
                    val isSelected = screen != null && currentScreen == screen
                    val isCartTrigger = screen == null

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                if (isCartTrigger) {
                                    viewModel.setCartOpen(true)
                                } else if (screen != null) {
                                    viewModel.navigateTo(screen)
                                }
                            }
                            .padding(vertical = 4.dp)
                            .testTag("nav_item_${label.lowercase()}")
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = label,
                            tint = if (isSelected) MutedBrass else MutedBrass.copy(alpha = 0.4f),
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isSelected) MutedBrass else MutedBrass.copy(alpha = 0.4f),
                            fontSize = 10.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }
        }
    }
}
