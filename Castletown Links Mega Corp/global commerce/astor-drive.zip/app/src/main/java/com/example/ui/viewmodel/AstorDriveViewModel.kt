package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.firebase.AstorDriveRepository
import com.example.data.model.AmericanHub
import com.example.data.model.Booking
import com.example.data.model.ConciergeRequest
import com.example.data.model.ConciergeRequestType
import com.example.data.model.DeliveryType
import com.example.data.model.FleetCatalog
import com.example.data.model.FleetCategory
import com.example.data.model.LiveVehicleAvailability
import com.example.data.model.UserProfile
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

data class TripPlannerState(
    val pickupHub: AmericanHub = FleetCatalog.defaultHub,
    val returnHub: AmericanHub = FleetCatalog.defaultHub,
    val returnToSameLocation: Boolean = true,
    val startEpochDay: Long = LocalDate.now().plusDays(2).toEpochDay(),
    val endEpochDay: Long = LocalDate.now().plusDays(5).toEpochDay(),
    val selectedCategory: String = FleetCategory.ALL.label,
    val showSavedOnly: Boolean = false,
    val deliveryType: DeliveryType = DeliveryType.HUB_COLLECTION,
    val deliveryAddress: String = "",
    val deliveryTimeWindow: String = FleetCatalog.deliveryTimeWindows[1],
    val chauffeurRequested: Boolean = false,
    val conciergeNotes: String = ""
) {
    val daysCount: Int
        get() = (endEpochDay - startEpochDay).coerceAtLeast(1L).toInt()

    val formattedDateRange: String
        get() {
            val start = LocalDate.ofEpochDay(startEpochDay)
            val end = LocalDate.ofEpochDay(endEpochDay)
            val monthFmt = DateTimeFormatter.ofPattern("MMMM", Locale.US)
            val shortFmt = DateTimeFormatter.ofPattern("d MMM", Locale.US)
            return if (start.month == end.month && start.year == end.year) {
                "${start.dayOfMonth}–${end.dayOfMonth} ${start.format(monthFmt)}"
            } else {
                "${start.format(shortFmt)} – ${end.format(shortFmt)}"
            }
        }
}

data class ActionFeedback(
    val message: String,
    val isError: Boolean = false
)

class AstorDriveViewModel(
    private val repository: AstorDriveRepository,
    private val currentUserId: String,
    private val userDisplayName: String,
    private val userEmail: String
) : ViewModel() {

    private val _planner = MutableStateFlow(TripPlannerState())
    val planner: StateFlow<TripPlannerState> = _planner.asStateFlow()

    private val _feedback = MutableStateFlow<ActionFeedback?>(null)
    val feedback: StateFlow<ActionFeedback?> = _feedback.asStateFlow()

    private val _isSubmitting = MutableStateFlow(false)
    val isSubmitting: StateFlow<Boolean> = _isSubmitting.asStateFlow()

    private val _prefilledConciergeVehicle = MutableStateFlow<String?>(null)
    val prefilledConciergeVehicle: StateFlow<String?> = _prefilledConciergeVehicle.asStateFlow()

    init {
        viewModelScope.launch {
            repository.ensureUserProfile(userDisplayName, userEmail)
                .onFailure { Log.w(TAG, "Unable to ensure user profile: ${it.message}") }
        }
    }

    val userProfileState: StateFlow<UiState<UserProfile?>> = repository.observeUserProfile(currentUserId)
        .map<UserProfile?, UiState<UserProfile?>> { UiState.Success(it) }
        .catch { error ->
            emit(UiState.Error(unwrapFirestoreMessage(error, "Failed to load member profile")))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Loading
        )

    val bookingsState: StateFlow<UiState<List<Booking>>> = repository.observeBookings(currentUserId)
        .map<List<Booking>, UiState<List<Booking>>> { UiState.Success(it) }
        .catch { error ->
            emit(UiState.Error(unwrapFirestoreMessage(error, "Failed to load reservations")))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Loading
        )

    val conciergeRequestsState: StateFlow<UiState<List<ConciergeRequest>>> =
        repository.observeConciergeRequests(currentUserId)
            .map<List<ConciergeRequest>, UiState<List<ConciergeRequest>>> { UiState.Success(it) }
            .catch { error ->
                emit(UiState.Error(unwrapFirestoreMessage(error, "Failed to load concierge requests")))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = UiState.Loading
            )

    val savedVehicleIds: StateFlow<Set<String>> = repository.observeSavedVehicleIds(currentUserId)
        .catch { error ->
            Log.w(TAG, "Error observing saved vehicles", error)
            emit(emptySet())
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = emptySet()
        )

    val fleetAvailability: StateFlow<List<LiveVehicleAvailability>> = combine(
        _planner,
        bookingsState
    ) { plan, bookingsUi ->
        val bookings = (bookingsUi as? UiState.Success)?.data.orEmpty()
        FleetCatalog.vehicles.map { vehicle ->
            FleetCatalog.computeAvailability(
                vehicle = vehicle,
                hubDisplayName = plan.pickupHub.displayName,
                startEpochDay = plan.startEpochDay,
                endEpochDay = plan.endEpochDay,
                userBookings = bookings
            )
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = FleetCatalog.vehicles.map {
            FleetCatalog.computeAvailability(
                vehicle = it,
                hubDisplayName = FleetCatalog.defaultHub.displayName,
                startEpochDay = _planner.value.startEpochDay,
                endEpochDay = _planner.value.endEpochDay,
                userBookings = emptyList()
            )
        }
    )

    fun selectPickupHub(hub: AmericanHub) {
        _planner.update { state ->
            state.copy(
                pickupHub = hub,
                returnHub = if (state.returnToSameLocation) hub else state.returnHub
            )
        }
    }

    fun selectReturnHub(hub: AmericanHub) {
        _planner.update { it.copy(returnHub = hub) }
    }

    fun setReturnToSameLocation(same: Boolean) {
        _planner.update { state ->
            state.copy(
                returnToSameLocation = same,
                returnHub = if (same) state.pickupHub else state.returnHub
            )
        }
    }

    fun updateDates(startEpochDay: Long, endEpochDay: Long) {
        if (endEpochDay <= startEpochDay) return
        _planner.update { it.copy(startEpochDay = startEpochDay, endEpochDay = endEpochDay) }
    }

    fun selectCategory(categoryLabel: String) {
        _planner.update { it.copy(selectedCategory = categoryLabel, showSavedOnly = false) }
    }

    fun setShowSavedOnly(savedOnly: Boolean) {
        _planner.update { it.copy(showSavedOnly = savedOnly) }
    }

    fun setDeliveryType(type: DeliveryType) {
        _planner.update { it.copy(deliveryType = type) }
    }

    fun updateDeliveryAddress(address: String) {
        _planner.update { it.copy(deliveryAddress = address) }
    }

    fun selectDeliveryTimeWindow(window: String) {
        _planner.update { it.copy(deliveryTimeWindow = window) }
    }

    fun setChauffeurRequested(requested: Boolean) {
        _planner.update { it.copy(chauffeurRequested = requested) }
    }

    fun updateConciergeNotes(notes: String) {
        _planner.update { it.copy(conciergeNotes = notes) }
    }

    fun prefillConciergeForVehicle(vehicleName: String) {
        _prefilledConciergeVehicle.value = vehicleName
    }

    fun toggleSavedVehicle(vehicleId: String) {
        val currentlySaved = savedVehicleIds.value.contains(vehicleId)
        viewModelScope.launch {
            repository.toggleSavedVehicle(vehicleId, currentlySaved)
                .onFailure { error ->
                    _feedback.value = ActionFeedback(
                        message = error.localizedMessage ?: "Could not update saved vehicle",
                        isError = true
                    )
                }
        }
    }

    fun confirmReservation(
        availability: LiveVehicleAvailability,
        onConfirmed: (String) -> Unit
    ) {
        val plan = _planner.value
        val vehicle = availability.vehicle
        if (!availability.isAvailableNow) {
            _feedback.value = ActionFeedback(
                message = "No bays remaining at ${plan.pickupHub.city} for these dates. Adjust dates or contact Concierge.",
                isError = true
            )
            return
        }
        if (plan.deliveryType == DeliveryType.PERSONALISED_DELIVERY && plan.deliveryAddress.isBlank()) {
            _feedback.value = ActionFeedback(
                message = "Enter a hotel, residence, or FBO address for personalised delivery.",
                isError = true
            )
            return
        }

        val days = plan.daysCount
        val subtotal = vehicle.dailyRateUsd * days
        val deliveryFee = if (plan.deliveryType == DeliveryType.PERSONALISED_DELIVERY) {
            vehicle.deliveryFeeUsd
        } else {
            0
        }
        val chauffeurFee = if (plan.chauffeurRequested) 140 * days else 0
        val combinedDeliveryFee = deliveryFee + chauffeurFee
        val taxesAndFees = ((subtotal + combinedDeliveryFee) * 0.1525).toInt()
        val estimatedTotal = subtotal + combinedDeliveryFee + taxesAndFees

        val booking = Booking(
            userId = currentUserId,
            vehicleId = vehicle.id,
            vehicleName = vehicle.name,
            vehicleCategory = vehicle.category,
            pickupLocation = plan.pickupHub.displayName,
            returnLocation = if (plan.returnToSameLocation) {
                plan.pickupHub.displayName
            } else {
                plan.returnHub.displayName
            },
            returnToSameLocation = plan.returnToSameLocation,
            startDateEpochDay = plan.startEpochDay,
            endDateEpochDay = plan.endEpochDay,
            daysCount = days.toLong(),
            deliveryType = plan.deliveryType.value,
            deliveryAddress = if (plan.deliveryType == DeliveryType.PERSONALISED_DELIVERY) {
                plan.deliveryAddress.trim()
            } else {
                ""
            },
            deliveryTimeWindow = if (plan.deliveryType == DeliveryType.PERSONALISED_DELIVERY) {
                plan.deliveryTimeWindow
            } else {
                ""
            },
            chauffeurRequested = plan.chauffeurRequested,
            conciergeNotes = plan.conciergeNotes.trim(),
            dailyRateUsd = vehicle.dailyRateUsd.toLong(),
            subtotalUsd = subtotal.toLong(),
            deliveryFeeUsd = combinedDeliveryFee.toLong(),
            taxesAndFeesUsd = taxesAndFees.toLong(),
            estimatedTotalUsd = estimatedTotal.toLong(),
            securityDepositUsd = vehicle.securityDepositUsd.toLong(),
            status = "confirmed"
        )

        viewModelScope.launch {
            _isSubmitting.value = true
            repository.createBooking(booking)
                .onSuccess { bookingId ->
                    _isSubmitting.value = false
                    _feedback.value = ActionFeedback(
                        message = "${vehicle.name} reserved · Live hub inventory updated."
                    )
                    onConfirmed(bookingId)
                }
                .onFailure { error ->
                    _isSubmitting.value = false
                    _feedback.value = ActionFeedback(
                        message = error.localizedMessage ?: "Reservation failed. Please retry.",
                        isError = true
                    )
                }
        }
    }

    fun updateBookingDelivery(
        bookingId: String,
        deliveryAddress: String,
        deliveryTimeWindow: String,
        conciergeNotes: String
    ) {
        viewModelScope.launch {
            _isSubmitting.value = true
            repository.updateBookingDelivery(
                bookingId = bookingId,
                deliveryAddress = deliveryAddress.trim(),
                deliveryTimeWindow = deliveryTimeWindow,
                conciergeNotes = conciergeNotes.trim()
            )
                .onSuccess {
                    _isSubmitting.value = false
                    _feedback.value = ActionFeedback("Delivery instructions updated.")
                }
                .onFailure { error ->
                    _isSubmitting.value = false
                    _feedback.value = ActionFeedback(
                        message = error.localizedMessage ?: "Could not update delivery details.",
                        isError = true
                    )
                }
        }
    }

    fun cancelBooking(bookingId: String) {
        viewModelScope.launch {
            repository.cancelBooking(bookingId)
                .onSuccess {
                    _feedback.value = ActionFeedback("Reservation cancelled. Hub bay released.")
                }
                .onFailure { error ->
                    _feedback.value = ActionFeedback(
                        message = error.localizedMessage ?: "Could not cancel reservation.",
                        isError = true
                    )
                }
        }
    }

    fun submitConciergeRequest(
        requestType: ConciergeRequestType,
        pickupLocation: String,
        preferredDateText: String,
        deliveryAddress: String,
        vehiclePreference: String,
        guestCount: Int,
        notes: String
    ) {
        if (preferredDateText.isBlank()) {
            _feedback.value = ActionFeedback(
                message = "Please specify a preferred date or arrival window.",
                isError = true
            )
            return
        }

        val specialist = when (requestType) {
            ConciergeRequestType.FBO_TARMAC_HANDOFF -> "Elena Sterling · Aviation Desk"
            ConciergeRequestType.CHAUFFEUR_SERVICE -> "Marcus Thorne · Chauffeur Director"
            else -> "Julian Vance · Senior Concierge"
        }

        val request = ConciergeRequest(
            userId = currentUserId,
            requestType = requestType.value,
            pickupLocation = pickupLocation,
            preferredDateText = preferredDateText.trim(),
            deliveryAddress = deliveryAddress.trim(),
            vehiclePreference = vehiclePreference.ifBlank { "Cadillac Escalade" },
            guestCount = guestCount.coerceIn(1, 12).toLong(),
            notes = notes.trim(),
            status = "submitted",
            assignedSpecialist = specialist
        )

        viewModelScope.launch {
            _isSubmitting.value = true
            repository.createConciergeRequest(request)
                .onSuccess {
                    _isSubmitting.value = false
                    _prefilledConciergeVehicle.value = null
                    _feedback.value = ActionFeedback(
                        message = "Concierge request logged with $specialist."
                    )
                }
                .onFailure { error ->
                    _isSubmitting.value = false
                    _feedback.value = ActionFeedback(
                        message = error.localizedMessage ?: "Failed to submit concierge request.",
                        isError = true
                    )
                }
        }
    }

    fun cancelConciergeRequest(requestId: String) {
        viewModelScope.launch {
            repository.cancelConciergeRequest(requestId)
                .onSuccess {
                    _feedback.value = ActionFeedback("Concierge request withdrawn.")
                }
                .onFailure { error ->
                    _feedback.value = ActionFeedback(
                        message = error.localizedMessage ?: "Unable to cancel concierge request.",
                        isError = true
                    )
                }
        }
    }

    fun updateMemberDeliveryDefaults(defaultHub: String, preferredAddress: String) {
        viewModelScope.launch {
            repository.updateDeliveryPreferences(defaultHub, preferredAddress.trim())
                .onSuccess {
                    _feedback.value = ActionFeedback("Member delivery preferences saved.")
                }
                .onFailure { error ->
                    _feedback.value = ActionFeedback(
                        message = error.localizedMessage ?: "Unable to save preferences.",
                        isError = true
                    )
                }
        }
    }

    fun clearFeedback() {
        _feedback.value = null
    }

    private fun unwrapFirestoreMessage(error: Throwable, fallback: String): String {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val rootError = firestoreError ?: error
        Log.w(TAG, fallback, rootError)
        return rootError.localizedMessage ?: fallback
    }

    private companion object {
        const val TAG = "AstorDriveVM"
        const val STOP_TIMEOUT_MILLIS = 5000L
    }
}
