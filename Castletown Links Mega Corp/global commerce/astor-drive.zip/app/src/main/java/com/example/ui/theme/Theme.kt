package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val AstorLightColorScheme = lightColorScheme(
    primary = ObsidianEspresso,
    onPrimary = AlabasterCard,
    primaryContainer = ChampagneTint,
    onPrimaryContainer = ObsidianEspresso,
    secondary = ChampagneGold,
    onSecondary = AlabasterCard,
    secondaryContainer = WarmSandSurface,
    onSecondaryContainer = CharcoalInk,
    tertiary = EmeraldAvailable,
    onTertiary = AlabasterCard,
    tertiaryContainer = EmeraldTint,
    onTertiaryContainer = EmeraldAvailable,
    background = IvoryCanvas,
    onBackground = ObsidianEspresso,
    surface = AlabasterCard,
    onSurface = ObsidianEspresso,
    surfaceVariant = WarmSandSurface,
    onSurfaceVariant = WarmTaupe,
    outline = HairlineBorder,
    outlineVariant = WarmParchmentPill,
    error = CrimsonAlert,
    onError = AlabasterCard,
    errorContainer = CrimsonTint,
    onErrorContainer = CrimsonAlert
)

private val AstorDarkColorScheme = darkColorScheme(
    primary = BrightChampagne,
    onPrimary = NightObsidian,
    primaryContainer = NightCard,
    onPrimaryContainer = NightIvoryText,
    secondary = ChampagneGold,
    onSecondary = NightObsidian,
    secondaryContainer = NightSurface,
    onSecondaryContainer = NightIvoryText,
    tertiary = EmeraldAvailable,
    onTertiary = NightIvoryText,
    background = NightObsidian,
    onBackground = NightIvoryText,
    surface = NightSurface,
    onSurface = NightIvoryText,
    surfaceVariant = NightCard,
    onSurfaceVariant = NightMutedText,
    outline = NightBorder,
    outlineVariant = NightCard,
    error = CrimsonAlert,
    onError = NightIvoryText
)

val AstorShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun AstorDriveTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) AstorDarkColorScheme else AstorLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = AstorTypography,
        shapes = AstorShapes,
        content = content
    )
}
