package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.HeadsetMic
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.DirectionsCar
import androidx.compose.material.icons.outlined.HeadsetMic
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.DateRangePicker
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberDateRangePickerState
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.model.AmericanHub
import com.example.data.model.FleetCatalog
import com.example.data.model.UserProfile
import com.example.ui.theme.AlabasterCard
import com.example.ui.theme.AmberLimited
import com.example.ui.theme.AmberTint
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.ChampagneTint
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CrimsonTint
import com.example.ui.theme.EmeraldAvailable
import com.example.ui.theme.EmeraldTint
import com.example.ui.theme.HairlineBorder
import com.example.ui.theme.IvoryCanvas
import com.example.ui.theme.ObsidianEspresso
import com.example.ui.theme.WarmSandSurface
import com.example.ui.theme.WarmTaupe
import java.time.Instant
import java.time.ZoneOffset

enum class AstorTab(
    val route: String,
    val labelRes: Int
) {
    HOME("home", R.string.nav_home),
    FLEET("fleet", R.string.nav_fleet),
    BOOKINGS("bookings", R.string.nav_bookings),
    CONCIERGE("concierge", R.string.nav_concierge)
}

@Composable
fun AstorMonogramLogo(
    size: Dp = 28.dp,
    tint: Color = ChampagneGold,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier.size(size)) {
        val stroke = Stroke(width = this.size.minDimension * 0.085f, cap = StrokeCap.Round)
        val w = this.size.width
        val h = this.size.height

        // Outer architectural arch
        drawArc(
            color = tint,
            startAngle = 180f,
            sweepAngle = 180f,
            useCenter = false,
            topLeft = Offset(w * 0.14f, h * 0.14f),
            size = Size(w * 0.72f, h * 0.72f),
            style = stroke
        )
        drawLine(
            color = tint,
            start = Offset(w * 0.14f, h * 0.50f),
            end = Offset(w * 0.14f, h * 0.88f),
            strokeWidth = stroke.width,
            cap = StrokeCap.Round
        )
        drawLine(
            color = tint,
            start = Offset(w * 0.86f, h * 0.50f),
            end = Offset(w * 0.86f, h * 0.88f),
            strokeWidth = stroke.width,
            cap = StrokeCap.Round
        )

        // Inner parallel luxury pillars
        drawArc(
            color = tint,
            startAngle = 180f,
            sweepAngle = 180f,
            useCenter = false,
            topLeft = Offset(w * 0.30f, h * 0.28f),
            size = Size(w * 0.40f, h * 0.44f),
            style = stroke
        )
        drawLine(
            color = tint,
            start = Offset(w * 0.30f, h * 0.50f),
            end = Offset(w * 0.30f, h * 0.88f),
            strokeWidth = stroke.width,
            cap = StrokeCap.Round
        )
        drawLine(
            color = tint,
            start = Offset(w * 0.70f, h * 0.50f),
            end = Offset(w * 0.70f, h * 0.88f),
            strokeWidth = stroke.width,
            cap = StrokeCap.Round
        )
        drawLine(
            color = tint,
            start = Offset(w * 0.50f, h * 0.34f),
            end = Offset(w * 0.50f, h * 0.88f),
            strokeWidth = stroke.width,
            cap = StrokeCap.Round
        )
    }
}

@Composable
fun AstorTopBar(
    userPhotoUrl: String?,
    userName: String,
    onAvatarClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            AstorMonogramLogo(size = 28.dp)
            Box(
                modifier = Modifier
                    .width(1.dp)
                    .height(18.dp)
                    .background(HairlineBorder)
            )
            Text(
                text = stringResource(R.string.brand_wordmark),
                style = MaterialTheme.typography.titleSmall.copy(
                    letterSpacing = 3.2.sp,
                    fontWeight = FontWeight.Medium
                ),
                color = ObsidianEspresso
            )
        }

        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .minimumInteractiveComponentSize()
                .size(44.dp)
                .clip(CircleShape)
                .border(1.5.dp, ChampagneGold.copy(alpha = 0.55f), CircleShape)
                .background(WarmSandSurface)
                .clickable(role = Role.Button, onClick = onAvatarClick)
                .testTag("profile_avatar_button")
        ) {
            if (!userPhotoUrl.isNullOrBlank()) {
                AsyncImage(
                    model = userPhotoUrl,
                    contentDescription = "Member profile for $userName",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                )
            } else {
                Text(
                    text = userName.trim().firstOrNull()?.uppercase() ?: "A",
                    style = MaterialTheme.typography.titleMedium,
                    color = ObsidianEspresso
                )
            }
        }
    }
}

@Composable
fun AstorDetailTopBar(
    isBookmarked: Boolean,
    onBackClick: () -> Unit,
    onBookmarkClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        IconButton(
            onClick = onBackClick,
            modifier = Modifier
                .minimumInteractiveComponentSize()
                .testTag("detail_back_button")
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Back to fleet",
                tint = ObsidianEspresso
            )
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            AstorMonogramLogo(size = 24.dp)
            Text(
                text = stringResource(R.string.brand_wordmark),
                style = MaterialTheme.typography.titleSmall.copy(
                    letterSpacing = 2.8.sp,
                    fontWeight = FontWeight.Medium
                ),
                color = ObsidianEspresso
            )
        }

        IconButton(
            onClick = onBookmarkClick,
            modifier = Modifier
                .minimumInteractiveComponentSize()
                .testTag("detail_bookmark_button")
        ) {
            Icon(
                imageVector = if (isBookmarked) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                contentDescription = if (isBookmarked) "Remove from saved fleet" else "Save vehicle",
                tint = if (isBookmarked) ChampagneGold else ObsidianEspresso
            )
        }
    }
}

@Composable
fun AstorBottomNavBar(
    currentRoute: String?,
    onSelectTab: (AstorTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = AlabasterCard,
        tonalElevation = 0.dp,
        shadowElevation = 6.dp,
        modifier = modifier.fillMaxWidth()
    ) {
        Column {
            HorizontalDivider(color = HairlineBorder, thickness = 0.8.dp)
            NavigationBar(
                containerColor = AlabasterCard,
                windowInsets = WindowInsets(0, 0, 0, 0),
                modifier = Modifier.navigationBarsPadding()
            ) {
                AstorTab.entries.forEach { tab ->
                    val selected = currentRoute == tab.route
                    val icon = when (tab) {
                        AstorTab.HOME -> if (selected) Icons.Filled.Home else Icons.Outlined.Home
                        AstorTab.FLEET -> if (selected) Icons.Filled.DirectionsCar else Icons.Outlined.DirectionsCar
                        AstorTab.BOOKINGS -> if (selected) Icons.Filled.CalendarMonth else Icons.Outlined.CalendarMonth
                        AstorTab.CONCIERGE -> if (selected) Icons.Filled.HeadsetMic else Icons.Outlined.HeadsetMic
                    }
                    NavigationBarItem(
                        selected = selected,
                        onClick = { onSelectTab(tab) },
                        icon = {
                            Icon(
                                imageVector = icon,
                                contentDescription = stringResource(tab.labelRes)
                            )
                        },
                        label = {
                            Text(
                                text = stringResource(tab.labelRes),
                                style = MaterialTheme.typography.labelMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = ChampagneGold,
                            selectedTextColor = ChampagneGold,
                            unselectedIconColor = ObsidianEspresso.copy(alpha = 0.7f),
                            unselectedTextColor = ObsidianEspresso.copy(alpha = 0.7f),
                            indicatorColor = ChampagneTint
                        ),
                        modifier = Modifier.testTag("nav_${tab.route}")
                    )
                }
            }
        }
    }
}

@Composable
fun AstorNavigationRail(
    currentRoute: String?,
    onSelectTab: (AstorTab) -> Unit
) {
    NavigationRail(
        containerColor = AlabasterCard,
        header = {
            Box(modifier = Modifier.padding(top = 16.dp, bottom = 12.dp)) {
                AstorMonogramLogo(size = 30.dp)
            }
        }
    ) {
        AstorTab.entries.forEach { tab ->
            val selected = currentRoute == tab.route
            val icon = when (tab) {
                AstorTab.HOME -> if (selected) Icons.Filled.Home else Icons.Outlined.Home
                AstorTab.FLEET -> if (selected) Icons.Filled.DirectionsCar else Icons.Outlined.DirectionsCar
                AstorTab.BOOKINGS -> if (selected) Icons.Filled.CalendarMonth else Icons.Outlined.CalendarMonth
                AstorTab.CONCIERGE -> if (selected) Icons.Filled.HeadsetMic else Icons.Outlined.HeadsetMic
            }
            NavigationRailItem(
                selected = selected,
                onClick = { onSelectTab(tab) },
                icon = { Icon(icon, contentDescription = stringResource(tab.labelRes)) },
                label = { Text(stringResource(tab.labelRes)) },
                colors = NavigationRailItemDefaults.colors(
                    selectedIconColor = ChampagneGold,
                    selectedTextColor = ChampagneGold,
                    unselectedIconColor = ObsidianEspresso.copy(alpha = 0.7f),
                    unselectedTextColor = ObsidianEspresso.copy(alpha = 0.7f),
                    indicatorColor = ChampagneTint
                )
            )
        }
    }
}

@Composable
fun AvailabilityBadge(
    availableBays: Int,
    statusText: String,
    modifier: Modifier = Modifier
) {
    val (bgColor, fgColor) = when {
        availableBays <= 0 -> CrimsonTint to CrimsonAlert
        availableBays == 1 -> AmberTint to AmberLimited
        else -> EmeraldTint to EmeraldAvailable
    }

    Surface(
        color = bgColor,
        shape = RoundedCornerShape(999.dp),
        modifier = modifier
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(fgColor)
            )
            Text(
                text = statusText,
                style = MaterialTheme.typography.labelMedium,
                color = fgColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HubPickerBottomSheet(
    title: String,
    selectedHub: AmericanHub,
    onSelectHub: (AmericanHub) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = AlabasterCard
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.headlineMedium,
                color = ObsidianEspresso
            )
            Text(
                text = "Select an Astor Drive American flagship hub. White-glove delivery is available within 25–35 miles of each salon.",
                style = MaterialTheme.typography.bodyMedium,
                color = WarmTaupe
            )
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(FleetCatalog.hubs, key = { it.id }) { hub ->
                    val isSelected = hub.id == selectedHub.id
                    Surface(
                        color = if (isSelected) ChampagneTint else IvoryCanvas,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(
                            width = if (isSelected) 1.5.dp else 1.dp,
                            color = if (isSelected) ChampagneGold else HairlineBorder
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .clickable {
                                onSelectHub(hub)
                                onDismiss()
                            }
                            .testTag("hub_option_${hub.id}")
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.LocationOn,
                                    contentDescription = null,
                                    tint = if (isSelected) ChampagneGold else WarmTaupe
                                )
                                Column {
                                    Text(
                                        text = hub.displayName,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = ObsidianEspresso
                                    )
                                    Text(
                                        text = "${hub.flagshipAddress} · ${hub.deliveryRadiusMiles} mi delivery",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = WarmTaupe
                                    )
                                }
                            }
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Filled.Check,
                                    contentDescription = "Selected hub",
                                    tint = ChampagneGold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AstorDateRangePickerDialog(
    initialStartEpochDay: Long,
    initialEndEpochDay: Long,
    onDatesConfirmed: (Long, Long) -> Unit,
    onDismiss: () -> Unit
) {
    val startMillis = remember(initialStartEpochDay) { initialStartEpochDay * 86_400_000L }
    val endMillis = remember(initialEndEpochDay) { initialEndEpochDay * 86_400_000L }
    val state = rememberDateRangePickerState(
        initialSelectedStartDateMillis = startMillis,
        initialSelectedEndDateMillis = endMillis
    )

    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(
                onClick = {
                    val s = state.selectedStartDateMillis
                    val e = state.selectedEndDateMillis
                    if (s != null && e != null && e > s) {
                        val sDay = Instant.ofEpochMilli(s).atZone(ZoneOffset.UTC).toLocalDate().toEpochDay()
                        val eDay = Instant.ofEpochMilli(e).atZone(ZoneOffset.UTC).toLocalDate().toEpochDay()
                        onDatesConfirmed(sDay, eDay)
                        onDismiss()
                    }
                },
                enabled = state.selectedStartDateMillis != null &&
                    state.selectedEndDateMillis != null &&
                    (state.selectedEndDateMillis ?: 0L) > (state.selectedStartDateMillis ?: 0L)
            ) {
                Text("Confirm dates", color = ObsidianEspresso, fontWeight = FontWeight.SemiBold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = WarmTaupe)
            }
        }
    ) {
        DateRangePicker(
            state = state,
            title = {
                Text(
                    text = "Select rental dates",
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(start = 24.dp, top = 16.dp)
                )
            },
            headline = {
                Text(
                    text = "Real-time hub availability",
                    style = MaterialTheme.typography.bodyMedium,
                    color = WarmTaupe,
                    modifier = Modifier.padding(start = 24.dp, bottom = 12.dp)
                )
            },
            showModeToggle = false,
            modifier = Modifier.height(460.dp)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MemberProfileSheet(
    userName: String,
    userEmail: String,
    profile: UserProfile?,
    currentHub: AmericanHub,
    onSavePreferences: (String, String) -> Unit,
    onSignOutClick: () -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var selectedHubName by remember(profile, currentHub) {
        mutableStateOf(profile?.defaultHub ?: currentHub.displayName)
    }
    var preferredAddress by remember(profile) {
        mutableStateOf(profile?.preferredDeliveryAddress ?: "")
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = AlabasterCard
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = userName.ifBlank { "Astor Member" },
                        style = MaterialTheme.typography.headlineMedium,
                        color = ObsidianEspresso
                    )
                    Text(
                        text = userEmail,
                        style = MaterialTheme.typography.bodyMedium,
                        color = WarmTaupe
                    )
                }
                Surface(
                    color = ChampagneTint,
                    shape = RoundedCornerShape(999.dp),
                    border = BorderStroke(1.dp, ChampagneGold)
                ) {
                    Text(
                        text = "${profile?.vipTier ?: "Signature"} Tier",
                        style = MaterialTheme.typography.labelMedium,
                        color = ChampagneGold,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }

            HorizontalDivider(color = HairlineBorder)

            Text(
                text = "Personalised Delivery Defaults",
                style = MaterialTheme.typography.titleMedium,
                color = ObsidianEspresso
            )

            OutlinedTextField(
                value = preferredAddress,
                onValueChange = { preferredAddress = it },
                label = { Text("Saved hotel, residence, or FBO address") },
                placeholder = { Text("e.g., Parker Palm Springs, 4200 E Palm Canyon Dr") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedButton(
                    onClick = {
                        onSignOutClick()
                        onDismiss()
                    },
                    border = BorderStroke(1.dp, HairlineBorder),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("sign_out_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Logout,
                        contentDescription = null,
                        tint = ObsidianEspresso,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Sign out", color = ObsidianEspresso)
                }

                Button(
                    onClick = {
                        onSavePreferences(selectedHubName, preferredAddress)
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ObsidianEspresso,
                        contentColor = AlabasterCard
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                ) {
                    Text("Save defaults")
                }
            }
        }
    }
}
