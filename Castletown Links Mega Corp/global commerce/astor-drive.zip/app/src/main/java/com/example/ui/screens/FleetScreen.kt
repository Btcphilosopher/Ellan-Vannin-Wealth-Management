package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.LocalShipping
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.FleetCategory
import com.example.data.model.LiveVehicleAvailability
import com.example.ui.components.AvailabilityBadge
import com.example.ui.theme.AlabasterCard
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.ChampagneTint
import com.example.ui.theme.HairlineBorder
import com.example.ui.theme.IvoryCanvas
import com.example.ui.theme.ObsidianEspresso
import com.example.ui.theme.WarmParchmentPill
import com.example.ui.theme.WarmTaupe
import com.example.ui.viewmodel.TripPlannerState

@Composable
fun FleetScreen(
    planner: TripPlannerState,
    fleetAvailability: List<LiveVehicleAvailability>,
    savedVehicleIds: Set<String>,
    onSelectCategory: (String) -> Unit,
    onToggleShowSavedOnly: (Boolean) -> Unit,
    onOpenPickupPicker: () -> Unit,
    onOpenDatePicker: () -> Unit,
    onToggleSaved: (String) -> Unit,
    onSelectVehicle: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val filteredFleet = fleetAvailability.filter { item ->
        val matchesSaved = !planner.showSavedOnly || savedVehicleIds.contains(item.vehicle.id)
        val matchesCategory = planner.selectedCategory == FleetCategory.ALL.label ||
            item.vehicle.category == planner.selectedCategory
        matchesSaved && matchesCategory
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(IvoryCanvas),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = stringResource(R.string.fleet_title),
                        style = MaterialTheme.typography.displayMedium,
                        color = ObsidianEspresso
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Surface(
                            color = WarmParchmentPill,
                            shape = RoundedCornerShape(999.dp),
                            border = BorderStroke(1.dp, HairlineBorder),
                            modifier = Modifier
                                .clip(RoundedCornerShape(999.dp))
                                .clickable(onClick = onOpenPickupPicker)
                                .testTag("fleet_hub_pill")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp),
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.LocationOn,
                                    contentDescription = null,
                                    tint = ChampagneGold,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = planner.pickupHub.city,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = ObsidianEspresso
                                )
                            }
                        }

                        Surface(
                            color = WarmParchmentPill,
                            shape = RoundedCornerShape(999.dp),
                            border = BorderStroke(1.dp, HairlineBorder),
                            modifier = Modifier
                                .clip(RoundedCornerShape(999.dp))
                                .clickable(onClick = onOpenDatePicker)
                                .testTag("fleet_dates_pill")
                        ) {
                            Text(
                                text = planner.formattedDateRange,
                                style = MaterialTheme.typography.labelLarge,
                                color = ObsidianEspresso,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Category filter pills matching mockup ("All", "SUVs", "Sports", "Electric") + Saved
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(FleetCategory.entries) { category ->
                            val isSelected = !planner.showSavedOnly && planner.selectedCategory == category.label
                            FilterChipPill(
                                label = category.label,
                                selected = isSelected,
                                onClick = { onSelectCategory(category.label) },
                                testTag = "filter_${category.label.lowercase()}"
                            )
                        }
                        item {
                            FilterChipPill(
                                label = "Saved (${savedVehicleIds.size})",
                                selected = planner.showSavedOnly,
                                onClick = { onToggleShowSavedOnly(!planner.showSavedOnly) },
                                testTag = "filter_saved"
                            )
                        }
                    }
                }
            }

            if (filteredFleet.isEmpty()) {
                item {
                    Surface(
                        color = AlabasterCard,
                        shape = RoundedCornerShape(20.dp),
                        border = BorderStroke(1.dp, HairlineBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(28.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.BookmarkBorder,
                                contentDescription = null,
                                tint = ChampagneGold,
                                modifier = Modifier.size(36.dp)
                            )
                            Text(
                                text = "No saved vehicles yet",
                                style = MaterialTheme.typography.headlineSmall,
                                color = ObsidianEspresso
                            )
                            Text(
                                text = "Tap the bookmark icon on any flagship model to curate your personal Astor garage.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = WarmTaupe,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            } else {
                items(filteredFleet, key = { it.vehicle.id }) { item ->
                    FleetVehicleCard(
                        availability = item,
                        isSaved = savedVehicleIds.contains(item.vehicle.id),
                        onToggleSaved = { onToggleSaved(item.vehicle.id) },
                        onViewVehicle = { onSelectVehicle(item.vehicle.id) }
                    )
                }
            }

            item {
                Text(
                    text = stringResource(R.string.fleet_footer_note),
                    style = MaterialTheme.typography.bodySmall,
                    color = WarmTaupe,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                )
            }
        }
    }
}

@Composable
private fun FilterChipPill(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    Surface(
        color = if (selected) ObsidianEspresso else WarmParchmentPill,
        shape = RoundedCornerShape(999.dp),
        border = BorderStroke(1.dp, if (selected) ObsidianEspresso else HairlineBorder),
        modifier = Modifier
            .clip(RoundedCornerShape(999.dp))
            .clickable(onClick = onClick)
            .testTag(testTag)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            color = if (selected) AlabasterCard else ObsidianEspresso,
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp)
        )
    }
}

@Composable
private fun FleetVehicleCard(
    availability: LiveVehicleAvailability,
    isSaved: Boolean,
    onToggleSaved: () -> Unit,
    onViewVehicle: () -> Unit
) {
    val vehicle = availability.vehicle
    Surface(
        color = AlabasterCard,
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, HairlineBorder),
        shadowElevation = 2.dp,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onViewVehicle)
            .testTag("fleet_card_${vehicle.id}")
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(195.dp)
            ) {
                Image(
                    painter = painterResource(id = vehicle.imageRes),
                    contentDescription = "${vehicle.name} studio view",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                AvailabilityBadge(
                    availableBays = availability.availableBays,
                    statusText = availability.statusText,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(12.dp)
                )
                Surface(
                    color = AlabasterCard.copy(alpha = 0.9f),
                    shape = CircleShape,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(10.dp)
                        .minimumInteractiveComponentSize()
                ) {
                    IconButton(
                        onClick = onToggleSaved,
                        modifier = Modifier
                            .size(40.dp)
                            .testTag("bookmark_${vehicle.id}")
                    ) {
                        Icon(
                            imageVector = if (isSaved) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                            contentDescription = if (isSaved) "Remove bookmark" else "Bookmark ${vehicle.name}",
                            tint = if (isSaved) ChampagneGold else ObsidianEspresso
                        )
                    }
                }
            }

            Column(
                modifier = Modifier.padding(horizontal = 18.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = vehicle.name,
                            style = MaterialTheme.typography.headlineMedium,
                            color = ObsidianEspresso
                        )
                        Text(
                            text = "${vehicle.categorySubtitle} · ${vehicle.seats} seats · ${vehicle.transmission}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = WarmTaupe
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.LocalShipping,
                        contentDescription = null,
                        tint = ChampagneGold,
                        modifier = Modifier.size(15.dp)
                    )
                    Text(
                        text = "${vehicle.powertrainSpec} · ${vehicle.deliveryLeadMinutes} min delivery",
                        style = MaterialTheme.typography.bodySmall,
                        color = ChampagneGold,
                        fontWeight = FontWeight.Medium
                    )
                }

                Spacer(modifier = Modifier.height(2.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(
                            text = "$${vehicle.dailyRateUsd}",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold
                            ),
                            color = ObsidianEspresso
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "/ day",
                            style = MaterialTheme.typography.bodyMedium,
                            color = WarmTaupe,
                            modifier = Modifier.padding(bottom = 2.dp)
                        )
                    }

                    OutlinedButton(
                        onClick = onViewVehicle,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.2.dp, ChampagneGold.copy(alpha = 0.7f)),
                        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 10.dp),
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("view_vehicle_${vehicle.id}")
                    ) {
                        Text(
                            text = stringResource(R.string.cta_view_vehicle),
                            style = MaterialTheme.typography.labelLarge,
                            color = ChampagneGold
                        )
                    }
                }
            }
        }
    }
}
