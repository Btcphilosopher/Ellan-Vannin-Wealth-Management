package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.firebase.AstorDriveRepository
import com.example.data.model.DeliveryType
import com.example.data.model.FleetCatalog
import com.example.ui.auth.AstorDriveAuthScreen
import com.example.ui.auth.signOut
import com.example.ui.components.AstorBottomNavBar
import com.example.ui.components.AstorDateRangePickerDialog
import com.example.ui.components.AstorNavigationRail
import com.example.ui.components.AstorTab
import com.example.ui.components.AstorTopBar
import com.example.ui.components.HubPickerBottomSheet
import com.example.ui.components.MemberProfileSheet
import com.example.ui.screens.BookingsScreen
import com.example.ui.screens.ConciergeScreen
import com.example.ui.screens.FleetScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.VehicleDetailScreen
import com.example.ui.theme.AlabasterCard
import com.example.ui.theme.AstorDriveTheme
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.IvoryCanvas
import com.example.ui.theme.ObsidianEspresso
import com.example.ui.viewmodel.AstorDriveViewModel
import com.example.ui.viewmodel.UiState
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

const val ROUTE_VEHICLE_DETAIL = "vehicle/{vehicleId}"

internal fun FirebaseAuth.authStateFlow(): Flow<FirebaseUser?> = callbackFlow {
    val listener = FirebaseAuth.AuthStateListener { auth ->
        trySend(auth.currentUser)
    }
    addAuthStateListener(listener)
    awaitClose { removeAuthStateListener(listener) }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AstorDriveTheme {
                AppNavigation()
            }
        }
    }
}

@Composable
fun AppNavigation(auth: FirebaseAuth = Firebase.auth) {
    val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)
    val user = currentUser

    if (user == null) {
        AstorDriveAuthScreen(
            onAuthSuccess = { /* AuthStateListener drives transition automatically */ }
        )
    } else {
        key(user.uid) {
            AstorDriveMainShell(
                currentUserId = user.uid,
                userName = user.displayName ?: "Astor Member",
                userEmail = user.email ?: "",
                userPhotoUrl = user.photoUrl?.toString()
            )
        }
    }
}

@Composable
fun AstorDriveMainShell(
    currentUserId: String,
    userName: String,
    userEmail: String,
    userPhotoUrl: String?
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    val viewModel: AstorDriveViewModel = viewModel(
        key = currentUserId,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) {
                    "APPLICATION_KEY missing from CreationExtras"
                }
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                AstorDriveViewModel(
                    repository = AstorDriveRepository(db),
                    currentUserId = currentUserId,
                    userDisplayName = userName,
                    userEmail = userEmail
                )
            }
        }
    )

    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val planner by viewModel.planner.collectAsStateWithLifecycle()
    val fleetAvailability by viewModel.fleetAvailability.collectAsStateWithLifecycle()
    val savedVehicleIds by viewModel.savedVehicleIds.collectAsStateWithLifecycle()
    val bookingsState by viewModel.bookingsState.collectAsStateWithLifecycle()
    val conciergeRequestsState by viewModel.conciergeRequestsState.collectAsStateWithLifecycle()
    val userProfileState by viewModel.userProfileState.collectAsStateWithLifecycle()
    val feedback by viewModel.feedback.collectAsStateWithLifecycle()
    val isSubmitting by viewModel.isSubmitting.collectAsStateWithLifecycle()
    val prefilledConciergeVehicle by viewModel.prefilledConciergeVehicle.collectAsStateWithLifecycle()

    var showPickupPicker by remember { mutableStateOf(false) }
    var showReturnPicker by remember { mutableStateOf(false) }
    var showDatePicker by remember { mutableStateOf(false) }
    var showProfileSheet by remember { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(feedback) {
        feedback?.let {
            snackbarHostState.showSnackbar(
                message = it.message,
                duration = SnackbarDuration.Short
            )
            viewModel.clearFeedback()
        }
    }

    val isDetailScreen = currentRoute?.startsWith("vehicle/") == true
    val screenWidthDp = LocalConfiguration.current.screenWidthDp
    val useNavigationRail = screenWidthDp >= 600

    fun navigateToTab(tab: AstorTab) {
        navController.navigate(tab.route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    Scaffold(
        containerColor = IvoryCanvas,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = {
            SnackbarHost(hostState = snackbarHostState) { data ->
                Snackbar(
                    snackbarData = data,
                    containerColor = if (feedback?.isError == true) CrimsonAlert else ObsidianEspresso,
                    contentColor = AlabasterCard,
                    shape = RoundedCornerShape(12.dp)
                )
            }
        },
        topBar = {
            if (!isDetailScreen) {
                AstorTopBar(
                    userPhotoUrl = userPhotoUrl,
                    userName = userName,
                    onAvatarClick = { showProfileSheet = true }
                )
            }
        },
        bottomBar = {
            if (!isDetailScreen && !useNavigationRail) {
                AstorBottomNavBar(
                    currentRoute = currentRoute,
                    onSelectTab = ::navigateToTab
                )
            }
        }
    ) { innerPadding ->
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (!isDetailScreen && useNavigationRail) {
                AstorNavigationRail(
                    currentRoute = currentRoute,
                    onSelectTab = ::navigateToTab
                )
            }

            Box(modifier = Modifier.weight(1f)) {
                NavHost(
                    navController = navController,
                    startDestination = AstorTab.HOME.route
                ) {
                    composable(AstorTab.HOME.route) {
                        HomeScreen(
                            planner = planner,
                            fleetAvailability = fleetAvailability,
                            onOpenPickupPicker = { showPickupPicker = true },
                            onOpenReturnPicker = { showReturnPicker = true },
                            onOpenDatePicker = { showDatePicker = true },
                            onToggleReturnSameLocation = viewModel::setReturnToSameLocation,
                            onTogglePersonalisedDelivery = { enabled ->
                                viewModel.setDeliveryType(
                                    if (enabled) DeliveryType.PERSONALISED_DELIVERY
                                    else DeliveryType.HUB_COLLECTION
                                )
                            },
                            onExploreFleet = { navigateToTab(AstorTab.FLEET) },
                            onSelectVehicle = { vehicleId ->
                                navController.navigate("vehicle/$vehicleId")
                            },
                            onOpenConcierge = { navigateToTab(AstorTab.CONCIERGE) }
                        )
                    }

                    composable(AstorTab.FLEET.route) {
                        FleetScreen(
                            planner = planner,
                            fleetAvailability = fleetAvailability,
                            savedVehicleIds = savedVehicleIds,
                            onSelectCategory = viewModel::selectCategory,
                            onToggleShowSavedOnly = viewModel::setShowSavedOnly,
                            onOpenPickupPicker = { showPickupPicker = true },
                            onOpenDatePicker = { showDatePicker = true },
                            onToggleSaved = viewModel::toggleSavedVehicle,
                            onSelectVehicle = { vehicleId ->
                                navController.navigate("vehicle/$vehicleId")
                            }
                        )
                    }

                    composable(AstorTab.BOOKINGS.route) {
                        BookingsScreen(
                            bookingsState = bookingsState,
                            onUpdateDelivery = viewModel::updateBookingDelivery,
                            onCancelBooking = viewModel::cancelBooking,
                            onExploreFleet = { navigateToTab(AstorTab.FLEET) }
                        )
                    }

                    composable(AstorTab.CONCIERGE.route) {
                        ConciergeScreen(
                            planner = planner,
                            prefilledVehicle = prefilledConciergeVehicle,
                            conciergeRequestsState = conciergeRequestsState,
                            isSubmitting = isSubmitting,
                            onOpenPickupPicker = { showPickupPicker = true },
                            onSubmitRequest = viewModel::submitConciergeRequest,
                            onCancelRequest = viewModel::cancelConciergeRequest
                        )
                    }

                    composable(
                        route = ROUTE_VEHICLE_DETAIL,
                        arguments = listOf(navArgument("vehicleId") { type = NavType.StringType })
                    ) { entry ->
                        val vehicleId = entry.arguments?.getString("vehicleId")
                            ?: FleetCatalog.vehicles.first().id
                        val availability = fleetAvailability.firstOrNull { it.vehicle.id == vehicleId }
                            ?: fleetAvailability.first()

                        VehicleDetailScreen(
                            availability = availability,
                            planner = planner,
                            isBookmarked = savedVehicleIds.contains(availability.vehicle.id),
                            isSubmitting = isSubmitting,
                            onBackClick = { navController.popBackStack() },
                            onToggleBookmark = { viewModel.toggleSavedVehicle(availability.vehicle.id) },
                            onOpenDatePicker = { showDatePicker = true },
                            onOpenPickupPicker = { showPickupPicker = true },
                            onSelectDeliveryType = viewModel::setDeliveryType,
                            onDeliveryAddressChange = viewModel::updateDeliveryAddress,
                            onSelectTimeWindow = viewModel::selectDeliveryTimeWindow,
                            onToggleChauffeur = viewModel::setChauffeurRequested,
                            onConciergeNotesChange = viewModel::updateConciergeNotes,
                            onConfirmBooking = {
                                viewModel.confirmReservation(availability) {
                                    navController.popBackStack()
                                    navigateToTab(AstorTab.BOOKINGS)
                                }
                            },
                            onOpenConciergeSupport = {
                                viewModel.prefillConciergeForVehicle(availability.vehicle.name)
                                navController.popBackStack()
                                navigateToTab(AstorTab.CONCIERGE)
                            }
                        )
                    }
                }
            }
        }
    }

    if (showPickupPicker) {
        HubPickerBottomSheet(
            title = "Select pick-up hub",
            selectedHub = planner.pickupHub,
            onSelectHub = viewModel::selectPickupHub,
            onDismiss = { showPickupPicker = false }
        )
    }

    if (showReturnPicker) {
        HubPickerBottomSheet(
            title = "Select return hub",
            selectedHub = planner.returnHub,
            onSelectHub = viewModel::selectReturnHub,
            onDismiss = { showReturnPicker = false }
        )
    }

    if (showDatePicker) {
        AstorDateRangePickerDialog(
            initialStartEpochDay = planner.startEpochDay,
            initialEndEpochDay = planner.endEpochDay,
            onDatesConfirmed = viewModel::updateDates,
            onDismiss = { showDatePicker = false }
        )
    }

    if (showProfileSheet) {
        val profile = (userProfileState as? UiState.Success)?.data
        MemberProfileSheet(
            userName = userName,
            userEmail = userEmail,
            profile = profile,
            currentHub = planner.pickupHub,
            onSavePreferences = viewModel::updateMemberDeliveryDefaults,
            onSignOutClick = {
                signOut(credentialManager = credentialManager, scope = scope)
            },
            onDismiss = { showProfileSheet = false }
        )
    }
}
