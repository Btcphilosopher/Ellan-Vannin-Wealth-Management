package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.outlined.AirlineSeatReclineNormal
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.HeadsetMic
import androidx.compose.material.icons.outlined.LocalShipping
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.Luggage
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.DeliveryType
import com.example.data.model.FleetCatalog
import com.example.data.model.LiveVehicleAvailability
import com.example.ui.components.AstorDetailTopBar
import com.example.ui.components.AvailabilityBadge
import com.example.ui.theme.AlabasterCard
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.ChampagneTint
import com.example.ui.theme.HairlineBorder
import com.example.ui.theme.IvoryCanvas
import com.example.ui.theme.ObsidianEspresso
import com.example.ui.theme.WarmParchmentPill
import com.example.ui.theme.WarmSandSurface
import com.example.ui.theme.WarmTaupe
import com.example.ui.viewmodel.TripPlannerState
import java.text.NumberFormat
import java.util.Locale

@Composable
fun VehicleDetailScreen(
    availability: LiveVehicleAvailability,
    planner: TripPlannerState,
    isBookmarked: Boolean,
    isSubmitting: Boolean,
    onBackClick: () -> Unit,
    onToggleBookmark: () -> Unit,
    onOpenDatePicker: () -> Unit,
    onOpenPickupPicker: () -> Unit,
    onSelectDeliveryType: (DeliveryType) -> Unit,
    onDeliveryAddressChange: (String) -> Unit,
    onSelectTimeWindow: (String) -> Unit,
    onToggleChauffeur: (Boolean) -> Unit,
    onConciergeNotesChange: (String) -> Unit,
    onConfirmBooking: () -> Unit,
    onOpenConciergeSupport: () -> Unit,
    modifier: Modifier = Modifier
) {
    val vehicle = availability.vehicle
    val days = planner.daysCount
    val subtotal = vehicle.dailyRateUsd * days
    val deliveryFee = if (planner.deliveryType == DeliveryType.PERSONALISED_DELIVERY) {
        vehicle.deliveryFeeUsd
    } else {
        0
    }
    val chauffeurFee = if (planner.chauffeurRequested) 140 * days else 0
    val totalDeliveryFee = deliveryFee + chauffeurFee
    val taxesAndFees = ((subtotal + totalDeliveryFee) * 0.1525).toInt()
    val estimatedTotal = subtotal + totalDeliveryFee + taxesAndFees
    val usd = NumberFormat.getNumberInstance(Locale.US)

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(IvoryCanvas)
    ) {
        AstorDetailTopBar(
            isBookmarked = isBookmarked,
            onBackClick = onBackClick,
            onBookmarkClick = onToggleBookmark
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding()
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp)
                .widthIn(max = 680.dp)
                .align(Alignment.CenterHorizontally),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = stringResource(R.string.reservation_title),
                style = MaterialTheme.typography.displayMedium,
                color = ObsidianEspresso
            )

            // Hero photo
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(215.dp)
                    .clip(RoundedCornerShape(20.dp))
            ) {
                Image(
                    painter = painterResource(id = vehicle.heroImageRes),
                    contentDescription = "${vehicle.name} exterior view",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                AvailabilityBadge(
                    availableBays = availability.availableBays,
                    statusText = availability.statusText,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(12.dp)
                )
            }

            // Title & Trim
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = vehicle.name,
                    style = MaterialTheme.typography.displayMedium.copy(fontSize = 28.sp),
                    color = ObsidianEspresso
                )
                Text(
                    text = "${vehicle.trim} · ${vehicle.horsepower} hp · 0–60 in ${vehicle.zeroToSixty}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = ChampagneGold,
                    fontWeight = FontWeight.Medium
                )
            }

            // Spec Row matching mockup (7 seats | 4 bags | Automatic)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SpecItem(
                    icon = Icons.Outlined.AirlineSeatReclineNormal,
                    label = "${vehicle.seats} seats"
                )
                VerticalHairline()
                SpecItem(
                    icon = Icons.Outlined.Luggage,
                    label = "${vehicle.bags} bags"
                )
                VerticalHairline()
                SpecItem(
                    icon = Icons.Outlined.Settings,
                    label = vehicle.transmission
                )
            }

            // Reservation & Personalised Delivery Summary Card
            Surface(
                color = AlabasterCard,
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, HairlineBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Dates & Hub Row
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .clickable(onClick = onOpenDatePicker)
                            .padding(vertical = 4.dp)
                            .testTag("detail_dates_row")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.CalendarMonth,
                            contentDescription = null,
                            tint = ObsidianEspresso,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "${planner.formattedDateRange} · $days ${if (days == 1) "day" else "days"}",
                            style = MaterialTheme.typography.titleMedium,
                            color = ObsidianEspresso
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .clickable(onClick = onOpenPickupPicker)
                            .padding(vertical = 4.dp)
                            .testTag("detail_hub_row")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.LocationOn,
                            contentDescription = null,
                            tint = ObsidianEspresso,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = if (planner.deliveryType == DeliveryType.HUB_COLLECTION) {
                                planner.pickupHub.shortCode
                            } else {
                                "Delivered from ${planner.pickupHub.city} (${vehicle.deliveryLeadMinutes} min)"
                            },
                            style = MaterialTheme.typography.bodyLarge,
                            color = ObsidianEspresso
                        )
                    }

                    HorizontalDivider(color = HairlineBorder, thickness = 0.8.dp)

                    // Collection vs Personalised Delivery selector
                    Text(
                        text = "Handoff service",
                        style = MaterialTheme.typography.titleSmall,
                        color = WarmTaupe
                    )
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        DeliveryOptionCard(
                            selected = planner.deliveryType == DeliveryType.HUB_COLLECTION,
                            title = "Hub collection",
                            subtitle = "Complimentary",
                            onClick = { onSelectDeliveryType(DeliveryType.HUB_COLLECTION) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("delivery_option_hub")
                        )
                        DeliveryOptionCard(
                            selected = planner.deliveryType == DeliveryType.PERSONALISED_DELIVERY,
                            title = "Personalised delivery",
                            subtitle = "+$${vehicle.deliveryFeeUsd} white-glove",
                            onClick = { onSelectDeliveryType(DeliveryType.PERSONALISED_DELIVERY) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("delivery_option_personalised")
                        )
                    }

                    AnimatedVisibility(
                        visible = planner.deliveryType == DeliveryType.PERSONALISED_DELIVERY
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            OutlinedTextField(
                                value = planner.deliveryAddress,
                                onValueChange = onDeliveryAddressChange,
                                label = { Text("Hotel, residence, or FBO address") },
                                placeholder = { Text("e.g., The Beverly Hills Hotel, 9641 Sunset Blvd") },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("delivery_address_input")
                            )

                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                contentPadding = PaddingValues(vertical = 2.dp)
                            ) {
                                items(
                                    listOf(
                                        "Parker Palm Springs",
                                        "The Beverly Hills Hotel",
                                        "Signature Aviation FBO"
                                    )
                                ) { preset ->
                                    Surface(
                                        color = WarmParchmentPill,
                                        shape = RoundedCornerShape(999.dp),
                                        border = BorderStroke(1.dp, HairlineBorder),
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(999.dp))
                                            .clickable { onDeliveryAddressChange(preset) }
                                    ) {
                                        Text(
                                            text = preset,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = ObsidianEspresso,
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                        )
                                    }
                                }
                            }

                            Text(
                                text = "Preferred handoff window",
                                style = MaterialTheme.typography.bodySmall,
                                color = WarmTaupe
                            )
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(FleetCatalog.deliveryTimeWindows) { window ->
                                    val selected = planner.deliveryTimeWindow == window
                                    Surface(
                                        color = if (selected) ObsidianEspresso else WarmParchmentPill,
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(10.dp))
                                            .clickable { onSelectTimeWindow(window) }
                                    ) {
                                        Text(
                                            text = window,
                                            style = MaterialTheme.typography.labelMedium,
                                            color = if (selected) AlabasterCard else ObsidianEspresso,
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Dedicated Chauffeur Add-on
                    Surface(
                        color = WarmSandSurface.copy(alpha = 0.55f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Dedicated Astor Chauffeur",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = ObsidianEspresso
                                )
                                Text(
                                    text = "+$140 / day · Uniformed private driver",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = WarmTaupe
                                )
                            }
                            Switch(
                                checked = planner.chauffeurRequested,
                                onCheckedChange = onToggleChauffeur,
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = AlabasterCard,
                                    checkedTrackColor = ChampagneGold
                                ),
                                modifier = Modifier.testTag("chauffeur_switch")
                            )
                        }
                    }

                    OutlinedTextField(
                        value = planner.conciergeNotes,
                        onValueChange = onConciergeNotesChange,
                        label = { Text("Concierge prep notes (optional)") },
                        placeholder = { Text("Cabin beverages, luggage assistance, child seat") },
                        maxLines = 2,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("concierge_notes_input")
                    )

                    HorizontalDivider(color = HairlineBorder, thickness = 0.8.dp)

                    // Itemized Pricing Card
                    PricingRow("Rental subtotal ($${vehicle.dailyRateUsd} × $days d)", "$${usd.format(subtotal)}")
                    if (deliveryFee > 0) {
                        PricingRow("Personalised white-glove delivery", "$${usd.format(deliveryFee)}")
                    }
                    if (chauffeurFee > 0) {
                        PricingRow("Dedicated chauffeur ($days d)", "$${usd.format(chauffeurFee)}")
                    }
                    PricingRow("Estimated taxes & fees", "$${usd.format(taxesAndFees)}")

                    HorizontalDivider(color = HairlineBorder, thickness = 0.8.dp)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Estimated total",
                            style = MaterialTheme.typography.titleLarge,
                            color = ObsidianEspresso
                        )
                        Text(
                            text = "$${usd.format(estimatedTotal)} USD",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold
                            ),
                            color = ObsidianEspresso
                        )
                    }

                    Text(
                        text = "${stringResource(R.string.security_deposit_note)} ($${usd.format(vehicle.securityDepositUsd)} refundable hold)",
                        style = MaterialTheme.typography.bodySmall,
                        color = WarmTaupe
                    )
                }
            }

            // Continue to Booking CTA
            Button(
                onClick = onConfirmBooking,
                enabled = !isSubmitting && availability.isAvailableNow,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = ObsidianEspresso,
                    contentColor = AlabasterCard
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("continue_booking_button")
            ) {
                if (isSubmitting) {
                    CircularProgressIndicator(
                        color = AlabasterCard,
                        strokeWidth = 2.dp,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text("Confirming reservation…")
                } else {
                    Text(
                        text = if (availability.isAvailableNow) {
                            stringResource(R.string.cta_continue_booking)
                        } else {
                            "Unavailable on selected dates"
                        },
                        style = MaterialTheme.typography.titleMedium
                    )
                    if (availability.isAvailableNow) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // Concierge support link matching mockup
            Row(
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .clip(RoundedCornerShape(10.dp))
                    .clickable(onClick = onOpenConciergeSupport)
                    .padding(horizontal = 16.dp, vertical = 10.dp)
                    .testTag("concierge_support_link"),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.HeadsetMic,
                    contentDescription = null,
                    tint = ObsidianEspresso,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = stringResource(R.string.concierge_support),
                    style = MaterialTheme.typography.titleSmall.copy(
                        textDecoration = TextDecoration.Underline
                    ),
                    color = ObsidianEspresso
                )
            }
        }
    }
}

@Composable
private fun SpecItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = ObsidianEspresso,
            modifier = Modifier.size(18.dp)
        )
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = ObsidianEspresso
        )
    }
}

@Composable
private fun VerticalHairline() {
    Box(
        modifier = Modifier
            .width(1.dp)
            .height(18.dp)
            .background(HairlineBorder)
    )
}

@Composable
private fun DeliveryOptionCard(
    selected: Boolean,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = if (selected) ChampagneTint else IvoryCanvas,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(
            width = if (selected) 1.5.dp else 1.dp,
            color = if (selected) ChampagneGold else HairlineBorder
        ),
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = ObsidianEspresso
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = if (selected) ChampagneGold else WarmTaupe
            )
        }
    }
}

@Composable
private fun PricingRow(label: String, amount: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyLarge,
            color = WarmTaupe
        )
        Text(
            text = amount,
            style = MaterialTheme.typography.titleMedium,
            color = ObsidianEspresso
        )
    }
}
