package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.FlightLand
import androidx.compose.material.icons.outlined.HeadsetMic
import androidx.compose.material.icons.outlined.LocalShipping
import androidx.compose.material.icons.outlined.Remove
import androidx.compose.material.icons.outlined.Route
import androidx.compose.material.icons.outlined.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.ConciergeRequest
import com.example.data.model.ConciergeRequestType
import com.example.data.model.FleetCatalog
import com.example.ui.theme.AlabasterCard
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.ChampagneTint
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CrimsonTint
import com.example.ui.theme.EmeraldAvailable
import com.example.ui.theme.EmeraldTint
import com.example.ui.theme.HairlineBorder
import com.example.ui.theme.IvoryCanvas
import com.example.ui.theme.ObsidianEspresso
import com.example.ui.theme.WarmParchmentPill
import com.example.ui.theme.WarmSandSurface
import com.example.ui.theme.WarmTaupe
import com.example.ui.viewmodel.TripPlannerState
import com.example.ui.viewmodel.UiState

@Composable
fun ConciergeScreen(
    planner: TripPlannerState,
    prefilledVehicle: String?,
    conciergeRequestsState: UiState<List<ConciergeRequest>>,
    isSubmitting: Boolean,
    onOpenPickupPicker: () -> Unit,
    onSubmitRequest: (
        type: ConciergeRequestType,
        pickupLocation: String,
        preferredDateText: String,
        deliveryAddress: String,
        vehiclePreference: String,
        guestCount: Int,
        notes: String
    ) -> Unit,
    onCancelRequest: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedType by remember { mutableStateOf(ConciergeRequestType.BESPOKE_DELIVERY) }
    var preferredDateText by remember(planner.formattedDateRange) {
        mutableStateOf("${planner.formattedDateRange} · 2:00 PM")
    }
    var deliveryAddress by remember(planner.deliveryAddress) {
        mutableStateOf(planner.deliveryAddress)
    }
    var vehiclePreference by remember(prefilledVehicle) {
        mutableStateOf(prefilledVehicle ?: FleetCatalog.vehicles.first().name)
    }
    var guestCount by remember { mutableIntStateOf(2) }
    var notes by remember { mutableStateOf("") }

    LaunchedEffect(prefilledVehicle) {
        if (!prefilledVehicle.isNullOrBlank()) {
            vehiclePreference = prefilledVehicle
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(IvoryCanvas),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = stringResource(R.string.concierge_title),
                        style = MaterialTheme.typography.displayMedium,
                        color = ObsidianEspresso
                    )
                    Text(
                        text = "Direct priority desk for tarmac handoffs, bespoke routes, and private chauffeurs.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = WarmTaupe
                    )

                    // Specialist Presence Banner
                    Surface(
                        color = ObsidianEspresso,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Surface(
                                color = ChampagneGold.copy(alpha = 0.22f),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.size(44.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Outlined.HeadsetMic,
                                        contentDescription = null,
                                        tint = ChampagneGold
                                    )
                                }
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "24/7 DEDICATED DESK",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ChampagneGold
                                )
                                Text(
                                    text = "Julian Vance · Senior Concierge",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = AlabasterCard
                                )
                                Text(
                                    text = "Average response under 8 minutes",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = AlabasterCard.copy(alpha = 0.78f)
                                )
                            }
                            Icon(
                                imageVector = Icons.Outlined.Verified,
                                contentDescription = "Verified specialist",
                                tint = ChampagneGold
                            )
                        }
                    }
                }
            }

            // Concierge Booking Composer Card
            item {
                Surface(
                    color = AlabasterCard,
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, HairlineBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            text = "Exclusive Concierge Booking",
                            style = MaterialTheme.typography.headlineSmall,
                            color = ObsidianEspresso
                        )

                        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(ConciergeRequestType.entries) { type ->
                                val isSelected = selectedType == type
                                val icon = when (type) {
                                    ConciergeRequestType.BESPOKE_DELIVERY -> Icons.Outlined.LocalShipping
                                    ConciergeRequestType.FBO_TARMAC_HANDOFF -> Icons.Outlined.FlightLand
                                    ConciergeRequestType.CHAUFFEUR_SERVICE -> Icons.Outlined.HeadsetMic
                                    ConciergeRequestType.CUSTOM_ITINERARY -> Icons.Outlined.Route
                                    ConciergeRequestType.VEHICLE_SOURCING -> Icons.Outlined.Verified
                                }
                                Surface(
                                    color = if (isSelected) ChampagneTint else IvoryCanvas,
                                    shape = RoundedCornerShape(14.dp),
                                    border = BorderStroke(
                                        width = if (isSelected) 1.5.dp else 1.dp,
                                        color = if (isSelected) ChampagneGold else HairlineBorder
                                    ),
                                    modifier = Modifier
                                        .width(172.dp)
                                        .clip(RoundedCornerShape(14.dp))
                                        .clickable { selectedType = type }
                                        .testTag("concierge_type_${type.value}")
                                ) {
                                    Column(
                                        modifier = Modifier.padding(12.dp),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            imageVector = icon,
                                            contentDescription = null,
                                            tint = if (isSelected) ChampagneGold else ObsidianEspresso,
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Text(
                                            text = type.title,
                                            style = MaterialTheme.typography.titleSmall,
                                            color = ObsidianEspresso
                                        )
                                        Text(
                                            text = type.subtitle,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = WarmTaupe,
                                            maxLines = 2
                                        )
                                    }
                                }
                            }
                        }

                        // Hub selector pill
                        Surface(
                            color = IvoryCanvas,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, HairlineBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable(onClick = onOpenPickupPicker)
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "Regional Hub",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = WarmTaupe
                                    )
                                    Text(
                                        text = planner.pickupHub.displayName,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = ObsidianEspresso
                                    )
                                }
                                Text(
                                    text = "Change",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = ChampagneGold
                                )
                            }
                        }

                        // Vehicle preference quick pills
                        Text(
                            text = "Vehicle preference",
                            style = MaterialTheme.typography.titleSmall,
                            color = WarmTaupe
                        )
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(FleetCatalog.vehicles) { vehicle ->
                                val selected = vehiclePreference == vehicle.name
                                Surface(
                                    color = if (selected) ObsidianEspresso else WarmParchmentPill,
                                    shape = RoundedCornerShape(999.dp),
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(999.dp))
                                        .clickable { vehiclePreference = vehicle.name }
                                ) {
                                    Text(
                                        text = vehicle.name,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = if (selected) AlabasterCard else ObsidianEspresso,
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                                    )
                                }
                            }
                        }

                        OutlinedTextField(
                            value = preferredDateText,
                            onValueChange = { preferredDateText = it },
                            label = { Text("Arrival date & handoff time") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("concierge_date_input")
                        )

                        OutlinedTextField(
                            value = deliveryAddress,
                            onValueChange = { deliveryAddress = it },
                            label = { Text("Destination, hotel, or FBO tail number") },
                            placeholder = { Text("e.g., Signature Aviation LAX · Tail N808AD") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("concierge_address_input")
                        )

                        // Guest count stepper
                        Surface(
                            color = WarmSandSurface.copy(alpha = 0.55f),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Passengers & luggage party",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = ObsidianEspresso
                                )
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(
                                        onClick = { if (guestCount > 1) guestCount-- }
                                    ) {
                                        Icon(
                                            imageVector = Icons.Outlined.Remove,
                                            contentDescription = "Decrease guests",
                                            tint = ObsidianEspresso
                                        )
                                    }
                                    Text(
                                        text = "$guestCount",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = ObsidianEspresso,
                                        modifier = Modifier.padding(horizontal = 8.dp)
                                    )
                                    IconButton(
                                        onClick = { if (guestCount < 12) guestCount++ }
                                    ) {
                                        Icon(
                                            imageVector = Icons.Outlined.Add,
                                            contentDescription = "Increase guests",
                                            tint = ObsidianEspresso
                                        )
                                    }
                                }
                            }
                        }

                        OutlinedTextField(
                            value = notes,
                            onValueChange = { notes = it },
                            label = { Text("Bespoke instructions") },
                            placeholder = { Text("Chilled Fiji water, golf bag transfer, coastal route prep…") },
                            minLines = 2,
                            maxLines = 4,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("concierge_notes_field")
                        )

                        Button(
                            onClick = {
                                onSubmitRequest(
                                    selectedType,
                                    planner.pickupHub.displayName,
                                    preferredDateText,
                                    deliveryAddress,
                                    vehiclePreference,
                                    guestCount,
                                    notes
                                )
                                notes = ""
                            },
                            enabled = !isSubmitting,
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = ObsidianEspresso,
                                contentColor = AlabasterCard
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .testTag("submit_concierge_button")
                        ) {
                            if (isSubmitting) {
                                CircularProgressIndicator(
                                    color = AlabasterCard,
                                    strokeWidth = 2.dp,
                                    modifier = Modifier.size(20.dp)
                                )
                            } else {
                                Text(
                                    text = "Submit concierge booking",
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Live Concierge Requests Feed
            item {
                Text(
                    text = "Your Concierge Requests",
                    style = MaterialTheme.typography.headlineMedium,
                    color = ObsidianEspresso,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            when (conciergeRequestsState) {
                is UiState.Loading -> {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = ChampagneGold)
                        }
                    }
                }
                is UiState.Error -> {
                    item {
                        Surface(
                            color = CrimsonTint,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = conciergeRequestsState.message,
                                style = MaterialTheme.typography.bodyMedium,
                                color = CrimsonAlert,
                                modifier = Modifier.padding(14.dp)
                            )
                        }
                    }
                }
                is UiState.Success -> {
                    val requests = conciergeRequestsState.data
                    if (requests.isEmpty()) {
                        item {
                            Surface(
                                color = AlabasterCard,
                                shape = RoundedCornerShape(18.dp),
                                border = BorderStroke(1.dp, HairlineBorder),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "No bespoke requests submitted yet. Use the form above to arrange FBO tarmac staging, a private chauffeur, or custom vehicle sourcing.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = WarmTaupe,
                                    modifier = Modifier.padding(20.dp)
                                )
                            }
                        }
                    } else {
                        items(requests, key = { it.id }) { req ->
                            ConciergeRequestCard(
                                request = req,
                                onCancel = { onCancelRequest(req.id) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ConciergeRequestCard(
    request: ConciergeRequest,
    onCancel: () -> Unit
) {
    val isCancelled = request.status == "cancelled"
    val typeTitle = ConciergeRequestType.entries
        .firstOrNull { it.value == request.requestType }?.title ?: "Concierge Service"

    Surface(
        color = AlabasterCard,
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, HairlineBorder),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("concierge_card_${request.id}")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = typeTitle,
                    style = MaterialTheme.typography.titleMedium,
                    color = ObsidianEspresso
                )
                Surface(
                    color = if (isCancelled) CrimsonTint else EmeraldTint,
                    shape = RoundedCornerShape(999.dp)
                ) {
                    Text(
                        text = request.status.replace('_', ' ').replaceFirstChar { it.uppercase() },
                        style = MaterialTheme.typography.labelMedium,
                        color = if (isCancelled) CrimsonAlert else EmeraldAvailable,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            Text(
                text = "${request.vehiclePreference} · ${request.pickupLocation}",
                style = MaterialTheme.typography.bodyLarge,
                color = ChampagneGold,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = "Timing: ${request.preferredDateText} · ${request.guestCount} guests",
                style = MaterialTheme.typography.bodyMedium,
                color = ObsidianEspresso
            )
            if (request.deliveryAddress.isNotBlank()) {
                Text(
                    text = "Destination: ${request.deliveryAddress}",
                    style = MaterialTheme.typography.bodySmall,
                    color = WarmTaupe
                )
            }
            if (request.notes.isNotBlank()) {
                Text(
                    text = "Notes: ${request.notes}",
                    style = MaterialTheme.typography.bodySmall,
                    color = WarmTaupe
                )
            }
            HorizontalDivider(color = HairlineBorder, thickness = 0.8.dp)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = request.assignedSpecialist,
                    style = MaterialTheme.typography.bodySmall,
                    color = WarmTaupe
                )
                if (!isCancelled) {
                    OutlinedButton(
                        onClick = onCancel,
                        border = BorderStroke(1.dp, CrimsonAlert.copy(alpha = 0.4f)),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Text("Withdraw", color = CrimsonAlert, style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
    }
}
