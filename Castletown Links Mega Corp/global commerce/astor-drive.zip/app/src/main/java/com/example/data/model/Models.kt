package com.example.data.model

import androidx.annotation.DrawableRes
import com.example.R
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

enum class FleetCategory(val label: String) {
    ALL("All"),
    SUVS("SUVs"),
    SPORTS("Sports"),
    ELECTRIC("Electric")
}

enum class DeliveryType(val value: String, val label: String) {
    HUB_COLLECTION("hub_collection", "Hub collection"),
    PERSONALISED_DELIVERY("personalised_delivery", "Personalised delivery")
}

enum class ConciergeRequestType(
    val value: String,
    val title: String,
    val subtitle: String
) {
    BESPOKE_DELIVERY(
        value = "bespoke_delivery",
        title = "White-Glove Delivery",
        subtitle = "Doorstep, hotel porte-cochère, or private residence handoff"
    ),
    FBO_TARMAC_HANDOFF(
        value = "fbo_tarmac_handoff",
        title = "Private FBO Tarmac",
        subtitle = "Direct planeside staging timed to your tail number"
    ),
    CHAUFFEUR_SERVICE(
        value = "chauffeur_service",
        title = "Dedicated Chauffeur",
        subtitle = "Discreet uniformed driver for full-day or evening charters"
    ),
    CUSTOM_ITINERARY(
        value = "custom_itinerary",
        title = "Curated Route & Prep",
        subtitle = "Coastal highway routes, luggage van, or cabin provisioning"
    ),
    VEHICLE_SOURCING(
        value = "vehicle_sourcing",
        title = "Bespoke Fleet Request",
        subtitle = "Reserve exact trim, color spec, or multi-vehicle convoy"
    )
}

data class AmericanHub(
    val id: String,
    val displayName: String,
    val shortCode: String,
    val city: String,
    val deliveryRadiusMiles: Int,
    val flagshipAddress: String
)

data class Vehicle(
    val id: String,
    val name: String,
    val trim: String,
    val category: String,
    val categorySubtitle: String,
    val seats: Int,
    val bags: Int,
    val transmission: String,
    val horsepower: Int,
    val zeroToSixty: String,
    val powertrainSpec: String,
    val dailyRateUsd: Int,
    val securityDepositUsd: Int,
    @DrawableRes val imageRes: Int,
    @DrawableRes val heroImageRes: Int,
    val hubInventory: Map<String, Int>,
    val deliveryLeadMinutes: Int,
    val deliveryFeeUsd: Int,
    val conciergeHighlight: String,
    val amenities: List<String>
)

data class LiveVehicleAvailability(
    val vehicle: Vehicle,
    val totalBaysAtHub: Int,
    val activeUserBookingsOverlap: Int,
    val availableBays: Int,
    val statusText: String,
    val isAvailableNow: Boolean
)

@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "",
    val email: String = "",
    val defaultHub: String = FleetCatalog.defaultHub.displayName,
    val preferredDeliveryAddress: String = "",
    val vipTier: String = "Signature",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toCreateMap(): Map<String, Any> = buildMap {
        put("userId", userId)
        put("displayName", displayName.ifBlank { "Astor Member" })
        put("email", email)
        put("defaultHub", defaultHub.ifBlank { FleetCatalog.defaultHub.displayName })
        if (preferredDeliveryAddress.isNotBlank()) {
            put("preferredDeliveryAddress", preferredDeliveryAddress.take(240))
        }
        put("vipTier", vipTier.ifBlank { "Signature" })
        put("createdAt", FieldValue.serverTimestamp())
        put("updatedAt", FieldValue.serverTimestamp())
    }
}

@IgnoreExtraProperties
data class Booking(
    @DocumentId val id: String = "",
    val userId: String = "",
    val vehicleId: String = "",
    val vehicleName: String = "",
    val vehicleCategory: String = "SUVs",
    val pickupLocation: String = "",
    val returnLocation: String = "",
    val returnToSameLocation: Boolean = true,
    val startDateEpochDay: Long = 0L,
    val endDateEpochDay: Long = 0L,
    val daysCount: Long = 1L,
    val deliveryType: String = DeliveryType.HUB_COLLECTION.value,
    val deliveryAddress: String = "",
    val deliveryTimeWindow: String = "",
    val chauffeurRequested: Boolean = false,
    val conciergeNotes: String = "",
    val dailyRateUsd: Long = 0L,
    val subtotalUsd: Long = 0L,
    val deliveryFeeUsd: Long = 0L,
    val taxesAndFeesUsd: Long = 0L,
    val estimatedTotalUsd: Long = 0L,
    val securityDepositUsd: Long = 1500L,
    val status: String = "confirmed",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toCreateMap(): Map<String, Any> = buildMap {
        put("userId", userId)
        put("vehicleId", vehicleId)
        put("vehicleName", vehicleName)
        put("vehicleCategory", vehicleCategory)
        put("pickupLocation", pickupLocation)
        put("returnLocation", returnLocation)
        put("returnToSameLocation", returnToSameLocation)
        put("startDateEpochDay", startDateEpochDay)
        put("endDateEpochDay", endDateEpochDay)
        put("daysCount", daysCount)
        put("deliveryType", deliveryType)
        if (deliveryAddress.isNotBlank()) {
            put("deliveryAddress", deliveryAddress.take(240))
        }
        if (deliveryTimeWindow.isNotBlank()) {
            put("deliveryTimeWindow", deliveryTimeWindow.take(60))
        }
        put("chauffeurRequested", chauffeurRequested)
        if (conciergeNotes.isNotBlank()) {
            put("conciergeNotes", conciergeNotes.take(500))
        }
        put("dailyRateUsd", dailyRateUsd)
        put("subtotalUsd", subtotalUsd)
        put("deliveryFeeUsd", deliveryFeeUsd)
        put("taxesAndFeesUsd", taxesAndFeesUsd)
        put("estimatedTotalUsd", estimatedTotalUsd)
        put("securityDepositUsd", securityDepositUsd)
        put("status", "confirmed")
        put("createdAt", FieldValue.serverTimestamp())
        put("updatedAt", FieldValue.serverTimestamp())
    }
}

@IgnoreExtraProperties
data class ConciergeRequest(
    @DocumentId val id: String = "",
    val userId: String = "",
    val requestType: String = ConciergeRequestType.BESPOKE_DELIVERY.value,
    val pickupLocation: String = "",
    val preferredDateText: String = "",
    val deliveryAddress: String = "",
    val vehiclePreference: String = "",
    val guestCount: Long = 2L,
    val notes: String = "",
    val status: String = "submitted",
    val assignedSpecialist: String = "Julian Vance · Senior Concierge",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toCreateMap(): Map<String, Any> = buildMap {
        put("userId", userId)
        put("requestType", requestType)
        put("pickupLocation", pickupLocation)
        put("preferredDateText", preferredDateText)
        if (deliveryAddress.isNotBlank()) {
            put("deliveryAddress", deliveryAddress.take(240))
        }
        put("vehiclePreference", vehiclePreference)
        put("guestCount", guestCount.coerceIn(1L, 12L))
        if (notes.isNotBlank()) {
            put("notes", notes.take(600))
        }
        put("status", "submitted")
        put("assignedSpecialist", assignedSpecialist.ifBlank { "Julian Vance · Senior Concierge" })
        put("createdAt", FieldValue.serverTimestamp())
        put("updatedAt", FieldValue.serverTimestamp())
    }
}

object FleetCatalog {
    val hubs: List<AmericanHub> = listOf(
        AmericanHub(
            id = "lax",
            displayName = "Los Angeles · LAX",
            shortCode = "LAX collection",
            city = "Los Angeles",
            deliveryRadiusMiles = 35,
            flagshipAddress = "Private Astor Lounge · Century Blvd, Los Angeles"
        ),
        AmericanHub(
            id = "bh",
            displayName = "Beverly Hills · Rodeo",
            shortCode = "Beverly Hills salon",
            city = "Beverly Hills",
            deliveryRadiusMiles = 25,
            flagshipAddress = "442 N Canon Dr, Beverly Hills, CA"
        ),
        AmericanHub(
            id = "psp",
            displayName = "Palm Springs · PSP",
            shortCode = "Palm Springs resort",
            city = "Palm Springs",
            deliveryRadiusMiles = 30,
            flagshipAddress = "Palm Springs Boutique Valet · N Palm Canyon Dr"
        ),
        AmericanHub(
            id = "mia",
            displayName = "Miami · MIA",
            shortCode = "Miami Beach",
            city = "Miami",
            deliveryRadiusMiles = 30,
            flagshipAddress = "Brickell & Fisher Island Marine Lounge, Miami"
        ),
        AmericanHub(
            id = "jfk",
            displayName = "New York · JFK",
            shortCode = "Manhattan & JFK",
            city = "New York",
            deliveryRadiusMiles = 30,
            flagshipAddress = "Upper East Side Salon · Madison Ave, NY"
        ),
        AmericanHub(
            id = "ase",
            displayName = "Aspen · ASE",
            shortCode = "Aspen Alpine",
            city = "Aspen",
            deliveryRadiusMiles = 25,
            flagshipAddress = "Aspen Private Aviation Terminal · Sardy Field"
        )
    )

    val defaultHub: AmericanHub = hubs.first()

    val deliveryTimeWindows: List<String> = listOf(
        "08:30 AM – 09:30 AM",
        "10:00 AM – 11:00 AM",
        "01:00 PM – 02:00 PM",
        "04:00 PM – 05:00 PM",
        "07:00 PM – 08:00 PM"
    )

    val vehicles: List<Vehicle> = listOf(
        Vehicle(
            id = "cadillac_escalade",
            name = "Cadillac Escalade",
            trim = "Sport Platinum V8",
            category = FleetCategory.SUVS.label,
            categorySubtitle = "Luxury SUV",
            seats = 7,
            bags = 4,
            transmission = "Automatic",
            horsepower = 420,
            zeroToSixty = "5.9 s",
            powertrainSpec = "6.2L V8 · Air Ride Adaptive",
            dailyRateUsd = 295,
            securityDepositUsd = 1500,
            imageRes = R.drawable.img_car_escalade,
            heroImageRes = R.drawable.img_hero_palm_springs,
            hubInventory = mapOf(
                "Los Angeles · LAX" to 3,
                "Beverly Hills · Rodeo" to 2,
                "Palm Springs · PSP" to 3,
                "Miami · MIA" to 2,
                "New York · JFK" to 2,
                "Aspen · ASE" to 2
            ),
            deliveryLeadMinutes = 45,
            deliveryFeeUsd = 65,
            conciergeHighlight = "AKG Studio 36-speaker audio, Super Cruise, chilled cabin water",
            amenities = listOf(
                "Super Cruise Hands-Free",
                "AKG 36-Speaker Audio",
                "Air Ride Adaptive Suspension",
                "Heated & Ventilated Leather"
            )
        ),
        Vehicle(
            id = "chevrolet_corvette",
            name = "Chevrolet Corvette",
            trim = "Stingray 3LT Z51",
            category = FleetCategory.SPORTS.label,
            categorySubtitle = "Sports",
            seats = 2,
            bags = 2,
            transmission = "Automatic",
            horsepower = 495,
            zeroToSixty = "2.9 s",
            powertrainSpec = "6.2L Mid-Engine V8 · 8-Spd DCT",
            dailyRateUsd = 245,
            securityDepositUsd = 2000,
            imageRes = R.drawable.img_car_corvette,
            heroImageRes = R.drawable.img_car_corvette,
            hubInventory = mapOf(
                "Los Angeles · LAX" to 2,
                "Beverly Hills · Rodeo" to 2,
                "Palm Springs · PSP" to 2,
                "Miami · MIA" to 3,
                "New York · JFK" to 1,
                "Aspen · ASE" to 1
            ),
            deliveryLeadMinutes = 50,
            deliveryFeeUsd = 75,
            conciergeHighlight = "Removable carbon roof panel, Z51 performance exhaust, coastal route guide",
            amenities = listOf(
                "Mid-Engine 6.2L LT2 V8",
                "Magnetic Selective Ride",
                "Napa Leather GT2 Seats",
                "Front Lift Memory System"
            )
        ),
        Vehicle(
            id = "cadillac_lyriq",
            name = "Cadillac Lyriq",
            trim = "Atelier AWD Electric",
            category = FleetCategory.ELECTRIC.label,
            categorySubtitle = "Electric",
            seats = 5,
            bags = 4,
            transmission = "Automatic",
            horsepower = 500,
            zeroToSixty = "4.4 s",
            powertrainSpec = "Dual-Motor AWD · 307 mi Range",
            dailyRateUsd = 215,
            securityDepositUsd = 1200,
            imageRes = R.drawable.img_car_electric_suv,
            heroImageRes = R.drawable.img_car_electric_suv,
            hubInventory = mapOf(
                "Los Angeles · LAX" to 4,
                "Beverly Hills · Rodeo" to 3,
                "Palm Springs · PSP" to 2,
                "Miami · MIA" to 2,
                "New York · JFK" to 3,
                "Aspen · ASE" to 2
            ),
            deliveryLeadMinutes = 40,
            deliveryFeeUsd = 55,
            conciergeHighlight = "Delivered at 95%+ charge with NACS fast-charge adapter & valet charging card",
            amenities = listOf(
                "33-Inch Curved 9K Display",
                "Whisper-Quiet Acoustic Glass",
                "Panoramic Glass Roof",
                "Complimentary Fast Charging"
            )
        ),
        Vehicle(
            id = "cadillac_escalade_esv",
            name = "Cadillac Escalade ESV",
            trim = "Executive Chauffeur Spec",
            category = FleetCategory.SUVS.label,
            categorySubtitle = "Extended Luxury SUV",
            seats = 7,
            bags = 6,
            transmission = "Automatic",
            horsepower = 420,
            zeroToSixty = "6.1 s",
            powertrainSpec = "Extended Wheelbase · Rear Exec Screens",
            dailyRateUsd = 340,
            securityDepositUsd = 1800,
            imageRes = R.drawable.img_hero_palm_springs,
            heroImageRes = R.drawable.img_hero_palm_springs,
            hubInventory = mapOf(
                "Los Angeles · LAX" to 2,
                "Beverly Hills · Rodeo" to 2,
                "Palm Springs · PSP" to 2,
                "Miami · MIA" to 2,
                "New York · JFK" to 2,
                "Aspen · ASE" to 1
            ),
            deliveryLeadMinutes = 45,
            deliveryFeeUsd = 65,
            conciergeHighlight = "Ideal for FBO tarmac transfers, golf trunks & dedicated chauffeur bookings",
            amenities = listOf(
                "Second-Row Captain Chairs",
                "Rear Dual 12.6\" OLED Displays",
                "6 Full-Size Suitcase Bay",
                "Chauffeur Ready Package"
            )
        )
    )

    fun findById(vehicleId: String): Vehicle? = vehicles.firstOrNull { it.id == vehicleId }

    fun findHub(displayName: String): AmericanHub =
        hubs.firstOrNull { it.displayName == displayName } ?: defaultHub

    fun computeAvailability(
        vehicle: Vehicle,
        hubDisplayName: String,
        startEpochDay: Long,
        endEpochDay: Long,
        userBookings: List<Booking>
    ): LiveVehicleAvailability {
        val baseBays = vehicle.hubInventory[hubDisplayName] ?: 2
        val overlappingCount = userBookings.count { booking ->
            booking.vehicleId == vehicle.id &&
                booking.pickupLocation == hubDisplayName &&
                booking.status !in listOf("cancelled", "completed") &&
                booking.startDateEpochDay < endEpochDay &&
                booking.endDateEpochDay > startEpochDay
        }
        val available = (baseBays - overlappingCount).coerceAtLeast(0)
        val cityLabel = findHub(hubDisplayName).city
        val statusText = when {
            available == 0 -> "Reserved on selected dates"
            available == 1 -> "Live · 1 bay left in $cityLabel"
            else -> "Live · $available bays ready"
        }
        return LiveVehicleAvailability(
            vehicle = vehicle,
            totalBaysAtHub = baseBays,
            activeUserBookingsOverlap = overlappingCount,
            availableBays = available,
            statusText = statusText,
            isAvailableNow = available > 0
        )
    }
}
