package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.DirectionsCar
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.LocalShipping
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.Booking
import com.example.data.model.DeliveryType
import com.example.data.model.FleetCatalog
import com.example.ui.theme.AlabasterCard
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.ChampagneTint
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CrimsonTint
import com.example.ui.theme.EmeraldAvailable
import com.example.ui.theme.EmeraldTint
import com.example.ui.theme.HairlineBorder
import com.example.ui.theme.IvoryCanvas
import com.example.ui.theme.ObsidianEspresso
import com.example.ui.theme.WarmSandSurface
import com.example.ui.theme.WarmTaupe
import com.example.ui.viewmodel.UiState
import java.text.NumberFormat
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun BookingsScreen(
    bookingsState: UiState<List<Booking>>,
    onUpdateDelivery: (String, String, String, String) -> Unit,
    onCancelBooking: (String) -> Unit,
    onExploreFleet: () -> Unit,
    modifier: Modifier = Modifier
) {
    var editingBooking by remember { mutableStateOf<Booking?>(null) }
    var cancellingBooking by remember { mutableStateOf<Booking?>(null) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(IvoryCanvas),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = stringResource(R.string.bookings_title),
                        style = MaterialTheme.typography.displayMedium,
                        color = ObsidianEspresso
                    )
                    Text(
                        text = "Live reservations synced to your Astor Drive account.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = WarmTaupe
                    )
                }
            }

            when (bookingsState) {
                is UiState.Loading -> {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 48.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = ChampagneGold)
                        }
                    }
                }
                is UiState.Error -> {
                    item {
                        Surface(
                            color = CrimsonTint,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = bookingsState.message,
                                style = MaterialTheme.typography.bodyMedium,
                                color = CrimsonAlert,
                                modifier = Modifier.padding(16.dp)
                            )
                        }
                    }
                }
                is UiState.Success -> {
                    val bookings = bookingsState.data
                    if (bookings.isEmpty()) {
                        item {
                            EmptyBookingsCard(onExploreFleet = onExploreFleet)
                        }
                    } else {
                        items(bookings, key = { it.id }) { booking ->
                            BookingCard(
                                booking = booking,
                                onEditDelivery = { editingBooking = booking },
                                onCancel = { cancellingBooking = booking }
                            )
                        }
                    }
                }
            }
        }
    }

    editingBooking?.let { target ->
        EditBookingDeliverySheet(
            booking = target,
            onSave = { address, window, notes ->
                onUpdateDelivery(target.id, address, window, notes)
                editingBooking = null
            },
            onDismiss = { editingBooking = null }
        )
    }

    cancellingBooking?.let { target ->
        AlertDialog(
            onDismissRequest = { cancellingBooking = null },
            containerColor = AlabasterCard,
            title = {
                Text(
                    text = "Cancel ${target.vehicleName}?",
                    style = MaterialTheme.typography.headlineSmall,
                    color = ObsidianEspresso
                )
            },
            text = {
                Text(
                    text = "Your hub bay at ${target.pickupLocation} will be released immediately and any refundable hold voided.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = WarmTaupe
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onCancelBooking(target.id)
                        cancellingBooking = null
                    }
                ) {
                    Text("Cancel reservation", color = CrimsonAlert, fontWeight = FontWeight.SemiBold)
                }
            },
            dismissButton = {
                TextButton(onClick = { cancellingBooking = null }) {
                    Text("Keep booking", color = ObsidianEspresso)
                }
            }
        )
    }
}

@Composable
private fun EmptyBookingsCard(onExploreFleet: () -> Unit) {
    Surface(
        color = AlabasterCard,
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, HairlineBorder),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
    ) {
        Column(
            modifier = Modifier.padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Surface(
                color = WarmSandSurface,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.size(56.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Outlined.DirectionsCar,
                        contentDescription = null,
                        tint = ChampagneGold,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
            Text(
                text = "No active reservations",
                style = MaterialTheme.typography.headlineMedium,
                color = ObsidianEspresso
            )
            Text(
                text = "Select a Cadillac Escalade, Corvette Stingray, or Cadillac Lyriq from our American hubs with optional white-glove delivery.",
                style = MaterialTheme.typography.bodyMedium,
                color = WarmTaupe,
                textAlign = TextAlign.Center
            )
            Button(
                onClick = onExploreFleet,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = ObsidianEspresso,
                    contentColor = AlabasterCard
                ),
                modifier = Modifier
                    .padding(top = 4.dp)
                    .height(48.dp)
                    .testTag("empty_bookings_explore_button")
            ) {
                Text("Explore the fleet")
            }
        }
    }
}

@Composable
private fun BookingCard(
    booking: Booking,
    onEditDelivery: () -> Unit,
    onCancel: () -> Unit
) {
    val vehicle = FleetCatalog.findById(booking.vehicleId)
    val isCancelled = booking.status == "cancelled"
    val isTerminal = booking.status in listOf("cancelled", "completed")
    val usd = NumberFormat.getNumberInstance(Locale.US)
    val startText = LocalDate.ofEpochDay(booking.startDateEpochDay)
        .format(DateTimeFormatter.ofPattern("MMM d", Locale.US))
    val endText = LocalDate.ofEpochDay(booking.endDateEpochDay)
        .format(DateTimeFormatter.ofPattern("MMM d, yyyy", Locale.US))

    Surface(
        color = AlabasterCard,
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, HairlineBorder),
        shadowElevation = 2.dp,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("booking_card_${booking.id}")
    ) {
        Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                if (vehicle != null) {
                    Image(
                        painter = painterResource(id = vehicle.imageRes),
                        contentDescription = booking.vehicleName,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(76.dp)
                            .clip(RoundedCornerShape(14.dp))
                    )
                }
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Surface(
                        color = if (isCancelled) CrimsonTint else EmeraldTint,
                        shape = RoundedCornerShape(999.dp)
                    ) {
                        Text(
                            text = booking.status.replace('_', ' ')
                                .replaceFirstChar { it.uppercase() },
                            style = MaterialTheme.typography.labelMedium,
                            color = if (isCancelled) CrimsonAlert else EmeraldAvailable,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                    Text(
                        text = booking.vehicleName,
                        style = MaterialTheme.typography.headlineSmall,
                        color = ObsidianEspresso
                    )
                    Text(
                        text = "$${usd.format(booking.estimatedTotalUsd)} USD · ${booking.daysCount} days",
                        style = MaterialTheme.typography.titleSmall,
                        color = ChampagneGold
                    )
                }
            }

            HorizontalDivider(color = HairlineBorder, thickness = 0.8.dp)

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.CalendarMonth,
                    contentDescription = null,
                    tint = WarmTaupe,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "$startText – $endText",
                    style = MaterialTheme.typography.bodyMedium,
                    color = ObsidianEspresso
                )
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.LocationOn,
                    contentDescription = null,
                    tint = WarmTaupe,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = if (booking.returnToSameLocation) {
                        booking.pickupLocation
                    } else {
                        "${booking.pickupLocation} → ${booking.returnLocation}"
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = ObsidianEspresso
                )
            }

            if (booking.deliveryType == DeliveryType.PERSONALISED_DELIVERY.value) {
                Surface(
                    color = ChampagneTint.copy(alpha = 0.55f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.LocalShipping,
                            contentDescription = null,
                            tint = ChampagneGold,
                            modifier = Modifier.size(18.dp)
                        )
                        Column {
                            Text(
                                text = "White-glove delivery · ${booking.deliveryTimeWindow}",
                                style = MaterialTheme.typography.titleSmall,
                                color = ObsidianEspresso
                            )
                            Text(
                                text = booking.deliveryAddress,
                                style = MaterialTheme.typography.bodySmall,
                                color = WarmTaupe
                            )
                        }
                    }
                }
            }

            if (booking.conciergeNotes.isNotBlank()) {
                Text(
                    text = "Notes: ${booking.conciergeNotes}",
                    style = MaterialTheme.typography.bodySmall,
                    color = WarmTaupe
                )
            }

            if (!isTerminal) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedButton(
                        onClick = onEditDelivery,
                        border = BorderStroke(1.dp, HairlineBorder),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Edit,
                            contentDescription = null,
                            tint = ObsidianEspresso,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Update handoff", color = ObsidianEspresso)
                    }

                    OutlinedButton(
                        onClick = onCancel,
                        border = BorderStroke(1.dp, CrimsonAlert.copy(alpha = 0.4f)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Text("Cancel", color = CrimsonAlert)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EditBookingDeliverySheet(
    booking: Booking,
    onSave: (String, String, String) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var address by remember(booking) { mutableStateOf(booking.deliveryAddress) }
    var window by remember(booking) {
        mutableStateOf(booking.deliveryTimeWindow.ifBlank { FleetCatalog.deliveryTimeWindows[1] })
    }
    var notes by remember(booking) { mutableStateOf(booking.conciergeNotes) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = AlabasterCard
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = "Update handoff instructions",
                style = MaterialTheme.typography.headlineMedium,
                color = ObsidianEspresso
            )
            OutlinedTextField(
                value = address,
                onValueChange = { address = it },
                label = { Text("Delivery address or FBO terminal") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = window,
                onValueChange = { window = it },
                label = { Text("Time window") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Concierge prep notes") },
                maxLines = 3,
                modifier = Modifier.fillMaxWidth()
            )
            Button(
                onClick = { onSave(address, window, notes) },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = ObsidianEspresso,
                    contentColor = AlabasterCard
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
            ) {
                Text("Save changes")
            }
        }
    }
}
