package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Astor Drive Luxury Editorial Ivory & Champagne Palette
val IvoryCanvas = Color(0xFFF7F2EA)
val AlabasterCard = Color(0xFFFFFCF7)
val WarmSandSurface = Color(0xFFEEE7DA)
val WarmParchmentPill = Color(0xFFF2ECE1)

val ObsidianEspresso = Color(0xFF1B1814)
val CharcoalInk = Color(0xFF2B2620)
val WarmTaupe = Color(0xFF6B6257)
val SoftStoneText = Color(0xFF8C8275)

val ChampagneGold = Color(0xFF9C7A46)
val BrightChampagne = Color(0xFFC59B5F)
val ChampagneTint = Color(0xFFF0E6D6)
val HairlineBorder = Color(0xFFDCD3C4)

val EmeraldAvailable = Color(0xFF236647)
val EmeraldTint = Color(0xFFE4F0EA)
val AmberLimited = Color(0xFF9E6421)
val AmberTint = Color(0xFFF7ECE0)
val CrimsonAlert = Color(0xFF9E3333)
val CrimsonTint = Color(0xFFF8E6E6)

// Dark theme luxury nocturnal counterpart
val NightObsidian = Color(0xFF14120F)
val NightSurface = Color(0xFF1F1B16)
val NightCard = Color(0xFF27221C)
val NightIvoryText = Color(0xFFF3EDE2)
val NightMutedText = Color(0xFFB3A99B)
val NightBorder = Color(0xFF3A3229)
