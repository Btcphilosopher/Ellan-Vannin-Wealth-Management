package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.LocalShipping
import androidx.compose.material.icons.outlined.SupportAgent
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.DeliveryType
import com.example.data.model.LiveVehicleAvailability
import com.example.ui.components.AvailabilityBadge
import com.example.ui.theme.AlabasterCard
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.ChampagneTint
import com.example.ui.theme.HairlineBorder
import com.example.ui.theme.IvoryCanvas
import com.example.ui.theme.ObsidianEspresso
import com.example.ui.theme.WarmSandSurface
import com.example.ui.theme.WarmTaupe
import com.example.ui.viewmodel.TripPlannerState

@Composable
fun HomeScreen(
    planner: TripPlannerState,
    fleetAvailability: List<LiveVehicleAvailability>,
    onOpenPickupPicker: () -> Unit,
    onOpenReturnPicker: () -> Unit,
    onOpenDatePicker: () -> Unit,
    onToggleReturnSameLocation: (Boolean) -> Unit,
    onTogglePersonalisedDelivery: (Boolean) -> Unit,
    onExploreFleet: () -> Unit,
    onSelectVehicle: (String) -> Unit,
    onOpenConcierge: () -> Unit,
    modifier: Modifier = Modifier
) {
    val totalLiveBays = fleetAvailability.sumOf { it.availableBays }
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(IvoryCanvas)
            .verticalScroll(scrollState)
            .padding(bottom = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 680.dp)
                .padding(horizontal = 20.dp)
        ) {
            // Editorial Headline above Hero
            Text(
                text = stringResource(R.string.hero_headline),
                style = MaterialTheme.typography.displayLarge,
                color = ObsidianEspresso
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = stringResource(R.string.hero_subhead),
                style = MaterialTheme.typography.bodyLarge,
                color = WarmTaupe
            )
            Spacer(modifier = Modifier.height(16.dp))

            // Hero Photographic Card + Overlapping Booking Planner Card
            Box(modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp)
                        .clip(RoundedCornerShape(22.dp))
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_hero_palm_springs),
                        contentDescription = "Cadillac Escalade outside Palm Springs luxury hotel",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color(0x221B1814),
                                        Color.Transparent,
                                        Color(0x771B1814)
                                    )
                                )
                            )
                    )
                    Surface(
                        color = AlabasterCard.copy(alpha = 0.92f),
                        shape = RoundedCornerShape(999.dp),
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(14.dp)
                    ) {
                        AvailabilityBadge(
                            availableBays = totalLiveBays,
                            statusText = "Live · $totalLiveBays bays ready in ${planner.pickupHub.city}"
                        )
                    }
                }

                // Floating "Find your next drive" Reservation Card
                Surface(
                    color = AlabasterCard,
                    shape = RoundedCornerShape(22.dp),
                    border = BorderStroke(1.dp, HairlineBorder),
                    shadowElevation = 6.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 244.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.find_next_drive),
                            style = MaterialTheme.typography.headlineMedium,
                            color = ObsidianEspresso
                        )

                        // Grouped Pick-up & Dates selector container
                        Surface(
                            color = IvoryCanvas,
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, HairlineBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column {
                                SelectorRow(
                                    icon = Icons.Outlined.LocationOn,
                                    label = stringResource(R.string.label_pickup),
                                    value = planner.pickupHub.displayName,
                                    onClick = onOpenPickupPicker,
                                    testTag = "home_pickup_selector"
                                )
                                if (!planner.returnToSameLocation) {
                                    HorizontalDivider(color = HairlineBorder, thickness = 0.8.dp)
                                    SelectorRow(
                                        icon = Icons.Outlined.LocationOn,
                                        label = stringResource(R.string.label_return),
                                        value = planner.returnHub.displayName,
                                        onClick = onOpenReturnPicker,
                                        testTag = "home_return_selector"
                                    )
                                }
                                HorizontalDivider(color = HairlineBorder, thickness = 0.8.dp)
                                SelectorRow(
                                    icon = Icons.Outlined.CalendarMonth,
                                    label = stringResource(R.string.label_dates),
                                    value = "${planner.formattedDateRange} · ${planner.daysCount} days",
                                    onClick = onOpenDatePicker,
                                    testTag = "home_dates_selector"
                                )
                            }
                        }

                        // Return to same location checkbox
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { onToggleReturnSameLocation(!planner.returnToSameLocation) }
                                .padding(vertical = 2.dp)
                                .testTag("home_return_same_checkbox")
                        ) {
                            Checkbox(
                                checked = planner.returnToSameLocation,
                                onCheckedChange = onToggleReturnSameLocation,
                                colors = CheckboxDefaults.colors(
                                    checkedColor = ChampagneGold,
                                    checkmarkColor = AlabasterCard
                                )
                            )
                            Text(
                                text = stringResource(R.string.return_same_location),
                                style = MaterialTheme.typography.bodyLarge,
                                color = ObsidianEspresso
                            )
                        }

                        // Personalised Delivery Toggle Row
                        Surface(
                            color = WarmSandSurface.copy(alpha = 0.6f),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.LocalShipping,
                                        contentDescription = null,
                                        tint = ChampagneGold,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Column {
                                        Text(
                                            text = "Personalised white-glove delivery",
                                            style = MaterialTheme.typography.titleSmall,
                                            color = ObsidianEspresso
                                        )
                                        Text(
                                            text = "Deliver to hotel, residence, or FBO tarmac",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = WarmTaupe
                                        )
                                    }
                                }
                                Switch(
                                    checked = planner.deliveryType == DeliveryType.PERSONALISED_DELIVERY,
                                    onCheckedChange = onTogglePersonalisedDelivery,
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = AlabasterCard,
                                        checkedTrackColor = ChampagneGold
                                    ),
                                    modifier = Modifier.testTag("home_delivery_switch")
                                )
                            }
                        }

                        // Primary Obsidian CTA
                        Button(
                            onClick = onExploreFleet,
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = ObsidianEspresso,
                                contentColor = AlabasterCard
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .testTag("explore_fleet_button")
                        ) {
                            Text(
                                text = stringResource(R.string.cta_explore_fleet),
                                style = MaterialTheme.typography.titleMedium
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(26.dp))

            // Curated Flagship Preview Strip
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Signature American Fleet",
                    style = MaterialTheme.typography.headlineMedium,
                    color = ObsidianEspresso
                )
                Text(
                    text = "View all",
                    style = MaterialTheme.typography.titleSmall,
                    color = ChampagneGold,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable(onClick = onExploreFleet)
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
        }

        LazyRow(
            contentPadding = PaddingValues(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(fleetAvailability, key = { it.vehicle.id }) { item ->
                Surface(
                    color = AlabasterCard,
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, HairlineBorder),
                    modifier = Modifier
                        .width(248.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .clickable { onSelectVehicle(item.vehicle.id) }
                        .testTag("home_featured_${item.vehicle.id}")
                ) {
                    Column {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(145.dp)
                        ) {
                            Image(
                                painter = painterResource(id = item.vehicle.imageRes),
                                contentDescription = item.vehicle.name,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            AvailabilityBadge(
                                availableBays = item.availableBays,
                                statusText = if (item.isAvailableNow) "${item.availableBays} ready" else "Reserved",
                                modifier = Modifier
                                    .align(Alignment.TopStart)
                                    .padding(10.dp)
                            )
                        }
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = item.vehicle.name,
                                style = MaterialTheme.typography.headlineSmall,
                                color = ObsidianEspresso,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${item.vehicle.categorySubtitle} · ${item.vehicle.seats} seats",
                                style = MaterialTheme.typography.bodySmall,
                                color = WarmTaupe
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "$${item.vehicle.dailyRateUsd} / day",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = ObsidianEspresso
                                )
                                Text(
                                    text = "${item.vehicle.deliveryLeadMinutes}m delivery",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = ChampagneGold
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(22.dp))

        // Private Concierge Banner Card
        Surface(
            color = ObsidianEspresso,
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier
                .widthIn(max = 680.dp)
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .clip(RoundedCornerShape(20.dp))
                .clickable(onClick = onOpenConcierge)
                .testTag("home_concierge_card")
        ) {
            Row(
                modifier = Modifier.padding(20.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Surface(
                    color = ChampagneGold.copy(alpha = 0.22f),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.size(48.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Outlined.SupportAgent,
                            contentDescription = null,
                            tint = ChampagneGold
                        )
                    }
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "EXCLUSIVE CONCIERGE DESK",
                        style = MaterialTheme.typography.labelSmall,
                        color = ChampagneGold
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Private FBO tarmac staging & dedicated chauffeurs",
                        style = MaterialTheme.typography.titleMedium,
                        color = AlabasterCard
                    )
                    Text(
                        text = "Arrange bespoke delivery or custom itineraries 24/7.",
                        style = MaterialTheme.typography.bodySmall,
                        color = AlabasterCard.copy(alpha = 0.78f)
                    )
                }
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                    contentDescription = "Open private concierge",
                    tint = AlabasterCard
                )
            }
        }
    }
}

@Composable
private fun SelectorRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String,
    onClick: () -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 13.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.weight(1f)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = ObsidianEspresso,
                modifier = Modifier.size(20.dp)
            )
            Column {
                Text(
                    text = label,
                    style = MaterialTheme.typography.bodySmall,
                    color = WarmTaupe
                )
                Text(
                    text = value,
                    style = MaterialTheme.typography.titleMedium,
                    color = ObsidianEspresso,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        Icon(
            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
            contentDescription = "Change $label",
            tint = WarmTaupe
        )
    }
}
