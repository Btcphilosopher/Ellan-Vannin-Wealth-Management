package com.example.data.firebase

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.Booking
import com.example.data.model.ConciergeRequest
import com.example.data.model.ConciergeRequestType
import com.example.data.model.DeliveryType
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class AstorDriveRepositoryRuleTest : FirestoreEmulatorTestBase() {

    private fun sampleBooking(uid: String) = Booking(
        userId = uid,
        vehicleId = "cadillac_escalade",
        vehicleName = "Cadillac Escalade",
        vehicleCategory = "SUVs",
        pickupLocation = "Los Angeles · LAX",
        returnLocation = "Los Angeles · LAX",
        returnToSameLocation = true,
        startDateEpochDay = 20440L,
        endDateEpochDay = 20443L,
        daysCount = 3L,
        deliveryType = DeliveryType.PERSONALISED_DELIVERY.value,
        deliveryAddress = "Palm Springs Hotel, 1400 N Palm Canyon Dr",
        deliveryTimeWindow = "10:00 AM – 11:00 AM",
        chauffeurRequested = false,
        conciergeNotes = "Chilled sparkling water in center console",
        dailyRateUsd = 295L,
        subtotalUsd = 885L,
        deliveryFeeUsd = 65L,
        taxesAndFeesUsd = 135L,
        estimatedTotalUsd = 1085L,
        securityDepositUsd = 1500L,
        status = "confirmed"
    )

    private fun sampleConciergeRequest(uid: String) = ConciergeRequest(
        userId = uid,
        requestType = ConciergeRequestType.FBO_TARMAC_HANDOFF.value,
        pickupLocation = "Palm Springs · PSP",
        preferredDateText = "Dec 18 · 2:30 PM",
        deliveryAddress = "Signature Aviation Hangar 4",
        vehiclePreference = "Cadillac Escalade",
        guestCount = 4L,
        notes = "Direct tarmac luggage handoff",
        status = "submitted",
        assignedSpecialist = "Julian Vance · Senior Concierge"
    )

    @Test
    fun createAndObserveBooking_authenticatedOwner_persistsAndEmitsRealtime() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repository = AstorDriveRepository(firestore, auth)

        val profileRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.ensureUserProfile("Alice Astor", ALICE_EMAIL)
        }
        assertTrue(profileRes.isSuccess)

        val bookingId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.createBooking(sampleBooking(uid)).getOrThrow()
        }
        assertTrue(bookingId.isNotBlank())

        val bookings = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeBookings(uid).first { list -> list.any { it.id == bookingId } }
        }
        val created = bookings.first { it.id == bookingId }
        assertEquals("Cadillac Escalade", created.vehicleName)
        assertEquals("confirmed", created.status)

        val cancelRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.cancelBooking(bookingId)
        }
        assertTrue(cancelRes.isSuccess)
    }

    @Test
    fun createAndObserveConciergeRequest_authenticatedOwner_succeeds() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repository = AstorDriveRepository(firestore, auth)

        val requestId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.createConciergeRequest(sampleConciergeRequest(uid)).getOrThrow()
        }
        assertTrue(requestId.isNotBlank())

        val requests = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeConciergeRequests(uid).first { list -> list.any { it.id == requestId } }
        }
        assertEquals("Signature Aviation Hangar 4", requests.first { it.id == requestId }.deliveryAddress)
    }

    @Test
    fun toggleSavedVehicle_authenticatedOwner_persistsAndDeletes() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repository = AstorDriveRepository(firestore, auth)

        withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.toggleSavedVehicle("chevrolet_corvette", currentlySaved = false).getOrThrow()
        }
        val savedAfterAdd = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeSavedVehicleIds(uid).first { it.contains("chevrolet_corvette") }
        }
        assertTrue(savedAfterAdd.contains("chevrolet_corvette"))

        withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.toggleSavedVehicle("chevrolet_corvette", currentlySaved = true).getOrThrow()
        }
        val savedAfterRemove = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeSavedVehicleIds(uid).first { !it.contains("chevrolet_corvette") }
        }
        assertTrue(!savedAfterRemove.contains("chevrolet_corvette"))
    }

    @Test
    fun observeBookings_crossUserAccess_failsWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val aliceRepo = AstorDriveRepository(firestore, auth)
        withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.createBooking(sampleBooking(aliceUid)).getOrThrow()
        }

        signInTestUser(BOB_EMAIL)
        val bobRepo = AstorDriveRepository(firestore, auth)
        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                bobRepo.observeBookings(aliceUid).first()
            }
            fail("Expected PERMISSION_DENIED when Bob reads Alice's bookings")
        } catch (e: Exception) {
            val firestoreException = e.unwrapFirestoreException()
            assertNotNull("Expected nested FirebaseFirestoreException, got $e", firestoreException)
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreException!!.code)
        }
    }

    @Test
    fun observeBookings_unauthenticatedCaller_failsWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        auth.signOut()
        val repository = AstorDriveRepository(firestore, auth)

        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repository.observeBookings(aliceUid).first()
            }
            fail("Expected PERMISSION_DENIED when unauthenticated")
        } catch (e: Exception) {
            val firestoreException = e.unwrapFirestoreException()
            assertNotNull("Expected nested FirebaseFirestoreException, got $e", firestoreException)
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreException!!.code)
        }
    }

    private companion object {
        const val ALICE_EMAIL = "alice.astor@test.com"
        const val BOB_EMAIL = "bob.astor@test.com"
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 3000L
    }
}
