package com.example.data.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FleetCatalogTest {

    @Test
    fun computeAvailability_decrementsWhenActiveBookingOverlapsHubAndDates() {
        val escalade = FleetCatalog.findById("cadillac_escalade")!!
        val hub = "Los Angeles · LAX"
        val baseline = FleetCatalog.computeAvailability(
            vehicle = escalade,
            hubDisplayName = hub,
            startEpochDay = 20440L,
            endEpochDay = 20443L,
            userBookings = emptyList()
        )
        assertEquals(3, baseline.availableBays)
        assertTrue(baseline.isAvailableNow)

        val activeOverlap = Booking(
            id = "b1",
            vehicleId = escalade.id,
            pickupLocation = hub,
            startDateEpochDay = 20441L,
            endDateEpochDay = 20444L,
            status = "confirmed"
        )
        val cancelledOverlap = Booking(
            id = "b2",
            vehicleId = escalade.id,
            pickupLocation = hub,
            startDateEpochDay = 20440L,
            endDateEpochDay = 20443L,
            status = "cancelled"
        )

        val updated = FleetCatalog.computeAvailability(
            vehicle = escalade,
            hubDisplayName = hub,
            startEpochDay = 20440L,
            endEpochDay = 20443L,
            userBookings = listOf(activeOverlap, cancelledOverlap)
        )
        assertEquals(2, updated.availableBays)
        assertEquals(1, updated.activeUserBookingsOverlap)
        assertTrue(updated.isAvailableNow)
    }

    @Test
    fun computeAvailability_marksUnavailableWhenAllBaysBooked() {
        val corvette = FleetCatalog.findById("chevrolet_corvette")!!
        val hub = "New York · JFK" // base 1 bay
        val activeBooking = Booking(
            id = "b3",
            vehicleId = corvette.id,
            pickupLocation = hub,
            startDateEpochDay = 20440L,
            endDateEpochDay = 20442L,
            status = "confirmed"
        )

        val result = FleetCatalog.computeAvailability(
            vehicle = corvette,
            hubDisplayName = hub,
            startEpochDay = 20440L,
            endEpochDay = 20442L,
            userBookings = listOf(activeBooking)
        )
        assertEquals(0, result.availableBays)
        assertFalse(result.isAvailableNow)
    }
}
