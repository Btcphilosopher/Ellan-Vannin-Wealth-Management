const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_astor_123";
const BOB_UID = "bob_astor_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function serverTimestamp() {
  return new Date(Date.now() - 1000);
}

function validBookingPayload(uid) {
  return {
    userId: uid,
    vehicleId: "cadillac_escalade",
    vehicleName: "Cadillac Escalade",
    vehicleCategory: "SUVs",
    pickupLocation: "Los Angeles · LAX",
    returnLocation: "Los Angeles · LAX",
    returnToSameLocation: true,
    startDateEpochDay: 20440,
    endDateEpochDay: 20443,
    daysCount: 3,
    deliveryType: "hub_collection",
    deliveryAddress: "Palm Springs Hotel, 1400 N Palm Canyon Dr",
    deliveryTimeWindow: "10:00 AM - 11:00 AM",
    chauffeurRequested: false,
    conciergeNotes: "Chilled sparkling water in cabin",
    dailyRateUsd: 295,
    subtotalUsd: 885,
    deliveryFeeUsd: 0,
    taxesAndFeesUsd: 135,
    estimatedTotalUsd: 1020,
    securityDepositUsd: 1500,
    status: "confirmed",
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };
}

function validConciergePayload(uid) {
  return {
    userId: uid,
    requestType: "fbo_tarmac_handoff",
    pickupLocation: "Palm Springs · PSP",
    preferredDateText: "Dec 18 · 2:30 PM",
    deliveryAddress: "Signature Aviation FBO Hangar 4",
    vehiclePreference: "Cadillac Escalade",
    guestCount: 4,
    notes: "Planeside luggage transfer requested",
    status: "submitted",
    assignedSpecialist: "Julian Vance · Senior Concierge",
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user: cannot read or write bookings, concierge, or profile", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("bookings").get());
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("conciergeRequests").get());
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("bookings").doc("b1").set(validBookingPayload(ALICE_UID)));
});

test("Owner can create, read, update delivery details, and cancel own booking", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bookingRef = aliceDb.collection("users").doc(ALICE_UID).collection("bookings").doc("b_001");

  await assertSucceeds(bookingRef.set(validBookingPayload(ALICE_UID)));
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).collection("bookings").get());

  await assertSucceeds(bookingRef.update({
    deliveryAddress: "Beverly Hills Hotel Bungalow 5",
    updatedAt: serverTimestamp(),
  }));

  await assertSucceeds(bookingRef.update({
    status: "cancelled",
    updatedAt: serverTimestamp(),
  }));

  // Terminal state locking: cannot modify once cancelled
  await assertFails(bookingRef.update({
    conciergeNotes: "Trying after cancel",
    updatedAt: serverTimestamp(),
  }));
});

test("Cross-user isolation: Bob cannot read, create, or update Alice's bookings or concierge requests", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("bookings").doc("b_alice").set(validBookingPayload(ALICE_UID))
  );

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("bookings").get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("bookings").doc("b_alice").get());
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("bookings").doc("b_spoof").set(validBookingPayload(ALICE_UID))
  );
  await assertFails(
    bobDb.collection("users").doc(BOB_UID).collection("bookings").doc("b_spoof2").set(validBookingPayload(ALICE_UID))
  );
});

test("Shadow update & schema poisoning blocked on bookings and concierge requests", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bookingRef = aliceDb.collection("users").doc(ALICE_UID).collection("bookings").doc("b_shadow");

  const withGhostField = { ...validBookingPayload(ALICE_UID), isAdminApproved: true };
  await assertFails(bookingRef.set(withGhostField));

  const badStatus = { ...validBookingPayload(ALICE_UID), status: "completed" };
  await assertFails(bookingRef.set(badStatus));

  const conciergeRef = aliceDb.collection("users").doc(ALICE_UID).collection("conciergeRequests").doc("c_001");
  await assertSucceeds(conciergeRef.set(validConciergePayload(ALICE_UID)));

  // Cannot escalate concierge status directly via client update
  await assertFails(conciergeRef.update({ status: "confirmed", updatedAt: serverTimestamp() }));
});

test("Owner can bookmark and remove saved vehicles; cannot update or spoof", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const savedRef = aliceDb.collection("users").doc(ALICE_UID).collection("savedVehicles").doc("cadillac_escalade");

  await assertSucceeds(savedRef.set({
    userId: ALICE_UID,
    vehicleId: "cadillac_escalade",
    createdAt: serverTimestamp(),
  }));

  await assertFails(savedRef.update({ vehicleId: "chevrolet_corvette" }));
  await assertSucceeds(savedRef.delete());
});
