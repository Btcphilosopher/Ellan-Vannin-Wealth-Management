'use client';

import React from 'react';
import { MarketProvider, useMarket } from '@/lib/store/market-context';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { LegalDisclaimer } from '@/components/LegalDisclaimer';
import { ToastContainer } from '@/components/ToastContainer';
import { MarketplaceCatalog } from '@/components/MarketplaceCatalog';
import { GlobalMarketMap } from '@/components/GlobalMarketMap';
import { SupplierDirectory } from '@/components/SupplierDirectory';
import { RFQMarketplace } from '@/components/RFQMarketplace';
import { BuyerDashboard } from '@/components/BuyerDashboard';
import { MerchantOS } from '@/components/MerchantOS';
import { MarketWallet } from '@/components/MarketWallet';
import { LogisticsDashboard } from '@/components/LogisticsDashboard';
import { ProductDetailModal } from '@/components/ProductDetailModal';
import { CheckoutModal } from '@/components/CheckoutModal';

function MarketAppContent() {
  const {
    activeTab,
    selectedProduct,
    setSelectedProduct,
    checkoutItem,
    setCheckoutItem,
  } = useMarket();

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col font-sans selection:bg-amber-500 selection:text-zinc-950">
      <LegalDisclaimer />
      <Header />

      <main className="flex-1 max-w-7xl mx-auto px-4 py-8 w-full">
        {activeTab === 'MARKETPLACE' && <MarketplaceCatalog />}
        {activeTab === 'DISCOVER' && (
          <div className="space-y-8">
            <GlobalMarketMap />
            <MarketplaceCatalog />
          </div>
        )}
        {activeTab === 'SUPPLIERS' && <SupplierDirectory />}
        {activeTab === 'RFQ' && <RFQMarketplace />}
        {activeTab === 'ORDERS' && <BuyerDashboard />}
        {activeTab === 'MERCHANT_OS' && <MerchantOS />}
        {activeTab === 'FINANCE' && <MarketWallet />}
        {activeTab === 'LOGISTICS' && <LogisticsDashboard />}
      </main>

      <Footer />
      <ToastContainer />

      {/* Active Modals */}
      {selectedProduct && (
        <ProductDetailModal
          product={selectedProduct}
          onClose={() => setSelectedProduct(null)}
        />
      )}

      {checkoutItem && (
        <CheckoutModal onClose={() => setCheckoutItem(null)} />
      )}
    </div>
  );
}

export default function Home() {
  return (
    <MarketProvider>
      <MarketAppContent />
    </MarketProvider>
  );
}
