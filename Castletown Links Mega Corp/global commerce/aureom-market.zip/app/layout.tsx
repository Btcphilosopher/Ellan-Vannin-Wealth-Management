import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'AUREOM MARKET — Global Commerce. Native Money.',
  description: 'The Web3-native global B2B/B2C marketplace. Source products, negotiate directly, and settle global trade with Bitcoin and Tether.',
  openGraph: {
    title: 'AUREOM MARKET — Global Commerce. Native Money.',
    description: 'The Web3-native global B2B/B2C marketplace. Source products, negotiate directly, and settle global trade with Bitcoin and Tether.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'AUREOM MARKET — Global Commerce. Native Money.',
    description: 'The Web3-native global B2B/B2C marketplace. Source products, negotiate directly, and settle global trade with Bitcoin and Tether.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
