'use client';

import React, { useState } from 'react';
import { Product } from '@/types';
import { useMarket } from '@/lib/store/market-context';
import {
  X,
  ShieldCheck,
  Star,
  MapPin,
  Clock,
  Boxes,
  CheckCircle2,
  Lock,
  MessageSquare,
  FileText,
  ShoppingCart,
  Layers,
  ChevronRight,
  Info,
  Box,
} from 'lucide-react';

interface ProductDetailModalProps {
  product: Product;
  onClose: () => void;
}

export const ProductDetailModal = ({ product, onClose }: ProductDetailModalProps) => {
  const {
    setSelectedProduct,
    setCheckoutItem,
    setActiveTab,
    formatPrice,
    exchangeRates,
  } = useMarket();

  const [selectedImage, setSelectedImage] = useState(product.images[0]);
  const [quantity, setQuantity] = useState(product.moq);
  const [selectedCustomizations, setSelectedCustomizations] = useState<Record<string, string>>({});
  const [view3dModel, setView3dModel] = useState(false);

  // Calculate unit price based on volume tiers
  let calculatedUnitPrice = product.basePriceUSD;
  const applicableTier = product.priceTiers.find(
    (t) => quantity >= t.minQuantity && (!t.maxQuantity || quantity <= t.maxQuantity)
  );
  if (applicableTier) {
    calculatedUnitPrice = applicableTier.pricePerUnit;
  }

  // Add customization extra costs
  let customAdders = 0;
  product.customizationOptions?.forEach((opt) => {
    if (selectedCustomizations[opt.id] && opt.unitCostAdder) {
      customAdders += opt.unitCostAdder;
    }
  });

  const finalUnitPriceUSD = calculatedUnitPrice + customAdders;
  const totalPriceUSD = finalUnitPriceUSD * quantity;

  const handleStartCheckout = () => {
    setCheckoutItem({
      product,
      quantity,
      customizations: selectedCustomizations,
    });
    onClose();
  };

  const handleStartNegotiation = () => {
    onClose();
    setActiveTab('RFQ');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/80 backdrop-blur-md overflow-y-auto">
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl max-w-5xl w-full max-h-[92vh] overflow-y-auto text-zinc-100 shadow-2xl relative animate-in fade-in zoom-in-95 duration-200">
        {/* Sticky Header Close */}
        <div className="sticky top-0 z-20 bg-zinc-900/90 backdrop-blur border-b border-zinc-800 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-mono">
            <span className="text-amber-400 font-bold uppercase">SKU: {product.sku}</span>
            <span className="text-zinc-600">|</span>
            <span className="text-zinc-400">{product.category}</span>
          </div>

          <button
            onClick={onClose}
            className="text-zinc-400 hover:text-zinc-100 p-1.5 rounded-lg hover:bg-zinc-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 grid grid-cols-1 lg:grid-cols-2 gap-8 font-mono">
          {/* LEFT: Photo Gallery, Technical Drawings, 3D Canvas */}
          <div className="space-y-4">
            {/* Main Visual Frame */}
            <div className="relative aspect-[4/3] bg-zinc-950 rounded-xl overflow-hidden border border-zinc-800 flex items-center justify-center">
              {view3dModel ? (
                <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center bg-gradient-to-b from-zinc-950 to-zinc-900 text-zinc-400 space-y-3">
                  <Box className="w-16 h-16 text-amber-400 animate-bounce" />
                  <div className="text-sm font-bold text-zinc-200 uppercase">
                    3D STEP / CAD Model Preview
                  </div>
                  <p className="text-xs max-w-xs text-zinc-500">
                    Interactive CAD model viewer ready. Precision CNC dimensions: 180mm × 120mm × 45mm.
                  </p>
                  <button
                    onClick={() => setView3dModel(false)}
                    className="bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs px-3 py-1.5 rounded"
                  >
                    Return to Photography
                  </button>
                </div>
              ) : (
                <img
                  src={selectedImage}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
              )}

              {/* 3D Model Toggle Overlay */}
              {product.has3dModel && !view3dModel && (
                <button
                  onClick={() => setView3dModel(true)}
                  className="absolute bottom-3 right-3 bg-zinc-950/90 hover:bg-amber-400 hover:text-zinc-950 text-amber-300 border border-amber-500/40 px-3 py-1.5 rounded text-xs font-bold flex items-center gap-1.5 shadow-lg transition-colors"
                >
                  <Box className="w-4 h-4" />
                  <span>3D CAD VIEW</span>
                </button>
              )}
            </div>

            {/* Gallery Thumbnails */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1">
              {product.images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setSelectedImage(img);
                    setView3dModel(false);
                  }}
                  className={`w-16 h-16 rounded-lg overflow-hidden border-2 shrink-0 transition-all ${
                    selectedImage === img && !view3dModel
                      ? 'border-amber-400 scale-105'
                      : 'border-zinc-800 opacity-60 hover:opacity-100'
                  }`}
                >
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>

            {/* Technical Specifications Table */}
            <div className="pt-4 border-t border-zinc-800 space-y-2">
              <h4 className="text-xs font-bold uppercase text-zinc-300 tracking-wider flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-amber-400" />
                STRUCTURED TECHNICAL SPECIFICATIONS
              </h4>
              <div className="border border-zinc-800 rounded-lg overflow-hidden text-xs">
                {product.specs.map((spec, idx) => (
                  <div
                    key={idx}
                    className={`grid grid-cols-2 p-2.5 ${
                      idx % 2 === 0 ? 'bg-zinc-950/60' : 'bg-zinc-900/60'
                    } border-b border-zinc-800/60 last:border-0`}
                  >
                    <span className="text-zinc-400">{spec.key}</span>
                    <span className="text-zinc-100 font-semibold text-right">{spec.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* RIGHT: Product Info, Volume Tier Pricing, Customization, Live Currency Conversion & Actions */}
          <div className="space-y-5">
            <div>
              {/* Manufacturer Line */}
              <div className="flex items-center gap-2 text-xs text-zinc-400 mb-1.5">
                <span className="text-emerald-400 font-bold flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  VERIFIED MANUFACTURER
                </span>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-zinc-500" />
                  {product.supplierLocation}
                </span>
                <span>•</span>
                <span className="text-amber-400 font-bold flex items-center gap-0.5">
                  <Star className="w-3.5 h-3.5 fill-amber-400" />
                  {product.supplierRating}
                </span>
              </div>

              <h2 className="text-xl font-bold text-zinc-100 uppercase tracking-tight leading-snug">
                {product.name}
              </h2>
            </div>

            {/* Tiered Volume Pricing Table */}
            <div className="bg-zinc-950 p-3.5 rounded-xl border border-zinc-800 space-y-2">
              <div className="text-[11px] font-bold uppercase text-amber-400 tracking-wider">
                VOLUME TIER PRICING SCHEDULING (USD / UNIT)
              </div>
              <div className="grid grid-cols-4 gap-2 text-center text-xs">
                {product.priceTiers.map((tier, idx) => {
                  const isSelectedTier =
                    quantity >= tier.minQuantity &&
                    (!tier.maxQuantity || quantity <= tier.maxQuantity);
                  return (
                    <div
                      key={idx}
                      className={`p-2 rounded border transition-all ${
                        isSelectedTier
                          ? 'bg-amber-500/10 border-amber-500/60 text-amber-300 font-bold'
                          : 'bg-zinc-900 border-zinc-800 text-zinc-400'
                      }`}
                    >
                      <div className="text-[10px] text-zinc-500">
                        {tier.maxQuantity ? `${tier.minQuantity}–${tier.maxQuantity}` : `${tier.minQuantity}+`}
                      </div>
                      <div className="text-sm font-bold text-zinc-100 mt-0.5">
                        ${tier.pricePerUnit.toFixed(2)}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Quantity Selector */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <label className="text-zinc-300 font-bold uppercase">ORDER QUANTITY (UNITS):</label>
                <span className="text-zinc-400 text-[11px]">MOQ: {product.moq} units</span>
              </div>
              <div className="flex items-center gap-3">
                <input
                  type="number"
                  min={product.moq}
                  step={10}
                  value={quantity}
                  onChange={(e) => setQuantity(Math.max(product.moq, parseInt(e.target.value) || product.moq))}
                  className="bg-zinc-950 border border-zinc-800 focus:border-amber-500 text-zinc-100 text-base font-bold rounded-lg px-4 py-2 w-36 focus:outline-none font-mono"
                />
                <div className="flex gap-1.5 text-xs">
                  <button
                    onClick={() => setQuantity(product.moq)}
                    className="bg-zinc-800 hover:bg-zinc-700 text-zinc-300 px-2.5 py-1.5 rounded"
                  >
                    MOQ ({product.moq})
                  </button>
                  <button
                    onClick={() => setQuantity(500)}
                    className="bg-zinc-800 hover:bg-zinc-700 text-zinc-300 px-2.5 py-1.5 rounded"
                  >
                    500
                  </button>
                  <button
                    onClick={() => setQuantity(5000)}
                    className="bg-zinc-800 hover:bg-zinc-700 text-zinc-300 px-2.5 py-1.5 rounded"
                  >
                    5,000
                  </button>
                </div>
              </div>
            </div>

            {/* Customization Options */}
            {product.customizationAvailable && product.customizationOptions && (
              <div className="bg-zinc-950 p-3.5 rounded-xl border border-zinc-800 space-y-2.5">
                <div className="text-[11px] font-bold uppercase text-zinc-300 tracking-wider">
                  FACTORY CUSTOMIZATION OPTIONS
                </div>
                {product.customizationOptions.map((opt) => (
                  <div key={opt.id} className="text-xs space-y-1">
                    <div className="flex items-center justify-between text-zinc-400">
                      <span>{opt.label}</span>
                      {opt.unitCostAdder && (
                        <span className="text-amber-400 text-[10px]">
                          + ${opt.unitCostAdder.toFixed(2)}/unit
                        </span>
                      )}
                    </div>
                    {opt.type === 'select' && opt.options && (
                      <select
                        value={selectedCustomizations[opt.id] || opt.options[0]}
                        onChange={(e) =>
                          setSelectedCustomizations({
                            ...selectedCustomizations,
                            [opt.id]: e.target.value,
                          })
                        }
                        className="bg-zinc-900 border border-zinc-800 text-zinc-200 text-xs rounded px-2.5 py-1.5 w-full focus:outline-none"
                      >
                        {opt.options.map((o, i) => (
                          <option key={i} value={o}>
                            {o}
                          </option>
                        ))}
                      </select>
                    )}
                    {opt.type === 'checkbox' && (
                      <label className="flex items-center gap-2 cursor-pointer text-zinc-300">
                        <input
                          type="checkbox"
                          checked={!!selectedCustomizations[opt.id]}
                          onChange={(e) =>
                            setSelectedCustomizations({
                              ...selectedCustomizations,
                              [opt.id]: e.target.checked ? 'Enabled' : '',
                            })
                          }
                          className="accent-amber-400 rounded"
                        />
                        <span>Enable {opt.label}</span>
                      </label>
                    )}
                  </div>
                ))}
              </div>
            )}

            {/* Live Exchange Rate Conversion Card */}
            <div className="bg-gradient-to-br from-zinc-950 via-zinc-900 to-zinc-950 p-4 rounded-xl border border-zinc-800 space-y-2">
              <div className="flex items-center justify-between text-[10px] uppercase text-zinc-400">
                <span className="flex items-center gap-1 font-bold text-amber-400">
                  <Lock className="w-3 h-3" /> LIVE MULTI-RAIL CONVERSION QUOTE
                </span>
                <span className="text-zinc-500">DEMO MARKET DATA</span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 pt-1 font-mono">
                <div className="bg-zinc-900 p-2 rounded border border-zinc-800">
                  <div className="text-[10px] text-zinc-500">TOTAL USD</div>
                  <div className="text-sm font-bold text-zinc-100">
                    ${totalPriceUSD.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </div>
                </div>

                <div className="bg-zinc-900 p-2 rounded border border-amber-500/30">
                  <div className="text-[10px] text-amber-400 font-bold">₿ BITCOIN (BTC)</div>
                  <div className="text-sm font-bold text-amber-300">
                    {(totalPriceUSD / exchangeRates.BTC_USD).toFixed(5)} BTC
                  </div>
                </div>

                <div className="bg-zinc-900 p-2 rounded border border-emerald-500/30">
                  <div className="text-[10px] text-emerald-400 font-bold">₮ TETHER (USDT)</div>
                  <div className="text-sm font-bold text-emerald-300">
                    {totalPriceUSD.toLocaleString()} USDT
                  </div>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-2 pt-2">
              <button
                onClick={handleStartCheckout}
                className="w-full bg-amber-400 hover:bg-amber-300 text-zinc-950 font-black py-3 px-4 rounded-lg uppercase tracking-wider text-sm flex items-center justify-center gap-2 transition-all shadow-lg"
              >
                <ShoppingCart className="w-4 h-4" />
                <span>INITIATE WEB3 ESCROW CHECKOUT ({formatPrice(totalPriceUSD)})</span>
              </button>

              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={handleStartNegotiation}
                  className="bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-bold py-2.5 px-3 rounded-lg text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition-colors border border-zinc-700"
                >
                  <MessageSquare className="w-3.5 h-3.5 text-amber-400" />
                  <span>DIRECT NEGOTIATION</span>
                </button>

                <button
                  onClick={handleStartNegotiation}
                  className="bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-bold py-2.5 px-3 rounded-lg text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition-colors border border-zinc-700"
                >
                  <FileText className="w-3.5 h-3.5 text-blue-400" />
                  <span>REQUEST RFQ QUOTE</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
