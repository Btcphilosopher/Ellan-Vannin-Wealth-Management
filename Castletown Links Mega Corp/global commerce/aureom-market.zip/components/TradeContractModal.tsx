'use client';

import React from 'react';
import { TradeContract } from '@/types';
import { X, ShieldCheck, Download, Printer, Lock, FileCheck, CheckCircle2 } from 'lucide-react';

interface TradeContractModalProps {
  contract: TradeContract;
  onClose: () => void;
}

export const TradeContractModal = ({ contract, onClose }: TradeContractModalProps) => {
  const handlePrint = () => {
    window.print();
  };

  const handleDownloadJSON = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(contract, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `${contract.contractId}_signed.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/85 backdrop-blur-md overflow-y-auto">
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl max-w-3xl w-full text-zinc-100 shadow-2xl overflow-hidden font-mono animate-in fade-in zoom-in-95 duration-200">
        {/* Header Bar */}
        <div className="bg-zinc-950 border-b border-zinc-800 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileCheck className="w-5 h-5 text-emerald-400" />
            <div>
              <h3 className="font-bold text-sm uppercase text-zinc-100 tracking-wider">
                DIGITAL TRADE AGREEMENT & PURCHASE CONTRACT
              </h3>
              <p className="text-[10px] text-zinc-500">CONTRACT ID: {contract.contractId}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-zinc-400 hover:text-zinc-100 p-1.5 rounded-lg hover:bg-zinc-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Contract Document Body */}
        <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto text-xs leading-relaxed">
          {/* Document Verification Header */}
          <div className="bg-zinc-950 p-4 rounded-xl border border-zinc-800 space-y-2">
            <div className="flex items-center justify-between text-[10px] text-zinc-400 font-bold uppercase">
              <span className="text-emerald-400 flex items-center gap-1">
                <ShieldCheck className="w-4 h-4" /> SHA-256 DOCUMENT INTEGRITY VERIFIED
              </span>
              <span className="text-zinc-500">TIMESTAMP: {contract.buyerSignature?.timestamp}</span>
            </div>
            <div className="bg-zinc-900 p-2 rounded border border-zinc-800 text-[10px] text-amber-400 font-mono truncate">
              HASH: {contract.documentHashSHA256}
            </div>
          </div>

          {/* Parties */}
          <div className="grid grid-cols-2 gap-4 bg-zinc-950/60 p-4 rounded-xl border border-zinc-800">
            <div>
              <span className="text-[10px] text-zinc-500 uppercase font-bold">BUYER ENTITY:</span>
              <div className="text-sm font-bold text-zinc-100 mt-1">{contract.buyerName}</div>
              <p className="text-[11px] text-zinc-400 mt-0.5">Authorized Procurement Division</p>
            </div>
            <div>
              <span className="text-[10px] text-zinc-500 uppercase font-bold">SELLER ENTITY:</span>
              <div className="text-sm font-bold text-zinc-100 mt-1">{contract.sellerName}</div>
              <p className="text-[11px] text-zinc-400 mt-0.5">Verified Industrial Manufacturer</p>
            </div>
          </div>

          {/* Terms Grid */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider">
              ARTICLE I: COMMERCIAL & DELIVERY TERMS
            </h4>
            <div className="border border-zinc-800 rounded-lg overflow-hidden text-xs">
              <div className="grid grid-cols-3 p-2.5 bg-zinc-950 border-b border-zinc-800">
                <span className="text-zinc-400">PRODUCT ITEM:</span>
                <span className="col-span-2 text-zinc-100 font-semibold">{contract.productName}</span>
              </div>
              <div className="grid grid-cols-3 p-2.5 bg-zinc-900/60 border-b border-zinc-800">
                <span className="text-zinc-400">QUANTITY:</span>
                <span className="col-span-2 text-zinc-100 font-semibold">{contract.quantity} units</span>
              </div>
              <div className="grid grid-cols-3 p-2.5 bg-zinc-950 border-b border-zinc-800">
                <span className="text-zinc-400">TOTAL CONSIDERATION:</span>
                <span className="col-span-2 text-emerald-400 font-bold">
                  ${contract.totalPriceUSD.toLocaleString()} ({contract.currency})
                </span>
              </div>
              <div className="grid grid-cols-3 p-2.5 bg-zinc-900/60 border-b border-zinc-800">
                <span className="text-zinc-400">INCOTERMS & SHIPPING:</span>
                <span className="col-span-2 text-zinc-100">{contract.shippingTerms}</span>
              </div>
              <div className="grid grid-cols-3 p-2.5 bg-zinc-950 border-b border-zinc-800">
                <span className="text-zinc-400">QUALITY & INSPECTION:</span>
                <span className="col-span-2 text-zinc-100">{contract.inspectionTerms}</span>
              </div>
              <div className="grid grid-cols-3 p-2.5 bg-zinc-900/60">
                <span className="text-zinc-400">ESCROW SETTLEMENT:</span>
                <span className="col-span-2 text-zinc-100">{contract.escrowConditions}</span>
              </div>
            </div>
          </div>

          {/* Signatures */}
          <div className="space-y-3 pt-2">
            <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider">
              ARTICLE II: CRYPTOGRAPHIC SIGNATURE ATTESTATIONS
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Buyer Signature */}
              <div className="bg-zinc-950 p-3.5 rounded-xl border border-zinc-800 space-y-2">
                <div className="flex items-center justify-between text-[10px] text-zinc-400 font-bold uppercase">
                  <span>BUYER SIGNATURE</span>
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                </div>
                <div className="text-xs font-bold text-zinc-200">
                  {contract.buyerSignature?.signedBy}
                </div>
                <div className="text-[10px] text-zinc-500">
                  TIMESTAMP: {contract.buyerSignature?.timestamp}
                </div>
                <div className="text-[10px] text-zinc-400 font-mono truncate">
                  SIG: {contract.buyerSignature?.signatureHash}
                </div>
              </div>

              {/* Seller Signature */}
              <div className="bg-zinc-950 p-3.5 rounded-xl border border-zinc-800 space-y-2">
                <div className="flex items-center justify-between text-[10px] text-zinc-400 font-bold uppercase">
                  <span>SELLER SIGNATURE</span>
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                </div>
                <div className="text-xs font-bold text-zinc-200">
                  {contract.sellerSignature?.signedBy}
                </div>
                <div className="text-[10px] text-zinc-500">
                  TIMESTAMP: {contract.sellerSignature?.timestamp}
                </div>
                <div className="text-[10px] text-zinc-400 font-mono truncate">
                  SIG: {contract.sellerSignature?.signatureHash}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Action Footer */}
        <div className="bg-zinc-950 border-t border-zinc-800 px-6 py-4 flex items-center justify-between">
          <button
            onClick={handleDownloadJSON}
            className="bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-zinc-700 px-4 py-2 rounded text-xs font-bold flex items-center gap-2 transition-colors"
          >
            <Download className="w-4 h-4" />
            <span>EXPORT AUDIT JSON</span>
          </button>

          <button
            onClick={handlePrint}
            className="bg-amber-400 hover:bg-amber-300 text-zinc-950 px-4 py-2 rounded text-xs font-black uppercase flex items-center gap-2 transition-colors shadow-lg"
          >
            <Printer className="w-4 h-4" />
            <span>PRINT / SAVE AGREEMENT</span>
          </button>
        </div>
      </div>
    </div>
  );
};
