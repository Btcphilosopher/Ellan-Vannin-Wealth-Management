'use client';

import React, { useState } from 'react';
import { useMarket } from '@/lib/store/market-context';
import {
  Wallet,
  Coins,
  ArrowDownRight,
  ArrowUpRight,
  Lock,
  Copy,
  Plus,
  FileText,
  CheckCircle2,
  QrCode,
  Building2,
  Printer,
} from 'lucide-react';

export const MarketWallet = () => {
  const { walletBalances, walletTransactions, depositFunds, exchangeRates, formatPrice } =
    useMarket();

  const [activeDepositModal, setActiveDepositModal] = useState<any>(null);
  const [depositAmount, setDepositAmount] = useState(1000);
  const [copied, setCopied] = useState(false);

  // Invoice creator form state
  const [showInvoiceModal, setShowInvoiceModal] = useState(false);
  const [invBuyerName, setInvBuyerName] = useState('AeroTech Systems Ltd.');
  const [invProductTitle, setInvProductTitle] = useState('Precision CNC Aluminium Housing');
  const [invAmount, setInvAmount] = useState(5900.00);

  const totalPortfolioUSD =
    walletBalances.btc * exchangeRates.BTC_USD +
    walletBalances.usdt +
    walletBalances.fiatUSD +
    walletBalances.fiatEUR * exchangeRates.EUR_USD +
    walletBalances.fiatGBP * exchangeRates.GBP_USD;

  const handleCopy = (txt: string) => {
    navigator.clipboard.writeText(txt);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePerformDeposit = (asset: 'BTC' | 'USDT' | 'USD') => {
    depositFunds(asset, depositAmount);
    setActiveDepositModal(null);
  };

  return (
    <div className="space-y-8 font-mono">
      {/* Top Total Portfolio Banner */}
      <div className="bg-gradient-to-r from-zinc-950 via-zinc-900 to-zinc-950 border border-zinc-800 rounded-2xl p-6 shadow-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-amber-400 uppercase tracking-widest">
            <Wallet className="w-4 h-4 text-amber-400" />
            NATIVE MULTI-RAIL MARKET WALLET
          </div>
          <h2 className="text-2xl font-black text-zinc-100 uppercase tracking-tight mt-1">
            {formatPrice(totalPortfolioUSD)}
          </h2>
          <p className="text-xs text-zinc-400 mt-0.5">
            Total Liquid Capital & Escrow Locks across Bitcoin, USDT, and Fiat reserves
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveDepositModal('USDT')}
            className="bg-amber-400 hover:bg-amber-300 text-zinc-950 font-black px-4 py-2.5 rounded-lg text-xs uppercase flex items-center gap-1.5 shadow-lg transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>DEPOSIT FUNDS</span>
          </button>

          <button
            onClick={() => setShowInvoiceModal(true)}
            className="bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-zinc-700 font-bold px-4 py-2.5 rounded-lg text-xs uppercase flex items-center gap-1.5 transition-colors"
          >
            <FileText className="w-4 h-4 text-emerald-400" />
            <span>CREATE TRADE INVOICE</span>
          </button>
        </div>
      </div>

      {/* Asset Balances Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Bitcoin */}
        <div className="bg-zinc-900 border border-amber-500/30 p-5 rounded-xl space-y-2">
          <div className="flex items-center justify-between text-xs font-bold">
            <span className="text-amber-400 flex items-center gap-1">
              <Coins className="w-4 h-4" /> BITCOIN (BTC)
            </span>
            <span className="text-[10px] text-zinc-500">ON-CHAIN</span>
          </div>
          <div className="text-xl font-black text-zinc-100">
            {walletBalances.btc.toFixed(4)} BTC
          </div>
          <div className="text-xs text-zinc-400">
            ≈ {formatPrice(walletBalances.btc * exchangeRates.BTC_USD)}
          </div>
        </div>

        {/* USDT */}
        <div className="bg-zinc-900 border border-emerald-500/30 p-5 rounded-xl space-y-2">
          <div className="flex items-center justify-between text-xs font-bold">
            <span className="text-emerald-400 flex items-center gap-1">
              <Coins className="w-4 h-4" /> TETHER (USDT)
            </span>
            <span className="text-[10px] text-zinc-500">TRC20 / SOL</span>
          </div>
          <div className="text-xl font-black text-zinc-100">
            {walletBalances.usdt.toLocaleString()} USDT
          </div>
          <div className="text-xs text-zinc-400">≈ {formatPrice(walletBalances.usdt)}</div>
        </div>

        {/* Fiat USD */}
        <div className="bg-zinc-900 border border-zinc-800 p-5 rounded-xl space-y-2">
          <div className="flex items-center justify-between text-xs font-bold">
            <span className="text-zinc-300">FIAT USD ($)</span>
            <span className="text-[10px] text-zinc-500">BANK WIRE</span>
          </div>
          <div className="text-xl font-black text-zinc-100">
            ${walletBalances.fiatUSD.toLocaleString()}
          </div>
          <div className="text-xs text-zinc-400">USD Reserve Account</div>
        </div>

        {/* Fiat EUR */}
        <div className="bg-zinc-900 border border-zinc-800 p-5 rounded-xl space-y-2">
          <div className="flex items-center justify-between text-xs font-bold">
            <span className="text-zinc-300">FIAT EUR (€)</span>
            <span className="text-[10px] text-zinc-500">SEPA INSTANT</span>
          </div>
          <div className="text-xl font-black text-zinc-100">
            €{walletBalances.fiatEUR.toLocaleString()}
          </div>
          <div className="text-xs text-zinc-400">EUR Reserve Account</div>
        </div>
      </div>

      {/* Transaction History Log */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
          <h3 className="font-bold text-sm text-zinc-100 uppercase tracking-wider">
            WEB3 TRANSACTION & ESCROW AUDIT LOG ({walletTransactions.length})
          </h3>
          <span className="text-xs text-emerald-400 font-bold">ALL TRANSACTIONS FINALIZED</span>
        </div>

        <div className="space-y-2">
          {walletTransactions.map((tx) => (
            <div
              key={tx.id}
              className="bg-zinc-950 p-4 rounded-xl border border-zinc-800/80 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs"
            >
              <div className="flex items-center gap-3">
                <div
                  className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${
                    tx.type === 'ESCROW_LOCK'
                      ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                      : tx.type === 'DEPOSIT'
                      ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                      : 'bg-blue-500/10 text-blue-400 border border-blue-500/30'
                  }`}
                >
                  {tx.type === 'ESCROW_LOCK' ? (
                    <Lock className="w-4 h-4" />
                  ) : tx.type === 'DEPOSIT' ? (
                    <ArrowDownRight className="w-4 h-4" />
                  ) : (
                    <ArrowUpRight className="w-4 h-4" />
                  )}
                </div>

                <div>
                  <div className="font-bold text-zinc-100">{tx.type.replace('_', ' ')}</div>
                  <div className="text-[11px] text-zinc-500">{tx.counterparty}</div>
                  <div className="text-[10px] font-mono text-zinc-600 truncate max-w-xs mt-0.5">
                    TX: {tx.txHash}
                  </div>
                </div>
              </div>

              <div className="text-right">
                <div className="font-bold text-amber-400 font-mono text-sm">
                  {tx.amount} {tx.asset}
                </div>
                <div className="text-[10px] text-zinc-500">{tx.timestamp}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Deposit Modal */}
      {activeDepositModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/85 backdrop-blur-md">
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl max-w-md w-full p-6 text-zinc-100 space-y-4 font-mono shadow-2xl">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
              <h3 className="font-bold text-sm uppercase text-amber-400">
                DEPOSIT {activeDepositModal} TO MARKET WALLET
              </h3>
              <button
                onClick={() => setActiveDepositModal(null)}
                className="text-zinc-500 hover:text-zinc-200"
              >
                ✕
              </button>
            </div>

            <div className="space-y-2">
              <label className="text-xs text-zinc-400">ENTER AMOUNT TO DEPOSIT:</label>
              <input
                type="number"
                value={depositAmount}
                onChange={(e) => setDepositAmount(parseFloat(e.target.value) || 0)}
                className="w-full bg-zinc-950 border border-zinc-800 rounded p-2.5 text-zinc-100 font-bold"
              />
            </div>

            <div className="bg-zinc-950 p-3 rounded-lg border border-zinc-800 space-y-2 text-xs">
              <div className="text-[10px] text-zinc-500 uppercase">SIMULATED RECEIVING ADDRESS:</div>
              <div className="text-[11px] text-amber-400 font-mono break-all bg-zinc-900 p-2 rounded">
                TY8zKq7L3xM9PqW2N81K4m9X2z1L0p9Q81
              </div>
            </div>

            <button
              onClick={() => handlePerformDeposit(activeDepositModal)}
              className="w-full bg-amber-400 text-zinc-950 font-black py-3 rounded-lg uppercase text-xs shadow-lg"
            >
              CONFIRM & SIMULATE DEPOSIT
            </button>
          </div>
        </div>
      )}

      {/* Invoice Modal */}
      {showInvoiceModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/85 backdrop-blur-md">
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl max-w-xl w-full p-6 text-zinc-100 space-y-4 font-mono shadow-2xl">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
              <h3 className="font-bold text-sm uppercase text-emerald-400 flex items-center gap-2">
                <FileText className="w-4 h-4" /> DIGITAL B2B TRADE INVOICE GENERATOR
              </h3>
              <button
                onClick={() => setShowInvoiceModal(false)}
                className="text-zinc-500 hover:text-zinc-200"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-zinc-400 uppercase font-bold">BUYER COMPANY NAME:</label>
                <input
                  type="text"
                  value={invBuyerName}
                  onChange={(e) => setInvBuyerName(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded p-2 text-zinc-100 mt-1"
                />
              </div>

              <div>
                <label className="text-zinc-400 uppercase font-bold">ITEM DESCRIPTION:</label>
                <input
                  type="text"
                  value={invProductTitle}
                  onChange={(e) => setInvProductTitle(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded p-2 text-zinc-100 mt-1"
                />
              </div>

              <div>
                <label className="text-zinc-400 uppercase font-bold">INVOICE AMOUNT ($ USD):</label>
                <input
                  type="number"
                  value={invAmount}
                  onChange={(e) => setInvAmount(parseFloat(e.target.value))}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded p-2 text-zinc-100 mt-1"
                />
              </div>

              <div className="bg-zinc-950 p-3 rounded-xl border border-zinc-800 space-y-1 text-[11px] text-zinc-400">
                <div className="text-amber-400 font-bold uppercase">PAYMENT RECEIVING ADDRESS:</div>
                <div>USDT TRC20: TY8zKq7L3xM9PqW2N81K4m9X2z1L0p9Q81</div>
                <div>Bitcoin On-Chain: bc1q9v80qzp4q6k2u0wlzg2x0vhgvh2s4j4y9l4p3k</div>
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                onClick={() => window.print()}
                className="flex-1 bg-amber-400 text-zinc-950 font-black py-2.5 rounded-lg uppercase text-xs flex items-center justify-center gap-1.5 shadow-lg"
              >
                <Printer className="w-4 h-4" />
                <span>PRINT / EXPORT PDF INVOICE</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
