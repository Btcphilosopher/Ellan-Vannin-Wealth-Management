'use client';

import React from 'react';
import { useMarket } from '@/lib/store/market-context';
import { EscrowTimeline } from './EscrowTimeline';
import {
  PackageCheck,
  FileText,
  Wallet,
  Clock,
  ShieldCheck,
  ChevronRight,
  Plus,
} from 'lucide-react';

export const BuyerDashboard = () => {
  const { orders, rfqs, setActiveTab, setSelectedOrder, selectedOrder, formatPrice } =
    useMarket();

  const activeOrders = orders.filter((o) => o.escrowState !== 'RELEASED');
  const activeOrderToDisplay = selectedOrder || activeOrders[0] || orders[0];

  return (
    <div className="space-y-8 font-mono">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-zinc-950 via-zinc-900 to-zinc-950 border border-zinc-800 rounded-2xl p-6 shadow-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-amber-400 uppercase tracking-widest">
            <PackageCheck className="w-4 h-4 text-amber-400" />
            BUYER PROCUREMENT CONTROL CENTER
          </div>
          <h2 className="text-xl font-black text-zinc-100 uppercase tracking-tight mt-0.5">
            AEROTECH GLOBAL PROCUREMENT DASHBOARD
          </h2>
        </div>

        <button
          onClick={() => setActiveTab('RFQ')}
          className="bg-amber-400 hover:bg-amber-300 text-zinc-950 font-black px-5 py-2.5 rounded-lg text-xs uppercase tracking-wider flex items-center gap-2 shadow-lg transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>CREATE NEW RFQ</span>
        </button>
      </div>

      {/* Active Orders Directory */}
      <div className="space-y-4">
        <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
          <h3 className="font-bold text-sm text-zinc-100 uppercase tracking-wider">
            ACTIVE ORDERS & PROGRAMMABLE ESCROW ({orders.length})
          </h3>
        </div>

        {/* Selected Order Escrow Timeline Viewer */}
        {activeOrderToDisplay ? (
          <div className="space-y-4">
            <div className="flex gap-2 overflow-x-auto pb-2">
              {orders.map((ord) => {
                const isSelected = activeOrderToDisplay.id === ord.id;
                return (
                  <button
                    key={ord.id}
                    onClick={() => setSelectedOrder(ord)}
                    className={`px-4 py-2 rounded-lg border text-xs font-bold font-mono transition-all shrink-0 ${
                      isSelected
                        ? 'bg-amber-500/20 text-amber-300 border-amber-500/60 shadow-lg'
                        : 'bg-zinc-900 text-zinc-400 border-zinc-800 hover:text-zinc-200'
                    }`}
                  >
                    ORDER #{ord.id} ({ord.escrowState})
                  </button>
                );
              })}
            </div>

            <EscrowTimeline order={activeOrderToDisplay} />
          </div>
        ) : (
          <div className="bg-zinc-900 p-8 rounded-xl text-center text-zinc-500 text-xs border border-zinc-800">
            No active orders found. Explore marketplace products to initiate escrow checkout.
          </div>
        )}
      </div>

      {/* Active RFQs Overview */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
          <h3 className="font-bold text-sm text-zinc-100 uppercase tracking-wider flex items-center gap-2">
            <FileText className="w-4 h-4 text-amber-400" />
            MY PUBLISHED RFQS ({rfqs.length})
          </h3>
          <button
            onClick={() => setActiveTab('RFQ')}
            className="text-xs text-amber-400 hover:text-amber-300 flex items-center gap-1 font-bold"
          >
            <span>GO TO RFQ MARKETPLACE</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {rfqs.map((rfq) => (
            <div
              key={rfq.id}
              className="bg-zinc-950 p-4 rounded-xl border border-zinc-800 space-y-2 text-xs"
            >
              <div className="flex items-center justify-between text-[10px]">
                <span className="text-amber-400 font-bold">{rfq.category}</span>
                <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded font-bold">
                  {rfq.quotesCount} QUOTES RECEIVED
                </span>
              </div>
              <h4 className="font-bold text-zinc-100 text-sm">{rfq.productTitle}</h4>
              <div className="text-zinc-400 text-[11px]">
                Target: ${rfq.targetPricePerUnitUSD.toFixed(2)}/unit • Qty: {rfq.quantity}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
