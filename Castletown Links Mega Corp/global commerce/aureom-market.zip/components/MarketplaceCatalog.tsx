'use client';

import React from 'react';
import { useMarket } from '@/lib/store/market-context';
import { CategoryType, PaymentRail } from '@/types';
import { ProductCard } from './ProductCard';
import { GlobalMarketMap } from './GlobalMarketMap';
import {
  Store,
  ShieldCheck,
  Globe,
  Coins,
  Search,
  Filter,
  Sparkles,
  ArrowRight,
  Boxes,
  Lock,
  Building2,
} from 'lucide-react';

export const MarketplaceCatalog = () => {
  const {
    products,
    searchQuery,
    selectedCategory,
    setSelectedCategory,
    selectedRegionId,
    setSelectedRegionId,
    selectedAcceptedRail,
    setSelectedAcceptedRail,
    setActiveTab,
  } = useMarket();

  const categories: (CategoryType | 'ALL')[] = [
    'ALL',
    'Electronics',
    'Machinery',
    'Industrial Equipment',
    'Construction',
    'Energy',
    'Automotive',
    'Textiles',
    'Furniture',
    'Chemicals',
    'Semiconductors',
    'Agriculture',
    'Packaging',
    'Consumer Goods',
    'Software',
    'Components',
    'Luxury Goods',
  ];

  // Filtering logic
  const filteredProducts = products.filter((prod) => {
    if (selectedCategory !== 'ALL' && prod.category !== selectedCategory) {
      return false;
    }

    if (selectedAcceptedRail !== 'ALL' && !prod.acceptedRails.includes(selectedAcceptedRail)) {
      return false;
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = prod.name.toLowerCase().includes(q);
      const matchSku = prod.sku.toLowerCase().includes(q);
      const matchSupplier = prod.supplierName.toLowerCase().includes(q);
      const matchCategory = prod.category.toLowerCase().includes(q);
      const matchDesc = prod.description.toLowerCase().includes(q);
      if (!matchName && !matchSku && !matchSupplier && !matchCategory && !matchDesc) {
        return false;
      }
    }

    return true;
  });

  return (
    <div className="space-y-10 font-mono">
      {/* Hero Banner Section */}
      <div className="relative rounded-2xl bg-gradient-to-br from-zinc-950 via-zinc-900 to-zinc-950 border border-zinc-800 p-8 shadow-2xl overflow-hidden">
        {/* Subtle Background Glows */}
        <div className="absolute -top-24 -right-24 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 bg-zinc-900/90 border border-amber-500/40 text-amber-300 text-xs font-bold px-3 py-1 rounded-full shadow-md">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            THE GLOBAL MARKETPLACE, REBUILT FOR WEB 3.0
          </div>

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-zinc-100 uppercase tracking-tight leading-none">
            GLOBAL COMMERCE. <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-amber-200 to-emerald-400">
              NATIVE MONEY.
            </span>
          </h1>

          <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed max-w-2xl">
            Source manufactured industrial goods, negotiate direct B2B trade contracts, and settle global orders using Bitcoin, USDT, and programmable escrow.
          </p>

          {/* Core Telemetry Metrics Bar */}
          <div className="grid grid-cols-3 gap-4 pt-2 border-t border-zinc-800/80 text-xs">
            <div>
              <div className="text-[10px] text-zinc-500 uppercase">VERIFIED FACTORIES</div>
              <div className="text-base font-black text-zinc-100 mt-0.5">1,240 Hubs</div>
            </div>

            <div>
              <div className="text-[10px] text-zinc-500 uppercase">PROGRAMMABLE ESCROW</div>
              <div className="text-base font-black text-amber-400 mt-0.5">$28.4M Locked</div>
            </div>

            <div>
              <div className="text-[10px] text-zinc-500 uppercase">SETTLEMENT RAILS</div>
              <div className="text-base font-black text-emerald-400 mt-0.5">BTC • USDT • FIAT</div>
            </div>
          </div>

          {/* Action CTAs */}
          <div className="flex flex-wrap items-center gap-3 pt-3">
            <button
              onClick={() => setActiveTab('DISCOVER')}
              className="bg-amber-400 hover:bg-amber-300 text-zinc-950 font-black px-6 py-3 rounded-lg text-xs uppercase tracking-wider flex items-center gap-2 shadow-lg transition-all"
            >
              <Globe className="w-4 h-4" />
              <span>EXPLORE GLOBAL TRADE MAP</span>
            </button>

            <button
              onClick={() => setActiveTab('RFQ')}
              className="bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-zinc-700 font-bold px-6 py-3 rounded-lg text-xs uppercase tracking-wider flex items-center gap-2 transition-colors"
            >
              <span>CREATE AI RFQ BRIEF</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Global Trade Map Preview */}
      <GlobalMarketMap />

      {/* Categories & Rails Filter Bar */}
      <div className="space-y-4 bg-zinc-900 p-5 rounded-xl border border-zinc-800 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-zinc-800 pb-4">
          <div className="flex items-center gap-2 text-xs font-bold uppercase text-zinc-100">
            <Filter className="w-4 h-4 text-amber-400" />
            <span>FILTER INDUSTRIAL CATEGORIES & PAYMENT RAILS</span>
          </div>

          {/* Payment Rail Filter */}
          <div className="flex items-center gap-1.5 text-xs font-mono">
            <span className="text-zinc-500 uppercase text-[10px] font-bold">ACCEPTANCE:</span>
            <button
              onClick={() => setSelectedAcceptedRail('ALL')}
              className={`px-2.5 py-1 rounded border text-[11px] font-bold transition-colors ${
                selectedAcceptedRail === 'ALL'
                  ? 'bg-amber-400 text-zinc-950 border-amber-300'
                  : 'bg-zinc-950 border-zinc-800 text-zinc-400'
              }`}
            >
              ALL RAILS
            </button>
            <button
              onClick={() => setSelectedAcceptedRail('BITCOIN')}
              className={`px-2.5 py-1 rounded border text-[11px] font-bold transition-colors ${
                selectedAcceptedRail === 'BITCOIN'
                  ? 'bg-amber-400 text-zinc-950 border-amber-300'
                  : 'bg-zinc-950 border-zinc-800 text-zinc-400'
              }`}
            >
              ₿ BITCOIN
            </button>
            <button
              onClick={() => setSelectedAcceptedRail('USDT')}
              className={`px-2.5 py-1 rounded border text-[11px] font-bold transition-colors ${
                selectedAcceptedRail === 'USDT'
                  ? 'bg-amber-400 text-zinc-950 border-amber-300'
                  : 'bg-zinc-950 border-zinc-800 text-zinc-400'
              }`}
            >
              ₮ USDT
            </button>
          </div>
        </div>

        {/* Categories Horizontal Scroll Ribbon */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar text-xs">
          {categories.map((cat) => {
            const isSelected = selectedCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3.5 py-1.5 rounded-lg border font-bold transition-all whitespace-nowrap ${
                  isSelected
                    ? 'bg-amber-400 text-zinc-950 border-amber-300 shadow-md'
                    : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200 hover:border-zinc-700'
                }`}
              >
                {cat.toUpperCase()}
              </button>
            );
          })}
        </div>
      </div>

      {/* Catalog Grid Header */}
      <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
        <div className="flex items-center gap-2">
          <Store className="w-4 h-4 text-amber-400" />
          <h2 className="font-bold text-sm uppercase text-zinc-100 tracking-wider">
            PRODUCT CATALOG ({filteredProducts.length})
          </h2>
        </div>

        {selectedRegionId && (
          <button
            onClick={() => setSelectedRegionId(null)}
            className="text-xs text-amber-400 hover:text-amber-300 font-bold"
          >
            Clear Regional Filter ✕
          </button>
        )}
      </div>

      {/* Product Grid */}
      {filteredProducts.length === 0 ? (
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-12 text-center text-zinc-500 font-mono text-xs space-y-2">
          <Boxes className="w-8 h-8 text-zinc-600 mx-auto" />
          <div className="text-zinc-300 font-bold uppercase">No products match your search criteria</div>
          <p>Try resetting category filters or search query.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredProducts.map((prod) => (
            <ProductCard key={prod.id} product={prod} />
          ))}
        </div>
      )}
    </div>
  );
};
