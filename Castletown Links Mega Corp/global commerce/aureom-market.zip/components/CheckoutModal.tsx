'use client';

import React, { useState, useEffect } from 'react';
import { useMarket } from '@/lib/store/market-context';
import { PaymentRail, StablecoinNetwork } from '@/types';
import {
  X,
  ShieldCheck,
  Lock,
  QrCode,
  Copy,
  Clock,
  ArrowRight,
  Wallet,
  CheckCircle2,
  AlertCircle,
  Coins,
} from 'lucide-react';

interface CheckoutModalProps {
  onClose: () => void;
}

export const CheckoutModal = ({ onClose }: CheckoutModalProps) => {
  const { checkoutItem, createOrderFromCheckout, exchangeRates, formatPrice, walletBalances } =
    useMarket();

  const [paymentRail, setPaymentRail] = useState<PaymentRail>('USDT');
  const [selectedNetwork, setSelectedNetwork] = useState<StablecoinNetwork>('TRC20');
  const [copied, setCopied] = useState(false);
  const [timeLeftSeconds, setTimeLeftSeconds] = useState(900); // 15 mins countdown
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeftSeconds((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  if (!checkoutItem) return null;

  const { product, quantity, customizations } = checkoutItem;

  // Calculate pricing
  let unitPrice = product.basePriceUSD;
  const tier = product.priceTiers.find(
    (t) => quantity >= t.minQuantity && (!t.maxQuantity || quantity <= t.maxQuantity)
  );
  if (tier) unitPrice = tier.pricePerUnit;

  const subtotalUSD = unitPrice * quantity;
  const shippingUSD = Math.round(subtotalUSD * 0.04);
  const totalUSD = subtotalUSD + shippingUSD;

  // Selected payment values
  let paymentAmountFormatted = `$${totalUSD.toLocaleString()}`;
  let paymentAddress = 'TY8zKq7L3xM9PqW2N81K4m9X2z1L0p9Q81';

  if (paymentRail === 'BITCOIN') {
    const btcVal = totalUSD / exchangeRates.BTC_USD;
    paymentAmountFormatted = `₿ ${btcVal.toFixed(5)} BTC`;
    paymentAddress = 'bc1q9v80qzp4q6k2u0wlzg2x0vhgvh2s4j4y9l4p3k';
  } else if (paymentRail === 'LIGHTNING') {
    const btcVal = totalUSD / exchangeRates.BTC_USD;
    paymentAmountFormatted = `⚡ ${(btcVal * 100000000).toFixed(0)} sats`;
    paymentAddress = 'lnbc1q9v80qzp4q6k2u0wlzg2x0vhgvh2s4j4y9l4p3k8941029381029381029';
  } else if (paymentRail === 'USDT') {
    paymentAmountFormatted = `₮ ${totalUSD.toLocaleString()} USDT`;
    paymentAddress = product.supplierId === 'sup-101'
      ? 'TY8zKq7L3xM9PqW2N81K4m9X2z1L0p9Q81'
      : '0x71C7656EC7ab88b098defB751B7401B5f6d8976F';
  }

  const handleCopyAddress = () => {
    navigator.clipboard.writeText(paymentAddress);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleConfirmAndPay = () => {
    setIsProcessing(true);
    setTimeout(() => {
      createOrderFromCheckout(paymentRail, selectedNetwork);
      setIsProcessing(false);
      onClose();
    }, 1200);
  };

  const formatTimer = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/85 backdrop-blur-md overflow-y-auto">
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl max-w-3xl w-full text-zinc-100 shadow-2xl overflow-hidden font-mono animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="bg-zinc-950 border-b border-zinc-800 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Lock className="w-4 h-4 text-amber-400" />
            <h3 className="font-bold text-sm uppercase text-zinc-100 tracking-wider">
              AUREOM WEB3 ESCROW CHECKOUT
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-zinc-400 hover:text-zinc-100 p-1.5 rounded-lg hover:bg-zinc-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Order Summary Col */}
          <div className="space-y-4 border-r border-zinc-800/80 pr-0 md:pr-6">
            <div className="text-xs font-bold uppercase text-zinc-400 tracking-wider">
              ORDER SUMMARY
            </div>

            <div className="bg-zinc-950 p-3.5 rounded-xl border border-zinc-800 space-y-3">
              <div className="flex items-start gap-3">
                <img
                  src={product.images[0]}
                  alt=""
                  className="w-12 h-12 rounded object-cover border border-zinc-800 shrink-0"
                />
                <div className="min-w-0">
                  <h4 className="text-xs font-bold text-zinc-100 truncate">{product.name}</h4>
                  <p className="text-[11px] text-zinc-400">
                    {quantity} units × ${unitPrice.toFixed(2)}
                  </p>
                </div>
              </div>

              {/* Customization Details */}
              {Object.keys(customizations).length > 0 && (
                <div className="border-t border-zinc-800/80 pt-2 text-[11px] text-zinc-400 space-y-1">
                  <span className="text-amber-400 font-bold uppercase">Customizations:</span>
                  {Object.entries(customizations).map(([k, v]) => (
                    <div key={k} className="flex justify-between">
                      <span>{k}:</span>
                      <span className="text-zinc-200">{v}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Price Calculations */}
            <div className="space-y-1.5 text-xs text-zinc-400 pt-2">
              <div className="flex justify-between">
                <span>SUBTOTAL:</span>
                <span className="text-zinc-200">${subtotalUSD.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span>ESTIMATED FREIGHT & INSURANCE:</span>
                <span className="text-zinc-200">${shippingUSD.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-sm font-bold text-zinc-100 pt-2 border-t border-zinc-800">
                <span>TOTAL ESCROW VALUE:</span>
                <span className="text-amber-400 font-black">${totalUSD.toLocaleString()}</span>
              </div>
            </div>

            {/* Programmable Escrow Notice */}
            <div className="bg-emerald-500/10 border border-emerald-500/30 p-3 rounded-lg text-emerald-300 text-xs space-y-1">
              <div className="flex items-center gap-1.5 font-bold uppercase">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                PROGRAMMABLE ESCROW GUARANTEE
              </div>
              <p className="text-[11px] text-emerald-200/80 leading-snug">
                Funds remain locked in smart escrow until third-party factory quality inspection and bill of lading port receipt.
              </p>
            </div>
          </div>

          {/* Payment Rail Selector & QR Code Col */}
          <div className="space-y-4">
            <div className="text-xs font-bold uppercase text-zinc-400 tracking-wider">
              SELECT SETTLEMENT RAIL
            </div>

            {/* Rail Buttons */}
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => setPaymentRail('USDT')}
                className={`p-2.5 rounded-lg border text-center transition-all ${
                  paymentRail === 'USDT'
                    ? 'bg-emerald-500/10 border-emerald-500/80 text-emerald-300 font-bold'
                    : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                }`}
              >
                <div className="text-xs font-black">₮ USDT</div>
                <div className="text-[10px] text-zinc-500 mt-0.5">Stablecoin</div>
              </button>

              <button
                onClick={() => setPaymentRail('BITCOIN')}
                className={`p-2.5 rounded-lg border text-center transition-all ${
                  paymentRail === 'BITCOIN'
                    ? 'bg-amber-500/10 border-amber-500/80 text-amber-300 font-bold'
                    : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                }`}
              >
                <div className="text-xs font-black">₿ BITCOIN</div>
                <div className="text-[10px] text-zinc-500 mt-0.5">On-Chain</div>
              </button>

              <button
                onClick={() => setPaymentRail('FIAT')}
                className={`p-2.5 rounded-lg border text-center transition-all ${
                  paymentRail === 'FIAT'
                    ? 'bg-blue-500/10 border-blue-500/80 text-blue-300 font-bold'
                    : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                }`}
              >
                <div className="text-xs font-black">💳 FIAT</div>
                <div className="text-[10px] text-zinc-500 mt-0.5">Wire / Card</div>
              </button>
            </div>

            {/* USDT Network selector */}
            {paymentRail === 'USDT' && (
              <div className="space-y-1">
                <label className="text-[10px] text-zinc-400 uppercase font-bold">
                  SUPPORTED STABLECOIN NETWORK:
                </label>
                <div className="flex gap-1.5 overflow-x-auto text-xs">
                  {(['TRC20', 'ERC20', 'SOLANA', 'TON', 'POLYGON'] as StablecoinNetwork[]).map(
                    (net) => (
                      <button
                        key={net}
                        onClick={() => setSelectedNetwork(net)}
                        className={`px-2.5 py-1 rounded border text-[11px] font-bold ${
                          selectedNetwork === net
                            ? 'bg-emerald-400 text-zinc-950 border-emerald-300'
                            : 'bg-zinc-950 border-zinc-800 text-zinc-400'
                        }`}
                      >
                        {net}
                      </button>
                    )
                  )}
                </div>
              </div>
            )}

            {/* Payment Details Box with Timer */}
            <div className="bg-zinc-950 p-4 rounded-xl border border-zinc-800 space-y-3">
              <div className="flex items-center justify-between text-xs border-b border-zinc-800/80 pb-2">
                <span className="text-zinc-400">EXCHANGE RATE LOCKED FOR:</span>
                <span className="font-bold text-amber-400 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5" />
                  {formatTimer(timeLeftSeconds)}
                </span>
              </div>

              {/* Amount & Address Display */}
              <div>
                <div className="text-[10px] text-zinc-500 uppercase">QUOTED AMOUNT TO PAY:</div>
                <div className="text-lg font-black text-amber-400">{paymentAmountFormatted}</div>
              </div>

              {/* Simulated QR Code & Address Copy */}
              <div className="flex items-center gap-3 bg-zinc-900 p-2.5 rounded border border-zinc-800">
                <div className="w-14 h-14 bg-zinc-100 p-1 rounded shrink-0 flex items-center justify-center">
                  <QrCode className="w-12 h-12 text-zinc-950" />
                </div>
                <div className="min-w-0 flex-1 space-y-1">
                  <div className="text-[10px] text-zinc-500 uppercase">
                    ESCROW DEPOSIT ADDRESS:
                  </div>
                  <div className="text-[10px] font-mono text-zinc-300 truncate bg-zinc-950 p-1 rounded border border-zinc-800">
                    {paymentAddress}
                  </div>
                  <button
                    onClick={handleCopyAddress}
                    className="text-[10px] text-amber-400 hover:text-amber-300 font-bold flex items-center gap-1"
                  >
                    <Copy className="w-3 h-3" />
                    {copied ? 'COPIED TO CLIPBOARD!' : 'COPY DEPOSIT ADDRESS'}
                  </button>
                </div>
              </div>
            </div>

            {/* Final Action CTA */}
            <button
              onClick={handleConfirmAndPay}
              disabled={isProcessing}
              className="w-full bg-amber-400 hover:bg-amber-300 disabled:opacity-50 text-zinc-950 font-black py-3 px-4 rounded-lg uppercase tracking-wider text-xs flex items-center justify-center gap-2 transition-all shadow-lg"
            >
              {isProcessing ? (
                <span>COMMITTING ESCROW ON-CHAIN...</span>
              ) : (
                <>
                  <Wallet className="w-4 h-4" />
                  <span>PAY & COMMIT TO ESCROW ({paymentAmountFormatted})</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
