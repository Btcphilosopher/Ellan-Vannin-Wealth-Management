'use client';

import React, { useState } from 'react';
import { ShieldAlert, X, Info } from 'lucide-react';

export const LegalDisclaimer = () => {
  const [dismissed, setDismissed] = useState(false);

  if (dismissed) return null;

  return (
    <div className="bg-amber-950/80 dark:bg-amber-950/90 border-b border-amber-600/30 text-amber-200 text-xs px-4 py-2 flex items-center justify-between gap-3 shadow-inner">
      <div className="flex items-center gap-2 max-w-7xl mx-auto w-full">
        <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0" />
        <p className="leading-snug">
          <strong className="text-amber-300 font-semibold uppercase tracking-wider mr-1">
            DEMONSTRATION PLATFORM:
          </strong>
          Bitcoin & USDT settlements, programmable escrow states, merchant digital identity attestations, and logistics telemetry in this prototype are simulated using Web3-native architecture and real-time market data adapters.
        </p>
      </div>
      <button
        onClick={() => setDismissed(true)}
        className="text-amber-400 hover:text-amber-100 transition-colors p-1 rounded hover:bg-amber-900/50"
        title="Dismiss notice"
      >
        <X className="w-3.5 h-3.5" />
      </button>
    </div>
  );
};
