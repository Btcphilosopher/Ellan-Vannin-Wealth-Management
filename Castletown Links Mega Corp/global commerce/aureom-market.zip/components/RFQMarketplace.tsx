'use client';

import React, { useState } from 'react';
import { useMarket } from '@/lib/store/market-context';
import { RFQ, Quote } from '@/types';
import {
  Sparkles,
  FileText,
  Send,
  Plus,
  Building2,
  Clock,
  DollarSign,
  MapPin,
  CheckCircle2,
  ChevronRight,
  ShieldCheck,
  Zap,
} from 'lucide-react';

export const RFQMarketplace = () => {
  const { rfqs, quotes, publishRFQ, submitQuote, formatPrice, activeRole } = useMarket();

  const [aiPrompt, setAiPrompt] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [selectedRfqForQuotes, setSelectedRfqForQuotes] = useState<RFQ | null>(rfqs[0] || null);

  // Form State
  const [showManualForm, setShowManualForm] = useState(false);
  const [formTitle, setFormTitle] = useState('');
  const [formCategory, setFormCategory] = useState<any>('Electronics');
  const [formQty, setFormQty] = useState(1000);
  const [formPrice, setFormPrice] = useState(10.00);
  const [formDays, setFormDays] = useState(45);
  const [formDestination, setFormDestination] = useState('London, UK');
  const [formSpecs, setFormSpecs] = useState('');

  // Supplier Quote Form
  const [quoteUnitPrice, setQuoteUnitPrice] = useState(8.50);
  const [quoteLeadDays, setQuoteLeadDays] = useState(30);
  const [quoteNotes, setQuoteNotes] = useState('');

  const handleGenerateWithAi = async () => {
    if (!aiPrompt.trim()) return;
    setIsAiLoading(true);
    try {
      const res = await fetch('/api/gemini/rfq', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: aiPrompt }),
      });
      const data = await res.json();
      if (data && !data.error) {
        setFormTitle(data.productTitle || 'Custom Procurement Request');
        setFormCategory(data.category || 'Electronics');
        setFormQty(data.quantity || 1000);
        setFormPrice(data.targetPricePerUnitUSD || 12.00);
        setFormDays(data.targetDeliveryDays || 60);
        setFormDestination(data.destinationCityCountry || 'London, UK');
        setFormSpecs(data.specifications || aiPrompt);
        setShowManualForm(true);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsAiLoading(false);
    }
  };

  const handlePublishRfq = (e: React.FormEvent) => {
    e.preventDefault();
    const created = publishRFQ({
      productTitle: formTitle,
      category: formCategory,
      quantity: formQty,
      targetPricePerUnitUSD: formPrice,
      targetDeliveryDays: formDays,
      destinationCityCountry: formDestination,
      buyerCountry: 'United Kingdom',
      specifications: formSpecs,
      paymentPreference: ['USDT', 'BITCOIN', 'BANK_TRANSFER'],
    });
    setShowManualForm(false);
    setSelectedRfqForQuotes(created);
  };

  const handleSupplierSubmitQuote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRfqForQuotes) return;

    submitQuote({
      rfqId: selectedRfqForQuotes.id,
      supplierId: 'sup-101',
      supplierName: 'Shenzhen Precision Systems Ltd.',
      supplierLocation: 'Shenzhen, China',
      unitPriceUSD: quoteUnitPrice,
      moq: selectedRfqForQuotes.quantity,
      leadTimeDays: quoteLeadDays,
      toolingCostUSD: 0,
      shippingCostUSD: 1200,
      paymentTerms: '100% Escrow via USDT or Bitcoin',
      warrantyMonths: 24,
      certificationsProvided: ['ISO 9001', 'RoHS', 'CE'],
      notes: quoteNotes || 'Factory capacity allocated on 5-axis CNC lines.',
    });
  };

  const activeRfqQuotes = quotes.filter((q) => q.rfqId === selectedRfqForQuotes?.id);

  return (
    <div className="space-y-8 font-mono">
      {/* AI Brief Generator Banner */}
      <div className="bg-gradient-to-r from-zinc-950 via-zinc-900 to-zinc-950 border border-zinc-800 rounded-2xl p-6 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative z-10">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs font-bold text-amber-400 uppercase tracking-widest">
              <Sparkles className="w-4 h-4 text-amber-400" />
              GEMINI AI PROCUREMENT ASSISTANT
            </div>
            <h2 className="text-xl font-black text-zinc-100 uppercase tracking-tight">
              CREATE VERIFIABLE B2B RFQ IN NATURAL LANGUAGE
            </h2>
            <p className="text-xs text-zinc-400 max-w-xl">
              Type your raw project brief (materials, tolerance, quantity, budget, shipping port). The AI engine formats standard ISO specifications and alerts verified global suppliers.
            </p>
          </div>

          <button
            onClick={() => setShowManualForm(!showManualForm)}
            className="bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-zinc-700 px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-2 shrink-0"
          >
            <Plus className="w-4 h-4 text-amber-400" />
            <span>{showManualForm ? 'CLOSE FORM' : 'MANUAL RFQ FORM'}</span>
          </button>
        </div>

        {/* Natural Language Prompt Input */}
        <div className="mt-4 relative z-10 flex flex-col sm:flex-row gap-2">
          <input
            type="text"
            value={aiPrompt}
            onChange={(e) => setAiPrompt(e.target.value)}
            placeholder="e.g. Need 5,000 CNC 6061-T6 aluminum housings with IP65 seal and black anodized finish, target $12 each, delivery to Manchester in 60 days."
            className="flex-1 bg-zinc-950 border border-zinc-800 focus:border-amber-500/70 text-zinc-100 placeholder-zinc-500 text-xs rounded-lg px-4 py-3 focus:outline-none"
          />
          <button
            onClick={handleGenerateWithAi}
            disabled={isAiLoading}
            className="bg-amber-400 hover:bg-amber-300 disabled:opacity-50 text-zinc-950 font-black px-6 py-3 rounded-lg text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg transition-colors shrink-0"
          >
            {isAiLoading ? (
              <span>PARSING SPECIFICATIONS...</span>
            ) : (
              <>
                <Zap className="w-4 h-4" />
                <span>GENERATE RFQ WITH AI</span>
              </>
            )}
          </button>
        </div>

        {/* Manual / AI Populated Form Modal */}
        {showManualForm && (
          <form
            onSubmit={handlePublishRfq}
            className="mt-6 pt-6 border-t border-zinc-800/80 grid grid-cols-1 md:grid-cols-3 gap-4 text-xs relative z-10 bg-zinc-950/80 p-4 rounded-xl border border-zinc-800"
          >
            <div className="md:col-span-2 space-y-1">
              <label className="text-zinc-400 uppercase font-bold">RFQ PRODUCT TITLE:</label>
              <input
                type="text"
                required
                value={formTitle}
                onChange={(e) => setFormTitle(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded px-3 py-2 text-zinc-100 focus:outline-none"
              />
            </div>

            <div className="space-y-1">
              <label className="text-zinc-400 uppercase font-bold">CATEGORY:</label>
              <select
                value={formCategory}
                onChange={(e) => setFormCategory(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded px-3 py-2 text-zinc-100 focus:outline-none"
              >
                {[
                  'Electronics',
                  'Machinery',
                  'Industrial Equipment',
                  'Construction',
                  'Energy',
                  'Automotive',
                  'Textiles',
                  'Furniture',
                  'Chemicals',
                  'Semiconductors',
                  'Agriculture',
                  'Packaging',
                  'Consumer Goods',
                  'Software',
                  'Components',
                  'Luxury Goods',
                ].map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-zinc-400 uppercase font-bold">TARGET QUANTITY:</label>
              <input
                type="number"
                value={formQty}
                onChange={(e) => setFormQty(parseInt(e.target.value) || 100)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded px-3 py-2 text-zinc-100 focus:outline-none"
              />
            </div>

            <div className="space-y-1">
              <label className="text-zinc-400 uppercase font-bold">TARGET PRICE (USD/UNIT):</label>
              <input
                type="number"
                step={0.1}
                value={formPrice}
                onChange={(e) => setFormPrice(parseFloat(e.target.value) || 1)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded px-3 py-2 text-zinc-100 focus:outline-none"
              />
            </div>

            <div className="space-y-1">
              <label className="text-zinc-400 uppercase font-bold">MAX LEAD TIME (DAYS):</label>
              <input
                type="number"
                value={formDays}
                onChange={(e) => setFormDays(parseInt(e.target.value) || 30)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded px-3 py-2 text-zinc-100 focus:outline-none"
              />
            </div>

            <div className="md:col-span-3 space-y-1">
              <label className="text-zinc-400 uppercase font-bold">TECHNICAL SPECIFICATIONS & NOTES:</label>
              <textarea
                rows={3}
                value={formSpecs}
                onChange={(e) => setFormSpecs(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded px-3 py-2 text-zinc-100 focus:outline-none"
              />
            </div>

            <div className="md:col-span-3 flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowManualForm(false)}
                className="bg-zinc-800 text-zinc-300 px-4 py-2 rounded font-bold uppercase"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="bg-amber-400 text-zinc-950 px-6 py-2 rounded font-black uppercase shadow-lg"
              >
                PUBLISH RFQ TO NETWORK
              </button>
            </div>
          </form>
        )}
      </div>

      {/* Main RFQ Marketplace Directory & Matrix */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* RFQ Directory List */}
        <div className="space-y-4 lg:col-span-1">
          <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
            <h3 className="font-bold text-sm text-zinc-100 uppercase tracking-wider">
              ACTIVE GLOBAL RFQS ({rfqs.length})
            </h3>
            <span className="text-[10px] text-zinc-500 uppercase">REAL-TIME</span>
          </div>

          <div className="space-y-3">
            {rfqs.map((rfq) => {
              const isSelected = selectedRfqForQuotes?.id === rfq.id;
              return (
                <div
                  key={rfq.id}
                  onClick={() => setSelectedRfqForQuotes(rfq)}
                  className={`p-4 rounded-xl border transition-all cursor-pointer space-y-2 ${
                    isSelected
                      ? 'bg-amber-500/10 border-amber-500/80 shadow-lg'
                      : 'bg-zinc-900/90 border-zinc-800 hover:border-zinc-700'
                  }`}
                >
                  <div className="flex items-center justify-between text-[10px] text-zinc-400">
                    <span className="font-bold text-amber-400">{rfq.category}</span>
                    <span className="bg-zinc-800 px-2 py-0.5 rounded text-zinc-300">
                      {rfq.quotesCount} QUOTES
                    </span>
                  </div>

                  <h4 className="font-bold text-sm text-zinc-100 line-clamp-2">{rfq.productTitle}</h4>

                  <div className="grid grid-cols-2 gap-2 text-[11px] text-zinc-400 pt-1">
                    <div>
                      <span>QTY:</span> <strong className="text-zinc-200">{rfq.quantity}</strong>
                    </div>
                    <div>
                      <span>TARGET:</span>{' '}
                      <strong className="text-emerald-400">
                        ${rfq.targetPricePerUnitUSD.toFixed(2)}
                      </strong>
                    </div>
                  </div>

                  <div className="text-[10px] text-zinc-500 flex items-center justify-between pt-1 border-t border-zinc-800/60">
                    <span>{rfq.buyerName}</span>
                    <span>{rfq.destinationCityCountry}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Quotes & Matrix Panel */}
        <div className="lg:col-span-2 space-y-6">
          {selectedRfqForQuotes ? (
            <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6 space-y-6">
              {/* Selected RFQ Overview */}
              <div className="border-b border-zinc-800 pb-4 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-amber-400 uppercase">
                    RFQ #{selectedRfqForQuotes.id} • {selectedRfqForQuotes.category}
                  </span>
                  <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-xs px-2 py-0.5 rounded font-bold">
                    {selectedRfqForQuotes.status}
                  </span>
                </div>
                <h3 className="text-lg font-bold text-zinc-100 uppercase">
                  {selectedRfqForQuotes.productTitle}
                </h3>
                <p className="text-xs text-zinc-400 leading-relaxed bg-zinc-950 p-3 rounded border border-zinc-800">
                  {selectedRfqForQuotes.specifications}
                </p>
              </div>

              {/* Quotes Submitted List */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold uppercase text-zinc-300 tracking-wider">
                  SUBMITTED SUPPLIER QUOTES ({activeRfqQuotes.length})
                </h4>

                {activeRfqQuotes.length === 0 ? (
                  <div className="bg-zinc-950 p-6 rounded-lg border border-zinc-800 text-center text-xs text-zinc-500">
                    No supplier quotes submitted for this RFQ yet.
                  </div>
                ) : (
                  <div className="space-y-3">
                    {activeRfqQuotes.map((q) => (
                      <div
                        key={q.id}
                        className="bg-zinc-950 p-4 rounded-xl border border-zinc-800 space-y-3"
                      >
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-zinc-800/80 pb-2">
                          <div>
                            <span className="text-xs font-bold text-zinc-100">
                              {q.supplierName}
                            </span>
                            <span className="text-[10px] text-zinc-400 ml-2">
                              ({q.supplierLocation})
                            </span>
                          </div>
                          <div className="text-base font-black text-amber-400">
                            ${q.unitPriceUSD.toFixed(2)} / unit
                          </div>
                        </div>

                        <p className="text-xs text-zinc-400 italic">"{q.notes}"</p>

                        <div className="grid grid-cols-3 gap-2 text-[11px] text-zinc-400 bg-zinc-900 p-2 rounded">
                          <div>
                            LEAD TIME: <strong className="text-zinc-200">{q.leadTimeDays}d</strong>
                          </div>
                          <div>
                            FREIGHT: <strong className="text-zinc-200">${q.shippingCostUSD}</strong>
                          </div>
                          <div>
                            WARRANTY: <strong className="text-zinc-200">{q.warrantyMonths}m</strong>
                          </div>
                        </div>

                        <div className="flex items-center justify-between pt-1">
                          <span className="text-[10px] text-emerald-400 flex items-center gap-1 font-bold">
                            <ShieldCheck className="w-3.5 h-3.5" /> ESCROW READY
                          </span>

                          <button className="bg-amber-400 hover:bg-amber-300 text-zinc-950 font-bold text-xs px-3 py-1.5 rounded uppercase transition-colors">
                            ACCEPT QUOTE & ESCROW
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Submit Quote Section for Supplier Mode */}
              {activeRole === 'SUPPLIER' && (
                <form
                  onSubmit={handleSupplierSubmitQuote}
                  className="bg-zinc-950 p-4 rounded-xl border border-amber-500/40 space-y-3"
                >
                  <div className="text-xs font-bold uppercase text-amber-400">
                    SUBMIT FORMAL SUPPLIER QUOTE (MERCHANT OS):
                  </div>

                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div>
                      <label className="text-zinc-400">UNIT PRICE (USD):</label>
                      <input
                        type="number"
                        step={0.1}
                        value={quoteUnitPrice}
                        onChange={(e) => setQuoteUnitPrice(parseFloat(e.target.value))}
                        className="w-full bg-zinc-900 border border-zinc-800 rounded p-2 text-zinc-100"
                      />
                    </div>
                    <div>
                      <label className="text-zinc-400">LEAD TIME (DAYS):</label>
                      <input
                        type="number"
                        value={quoteLeadDays}
                        onChange={(e) => setQuoteLeadDays(parseInt(e.target.value))}
                        className="w-full bg-zinc-900 border border-zinc-800 rounded p-2 text-zinc-100"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs text-zinc-400">FACTORY NOTES:</label>
                    <textarea
                      rows={2}
                      value={quoteNotes}
                      onChange={(e) => setQuoteNotes(e.target.value)}
                      placeholder="Specify CNC machine availability, ISO certs, or payment terms..."
                      className="w-full bg-zinc-900 border border-zinc-800 rounded p-2 text-xs text-zinc-100"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-amber-400 text-zinc-950 font-black py-2 rounded text-xs uppercase shadow"
                  >
                    SUBMIT QUOTE TO BUYER
                  </button>
                </form>
              )}
            </div>
          ) : (
            <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-8 text-center text-zinc-500 text-xs">
              Select an RFQ from the left directory to view quote matrix.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
