'use client';

import React from 'react';
import { useMarket } from '@/lib/store/market-context';
import { Globe, ShieldCheck, Lock, Cpu, Coins, Terminal } from 'lucide-react';

export const Footer = () => {
  const { setActiveTab } = useMarket();

  return (
    <footer className="bg-zinc-950 border-t border-zinc-800 text-zinc-400 text-xs font-mono py-12 px-4 mt-16">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-5 gap-8">
        {/* Brand Col */}
        <div className="md:col-span-2 space-y-3">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded bg-zinc-100 text-zinc-950 font-black text-sm flex items-center justify-center">
              AM
            </div>
            <span className="text-zinc-100 font-bold tracking-wider text-sm uppercase">
              AUREOM MARKET
            </span>
          </div>
          <p className="text-zinc-400 text-xs leading-relaxed max-w-sm">
            The Web3-native global B2B/B2C marketplace. Source manufactured goods, negotiate direct contracts, and settle global trade with native digital money.
          </p>
          <div className="flex items-center gap-4 text-[11px] text-zinc-500 pt-2">
            <span className="flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> Cryptographic Identity
            </span>
            <span className="flex items-center gap-1">
              <Lock className="w-3.5 h-3.5 text-amber-400" /> Programmable Escrow
            </span>
          </div>
        </div>

        {/* Global Commerce */}
        <div>
          <h4 className="text-zinc-200 font-semibold tracking-wider text-xs uppercase mb-3 text-zinc-300">
            MARKETPLACE
          </h4>
          <ul className="space-y-2 text-zinc-400 text-xs">
            <li>
              <button onClick={() => setActiveTab('MARKETPLACE')} className="hover:text-zinc-100 transition-colors">
                Product Catalog
              </button>
            </li>
            <li>
              <button onClick={() => setActiveTab('DISCOVER')} className="hover:text-zinc-100 transition-colors">
                Global Trade Map
              </button>
            </li>
            <li>
              <button onClick={() => setActiveTab('SUPPLIERS')} className="hover:text-zinc-100 transition-colors">
                Verified Manufacturer Directory
              </button>
            </li>
            <li>
              <button onClick={() => setActiveTab('RFQ')} className="hover:text-zinc-100 transition-colors">
                Request for Quotation (RFQ)
              </button>
            </li>
          </ul>
        </div>

        {/* Web3 Infrastructure */}
        <div>
          <h4 className="text-zinc-200 font-semibold tracking-wider text-xs uppercase mb-3 text-zinc-300">
            FINANCIAL RAILS
          </h4>
          <ul className="space-y-2 text-zinc-400 text-xs">
            <li>
              <button onClick={() => setActiveTab('FINANCE')} className="hover:text-zinc-100 transition-colors">
                Bitcoin On-Chain Settlement
              </button>
            </li>
            <li>
              <button onClick={() => setActiveTab('FINANCE')} className="hover:text-zinc-100 transition-colors">
                Tether (USDT) Multi-Network
              </button>
            </li>
            <li>
              <button onClick={() => setActiveTab('ORDERS')} className="hover:text-zinc-100 transition-colors">
                Multi-Sig Escrow Engine
              </button>
            </li>
            <li>
              <button onClick={() => setActiveTab('LOGISTICS')} className="hover:text-zinc-100 transition-colors">
                Container Telemetry & BL Hashes
              </button>
            </li>
          </ul>
        </div>

        {/* Merchant OS & AI */}
        <div>
          <h4 className="text-zinc-200 font-semibold tracking-wider text-xs uppercase mb-3 text-zinc-300">
            SYSTEMS
          </h4>
          <ul className="space-y-2 text-zinc-400 text-xs">
            <li>
              <button onClick={() => setActiveTab('MERCHANT_OS')} className="hover:text-zinc-100 transition-colors">
                Merchant Operating System
              </button>
            </li>
            <li>
              <button onClick={() => setActiveTab('RFQ')} className="hover:text-zinc-100 transition-colors">
                AI Procurement Engine
              </button>
            </li>
            <li>
              <button onClick={() => setActiveTab('FINANCE')} className="hover:text-zinc-100 transition-colors">
                Market Wallet & Invoicing
              </button>
            </li>
          </ul>
        </div>
      </div>

      <div className="max-w-7xl mx-auto border-t border-zinc-900 mt-8 pt-6 flex flex-col md:flex-row items-center justify-between gap-4 text-[11px] text-zinc-500">
        <div>
          © 2026 AUREOM MARKET INC. GLOBAL COMMERCE. NATIVE MONEY.
        </div>
        <div className="flex items-center gap-4">
          <span>SHA-256 Verified Records</span>
          <span>•</span>
          <span>Zero-Knowledge Proof Attestations</span>
          <span>•</span>
          <span>ISO 27001 Certified Architecture</span>
        </div>
      </div>
    </footer>
  );
};
