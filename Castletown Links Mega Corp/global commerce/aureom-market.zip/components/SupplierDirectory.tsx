'use client';

import React, { useState } from 'react';
import { useMarket } from '@/lib/store/market-context';
import { SupplierCard } from './SupplierCard';
import { Building2, ShieldCheck, Search, MapPin, Award, CheckCircle2 } from 'lucide-react';

export const SupplierDirectory = () => {
  const { suppliers, selectedRegionId, setSelectedRegionId } = useMarket();

  const [filterType, setFilterType] = useState<string>('ALL');

  const filteredSuppliers = suppliers.filter((sup) => {
    if (filterType !== 'ALL' && sup.type !== filterType) return false;
    return true;
  });

  return (
    <div className="space-y-8 font-mono">
      {/* Header */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-amber-400 uppercase tracking-widest">
            <Building2 className="w-4 h-4 text-amber-400" />
            VERIFIED MANUFACTURER DIRECTORY
          </div>
          <h2 className="text-xl font-black text-zinc-100 uppercase tracking-tight mt-0.5">
            AUTHENTICATED GLOBAL INDUSTRIAL SUPPLIERS
          </h2>
        </div>

        <div className="flex items-center gap-2 text-xs text-emerald-400 font-bold bg-zinc-950 px-3 py-1.5 rounded border border-zinc-800">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>100% FACTORY LOCATION & WALLET OWNERSHIP AUDITED</span>
        </div>
      </div>

      {/* Filter Ribbon */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-zinc-950 p-4 rounded-xl border border-zinc-800 text-xs">
        <div className="flex items-center gap-2">
          <span className="text-zinc-400 uppercase font-bold">TYPE:</span>
          <button
            onClick={() => setFilterType('ALL')}
            className={`px-3 py-1.5 rounded border font-bold transition-colors ${
              filterType === 'ALL'
                ? 'bg-amber-400 text-zinc-950 border-amber-300'
                : 'bg-zinc-900 border-zinc-800 text-zinc-400'
            }`}
          >
            ALL
          </button>
          <button
            onClick={() => setFilterType('VERIFIED_FACTORY')}
            className={`px-3 py-1.5 rounded border font-bold transition-colors ${
              filterType === 'VERIFIED_FACTORY'
                ? 'bg-amber-400 text-zinc-950 border-amber-300'
                : 'bg-zinc-900 border-zinc-800 text-zinc-400'
            }`}
          >
            VERIFIED FACTORIES
          </button>
          <button
            onClick={() => setFilterType('TRADING_COMPANY')}
            className={`px-3 py-1.5 rounded border font-bold transition-colors ${
              filterType === 'TRADING_COMPANY'
                ? 'bg-amber-400 text-zinc-950 border-amber-300'
                : 'bg-zinc-900 border-zinc-800 text-zinc-400'
            }`}
          >
            TRADING HUBS
          </button>
        </div>

        <span className="text-zinc-500">{filteredSuppliers.length} Verified Suppliers</span>
      </div>

      {/* Supplier Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredSuppliers.map((sup) => (
          <SupplierCard key={sup.id} supplier={sup} />
        ))}
      </div>
    </div>
  );
};
