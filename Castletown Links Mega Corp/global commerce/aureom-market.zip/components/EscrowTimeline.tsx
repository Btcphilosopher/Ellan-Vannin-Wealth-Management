'use client';

import React, { useState } from 'react';
import { Order, EscrowState } from '@/types';
import { useMarket } from '@/lib/store/market-context';
import { TradeContractModal } from './TradeContractModal';
import {
  CheckCircle2,
  Clock,
  ShieldCheck,
  Lock,
  ArrowRight,
  AlertTriangle,
  FileCheck,
  ExternalLink,
  Coins,
} from 'lucide-react';

interface EscrowTimelineProps {
  order: Order;
}

export const EscrowTimeline = ({ order }: EscrowTimelineProps) => {
  const { advanceEscrowStage, releaseEscrow, raiseDispute, formatPrice } = useMarket();
  const [showContractModal, setShowContractModal] = useState(false);
  const [disputeReason, setDisputeReason] = useState('');
  const [showDisputeInput, setShowDisputeInput] = useState(false);

  const stagesOrder: EscrowState[] = [
    'CREATED',
    'FUNDED',
    'PRODUCTION',
    'INSPECTION',
    'SHIPPED',
    'DELIVERED',
    'RELEASED',
  ];

  const currentStageIndex = stagesOrder.indexOf(
    order.escrowState === 'RELEASE_PENDING' ? 'DELIVERED' : order.escrowState
  );

  const isDisputed = order.escrowState === 'DISPUTED';
  const isReleased = order.escrowState === 'RELEASED';

  const handleDisputeSubmit = () => {
    if (!disputeReason.trim()) return;
    raiseDispute(order.id, disputeReason);
    setShowDisputeInput(false);
  };

  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6 shadow-xl space-y-6 font-mono text-zinc-100">
      {/* Top Escrow Summary Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-zinc-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-amber-400 uppercase tracking-widest flex items-center gap-1">
              <Lock className="w-3.5 h-3.5" /> PROGRAMMABLE ESCROW STATE MACHINE
            </span>
            <span className="text-zinc-600">|</span>
            <span className="text-xs text-zinc-400">ORDER #{order.id}</span>
          </div>
          <h3 className="text-lg font-bold text-zinc-100 uppercase mt-1">
            {order.items[0].productName}
          </h3>
        </div>

        {/* Amount & Status Badge */}
        <div className="flex items-center gap-3">
          <div className="text-right">
            <div className="text-[10px] text-zinc-500 uppercase">LOCKED ESCROW VALUE</div>
            <div className="text-base font-black text-amber-400">
              {order.quotedAmountCrypto || formatPrice(order.totalUSD)}
            </div>
          </div>

          <div
            className={`px-3 py-1.5 rounded-lg border text-xs font-bold uppercase tracking-wider ${
              isDisputed
                ? 'bg-rose-500/10 border-rose-500/50 text-rose-400'
                : isReleased
                ? 'bg-emerald-500/10 border-emerald-500/50 text-emerald-400'
                : 'bg-amber-500/10 border-amber-500/50 text-amber-300'
            }`}
          >
            {order.escrowState.replace('_', ' ')}
          </div>
        </div>
      </div>

      {/* Visual Timeline Progress Bar */}
      <div className="relative py-2">
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
          {stagesOrder.map((stage, idx) => {
            const isCompleted = idx <= currentStageIndex && !isDisputed;
            const isCurrent = idx === currentStageIndex && !isDisputed && !isReleased;

            const milestone = order.milestones.find((m) => m.stage === stage);

            return (
              <div
                key={stage}
                className={`p-3 rounded-lg border text-left transition-all ${
                  isCurrent
                    ? 'bg-amber-500/10 border-amber-500/70 text-amber-300 shadow-lg'
                    : isCompleted
                    ? 'bg-zinc-950/80 border-emerald-500/40 text-emerald-400'
                    : 'bg-zinc-950/40 border-zinc-800 text-zinc-600'
                }`}
              >
                <div className="flex items-center justify-between gap-1 mb-1.5">
                  <span className="text-[10px] font-bold uppercase tracking-wider">
                    STEP 0{idx + 1}
                  </span>
                  {isCompleted ? (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  ) : isCurrent ? (
                    <Clock className="w-3.5 h-3.5 text-amber-400 animate-spin shrink-0" />
                  ) : (
                    <span className="w-3.5 h-3.5 rounded-full border border-zinc-700 shrink-0" />
                  )}
                </div>

                <div className="text-xs font-bold text-zinc-200 line-clamp-1 uppercase">
                  {stage}
                </div>

                {milestone?.timestamp && (
                  <div className="text-[9px] text-zinc-500 mt-1 truncate">
                    {milestone.timestamp}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Contract & Cryptographic Details Bar */}
      <div className="bg-zinc-950 p-4 rounded-xl border border-zinc-800 grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
        <div>
          <span className="text-[10px] text-zinc-500 uppercase">MERCHANT RECIPIENT:</span>
          <div className="font-bold text-zinc-200 truncate mt-0.5">{order.sellerName}</div>
        </div>

        <div>
          <span className="text-[10px] text-zinc-500 uppercase">PAYMENT TX HASH:</span>
          <div className="font-mono text-amber-400 truncate mt-0.5">{order.paymentTxHash}</div>
        </div>

        <div className="flex items-center justify-end">
          <button
            onClick={() => setShowContractModal(true)}
            className="bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-zinc-700 px-3 py-1.5 rounded text-xs font-bold flex items-center gap-1.5 transition-colors"
          >
            <FileCheck className="w-4 h-4 text-emerald-400" />
            <span>VIEW SIGNED CONTRACT</span>
          </button>
        </div>
      </div>

      {/* Interactive Milestone Trigger Controls */}
      {!isReleased && !isDisputed && (
        <div className="bg-zinc-950/60 p-4 rounded-xl border border-zinc-800 space-y-3">
          <div className="text-xs font-bold text-zinc-300 uppercase tracking-wider">
            MILESTONE GOVERNANCE & SETTLEMENT CONTROLS:
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {order.escrowState !== 'DELIVERED' && (
              <button
                onClick={() => advanceEscrowStage(order.id)}
                className="bg-zinc-800 hover:bg-zinc-700 text-amber-300 border border-amber-500/40 text-xs font-bold px-4 py-2 rounded-lg uppercase tracking-wider flex items-center gap-2 transition-colors"
              >
                <span>ADVANCE TO NEXT STAGE</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}

            <button
              onClick={() => releaseEscrow(order.id)}
              className="bg-emerald-500 hover:bg-emerald-400 text-zinc-950 text-xs font-black px-4 py-2 rounded-lg uppercase tracking-wider flex items-center gap-2 transition-colors shadow-lg"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>RELEASE ESCROW FUNDS TO MERCHANT</span>
            </button>

            <button
              onClick={() => setShowDisputeInput(!showDisputeInput)}
              className="bg-zinc-900 hover:bg-rose-950/50 text-rose-400 border border-rose-500/30 text-xs font-bold px-3 py-2 rounded-lg uppercase tracking-wider flex items-center gap-1.5 transition-colors ml-auto"
            >
              <AlertTriangle className="w-4 h-4" />
              <span>RAISE TRADE DISPUTE</span>
            </button>
          </div>

          {/* Dispute Form */}
          {showDisputeInput && (
            <div className="pt-3 border-t border-zinc-800 space-y-2">
              <label className="text-xs text-rose-400 font-bold uppercase">
                SPECIFY REASON FOR ESCROW DISPUTE / ARBITRATION:
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={disputeReason}
                  onChange={(e) => setDisputeReason(e.target.value)}
                  placeholder="e.g. Specification non-conformity during factory inspection..."
                  className="bg-zinc-900 border border-rose-500/40 text-zinc-100 text-xs rounded px-3 py-2 flex-1 focus:outline-none"
                />
                <button
                  onClick={handleDisputeSubmit}
                  className="bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs px-4 py-2 rounded uppercase"
                >
                  Submit
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Modal for Signed Digital Contract */}
      {showContractModal && order.contract && (
        <TradeContractModal contract={order.contract} onClose={() => setShowContractModal(false)} />
      )}
    </div>
  );
};
