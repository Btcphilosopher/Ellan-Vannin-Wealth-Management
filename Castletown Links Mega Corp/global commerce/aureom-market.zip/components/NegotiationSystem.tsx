'use client';

import React, { useState } from 'react';
import { useMarket } from '@/lib/store/market-context';
import { StructuredOffer } from '@/types';
import {
  MessageSquare,
  Send,
  Building2,
  CheckCircle2,
  XCircle,
  ArrowRightLeft,
  DollarSign,
  Clock,
  ShieldCheck,
  FileText,
} from 'lucide-react';

export const NegotiationSystem = () => {
  const {
    negotiationThreads,
    activeThreadId,
    setActiveThreadId,
    sendNegotiationMessage,
    respondToOffer,
    activeRole,
    setCheckoutItem,
    products,
  } = useMarket();

  const [messageText, setMessageText] = useState('');
  const [showOfferForm, setShowOfferForm] = useState(false);

  // Counter offer form states
  const [offerQty, setOfferQty] = useState(10000);
  const [offerPrice, setOfferPrice] = useState(4.20);
  const [offerLeadDays, setOfferLeadDays] = useState(25);
  const [offerFreight, setOfferFreight] = useState(800);

  const activeThread = negotiationThreads.find((t) => t.id === activeThreadId) || negotiationThreads[0];

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageText.trim() && !showOfferForm) return;

    let offer: StructuredOffer | undefined;
    if (showOfferForm) {
      offer = {
        quantity: offerQty,
        unitPriceUSD: offerPrice,
        leadTimeDays: offerLeadDays,
        shippingCostUSD: offerFreight,
        paymentTerms: '100% Escrow locked via USDT or BTC',
      };
    }

    sendNegotiationMessage(
      activeThread.id,
      messageText || 'Here is our revised structured counter-offer.',
      offer
    );

    setMessageText('');
    setShowOfferForm(false);
  };

  const handleAcceptAndCheckout = (msgId: string, offer: StructuredOffer) => {
    respondToOffer(activeThread.id, msgId, 'ACCEPTED');
    const prod = products.find((p) => p.id === activeThread.productId) || products[0];
    setCheckoutItem({
      product: {
        ...prod,
        basePriceUSD: offer.unitPriceUSD,
      },
      quantity: offer.quantity,
      customizations: {},
    });
  };

  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden shadow-2xl font-mono text-zinc-100 grid grid-cols-1 md:grid-cols-3 min-h-[600px]">
      {/* Threads Sidebar */}
      <div className="border-r border-zinc-800 bg-zinc-950 p-4 space-y-4">
        <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
          <div className="flex items-center gap-2">
            <MessageSquare className="w-4 h-4 text-amber-400" />
            <h3 className="font-bold text-xs uppercase text-zinc-100 tracking-wider">
              DIRECT NEGOTIATIONS
            </h3>
          </div>
          <span className="text-[10px] text-zinc-500 uppercase">{negotiationThreads.length} ACTIVE</span>
        </div>

        <div className="space-y-2">
          {negotiationThreads.map((thread) => {
            const isSelected = thread.id === activeThread.id;
            return (
              <div
                key={thread.id}
                onClick={() => setActiveThreadId(thread.id)}
                className={`p-3 rounded-lg border transition-all cursor-pointer space-y-1 ${
                  isSelected
                    ? 'bg-amber-500/10 border-amber-500/80'
                    : 'bg-zinc-900 border-zinc-800 hover:border-zinc-700'
                }`}
              >
                <div className="text-xs font-bold text-zinc-100 truncate">
                  {thread.supplierName}
                </div>
                <div className="text-[11px] text-amber-400 truncate">{thread.productName}</div>
                <div className="text-[10px] text-zinc-500 pt-1 flex items-center justify-between">
                  <span>{thread.messages.length} messages</span>
                  <span className="text-emerald-400 font-bold">LIVE</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Main Chat Stream & Offer Card Area */}
      <div className="md:col-span-2 flex flex-col justify-between bg-zinc-900 p-6 space-y-4">
        {/* Header */}
        <div className="border-b border-zinc-800 pb-3 flex items-center justify-between">
          <div>
            <span className="text-[10px] text-amber-400 font-bold uppercase">THREAD #{activeThread.id}</span>
            <h3 className="text-sm font-bold text-zinc-100 uppercase mt-0.5">
              {activeThread.supplierName}
            </h3>
            <p className="text-xs text-zinc-400">{activeThread.productName}</p>
          </div>

          <button
            onClick={() => setShowOfferForm(!showOfferForm)}
            className="bg-zinc-800 hover:bg-zinc-700 text-amber-300 border border-amber-500/40 text-xs font-bold px-3 py-1.5 rounded flex items-center gap-1.5 transition-colors"
          >
            <ArrowRightLeft className="w-3.5 h-3.5" />
            <span>{showOfferForm ? 'HIDE FORM' : 'ATTACH STRUCTURED OFFER'}</span>
          </button>
        </div>

        {/* Message Stream */}
        <div className="flex-1 space-y-4 overflow-y-auto max-h-[400px] pr-2">
          {activeThread.messages.map((msg) => {
            const isMe =
              (activeRole === 'BUYER' && msg.senderRole === 'BUYER') ||
              (activeRole === 'SUPPLIER' && msg.senderRole === 'SUPPLIER');

            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} space-y-1.5`}
              >
                <div className="flex items-center gap-2 text-[10px] text-zinc-500">
                  <span>{msg.senderName}</span>
                  <span>•</span>
                  <span>{msg.timestamp}</span>
                </div>

                <div
                  className={`p-3.5 rounded-xl text-xs leading-relaxed max-w-lg border ${
                    isMe
                      ? 'bg-amber-500/10 border-amber-500/30 text-zinc-100'
                      : 'bg-zinc-950 border-zinc-800 text-zinc-200'
                  }`}
                >
                  <p>{msg.text}</p>

                  {/* Structured Offer Card */}
                  {msg.structuredOffer && (
                    <div className="mt-3 p-3 rounded-lg bg-zinc-900 border border-amber-500/40 space-y-2">
                      <div className="flex items-center justify-between text-[10px] text-amber-400 font-bold uppercase">
                        <span>FORMAL STRUCTURED TRADE OFFER</span>
                        <span>{msg.status || 'PENDING'}</span>
                      </div>

                      <div className="grid grid-cols-2 gap-2 text-[11px] font-mono text-zinc-300">
                        <div>
                          QUANTITY: <strong className="text-zinc-100">{msg.structuredOffer.quantity}</strong>
                        </div>
                        <div>
                          UNIT PRICE:{' '}
                          <strong className="text-emerald-400">
                            ${msg.structuredOffer.unitPriceUSD.toFixed(2)}
                          </strong>
                        </div>
                        <div>
                          LEAD TIME: <strong className="text-zinc-100">{msg.structuredOffer.leadTimeDays} days</strong>
                        </div>
                        <div>
                          FREIGHT: <strong className="text-zinc-100">${msg.structuredOffer.shippingCostUSD}</strong>
                        </div>
                      </div>

                      <div className="text-[10px] text-zinc-400">
                        TERMS: {msg.structuredOffer.paymentTerms}
                      </div>

                      {/* Offer Action Buttons */}
                      {msg.status === 'PENDING' && !isMe && (
                        <div className="pt-2 border-t border-zinc-800 flex items-center gap-2">
                          <button
                            onClick={() => handleAcceptAndCheckout(msg.id, msg.structuredOffer!)}
                            className="bg-amber-400 hover:bg-amber-300 text-zinc-950 font-bold text-xs px-3 py-1 rounded uppercase flex items-center gap-1 shadow"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            ACCEPT & ESCROW
                          </button>

                          <button
                            onClick={() => respondToOffer(activeThread.id, msg.id, 'REJECTED')}
                            className="bg-zinc-800 hover:bg-rose-900/50 text-rose-400 text-xs px-3 py-1 rounded uppercase"
                          >
                            REJECT
                          </button>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Counter Offer Form Drawer */}
        {showOfferForm && (
          <div className="bg-zinc-950 p-4 rounded-xl border border-amber-500/40 space-y-3 text-xs">
            <div className="text-xs font-bold uppercase text-amber-400">
              BUILD STRUCTURED OFFER / COUNTER-OFFER:
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <div>
                <label className="text-[10px] text-zinc-400">QTY:</label>
                <input
                  type="number"
                  value={offerQty}
                  onChange={(e) => setOfferQty(parseInt(e.target.value))}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded p-1.5 text-zinc-100"
                />
              </div>

              <div>
                <label className="text-[10px] text-zinc-400">PRICE ($/UNIT):</label>
                <input
                  type="number"
                  step={0.1}
                  value={offerPrice}
                  onChange={(e) => setOfferPrice(parseFloat(e.target.value))}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded p-1.5 text-zinc-100"
                />
              </div>

              <div>
                <label className="text-[10px] text-zinc-400">LEAD TIME (DAYS):</label>
                <input
                  type="number"
                  value={offerLeadDays}
                  onChange={(e) => setOfferLeadDays(parseInt(e.target.value))}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded p-1.5 text-zinc-100"
                />
              </div>

              <div>
                <label className="text-[10px] text-zinc-400">FREIGHT ($):</label>
                <input
                  type="number"
                  value={offerFreight}
                  onChange={(e) => setOfferFreight(parseInt(e.target.value))}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded p-1.5 text-zinc-100"
                />
              </div>
            </div>
          </div>
        )}

        {/* Send Box */}
        <form onSubmit={handleSendMessage} className="flex gap-2">
          <input
            type="text"
            value={messageText}
            onChange={(e) => setMessageText(e.target.value)}
            placeholder="Type your message or negotiate terms..."
            className="flex-1 bg-zinc-950 border border-zinc-800 focus:border-amber-500 text-zinc-100 text-xs rounded-lg px-4 py-2.5 focus:outline-none"
          />
          <button
            type="submit"
            className="bg-amber-400 hover:bg-amber-300 text-zinc-950 font-black px-5 py-2.5 rounded-lg text-xs uppercase flex items-center gap-1.5 shadow-lg"
          >
            <Send className="w-3.5 h-3.5" />
            <span>SEND</span>
          </button>
        </form>
      </div>
    </div>
  );
};
