'use client';

import React from 'react';
import { Supplier } from '@/types';
import { useMarket } from '@/lib/store/market-context';
import {
  ShieldCheck,
  Star,
  MapPin,
  Building2,
  Users,
  Award,
  CheckCircle2,
  ExternalLink,
  Lock,
} from 'lucide-react';

interface SupplierCardProps {
  supplier: Supplier;
}

export const SupplierCard = ({ supplier }: SupplierCardProps) => {
  const { setSelectedSupplier, setActiveTab } = useMarket();

  return (
    <div
      onClick={() => setSelectedSupplier(supplier)}
      className="group bg-zinc-900/90 hover:bg-zinc-900 border border-zinc-800 hover:border-amber-500/50 rounded-xl p-5 shadow-lg transition-all duration-300 cursor-pointer space-y-4 flex flex-col justify-between"
    >
      <div className="space-y-3">
        {/* Top Header */}
        <div className="flex items-start gap-3">
          <img
            src={supplier.logo}
            alt={supplier.name}
            className="w-12 h-12 rounded-lg object-cover border border-zinc-700 shrink-0"
          />
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[10px] font-mono font-bold px-1.5 py-0.2 rounded flex items-center gap-1">
                <ShieldCheck className="w-3 h-3" />
                VERIFIED MANUFACTURER
              </span>
              <span className="text-[10px] font-mono text-zinc-500">
                {supplier.yearsOnMarket} YRS
              </span>
            </div>
            <h3 className="font-mono text-base font-bold text-zinc-100 group-hover:text-amber-400 transition-colors truncate mt-1">
              {supplier.name}
            </h3>
            <p className="text-xs font-mono text-zinc-400 flex items-center gap-1 mt-0.5">
              <MapPin className="w-3 h-3 text-zinc-500" />
              {supplier.location}
            </p>
          </div>
        </div>

        {/* Overview */}
        <p className="text-xs text-zinc-400 line-clamp-2 leading-relaxed">
          {supplier.overview}
        </p>

        {/* Performance Metrics Bar */}
        <div className="grid grid-cols-4 gap-1.5 font-mono text-center bg-zinc-950/80 p-2 rounded border border-zinc-800/80">
          <div>
            <div className="text-[9px] text-zinc-500 uppercase">RATING</div>
            <div className="text-xs font-bold text-amber-400 flex items-center justify-center gap-0.5 mt-0.5">
              <Star className="w-3 h-3 fill-amber-400" />
              {supplier.rating}
            </div>
          </div>

          <div>
            <div className="text-[9px] text-zinc-500 uppercase">ON-TIME</div>
            <div className="text-xs font-bold text-zinc-100 mt-0.5">
              {supplier.onTimeDeliveryRate}%
            </div>
          </div>

          <div>
            <div className="text-[9px] text-zinc-500 uppercase">DISPUTE</div>
            <div className="text-xs font-bold text-emerald-400 mt-0.5">
              {supplier.disputeRate}%
            </div>
          </div>

          <div>
            <div className="text-[9px] text-zinc-500 uppercase">REPEAT</div>
            <div className="text-xs font-bold text-zinc-100 mt-0.5">
              {supplier.repeatBuyerRate}%
            </div>
          </div>
        </div>

        {/* Digital Identity Proof Badges */}
        <div className="space-y-1.5 pt-1">
          <div className="text-[10px] font-mono font-bold uppercase text-zinc-500 tracking-wider flex items-center gap-1">
            <Lock className="w-3 h-3 text-amber-400" />
            CRYPTOGRAPHIC ATTESTATIONS:
          </div>
          <div className="grid grid-cols-2 gap-1 text-[11px] font-mono text-zinc-400">
            <span className="flex items-center gap-1 text-emerald-400">
              <CheckCircle2 className="w-3 h-3" /> Identity Verified
            </span>
            <span className="flex items-center gap-1 text-emerald-400">
              <CheckCircle2 className="w-3 h-3" /> Location Audited
            </span>
            <span className="flex items-center gap-1 text-emerald-400">
              <CheckCircle2 className="w-3 h-3" /> Wallet Owned
            </span>
            <span className="flex items-center gap-1 text-emerald-400">
              <CheckCircle2 className="w-3 h-3" /> Export Docs Signed
            </span>
          </div>
        </div>
      </div>

      {/* CTA Button */}
      <div className="pt-3 border-t border-zinc-800 flex items-center justify-between font-mono text-xs">
        <span className="text-[11px] text-zinc-500">MID: {supplier.digitalIdentity.merchantId}</span>
        <button className="bg-zinc-800 hover:bg-zinc-700 text-amber-400 text-xs font-bold px-3 py-1.5 rounded transition-colors flex items-center gap-1">
          <span>FACTORY PROFILE</span>
          <ExternalLink className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
