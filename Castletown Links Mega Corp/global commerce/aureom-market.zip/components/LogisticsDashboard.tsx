'use client';

import React from 'react';
import { useMarket } from '@/lib/store/market-context';
import {
  Truck,
  Anchor,
  CheckCircle2,
  Clock,
  MapPin,
  ShieldCheck,
  Globe,
  FileCheck,
  ChevronRight,
  Navigation,
} from 'lucide-react';

export const LogisticsDashboard = () => {
  const { shipments } = useMarket();

  return (
    <div className="space-y-8 font-mono">
      {/* Header Banner */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-amber-400 uppercase tracking-widest">
            <Truck className="w-4 h-4 text-amber-400" />
            GLOBAL FREIGHT & CONTAINER TELEMETRY
          </div>
          <h2 className="text-xl font-black text-zinc-100 uppercase tracking-tight mt-0.5">
            CRYPTOGRAPHIC BILL OF LADING & CONTAINER TRACKING
          </h2>
        </div>
        <div className="flex items-center gap-2 bg-zinc-950 px-3 py-1.5 rounded border border-zinc-800 text-xs text-zinc-400">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>MARITIME AIS TELEMETRY SYNCED</span>
        </div>
      </div>

      {/* Shipment Cards */}
      <div className="space-y-6">
        {shipments.map((shp) => (
          <div
            key={shp.id}
            className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 shadow-2xl space-y-6"
          >
            {/* Top Shipment Meta */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-zinc-800 pb-4">
              <div>
                <div className="flex items-center gap-2 text-xs font-bold text-amber-400">
                  <span>CARRIER: {shp.carrier}</span>
                  <span className="text-zinc-600">|</span>
                  <span>CONTAINER #{shp.containerId}</span>
                </div>
                <h3 className="text-lg font-bold text-zinc-100 uppercase mt-0.5">
                  ORDER #{shp.orderId}
                </h3>
              </div>

              <div className="text-right">
                <span className="text-[10px] text-zinc-500 uppercase">ESTIMATED PORT ARRIVAL</span>
                <div className="text-sm font-bold text-emerald-400">{shp.estimatedArrivalDate}</div>
              </div>
            </div>

            {/* Bill of Lading Cryptographic Hash Bar */}
            <div className="bg-zinc-950 p-3.5 rounded-xl border border-zinc-800 flex items-center justify-between gap-4 text-xs">
              <div className="flex items-center gap-2 min-w-0">
                <FileCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span className="text-zinc-400 uppercase font-bold shrink-0">BILL OF LADING HASH:</span>
                <span className="text-zinc-300 font-mono text-[11px] truncate">{shp.billOfLadingHash}</span>
              </div>
              <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold px-2 py-0.5 rounded shrink-0 uppercase">
                VERIFIED ON-CHAIN
              </span>
            </div>

            {/* Maritime Route Visual Bar */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-zinc-950/60 p-4 rounded-xl border border-zinc-800 text-xs">
              {/* Origin Port */}
              <div className="space-y-1">
                <div className="text-[10px] text-zinc-500 uppercase font-bold flex items-center gap-1">
                  <Anchor className="w-3.5 h-3.5 text-blue-400" /> DEPARTURE PORT
                </div>
                <div className="font-bold text-zinc-100">{shp.originPort}</div>
                <div className="text-[10px] text-zinc-500">DEPARTED: {shp.departureDate}</div>
              </div>

              {/* Current Location */}
              <div className="space-y-1 bg-zinc-900 p-2.5 rounded border border-amber-500/30">
                <div className="text-[10px] text-amber-400 uppercase font-bold flex items-center gap-1">
                  <Navigation className="w-3.5 h-3.5 animate-spin" /> LIVE LOCATION
                </div>
                <div className="font-bold text-amber-300">{shp.currentLocationName}</div>
                <div className="text-[10px] text-zinc-400">
                  COORDS: {shp.currentCoordinates.join(', ')}
                </div>
              </div>

              {/* Destination Port */}
              <div className="space-y-1 text-right md:text-left">
                <div className="text-[10px] text-zinc-500 uppercase font-bold flex items-center gap-1 md:justify-start justify-end">
                  <MapPin className="w-3.5 h-3.5 text-emerald-400" /> DESTINATION PORT
                </div>
                <div className="font-bold text-zinc-100">{shp.destinationPort}</div>
                <div className="text-[10px] text-zinc-500">EST: {shp.estimatedArrivalDate}</div>
              </div>
            </div>

            {/* Milestones Log */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold uppercase text-zinc-300 tracking-wider">
                CONTAINER & CUSTOMS EVENT AUDIT LOG
              </h4>
              <div className="space-y-2">
                {shp.events.map((ev, idx) => (
                  <div
                    key={idx}
                    className={`p-3 rounded-lg border flex items-center justify-between text-xs ${
                      ev.completed
                        ? 'bg-zinc-950 border-emerald-500/30 text-zinc-200'
                        : 'bg-zinc-950/40 border-zinc-800 text-zinc-500'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      {ev.completed ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                      ) : (
                        <Clock className="w-4 h-4 text-zinc-600 shrink-0" />
                      )}
                      <div>
                        <div className="font-bold">{ev.title}</div>
                        <div className="text-[10px] text-zinc-500">{ev.location}</div>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono text-zinc-400">{ev.timestamp}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
