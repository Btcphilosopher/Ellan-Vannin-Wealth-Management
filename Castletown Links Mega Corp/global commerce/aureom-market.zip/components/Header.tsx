'use client';

import React, { useState } from 'react';
import { useMarket, MainTabType, UserRole } from '@/lib/store/market-context';
import { CurrencyCode } from '@/types';
import {
  Search,
  Globe,
  Wallet,
  Building2,
  PackageCheck,
  Truck,
  FileText,
  Store,
  Compass,
  ArrowRightLeft,
  Moon,
  Sun,
  ShieldCheck,
  Coins,
} from 'lucide-react';

export const Header = () => {
  const {
    activeTab,
    setActiveTab,
    activeRole,
    setActiveRole,
    currency,
    setCurrency,
    walletBalances,
    searchQuery,
    setSearchQuery,
    formatPrice,
    orders,
  } = useMarket();

  const [isDarkMode, setIsDarkMode] = useState(true);

  const activeOrdersCount = orders.filter((o) => o.escrowState !== 'RELEASED').length;

  const toggleTheme = () => {
    setIsDarkMode(!isDarkMode);
    if (isDarkMode) {
      document.documentElement.classList.remove('dark');
    } else {
      document.documentElement.classList.add('dark');
    }
  };

  const navItems: { id: MainTabType; label: string; icon: React.ReactNode; badge?: number }[] = [
    { id: 'MARKETPLACE', label: 'MARKETPLACE', icon: <Store className="w-4 h-4" /> },
    { id: 'DISCOVER', label: 'DISCOVER', icon: <Compass className="w-4 h-4" /> },
    { id: 'SUPPLIERS', label: 'SUPPLIERS', icon: <Building2 className="w-4 h-4" /> },
    { id: 'RFQ', label: 'RFQ', icon: <FileText className="w-4 h-4" /> },
    { id: 'ORDERS', label: 'ORDERS & ESCROW', icon: <PackageCheck className="w-4 h-4" />, badge: activeOrdersCount },
    { id: 'LOGISTICS', label: 'LOGISTICS', icon: <Truck className="w-4 h-4" /> },
    { id: 'FINANCE', label: 'FINANCE', icon: <Wallet className="w-4 h-4" /> },
    { id: 'MERCHANT_OS', label: 'MERCHANT OS', icon: <ShieldCheck className="w-4 h-4" /> },
  ];

  return (
    <header className="sticky top-0 z-40 bg-zinc-950/95 dark:bg-zinc-950/95 border-b border-zinc-800 text-zinc-100 backdrop-blur-md">
      {/* Top Utility Ribbon */}
      <div className="border-b border-zinc-800/80 px-4 py-1.5 text-xs flex flex-wrap items-center justify-between gap-3 bg-zinc-900/60 font-mono text-zinc-400">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5 text-emerald-400 font-medium">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            MARKET 3.0 NETWORK ONLINE
          </span>
          <span className="hidden sm:inline text-zinc-600">|</span>
          <span className="hidden sm:inline text-zinc-400">
            BTC: <strong className="text-amber-400 font-semibold">$64,250</strong>
          </span>
          <span className="hidden sm:inline text-zinc-400">
            USDT: <strong className="text-emerald-400 font-semibold">$1.00</strong>
          </span>
        </div>

        <div className="flex items-center gap-4">
          {/* Role Switcher */}
          <div className="flex items-center gap-1 bg-zinc-900 p-0.5 rounded border border-zinc-800">
            <button
              onClick={() => setActiveRole('BUYER')}
              className={`px-2 py-0.5 rounded text-[11px] font-semibold transition-colors ${
                activeRole === 'BUYER'
                  ? 'bg-zinc-800 text-zinc-100 border border-zinc-700'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              Buyer Mode
            </button>
            <button
              onClick={() => {
                setActiveRole('SUPPLIER');
                setActiveTab('MERCHANT_OS');
              }}
              className={`px-2 py-0.5 rounded text-[11px] font-semibold transition-colors ${
                activeRole === 'SUPPLIER'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              Merchant OS
            </button>
          </div>

          {/* Currency Display Selector */}
          <div className="flex items-center gap-1.5">
            <Coins className="w-3.5 h-3.5 text-zinc-400" />
            <select
              value={currency}
              onChange={(e) => setCurrency(e.target.value as CurrencyCode)}
              className="bg-zinc-900 border border-zinc-800 text-zinc-200 text-xs rounded px-2 py-0.5 focus:outline-none focus:border-zinc-600 font-mono cursor-pointer"
            >
              <option value="USD">USD ($)</option>
              <option value="BTC">BTC (₿)</option>
              <option value="USDT">USDT (₮)</option>
              <option value="EUR">EUR (€)</option>
              <option value="GBP">GBP (£)</option>
            </select>
          </div>

          {/* Theme Switcher */}
          <button
            onClick={toggleTheme}
            className="p-1 rounded text-zinc-400 hover:text-zinc-100 hover:bg-zinc-900 transition-colors"
            title="Toggle Theme"
          >
            {isDarkMode ? <Sun className="w-3.5 h-3.5 text-amber-400" /> : <Moon className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Main Brand & Search Bar */}
      <div className="max-w-7xl mx-auto px-4 py-3.5 flex items-center justify-between gap-4">
        {/* Brand */}
        <div
          onClick={() => setActiveTab('MARKETPLACE')}
          className="cursor-pointer group flex items-center gap-3 shrink-0"
        >
          <div className="w-10 h-10 rounded bg-gradient-to-br from-zinc-100 via-zinc-200 to-zinc-400 text-zinc-950 flex items-center justify-center font-black tracking-tighter text-xl shadow-lg border border-zinc-300 group-hover:scale-105 transition-transform">
            AM
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-black tracking-wider text-zinc-100 font-mono uppercase">
                AUREOM MARKET
              </h1>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-zinc-800 text-amber-400 border border-amber-500/30">
                MARKET 3.0
              </span>
            </div>
            <p className="text-[10px] font-mono tracking-widest text-zinc-400 uppercase">
              GLOBAL COMMERCE. NATIVE MONEY.
            </p>
          </div>
        </div>

        {/* Global Search Bar */}
        <div className="flex-1 max-w-2xl relative">
          <div className="relative flex items-center">
            <Search className="w-4 h-4 text-zinc-400 absolute left-3.5 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                if (activeTab !== 'MARKETPLACE') {
                  setActiveTab('MARKETPLACE');
                }
              }}
              placeholder="Search products, factories, materials, machinery, SKUs, or specs..."
              className="w-full bg-zinc-900/90 border border-zinc-800 focus:border-amber-500/70 text-zinc-100 placeholder-zinc-500 text-sm rounded-lg pl-10 pr-24 py-2 focus:outline-none focus:ring-1 focus:ring-amber-500/50 transition-all font-mono"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-20 text-xs text-zinc-400 hover:text-zinc-100 font-mono px-1"
              >
                Clear
              </button>
            )}
            <button
              onClick={() => setActiveTab('MARKETPLACE')}
              className="absolute right-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-mono text-xs px-3 py-1 rounded transition-colors"
            >
              Search
            </button>
          </div>
        </div>

        {/* Wallet & Account Widget */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => setActiveTab('FINANCE')}
            className="flex items-center gap-2 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 hover:border-zinc-700 rounded-lg px-3 py-1.5 transition-all text-xs font-mono group"
          >
            <div className="w-7 h-7 rounded bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center">
              <Wallet className="w-3.5 h-3.5" />
            </div>
            <div className="text-left hidden md:block">
              <div className="text-[10px] text-zinc-400 uppercase tracking-wider">
                MARKET WALLET
              </div>
              <div className="text-zinc-100 font-semibold group-hover:text-amber-400 transition-colors">
                {formatPrice(walletBalances.fiatUSD)}
              </div>
            </div>
          </button>
        </div>
      </div>

      {/* Navigation Bar */}
      <nav className="border-t border-zinc-800/80 px-4 bg-zinc-950">
        <div className="max-w-7xl mx-auto flex items-center gap-1 overflow-x-auto no-scrollbar">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center gap-2 px-4 py-2.5 text-xs font-mono font-semibold tracking-wider transition-all border-b-2 whitespace-nowrap ${
                  isActive
                    ? 'border-amber-400 text-amber-400 bg-amber-500/5'
                    : 'border-transparent text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/50'
                }`}
              >
                {item.icon}
                <span>{item.label}</span>
                {item.badge !== undefined && item.badge > 0 && (
                  <span className="bg-amber-500 text-zinc-950 font-black text-[10px] px-1.5 py-0.2 rounded-full">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </nav>
    </header>
  );
};
