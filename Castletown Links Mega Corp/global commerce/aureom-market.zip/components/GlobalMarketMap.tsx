'use client';

import React, { useState } from 'react';
import { GLOBAL_REGIONS } from '@/lib/data/regions';
import { GlobalRegion } from '@/types';
import { useMarket } from '@/lib/store/market-context';
import { Globe, MapPin, Factory, Package, FileText, Anchor, ArrowRight, X } from 'lucide-react';

export const GlobalMarketMap = () => {
  const { setSelectedRegionId, setActiveTab } = useMarket();
  const [activeRegion, setActiveRegion] = useState<GlobalRegion | null>(GLOBAL_REGIONS[0]);

  const handleExplore = (regionId: string) => {
    setSelectedRegionId(regionId);
    setActiveTab('MARKETPLACE');
  };

  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6 shadow-2xl relative overflow-hidden">
      {/* Background Subtle Grid Pattern */}
      <div className="absolute inset-0 bg-[radial-gradient(#27272a_1px,transparent_1px)] [background-size:16px_16px] opacity-40 pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 relative z-10 border-b border-zinc-800 pb-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-amber-400 font-semibold uppercase tracking-wider">
            <Globe className="w-4 h-4 text-amber-400" />
            GLOBAL COMMERCE VISUALIZATION
          </div>
          <h2 className="text-xl font-black font-mono tracking-tight text-zinc-100 uppercase mt-0.5">
            WORLD TRADE CORRIDORS & MANUFACTURING HUBS
          </h2>
        </div>
        <p className="text-xs text-zinc-400 font-mono max-w-md">
          Real-time trade telemetry across 12 primary manufacturing corridors and maritime port hubs. Select a region to inspect supplier density and RFQ volume.
        </p>
      </div>

      {/* Interactive World Map Canvas Container */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 relative z-10">
        {/* Map Area */}
        <div className="lg:col-span-2 bg-zinc-950 border border-zinc-800 rounded-lg p-4 min-h-[380px] relative flex flex-col justify-between overflow-hidden">
          {/* World Map Stylized SVG Vector Overlay */}
          <div className="absolute inset-0 opacity-20 bg-[url('https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1200&q=80')] bg-cover bg-center grayscale mix-blend-luminosity" />

          {/* Trade Route Animated Corridors */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none stroke-zinc-700/60 stroke-[1.5] stroke-dasharray-[4_4]">
            {/* Route lines connecting hubs */}
            <path d="M 78% 48% Q 65% 50% 50% 32%" className="animate-pulse stroke-amber-500/40" />
            <path d="M 78% 48% Q 50% 35% 24% 34%" className="stroke-blue-500/40" />
            <path d="M 50% 32% Q 35% 30% 24% 34%" className="stroke-emerald-500/40" />
            <path d="M 78% 48% Q 68% 50% 58% 46%" className="stroke-amber-400/30" />
          </svg>

          {/* Region Pins */}
          <div className="relative w-full h-[320px] my-auto">
            {GLOBAL_REGIONS.map((region) => {
              const isSelected = activeRegion?.id === region.id;
              return (
                <button
                  key={region.id}
                  onClick={() => setActiveRegion(region)}
                  style={{
                    left: `${region.coordinates[0]}%`,
                    top: `${region.coordinates[1]}%`,
                  }}
                  className={`absolute -translate-x-1/2 -translate-y-1/2 group transition-all duration-300 z-20 ${
                    isSelected ? 'scale-125 z-30' : 'hover:scale-110'
                  }`}
                >
                  <div className="relative flex items-center justify-center">
                    <span
                      className={`w-3 h-3 rounded-full ${
                        isSelected
                          ? 'bg-amber-400 ring-4 ring-amber-500/30 animate-ping'
                          : 'bg-zinc-400 group-hover:bg-amber-400'
                      }`}
                    />
                    <span
                      className={`absolute w-3.5 h-3.5 rounded-full ${
                        isSelected ? 'bg-amber-400' : 'bg-zinc-300 group-hover:bg-amber-400'
                      }`}
                    />
                    {/* Tooltip badge */}
                    <div
                      className={`absolute top-full mt-1.5 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded text-[10px] font-mono font-bold whitespace-nowrap shadow-lg border transition-all ${
                        isSelected
                          ? 'bg-amber-400 text-zinc-950 border-amber-300'
                          : 'bg-zinc-900/90 text-zinc-300 border-zinc-700 opacity-80 group-hover:opacity-100'
                      }`}
                    >
                      {region.code}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Legend */}
          <div className="flex items-center justify-between text-[11px] font-mono text-zinc-400 border-t border-zinc-800/80 pt-2 z-10">
            <span className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
              Active Manufacturing Hub
            </span>
            <span>Click Pin to Inspect Regional Supply Chain</span>
          </div>
        </div>

        {/* Region Details Panel */}
        {activeRegion ? (
          <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-5 flex flex-col justify-between font-mono">
            <div>
              <div className="flex items-center justify-between gap-2 border-b border-zinc-800 pb-3">
                <div>
                  <span className="text-[10px] font-bold text-amber-400 uppercase tracking-widest">
                    REGION CODE: {activeRegion.code}
                  </span>
                  <h3 className="text-lg font-black text-zinc-100 uppercase mt-0.5">
                    {activeRegion.name}
                  </h3>
                </div>
                <button
                  onClick={() => setActiveRegion(null)}
                  className="text-zinc-500 hover:text-zinc-200 p-1"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Core Metrics Grid */}
              <div className="grid grid-cols-3 gap-2 my-4">
                <div className="bg-zinc-900/80 p-2.5 rounded border border-zinc-800 text-center">
                  <div className="flex items-center justify-center gap-1 text-[10px] text-zinc-400 uppercase mb-1">
                    <Factory className="w-3 h-3 text-amber-400" />
                    SUPPLIERS
                  </div>
                  <div className="text-sm font-black text-zinc-100">
                    {activeRegion.supplierCount}
                  </div>
                </div>

                <div className="bg-zinc-900/80 p-2.5 rounded border border-zinc-800 text-center">
                  <div className="flex items-center justify-center gap-1 text-[10px] text-zinc-400 uppercase mb-1">
                    <Package className="w-3 h-3 text-emerald-400" />
                    PRODUCTS
                  </div>
                  <div className="text-sm font-black text-zinc-100">
                    {activeRegion.productCount}
                  </div>
                </div>

                <div className="bg-zinc-900/80 p-2.5 rounded border border-zinc-800 text-center">
                  <div className="flex items-center justify-center gap-1 text-[10px] text-zinc-400 uppercase mb-1">
                    <FileText className="w-3 h-3 text-blue-400" />
                    RFQS
                  </div>
                  <div className="text-sm font-black text-zinc-100">
                    {activeRegion.activeRfqsCount}
                  </div>
                </div>
              </div>

              {/* Primary Exports */}
              <div className="space-y-3 text-xs">
                <div>
                  <h4 className="text-[10px] uppercase font-bold text-zinc-400 tracking-wider mb-1.5">
                    PRIMARY EXPORT INDUSTRIES:
                  </h4>
                  <div className="flex flex-wrap gap-1.5">
                    {activeRegion.primaryExports.map((exp, idx) => (
                      <span
                        key={idx}
                        className="bg-zinc-900 text-zinc-300 border border-zinc-800 px-2 py-0.5 rounded text-[11px]"
                      >
                        {exp}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Major Ports */}
                <div>
                  <h4 className="text-[10px] uppercase font-bold text-zinc-400 tracking-wider mb-1.5 flex items-center gap-1">
                    <Anchor className="w-3 h-3 text-blue-400" />
                    MAJOR CONTAINER PORTS:
                  </h4>
                  <ul className="text-zinc-300 text-xs space-y-1 pl-1">
                    {activeRegion.majorPorts.map((port, idx) => (
                      <li key={idx} className="flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-blue-400 shrink-0" />
                        {port}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>

            {/* Action CTA */}
            <div className="pt-4 border-t border-zinc-800 mt-4">
              <button
                onClick={() => handleExplore(activeRegion.id)}
                className="w-full bg-amber-400 hover:bg-amber-300 text-zinc-950 font-bold py-2.5 px-4 rounded font-mono text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-lg"
              >
                <span>EXPLORE {activeRegion.name.toUpperCase()} PRODUCTS</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        ) : (
          <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-5 flex items-center justify-center text-center text-zinc-500 font-mono text-xs">
            Select a region pin on the trade map to inspect regional industrial capabilities.
          </div>
        )}
      </div>
    </div>
  );
};
