'use client';

import React, { useState } from 'react';
import { useMarket } from '@/lib/store/market-context';
import {
  ShieldCheck,
  Building2,
  Lock,
  Plus,
  Coins,
  DollarSign,
  TrendingUp,
  Package,
  Award,
  CheckCircle2,
  Users,
  Layers,
  Settings,
} from 'lucide-react';

export const MerchantOS = () => {
  const { products, suppliers, orders, formatPrice, activeRole } = useMarket();

  const mySupplier = suppliers[0]; // Shenzhen Precision Systems
  const myProducts = products.filter((p) => p.supplierId === mySupplier.id);

  const [showAddProductModal, setShowAddProductModal] = useState(false);

  // Form state
  const [newProdName, setNewProdName] = useState('');
  const [newProdCategory, setNewProdCategory] = useState<any>('Electronics');
  const [newProdPrice, setNewProdPrice] = useState(15.00);
  const [newProdMoq, setNewProdMoq] = useState(100);
  const [newProdLeadDays, setNewProdLeadDays] = useState(14);

  return (
    <div className="space-y-8 font-mono">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-zinc-950 via-zinc-900 to-zinc-950 border border-zinc-800 rounded-2xl p-6 shadow-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <img
            src={mySupplier.logo}
            alt=""
            className="w-14 h-14 rounded-xl object-cover border border-zinc-700"
          />
          <div>
            <div className="flex items-center gap-2">
              <span className="bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-bold px-2 py-0.5 rounded flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                VERIFIED MERCHANT OS 3.0
              </span>
              <span className="text-xs text-zinc-400">MID: {mySupplier.digitalIdentity.merchantId}</span>
            </div>
            <h2 className="text-xl font-black text-zinc-100 uppercase tracking-tight mt-1">
              {mySupplier.name}
            </h2>
          </div>
        </div>

        <button
          onClick={() => setShowAddProductModal(!showAddProductModal)}
          className="bg-amber-400 hover:bg-amber-300 text-zinc-950 font-black px-5 py-2.5 rounded-lg text-xs uppercase tracking-wider flex items-center gap-2 shadow-lg transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>LIST NEW PRODUCT</span>
        </button>
      </div>

      {/* GMV & Crypto Revenue Analytics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-zinc-900 p-5 rounded-xl border border-zinc-800 space-y-1">
          <div className="text-[10px] text-zinc-500 uppercase font-bold flex items-center gap-1">
            <TrendingUp className="w-3.5 h-3.5 text-amber-400" /> TOTAL MERCHANDISE VOLUME (GMV)
          </div>
          <div className="text-2xl font-black text-zinc-100">$284,500.00</div>
          <div className="text-[10px] text-emerald-400 font-bold">+18.4% vs last month</div>
        </div>

        <div className="bg-zinc-900 p-5 rounded-xl border border-zinc-800 space-y-1">
          <div className="text-[10px] text-zinc-500 uppercase font-bold flex items-center gap-1">
            <Lock className="w-3.5 h-3.5 text-amber-400" /> ACTIVE PROGRAMMABLE ESCROW
          </div>
          <div className="text-2xl font-black text-amber-400">$41,430.00</div>
          <div className="text-[10px] text-zinc-400 font-mono">Locked across 3 active orders</div>
        </div>

        <div className="bg-zinc-900 p-5 rounded-xl border border-zinc-800 space-y-1">
          <div className="text-[10px] text-zinc-500 uppercase font-bold flex items-center gap-1">
            <Coins className="w-3.5 h-3.5 text-emerald-400" /> BITCOIN & USDT SETTLED
          </div>
          <div className="text-2xl font-black text-emerald-400">2.84 BTC / 128.4K ₮</div>
          <div className="text-[10px] text-zinc-400">Instant multi-sig wallet payout</div>
        </div>

        <div className="bg-zinc-900 p-5 rounded-xl border border-zinc-800 space-y-1">
          <div className="text-[10px] text-zinc-500 uppercase font-bold flex items-center gap-1">
            <Award className="w-3.5 h-3.5 text-blue-400" /> REPUTATION SCORE
          </div>
          <div className="text-2xl font-black text-zinc-100">99.4 / 100</div>
          <div className="text-[10px] text-emerald-400 font-bold">0.00% Dispute Rate</div>
        </div>
      </div>

      {/* Digital Merchant Identity & Attestation Certificate */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
          <h3 className="font-bold text-sm text-zinc-100 uppercase tracking-wider flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            MERCHANT CRYPTOGRAPHIC ATTESTATION CERTIFICATES
          </h3>
          <span className="text-xs text-emerald-400 font-bold">ALL ATTESTATIONS ACTIVE</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="bg-zinc-950 p-4 rounded-xl border border-zinc-800 space-y-2">
            <div className="text-[10px] text-zinc-500 uppercase font-bold">SETTLEMENT WALLET ADDRESS</div>
            <div className="font-mono text-amber-400 truncate bg-zinc-900 p-2 rounded border border-zinc-800">
              {mySupplier.digitalIdentity.btcSettlementAddress}
            </div>
          </div>

          <div className="bg-zinc-950 p-4 rounded-xl border border-zinc-800 space-y-2">
            <div className="text-[10px] text-zinc-500 uppercase font-bold">PUBLIC KEY ATTESTATION</div>
            <div className="font-mono text-zinc-300 truncate bg-zinc-900 p-2 rounded border border-zinc-800">
              {mySupplier.digitalIdentity.cryptographicPublicKey}
            </div>
          </div>

          <div className="bg-zinc-950 p-4 rounded-xl border border-zinc-800 space-y-2">
            <div className="text-[10px] text-zinc-500 uppercase font-bold">FACTORY AUDIT CERTIFICATE</div>
            <div className="font-mono text-emerald-400 truncate bg-zinc-900 p-2 rounded border border-zinc-800">
              {mySupplier.digitalIdentity.verifiedCertificates[0]?.hash || '0x94827104928174129481'}
            </div>
          </div>
        </div>
      </div>

      {/* Catalog Manager */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
          <h3 className="font-bold text-sm text-zinc-100 uppercase tracking-wider flex items-center gap-2">
            <Package className="w-4 h-4 text-amber-400" />
            MERCHANT CATALOG MANAGER ({myProducts.length})
          </h3>
        </div>

        <div className="space-y-3">
          {myProducts.map((p) => (
            <div
              key={p.id}
              className="bg-zinc-950 p-4 rounded-xl border border-zinc-800 flex flex-col md:flex-row md:items-center justify-between gap-4 text-xs"
            >
              <div className="flex items-center gap-3">
                <img
                  src={p.images[0]}
                  alt=""
                  className="w-12 h-12 rounded object-cover border border-zinc-800 shrink-0"
                />
                <div>
                  <div className="text-[10px] text-amber-400 font-bold">{p.sku}</div>
                  <h4 className="font-bold text-zinc-100 text-sm">{p.name}</h4>
                  <div className="text-[11px] text-zinc-500 mt-0.5">
                    MOQ: {p.moq} • Lead Time: {p.leadTimeDays} days
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="text-right">
                  <div className="text-[10px] text-zinc-500 uppercase">BASE PRICE</div>
                  <div className="text-sm font-bold text-emerald-400">${p.basePriceUSD.toFixed(2)}</div>
                </div>

                <button className="bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-zinc-700 px-3 py-1.5 rounded text-xs font-bold uppercase">
                  EDIT PRICING TIERS
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
