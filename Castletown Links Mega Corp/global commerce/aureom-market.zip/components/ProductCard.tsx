'use client';

import React from 'react';
import { Product } from '@/types';
import { useMarket } from '@/lib/store/market-context';
import {
  ShieldCheck,
  Star,
  MapPin,
  Clock,
  Package,
  CheckCircle2,
  ChevronRight,
  Boxes,
} from 'lucide-react';

interface ProductCardProps {
  product: Product;
}

export const ProductCard = ({ product }: ProductCardProps) => {
  const { setSelectedProduct, setCheckoutItem, formatPrice, currency } = useMarket();

  const lowestTier = product.priceTiers[product.priceTiers.length - 1];
  const highestTier = product.priceTiers[0];

  const handleQuickCheckout = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCheckoutItem({
      product,
      quantity: product.moq,
      customizations: {},
    });
  };

  return (
    <div
      onClick={() => setSelectedProduct(product)}
      className="group bg-zinc-900/90 hover:bg-zinc-900 border border-zinc-800 hover:border-amber-500/50 rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 flex flex-col justify-between cursor-pointer relative"
    >
      {/* Upper Media & Badges */}
      <div>
        <div className="relative aspect-[4/3] bg-zinc-950 overflow-hidden">
          <img
            src={product.images[0]}
            alt={product.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-90 group-hover:opacity-100"
          />

          {/* Verification Badge */}
          {product.isVerified && (
            <div className="absolute top-2.5 left-2.5 bg-zinc-950/90 backdrop-blur-md border border-emerald-500/40 text-emerald-400 text-[10px] font-mono font-bold px-2 py-0.5 rounded flex items-center gap-1 shadow-md">
              <ShieldCheck className="w-3 h-3 text-emerald-400" />
              VERIFIED FACTORY
            </div>
          )}

          {/* Ready to Ship Badge */}
          {product.readyToShip && (
            <div className="absolute top-2.5 right-2.5 bg-zinc-950/90 backdrop-blur-md border border-amber-500/40 text-amber-300 text-[10px] font-mono font-semibold px-2 py-0.5 rounded shadow-md">
              READY TO SHIP
            </div>
          )}

          {/* Accepted Crypto Rails Pill Overlay */}
          <div className="absolute bottom-2 left-2.5 flex items-center gap-1 font-mono text-[10px]">
            {product.acceptedRails.includes('BITCOIN') && (
              <span className="bg-amber-500/20 text-amber-300 border border-amber-500/40 px-1.5 py-0.2 rounded">
                ₿ BTC
              </span>
            )}
            {product.acceptedRails.includes('USDT') && (
              <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-1.5 py-0.2 rounded">
                ₮ USDT
              </span>
            )}
            <span className="bg-zinc-800/90 text-zinc-300 border border-zinc-700 px-1.5 py-0.2 rounded">
              FIAT
            </span>
          </div>
        </div>

        {/* Content Details */}
        <div className="p-4 space-y-2.5">
          {/* Supplier Info line */}
          <div className="flex items-center justify-between gap-2 text-xs font-mono text-zinc-400">
            <span className="truncate hover:text-zinc-200 transition-colors">
              {product.supplierName}
            </span>
            <div className="flex items-center gap-1 text-amber-400 shrink-0">
              <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
              <span className="font-bold text-[11px]">{product.supplierRating}</span>
            </div>
          </div>

          {/* Title */}
          <h3 className="font-mono text-sm font-bold text-zinc-100 group-hover:text-amber-400 transition-colors line-clamp-2 leading-snug">
            {product.name}
          </h3>

          {/* Location & Lead time */}
          <div className="flex items-center gap-3 text-[11px] font-mono text-zinc-400 pt-0.5">
            <span className="flex items-center gap-1 truncate">
              <MapPin className="w-3 h-3 text-zinc-500 shrink-0" />
              {product.supplierLocation}
            </span>
            <span>•</span>
            <span className="flex items-center gap-1 shrink-0">
              <Clock className="w-3 h-3 text-zinc-500 shrink-0" />
              {product.leadTimeDays}d Lead
            </span>
          </div>

          {/* Price Range Tiers */}
          <div className="pt-2 border-t border-zinc-800/80">
            <div className="text-[10px] font-mono uppercase text-zinc-500">INDICATIVE VOLUME PRICE</div>
            <div className="flex items-baseline gap-1.5 mt-0.5">
              <span className="font-mono font-black text-base text-zinc-100 tracking-tight">
                {formatPrice(lowestTier.pricePerUnit)}
              </span>
              <span className="text-xs text-zinc-400 font-mono">
                – {formatPrice(highestTier.pricePerUnit)}
              </span>
              <span className="text-[10px] text-zinc-500 font-mono ml-auto">/ unit</span>
            </div>
          </div>
        </div>
      </div>

      {/* Footer Meta & Quick Action */}
      <div className="px-4 pb-4 pt-2 border-t border-zinc-800/60 bg-zinc-950/40 flex items-center justify-between gap-2 font-mono text-xs">
        <div className="text-[11px] text-zinc-400 flex items-center gap-1">
          <Boxes className="w-3.5 h-3.5 text-zinc-500" />
          <span>MOQ: <strong className="text-zinc-200">{product.moq}</strong> units</span>
        </div>

        <button
          onClick={handleQuickCheckout}
          className="bg-zinc-800 hover:bg-amber-400 hover:text-zinc-950 text-zinc-200 text-xs font-bold px-3 py-1.5 rounded transition-all flex items-center gap-1 shadow"
        >
          <span>ORDER</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
