export type CategoryType =
  | 'Electronics'
  | 'Machinery'
  | 'Industrial Equipment'
  | 'Construction'
  | 'Energy'
  | 'Automotive'
  | 'Textiles'
  | 'Furniture'
  | 'Chemicals'
  | 'Semiconductors'
  | 'Agriculture'
  | 'Packaging'
  | 'Consumer Goods'
  | 'Software'
  | 'Components'
  | 'Luxury Goods';

export type SupplierType = 'VERIFIED_FACTORY' | 'TRADING_COMPANY' | 'OEM_ODM_MANUFACTURER';

export type PaymentRail = 'BITCOIN' | 'LIGHTNING' | 'USDT' | 'FIAT' | 'BANK_TRANSFER';

export type StablecoinNetwork = 'TRC20' | 'ERC20' | 'SOLANA' | 'TON' | 'POLYGON';

export type CurrencyCode = 'USD' | 'EUR' | 'GBP' | 'BTC' | 'USDT';

export interface PriceTier {
  minQuantity: number;
  maxQuantity?: number;
  pricePerUnit: number;
}

export interface TechnicalSpec {
  key: string;
  value: string;
}

export interface CustomizationOption {
  id: string;
  label: string;
  type: 'select' | 'text' | 'checkbox';
  options?: string[];
  unitCostAdder?: number;
}

export interface Product {
  id: string;
  sku: string;
  name: string;
  category: CategoryType;
  supplierId: string;
  supplierName: string;
  supplierLocation: string;
  supplierRating: number;
  supplierType: SupplierType;
  isVerified: boolean;
  yearsInMarket: number;
  description: string;
  images: string[];
  specs: TechnicalSpec[];
  moq: number;
  priceTiers: PriceTier[];
  basePriceUSD: number;
  leadTimeDays: number;
  shippingEstimateDays: number;
  acceptedRails: PaymentRail[];
  certifications: string[];
  customizationAvailable: boolean;
  customizationOptions?: CustomizationOption[];
  readyToShip: boolean;
  originCountry: string;
  stockUnits: number;
  has3dModel?: boolean;
}

export interface DigitalIdentity {
  merchantId: string;
  legalEntityName: string;
  taxRegistrationNumber: string;
  companyRegistrationCountry: string;
  factoryAddress: string;
  cryptographicPublicKey: string;
  btcSettlementAddress: string;
  usdtAddresses: Record<StablecoinNetwork, string>;
  verifiedCertificates: {
    title: string;
    issuer: string;
    issuedDate: string;
    hash: string;
    verified: boolean;
  }[];
  verifications: {
    companyIdentity: boolean;
    manufacturingLocation: boolean;
    exportDocumentation: boolean;
    walletOwnership: boolean;
    productCertification: boolean;
  };
}

export interface Supplier {
  id: string;
  name: string;
  logo: string;
  type: SupplierType;
  rating: number;
  reviewsCount: number;
  yearsOnMarket: number;
  location: string;
  city: string;
  country: string;
  employeesCount: string;
  factoryAreaSqM: number;
  annualExportValueUSD: string;
  overview: string;
  machinery: string[];
  exportRegions: string[];
  responseRate: number; // percentage
  responseTimeHours: number;
  onTimeDeliveryRate: number; // percentage
  orderCompletionRate: number; // percentage
  disputeRate: number; // percentage
  repeatBuyerRate: number; // percentage
  digitalIdentity: DigitalIdentity;
  factoryImages: string[];
  primaryCategories: CategoryType[];
}

export type EscrowState =
  | 'CREATED'
  | 'FUNDED'
  | 'PRODUCTION'
  | 'INSPECTION'
  | 'SHIPPED'
  | 'DELIVERED'
  | 'RELEASE_PENDING'
  | 'RELEASED'
  | 'DISPUTED'
  | 'REFUNDED';

export interface TradeContract {
  contractId: string;
  orderId: string;
  buyerName: string;
  sellerName: string;
  productName: string;
  quantity: number;
  totalPriceUSD: number;
  currency: CurrencyCode;
  paymentRail: PaymentRail;
  deliveryDate: string;
  shippingTerms: string; // e.g. Incoterms FOB Shenzhen
  inspectionTerms: string;
  escrowConditions: string;
  documentHashSHA256: string;
  buyerSignature?: {
    signedBy: string;
    timestamp: string;
    signatureHash: string;
  };
  sellerSignature?: {
    signedBy: string;
    timestamp: string;
    signatureHash: string;
  };
}

export interface OrderItem {
  productId: string;
  productName: string;
  sku: string;
  image: string;
  quantity: number;
  unitPriceUSD: number;
  selectedCustomizations?: Record<string, string>;
}

export interface Order {
  id: string;
  buyerId: string;
  buyerName: string;
  sellerId: string;
  sellerName: string;
  items: OrderItem[];
  subtotalUSD: number;
  shippingUSD: number;
  totalUSD: number;
  paymentRail: PaymentRail;
  paymentNetwork?: StablecoinNetwork;
  quotedAmountCrypto?: string;
  quotedCryptoCurrency?: 'BTC' | 'USDT';
  exchangeRateAtLock?: number;
  paymentAddress?: string;
  paymentTxHash?: string;
  paymentStatus: 'UNPAID' | 'DETECTED' | 'CONFIRMED' | 'FAILED';
  escrowState: EscrowState;
  createdAt: string;
  estimatedDeliveryDate: string;
  contract?: TradeContract;
  shipmentId?: string;
  milestones: {
    stage: EscrowState;
    label: string;
    timestamp?: string;
    completed: boolean;
  }[];
}

export interface RFQ {
  id: string;
  buyerId: string;
  buyerName: string;
  buyerCountry: string;
  productTitle: string;
  category: CategoryType;
  quantity: number;
  targetPricePerUnitUSD: number;
  targetDeliveryDays: number;
  destinationCityCountry: string;
  specifications: string;
  paymentPreference: PaymentRail[];
  createdAt: string;
  status: 'OPEN' | 'IN_NEGOTIATION' | 'CLOSED';
  quotesCount: number;
}

export interface Quote {
  id: string;
  rfqId: string;
  supplierId: string;
  supplierName: string;
  supplierLocation: string;
  supplierRating: number;
  unitPriceUSD: number;
  moq: number;
  leadTimeDays: number;
  toolingCostUSD: number;
  shippingCostUSD: number;
  paymentTerms: string;
  warrantyMonths: number;
  certificationsProvided: string[];
  notes: string;
  createdAt: string;
  status: 'SUBMITTED' | 'ACCEPTED' | 'COUNTERED' | 'REJECTED';
}

export interface StructuredOffer {
  quantity: number;
  unitPriceUSD: number;
  leadTimeDays: number;
  shippingCostUSD: number;
  paymentTerms: string;
}

export interface NegotiationMessage {
  id: string;
  threadId: string;
  senderId: string;
  senderName: string;
  senderRole: 'BUYER' | 'SUPPLIER';
  timestamp: string;
  text: string;
  structuredOffer?: StructuredOffer;
  status?: 'PENDING' | 'ACCEPTED' | 'COUNTERED' | 'REJECTED';
}

export interface Shipment {
  id: string;
  orderId: string;
  carrier: string;
  containerId: string;
  billOfLadingHash: string;
  originPort: string;
  destinationPort: string;
  currentLocationName: string;
  currentCoordinates: [number, number]; // [lat, lng]
  originCoordinates: [number, number];
  destinationCoordinates: [number, number];
  departureDate: string;
  estimatedArrivalDate: string;
  status: 'CONTAINER_BOOKED' | 'PORT_LOADING' | 'IN_TRANSIT' | 'CUSTOMS_CLEARANCE' | 'DELIVERED';
  events: {
    title: string;
    location: string;
    timestamp: string;
    completed: boolean;
  }[];
}

export interface WalletTransaction {
  id: string;
  type: 'DEPOSIT' | 'WITHDRAWAL' | 'ESCROW_LOCK' | 'ESCROW_RELEASE' | 'PAYMENT_SENT' | 'PAYMENT_RECEIVED';
  asset: 'BTC' | 'USDT' | 'USD' | 'EUR' | 'GBP';
  network?: StablecoinNetwork | 'BITCOIN_ONCHAIN' | 'LIGHTNING';
  amount: number;
  amountUSD: number;
  txHash?: string;
  timestamp: string;
  counterparty: string;
  status: 'PENDING' | 'CONFIRMED' | 'FAILED';
}

export interface GlobalRegion {
  id: string;
  name: string;
  code: string;
  coordinates: [number, number]; // map position % [x, y]
  supplierCount: string;
  productCount: string;
  activeRfqsCount: string;
  primaryExports: string[];
  majorPorts: string[];
  tradeCorridors: string[];
}
