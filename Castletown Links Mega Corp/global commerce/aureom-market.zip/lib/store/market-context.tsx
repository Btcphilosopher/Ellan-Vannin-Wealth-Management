'use client';

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import {
  Product,
  Supplier,
  Order,
  RFQ,
  Quote,
  Shipment,
  WalletTransaction,
  CurrencyCode,
  EscrowState,
  PaymentRail,
  StablecoinNetwork,
  CategoryType,
  NegotiationMessage,
  StructuredOffer,
} from '@/types';
import { MOCK_PRODUCTS } from '@/lib/data/products';
import { MOCK_SUPPLIERS } from '@/lib/data/suppliers';
import { MOCK_ORDERS } from '@/lib/data/orders';
import { MOCK_RFQS, MOCK_QUOTES } from '@/lib/data/rfqs';
import { MOCK_SHIPMENTS } from '@/lib/data/logistics';
import { INITIAL_WALLET_TRANSACTIONS } from '@/lib/data/wallet';

export type MainTabType =
  | 'MARKETPLACE'
  | 'DISCOVER'
  | 'SUPPLIERS'
  | 'RFQ'
  | 'ORDERS'
  | 'MERCHANT_OS'
  | 'FINANCE'
  | 'LOGISTICS';

export type UserRole = 'BUYER' | 'SUPPLIER';

export interface ToastMessage {
  id: string;
  type: 'success' | 'info' | 'warning' | 'error';
  title: string;
  message: string;
  timestamp: string;
}

export interface NegotiationThread {
  id: string;
  supplierId: string;
  supplierName: string;
  productId?: string;
  productName?: string;
  messages: NegotiationMessage[];
}

interface MarketContextType {
  activeTab: MainTabType;
  setActiveTab: (tab: MainTabType) => void;
  activeRole: UserRole;
  setActiveRole: (role: UserRole) => void;
  currency: CurrencyCode;
  setCurrency: (currency: CurrencyCode) => void;
  
  // Data
  products: Product[];
  suppliers: Supplier[];
  orders: Order[];
  rfqs: RFQ[];
  quotes: Quote[];
  shipments: Shipment[];
  walletTransactions: WalletTransaction[];
  walletBalances: {
    btc: number;
    usdt: number;
    fiatUSD: number;
    fiatEUR: number;
    fiatGBP: number;
  };
  
  // Filters & Search
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  selectedCategory: CategoryType | 'ALL';
  setSelectedCategory: (cat: CategoryType | 'ALL') => void;
  selectedRegionId: string | null;
  setSelectedRegionId: (id: string | null) => void;
  selectedSupplierType: string | 'ALL';
  setSelectedSupplierType: (st: string | 'ALL') => void;
  selectedAcceptedRail: PaymentRail | 'ALL';
  setSelectedAcceptedRail: (rail: PaymentRail | 'ALL') => void;
  
  // Modals & Active Selections
  selectedProduct: Product | null;
  setSelectedProduct: (p: Product | null) => void;
  selectedSupplier: Supplier | null;
  setSelectedSupplier: (s: Supplier | null) => void;
  selectedOrder: Order | null;
  setSelectedOrder: (o: Order | null) => void;
  checkoutItem: {
    product: Product;
    quantity: number;
    customizations: Record<string, string>;
  } | null;
  setCheckoutItem: (item: { product: Product; quantity: number; customizations: Record<string, string> } | null) => void;
  
  // Actions
  createOrderFromCheckout: (
    paymentRail: PaymentRail,
    network?: StablecoinNetwork
  ) => Order;
  advanceEscrowStage: (orderId: string) => void;
  releaseEscrow: (orderId: string) => void;
  raiseDispute: (orderId: string, reason: string) => void;
  publishRFQ: (rfqData: Omit<RFQ, 'id' | 'createdAt' | 'status' | 'quotesCount' | 'buyerId' | 'buyerName'>) => RFQ;
  submitQuote: (quoteData: Omit<Quote, 'id' | 'createdAt' | 'status' | 'supplierRating'>) => void;
  
  // Negotiation Chat
  negotiationThreads: NegotiationThread[];
  activeThreadId: string | null;
  setActiveThreadId: (id: string | null) => void;
  sendNegotiationMessage: (threadId: string, text: string, offer?: StructuredOffer) => void;
  respondToOffer: (threadId: string, messageId: string, action: 'ACCEPTED' | 'REJECTED' | 'COUNTERED') => void;
  
  // Wallet Actions
  depositFunds: (asset: 'BTC' | 'USDT' | 'USD', amount: number, network?: StablecoinNetwork) => void;
  
  // Exchange Rates
  exchangeRates: {
    BTC_USD: number;
    EUR_USD: number;
    GBP_USD: number;
    USDT_USD: number;
  };
  
  // Toasts
  toasts: ToastMessage[];
  addToast: (title: string, message: string, type?: ToastMessage['type']) => void;
  removeToast: (id: string) => void;
  
  // Helpers
  formatPrice: (amountUSD: number, targetCurrency?: CurrencyCode) => string;
}

const MarketContext = createContext<MarketContextType | undefined>(undefined);

export const MarketProvider = ({ children }: { children: ReactNode }) => {
  const [activeTab, setActiveTab] = useState<MainTabType>('MARKETPLACE');
  const [activeRole, setActiveRole] = useState<UserRole>('BUYER');
  const [currency, setCurrency] = useState<CurrencyCode>('USD');
  
  const [products, setProducts] = useState<Product[]>(MOCK_PRODUCTS);
  const [suppliers] = useState<Supplier[]>(MOCK_SUPPLIERS);
  const [orders, setOrders] = useState<Order[]>(MOCK_ORDERS);
  const [rfqs, setRfqs] = useState<RFQ[]>(MOCK_RFQS);
  const [quotes, setQuotes] = useState<Quote[]>(MOCK_QUOTES);
  const [shipments, setShipments] = useState<Shipment[]>(MOCK_SHIPMENTS);
  const [walletTransactions, setWalletTransactions] = useState<WalletTransaction[]>(INITIAL_WALLET_TRANSACTIONS);
  
  const [walletBalances, setWalletBalances] = useState({
    btc: 0.4821,
    usdt: 18420.00,
    fiatUSD: 12840.00,
    fiatEUR: 11200.00,
    fiatGBP: 9500.00,
  });

  const exchangeRates = {
    BTC_USD: 64250.00,
    EUR_USD: 1.08,
    GBP_USD: 1.29,
    USDT_USD: 1.00,
  };

  // Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<CategoryType | 'ALL'>('ALL');
  const [selectedRegionId, setSelectedRegionId] = useState<string | null>(null);
  const [selectedSupplierType, setSelectedSupplierType] = useState<string | 'ALL'>('ALL');
  const [selectedAcceptedRail, setSelectedAcceptedRail] = useState<PaymentRail | 'ALL'>('ALL');

  // Active Modals
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [selectedSupplier, setSelectedSupplier] = useState<Supplier | null>(null);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [checkoutItem, setCheckoutItem] = useState<{
    product: Product;
    quantity: number;
    customizations: Record<string, string>;
  } | null>(null);

  // Negotiation Threads
  const [negotiationThreads, setNegotiationThreads] = useState<NegotiationThread[]>([
    {
      id: 'thread-1',
      supplierId: 'sup-101',
      supplierName: 'Shenzhen Precision Systems Ltd.',
      productId: 'prod-101',
      productName: 'Precision CNC Aluminium Housing (IP65)',
      messages: [
        {
          id: 'm1',
          threadId: 'thread-1',
          senderId: 'usr-buyer',
          senderName: 'AeroTech Systems Ltd.',
          senderRole: 'BUYER',
          timestamp: '2026-09-15 09:12',
          text: 'Hello Shenzhen Precision team. Can you support 10,000 units with custom laser hash engraving on bottom by October 15th?',
        },
        {
          id: 'm2',
          threadId: 'thread-1',
          senderId: 'sup-101',
          senderName: 'Shenzhen Precision Sales Director',
          senderRole: 'SUPPLIER',
          timestamp: '2026-09-15 10:04',
          text: 'Greetings AeroTech team! Yes, we have capacity on our Haas 5-axis lines. Here is our formal structured offer for 10,000 units.',
          structuredOffer: {
            quantity: 10000,
            unitPriceUSD: 4.50,
            leadTimeDays: 28,
            shippingCostUSD: 850.00,
            paymentTerms: '100% Escrow via USDT TRC20 or Bitcoin',
          },
          status: 'PENDING',
        },
      ],
    },
  ]);
  const [activeThreadId, setActiveThreadId] = useState<string | null>('thread-1');

  // Toasts
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = (title: string, message: string, type: ToastMessage['type'] = 'info') => {
    const id = 'toast-' + Math.random().toString(36).substr(2, 9);
    const newToast: ToastMessage = {
      id,
      title,
      message,
      type,
      timestamp: new Date().toLocaleTimeString(),
    };
    setToasts((prev) => [newToast, ...prev].slice(0, 5));
    setTimeout(() => {
      removeToast(id);
    }, 5000);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Helper formatting
  const formatPrice = (amountUSD: number, targetCurrency: CurrencyCode = currency): string => {
    switch (targetCurrency) {
      case 'BTC':
        const btc = amountUSD / exchangeRates.BTC_USD;
        return `₿ ${btc.toFixed(4)} BTC`;
      case 'USDT':
        return `₮ ${amountUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USDT`;
      case 'EUR':
        const eur = amountUSD / exchangeRates.EUR_USD;
        return `€${eur.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
      case 'GBP':
        const gbp = amountUSD / exchangeRates.GBP_USD;
        return `£${gbp.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
      case 'USD':
      default:
        return `$${amountUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    }
  };

  // Order Creation from Checkout
  const createOrderFromCheckout = (
    paymentRail: PaymentRail,
    network: StablecoinNetwork = 'TRC20'
  ): Order => {
    if (!checkoutItem) throw new Error('No checkout item selected');
    
    const { product, quantity, customizations } = checkoutItem;
    // Calculate tier unit price
    let unitPrice = product.basePriceUSD;
    const tier = product.priceTiers.find(
      (t) => quantity >= t.minQuantity && (!t.maxQuantity || quantity <= t.maxQuantity)
    );
    if (tier) {
      unitPrice = tier.pricePerUnit;
    }

    const subtotalUSD = unitPrice * quantity;
    const shippingUSD = Math.round(subtotalUSD * 0.04);
    const totalUSD = subtotalUSD + shippingUSD;

    const orderId = 'AM-ORD-' + Math.floor(10000 + Math.random() * 90000);
    const contractId = 'AGR-' + new Date().getFullYear() + '-' + Math.floor(100000 + Math.random() * 900000);

    let quotedCryptoCurrency: 'BTC' | 'USDT' | undefined;
    let quotedAmountCrypto: string | undefined;
    let paymentAddress = 'TY8zKq7L3xM9PqW2N81K4m9X2z1L0p9Q81';

    if (paymentRail === 'BITCOIN' || paymentRail === 'LIGHTNING') {
      quotedCryptoCurrency = 'BTC';
      quotedAmountCrypto = (totalUSD / exchangeRates.BTC_USD).toFixed(5) + ' BTC';
      paymentAddress = 'bc1q9v80qzp4q6k2u0wlzg2x0vhgvh2s4j4y9l4p3k';
    } else if (paymentRail === 'USDT') {
      quotedCryptoCurrency = 'USDT';
      quotedAmountCrypto = totalUSD.toFixed(2) + ' USDT';
      paymentAddress = product.supplierId === 'sup-101'
        ? 'TY8zKq7L3xM9PqW2N81K4m9X2z1L0p9Q81'
        : '0x71C7656EC7ab88b098defB751B7401B5f6d8976F';
    }

    // SHA-256 simulation
    const docHash = '0x' + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('');

    const newOrder: Order = {
      id: orderId,
      buyerId: 'usr-buyer-active',
      buyerName: 'AeroTech Global Procurement',
      sellerId: product.supplierId,
      sellerName: product.supplierName,
      items: [
        {
          productId: product.id,
          productName: product.name,
          sku: product.sku,
          image: product.images[0],
          quantity,
          unitPriceUSD: unitPrice,
          selectedCustomizations: customizations,
        },
      ],
      subtotalUSD,
      shippingUSD,
      totalUSD,
      paymentRail,
      paymentNetwork: paymentRail === 'USDT' ? network : undefined,
      quotedAmountCrypto,
      quotedCryptoCurrency,
      exchangeRateAtLock: paymentRail === 'BITCOIN' ? exchangeRates.BTC_USD : 1.00,
      paymentAddress,
      paymentTxHash: '0x' + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join(''),
      paymentStatus: 'CONFIRMED',
      escrowState: 'FUNDED',
      createdAt: new Date().toISOString().split('T')[0],
      estimatedDeliveryDate: new Date(Date.now() + (product.leadTimeDays + product.shippingEstimateDays) * 86400000)
        .toISOString()
        .split('T')[0],
      contract: {
        contractId,
        orderId,
        buyerName: 'AeroTech Global Procurement',
        sellerName: product.supplierName,
        productName: product.name,
        quantity,
        totalPriceUSD: totalUSD,
        currency: paymentRail === 'BITCOIN' ? 'BTC' : 'USDT',
        paymentRail,
        deliveryDate: new Date(Date.now() + (product.leadTimeDays + product.shippingEstimateDays) * 86400000)
          .toISOString()
          .split('T')[0],
        shippingTerms: `FOB ${product.originCountry} / DDP Destination`,
        inspectionTerms: 'ISO 2859-1 Third-Party Factory Pre-Shipment Quality Inspection',
        escrowConditions: '100% Funds Committed to Programmable Multi-Sig Escrow. Milestone releases on verification.',
        documentHashSHA256: docHash,
        buyerSignature: {
          signedBy: 'AeroTech Authorized Signer (PubKey 0x9812...8912)',
          timestamp: new Date().toISOString(),
          signatureHash: '0xsig_' + docHash.substring(0, 16),
        },
        sellerSignature: {
          signedBy: `${product.supplierName} Sales Lead (PubKey 0x3841...7710)`,
          timestamp: new Date().toISOString(),
          signatureHash: '0xsig_seller_' + docHash.substring(0, 16),
        },
      },
      milestones: [
        { stage: 'CREATED', label: 'Order Created & Digital Purchase Agreement Signed', timestamp: new Date().toLocaleTimeString(), completed: true },
        { stage: 'FUNDED', label: `${quotedAmountCrypto || '$' + totalUSD} Committed to Programmable Escrow`, timestamp: new Date().toLocaleTimeString(), completed: true },
        { stage: 'PRODUCTION', label: 'Factory Production Commenced', completed: false },
        { stage: 'INSPECTION', label: 'QC Pre-Shipment Inspection', completed: false },
        { stage: 'SHIPPED', label: 'Customs Sealed & Port Departure', completed: false },
        { stage: 'DELIVERED', label: 'Destination Port Receipt', completed: false },
        { stage: 'RELEASED', label: 'Final Settlement Release to Merchant', completed: false },
      ],
    };

    setOrders((prev) => [newOrder, ...prev]);

    // Update wallet
    if (paymentRail === 'BITCOIN' && quotedAmountCrypto) {
      const btcVal = parseFloat(quotedAmountCrypto);
      setWalletBalances((b) => ({ ...b, btc: Math.max(0, b.btc - btcVal) }));
    } else if (paymentRail === 'USDT') {
      setWalletBalances((b) => ({ ...b, usdt: Math.max(0, b.usdt - totalUSD) }));
    } else {
      setWalletBalances((b) => ({ ...b, fiatUSD: Math.max(0, b.fiatUSD - totalUSD) }));
    }

    // Add transaction record
    const newTx: WalletTransaction = {
      id: 'tx-' + Math.floor(10000 + Math.random() * 90000),
      type: 'ESCROW_LOCK',
      asset: paymentRail === 'BITCOIN' ? 'BTC' : 'USDT',
      network: paymentRail === 'USDT' ? network : 'BITCOIN_ONCHAIN',
      amount: paymentRail === 'BITCOIN' ? totalUSD / exchangeRates.BTC_USD : totalUSD,
      amountUSD: totalUSD,
      txHash: newOrder.paymentTxHash,
      timestamp: new Date().toLocaleString(),
      counterparty: `${product.supplierName} Escrow Contract`,
      status: 'CONFIRMED',
    };
    setWalletTransactions((prev) => [newTx, ...prev]);

    addToast('Escrow Funded & Order Placed', `Order #${orderId} for ${product.name} created successfully.`, 'success');
    setCheckoutItem(null);
    setSelectedOrder(newOrder);
    setActiveTab('ORDERS');
    return newOrder;
  };

  const advanceEscrowStage = (orderId: string) => {
    setOrders((prev) =>
      prev.map((ord) => {
        if (ord.id !== orderId) return ord;
        
        const stages: EscrowState[] = [
          'CREATED',
          'FUNDED',
          'PRODUCTION',
          'INSPECTION',
          'SHIPPED',
          'DELIVERED',
          'RELEASE_PENDING',
          'RELEASED',
        ];
        const currIdx = stages.indexOf(ord.escrowState);
        if (currIdx >= stages.length - 1) return ord;

        const nextStage = stages[currIdx + 1];
        const updatedMilestones = ord.milestones.map((m) => {
          if (m.stage === nextStage) {
            return { ...m, completed: true, timestamp: new Date().toLocaleString() };
          }
          return m;
        });

        addToast(
          'Escrow Milestone Advanced',
          `Order #${orderId} moved to stage ${nextStage}`,
          'info'
        );

        return {
          ...ord,
          escrowState: nextStage,
          milestones: updatedMilestones,
        };
      })
    );
  };

  const releaseEscrow = (orderId: string) => {
    setOrders((prev) =>
      prev.map((ord) => {
        if (ord.id !== orderId) return ord;

        const updatedMilestones = ord.milestones.map((m) => ({ ...m, completed: true }));

        addToast(
          'Escrow Released',
          `Funds for Order #${orderId} ($${ord.totalUSD.toLocaleString()}) disbursed to merchant.`,
          'success'
        );

        const releaseTx: WalletTransaction = {
          id: 'tx-rel-' + Math.floor(10000 + Math.random() * 90000),
          type: 'ESCROW_RELEASE',
          asset: ord.paymentRail === 'BITCOIN' ? 'BTC' : 'USDT',
          amount: ord.paymentRail === 'BITCOIN' ? ord.totalUSD / exchangeRates.BTC_USD : ord.totalUSD,
          amountUSD: ord.totalUSD,
          txHash: '0xrel_' + Array.from({ length: 48 }, () => Math.floor(Math.random() * 16).toString(16)).join(''),
          timestamp: new Date().toLocaleString(),
          counterparty: `${ord.sellerName} Merchant Wallet`,
          status: 'CONFIRMED',
        };
        setWalletTransactions((txs) => [releaseTx, ...txs]);

        return {
          ...ord,
          escrowState: 'RELEASED',
          milestones: updatedMilestones,
        };
      })
    );
  };

  const raiseDispute = (orderId: string, reason: string) => {
    setOrders((prev) =>
      prev.map((ord) => {
        if (ord.id !== orderId) return ord;
        addToast('Escrow Dispute Opened', `Dispute opened for Order #${orderId}: ${reason}`, 'warning');
        return {
          ...ord,
          escrowState: 'DISPUTED',
        };
      })
    );
  };

  const publishRFQ = (
    rfqData: Omit<RFQ, 'id' | 'createdAt' | 'status' | 'quotesCount' | 'buyerId' | 'buyerName'>
  ): RFQ => {
    const newRfq: RFQ = {
      ...rfqData,
      id: 'rfq-' + Math.floor(2000 + Math.random() * 8000),
      buyerId: 'usr-buyer-active',
      buyerName: 'AeroTech Global Procurement',
      createdAt: new Date().toISOString().split('T')[0],
      status: 'OPEN',
      quotesCount: 0,
    };
    setRfqs((prev) => [newRfq, ...prev]);
    addToast('RFQ Published', `Request for Quotation '${newRfq.productTitle}' live on global supplier network.`, 'success');
    return newRfq;
  };

  const submitQuote = (quoteData: Omit<Quote, 'id' | 'createdAt' | 'status' | 'supplierRating'>) => {
    const newQuote: Quote = {
      ...quoteData,
      id: 'quote-' + Math.floor(3000 + Math.random() * 7000),
      supplierRating: 4.92,
      createdAt: new Date().toISOString().split('T')[0],
      status: 'SUBMITTED',
    };
    setQuotes((prev) => [newQuote, ...prev]);
    setRfqs((prev) =>
      prev.map((r) => (r.id === quoteData.rfqId ? { ...r, quotesCount: r.quotesCount + 1 } : r))
    );
    addToast('Supplier Quote Submitted', `Quote submitted for RFQ #${quoteData.rfqId}`, 'success');
  };

  const sendNegotiationMessage = (threadId: string, text: string, offer?: StructuredOffer) => {
    const newMsg: NegotiationMessage = {
      id: 'msg-' + Date.now(),
      threadId,
      senderId: activeRole === 'BUYER' ? 'usr-buyer' : 'sup-101',
      senderName: activeRole === 'BUYER' ? 'AeroTech Procurement Lead' : 'Shenzhen Precision Sales Director',
      senderRole: activeRole,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      text,
      structuredOffer: offer,
      status: offer ? 'PENDING' : undefined,
    };

    setNegotiationThreads((prev) =>
      prev.map((th) => {
        if (th.id !== threadId) return th;
        return {
          ...th,
          messages: [...th.messages, newMsg],
        };
      })
    );
  };

  const respondToOffer = (threadId: string, messageId: string, action: 'ACCEPTED' | 'REJECTED' | 'COUNTERED') => {
    setNegotiationThreads((prev) =>
      prev.map((th) => {
        if (th.id !== threadId) return th;
        return {
          ...th,
          messages: th.messages.map((m) => (m.id === messageId ? { ...m, status: action } : m)),
        };
      })
    );
    addToast('Offer Update', `Structured offer marked as ${action}`, 'info');
  };

  const depositFunds = (asset: 'BTC' | 'USDT' | 'USD', amount: number, network: StablecoinNetwork = 'TRC20') => {
    if (asset === 'BTC') {
      setWalletBalances((b) => ({ ...b, btc: b.btc + amount }));
    } else if (asset === 'USDT') {
      setWalletBalances((b) => ({ ...b, usdt: b.usdt + amount }));
    } else {
      setWalletBalances((b) => ({ ...b, fiatUSD: b.fiatUSD + amount }));
    }

    const tx: WalletTransaction = {
      id: 'tx-dep-' + Math.floor(10000 + Math.random() * 90000),
      type: 'DEPOSIT',
      asset,
      network: asset === 'USDT' ? network : asset === 'BTC' ? 'BITCOIN_ONCHAIN' : undefined,
      amount,
      amountUSD: asset === 'BTC' ? amount * exchangeRates.BTC_USD : amount,
      txHash: '0xdep_' + Array.from({ length: 48 }, () => Math.floor(Math.random() * 16).toString(16)).join(''),
      timestamp: new Date().toLocaleString(),
      counterparty: 'External Wallet Deposit',
      status: 'CONFIRMED',
    };
    setWalletTransactions((prev) => [tx, ...prev]);
    addToast('Wallet Deposit Complete', `Deposited ${amount} ${asset} to Market Wallet`, 'success');
  };

  return (
    <MarketContext.Provider
      value={{
        activeTab,
        setActiveTab,
        activeRole,
        setActiveRole,
        currency,
        setCurrency,
        products,
        suppliers,
        orders,
        rfqs,
        quotes,
        shipments,
        walletTransactions,
        walletBalances,
        searchQuery,
        setSearchQuery,
        selectedCategory,
        setSelectedCategory,
        selectedRegionId,
        setSelectedRegionId,
        selectedSupplierType,
        setSelectedSupplierType,
        selectedAcceptedRail,
        setSelectedAcceptedRail,
        selectedProduct,
        setSelectedProduct,
        selectedSupplier,
        setSelectedSupplier,
        selectedOrder,
        setSelectedOrder,
        checkoutItem,
        setCheckoutItem,
        createOrderFromCheckout,
        advanceEscrowStage,
        releaseEscrow,
        raiseDispute,
        publishRFQ,
        submitQuote,
        negotiationThreads,
        activeThreadId,
        setActiveThreadId,
        sendNegotiationMessage,
        respondToOffer,
        depositFunds,
        exchangeRates,
        toasts,
        addToast,
        removeToast,
        formatPrice,
      }}
    >
      {children}
    </MarketContext.Provider>
  );
};

export const useMarket = () => {
  const context = useContext(MarketContext);
  if (!context) {
    throw new Error('useMarket must be used within a MarketProvider');
  }
  return context;
};
