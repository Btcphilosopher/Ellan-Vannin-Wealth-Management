import React from 'react';
import { useSimulationStore } from '../../simulation/simulationEngine';
import { translations } from '../../i18n/translations';
import { ShieldCheck, Server, Activity, Link2, Zap, CheckCircle2, AlertTriangle } from 'lucide-react';

export const TopStatusBar: React.FC = () => {
  const { language, rtgsLinkStatus, sicStatus, dltNodes, institutions } = useSimulationStore();
  const t = translations[language] || translations.en;

  const offlineNodes = dltNodes.filter((n) => n.status !== 'ONLINE').length;
  const stressedBanks = institutions.filter((i) => i.status !== 'ACTIVE').length;

  return (
    <div className="bg-slate-900 border-b border-slate-800 text-slate-300 text-xs font-mono py-2 px-4">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-y-2 gap-x-6">
        <div className="flex items-center gap-1.5">
          <Server className="w-3.5 h-3.5 text-emerald-400" />
          <span className="text-slate-400">{t.system}:</span>
          <span className="text-emerald-400 font-bold tracking-wider">{t.operational}</span>
        </div>

        <div className="flex items-center gap-1.5">
          <CheckCircle2 className="w-3.5 h-3.5 text-blue-400" />
          <span className="text-slate-400">{t.snbLedger}:</span>
          <span className="text-blue-400 font-bold tracking-wider">{t.synchronized}</span>
        </div>

        <div className="flex items-center gap-1.5">
          <Activity className="w-3.5 h-3.5 text-emerald-400" />
          <span className="text-slate-400">{t.dltPlatform}:</span>
          <span className={`font-bold tracking-wider ${offlineNodes > 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
            {offlineNodes > 0 ? `DEGRADED (${offlineNodes} OFFLINE)` : t.operational}
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          <Zap className="w-3.5 h-3.5 text-cyan-400" />
          <span className="text-slate-400">{t.sic}:</span>
          <span className="text-cyan-400 font-bold tracking-wider">{t.simulated}</span>
        </div>

        <div className="flex items-center gap-1.5">
          <Link2 className="w-3.5 h-3.5 text-emerald-400" />
          <span className="text-slate-400">{t.rtgsLink}:</span>
          <span
            className={`font-bold tracking-wider ${
              rtgsLinkStatus === 'OPERATIONAL'
                ? 'text-emerald-400'
                : rtgsLinkStatus === 'DEGRADED'
                ? 'text-amber-400'
                : 'text-red-400'
            }`}
          >
            {rtgsLinkStatus}
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span className="text-slate-400">{t.dvp}:</span>
          <span className="text-emerald-400 font-bold tracking-wider">{t.normal}</span>
        </div>

        <div className="flex items-center gap-1.5">
          <span className="text-slate-400">{t.liquidity}:</span>
          <span className={`font-bold tracking-wider ${stressedBanks > 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
            {stressedBanks > 0 ? 'STRESSED' : t.stable}
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          <span className="text-slate-400">{t.risk}:</span>
          <span className={`font-bold tracking-wider ${stressedBanks > 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
            {stressedBanks > 0 ? 'ELEVATED' : t.low}
          </span>
        </div>
      </div>
    </div>
  );
};
