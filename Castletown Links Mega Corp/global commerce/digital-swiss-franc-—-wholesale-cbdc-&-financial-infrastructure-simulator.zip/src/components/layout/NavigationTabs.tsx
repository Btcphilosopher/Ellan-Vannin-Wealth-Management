import React from 'react';
import { useSimulationStore } from '../../simulation/simulationEngine';
import { translations } from '../../i18n/translations';
import {
  LayoutDashboard,
  Building2,
  Coins,
  Landmark,
  Network,
  Briefcase,
  GitCommit,
  Workflow,
  Layers,
  Repeat,
  Radio,
  ArrowRightLeft,
  Banknote,
  Scale,
  Activity,
  Globe2,
  Lock,
  ShieldAlert,
  FileSpreadsheet,
  GitCompare,
  AlertTriangle,
  FlaskConical,
} from 'lucide-react';

export const NavigationTabs: React.FC = () => {
  const { activeTab, setActiveTab, language } = useSimulationStore();
  const t = translations[language] || translations.en;

  const tabs = [
    { id: 'command-center', label: t.tabCommandCenter, icon: LayoutDashboard },
    { id: 'snb-core', label: t.tabSnbCore, icon: Landmark },
    { id: 'wholesale-cbdc', label: t.tabWholesaleCbdc, icon: Coins },
    { id: 'financial-institutions', label: t.tabBanks, icon: Building2 },
    { id: 'dlt-platform', label: t.tabDlt, icon: Network },
    { id: 'tokenised-assets', label: t.tabTokenisedAssets, icon: Briefcase },
    { id: 'dvp-engine', label: t.tabDvpEngine, icon: GitCommit },
    { id: 'helvetia-a', label: t.tabHelvetiaA, icon: Workflow },
    { id: 'helvetia-b', label: t.tabHelvetiaB, icon: Layers },
    { id: 'sic-simulator', label: t.tabSic, icon: Repeat },
    { id: 'rtgs-link', label: t.tabRtgsLink, icon: Radio },
    { id: 'repo-market', label: t.tabRepo, icon: ArrowRightLeft },
    { id: 'monetary-policy', label: t.tabMonetaryPolicy, icon: Banknote },
    { id: 'collateral', label: t.tabCollateral, icon: Scale },
    { id: 'liquidity', label: t.tabLiquidity, icon: Activity },
    { id: 'stability', label: t.tabStability, icon: ShieldAlert },
    { id: 'cross-border', label: t.tabCrossBorder, icon: Globe2 },
    { id: 'privacy', label: t.tabPrivacy, icon: Lock },
    { id: 'security', label: t.tabSecurity, icon: ShieldAlert },
    { id: 'audit', label: t.tabAudit, icon: FileSpreadsheet },
    { id: 'comparison', label: t.tabComparison, icon: GitCompare },
    { id: 'chaos', label: t.tabChaos, icon: AlertTriangle },
    { id: 'retail-research', label: t.tabRetailResearch, icon: FlaskConical },
  ];

  return (
    <div className="bg-slate-900 border-b border-slate-800 text-slate-300 overflow-x-auto scrollbar-none">
      <div className="max-w-7xl mx-auto px-2 flex items-center gap-1 py-1">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          const isExperimental = tab.id === 'retail-research';

          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded text-xs font-mono whitespace-nowrap transition border ${
                isActive
                  ? 'bg-blue-600 text-white font-semibold border-blue-500 shadow-xs'
                  : isExperimental
                  ? 'bg-purple-950/40 text-purple-300 border-purple-800/50 hover:bg-purple-900/60'
                  : 'bg-slate-900/50 text-slate-400 border-transparent hover:text-slate-200 hover:bg-slate-800/80'
              }`}
            >
              <Icon className="w-3.5 h-3.5 shrink-0" />
              <span>{tab.label}</span>
              {isExperimental && (
                <span className="ml-1 bg-purple-900 text-purple-200 text-[9px] px-1 rounded uppercase font-sans">
                  EXP
                </span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};
