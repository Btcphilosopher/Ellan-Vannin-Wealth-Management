import React from 'react';
import { useSimulationStore } from '../../simulation/simulationEngine';
import { translations } from '../../i18n/translations';
import { Language } from '../../types/simulation';
import { Play, Pause, RotateCcw, ShieldCheck, Cpu } from 'lucide-react';

export const HeaderBanner: React.FC = () => {
  const {
    language,
    setLanguage,
    simulationSpeed,
    setSimulationSpeed,
    isRunning,
    toggleSimulationRunning,
    resetSimulation,
    blockHeight,
  } = useSimulationStore();

  const t = translations[language] || translations.en;

  return (
    <header className="bg-slate-950 text-slate-100 border-b border-slate-800">
      {/* Top Banner Disclaimer - Mandatory Swiss institutional style */}
      <div className="bg-red-800/90 text-white text-xs font-mono py-1 px-4 tracking-widest flex items-center justify-between border-b border-red-700/50">
        <div className="flex items-center gap-2">
          <span className="inline-block w-2 h-2 rounded-full bg-red-200 animate-pulse"></span>
          <span className="font-semibold">{t.bannerText}</span>
        </div>
        <div className="hidden sm:flex items-center gap-4 text-[11px] opacity-90">
          <span>{t.notLiveWarning}</span>
          <span className="bg-red-950/60 px-2 py-0.5 rounded text-red-200">CONFIDENTIAL & RESEARCH ONLY</span>
        </div>
      </div>

      {/* Main Header Toolbar */}
      <div className="max-w-7xl mx-auto px-4 py-3 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        {/* Title branding */}
        <div className="flex items-center gap-3">
          {/* Swiss Cross Symbol Accent */}
          <div className="w-10 h-10 bg-red-600 rounded flex items-center justify-center shrink-0 shadow-sm border border-red-500/30">
            <div className="relative w-6 h-6 flex items-center justify-center">
              <div className="absolute w-5 h-1.5 bg-white"></div>
              <div className="absolute h-5 w-1.5 bg-white"></div>
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold tracking-tight text-white font-serif">{t.title}</h1>
              <span className="bg-slate-800 text-slate-300 text-[10px] font-mono px-2 py-0.5 rounded border border-slate-700">
                PROJ. HELVETIA SIM
              </span>
            </div>
            <p className="text-xs text-slate-400 font-mono tracking-wide">{t.subtitle}</p>
          </div>
        </div>

        {/* Right side controls: Language & Ticker speed */}
        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto justify-between md:justify-end">
          {/* Simulation Ticker Controls */}
          <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 rounded p-1 font-mono text-xs">
            <div className="flex items-center gap-1.5 px-2 text-slate-400 border-r border-slate-800">
              <Cpu className="w-3.5 h-3.5 text-blue-400" />
              <span>BLK <strong className="text-slate-200">#{blockHeight}</strong></span>
            </div>

            <button
              onClick={toggleSimulationRunning}
              className={`p-1.5 rounded transition ${
                isRunning
                  ? 'bg-amber-950/80 text-amber-300 border border-amber-800/50 hover:bg-amber-900'
                  : 'bg-emerald-950/80 text-emerald-300 border border-emerald-800/50 hover:bg-emerald-900'
              }`}
              title={isRunning ? 'Pause Simulation' : 'Resume Simulation'}
            >
              {isRunning ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            </button>

            {/* Speed Multiplier */}
            <div className="flex items-center text-[11px] bg-slate-950 rounded p-0.5 border border-slate-800">
              {[1, 10, 100, 1000].map((spd) => (
                <button
                  key={spd}
                  onClick={() => setSimulationSpeed(spd)}
                  className={`px-1.5 py-0.5 rounded transition ${
                    simulationSpeed === spd
                      ? 'bg-blue-600 text-white font-bold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {spd}×
                </button>
              ))}
            </div>

            <button
              onClick={resetSimulation}
              className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded transition"
              title="Reset Simulation State"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Language Selector */}
          <div className="flex items-center bg-slate-900 border border-slate-800 rounded p-0.5 text-xs font-mono">
            {(['en', 'de', 'fr', 'it'] as Language[]).map((lang) => (
              <button
                key={lang}
                onClick={() => setLanguage(lang)}
                className={`px-2 py-1 rounded transition uppercase ${
                  language === lang
                    ? 'bg-slate-700 text-white font-bold shadow-xs'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {lang}
              </button>
            ))}
          </div>
        </div>
      </div>
    </header>
  );
};
