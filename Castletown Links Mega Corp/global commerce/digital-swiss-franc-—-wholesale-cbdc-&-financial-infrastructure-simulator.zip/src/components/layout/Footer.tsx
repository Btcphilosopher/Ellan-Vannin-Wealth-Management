import React from 'react';
import { useSimulationStore } from '../../simulation/simulationEngine';
import { translations } from '../../i18n/translations';

export const Footer: React.FC = () => {
  const { language } = useSimulationStore();
  const t = translations[language] || translations.en;

  return (
    <footer className="bg-slate-950 border-t border-slate-800 text-slate-400 py-4 px-6 font-mono text-xs mt-auto">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="flex flex-col sm:flex-row items-center gap-2">
          <span className="font-semibold text-slate-200">
            DIGITAL SWISS FRANC — WHOLESALE CBDC RESEARCH SIMULATION
          </span>
          <span className="hidden sm:inline text-slate-600">·</span>
          <span className="text-slate-400 italic">
            DIGITALER SCHWEIZER FRANKEN — SIMULATION FÜR WHOLESALE-CBDC
          </span>
        </div>

        <div className="flex items-center gap-3 text-red-400 bg-red-950/40 px-3 py-1 rounded border border-red-900/50 text-[11px]">
          <span className="font-bold">{t.notLiveWarning}</span>
        </div>
      </div>
    </footer>
  );
};
