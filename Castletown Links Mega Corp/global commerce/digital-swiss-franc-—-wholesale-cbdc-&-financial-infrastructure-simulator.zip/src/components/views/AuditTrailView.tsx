import React, { useState } from 'react';
import { useSimulationStore } from '../../simulation/simulationEngine';
import { translations } from '../../i18n/translations';
import { Search, FileText, CheckCircle2 } from 'lucide-react';
import { AuditRecord } from '../../types/simulation';

export const AuditTrailView: React.FC = () => {
  const { auditRecords, language } = useSimulationStore();
  const t = translations[language] || translations.en;

  const [searchTerm, setSearchTerm] = useState('');

  const filteredTrail = auditRecords.filter(
    (entry: AuditRecord) =>
      entry.details.toLowerCase().includes(searchTerm.toLowerCase()) ||
      entry.eventType.toLowerCase().includes(searchTerm.toLowerCase()) ||
      entry.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6 font-mono text-xs">
      <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-400" />
            <h2 className="text-lg font-bold font-serif text-white tracking-wide">
              IMMUTABLE AUDIT TRAIL & DOUBLE-ENTRY JOURNAL
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Cryptographically Verifiable Central Bank Audit Log with Balanced Accounting Legs
          </p>
        </div>

        <div className="relative w-full md:w-64">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search audit trail..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded pl-9 pr-3 py-2 text-white text-xs"
          />
        </div>
      </div>

      {/* Audit Log Table */}
      <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-4">
        <h3 className="text-sm font-bold text-white font-serif border-b border-slate-800 pb-2">
          CENTRAL BANK IMMUTABLE JOURNAL ({filteredTrail.length} Records)
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 text-[11px]">
                <th className="py-2 px-3">TIMESTAMP</th>
                <th className="py-2 px-3">LOG ID</th>
                <th className="py-2 px-3">ACTION TYPE</th>
                <th className="py-2 px-3">DETAILS</th>
                <th className="py-2 px-3">HASH VERIFICATION</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {filteredTrail.map((log: AuditRecord) => (
                <tr key={log.id} className="hover:bg-slate-800/40 transition">
                  <td className="py-2 px-3 text-slate-400 whitespace-nowrap">
                    {new Date(log.timestamp).toLocaleTimeString()}
                  </td>
                  <td className="py-2 px-3 font-bold text-blue-400">{log.id}</td>
                  <td className="py-2 px-3 font-bold text-purple-300">{log.eventType}</td>
                  <td className="py-2 px-3 text-slate-200 max-w-md truncate">{log.details}</td>
                  <td className="py-2 px-3 text-emerald-400 font-bold font-mono">
                    <span className="flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                      VERIFIED
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
