import React from 'react';
import { useSimulationStore } from '../../simulation/simulationEngine';
import { translations } from '../../i18n/translations';
import { ShieldAlert, Key, Cpu, AlertTriangle, CheckCircle2 } from 'lucide-react';

export const CybersecurityView: React.FC = () => {
  const { language } = useSimulationStore();
  const t = translations[language] || translations.en;

  return (
    <div className="space-y-6 font-mono text-xs">
      <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-red-400" />
            <h2 className="text-lg font-bold font-serif text-white tracking-wide">
              CYBERSECURITY & OPERATIONAL RESILIENCE CENTER
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Hardware Security Modules (HSM), Quantum-Resistant Cryptography & Threat Intelligence
          </p>
        </div>

        <div className="bg-slate-950 px-3 py-1.5 rounded border border-slate-800 text-slate-300">
          Post-Quantum Security: <strong className="text-emerald-400">CRYSTALS-Dilithium Enabled</strong>
        </div>
      </div>

      {/* Cyber Incident #HEL-00482 Investigation Banner */}
      <div className="bg-amber-950/30 border border-amber-800/80 p-5 rounded-lg space-y-3">
        <div className="flex items-center justify-between border-b border-amber-800/60 pb-2">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-amber-400" />
            <h3 className="text-sm font-bold text-amber-300 font-serif">
              SIMULATED THREAT INCIDENT REPORT: #HEL-00482
            </h3>
          </div>
          <span className="bg-amber-950 text-amber-300 px-2 py-0.5 rounded text-[10px] font-bold border border-amber-800">
            MITIGATED / CONTAINED
          </span>
        </div>

        <p className="text-slate-300 leading-relaxed">
          <strong>INCIDENT DESCRIPTION:</strong> Automated threat detection identified anomalous signature timing variation on Node 04 (Zurich Securities Validator). The Zero-Trust perimeter automatically isolated the node, triggered threshold key re-sharing across surviving validator nodes, and prevented block corruption.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2 text-[11px]">
          <div className="p-2.5 bg-slate-950 rounded border border-slate-800">
            <span className="text-slate-400 block">CONTAINMENT STATUS</span>
            <span className="font-bold text-emerald-400">Node Quarantined in 0.04s</span>
          </div>
          <div className="p-2.5 bg-slate-950 rounded border border-slate-800">
            <span className="text-slate-400 block">HSM KEY INTEGRITY</span>
            <span className="font-bold text-emerald-400">FIPS 140-3 Level 4 Secured</span>
          </div>
          <div className="p-2.5 bg-slate-950 rounded border border-slate-800">
            <span className="text-slate-400 block">LEDGER FINALITY IMPACT</span>
            <span className="font-bold text-emerald-400">Zero Transaction Reversion</span>
          </div>
        </div>
      </div>
    </div>
  );
};
