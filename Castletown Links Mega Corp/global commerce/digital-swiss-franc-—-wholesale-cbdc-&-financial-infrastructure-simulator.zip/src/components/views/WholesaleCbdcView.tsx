import React, { useState } from 'react';
import { useSimulationStore } from '../../simulation/simulationEngine';
import { translations } from '../../i18n/translations';
import { Coins, ArrowDownLeft, ArrowUpRight, Lock, ShieldCheck, RefreshCw, Send } from 'lucide-react';

export const WholesaleCbdcView: React.FC = () => {
  const {
    snbBalanceSheet,
    institutions,
    issueWchf,
    redeemWchf,
    transferWchf,
    freezeAccount,
    reconcileLedgers,
    language,
  } = useSimulationStore();

  const t = translations[language] || translations.en;

  // Form states
  const [selectedBank, setSelectedBank] = useState(institutions[0]?.id || '');
  const [actionAmount, setActionAmount] = useState('1000000000'); // 1B CHF default
  const [transferSender, setTransferSender] = useState(institutions[0]?.id || '');
  const [transferReceiver, setTransferReceiver] = useState(institutions[1]?.id || '');
  const [transferAmount, setTransferAmount] = useState('500000000'); // 500M CHF

  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const handleIssue = () => {
    const amount = parseFloat(actionAmount);
    if (!amount || amount <= 0) return;
    const ok = issueWchf(selectedBank, amount);
    if (ok) {
      setMessage({
        type: 'success',
        text: `Successfully issued CHF ${amount.toLocaleString()} wCHF against SNB Sight Deposit conversion.`,
      });
    } else {
      setMessage({
        type: 'error',
        text: 'Issuance failed. Check if institution has sufficient SNB sight deposit balance or is frozen.',
      });
    }
  };

  const handleRedeem = () => {
    const amount = parseFloat(actionAmount);
    if (!amount || amount <= 0) return;
    const ok = redeemWchf(selectedBank, amount);
    if (ok) {
      setMessage({
        type: 'success',
        text: `Successfully redeemed CHF ${amount.toLocaleString()} wCHF back into traditional SNB sight deposit.`,
      });
    } else {
      setMessage({
        type: 'error',
        text: 'Redemption failed. Check wCHF balance of selected institution.',
      });
    }
  };

  const handleTransfer = () => {
    const amount = parseFloat(transferAmount);
    if (!amount || amount <= 0) return;
    const ok = transferWchf(transferSender, transferReceiver, amount);
    if (ok) {
      setMessage({
        type: 'success',
        text: `Transferred CHF ${amount.toLocaleString()} wCHF on DLT from ${
          institutions.find((i) => i.id === transferSender)?.name
        } to ${institutions.find((i) => i.id === transferReceiver)?.name}.`,
      });
    } else {
      setMessage({
        type: 'error',
        text: 'Transfer failed. Check sender balance or participant frozen status.',
      });
    }
  };

  const handleReconcile = () => {
    const res = reconcileLedgers();
    if (res.matched) {
      setMessage({ type: 'success', text: res.details });
    } else {
      setMessage({ type: 'error', text: res.details });
    }
  };

  const totalWchf = snbBalanceSheet.liabilities.wholesaleCbdcOutstanding;

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Coins className="w-5 h-5 text-emerald-400" />
            <h2 className="text-lg font-bold font-serif text-white tracking-wide">
              WHOLESALE DIGITAL SWISS FRANC (wCHF) LEDGER
            </h2>
          </div>
          <p className="text-xs font-mono text-slate-400 mt-1">
            Central-Bank Money Available Exclusively to Regulated Financial Market Participants
          </p>
        </div>

        <button
          onClick={handleReconcile}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white font-mono text-xs font-bold px-4 py-2 rounded transition shadow-xs"
        >
          <RefreshCw className="w-4 h-4" />
          {t.reconcile}
        </button>
      </div>

      {/* Notification Toast */}
      {message && (
        <div
          className={`p-4 rounded-lg font-mono text-xs border ${
            message.type === 'success'
              ? 'bg-emerald-950/80 text-emerald-300 border-emerald-800'
              : 'bg-red-950/80 text-red-300 border-red-800'
          }`}
        >
          {message.text}
        </div>
      )}

      {/* Primary wCHF Control Operations Workbench */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 font-mono text-xs">
        {/* Issuance & Redemption Panel */}
        <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-4">
          <h3 className="text-sm font-bold text-white font-serif border-b border-slate-800 pb-2">
            SNB CENTRAL ISSUANCE & REDEMPTION DESK
          </h3>

          <div className="space-y-3">
            <div>
              <label className="block text-slate-400 text-xs mb-1">SELECT INSTITUTION</label>
              <select
                value={selectedBank}
                onChange={(e) => setSelectedBank(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-white text-xs"
              >
                {institutions.map((inst) => (
                  <option key={inst.id} value={inst.id}>
                    {inst.name} ({inst.code}) — Sight: CHF {(inst.snbSightDeposit / 1e9).toFixed(1)}B | wCHF: CHF {(inst.wChfBalance / 1e9).toFixed(1)}B
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-400 text-xs mb-1">AMOUNT (CHF)</label>
              <input
                type="number"
                value={actionAmount}
                onChange={(e) => setActionAmount(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-white font-bold text-xs"
              />
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <button
                onClick={handleIssue}
                className="flex items-center justify-center gap-2 bg-emerald-700 hover:bg-emerald-600 text-white font-bold py-2.5 rounded transition shadow-xs"
              >
                <ArrowDownLeft className="w-4 h-4" />
                {t.issueWchf}
              </button>

              <button
                onClick={handleRedeem}
                className="flex items-center justify-center gap-2 bg-amber-700 hover:bg-amber-600 text-white font-bold py-2.5 rounded transition shadow-xs"
              >
                <ArrowUpRight className="w-4 h-4" />
                {t.redeemWchf}
              </button>
            </div>
          </div>
        </div>

        {/* Institutional Direct DLT Transfer Panel */}
        <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-4">
          <h3 className="text-sm font-bold text-white font-serif border-b border-slate-800 pb-2">
            INTERBANK DIRECT DLT wCHF TRANSFER
          </h3>

          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-400 text-xs mb-1">SENDER</label>
                <select
                  value={transferSender}
                  onChange={(e) => setTransferSender(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-white text-xs"
                >
                  {institutions.map((inst) => (
                    <option key={inst.id} value={inst.id}>
                      {inst.code}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 text-xs mb-1">RECEIVER</label>
                <select
                  value={transferReceiver}
                  onChange={(e) => setTransferReceiver(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-white text-xs"
                >
                  {institutions.map((inst) => (
                    <option key={inst.id} value={inst.id}>
                      {inst.code}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-slate-400 text-xs mb-1">TRANSFER AMOUNT (CHF)</label>
              <input
                type="number"
                value={transferAmount}
                onChange={(e) => setTransferAmount(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-white font-bold text-xs"
              />
            </div>

            <button
              onClick={handleTransfer}
              className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-500 text-white font-bold py-2.5 rounded transition shadow-xs mt-2"
            >
              <Send className="w-4 h-4" />
              {t.transferWchf}
            </button>
          </div>
        </div>
      </div>

      {/* Institutional Holdings & Liquidity Table */}
      <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-4 font-mono text-xs">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-sm font-bold text-white font-serif">
            INSTITUTIONAL wCHF SETTLEMENT BALANCES
          </h3>
          <span className="text-slate-400">
            TOTAL wCHF OUTSTANDING: <strong className="text-emerald-400">CHF {(totalWchf / 1e9).toFixed(2)}B</strong>
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 text-[11px]">
                <th className="py-2.5 px-3">{t.institution}</th>
                <th className="py-2.5 px-3">CODE</th>
                <th className="py-2.5 px-3">{t.sightDeposit}</th>
                <th className="py-2.5 px-3">{t.wChfBalance}</th>
                <th className="py-2.5 px-3">TOTAL CASH LIQUIDITY</th>
                <th className="py-2.5 px-3">{t.status}</th>
                <th className="py-2.5 px-3 text-right">{t.action}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {institutions.map((inst) => {
                const totalLiquidity = inst.snbSightDeposit + inst.wChfBalance;
                return (
                  <tr key={inst.id} className="hover:bg-slate-800/40 transition">
                    <td className="py-2.5 px-3 font-bold text-white">{inst.name}</td>
                    <td className="py-2.5 px-3 text-blue-400 font-bold">{inst.code}</td>
                    <td className="py-2.5 px-3">CHF {(inst.snbSightDeposit / 1e9).toFixed(2)}B</td>
                    <td className="py-2.5 px-3 font-bold text-emerald-400">
                      CHF {(inst.wChfBalance / 1e9).toFixed(2)}B
                    </td>
                    <td className="py-2.5 px-3 text-cyan-400">
                      CHF {(totalLiquidity / 1e9).toFixed(2)}B
                    </td>
                    <td className="py-2.5 px-3">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          inst.status === 'ACTIVE'
                            ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                            : 'bg-red-950 text-red-300 border border-red-800'
                        }`}
                      >
                        {inst.status}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      <button
                        onClick={() => freezeAccount(inst.id)}
                        className={`px-2 py-1 rounded text-[11px] font-bold transition flex items-center gap-1 ml-auto ${
                          inst.status === 'FROZEN'
                            ? 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                            : 'bg-red-950/80 text-red-300 hover:bg-red-900 border border-red-800/60'
                        }`}
                      >
                        <Lock className="w-3 h-3" />
                        {inst.status === 'FROZEN' ? 'UNFREEZE' : 'FREEZE'}
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
