import React from 'react';
import { useSimulationStore } from '../../simulation/simulationEngine';
import { translations } from '../../i18n/translations';
import { Network, Server, ShieldCheck, Activity, Power } from 'lucide-react';

export const DltPlatformView: React.FC = () => {
  const { dltNodes, toggleDltNode, blockHeight, language } = useSimulationStore();
  const t = translations[language] || translations.en;

  return (
    <div className="space-y-6">
      <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Network className="w-5 h-5 text-indigo-400" />
            <h2 className="text-lg font-bold font-serif text-white tracking-wide">
              DLT FINANCIAL MARKET INFRASTRUCTURE PLATFORM
            </h2>
          </div>
          <p className="text-xs font-mono text-slate-400 mt-1">
            Permissioned Consensus Nodes, Cryptographic State Transitions & Finality Verification
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="bg-indigo-950 text-indigo-300 border border-indigo-800 px-3 py-1.5 rounded">
            CURRENT BLOCK: #{blockHeight}
          </span>
          <span className="bg-emerald-950 text-emerald-300 border border-emerald-800 px-3 py-1.5 rounded">
            CONSENSUS: PBFT FINALITY
          </span>
        </div>
      </div>

      {/* Nodes Network Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 font-mono text-xs">
        {dltNodes.map((node) => (
          <div
            key={node.id}
            className={`p-5 rounded-lg border transition space-y-4 ${
              node.status === 'ONLINE'
                ? 'bg-slate-900 border-slate-800'
                : 'bg-red-950/20 border-red-800/80'
            }`}
          >
            <div className="flex items-start justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-sm font-bold text-white font-serif">{node.name}</h3>
                <span className="text-[11px] text-indigo-400">{node.role}</span>
              </div>

              <span
                className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                  node.status === 'ONLINE'
                    ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                    : 'bg-red-950 text-red-300 border border-red-800'
                }`}
              >
                {node.status}
              </span>
            </div>

            <div className="space-y-2 text-slate-300">
              <div className="flex justify-between">
                <span className="text-slate-400">Node Latency:</span>
                <span className="text-emerald-400 font-bold">{node.latencyMs} ms</span>
              </div>

              <div className="flex justify-between">
                <span className="text-slate-400">Synced Block Height:</span>
                <span className="text-slate-200">#{node.blockHeight}</span>
              </div>

              <div className="flex justify-between">
                <span className="text-slate-400">Connected Peers:</span>
                <span className="text-blue-400 font-bold">{node.peersCount} Nodes</span>
              </div>

              <div className="flex justify-between">
                <span className="text-slate-400">Total Tx Processed:</span>
                <span className="text-white font-bold">{node.txProcessed.toLocaleString()}</span>
              </div>
            </div>

            <button
              onClick={() => toggleDltNode(node.id)}
              className={`w-full py-2 rounded font-bold transition flex items-center justify-center gap-2 ${
                node.status === 'ONLINE'
                  ? 'bg-red-950/80 hover:bg-red-900 text-red-300 border border-red-800/60'
                  : 'bg-emerald-950/80 hover:bg-emerald-900 text-emerald-300 border border-emerald-800/60'
              }`}
            >
              <Power className="w-3.5 h-3.5" />
              {node.status === 'ONLINE' ? 'TAKE NODE OFFLINE' : 'RESTORE NODE'}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};
