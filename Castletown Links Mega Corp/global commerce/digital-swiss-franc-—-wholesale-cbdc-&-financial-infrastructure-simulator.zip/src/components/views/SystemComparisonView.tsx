import React from 'react';
import { useSimulationStore } from '../../simulation/simulationEngine';
import { translations } from '../../i18n/translations';
import { Scale, CheckCircle2, ArrowRightLeft } from 'lucide-react';

export const SystemComparisonView: React.FC = () => {
  const { language } = useSimulationStore();
  const t = translations[language] || translations.en;

  const comparisons = [
    {
      dimension: 'Central-Bank Money Location',
      modelA: 'Directly on DLT platform as Wholesale CBDC token (wCHF)',
      modelB: 'Inside traditional Swiss Interbank Clearing (SIC) RTGS sight deposits',
    },
    {
      dimension: 'Atomicity Mechanism',
      modelA: 'Single smart-contract atomic swap on DLT platform',
      modelB: 'Two-phase lock & commit with RTGS Link bridge',
    },
    {
      dimension: 'Principal Risk Elimination',
      modelA: 'Complete cryptographic zero principal risk',
      modelB: 'Complete zero principal risk backed by atomic rollback',
    },
    {
      dimension: 'SNB Operational Scope',
      modelA: 'SNB operates/issues wCHF directly on third-party financial DLT',
      modelB: 'SNB retains cash inside existing SIC RTGS infrastructure',
    },
    {
      dimension: 'Settlement Latency',
      modelA: 'Sub-second (Instant DLT block finality ~0.4s)',
      modelB: 'RTGS roundtrip latency (~0.71s - 1.2s)',
    },
    {
      dimension: 'Cross-Border Interoperability',
      modelA: 'Native multi-asset atomic swaps (mBridge, Project Mariana)',
      modelB: 'Requires cross-system messaging bridges',
    },
  ];

  return (
    <div className="space-y-6 font-mono text-xs">
      <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Scale className="w-5 h-5 text-purple-400" />
            <h2 className="text-lg font-bold font-serif text-white tracking-wide">
              HELVETIA MODEL A vs MODEL B ARCHITECTURAL BENCHMARK
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Comparative Engineering Matrix of Integrated DLT vs Synchronised RTGS Settlement
          </p>
        </div>
      </div>

      <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-4">
        <h3 className="text-sm font-bold text-white font-serif border-b border-slate-800 pb-2">
          ENGINEERING COMPARISON MATRIX
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 text-[11px]">
                <th className="py-3 px-4 w-1/4">ARCHITECTURAL DIMENSION</th>
                <th className="py-3 px-4 w-3/8 text-blue-400 font-bold">MODEL A (INTEGRATED wCHF)</th>
                <th className="py-3 px-4 w-3/8 text-cyan-400 font-bold">MODEL B (SYNCHRONISED RTGS)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {comparisons.map((c) => (
                <tr key={c.dimension} className="hover:bg-slate-800/40 transition">
                  <td className="py-3 px-4 font-bold text-white">{c.dimension}</td>
                  <td className="py-3 px-4 text-slate-200 border-l border-slate-800/60">{c.modelA}</td>
                  <td className="py-3 px-4 text-slate-200 border-l border-slate-800/60">{c.modelB}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
