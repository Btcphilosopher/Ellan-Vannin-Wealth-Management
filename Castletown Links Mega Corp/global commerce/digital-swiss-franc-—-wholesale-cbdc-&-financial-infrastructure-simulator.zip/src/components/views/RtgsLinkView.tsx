import React from 'react';
import { useSimulationStore } from '../../simulation/simulationEngine';
import { translations } from '../../i18n/translations';
import { Radio, Activity, AlertTriangle, RefreshCw, RadioTower } from 'lucide-react';

export const RtgsLinkView: React.FC = () => {
  const { rtgsLinkStatus, rtgsLinkLatencyMs, setRtgsLinkState, language } = useSimulationStore();
  const t = translations[language] || translations.en;

  return (
    <div className="space-y-6 font-mono text-xs">
      <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Radio className="w-5 h-5 text-rose-400" />
            <h2 className="text-lg font-bold font-serif text-white tracking-wide">
              RTGS LINK SYNCHRONISATION GATEWAY
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Interoperability Bridge Connecting DLT Asset Ledger with SIC RTGS Central-Bank Money
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setRtgsLinkState('OPERATIONAL', 0.71)}
            className="bg-emerald-950 hover:bg-emerald-900 text-emerald-300 font-bold px-3 py-1.5 rounded border border-emerald-800 transition"
          >
            SET OPERATIONAL (0.71s)
          </button>
          <button
            onClick={() => setRtgsLinkState('DEGRADED', 2500)}
            className="bg-amber-950 hover:bg-amber-900 text-amber-300 font-bold px-3 py-1.5 rounded border border-amber-800 transition"
          >
            SET DEGRADED (2.5s)
          </button>
          <button
            onClick={() => setRtgsLinkState('DISCONNECTED', 99999)}
            className="bg-red-950 hover:bg-red-900 text-red-300 font-bold px-3 py-1.5 rounded border border-red-800 transition"
          >
            DISCONNECT LINK
          </button>
        </div>
      </div>

      {/* Gateway State Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-2">
          <span className="text-slate-400 text-[11px]">GATEWAY STATUS</span>
          <div className="text-xl font-bold text-white flex items-center gap-2">
            <RadioTower className={`w-5 h-5 ${rtgsLinkStatus === 'OPERATIONAL' ? 'text-emerald-400' : 'text-red-400'}`} />
            <span className={rtgsLinkStatus === 'OPERATIONAL' ? 'text-emerald-400' : 'text-red-400'}>
              {rtgsLinkStatus}
            </span>
          </div>
          <p className="text-slate-400 text-[11px]">ISO 20022 Financial Messaging Engine</p>
        </div>

        <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-2">
          <span className="text-slate-400 text-[11px]">RTGS LINK LATENCY</span>
          <div className="text-xl font-bold text-white">
            {rtgsLinkStatus === 'DISCONNECTED' ? 'TIMEOUT (∞)' : `${rtgsLinkLatencyMs} ms`}
          </div>
          <p className="text-slate-400 text-[11px]">Two-Phase Lock Roundtrip Time</p>
        </div>

        <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-2">
          <span className="text-slate-400 text-[11px]">MESSAGE DISPATCH THROUGHPUT</span>
          <div className="text-xl font-bold text-cyan-400">
            {rtgsLinkStatus === 'OPERATIONAL' ? '1,420 msgs/sec' : '0 msgs/sec'}
          </div>
          <p className="text-slate-400 text-[11px]">Cryptographic State Confirmations</p>
        </div>
      </div>
    </div>
  );
};
