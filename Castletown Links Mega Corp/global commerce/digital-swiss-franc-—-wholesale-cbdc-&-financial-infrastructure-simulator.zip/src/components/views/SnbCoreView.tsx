import React from 'react';
import { useSimulationStore } from '../../simulation/simulationEngine';
import { translations } from '../../i18n/translations';
import { Landmark, Scale, CheckCircle2, Coins, ArrowDownUp } from 'lucide-react';

export const SnbCoreView: React.FC = () => {
  const { snbBalanceSheet, language } = useSimulationStore();
  const t = translations[language] || translations.en;

  const totalAssets =
    snbBalanceSheet.assets.swissGovSecurities +
    snbBalanceSheet.assets.foreignCurrencyInvestments +
    snbBalanceSheet.assets.repoAssets +
    snbBalanceSheet.assets.loansToBanks +
    snbBalanceSheet.assets.otherAssets;

  const totalLiabilities =
    snbBalanceSheet.liabilities.sightDeposits +
    snbBalanceSheet.liabilities.banknotesInCirculation +
    snbBalanceSheet.liabilities.wholesaleCbdcOutstanding +
    snbBalanceSheet.liabilities.otherLiabilities;

  const totalEquity = snbBalanceSheet.equity.capitalAndReserves;
  const totalLiabEquity = totalLiabilities + totalEquity;

  const isBalanced = Math.abs(totalAssets - totalLiabEquity) < 1;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Landmark className="w-5 h-5 text-red-500" />
            <h2 className="text-lg font-bold font-serif text-white tracking-wide">
              SCHWEIZERISCHE NATIONALBANK · BALANCE SHEET CORE
            </h2>
          </div>
          <p className="text-xs font-mono text-slate-400 mt-1">
            Simulated Central-Bank Double-Entry Ledger Engine & Statutory Capital Reserves
          </p>
        </div>

        {/* Balance Integrity Status Indicator */}
        <div
          className={`flex items-center gap-2 px-3 py-1.5 rounded font-mono text-xs border ${
            isBalanced
              ? 'bg-emerald-950/80 text-emerald-300 border-emerald-800'
              : 'bg-red-950/80 text-red-300 border-red-800'
          }`}
        >
          <Scale className="w-4 h-4" />
          <span>EQUATION: <strong>ASSETS = LIABILITIES + EQUITY</strong></span>
          {isBalanced && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
        </div>
      </div>

      {/* Balance Sheet T-Account Table */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 font-mono text-xs">
        {/* ASSETS COLUMN */}
        <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-blue-400 font-serif">ASSETS (AKTIVA)</h3>
            <span className="text-sm font-bold text-white">
              CHF {(totalAssets / 1_000_000_000).toFixed(2)}B
            </span>
          </div>

          <div className="space-y-2 text-slate-300">
            <div className="flex justify-between p-2.5 bg-slate-950 rounded border border-slate-800">
              <span>Swiss Government Securities</span>
              <span className="font-bold text-white">
                CHF {(snbBalanceSheet.assets.swissGovSecurities / 1_000_000_000).toFixed(2)}B
              </span>
            </div>

            <div className="flex justify-between p-2.5 bg-slate-950 rounded border border-slate-800">
              <span>Foreign Currency Investments</span>
              <span className="font-bold text-white">
                CHF {(snbBalanceSheet.assets.foreignCurrencyInvestments / 1_000_000_000).toFixed(2)}B
              </span>
            </div>

            <div className="flex justify-between p-2.5 bg-slate-950 rounded border border-slate-800">
              <span>Repo Claims & Monetary Assets</span>
              <span className="font-bold text-white">
                CHF {(snbBalanceSheet.assets.repoAssets / 1_000_000_000).toFixed(2)}B
              </span>
            </div>

            <div className="flex justify-between p-2.5 bg-slate-950 rounded border border-slate-800">
              <span>Loans to Financial Institutions</span>
              <span className="font-bold text-white">
                CHF {(snbBalanceSheet.assets.loansToBanks / 1_000_000_000).toFixed(2)}B
              </span>
            </div>

            <div className="flex justify-between p-2.5 bg-slate-950 rounded border border-slate-800">
              <span>Other Central Bank Assets</span>
              <span className="font-bold text-white">
                CHF {(snbBalanceSheet.assets.otherAssets / 1_000_000_000).toFixed(2)}B
              </span>
            </div>
          </div>
        </div>

        {/* LIABILITIES & EQUITY COLUMN */}
        <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-rose-400 font-serif">LIABILITIES & EQUITY (PASSIVA)</h3>
            <span className="text-sm font-bold text-white">
              CHF {(totalLiabEquity / 1_000_000_000).toFixed(2)}B
            </span>
          </div>

          <div className="space-y-2 text-slate-300">
            {/* Highlight Wholesale CBDC as SNB Liability */}
            <div className="flex justify-between p-2.5 bg-emerald-950/40 rounded border border-emerald-800/80">
              <span className="flex items-center gap-1.5 font-bold text-emerald-300">
                <Coins className="w-3.5 h-3.5 text-emerald-400" />
                Wholesale CBDC Outstanding (wCHF)
              </span>
              <span className="font-bold text-emerald-300">
                CHF {(snbBalanceSheet.liabilities.wholesaleCbdcOutstanding / 1_000_000_000).toFixed(2)}B
              </span>
            </div>

            <div className="flex justify-between p-2.5 bg-slate-950 rounded border border-slate-800">
              <span>Sight Deposits (Commercial Banks at SNB)</span>
              <span className="font-bold text-white">
                CHF {(snbBalanceSheet.liabilities.sightDeposits / 1_000_000_000).toFixed(2)}B
              </span>
            </div>

            <div className="flex justify-between p-2.5 bg-slate-950 rounded border border-slate-800">
              <span>Banknotes in Circulation</span>
              <span className="font-bold text-white">
                CHF {(snbBalanceSheet.liabilities.banknotesInCirculation / 1_000_000_000).toFixed(2)}B
              </span>
            </div>

            <div className="flex justify-between p-2.5 bg-slate-950 rounded border border-slate-800">
              <span>Other Liabilities</span>
              <span className="font-bold text-white">
                CHF {(snbBalanceSheet.liabilities.otherLiabilities / 1_000_000_000).toFixed(2)}B
              </span>
            </div>

            <div className="flex justify-between p-2.5 bg-slate-900 rounded border border-amber-800/60 font-bold text-amber-300 mt-2">
              <span>Equity Capital & Statutory Reserves</span>
              <span>
                CHF {(snbBalanceSheet.equity.capitalAndReserves / 1_000_000_000).toFixed(2)}B
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* SNB Institutional Monograph Note */}
      <div className="bg-slate-900 p-4 rounded-lg border border-slate-800 text-xs font-mono text-slate-400 leading-relaxed">
        <p>
          <strong>MONETARY AUTHORITY PRINCIPLE:</strong> The Wholesale Digital Swiss Franc (wCHF) is created directly on the DLT ledger as a direct central-bank liability of the Schweizerische Nationalbank. When a financial institution converts traditional SNB sight deposits into wCHF, SNB sight deposit liabilities decrease while wCHF liabilities increase by the exact identical amount, preserving total balance sheet volume and double-entry accounting integrity.
        </p>
      </div>
    </div>
  );
};
