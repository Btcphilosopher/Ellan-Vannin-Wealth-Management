import React from 'react';
import { useSimulationStore } from '../../simulation/simulationEngine';
import { translations } from '../../i18n/translations';
import { Globe2, ArrowRightLeft, ShieldCheck } from 'lucide-react';

export const CrossBorderView: React.FC = () => {
  const { language } = useSimulationStore();
  const t = translations[language] || translations.en;

  const corridors = [
    { pair: 'wCHF / wEUR', rate: 1.0425, status: 'ACTIVE', volume: 'CHF 4.2B', protocol: 'mBridge PvP' },
    { pair: 'wCHF / wUSD', rate: 1.1380, status: 'ACTIVE', volume: 'CHF 8.7B', protocol: 'mBridge PvP' },
    { pair: 'wCHF / wGBP', rate: 0.8910, status: 'ACTIVE', volume: 'CHF 2.1B', protocol: 'Project Mariana' },
    { pair: 'wCHF / wJPY', rate: 172.45, status: 'EXPERIMENTAL', volume: 'CHF 650M', protocol: 'Atomic Swap' },
  ];

  return (
    <div className="space-y-6 font-mono text-xs">
      <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Globe2 className="w-5 h-5 text-cyan-400" />
            <h2 className="text-lg font-bold font-serif text-white tracking-wide">
              CROSS-BORDER MULTI-CBDC SETTLEMENT CORRIDORS
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Payment-versus-Payment (PvP) Interoperability with Foreign Wholesale CBDC Networks
          </p>
        </div>

        <div className="bg-slate-950 px-3 py-1.5 rounded border border-slate-800 text-slate-300">
          Corridor Protocol: <strong className="text-cyan-400 font-bold">Project Mariana AMM & mBridge</strong>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {corridors.map((c) => (
          <div key={c.pair} className="bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-3">
            <div className="flex justify-between items-center border-b border-slate-800 pb-2">
              <h3 className="text-sm font-bold text-white font-serif">{c.pair}</h3>
              <span className="bg-cyan-950 text-cyan-300 px-2 py-0.5 rounded text-[10px] border border-cyan-800 font-bold">
                {c.protocol}
              </span>
            </div>

            <div className="space-y-1 text-slate-300">
              <div className="flex justify-between">
                <span className="text-slate-400">Indicative FX Rate:</span>
                <span className="text-emerald-400 font-bold">{c.rate}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">24h Settlement Volume:</span>
                <span className="text-white font-bold">{c.volume}</span>
              </div>
              <div className="flex justify-between border-t border-slate-800 pt-1">
                <span className="text-slate-400">PvP Settlement Finality:</span>
                <span className="text-emerald-300 font-bold">ATOMIC DLT SWAP</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
