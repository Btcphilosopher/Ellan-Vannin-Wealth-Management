import React from 'react';
import { useSimulationStore } from '../../simulation/simulationEngine';
import { translations } from '../../i18n/translations';
import { ShieldAlert, AlertTriangle, Activity, RefreshCw } from 'lucide-react';

export const FinancialStabilityView: React.FC = () => {
  const {
    institutions,
    injectLiquidityShock,
    defaultCounterparty,
    setRtgsLinkState,
    runRecoveryEngine,
    language,
  } = useSimulationStore();

  const t = translations[language] || translations.en;

  const stressedCount = institutions.filter((i) => i.status !== 'ACTIVE').length;

  return (
    <div className="space-y-6 font-mono text-xs">
      <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-red-400" />
            <h2 className="text-lg font-bold font-serif text-white tracking-wide">
              FINANCIAL STABILITY MONITOR & SYSTEMIC STRESS LAB
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Macroprudential Stress Testing of Tokenised Settlement Infrastructures
          </p>
        </div>

        <button
          onClick={runRecoveryEngine}
          className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-4 py-2 rounded transition flex items-center gap-2 shadow-xs"
        >
          <RefreshCw className="w-4 h-4" />
          EXECUTE SYSTEM RECOVERY
        </button>
      </div>

      {/* Stress Scenario Trigger Dashboard */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-3">
          <h3 className="text-sm font-bold text-amber-400 font-serif">1. BANK LIQUIDITY SHOCK</h3>
          <p className="text-slate-400 text-[11px]">
            Simulate sudden 3.0 Billion wCHF liquidity withdrawal from AlpenBank AG.
          </p>
          <button
            onClick={() => injectLiquidityShock(institutions[0]?.id, 3_000_000_000)}
            className="w-full bg-amber-950 hover:bg-amber-900 text-amber-300 font-bold py-2 rounded border border-amber-800 transition"
          >
            RUN LIQUIDITY SHOCK
          </button>
        </div>

        <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-3">
          <h3 className="text-sm font-bold text-rose-400 font-serif">2. RTGS LINK FAILURE</h3>
          <p className="text-slate-400 text-[11px]">
            Disconnect the RTGS Link bridge between DLT and Swiss Interbank Clearing.
          </p>
          <button
            onClick={() => setRtgsLinkState('DISCONNECTED', 99999)}
            className="w-full bg-red-950 hover:bg-red-900 text-red-300 font-bold py-2 rounded border border-red-800 transition"
          >
            TRIGGER RTGS LINK OUTAGE
          </button>
        </div>

        <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-3">
          <h3 className="text-sm font-bold text-red-500 font-serif">3. COUNTERPARTY DEFAULT</h3>
          <p className="text-slate-400 text-[11px]">
            Simulate counterparty insolvency and trading suspension for Zurich Capital Bank.
          </p>
          <button
            onClick={() => defaultCounterparty(institutions[2]?.id)}
            className="w-full bg-red-950 hover:bg-red-900 text-red-300 font-bold py-2 rounded border border-red-800 transition"
          >
            TRIGGER COUNTERPARTY DEFAULT
          </button>
        </div>
      </div>
    </div>
  );
};
