import React from 'react';
import { useSimulationStore } from '../../simulation/simulationEngine';
import { translations } from '../../i18n/translations';
import { Layers, Briefcase, Radio, Zap, ArrowRight, RotateCcw } from 'lucide-react';

export const HelvetiaModelBView: React.FC = () => {
  const { dvpTransactions, rtgsLinkStatus, rtgsLinkLatencyMs, language } = useSimulationStore();
  const t = translations[language] || translations.en;

  const modelBTx = dvpTransactions.filter((t) => t.model === 'MODEL_B_SYNCHRONISED');

  return (
    <div className="space-y-6">
      <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-cyan-400" />
            <h2 className="text-lg font-bold font-serif text-white tracking-wide">
              PROJECT HELVETIA · MODEL B: RTGS-LINKED SYNCHRONISED SETTLEMENT
            </h2>
          </div>
          <p className="text-xs font-mono text-slate-400 mt-1">
            Tokenised Assets on DLT Synchronised with Central-Bank Cash Leg in Swiss Interbank Clearing (SIC)
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span
            className={`px-3 py-1.5 rounded font-bold border ${
              rtgsLinkStatus === 'OPERATIONAL'
                ? 'bg-emerald-950 text-emerald-300 border-emerald-800'
                : 'bg-red-950 text-red-300 border-red-800'
            }`}
          >
            RTGS LINK: {rtgsLinkStatus} ({rtgsLinkLatencyMs} ms)
          </span>
        </div>
      </div>

      {/* Model B Architectural Flow Diagram */}
      <div className="bg-slate-900 p-6 rounded-lg border border-slate-800 space-y-6 font-mono text-xs">
        <h3 className="text-sm font-bold text-white font-serif border-b border-slate-800 pb-2">
          SYNCHRONISED SETTLEMENT PIPELINE (DLT ↕ RTGS LINK ↕ SIC)
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-3 text-center items-center">
          <div className="bg-slate-950 p-3 rounded border border-blue-900/80 space-y-1">
            <Briefcase className="w-5 h-5 text-blue-400 mx-auto" />
            <h4 className="font-bold text-white">DLT ASSET LOCK</h4>
            <p className="text-[10px] text-slate-400">Tokens locked on SDX</p>
          </div>

          <ArrowRight className="w-4 h-4 text-slate-500 mx-auto hidden md:block" />

          <div className="bg-slate-950 p-3 rounded border border-rose-900/80 space-y-1">
            <Radio className="w-5 h-5 text-rose-400 mx-auto" />
            <h4 className="font-bold text-white">RTGS LINK BRIDGE</h4>
            <p className="text-[10px] text-slate-400">2-Phase Lock Msg</p>
          </div>

          <ArrowRight className="w-4 h-4 text-slate-500 mx-auto hidden md:block" />

          <div className="bg-slate-950 p-3 rounded border border-amber-900/80 space-y-1">
            <Zap className="w-5 h-5 text-amber-400 mx-auto" />
            <h4 className="font-bold text-white">SIC RTGS CASH</h4>
            <p className="text-[10px] text-slate-400">SNB Sight Balance</p>
          </div>
        </div>

        <div className="bg-slate-950 p-4 rounded border border-slate-800 leading-relaxed text-slate-300">
          <h4 className="font-bold text-white mb-1">ENGINEERING CHARACTERISTICS OF MODEL B:</h4>
          <ul className="list-disc list-inside space-y-1 text-slate-400">
            <li><strong>Preserves Existing RTGS Architecture:</strong> SNB cash remains inside traditional Swiss Interbank Clearing (SIC).</li>
            <li><strong>Interoperability:</strong> Enables tokenised asset platforms to settle without requiring cash on the DLT platform.</li>
            <li><strong>Atomic Rollback Protection:</strong> If cash settlement fails in SIC or the RTGS Link message times out, asset tokens are automatically unlocked and returned on DLT.</li>
          </ul>
        </div>
      </div>

      {/* Model B Transaction History */}
      <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 font-mono text-xs space-y-3">
        <h3 className="text-sm font-bold text-white font-serif border-b border-slate-800 pb-2">
          EXECUTED MODEL B SYNCHRONISED TRANSACTIONS ({modelBTx.length})
        </h3>

        {modelBTx.length === 0 ? (
          <p className="text-slate-500 py-4 text-center">No Model B transactions executed yet. Use the DVP Engine tab to execute one.</p>
        ) : (
          <div className="space-y-2">
            {modelBTx.map((tx) => (
              <div key={tx.id} className="p-3 bg-slate-950 rounded border border-slate-800 flex justify-between items-center">
                <div>
                  <span className="font-bold text-cyan-400">{tx.id}</span>
                  <span className="text-slate-400 ml-3">Asset: {tx.assetIsin} ({tx.assetAmount} units)</span>
                  {tx.sicReference && (
                    <span className="text-amber-400 text-[10px] ml-3 font-bold">SIC Ref: {tx.sicReference}</span>
                  )}
                </div>
                <div className="flex items-center gap-4">
                  <span className="font-bold text-emerald-400">CHF {tx.totalCashValue.toLocaleString()}</span>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      tx.status === 'SETTLED'
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                        : 'bg-red-950 text-red-300 border border-red-800'
                    }`}
                  >
                    {tx.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
