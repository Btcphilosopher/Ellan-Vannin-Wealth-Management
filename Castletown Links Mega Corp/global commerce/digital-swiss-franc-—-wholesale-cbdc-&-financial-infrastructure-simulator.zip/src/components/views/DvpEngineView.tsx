import React, { useState } from 'react';
import { useSimulationStore } from '../../simulation/simulationEngine';
import { translations } from '../../i18n/translations';
import { SettlementModel } from '../../types/simulation';
import { GitCommit, ArrowRight, CheckCircle2, XCircle, ShieldCheck, Workflow, Layers } from 'lucide-react';

export const DvpEngineView: React.FC = () => {
  const { institutions, tokenisedAssets, dvpTransactions, executeDvp, language } = useSimulationStore();
  const t = translations[language] || translations.en;

  const [model, setModel] = useState<SettlementModel>('MODEL_A_INTEGRATED');
  const [buyerId, setBuyerId] = useState(institutions[0]?.id || '');
  const [sellerId, setSellerId] = useState(institutions[1]?.id || '');
  const [selectedIsin, setSelectedIsin] = useState(tokenisedAssets[0]?.isin || '');
  const [amountUnits, setAmountUnits] = useState('1000000'); // 1M units

  const [lastTxResult, setLastTxResult] = useState<any | null>(null);

  const handleExecuteTrade = () => {
    const units = parseFloat(amountUnits);
    if (!units || units <= 0) return;

    const res = executeDvp({
      model,
      buyerId,
      sellerId,
      assetIsin: selectedIsin,
      assetAmount: units,
    });

    setLastTxResult(res);
  };

  const asset = tokenisedAssets.find((a) => a.isin === selectedIsin);
  const calculatedCashVal = asset ? (parseFloat(amountUnits || '0') * (asset.nominalValue / 10000) * asset.unitPrice) / 100 : 0;

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <GitCommit className="w-5 h-5 text-purple-400" />
            <h2 className="text-lg font-bold font-serif text-white tracking-wide">
              ATOMIC DELIVERY-VERSUS-PAYMENT (DVP) ENGINE
            </h2>
          </div>
          <p className="text-xs font-mono text-slate-400 mt-1">
            Guaranteed Simultaneous Atomic Settlement of Tokenised Securities & Central Bank Money
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="bg-purple-950 text-purple-300 border border-purple-800 px-3 py-1.5 rounded">
            ZERO PRINCIPAL RISK
          </span>
        </div>
      </div>

      {/* Trade Construction Workbench */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 font-mono text-xs">
        {/* Input Parameters */}
        <div className="lg:col-span-1 bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-4">
          <h3 className="text-sm font-bold text-white font-serif border-b border-slate-800 pb-2">
            NEW DVP TRADE INSTRUCTION
          </h3>

          <div className="space-y-3">
            <div>
              <label className="block text-slate-400 text-xs mb-1">SETTLEMENT ARCHITECTURE MODEL</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setModel('MODEL_A_INTEGRATED')}
                  className={`p-2 rounded font-bold text-center border text-[11px] transition ${
                    model === 'MODEL_A_INTEGRATED'
                      ? 'bg-blue-600 text-white border-blue-500'
                      : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                  }`}
                >
                  MODEL A (wCHF on DLT)
                </button>
                <button
                  type="button"
                  onClick={() => setModel('MODEL_B_SYNCHRONISED')}
                  className={`p-2 rounded font-bold text-center border text-[11px] transition ${
                    model === 'MODEL_B_SYNCHRONISED'
                      ? 'bg-cyan-600 text-white border-cyan-500'
                      : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                  }`}
                >
                  MODEL B (SIC RTGS Link)
                </button>
              </div>
            </div>

            <div>
              <label className="block text-slate-400 text-xs mb-1">BUYER (CASH PAYER)</label>
              <select
                value={buyerId}
                onChange={(e) => setBuyerId(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-white text-xs"
              >
                {institutions.map((i) => (
                  <option key={i.id} value={i.id}>
                    {i.name} ({i.code}) — wCHF: {(i.wChfBalance / 1e9).toFixed(1)}B | Sight: {(i.snbSightDeposit / 1e9).toFixed(1)}B
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-400 text-xs mb-1">SELLER (ASSET DELIVERER)</label>
              <select
                value={sellerId}
                onChange={(e) => setSellerId(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-white text-xs"
              >
                {institutions.map((i) => (
                  <option key={i.id} value={i.id}>
                    {i.name} ({i.code})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-400 text-xs mb-1">TOKENISED ASSET ISIN</label>
              <select
                value={selectedIsin}
                onChange={(e) => setSelectedIsin(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-white text-xs"
              >
                {tokenisedAssets.map((a) => (
                  <option key={a.isin} value={a.isin}>
                    {a.symbol} — {a.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-400 text-xs mb-1">UNITS AMOUNT</label>
              <input
                type="number"
                value={amountUnits}
                onChange={(e) => setAmountUnits(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-white font-bold text-xs"
              />
            </div>

            <div className="bg-slate-950 p-2.5 rounded border border-slate-800 text-slate-300 space-y-1">
              <div className="flex justify-between">
                <span>Calculated Cash Value:</span>
                <span className="font-bold text-emerald-400">
                  CHF {calculatedCashVal.toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between text-[11px] text-slate-400">
                <span>Settlement Currency:</span>
                <span>{model === 'MODEL_A_INTEGRATED' ? 'wCHF Token' : 'SIC RTGS Sight Money'}</span>
              </div>
            </div>

            <button
              onClick={handleExecuteTrade}
              className="w-full flex items-center justify-center gap-2 bg-purple-700 hover:bg-purple-600 text-white font-bold py-3 rounded transition shadow-xs mt-2"
            >
              <GitCommit className="w-4 h-4" />
              {t.executeDvp}
            </button>
          </div>
        </div>

        {/* Live Execution State Visualizer */}
        <div className="lg:col-span-2 bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-4">
          <h3 className="text-sm font-bold text-white font-serif border-b border-slate-800 pb-2">
            ATOMIC SETTLEMENT EXECUTION PIPELINE
          </h3>

          {lastTxResult ? (
            <div className="space-y-4">
              <div
                className={`p-4 rounded border ${
                  lastTxResult.status === 'SETTLED'
                    ? 'bg-emerald-950/60 border-emerald-800 text-emerald-300'
                    : 'bg-red-950/60 border-red-800 text-red-300'
                }`}
              >
                <div className="flex items-center justify-between font-bold">
                  <span>TX REF: {lastTxResult.id}</span>
                  <span className="px-2 py-0.5 rounded text-[10px] bg-slate-900 border border-slate-700">
                    {lastTxResult.status}
                  </span>
                </div>
                {lastTxResult.failureReason && (
                  <p className="mt-2 text-xs font-mono text-red-300">
                    REJECTION REASON: {lastTxResult.failureReason}
                  </p>
                )}
                {lastTxResult.txHashDLT && (
                  <p className="mt-1 text-[11px] font-mono text-slate-400">
                    DLT Tx Hash: <strong className="text-blue-300">{lastTxResult.txHashDLT}</strong>
                  </p>
                )}
                {lastTxResult.sicReference && (
                  <p className="mt-0.5 text-[11px] font-mono text-slate-400">
                    SIC Reference: <strong className="text-cyan-300">{lastTxResult.sicReference}</strong>
                  </p>
                )}
              </div>

              {/* State Machine Steps */}
              <div className="space-y-2">
                {lastTxResult.statusSteps?.map((step: any, idx: number) => (
                  <div
                    key={idx}
                    className="flex items-center justify-between p-3 bg-slate-950 rounded border border-slate-800"
                  >
                    <div className="flex items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-slate-800 flex items-center justify-center font-bold text-[10px]">
                        {idx + 1}
                      </span>
                      <span className="font-bold text-slate-200">{step.stepName}</span>
                    </div>

                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        step.status === 'COMPLETED'
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : step.status === 'FAILED'
                          ? 'bg-red-950 text-red-300 border border-red-800'
                          : 'bg-slate-900 text-slate-400'
                      }`}
                    >
                      {step.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="h-64 flex flex-col items-center justify-center text-slate-500 font-mono text-xs border border-dashed border-slate-800 rounded">
              <GitCommit className="w-8 h-8 text-slate-600 mb-2" />
              <span>Select trade parameters and execute DVP settlement.</span>
            </div>
          )}
        </div>
      </div>

      {/* DVP Settlement History Log */}
      <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-4 font-mono text-xs">
        <h3 className="text-sm font-bold text-white font-serif border-b border-slate-800 pb-2">
          DVP SETTLEMENT JOURNAL ({dvpTransactions.length} Transactions)
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 text-[11px]">
                <th className="py-2 px-3">TX ID</th>
                <th className="py-2 px-3">MODEL</th>
                <th className="py-2 px-3">BUYER</th>
                <th className="py-2 px-3">SELLER</th>
                <th className="py-2 px-3">ASSET</th>
                <th className="py-2 px-3">UNITS</th>
                <th className="py-2 px-3">CASH VALUE</th>
                <th className="py-2 px-3">STATUS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {dvpTransactions.map((tx) => (
                <tr key={tx.id} className="hover:bg-slate-800/40 transition">
                  <td className="py-2 px-3 font-bold text-purple-400">{tx.id}</td>
                  <td className="py-2 px-3">
                    <span
                      className={`px-1.5 py-0.5 rounded text-[10px] ${
                        tx.model === 'MODEL_A_INTEGRATED'
                          ? 'bg-blue-950 text-blue-300'
                          : 'bg-cyan-950 text-cyan-300'
                      }`}
                    >
                      {tx.model === 'MODEL_A_INTEGRATED' ? 'MODEL A' : 'MODEL B'}
                    </span>
                  </td>
                  <td className="py-2 px-3 font-bold text-white">
                    {institutions.find((i) => i.id === tx.buyerId)?.code || tx.buyerId}
                  </td>
                  <td className="py-2 px-3 font-bold text-white">
                    {institutions.find((i) => i.id === tx.sellerId)?.code || tx.sellerId}
                  </td>
                  <td className="py-2 px-3 text-slate-300">{tx.assetIsin}</td>
                  <td className="py-2 px-3">{tx.assetAmount.toLocaleString()}</td>
                  <td className="py-2 px-3 font-bold text-emerald-400">
                    CHF {tx.totalCashValue.toLocaleString()}
                  </td>
                  <td className="py-2 px-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        tx.status === 'SETTLED'
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : 'bg-red-950 text-red-300 border border-red-800'
                      }`}
                    >
                      {tx.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
