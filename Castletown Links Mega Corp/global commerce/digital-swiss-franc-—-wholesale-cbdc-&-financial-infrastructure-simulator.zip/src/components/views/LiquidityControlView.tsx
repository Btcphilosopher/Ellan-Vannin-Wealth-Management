import React from 'react';
import { useSimulationStore } from '../../simulation/simulationEngine';
import { translations } from '../../i18n/translations';
import { Activity, ShieldAlert, ArrowUpRight, TrendingDown } from 'lucide-react';

export const LiquidityControlView: React.FC = () => {
  const { institutions, language, injectLiquidityShock } = useSimulationStore();
  const t = translations[language] || translations.en;

  return (
    <div className="space-y-6 font-mono text-xs">
      <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-cyan-400" />
            <h2 className="text-lg font-bold font-serif text-white tracking-wide">
              INTRADAY LIQUIDITY CONTROL CENTER
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Real-Time Monitoring of SNB Sight Balances, wCHF Holdings & Payment Queue Prioritisation
          </p>
        </div>

        <div className="bg-slate-950 px-3 py-1.5 rounded border border-slate-800 text-slate-300">
          Liquidity Buffer Index: <strong className="text-emerald-400">98.4% (HEALTHY)</strong>
        </div>
      </div>

      {/* Liquidity Positions Table */}
      <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-4">
        <h3 className="text-sm font-bold text-white font-serif border-b border-slate-800 pb-2">
          PARTICIPANT LIQUIDITY BUFFER & STRESS TEST BENCHMARKS
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 text-[11px]">
                <th className="py-2.5 px-3">BANK</th>
                <th className="py-2.5 px-3">SIGHT BALANCE</th>
                <th className="py-2.5 px-3">wCHF DLT BALANCE</th>
                <th className="py-2.5 px-3">LIQUIDITY BUFFER</th>
                <th className="py-2.5 px-3">STRESS STATUS</th>
                <th className="py-2.5 px-3 text-right">ACTION</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {institutions.map((inst) => (
                <tr key={inst.id} className="hover:bg-slate-800/40 transition">
                  <td className="py-2.5 px-3 font-bold text-white">{inst.name}</td>
                  <td className="py-2.5 px-3 font-bold text-white">CHF {(inst.snbSightDeposit / 1e9).toFixed(2)}B</td>
                  <td className="py-2.5 px-3 font-bold text-emerald-400">CHF {(inst.wChfBalance / 1e9).toFixed(2)}B</td>
                  <td className="py-2.5 px-3 text-cyan-300">CHF {(inst.liquidityBuffer / 1e9).toFixed(2)}B</td>
                  <td className="py-2.5 px-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        inst.status === 'ACTIVE'
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : 'bg-amber-950 text-amber-300 border border-amber-800'
                      }`}
                    >
                      {inst.status}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-right">
                    <button
                      onClick={() => injectLiquidityShock(inst.id, 1_500_000_000)}
                      className="bg-amber-950 hover:bg-amber-900 text-amber-300 px-2.5 py-1 rounded text-[10px] font-bold border border-amber-800/60 transition"
                    >
                      INJECT SHOCK (-1.5B)
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
