import React from 'react';
import { useSimulationStore } from '../../simulation/simulationEngine';
import { translations } from '../../i18n/translations';
import { Repeat, Zap, CheckCircle2, Clock, AlertTriangle } from 'lucide-react';

export const SicSimulatorView: React.FC = () => {
  const { institutions, sicStatus, language } = useSimulationStore();
  const t = translations[language] || translations.en;

  // Synthetic queue items
  const queueItems = [
    {
      id: 'SIC-PAY-8801',
      time: '14:22:10',
      sender: 'AlpenBank AG (ALPA)',
      receiver: 'Helvetic Commercial Bank (HELV)',
      amount: 250_000_000,
      priority: 'HIGH',
      purpose: 'RTGS_LINK_SYNC',
      status: 'SETTLED',
    },
    {
      id: 'SIC-PAY-8802',
      time: '14:25:40',
      sender: 'Zurich Capital Bank (ZURC)',
      receiver: 'Lake Geneva Bank (LAKE)',
      amount: 120_000_000,
      priority: 'NORMAL',
      purpose: 'INTERBANK_PAYMENT',
      status: 'SETTLED',
    },
    {
      id: 'SIC-PAY-8803',
      time: '14:28:15',
      sender: 'Basel Financial (BASE)',
      receiver: 'Schweizerische Nationalbank',
      amount: 500_000_000,
      priority: 'HIGH',
      purpose: 'MONETARY_POLICY',
      status: 'SETTLED',
    },
    {
      id: 'SIC-PAY-8804',
      time: '14:30:00',
      sender: 'Leman Securities (LEMA)',
      receiver: 'Bern Cantonal Finance (BERN)',
      amount: 80_000_000,
      priority: 'NORMAL',
      purpose: 'RTGS_LINK_SYNC',
      status: 'QUEUED',
    },
  ];

  return (
    <div className="space-y-6">
      <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Repeat className="w-5 h-5 text-cyan-400" />
            <h2 className="text-lg font-bold font-serif text-white tracking-wide">
              SWISS INTERBANK CLEARING (SIC) / RTGS SIMULATOR
            </h2>
          </div>
          <p className="text-xs font-mono text-slate-400 mt-1">
            Real-Time Gross Settlement Queue Manager & SNB Sight Deposit Accounts
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="bg-cyan-950 text-cyan-300 border border-cyan-800 px-3 py-1.5 rounded">
            SIC SYSTEM STATUS: OPERATIONAL
          </span>
        </div>
      </div>

      {/* Sight Deposits Ledger Table */}
      <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 font-mono text-xs space-y-4">
        <h3 className="text-sm font-bold text-white font-serif border-b border-slate-800 pb-2">
          SIC RTGS PARTICIPANT SIGHT DEPOSIT ACCOUNTS
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 text-[11px]">
                <th className="py-2 px-3">PARTICIPANT</th>
                <th className="py-2 px-3">SIC CODE</th>
                <th className="py-2 px-3">SNB SIGHT BALANCE</th>
                <th className="py-2 px-3">INTRADAY CREDIT LIMIT</th>
                <th className="py-2 px-3">SETTLEMENT QUEUE</th>
                <th className="py-2 px-3">STATUS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {institutions.map((inst) => (
                <tr key={inst.id} className="hover:bg-slate-800/40 transition">
                  <td className="py-2 px-3 font-bold text-white">{inst.name}</td>
                  <td className="py-2 px-3 text-cyan-400 font-bold">{inst.code}</td>
                  <td className="py-2 px-3 font-bold text-emerald-400">
                    CHF {(inst.snbSightDeposit / 1e9).toFixed(2)}B
                  </td>
                  <td className="py-2 px-3 text-slate-300">
                    CHF {((inst.snbSightDeposit * 0.25) / 1e9).toFixed(2)}B
                  </td>
                  <td className="py-2 px-3 text-amber-300">{inst.settlementQueueCount} items</td>
                  <td className="py-2 px-3">
                    <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-950 text-emerald-300 font-bold border border-emerald-800">
                      ONLINE
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* SIC Payment Queue */}
      <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 font-mono text-xs space-y-4">
        <h3 className="text-sm font-bold text-white font-serif border-b border-slate-800 pb-2">
          SIC RTGS PAYMENT INSTRUCTION QUEUE
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 text-[11px]">
                <th className="py-2 px-3">TIME</th>
                <th className="py-2 px-3">INSTRUCTION ID</th>
                <th className="py-2 px-3">SENDER</th>
                <th className="py-2 px-3">RECEIVER</th>
                <th className="py-2 px-3">AMOUNT</th>
                <th className="py-2 px-3">PRIORITY</th>
                <th className="py-2 px-3">PURPOSE</th>
                <th className="py-2 px-3">STATUS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {queueItems.map((item) => (
                <tr key={item.id} className="hover:bg-slate-800/40 transition">
                  <td className="py-2 px-3 text-slate-400">{item.time}</td>
                  <td className="py-2 px-3 font-bold text-cyan-400">{item.id}</td>
                  <td className="py-2 px-3 text-white">{item.sender}</td>
                  <td className="py-2 px-3 text-white">{item.receiver}</td>
                  <td className="py-2 px-3 font-bold text-emerald-400">
                    CHF {item.amount.toLocaleString()}
                  </td>
                  <td className="py-2 px-3">
                    <span
                      className={`px-1.5 py-0.5 rounded text-[10px] ${
                        item.priority === 'HIGH' ? 'bg-amber-950 text-amber-300' : 'bg-slate-800 text-slate-300'
                      }`}
                    >
                      {item.priority}
                    </span>
                  </td>
                  <td className="py-2 px-3 text-purple-300">{item.purpose}</td>
                  <td className="py-2 px-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        item.status === 'SETTLED'
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : 'bg-amber-950 text-amber-300 border border-amber-800'
                      }`}
                    >
                      {item.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
