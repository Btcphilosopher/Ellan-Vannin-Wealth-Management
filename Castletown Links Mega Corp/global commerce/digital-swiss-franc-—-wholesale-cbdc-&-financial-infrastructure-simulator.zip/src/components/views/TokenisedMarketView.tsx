import React from 'react';
import { useSimulationStore } from '../../simulation/simulationEngine';
import { translations } from '../../i18n/translations';
import { Briefcase, CheckCircle2, ShieldCheck } from 'lucide-react';

export const TokenisedMarketView: React.FC = () => {
  const { tokenisedAssets, institutions, language } = useSimulationStore();
  const t = translations[language] || translations.en;

  return (
    <div className="space-y-6">
      <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Briefcase className="w-5 h-5 text-blue-400" />
            <h2 className="text-lg font-bold font-serif text-white tracking-wide">
              TOKENISED FINANCIAL ASSET MARKET
            </h2>
          </div>
          <p className="text-xs font-mono text-slate-400 mt-1">
            DVP-Eligible Tokenised Swiss Debt, Money Market & Central Bank Securities
          </p>
        </div>

        <div className="text-xs font-mono text-slate-400 bg-slate-950 px-3 py-1.5 rounded border border-slate-800">
          Total Market Volume: <strong className="text-blue-400">CHF 126.4B</strong>
        </div>
      </div>

      {/* Assets Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 font-mono text-xs">
        {tokenisedAssets.map((asset) => (
          <div key={asset.isin} className="bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-4">
            <div className="flex items-start justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-sm font-bold text-white font-serif">{asset.name}</h3>
                <span className="text-[11px] text-blue-400 font-bold">{asset.symbol}</span>
              </div>
              <span className="bg-slate-950 text-slate-300 px-2 py-0.5 rounded text-[10px] border border-slate-800">
                {asset.isin}
              </span>
            </div>

            <div className="space-y-2 text-slate-300">
              <div className="flex justify-between">
                <span className="text-slate-400">Issuer:</span>
                <span className="text-white font-bold">{asset.issuer}</span>
              </div>

              <div className="flex justify-between">
                <span className="text-slate-400">Nominal Issue:</span>
                <span className="text-white font-bold">CHF {(asset.nominalValue / 1e9).toFixed(2)}B</span>
              </div>

              <div className="flex justify-between">
                <span className="text-slate-400">Market Price:</span>
                <span className="text-emerald-400 font-bold">{asset.unitPrice.toFixed(2)}% of Par</span>
              </div>

              <div className="flex justify-between">
                <span className="text-slate-400">Coupon / Yield:</span>
                <span className="text-cyan-400 font-bold">{asset.couponRate.toFixed(2)}% p.a.</span>
              </div>

              <div className="flex justify-between">
                <span className="text-slate-400">Collateral Haircut:</span>
                <span className="text-amber-300 font-bold">{asset.haircut.toFixed(1)}%</span>
              </div>

              <div className="flex justify-between border-t border-slate-800 pt-2">
                <span className="text-slate-400">Maturity Date:</span>
                <span className="text-slate-200">{asset.maturityDate}</span>
              </div>
            </div>

            {/* Holders distribution breakdown */}
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800 space-y-1 text-[11px]">
              <span className="text-slate-400 block font-bold">MAJOR INSTITUTIONAL HOLDERS</span>
              {Object.entries(asset.holders).map(([instId, amount]) => {
                const instName = institutions.find((i) => i.id === instId)?.code || instId;
                return (
                  <div key={instId} className="flex justify-between text-slate-300">
                    <span>{instName}:</span>
                    <span>{(amount / 1e9).toFixed(2)}B units</span>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
