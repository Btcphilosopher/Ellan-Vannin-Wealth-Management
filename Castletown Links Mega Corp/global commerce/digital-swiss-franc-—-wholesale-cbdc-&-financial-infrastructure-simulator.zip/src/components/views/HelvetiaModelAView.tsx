import React from 'react';
import { useSimulationStore } from '../../simulation/simulationEngine';
import { translations } from '../../i18n/translations';
import { Workflow, Coins, Briefcase, CheckCircle2, ArrowRight } from 'lucide-react';

export const HelvetiaModelAView: React.FC = () => {
  const { dvpTransactions, language } = useSimulationStore();
  const t = translations[language] || translations.en;

  const modelATx = dvpTransactions.filter((t) => t.model === 'MODEL_A_INTEGRATED');

  return (
    <div className="space-y-6">
      <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Workflow className="w-5 h-5 text-blue-400" />
            <h2 className="text-lg font-bold font-serif text-white tracking-wide">
              PROJECT HELVETIA · MODEL A: INTEGRATED DLT SETTLEMENT
            </h2>
          </div>
          <p className="text-xs font-mono text-slate-400 mt-1">
            Wholesale CBDC (wCHF) and Tokenised Securities Exist on the Same DLT Platform
          </p>
        </div>

        <span className="bg-blue-950 text-blue-300 font-mono text-xs px-3 py-1.5 rounded border border-blue-800">
          SINGLE DLT INFRASTRUCTURE
        </span>
      </div>

      {/* Model A Architectural Diagram */}
      <div className="bg-slate-900 p-6 rounded-lg border border-slate-800 space-y-6 font-mono text-xs">
        <h3 className="text-sm font-bold text-white font-serif border-b border-slate-800 pb-2">
          INTEGRATED SETTLEMENT ARCHITECTURE FLOW
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
          <div className="bg-slate-950 p-4 rounded border border-blue-900/80 space-y-2">
            <Briefcase className="w-6 h-6 text-blue-400 mx-auto" />
            <h4 className="font-bold text-white">TOKENISED ASSET</h4>
            <p className="text-[11px] text-slate-400">Swiss Govt Bonds / Corporate Debt issued on SDX DLT</p>
          </div>

          <div className="flex items-center justify-center text-blue-400 font-bold">
            <div className="flex flex-col items-center gap-1">
              <span className="text-[11px] text-emerald-400">ATOMIC SWAP</span>
              <ArrowRight className="w-6 h-6" />
              <span className="text-[10px] text-slate-400">SAME DLT PLATFORM</span>
            </div>
          </div>

          <div className="bg-slate-950 p-4 rounded border border-emerald-900/80 space-y-2">
            <Coins className="w-6 h-6 text-emerald-400 mx-auto" />
            <h4 className="font-bold text-white">WHOLESALE CBDC (wCHF)</h4>
            <p className="text-[11px] text-slate-400">Central Bank Money issued by SNB directly on DLT</p>
          </div>
        </div>

        <div className="bg-slate-950 p-4 rounded border border-slate-800 leading-relaxed text-slate-300">
          <h4 className="font-bold text-white mb-1">ENGINEERING CHARACTERISTICS OF MODEL A:</h4>
          <ul className="list-disc list-inside space-y-1 text-slate-400">
            <li><strong>Zero Principal Risk:</strong> Delivery vs Payment executes in a single atomic smart contract transaction.</li>
            <li><strong>High Capital Efficiency:</strong> No lockups or RTGS synchronization delays required.</li>
            <li><strong>Infrastructure Requirement:</strong> SNB must issue and maintain wholesale CBDC on the private permissioned DLT platform.</li>
          </ul>
        </div>
      </div>

      {/* Model A Transaction History */}
      <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 font-mono text-xs space-y-3">
        <h3 className="text-sm font-bold text-white font-serif border-b border-slate-800 pb-2">
          EXECUTED MODEL A INTEGRATED TRANSACTIONS ({modelATx.length})
        </h3>

        {modelATx.length === 0 ? (
          <p className="text-slate-500 py-4 text-center">No Model A transactions executed yet. Use the DVP Engine tab to execute one.</p>
        ) : (
          <div className="space-y-2">
            {modelATx.map((tx) => (
              <div key={tx.id} className="p-3 bg-slate-950 rounded border border-slate-800 flex justify-between items-center">
                <div>
                  <span className="font-bold text-blue-400">{tx.id}</span>
                  <span className="text-slate-400 ml-3">Asset: {tx.assetIsin} ({tx.assetAmount} units)</span>
                </div>
                <div className="flex items-center gap-4">
                  <span className="font-bold text-emerald-400">CHF {tx.totalCashValue.toLocaleString()}</span>
                  <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-950 text-emerald-300 font-bold border border-emerald-800">
                    {tx.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
