import React, { useState } from 'react';
import { useSimulationStore } from '../../simulation/simulationEngine';
import { translations } from '../../i18n/translations';
import { Banknote, Landmark, Send, CheckCircle2 } from 'lucide-react';

export const MonetaryPolicyView: React.FC = () => {
  const { snbBills, createSnbBillAuction, submitBillBid, institutions, language } = useSimulationStore();
  const t = translations[language] || translations.en;

  const [seriesName, setSeriesName] = useState('SNB-BILL-2026-Q4');
  const [targetVol, setTargetVol] = useState('5000000000'); // 5B
  const [yieldVal, setYieldVal] = useState('0.95');

  const handleCreateAuction = () => {
    const vol = parseFloat(targetVol);
    const yld = parseFloat(yieldVal);
    if (!vol || vol <= 0) return;
    createSnbBillAuction(seriesName, vol, yld);
  };

  return (
    <div className="space-y-6 font-mono text-xs">
      <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Banknote className="w-5 h-5 text-emerald-400" />
            <h2 className="text-lg font-bold font-serif text-white tracking-wide">
              SNB MONETARY POLICY OPERATIONS & DIGITAL BILLS
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Issuance of Digital Central-Bank Debt Instruments Settled in Wholesale CBDC
          </p>
        </div>

        <div className="bg-slate-950 px-3 py-1.5 rounded border border-slate-800 text-slate-300">
          SNB Policy Rate: <strong className="text-emerald-400">1.25% p.a.</strong>
        </div>
      </div>

      {/* Auction Launcher */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-4">
          <h3 className="text-sm font-bold text-white font-serif border-b border-slate-800 pb-2">
            LAUNCH DIGITAL SNB BILL AUCTION
          </h3>

          <div className="space-y-3">
            <div>
              <label className="block text-slate-400 text-xs mb-1">SERIES NAME</label>
              <input
                type="text"
                value={seriesName}
                onChange={(e) => setSeriesName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-white font-bold text-xs"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-400 text-xs mb-1">TARGET VOLUME (CHF)</label>
                <input
                  type="number"
                  value={targetVol}
                  onChange={(e) => setTargetVol(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-white font-bold text-xs"
                />
              </div>

              <div>
                <label className="block text-slate-400 text-xs mb-1">INDICATIVE YIELD (%)</label>
                <input
                  type="number"
                  step="0.05"
                  value={yieldVal}
                  onChange={(e) => setYieldVal(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-white font-bold text-xs"
                />
              </div>
            </div>

            <button
              onClick={handleCreateAuction}
              className="w-full bg-emerald-700 hover:bg-emerald-600 text-white font-bold py-2.5 rounded transition shadow-xs mt-2"
            >
              ANNOUNCE & START AUCTION
            </button>
          </div>
        </div>

        {/* Existing Auctions */}
        <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-4">
          <h3 className="text-sm font-bold text-white font-serif border-b border-slate-800 pb-2">
            DIGITAL SNB BILL AUCTION REGISTER ({snbBills.length})
          </h3>

          <div className="space-y-3 max-h-64 overflow-y-auto">
            {snbBills.map((bill) => (
              <div key={bill.isin} className="p-3 bg-slate-950 rounded border border-slate-800 space-y-1">
                <div className="flex justify-between items-center font-bold">
                  <span className="text-blue-400">{bill.series}</span>
                  <span className="text-slate-400 text-[10px]">{bill.isin}</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>Target Volume: CHF {(bill.targetVolume / 1e9).toFixed(1)}B</span>
                  <span className="text-emerald-400">{bill.yieldPercent}% Yield</span>
                </div>
                <div className="flex justify-between text-[11px] text-slate-400 border-t border-slate-800/80 pt-1">
                  <span>Maturity: {bill.maturityDate}</span>
                  <span className="text-amber-300 font-bold">{bill.status}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
