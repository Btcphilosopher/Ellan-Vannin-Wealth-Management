import React from 'react';
import { useSimulationStore } from '../../simulation/simulationEngine';
import { translations } from '../../i18n/translations';
import { ShieldCheck, EyeOff, Lock, FileKey } from 'lucide-react';

export const PrivacyGovernanceView: React.FC = () => {
  const { language } = useSimulationStore();
  const t = translations[language] || translations.en;

  const permissions = [
    { role: 'SNB Central Bank Authority', viewBalances: 'FULL UNMASKED', initiateIssuance: 'YES', inspectAudit: 'FULL ACCESS' },
    { role: 'Tier-1 Commercial Banks', viewBalances: 'OWN + ANONYMISED DEPT', initiateIssuance: 'CONVERSION ONLY', inspectAudit: 'OWN TRANSACTIONS' },
    { role: 'SIX Digital Exchange (SDX)', viewBalances: 'ASSET LEDGER ONLY', initiateIssuance: 'NO', inspectAudit: 'MATCHING LOGS' },
    { role: 'FINMA Regulator', viewBalances: 'COMPLIANCE AUDIT VIEW', initiateIssuance: 'NO', inspectAudit: 'FULL ANONYMISED' },
  ];

  return (
    <div className="space-y-6 font-mono text-xs">
      <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-indigo-400" />
            <h2 className="text-lg font-bold font-serif text-white tracking-wide">
              PRIVACY MATRIX & ROLE-BASED GOVERNANCE
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Zero-Knowledge Proof Confidentiality Controls & FINMA Regulatory Access Layers
          </p>
        </div>

        <div className="bg-slate-950 px-3 py-1.5 rounded border border-slate-800 text-slate-300">
          Cryptographic Mode: <strong className="text-indigo-400">zk-SNARK Confidential Balances</strong>
        </div>
      </div>

      <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-4">
        <h3 className="text-sm font-bold text-white font-serif border-b border-slate-800 pb-2">
          ROLE-BASED PERMISSION MATRIX
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 text-[11px]">
                <th className="py-2.5 px-3">GOVERNANCE ROLE</th>
                <th className="py-2.5 px-3">BALANCE VISIBILITY</th>
                <th className="py-2.5 px-3">wCHF ISSUANCE PERMISSION</th>
                <th className="py-2.5 px-3">AUDIT TRAIL INSPECTION</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {permissions.map((p) => (
                <tr key={p.role} className="hover:bg-slate-800/40 transition">
                  <td className="py-2.5 px-3 font-bold text-white">{p.role}</td>
                  <td className="py-2.5 px-3 text-indigo-300 font-bold">{p.viewBalances}</td>
                  <td className="py-2.5 px-3 text-emerald-400 font-bold">{p.initiateIssuance}</td>
                  <td className="py-2.5 px-3 text-slate-300">{p.inspectAudit}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
