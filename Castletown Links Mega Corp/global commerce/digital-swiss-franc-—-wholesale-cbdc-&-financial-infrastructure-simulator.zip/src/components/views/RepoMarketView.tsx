import React, { useState } from 'react';
import { useSimulationStore } from '../../simulation/simulationEngine';
import { translations } from '../../i18n/translations';
import { ArrowRightLeft, Lock, Coins, CheckCircle2 } from 'lucide-react';

export const RepoMarketView: React.FC = () => {
  const { institutions, tokenisedAssets, repoTrades, createRepoTrade, closeRepoTrade, language } = useSimulationStore();
  const t = translations[language] || translations.en;

  const [borrowerId, setBorrowerId] = useState(institutions[0]?.id || '');
  const [lenderId, setLenderId] = useState(institutions[1]?.id || '');
  const [collateralIsin, setCollateralIsin] = useState(tokenisedAssets[0]?.isin || '');
  const [cashAmount, setCashAmount] = useState('500000000'); // 500M CHF
  const [repoRate, setRepoRate] = useState('1.25'); // 1.25%
  const [termDays, setTermDays] = useState('7');

  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const handleCreateRepo = () => {
    const cash = parseFloat(cashAmount);
    const rate = parseFloat(repoRate);
    const term = parseInt(termDays);

    if (!cash || cash <= 0) return;

    const ok = createRepoTrade({
      borrowerId,
      lenderId,
      collateralIsin,
      collateralUnits: Math.floor(cash / 100),
      cashAmount: cash,
      repoRatePercent: rate,
      termDays: term,
    });

    if (ok) {
      setMessage({
        type: 'success',
        text: `Digital Repo initiated: Borrower received CHF ${cash.toLocaleString()} wCHF against tokenised collateral lock.`,
      });
    } else {
      setMessage({
        type: 'error',
        text: 'Repo initiation failed. Check lender wCHF balance or institution status.',
      });
    }
  };

  const handleCloseRepo = (repoId: string) => {
    const ok = closeRepoTrade(repoId);
    if (ok) {
      setMessage({
        type: 'success',
        text: `Repo ${repoId} closed and repaid with interest. Collateral released back to borrower.`,
      });
    } else {
      setMessage({
        type: 'error',
        text: 'Repo closure failed. Check borrower wCHF repayment balance.',
      });
    }
  };

  return (
    <div className="space-y-6 font-mono text-xs">
      <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <ArrowRightLeft className="w-5 h-5 text-amber-400" />
            <h2 className="text-lg font-bold font-serif text-white tracking-wide">
              TOKENISED DIGITAL REPO MARKET
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Automated Triparty Repo Operations Settled in Wholesale CBDC (wCHF)
          </p>
        </div>

        <div className="bg-slate-950 px-3 py-1.5 rounded border border-slate-800 text-slate-300">
          Active Repo Volume: <strong className="text-amber-400">CHF {(repoTrades.filter((r) => r.status === 'ACTIVE').reduce((acc, r) => acc + r.cashAmount, 0) / 1e9).toFixed(2)}B</strong>
        </div>
      </div>

      {message && (
        <div
          className={`p-4 rounded border ${
            message.type === 'success'
              ? 'bg-emerald-950/80 text-emerald-300 border-emerald-800'
              : 'bg-red-950/80 text-red-300 border-red-800'
          }`}
        >
          {message.text}
        </div>
      )}

      {/* Repo Creation Form & Lifecycle Visualizer */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Form */}
        <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-4">
          <h3 className="text-sm font-bold text-white font-serif border-b border-slate-800 pb-2">
            INITIATE DIGITAL REPO AGREEMENT
          </h3>

          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-400 text-xs mb-1">CASH BORROWER</label>
                <select
                  value={borrowerId}
                  onChange={(e) => setBorrowerId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-white text-xs"
                >
                  {institutions.map((i) => (
                    <option key={i.id} value={i.id}>
                      {i.code} — {i.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 text-xs mb-1">CASH LENDER</label>
                <select
                  value={lenderId}
                  onChange={(e) => setLenderId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-white text-xs"
                >
                  {institutions.map((i) => (
                    <option key={i.id} value={i.id}>
                      {i.code} — {i.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-slate-400 text-xs mb-1">COLLATERAL INSTRUMENT</label>
              <select
                value={collateralIsin}
                onChange={(e) => setCollateralIsin(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-white text-xs"
              >
                {tokenisedAssets.map((a) => (
                  <option key={a.isin} value={a.isin}>
                    {a.symbol} (Haircut: {a.haircut}%)
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block text-slate-400 text-xs mb-1">CASH (CHF)</label>
                <input
                  type="number"
                  value={cashAmount}
                  onChange={(e) => setCashAmount(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-white font-bold text-xs"
                />
              </div>

              <div>
                <label className="block text-slate-400 text-xs mb-1">REPO RATE (%)</label>
                <input
                  type="number"
                  step="0.05"
                  value={repoRate}
                  onChange={(e) => setRepoRate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-white font-bold text-xs"
                />
              </div>

              <div>
                <label className="block text-slate-400 text-xs mb-1">TERM (DAYS)</label>
                <input
                  type="number"
                  value={termDays}
                  onChange={(e) => setTermDays(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-white font-bold text-xs"
                />
              </div>
            </div>

            <button
              onClick={handleCreateRepo}
              className="w-full bg-amber-600 hover:bg-amber-500 text-white font-bold py-2.5 rounded transition shadow-xs mt-2"
            >
              EXECUTE REPO TRADE
            </button>
          </div>
        </div>

        {/* Lifecycle Diagram */}
        <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-4">
          <h3 className="text-sm font-bold text-white font-serif border-b border-slate-800 pb-2">
            DIGITAL REPO LIFECYCLE
          </h3>

          <div className="space-y-2 text-slate-300">
            <div className="p-2.5 bg-slate-950 rounded border border-slate-800 flex justify-between items-center">
              <span>1. TRADE EXECUTION & MATCHING</span>
              <span className="text-emerald-400 font-bold">AUTOMATED</span>
            </div>
            <div className="p-2.5 bg-slate-950 rounded border border-slate-800 flex justify-between items-center">
              <span>2. COLLATERAL SMART LOCK</span>
              <span className="text-blue-400 font-bold">HAIRCUT ENFORCED</span>
            </div>
            <div className="p-2.5 bg-slate-950 rounded border border-slate-800 flex justify-between items-center">
              <span>3. wCHF CASH SETTLEMENT</span>
              <span className="text-emerald-400 font-bold">ATOMIC DVP</span>
            </div>
            <div className="p-2.5 bg-slate-950 rounded border border-slate-800 flex justify-between items-center">
              <span>4. MATURITY & REPAYMENT</span>
              <span className="text-amber-400 font-bold">AUTO RELEASE</span>
            </div>
          </div>
        </div>
      </div>

      {/* Active Repos Table */}
      <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-4">
        <h3 className="text-sm font-bold text-white font-serif border-b border-slate-800 pb-2">
          ACTIVE DIGITAL REPO CONTRACTS ({repoTrades.length})
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 text-[11px]">
                <th className="py-2 px-3">REPO ID</th>
                <th className="py-2 px-3">BORROWER</th>
                <th className="py-2 px-3">LENDER</th>
                <th className="py-2 px-3">CASH (CHF)</th>
                <th className="py-2 px-3">RATE</th>
                <th className="py-2 px-3">MATURITY</th>
                <th className="py-2 px-3">STATUS</th>
                <th className="py-2 px-3 text-right">ACTION</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {repoTrades.map((repo) => (
                <tr key={repo.id} className="hover:bg-slate-800/40 transition">
                  <td className="py-2 px-3 font-bold text-amber-400">{repo.id}</td>
                  <td className="py-2 px-3 text-white">
                    {institutions.find((i) => i.id === repo.borrowerId)?.code || repo.borrowerId}
                  </td>
                  <td className="py-2 px-3 text-white">
                    {institutions.find((i) => i.id === repo.lenderId)?.code || repo.lenderId}
                  </td>
                  <td className="py-2 px-3 font-bold text-emerald-400">
                    CHF {repo.cashAmount.toLocaleString()}
                  </td>
                  <td className="py-2 px-3 text-cyan-400">{repo.repoRatePercent}%</td>
                  <td className="py-2 px-3 text-slate-400">{repo.maturityDate}</td>
                  <td className="py-2 px-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        repo.status === 'ACTIVE'
                          ? 'bg-amber-950 text-amber-300 border border-amber-800'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {repo.status}
                    </span>
                  </td>
                  <td className="py-2 px-3 text-right">
                    {repo.status === 'ACTIVE' && (
                      <button
                        onClick={() => handleCloseRepo(repo.id)}
                        className="bg-emerald-950 hover:bg-emerald-900 text-emerald-300 px-2 py-1 rounded text-[10px] font-bold border border-emerald-800 transition"
                      >
                        REPAY & CLOSE
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
