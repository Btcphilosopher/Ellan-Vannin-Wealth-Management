import React from 'react';
import { useSimulationStore } from '../../simulation/simulationEngine';
import { translations } from '../../i18n/translations';
import { Scale, ShieldCheck, AlertCircle } from 'lucide-react';

export const CollateralManagementView: React.FC = () => {
  const { tokenisedAssets, institutions, language } = useSimulationStore();
  const t = translations[language] || translations.en;

  return (
    <div className="space-y-6 font-mono text-xs">
      <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Scale className="w-5 h-5 text-amber-400" />
            <h2 className="text-lg font-bold font-serif text-white tracking-wide">
              TRIPARTY COLLATERAL MANAGEMENT CENTER
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Eligible SNB Securities, Haircut Matrix & Automatic Margin Call Triggers
          </p>
        </div>

        <div className="bg-slate-950 px-3 py-1.5 rounded border border-slate-800 text-slate-300">
          Total Pledged Collateral: <strong className="text-amber-400">CHF 49.9B</strong>
        </div>
      </div>

      {/* Collateral Table */}
      <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-4">
        <h3 className="text-sm font-bold text-white font-serif border-b border-slate-800 pb-2">
          SNB ELIGIBLE COLLATERAL BASKET & HAIRCUTS
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 text-[11px]">
                <th className="py-2.5 px-3">ISIN</th>
                <th className="py-2.5 px-3">INSTRUMENT</th>
                <th className="py-2.5 px-3">ISSUER</th>
                <th className="py-2.5 px-3">MARKET PRICE</th>
                <th className="py-2.5 px-3">HAIRCUT (%)</th>
                <th className="py-2.5 px-3">ELIGIBLE VALUE</th>
                <th className="py-2.5 px-3">STATUS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {tokenisedAssets.map((asset) => {
                const eligibleVal = asset.nominalValue * (1 - asset.haircut / 100);
                return (
                  <tr key={asset.isin} className="hover:bg-slate-800/40 transition">
                    <td className="py-2.5 px-3 text-blue-400 font-bold">{asset.isin}</td>
                    <td className="py-2.5 px-3 font-bold text-white">{asset.name}</td>
                    <td className="py-2.5 px-3 text-slate-300">{asset.issuer}</td>
                    <td className="py-2.5 px-3 text-emerald-400 font-bold">{asset.unitPrice.toFixed(2)}%</td>
                    <td className="py-2.5 px-3 text-amber-300 font-bold">{asset.haircut.toFixed(1)}%</td>
                    <td className="py-2.5 px-3 text-cyan-300">CHF {(eligibleVal / 1e9).toFixed(2)}B</td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold">
                        SNB ELIGIBLE
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
