import React from 'react';
import { useSimulationStore } from '../../simulation/simulationEngine';
import { translations } from '../../i18n/translations';
import { Smartphone, ShieldAlert, Lock, AlertTriangle } from 'lucide-react';

export const RetailCbdcResearchView: React.FC = () => {
  const { language } = useSimulationStore();
  const t = translations[language] || translations.en;

  return (
    <div className="space-y-6 font-mono text-xs">
      <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-amber-400" />
            <h2 className="text-lg font-bold font-serif text-white tracking-wide">
              RETAIL CBDC EXPERIMENTAL RESEARCH SANDBOX
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Hypothetical Retail Swiss Franc Prototype (Holding Caps, Offline Resilience & Disintermediation Guardrails)
          </p>
        </div>

        <div className="bg-amber-950/80 text-amber-300 px-3 py-1.5 rounded border border-amber-800 font-bold">
          SNB POLICY NOTE: RESEARCH ONLY
        </div>
      </div>

      {/* Policy Disclaimer Banner */}
      <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-3 leading-relaxed text-slate-300">
        <h3 className="text-sm font-bold text-white font-serif border-b border-slate-800 pb-2">
          CENTRAL BANK MONETARY POLICY POSITION ON RETAIL CBDC
        </h3>

        <p>
          The Schweizerische Nationalbank (SNB) maintains a clear operational distinction between <strong>Wholesale CBDC (wCBDC)</strong> and <strong>Retail CBDC (rCBDC)</strong>:
        </p>

        <ul className="list-disc list-inside space-y-1 text-slate-400">
          <li><strong>Wholesale CBDC is the SNB's primary focus:</strong> Settling wholesale financial transactions between regulated financial institutions in central bank money minimizes credit and liquidity risk across financial market infrastructure.</li>
          <li><strong>Retail CBDC risks bank disintermediation:</strong> Issuing central bank digital money directly to the general public during financial stress could trigger rapid run behavior from commercial bank deposits into SNB liabilities.</li>
          <li><strong>Experimental Guardrails:</strong> This sandbox models mandatory holding limits (e.g. max CHF 3,000 per citizen), non-remuneration (0% interest rate), and two-tier distribution through commercial banks.</li>
        </ul>
      </div>

      {/* Experimental Parameters Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-2">
          <span className="text-slate-400 text-[11px]">HYPOTHETICAL HOLDING CAP</span>
          <div className="text-xl font-bold text-amber-400">CHF 3,000 / Person</div>
          <p className="text-slate-400 text-[11px]">Automated Waterfall to Commercial Deposit Account</p>
        </div>

        <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-2">
          <span className="text-slate-400 text-[11px]">DISTRIBUTION MODEL</span>
          <div className="text-xl font-bold text-white">Two-Tiered Architecture</div>
          <p className="text-slate-400 text-[11px]">Commercial Banks Manage Customer Wallets & KYC</p>
        </div>

        <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-2">
          <span className="text-slate-400 text-[11px]">OFFLINE PAYMENT LIMIT</span>
          <div className="text-xl font-bold text-cyan-400">CHF 500 / Tx</div>
          <p className="text-slate-400 text-[11px]">Secure Hardware Element Peer-to-Peer Transfer</p>
        </div>
      </div>
    </div>
  );
};
