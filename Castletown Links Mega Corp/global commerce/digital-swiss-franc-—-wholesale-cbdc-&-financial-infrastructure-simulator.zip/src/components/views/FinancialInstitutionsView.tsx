import React from 'react';
import { useSimulationStore } from '../../simulation/simulationEngine';
import { translations } from '../../i18n/translations';
import { Building2, ShieldAlert, ArrowRightLeft, Lock, Scale } from 'lucide-react';

export const FinancialInstitutionsView: React.FC = () => {
  const { institutions, language, freezeAccount, injectLiquidityShock, defaultCounterparty } = useSimulationStore();
  const t = translations[language] || translations.en;

  return (
    <div className="space-y-6">
      <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Building2 className="w-5 h-5 text-blue-400" />
            <h2 className="text-lg font-bold font-serif text-white tracking-wide">
              PARTICIPATING FINANCIAL INSTITUTIONS
            </h2>
          </div>
          <p className="text-xs font-mono text-slate-400 mt-1">
            Simulated Tier-1 Swiss Banks, Cantonal Institutions, Private Banks & Securities Dealers
          </p>
        </div>

        <div className="text-xs font-mono text-slate-400 bg-slate-950 px-3 py-1.5 rounded border border-slate-800">
          Total Participants: <strong className="text-white">{institutions.length} Institutions</strong>
        </div>
      </div>

      {/* Financial Institutions Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 font-mono text-xs">
        {institutions.map((inst) => (
          <div
            key={inst.id}
            className={`p-5 rounded-lg border transition space-y-4 ${
              inst.status === 'ACTIVE'
                ? 'bg-slate-900 border-slate-800'
                : inst.status === 'STRESSED'
                ? 'bg-amber-950/20 border-amber-800/80'
                : 'bg-red-950/30 border-red-800/80'
            }`}
          >
            <div className="flex items-start justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-sm font-bold text-white font-serif">{inst.name}</h3>
                <span className="text-[11px] text-slate-400">{inst.type.replace('_', ' ')}</span>
              </div>
              <span className="bg-blue-950 text-blue-300 font-bold px-2 py-0.5 rounded text-[11px]">
                {inst.code}
              </span>
            </div>

            <div className="space-y-2 text-slate-300">
              <div className="flex justify-between">
                <span className="text-slate-400">SNB Sight Deposit:</span>
                <span className="font-bold text-white">CHF {(inst.snbSightDeposit / 1e9).toFixed(2)}B</span>
              </div>

              <div className="flex justify-between">
                <span className="text-slate-400">wCHF Balance:</span>
                <span className="font-bold text-emerald-400">CHF {(inst.wChfBalance / 1e9).toFixed(2)}B</span>
              </div>

              <div className="flex justify-between">
                <span className="text-slate-400">Tokenised Assets:</span>
                <span className="font-bold text-blue-400">CHF {(inst.tokenisedAssetsValue / 1e9).toFixed(2)}B</span>
              </div>

              <div className="flex justify-between">
                <span className="text-slate-400">Pledged Collateral:</span>
                <span className="text-slate-300">CHF {(inst.collateralPledged / 1e9).toFixed(2)}B</span>
              </div>

              <div className="flex justify-between border-t border-slate-800/80 pt-2">
                <span className="text-slate-400">Regulatory Capital:</span>
                <span className="font-bold text-amber-300">CHF {(inst.capital / 1e9).toFixed(2)}B</span>
              </div>

              <div className="flex justify-between items-center pt-1">
                <span className="text-slate-400">Risk Exposure Index:</span>
                <span
                  className={`font-bold px-1.5 py-0.5 rounded text-[10px] ${
                    inst.riskScore < 15
                      ? 'bg-emerald-950 text-emerald-300'
                      : inst.riskScore < 40
                      ? 'bg-amber-950 text-amber-300'
                      : 'bg-red-950 text-red-300'
                  }`}
                >
                  {inst.riskScore} / 100
                </span>
              </div>
            </div>

            {/* Controls */}
            <div className="grid grid-cols-2 gap-2 border-t border-slate-800 pt-3 text-[11px]">
              <button
                onClick={() => injectLiquidityShock(inst.id, 2_000_000_000)}
                className="bg-amber-950/80 hover:bg-amber-900 text-amber-300 py-1.5 rounded font-bold transition border border-amber-800/60"
              >
                SHOCK (-2B)
              </button>

              <button
                onClick={() => freezeAccount(inst.id)}
                className={`py-1.5 rounded font-bold transition ${
                  inst.status === 'FROZEN'
                    ? 'bg-slate-800 text-slate-200'
                    : 'bg-red-950/80 hover:bg-red-900 text-red-300 border border-red-800/60'
                }`}
              >
                {inst.status === 'FROZEN' ? 'UNFREEZE' : 'FREEZE'}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
