import React from 'react';
import { useSimulationStore } from '../../simulation/simulationEngine';
import { translations } from '../../i18n/translations';
import {
  Coins,
  Briefcase,
  Activity,
  GitCommit,
  ArrowRightLeft,
  Clock,
  Zap,
  Radio,
  Server,
  ArrowUpRight,
  TrendingUp,
  ShieldCheck,
} from 'lucide-react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
} from 'recharts';

export const CommandCenterView: React.FC = () => {
  const { systemMetrics, dvpTransactions, auditRecords, language, blockHeight } = useSimulationStore();
  const t = translations[language] || translations.en;

  // Chart seed data
  const settlementTrend = [
    { time: '09:00', volume: 8.2, dvp: 2400 },
    { time: '10:00', volume: 12.4, dvp: 3800 },
    { time: '11:00', volume: 18.9, dvp: 5100 },
    { time: '12:00', volume: 22.1, dvp: 6900 },
    { time: '13:00', volume: 29.5, dvp: 9800 },
    { time: '14:00', volume: 35.8, dvp: 12400 },
    { time: '15:00', volume: 42.8, dvp: 18421 },
  ];

  const modelDistribution = [
    { name: 'Model A (Integrated DLT)', value: 26.8, color: '#2563EB' },
    { name: 'Model B (RTGS Synchronised)', value: 16.0, color: '#0EA5E9' },
  ];

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold font-serif text-white tracking-wide">
            WHOLESALE FINANCIAL INFRASTRUCTURE CONTROL CENTER
          </h2>
          <p className="text-xs font-mono text-slate-400 mt-0.5">
            Real-time Monitoring of SNB wCHF Ledger, DLT Securities Exchange, and SIC RTGS Synchroniser
          </p>
        </div>
        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="bg-blue-950 text-blue-300 border border-blue-800 px-3 py-1 rounded">
            SIMULATION TICK #{blockHeight}
          </span>
          <span className="bg-emerald-950 text-emerald-300 border border-emerald-800 px-3 py-1 rounded flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
            LIVE ENGINE
          </span>
        </div>
      </div>

      {/* Primary Key Metrics Grid - Exact Prompt Mandate */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {/* Metric 1 */}
        <div className="bg-slate-900 p-4 rounded-lg border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono">
            <span>{t.wChfOutstanding}</span>
            <Coins className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-white mt-2">
            CHF {(systemMetrics.wholesaleCbdcOutstanding / 1_000_000_000).toFixed(1)}B
          </div>
          <div className="text-[11px] font-mono text-emerald-400 mt-1 flex items-center gap-1">
            <TrendingUp className="w-3 h-3" /> 100% Central Bank Backed
          </div>
        </div>

        {/* Metric 2 */}
        <div className="bg-slate-900 p-4 rounded-lg border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono">
            <span>{t.tokenisedAssets}</span>
            <Briefcase className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-white mt-2">
            CHF {(systemMetrics.tokenisedAssetsTotal / 1_000_000_000).toFixed(1)}B
          </div>
          <div className="text-[11px] font-mono text-blue-400 mt-1">
            7 Instrument Classes
          </div>
        </div>

        {/* Metric 3 */}
        <div className="bg-slate-900 p-4 rounded-lg border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono">
            <span>{t.settlementValue}</span>
            <Activity className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-white mt-2">
            CHF {(systemMetrics.dailySettlementValue / 1_000_000_000).toFixed(1)}B
          </div>
          <div className="text-[11px] font-mono text-cyan-400 mt-1">
            24h Intraday Volume
          </div>
        </div>

        {/* Metric 4 */}
        <div className="bg-slate-900 p-4 rounded-lg border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono">
            <span>{t.dvpTransactions}</span>
            <GitCommit className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-white mt-2">
            {systemMetrics.dvpTransactionsCount.toLocaleString()}
          </div>
          <div className="text-[11px] font-mono text-purple-400 mt-1">
            100% Atomic Finality
          </div>
        </div>

        {/* Metric 5 */}
        <div className="bg-slate-900 p-4 rounded-lg border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono">
            <span>{t.repoValue}</span>
            <ArrowRightLeft className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-white mt-2">
            CHF {(systemMetrics.repoValueOutstanding / 1_000_000_000).toFixed(1)}B
          </div>
          <div className="text-[11px] font-mono text-amber-400 mt-1">
            Triparty DLT Collateral
          </div>
        </div>

        {/* Metric 6 */}
        <div className="bg-slate-900 p-4 rounded-lg border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono">
            <span>{t.avgLatency}</span>
            <Clock className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-white mt-2">
            {systemMetrics.avgSettlementLatencySec} sec
          </div>
          <div className="text-[11px] font-mono text-emerald-400 mt-1">
            Sub-second Finality
          </div>
        </div>

        {/* Metric 7 */}
        <div className="bg-slate-900 p-4 rounded-lg border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono">
            <span>{t.dltTps}</span>
            <Zap className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-white mt-2">
            {systemMetrics.dltTps.toLocaleString()}
          </div>
          <div className="text-[11px] font-mono text-indigo-400 mt-1">
            Permissioned Consensus
          </div>
        </div>

        {/* Metric 8 */}
        <div className="bg-slate-900 p-4 rounded-lg border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 text-xs font-mono">
            <span>{t.rtgsLatency}</span>
            <Radio className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-white mt-2">
            {systemMetrics.rtgsLinkLatencySec} sec
          </div>
          <div className="text-[11px] font-mono text-rose-400 mt-1">
            SIC Two-Phase Commit
          </div>
        </div>
      </div>

      {/* System Topology Diagram & Settlement Trend Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Architecture Topology Visualizer */}
        <div className="lg:col-span-1 bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold font-serif text-white tracking-wide">
              HELVETIA DUAL ARCHITECTURE FLOW
            </h3>
            <span className="text-[10px] font-mono text-slate-400">MODEL A vs MODEL B</span>
          </div>

          <div className="space-y-3 font-mono text-xs">
            {/* Model A Branch */}
            <div className="bg-slate-950 p-3 rounded border border-blue-900/60 space-y-2">
              <div className="flex items-center justify-between text-blue-400 font-bold">
                <span>HELVETIA MODEL A</span>
                <span className="text-[10px] bg-blue-900/60 px-1.5 py-0.5 rounded text-blue-200">
                  INTEGRATED
                </span>
              </div>
              <div className="text-[11px] text-slate-300 space-y-1">
                <div className="flex items-center justify-between bg-slate-900 p-1.5 rounded">
                  <span>Cash Leg:</span>
                  <span className="text-emerald-400">wCHF on DLT</span>
                </div>
                <div className="flex items-center justify-between bg-slate-900 p-1.5 rounded">
                  <span>Securities Leg:</span>
                  <span className="text-blue-400">SDX Tokenised Asset</span>
                </div>
                <div className="flex items-center justify-between bg-slate-900 p-1.5 rounded">
                  <span>Settlement:</span>
                  <span className="text-purple-400 font-bold">Single DLT Atomic Swap</span>
                </div>
              </div>
            </div>

            {/* Model B Branch */}
            <div className="bg-slate-950 p-3 rounded border border-cyan-900/60 space-y-2">
              <div className="flex items-center justify-between text-cyan-400 font-bold">
                <span>HELVETIA MODEL B</span>
                <span className="text-[10px] bg-cyan-900/60 px-1.5 py-0.5 rounded text-cyan-200">
                  SYNCHRONISED
                </span>
              </div>
              <div className="text-[11px] text-slate-300 space-y-1">
                <div className="flex items-center justify-between bg-slate-900 p-1.5 rounded">
                  <span>Cash Leg:</span>
                  <span className="text-amber-400">SIC RTGS Sight Balance</span>
                </div>
                <div className="flex items-center justify-between bg-slate-900 p-1.5 rounded">
                  <span>Securities Leg:</span>
                  <span className="text-blue-400">SDX Tokenised Asset</span>
                </div>
                <div className="flex items-center justify-between bg-slate-900 p-1.5 rounded">
                  <span>Bridge:</span>
                  <span className="text-rose-400 font-bold">2-Phase Lock RTGS Link</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Settlement Trend Chart */}
        <div className="lg:col-span-2 bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold font-serif text-white tracking-wide">
              24-HOUR INTRADAY SETTLEMENT VOLUME (CHF BILLIONS)
            </h3>
            <span className="text-xs font-mono text-emerald-400">REAL-TIME TICKER ACTIVE</span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={settlementTrend}>
                <defs>
                  <linearGradient id="colorVolume" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563EB" stopOpacity={0.8} />
                    <stop offset="95%" stopColor="#2563EB" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="time" stroke="#64748B" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748B" fontSize={11} tickLine={false} unit="B" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0F172A', borderColor: '#334155', color: '#F8FAFC' }}
                  itemStyle={{ color: '#60A5FA' }}
                />
                <Area type="monotone" dataKey="volume" stroke="#3B82F6" fillOpacity={1} fill="url(#colorVolume)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Live Audit Log Stream Feed */}
      <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold font-serif text-white tracking-wide flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            REAL-TIME INFRASTRUCTURE AUDIT STREAM
          </h3>
          <span className="text-xs font-mono text-slate-400">
            {auditRecords.length} Audit Entries Recorded
          </span>
        </div>

        <div className="bg-slate-950 p-3 rounded border border-slate-800 max-h-48 overflow-y-auto space-y-2 font-mono text-xs">
          {auditRecords.slice(0, 5).map((log) => (
            <div key={log.id} className="border-b border-slate-800/80 pb-2 last:border-none last:pb-0">
              <div className="flex items-center justify-between text-slate-400 text-[11px]">
                <span className="text-blue-400 font-bold">{log.id}</span>
                <span>{new Date(log.timestamp).toLocaleTimeString()}</span>
              </div>
              <p className="text-slate-200 mt-0.5">{log.details}</p>
              {log.amountChf && (
                <div className="text-[10px] text-emerald-400 mt-0.5">
                  Amount: CHF {log.amountChf.toLocaleString()}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
