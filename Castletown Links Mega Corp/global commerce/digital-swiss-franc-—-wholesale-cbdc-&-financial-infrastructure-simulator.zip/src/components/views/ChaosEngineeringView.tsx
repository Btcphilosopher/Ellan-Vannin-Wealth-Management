import React from 'react';
import { useSimulationStore } from '../../simulation/simulationEngine';
import { translations } from '../../i18n/translations';
import { Zap, AlertTriangle, Power, RefreshCw, Radio } from 'lucide-react';

export const ChaosEngineeringView: React.FC = () => {
  const {
    dltNodes,
    toggleDltNode,
    setRtgsLinkState,
    injectLiquidityShock,
    runRecoveryEngine,
    institutions,
    language,
  } = useSimulationStore();

  const t = translations[language] || translations.en;

  return (
    <div className="space-y-6 font-mono text-xs">
      <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-amber-400" />
            <h2 className="text-lg font-bold font-serif text-white tracking-wide">
              CHAOS ENGINEERING & INFRASTRUCTURE FAILURE LAB
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Controlled Fault Injection Workbench for Testing DLT Consensus & Settlement Resiliency
          </p>
        </div>

        <button
          onClick={runRecoveryEngine}
          className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-4 py-2 rounded transition shadow-xs flex items-center gap-2"
        >
          <RefreshCw className="w-4 h-4" />
          FULL SYSTEM RECOVERY
        </button>
      </div>

      {/* Control Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Node Failure Injector */}
        <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-3">
          <h3 className="text-sm font-bold text-white font-serif border-b border-slate-800 pb-2">
            1. DLT NODE OUTAGE INJECTOR
          </h3>

          <div className="space-y-2">
            {dltNodes.map((node) => (
              <div key={node.id} className="flex justify-between items-center p-2 bg-slate-950 rounded border border-slate-800">
                <span>{node.name}</span>
                <button
                  onClick={() => toggleDltNode(node.id)}
                  className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    node.status === 'ONLINE'
                      ? 'bg-red-950 text-red-300 hover:bg-red-900'
                      : 'bg-emerald-950 text-emerald-300 hover:bg-emerald-900'
                  }`}
                >
                  {node.status === 'ONLINE' ? 'FAIL NODE' : 'RESTORE'}
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Network Gateway Interruption */}
        <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-3">
          <h3 className="text-sm font-bold text-white font-serif border-b border-slate-800 pb-2">
            2. RTGS LINK LATENCY & FAILURE
          </h3>

          <div className="space-y-2">
            <button
              onClick={() => setRtgsLinkState('DEGRADED', 3000)}
              className="w-full bg-amber-950 hover:bg-amber-900 text-amber-300 font-bold py-2 rounded border border-amber-800 transition"
            >
              INJECT 3000ms LATENCY
            </button>

            <button
              onClick={() => setRtgsLinkState('DISCONNECTED', 99999)}
              className="w-full bg-red-950 hover:bg-red-900 text-red-300 font-bold py-2 rounded border border-red-800 transition"
            >
              DISCONNECT LINK GATEWAY
            </button>

            <button
              onClick={() => setRtgsLinkState('OPERATIONAL', 0.71)}
              className="w-full bg-emerald-950 hover:bg-emerald-900 text-emerald-300 font-bold py-2 rounded border border-emerald-800 transition"
            >
              RESTORE RTGS LINK
            </button>
          </div>
        </div>

        {/* Liquidity Stress Shock */}
        <div className="bg-slate-900 p-5 rounded-lg border border-slate-800 space-y-3">
          <h3 className="text-sm font-bold text-white font-serif border-b border-slate-800 pb-2">
            3. LIQUIDITY DRAIN INJECTOR
          </h3>

          <div className="space-y-2">
            {institutions.slice(0, 4).map((inst) => (
              <div key={inst.id} className="flex justify-between items-center p-2 bg-slate-950 rounded border border-slate-800">
                <span>{inst.code}</span>
                <button
                  onClick={() => injectLiquidityShock(inst.id, 2_000_000_000)}
                  className="bg-amber-950 hover:bg-amber-900 text-amber-300 px-2 py-0.5 rounded text-[10px] font-bold border border-amber-800"
                >
                  DRAIN 2B wCHF
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
