export type Language = 'en' | 'de' | 'fr' | 'it';

export type SettlementModel = 'MODEL_A_INTEGRATED' | 'MODEL_B_SYNCHRONISED';

export type TransactionStatus =
  | 'PENDING'
  | 'ASSET_RESERVED'
  | 'CASH_RESERVED'
  | 'MATCHED'
  | 'RTGS_INSTRUCTED'
  | 'SIC_SETTLING'
  | 'SETTLED'
  | 'FAILED'
  | 'ROLLED_BACK';

export type PriorityLevel = 'HIGH' | 'NORMAL' | 'LOW';

export interface SnbBalanceSheet {
  assets: {
    swissGovSecurities: number; // in CHF
    foreignCurrencyInvestments: number;
    repoAssets: number;
    loansToBanks: number;
    otherAssets: number;
  };
  liabilities: {
    sightDeposits: number; // Bank commercial accounts at SNB
    banknotesInCirculation: number;
    wholesaleCbdcOutstanding: number; // wCHF
    otherLiabilities: number;
  };
  equity: {
    capitalAndReserves: number;
  };
}

export interface FinancialInstitution {
  id: string;
  name: string;
  code: string; // e.g., ALPA, HELV, ZURC
  type: 'COMMERCIAL_BANK' | 'CANTONAL_BANK' | 'PRIVATE_BANK' | 'SECURITIES_FIRM';
  snbSightDeposit: number; // CHF in traditional RTGS/SIC
  wChfBalance: number; // wCHF on DLT
  securitiesValue: number;
  tokenisedAssetsValue: number;
  collateralPledged: number;
  repoObligations: number;
  liquidityBuffer: number;
  capital: number;
  status: 'ACTIVE' | 'SUSPENDED' | 'STRESSED' | 'FROZEN';
  riskScore: number; // 0 - 100
  settlementQueueCount: number;
}

export interface TokenisedAsset {
  isin: string;
  symbol: string;
  name: string;
  assetType: 'GOVT_BOND' | 'CONFED_BILL' | 'CORP_BOND' | 'MONEY_MARKET' | 'FUND_UNIT' | 'COMMERCIAL_PAPER' | 'REPO_COLLATERAL' | 'SNB_BILL';
  issuer: string;
  currency: 'CHF' | 'EUR' | 'USD';
  nominalValue: number; // Total supply
  unitPrice: number; // Price as % of par or CHF per unit
  couponRate: number; // %
  maturityDate: string;
  collateralEligible: boolean;
  haircut: number; // % (e.g., 5%)
  holders: Record<string, number>; // institutionId -> units owned
}

export interface DvpTransaction {
  id: string;
  timestamp: number;
  model: SettlementModel;
  buyerId: string;
  sellerId: string;
  assetIsin: string;
  assetAmount: number; // units
  unitPrice: number;
  totalCashValue: number; // CHF
  status: TransactionStatus;
  statusSteps: {
    stepName: string;
    completedAt?: number;
    status: 'COMPLETED' | 'IN_PROGRESS' | 'PENDING' | 'FAILED';
  }[];
  failureReason?: string;
  txHashDLT?: string;
  sicReference?: string;
  rtgsLinkLatencyMs?: number;
}

export interface RepoTrade {
  id: string;
  borrowerId: string;
  lenderId: string;
  collateralIsin: string;
  collateralUnits: number;
  collateralValue: number;
  cashAmount: number;
  haircutPercent: number;
  repoRatePercent: number;
  startDate: string;
  maturityDate: string;
  status: 'INITIATED' | 'COLLATERAL_LOCKED' | 'CASH_SETTLED' | 'ACTIVE' | 'MARGIN_CALL' | 'MATURED' | 'CLOSED';
}

export interface DigitalSnbBill {
  isin: string;
  series: string;
  auctionDate: string;
  settlementDate: string;
  maturityDate: string;
  targetVolume: number; // CHF
  allocatedVolume: number; // CHF
  yieldPercent: number;
  status: 'ANNOUNCED' | 'BIDDING' | 'ALLOCATED' | 'SETTLED' | 'MATURED';
  bids: {
    institutionId: string;
    amount: number;
    bidYieldPercent: number;
    allocatedAmount?: number;
  }[];
}

export interface DltNode {
  id: string;
  name: string;
  role: 'SNB_VALIDATOR' | 'BANK_NODE' | 'INFRASTRUCTURE_OPERATOR' | 'SETTLEMENT_ENGINE' | 'AUDIT_OBSERVER';
  institutionId?: string;
  status: 'ONLINE' | 'SYNCHRONIZING' | 'OFFLINE' | 'DEGRADED';
  latencyMs: number;
  blockHeight: number;
  peersCount: number;
  txProcessed: number;
}

export interface SicQueueItem {
  id: string;
  timestamp: number;
  senderId: string;
  receiverId: string;
  amount: number;
  priority: PriorityLevel;
  status: 'QUEUED' | 'SETTLED' | 'WAITING_FOR_LIQUIDITY' | 'REJECTED';
  purpose: 'RTGS_LINK_SYNC' | 'INTERBANK_PAYMENT' | 'SNB_RESERVE_TRANSFER' | 'MONETARY_POLICY';
}

export interface CyberIncident {
  id: string;
  timestamp: number;
  type: 'RTGS_SYNCHRONISATION_ANOMALY' | 'DLT_NODE_DISCONNECT' | 'RECONCILIATION_MISMATCH' | 'LATENCY_SPIKE' | 'UNAUTHORIZED_PAYMENT_ATTEMPT';
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  affectedComponent: string;
  status: 'INVESTIGATING' | 'CONTAINED' | 'RESOLVED' | 'MITIGATED';
  details: string;
}

export interface AuditRecord {
  id: string;
  timestamp: number;
  eventType: string;
  actor: string;
  details: string;
  amountChf?: number;
  txHash?: string;
  doubleEntryLegs: {
    account: string;
    debit: number;
    credit: number;
  }[];
}

export interface CrossBorderCorridor {
  pair: 'CHF/EUR' | 'CHF/USD' | 'CHF/GBP' | 'CHF/JPY';
  foreignCentralBank: string;
  exchangeRate: number;
  dailyVolumeChf: number;
  avgLatencySec: number;
  liquidityPoolChf: number;
  status: 'OPERATIONAL' | 'DEGRADED';
}

export interface SystemMetrics {
  wholesaleCbdcOutstanding: number;
  tokenisedAssetsTotal: number;
  dailySettlementValue: number;
  dvpTransactionsCount: number;
  repoValueOutstanding: number;
  avgSettlementLatencySec: number;
  dltTps: number;
  rtgsLinkLatencySec: number;
}
