import React from 'react';
import { useSimulationStore } from './simulation/simulationEngine';
import { HeaderBanner } from './components/layout/HeaderBanner';
import { TopStatusBar } from './components/layout/TopStatusBar';
import { NavigationTabs } from './components/layout/NavigationTabs';
import { Footer } from './components/layout/Footer';

// Views
import { CommandCenterView } from './components/views/CommandCenterView';
import { SnbCoreView } from './components/views/SnbCoreView';
import { WholesaleCbdcView } from './components/views/WholesaleCbdcView';
import { FinancialInstitutionsView } from './components/views/FinancialInstitutionsView';
import { DltPlatformView } from './components/views/DltPlatformView';
import { TokenisedMarketView } from './components/views/TokenisedMarketView';
import { DvpEngineView } from './components/views/DvpEngineView';
import { HelvetiaModelAView } from './components/views/HelvetiaModelAView';
import { HelvetiaModelBView } from './components/views/HelvetiaModelBView';
import { SicSimulatorView } from './components/views/SicSimulatorView';
import { RtgsLinkView } from './components/views/RtgsLinkView';
import { RepoMarketView } from './components/views/RepoMarketView';
import { MonetaryPolicyView } from './components/views/MonetaryPolicyView';
import { CollateralManagementView } from './components/views/CollateralManagementView';
import { LiquidityControlView } from './components/views/LiquidityControlView';
import { FinancialStabilityView } from './components/views/FinancialStabilityView';
import { CrossBorderView } from './components/views/CrossBorderView';
import { PrivacyGovernanceView } from './components/views/PrivacyGovernanceView';
import { CybersecurityView } from './components/views/CybersecurityView';
import { AuditTrailView } from './components/views/AuditTrailView';
import { SystemComparisonView } from './components/views/SystemComparisonView';
import { ChaosEngineeringView } from './components/views/ChaosEngineeringView';
import { RetailCbdcResearchView } from './components/views/RetailCbdcResearchView';

export default function App() {
  const { activeTab } = useSimulationStore();

  const renderActiveView = () => {
    switch (activeTab) {
      case 'command-center':
        return <CommandCenterView />;
      case 'snb-core':
        return <SnbCoreView />;
      case 'wholesale-cbdc':
        return <WholesaleCbdcView />;
      case 'financial-institutions':
        return <FinancialInstitutionsView />;
      case 'dlt-platform':
        return <DltPlatformView />;
      case 'tokenised-assets':
        return <TokenisedMarketView />;
      case 'dvp-engine':
        return <DvpEngineView />;
      case 'helvetia-a':
        return <HelvetiaModelAView />;
      case 'helvetia-b':
        return <HelvetiaModelBView />;
      case 'sic-simulator':
        return <SicSimulatorView />;
      case 'rtgs-link':
        return <RtgsLinkView />;
      case 'repo-market':
        return <RepoMarketView />;
      case 'monetary-policy':
        return <MonetaryPolicyView />;
      case 'collateral':
        return <CollateralManagementView />;
      case 'liquidity':
        return <LiquidityControlView />;
      case 'stability':
        return <FinancialStabilityView />;
      case 'cross-border':
        return <CrossBorderView />;
      case 'privacy':
        return <PrivacyGovernanceView />;
      case 'security':
        return <CybersecurityView />;
      case 'audit':
        return <AuditTrailView />;
      case 'comparison':
        return <SystemComparisonView />;
      case 'chaos':
        return <ChaosEngineeringView />;
      case 'retail-research':
        return <RetailCbdcResearchView />;
      default:
        return <CommandCenterView />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-red-900 selection:text-white">
      {/* Institutional Top Header */}
      <HeaderBanner />

      {/* Real-time System Telemetry Status Bar */}
      <TopStatusBar />

      {/* Module Navigation Bar */}
      <NavigationTabs />

      {/* Main Module Workbench View Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 space-y-6">
        {renderActiveView()}
      </main>

      {/* Institutional Research & Engineering Disclaimer Footer */}
      <Footer />
    </div>
  );
}
