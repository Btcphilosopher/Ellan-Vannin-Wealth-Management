import { create } from 'zustand';
import {
  Language,
  SnbBalanceSheet,
  FinancialInstitution,
  TokenisedAsset,
  DvpTransaction,
  RepoTrade,
  DigitalSnbBill,
  DltNode,
  SicQueueItem,
  CyberIncident,
  AuditRecord,
  CrossBorderCorridor,
  SystemMetrics,
  SettlementModel,
} from '../types/simulation';
import {
  initialSnbBalanceSheet,
  initialInstitutions,
  initialTokenisedAssets,
  initialDltNodes,
  initialCrossBorderCorridors,
  initialCyberIncidents,
  initialSnbBills,
  initialSystemMetrics,
} from '../data/seedData';

interface SimulationState {
  // Config & Language
  language: Language;
  setLanguage: (lang: Language) => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;

  // Clock & Speed
  simulationSpeed: number; // 1, 10, 100, 1000, 10000
  isRunning: boolean;
  blockHeight: number;
  tickCount: number;
  setSimulationSpeed: (speed: number) => void;
  toggleSimulationRunning: () => void;
  tickSimulation: () => void;

  // State
  snbBalanceSheet: SnbBalanceSheet;
  institutions: FinancialInstitution[];
  tokenisedAssets: TokenisedAsset[];
  dvpTransactions: DvpTransaction[];
  repoTrades: RepoTrade[];
  snbBills: DigitalSnbBill[];
  dltNodes: DltNode[];
  sicQueue: SicQueueItem[];
  cyberIncidents: CyberIncident[];
  auditRecords: AuditRecord[];
  crossBorderCorridors: CrossBorderCorridor[];
  systemMetrics: SystemMetrics;

  // Failure & Chaos Toggles
  dltNodeFailures: Record<string, boolean>;
  rtgsLinkStatus: 'OPERATIONAL' | 'DEGRADED' | 'DISCONNECTED';
  rtgsLinkLatencyMs: number;
  sicStatus: 'OPERATIONAL' | 'PAUSED';

  // Core Actions
  issueWchf: (institutionId: string, amountChf: number) => boolean;
  redeemWchf: (institutionId: string, amountChf: number) => boolean;
  transferWchf: (senderId: string, receiverId: string, amountChf: number) => boolean;
  freezeAccount: (institutionId: string) => void;
  reconcileLedgers: () => { matched: boolean; details: string };

  // DVP Engine Actions
  executeDvp: (params: {
    model: SettlementModel;
    buyerId: string;
    sellerId: string;
    assetIsin: string;
    assetAmount: number; // units
  }) => DvpTransaction;

  // Repo Actions
  createRepoTrade: (params: {
    borrowerId: string;
    lenderId: string;
    collateralIsin: string;
    collateralUnits: number;
    cashAmount: number;
    repoRatePercent: number;
    termDays: number;
  }) => boolean;
  closeRepoTrade: (repoId: string) => boolean;

  // Monetary Operations & Bills
  createSnbBillAuction: (seriesName: string, targetVolumeChf: number, yieldPercent: number) => void;
  submitBillBid: (billIsin: string, institutionId: string, amountChf: number, bidYield: number) => boolean;

  // Chaos Engineering Actions
  toggleDltNode: (nodeId: string) => void;
  setRtgsLinkState: (status: 'OPERATIONAL' | 'DEGRADED' | 'DISCONNECTED', latencyMs: number) => void;
  injectLiquidityShock: (institutionId: string, shockAmountChf: number) => void;
  defaultCounterparty: (institutionId: string) => void;
  runRecoveryEngine: () => void;

  // Reset
  resetSimulation: () => void;
}

export const useSimulationStore = create<SimulationState>((set, get) => ({
  language: 'en',
  setLanguage: (lang) => set({ language: lang }),
  activeTab: 'command-center',
  setActiveTab: (tab) => set({ activeTab: tab }),

  simulationSpeed: 1,
  isRunning: true,
  blockHeight: 894210,
  tickCount: 0,
  setSimulationSpeed: (speed) => set({ simulationSpeed: speed }),
  toggleSimulationRunning: () => set((state) => ({ isRunning: !state.isRunning })),

  snbBalanceSheet: { ...initialSnbBalanceSheet },
  institutions: [...initialInstitutions],
  tokenisedAssets: [...initialTokenisedAssets],
  dvpTransactions: [],
  repoTrades: [],
  snbBills: [...initialSnbBills],
  dltNodes: [...initialDltNodes],
  sicQueue: [],
  cyberIncidents: [...initialCyberIncidents],
  auditRecords: [
    {
      id: 'AUD-0001',
      timestamp: Date.now() - 7200000,
      eventType: 'SYSTEM_GENESIS_RECONCILIATION',
      actor: 'Schweizerische Nationalbank',
      details: 'Initial double-entry ledger state reconciled with sight deposits and DLT wCHF balances.',
      amountChf: 84_700_000_000,
      doubleEntryLegs: [
        { account: 'SNB Liability: Sight Deposits', debit: 84_700_000_000, credit: 0 },
        { account: 'SNB Liability: wCHF Outstanding', debit: 0, credit: 84_700_000_000 },
      ],
    },
  ],
  crossBorderCorridors: [...initialCrossBorderCorridors],
  systemMetrics: { ...initialSystemMetrics },

  dltNodeFailures: {},
  rtgsLinkStatus: 'OPERATIONAL',
  rtgsLinkLatencyMs: 0.71,
  sicStatus: 'OPERATIONAL',

  issueWchf: (institutionId, amountChf) => {
    const state = get();
    const inst = state.institutions.find((i) => i.id === institutionId);
    if (!inst || inst.status === 'FROZEN') return false;
    if (inst.snbSightDeposit < amountChf) return false; // Convert from sight deposit

    // Double-entry accounting:
    // SNB Balance Sheet:
    // Debit Liabilities: Sight Deposits (reduced)
    // Credit Liabilities: Wholesale CBDC Outstanding (increased)
    const updatedSnbSheet: SnbBalanceSheet = {
      ...state.snbBalanceSheet,
      liabilities: {
        ...state.snbBalanceSheet.liabilities,
        sightDeposits: state.snbBalanceSheet.liabilities.sightDeposits - amountChf,
        wholesaleCbdcOutstanding: state.snbBalanceSheet.liabilities.wholesaleCbdcOutstanding + amountChf,
      },
    };

    // Bank Balance Sheet:
    // Debit Asset: wCHF Balance (increased)
    // Credit Asset: SNB Sight Deposit (decreased)
    const updatedInstitutions = state.institutions.map((i) => {
      if (i.id === institutionId) {
        return {
          ...i,
          snbSightDeposit: i.snbSightDeposit - amountChf,
          wChfBalance: i.wChfBalance + amountChf,
        };
      }
      return i;
    });

    const newAudit: AuditRecord = {
      id: `AUD-${Date.now().toString().slice(-6)}`,
      timestamp: Date.now(),
      eventType: 'wCHF_ISSUANCE',
      actor: 'Schweizerische Nationalbank',
      details: `Issued CHF ${amountChf.toLocaleString()} wCHF to ${inst.name} against SNB sight deposit conversion.`,
      amountChf,
      doubleEntryLegs: [
        { account: `SNB Liability: Sight Deposits (${inst.code})`, debit: amountChf, credit: 0 },
        { account: `SNB Liability: Wholesale CBDC Outstanding`, debit: 0, credit: amountChf },
        { account: `${inst.name} Asset: wCHF Balance`, debit: amountChf, credit: 0 },
        { account: `${inst.name} Asset: SNB Sight Deposit`, debit: 0, credit: amountChf },
      ],
    };

    set({
      snbBalanceSheet: updatedSnbSheet,
      institutions: updatedInstitutions,
      auditRecords: [newAudit, ...state.auditRecords],
      systemMetrics: {
        ...state.systemMetrics,
        wholesaleCbdcOutstanding: updatedSnbSheet.liabilities.wholesaleCbdcOutstanding,
      },
    });

    return true;
  },

  redeemWchf: (institutionId, amountChf) => {
    const state = get();
    const inst = state.institutions.find((i) => i.id === institutionId);
    if (!inst || inst.status === 'FROZEN') return false;
    if (inst.wChfBalance < amountChf) return false;

    // Double-entry accounting:
    // SNB Liabilities: wCHF Outstanding decreases, Sight Deposits increases
    const updatedSnbSheet: SnbBalanceSheet = {
      ...state.snbBalanceSheet,
      liabilities: {
        ...state.snbBalanceSheet.liabilities,
        wholesaleCbdcOutstanding: state.snbBalanceSheet.liabilities.wholesaleCbdcOutstanding - amountChf,
        sightDeposits: state.snbBalanceSheet.liabilities.sightDeposits + amountChf,
      },
    };

    // Bank Assets: wCHF Balance decreases, SNB Sight Deposit increases
    const updatedInstitutions = state.institutions.map((i) => {
      if (i.id === institutionId) {
        return {
          ...i,
          wChfBalance: i.wChfBalance - amountChf,
          snbSightDeposit: i.snbSightDeposit + amountChf,
        };
      }
      return i;
    });

    const newAudit: AuditRecord = {
      id: `AUD-${Date.now().toString().slice(-6)}`,
      timestamp: Date.now(),
      eventType: 'wCHF_REDEMPTION',
      actor: inst.name,
      details: `Redeemed CHF ${amountChf.toLocaleString()} wCHF for traditional SNB sight deposit.`,
      amountChf,
      doubleEntryLegs: [
        { account: `SNB Liability: Wholesale CBDC Outstanding`, debit: amountChf, credit: 0 },
        { account: `SNB Liability: Sight Deposits (${inst.code})`, debit: 0, credit: amountChf },
        { account: `${inst.name} Asset: SNB Sight Deposit`, debit: amountChf, credit: 0 },
        { account: `${inst.name} Asset: wCHF Balance`, debit: 0, credit: amountChf },
      ],
    };

    set({
      snbBalanceSheet: updatedSnbSheet,
      institutions: updatedInstitutions,
      auditRecords: [newAudit, ...state.auditRecords],
      systemMetrics: {
        ...state.systemMetrics,
        wholesaleCbdcOutstanding: updatedSnbSheet.liabilities.wholesaleCbdcOutstanding,
      },
    });

    return true;
  },

  transferWchf: (senderId, receiverId, amountChf) => {
    const state = get();
    const sender = state.institutions.find((i) => i.id === senderId);
    const receiver = state.institutions.find((i) => i.id === receiverId);

    if (!sender || !receiver || sender.status === 'FROZEN' || receiver.status === 'FROZEN') return false;
    if (sender.wChfBalance < amountChf) return false;

    const updatedInstitutions = state.institutions.map((i) => {
      if (i.id === senderId) {
        return { ...i, wChfBalance: i.wChfBalance - amountChf };
      }
      if (i.id === receiverId) {
        return { ...i, wChfBalance: i.wChfBalance + amountChf };
      }
      return i;
    });

    const newAudit: AuditRecord = {
      id: `AUD-${Date.now().toString().slice(-6)}`,
      timestamp: Date.now(),
      eventType: 'wCHF_DIRECT_TRANSFER',
      actor: sender.name,
      details: `Transferred CHF ${amountChf.toLocaleString()} wCHF on DLT to ${receiver.name}.`,
      amountChf,
      doubleEntryLegs: [
        { account: `${sender.name} Asset: wCHF Balance`, debit: 0, credit: amountChf },
        { account: `${receiver.name} Asset: wCHF Balance`, debit: amountChf, credit: 0 },
      ],
    };

    set({
      institutions: updatedInstitutions,
      auditRecords: [newAudit, ...state.auditRecords],
    });

    return true;
  },

  freezeAccount: (institutionId) => {
    const state = get();
    const updatedInstitutions = state.institutions.map((i) => {
      if (i.id === institutionId) {
        const newStatus = i.status === 'FROZEN' ? ('ACTIVE' as const) : ('FROZEN' as const);
        return { ...i, status: newStatus };
      }
      return i;
    });
    set({ institutions: updatedInstitutions });
  },

  reconcileLedgers: () => {
    const state = get();
    const totalWchfInBanks = state.institutions.reduce((acc, i) => acc + i.wChfBalance, 0);
    const snbWchfLiab = state.snbBalanceSheet.liabilities.wholesaleCbdcOutstanding;

    // Small rounding threshold in simulation
    const delta = Math.abs(totalWchfInBanks - snbWchfLiab);
    const matched = delta < 1000;

    const audit: AuditRecord = {
      id: `AUD-${Date.now().toString().slice(-6)}`,
      timestamp: Date.now(),
      eventType: 'SYSTEM_RECONCILIATION',
      actor: 'FINMA / SNB Auditor Engine',
      details: matched
        ? `Reconciliation SUCCESS: DLT wCHF sum (CHF ${totalWchfInBanks.toLocaleString()}) matches SNB Liability (CHF ${snbWchfLiab.toLocaleString()}).`
        : `Reconciliation MISMATCH: Delta of CHF ${delta.toLocaleString()} between DLT sum and SNB Liability.`,
      amountChf: totalWchfInBanks,
      doubleEntryLegs: [],
    };

    set({ auditRecords: [audit, ...state.auditRecords] });

    return {
      matched,
      details: audit.details,
    };
  },

  executeDvp: ({ model, buyerId, sellerId, assetIsin, assetAmount }) => {
    const state = get();
    const buyer = state.institutions.find((i) => i.id === buyerId);
    const seller = state.institutions.find((i) => i.id === sellerId);
    const asset = state.tokenisedAssets.find((a) => a.isin === assetIsin);

    const txId = `DVP-${Date.now().toString().slice(-6)}`;
    const price = asset ? asset.unitPrice : 100;
    const totalCashValue = (assetAmount * (asset ? asset.nominalValue / 10000 : 1000) * price) / 100;

    if (!buyer || !seller || !asset) {
      const failedTx: DvpTransaction = {
        id: txId,
        timestamp: Date.now(),
        model,
        buyerId,
        sellerId,
        assetIsin,
        assetAmount,
        unitPrice: price,
        totalCashValue,
        status: 'FAILED',
        failureReason: 'Invalid participant or asset entity',
        statusSteps: [{ stepName: 'ASSET_RESERVED', status: 'FAILED' }],
      };
      set({ dvpTransactions: [failedTx, ...state.dvpTransactions] });
      return failedTx;
    }

    const sellerHoldings = asset.holders[sellerId] || 0;

    // Check seller asset availability
    if (sellerHoldings < assetAmount) {
      const failedTx: DvpTransaction = {
        id: txId,
        timestamp: Date.now(),
        model,
        buyerId,
        sellerId,
        assetIsin,
        assetAmount,
        unitPrice: price,
        totalCashValue,
        status: 'FAILED',
        failureReason: `Seller ${seller.code} has insufficient tokenised asset balance (${sellerHoldings} available, ${assetAmount} required)`,
        statusSteps: [
          { stepName: 'Asset Verification', status: 'FAILED' },
          { stepName: 'Cash Reservation', status: 'PENDING' },
          { stepName: 'Atomic Settlement', status: 'PENDING' },
        ],
      };
      set({ dvpTransactions: [failedTx, ...state.dvpTransactions] });
      return failedTx;
    }

    // Check cash availability depending on Model A vs Model B
    if (model === 'MODEL_A_INTEGRATED') {
      if (buyer.wChfBalance < totalCashValue) {
        const failedTx: DvpTransaction = {
          id: txId,
          timestamp: Date.now(),
          model,
          buyerId,
          sellerId,
          assetIsin,
          assetAmount,
          unitPrice: price,
          totalCashValue,
          status: 'ROLLED_BACK',
          failureReason: `Model A Atomic Lock Failed: Buyer ${buyer.code} lacks required wCHF balance (CHF ${totalCashValue.toLocaleString()} needed, CHF ${buyer.wChfBalance.toLocaleString()} available)`,
          statusSteps: [
            { stepName: 'Asset Reserved on DLT', status: 'COMPLETED' },
            { stepName: 'wCHF Cash Lock on DLT', status: 'FAILED' },
            { stepName: 'Atomic Swap Execution', status: 'PENDING' },
          ],
        };
        set({ dvpTransactions: [failedTx, ...state.dvpTransactions] });
        return failedTx;
      }

      // Check DLT infrastructure health / node failures
      if (state.dltNodes.some((n) => n.status === 'OFFLINE' && n.role === 'SETTLEMENT_ENGINE')) {
        const failedTx: DvpTransaction = {
          id: txId,
          timestamp: Date.now(),
          model,
          buyerId,
          sellerId,
          assetIsin,
          assetAmount,
          unitPrice: price,
          totalCashValue,
          status: 'ROLLED_BACK',
          failureReason: 'DLT Settlement Engine primary node is OFFLINE. DVP state transition rejected.',
          statusSteps: [
            { stepName: 'Asset Lock', status: 'COMPLETED' },
            { stepName: 'wCHF Lock', status: 'COMPLETED' },
            { stepName: 'DLT Node Consensus', status: 'FAILED' },
          ],
        };
        set({ dvpTransactions: [failedTx, ...state.dvpTransactions] });
        return failedTx;
      }

      // SUCCESS Model A: Integrated Atomic Swap
      const updatedInstitutions = state.institutions.map((i) => {
        if (i.id === buyerId) {
          return {
            ...i,
            wChfBalance: i.wChfBalance - totalCashValue,
            tokenisedAssetsValue: i.tokenisedAssetsValue + totalCashValue,
          };
        }
        if (i.id === sellerId) {
          return {
            ...i,
            wChfBalance: i.wChfBalance + totalCashValue,
            tokenisedAssetsValue: Math.max(0, i.tokenisedAssetsValue - totalCashValue),
          };
        }
        return i;
      });

      const updatedAssetHolders = {
        ...asset.holders,
        [sellerId]: sellerHoldings - assetAmount,
        [buyerId]: (asset.holders[buyerId] || 0) + assetAmount,
      };

      const updatedAssets = state.tokenisedAssets.map((a) =>
        a.isin === assetIsin ? { ...a, holders: updatedAssetHolders } : a
      );

      const successfulTx: DvpTransaction = {
        id: txId,
        timestamp: Date.now(),
        model,
        buyerId,
        sellerId,
        assetIsin,
        assetAmount,
        unitPrice: price,
        totalCashValue,
        status: 'SETTLED',
        txHashDLT: `0x${Math.random().toString(16).substring(2, 10)}${Math.random().toString(16).substring(2, 10)}`,
        statusSteps: [
          { stepName: 'Asset Token Reserved on DLT', status: 'COMPLETED' },
          { stepName: 'wCHF Token Reserved on DLT', status: 'COMPLETED' },
          { stepName: 'Atomic State Transition Matched', status: 'COMPLETED' },
          { stepName: 'Simultaneous Ledger Finality', status: 'COMPLETED' },
        ],
      };

      const audit: AuditRecord = {
        id: `AUD-${Date.now().toString().slice(-6)}`,
        timestamp: Date.now(),
        eventType: 'DVP_MODEL_A_SETTLEMENT',
        actor: 'SIX DLT Integrated Settlement Engine',
        details: `Integrated Model A Atomic DVP: ${buyer.name} bought ${assetAmount} units of ${asset.symbol} from ${seller.name} for CHF ${totalCashValue.toLocaleString()} wCHF.`,
        amountChf: totalCashValue,
        txHash: successfulTx.txHashDLT,
        doubleEntryLegs: [
          { account: `${buyer.name} Asset: wCHF Balance`, debit: 0, credit: totalCashValue },
          { account: `${buyer.name} Asset: Tokenised ${asset.symbol}`, debit: totalCashValue, credit: 0 },
          { account: `${seller.name} Asset: Tokenised ${asset.symbol}`, debit: 0, credit: totalCashValue },
          { account: `${seller.name} Asset: wCHF Balance`, debit: totalCashValue, credit: 0 },
        ],
      };

      set({
        institutions: updatedInstitutions,
        tokenisedAssets: updatedAssets,
        dvpTransactions: [successfulTx, ...state.dvpTransactions],
        auditRecords: [audit, ...state.auditRecords],
        systemMetrics: {
          ...state.systemMetrics,
          dvpTransactionsCount: state.systemMetrics.dvpTransactionsCount + 1,
          dailySettlementValue: state.systemMetrics.dailySettlementValue + totalCashValue,
        },
      });

      return successfulTx;
    } else {
      // MODEL B: Synchronised Settlement (Securities on DLT, Cash on SIC RTGS via RTGS Link)
      if (buyer.snbSightDeposit < totalCashValue) {
        const failedTx: DvpTransaction = {
          id: txId,
          timestamp: Date.now(),
          model,
          buyerId,
          sellerId,
          assetIsin,
          assetAmount,
          unitPrice: price,
          totalCashValue,
          status: 'ROLLED_BACK',
          failureReason: `Model B RTGS Lock Failed: Buyer ${buyer.code} has insufficient traditional SNB sight deposit in SIC (CHF ${totalCashValue.toLocaleString()} required, CHF ${buyer.snbSightDeposit.toLocaleString()} available)`,
          statusSteps: [
            { stepName: 'DLT Asset Token Reserved', status: 'COMPLETED' },
            { stepName: 'RTGS Instruction Dispatched', status: 'COMPLETED' },
            { stepName: 'SIC Sight Deposit Settlement', status: 'FAILED' },
            { stepName: 'Atomic Rollback Initiated', status: 'COMPLETED' },
          ],
        };
        set({ dvpTransactions: [failedTx, ...state.dvpTransactions] });
        return failedTx;
      }

      if (state.rtgsLinkStatus === 'DISCONNECTED') {
        const failedTx: DvpTransaction = {
          id: txId,
          timestamp: Date.now(),
          model,
          buyerId,
          sellerId,
          assetIsin,
          assetAmount,
          unitPrice: price,
          totalCashValue,
          status: 'ROLLED_BACK',
          failureReason: 'Model B RTGS Link Bridge is DISCONNECTED. Instruction transmission timed out.',
          statusSteps: [
            { stepName: 'DLT Asset Token Reserved', status: 'COMPLETED' },
            { stepName: 'RTGS Link Transmission', status: 'FAILED' },
            { stepName: 'DLT Asset Lock Released', status: 'COMPLETED' },
          ],
        };
        set({ dvpTransactions: [failedTx, ...state.dvpTransactions] });
        return failedTx;
      }

      // SUCCESS Model B: Synchronised Settlement
      const sicRef = `SIC-RTGS-${Math.floor(100000 + Math.random() * 900000)}`;

      // Update SNB Sight Deposits in SIC
      const updatedInstitutions = state.institutions.map((i) => {
        if (i.id === buyerId) {
          return {
            ...i,
            snbSightDeposit: i.snbSightDeposit - totalCashValue,
            tokenisedAssetsValue: i.tokenisedAssetsValue + totalCashValue,
          };
        }
        if (i.id === sellerId) {
          return {
            ...i,
            snbSightDeposit: i.snbSightDeposit + totalCashValue,
            tokenisedAssetsValue: Math.max(0, i.tokenisedAssetsValue - totalCashValue),
          };
        }
        return i;
      });

      const updatedAssetHolders = {
        ...asset.holders,
        [sellerId]: sellerHoldings - assetAmount,
        [buyerId]: (asset.holders[buyerId] || 0) + assetAmount,
      };

      const updatedAssets = state.tokenisedAssets.map((a) =>
        a.isin === assetIsin ? { ...a, holders: updatedAssetHolders } : a
      );

      const successfulTx: DvpTransaction = {
        id: txId,
        timestamp: Date.now(),
        model,
        buyerId,
        sellerId,
        assetIsin,
        assetAmount,
        unitPrice: price,
        totalCashValue,
        status: 'SETTLED',
        txHashDLT: `0x${Math.random().toString(16).substring(2, 10)}`,
        sicReference: sicRef,
        rtgsLinkLatencyMs: state.rtgsLinkLatencyMs * 1000,
        statusSteps: [
          { stepName: 'DLT Asset Lock', status: 'COMPLETED' },
          { stepName: 'RTGS Link Message Dispatched', status: 'COMPLETED' },
          { stepName: 'SIC RTGS Cash Settlement Executed', status: 'COMPLETED' },
          { stepName: 'SIC Confirmation Delivered to DLT', status: 'COMPLETED' },
          { stepName: 'DLT Asset Released to Buyer', status: 'COMPLETED' },
        ],
      };

      const audit: AuditRecord = {
        id: `AUD-${Date.now().toString().slice(-6)}`,
        timestamp: Date.now(),
        eventType: 'DVP_MODEL_B_SETTLEMENT',
        actor: 'SIC / RTGS Link Synchroniser',
        details: `Synchronised Model B DVP: ${buyer.name} bought ${assetAmount} units of ${asset.symbol} from ${seller.name} via SIC RTGS cash leg (Ref: ${sicRef}).`,
        amountChf: totalCashValue,
        txHash: successfulTx.txHashDLT,
        doubleEntryLegs: [
          { account: `${buyer.name} Asset: SNB Sight Deposit`, debit: 0, credit: totalCashValue },
          { account: `${buyer.name} Asset: Tokenised ${asset.symbol}`, debit: totalCashValue, credit: 0 },
          { account: `${seller.name} Asset: Tokenised ${asset.symbol}`, debit: 0, credit: totalCashValue },
          { account: `${seller.name} Asset: SNB Sight Deposit`, debit: totalCashValue, credit: 0 },
        ],
      };

      set({
        institutions: updatedInstitutions,
        tokenisedAssets: updatedAssets,
        dvpTransactions: [successfulTx, ...state.dvpTransactions],
        auditRecords: [audit, ...state.auditRecords],
        systemMetrics: {
          ...state.systemMetrics,
          dvpTransactionsCount: state.systemMetrics.dvpTransactionsCount + 1,
          dailySettlementValue: state.systemMetrics.dailySettlementValue + totalCashValue,
        },
      });

      return successfulTx;
    }
  },

  createRepoTrade: ({ borrowerId, lenderId, collateralIsin, collateralUnits, cashAmount, repoRatePercent, termDays }) => {
    const state = get();
    const borrower = state.institutions.find((i) => i.id === borrowerId);
    const lender = state.institutions.find((i) => i.id === lenderId);
    const collateral = state.tokenisedAssets.find((a) => a.isin === collateralIsin);

    if (!borrower || !lender || !collateral) return false;
    if (lender.wChfBalance < cashAmount) return false;

    const repoId = `REPO-${Date.now().toString().slice(-6)}`;
    const newRepo: RepoTrade = {
      id: repoId,
      borrowerId,
      lenderId,
      collateralIsin,
      collateralUnits,
      collateralValue: cashAmount * (1 + collateral.haircut / 100),
      cashAmount,
      haircutPercent: collateral.haircut,
      repoRatePercent,
      startDate: new Date().toISOString().split('T')[0],
      maturityDate: new Date(Date.now() + termDays * 86400000).toISOString().split('T')[0],
      status: 'ACTIVE',
    };

    // Execute initial repo cash & collateral legs:
    // Lender gives wCHF to Borrower, Borrower locks collateral
    const updatedInstitutions = state.institutions.map((i) => {
      if (i.id === borrowerId) {
        return {
          ...i,
          wChfBalance: i.wChfBalance + cashAmount,
          collateralPledged: i.collateralPledged + newRepo.collateralValue,
          repoObligations: i.repoObligations + cashAmount,
        };
      }
      if (i.id === lenderId) {
        return {
          ...i,
          wChfBalance: i.wChfBalance - cashAmount,
        };
      }
      return i;
    });

    const audit: AuditRecord = {
      id: `AUD-${Date.now().toString().slice(-6)}`,
      timestamp: Date.now(),
      eventType: 'DIGITAL_REPO_INITIATED',
      actor: `${borrower.name} / ${lender.name}`,
      details: `Repo Trade ${repoId}: ${borrower.name} borrowed CHF ${cashAmount.toLocaleString()} wCHF from ${lender.name} at ${repoRatePercent}% rate against ${collateral.symbol} collateral.`,
      amountChf: cashAmount,
      doubleEntryLegs: [
        { account: `${lender.name} Asset: wCHF Balance`, debit: 0, credit: cashAmount },
        { account: `${borrower.name} Asset: wCHF Balance`, debit: cashAmount, credit: 0 },
        { account: `${borrower.name} Liability: Repo Obligation`, debit: 0, credit: cashAmount },
      ],
    };

    set({
      repoTrades: [newRepo, ...state.repoTrades],
      institutions: updatedInstitutions,
      auditRecords: [audit, ...state.auditRecords],
      systemMetrics: {
        ...state.systemMetrics,
        repoValueOutstanding: state.systemMetrics.repoValueOutstanding + cashAmount,
      },
    });

    return true;
  },

  closeRepoTrade: (repoId) => {
    const state = get();
    const repo = state.repoTrades.find((r) => r.id === repoId);
    if (!repo || repo.status !== 'ACTIVE') return false;

    const borrower = state.institutions.find((i) => i.id === repo.borrowerId);
    const lender = state.institutions.find((i) => i.id === repo.lenderId);
    if (!borrower || !lender) return false;

    const repaymentAmount = repo.cashAmount * (1 + repo.repoRatePercent / 100);
    if (borrower.wChfBalance < repaymentAmount) return false;

    const updatedRepoTrades = state.repoTrades.map((r) =>
      r.id === repoId ? ({ ...r, status: 'CLOSED' } as RepoTrade) : r
    );

    const updatedInstitutions = state.institutions.map((i) => {
      if (i.id === repo.borrowerId) {
        return {
          ...i,
          wChfBalance: i.wChfBalance - repaymentAmount,
          collateralPledged: Math.max(0, i.collateralPledged - repo.collateralValue),
          repoObligations: Math.max(0, i.repoObligations - repo.cashAmount),
        };
      }
      if (i.id === repo.lenderId) {
        return {
          ...i,
          wChfBalance: i.wChfBalance + repaymentAmount,
        };
      }
      return i;
    });

    const audit: AuditRecord = {
      id: `AUD-${Date.now().toString().slice(-6)}`,
      timestamp: Date.now(),
      eventType: 'DIGITAL_REPO_CLOSED',
      actor: borrower.name,
      details: `Repo Trade ${repoId} Matured & Closed: Repaid CHF ${repaymentAmount.toLocaleString()} wCHF to ${lender.name}. Collateral released.`,
      amountChf: repaymentAmount,
      doubleEntryLegs: [
        { account: `${borrower.name} Asset: wCHF Balance`, debit: 0, credit: repaymentAmount },
        { account: `${borrower.name} Liability: Repo Obligation`, debit: repo.cashAmount, credit: 0 },
        { account: `${lender.name} Asset: wCHF Balance`, debit: repaymentAmount, credit: 0 },
      ],
    };

    set({
      repoTrades: updatedRepoTrades,
      institutions: updatedInstitutions,
      auditRecords: [audit, ...state.auditRecords],
      systemMetrics: {
        ...state.systemMetrics,
        repoValueOutstanding: Math.max(0, state.systemMetrics.repoValueOutstanding - repo.cashAmount),
      },
    });

    return true;
  },

  createSnbBillAuction: (seriesName, targetVolumeChf, yieldPercent) => {
    const state = get();
    const newIsin = `CH00129482${Math.floor(10 + Math.random() * 89)}`;
    const newBill: DigitalSnbBill = {
      isin: newIsin,
      series: seriesName,
      auctionDate: new Date().toISOString().split('T')[0],
      settlementDate: new Date(Date.now() + 86400000).toISOString().split('T')[0],
      maturityDate: new Date(Date.now() + 90 * 86400000).toISOString().split('T')[0],
      targetVolume: targetVolumeChf,
      allocatedVolume: 0,
      yieldPercent,
      status: 'BIDDING',
      bids: [],
    };

    set({ snbBills: [newBill, ...state.snbBills] });
  },

  submitBillBid: (billIsin, institutionId, amountChf, bidYield) => {
    const state = get();
    const bill = state.snbBills.find((b) => b.isin === billIsin);
    if (!bill || bill.status !== 'BIDDING') return false;

    const updatedBills = state.snbBills.map((b) => {
      if (b.isin === billIsin) {
        return {
          ...b,
          bids: [...b.bids, { institutionId, amount: amountChf, bidYieldPercent: bidYield }],
        };
      }
      return b;
    });

    set({ snbBills: updatedBills });
    return true;
  },

  toggleDltNode: (nodeId) => {
    const state = get();
    const updatedNodes = state.dltNodes.map((n) => {
      if (n.id === nodeId) {
        const nextStatus = n.status === 'ONLINE' ? ('OFFLINE' as const) : ('ONLINE' as const);
        return { ...n, status: nextStatus };
      }
      return n;
    });
    set({ dltNodes: updatedNodes });
  },

  setRtgsLinkState: (status, latencyMs) => {
    set({
      rtgsLinkStatus: status,
      rtgsLinkLatencyMs: latencyMs,
      systemMetrics: {
        ...get().systemMetrics,
        rtgsLinkLatencySec: latencyMs / 1000,
      },
    });
  },

  injectLiquidityShock: (institutionId, shockAmountChf) => {
    const state = get();
    const inst = state.institutions.find((i) => i.id === institutionId);
    if (!inst) return;

    const updatedInstitutions = state.institutions.map((i) => {
      if (i.id === institutionId) {
        return {
          ...i,
          wChfBalance: Math.max(0, i.wChfBalance - shockAmountChf),
          snbSightDeposit: Math.max(0, i.snbSightDeposit - shockAmountChf),
          status: 'STRESSED' as const,
          riskScore: Math.min(99, i.riskScore + 40),
        };
      }
      return i;
    });

    const incident: CyberIncident = {
      id: `HEL-${Math.floor(100 + Math.random() * 899)}`,
      timestamp: Date.now(),
      type: 'RECONCILIATION_MISMATCH',
      severity: 'HIGH',
      affectedComponent: `${inst.name} Liquidity Gateway`,
      status: 'INVESTIGATING',
      details: `Simulated liquidity shock injected: CHF ${shockAmountChf.toLocaleString()} drained from ${inst.name}. Risk level elevated to STRESSED.`,
    };

    set({
      institutions: updatedInstitutions,
      cyberIncidents: [incident, ...state.cyberIncidents],
    });
  },

  defaultCounterparty: (institutionId) => {
    const state = get();
    const inst = state.institutions.find((i) => i.id === institutionId);
    if (!inst) return;

    const updatedInstitutions = state.institutions.map((i) => {
      if (i.id === institutionId) {
        return {
          ...i,
          status: 'SUSPENDED' as const,
          riskScore: 99,
          wChfBalance: 0,
        };
      }
      return i;
    });

    const incident: CyberIncident = {
      id: `HEL-${Math.floor(100 + Math.random() * 899)}`,
      timestamp: Date.now(),
      type: 'UNAUTHORIZED_PAYMENT_ATTEMPT',
      severity: 'CRITICAL',
      affectedComponent: `${inst.name} Settlement Account`,
      status: 'CONTAINED',
      details: `Counterparty default simulated: ${inst.name} suspended from SNB wCHF settlement and DLT network consensus.`,
    };

    set({
      institutions: updatedInstitutions,
      cyberIncidents: [incident, ...state.cyberIncidents],
    });
  },

  runRecoveryEngine: () => {
    const state = get();
    // Restore nodes & statuses
    const resetNodes = state.dltNodes.map((n) => ({ ...n, status: 'ONLINE' as const }));
    const resetInstitutions = state.institutions.map((i) => ({
      ...i,
      status: 'ACTIVE' as const,
      riskScore: Math.max(5, i.riskScore - 30),
    }));

    const recoveryAudit: AuditRecord = {
      id: `AUD-${Date.now().toString().slice(-6)}`,
      timestamp: Date.now(),
      eventType: 'SYSTEM_RECOVERY_ENGINE_EXECUTION',
      actor: 'FINMA / SNB Business Continuity Engine',
      details: 'Recovery engine executed: Restored primary DLT node state, failover synchronization, and unblocked payment queues.',
      doubleEntryLegs: [],
    };

    set({
      dltNodes: resetNodes,
      institutions: resetInstitutions,
      rtgsLinkStatus: 'OPERATIONAL',
      rtgsLinkLatencyMs: 0.71,
      sicStatus: 'OPERATIONAL',
      auditRecords: [recoveryAudit, ...state.auditRecords],
    });
  },

  resetSimulation: () => {
    set({
      snbBalanceSheet: { ...initialSnbBalanceSheet },
      institutions: [...initialInstitutions],
      tokenisedAssets: [...initialTokenisedAssets],
      dvpTransactions: [],
      repoTrades: [],
      snbBills: [...initialSnbBills],
      dltNodes: [...initialDltNodes],
      sicQueue: [],
      cyberIncidents: [...initialCyberIncidents],
      crossBorderCorridors: [...initialCrossBorderCorridors],
      systemMetrics: { ...initialSystemMetrics },
      rtgsLinkStatus: 'OPERATIONAL',
      rtgsLinkLatencyMs: 0.71,
      sicStatus: 'OPERATIONAL',
    });
  },

  tickSimulation: () => {
    const state = get();
    if (!state.isRunning) return;

    const speed = state.simulationSpeed;
    const nextBlock = state.blockHeight + 1;
    const nextTick = state.tickCount + 1;

    // Periodically generate background synthetic DVP or Repo transactions or market price subtle fluctuations
    let updatedMetrics = { ...state.systemMetrics };

    // Increment simulated DVP counts and volume slightly
    updatedMetrics.dvpTransactionsCount += Math.floor((1 + Math.random() * 3) * speed);
    updatedMetrics.dailySettlementValue += Math.floor((10_000_000 + Math.random() * 50_000_000) * speed);
    updatedMetrics.dltTps = Math.floor(3500 + Math.random() * 600);

    // Update block heights on DLT nodes
    const updatedNodes = state.dltNodes.map((n) => ({
      ...n,
      blockHeight: n.status === 'ONLINE' ? nextBlock : n.blockHeight,
      txProcessed: n.status === 'ONLINE' ? n.txProcessed + Math.floor(10 * speed) : n.txProcessed,
    }));

    set({
      blockHeight: nextBlock,
      tickCount: nextTick,
      dltNodes: updatedNodes,
      systemMetrics: updatedMetrics,
    });
  },
}));
