# NordicOps — Independent Scandinavian Furniture Enterprise Workspace

An independent, IKEA-inspired Android enterprise operations concept built with **Kotlin**, **Jetpack Compose (Material 3)**, and **Room SQLite** with ACID transactions, idempotency keys, optimistic concurrency versioning, an immutable stock-movement ledger, an outbox event log, and a balanced double-entry financial subledger.

> **Disclaimer:** Independent concept demonstration with fictional furniture (`FJELL-120`, `SKAGEN-3S`, `ALVAR-140`, `NORD-200`), suppliers, factories, stores, customers, and simulated payments. No affiliation with or access to proprietary systems is implied.

## 16 Interconnected Workspaces
1. **Overview** — Executive KPIs, live exception queue, and the interactive **14-step Product-to-Customer E2E Journey**.
2. **Products** — Multi-package flat-pack structure, barcodes, spare parts, and complete-set availability calculation (`min(floor(avail_i / req_i))`).
3. **Design** — 7-stage engineering workflow (`Concept -> Design Review -> Prototype -> Testing -> Approved -> Released -> Retired`), configurable safety review criteria, and immutable Released revision guards.
4. **Suppliers** — Qualification, POs, AQL dock inspection, 3-way matching, Supplier Declaration vs Independently Verified origin evidence, and shared-factory concentration risk.
5. **Manufacturing** — Work centres, capacity utilization, explicit bottleneck/infeasible schedule flagging, scrap/rework, and quality package release.
6. **Inventory** — Multi-site & multi-zone positions (`On Hand`, `Reserved`, `Available`, `In Transit`, `Quarantined`, `Damaged`, `Display Stock`), immutable `StockMovementEntity` ledger, and inter-site transfers.
7. **Distribution** — Geometric volume estimates vs validated physical truck loads, infeasible vehicle alerts, and explicit packaging-efficiency formula.
8. **Stores** — Store tasks, aisle/bin locations, click-and-collect staging, and an interactive **2D Room Planner** with collision checks and complete-package shopping list resolution.
9. **Online Orders** — Catalogue search, delivery slot validation, atomic complete-set reservations, and 5 separated state machines (`order`, `payment`, `fulfilment`, `delivery`, `assembly`).
10. **Delivery & Assembly** — Split delivery tracking, separated delivery vs assembly completion, instruction revision pinning, missing-fitting reports, spare-part dispatch, and time-limited protected customer address windows.
11. **Returns** — RMA intake into `Quarantine` (never auto-saleable), condition grading, separated refund review, and anonymized `RESALE-LOT` approval.
12. **Customers** — Service case tracking with role-based PII masking.
13. **Workforce** — Shifts, training certifications, and equipment maintenance tickets (payroll/clinical records isolated behind external boundaries).
14. **Finance** — Balanced double-entry subledger (`SUM(debit) == SUM(credit)`), integer-cent EUR arithmetic, 25.00% half-even VAT, and 8-layer cost + step-cost margin analysis.
15. **Analytics** — Operational KPIs and 4-tier sustainability evidence separation (`Measured`, `Modelled`, `Supplier Statement`, `Verified Certification`).
16. **Administration** — Live 10-role RBAC simulator, authorization gates, immutable audit log, and transactional outbox dispatcher.

## Core Entity-Relationship Overview (Room SQLite)
- `ProductFamilyEntity` 1--* `PackageSpecEntity` 1--* `InventoryPositionEntity`
- `ProductFamilyEntity` 1--* `DesignChangeEntity` & `SparePartEntity`
- `SupplierEntity` 1--* `MaterialEvidenceEntity` & `PurchaseOrderEntity`
- `WorkCentreEntity` 1--* `ProductionOrderEntity` -> `StockMovementEntity` (idempotency-keyed)
- `CustomerEntity` 1--* `SalesOrderEntity` 1--1 `DeliveryAssemblyTaskEntity` & 1--* `ReturnCaseEntity`
- `JournalEntryEntity` 1--* `JournalLineEntity` (balanced Dr=Cr constraint)
- `AuditOutboxEntity` (transactional outbox & RBAC access audit)

## Build & Verify Locally
```bash
# Build Debug APK
gradle :app:assembleDebug

# Run JVM Unit & Robolectric Integration Tests
gradle :app:testDebugUnitTest
```
