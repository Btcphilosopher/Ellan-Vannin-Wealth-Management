package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.domain.model.CompleteProductAvailability
import com.example.domain.model.RoomItemPlacement
import com.example.ui.theme.*

enum class BadgeTone {
    NEUTRAL,
    INFO,
    VERIFIED,
    WARNING,
    EXCEPTION
}

@Composable
fun StatusBadge(
    text: String,
    tone: BadgeTone = BadgeTone.NEUTRAL,
    modifier: Modifier = Modifier
) {
    val (bg, fg) = when (tone) {
        BadgeTone.NEUTRAL -> SurfaceMuted to InkSecondary
        BadgeTone.INFO -> NordicBlueLight to DeepNordicBlue
        BadgeTone.VERIFIED -> VerifiedGreenBg to VerifiedGreen
        BadgeTone.WARNING -> WarningAmberBg to WarningAmber
        BadgeTone.EXCEPTION -> ExceptionRedBg to ExceptionRed
    }
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(bg)
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelMedium,
            color = fg,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun EnterpriseCard(
    modifier: Modifier = Modifier,
    borderColor: Color = BorderHairline,
    containerColor: Color = SurfaceWhite,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(6.dp),
        color = containerColor,
        border = BorderStroke(1.dp, borderColor),
        tonalElevation = 0.dp
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            content = content
        )
    }
}

@Composable
fun SectionHeader(
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    trailing: (@Composable () -> Unit)? = null
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.headlineSmall,
                color = InkBlack
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = InkSecondary
            )
        }
        if (trailing != null) {
            Spacer(Modifier.width(12.dp))
            trailing()
        }
    }
}

@Composable
fun KpiTile(
    label: String,
    value: String,
    caption: String,
    tone: BadgeTone = BadgeTone.NEUTRAL,
    modifier: Modifier = Modifier
) {
    val accent = when (tone) {
        BadgeTone.EXCEPTION -> ExceptionRed
        BadgeTone.VERIFIED -> VerifiedGreen
        BadgeTone.WARNING -> WarningAmber
        BadgeTone.INFO -> NordicBlue
        BadgeTone.NEUTRAL -> BorderHairline
    }
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(6.dp),
        color = SurfaceWhite,
        border = BorderStroke(1.dp, BorderHairline)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(accent)
                )
                Text(
                    text = label.uppercase(),
                    style = MaterialTheme.typography.labelMedium,
                    color = InkSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Text(
                text = value,
                style = MaterialTheme.typography.headlineMedium,
                color = if (tone == BadgeTone.EXCEPTION) ExceptionRed else InkBlack
            )
            Text(
                text = caption,
                style = MaterialTheme.typography.bodySmall,
                color = InkSecondary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun NordicPrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.heightIn(min = 48.dp),
        shape = RoundedCornerShape(4.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = WarmYellow,
            contentColor = InkBlack,
            disabledContainerColor = SurfaceMuted,
            disabledContentColor = InkSecondary
        ),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp)
    ) {
        Text(text = text, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun NordicOutlineButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.heightIn(min = 48.dp),
        shape = RoundedCornerShape(4.dp),
        border = BorderStroke(1.dp, if (enabled) NordicBlue else BorderHairline),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = NordicBlue)
    ) {
        Text(text = text, style = MaterialTheme.typography.labelLarge)
    }
}

/**
 * Scandinavian flat-pack instruction-inspired diagram illustrating multi-package
 * set completeness: having Box 1 without Box 2 = 0 complete sellable units.
 */
@Composable
fun FlatPackDiagramCanvas(
    availability: CompleteProductAvailability,
    modifier: Modifier = Modifier
) {
    val packages = availability.packageBreakdown
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .background(WarmGreyBg)
            .border(1.dp, BorderHairline, RoundedCornerShape(4.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "FLAT-PACK SET SCHEMATIC · ${availability.productCode}",
                style = MaterialTheme.typography.labelMedium,
                color = DeepNordicBlue
            )
            StatusBadge(
                text = if (availability.completeSetsAvailable > 0) {
                    "${availability.completeSetsAvailable} COMPLETE SETS"
                } else {
                    "0 COMPLETE SETS"
                },
                tone = if (availability.completeSetsAvailable > 0) BadgeTone.VERIFIED else BadgeTone.EXCEPTION
            )
        }

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(82.dp)
        ) {
            val boxCount = packages.size.coerceAtLeast(1)
            val gap = 16.dp.toPx()
            val usableW = size.width - 64.dp.toPx()
            val boxW = ((usableW - (gap * (boxCount - 1))) / boxCount).coerceAtMost(130.dp.toPx())
            val boxH = size.height - 18.dp.toPx()

            packages.forEachIndexed { idx, pkg ->
                val x = 8.dp.toPx() + idx * (boxW + gap)
                val y = 8.dp.toPx()
                val strokeColor = if (pkg.available > 0) Color(0xFF0058A3) else Color(0xFFB3261E)
                // Flat-pack isometric front face
                drawRect(
                    color = Color.White,
                    topLeft = Offset(x, y),
                    size = Size(boxW, boxH)
                )
                drawRect(
                    color = strokeColor,
                    topLeft = Offset(x, y),
                    size = Size(boxW, boxH),
                    style = Stroke(width = 2.dp.toPx())
                )
                // Flat-pack tape line & dowel symbol
                drawLine(
                    color = strokeColor.copy(alpha = 0.45f),
                    start = Offset(x, y + boxH * 0.35f),
                    end = Offset(x + boxW, y + boxH * 0.35f),
                    strokeWidth = 1.5.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 6f), 0f)
                )
                if (idx < boxCount - 1) {
                    val plusX = x + boxW + gap * 0.5f
                    val plusY = y + boxH * 0.5f
                    drawLine(
                        color = Color(0xFF111111),
                        start = Offset(plusX - 5.dp.toPx(), plusY),
                        end = Offset(plusX + 5.dp.toPx(), plusY),
                        strokeWidth = 2.dp.toPx()
                    )
                    drawLine(
                        color = Color(0xFF111111),
                        start = Offset(plusX, plusY - 5.dp.toPx()),
                        end = Offset(plusX, plusY + 5.dp.toPx()),
                        strokeWidth = 2.dp.toPx()
                    )
                }
            }

            // Equals -> Complete Product box on right
            val eqX = size.width - 48.dp.toPx()
            val midY = size.height * 0.5f
            drawLine(color = Color(0xFF111111), start = Offset(eqX - 12.dp.toPx(), midY - 3.dp.toPx()), end = Offset(eqX - 2.dp.toPx(), midY - 3.dp.toPx()), strokeWidth = 2.dp.toPx())
            drawLine(color = Color(0xFF111111), start = Offset(eqX - 12.dp.toPx(), midY + 3.dp.toPx()), end = Offset(eqX - 2.dp.toPx(), midY + 3.dp.toPx()), strokeWidth = 2.dp.toPx())

            val resultColor = if (availability.completeSetsAvailable > 0) Color(0xFF007A3E) else Color(0xFFB3261E)
            drawCircle(
                color = resultColor.copy(alpha = 0.14f),
                radius = 18.dp.toPx(),
                center = Offset(size.width - 20.dp.toPx(), midY)
            )
            drawCircle(
                color = resultColor,
                radius = 18.dp.toPx(),
                center = Offset(size.width - 20.dp.toPx(), midY),
                style = Stroke(width = 2.dp.toPx())
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            packages.forEach { pkg ->
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .background(SurfaceWhite, RoundedCornerShape(4.dp))
                        .border(1.dp, BorderHairline, RoundedCornerShape(4.dp))
                        .padding(8.dp)
                ) {
                    Text(
                        text = pkg.packageCode,
                        style = MonoDataStyle,
                        color = InkBlack,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "Avail: ${pkg.available} · OnHand: ${pkg.onHand} · Res: ${pkg.reserved}",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (pkg.available == 0) ExceptionRed else InkSecondary
                    )
                }
            }
        }

        if (availability.hasPackageMismatch) {
            Text(
                text = "MULTI-PACKAGE RULE ACTIVE: Partial boxes exist (${availability.limitingPackageCode} = 0 avail), so sellable complete-set availability = 0.",
                style = MaterialTheme.typography.bodySmall,
                color = ExceptionRed,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
fun RoomPlannerCanvas(
    roomWidthCm: Int,
    roomDepthCm: Int,
    placements: List<RoomItemPlacement>,
    selectedId: String?,
    collisionIds: Set<String>,
    onSelectItem: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(SurfaceWhite, RoundedCornerShape(6.dp))
            .border(1.dp, BorderHairline, RoundedCornerShape(6.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "2D ROOM PLANNER (${roomWidthCm}cm × ${roomDepthCm}cm)",
                style = MonoDataStyle,
                color = DeepNordicBlue
            )
            StatusBadge(
                text = if (collisionIds.isEmpty()) "CLEARANCE OK" else "DIMENSIONAL CONFLICT",
                tone = if (collisionIds.isEmpty()) BadgeTone.VERIFIED else BadgeTone.EXCEPTION
            )
        }

        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .height(210.dp)
                .background(WarmGreyBg, RoundedCornerShape(4.dp))
                .border(2.dp, DeepNordicBlue, RoundedCornerShape(4.dp))
        ) {
            val scaleX = maxWidth / roomWidthCm.toFloat()
            val scaleY = maxHeight / roomDepthCm.toFloat()
            val scale = minOf(scaleX.value, scaleY.value)

            Canvas(modifier = Modifier.fillMaxSize()) {
                val step = 50f * (size.width / roomWidthCm.toFloat())
                var x = step
                while (x < size.width) {
                    drawLine(
                        color = Color(0xFFD5D2C8),
                        start = Offset(x, 0f),
                        end = Offset(x, size.height),
                        strokeWidth = 1f
                    )
                    x += step
                }
                val stepY = 50f * (size.height / roomDepthCm.toFloat())
                var y = stepY
                while (y < size.height) {
                    drawLine(
                        color = Color(0xFFD5D2C8),
                        start = Offset(0f, y),
                        end = Offset(size.width, y),
                        strokeWidth = 1f
                    )
                    y += stepY
                }
            }

            placements.forEach { item ->
                val isSelected = item.id == selectedId
                val hasConflict = item.id in collisionIds
                val leftDp = (item.xCm * scale).dp
                val topDp = (item.yCm * scale).dp
                val wDp = (item.effectiveWidthCm * scale).dp.coerceAtLeast(36.dp)
                val hDp = (item.effectiveDepthCm * scale).dp.coerceAtLeast(28.dp)

                Box(
                    modifier = Modifier
                        .offset(x = leftDp, y = topDp)
                        .size(width = wDp, height = hDp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(
                            when {
                                hasConflict -> ExceptionRedBg
                                isSelected -> WarmYellowContainer
                                else -> NordicBlueLight
                            }
                        )
                        .border(
                            width = if (isSelected) 2.dp else 1.dp,
                            color = when {
                                hasConflict -> ExceptionRed
                                isSelected -> InkBlack
                                else -> NordicBlue
                            },
                            shape = RoundedCornerShape(3.dp)
                        )
                        .clickable { onSelectItem(item.id) }
                        .padding(4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "${item.label}\n${item.effectiveWidthCm}×${item.effectiveDepthCm}",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (hasConflict) ExceptionRed else InkBlack,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}
