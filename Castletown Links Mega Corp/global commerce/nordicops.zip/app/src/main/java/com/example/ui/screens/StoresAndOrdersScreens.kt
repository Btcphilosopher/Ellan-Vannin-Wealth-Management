package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.domain.model.MoneyFormat
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.EnterpriseUiState
import com.example.ui.viewmodel.EnterpriseViewModel

@Composable
fun StoresScreen(
    state: EnterpriseUiState,
    vm: EnterpriseViewModel,
    onBack: () -> Unit,
    onPlaceStoreOrder: (String, String, String, Int, Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)
    val storeTasks = state.storeTasks
    val roomProducts = state.roomPlacements.mapNotNull { rm ->
        state.products.firstOrNull { it.id == rm.productId }
    }
    val resolvedPackages = roomProducts.flatMap { prod ->
        state.packages.filter { it.productId == prod.id }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(WarmGreyBg),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionHeader(
                title = "Stores & Customer Room Planning",
                subtitle = "Self-service aisles, click-and-collect staging & interactive 2D room planner (${state.activeSite})"
            )
        }

        // Interactive 2D Room Planner Module
        item {
            EnterpriseCard {
                Text(text = "Room-Planning Module", style = MaterialTheme.typography.titleLarge)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    NordicOutlineButton(
                        text = "W: ${state.roomWidthCm}cm (-20)",
                        onClick = { vm.updateRoomDimensions(state.roomWidthCm - 20, state.roomDepthCm) },
                        modifier = Modifier.weight(1f)
                    )
                    NordicOutlineButton(
                        text = "W +20cm",
                        onClick = { vm.updateRoomDimensions(state.roomWidthCm + 20, state.roomDepthCm) },
                        modifier = Modifier.weight(1f)
                    )
                    NordicOutlineButton(
                        text = "D: ${state.roomDepthCm}cm (+20)",
                        onClick = { vm.updateRoomDimensions(state.roomWidthCm, state.roomDepthCm + 20) },
                        modifier = Modifier.weight(1f)
                    )
                }

                RoomPlannerCanvas(
                    roomWidthCm = state.roomWidthCm,
                    roomDepthCm = state.roomDepthCm,
                    placements = state.roomPlacements,
                    selectedId = state.selectedRoomItemId,
                    collisionIds = state.roomCollisionIds,
                    onSelectItem = { vm.selectRoomItem(it) }
                )

                // Move & rotate controls for selected furniture footprint
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    NordicOutlineButton(text = "←", onClick = { vm.moveSelectedRoomItem(-20, 0) }, modifier = Modifier.weight(1f))
                    NordicOutlineButton(text = "→", onClick = { vm.moveSelectedRoomItem(20, 0) }, modifier = Modifier.weight(1f))
                    NordicOutlineButton(text = "↑", onClick = { vm.moveSelectedRoomItem(0, -20) }, modifier = Modifier.weight(1f))
                    NordicOutlineButton(text = "↓", onClick = { vm.moveSelectedRoomItem(0, 20) }, modifier = Modifier.weight(1f))
                    NordicOutlineButton(text = "Rotate", onClick = { vm.rotateSelectedRoomItem() }, modifier = Modifier.weight(1.3f))
                    NordicOutlineButton(text = "Del", onClick = { vm.removeSelectedRoomItem() }, modifier = Modifier.weight(1f))
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    state.products.take(3).forEach { prod ->
                        FilterChip(
                            selected = false,
                            onClick = { vm.addRoomFurniture(prod) },
                            label = { Text("+ ${prod.code}", style = MaterialTheme.typography.labelMedium) }
                        )
                    }
                }

                Text(
                    text = "Disclaimer: Basic 2D dimensional clearance check only. Does not verify structural suitability, wall-anchoring substrate, or building code compliance.",
                    style = MaterialTheme.typography.bodySmall,
                    color = InkSecondary
                )

                // Shopping list resolved to variants & complete package sets
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = WarmGreyBg,
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderHairline)
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "Resolved Shopping List: ${roomProducts.size} Products -> ${resolvedPackages.size} Required Packages",
                            style = MaterialTheme.typography.titleSmall,
                            color = DeepNordicBlue
                        )
                        resolvedPackages.forEach { pkg ->
                            val pos = state.inventory.firstOrNull { it.packageId == pkg.id && it.siteId == state.activeSite }
                            Text(
                                text = "• ${pkg.packageCode} | ${pos?.aisleBin ?: "Backroom"} | Avail: ${pos?.available ?: 0}",
                                style = MonoDataStyle,
                                color = if ((pos?.available ?: 0) > 0) InkBlack else ExceptionRed
                            )
                        }
                        val firstRoomProd = roomProducts.firstOrNull()
                        if (firstRoomProd != null) {
                            NordicPrimaryButton(
                                text = "Reserve First Item via Click & Collect",
                                onClick = {
                                    onPlaceStoreOrder(firstRoomProd.id, state.activeSite, "CLICK_AND_COLLECT", 1, false)
                                },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }
        }

        item {
            Text(text = "Store Tasks & Self-Service Operations", style = MaterialTheme.typography.titleLarge)
        }

        items(storeTasks, key = { it.id }) { t ->
            EnterpriseCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "${t.category} · ${t.aisleBin}", style = MonoDataStyle, color = DeepNordicBlue)
                        Text(text = t.title, style = MaterialTheme.typography.titleSmall)
                        Text(text = "Assignee: ${t.assigneeRole}", style = MaterialTheme.typography.bodySmall, color = InkSecondary)
                    }
                    StatusBadge(
                        text = t.status,
                        tone = if (t.status == "COMPLETED") BadgeTone.VERIFIED else BadgeTone.INFO
                    )
                }
            }
        }
    }
}

@Composable
fun OnlineOrdersScreen(
    state: EnterpriseUiState,
    onBack: () -> Unit,
    onPlaceOrder: (String, String, String, Int, Boolean) -> Unit,
    onScheduleDelivery: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)
    var search by remember { mutableStateOf("") }
    var channel by remember { mutableStateOf("ONLINE_DELIVERY") }
    var assemblyAddon by remember { mutableStateOf(true) }

    val filteredProducts = remember(state.products, search) {
        if (search.isBlank()) state.products
        else state.products.filter {
            it.code.contains(search, ignoreCase = true) || it.name.contains(search, ignoreCase = true)
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(WarmGreyBg),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionHeader(
                title = "E-Commerce & Order Management",
                subtitle = "Atomic complete-set reservations & 5 independent state machines (Simulated Payments)"
            )
        }

        item {
            EnterpriseCard {
                OutlinedTextField(
                    value = search,
                    onValueChange = { search = it },
                    label = { Text("Search catalogue by SKU or name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilterChip(
                        selected = channel == "ONLINE_DELIVERY",
                        onClick = { channel = "ONLINE_DELIVERY" },
                        label = { Text("Home Delivery (€49)") }
                    )
                    FilterChip(
                        selected = channel == "CLICK_AND_COLLECT",
                        onClick = { channel = "CLICK_AND_COLLECT" },
                        label = { Text("Click & Collect (€0)") }
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = assemblyAddon, onCheckedChange = { assemblyAddon = it })
                    Text(text = "Include Certified Wall-Anchor & Assembly Add-on (+€65.00)", style = MaterialTheme.typography.bodyMedium)
                }
                Text(
                    text = "Delivery Slot Validation: Oslo Metro Zone 0355 · Tomorrow 10:00–14:00 (4/12 slots free)",
                    style = MonoDataStyle,
                    color = VerifiedGreen
                )
            }
        }

        items(filteredProducts, key = { it.id }) { prod ->
            val avail = state.completeAvailability.firstOrNull {
                it.productId == prod.id && it.siteId == state.activeSite
            }
            val completeSets = avail?.completeSetsAvailable ?: 0
            val drawableId = when (prod.imageKey) {
                "sofa" -> R.drawable.img_sofa_skagen
                "desk" -> R.drawable.img_desk_alvar
                else -> R.drawable.img_wardrobe_fjell
            }

            EnterpriseCard {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Image(
                        painter = painterResource(id = drawableId),
                        contentDescription = prod.name,
                        modifier = Modifier
                            .size(72.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        contentScale = ContentScale.Crop
                    )
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = prod.code, style = MonoDataStyle, color = DeepNordicBlue)
                            StatusBadge(
                                text = "$completeSets SETS AT ${state.activeSite}",
                                tone = if (completeSets > 0) BadgeTone.VERIFIED else BadgeTone.EXCEPTION
                            )
                        }
                        Text(text = prod.name, style = MaterialTheme.typography.titleMedium)
                        Text(text = MoneyFormat.formatEur(prod.sellingPriceCents), style = MaterialTheme.typography.titleSmall)
                    }
                }
                NordicPrimaryButton(
                    text = if (completeSets > 0) "Order & Reserve Complete Set" else "Test Atomic Reject (Missing Box)",
                    onClick = { onPlaceOrder(prod.id, state.activeSite, channel, 1, assemblyAddon) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("order_${prod.code}")
                )
            }
        }

        item {
            Text(text = "Orders (Separated State Machines)", style = MaterialTheme.typography.titleLarge)
        }

        items(state.salesOrders, key = { it.id }) { ord ->
            EnterpriseCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "${ord.orderNumber} · ${ord.channel}", style = MonoDataStyle, color = DeepNordicBlue)
                    Text(text = MoneyFormat.formatEur(ord.totalCents), style = MaterialTheme.typography.titleMedium)
                }
                Text(text = "Instruction Revision Pinned: ${ord.instructionVersion}", style = MaterialTheme.typography.bodySmall, color = InkSecondary)
                // 5 independent state machine pills
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        StatusBadge(text = "ORD: ${ord.orderState}", tone = BadgeTone.INFO)
                        StatusBadge(text = "PAY: ${ord.paymentState}", tone = BadgeTone.VERIFIED)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        StatusBadge(text = "FULFIL: ${ord.fulfilmentState}", tone = BadgeTone.INFO)
                        StatusBadge(
                            text = "DEL: ${ord.deliveryState}",
                            tone = if (ord.deliveryState == "DELIVERED") BadgeTone.VERIFIED else BadgeTone.WARNING
                        )
                    }
                    StatusBadge(
                        text = "ASM: ${ord.assemblyState}",
                        tone = when (ord.assemblyState) {
                            "COMPLETED" -> BadgeTone.VERIFIED
                            "BLOCKED_MISSING_PART" -> BadgeTone.EXCEPTION
                            else -> BadgeTone.NEUTRAL
                        }
                    )
                }
                if (ord.channel == "ONLINE_DELIVERY" && ord.deliveryState == "NOT_SCHEDULED") {
                    NordicOutlineButton(
                        text = "Dispatch to Delivery & Assembly",
                        onClick = { onScheduleDelivery(ord.id) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}
