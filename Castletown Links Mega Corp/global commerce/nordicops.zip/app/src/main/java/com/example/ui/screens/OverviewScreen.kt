package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.model.MoneyFormat
import com.example.domain.model.WorkspaceId
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.EnterpriseUiState

@Composable
fun OverviewScreen(
    state: EnterpriseUiState,
    onSelectWorkspace: (WorkspaceId) -> Unit,
    onRunStep: (Int) -> Unit,
    onRunAllSteps: () -> Unit,
    onResetDemo: () -> Unit,
    modifier: Modifier = Modifier
) {
    val completedCount = state.demoSteps.count { it.isCompleted }
    val nextStep = state.demoSteps.firstOrNull { !it.isCompleted }
    val packageMismatchCount = state.completeAvailability.count { it.hasPackageMismatch }
    val infeasibleShipments = state.shipments.count { !it.loadFeasible }
    val blockedProduction = state.productionOrders.count {
        it.status == "SHORTAGE_BLOCKED" || it.status == "INFEASIBLE_CAPACITY"
    }
    val quarantinedReturns = state.returnCases.count { it.stockDisposition == "QUARANTINE" }
    val totalExceptions = packageMismatchCount + infeasibleShipments + blockedProduction + quarantinedReturns

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(WarmGreyBg),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = NordicBlueLight,
                border = BorderStroke(1.dp, NordicBlue.copy(alpha = 0.3f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = "INDEPENDENT SCANDINAVIAN ENTERPRISE DEMO",
                            style = MaterialTheme.typography.labelMedium,
                            color = DeepNordicBlue
                        )
                        Text(
                            text = "Fictional furniture, suppliers, factories, stores, and simulated payments. All transactions persist locally with ACID double-entry & stock ledgers.",
                            style = MaterialTheme.typography.bodySmall,
                            color = InkBlack
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    StatusBadge(
                        text = state.activeRole.displayName,
                        tone = BadgeTone.INFO
                    )
                }
            }
        }

        item {
            SectionHeader(
                title = "Headquarters Operations Overview",
                subtitle = "16 connected workspaces · Active site ${state.activeSite}",
                trailing = {
                    StatusBadge(
                        text = if (state.isLedgerBalanced) "LEDGER BALANCED" else "CHECK LEDGER",
                        tone = if (state.isLedgerBalanced) BadgeTone.VERIFIED else BadgeTone.EXCEPTION
                    )
                }
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                KpiTile(
                    label = "Complete Sets (${state.activeSite})",
                    value = state.completeAvailability
                        .filter { it.siteId == state.activeSite }
                        .sumOf { it.completeSetsAvailable }
                        .toString(),
                    caption = "Sellable only when all boxes available",
                    tone = BadgeTone.INFO,
                    modifier = Modifier.weight(1f)
                )
                KpiTile(
                    label = "Active Exceptions",
                    value = totalExceptions.toString(),
                    caption = "Shortages, infeasible loads & quarantine",
                    tone = if (totalExceptions > 0) BadgeTone.EXCEPTION else BadgeTone.VERIFIED,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                KpiTile(
                    label = "Trial Balance",
                    value = MoneyFormat.formatEur(state.totalDebitsCents),
                    caption = "Dr = Cr (${state.journalEntries.size} journals)",
                    tone = if (state.isLedgerBalanced) BadgeTone.VERIFIED else BadgeTone.EXCEPTION,
                    modifier = Modifier.weight(1f)
                )
                KpiTile(
                    label = "E2E Demo Journey",
                    value = "$completedCount / 14",
                    caption = "Product-to-resale & finance steps",
                    tone = if (completedCount == 14) BadgeTone.VERIFIED else BadgeTone.WARNING,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Genuine Exception Queue
        if (totalExceptions > 0) {
            item {
                EnterpriseCard(borderColor = ExceptionRed.copy(alpha = 0.45f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Warning,
                            contentDescription = "Operational exceptions",
                            tint = ExceptionRed
                        )
                        Text(
                            text = "Live Exception Queue ($totalExceptions)",
                            style = MaterialTheme.typography.titleMedium,
                            color = ExceptionRed
                        )
                    }
                    if (packageMismatchCount > 0) {
                        ExceptionRow(
                            title = "Multi-package set mismatch",
                            detail = "Partial boxes on hand at store/DC yield 0 complete sellable products",
                            target = WorkspaceId.PRODUCTS,
                            onInspect = onSelectWorkspace
                        )
                    }
                    if (blockedProduction > 0) {
                        ExceptionRow(
                            title = "$blockedProduction Production order blocked",
                            detail = "Component shortage or work-centre capacity bottleneck flagged",
                            target = WorkspaceId.MANUFACTURING,
                            onInspect = onSelectWorkspace
                        )
                    }
                    if (infeasibleShipments > 0) {
                        ExceptionRow(
                            title = "$infeasibleShipments Shipment load infeasible",
                            detail = "Validated weight/volume exceeds vehicle limit",
                            target = WorkspaceId.DISTRIBUTION,
                            onInspect = onSelectWorkspace
                        )
                    }
                    if (quarantinedReturns > 0) {
                        ExceptionRow(
                            title = "$quarantinedReturns Return held in Quarantine",
                            detail = "Returned stock awaits inspection before resale or recycling",
                            target = WorkspaceId.RETURNS,
                            onInspect = onSelectWorkspace
                        )
                    }
                }
            }
        }

        // 14-Step End-to-End Demonstration Workflow
        item {
            EnterpriseCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "14-Step Product-to-Customer Demonstration",
                            style = MaterialTheme.typography.titleLarge,
                            color = InkBlack
                        )
                        Text(
                            text = "Execute the full lifecycle against the live transactional database.",
                            style = MaterialTheme.typography.bodySmall,
                            color = InkSecondary
                        )
                    }
                    IconButton(
                        onClick = onResetDemo,
                        modifier = Modifier.testTag("reset_demo_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Refresh,
                            contentDescription = "Reset demonstration seed",
                            tint = NordicBlue
                        )
                    }
                }

                LinearProgressIndicator(
                    progress = { completedCount / 14f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = NordicBlue,
                    trackColor = SurfaceMuted
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    NordicPrimaryButton(
                        text = if (nextStep != null) "Run Step ${nextStep.stepNumber}" else "All 14 Done",
                        onClick = { nextStep?.let { onRunStep(it.stepNumber) } },
                        enabled = nextStep != null && !state.isRunningDemoAll,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("run_next_demo_step")
                    )
                    NordicOutlineButton(
                        text = if (state.isRunningDemoAll) "Running..." else "Run All 14",
                        onClick = onRunAllSteps,
                        enabled = completedCount < 14 && !state.isRunningDemoAll,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("run_all_demo_steps")
                    )
                }
            }
        }

        items(state.demoSteps, key = { it.stepNumber }) { step ->
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = SurfaceWhite,
                border = BorderStroke(
                    1.dp,
                    if (step.isCompleted) VerifiedGreen.copy(alpha = 0.45f) else BorderHairline
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (step.isCompleted) VerifiedGreenBg else NordicBlueLight),
                        contentAlignment = Alignment.Center
                    ) {
                        if (step.isCompleted) {
                            Icon(
                                imageVector = Icons.Filled.CheckCircle,
                                contentDescription = "Completed",
                                tint = VerifiedGreen,
                                modifier = Modifier.size(18.dp)
                            )
                        } else {
                            Text(
                                text = step.stepNumber.toString(),
                                style = MonoDataStyle,
                                color = DeepNordicBlue,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = step.title,
                            style = MaterialTheme.typography.titleSmall,
                            color = InkBlack
                        )
                        Text(
                            text = step.detail,
                            style = MaterialTheme.typography.bodySmall,
                            color = InkSecondary
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            StatusBadge(text = step.targetWorkspace.title, tone = BadgeTone.NEUTRAL)
                            StatusBadge(text = step.entityRef, tone = BadgeTone.INFO)
                        }
                    }

                    Column(
                        horizontalAlignment = Alignment.End,
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        IconButton(
                            onClick = { onRunStep(step.stepNumber) },
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("run_step_${step.stepNumber}")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.PlayArrow,
                                contentDescription = "Execute step ${step.stepNumber}",
                                tint = if (step.isCompleted) VerifiedGreen else NordicBlue
                            )
                        }
                        Text(
                            text = "Open",
                            style = MaterialTheme.typography.labelMedium,
                            color = NordicBlue,
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .clickable { onSelectWorkspace(step.targetWorkspace) }
                                .padding(horizontal = 6.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ExceptionRow(
    title: String,
    detail: String,
    target: WorkspaceId,
    onInspect: (WorkspaceId) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .background(ExceptionRedBg)
            .border(1.dp, ExceptionRed.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
            .clickable { onInspect(target) }
            .padding(10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, style = MaterialTheme.typography.titleSmall, color = ExceptionRed)
            Text(text = detail, style = MaterialTheme.typography.bodySmall, color = InkBlack)
        }
        Spacer(Modifier.width(8.dp))
        StatusBadge(text = "OPEN ${target.shortTitle.uppercase()}", tone = BadgeTone.EXCEPTION)
    }
}
