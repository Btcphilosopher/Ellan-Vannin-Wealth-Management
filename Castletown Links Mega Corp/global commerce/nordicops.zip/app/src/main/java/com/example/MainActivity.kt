package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.MainScaffold
import com.example.ui.theme.NordicOpsTheme
import com.example.ui.viewmodel.EnterpriseViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NordicOpsTheme {
                val vm: EnterpriseViewModel = viewModel()
                MainScaffold(vm = vm)
            }
        }
    }
}
