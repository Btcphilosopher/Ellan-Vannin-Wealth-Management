package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.domain.model.MoneyFormat
import com.example.domain.model.UserRole
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.EnterpriseUiState

@Composable
fun CustomersScreen(
    state: EnterpriseUiState,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)
    val canSeePii = state.activeRole.canViewUnmaskedCustomerPii

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(WarmGreyBg),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionHeader(
                title = "Customers & Service Cases",
                subtitle = if (canSeePii) "Privileged PII view active for ${state.activeRole.displayName}" else "Addresses & full names masked for ${state.activeRole.displayName}"
            )
        }
        items(state.customers, key = { it.id }) { cust ->
            EnterpriseCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = cust.code, style = MonoDataStyle, color = DeepNordicBlue)
                        Text(
                            text = if (canSeePii) cust.fullName else cust.maskedName,
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = if (canSeePii) cust.protectedAddress else "Postal Zone ${cust.deliveryAreaCode} (${cust.region}) · Address Redacted",
                            style = MaterialTheme.typography.bodySmall,
                            color = InkSecondary
                        )
                    }
                    StatusBadge(
                        text = "${cust.serviceCasesCount} CASES",
                        tone = if (cust.serviceCasesCount > 0) BadgeTone.WARNING else BadgeTone.VERIFIED
                    )
                }
            }
        }
    }
}

@Composable
fun WorkforceScreen(
    state: EnterpriseUiState,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(WarmGreyBg),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionHeader(
                title = "Workforce, Shifts & Equipment",
                subtitle = "Payroll & clinical HR records remain behind separately reviewed external integrations"
            )
        }
        items(state.workforceShifts, key = { it.id }) { wf ->
            EnterpriseCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "${wf.workerCode} · ${wf.displayName}", style = MaterialTheme.typography.titleMedium)
                        Text(text = "${wf.role} · ${wf.siteId} · Shift ${wf.shiftWindow}", style = MaterialTheme.typography.bodySmall, color = InkSecondary)
                    }
                    StatusBadge(text = wf.siteId, tone = BadgeTone.INFO)
                }
                Text(text = "Training: ${wf.trainingCert}", style = MaterialTheme.typography.bodySmall)
                Text(
                    text = "Equipment Maintenance: ${wf.maintenanceTicket}",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (wf.maintenanceTicket != "None") WarningAmber else VerifiedGreen
                )
            }
        }
    }
}

@Composable
fun FinanceScreen(
    state: EnterpriseUiState,
    onBack: () -> Unit,
    onPostReconciliation: (Long, String) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(WarmGreyBg),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionHeader(
                title = "Finance, Cost Layers & Double-Entry Subledger",
                subtitle = "Integer-cent EUR arithmetic · 25.00% half-even VAT · Statutory accounting behind reviewed boundary",
                trailing = {
                    NordicPrimaryButton(
                        text = "Post Recon JE",
                        onClick = { onPostReconciliation(46800L, "ORD-2026-9001") }
                    )
                }
            )
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                KpiTile(
                    label = "Total Debits",
                    value = MoneyFormat.formatEur(state.totalDebitsCents),
                    caption = "EUR Minor-Unit Sum",
                    tone = BadgeTone.INFO,
                    modifier = Modifier.weight(1f)
                )
                KpiTile(
                    label = "Total Credits",
                    value = MoneyFormat.formatEur(state.totalCreditsCents),
                    caption = if (state.isLedgerBalanced) "Trial Balance = 0.00 diff" else "IMBALANCED",
                    tone = if (state.isLedgerBalanced) BadgeTone.VERIFIED else BadgeTone.EXCEPTION,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            EnterpriseCard {
                Text(text = "8-Layer Cost & Step-Cost Margin Analysis", style = MaterialTheme.typography.titleMedium)
                Text(
                    text = "Distinguishes Incremental Unit Cost vs Average Allocated Cost vs Contribution Margin. Larger runs incur step-cost surcharges above capacity thresholds.",
                    style = MaterialTheme.typography.bodySmall,
                    color = InkSecondary
                )
                state.costBreakdowns.forEach { cb ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, BorderHairline, RoundedCornerShape(4.dp))
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = cb.productCode, style = MonoDataStyle, color = DeepNordicBlue)
                            Text(text = "Net Price: ${MoneyFormat.formatEur(cb.sellingPriceNetCents)}", style = MonoDataStyle)
                        }
                        Text(
                            text = "Mat ${MoneyFormat.formatEur(cb.materialsCents)} · Mfg ${MoneyFormat.formatEur(cb.manufacturingCents)} · Pack ${MoneyFormat.formatEur(cb.packagingCents)} · Trans ${MoneyFormat.formatEur(cb.transportCents)}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = "Whse ${MoneyFormat.formatEur(cb.warehousingCents)} · Store ${MoneyFormat.formatEur(cb.storeAllocationCents)} · Ret ${MoneyFormat.formatEur(cb.returnsAllowanceCents)} · Svc ${MoneyFormat.formatEur(cb.serviceFulfilmentCents)}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = "Incremental: ${MoneyFormat.formatEur(cb.incrementalUnitCostCents)} | Avg Alloc: ${MoneyFormat.formatEur(cb.averageAllocatedCostCents)} | Contribution: ${MoneyFormat.formatEur(cb.contributionMarginCents)} | Operating: ${MoneyFormat.formatEur(cb.operatingMarginCents)}",
                            style = MonoDataStyle,
                            color = VerifiedGreen
                        )
                        Text(
                            text = "Step-Cost Threshold: >${cb.stepCostThresholdUnits} units/shift adds +${MoneyFormat.formatEur(cb.stepCostSurchargePerBatchCents)} overtime/tooling batch cost.",
                            style = MaterialTheme.typography.bodySmall,
                            color = WarningAmber
                        )
                    }
                }
            }
        }

        items(state.journalEntries, key = { it.id }) { je ->
            val lines = state.journalLines.filter { it.entryId == je.id }
            EnterpriseCard {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(text = "${je.entryNumber} · ${je.referenceId}", style = MonoDataStyle, color = DeepNordicBlue)
                    StatusBadge(
                        text = "Dr=Cr ${MoneyFormat.formatEur(je.totalDebitCents)}",
                        tone = BadgeTone.VERIFIED
                    )
                }
                Text(text = je.description, style = MaterialTheme.typography.bodySmall)
                lines.forEach { ln ->
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = "${ln.accountCode} ${ln.accountName}", style = MaterialTheme.typography.bodySmall)
                        Text(
                            text = if (ln.debitCents > 0) "Dr ${MoneyFormat.formatEur(ln.debitCents)}" else "Cr ${MoneyFormat.formatEur(ln.creditCents)}",
                            style = MonoDataStyle
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AnalyticsScreen(
    state: EnterpriseUiState,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)
    val totalOrders = state.salesOrders.size
    val totalDelivered = state.deliveryTasks.count { it.deliveryCompleted }
    val totalAssembled = state.deliveryTasks.count { it.assemblyCompleted }
    val poOnTime = state.suppliers.map { it.onTimeRatePct }.average()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(WarmGreyBg),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionHeader(
                title = "Analytics & Sustainability Evidence",
                subtitle = "Inspectable metrics separating measured materials, modelled emissions, supplier statements & verified certifications"
            )
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                KpiTile("Active Orders", "$totalOrders", "Delivered: $totalDelivered · Assembled: $totalAssembled", BadgeTone.INFO, Modifier.weight(1f))
                KpiTile("Supplier On-Time", "${((poOnTime * 10).toInt() / 10.0)}%", "Avg across ${state.suppliers.size} qualified/cond. mills", BadgeTone.VERIFIED, Modifier.weight(1f))
            }
        }

        items(state.sustainabilityMetrics, key = { it.id }) { sus ->
            EnterpriseCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = sus.metricName, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                    StatusBadge(
                        text = sus.category,
                        tone = if (sus.verified) BadgeTone.VERIFIED else BadgeTone.WARNING
                    )
                }
                Text(text = sus.valueText, style = MonoDataStyle, color = DeepNordicBlue)
                Text(
                    text = "Boundary: ${sus.boundary} · Factor/Basis: ${sus.factor} · Date: ${sus.evidenceDate}",
                    style = MaterialTheme.typography.bodySmall,
                    color = InkSecondary
                )
            }
        }
    }
}

@Composable
fun AdministrationScreen(
    state: EnterpriseUiState,
    onBack: () -> Unit,
    onSelectRole: (UserRole) -> Unit,
    onDispatchOutbox: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(WarmGreyBg),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionHeader(
                title = "Administration, RBAC & Outbox",
                subtitle = "Test live permission enforcement across 10 enterprise roles, audit logs & outbox events"
            )
        }

        item {
            EnterpriseCard {
                Text(text = "Active Role Simulator (${state.activeRole.displayName})", style = MaterialTheme.typography.titleMedium)
                Text(
                    text = "Switch roles to verify backend authorization gates (e.g., External Auditor or Store Associate blocked from posting journals or approving design revisions).",
                    style = MaterialTheme.typography.bodySmall,
                    color = InkSecondary
                )
                UserRole.entries.chunked(2).forEach { pair ->
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        pair.forEach { role ->
                            FilterChip(
                                selected = state.activeRole == role,
                                onClick = { onSelectRole(role) },
                                label = { Text(role.displayName, style = MaterialTheme.typography.labelMedium) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }

        item {
            Text(text = "Immutable Audit & Transactional Outbox (${state.auditOutbox.size})", style = MaterialTheme.typography.titleLarge)
        }

        items(state.auditOutbox, key = { it.id }) { aud ->
            EnterpriseCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "${aud.eventType} (${aud.entityId})", style = MonoDataStyle, color = DeepNordicBlue, modifier = Modifier.weight(1f))
                    StatusBadge(
                        text = aud.outboxStatus,
                        tone = when {
                            aud.eventType == "ACCESS_DENIED" -> BadgeTone.EXCEPTION
                            aud.outboxStatus == "DISPATCHED" -> BadgeTone.VERIFIED
                            else -> BadgeTone.WARNING
                        }
                    )
                }
                Text(text = aud.payloadSummary, style = MaterialTheme.typography.bodySmall)
                Text(text = "Actor: ${aud.actorRole} · Key: ${aud.idempotencyKey}", style = MaterialTheme.typography.bodySmall, color = InkSecondary)
                if (aud.outboxStatus == "PENDING") {
                    NordicOutlineButton(
                        text = "Dispatch Outbox Event",
                        onClick = { onDispatchOutbox(aud.id) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}
