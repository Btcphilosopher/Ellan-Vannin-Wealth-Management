package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val NordicLightColorScheme = lightColorScheme(
    primary = NordicBlue,
    onPrimary = InkOnBlue,
    primaryContainer = NordicBlueLight,
    onPrimaryContainer = DeepNordicBlue,
    secondary = WarmYellow,
    onSecondary = InkBlack,
    secondaryContainer = WarmYellowContainer,
    onSecondaryContainer = InkBlack,
    tertiary = DeepNordicBlue,
    onTertiary = InkOnBlue,
    background = WarmGreyBg,
    onBackground = InkBlack,
    surface = SurfaceWhite,
    onSurface = InkBlack,
    surfaceVariant = SurfaceMuted,
    onSurfaceVariant = InkSecondary,
    outline = BorderHairline,
    outlineVariant = BorderHairline,
    error = ExceptionRed,
    onError = SurfaceWhite,
    errorContainer = ExceptionRedBg,
    onErrorContainer = ExceptionRed
)

private val NordicShapes = Shapes(
    extraSmall = RoundedCornerShape(2.dp),
    small = RoundedCornerShape(4.dp),
    medium = RoundedCornerShape(6.dp),
    large = RoundedCornerShape(8.dp),
    extraLarge = RoundedCornerShape(10.dp)
)

@Composable
fun NordicOpsTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = NordicLightColorScheme,
        typography = Typography,
        shapes = NordicShapes,
        content = content
    )
}
