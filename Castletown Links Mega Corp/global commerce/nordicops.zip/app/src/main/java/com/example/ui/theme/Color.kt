package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Scandinavian Enterprise Palette
val NordicBlue = Color(0xFF0058A3)
val DeepNordicBlue = Color(0xFF003E73)
val NordicBlueLight = Color(0xFFE6F0FA)

val WarmYellow = Color(0xFFFFDB00)
val WarmYellowPressed = Color(0xFFE5C400)
val WarmYellowContainer = Color(0xFFFFF6BF)

val WarmGreyBg = Color(0xFFF5F4F0)
val SurfaceWhite = Color(0xFFFFFFFF)
val SurfaceMuted = Color(0xFFEAE8E1)
val BorderHairline = Color(0xFFD5D2C8)

val InkBlack = Color(0xFF111111)
val InkSecondary = Color(0xFF4A4A48)
val InkOnBlue = Color(0xFFFFFFFF)

// Semantic status colors (Red strictly for genuine exceptions)
val ExceptionRed = Color(0xFFB3261E)
val ExceptionRedBg = Color(0xFFFCECEC)

val VerifiedGreen = Color(0xFF007A3E)
val VerifiedGreenBg = Color(0xFFE6F4EC)

val WarningAmber = Color(0xFF9A5B00)
val WarningAmberBg = Color(0xFFFFF3DC)
