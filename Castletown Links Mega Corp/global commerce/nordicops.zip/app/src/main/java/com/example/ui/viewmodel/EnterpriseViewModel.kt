package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.*
import com.example.data.repository.EnterpriseRepository
import com.example.domain.model.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class EnterpriseUiState(
    val activeWorkspace: WorkspaceId = WorkspaceId.OVERVIEW,
    val activeRole: UserRole = UserRole.HQ_ADMIN,
    val activeSite: String = "STORE-OSLO",
    val canNavigateBack: Boolean = false,
    val products: List<ProductFamilyEntity> = emptyList(),
    val packages: List<PackageSpecEntity> = emptyList(),
    val spareParts: List<SparePartEntity> = emptyList(),
    val designChanges: List<DesignChangeEntity> = emptyList(),
    val suppliers: List<SupplierEntity> = emptyList(),
    val materialEvidence: List<MaterialEvidenceEntity> = emptyList(),
    val purchaseOrders: List<PurchaseOrderEntity> = emptyList(),
    val workCentres: List<WorkCentreEntity> = emptyList(),
    val productionOrders: List<ProductionOrderEntity> = emptyList(),
    val inventory: List<InventoryPositionEntity> = emptyList(),
    val stockMovements: List<StockMovementEntity> = emptyList(),
    val shipments: List<DistributionShipmentEntity> = emptyList(),
    val storeTasks: List<StoreTaskEntity> = emptyList(),
    val customers: List<CustomerEntity> = emptyList(),
    val salesOrders: List<SalesOrderEntity> = emptyList(),
    val deliveryTasks: List<DeliveryAssemblyTaskEntity> = emptyList(),
    val returnCases: List<ReturnCaseEntity> = emptyList(),
    val journalEntries: List<JournalEntryEntity> = emptyList(),
    val journalLines: List<JournalLineEntity> = emptyList(),
    val sustainabilityMetrics: List<SustainabilityMetricEntity> = emptyList(),
    val workforceShifts: List<WorkforceShiftEntity> = emptyList(),
    val auditOutbox: List<AuditOutboxEntity> = emptyList(),
    val demoSteps: List<DemoWorkflowStep> = DemoSeedData.demoStepDefinitions,
    val completeAvailability: List<CompleteProductAvailability> = emptyList(),
    val costBreakdowns: List<CostLayerBreakdown> = emptyList(),
    val totalDebitsCents: Long = 0L,
    val totalCreditsCents: Long = 0L,
    val roomWidthCm: Int = 420,
    val roomDepthCm: Int = 340,
    val roomPlacements: List<RoomItemPlacement> = listOf(
        RoomItemPlacement("rm-1", "prod-skagen-3s", "SKAGEN-3S", "SKAGEN Sofa", 218, 92, 30, 35),
        RoomItemPlacement("rm-2", "prod-alvar-140", "ALVAR-140", "ALVAR Desk", 140, 70, 260, 220)
    ),
    val selectedRoomItemId: String? = "rm-1",
    val isRunningDemoAll: Boolean = false,
    val feedbackMessage: String? = null
) {
    val isLedgerBalanced: Boolean get() = totalDebitsCents == totalCreditsCents && totalDebitsCents > 0L

    val roomCollisionIds: Set<String>
        get() {
            val hits = mutableSetOf<String>()
            roomPlacements.forEach { a ->
                if (a.xCm < 0 || a.yCm < 0 ||
                    a.xCm + a.effectiveWidthCm > roomWidthCm ||
                    a.yCm + a.effectiveDepthCm > roomDepthCm
                ) {
                    hits.add(a.id)
                }
            }
            for (i in roomPlacements.indices) {
                for (j in i + 1 until roomPlacements.size) {
                    val a = roomPlacements[i]
                    val b = roomPlacements[j]
                    val overlapX = a.xCm < b.xCm + b.effectiveWidthCm && a.xCm + a.effectiveWidthCm > b.xCm
                    val overlapY = a.yCm < b.yCm + b.effectiveDepthCm && a.yCm + a.effectiveDepthCm > b.yCm
                    if (overlapX && overlapY) {
                        hits.add(a.id)
                        hits.add(b.id)
                    }
                }
            }
            return hits
        }
}

class EnterpriseViewModel(application: Application) : AndroidViewModel(application) {
    private val db = NordicOpsDatabase.getInstance(application)
    private val repo = EnterpriseRepository(db)

    private val _activeWorkspace = MutableStateFlow(WorkspaceId.OVERVIEW)
    private val _history = MutableStateFlow<List<WorkspaceId>>(emptyList())
    private val _activeRole = MutableStateFlow(UserRole.HQ_ADMIN)
    private val _activeSite = MutableStateFlow("STORE-OSLO")
    private val _roomWidthCm = MutableStateFlow(420)
    private val _roomDepthCm = MutableStateFlow(340)
    private val _roomPlacements = MutableStateFlow(
        listOf(
            RoomItemPlacement("rm-1", "prod-skagen-3s", "SKAGEN-3S", "SKAGEN Sofa", 218, 92, 30, 35),
            RoomItemPlacement("rm-2", "prod-alvar-140", "ALVAR-140", "ALVAR Desk", 140, 70, 260, 220)
        )
    )
    private val _selectedRoomItemId = MutableStateFlow<String?>("rm-1")
    private val _isRunningDemoAll = MutableStateFlow(false)
    private val _feedback = MutableStateFlow<String?>(null)

    init {
        viewModelScope.launch {
            repo.initialize()
        }
    }

    private data class CoreBundle(
        val products: List<ProductFamilyEntity>,
        val packages: List<PackageSpecEntity>,
        val spareParts: List<SparePartEntity>,
        val designChanges: List<DesignChangeEntity>,
        val suppliers: List<SupplierEntity>,
        val materialEvidence: List<MaterialEvidenceEntity>,
        val purchaseOrders: List<PurchaseOrderEntity>
    )

    private data class OpsBundle(
        val workCentres: List<WorkCentreEntity>,
        val productionOrders: List<ProductionOrderEntity>,
        val inventory: List<InventoryPositionEntity>,
        val stockMovements: List<StockMovementEntity>,
        val shipments: List<DistributionShipmentEntity>,
        val storeTasks: List<StoreTaskEntity>
    )

    private data class CommerceBundle(
        val customers: List<CustomerEntity>,
        val salesOrders: List<SalesOrderEntity>,
        val deliveryTasks: List<DeliveryAssemblyTaskEntity>,
        val returnCases: List<ReturnCaseEntity>
    )

    private data class GovernanceBundle(
        val journalEntries: List<JournalEntryEntity>,
        val journalLines: List<JournalLineEntity>,
        val sustainability: List<SustainabilityMetricEntity>,
        val workforce: List<WorkforceShiftEntity>,
        val auditOutbox: List<AuditOutboxEntity>,
        val demoProgress: List<DemoStepProgressEntity>
    )

    private data class UiMetaBundle(
        val workspace: WorkspaceId,
        val history: List<WorkspaceId>,
        val role: UserRole,
        val site: String,
        val roomW: Int,
        val roomD: Int,
        val placements: List<RoomItemPlacement>,
        val selectedRoomId: String?,
        val isRunningDemo: Boolean,
        val feedback: String?
    )

    private val coreFlow = combine(
        repo.products,
        repo.packages,
        repo.spareParts,
        repo.designChanges,
        repo.suppliers,
        repo.materialEvidence,
        repo.purchaseOrders
    ) { arr ->
        @Suppress("UNCHECKED_CAST")
        CoreBundle(
            arr[0] as List<ProductFamilyEntity>,
            arr[1] as List<PackageSpecEntity>,
            arr[2] as List<SparePartEntity>,
            arr[3] as List<DesignChangeEntity>,
            arr[4] as List<SupplierEntity>,
            arr[5] as List<MaterialEvidenceEntity>,
            arr[6] as List<PurchaseOrderEntity>
        )
    }

    private val opsFlow = combine(
        repo.workCentres,
        repo.productionOrders,
        repo.inventory,
        repo.stockMovements,
        repo.shipments,
        repo.storeTasks
    ) { arr ->
        @Suppress("UNCHECKED_CAST")
        OpsBundle(
            arr[0] as List<WorkCentreEntity>,
            arr[1] as List<ProductionOrderEntity>,
            arr[2] as List<InventoryPositionEntity>,
            arr[3] as List<StockMovementEntity>,
            arr[4] as List<DistributionShipmentEntity>,
            arr[5] as List<StoreTaskEntity>
        )
    }

    private val commerceFlow = combine(
        repo.customers,
        repo.salesOrders,
        repo.deliveryTasks,
        repo.returnCases
    ) { customers, orders, deliveries, returns ->
        CommerceBundle(customers, orders, deliveries, returns)
    }

    private val governanceFlow = combine(
        repo.journalEntries,
        repo.journalLines,
        repo.sustainabilityMetrics,
        repo.workforceShifts,
        repo.auditOutbox,
        repo.demoProgress
    ) { arr ->
        @Suppress("UNCHECKED_CAST")
        GovernanceBundle(
            arr[0] as List<JournalEntryEntity>,
            arr[1] as List<JournalLineEntity>,
            arr[2] as List<SustainabilityMetricEntity>,
            arr[3] as List<WorkforceShiftEntity>,
            arr[4] as List<AuditOutboxEntity>,
            arr[5] as List<DemoStepProgressEntity>
        )
    }

    private val metaFlow = combine(
        _activeWorkspace,
        _history,
        _activeRole,
        _activeSite,
        _roomWidthCm,
        _roomDepthCm,
        _roomPlacements,
        _selectedRoomItemId,
        _isRunningDemoAll,
        _feedback
    ) { arr ->
        @Suppress("UNCHECKED_CAST")
        UiMetaBundle(
            arr[0] as WorkspaceId,
            arr[1] as List<WorkspaceId>,
            arr[2] as UserRole,
            arr[3] as String,
            arr[4] as Int,
            arr[5] as Int,
            arr[6] as List<RoomItemPlacement>,
            arr[7] as String?,
            arr[8] as Boolean,
            arr[9] as String?
        )
    }

    val uiState: StateFlow<EnterpriseUiState> = combine(
        coreFlow,
        opsFlow,
        commerceFlow,
        governanceFlow,
        metaFlow
    ) { core, ops, commerce, gov, meta ->
        val sites = listOf("DC-MALMO", "STORE-OSLO", "STORE-STOCKHOLM")
        val availabilityList = core.products.flatMap { prod ->
            val prodPkgs = core.packages.filter { it.productId == prod.id }
            sites.map { siteId ->
                val pkgItems = prodPkgs.map { pkg ->
                    val sitePos = ops.inventory.filter { it.packageId == pkg.id && it.siteId == siteId }
                    val saleablePos = sitePos.filter { it.zone == "SELF_SERVICE_AISLE" || it.zone == "BACKROOM" }
                    val onHand = saleablePos.sumOf { it.onHand }
                    val reserved = saleablePos.sumOf { it.reserved }
                    PackageAvailabilityItem(
                        packageId = pkg.id,
                        packageCode = pkg.packageCode,
                        packageIndex = pkg.packageIndex,
                        totalPackages = pkg.totalPackages,
                        requiredPerProduct = pkg.requiredQtyPerProduct,
                        onHand = onHand,
                        reserved = reserved,
                        available = (onHand - reserved).coerceAtLeast(0),
                        inTransit = sitePos.sumOf { it.inTransit },
                        quarantined = sitePos.sumOf { it.quarantined },
                        damaged = sitePos.sumOf { it.damaged },
                        displayStock = sitePos.sumOf { it.displayStock }
                    )
                }
                CompleteProductAvailability.compute(prod.id, prod.code, prod.name, siteId, pkgItems)
            }
        }

        val steps = DemoSeedData.demoStepDefinitions.map { def ->
            val saved = gov.demoProgress.firstOrNull { it.stepNumber == def.stepNumber }
            def.copy(isCompleted = saved?.completed == true)
        }

        EnterpriseUiState(
            activeWorkspace = meta.workspace,
            activeRole = meta.role,
            activeSite = meta.site,
            canNavigateBack = meta.history.isNotEmpty() || meta.workspace != WorkspaceId.OVERVIEW,
            products = core.products,
            packages = core.packages,
            spareParts = core.spareParts,
            designChanges = core.designChanges,
            suppliers = core.suppliers,
            materialEvidence = core.materialEvidence,
            purchaseOrders = core.purchaseOrders,
            workCentres = ops.workCentres,
            productionOrders = ops.productionOrders,
            inventory = ops.inventory,
            stockMovements = ops.stockMovements,
            shipments = ops.shipments,
            storeTasks = ops.storeTasks,
            customers = commerce.customers,
            salesOrders = commerce.salesOrders,
            deliveryTasks = commerce.deliveryTasks,
            returnCases = commerce.returnCases,
            journalEntries = gov.journalEntries,
            journalLines = gov.journalLines,
            sustainabilityMetrics = gov.sustainability,
            workforceShifts = gov.workforce,
            auditOutbox = gov.auditOutbox,
            demoSteps = steps,
            completeAvailability = availabilityList,
            costBreakdowns = core.products.map { repo.computeCostLayers(it) },
            totalDebitsCents = gov.journalLines.sumOf { it.debitCents },
            totalCreditsCents = gov.journalLines.sumOf { it.creditCents },
            roomWidthCm = meta.roomW,
            roomDepthCm = meta.roomD,
            roomPlacements = meta.placements,
            selectedRoomItemId = meta.selectedRoomId,
            isRunningDemoAll = meta.isRunningDemo,
            feedbackMessage = meta.feedback
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = EnterpriseUiState()
    )

    fun selectWorkspace(workspace: WorkspaceId) {
        if (workspace != _activeWorkspace.value) {
            _history.value = (_history.value + _activeWorkspace.value).takeLast(10)
            _activeWorkspace.value = workspace
        }
    }

    fun navigateBack() {
        val hist = _history.value
        if (hist.isNotEmpty()) {
            _activeWorkspace.value = hist.last()
            _history.value = hist.dropLast(1)
        } else if (_activeWorkspace.value != WorkspaceId.OVERVIEW) {
            _activeWorkspace.value = WorkspaceId.OVERVIEW
        }
    }

    fun setRole(role: UserRole) {
        _activeRole.value = role
        _feedback.value = "Switched role to ${role.displayName}"
    }

    fun setSite(siteId: String) {
        _activeSite.value = siteId
    }

    fun clearFeedback() {
        _feedback.value = null
    }

    private fun launchAction(block: suspend () -> Result<String>) {
        viewModelScope.launch {
            val res = block()
            _feedback.value = res.getOrElse { it.message ?: "Action failed" }
        }
    }

    fun runDemoStep(stepNumber: Int) {
        launchAction { repo.executeDemoStep(stepNumber, _activeRole.value) }
    }

    fun runAllDemoSteps() {
        if (_isRunningDemoAll.value) return
        viewModelScope.launch {
            _isRunningDemoAll.value = true
            var lastMsg = "Completed all 14 demonstration steps."
            for (step in 1..14) {
                val res = repo.executeDemoStep(step, _activeRole.value)
                if (res.isFailure) {
                    lastMsg = "Step $step error: ${res.exceptionOrNull()?.message}"
                    break
                }
            }
            _isRunningDemoAll.value = false
            _feedback.value = lastMsg
        }
    }

    fun resetDemo() {
        launchAction { repo.resetDemo() }
    }

    fun createTwoPackageProduct(code: String, name: String, variant: String, priceCents: Long) {
        launchAction { repo.createTwoPackageProduct(_activeRole.value, code, name, variant, priceCents) }
    }

    fun advanceDesignStage(changeId: String, targetStage: String, safetyReviewed: Boolean) {
        launchAction { repo.advanceDesignStage(_activeRole.value, changeId, targetStage, safetyReviewed) }
    }

    fun createPurchaseOrder(poNumber: String, supplierId: String, componentCode: String, componentName: String, qty: Int, unitCostCents: Long) {
        launchAction { repo.createPurchaseOrder(_activeRole.value, poNumber, supplierId, componentCode, componentName, qty, unitCostCents) }
    }

    fun receivePurchaseOrder(poId: String, delta: Int, passed: Boolean) {
        launchAction { repo.receiveAndInspectPurchaseOrder(_activeRole.value, poId, delta, passed) }
    }

    fun scheduleAndReleaseProduction(orderNumber: String, productId: String, workCentreId: String, qty: Int) {
        launchAction { repo.scheduleAndReleaseProduction(_activeRole.value, orderNumber, productId, workCentreId, qty) }
    }

    fun transferStock(productId: String, fromSiteId: String, toSiteId: String, setsQty: Int) {
        launchAction { repo.transferStock(_activeRole.value, productId, fromSiteId, toSiteId, setsQty) }
    }

    fun upgradeShipmentVehicle(shipmentId: String) {
        launchAction { repo.upgradeShipmentVehicle(_activeRole.value, shipmentId) }
    }

    fun placeOrder(productId: String, siteId: String, channel: String, qty: Int, assemblyAddon: Boolean) {
        val ordNum = "ORD-2026-${(3100..9899).random()}"
        launchAction {
            repo.placeOrderWithAtomicReservation(
                _activeRole.value,
                ordNum,
                "cust-101",
                siteId,
                channel,
                productId,
                qty,
                assemblyAddon
            )
        }
    }

    fun scheduleDelivery(orderId: String) {
        val num = "DA-2026-${(3100..9899).random()}"
        launchAction { repo.scheduleDeliveryAndAssembly(_activeRole.value, orderId, num) }
    }

    fun deliverNextPackage(taskId: String) {
        launchAction { repo.recordSplitDeliveryPackage(_activeRole.value, taskId) }
    }

    fun reportMissingFitting(taskId: String, partCode: String) {
        launchAction { repo.reportMissingFitting(_activeRole.value, taskId, partCode) }
    }

    fun dispatchSparePart(taskId: String) {
        launchAction { repo.dispatchSparePartForTask(_activeRole.value, taskId) }
    }

    fun completeDeliveryAssembly(taskId: String) {
        launchAction { repo.completeDeliveryAndAssembly(_activeRole.value, taskId) }
    }

    fun processReturnToResale(returnId: String, resalePriceCents: Long) {
        launchAction { repo.processReturnToResale(_activeRole.value, returnId, resalePriceCents) }
    }

    fun postReconciliationJournal(grossCents: Long, refId: String) {
        val num = "JE-2026-${(100..999).random()}"
        launchAction { repo.reconcileFinanceJournal(_activeRole.value, num, refId, grossCents) }
    }

    fun dispatchOutboxEvent(auditId: String) {
        launchAction { repo.dispatchOutboxEvent(_activeRole.value, auditId) }
    }

    // Interactive Room Planner mutations
    fun updateRoomDimensions(widthCm: Int, depthCm: Int) {
        _roomWidthCm.value = widthCm.coerceIn(220, 800)
        _roomDepthCm.value = depthCm.coerceIn(200, 700)
    }

    fun selectRoomItem(id: String) {
        _selectedRoomItemId.value = id
    }

    fun addRoomFurniture(product: ProductFamilyEntity) {
        val (w, d) = when (product.code) {
            "FJELL-120" -> 120 to 60
            "SKAGEN-3S" -> 218 to 92
            "ALVAR-140" -> 140 to 70
            else -> 90 to 40
        }
        val newItem = RoomItemPlacement(
            id = "rm-${System.nanoTime()}",
            productId = product.id,
            productCode = product.code,
            label = product.code,
            widthCm = w,
            depthCm = d,
            xCm = 20,
            yCm = 20
        )
        _roomPlacements.value = _roomPlacements.value + newItem
        _selectedRoomItemId.value = newItem.id
    }

    fun moveSelectedRoomItem(dxCm: Int, dyCm: Int) {
        val sel = _selectedRoomItemId.value ?: return
        _roomPlacements.value = _roomPlacements.value.map { item ->
            if (item.id == sel) {
                item.copy(xCm = (item.xCm + dxCm).coerceAtLeast(-20), yCm = (item.yCm + dyCm).coerceAtLeast(-20))
            } else item
        }
    }

    fun rotateSelectedRoomItem() {
        val sel = _selectedRoomItemId.value ?: return
        _roomPlacements.value = _roomPlacements.value.map { item ->
            if (item.id == sel) item.copy(rotated = !item.rotated) else item
        }
    }

    fun removeSelectedRoomItem() {
        val sel = _selectedRoomItemId.value ?: return
        _roomPlacements.value = _roomPlacements.value.filterNot { it.id == sel }
        _selectedRoomItemId.value = _roomPlacements.value.firstOrNull()?.id
    }
}
