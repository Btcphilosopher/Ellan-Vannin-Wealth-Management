package com.example.domain.model

import kotlin.math.floor
import kotlin.math.roundToLong

enum class WorkspaceGroup(val label: String) {
    COMMAND("Command"),
    SUPPLY("Product & Supply"),
    OPERATIONS("Inventory & Stores"),
    COMMERCE("Orders & Field"),
    GOVERNANCE("Finance & Audit")
}

enum class WorkspaceId(
    val title: String,
    val shortTitle: String,
    val group: WorkspaceGroup,
    val subtitle: String
) {
    OVERVIEW("Overview", "Overview", WorkspaceGroup.COMMAND, "14-step value chain & live exception queue"),
    PRODUCTS("Products", "Products", WorkspaceGroup.SUPPLY, "Flat-pack variants, multi-package sets & spare parts"),
    DESIGN("Design", "Design", WorkspaceGroup.SUPPLY, "Revision workflow, BOMs, tests & safety reviews"),
    SUPPLIERS("Suppliers", "Suppliers", WorkspaceGroup.SUPPLY, "Qualification, POs, origin evidence & factory risk"),
    MANUFACTURING("Manufacturing", "Mfg", WorkspaceGroup.SUPPLY, "Routings, work centres, bottlenecks & quality release"),
    INVENTORY("Inventory", "Inventory", WorkspaceGroup.OPERATIONS, "Sites, zones, separated stock & immutable ledger"),
    DISTRIBUTION("Distribution", "Distrib", WorkspaceGroup.OPERATIONS, "Consolidation, geometric vs validated truck loads"),
    STORES("Stores", "Stores", WorkspaceGroup.OPERATIONS, "Aisles/bins, displays, tasks & 2D room planner"),
    ONLINE_ORDERS("Online Orders", "Orders", WorkspaceGroup.COMMERCE, "Cart, slot capacity, atomic sets & split fulfilment"),
    DELIVERY_ASSEMBLY("Delivery & Assembly", "Field", WorkspaceGroup.COMMERCE, "Crews, instruction pinning & missing fittings"),
    RETURNS("Returns", "Returns", WorkspaceGroup.COMMERCE, "Quarantine, inspection, resale lots & refund review"),
    CUSTOMERS("Customers", "Customers", WorkspaceGroup.COMMERCE, "Profiles, service cases & protected PII masking"),
    WORKFORCE("Workforce", "Staff", WorkspaceGroup.GOVERNANCE, "Roles, shifts, training & equipment maintenance"),
    FINANCE("Finance", "Finance", WorkspaceGroup.GOVERNANCE, "Double-entry subledger, 3-way match & 8 cost layers"),
    ANALYTICS("Analytics", "Analytics", WorkspaceGroup.GOVERNANCE, "Traceable KPIs & separated sustainability evidence"),
    ADMINISTRATION("Administration", "Admin", WorkspaceGroup.GOVERNANCE, "10-role RBAC, approvals, audit log & outbox")
}

enum class UserRole(
    val displayName: String,
    val defaultSite: String,
    val canApproveRevision: Boolean,
    val canApproveFinance: Boolean,
    val canAdjustStock: Boolean,
    val canManageProcurement: Boolean,
    val canReleaseProduction: Boolean,
    val canViewUnmaskedCustomerPii: Boolean,
    val isReadOnlyAuditor: Boolean = false
) {
    HQ_ADMIN("Headquarters Admin", "HQ-STOCKHOLM", true, true, true, true, true, true),
    DESIGN_ENGINEER("Design Engineer", "HQ-STOCKHOLM", true, false, false, false, false, false),
    PROCUREMENT("Procurement Lead", "HQ-STOCKHOLM", false, false, false, true, false, false),
    FACTORY_OPS("Factory Operations", "PLANT-ALM-01", false, false, false, false, true, false),
    WAREHOUSE("Warehouse Operator", "DC-MALMO", false, false, true, false, false, false),
    STORE_ASSOCIATE("Store Associate", "STORE-OSLO", false, false, true, false, false, false),
    FINANCE_CONTROLLER("Finance Controller", "HQ-STOCKHOLM", false, true, false, false, false, true),
    CUSTOMER_SERVICE("Customer Service", "HQ-STOCKHOLM", false, false, false, false, false, true),
    DELIVERY_PROVIDER("Delivery & Assembly", "FIELD-OSLO", false, false, false, false, false, false),
    AUDITOR("External Auditor", "HQ-STOCKHOLM", false, false, false, false, false, false, true)
}

object MoneyFormat {
    private const val VAT_BPS = 2500L // 25.00% Nordic standard VAT

    fun formatEur(cents: Long): String {
        val sign = if (cents < 0) "-" else ""
        val abs = kotlin.math.abs(cents)
        val whole = abs / 100
        val frac = abs % 100
        return "$sign€${whole}.${frac.toString().padStart(2, '0')}"
    }

    fun calculateVatHalfEven(netCents: Long, bps: Long = VAT_BPS): Long {
        val numerator = netCents * bps
        val quotient = numerator / 10_000L
        val remainder = numerator % 10_000L
        return when {
            remainder > 5_000L -> quotient + 1
            remainder < 5_000L -> quotient
            quotient % 2L != 0L -> quotient + 1
            else -> quotient
        }
    }

    fun percent(numerator: Double, denominator: Double): String {
        if (denominator <= 0.0) return "0.0%"
        val pct = ((numerator / denominator) * 1000.0).roundToLong() / 10.0
        return "${pct}%"
    }
}

data class PackageAvailabilityItem(
    val packageId: String,
    val packageCode: String,
    val packageIndex: Int,
    val totalPackages: Int,
    val requiredPerProduct: Int,
    val onHand: Int,
    val reserved: Int,
    val available: Int,
    val inTransit: Int,
    val quarantined: Int,
    val damaged: Int,
    val displayStock: Int
)

data class CompleteProductAvailability(
    val productId: String,
    val productCode: String,
    val productName: String,
    val siteId: String,
    val requiredPackagesCount: Int,
    val completeSetsAvailable: Int,
    val limitingPackageCode: String?,
    val packageBreakdown: List<PackageAvailabilityItem>
) {
    val hasPackageMismatch: Boolean
        get() = packageBreakdown.any { it.available > 0 } && completeSetsAvailable == 0

    companion object {
        fun compute(
            productId: String,
            productCode: String,
            productName: String,
            siteId: String,
            items: List<PackageAvailabilityItem>
        ): CompleteProductAvailability {
            val complete = if (items.isEmpty()) 0 else {
                items.minOf { item ->
                    if (item.requiredPerProduct <= 0) 0
                    else floor(item.available.toDouble() / item.requiredPerProduct.toDouble()).toInt()
                }
            }
            val limiting = items.minByOrNull { item ->
                if (item.requiredPerProduct <= 0) Int.MAX_VALUE
                else item.available / item.requiredPerProduct
            }?.packageCode
            return CompleteProductAvailability(
                productId = productId,
                productCode = productCode,
                productName = productName,
                siteId = siteId,
                requiredPackagesCount = items.size,
                completeSetsAvailable = complete,
                limitingPackageCode = limiting,
                packageBreakdown = items
            )
        }
    }
}

data class CostLayerBreakdown(
    val productId: String,
    val productCode: String,
    val materialsCents: Long,
    val manufacturingCents: Long,
    val packagingCents: Long,
    val transportCents: Long,
    val warehousingCents: Long,
    val storeAllocationCents: Long,
    val returnsAllowanceCents: Long,
    val serviceFulfilmentCents: Long,
    val stepCostThresholdUnits: Int,
    val stepCostSurchargePerBatchCents: Long,
    val sellingPriceNetCents: Long
) {
    val averageAllocatedCostCents: Long
        get() = materialsCents + manufacturingCents + packagingCents + transportCents +
            warehousingCents + storeAllocationCents + returnsAllowanceCents + serviceFulfilmentCents

    val incrementalUnitCostCents: Long
        get() = materialsCents + manufacturingCents + packagingCents + transportCents

    val contributionMarginCents: Long
        get() = sellingPriceNetCents - incrementalUnitCostCents

    val operatingMarginCents: Long
        get() = sellingPriceNetCents - averageAllocatedCostCents
}

data class DemoWorkflowStep(
    val stepNumber: Int,
    val title: String,
    val detail: String,
    val targetWorkspace: WorkspaceId,
    val isCompleted: Boolean,
    val entityRef: String
)

data class RoomItemPlacement(
    val id: String,
    val productId: String,
    val productCode: String,
    val label: String,
    val widthCm: Int,
    val depthCm: Int,
    val xCm: Int,
    val yCm: Int,
    val rotated: Boolean = false
) {
    val effectiveWidthCm: Int get() = if (rotated) depthCm else widthCm
    val effectiveDepthCm: Int get() = if (rotated) widthCm else depthCm
}
