package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.model.WorkspaceGroup
import com.example.domain.model.WorkspaceId
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.EnterpriseUiState
import com.example.ui.viewmodel.EnterpriseViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScaffold(vm: EnterpriseViewModel) {
    val state by vm.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    var showWorkspaceSheet by remember { mutableStateOf(false) }

    LaunchedEffect(state.feedbackMessage) {
        val msg = state.feedbackMessage
        if (msg != null) {
            snackbarHostState.showSnackbar(msg, duration = SnackbarDuration.Short)
            vm.clearFeedback()
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isExpanded = maxWidth >= 840.dp

        Row(modifier = Modifier.fillMaxSize()) {
            if (isExpanded) {
                NordicSideRail(
                    activeWorkspace = state.activeWorkspace,
                    onSelectWorkspace = { vm.selectWorkspace(it) }
                )
            }

            Scaffold(
                modifier = Modifier.weight(1f),
                containerColor = WarmGreyBg,
                snackbarHost = { SnackbarHost(snackbarHostState) },
                topBar = {
                    TopAppBar(
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = NordicBlue,
                            titleContentColor = InkOnBlue,
                            navigationIconContentColor = InkOnBlue,
                            actionIconContentColor = InkOnBlue
                        ),
                        navigationIcon = {
                            if (state.canNavigateBack && !isExpanded) {
                                IconButton(onClick = { vm.navigateBack() }) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                        contentDescription = "Back"
                                    )
                                }
                            }
                        },
                        title = {
                            Column {
                                Text(
                                    text = "NordicOps · ${state.activeWorkspace.title}",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = InkOnBlue,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${state.activeRole.displayName} · ${state.activeSite}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = WarmYellow,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        },
                        actions = {
                            if (!isExpanded) {
                                TextButton(
                                    onClick = { showWorkspaceSheet = true },
                                    modifier = Modifier
                                        .heightIn(min = 48.dp)
                                        .testTag("open_all_workspaces"),
                                    colors = ButtonDefaults.textButtonColors(contentColor = WarmYellow)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Apps,
                                        contentDescription = "All 16 workspaces",
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(Modifier.width(4.dp))
                                    Text("All 16", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    )
                },
                bottomBar = {
                    if (!isExpanded) {
                        NavigationBar(
                            containerColor = DeepNordicBlue,
                            contentColor = InkOnBlue
                        ) {
                            val primaryTabs = listOf(
                                WorkspaceId.OVERVIEW to Icons.Filled.Dashboard,
                                WorkspaceId.PRODUCTS to Icons.Filled.Inventory2,
                                WorkspaceId.INVENTORY to Icons.Filled.Warehouse,
                                WorkspaceId.ONLINE_ORDERS to Icons.Filled.ShoppingCart,
                                WorkspaceId.FINANCE to Icons.Filled.AccountBalance
                            )
                            primaryTabs.forEach { (ws, icon) ->
                                val selected = state.activeWorkspace == ws
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { vm.selectWorkspace(ws) },
                                    icon = { Icon(icon, contentDescription = ws.title) },
                                    label = {
                                        Text(
                                            text = ws.shortTitle,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = InkBlack,
                                        selectedTextColor = WarmYellow,
                                        indicatorColor = WarmYellow,
                                        unselectedIconColor = InkOnBlue.copy(alpha = 0.8f),
                                        unselectedTextColor = InkOnBlue.copy(alpha = 0.8f)
                                    )
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                WorkspaceContentHost(
                    state = state,
                    vm = vm,
                    modifier = Modifier.padding(innerPadding)
                )
            }
        }
    }

    if (showWorkspaceSheet) {
        ModalBottomSheet(
            onDismissRequest = { showWorkspaceSheet = false },
            containerColor = SurfaceWhite
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "All 16 Enterprise Workspaces",
                    style = MaterialTheme.typography.titleLarge,
                    color = DeepNordicBlue
                )
                LazyColumn(
                    modifier = Modifier.heightIn(max = 480.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    WorkspaceGroup.entries.forEach { group ->
                        item(key = "hdr-${group.name}") {
                            Text(
                                text = group.label.uppercase(),
                                style = MaterialTheme.typography.labelMedium,
                                color = InkSecondary,
                                modifier = Modifier.padding(top = 6.dp)
                            )
                        }
                        val groupItems = WorkspaceId.entries.filter { it.group == group }
                        items(groupItems, key = { it.name }) { ws ->
                            val active = state.activeWorkspace == ws
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (active) NordicBlueLight else WarmGreyBg)
                                    .clickable {
                                        vm.selectWorkspace(ws)
                                        showWorkspaceSheet = false
                                    }
                                    .padding(horizontal = 12.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Icon(
                                    imageVector = workspaceIcon(ws),
                                    contentDescription = ws.title,
                                    tint = if (active) NordicBlue else InkSecondary
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = ws.title,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = if (active) DeepNordicBlue else InkBlack
                                    )
                                    Text(
                                        text = ws.subtitle,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = InkSecondary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NordicSideRail(
    activeWorkspace: WorkspaceId,
    onSelectWorkspace: (WorkspaceId) -> Unit
) {
    Surface(
        modifier = Modifier
            .width(236.dp)
            .fillMaxHeight(),
        color = DeepNordicBlue
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            item {
                Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 10.dp)) {
                    Text(
                        text = "NORDICOPS",
                        style = MaterialTheme.typography.titleLarge,
                        color = WarmYellow
                    )
                    Text(
                        text = "Enterprise Workspace",
                        style = MaterialTheme.typography.bodySmall,
                        color = InkOnBlue.copy(alpha = 0.8f)
                    )
                }
            }
            WorkspaceGroup.entries.forEach { group ->
                item {
                    Text(
                        text = group.label.uppercase(),
                        style = MaterialTheme.typography.labelMedium,
                        color = InkOnBlue.copy(alpha = 0.6f),
                        modifier = Modifier.padding(start = 8.dp, top = 10.dp, bottom = 2.dp)
                    )
                }
                val groupItems = WorkspaceId.entries.filter { it.group == group }
                items(groupItems, key = { it.name }) { ws ->
                    val selected = ws == activeWorkspace
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 48.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (selected) WarmYellow else DeepNordicBlue)
                            .clickable { onSelectWorkspace(ws) }
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = workspaceIcon(ws),
                            contentDescription = ws.title,
                            tint = if (selected) InkBlack else InkOnBlue,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = ws.title,
                            style = MaterialTheme.typography.labelLarge,
                            color = if (selected) InkBlack else InkOnBlue,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun WorkspaceContentHost(
    state: EnterpriseUiState,
    vm: EnterpriseViewModel,
    modifier: Modifier = Modifier
) {
    when (state.activeWorkspace) {
        WorkspaceId.OVERVIEW -> OverviewScreen(
            state = state,
            onSelectWorkspace = { vm.selectWorkspace(it) },
            onRunStep = { vm.runDemoStep(it) },
            onRunAllSteps = { vm.runAllDemoSteps() },
            onResetDemo = { vm.resetDemo() },
            modifier = modifier
        )
        WorkspaceId.PRODUCTS -> ProductsScreen(
            state = state,
            onBack = { vm.navigateBack() },
            onCreateTwoPackageProduct = { c, n, v, p -> vm.createTwoPackageProduct(c, n, v, p) },
            modifier = modifier
        )
        WorkspaceId.DESIGN -> DesignScreen(
            state = state,
            onBack = { vm.navigateBack() },
            onAdvanceStage = { id, stg, rev -> vm.advanceDesignStage(id, stg, rev) },
            modifier = modifier
        )
        WorkspaceId.SUPPLIERS -> SuppliersScreen(
            state = state,
            onBack = { vm.navigateBack() },
            onCreatePo = { num, sup, comp, name, q, cost -> vm.createPurchaseOrder(num, sup, comp, name, q, cost) },
            onReceivePo = { id, delta, ok -> vm.receivePurchaseOrder(id, delta, ok) },
            modifier = modifier
        )
        WorkspaceId.MANUFACTURING -> ManufacturingScreen(
            state = state,
            onBack = { vm.navigateBack() },
            onScheduleAndRelease = { num, prod, wc, qty -> vm.scheduleAndReleaseProduction(num, prod, wc, qty) },
            modifier = modifier
        )
        WorkspaceId.INVENTORY -> InventoryScreen(
            state = state,
            onBack = { vm.navigateBack() },
            onSelectSite = { vm.setSite(it) },
            onTransferStock = { prod, from, to, q -> vm.transferStock(prod, from, to, q) },
            modifier = modifier
        )
        WorkspaceId.DISTRIBUTION -> DistributionScreen(
            state = state,
            onBack = { vm.navigateBack() },
            onUpgradeVehicle = { vm.upgradeShipmentVehicle(it) },
            modifier = modifier
        )
        WorkspaceId.STORES -> StoresScreen(
            state = state,
            vm = vm,
            onBack = { vm.navigateBack() },
            onPlaceStoreOrder = { p, s, ch, q, asm -> vm.placeOrder(p, s, ch, q, asm) },
            modifier = modifier
        )
        WorkspaceId.ONLINE_ORDERS -> OnlineOrdersScreen(
            state = state,
            onBack = { vm.navigateBack() },
            onPlaceOrder = { p, s, ch, q, asm -> vm.placeOrder(p, s, ch, q, asm) },
            onScheduleDelivery = { vm.scheduleDelivery(it) },
            modifier = modifier
        )
        WorkspaceId.DELIVERY_ASSEMBLY -> DeliveryAssemblyScreen(
            state = state,
            onBack = { vm.navigateBack() },
            onDeliverNextBox = { vm.deliverNextPackage(it) },
            onReportMissingFitting = { id, code -> vm.reportMissingFitting(id, code) },
            onDispatchSparePart = { vm.dispatchSparePart(it) },
            onCompleteAssembly = { vm.completeDeliveryAssembly(it) },
            modifier = modifier
        )
        WorkspaceId.RETURNS -> ReturnsScreen(
            state = state,
            onBack = { vm.navigateBack() },
            onProcessToResale = { id, price -> vm.processReturnToResale(id, price) },
            modifier = modifier
        )
        WorkspaceId.CUSTOMERS -> CustomersScreen(
            state = state,
            onBack = { vm.navigateBack() },
            modifier = modifier
        )
        WorkspaceId.WORKFORCE -> WorkforceScreen(
            state = state,
            onBack = { vm.navigateBack() },
            modifier = modifier
        )
        WorkspaceId.FINANCE -> FinanceScreen(
            state = state,
            onBack = { vm.navigateBack() },
            onPostReconciliation = { gross, ref -> vm.postReconciliationJournal(gross, ref) },
            modifier = modifier
        )
        WorkspaceId.ANALYTICS -> AnalyticsScreen(
            state = state,
            onBack = { vm.navigateBack() },
            modifier = modifier
        )
        WorkspaceId.ADMINISTRATION -> AdministrationScreen(
            state = state,
            onBack = { vm.navigateBack() },
            onSelectRole = { vm.setRole(it) },
            onDispatchOutbox = { vm.dispatchOutboxEvent(it) },
            modifier = modifier
        )
    }
}

private fun workspaceIcon(ws: WorkspaceId): ImageVector = when (ws) {
    WorkspaceId.OVERVIEW -> Icons.Outlined.Dashboard
    WorkspaceId.PRODUCTS -> Icons.Outlined.Inventory2
    WorkspaceId.DESIGN -> Icons.Outlined.Architecture
    WorkspaceId.SUPPLIERS -> Icons.Outlined.Handshake
    WorkspaceId.MANUFACTURING -> Icons.Outlined.PrecisionManufacturing
    WorkspaceId.INVENTORY -> Icons.Outlined.Warehouse
    WorkspaceId.DISTRIBUTION -> Icons.Outlined.LocalShipping
    WorkspaceId.STORES -> Icons.Outlined.Storefront
    WorkspaceId.ONLINE_ORDERS -> Icons.Outlined.ShoppingCart
    WorkspaceId.DELIVERY_ASSEMBLY -> Icons.Outlined.Build
    WorkspaceId.RETURNS -> Icons.Outlined.AssignmentReturn
    WorkspaceId.CUSTOMERS -> Icons.Outlined.People
    WorkspaceId.WORKFORCE -> Icons.Outlined.Badge
    WorkspaceId.FINANCE -> Icons.Outlined.AccountBalance
    WorkspaceId.ANALYTICS -> Icons.Outlined.Analytics
    WorkspaceId.ADMINISTRATION -> Icons.Outlined.AdminPanelSettings
}
