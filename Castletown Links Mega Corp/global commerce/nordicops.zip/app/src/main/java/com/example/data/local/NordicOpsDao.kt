package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface NordicOpsDao {

    // Reactive Flows
    @Query("SELECT * FROM product_families ORDER BY code ASC")
    fun observeProducts(): Flow<List<ProductFamilyEntity>>

    @Query("SELECT * FROM package_specs ORDER BY productId ASC, packageIndex ASC")
    fun observePackages(): Flow<List<PackageSpecEntity>>

    @Query("SELECT * FROM spare_parts ORDER BY partNumber ASC")
    fun observeSpareParts(): Flow<List<SparePartEntity>>

    @Query("SELECT * FROM design_changes ORDER BY updatedAt DESC")
    fun observeDesignChanges(): Flow<List<DesignChangeEntity>>

    @Query("SELECT * FROM suppliers ORDER BY code ASC")
    fun observeSuppliers(): Flow<List<SupplierEntity>>

    @Query("SELECT * FROM material_evidence ORDER BY supplierId ASC")
    fun observeMaterialEvidence(): Flow<List<MaterialEvidenceEntity>>

    @Query("SELECT * FROM purchase_orders ORDER BY poNumber DESC")
    fun observePurchaseOrders(): Flow<List<PurchaseOrderEntity>>

    @Query("SELECT * FROM work_centres ORDER BY code ASC")
    fun observeWorkCentres(): Flow<List<WorkCentreEntity>>

    @Query("SELECT * FROM production_orders ORDER BY orderNumber DESC")
    fun observeProductionOrders(): Flow<List<ProductionOrderEntity>>

    @Query("SELECT * FROM inventory_positions ORDER BY siteId ASC, packageId ASC")
    fun observeInventory(): Flow<List<InventoryPositionEntity>>

    @Query("SELECT * FROM stock_movements ORDER BY createdAt DESC LIMIT 100")
    fun observeStockMovements(): Flow<List<StockMovementEntity>>

    @Query("SELECT * FROM distribution_shipments ORDER BY shipmentNumber DESC")
    fun observeShipments(): Flow<List<DistributionShipmentEntity>>

    @Query("SELECT * FROM store_tasks ORDER BY siteId ASC")
    fun observeStoreTasks(): Flow<List<StoreTaskEntity>>

    @Query("SELECT * FROM customers ORDER BY code ASC")
    fun observeCustomers(): Flow<List<CustomerEntity>>

    @Query("SELECT * FROM sales_orders ORDER BY createdAt DESC")
    fun observeSalesOrders(): Flow<List<SalesOrderEntity>>

    @Query("SELECT * FROM delivery_assembly_tasks ORDER BY taskNumber DESC")
    fun observeDeliveryTasks(): Flow<List<DeliveryAssemblyTaskEntity>>

    @Query("SELECT * FROM return_cases ORDER BY rmaNumber DESC")
    fun observeReturnCases(): Flow<List<ReturnCaseEntity>>

    @Query("SELECT * FROM journal_entries ORDER BY createdAt DESC")
    fun observeJournalEntries(): Flow<List<JournalEntryEntity>>

    @Query("SELECT * FROM journal_lines")
    fun observeJournalLines(): Flow<List<JournalLineEntity>>

    @Query("SELECT * FROM sustainability_metrics ORDER BY productId ASC")
    fun observeSustainabilityMetrics(): Flow<List<SustainabilityMetricEntity>>

    @Query("SELECT * FROM workforce_shifts ORDER BY siteId ASC, workerCode ASC")
    fun observeWorkforceShifts(): Flow<List<WorkforceShiftEntity>>

    @Query("SELECT * FROM audit_outbox ORDER BY createdAt DESC LIMIT 120")
    fun observeAuditOutbox(): Flow<List<AuditOutboxEntity>>

    @Query("SELECT * FROM demo_step_progress ORDER BY stepNumber ASC")
    fun observeDemoProgress(): Flow<List<DemoStepProgressEntity>>

    // Direct lookup helpers for transactional validation
    @Query("SELECT COUNT(*) FROM product_families")
    suspend fun countProducts(): Int

    @Query("SELECT * FROM product_families WHERE id = :id LIMIT 1")
    suspend fun getProductById(id: String): ProductFamilyEntity?

    @Query("SELECT * FROM package_specs WHERE productId = :productId ORDER BY packageIndex ASC")
    suspend fun getPackagesForProduct(productId: String): List<PackageSpecEntity>

    @Query("SELECT * FROM package_specs WHERE id = :id LIMIT 1")
    suspend fun getPackageById(id: String): PackageSpecEntity?

    @Query("SELECT * FROM design_changes WHERE id = :id LIMIT 1")
    suspend fun getDesignChangeById(id: String): DesignChangeEntity?

    @Query("SELECT * FROM purchase_orders WHERE id = :id LIMIT 1")
    suspend fun getPurchaseOrderById(id: String): PurchaseOrderEntity?

    @Query("SELECT * FROM work_centres WHERE id = :id LIMIT 1")
    suspend fun getWorkCentreById(id: String): WorkCentreEntity?

    @Query("SELECT * FROM production_orders WHERE id = :id LIMIT 1")
    suspend fun getProductionOrderById(id: String): ProductionOrderEntity?

    @Query("SELECT * FROM inventory_positions WHERE packageId = :packageId AND siteId = :siteId AND zone = :zone LIMIT 1")
    suspend fun getInventoryPosition(packageId: String, siteId: String, zone: String): InventoryPositionEntity?

    @Query("SELECT * FROM inventory_positions WHERE packageId = :packageId AND siteId = :siteId")
    suspend fun getInventoryForPackageAtSite(packageId: String, siteId: String): List<InventoryPositionEntity>

    @Query("SELECT * FROM stock_movements WHERE idempotencyKey = :key LIMIT 1")
    suspend fun findMovementByIdempotencyKey(key: String): StockMovementEntity?

    @Query("SELECT * FROM sales_orders WHERE id = :id LIMIT 1")
    suspend fun getSalesOrderById(id: String): SalesOrderEntity?

    @Query("SELECT * FROM sales_orders WHERE idempotencyKey = :key LIMIT 1")
    suspend fun findOrderByIdempotencyKey(key: String): SalesOrderEntity?

    @Query("SELECT * FROM delivery_assembly_tasks WHERE id = :id LIMIT 1")
    suspend fun getDeliveryTaskById(id: String): DeliveryAssemblyTaskEntity?

    @Query("SELECT * FROM delivery_assembly_tasks WHERE orderId = :orderId LIMIT 1")
    suspend fun getDeliveryTaskByOrderId(orderId: String): DeliveryAssemblyTaskEntity?

    @Query("SELECT * FROM spare_parts WHERE id = :id LIMIT 1")
    suspend fun getSparePartById(id: String): SparePartEntity?

    @Query("SELECT * FROM return_cases WHERE id = :id LIMIT 1")
    suspend fun getReturnCaseById(id: String): ReturnCaseEntity?

    @Query("SELECT * FROM distribution_shipments WHERE id = :id LIMIT 1")
    suspend fun getShipmentById(id: String): DistributionShipmentEntity?

    @Query("SELECT * FROM audit_outbox WHERE id = :id LIMIT 1")
    suspend fun getAuditById(id: String): AuditOutboxEntity?

    // Inserts & Updates
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProducts(items: List<ProductFamilyEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPackages(items: List<PackageSpecEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSpareParts(items: List<SparePartEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDesignChanges(items: List<DesignChangeEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSuppliers(items: List<SupplierEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMaterialEvidence(items: List<MaterialEvidenceEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPurchaseOrders(items: List<PurchaseOrderEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkCentres(items: List<WorkCentreEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProductionOrders(items: List<ProductionOrderEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInventoryPositions(items: List<InventoryPositionEntity>)

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertStockMovement(movement: StockMovementEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStockMovementsSeed(items: List<StockMovementEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShipments(items: List<DistributionShipmentEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStoreTasks(items: List<StoreTaskEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomers(items: List<CustomerEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSalesOrders(items: List<SalesOrderEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDeliveryTasks(items: List<DeliveryAssemblyTaskEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReturnCases(items: List<ReturnCaseEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJournalEntries(items: List<JournalEntryEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJournalLines(items: List<JournalLineEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSustainabilityMetrics(items: List<SustainabilityMetricEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkforceShifts(items: List<WorkforceShiftEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditOutbox(item: AuditOutboxEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditOutboxList(items: List<AuditOutboxEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDemoProgress(items: List<DemoStepProgressEntity>)

    @Update
    suspend fun updateProduct(product: ProductFamilyEntity)

    @Update
    suspend fun updateDesignChange(change: DesignChangeEntity)

    @Update
    suspend fun updatePurchaseOrder(po: PurchaseOrderEntity)

    @Update
    suspend fun updateWorkCentre(wc: WorkCentreEntity)

    @Update
    suspend fun updateProductionOrder(order: ProductionOrderEntity)

    @Update
    suspend fun updateInventoryPosition(pos: InventoryPositionEntity)

    @Update
    suspend fun updateShipment(shipment: DistributionShipmentEntity)

    @Update
    suspend fun updateSalesOrder(order: SalesOrderEntity)

    @Update
    suspend fun updateDeliveryTask(task: DeliveryAssemblyTaskEntity)

    @Update
    suspend fun updateSparePart(part: SparePartEntity)

    @Update
    suspend fun updateReturnCase(ret: ReturnCaseEntity)

    @Update
    suspend fun updateAuditOutbox(entry: AuditOutboxEntity)

    // Clear all tables for clean demo reset
    @Query("DELETE FROM product_families") suspend fun clearProducts()
    @Query("DELETE FROM package_specs") suspend fun clearPackages()
    @Query("DELETE FROM spare_parts") suspend fun clearSpareParts()
    @Query("DELETE FROM design_changes") suspend fun clearDesignChanges()
    @Query("DELETE FROM suppliers") suspend fun clearSuppliers()
    @Query("DELETE FROM material_evidence") suspend fun clearMaterialEvidence()
    @Query("DELETE FROM purchase_orders") suspend fun clearPurchaseOrders()
    @Query("DELETE FROM work_centres") suspend fun clearWorkCentres()
    @Query("DELETE FROM production_orders") suspend fun clearProductionOrders()
    @Query("DELETE FROM inventory_positions") suspend fun clearInventory()
    @Query("DELETE FROM stock_movements") suspend fun clearStockMovements()
    @Query("DELETE FROM distribution_shipments") suspend fun clearShipments()
    @Query("DELETE FROM store_tasks") suspend fun clearStoreTasks()
    @Query("DELETE FROM customers") suspend fun clearCustomers()
    @Query("DELETE FROM sales_orders") suspend fun clearSalesOrders()
    @Query("DELETE FROM delivery_assembly_tasks") suspend fun clearDeliveryTasks()
    @Query("DELETE FROM return_cases") suspend fun clearReturnCases()
    @Query("DELETE FROM journal_entries") suspend fun clearJournalEntries()
    @Query("DELETE FROM journal_lines") suspend fun clearJournalLines()
    @Query("DELETE FROM sustainability_metrics") suspend fun clearSustainabilityMetrics()
    @Query("DELETE FROM workforce_shifts") suspend fun clearWorkforceShifts()
    @Query("DELETE FROM audit_outbox") suspend fun clearAuditOutbox()
    @Query("DELETE FROM demo_step_progress") suspend fun clearDemoProgress()

    @Transaction
    suspend fun clearAllTablesForReset() {
        clearProducts()
        clearPackages()
        clearSpareParts()
        clearDesignChanges()
        clearSuppliers()
        clearMaterialEvidence()
        clearPurchaseOrders()
        clearWorkCentres()
        clearProductionOrders()
        clearInventory()
        clearStockMovements()
        clearShipments()
        clearStoreTasks()
        clearCustomers()
        clearSalesOrders()
        clearDeliveryTasks()
        clearReturnCases()
        clearJournalEntries()
        clearJournalLines()
        clearSustainabilityMetrics()
        clearWorkforceShifts()
        clearAuditOutbox()
        clearDemoProgress()
    }

    @Transaction
    suspend fun postBalancedJournalEntry(
        entry: JournalEntryEntity,
        lines: List<JournalLineEntity>,
        audit: AuditOutboxEntity
    ) {
        val sumDebit = lines.sumOf { it.debitCents }
        val sumCredit = lines.sumOf { it.creditCents }
        require(sumDebit == sumCredit && sumDebit > 0L) {
            "Journal imbalance rejected: debit=$sumDebit credit=$sumCredit"
        }
        insertJournalEntries(listOf(entry.copy(totalDebitCents = sumDebit, totalCreditCents = sumCredit)))
        insertJournalLines(lines)
        insertAuditOutbox(audit)
    }

    @Transaction
    suspend fun releaseManufacturedPackages(
        productionOrderId: String,
        siteId: String,
        actorRole: String,
        idempotencyKey: String
    ): String {
        if (findMovementByIdempotencyKey(idempotencyKey) != null) {
            return "Idempotent skip: production release already recorded."
        }
        val prod = getProductionOrderById(productionOrderId)
            ?: error("Production order not found")
        val packages = getPackagesForProduct(prod.productId)
        require(packages.isNotEmpty()) { "No packages defined for product ${prod.productId}" }

        val qtyToRelease = prod.targetQty
        packages.forEachIndexed { idx, pkg ->
            val zone = "BACKROOM"
            val existing = getInventoryPosition(pkg.id, siteId, zone)
            val addedUnits = qtyToRelease * pkg.requiredQtyPerProduct
            if (existing != null) {
                updateInventoryPosition(
                    existing.copy(
                        onHand = existing.onHand + addedUnits,
                        version = existing.version + 1
                    )
                )
            } else {
                insertInventoryPositions(
                    listOf(
                        InventoryPositionEntity(
                            id = "inv-${pkg.id}-$siteId-$zone",
                            packageId = pkg.id,
                            siteId = siteId,
                            zone = zone,
                            aisleBin = "DC-RACK-0${idx + 1}",
                            onHand = addedUnits,
                            reserved = 0,
                            inTransit = 0,
                            quarantined = 0,
                            damaged = 0,
                            displayStock = 0,
                            version = 1
                        )
                    )
                )
            }
            insertStockMovement(
                StockMovementEntity(
                    id = "mov-${System.nanoTime()}-$idx",
                    idempotencyKey = "$idempotencyKey-pkg-${pkg.id}",
                    packageId = pkg.id,
                    siteId = siteId,
                    zone = zone,
                    movementType = "PRODUCTION_RELEASE",
                    qtyDelta = addedUnits,
                    bucket = "ON_HAND",
                    referenceId = prod.orderNumber,
                    actorRole = actorRole,
                    note = "Quality released ${prod.revisionTag} (${pkg.packageCode})"
                )
            )
        }
        updateProductionOrder(
            prod.copy(
                completedPackages = qtyToRelease * packages.size,
                status = "QUALITY_RELEASED",
                version = prod.version + 1
            )
        )
        insertAuditOutbox(
            AuditOutboxEntity(
                id = "aud-${System.nanoTime()}",
                eventType = "PRODUCTION_QUALITY_RELEASED",
                entityType = "ProductionOrder",
                entityId = prod.orderNumber,
                actorRole = actorRole,
                idempotencyKey = idempotencyKey,
                payloadSummary = "Released $qtyToRelease complete sets (${packages.size} packages each) at $siteId",
                outboxStatus = "PENDING"
            )
        )
        return "Released $qtyToRelease sets of ${prod.orderNumber} into $siteId Backroom"
    }

    @Transaction
    suspend fun transferCompleteProductStock(
        productId: String,
        fromSiteId: String,
        toSiteId: String,
        setsQty: Int,
        actorRole: String,
        idempotencyKey: String
    ): String {
        if (findMovementByIdempotencyKey("$idempotencyKey-check") != null) {
            return "Idempotent skip: transfer already applied."
        }
        val packages = getPackagesForProduct(productId)
        require(packages.isNotEmpty()) { "Product has no package specifications." }

        // Check availability across all required packages at origin first
        packages.forEach { pkg ->
            val src = getInventoryPosition(pkg.id, fromSiteId, "BACKROOM")
                ?: error("No stock at $fromSiteId for ${pkg.packageCode}")
            val needed = setsQty * pkg.requiredQtyPerProduct
            if (src.available < needed) {
                error("Insufficient available stock for ${pkg.packageCode} at $fromSiteId (avail=${src.available}, need=$needed)")
            }
        }

        packages.forEachIndexed { idx, pkg ->
            val needed = setsQty * pkg.requiredQtyPerProduct
            val src = getInventoryPosition(pkg.id, fromSiteId, "BACKROOM")!!
            updateInventoryPosition(
                src.copy(
                    onHand = src.onHand - needed,
                    version = src.version + 1
                )
            )
            insertStockMovement(
                StockMovementEntity(
                    id = "mov-out-${System.nanoTime()}-$idx",
                    idempotencyKey = if (idx == 0) "$idempotencyKey-check" else "$idempotencyKey-out-${pkg.id}",
                    packageId = pkg.id,
                    siteId = fromSiteId,
                    zone = "BACKROOM",
                    movementType = "TRANSFER_OUT",
                    qtyDelta = -needed,
                    bucket = "ON_HAND",
                    referenceId = "TRF->$toSiteId",
                    actorRole = actorRole,
                    note = "Transferred $needed units of ${pkg.packageCode} to $toSiteId"
                )
            )

            val destZone = "SELF_SERVICE_AISLE"
            val dest = getInventoryPosition(pkg.id, toSiteId, destZone)
            if (dest != null) {
                updateInventoryPosition(
                    dest.copy(
                        onHand = dest.onHand + needed,
                        version = dest.version + 1
                    )
                )
            } else {
                insertInventoryPositions(
                    listOf(
                        InventoryPositionEntity(
                            id = "inv-${pkg.id}-$toSiteId-$destZone",
                            packageId = pkg.id,
                            siteId = toSiteId,
                            zone = destZone,
                            aisleBin = "Aisle ${12 + idx}-Bin ${4 + idx}",
                            onHand = needed,
                            reserved = 0,
                            inTransit = 0,
                            quarantined = 0,
                            damaged = 0,
                            displayStock = 1,
                            version = 1
                        )
                    )
                )
            }
            insertStockMovement(
                StockMovementEntity(
                    id = "mov-in-${System.nanoTime()}-$idx",
                    idempotencyKey = "$idempotencyKey-in-${pkg.id}",
                    packageId = pkg.id,
                    siteId = toSiteId,
                    zone = destZone,
                    movementType = "TRANSFER_IN",
                    qtyDelta = needed,
                    bucket = "ON_HAND",
                    referenceId = "TRF<-$fromSiteId",
                    actorRole = actorRole,
                    note = "Received $needed units of ${pkg.packageCode} into $destZone"
                )
            )
        }
        insertAuditOutbox(
            AuditOutboxEntity(
                id = "aud-${System.nanoTime()}",
                eventType = "INTERSITE_STOCK_TRANSFERRED",
                entityType = "Transfer",
                entityId = "$fromSiteId->$toSiteId",
                actorRole = actorRole,
                idempotencyKey = idempotencyKey,
                payloadSummary = "Transferred $setsQty complete sets of $productId from $fromSiteId to $toSiteId",
                outboxStatus = "PENDING"
            )
        )
        return "Transferred $setsQty complete sets from $fromSiteId to $toSiteId"
    }

    @Transaction
    suspend fun placeOrderAndReserveCompleteSet(
        order: SalesOrderEntity,
        actorRole: String
    ): String {
        if (findOrderByIdempotencyKey(order.idempotencyKey) != null) {
            return "Idempotent skip: order ${order.orderNumber} already placed."
        }
        val packages = getPackagesForProduct(order.productId)
        require(packages.isNotEmpty()) { "Cannot order product without package definitions." }

        // Verify complete package set availability at site (sum across saleable zones: SELF_SERVICE_AISLE + BACKROOM)
        val selectedPositions = mutableListOf<Pair<PackageSpecEntity, InventoryPositionEntity>>()
        packages.forEach { pkg ->
            val needed = order.qty * pkg.requiredQtyPerProduct
            val positions = getInventoryForPackageAtSite(pkg.id, order.siteId)
                .filter { it.zone == "SELF_SERVICE_AISLE" || it.zone == "BACKROOM" }
            val best = positions.firstOrNull { it.available >= needed }
                ?: error("Complete-set reservation blocked: ${pkg.packageCode} lacks $needed available units at ${order.siteId} (missing package prevents sellable set).")
            selectedPositions.add(pkg to best)
        }

        // Atomically reserve every package in the set
        selectedPositions.forEachIndexed { idx, (pkg, pos) ->
            val needed = order.qty * pkg.requiredQtyPerProduct
            updateInventoryPosition(
                pos.copy(
                    reserved = pos.reserved + needed,
                    version = pos.version + 1
                )
            )
            insertStockMovement(
                StockMovementEntity(
                    id = "mov-res-${System.nanoTime()}-$idx",
                    idempotencyKey = "${order.idempotencyKey}-res-${pkg.id}",
                    packageId = pkg.id,
                    siteId = order.siteId,
                    zone = pos.zone,
                    movementType = "RESERVE",
                    qtyDelta = needed,
                    bucket = "RESERVED",
                    referenceId = order.orderNumber,
                    actorRole = actorRole,
                    note = "Atomic complete-set reservation for ${order.orderNumber}"
                )
            )
        }

        val confirmedOrder = order.copy(
            orderState = "CONFIRMED",
            paymentState = "CAPTURED_SIMULATED",
            fulfilmentState = "RESERVED_COMPLETE_SET",
            deliveryState = if (order.channel == "CLICK_AND_COLLECT") "COLLECTION_READY" else "NOT_SCHEDULED",
            assemblyState = if (order.assemblyAddon) "PENDING_SCHEDULE" else "NOT_REQUIRED"
        )
        insertSalesOrders(listOf(confirmedOrder))
        insertAuditOutbox(
            AuditOutboxEntity(
                id = "aud-${System.nanoTime()}",
                eventType = "ORDER_RESERVED_COMPLETE_SET",
                entityType = "SalesOrder",
                entityId = order.orderNumber,
                actorRole = actorRole,
                idempotencyKey = order.idempotencyKey,
                payloadSummary = "Order ${order.orderNumber}: atomically reserved ${packages.size} packages at ${order.siteId}",
                outboxStatus = "PENDING"
            )
        )
        return "Order ${order.orderNumber} confirmed with atomic ${packages.size}-package reservation"
    }
}
