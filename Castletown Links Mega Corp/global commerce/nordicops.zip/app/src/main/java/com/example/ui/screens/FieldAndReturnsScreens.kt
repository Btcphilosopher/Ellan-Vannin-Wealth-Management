package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.domain.model.MoneyFormat
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.EnterpriseUiState

@Composable
fun DeliveryAssemblyScreen(
    state: EnterpriseUiState,
    onBack: () -> Unit,
    onDeliverNextBox: (String) -> Unit,
    onReportMissingFitting: (String, String) -> Unit,
    onDispatchSparePart: (String) -> Unit,
    onCompleteAssembly: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(WarmGreyBg),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionHeader(
                title = "Delivery & Assembly Field Operations",
                subtitle = "Separated delivery vs assembly completion, instruction pinning & spare-part recovery"
            )
        }

        items(state.deliveryTasks, key = { it.id }) { task ->
            val order = state.salesOrders.firstOrNull { it.id == task.orderId }
            val hasMissingBlock = task.missingFittingCode != null && !task.sparePartDispatched

            EnterpriseCard(
                borderColor = if (hasMissingBlock) ExceptionRed.copy(alpha = 0.55f) else BorderHairline
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "${task.taskNumber} · Order ${order?.orderNumber ?: task.orderId}", style = MonoDataStyle, color = DeepNordicBlue)
                        Text(text = "${task.crewName} · ${task.vehicleCode}", style = MaterialTheme.typography.titleMedium)
                    }
                    StatusBadge(
                        text = if (task.assemblyCompleted) "ASSEMBLY DONE" else if (hasMissingBlock) "MISSING PART" else task.packageReadiness,
                        tone = when {
                            task.assemblyCompleted -> BadgeTone.VERIFIED
                            hasMissingBlock -> BadgeTone.EXCEPTION
                            else -> BadgeTone.INFO
                        }
                    )
                }

                Text(
                    text = "Skill: ${task.requiredSkill} · Est. ${task.estimatedMinutes} min · Pinned Manual: ${order?.instructionVersion ?: "INST-v1"}",
                    style = MaterialTheme.typography.bodySmall,
                    color = InkSecondary
                )
                Text(
                    text = "Protected Address & Photo Access: ${task.providerAccessWindow}",
                    style = MonoDataStyle,
                    color = DeepNordicBlue
                )
                Text(
                    text = "Boxes Delivered: ${task.deliveredPackages} / ${task.totalPackages} · Delivery Done: ${task.deliveryCompleted} · Assembly Done: ${task.assemblyCompleted} · Customer Accepted: ${task.customerAccepted}",
                    style = MaterialTheme.typography.bodySmall
                )

                if (task.missingFittingCode != null) {
                    Text(
                        text = "Missing Fitting: ${task.missingFittingCode} · Spare Part Dispatched: ${task.sparePartDispatched}",
                        style = MaterialTheme.typography.titleSmall,
                        color = if (task.sparePartDispatched) VerifiedGreen else ExceptionRed
                    )
                }

                if (!task.deliveryCompleted) {
                    NordicOutlineButton(
                        text = "Deliver Package ${task.deliveredPackages + 1} of ${task.totalPackages} (Split Check)",
                        onClick = { onDeliverNextBox(task.id) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                if (!task.assemblyCompleted) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (task.missingFittingCode == null) {
                            NordicOutlineButton(
                                text = "Report Missing SP-118331",
                                onClick = { onReportMissingFitting(task.id, "SP-118331") },
                                modifier = Modifier.weight(1f)
                            )
                        } else if (!task.sparePartDispatched) {
                            NordicPrimaryButton(
                                text = "Dispatch Spare Part",
                                onClick = { onDispatchSparePart(task.id) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        NordicPrimaryButton(
                            text = "Complete Assembly",
                            onClick = { onCompleteAssembly(task.id) },
                            enabled = !hasMissingBlock,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ReturnsScreen(
    state: EnterpriseUiState,
    onBack: () -> Unit,
    onProcessToResale: (String, Long) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(WarmGreyBg),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionHeader(
                title = "Returns, Quarantine & Circular Resale",
                subtitle = "Physical receipt enters Quarantine (never auto-saleable); refund & resale approval stay separate"
            )
        }

        items(state.returnCases, key = { it.id }) { ret ->
            val isQuarantined = ret.stockDisposition == "QUARANTINE"
            EnterpriseCard(borderColor = if (isQuarantined) WarningAmber.copy(alpha = 0.5f) else VerifiedGreen.copy(alpha = 0.5f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "${ret.rmaNumber} · Product ${ret.productId.uppercase()}", style = MonoDataStyle, color = DeepNordicBlue)
                        Text(text = ret.packageCheckNote, style = MaterialTheme.typography.titleSmall)
                    }
                    StatusBadge(
                        text = ret.stockDisposition,
                        tone = if (ret.approvedForResale) BadgeTone.VERIFIED else BadgeTone.WARNING
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    StatusBadge(text = "RECEIPT: ${ret.physicalReceiptState}", tone = BadgeTone.INFO)
                    StatusBadge(text = "REFUND: ${ret.refundState}", tone = if (ret.refundState == "APPROVED") BadgeTone.VERIFIED else BadgeTone.WARNING)
                }

                Text(
                    text = "Condition: ${ret.conditionGrade} · Missing: ${ret.missingPartsNote}",
                    style = MaterialTheme.typography.bodySmall,
                    color = InkSecondary
                )

                if (ret.approvedForResale) {
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = VerifiedGreenBg
                    ) {
                        Text(
                            text = "Anonymized Resale Lot: ${ret.resaleLotCode} · Markdown Price: ${MoneyFormat.formatEur(ret.resalePriceCents)} · Inspected by: ${ret.inspectedByRole} (Former customer PII purged)",
                            style = MaterialTheme.typography.bodySmall,
                            color = VerifiedGreen,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                } else {
                    NordicPrimaryButton(
                        text = "Inspect & Approve into Resale Stock (€549.00)",
                        onClick = { onProcessToResale(ret.id, 54900L) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}
