package com.example.data.local

import com.example.domain.model.DemoWorkflowStep
import com.example.domain.model.WorkspaceId

object DemoSeedData {

    val initialProducts = listOf(
        ProductFamilyEntity(
            id = "prod-fjell-120",
            code = "FJELL-120",
            name = "FJELL Modular Wardrobe 120cm",
            family = "FJELL Storage",
            variantName = "Birch Veneer / Matte White",
            dimensionsCm = "120 x 60 x 201 cm",
            finish = "Water-based White Lacquer & Clear Birch",
            materials = "FSC-certified Baltic birch ply, honeycomb core, zinc cam-locks",
            regionAssortment = "EU-NORTH / EU-WEST / UK",
            sellingPriceCents = 34900L,
            activeRevision = "REV-2.1",
            imageKey = "wardrobe"
        ),
        ProductFamilyEntity(
            id = "prod-skagen-3s",
            code = "SKAGEN-3S",
            name = "SKAGEN 3-Seat Linen Sofa",
            family = "SKAGEN Living",
            variantName = "Warm Grey Wool / Light Oak",
            dimensionsCm = "218 x 92 x 80 cm",
            finish = "Oiled European Oak & Unbleached Wool Blend",
            materials = "Solid oak frame, pocket springs, recycled PET wadding",
            regionAssortment = "EU-NORTH / EU-WEST",
            sellingPriceCents = 79900L,
            activeRevision = "REV-1.4",
            imageKey = "sofa"
        ),
        ProductFamilyEntity(
            id = "prod-alvar-140",
            code = "ALVAR-140",
            name = "ALVAR Work Desk 140cm",
            family = "ALVAR Workspace",
            variantName = "Oak Veneer / Powder White Steel",
            dimensionsCm = "140 x 70 x 74 cm",
            finish = "Matte Clear Acrylic / Epoxy Steel",
            materials = "Oak veneer particleboard, 45% recycled steel underframe",
            regionAssortment = "GLOBAL-CORE",
            sellingPriceCents = 22900L,
            activeRevision = "REV-3.0",
            imageKey = "desk"
        )
    )

    val initialPackages = listOf(
        // FJELL-120: 2-package wardrobe
        PackageSpecEntity(
            id = "pkg-fjell-1",
            productId = "prod-fjell-120",
            packageCode = "FJELL-120-BOX1",
            packageIndex = 1,
            totalPackages = 2,
            weightKg = 31.4,
            dimsCm = "205 x 63 x 9 cm",
            outerVolumeLiters = 116.2,
            contentVolumeLiters = 98.4,
            contentsSummary = "Side panels, top/bottom rails, hanging rod",
            barcode = "7340192801014",
            handlingReq = "FLAT_STACK_MAX_8 · 2-PERSON_LIFT",
            compatibleRevision = "REV-2.1",
            requiredQtyPerProduct = 1
        ),
        PackageSpecEntity(
            id = "pkg-fjell-2",
            productId = "prod-fjell-120",
            packageCode = "FJELL-120-BOX2",
            packageIndex = 2,
            totalPackages = 2,
            weightKg = 24.8,
            dimsCm = "199 x 61 x 7 cm",
            outerVolumeLiters = 85.0,
            contentVolumeLiters = 71.1,
            contentsSummary = "2x Doors, soft-close hinges, cam-lock kit CAM-M6",
            barcode = "7340192801021",
            handlingReq = "EDGE_PROTECTED · KEEP_DRY",
            compatibleRevision = "REV-2.1",
            requiredQtyPerProduct = 1
        ),
        // SKAGEN-3S: 2-package sofa
        PackageSpecEntity(
            id = "pkg-skagen-1",
            productId = "prod-skagen-3s",
            packageCode = "SKAGEN-3S-BOX1",
            packageIndex = 1,
            totalPackages = 2,
            weightKg = 38.0,
            dimsCm = "212 x 88 x 36 cm",
            outerVolumeLiters = 671.6,
            contentVolumeLiters = 540.0,
            contentsSummary = "Base frame, oak legs, M8 anchor bolts",
            barcode = "7340192802011",
            handlingReq = "FORKLIFT_OR_2_PERSON",
            compatibleRevision = "REV-1.4",
            requiredQtyPerProduct = 1
        ),
        PackageSpecEntity(
            id = "pkg-skagen-2",
            productId = "prod-skagen-3s",
            packageCode = "SKAGEN-3S-BOX2",
            packageIndex = 2,
            totalPackages = 2,
            weightKg = 22.5,
            dimsCm = "110 x 75 x 42 cm",
            outerVolumeLiters = 346.5,
            contentVolumeLiters = 290.0,
            contentsSummary = "Armrests, wool cushions, backrest upholstery",
            barcode = "7340192802028",
            handlingReq = "KEEP_DRY · DO_NOT_CRUSH",
            compatibleRevision = "REV-1.4",
            requiredQtyPerProduct = 1
        ),
        // ALVAR-140: 1-package desk
        PackageSpecEntity(
            id = "pkg-alvar-1",
            productId = "prod-alvar-140",
            packageCode = "ALVAR-140-BOX1",
            packageIndex = 1,
            totalPackages = 1,
            weightKg = 21.2,
            dimsCm = "146 x 74 x 8 cm",
            outerVolumeLiters = 86.4,
            contentVolumeLiters = 74.2,
            contentsSummary = "Tabletop, steel legs, cable tray, hex key kit",
            barcode = "7340192803018",
            handlingReq = "STANDARD_FLATPACK",
            compatibleRevision = "REV-3.0",
            requiredQtyPerProduct = 1
        )
    )

    val initialSpareParts = listOf(
        SparePartEntity("sp-cam-m6", "SP-118331", "Zinc Cam-Lock & Dowel Pack (8x)", "prod-fjell-120", "15mm zinc alloy cam + 8x30mm beech dowel", 142, 450L),
        SparePartEntity("sp-hinge-sc", "SP-109221", "Soft-Close Concealed Hinge 110°", "prod-fjell-120", "Nickel-plated steel cup 35mm", 68, 900L),
        SparePartEntity("sp-bolt-m8", "SP-120410", "M8x45 Leg Anchor Bolt Set", "prod-skagen-3s", "Grade 8.8 steel + spring washer", 94, 380L),
        SparePartEntity("sp-hex-4", "SP-100092", "4mm Z-Key & Cable Clip Kit", "prod-alvar-140", "Hardened Cr-V steel", 310, 150L)
    )

    val initialDesignChanges = listOf(
        DesignChangeEntity(
            id = "chg-fjell-21",
            productId = "prod-fjell-120",
            revisionTag = "REV-2.1",
            stage = "Released",
            designBrief = "Reinforced rear anti-tip wall bracket & FSC birch frame",
            targetCostCents = 14800L,
            bomSummary = "2x Birch side stiles, 2x honeycomb doors, 16x cam-locks, wall strap",
            prototypeNote = "Proto #P-214 validated door reveal gap 2.0mm +/- 0.4mm",
            testResultNote = "Cyclic hinge test 40,000 cycles passed; stability pull test 350N passed",
            packagingProposal = "Split 2-box ISTA-3A flat-pack under 32kg per box",
            instructionVersion = "INST-FJELL-v2.1",
            safetyChecklistReviewed = true,
            safetyReviewerNote = "Stability criteria reviewed; wall anchor notice printed on cover (not a statutory certification)",
            approvedByRole = "Design Engineer"
        ),
        DesignChangeEntity(
            id = "chg-skagen-15",
            productId = "prod-skagen-3s",
            revisionTag = "REV-1.5-DRAFT",
            stage = "Testing",
            designBrief = "Tool-free snap-bracket armrest revision to cut assembly time by 12 min",
            targetCostCents = 33500L,
            bomSummary = "Oak sub-frame, 2x snap-lock steel brackets, wool cover set",
            prototypeNote = "Proto #P-309 built at Almhult Prototyping Lab",
            testResultNote = "Martindale fabric abrasion 55,000 rubs; bracket fatigue test underway",
            packagingProposal = "Retain 2-box split; reduce Box 2 foam insert by 18%",
            instructionVersion = "INST-SKAGEN-v1.5d",
            safetyChecklistReviewed = false,
            safetyReviewerNote = "Pending structural cyclic shear review before Approved gate",
            approvedByRole = null
        )
    )

    val initialSuppliers = listOf(
        SupplierEntity("sup-baltic", "SUP-LT-01", "Baltic Ply & Veneer UAB", "Kaunas, Lithuania", "FAC-KAUNAS-A", "QUALIFIED", 14, 120, 96.4, 0.8, "Primary birch ply source (68% share) — single-factory dependency"),
        SupplierEntity("sup-smaland", "SUP-SE-04", "Smaland Precision Hardware AB", "Vaxjo, Sweden", "FAC-VAXJO-H2", "QUALIFIED", 7, 500, 98.9, 0.2, "Low concentration risk; dual-tooled zinc casting lines"),
        SupplierEntity("sup-silesia", "SUP-PL-09", "Silesia Upholstery & Foam Sp.", "Wroclaw, Poland", "FAC-WROCLAW-U1", "CONDITIONAL", 21, 60, 88.2, 2.4, "Shared factory FAC-WROCLAW-U1 supplies 2 sofa variants — monitor lead-time drift")
    )

    val initialMaterialEvidence = listOf(
        MaterialEvidenceEntity("ev-1", "sup-baltic", "Baltic Birch Plywood 18mm", "INDEPENDENTLY_VERIFIED", "Nordic Timber Assurance Body", "Chain-of-Custody Lot #LT-882", "2026-02-10", "2027-02-10", "Covers Kaunas Mill only"),
        MaterialEvidenceEntity("ev-2", "sup-smaland", "Recycled Zinc Alloy Cam-Locks", "SUPPLIER_DECLARATION", "Smaland Precision Hardware AB", "Self-declared 40% post-industrial scrap", "2026-04-01", "2027-04-01", "Unverified declaration — requires lab assay"),
        MaterialEvidenceEntity("ev-3", "sup-silesia", "Wool-Blend Upholstery", "INDEPENDENTLY_VERIFIED", "EuroTex Lab Audit", "OEKO-TEX Standard Check", "2026-01-15", "2027-01-15", "Lot-scoped to 2026 dye batch")
    )

    val initialPurchaseOrders = listOf(
        PurchaseOrderEntity("po-1001", "PO-2026-1001", "sup-baltic", "CMP-BIRCH-PANEL", "Pre-drilled Birch Side Panels", 240, 240, 4200L, "RECEIVED_INSPECTED", 14, true, "AQL 1.0 passed — 0 warped sheets"),
        PurchaseOrderEntity("po-1002", "PO-2026-1002", "sup-smaland", "CMP-CAM-KIT", "Cam-Lock & Hinge Hardware Kits", 400, 200, 1150L, "PARTIAL_RECEIVED", 7, false, "200/400 received; balance in transit"),
        PurchaseOrderEntity("po-1003", "PO-2026-1003", "sup-silesia", "CMP-SOFA-CUSH", "SKAGEN Wool Cushion Sets", 80, 0, 11800L, "ORDERED", 21, false, "Scheduled arrival in 9 days")
    )

    val initialWorkCentres = listOf(
        WorkCentreEntity("wc-cnc", "WC-CNC-01", "CNC Panel & Boring Line", "PLANT-ALM-01", 16.0, 12.5, false),
        WorkCentreEntity("wc-edge", "WC-EDGE-02", "Automated Edge-Banding", "PLANT-ALM-01", 16.0, 15.6, true),
        WorkCentreEntity("wc-pack", "WC-PACK-03", "Flat-Pack Cartoning & Strapping", "PLANT-ALM-01", 16.0, 11.0, false)
    )

    val initialProductionOrders = listOf(
        ProductionOrderEntity("mfg-501", "MO-2026-0501", "prod-fjell-120", "REV-2.1", "wc-cnc", 20, 40, 1, 1, "QUALITY_RELEASED", "CNC -> Edge Band -> Box 1 & Box 2 Pack", "All components issued", 11.5),
        ProductionOrderEntity("mfg-502", "MO-2026-0502", "prod-skagen-3s", "REV-1.4", "wc-edge", 12, 0, 0, 0, "SHORTAGE_BLOCKED", "Frame -> Upholstery -> 2-Box Pack", "Blocked: CMP-SOFA-CUSH 0 on hand (PO-2026-1003 open)", 0.0)
    )

    val initialInventory = listOf(
        // Notice: SKAGEN-3S at STORE-OSLO intentionally demonstrates the multi-package rule!
        // 4 units of BOX1 available, 0 units of BOX2 available => 0 complete sellable SKAGEN-3S sofas!
        InventoryPositionEntity("inv-fjell1-dc", "pkg-fjell-1", "DC-MALMO", "BACKROOM", "DC-A04-01", 28, 2, 0, 0, 0, 0),
        InventoryPositionEntity("inv-fjell2-dc", "pkg-fjell-2", "DC-MALMO", "BACKROOM", "DC-A04-02", 26, 2, 0, 0, 0, 0),
        InventoryPositionEntity("inv-fjell1-oslo", "pkg-fjell-1", "STORE-OSLO", "SELF_SERVICE_AISLE", "Aisle 14-Bin 02", 8, 1, 2, 0, 0, 1),
        InventoryPositionEntity("inv-fjell2-oslo", "pkg-fjell-2", "STORE-OSLO", "SELF_SERVICE_AISLE", "Aisle 14-Bin 03", 7, 1, 2, 0, 0, 1),
        InventoryPositionEntity("inv-skagen1-oslo", "pkg-skagen-1", "STORE-OSLO", "SELF_SERVICE_AISLE", "Aisle 06-Bin 11", 4, 0, 0, 0, 0, 1),
        InventoryPositionEntity("inv-skagen2-oslo", "pkg-skagen-2", "STORE-OSLO", "SELF_SERVICE_AISLE", "Aisle 06-Bin 12", 0, 0, 4, 1, 0, 1),
        InventoryPositionEntity("inv-alvar1-oslo", "pkg-alvar-1", "STORE-OSLO", "SELF_SERVICE_AISLE", "Aisle 09-Bin 01", 14, 2, 0, 0, 1, 2),
        InventoryPositionEntity("inv-fjell1-sthlm", "pkg-fjell-1", "STORE-STOCKHOLM", "SELF_SERVICE_AISLE", "Aisle 11-Bin 05", 5, 0, 0, 0, 0, 1),
        InventoryPositionEntity("inv-fjell2-sthlm", "pkg-fjell-2", "STORE-STOCKHOLM", "SELF_SERVICE_AISLE", "Aisle 11-Bin 06", 5, 0, 0, 0, 0, 1)
    )

    val initialMovements = listOf(
        StockMovementEntity("mov-seed-1", "seed-mov-1", "pkg-fjell-1", "DC-MALMO", "BACKROOM", "PRODUCTION_RELEASE", 28, "ON_HAND", "MO-2026-0501", "Factory Ops", "Released REV-2.1 Box 1"),
        StockMovementEntity("mov-seed-2", "seed-mov-2", "pkg-fjell-2", "DC-MALMO", "BACKROOM", "PRODUCTION_RELEASE", 26, "ON_HAND", "MO-2026-0501", "Factory Ops", "Released REV-2.1 Box 2"),
        StockMovementEntity("mov-seed-3", "seed-mov-3", "pkg-skagen-2", "STORE-OSLO", "QUARANTINE", "RETURN_QUARANTINE", 1, "QUARANTINED", "RMA-2026-008", "Warehouse Ops", "Returned cushion box held in Quarantine pending inspection")
    )

    val initialShipments = listOf(
        DistributionShipmentEntity(
            id = "shp-301",
            shipmentNumber = "SHP-2026-0301",
            originSiteId = "DC-MALMO",
            destSiteId = "STORE-OSLO",
            vehicleId = "TRK-EU-14 (24t Curtain)",
            vehicleMaxWeightKg = 18000.0,
            vehicleMaxVolM3 = 68.0,
            geometricEstimateVolM3 = 52.4,
            validatedLoadWeightKg = 11420.0,
            validatedLoadVolM3 = 58.9,
            packagingEfficiencyPct = 84.1,
            loadFeasible = true,
            infeasibilityReason = "",
            status = "IN_TRANSIT",
            carrierName = "Nordic Freight AB",
            deliveryWindow = "Tomorrow 06:00–08:30",
            proofOfReceiptNote = "Awaiting gate check-in at Oslo"
        ),
        DistributionShipmentEntity(
            id = "shp-302",
            shipmentNumber = "SHP-2026-0302",
            originSiteId = "DC-MALMO",
            destSiteId = "STORE-STOCKHOLM",
            vehicleId = "VAN-CITY-04 (3.5t EV)",
            vehicleMaxWeightKg = 1200.0,
            vehicleMaxVolM3 = 14.0,
            geometricEstimateVolM3 = 12.8,
            validatedLoadWeightKg = 1380.0,
            validatedLoadVolM3 = 15.2,
            packagingEfficiencyPct = 79.4,
            loadFeasible = false,
            infeasibilityReason = "INFEASIBLE: Validated pallet load 1380kg / 15.2m³ exceeds 1200kg / 14.0m³ EV limit after pallet overhang",
            status = "PLANNED",
            carrierName = "Svea Urban EV",
            deliveryWindow = "Pending vehicle upgrade",
            proofOfReceiptNote = "Blocked by load validation"
        )
    )

    val initialStoreTasks = listOf(
        StoreTaskEntity("tsk-1", "STORE-OSLO", "REPLENISHMENT", "Replenish Aisle 06-Bin 12 SKAGEN Box 2 from inbound SHP-2026-0301", "Warehouse Operator", "OPEN", "Aisle 06-Bin 12"),
        StoreTaskEntity("tsk-2", "STORE-OSLO", "FLOOR_DISPLAY", "Verify FJELL-120 wall-anchoring tag on Showroom Bay 4", "Store Associate", "COMPLETED", "Bay 04"),
        StoreTaskEntity("tsk-3", "STORE-OSLO", "CLICK_COLLECT", "Stage Order ORD-2026-9001 at Locker Bank B", "Store Associate", "IN_PROGRESS", "Collection B2"),
        StoreTaskEntity("tsk-4", "STORE-OSLO", "MAINTENANCE", "Pallet stacker #PS-02 hydraulic pressure check", "Warehouse Operator", "OPEN", "Backroom Dock 1")
    )

    val initialCustomers = listOf(
        CustomerEntity("cust-101", "CUST-8841", "Astrid Lindholm", "A*** L*** (Oslo-03)", "NO-OSLO", "0355", "Markveien 42B, 0554 Oslo [Protected]", 1),
        CustomerEntity("cust-102", "CUST-8842", "Henrik Solberg", "H*** S*** (Stockholm-11)", "SE-STHLM", "1145", "Sveavagen 88, 113 59 Stockholm [Protected]", 0)
    )

    val initialOrders = listOf(
        SalesOrderEntity(
            id = "ord-9001",
            orderNumber = "ORD-2026-9001",
            customerId = "cust-101",
            siteId = "STORE-OSLO",
            channel = "ONLINE_DELIVERY",
            productId = "prod-fjell-120",
            qty = 1,
            assemblyAddon = true,
            orderState = "CONFIRMED",
            paymentState = "CAPTURED_SIMULATED",
            fulfilmentState = "RESERVED_COMPLETE_SET",
            deliveryState = "PARTIALLY_DELIVERED",
            assemblyState = "SCHEDULED",
            totalCents = 46800L,
            deliveryChargeCents = 4900L,
            assemblyChargeCents = 7000L,
            instructionVersion = "INST-FJELL-v2.1",
            idempotencyKey = "seed-ord-9001"
        )
    )

    val initialDeliveryTasks = listOf(
        DeliveryAssemblyTaskEntity(
            id = "del-9001",
            taskNumber = "DA-2026-9001",
            orderId = "ord-9001",
            crewName = "Oslo Team Alpha (2-Tech)",
            vehicleCode = "EV-BOX-07",
            requiredSkill = "WALL_ANCHORING_CERT + CASEWORK",
            estimatedMinutes = 75,
            packageReadiness = "PARTIAL",
            deliveredPackages = 1,
            totalPackages = 2,
            deliveryCompleted = false,
            assemblyCompleted = false,
            missingFittingCode = null,
            sparePartDispatched = false,
            customerAccepted = false,
            providerAccessWindow = "Active 13:00–17:00 (Auto-expires in 3h)"
        )
    )

    val initialReturnCases = listOf(
        ReturnCaseEntity(
            id = "ret-008",
            rmaNumber = "RMA-2026-008",
            orderId = "ord-9001",
            productId = "prod-skagen-3s",
            packageCheckNote = "Box 2 opened; fabric spotless, 1x M8 leg washer missing",
            conditionGrade = "UNINSPECTED",
            refundState = "PENDING_REVIEW",
            physicalReceiptState = "RECEIVED_QUARANTINE",
            stockDisposition = "QUARANTINE",
            missingPartsNote = "Missing 1x M8 washer",
            resaleLotCode = null,
            resalePriceCents = 0L,
            inspectedByRole = null,
            approvedForResale = false
        )
    )

    val initialJournalEntries = listOf(
        JournalEntryEntity("je-1", "JE-2026-0001", "INVENTORY_VALUATION", "DC-MALMO", "Opening finished goods valuation (FJELL & ALVAR)", 1142000L, 1142000L, "EUR", 2500, "Finance Controller"),
        JournalEntryEntity("je-2", "JE-2026-0002", "SALES_ORDER", "ORD-2026-9001", "Simulated payment capture incl. 25% VAT & assembly fee", 46800L, 46800L, "EUR", 2500, "Finance Controller")
    )

    val initialJournalLines = listOf(
        JournalLineEntity("jl-1", "je-1", "1400", "Finished Goods Inventory", 1142000L, 0L),
        JournalLineEntity("jl-2", "je-1", "3010", "Opening Capital / WIP Absorption", 0L, 1142000L),
        JournalLineEntity("jl-3", "je-2", "1120", "Simulated Payment Clearing", 46800L, 0L),
        JournalLineEntity("jl-4", "je-2", "4000", "Furniture & Service Revenue (Net)", 0L, 37440L),
        JournalLineEntity("jl-5", "je-2", "2210", "Output VAT Payable (25.0%)", 0L, 9360L)
    )

    val initialSustainability = listOf(
        SustainabilityMetricEntity("sus-1", "prod-fjell-120", "MEASURED_MATERIAL", "Baltic Birch Mass per Unit", "41.8 kg measured", "Gate-to-gate Almhult line", "Direct scale reading", "2026-10-12", true),
        SustainabilityMetricEntity("sus-2", "prod-fjell-120", "MODELLED_EMISSIONS", "Cradle-to-Store Transport CO2e", "14.2 kg CO2e (modelled)", "Baltic -> Malmo -> Oslo 680km", "GLEC v3.0 road factor 0.062 kg/t-km", "2026-10-15", false),
        SustainabilityMetricEntity("sus-3", "prod-fjell-120", "SUPPLIER_STATEMENT", "Recycled Zinc Share in Cam-Locks", "40% declared by Smaland AB", "Hardware sub-assembly", "Supplier self-declaration only", "2026-04-01", false),
        SustainabilityMetricEntity("sus-4", "prod-fjell-120", "VERIFIED_CERTIFICATION", "Timber Chain-of-Custody", "Verified CoC #LT-882", "Kaunas Ply Mill", "Nordic Timber Assurance Audit", "2026-02-10", true)
    )

    val initialWorkforce = listOf(
        WorkforceShiftEntity("wf-1", "EMP-104", "Erik Lindqvist", "Factory Operations", "PLANT-ALM-01", "06:00–14:30", "CNC Safety L3 (Valid 2027)", "None"),
        WorkforceShiftEntity("wf-2", "EMP-219", "Maja Bergstrom", "Warehouse Operator", "DC-MALMO", "07:00–15:30", "Reach Truck & Hazmat-Dry", "Ticket #MT-41: Reach Truck #3 brake inspection"),
        WorkforceShiftEntity("wf-3", "EMP-308", "Sander Bakken", "Store Associate", "STORE-OSLO", "09:30–18:00", "Room Planner & Click-Collect", "None"),
        WorkforceShiftEntity("wf-4", "EMP-412", "Ingrid Holm", "Delivery & Assembly", "FIELD-OSLO", "08:00–16:30", "Wall-Anchoring & Casework Pro", "EV-BOX-07 tire check OK")
    )

    val initialAuditOutbox = listOf(
        AuditOutboxEntity("aud-seed-1", "SYSTEM_SEED_INITIALIZED", "Workspace", "NORDICOPS-DEMO", "Headquarters Admin", "seed-init-001", "Seeded 3 product families, 5 package specs, 3 sites, and balanced double-entry ledger", "DISPATCHED")
    )

    val demoStepDefinitions: List<DemoWorkflowStep> = listOf(
        DemoWorkflowStep(1, "Create two-package furniture product", "Create NORD-200 Oak Bookcase with BOX1 (frame) & BOX2 (glass doors)", WorkspaceId.PRODUCTS, false, "NORD-200"),
        DemoWorkflowStep(2, "Approve BOM & packaging", "Review safety criteria & release REV-1.0 BOM + 2-box ISTA packaging", WorkspaceId.DESIGN, false, "REV-1.0"),
        DemoWorkflowStep(3, "Purchase components", "Issue PO-2026-2001 to Baltic Ply for 20 sets of oak panels", WorkspaceId.SUPPLIERS, false, "PO-2026-2001"),
        DemoWorkflowStep(4, "Receive & inspect components", "Receive 20/20 sets with AQL inspection & 3-way match readiness", WorkspaceId.SUPPLIERS, false, "PO-2026-2001"),
        DemoWorkflowStep(5, "Manufacture & release packages", "Run MO-2026-2001 on CNC & release 20 complete 2-box sets to DC-MALMO", WorkspaceId.MANUFACTURING, false, "MO-2026-2001"),
        DemoWorkflowStep(6, "Transfer stock to store", "Transfer 8 complete 2-box sets from DC-MALMO to STORE-OSLO aisle bins", WorkspaceId.INVENTORY, false, "DC-MALMO->STORE-OSLO"),
        DemoWorkflowStep(7, "Place online order", "Place ORD-2026-9901 for NORD-200 with delivery & assembly add-on", WorkspaceId.ONLINE_ORDERS, false, "ORD-2026-9901"),
        DemoWorkflowStep(8, "Reserve complete package set", "Atomically reserve both BOX1 & BOX2 in STORE-OSLO inventory", WorkspaceId.INVENTORY, false, "ORD-2026-9901"),
        DemoWorkflowStep(9, "Schedule delivery & assembly", "Assign Oslo Team Alpha + EV-BOX-07 with INST-NORD-v1.0 pinned", WorkspaceId.DELIVERY_ASSEMBLY, false, "DA-2026-9901"),
        DemoWorkflowStep(10, "Report a missing fitting", "Crew reports missing SP-118331 cam-lock during assembly", WorkspaceId.DELIVERY_ASSEMBLY, false, "SP-118331"),
        DemoWorkflowStep(11, "Send a spare part", "Dispatch SP-118331 from spare-parts stock & unblock assembly", WorkspaceId.DELIVERY_ASSEMBLY, false, "SP-118331"),
        DemoWorkflowStep(12, "Complete assembly", "Record customer acceptance & separate delivery/assembly completion", WorkspaceId.DELIVERY_ASSEMBLY, false, "DA-2026-9901"),
        DemoWorkflowStep(13, "Process return into inspected resale stock", "Receive RMA-2026-008 via Quarantine, inspect, approve RESALE-LOT", WorkspaceId.RETURNS, false, "RMA-2026-008"),
        DemoWorkflowStep(14, "Reconcile stock, payments & margin", "Post balanced double-entry journal & verify trial balance + margin", WorkspaceId.FINANCE, false, "JE-2026-DEMO")
    )

    val initialDemoProgress = demoStepDefinitions.map {
        DemoStepProgressEntity(stepNumber = it.stepNumber, completed = false, entityRef = it.entityRef)
    }
}
