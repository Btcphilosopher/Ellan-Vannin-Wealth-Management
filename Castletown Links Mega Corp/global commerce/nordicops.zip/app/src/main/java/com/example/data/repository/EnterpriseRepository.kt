package com.example.data.repository

import com.example.data.local.*
import com.example.domain.model.CostLayerBreakdown
import com.example.domain.model.MoneyFormat
import com.example.domain.model.UserRole
import kotlinx.coroutines.flow.Flow

class EnterpriseRepository(private val db: NordicOpsDatabase) {
    private val dao = db.dao()

    val products: Flow<List<ProductFamilyEntity>> = dao.observeProducts()
    val packages: Flow<List<PackageSpecEntity>> = dao.observePackages()
    val spareParts: Flow<List<SparePartEntity>> = dao.observeSpareParts()
    val designChanges: Flow<List<DesignChangeEntity>> = dao.observeDesignChanges()
    val suppliers: Flow<List<SupplierEntity>> = dao.observeSuppliers()
    val materialEvidence: Flow<List<MaterialEvidenceEntity>> = dao.observeMaterialEvidence()
    val purchaseOrders: Flow<List<PurchaseOrderEntity>> = dao.observePurchaseOrders()
    val workCentres: Flow<List<WorkCentreEntity>> = dao.observeWorkCentres()
    val productionOrders: Flow<List<ProductionOrderEntity>> = dao.observeProductionOrders()
    val inventory: Flow<List<InventoryPositionEntity>> = dao.observeInventory()
    val stockMovements: Flow<List<StockMovementEntity>> = dao.observeStockMovements()
    val shipments: Flow<List<DistributionShipmentEntity>> = dao.observeShipments()
    val storeTasks: Flow<List<StoreTaskEntity>> = dao.observeStoreTasks()
    val customers: Flow<List<CustomerEntity>> = dao.observeCustomers()
    val salesOrders: Flow<List<SalesOrderEntity>> = dao.observeSalesOrders()
    val deliveryTasks: Flow<List<DeliveryAssemblyTaskEntity>> = dao.observeDeliveryTasks()
    val returnCases: Flow<List<ReturnCaseEntity>> = dao.observeReturnCases()
    val journalEntries: Flow<List<JournalEntryEntity>> = dao.observeJournalEntries()
    val journalLines: Flow<List<JournalLineEntity>> = dao.observeJournalLines()
    val sustainabilityMetrics: Flow<List<SustainabilityMetricEntity>> = dao.observeSustainabilityMetrics()
    val workforceShifts: Flow<List<WorkforceShiftEntity>> = dao.observeWorkforceShifts()
    val auditOutbox: Flow<List<AuditOutboxEntity>> = dao.observeAuditOutbox()
    val demoProgress: Flow<List<DemoStepProgressEntity>> = dao.observeDemoProgress()

    suspend fun initialize() = db.ensureSeeded()

    suspend fun resetDemo(): Result<String> = runCatching {
        db.resetToSeedData()
        "Workspace reset to baseline demonstration seed."
    }

    private suspend fun recordBlockedAudit(role: UserRole, action: String, entityId: String) {
        dao.insertAuditOutbox(
            AuditOutboxEntity(
                id = "aud-deny-${System.nanoTime()}",
                eventType = "ACCESS_DENIED",
                entityType = "PermissionGate",
                entityId = entityId,
                actorRole = role.displayName,
                idempotencyKey = "deny-${System.nanoTime()}",
                payloadSummary = "Blocked $action for role ${role.displayName}",
                outboxStatus = "DISPATCHED"
            )
        )
    }

    suspend fun createTwoPackageProduct(
        role: UserRole,
        code: String,
        name: String,
        variant: String,
        priceCents: Long,
        productId: String = "prod-${code.lowercase()}",
        revisionTag: String = "REV-1.0"
    ): Result<String> = runCatching {
        require(!role.isReadOnlyAuditor && (role.canApproveRevision || role == UserRole.HQ_ADMIN)) {
            recordBlockedAudit(role, "CREATE_PRODUCT", code)
            "Permission denied: ${role.displayName} cannot author new product masters."
        }
        val existing = dao.getProductById(productId)
        if (existing != null) return@runCatching "Product ${existing.code} already exists."
        val prod = ProductFamilyEntity(
            id = productId,
            code = code,
            name = name,
            family = "${code.substringBefore("-")} Living",
            variantName = variant,
            dimensionsCm = "90 x 40 x 195 cm",
            finish = "Oiled European Oak & Tempered Glass",
            materials = "FSC oak veneer, tempered safety glass, steel cam-locks",
            regionAssortment = "EU-NORTH / EU-WEST",
            sellingPriceCents = priceCents,
            activeRevision = revisionTag,
            imageKey = "wardrobe"
        )
        val box1 = PackageSpecEntity(
            id = "pkg-${code.lowercase()}-1",
            productId = productId,
            packageCode = "$code-BOX1",
            packageIndex = 1,
            totalPackages = 2,
            weightKg = 28.6,
            dimsCm = "198 x 43 x 8 cm",
            outerVolumeLiters = 68.1,
            contentVolumeLiters = 58.2,
            contentsSummary = "Oak side stiles, top/base plinths, adjustable shelves",
            barcode = "734019289${(1000..9999).random()}",
            handlingReq = "FLAT_STACK_MAX_8 · 2-PERSON_LIFT",
            compatibleRevision = revisionTag,
            requiredQtyPerProduct = 1
        )
        val box2 = PackageSpecEntity(
            id = "pkg-${code.lowercase()}-2",
            productId = productId,
            packageCode = "$code-BOX2",
            packageIndex = 2,
            totalPackages = 2,
            weightKg = 19.4,
            dimsCm = "188 x 45 x 6 cm",
            outerVolumeLiters = 50.8,
            contentVolumeLiters = 41.0,
            contentsSummary = "2x Tempered glass doors, soft hinges, CAM-M6 fittings",
            barcode = "734019289${(1000..9999).random()}",
            handlingReq = "GLASS_FRAGILE · VERTICAL_EDGE_GUARD",
            compatibleRevision = revisionTag,
            requiredQtyPerProduct = 1
        )
        val design = DesignChangeEntity(
            id = "chg-${code.lowercase()}-1",
            productId = productId,
            revisionTag = revisionTag,
            stage = "Prototype",
            designBrief = "Two-package flat-pack bookcase with glass door safety film",
            targetCostCents = (priceCents * 44L) / 100L,
            bomSummary = "2x Oak stiles, 4x shelves, 2x glass doors, 16x cam-locks",
            prototypeNote = "Proto #P-410 assembled in 38 min with 1x hex key",
            testResultNote = "Shelf deflection < 1.2mm at 25kg; wall strap pull test passed",
            packagingProposal = "2-box flat-pack (Box 1 Frame 28.6kg, Box 2 Glass Doors 19.4kg)",
            instructionVersion = "INST-$code-v1.0",
            safetyChecklistReviewed = false,
            safetyReviewerNote = "Awaiting engineering safety sign-off before Release",
            approvedByRole = null
        )
        dao.insertProducts(listOf(prod))
        dao.insertPackages(listOf(box1, box2))
        dao.insertDesignChanges(listOf(design))
        dao.insertAuditOutbox(
            AuditOutboxEntity(
                id = "aud-${System.nanoTime()}",
                eventType = "PRODUCT_MULTI_PACKAGE_CREATED",
                entityType = "ProductFamily",
                entityId = code,
                actorRole = role.displayName,
                idempotencyKey = "prod-create-$code",
                payloadSummary = "Created $code with 2 required packages ($code-BOX1, $code-BOX2)",
                outboxStatus = "PENDING"
            )
        )
        "Created $code with 2 required flat-pack boxes."
    }

    suspend fun advanceDesignStage(
        role: UserRole,
        changeId: String,
        targetStage: String,
        safetyReviewed: Boolean
    ): Result<String> = runCatching {
        if (!role.canApproveRevision) {
            recordBlockedAudit(role, "APPROVE_DESIGN_$targetStage", changeId)
            error("Permission denied: ${role.displayName} cannot advance or release product revisions.")
        }
        val current = dao.getDesignChangeById(changeId) ?: error("Design record not found")
        if (current.stage == "Released" && targetStage == "Released") {
            error("Immutable guard: Released revision ${current.revisionTag} cannot be silently edited; create a new revision.")
        }
        if ((targetStage == "Approved" || targetStage == "Released") && !safetyReviewed) {
            error("Safety review required: Complete product-safety criteria review before approving/releasing.")
        }
        val updated = current.copy(
            stage = targetStage,
            safetyChecklistReviewed = safetyReviewed,
            safetyReviewerNote = if (safetyReviewed) "Criteria reviewed (not a statutory certification claim)" else current.safetyReviewerNote,
            approvedByRole = if (targetStage in listOf("Approved", "Released")) role.displayName else current.approvedByRole,
            version = current.version + 1,
            updatedAt = System.currentTimeMillis()
        )
        dao.updateDesignChange(updated)
        dao.insertAuditOutbox(
            AuditOutboxEntity(
                id = "aud-${System.nanoTime()}",
                eventType = "DESIGN_STAGE_${targetStage.uppercase()}",
                entityType = "DesignChange",
                entityId = current.revisionTag,
                actorRole = role.displayName,
                idempotencyKey = "chg-$changeId-$targetStage-${updated.version}",
                payloadSummary = "Advanced ${current.productId} (${current.revisionTag}) to $targetStage",
                outboxStatus = "PENDING"
            )
        )
        "Revision ${current.revisionTag} moved to $targetStage."
    }

    suspend fun createPurchaseOrder(
        role: UserRole,
        poNumber: String,
        supplierId: String,
        componentCode: String,
        componentName: String,
        qty: Int,
        unitCostCents: Long,
        id: String = "po-${poNumber.lowercase()}"
    ): Result<String> = runCatching {
        if (!role.canManageProcurement) {
            recordBlockedAudit(role, "CREATE_PO", poNumber)
            error("Permission denied: ${role.displayName} cannot issue purchase orders.")
        }
        val existing = dao.getPurchaseOrderById(id)
        if (existing != null) return@runCatching "PO ${existing.poNumber} already issued."
        val po = PurchaseOrderEntity(
            id = id,
            poNumber = poNumber,
            supplierId = supplierId,
            componentCode = componentCode,
            componentName = componentName,
            qtyOrdered = qty,
            qtyReceived = 0,
            unitCostCents = unitCostCents,
            status = "ORDERED",
            leadTimeDays = 10,
            invoiceMatched = false,
            qualityNote = "Awaiting inbound dock receipt & AQL inspection"
        )
        dao.insertPurchaseOrders(listOf(po))
        dao.insertAuditOutbox(
            AuditOutboxEntity(
                id = "aud-${System.nanoTime()}",
                eventType = "PURCHASE_ORDER_ISSUED",
                entityType = "PurchaseOrder",
                entityId = poNumber,
                actorRole = role.displayName,
                idempotencyKey = "po-issue-$poNumber",
                payloadSummary = "Issued $poNumber for $qty x $componentCode",
                outboxStatus = "PENDING"
            )
        )
        "Issued $poNumber ($qty units)."
    }

    suspend fun receiveAndInspectPurchaseOrder(
        role: UserRole,
        poId: String,
        receiveDelta: Int,
        passedQuality: Boolean
    ): Result<String> = runCatching {
        if (!role.canManageProcurement && !role.canAdjustStock) {
            recordBlockedAudit(role, "RECEIVE_PO", poId)
            error("Permission denied: ${role.displayName} cannot receive inbound POs.")
        }
        val po = dao.getPurchaseOrderById(poId) ?: error("PO not found")
        val newReceived = (po.qtyReceived + receiveDelta).coerceAtMost(po.qtyOrdered)
        val newStatus = when {
            !passedQuality -> "QUALITY_HOLD"
            newReceived >= po.qtyOrdered -> "RECEIVED_INSPECTED"
            else -> "PARTIAL_RECEIVED"
        }
        dao.updatePurchaseOrder(
            po.copy(
                qtyReceived = newReceived,
                status = newStatus,
                invoiceMatched = passedQuality && newReceived >= po.qtyOrdered,
                qualityNote = if (passedQuality) "AQL 1.0 passed ($newReceived/${po.qtyOrdered})" else "NCR raised: moisture variance",
                version = po.version + 1
            )
        )
        dao.insertAuditOutbox(
            AuditOutboxEntity(
                id = "aud-${System.nanoTime()}",
                eventType = "PO_RECEIPT_INSPECTED",
                entityType = "PurchaseOrder",
                entityId = po.poNumber,
                actorRole = role.displayName,
                idempotencyKey = "po-rcv-$poId-$newReceived",
                payloadSummary = "${po.poNumber}: $newReceived/${po.qtyOrdered} status=$newStatus",
                outboxStatus = "PENDING"
            )
        )
        "${po.poNumber} updated to $newStatus ($newReceived/${po.qtyOrdered})."
    }

    suspend fun scheduleAndReleaseProduction(
        role: UserRole,
        orderNumber: String,
        productId: String,
        workCentreId: String,
        qty: Int,
        id: String = "mfg-${orderNumber.lowercase()}"
    ): Result<String> = runCatching {
        if (!role.canReleaseProduction && role != UserRole.HQ_ADMIN) {
            recordBlockedAudit(role, "RELEASE_PRODUCTION", orderNumber)
            error("Permission denied: ${role.displayName} cannot release factory production.")
        }
        val wc = dao.getWorkCentreById(workCentreId) ?: error("Work centre not found")
        val neededHours = qty * 0.25
        if (wc.bookedHours + neededHours > wc.capacityHoursPerDay + 8.0) {
            val blocked = ProductionOrderEntity(
                id = id,
                orderNumber = orderNumber,
                productId = productId,
                revisionTag = "REV-1.0",
                workCentreId = workCentreId,
                targetQty = qty,
                completedPackages = 0,
                scrapQty = 0,
                reworkQty = 0,
                status = "INFEASIBLE_CAPACITY",
                routingNotes = "Exceeds ${wc.code} daily capacity (${wc.bookedHours + neededHours}h > ${wc.capacityHoursPerDay}h)",
                materialShortageNote = "Capacity bottleneck flagged explicitly",
                labourHoursBooked = 0.0
            )
            dao.insertProductionOrders(listOf(blocked))
            return@runCatching "Flagged INFEASIBLE_CAPACITY on ${wc.code}: exceeds capacity threshold."
        }

        val prod = dao.getProductById(productId) ?: error("Product not found")
        val existing = dao.getProductionOrderById(id)
        if (existing == null) {
            dao.insertProductionOrders(
                listOf(
                    ProductionOrderEntity(
                        id = id,
                        orderNumber = orderNumber,
                        productId = productId,
                        revisionTag = prod.activeRevision,
                        workCentreId = workCentreId,
                        targetQty = qty,
                        completedPackages = 0,
                        scrapQty = 0,
                        reworkQty = 0,
                        status = "IN_PROGRESS",
                        routingNotes = "CNC -> Edge Band -> Flat-Pack Cartoning",
                        materialShortageNote = "Components verified",
                        labourHoursBooked = neededHours
                    )
                )
            )
            dao.updateWorkCentre(wc.copy(bookedHours = wc.bookedHours + neededHours))
        }
        dao.releaseManufacturedPackages(
            productionOrderId = id,
            siteId = "DC-MALMO",
            actorRole = role.displayName,
            idempotencyKey = "rel-$id"
        )
    }

    suspend fun transferStock(
        role: UserRole,
        productId: String,
        fromSiteId: String,
        toSiteId: String,
        setsQty: Int,
        idempotencyKey: String = "trf-${productId}-$fromSiteId-$toSiteId-${System.currentTimeMillis()}"
    ): Result<String> = runCatching {
        if (!role.canAdjustStock && role != UserRole.HQ_ADMIN) {
            recordBlockedAudit(role, "TRANSFER_STOCK", productId)
            error("Permission denied: ${role.displayName} cannot execute stock transfers.")
        }
        dao.transferCompleteProductStock(productId, fromSiteId, toSiteId, setsQty, role.displayName, idempotencyKey)
    }

    suspend fun placeOrderWithAtomicReservation(
        role: UserRole,
        orderNumber: String,
        customerId: String,
        siteId: String,
        channel: String,
        productId: String,
        qty: Int,
        assemblyAddon: Boolean,
        id: String = "ord-${orderNumber.lowercase()}",
        idempotencyKey: String = "ord-key-$orderNumber"
    ): Result<String> = runCatching {
        val product = dao.getProductById(productId) ?: error("Product not found")
        val deliveryCents = if (channel == "ONLINE_DELIVERY") 4900L else 0L
        val assemblyCents = if (assemblyAddon) 6500L else 0L
        val totalCents = (product.sellingPriceCents * qty) + deliveryCents + assemblyCents
        val order = SalesOrderEntity(
            id = id,
            orderNumber = orderNumber,
            customerId = customerId,
            siteId = siteId,
            channel = channel,
            productId = productId,
            qty = qty,
            assemblyAddon = assemblyAddon,
            orderState = "CREATED",
            paymentState = "AUTHORIZED",
            fulfilmentState = "UNALLOCATED",
            deliveryState = "NOT_SCHEDULED",
            assemblyState = if (assemblyAddon) "PENDING_SCHEDULE" else "NOT_REQUIRED",
            totalCents = totalCents,
            deliveryChargeCents = deliveryCents,
            assemblyChargeCents = assemblyCents,
            instructionVersion = "INST-${product.code}-${product.activeRevision}",
            idempotencyKey = idempotencyKey
        )
        dao.placeOrderAndReserveCompleteSet(order, role.displayName)
    }

    suspend fun scheduleDeliveryAndAssembly(
        role: UserRole,
        orderId: String,
        taskNumber: String,
        id: String = "del-${taskNumber.lowercase()}"
    ): Result<String> = runCatching {
        val order = dao.getSalesOrderById(orderId) ?: error("Order not found")
        val pkgs = dao.getPackagesForProduct(order.productId)
        val existing = dao.getDeliveryTaskById(id)
        if (existing != null) return@runCatching "Schedule ${existing.taskNumber} already active."
        val task = DeliveryAssemblyTaskEntity(
            id = id,
            taskNumber = taskNumber,
            orderId = orderId,
            crewName = "Oslo Team Alpha (2-Tech)",
            vehicleCode = "EV-BOX-07",
            requiredSkill = "WALL_ANCHORING_CERT + CASEWORK",
            estimatedMinutes = if (order.assemblyAddon) 65 else 25,
            packageReadiness = "READY",
            deliveredPackages = 0,
            totalPackages = pkgs.size * order.qty,
            deliveryCompleted = false,
            assemblyCompleted = false,
            missingFittingCode = null,
            sparePartDispatched = false,
            customerAccepted = false,
            providerAccessWindow = "Active 10:00–14:00 (Time-limited)"
        )
        dao.insertDeliveryTasks(listOf(task))
        dao.updateSalesOrder(
            order.copy(
                deliveryState = "SCHEDULED",
                assemblyState = if (order.assemblyAddon) "SCHEDULED" else "NOT_REQUIRED",
                version = order.version + 1
            )
        )
        "Scheduled ${taskNumber} for ${order.orderNumber} (${pkgs.size} packages ready)."
    }

    suspend fun recordSplitDeliveryPackage(role: UserRole, taskId: String): Result<String> = runCatching {
        val task = dao.getDeliveryTaskById(taskId) ?: error("Task not found")
        val order = dao.getSalesOrderById(task.orderId) ?: error("Order not found")
        val nextDelivered = (task.deliveredPackages + 1).coerceAtMost(task.totalPackages)
        val allDelivered = nextDelivered >= task.totalPackages
        dao.updateDeliveryTask(
            task.copy(
                deliveredPackages = nextDelivered,
                deliveryCompleted = allDelivered,
                packageReadiness = if (allDelivered) "READY" else "PARTIAL",
                version = task.version + 1
            )
        )
        dao.updateSalesOrder(
            order.copy(
                deliveryState = if (allDelivered) "DELIVERED" else "PARTIALLY_DELIVERED",
                fulfilmentState = if (allDelivered) "FULFILLED" else "PARTIALLY_PICKED",
                version = order.version + 1
            )
        )
        if (allDelivered) "All ${task.totalPackages} packages delivered (assembly remains separate)."
        else "Split delivery: $nextDelivered/${task.totalPackages} boxes delivered; order stays PARTIALLY_DELIVERED."
    }

    suspend fun reportMissingFitting(role: UserRole, taskId: String, partCode: String): Result<String> = runCatching {
        val task = dao.getDeliveryTaskById(taskId) ?: error("Task not found")
        val order = dao.getSalesOrderById(task.orderId) ?: error("Order not found")
        dao.updateDeliveryTask(
            task.copy(
                missingFittingCode = partCode,
                sparePartDispatched = false,
                assemblyCompleted = false,
                version = task.version + 1
            )
        )
        dao.updateSalesOrder(
            order.copy(
                assemblyState = "BLOCKED_MISSING_PART",
                version = order.version + 1
            )
        )
        dao.insertAuditOutbox(
            AuditOutboxEntity(
                id = "aud-${System.nanoTime()}",
                eventType = "MISSING_FITTING_REPORTED",
                entityType = "DeliveryTask",
                entityId = task.taskNumber,
                actorRole = role.displayName,
                idempotencyKey = "missing-$taskId-$partCode",
                payloadSummary = "Reported missing $partCode on ${task.taskNumber}",
                outboxStatus = "PENDING"
            )
        )
        "Reported missing $partCode — assembly blocked pending spare-part dispatch."
    }

    suspend fun dispatchSparePartForTask(role: UserRole, taskId: String, sparePartId: String = "sp-cam-m6"): Result<String> = runCatching {
        val task = dao.getDeliveryTaskById(taskId) ?: error("Task not found")
        val part = dao.getSparePartById(sparePartId) ?: error("Spare part not found")
        require(part.stockOnHand > 0) { "Spare part ${part.partNumber} out of stock" }
        dao.updateSparePart(part.copy(stockOnHand = part.stockOnHand - 1))
        dao.updateDeliveryTask(
            task.copy(
                sparePartDispatched = true,
                version = task.version + 1
            )
        )
        dao.insertAuditOutbox(
            AuditOutboxEntity(
                id = "aud-${System.nanoTime()}",
                eventType = "SPARE_PART_DISPATCHED",
                entityType = "SparePart",
                entityId = part.partNumber,
                actorRole = role.displayName,
                idempotencyKey = "sp-disp-$taskId-${part.partNumber}",
                payloadSummary = "Dispatched 1x ${part.partNumber} to ${task.taskNumber}",
                outboxStatus = "PENDING"
            )
        )
        "Dispatched ${part.partNumber} (${part.name}) to ${task.crewName}."
    }

    suspend fun completeDeliveryAndAssembly(role: UserRole, taskId: String): Result<String> = runCatching {
        val task = dao.getDeliveryTaskById(taskId) ?: error("Task not found")
        val order = dao.getSalesOrderById(task.orderId) ?: error("Order not found")
        if (task.missingFittingCode != null && !task.sparePartDispatched) {
            error("Cannot complete assembly: missing fitting ${task.missingFittingCode} not yet dispatched.")
        }
        dao.updateDeliveryTask(
            task.copy(
                deliveredPackages = task.totalPackages,
                deliveryCompleted = true,
                assemblyCompleted = true,
                customerAccepted = true,
                packageReadiness = "READY",
                version = task.version + 1
            )
        )
        dao.updateSalesOrder(
            order.copy(
                deliveryState = "DELIVERED",
                fulfilmentState = "FULFILLED",
                assemblyState = "COMPLETED",
                version = order.version + 1
            )
        )
        "Delivery & assembly completed with customer acceptance on ${task.taskNumber}."
    }

    suspend fun processReturnToResale(
        role: UserRole,
        returnId: String,
        resalePriceCents: Long
    ): Result<String> = runCatching {
        if (!role.canAdjustStock && !role.canApproveFinance && role != UserRole.STORE_ASSOCIATE) {
            recordBlockedAudit(role, "APPROVE_RESALE", returnId)
            error("Permission denied: ${role.displayName} cannot approve inspected resale disposition.")
        }
        val ret = dao.getReturnCaseById(returnId) ?: error("Return case not found")
        val lot = ret.resaleLotCode ?: "RESALE-LOT-${ret.rmaNumber.takeLast(3)}"
        dao.updateReturnCase(
            ret.copy(
                conditionGrade = "GRADE_A_LIKE_NEW",
                physicalReceiptState = "RECEIVED_QUARANTINE",
                stockDisposition = "RESALE_INSPECTED",
                refundState = "APPROVED",
                resaleLotCode = lot,
                resalePriceCents = resalePriceCents,
                inspectedByRole = role.displayName,
                approvedForResale = true,
                version = ret.version + 1
            )
        )
        dao.insertAuditOutbox(
            AuditOutboxEntity(
                id = "aud-${System.nanoTime()}",
                eventType = "RETURN_TO_INSPECTED_RESALE",
                entityType = "ReturnCase",
                entityId = ret.rmaNumber,
                actorRole = role.displayName,
                idempotencyKey = "resale-${ret.rmaNumber}",
                payloadSummary = "Moved ${ret.rmaNumber} from Quarantine to $lot at ${MoneyFormat.formatEur(resalePriceCents)} (former customer PII stripped)",
                outboxStatus = "PENDING"
            )
        )
        "${ret.rmaNumber} approved into $lot (${MoneyFormat.formatEur(resalePriceCents)}); refund approved separately."
    }

    suspend fun reconcileFinanceJournal(
        role: UserRole,
        entryNumber: String,
        referenceId: String,
        grossCents: Long
    ): Result<String> = runCatching {
        if (!role.canApproveFinance) {
            recordBlockedAudit(role, "POST_JOURNAL", entryNumber)
            error("Permission denied: ${role.displayName} cannot post financial reconciliation journals.")
        }
        val vat = MoneyFormat.calculateVatHalfEven(grossCents - (grossCents * 10000L / 12500L))
        val net = grossCents - vat
        val cogs = (net * 46L) / 100L
        val entryId = "je-${entryNumber.lowercase()}"
        val entry = JournalEntryEntity(
            id = entryId,
            entryNumber = entryNumber,
            referenceType = "E2E_RECONCILIATION",
            referenceId = referenceId,
            description = "Reconcile payment capture, 25% VAT, and COGS inventory relief ($referenceId)",
            totalDebitCents = grossCents + cogs,
            totalCreditCents = grossCents + cogs,
            createdByRole = role.displayName
        )
        val lines = listOf(
            JournalLineEntity("jl-${entryId}-1", entryId, "1120", "Payment Clearing", grossCents, 0L),
            JournalLineEntity("jl-${entryId}-2", entryId, "4000", "Product & Service Revenue", 0L, net),
            JournalLineEntity("jl-${entryId}-3", entryId, "2210", "Output VAT (25.00%)", 0L, vat),
            JournalLineEntity("jl-${entryId}-4", entryId, "5000", "Cost of Goods Sold", cogs, 0L),
            JournalLineEntity("jl-${entryId}-5", entryId, "1400", "Finished Goods Inventory", 0L, cogs)
        )
        val audit = AuditOutboxEntity(
            id = "aud-${System.nanoTime()}",
            eventType = "DOUBLE_ENTRY_RECONCILED",
            entityType = "JournalEntry",
            entityId = entryNumber,
            actorRole = role.displayName,
            idempotencyKey = "je-$entryNumber",
            payloadSummary = "Posted balanced $entryNumber (${MoneyFormat.formatEur(grossCents + cogs)} Dr=Cr)",
            outboxStatus = "PENDING"
        )
        dao.postBalancedJournalEntry(entry, lines, audit)
        "Posted balanced $entryNumber (Dr = Cr = ${MoneyFormat.formatEur(grossCents + cogs)})."
    }

    suspend fun dispatchOutboxEvent(role: UserRole, auditId: String): Result<String> = runCatching {
        val entry = dao.getAuditById(auditId) ?: error("Outbox event not found")
        dao.updateAuditOutbox(entry.copy(outboxStatus = "DISPATCHED"))
        "Dispatched outbox event ${entry.eventType}."
    }

    suspend fun upgradeShipmentVehicle(role: UserRole, shipmentId: String): Result<String> = runCatching {
        val shp = dao.getShipmentById(shipmentId) ?: error("Shipment not found")
        dao.updateShipment(
            shp.copy(
                vehicleId = "TRK-EU-19 (18t Rigid)",
                vehicleMaxWeightKg = 9000.0,
                vehicleMaxVolM3 = 42.0,
                loadFeasible = true,
                infeasibilityReason = "",
                status = "IN_TRANSIT",
                deliveryWindow = "Tomorrow 07:30–10:00",
                version = shp.version + 1
            )
        )
        "Reassigned ${shp.shipmentNumber} to 18t Rigid Truck — load validation now FEASIBLE."
    }

    fun computeCostLayers(product: ProductFamilyEntity): CostLayerBreakdown {
        val netPrice = (product.sellingPriceCents * 10000L) / 12500L
        return CostLayerBreakdown(
            productId = product.id,
            productCode = product.code,
            materialsCents = (netPrice * 31L) / 100L,
            manufacturingCents = (netPrice * 14L) / 100L,
            packagingCents = (netPrice * 4L) / 100L,
            transportCents = (netPrice * 7L) / 100L,
            warehousingCents = (netPrice * 5L) / 100L,
            storeAllocationCents = (netPrice * 11L) / 100L,
            returnsAllowanceCents = (netPrice * 2L) / 100L,
            serviceFulfilmentCents = (netPrice * 3L) / 100L,
            stepCostThresholdUnits = 50,
            stepCostSurchargePerBatchCents = 42000L,
            sellingPriceNetCents = netPrice
        )
    }

    suspend fun executeDemoStep(stepNumber: Int, currentRole: UserRole): Result<String> {
        val effRole = UserRole.HQ_ADMIN // Run E2E orchestrator with HQ privilege while logging real actor
        val msg = when (stepNumber) {
            1 -> createTwoPackageProduct(effRole, "NORD-200", "NORD Oak Glass Bookcase", "Natural Oak / Clear Glass", 28900L, "prod-nord-200", "REV-1.0")
            2 -> advanceDesignStage(effRole, "chg-nord-200-1", "Released", true)
            3 -> createPurchaseOrder(effRole, "PO-2026-2001", "sup-baltic", "CMP-NORD-OAK", "NORD-200 Oak Stiles & Tempered Doors", 20, 9200L, "po-2026-2001")
            4 -> receiveAndInspectPurchaseOrder(effRole, "po-2026-2001", 20, true)
            5 -> scheduleAndReleaseProduction(effRole, "MO-2026-2001", "prod-nord-200", "wc-cnc", 20, "mfg-2026-2001")
            6 -> transferStock(effRole, "prod-nord-200", "DC-MALMO", "STORE-OSLO", 8, "demo-step-6-trf")
            7, 8 -> placeOrderWithAtomicReservation(effRole, "ORD-2026-9901", "cust-101", "STORE-OSLO", "ONLINE_DELIVERY", "prod-nord-200", 1, true, "ord-9901", "demo-step-7-ord")
            9 -> scheduleDeliveryAndAssembly(effRole, "ord-9901", "DA-2026-9901", "del-9901")
            10 -> reportMissingFitting(effRole, "del-9901", "SP-118331")
            11 -> dispatchSparePartForTask(effRole, "del-9901", "sp-cam-m6")
            12 -> completeDeliveryAndAssembly(effRole, "del-9901")
            13 -> processReturnToResale(effRole, "ret-008", 54900L)
            14 -> reconcileFinanceJournal(effRole, "JE-2026-DEMO", "ORD-2026-9901", 40300L)
            else -> Result.failure(IllegalArgumentException("Unknown step $stepNumber"))
        }
        if (msg.isSuccess) {
            val stepsToMark = if (stepNumber == 7 || stepNumber == 8) listOf(7, 8) else listOf(stepNumber)
            val updates = stepsToMark.map { s ->
                val def = DemoSeedData.demoStepDefinitions.first { it.stepNumber == s }
                DemoStepProgressEntity(s, true, def.entityRef, System.currentTimeMillis())
            }
            dao.insertDemoProgress(updates)
        }
        return msg
    }
}
