package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.domain.model.MoneyFormat
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.EnterpriseUiState

@Composable
fun SuppliersScreen(
    state: EnterpriseUiState,
    onBack: () -> Unit,
    onCreatePo: (String, String, String, String, Int, Long) -> Unit,
    onReceivePo: (String, Int, Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)
    var showNewPo by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(WarmGreyBg),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionHeader(
                title = "Suppliers & Procurement",
                subtitle = "Qualification, POs, origin declarations vs verified evidence, and concentration risk",
                trailing = {
                    NordicPrimaryButton(
                        text = "+ Issue PO",
                        onClick = { showNewPo = true },
                        modifier = Modifier.testTag("issue_po_button")
                    )
                }
            )
        }

        items(state.suppliers, key = { it.id }) { sup ->
            val evidence = state.materialEvidence.filter { it.supplierId == sup.id }
            EnterpriseCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "${sup.code} · ${sup.name}", style = MaterialTheme.typography.titleMedium)
                        Text(text = "${sup.region} · Factory ${sup.factoryId}", style = MaterialTheme.typography.bodySmall, color = InkSecondary)
                    }
                    StatusBadge(
                        text = sup.qualificationStatus,
                        tone = if (sup.qualificationStatus == "QUALIFIED") BadgeTone.VERIFIED else BadgeTone.WARNING
                    )
                }
                Text(
                    text = "Lead ${sup.leadTimeDays}d · MOQ ${sup.moqUnits} · On-Time ${sup.onTimeRatePct}% · Defect ${sup.defectRatePct}%",
                    style = MonoDataStyle,
                    color = InkBlack
                )
                Text(
                    text = "Concentration Risk: ${sup.concentrationRiskNote}",
                    style = MaterialTheme.typography.bodySmall,
                    color = WarningAmber
                )
                evidence.forEach { ev ->
                    val isVerified = ev.evidenceType == "INDEPENDENTLY_VERIFIED"
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(WarmGreyBg, RoundedCornerShape(4.dp))
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = "${ev.materialName} (${ev.issuer})", style = MaterialTheme.typography.titleSmall)
                            Text(
                                text = "${ev.scope} · Valid ${ev.issuedDate} to ${ev.expiryDate} · ${ev.boundaryNote}",
                                style = MaterialTheme.typography.bodySmall,
                                color = InkSecondary
                            )
                        }
                        StatusBadge(
                            text = if (isVerified) "VERIFIED AUDIT" else "SUPPLIER DECL.",
                            tone = if (isVerified) BadgeTone.VERIFIED else BadgeTone.WARNING
                        )
                    }
                }
            }
        }

        item {
            Text(text = "Purchase Orders & Dock Receipts", style = MaterialTheme.typography.titleLarge)
        }

        items(state.purchaseOrders, key = { it.id }) { po ->
            EnterpriseCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "${po.poNumber} · ${po.componentCode}", style = MonoDataStyle, color = DeepNordicBlue)
                        Text(text = po.componentName, style = MaterialTheme.typography.titleSmall)
                    }
                    StatusBadge(
                        text = po.status,
                        tone = when (po.status) {
                            "RECEIVED_INSPECTED" -> BadgeTone.VERIFIED
                            "QUALITY_HOLD" -> BadgeTone.EXCEPTION
                            else -> BadgeTone.INFO
                        }
                    )
                }
                Text(
                    text = "Received: ${po.qtyReceived}/${po.qtyOrdered} · Unit ${MoneyFormat.formatEur(po.unitCostCents)} · 3-Way Match: ${if (po.invoiceMatched) "MATCHED" else "PENDING"}",
                    style = MaterialTheme.typography.bodySmall
                )
                Text(text = po.qualityNote, style = MaterialTheme.typography.bodySmall, color = InkSecondary)
                if (po.qtyReceived < po.qtyOrdered) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        NordicPrimaryButton(
                            text = "Receive & Pass AQL",
                            onClick = { onReceivePo(po.id, po.qtyOrdered - po.qtyReceived, true) },
                            modifier = Modifier.weight(1f)
                        )
                        NordicOutlineButton(
                            text = "Flag Quality Hold",
                            onClick = { onReceivePo(po.id, 10, false) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }

    if (showNewPo) {
        var poNum by remember { mutableStateOf("PO-2026-${(2100..2999).random()}") }
        var qtyText by remember { mutableStateOf("40") }
        AlertDialog(
            onDismissRequest = { showNewPo = false },
            title = { Text("Issue Purchase Order") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = poNum, onValueChange = { poNum = it }, label = { Text("PO Number") })
                    OutlinedTextField(value = qtyText, onValueChange = { qtyText = it }, label = { Text("Quantity (units)") })
                }
            },
            confirmButton = {
                NordicPrimaryButton(
                    text = "Issue PO",
                    onClick = {
                        onCreatePo(poNum, "sup-baltic", "CMP-BIRCH-PANEL", "Pre-drilled Birch Panels", qtyText.toIntOrNull() ?: 40, 4200L)
                        showNewPo = false
                    }
                )
            },
            dismissButton = { TextButton(onClick = { showNewPo = false }) { Text("Cancel") } }
        )
    }
}

@Composable
fun ManufacturingScreen(
    state: EnterpriseUiState,
    onBack: () -> Unit,
    onScheduleAndRelease: (String, String, String, Int) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(WarmGreyBg),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionHeader(
                title = "Manufacturing & Work Centre Capacity",
                subtitle = "Versioned BOMs, routing bottlenecks, scrap/rework, and quality package release",
                trailing = {
                    val targetProd = state.products.firstOrNull()
                    if (targetProd != null) {
                        NordicPrimaryButton(
                            text = "+ Release 10 Sets",
                            onClick = {
                                onScheduleAndRelease(
                                    "MO-2026-${(600..999).random()}",
                                    targetProd.id,
                                    "wc-cnc",
                                    10
                                )
                            },
                            modifier = Modifier.testTag("release_mfg_button")
                        )
                    }
                }
            )
        }

        item {
            EnterpriseCard {
                Text(text = "Work Centres & Bottleneck Telemetry (PLANT-ALM-01)", style = MaterialTheme.typography.titleMedium)
                state.workCentres.forEach { wc ->
                    val ratio = (wc.bookedHours / wc.capacityHoursPerDay).toFloat().coerceIn(0f, 1.2f)
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "${wc.code} · ${wc.name}", style = MaterialTheme.typography.titleSmall)
                            StatusBadge(
                                text = "${wc.bookedHours}h / ${wc.capacityHoursPerDay}h",
                                tone = if (wc.bottleneckFlag || ratio > 0.95f) BadgeTone.EXCEPTION else BadgeTone.VERIFIED
                            )
                        }
                        LinearProgressIndicator(
                            progress = { ratio.coerceAtMost(1f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = if (wc.bottleneckFlag || ratio > 0.95f) ExceptionRed else NordicBlue,
                            trackColor = SurfaceMuted
                        )
                    }
                }
                val firstProd = state.products.firstOrNull()
                if (firstProd != null) {
                    NordicOutlineButton(
                        text = "Test Capacity Overflow (100 sets on Bottleneck)",
                        onClick = {
                            onScheduleAndRelease(
                                "MO-OVER-${(10..99).random()}",
                                firstProd.id,
                                "wc-edge",
                                100
                            )
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        items(state.productionOrders, key = { it.id }) { mo ->
            val isError = mo.status == "SHORTAGE_BLOCKED" || mo.status == "INFEASIBLE_CAPACITY"
            EnterpriseCard(borderColor = if (isError) ExceptionRed.copy(alpha = 0.5f) else BorderHairline) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "${mo.orderNumber} · ${mo.revisionTag}", style = MonoDataStyle, color = DeepNordicBlue)
                    StatusBadge(
                        text = mo.status,
                        tone = when {
                            isError -> BadgeTone.EXCEPTION
                            mo.status == "QUALITY_RELEASED" -> BadgeTone.VERIFIED
                            else -> BadgeTone.INFO
                        }
                    )
                }
                Text(
                    text = "Target: ${mo.targetQty} sets · Released Boxes: ${mo.completedPackages} · Scrap: ${mo.scrapQty} · Rework: ${mo.reworkQty}",
                    style = MaterialTheme.typography.bodyMedium
                )
                Text(text = "Routing: ${mo.routingNotes}", style = MaterialTheme.typography.bodySmall, color = InkSecondary)
                Text(
                    text = mo.materialShortageNote,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (isError) ExceptionRed else VerifiedGreen
                )
            }
        }
    }
}
