package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.EnterpriseUiState

@Composable
fun InventoryScreen(
    state: EnterpriseUiState,
    onBack: () -> Unit,
    onSelectSite: (String) -> Unit,
    onTransferStock: (String, String, String, Int) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)
    val sites = listOf("DC-MALMO", "STORE-OSLO", "STORE-STOCKHOLM")
    val siteAvail = state.completeAvailability.filter { it.siteId == state.activeSite }
    val siteInventory = state.inventory.filter { it.siteId == state.activeSite }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(WarmGreyBg),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionHeader(
                title = "Inventory & Immutable Ledger",
                subtitle = "Side-by-side Package vs Complete-Product availability across sites & zones"
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                sites.forEach { s ->
                    FilterChip(
                        selected = state.activeSite == s,
                        onClick = { onSelectSite(s) },
                        label = { Text(s, style = MaterialTheme.typography.labelMedium) }
                    )
                }
            }
        }

        item {
            EnterpriseCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Complete-Set Availability (${state.activeSite})",
                        style = MaterialTheme.typography.titleMedium
                    )
                    val transferProd = state.products.firstOrNull { it.code == "FJELL-120" }
                    if (transferProd != null && state.activeSite == "STORE-OSLO") {
                        NordicPrimaryButton(
                            text = "Transfer 2 FJELL DC->Oslo",
                            onClick = { onTransferStock(transferProd.id, "DC-MALMO", "STORE-OSLO", 2) },
                            modifier = Modifier.testTag("transfer_stock_button")
                        )
                    }
                }
                siteAvail.forEach { ca ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, BorderHairline, RoundedCornerShape(4.dp))
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = "${ca.productCode} · ${ca.productName}", style = MaterialTheme.typography.titleSmall)
                            Text(
                                text = ca.packageBreakdown.joinToString(" | ") { "${it.packageCode.substringAfterLast("-")}: ${it.available} avail" },
                                style = MonoDataStyle,
                                color = InkSecondary
                            )
                        }
                        StatusBadge(
                            text = "${ca.completeSetsAvailable} SELLABLE",
                            tone = if (ca.completeSetsAvailable > 0) BadgeTone.VERIFIED else BadgeTone.EXCEPTION
                        )
                    }
                }
            }
        }

        item {
            Text(text = "Zone Positions & 7 Separated Stock Buckets", style = MaterialTheme.typography.titleLarge)
        }

        items(siteInventory, key = { it.id }) { pos ->
            val pkg = state.packages.firstOrNull { it.id == pos.packageId }
            EnterpriseCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "${pkg?.packageCode ?: pos.packageId} · ${pos.zone}", style = MonoDataStyle, color = DeepNordicBlue)
                        Text(text = "Location: ${pos.aisleBin} (v${pos.version})", style = MaterialTheme.typography.bodySmall, color = InkSecondary)
                    }
                    StatusBadge(
                        text = "${pos.available} AVAIL",
                        tone = if (pos.available > 0) BadgeTone.VERIFIED else BadgeTone.EXCEPTION
                    )
                }
                Text(
                    text = "OnHand: ${pos.onHand} | Reserved: ${pos.reserved} | Avail: ${pos.available} | InTransit: ${pos.inTransit} | Quarantine: ${pos.quarantined} | Damaged: ${pos.damaged} | Display: ${pos.displayStock}",
                    style = MonoDataStyle,
                    color = InkBlack
                )
            }
        }

        item {
            EnterpriseCard {
                Text(text = "Immutable Stock-Movement Ledger (Latest)", style = MaterialTheme.typography.titleMedium)
                state.stockMovements.take(12).forEach { mov ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(WarmGreyBg, RoundedCornerShape(4.dp))
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = "${mov.movementType} · ${mov.siteId} (${mov.zone})", style = MaterialTheme.typography.titleSmall)
                            Text(text = "${mov.note} · Key ${mov.idempotencyKey}", style = MaterialTheme.typography.bodySmall, color = InkSecondary)
                        }
                        Text(
                            text = if (mov.qtyDelta >= 0) "+${mov.qtyDelta}" else "${mov.qtyDelta}",
                            style = MonoDataStyle,
                            color = if (mov.qtyDelta >= 0) VerifiedGreen else ExceptionRed
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DistributionScreen(
    state: EnterpriseUiState,
    onBack: () -> Unit,
    onUpgradeVehicle: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(WarmGreyBg),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionHeader(
                title = "Distribution & Transport Planning",
                subtitle = "Geometric volume estimates vs validated physical loading plans & packaging efficiency"
            )
        }

        item {
            EnterpriseCard {
                Text(text = "Packaging Efficiency Formula", style = MaterialTheme.typography.titleMedium)
                Text(
                    text = "Efficiency = Sum(Content Volume) / Sum(Outer Carton Volume) × 100%",
                    style = MonoDataStyle,
                    color = DeepNordicBlue
                )
                val totalContent = state.packages.sumOf { it.contentVolumeLiters }
                val totalOuter = state.packages.sumOf { it.outerVolumeLiters }
                val pct = if (totalOuter > 0) ((totalContent / totalOuter) * 1000).toInt() / 10.0 else 0.0
                Text(
                    text = "Catalog Flat-Pack Ratio: ${totalContent.toInt()}L / ${totalOuter.toInt()}L = $pct% volumetric utilization",
                    style = MaterialTheme.typography.bodySmall,
                    color = InkSecondary
                )
            }
        }

        items(state.shipments, key = { it.id }) { shp ->
            EnterpriseCard(
                borderColor = if (shp.loadFeasible) BorderHairline else ExceptionRed.copy(alpha = 0.55f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "${shp.shipmentNumber} · ${shp.originSiteId} -> ${shp.destSiteId}", style = MonoDataStyle, color = DeepNordicBlue)
                        Text(text = "${shp.vehicleId} · ${shp.carrierName}", style = MaterialTheme.typography.titleSmall)
                    }
                    StatusBadge(
                        text = if (shp.loadFeasible) shp.status else "INFEASIBLE LOAD",
                        tone = if (shp.loadFeasible) BadgeTone.VERIFIED else BadgeTone.EXCEPTION
                    )
                }

                // Separate Geometric Estimate vs Validated Physical Plan
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .background(WarmGreyBg, RoundedCornerShape(4.dp))
                            .padding(8.dp)
                    ) {
                        Text(text = "GEOMETRIC ESTIMATE", style = MaterialTheme.typography.labelMedium, color = InkSecondary)
                        Text(text = "${shp.geometricEstimateVolM3} m³", style = MonoDataStyle)
                    }
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .background(if (shp.loadFeasible) VerifiedGreenBg else ExceptionRedBg, RoundedCornerShape(4.dp))
                            .padding(8.dp)
                    ) {
                        Text(text = "VALIDATED PHYSICAL LOAD", style = MaterialTheme.typography.labelMedium, color = InkSecondary)
                        Text(
                            text = "${shp.validatedLoadVolM3} m³ / ${shp.validatedLoadWeightKg.toInt()} kg",
                            style = MonoDataStyle,
                            color = if (shp.loadFeasible) VerifiedGreen else ExceptionRed
                        )
                    }
                }

                Text(
                    text = "Vehicle Limits: ${shp.vehicleMaxWeightKg.toInt()} kg · ${shp.vehicleMaxVolM3} m³ · Window: ${shp.deliveryWindow} · Pack Eff: ${shp.packagingEfficiencyPct}%",
                    style = MaterialTheme.typography.bodySmall,
                    color = InkSecondary
                )
                Text(
                    text = if (shp.loadFeasible) shp.proofOfReceiptNote else shp.infeasibilityReason,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (shp.loadFeasible) InkSecondary else ExceptionRed
                )

                if (!shp.loadFeasible) {
                    NordicPrimaryButton(
                        text = "Reassign to 18t Rigid Truck (Resolve Infeasible)",
                        onClick = { onUpgradeVehicle(shp.id) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}
