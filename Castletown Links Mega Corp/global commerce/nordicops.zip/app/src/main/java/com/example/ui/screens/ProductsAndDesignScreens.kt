package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.domain.model.MoneyFormat
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.EnterpriseUiState

@Composable
fun ProductsScreen(
    state: EnterpriseUiState,
    onBack: () -> Unit,
    onCreateTwoPackageProduct: (String, String, String, Long) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)
    var showCreateDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(WarmGreyBg),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionHeader(
                title = "Product Information & Flat-Pack Sets",
                subtitle = "Sellable availability equals complete required package sets at ${state.activeSite}",
                trailing = {
                    NordicPrimaryButton(
                        text = "+ 2-Box Product",
                        onClick = { showCreateDialog = true },
                        modifier = Modifier.testTag("create_product_button")
                    )
                }
            )
        }

        items(state.products, key = { it.id }) { prod ->
            val pkgs = state.packages.filter { it.productId == prod.id }
            val avail = state.completeAvailability.firstOrNull {
                it.productId == prod.id && it.siteId == state.activeSite
            }
            val drawableId = when (prod.imageKey) {
                "sofa" -> R.drawable.img_sofa_skagen
                "desk" -> R.drawable.img_desk_alvar
                else -> R.drawable.img_wardrobe_fjell
            }

            EnterpriseCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Image(
                        painter = painterResource(id = drawableId),
                        contentDescription = prod.name,
                        modifier = Modifier
                            .size(96.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .border(1.dp, BorderHairline, RoundedCornerShape(4.dp)),
                        contentScale = ContentScale.Crop
                    )
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = prod.code, style = MonoDataStyle, color = DeepNordicBlue)
                            StatusBadge(text = prod.activeRevision, tone = BadgeTone.INFO)
                        }
                        Text(text = prod.name, style = MaterialTheme.typography.titleMedium, color = InkBlack)
                        Text(text = "${prod.variantName} · ${prod.dimensionsCm}", style = MaterialTheme.typography.bodySmall, color = InkSecondary)
                        Text(text = prod.materials, style = MaterialTheme.typography.bodySmall, color = InkSecondary)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = MoneyFormat.formatEur(prod.sellingPriceCents),
                                style = MaterialTheme.typography.titleMedium,
                                color = InkBlack
                            )
                            Text(
                                text = "${pkgs.size} logistics packages",
                                style = MaterialTheme.typography.labelMedium,
                                color = NordicBlue
                            )
                        }
                    }
                }

                if (avail != null) {
                    FlatPackDiagramCanvas(availability = avail)
                }

                pkgs.forEach { pkg ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(WarmGreyBg, RoundedCornerShape(4.dp))
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${pkg.packageCode} (${pkg.packageIndex}/${pkg.totalPackages}) · ${pkg.weightKg}kg · ${pkg.dimsCm}",
                                style = MonoDataStyle,
                                color = InkBlack
                            )
                            Text(
                                text = "${pkg.contentsSummary} | EAN ${pkg.barcode}",
                                style = MaterialTheme.typography.bodySmall,
                                color = InkSecondary
                            )
                        }
                        StatusBadge(text = pkg.compatibleRevision, tone = BadgeTone.NEUTRAL)
                    }
                }
            }
        }

        item {
            EnterpriseCard {
                Text(text = "Spare Parts Catalogue (Distinct from Sellable Sets)", style = MaterialTheme.typography.titleMedium)
                state.spareParts.forEach { sp ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, BorderHairline, RoundedCornerShape(4.dp))
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = "${sp.partNumber} · ${sp.name}", style = MaterialTheme.typography.titleSmall)
                            Text(text = sp.hardwareSpec, style = MaterialTheme.typography.bodySmall, color = InkSecondary)
                        }
                        StatusBadge(
                            text = "${sp.stockOnHand} on hand",
                            tone = if (sp.stockOnHand > 20) BadgeTone.VERIFIED else BadgeTone.WARNING
                        )
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        var code by remember { mutableStateOf("KRON-180") }
        var name by remember { mutableStateOf("KRON Birch Cabinet") }
        var variant by remember { mutableStateOf("Natural Birch / White") }
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("Create Two-Package Product") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = code, onValueChange = { code = it }, label = { Text("Product Code") }, singleLine = true)
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Product Name") }, singleLine = true)
                    OutlinedTextField(value = variant, onValueChange = { variant = it }, label = { Text("Variant & Finish") }, singleLine = true)
                }
            },
            confirmButton = {
                NordicPrimaryButton(
                    text = "Create 2-Box Set",
                    onClick = {
                        onCreateTwoPackageProduct(code.trim().uppercase(), name.trim(), variant.trim(), 31900L)
                        showCreateDialog = false
                    }
                )
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
fun DesignScreen(
    state: EnterpriseUiState,
    onBack: () -> Unit,
    onAdvanceStage: (String, String, Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)
    val stages = listOf("Concept", "Design Review", "Prototype", "Testing", "Approved", "Released", "Retired")

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(WarmGreyBg),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionHeader(
                title = "Product Development & Change Control",
                subtitle = "Concept -> Design Review -> Prototype -> Testing -> Approved -> Released -> Retired"
            )
        }

        items(state.designChanges, key = { it.id }) { chg ->
            var safetyChecked by remember(chg.id, chg.safetyChecklistReviewed) {
                mutableStateOf(chg.safetyChecklistReviewed)
            }
            val nextStage = when (chg.stage) {
                "Concept" -> "Design Review"
                "Design Review" -> "Prototype"
                "Prototype" -> "Testing"
                "Testing" -> "Approved"
                "Approved" -> "Released"
                "Released" -> "Retired"
                else -> null
            }

            EnterpriseCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "${chg.productId.uppercase()} · ${chg.revisionTag}", style = MonoDataStyle, color = DeepNordicBlue)
                        Text(text = "Stage: ${chg.stage} (v${chg.version})", style = MaterialTheme.typography.titleMedium)
                    }
                    StatusBadge(
                        text = chg.stage.uppercase(),
                        tone = when (chg.stage) {
                            "Released" -> BadgeTone.VERIFIED
                            "Testing", "Prototype" -> BadgeTone.WARNING
                            else -> BadgeTone.INFO
                        }
                    )
                }

                // 7-stage progress pills
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    val activeIdx = stages.indexOf(chg.stage)
                    stages.forEachIndexed { idx, s ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(6.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(
                                    when {
                                        idx < activeIdx -> VerifiedGreen
                                        idx == activeIdx -> NordicBlue
                                        else -> SurfaceMuted
                                    }
                                )
                        )
                    }
                }

                Text(text = chg.designBrief, style = MaterialTheme.typography.bodyMedium, color = InkBlack)
                Text(text = "Target Cost: ${MoneyFormat.formatEur(chg.targetCostCents)} · Inst: ${chg.instructionVersion}", style = MonoDataStyle, color = InkSecondary)
                Text(text = "BOM: ${chg.bomSummary}", style = MaterialTheme.typography.bodySmall, color = InkSecondary)
                Text(text = "Prototype & Test: ${chg.prototypeNote} | ${chg.testResultNote}", style = MaterialTheme.typography.bodySmall, color = InkSecondary)
                Text(text = "Packaging Proposal: ${chg.packagingProposal}", style = MaterialTheme.typography.bodySmall, color = InkSecondary)

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(WarmGreyBg, RoundedCornerShape(4.dp))
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = safetyChecked,
                        onCheckedChange = { safetyChecked = it },
                        enabled = chg.stage != "Released"
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Product-Safety Acceptance Criteria Reviewed",
                            style = MaterialTheme.typography.titleSmall
                        )
                        Text(
                            text = "Note: Checklist review does NOT imply regulatory certification or substitute for accredited testing.",
                            style = MaterialTheme.typography.bodySmall,
                            color = InkSecondary
                        )
                    }
                }

                if (chg.stage == "Released") {
                    Text(
                        text = "RELEASED LOCK: Silent component replacement is blocked. Open a new revision to modify BOM.",
                        style = MaterialTheme.typography.bodySmall,
                        color = DeepNordicBlue
                    )
                }

                if (nextStage != null) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        NordicPrimaryButton(
                            text = "Advance -> $nextStage",
                            onClick = { onAdvanceStage(chg.id, nextStage, safetyChecked) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}
