package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.withTransaction

@Database(
    entities = [
        ProductFamilyEntity::class,
        PackageSpecEntity::class,
        SparePartEntity::class,
        DesignChangeEntity::class,
        SupplierEntity::class,
        MaterialEvidenceEntity::class,
        PurchaseOrderEntity::class,
        WorkCentreEntity::class,
        ProductionOrderEntity::class,
        InventoryPositionEntity::class,
        StockMovementEntity::class,
        DistributionShipmentEntity::class,
        StoreTaskEntity::class,
        CustomerEntity::class,
        SalesOrderEntity::class,
        DeliveryAssemblyTaskEntity::class,
        ReturnCaseEntity::class,
        JournalEntryEntity::class,
        JournalLineEntity::class,
        SustainabilityMetricEntity::class,
        WorkforceShiftEntity::class,
        AuditOutboxEntity::class,
        DemoStepProgressEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class NordicOpsDatabase : RoomDatabase() {
    abstract fun dao(): NordicOpsDao

    suspend fun ensureSeeded() {
        val d = dao()
        if (d.countProducts() == 0) {
            seedAllInternal(d)
        }
    }

    suspend fun resetToSeedData() {
        val d = dao()
        withTransaction {
            d.clearAllTablesForReset()
            seedAllInternal(d)
        }
    }

    private suspend fun seedAllInternal(d: NordicOpsDao) {
        d.insertProducts(DemoSeedData.initialProducts)
        d.insertPackages(DemoSeedData.initialPackages)
        d.insertSpareParts(DemoSeedData.initialSpareParts)
        d.insertDesignChanges(DemoSeedData.initialDesignChanges)
        d.insertSuppliers(DemoSeedData.initialSuppliers)
        d.insertMaterialEvidence(DemoSeedData.initialMaterialEvidence)
        d.insertPurchaseOrders(DemoSeedData.initialPurchaseOrders)
        d.insertWorkCentres(DemoSeedData.initialWorkCentres)
        d.insertProductionOrders(DemoSeedData.initialProductionOrders)
        d.insertInventoryPositions(DemoSeedData.initialInventory)
        d.insertStockMovementsSeed(DemoSeedData.initialMovements)
        d.insertShipments(DemoSeedData.initialShipments)
        d.insertStoreTasks(DemoSeedData.initialStoreTasks)
        d.insertCustomers(DemoSeedData.initialCustomers)
        d.insertSalesOrders(DemoSeedData.initialOrders)
        d.insertDeliveryTasks(DemoSeedData.initialDeliveryTasks)
        d.insertReturnCases(DemoSeedData.initialReturnCases)
        d.insertJournalEntries(DemoSeedData.initialJournalEntries)
        d.insertJournalLines(DemoSeedData.initialJournalLines)
        d.insertSustainabilityMetrics(DemoSeedData.initialSustainability)
        d.insertWorkforceShifts(DemoSeedData.initialWorkforce)
        d.insertAuditOutboxList(DemoSeedData.initialAuditOutbox)
        d.insertDemoProgress(DemoSeedData.initialDemoProgress)
    }

    companion object {
        @Volatile
        private var INSTANCE: NordicOpsDatabase? = null

        fun getInstance(context: Context): NordicOpsDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    NordicOpsDatabase::class.java,
                    "nordic_ops_enterprise.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
