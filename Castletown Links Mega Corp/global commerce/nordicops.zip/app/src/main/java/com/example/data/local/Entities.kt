package com.example.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "product_families")
data class ProductFamilyEntity(
    @PrimaryKey val id: String,
    val code: String,
    val name: String,
    val family: String,
    val variantName: String,
    val dimensionsCm: String,
    val finish: String,
    val materials: String,
    val regionAssortment: String,
    val sellingPriceCents: Long,
    val activeRevision: String,
    val imageKey: String,
    val version: Int = 1
)

@Entity(
    tableName = "package_specs",
    indices = [Index("productId")]
)
data class PackageSpecEntity(
    @PrimaryKey val id: String,
    val productId: String,
    val packageCode: String,
    val packageIndex: Int,
    val totalPackages: Int,
    val weightKg: Double,
    val dimsCm: String,
    val outerVolumeLiters: Double,
    val contentVolumeLiters: Double,
    val contentsSummary: String,
    val barcode: String,
    val handlingReq: String,
    val compatibleRevision: String,
    val requiredQtyPerProduct: Int = 1
)

@Entity(tableName = "spare_parts")
data class SparePartEntity(
    @PrimaryKey val id: String,
    val partNumber: String,
    val name: String,
    val productId: String,
    val hardwareSpec: String,
    val stockOnHand: Int,
    val unitCostCents: Long
)

@Entity(tableName = "design_changes")
data class DesignChangeEntity(
    @PrimaryKey val id: String,
    val productId: String,
    val revisionTag: String,
    val stage: String, // Concept, Design Review, Prototype, Testing, Approved, Released, Retired
    val designBrief: String,
    val targetCostCents: Long,
    val bomSummary: String,
    val prototypeNote: String,
    val testResultNote: String,
    val packagingProposal: String,
    val instructionVersion: String,
    val safetyChecklistReviewed: Boolean,
    val safetyReviewerNote: String,
    val approvedByRole: String?,
    val version: Int = 1,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "suppliers")
data class SupplierEntity(
    @PrimaryKey val id: String,
    val code: String,
    val name: String,
    val region: String,
    val factoryId: String,
    val qualificationStatus: String,
    val leadTimeDays: Int,
    val moqUnits: Int,
    val onTimeRatePct: Double,
    val defectRatePct: Double,
    val concentrationRiskNote: String
)

@Entity(tableName = "material_evidence")
data class MaterialEvidenceEntity(
    @PrimaryKey val id: String,
    val supplierId: String,
    val materialName: String,
    val evidenceType: String, // SUPPLIER_DECLARATION or INDEPENDENTLY_VERIFIED
    val issuer: String,
    val scope: String,
    val issuedDate: String,
    val expiryDate: String,
    val boundaryNote: String
)

@Entity(tableName = "purchase_orders")
data class PurchaseOrderEntity(
    @PrimaryKey val id: String,
    val poNumber: String,
    val supplierId: String,
    val componentCode: String,
    val componentName: String,
    val qtyOrdered: Int,
    val qtyReceived: Int,
    val unitCostCents: Long,
    val status: String, // DRAFT, ORDERED, PARTIAL_RECEIVED, RECEIVED_INSPECTED, QUALITY_HOLD
    val leadTimeDays: Int,
    val invoiceMatched: Boolean,
    val qualityNote: String,
    val version: Int = 1
)

@Entity(tableName = "work_centres")
data class WorkCentreEntity(
    @PrimaryKey val id: String,
    val code: String,
    val name: String,
    val siteId: String,
    val capacityHoursPerDay: Double,
    val bookedHours: Double,
    val bottleneckFlag: Boolean
)

@Entity(tableName = "production_orders")
data class ProductionOrderEntity(
    @PrimaryKey val id: String,
    val orderNumber: String,
    val productId: String,
    val revisionTag: String,
    val workCentreId: String,
    val targetQty: Int,
    val completedPackages: Int,
    val scrapQty: Int,
    val reworkQty: Int,
    val status: String, // PLANNED, IN_PROGRESS, SHORTAGE_BLOCKED, INFEASIBLE_CAPACITY, QUALITY_RELEASED
    val routingNotes: String,
    val materialShortageNote: String,
    val labourHoursBooked: Double,
    val version: Int = 1
)

@Entity(
    tableName = "inventory_positions",
    indices = [Index(value = ["packageId", "siteId", "zone"], unique = true)]
)
data class InventoryPositionEntity(
    @PrimaryKey val id: String,
    val packageId: String,
    val siteId: String,
    val zone: String, // BACKROOM, SELF_SERVICE_AISLE, COLLECTION_AREA, RETURNS_AREA, QUARANTINE
    val aisleBin: String,
    val onHand: Int,
    val reserved: Int,
    val inTransit: Int,
    val quarantined: Int,
    val damaged: Int,
    val displayStock: Int,
    val version: Int = 1
) {
    val available: Int get() = (onHand - reserved).coerceAtLeast(0)
}

@Entity(
    tableName = "stock_movements",
    indices = [Index(value = ["idempotencyKey"], unique = true)]
)
data class StockMovementEntity(
    @PrimaryKey val id: String,
    val idempotencyKey: String,
    val packageId: String,
    val siteId: String,
    val zone: String,
    val movementType: String, // RECEIPT, PRODUCTION_RELEASE, TRANSFER_OUT, TRANSFER_IN, RESERVE, PICK, RETURN_QUARANTINE, RESALE_RELEASE, ADJUSTMENT
    val qtyDelta: Int,
    val bucket: String,
    val referenceId: String,
    val actorRole: String,
    val note: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "distribution_shipments")
data class DistributionShipmentEntity(
    @PrimaryKey val id: String,
    val shipmentNumber: String,
    val originSiteId: String,
    val destSiteId: String,
    val vehicleId: String,
    val vehicleMaxWeightKg: Double,
    val vehicleMaxVolM3: Double,
    val geometricEstimateVolM3: Double,
    val validatedLoadWeightKg: Double,
    val validatedLoadVolM3: Double,
    val packagingEfficiencyPct: Double,
    val loadFeasible: Boolean,
    val infeasibilityReason: String,
    val status: String, // PLANNED, IN_TRANSIT, RECEIVED, FAILED_DELIVERY
    val carrierName: String,
    val deliveryWindow: String,
    val proofOfReceiptNote: String,
    val version: Int = 1
)

@Entity(tableName = "store_tasks")
data class StoreTaskEntity(
    @PrimaryKey val id: String,
    val siteId: String,
    val category: String, // REPLENISHMENT, FLOOR_DISPLAY, CLICK_COLLECT, MAINTENANCE, ENQUIRY
    val title: String,
    val assigneeRole: String,
    val status: String,
    val aisleBin: String
)

@Entity(tableName = "customers")
data class CustomerEntity(
    @PrimaryKey val id: String,
    val code: String,
    val fullName: String,
    val maskedName: String,
    val region: String,
    val deliveryAreaCode: String,
    val protectedAddress: String,
    val serviceCasesCount: Int
)

@Entity(
    tableName = "sales_orders",
    indices = [Index(value = ["idempotencyKey"], unique = true)]
)
data class SalesOrderEntity(
    @PrimaryKey val id: String,
    val orderNumber: String,
    val customerId: String,
    val siteId: String,
    val channel: String, // ONLINE_DELIVERY, CLICK_AND_COLLECT, IN_STORE
    val productId: String,
    val qty: Int,
    val assemblyAddon: Boolean,
    val orderState: String, // CREATED, CONFIRMED, AMENDED, CANCELLED
    val paymentState: String, // PENDING, AUTHORIZED, CAPTURED_SIMULATED, PARTIAL_REFUNDED
    val fulfilmentState: String, // UNALLOCATED, RESERVED_COMPLETE_SET, PARTIALLY_PICKED, FULFILLED
    val deliveryState: String, // NOT_SCHEDULED, SCHEDULED, PARTIALLY_DELIVERED, DELIVERED, FAILED
    val assemblyState: String, // NOT_REQUIRED, SCHEDULED, BLOCKED_MISSING_PART, COMPLETED
    val totalCents: Long,
    val deliveryChargeCents: Long,
    val assemblyChargeCents: Long,
    val instructionVersion: String,
    val idempotencyKey: String,
    val version: Int = 1,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "delivery_assembly_tasks")
data class DeliveryAssemblyTaskEntity(
    @PrimaryKey val id: String,
    val taskNumber: String,
    val orderId: String,
    val crewName: String,
    val vehicleCode: String,
    val requiredSkill: String,
    val estimatedMinutes: Int,
    val packageReadiness: String, // READY, PARTIAL, BLOCKED
    val deliveredPackages: Int,
    val totalPackages: Int,
    val deliveryCompleted: Boolean,
    val assemblyCompleted: Boolean,
    val missingFittingCode: String?,
    val sparePartDispatched: Boolean,
    val customerAccepted: Boolean,
    val providerAccessWindow: String,
    val version: Int = 1
)

@Entity(tableName = "return_cases")
data class ReturnCaseEntity(
    @PrimaryKey val id: String,
    val rmaNumber: String,
    val orderId: String,
    val productId: String,
    val packageCheckNote: String,
    val conditionGrade: String, // UNINSPECTED, GRADE_A_LIKE_NEW, GRADE_B_REPACKED, SCRAP_RECYCLE
    val refundState: String, // PENDING_REVIEW, APPROVED, REFUNDED, REJECTED
    val physicalReceiptState: String, // EXPECTED, RECEIVED_QUARANTINE
    val stockDisposition: String, // QUARANTINE, REPAIR, RESALE_INSPECTED, RECYCLING
    val missingPartsNote: String,
    val resaleLotCode: String?,
    val resalePriceCents: Long,
    val inspectedByRole: String?,
    val approvedForResale: Boolean,
    val version: Int = 1
)

@Entity(tableName = "journal_entries")
data class JournalEntryEntity(
    @PrimaryKey val id: String,
    val entryNumber: String,
    val referenceType: String,
    val referenceId: String,
    val description: String,
    val totalDebitCents: Long,
    val totalCreditCents: Long,
    val currency: String = "EUR",
    val taxBps: Int = 2500,
    val createdByRole: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "journal_lines",
    indices = [Index("entryId")]
)
data class JournalLineEntity(
    @PrimaryKey val id: String,
    val entryId: String,
    val accountCode: String,
    val accountName: String,
    val debitCents: Long,
    val creditCents: Long
)

@Entity(tableName = "sustainability_metrics")
data class SustainabilityMetricEntity(
    @PrimaryKey val id: String,
    val productId: String,
    val category: String, // MEASURED_MATERIAL, MODELLED_EMISSIONS, SUPPLIER_STATEMENT, VERIFIED_CERTIFICATION
    val metricName: String,
    val valueText: String,
    val boundary: String,
    val factor: String,
    val evidenceDate: String,
    val verified: Boolean
)

@Entity(tableName = "workforce_shifts")
data class WorkforceShiftEntity(
    @PrimaryKey val id: String,
    val workerCode: String,
    val displayName: String,
    val role: String,
    val siteId: String,
    val shiftWindow: String,
    val trainingCert: String,
    val maintenanceTicket: String
)

@Entity(tableName = "audit_outbox")
data class AuditOutboxEntity(
    @PrimaryKey val id: String,
    val eventType: String,
    val entityType: String,
    val entityId: String,
    val actorRole: String,
    val idempotencyKey: String,
    val payloadSummary: String,
    val outboxStatus: String, // PENDING, DISPATCHED
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "demo_step_progress")
data class DemoStepProgressEntity(
    @PrimaryKey val stepNumber: Int,
    val completed: Boolean,
    val entityRef: String,
    val completedAt: Long = 0L
)
