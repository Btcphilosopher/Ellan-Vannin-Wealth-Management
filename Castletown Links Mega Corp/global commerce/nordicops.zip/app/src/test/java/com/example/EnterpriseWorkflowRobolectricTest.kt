package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.NordicOpsDatabase
import com.example.data.repository.EnterpriseRepository
import com.example.domain.model.CompleteProductAvailability
import com.example.domain.model.MoneyFormat
import com.example.domain.model.PackageAvailabilityItem
import com.example.domain.model.UserRole
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class EnterpriseWorkflowRobolectricTest {

    private lateinit var db: NordicOpsDatabase
    private lateinit var repo: EnterpriseRepository

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, NordicOpsDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repo = EnterpriseRepository(db)
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun multiPackageAvailability_oneBoxOfTwoBoxProduct_returnsZeroCompleteSets() {
        val avail = CompleteProductAvailability.compute(
            productId = "prod-skagen-3s",
            productCode = "SKAGEN-3S",
            productName = "SKAGEN Sofa",
            siteId = "STORE-OSLO",
            items = listOf(
                PackageAvailabilityItem("p1", "SKAGEN-BOX1", 1, 2, 1, 4, 0, 4, 0, 0, 0, 1),
                PackageAvailabilityItem("p2", "SKAGEN-BOX2", 2, 2, 1, 0, 0, 0, 4, 1, 0, 1)
            )
        )
        assertEquals(0, avail.completeSetsAvailable)
        assertTrue(avail.hasPackageMismatch)
        assertEquals("SKAGEN-BOX2", avail.limitingPackageCode)
    }

    @Test
    fun atomicOrderReservation_rejectsPartialPackageSet_and_reservesCompleteSet() = runTest {
        db.resetToSeedData()

        // SKAGEN-3S at STORE-OSLO has 4x BOX1 and 0x BOX2 -> must fail atomically
        val failRes = repo.placeOrderWithAtomicReservation(
            role = UserRole.HQ_ADMIN,
            orderNumber = "ORD-FAIL-1",
            customerId = "cust-101",
            siteId = "STORE-OSLO",
            channel = "ONLINE_DELIVERY",
            productId = "prod-skagen-3s",
            qty = 1,
            assemblyAddon = false
        )
        assertTrue(failRes.isFailure)

        // FJELL-120 at STORE-OSLO has complete sets -> must reserve both boxes atomically
        val okRes = repo.placeOrderWithAtomicReservation(
            role = UserRole.HQ_ADMIN,
            orderNumber = "ORD-OK-1",
            customerId = "cust-101",
            siteId = "STORE-OSLO",
            channel = "ONLINE_DELIVERY",
            productId = "prod-fjell-120",
            qty = 1,
            assemblyAddon = true
        )
        assertTrue(okRes.isSuccess)
    }

    @Test
    fun rbacAccessControl_blocksUnprivilegedActions_and_logsAudit() = runTest {
        db.resetToSeedData()

        val auditorAttempt = repo.reconcileFinanceJournal(
            role = UserRole.AUDITOR,
            entryNumber = "JE-BLOCKED",
            referenceId = "ORD-1",
            grossCents = 10000L
        )
        assertTrue(auditorAttempt.isFailure)

        val storeDesignAttempt = repo.advanceDesignStage(
            role = UserRole.STORE_ASSOCIATE,
            changeId = "chg-skagen-15",
            targetStage = "Released",
            safetyReviewed = true
        )
        assertTrue(storeDesignAttempt.isFailure)

        val audits = repo.auditOutbox.first()
        assertTrue(audits.any { it.eventType == "ACCESS_DENIED" })
    }

    @Test
    fun full14StepDemoJourney_completesWithBalancedDoubleEntryLedger() = runTest {
        db.resetToSeedData()

        for (step in 1..14) {
            val res = repo.executeDemoStep(step, UserRole.HQ_ADMIN)
            assertTrue("Step $step failed: ${res.exceptionOrNull()?.message}", res.isSuccess)
        }

        val lines = repo.journalLines.first()
        val totalDr = lines.sumOf { it.debitCents }
        val totalCr = lines.sumOf { it.creditCents }
        assertTrue(totalDr > 0L)
        assertEquals(totalDr, totalCr)

        val returns = repo.returnCases.first()
        assertTrue(returns.any { it.approvedForResale && it.resaleLotCode != null })

        val tasks = repo.deliveryTasks.first()
        assertTrue(tasks.any { it.id == "del-9901" && it.deliveryCompleted && it.assemblyCompleted && it.sparePartDispatched })

        // Verify half-even VAT rounding helper
        assertEquals(2500L, MoneyFormat.calculateVatHalfEven(10000L))
    }
}
