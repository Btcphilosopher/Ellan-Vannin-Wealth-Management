import React, { createContext, useContext, useState, ReactNode } from 'react';
import {
  Language,
  NavSection,
  Wallet,
  Institution,
  Merchant,
  Transaction,
  IssuanceBatch,
  SettlementQueueItem,
  ProgrammablePaymentRule,
  OfflineTxnBufferItem,
  RiskAlert,
  AuditEvent,
  SystemComponent,
  RegionalMetric,
  EconomicParams,
  PaymentMethod,
} from '../types';
import {
  INITIAL_INSTITUTIONS,
  INITIAL_WALLETS,
  INITIAL_MERCHANTS,
  INITIAL_TRANSACTIONS,
  INITIAL_ISSUANCE_BATCHES,
  INITIAL_SETTLEMENT_QUEUE,
  INITIAL_PROGRAMMABLE_RULES,
  INITIAL_RISK_ALERTS,
  INITIAL_AUDIT_EVENTS,
  INITIAL_SYSTEM_COMPONENTS,
  INITIAL_REGIONAL_METRICS,
} from '../data/seedData';
import { formatTimestampIST } from '../utils/formatters';

interface SimulationContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  currentSection: NavSection;
  activeSection: NavSection;
  setNavSection: (sec: NavSection) => void;

  institutions: Institution[];
  wallets: Wallet[];
  merchants: Merchant[];
  transactions: Transaction[];
  issuanceBatches: IssuanceBatch[];
  settlementQueue: SettlementQueueItem[];
  programmableRules: ProgrammablePaymentRule[];
  programmableContracts: ProgrammablePaymentRule[];
  offlineBuffer: OfflineTxnBufferItem[];
  offlineTxnBuffer: OfflineTxnBufferItem[];
  riskAlerts: RiskAlert[];
  auditEvents: AuditEvent[];
  systemComponents: SystemComponent[];
  regionalMetrics: RegionalMetric[];
  economicParams: EconomicParams;
  networkOfflineMode: boolean;
  isNetworkOnline: boolean;
  setNetworkOfflineMode: (off: boolean) => void;
  toggleNetworkStatus: () => void;

  // Actions
  issueERupee: (params: { institutionId: string; amount: number; purpose: string; settlementAccount: string }) => { success: boolean; message: string; batch?: IssuanceBatch };
  redeemERupee: (params: { institutionId: string; amount: number; purpose: string }) => { success: boolean; message: string };
  sendWalletPayment: (params: {
    sourceWalletId: string;
    targetWalletIdOrUpi: string;
    amount: number;
    narration: string;
    paymentMethod?: PaymentMethod;
    channel?: 'RETAIL_APP' | 'MERCHANT_POS' | 'INTERBANK_RTGS' | 'UPI_BRIDGE' | 'OFFLINE_DEVICE';
  }) => { success: boolean; message: string; transaction?: Transaction };
  executeUpiSwap: (params: {
    sourceAccount: string;
    destinationAccount: string;
    amount: number;
    mode: 'eRupee_TO_UPI' | 'UPI_TO_eRupee';
  }) => { success: boolean; message: string; transaction?: Transaction };
  processOfflinePayment: (params: {
    senderWalletId: string;
    receiverWalletId: string;
    amount: number;
    deviceId: string;
  }) => { success: boolean; message: string; bufferItem?: OfflineTxnBufferItem };
  executeOfflineTxn: (params: {
    payerId: string;
    payeeId: string;
    amount: number;
  }) => { success: boolean; message: string };
  syncOfflineLedger: () => { success: boolean; syncedCount: number; message: string };
  syncOfflineTxns: () => { success: boolean; syncedCount: number; message: string };
  triggerSettlementBatch: (id?: string) => void;
  createProgrammableContract: (params: {
    title: string;
    purpose: string;
    conditionRule: string;
    amount: number;
    sourceWalletId: string;
    beneficiaryWalletId: string;
    expiryDate: string;
  }) => void;
  triggerProgrammableContract: (ruleId: string) => void;
  updateProgrammableRuleStatus: (ruleId: string, status: 'CONDITION_MET' | 'EXECUTED' | 'CANCELLED') => void;
  freezeWallet: (walletId: string) => void;
  unfreezeWallet: (walletId: string) => void;
  resolveRiskAlert: (alertId: string, action: 'CLEARED' | 'FROZEN') => void;
  updateRiskAlertStatus: (alertId: string, newStatus: 'RESOLVED' | 'ACTION_TAKEN') => void;
  setEconomicParams: React.Dispatch<React.SetStateAction<EconomicParams>>;
  resetSimulationData: () => void;
}

const SimulationContext = createContext<SimulationContextType | undefined>(undefined);

export const SimulationProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('en');
  const [currentSection, setNavSection] = useState<NavSection>('overview');

  const [institutions, setInstitutions] = useState<Institution[]>(INITIAL_INSTITUTIONS);
  const [wallets, setWallets] = useState<Wallet[]>(INITIAL_WALLETS);
  const [merchants, setMerchants] = useState<Merchant[]>(INITIAL_MERCHANTS);
  const [transactions, setTransactions] = useState<Transaction[]>(INITIAL_TRANSACTIONS);
  const [issuanceBatches, setIssuanceBatches] = useState<IssuanceBatch[]>(INITIAL_ISSUANCE_BATCHES);
  const [settlementQueue, setSettlementQueue] = useState<SettlementQueueItem[]>(INITIAL_SETTLEMENT_QUEUE);
  const [programmableRules, setProgrammableRules] = useState<ProgrammablePaymentRule[]>(INITIAL_PROGRAMMABLE_RULES);
  const [offlineBuffer, setOfflineBuffer] = useState<OfflineTxnBufferItem[]>([
    {
      id: 'OFF-BUF-101',
      deviceId: 'NFC-SUBWAY-441',
      senderWalletId: 'WLT-IND-1003',
      senderName: 'Rohan Kulkarni',
      receiverWalletId: 'WLT-MER-2003',
      receiverName: 'Bengaluru Metro Rail',
      amount: 120,
      localNonce: 'LOCAL-NONCE-99210',
      timestamp: formatTimestampIST(),
      syncStatus: 'LOCAL_BUFFER',
    },
  ]);

  const seededRegional = INITIAL_REGIONAL_METRICS.map((m) => ({
    ...m,
    circulation: m.transactionValue * 1.8,
    offlineRatio: 0.12,
  }));

  const seededRiskAlerts: RiskAlert[] = INITIAL_RISK_ALERTS.map((a) => ({
    ...a,
    entityName: a.institutionName,
    entityId: a.institutionId,
  }));

  const seededAuditEvents: AuditEvent[] = INITIAL_AUDIT_EVENTS.map((e) => ({
    ...e,
    performedBy: e.institution,
    action: e.operation,
    details: e.resource,
    category: 'SYSTEM',
  }));

  const [riskAlerts, setRiskAlerts] = useState<RiskAlert[]>(seededRiskAlerts);
  const [auditEvents, setAuditEvents] = useState<AuditEvent[]>(seededAuditEvents);
  const [systemComponents] = useState<SystemComponent[]>(INITIAL_SYSTEM_COMPONENTS);
  const [regionalMetrics] = useState<RegionalMetric[]>(seededRegional);
  const [networkOfflineMode, setNetworkOfflineMode] = useState<boolean>(false);

  const [economicParams, setEconomicParams] = useState<EconomicParams>({
    eRupeeCirculation: 18427,
    walletAdoptionRate: 24.8,
    dailyTransactionFrequency: 2.48,
    paymentVelocity: 4.2,
    cashUsageReduction: 18.5,
    depositMigrationPercent: 3.2,
    settlementDemand: 1250,
    liquidityDemand: 8500,
    simulationSpeed: 1,
    isSimulating: true,
  });

  const toggleNetworkStatus = () => setNetworkOfflineMode((prev) => !prev);

  const logAudit = (operation: string, institution: string, resource: string, result: 'SUCCESS' | 'BLOCKED' | 'FLAGGED' | 'COMPLETED', riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL' = 'LOW') => {
    const newAudit: AuditEvent = {
      id: `AUD-${Math.floor(800000 + Math.random() * 100000)}`,
      eventId: `AUD-${Math.floor(2000000 + Math.random() * 1000000)}`,
      timestamp: formatTimestampIST(),
      institution,
      performedBy: institution,
      operation,
      action: operation,
      resource,
      details: resource,
      category: operation.includes('Issuance') ? 'ISSUANCE' : operation.includes('Payment') ? 'PAYMENT' : 'SYSTEM',
      result,
      riskLevel,
    };
    setAuditEvents((prev) => [newAudit, ...prev]);
  };

  const issueERupee = ({ institutionId, amount, purpose, settlementAccount }: { institutionId: string; amount: number; purpose: string; settlementAccount: string }) => {
    const inst = institutions.find((i) => i.id === institutionId);
    if (!inst) return { success: false, message: 'Target institution not found' };

    const previousBalance = inst.eRupeeBalance;
    const newBalance = previousBalance + amount;

    setInstitutions((prev) =>
      prev.map((i) => {
        if (i.id === institutionId) {
          return { ...i, eRupeeBalance: newBalance };
        }
        if (i.code === 'RBDC') {
          return { ...i, eRupeeBalance: i.eRupeeBalance + amount };
        }
        return i;
      })
    );

    const newBatch: IssuanceBatch = {
      id: `BATCH-ISS-2026-${Math.floor(100 + Math.random() * 900)}`,
      date: new Date().toISOString().split('T')[0],
      institutionId,
      institutionName: inst.name,
      amount,
      purpose,
      settlementAccount,
      previousBalance,
      newBalance,
      processingStatus: 'COMPLETED',
      timestamp: `${new Date().toISOString().split('T')[0]} ${formatTimestampIST()}`,
      auditRef: `AUD-ISS-${Math.floor(800000 + Math.random() * 100000)}`,
    };

    setIssuanceBatches((prev) => [newBatch, ...prev]);
    logAudit('Central Bank e₹ Issuance', inst.name, newBatch.id, 'COMPLETED', 'LOW');

    return { success: true, message: `Successfully issued ₹${amount.toLocaleString('en-IN')} e₹ to ${inst.name}`, batch: newBatch };
  };

  const redeemERupee = ({ institutionId, amount, purpose }: { institutionId: string; amount: number; purpose: string }) => {
    const inst = institutions.find((i) => i.id === institutionId);
    if (!inst) return { success: false, message: 'Institution not found' };
    if (inst.eRupeeBalance < amount) return { success: false, message: 'Insufficient institutional e₹ balance for redemption' };

    setInstitutions((prev) =>
      prev.map((i) => {
        if (i.id === institutionId) {
          return { ...i, eRupeeBalance: i.eRupeeBalance - amount };
        }
        if (i.code === 'RBDC') {
          return { ...i, eRupeeBalance: Math.max(0, i.eRupeeBalance - amount) };
        }
        return i;
      })
    );

    logAudit('Institutional e₹ Redemption', inst.name, `REDEEM-₹${amount}`, 'COMPLETED', 'LOW');
    return { success: true, message: `Redeemed ₹${amount.toLocaleString('en-IN')} e₹ from ${inst.name}` };
  };

  const sendWalletPayment = ({
    sourceWalletId,
    targetWalletIdOrUpi,
    amount,
    narration,
    paymentMethod = 'eRupee_Ledger',
    channel = 'RETAIL_APP',
  }: {
    sourceWalletId: string;
    targetWalletIdOrUpi: string;
    amount: number;
    narration: string;
    paymentMethod?: PaymentMethod;
    channel?: 'RETAIL_APP' | 'MERCHANT_POS' | 'INTERBANK_RTGS' | 'UPI_BRIDGE' | 'OFFLINE_DEVICE';
  }) => {
    const sourceWlt = wallets.find((w) => w.id === sourceWalletId || w.phone === sourceWalletId);
    if (!sourceWlt) return { success: false, message: 'Source wallet not found' };

    if (sourceWlt.status === 'FROZEN') {
      logAudit('Wallet Payment Attempt', sourceWlt.ownerName, sourceWlt.id, 'BLOCKED', 'HIGH');
      return { success: false, message: 'Transaction rejected: Source wallet is FROZEN by compliance' };
    }

    if (sourceWlt.availableBalance < amount) {
      logAudit('Wallet Payment Attempt', sourceWlt.ownerName, sourceWlt.id, 'BLOCKED', 'LOW');
      return { success: false, message: `Insufficient balance. Available: ₹${sourceWlt.availableBalance.toLocaleString('en-IN')}` };
    }

    let targetWlt = wallets.find((w) => w.id === targetWalletIdOrUpi || w.upiId === targetWalletIdOrUpi || w.phone === targetWalletIdOrUpi);
    let targetName = targetWlt ? targetWlt.ownerName : targetWalletIdOrUpi;
    let targetInst = targetWlt ? targetWlt.bankName : 'Interoperable Participant';

    setWallets((prev) =>
      prev.map((w) => {
        if (w.id === sourceWlt.id) {
          const newBal = w.balance - amount;
          return {
            ...w,
            balance: newBal,
            availableBalance: newBal,
            transactionCount: w.transactionCount + 1,
            lastActivity: 'Just now',
          };
        }
        if (targetWlt && w.id === targetWlt.id) {
          const newBal = w.balance + amount;
          return {
            ...w,
            balance: newBal,
            availableBalance: newBal,
            transactionCount: w.transactionCount + 1,
            lastActivity: 'Just now',
          };
        }
        return w;
      })
    );

    const merchant = merchants.find((m) => m.walletId === targetWlt?.id || m.upiId === targetWalletIdOrUpi);
    if (merchant) {
      setMerchants((prev) =>
        prev.map((m) => {
          if (m.id === merchant.id) {
            return {
              ...m,
              todaySales: m.todaySales + amount,
              transactionCount: m.transactionCount + 1,
              eRupeeBalance: m.eRupeeBalance + amount,
            };
          }
          return m;
        })
      );
    }

    const txnId = `TXN-E-${Math.floor(2000000 + Math.random() * 1000000)}`;
    const newTxn: Transaction = {
      id: txnId,
      reference: `REF-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.floor(10000 + Math.random() * 90000)}`,
      timestamp: `${new Date().toISOString().slice(0, 10)} ${formatTimestampIST()}`,
      type: merchant ? 'P2M' : 'P2P',
      paymentMethod,
      sourceId: sourceWlt.id,
      sourceName: sourceWlt.ownerName,
      sourceInstitution: sourceWlt.bankName,
      destinationId: targetWlt ? targetWlt.id : targetWalletIdOrUpi,
      destinationName: targetName,
      destinationInstitution: targetInst,
      amount,
      status: 'COMPLETED',
      riskScore: amount > 500000 ? 75 : 2,
      channel,
      narration: narration || 'Digital Rupee Wallet Transfer',
    };

    setTransactions((prev) => [newTxn, ...prev]);

    const settlementItem: SettlementQueueItem = {
      id: `SETTL-${Math.floor(9000 + Math.random() * 1000)}`,
      reference: txnId,
      originatingInstitution: sourceWlt.bankName,
      receivingInstitution: targetInst,
      amount,
      purpose: narration,
      status: 'COMPLETED',
      priority: amount > 100000 ? 'URGENT' : 'NORMAL',
      latencyMs: Math.floor(12 + Math.random() * 30),
      timestamp: formatTimestampIST(),
    };
    setSettlementQueue((prev) => [settlementItem, ...prev]);

    logAudit('e₹ Payment Executed', sourceWlt.bankName, txnId, 'COMPLETED', 'LOW');

    return { success: true, message: `Payment of ₹${amount.toLocaleString('en-IN')} successful!`, transaction: newTxn };
  };

  const executeUpiSwap = ({
    sourceAccount,
    destinationAccount,
    amount,
    mode,
  }: {
    sourceAccount: string;
    destinationAccount: string;
    amount: number;
    mode: 'eRupee_TO_UPI' | 'UPI_TO_eRupee';
  }) => {
    const txnId = `TXN-UPI-${Math.floor(2000000 + Math.random() * 1000000)}`;

    if (mode === 'UPI_TO_eRupee') {
      const targetWlt = wallets.find((w) => w.id === destinationAccount || w.upiId === destinationAccount);
      if (targetWlt) {
        setWallets((prev) =>
          prev.map((w) => (w.id === targetWlt.id ? { ...w, balance: w.balance + amount, availableBalance: w.availableBalance + amount } : w))
        );
      }
    } else {
      const srcWlt = wallets.find((w) => w.id === sourceAccount || w.upiId === sourceAccount);
      if (srcWlt && srcWlt.availableBalance < amount) {
        return { success: false, message: 'Insufficient e₹ wallet balance for UPI conversion' };
      }
      if (srcWlt) {
        setWallets((prev) =>
          prev.map((w) => (w.id === srcWlt.id ? { ...w, balance: w.balance - amount, availableBalance: w.availableBalance - amount } : w))
        );
      }
    }

    const newTxn: Transaction = {
      id: txnId,
      reference: `NPCI-BRIDGE-${Math.floor(100000 + Math.random() * 900000)}`,
      timestamp: `${new Date().toISOString().slice(0, 10)} ${formatTimestampIST()}`,
      type: mode === 'UPI_TO_eRupee' ? 'UPI_SWAP_IN' : 'UPI_SWAP_OUT',
      paymentMethod: 'UPI_Interoperability',
      sourceId: sourceAccount,
      sourceName: sourceAccount,
      sourceInstitution: 'UPI Interoperability Layer (NPCI Sim)',
      destinationId: destinationAccount,
      destinationName: destinationAccount,
      destinationInstitution: 'e₹ Sovereign Ledger',
      amount,
      status: 'COMPLETED',
      riskScore: 3,
      channel: 'UPI_BRIDGE',
      narration: mode === 'UPI_TO_eRupee' ? 'Convert Commercial Bank UPI → e₹ Sovereign Money' : 'Convert e₹ Sovereign Money → UPI Bank Account',
    };

    setTransactions((prev) => [newTxn, ...prev]);
    logAudit('UPI Interoperability Conversion', 'NPCI Bridge', txnId, 'COMPLETED', 'LOW');

    return { success: true, message: `UPI x e₹ Interoperable transfer of ₹${amount.toLocaleString('en-IN')} complete!`, transaction: newTxn };
  };

  const processOfflinePayment = ({
    senderWalletId,
    receiverWalletId,
    amount,
    deviceId,
  }: {
    senderWalletId: string;
    receiverWalletId: string;
    amount: number;
    deviceId: string;
  }) => {
    const sender = wallets.find((w) => w.id === senderWalletId);
    if (!sender) return { success: false, message: 'Sender wallet not found on device secure element' };
    if (sender.availableBalance < amount) {
      return { success: false, message: 'Insufficient local secure token balance on offline hardware element' };
    }

    setWallets((prev) =>
      prev.map((w) => (w.id === sender.id ? { ...w, offlineSyncPending: w.offlineSyncPending + amount } : w))
    );

    const bufItem: OfflineTxnBufferItem = {
      id: `OFF-BUF-${Math.floor(100 + Math.random() * 900)}`,
      deviceId,
      senderWalletId: sender.id,
      senderName: sender.ownerName,
      receiverWalletId,
      receiverName: 'Transit Terminal / Merchant',
      amount,
      localNonce: `NONCE-${Math.floor(100000 + Math.random() * 900000)}`,
      timestamp: formatTimestampIST(),
      syncStatus: 'LOCAL_BUFFER',
    };

    setOfflineBuffer((prev) => [bufItem, ...prev]);
    return { success: true, message: 'Offline NFC Token Payment executed & stored in Secure Hardware Element', bufferItem: bufItem };
  };

  const executeOfflineTxn = ({ payerId, payeeId, amount }: { payerId: string; payeeId: string; amount: number }) => {
    return processOfflinePayment({
      senderWalletId: payerId,
      receiverWalletId: payeeId,
      amount,
      deviceId: 'NFC-MOBILE-VAULT-881',
    });
  };

  const syncOfflineLedger = () => {
    const pending = offlineBuffer.filter((item) => item.syncStatus === 'LOCAL_BUFFER');
    if (pending.length === 0) {
      return { success: true, syncedCount: 0, message: 'No offline buffered payments pending reconciliation.' };
    }

    pending.forEach((item) => {
      sendWalletPayment({
        sourceWalletId: item.senderWalletId,
        targetWalletIdOrUpi: item.receiverWalletId,
        amount: item.amount,
        narration: `Offline Hardware Sync: ${item.localNonce} via ${item.deviceId}`,
        paymentMethod: 'Offline_NFC_Token',
        channel: 'OFFLINE_DEVICE',
      });
    });

    setOfflineBuffer((prev) =>
      prev.map((item) => ({
        ...item,
        syncStatus: 'RECONCILED',
      }))
    );

    logAudit('Offline Ledger Bulk Reconciliation', 'CBDC Core Node', `SYNC-${pending.length}-ITEMS`, 'COMPLETED', 'LOW');

    return {
      success: true,
      syncedCount: pending.length,
      message: `Reconciled ${pending.length} offline transactions onto the central e₹ ledger cleanly.`,
    };
  };

  const syncOfflineTxns = () => syncOfflineLedger();

  const triggerSettlementBatch = (id?: string) => {
    setSettlementQueue((prev) =>
      prev.map((item) => {
        if (!id || item.id === id) {
          return { ...item, status: 'COMPLETED' };
        }
        return item;
      })
    );
    logAudit('Interbank Batch Settlement', 'Clearing House', id || 'ALL_PENDING', 'COMPLETED', 'LOW');
  };

  const createProgrammableContract = ({
    title,
    purpose,
    conditionRule,
    amount,
    sourceWalletId,
    beneficiaryWalletId,
    expiryDate,
  }: {
    title: string;
    purpose: string;
    conditionRule: string;
    amount: number;
    sourceWalletId: string;
    beneficiaryWalletId: string;
    expiryDate: string;
  }) => {
    const newRule: ProgrammablePaymentRule = {
      id: `PROG-${Math.floor(1000 + Math.random() * 9000)}`,
      title,
      payerName: 'Central Bank / Govt Escrow Pool',
      amount,
      conditionRule,
      status: 'ACTIVE',
      expiryDate,
      purpose,
    };

    setProgrammableRules((prev) => [newRule, ...prev]);
    logAudit('Programmable Rule Deployed', 'Smart Contract Engine', newRule.id, 'COMPLETED', 'LOW');
  };

  const updateProgrammableRuleStatus = (ruleId: string, newStatus: 'CONDITION_MET' | 'EXECUTED' | 'CANCELLED') => {
    const rule = programmableRules.find((r) => r.id === ruleId);
    if (!rule) return;

    if (newStatus === 'EXECUTED') {
      logAudit('Programmable Smart Disbursement', rule.payerName, rule.id, 'COMPLETED', 'LOW');
    }

    setProgrammableRules((prev) =>
      prev.map((r) => (r.id === ruleId ? { ...r, status: newStatus } : r))
    );
  };

  const triggerProgrammableContract = (ruleId: string) => {
    updateProgrammableRuleStatus(ruleId, 'EXECUTED');
  };

  const freezeWallet = (walletId: string) => {
    setWallets((prev) =>
      prev.map((w) => (w.id === walletId ? { ...w, status: 'FROZEN', riskStatus: 'HIGH' } : w))
    );
    logAudit('Compliance Freeze Action', 'RBI Supervision', walletId, 'FLAGGED', 'HIGH');
  };

  const unfreezeWallet = (walletId: string) => {
    setWallets((prev) =>
      prev.map((w) => (w.id === walletId ? { ...w, status: 'ACTIVE', riskStatus: 'LOW' } : w))
    );
    logAudit('Compliance Unfreeze Action', 'RBI Supervision', walletId, 'COMPLETED', 'LOW');
  };

  const resolveRiskAlert = (alertId: string, action: 'CLEARED' | 'FROZEN') => {
    setRiskAlerts((prev) =>
      prev.map((a) => (a.id === alertId ? { ...a, status: action === 'CLEARED' ? 'CLEARED' : 'FROZEN' } : a))
    );
  };

  const updateRiskAlertStatus = (alertId: string, newStatus: 'RESOLVED' | 'ACTION_TAKEN') => {
    setRiskAlerts((prev) =>
      prev.map((a) => (a.id === alertId ? { ...a, status: newStatus === 'RESOLVED' ? 'CLEARED' : 'FROZEN' } : a))
    );
  };

  const resetSimulationData = () => {
    setInstitutions(INITIAL_INSTITUTIONS);
    setWallets(INITIAL_WALLETS);
    setMerchants(INITIAL_MERCHANTS);
    setTransactions(INITIAL_TRANSACTIONS);
    setIssuanceBatches(INITIAL_ISSUANCE_BATCHES);
    setSettlementQueue(INITIAL_SETTLEMENT_QUEUE);
    setProgrammableRules(INITIAL_PROGRAMMABLE_RULES);
    setRiskAlerts(seededRiskAlerts);
    setAuditEvents(seededAuditEvents);
    setNetworkOfflineMode(false);
  };

  return (
    <SimulationContext.Provider
      value={{
        language,
        setLanguage,
        currentSection,
        activeSection: currentSection,
        setNavSection,
        institutions,
        wallets,
        merchants,
        transactions,
        issuanceBatches,
        settlementQueue,
        programmableRules,
        programmableContracts: programmableRules,
        offlineBuffer,
        offlineTxnBuffer: offlineBuffer,
        riskAlerts,
        auditEvents,
        systemComponents,
        regionalMetrics,
        economicParams,
        networkOfflineMode,
        isNetworkOnline: !networkOfflineMode,
        setNetworkOfflineMode,
        toggleNetworkStatus,
        issueERupee,
        redeemERupee,
        sendWalletPayment,
        executeUpiSwap,
        processOfflinePayment,
        executeOfflineTxn,
        syncOfflineLedger,
        syncOfflineTxns,
        triggerSettlementBatch,
        createProgrammableContract,
        triggerProgrammableContract,
        updateProgrammableRuleStatus,
        freezeWallet,
        unfreezeWallet,
        resolveRiskAlert,
        updateRiskAlertStatus,
        setEconomicParams,
        resetSimulationData,
      }}
    >
      {children}
    </SimulationContext.Provider>
  );
};

export const useCBDCSimulation = () => {
  const context = useContext(SimulationContext);
  if (!context) {
    throw new Error('useCBDCSimulation must be used within a SimulationProvider');
  }
  return context;
};
