export type Language = 'en' | 'hi';

export type NavSection =
  | 'overview'
  | 'issuance'
  | 'retail'
  | 'consumer_wallet'
  | 'wholesale'
  | 'banks'
  | 'merchants'
  | 'upi_interop'
  | 'settlement'
  | 'offline'
  | 'programmable'
  | 'liquidity'
  | 'risk'
  | 'ledger'
  | 'regional_analytics'
  | 'economic_sim'
  | 'system_arch'
  | 'network_ops'
  | 'audit'
  | 'system_ops';

export type WalletType = 'RETAIL' | 'MERCHANT' | 'INSTITUTIONAL';
export type WalletStatus = 'ACTIVE' | 'FROZEN' | 'SUSPENDED';
export type KycStatus = 'VERIFIED' | 'TIER_1' | 'TIER_2' | 'PENDING';
export type RiskLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export interface Wallet {
  id: string;
  type: WalletType;
  bankId: string;
  bankName: string;
  ownerName: string;
  upiId?: string;
  phone?: string;
  balance: number;
  availableBalance: number;
  heldAmount: number;
  transactionCount: number;
  kycStatus: KycStatus;
  status: WalletStatus;
  riskStatus: RiskLevel;
  lastActivity: string;
  offlineSyncPending: number;
}

export interface Institution {
  id: string;
  name: string;
  code: string;
  type: 'CENTRAL_BANK' | 'COMMERCIAL_BANK' | 'NON_BANK_PSP';
  eRupeeBalance: number;
  customerWalletsCount: number;
  merchantWalletsCount: number;
  todayTransactionsCount: number;
  settlementPosition: number; // positive = credit, negative = debit
  liquidityBuffer: number;
  apiHealth: 'OPERATIONAL' | 'DEGRADED' | 'MAINTENANCE' | 'OFFLINE';
  riskScore: number;
  icon?: string;
}

export interface Merchant {
  id: string;
  businessName: string;
  category: string;
  bankId: string;
  bankName: string;
  walletId: string;
  upiId: string;
  todaySales: number;
  transactionCount: number;
  avgTxnValue: number;
  pendingSettlement: number;
  eRupeeBalance: number;
  location: string;
  terminalStatus: 'ONLINE' | 'OFFLINE' | 'BUSY';
}

export type TxnType =
  | 'ISSUANCE'
  | 'REDEMPTION'
  | 'P2P'
  | 'P2M'
  | 'INTERBANK'
  | 'UPI_SWAP_IN'
  | 'UPI_SWAP_OUT'
  | 'OFFLINE_PAYMENT'
  | 'OFFLINE_SYNC'
  | 'PROGRAMMABLE_DISBURSEMENT';

export type PaymentMethod = 'eRupee_Ledger' | 'UPI_Interoperability' | 'Offline_NFC_Token';
export type SettlementStatus = 'COMPLETED' | 'SETTLING' | 'PENDING' | 'HELD_RISK' | 'FAILED';

export interface Transaction {
  id: string;
  reference: string;
  timestamp: string;
  type: TxnType;
  paymentMethod: PaymentMethod;
  sourceId: string;
  sourceName: string;
  sourceInstitution: string;
  destinationId: string;
  destinationName: string;
  destinationInstitution: string;
  amount: number;
  status: SettlementStatus;
  riskScore: number;
  channel: 'RETAIL_APP' | 'MERCHANT_POS' | 'INTERBANK_RTGS' | 'UPI_BRIDGE' | 'OFFLINE_DEVICE';
  narration: string;
  offlineMeta?: {
    deviceId: string;
    localNonce: string;
    syncedAt?: string;
  };
}

export interface IssuanceBatch {
  id: string;
  date: string;
  institutionId: string;
  institutionName: string;
  amount: number;
  purpose: string;
  settlementAccount: string;
  previousBalance: number;
  newBalance: number;
  processingStatus: 'COMPLETED' | 'PENDING' | 'APPROVED' | 'REJECTED';
  timestamp: string;
  auditRef: string;
}

export interface SettlementQueueItem {
  id: string;
  reference: string;
  originatingInstitution: string;
  receivingInstitution: string;
  amount: number;
  purpose: string;
  status: 'WAITING' | 'PROCESSING' | 'SETTLING' | 'COMPLETED' | 'HELD' | 'FAILED';
  priority: 'HIGH' | 'NORMAL' | 'URGENT';
  latencyMs: number;
  timestamp: string;
}

export interface ProgrammablePaymentRule {
  id: string;
  title?: string;
  invoiceRef?: string;
  payerName: string;
  recipientName?: string;
  amount: number;
  conditionType?: 'DELIVERY_CONFIRMED' | 'MILESTONE_REACHED' | 'TAX_VERIFIED' | 'SCHEDULED_DATE' | 'AGRICULTURAL_SUBSIDY';
  conditionRule?: string;
  conditionDescription?: string;
  status: 'WAITING_FOR_CONDITION' | 'CONDITION_MET' | 'EXECUTED' | 'EXPIRED' | 'CANCELLED' | 'ACTIVE';
  expiryDate: string;
  purpose: string;
}

export interface OfflineTxnBufferItem {
  id: string;
  deviceId: string;
  senderWalletId: string;
  senderName: string;
  receiverWalletId: string;
  receiverName: string;
  amount: number;
  localNonce: string;
  timestamp: string;
  syncStatus: 'LOCAL_BUFFER' | 'SYNCING' | 'RECONCILED' | 'DUPLICATE_ALERT';
}

export interface RiskAlert {
  id: string;
  transactionId: string;
  institutionId: string;
  institutionName: string;
  entityName?: string;
  entityId?: string;
  amount: number;
  ruleTriggered: string;
  severity: RiskLevel;
  status: 'REVIEW_REQUIRED' | 'INVESTIGATING' | 'CLEARED' | 'FROZEN' | 'RESOLVED' | 'ACTION_TAKEN';
  description: string;
  timestamp: string;
}

export interface AuditEvent {
  id: string;
  eventId: string;
  timestamp: string;
  institution: string;
  performedBy?: string;
  operation: string;
  action?: string;
  resource: string;
  details?: string;
  category?: string;
  result: 'SUCCESS' | 'BLOCKED' | 'FLAGGED' | 'COMPLETED';
  riskLevel: RiskLevel;
}

export interface SystemComponent {
  id: string;
  name: string;
  category: 'CORE' | 'GATEWAY' | 'QUEUE' | 'SERVICE';
  status: 'OPERATIONAL' | 'DEGRADED' | 'MAINTENANCE' | 'OFFLINE';
  latencyMs: number;
  throughputRps: number;
  errorRatePercent: number;
  heartbeat: string;
}

export interface RegionalMetric {
  regionCode: 'NORTH' | 'SOUTH' | 'EAST' | 'WEST' | 'CENTRAL' | 'NORTHEAST';
  regionName: string;
  circulation?: number;
  transactionVolume: number;
  transactionValue: number;
  activeWallets: number;
  merchantCount: number;
  institutionCount: number;
  settlementValue: number;
  offlineRatio?: number;
  majorCities: string[];
}

export interface EconomicParams {
  eRupeeCirculation: number; // in Crores
  walletAdoptionRate: number; // %
  dailyTransactionFrequency: number; // millions
  paymentVelocity: number; // multiplier
  cashUsageReduction: number; // %
  depositMigrationPercent: number; // % from commercial bank deposits
  settlementDemand: number; // Cr/day
  liquidityDemand: number; // Cr
  simulationSpeed: 1 | 10 | 100;
  isSimulating: boolean;
}
