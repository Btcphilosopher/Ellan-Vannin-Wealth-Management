import React from 'react';
import { SimulationProvider, useCBDCSimulation } from './simulation/SimulationContext';
import { SimulationBanner } from './components/layout/SimulationBanner';
import { Header } from './components/layout/Header';
import { SidebarNav } from './components/layout/SidebarNav';
import { StartupOverlay } from './components/layout/StartupOverlay';

// Modules
import { DashboardModule } from './components/modules/DashboardModule';
import { IssuanceModule } from './components/modules/IssuanceModule';
import { RetailModule } from './components/modules/RetailModule';
import { ConsumerWalletModule } from './components/modules/ConsumerWalletModule';
import { WholesaleModule } from './components/modules/WholesaleModule';
import { BankingNetworkModule } from './components/modules/BankingNetworkModule';
import { MerchantModule } from './components/modules/MerchantModule';
import { UpiInteropModule } from './components/modules/UpiInteropModule';
import { SettlementModule } from './components/modules/SettlementModule';
import { OfflineModule } from './components/modules/OfflineModule';
import { ProgrammableModule } from './components/modules/ProgrammableModule';
import { LiquidityModule } from './components/modules/LiquidityModule';
import { RiskModule } from './components/modules/RiskModule';
import { LedgerModule } from './components/modules/LedgerModule';
import { RegionalAnalyticsModule } from './components/modules/RegionalAnalyticsModule';
import { EconomicSimModule } from './components/modules/EconomicSimModule';
import { SystemArchModule } from './components/modules/SystemArchModule';
import { NetworkOpsModule } from './components/modules/NetworkOpsModule';
import { SystemOpsModule } from './components/modules/SystemOpsModule';
import { AuditLogModule } from './components/modules/AuditLogModule';

const MainContent: React.FC = () => {
  const { currentSection } = useCBDCSimulation();

  const renderActiveModule = () => {
    switch (currentSection) {
      case 'overview':
        return <DashboardModule />;
      case 'issuance':
        return <IssuanceModule />;
      case 'retail':
        return <RetailModule />;
      case 'consumer_wallet':
        return <ConsumerWalletModule />;
      case 'wholesale':
        return <WholesaleModule />;
      case 'banks':
        return <BankingNetworkModule />;
      case 'merchants':
        return <MerchantModule />;
      case 'upi_interop':
        return <UpiInteropModule />;
      case 'settlement':
        return <SettlementModule />;
      case 'offline':
        return <OfflineModule />;
      case 'programmable':
        return <ProgrammableModule />;
      case 'liquidity':
        return <LiquidityModule />;
      case 'risk':
        return <RiskModule />;
      case 'ledger':
        return <LedgerModule />;
      case 'regional_analytics':
        return <RegionalAnalyticsModule />;
      case 'economic_sim':
        return <EconomicSimModule />;
      case 'system_arch':
        return <SystemArchModule />;
      case 'network_ops':
        return <NetworkOpsModule />;
      case 'system_ops':
        return <SystemOpsModule />;
      case 'audit':
        return <AuditLogModule />;
      default:
        return <DashboardModule />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      <SimulationBanner />
      <Header />

      <div className="flex-1 flex overflow-hidden">
        <SidebarNav />
        <main className="flex-1 overflow-y-auto p-4 lg:p-6 space-y-6 max-w-7xl mx-auto w-full">
          {renderActiveModule()}
        </main>
      </div>

      <StartupOverlay />
    </div>
  );
};

export function App() {
  return (
    <SimulationProvider>
      <MainContent />
    </SimulationProvider>
  );
}

export default App;
