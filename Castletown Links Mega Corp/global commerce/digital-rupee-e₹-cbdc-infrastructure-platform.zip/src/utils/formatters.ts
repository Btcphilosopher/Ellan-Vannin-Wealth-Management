/**
 * Indian Number System Formatting Utilities
 * Standard: Enforces the Indian numbering grouping (3 digits, then groups of 2 digits).
 * Examples:
 *   1000 -> 1,000
 *   100000 -> 1,00,000 (1 Lakh)
 *   10000000 -> 1,00,00,000 (1 Crore)
 */

export function formatIndianNumber(val: number | string): string {
  const num = typeof val === 'string' ? parseFloat(val) : val;
  if (isNaN(num)) return '0';

  const isNegative = num < 0;
  const absNum = Math.abs(num);

  // Separate integer and decimal parts
  const parts = absNum.toFixed(2).split('.');
  let integerPart = parts[0];
  const decimalPart = parts[1];

  // Apply Indian grouping logic
  if (integerPart.length > 3) {
    const last3 = integerPart.substring(integerPart.length - 3);
    const otherNumbers = integerPart.substring(0, integerPart.length - 3);
    const formattedOthers = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ',');
    integerPart = formattedOthers + ',' + last3;
  }

  // Omit .00 if whole number or preserve decimals if needed
  const formattedStr = decimalPart === '00' ? integerPart : `${integerPart}.${decimalPart}`;
  return isNegative ? `-${formattedStr}` : formattedStr;
}

export function formatIndianRupee(amount: number, showDecimals: boolean = false): string {
  const isNegative = amount < 0;
  const absAmount = Math.abs(amount);
  
  const parts = (showDecimals ? absAmount.toFixed(2) : Math.round(absAmount).toString()).split('.');
  let integerPart = parts[0];
  
  if (integerPart.length > 3) {
    const last3 = integerPart.substring(integerPart.length - 3);
    const otherNumbers = integerPart.substring(0, integerPart.length - 3);
    const formattedOthers = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ',');
    integerPart = formattedOthers + ',' + last3;
  }

  const finalNumStr = parts[1] ? `${integerPart}.${parts[1]}` : integerPart;
  return `${isNegative ? '-' : ''}₹${finalNumStr}`;
}

export function formatCompactRupee(amount: number): string {
  const absAmount = Math.abs(amount);
  const sign = amount < 0 ? '-' : '';

  if (absAmount >= 10000000) {
    // 1 Crore = 1,00,00,000
    const crores = absAmount / 10000000;
    if (crores >= 10000) {
      return `${sign}₹${formatIndianNumber(Math.round(crores))} Cr`;
    }
    return `${sign}₹${crores.toFixed(2)} Cr`;
  } else if (absAmount >= 100000) {
    // 1 Lakh = 1,00,000
    const lakhs = absAmount / 100000;
    return `${sign}₹${lakhs.toFixed(2)} Lakh`;
  } else if (absAmount >= 1000) {
    const thousands = absAmount / 1000;
    return `${sign}₹${thousands.toFixed(1)}K`;
  }

  return formatIndianRupee(amount, false);
}

export function formatTimestampIST(dateInput: Date | string = new Date()): string {
  const d = typeof dateInput === 'string' ? new Date(dateInput) : dateInput;
  // Format in Indian Standard Time (IST)
  return d.toLocaleTimeString('en-IN', {
    hour12: false,
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  }) + ' IST';
}

export function formatFullDateIST(dateInput: Date | string = new Date()): string {
  const d = typeof dateInput === 'string' ? new Date(dateInput) : dateInput;
  return d.toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  }) + ' ' + formatTimestampIST(d);
}
