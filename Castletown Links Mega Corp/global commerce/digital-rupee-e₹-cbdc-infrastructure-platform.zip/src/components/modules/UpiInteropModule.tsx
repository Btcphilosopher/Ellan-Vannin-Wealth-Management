import React, { useState } from 'react';
import { useCBDCSimulation } from '../../simulation/SimulationContext';
import { formatIndianRupee, formatCompactRupee } from '../../utils/formatters';
import { ArrowRightLeft, ShieldAlert, CheckCircle2, RefreshCw, Cpu, Layers, ArrowRight } from 'lucide-react';

export const UpiInteropModule: React.FC = () => {
  const { executeUpiSwap, transactions } = useCBDCSimulation();

  const [paymentMode, setPaymentMode] = useState<'eRupee_TO_UPI' | 'UPI_TO_eRupee' | 'eRupee_TO_eRupee' | 'UPI_MERCHANT'>('eRupee_TO_UPI');
  const [sourceAcc, setSourceAcc] = useState<string>('WLT-IND-1001');
  const [destAcc, setDestAcc] = useState<string>('merchant.store@upi.npci');
  const [amountStr, setAmountStr] = useState<string>('1250');

  // Multi-step settlement simulation states
  const [stage, setStage] = useState<'IDLE' | 'ACCEPTED' | 'PENDING' | 'COMPLETE'>('IDLE');
  const [activeTxnId, setActiveTxnId] = useState<string>('TXN-UPI-882109');
  const [feedbackMsg, setFeedbackMsg] = useState<string | null>(null);

  const handleExecuteInterop = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(amountStr);
    if (isNaN(amt) || amt <= 0) return;

    setFeedbackMsg(null);
    setStage('ACCEPTED');

    setTimeout(() => {
      setStage('PENDING');

      setTimeout(() => {
        const modeFlag = paymentMode === 'UPI_TO_eRupee' ? 'UPI_TO_eRupee' : 'eRupee_TO_UPI';
        const res = executeUpiSwap({
          sourceAccount: sourceAcc,
          destinationAccount: destAcc,
          amount: amt,
          mode: modeFlag,
        });

        if (res.transaction) {
          setActiveTxnId(res.transaction.id);
        }
        setStage('COMPLETE');
        setFeedbackMsg(res.message);
      }, 1000);
    }, 800);
  };

  const interopTxns = transactions.filter((t) => t.paymentMethod === 'UPI_Interoperability');

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <ArrowRightLeft className="w-5 h-5 text-amber-400" />
            <span>e₹ × UPI INTEROPERABILITY BRIDGE</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Simulated Interoperability Layer Connecting Central Bank Digital Rupee Tokens with NPCI UPI Payment Rail
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs text-amber-400 bg-amber-950 px-3 py-1.5 rounded border border-amber-800">
          <ShieldAlert className="w-3.5 h-3.5" />
          <span>SIMULATION BRIDGE — NO ACTUAL NPCI/UPI CONNECTION</span>
        </div>
      </div>

      {/* Visual Interoperability Flowchart requested by prompt */}
      <div className="bg-slate-950 border border-slate-800 p-5 rounded-lg font-mono">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">
          INTEROPERABILITY PIPELINE (CBDC LEDGER vs UPI INTERFACE)
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-3 text-center text-xs">
          <div className="bg-slate-900 border border-amber-500/50 p-3 rounded text-amber-300 font-bold flex flex-col items-center">
            <span className="text-[10px] text-slate-400">01. ORIGIN</span>
            <span>e₹ WALLET</span>
            <span className="text-[9px] text-slate-500 mt-1">Sovereign Money</span>
          </div>

          <div className="hidden md:flex items-center justify-center text-amber-500 font-bold">→</div>

          <div className="bg-slate-900 border border-slate-700 p-3 rounded text-slate-200 font-bold flex flex-col items-center">
            <span className="text-[10px] text-slate-400">02. INTERFACE</span>
            <span>UPI QR / VPA LAYER</span>
            <span className="text-[9px] text-slate-500 mt-1">Common Acceptance</span>
          </div>

          <div className="hidden md:flex items-center justify-center text-amber-500 font-bold">→</div>

          <div className="bg-slate-900 border border-slate-700 p-3 rounded text-emerald-300 font-bold flex flex-col items-center">
            <span className="text-[10px] text-slate-400">03. SETTLEMENT</span>
            <span>BANK / MERCHANT</span>
            <span className="text-[9px] text-slate-500 mt-1">Central Clear</span>
          </div>
        </div>

        <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
          <span className="flex items-center gap-1.5 text-amber-400 font-bold">
            <Layers className="w-3.5 h-3.5" />
            <span>CBDC Ledger != Commercial Bank UPI Account</span>
          </span>
          <span>Interoperable QR allows e₹ tokens to pay any UPI QR seamlessly</span>
        </div>
      </div>

      {/* Mode Selector & Form */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Form */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 font-mono space-y-4">
          <h3 className="text-sm font-bold text-white border-b border-slate-800 pb-2">
            INTEROPERABLE PAYMENT EXECUTOR
          </h3>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <button
              type="button"
              onClick={() => setPaymentMode('eRupee_TO_UPI')}
              className={`p-2 rounded border text-left font-bold ${
                paymentMode === 'eRupee_TO_UPI' ? 'bg-amber-600 text-white border-amber-500' : 'bg-slate-950 text-slate-400 border-slate-800'
              }`}
            >
              e₹ Wallet → UPI VPA
            </button>
            <button
              type="button"
              onClick={() => setPaymentMode('UPI_TO_eRupee')}
              className={`p-2 rounded border text-left font-bold ${
                paymentMode === 'UPI_TO_eRupee' ? 'bg-amber-600 text-white border-amber-500' : 'bg-slate-950 text-slate-400 border-slate-800'
              }`}
            >
              UPI Bank → e₹ Wallet
            </button>
            <button
              type="button"
              onClick={() => setPaymentMode('eRupee_TO_eRupee')}
              className={`p-2 rounded border text-left font-bold ${
                paymentMode === 'eRupee_TO_eRupee' ? 'bg-amber-600 text-white border-amber-500' : 'bg-slate-950 text-slate-400 border-slate-800'
              }`}
            >
              e₹ Token → e₹ Token
            </button>
            <button
              type="button"
              onClick={() => setPaymentMode('UPI_MERCHANT')}
              className={`p-2 rounded border text-left font-bold ${
                paymentMode === 'UPI_MERCHANT' ? 'bg-amber-600 text-white border-amber-500' : 'bg-slate-950 text-slate-400 border-slate-800'
              }`}
            >
              UPI Merchant → e₹ Wallet
            </button>
          </div>

          <form onSubmit={handleExecuteInterop} className="space-y-3 text-xs">
            <div>
              <label className="block text-slate-400 mb-1">Originating Account / VPA</label>
              <input
                type="text"
                value={sourceAcc}
                onChange={(e) => setSourceAcc(e.target.value)}
                required
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-white outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1">Destination VPA / e₹ Wallet</label>
              <input
                type="text"
                value={destAcc}
                onChange={(e) => setDestAcc(e.target.value)}
                required
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-white outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1">Amount (₹ INR)</label>
              <input
                type="number"
                value={amountStr}
                onChange={(e) => setAmountStr(e.target.value)}
                required
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-white outline-none focus:border-amber-500"
              />
            </div>

            <button
              type="submit"
              disabled={stage === 'ACCEPTED' || stage === 'PENDING'}
              className="w-full py-2.5 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white font-bold rounded transition-colors"
            >
              TRIGGER INTEROPERABLE SWAP
            </button>
          </form>
        </div>

        {/* Multi-step Status Timeline requested by prompt */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 font-mono space-y-4">
          <h3 className="text-sm font-bold text-white border-b border-slate-800 pb-2">
            SETTLEMENT TIMELINE & STATUS MONITOR
          </h3>

          <div className="space-y-3 text-xs">
            {/* Step 1 */}
            <div
              className={`p-3 rounded border flex items-center justify-between ${
                stage === 'ACCEPTED' || stage === 'PENDING' || stage === 'COMPLETE'
                  ? 'bg-emerald-950/60 border-emerald-700 text-emerald-300 font-bold'
                  : 'bg-slate-950 border-slate-800 text-slate-500'
              }`}
            >
              <span>1. Payment Accepted at Interop Layer</span>
              {stage !== 'IDLE' ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <span>Waiting</span>}
            </div>

            {/* Step 2 */}
            <div
              className={`p-3 rounded border flex items-center justify-between ${
                stage === 'PENDING' || stage === 'COMPLETE'
                  ? 'bg-amber-950/60 border-amber-700 text-amber-300 font-bold'
                  : 'bg-slate-950 border-slate-800 text-slate-500'
              }`}
            >
              <span>2. Settlement Pending (NPCI Bridge Check)</span>
              {stage === 'PENDING' ? (
                <div className="w-3.5 h-3.5 border-2 border-amber-400 border-t-transparent rounded-full animate-spin"></div>
              ) : stage === 'COMPLETE' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              ) : (
                <span>Waiting</span>
              )}
            </div>

            {/* Step 3 */}
            <div
              className={`p-3 rounded border flex items-center justify-between ${
                stage === 'COMPLETE'
                  ? 'bg-emerald-950/60 border-emerald-700 text-emerald-300 font-bold'
                  : 'bg-slate-950 border-slate-800 text-slate-500'
              }`}
            >
              <span>3. Settlement Complete on e₹ Central Ledger</span>
              {stage === 'COMPLETE' ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <span>Waiting</span>}
            </div>
          </div>

          {stage === 'COMPLETE' && (
            <div className="p-3 bg-slate-950 border border-emerald-500/40 rounded text-emerald-300 text-xs space-y-1">
              <div className="font-bold">✓ Transaction Settled Final</div>
              <div>Txn ID: {activeTxnId}</div>
              <div>Amount: {formatIndianRupee(parseFloat(amountStr) || 0)}</div>
            </div>
          )}
        </div>

      </div>

    </div>
  );
};
