import React from 'react';
import { useCBDCSimulation } from '../../simulation/SimulationContext';
import { StatCard } from '../common/StatCard';
import { MetricChart } from '../common/MetricChart';
import { formatIndianRupee, formatCompactRupee, formatIndianNumber } from '../../utils/formatters';
import {
  Coins,
  Wallet,
  ArrowUpRight,
  Store,
  ArrowRightLeft,
  WifiOff,
  CheckCircle2,
  Building2,
  Activity,
  TrendingUp,
} from 'lucide-react';

export const DashboardModule: React.FC = () => {
  const { language, transactions, wallets, merchants, institutions } = useCBDCSimulation();

  // Core metrics calculation from live simulation state
  const totalCirculation = 18427000000000; // ₹18,42,70,00,00,000
  const activeWalletsCount = wallets.filter((w) => w.status === 'ACTIVE').length + 24813920;
  const totalWalletsCount = 28450000;
  const todayTxnCount = transactions.length + 2481392;
  const todayTxnValue = transactions.reduce((acc, t) => acc + t.amount, 7842135600);

  const retailTxnCount = 1842100;
  const wholesaleTxnCount = 4210;
  const merchantTxnCount = 482000;
  const upiLinkedTxnCount = 124000;
  const offlineTxnCount = 28400;
  const settlementValue = 38500000000; // ₹3,850 Cr

  // Sample chart series
  const circulationSeries = [
    { label: '00:00', value: 17800 },
    { label: '04:00', value: 17850 },
    { label: '08:00', value: 18100 },
    { label: '12:00', value: 18350 },
    { label: '16:00', value: 18427 },
  ];

  const volumeSeries = [
    { label: '08:00', value: 420 },
    { label: '10:00', value: 1240 },
    { label: '12:00', value: 1890 },
    { label: '14:00', value: 2481 },
  ];

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 bg-slate-900/90 border border-slate-800 p-4 rounded-lg">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-bold text-white tracking-tight font-sans">
              DIGITAL RUPEE — NATIONAL OPERATIONS DASHBOARD
            </h2>
            <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-mono text-[11px] font-semibold">
              NATIONAL LEDGER ONLINE
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            {language === 'hi'
              ? 'अखिल भारतीय सीबीडीसी परिसंचरण, रिटेल/होलसेल समाशोधन एवं यूपीआई इंटरऑपरेबिलिटी मॉनिटर'
              : 'Pan-India e₹ Circulation, Retail/Wholesale Clearing & UPI Interoperability Operations'}
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs text-amber-300 bg-amber-950/60 border border-amber-800/60 px-3 py-1.5 rounded">
          <Activity className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
          <span>SIMULATED DATA | 100% FICTIONAL ECOSYSTEM</span>
        </div>
      </div>

      {/* Core Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total e₹ in Circulation"
          value={formatIndianRupee(totalCirculation)}
          compactValue={formatCompactRupee(totalCirculation)}
          subtext="Sovereign Central Bank Money"
          icon={Coins}
          accentColor="amber"
        />
        <StatCard
          title="Today's Transactions"
          value={formatIndianNumber(todayTxnCount)}
          subtext="Processed on Core e₹ Ledger"
          icon={ArrowUpRight}
          trend={{ value: '14.2% vs yesterday', isPositive: true }}
          accentColor="emerald"
        />
        <StatCard
          title="Today's Transaction Value"
          value={formatIndianRupee(todayTxnValue)}
          compactValue={formatCompactRupee(todayTxnValue)}
          subtext="Gross Retail & Wholesale Volume"
          icon={TrendingUp}
          accentColor="blue"
        />
        <StatCard
          title="Active Registered Wallets"
          value={formatIndianNumber(activeWalletsCount)}
          subtext={`Out of ${formatIndianNumber(totalWalletsCount)} Total`}
          icon={Wallet}
          accentColor="amber"
        />
      </div>

      {/* Secondary Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="bg-slate-900 border border-slate-800 p-3 rounded-md font-mono">
          <div className="text-[10px] text-slate-400 flex items-center gap-1">
            <Wallet className="w-3 h-3 text-emerald-400" />
            <span>Retail Txns</span>
          </div>
          <div className="text-base font-bold text-white mt-1">
            {formatIndianNumber(retailTxnCount)}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">74.2% of Total</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3 rounded-md font-mono">
          <div className="text-[10px] text-slate-400 flex items-center gap-1">
            <Building2 className="w-3 h-3 text-sky-400" />
            <span>Wholesale Txns</span>
          </div>
          <div className="text-base font-bold text-white mt-1">
            {formatIndianNumber(wholesaleTxnCount)}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Interbank Clearing</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3 rounded-md font-mono">
          <div className="text-[10px] text-slate-400 flex items-center gap-1">
            <Store className="w-3 h-3 text-amber-400" />
            <span>Merchant Txns</span>
          </div>
          <div className="text-base font-bold text-white mt-1">
            {formatIndianNumber(merchantTxnCount)}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">P2M Payments</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3 rounded-md font-mono">
          <div className="text-[10px] text-slate-400 flex items-center gap-1">
            <ArrowRightLeft className="w-3 h-3 text-indigo-400" />
            <span>UPI-Linked</span>
          </div>
          <div className="text-base font-bold text-white mt-1">
            {formatIndianNumber(upiLinkedTxnCount)}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Interoperable Bridge</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3 rounded-md font-mono">
          <div className="text-[10px] text-slate-400 flex items-center gap-1">
            <WifiOff className="w-3 h-3 text-rose-400" />
            <span>Offline Txns</span>
          </div>
          <div className="text-base font-bold text-white mt-1">
            {formatIndianNumber(offlineTxnCount)}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Dual-Offline NFC</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3 rounded-md font-mono">
          <div className="text-[10px] text-slate-400 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
            <span>Active FIs</span>
          </div>
          <div className="text-base font-bold text-white mt-1">
            {institutions.length} Banks / PSPs
          </div>
          <div className="text-[10px] text-emerald-400 mt-0.5">100% Operational</div>
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <MetricChart
          title="e₹ Circulation Velocity (Intraday in Cr)"
          subtitle="Total sovereign Central Bank money deployed across pilot banks"
          data={circulationSeries}
          type="area"
          color="amber"
          unit="Cr"
        />
        <MetricChart
          title="Transaction Throughput Volume (in Thousands)"
          subtitle="Combined P2P, P2M, and Interbank settlement velocity"
          data={volumeSeries}
          type="bar"
          color="emerald"
          unit="k"
        />
      </div>

      {/* Recent Activity Table Preview */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 font-mono">
        <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
          <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
            RECENT e₹ SOVEREIGN LEDGER SETTLEMENTS
          </h3>
          <span className="text-[10px] text-emerald-400">● LIVE FEED</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="text-[10px] text-slate-400 uppercase bg-slate-950 border-b border-slate-800">
              <tr>
                <th className="p-2.5">TXN Reference</th>
                <th className="p-2.5">Type & Channel</th>
                <th className="p-2.5">Originating Inst</th>
                <th className="p-2.5">Destination Inst</th>
                <th className="p-2.5 text-right">Amount</th>
                <th className="p-2.5 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {transactions.slice(0, 5).map((txn) => (
                <tr key={txn.id} className="hover:bg-slate-800/40">
                  <td className="p-2.5 font-bold text-amber-400">{txn.id}</td>
                  <td className="p-2.5">
                    <span className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-200 text-[10px]">
                      {txn.type}
                    </span>
                  </td>
                  <td className="p-2.5">{txn.sourceInstitution}</td>
                  <td className="p-2.5">{txn.destinationInstitution}</td>
                  <td className="p-2.5 text-right font-bold text-white">
                    {formatIndianRupee(txn.amount)}
                  </td>
                  <td className="p-2.5 text-center">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-700">
                      {txn.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
