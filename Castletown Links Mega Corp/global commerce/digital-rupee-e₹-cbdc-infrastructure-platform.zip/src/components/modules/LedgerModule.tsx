import React, { useState } from 'react';
import { useCBDCSimulation } from '../../simulation/SimulationContext';
import { formatIndianRupee } from '../../utils/formatters';
import { StatusBadge } from '../common/StatusBadge';
import { Database, Search, Filter, ShieldCheck } from 'lucide-react';

export const LedgerModule: React.FC = () => {
  const { transactions } = useCBDCSimulation();

  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedChannel, setSelectedChannel] = useState<string>('ALL');

  const filtered = transactions.filter((t) => {
    const matchesSearch =
      t.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.sourceInstitution.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.destinationInstitution.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.narration.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesChannel = selectedChannel === 'ALL' || t.channel === selectedChannel;
    return matchesSearch && matchesChannel;
  });

  return (
    <div className="space-y-6 font-mono">
      
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Database className="w-5 h-5 text-amber-400" />
            <span>DIGITAL RUPEE CENTRAL SOVEREIGN LEDGER</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Authoritative Append-Only Central Bank Record of All e₹ Issuances, Transfers & Redemptions
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-500" />
            <input
              type="text"
              placeholder="Search reference, bank, narration..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-slate-950 border border-slate-700 rounded pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:border-amber-500 outline-none w-64"
            />
          </div>

          <select
            value={selectedChannel}
            onChange={(e) => setSelectedChannel(e.target.value)}
            className="bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-xs text-amber-400 font-bold outline-none"
          >
            <option value="ALL">ALL CHANNELS</option>
            <option value="P2P_MOBILE">P2P MOBILE</option>
            <option value="P2M_QR">P2M QR</option>
            <option value="INTERBANK_RTGS">INTERBANK RTGS</option>
            <option value="OFFLINE_NFC">OFFLINE NFC</option>
            <option value="PROGRAMMABLE_ESCROW">PROGRAMMABLE ESCROW</option>
          </select>
        </div>
      </div>

      {/* Ledger Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
        <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
          <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
            AUTHORITATIVE CENTRAL LEDGER ENTRIES ({filtered.length})
          </h3>
          <span className="text-[10px] text-emerald-400 font-bold">● IMMUTABLE CRYPTOGRAPHIC VERIFICATION</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="text-[10px] text-slate-400 uppercase bg-slate-950 border-b border-slate-800">
              <tr>
                <th className="p-2.5">Ledger TXN Ref</th>
                <th className="p-2.5">Channel</th>
                <th className="p-2.5">Origin Institution</th>
                <th className="p-2.5">Destination Institution</th>
                <th className="p-2.5 text-right">Amount</th>
                <th className="p-2.5">Narration / Metadata</th>
                <th className="p-2.5 text-center">Status</th>
                <th className="p-2.5 text-right">Timestamp</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filtered.map((t) => (
                <tr key={t.id} className="hover:bg-slate-800/40">
                  <td className="p-2.5 font-bold text-amber-400">{t.id}</td>
                  <td className="p-2.5">
                    <span className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-200 text-[10px] font-bold">
                      {t.channel}
                    </span>
                  </td>
                  <td className="p-2.5 text-white">{t.sourceInstitution}</td>
                  <td className="p-2.5 text-white">{t.destinationInstitution}</td>
                  <td className="p-2.5 text-right font-bold text-emerald-400">{formatIndianRupee(t.amount)}</td>
                  <td className="p-2.5 text-slate-400">{t.narration}</td>
                  <td className="p-2.5 text-center">
                    <StatusBadge status={t.status} />
                  </td>
                  <td className="p-2.5 text-right text-slate-500">{t.timestamp}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
