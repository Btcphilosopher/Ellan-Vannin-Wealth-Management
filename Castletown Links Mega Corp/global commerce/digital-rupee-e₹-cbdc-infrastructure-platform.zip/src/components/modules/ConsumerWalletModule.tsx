import React, { useState } from 'react';
import { useCBDCSimulation } from '../../simulation/SimulationContext';
import { formatIndianRupee } from '../../utils/formatters';
import { QrCode, ArrowUpRight, ArrowDownLeft, Scan, RefreshCw, Landmark, Shield, CheckCircle2 } from 'lucide-react';

export const ConsumerWalletModule: React.FC = () => {
  const { wallets, sendWalletPayment } = useCBDCSimulation();
  const demoWallet = wallets[0] || {
    id: 'WLT-IND-1001',
    ownerName: 'Aarav Sharma',
    upiId: 'aarav.sharma@erupee',
    bankName: 'Bharat National Bank',
    balance: 28452.00,
  };

  const [activeTab, setActiveTab] = useState<'HISTORY' | 'PAY' | 'QR'>('HISTORY');
  const [recipient, setRecipient] = useState<string>('metrosupermarket@bnb.erupee');
  const [payAmount, setPayAmount] = useState<string>('860');
  const [payFeedback, setPayFeedback] = useState<string | null>(null);

  // Simulated recent transactions requested by prompt
  const recentTransactions = [
    { title: 'Bengaluru Metro Rail Payment', amount: 120, type: 'DEBIT', cat: 'Transit', date: 'Today, 14:40' },
    { title: 'Metro Kirana Grocery Store', amount: 860, type: 'DEBIT', cat: 'Retail', date: 'Today, 11:20' },
    { title: 'Barbeque Nation Restaurant', amount: 1240, type: 'DEBIT', cat: 'Dining', date: 'Yesterday, 20:15' },
    { title: 'Tata Croma Online Purchase', amount: 2850, type: 'DEBIT', cat: 'Electronics', date: '17 Sep, 16:30' },
    { title: 'BEST Electricity Utility Bill', amount: 1840, type: 'DEBIT', cat: 'Utilities', date: '15 Sep, 10:10' },
  ];

  const handleExecutePayment = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(payAmount);
    if (isNaN(amt) || amt <= 0) return;

    const res = sendWalletPayment({
      sourceWalletId: demoWallet.id,
      targetWalletIdOrUpi: recipient,
      amount: amt,
      narration: 'Retail Consumer App Payment',
    });

    if (res.success) {
      setPayFeedback(`✓ Payment Successful! ${res.message}`);
      setTimeout(() => {
        setPayFeedback(null);
        setActiveTab('HISTORY');
      }, 1500);
    } else {
      setPayFeedback(`❌ ${res.message}`);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      
      {/* Title */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2 font-sans">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span>CONSUMER e₹ WALLET INTERFACE SIMULATION</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Demonstrating e₹ Sovereign Token Wallet UI on End-User Devices
          </p>
        </div>
        <span className="text-xs font-mono text-amber-400 font-bold bg-amber-950 px-2.5 py-1 rounded border border-amber-800">
          SIMULATED MOBILE APP
        </span>
      </div>

      {/* Realistic Mobile Wallet Card Container */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-950 to-slate-900 border border-slate-800 rounded-2xl p-6 font-mono text-white shadow-2xl relative overflow-hidden">
        
        {/* Subtle Watermark */}
        <div className="absolute top-4 right-6 text-6xl font-extrabold text-slate-800/20 select-none pointer-events-none">
          e₹
        </div>

        {/* Card Top Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-amber-500/10 border border-amber-500/30 flex items-center justify-center font-bold text-amber-400 text-lg">
              e₹
            </div>
            <div>
              <h3 className="font-bold text-sm text-white">Digital Rupee</h3>
              <p className="text-[11px] text-slate-400">{demoWallet.bankName}</p>
            </div>
          </div>

          <div className="text-right text-[11px] text-slate-400">
            <span>UPI ID: </span>
            <span className="text-amber-300 font-bold">{demoWallet.upiId}</span>
          </div>
        </div>

        {/* Balance Display */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 mb-6 text-center space-y-1">
          <span className="text-xs text-slate-400 uppercase tracking-wider block">Available Sovereign e₹ Balance</span>
          <div className="text-3xl sm:text-4xl font-extrabold text-amber-400 tracking-tight font-mono">
            {formatIndianRupee(demoWallet.balance, true)}
          </div>
          <span className="text-[10px] text-emerald-400 block pt-1">
            ✓ Central Bank Money • Zero Intermediary Risk
          </span>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-4 gap-2 text-center text-xs mb-6">
          <button
            onClick={() => setActiveTab('PAY')}
            className="p-3 bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-amber-500/50 rounded-xl flex flex-col items-center gap-1.5 transition-all text-amber-300"
          >
            <ArrowUpRight className="w-5 h-5 text-amber-400" />
            <span className="font-bold">Send</span>
          </button>

          <button
            onClick={() => setActiveTab('QR')}
            className="p-3 bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-amber-500/50 rounded-xl flex flex-col items-center gap-1.5 transition-all text-emerald-300"
          >
            <ArrowDownLeft className="w-5 h-5 text-emerald-400" />
            <span className="font-bold">Receive</span>
          </button>

          <button
            onClick={() => setActiveTab('PAY')}
            className="p-3 bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-amber-500/50 rounded-xl flex flex-col items-center gap-1.5 transition-all text-sky-300"
          >
            <Scan className="w-5 h-5 text-sky-400" />
            <span className="font-bold">Scan & Pay</span>
          </button>

          <button
            onClick={() => setActiveTab('PAY')}
            className="p-3 bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-amber-500/50 rounded-xl flex flex-col items-center gap-1.5 transition-all text-purple-300"
          >
            <QrCode className="w-5 h-5 text-purple-400" />
            <span className="font-bold">Request</span>
          </button>
        </div>

        {/* Tab Content */}
        {activeTab === 'HISTORY' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs text-slate-400 border-b border-slate-800 pb-2">
              <span className="font-bold uppercase tracking-wider text-slate-300">Recent e₹ Transactions</span>
              <span>Live Ledger Sync</span>
            </div>

            <div className="space-y-2">
              {recentTransactions.map((t, idx) => (
                <div
                  key={idx}
                  className="p-3 bg-slate-900/60 border border-slate-800/80 rounded-lg flex items-center justify-between text-xs hover:bg-slate-900 transition-colors"
                >
                  <div className="space-y-0.5">
                    <div className="font-bold text-white">{t.title}</div>
                    <div className="text-[10px] text-slate-400">
                      {t.cat} • {t.date}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-rose-400">-{formatIndianRupee(t.amount)}</div>
                    <span className="text-[9px] text-emerald-400">Settled in e₹</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Pay Tab */}
        {activeTab === 'PAY' && (
          <form onSubmit={handleExecutePayment} className="space-y-4 pt-2">
            <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider">Execute e₹ Merchant / P2P Payment</h4>

            {payFeedback && (
              <div className="p-3 rounded bg-slate-950 border border-amber-500/40 text-amber-300 text-xs">
                {payFeedback}
              </div>
            )}

            <div>
              <label className="block text-xs text-slate-400 mb-1">Payee UPI VPA or Wallet ID</label>
              <input
                type="text"
                value={recipient}
                onChange={(e) => setRecipient(e.target.value)}
                required
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:border-amber-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1">Amount (₹ INR)</label>
              <input
                type="number"
                value={payAmount}
                onChange={(e) => setPayAmount(e.target.value)}
                required
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:border-amber-500 outline-none"
              />
            </div>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setActiveTab('HISTORY')}
                className="flex-1 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-bold"
              >
                Back
              </button>
              <button
                type="submit"
                className="flex-1 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-lg text-xs font-bold"
              >
                PAY NOW
              </button>
            </div>
          </form>
        )}

        {/* QR Tab */}
        {activeTab === 'QR' && (
          <div className="text-center py-4 space-y-3">
            <h4 className="text-xs font-bold text-emerald-400 uppercase">Your Personal e₹ QR Code</h4>
            <div className="w-40 h-40 mx-auto bg-white p-3 rounded-xl flex items-center justify-center shadow-lg">
              <QrCode className="w-32 h-32 text-slate-950" />
            </div>
            <div className="text-xs text-slate-300 font-bold">{demoWallet.upiId}</div>
            <button
              onClick={() => setActiveTab('HISTORY')}
              className="px-4 py-1.5 bg-slate-800 text-slate-300 rounded text-xs"
            >
              Back to Transactions
            </button>
          </div>
        )}

      </div>

    </div>
  );
};
