import React from 'react';
import { useCBDCSimulation } from '../../simulation/SimulationContext';
import { formatIndianRupee, formatCompactRupee, formatIndianNumber } from '../../utils/formatters';
import { StatusBadge } from '../common/StatusBadge';
import { Building, Shield, Activity, Cpu, CheckCircle2 } from 'lucide-react';

export const BankingNetworkModule: React.FC = () => {
  const { institutions } = useCBDCSimulation();

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Building className="w-5 h-5 text-amber-400" />
            <span>INDIAN PARTICIPATING BANKING NETWORK</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Commercial Banks & Non-Bank Payment Service Providers (PSPs) Participating in the e₹ Pilot
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs text-amber-400 bg-amber-950 px-3 py-1.5 rounded border border-amber-800">
          <Shield className="w-3.5 h-3.5" />
          <span>FICTIONAL SIMULATION INSTITUTION NETWORK</span>
        </div>
      </div>

      {/* Grid of Banks */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {institutions.map((inst) => (
          <div
            key={inst.id}
            className="bg-slate-900 border border-slate-800 rounded-xl p-5 font-mono space-y-4 hover:border-slate-700 transition-colors shadow-sm relative overflow-hidden"
          >
            {/* Header */}
            <div className="flex items-start justify-between gap-2 border-b border-slate-800 pb-3">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-white text-base">{inst.name}</h3>
                </div>
                <span className="text-[10px] text-amber-400/90 font-bold uppercase tracking-wider block mt-0.5">
                  {inst.type.replace(/_/g, ' ')} • {inst.code}
                </span>
              </div>
              <StatusBadge status={inst.apiHealth} />
            </div>

            {/* Fictional Banner */}
            <div className="bg-slate-950 text-[10px] text-slate-500 p-1.5 rounded text-center border border-slate-800">
              FICTIONAL SIMULATION INSTITUTION
            </div>

            {/* Data Grid */}
            <div className="space-y-2 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">e₹ Holding Balance:</span>
                <span className="font-bold text-emerald-400">{formatIndianRupee(inst.eRupeeBalance)}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Customer Wallets:</span>
                <span className="text-slate-200">{formatIndianNumber(inst.customerWalletsCount)}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Merchant Wallets:</span>
                <span className="text-slate-200">{formatIndianNumber(inst.merchantWalletsCount)}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Today's Transactions:</span>
                <span className="text-slate-200">{formatIndianNumber(inst.todayTransactionsCount)}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Net Settlement Position:</span>
                <span className={inst.settlementPosition >= 0 ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                  {inst.settlementPosition >= 0 ? '+' : ''}
                  {formatIndianRupee(inst.settlementPosition)}
                </span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Liquidity Buffer:</span>
                <span className="text-amber-300">{formatCompactRupee(inst.liquidityBuffer)}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-400">API Health Status:</span>
                <span className="text-emerald-400 flex items-center gap-1 font-bold">
                  <Activity className="w-3 h-3" />
                  <span>OPERATIONAL (12ms)</span>
                </span>
              </div>
            </div>

            {/* Footer */}
            <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-500">
              <span>Risk Index: {inst.riskScore}/100</span>
              <span className="text-amber-400">Central Ledger Connected</span>
            </div>
          </div>
        ))}
      </div>

    </div>
  );
};
