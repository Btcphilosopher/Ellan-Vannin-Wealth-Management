import React from 'react';
import { Server, Cpu, Database, HardDrive, ShieldCheck, CheckCircle2 } from 'lucide-react';

export const SystemOpsModule: React.FC = () => {
  const nodes = [
    { location: 'Mumbai primary DC', type: 'Primary Core Ledger', cpu: '28%', status: 'OPERATIONAL', ping: '2ms' },
    { location: 'Delhi disaster recovery DC', type: 'Hot Standby Ledger', cpu: '22%', status: 'OPERATIONAL', ping: '8ms' },
    { location: 'Bengaluru regional node', type: 'Southern Clearing Node', cpu: '34%', status: 'OPERATIONAL', ping: '12ms' },
    { location: 'Hyderabad regional node', type: 'Central Settlement Node', cpu: '19%', status: 'OPERATIONAL', ping: '11ms' },
    { location: 'Kolkata regional node', type: 'Eastern Clearing Node', cpu: '15%', status: 'OPERATIONAL', ping: '18ms' },
  ];

  return (
    <div className="space-y-6 font-mono">
      
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Server className="w-5 h-5 text-amber-400" />
            <span>INFRASTRUCTURE & SYSTEM OPERATIONS MONITOR</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Hardware Security Modules (HSM), Data Centre Clusters & Cryptographic Key Management
          </p>
        </div>

        <span className="text-xs font-bold text-emerald-400 bg-emerald-950 px-3 py-1.5 rounded border border-emerald-800">
          ● HSM ACTIVE & SECURE
        </span>
      </div>

      {/* Nodes Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
        <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider mb-3">
          NATIONAL DATA CENTRE & NODE TELEMETRY
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="text-[10px] text-slate-400 uppercase bg-slate-950 border-b border-slate-800">
              <tr>
                <th className="p-2.5">Node Location</th>
                <th className="p-2.5">Role / Subsystem</th>
                <th className="p-2.5">CPU Load</th>
                <th className="p-2.5 text-center">Status</th>
                <th className="p-2.5 text-right">Ping Latency</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {nodes.map((node, i) => (
                <tr key={i} className="hover:bg-slate-800/40">
                  <td className="p-2.5 font-bold text-white">{node.location}</td>
                  <td className="p-2.5 text-slate-400">{node.type}</td>
                  <td className="p-2.5 font-bold text-amber-400">{node.cpu}</td>
                  <td className="p-2.5 text-center">
                    <span className="px-2 py-0.5 bg-emerald-950 text-emerald-300 border border-emerald-800 rounded text-[10px] font-bold">
                      {node.status}
                    </span>
                  </td>
                  <td className="p-2.5 text-right text-emerald-400 font-bold">{node.ping}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
