import React, { useState } from 'react';
import { useCBDCSimulation } from '../../simulation/SimulationContext';
import { ShieldCheck, Search, Filter } from 'lucide-react';

export const AuditLogModule: React.FC = () => {
  const { auditEvents } = useCBDCSimulation();

  const [searchTerm, setSearchTerm] = useState<string>('');
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');

  const filtered = auditEvents.filter((event) => {
    const matchesSearch =
      (event.action || event.operation || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (event.performedBy || event.institution || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (event.details || event.resource || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      event.id.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesCategory = categoryFilter === 'ALL' || event.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="space-y-6 font-mono">
      
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-amber-400" />
            <span>CBDC SOVEREIGN AUDIT TRAIL & AUDIT LOGS</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Immutable Append-Only Audit Stream Recording Every Administrative, Issuance, and Settlement Operation
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-500" />
            <input
              type="text"
              placeholder="Search audit trail..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-slate-950 border border-slate-700 rounded pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:border-amber-500 outline-none w-56"
            />
          </div>

          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-xs text-amber-400 font-bold outline-none"
          >
            <option value="ALL">ALL CATEGORIES</option>
            <option value="ISSUANCE">ISSUANCE & REDEMPTION</option>
            <option value="PAYMENT">PAYMENT & TRANSFERS</option>
            <option value="FREEZE">FREEZE & COMPLIANCE</option>
            <option value="SETTLEMENT">INTERBANK SETTLEMENT</option>
            <option value="PROGRAMMABLE">PROGRAMMABLE RULES</option>
            <option value="SYSTEM">SYSTEM OPERATIONS</option>
          </select>
        </div>
      </div>

      {/* Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
        <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider mb-3">
          AUDIT EVENT STREAM ({filtered.length} RECORDS)
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="text-[10px] text-slate-400 uppercase bg-slate-950 border-b border-slate-800">
              <tr>
                <th className="p-2.5">Audit ID</th>
                <th className="p-2.5">Category</th>
                <th className="p-2.5">Action Executed</th>
                <th className="p-2.5">Operator / Authority</th>
                <th className="p-2.5">Details & Metadata</th>
                <th className="p-2.5 text-right">Timestamp</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filtered.map((event) => (
                <tr key={event.id} className="hover:bg-slate-800/40">
                  <td className="p-2.5 font-bold text-amber-400">{event.id}</td>
                  <td className="p-2.5">
                    <span className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-200 text-[10px] font-bold">
                      {event.category}
                    </span>
                  </td>
                  <td className="p-2.5 font-bold text-white">{event.action}</td>
                  <td className="p-2.5 text-slate-300">{event.performedBy}</td>
                  <td className="p-2.5 text-slate-400">{event.details}</td>
                  <td className="p-2.5 text-right text-slate-500">{event.timestamp}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
