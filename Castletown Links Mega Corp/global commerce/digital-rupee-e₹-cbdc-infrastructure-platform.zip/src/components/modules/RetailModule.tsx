import React, { useState } from 'react';
import { useCBDCSimulation } from '../../simulation/SimulationContext';
import { formatIndianRupee } from '../../utils/formatters';
import { StatusBadge } from '../common/StatusBadge';
import { Wallet as WalletIcon, ShieldAlert, Lock, Unlock, ArrowUpRight, Search, Filter } from 'lucide-react';
import { Wallet } from '../../types';

export const RetailModule: React.FC = () => {
  const { wallets, freezeWallet, unfreezeWallet, sendWalletPayment } = useCBDCSimulation();
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [filterType, setFilterType] = useState<'ALL' | 'RETAIL' | 'MERCHANT' | 'INSTITUTIONAL'>('ALL');
  const [selectedWallet, setSelectedWallet] = useState<Wallet | null>(wallets[0] || null);

  // Action modal state
  const [actionModal, setActionModal] = useState<'SEND' | 'PAY' | null>(null);
  const [targetId, setTargetId] = useState<string>('');
  const [payAmount, setPayAmount] = useState<string>('500');
  const [narration, setNarration] = useState<string>('Retail e₹ Payment');
  const [actionFeedback, setActionFeedback] = useState<string | null>(null);

  const filteredWallets = wallets.filter((w) => {
    const matchesSearch =
      w.ownerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      w.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (w.upiId && w.upiId.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesType = filterType === 'ALL' || w.type === filterType;
    return matchesSearch && matchesType;
  });

  const handleSendPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedWallet) return;
    setActionFeedback(null);

    const result = sendWalletPayment({
      sourceWalletId: selectedWallet.id,
      targetWalletIdOrUpi: targetId,
      amount: parseFloat(payAmount) || 0,
      narration,
    });

    if (result.success) {
      setActionFeedback(`✓ ${result.message}`);
      setTimeout(() => {
        setActionModal(null);
        setActionFeedback(null);
      }, 1500);
    } else {
      setActionFeedback(`❌ ${result.message}`);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <WalletIcon className="w-5 h-5 text-amber-400" />
            <span>RETAIL e₹ CBDC OPERATIONS</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Individual & Merchant Wallet Registry, P2P Transfers, P2M Payments & Compliance Freeze Controls
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-500" />
            <input
              type="text"
              placeholder="Search wallet, name, UPI ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-slate-950 border border-slate-700 rounded pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:border-amber-500 outline-none w-56"
            />
          </div>

          <div className="flex items-center bg-slate-950 rounded border border-slate-800 p-0.5">
            <button
              onClick={() => setFilterType('ALL')}
              className={`px-2 py-1 text-[11px] rounded ${filterType === 'ALL' ? 'bg-amber-600 text-white font-bold' : 'text-slate-400'}`}
            >
              ALL
            </button>
            <button
              onClick={() => setFilterType('RETAIL')}
              className={`px-2 py-1 text-[11px] rounded ${filterType === 'RETAIL' ? 'bg-amber-600 text-white font-bold' : 'text-slate-400'}`}
            >
              RETAIL
            </button>
            <button
              onClick={() => setFilterType('MERCHANT')}
              className={`px-2 py-1 text-[11px] rounded ${filterType === 'MERCHANT' ? 'bg-amber-600 text-white font-bold' : 'text-slate-400'}`}
            >
              MERCHANT
            </button>
          </div>
        </div>
      </div>

      {/* Main Grid: Wallets Table + Wallet Detail Inspector Drawer */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Table */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-4 font-mono">
          <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider mb-3">
            REGISTERED RETAIL & MERCHANT e₹ WALLETS ({filteredWallets.length})
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="text-[10px] text-slate-400 uppercase bg-slate-950 border-b border-slate-800">
                <tr>
                  <th className="p-2.5">Wallet ID</th>
                  <th className="p-2.5">Owner Name</th>
                  <th className="p-2.5">Issuing Bank</th>
                  <th className="p-2.5 text-right">Balance</th>
                  <th className="p-2.5 text-center">Status</th>
                  <th className="p-2.5 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredWallets.map((w) => {
                  const isSelected = selectedWallet?.id === w.id;
                  return (
                    <tr
                      key={w.id}
                      onClick={() => setSelectedWallet(w)}
                      className={`cursor-pointer transition-colors ${
                        isSelected ? 'bg-amber-950/40 border-l-2 border-amber-500' : 'hover:bg-slate-800/40'
                      }`}
                    >
                      <td className="p-2.5 font-bold text-amber-400">{w.id}</td>
                      <td className="p-2.5 font-medium text-white">{w.ownerName}</td>
                      <td className="p-2.5 text-slate-400">{w.bankName}</td>
                      <td className="p-2.5 text-right font-bold text-emerald-400">
                        {formatIndianRupee(w.balance, true)}
                      </td>
                      <td className="p-2.5 text-center">
                        <StatusBadge status={w.status} />
                      </td>
                      <td className="p-2.5 text-right">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedWallet(w);
                          }}
                          className="px-2 py-0.5 rounded text-[10px] bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700"
                        >
                          Inspect
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Detail Inspector Drawer */}
        {selectedWallet && (
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 font-mono space-y-4">
            <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
              <div>
                <span className="text-[10px] text-amber-400 font-bold uppercase">{selectedWallet.type} WALLET INSPECTOR</span>
                <h3 className="text-base font-bold text-white">{selectedWallet.ownerName}</h3>
              </div>
              <StatusBadge status={selectedWallet.status} />
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Wallet ID:</span>
                <span className="text-white font-bold">{selectedWallet.id}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">UPI VPA:</span>
                <span className="text-amber-300">{selectedWallet.upiId || 'N/A'}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Issuing Institution:</span>
                <span className="text-slate-200">{selectedWallet.bankName}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Total e₹ Balance:</span>
                <span className="text-emerald-400 font-bold text-sm">
                  {formatIndianRupee(selectedWallet.balance, true)}
                </span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Available Balance:</span>
                <span className="text-slate-200">{formatIndianRupee(selectedWallet.availableBalance, true)}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Held Amount:</span>
                <span className="text-rose-400">{formatIndianRupee(selectedWallet.heldAmount, true)}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">KYC Status:</span>
                <span className="text-emerald-400 font-bold">{selectedWallet.kycStatus}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Txn Count:</span>
                <span className="text-slate-200">{selectedWallet.transactionCount}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Risk Assessment:</span>
                <span className={selectedWallet.riskStatus === 'HIGH' ? 'text-rose-400 font-bold' : 'text-emerald-400'}>
                  {selectedWallet.riskStatus}
                </span>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="pt-2 border-t border-slate-800 space-y-2">
              <span className="text-[10px] text-slate-400 uppercase font-bold block">WALLET COMPLIANCE & PAYMENT ACTIONS</span>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => {
                    setActionModal('SEND');
                    setTargetId(wallets.find((w) => w.id !== selectedWallet.id)?.id || '');
                  }}
                  disabled={selectedWallet.status === 'FROZEN'}
                  className="py-1.5 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white font-bold rounded text-xs transition-colors flex items-center justify-center gap-1"
                >
                  <ArrowUpRight className="w-3.5 h-3.5" />
                  <span>SEND e₹</span>
                </button>

                {selectedWallet.status === 'FROZEN' ? (
                  <button
                    onClick={() => unfreezeWallet(selectedWallet.id)}
                    className="py-1.5 bg-emerald-700 hover:bg-emerald-600 text-white font-bold rounded text-xs transition-colors flex items-center justify-center gap-1"
                  >
                    <Unlock className="w-3.5 h-3.5" />
                    <span>UNFREEZE</span>
                  </button>
                ) : (
                  <button
                    onClick={() => freezeWallet(selectedWallet.id)}
                    className="py-1.5 bg-rose-900 hover:bg-rose-800 text-white font-bold rounded text-xs transition-colors flex items-center justify-center gap-1"
                  >
                    <Lock className="w-3.5 h-3.5" />
                    <span>FREEZE</span>
                  </button>
                )}
              </div>
            </div>

          </div>
        )}

      </div>

      {/* Modal for Send e₹ */}
      {actionModal && selectedWallet && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-lg p-6 max-w-md w-full font-mono space-y-4 shadow-2xl">
            <h3 className="text-base font-bold text-white border-b border-slate-800 pb-2">
              EXECUTE e₹ RETAIL TRANSFER
            </h3>

            {actionFeedback && (
              <div className="p-3 bg-slate-950 border border-amber-500/50 rounded text-amber-300 text-xs">
                {actionFeedback}
              </div>
            )}

            <form onSubmit={handleSendPayment} className="space-y-3">
              <div>
                <label className="block text-xs text-slate-400 mb-1">Source Wallet</label>
                <div className="p-2 bg-slate-950 border border-slate-800 rounded text-xs text-amber-400">
                  {selectedWallet.ownerName} ({selectedWallet.id}) — Bal: {formatIndianRupee(selectedWallet.balance)}
                </div>
              </div>

              <div>
                <label className="block text-xs text-slate-400 mb-1">Destination Wallet ID or UPI VPA</label>
                <input
                  type="text"
                  value={targetId}
                  onChange={(e) => setTargetId(e.target.value)}
                  placeholder="e.g. WLT-IND-1002 or priya.p@mcb.erupee"
                  required
                  className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-xs text-white focus:border-amber-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs text-slate-400 mb-1">Amount (₹ INR)</label>
                <input
                  type="number"
                  value={payAmount}
                  onChange={(e) => setPayAmount(e.target.value)}
                  required
                  className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-xs text-white focus:border-amber-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs text-slate-400 mb-1">Narration</label>
                <input
                  type="text"
                  value={narration}
                  onChange={(e) => setNarration(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-xs text-white focus:border-amber-500 outline-none"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setActionModal(null)}
                  className="flex-1 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs rounded font-bold"
                >
                  CANCEL
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-amber-600 hover:bg-amber-500 text-white text-xs rounded font-bold"
                >
                  CONFIRM TRANSFER
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
