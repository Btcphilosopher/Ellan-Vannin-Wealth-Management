import React, { useState } from 'react';
import { useCBDCSimulation } from '../../simulation/SimulationContext';
import { formatIndianRupee, formatCompactRupee, formatIndianNumber } from '../../utils/formatters';
import { Store, QrCode, CheckCircle2, ArrowRight, RefreshCw, CreditCard, Smartphone } from 'lucide-react';

export const MerchantModule: React.FC = () => {
  const { merchants, sendWalletPayment } = useCBDCSimulation();
  const [selectedMerchant, setSelectedMerchant] = useState(merchants[0]);

  // Terminal state
  const [terminalAmount, setTerminalAmount] = useState<string>('1850');
  const [terminalState, setTerminalState] = useState<'IDLE' | 'PROCESSING' | 'SUCCESS'>('IDLE');
  const [lastTxnId, setLastTxnId] = useState<string>('TXN-E-2048193');

  const handleSimulatePayment = () => {
    const amt = parseFloat(terminalAmount) || 1850;
    setTerminalState('PROCESSING');

    setTimeout(() => {
      const res = sendWalletPayment({
        sourceWalletId: 'WLT-IND-1001', // Aarav Sharma
        targetWalletIdOrUpi: selectedMerchant.upiId,
        amount: amt,
        narration: `Merchant POS Sale at ${selectedMerchant.businessName}`,
        channel: 'MERCHANT_POS',
      });

      if (res.transaction) {
        setLastTxnId(res.transaction.id);
      }
      setTerminalState('SUCCESS');
    }, 1200);
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Store className="w-5 h-5 text-amber-400" />
            <span>DIGITAL RUPEE MERCHANT NETWORK & POS TERMINAL</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Acceptance Infrastructure, Merchant Settlements & Real-Time Counter POS Payment Terminal Simulation
          </p>
        </div>

        <select
          value={selectedMerchant.id}
          onChange={(e) => {
            const m = merchants.find((x) => x.id === e.target.value);
            if (m) setSelectedMerchant(m);
          }}
          className="bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-xs text-amber-400 font-mono font-bold outline-none"
        >
          {merchants.map((m) => (
            <option key={m.id} value={m.id}>
              {m.businessName} ({m.location})
            </option>
          ))}
        </select>
      </div>

      {/* Merchant Dashboard KPI Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 font-mono">
        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-lg">
          <div className="text-[10px] text-slate-400 uppercase">Today's Sales</div>
          <div className="text-base font-bold text-emerald-400 mt-1">
            {formatIndianRupee(selectedMerchant.todaySales)}
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-lg">
          <div className="text-[10px] text-slate-400 uppercase">Transaction Count</div>
          <div className="text-base font-bold text-white mt-1">
            {formatIndianNumber(selectedMerchant.transactionCount)}
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-lg">
          <div className="text-[10px] text-slate-400 uppercase">Average Txn</div>
          <div className="text-base font-bold text-amber-400 mt-1">
            {formatIndianRupee(selectedMerchant.avgTxnValue)}
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-lg">
          <div className="text-[10px] text-slate-400 uppercase">Refunds</div>
          <div className="text-base font-bold text-slate-300 mt-1">₹0.00</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-lg">
          <div className="text-[10px] text-slate-400 uppercase">Pending Settlement</div>
          <div className="text-base font-bold text-amber-300 mt-1">
            {formatIndianRupee(selectedMerchant.pendingSettlement)}
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-lg">
          <div className="text-[10px] text-slate-400 uppercase">e₹ Wallet Balance</div>
          <div className="text-base font-bold text-emerald-400 mt-1">
            {formatIndianRupee(selectedMerchant.eRupeeBalance)}
          </div>
        </div>
      </div>

      {/* POS Terminal & Payment Route Simulator */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Terminal Screen Simulation */}
        <div className="bg-slate-950 border border-slate-800 rounded-xl p-6 font-mono text-center space-y-5 shadow-2xl relative">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <span className="text-xs text-slate-400 font-bold uppercase">{selectedMerchant.businessName} POS</span>
            <span className="text-[10px] text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800">
              ● POS TERMINAL ONLINE
            </span>
          </div>

          <div className="space-y-1">
            <h3 className="text-sm font-extrabold text-amber-400 uppercase tracking-widest">DIGITAL RUPEE</h3>
            <p className="text-xs text-slate-400">Accepting e₹ Sovereign Token & UPI Interoperable Payments</p>
          </div>

          {terminalState === 'IDLE' && (
            <div className="space-y-4 py-4 max-w-xs mx-auto">
              <div>
                <label className="block text-xs text-slate-400 mb-1">Enter Charge Amount (₹)</label>
                <input
                  type="number"
                  value={terminalAmount}
                  onChange={(e) => setTerminalAmount(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xl font-bold text-amber-400 text-center outline-none"
                />
              </div>

              <button
                onClick={handleSimulatePayment}
                className="w-full py-3 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-lg text-sm transition-colors shadow-lg"
              >
                GENERATE POS CHARGE (₹{terminalAmount})
              </button>
            </div>
          )}

          {terminalState === 'PROCESSING' && (
            <div className="py-8 space-y-3">
              <div className="w-12 h-12 border-4 border-amber-500 border-t-transparent rounded-full animate-spin mx-auto"></div>
              <div className="text-lg font-bold text-amber-400 animate-pulse">PROCESSING PAYMENT...</div>
              <div className="text-xs text-slate-400">Verifying e₹ Ledger & Initiating Merchant Settlement</div>
            </div>
          )}

          {terminalState === 'SUCCESS' && (
            <div className="py-6 space-y-4 bg-emerald-950/40 border border-emerald-500/30 rounded-xl p-5">
              <div className="w-12 h-12 bg-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto ring-4 ring-emerald-500/30">
                <CheckCircle2 className="w-8 h-8" />
              </div>

              <div>
                <div className="text-2xl font-extrabold text-white">PAYMENT SUCCESSFUL</div>
                <div className="text-2xl font-mono text-emerald-400 font-bold mt-1">
                  {formatIndianRupee(parseFloat(terminalAmount) || 1850)}
                </div>
              </div>

              <div className="text-xs text-slate-300 space-y-1 bg-slate-900/80 p-3 rounded border border-slate-800 text-left">
                <div className="flex justify-between">
                  <span className="text-slate-400">Transaction ID:</span>
                  <span className="text-amber-400 font-bold">{lastTxnId}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Merchant VPA:</span>
                  <span className="text-slate-200">{selectedMerchant.upiId}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Settlement State:</span>
                  <span className="text-emerald-400 font-bold">CLEAR & CREDITED</span>
                </div>
              </div>

              <button
                onClick={() => setTerminalState('IDLE')}
                className="px-6 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded font-bold text-xs"
              >
                NEW SALE
              </button>
            </div>
          )}
        </div>

        {/* Payment Route Diagram requested by prompt */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 font-mono space-y-4">
          <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider border-b border-slate-800 pb-2">
            PAYMENT ROUTING ARCHITECTURE
          </h3>

          <div className="space-y-3 text-xs">
            <div className="flex items-center justify-between bg-slate-950 p-3 rounded border border-slate-800">
              <div className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-amber-400" />
                <span className="font-bold text-white">e₹ Wallet (Customer)</span>
              </div>
              <span className="text-slate-400">Debited Sovereign Money</span>
            </div>

            <div className="flex justify-center text-amber-500 font-bold">↓</div>

            <div className="flex items-center justify-between bg-slate-950 p-3 rounded border border-slate-800">
              <div className="flex items-center gap-2">
                <Store className="w-4 h-4 text-emerald-400" />
                <span className="font-bold text-white">Merchant Acquiring Node</span>
              </div>
              <span className="text-slate-400">{selectedMerchant.businessName}</span>
            </div>

            <div className="flex justify-center text-amber-500 font-bold">↓</div>

            <div className="flex items-center justify-between bg-slate-950 p-3 rounded border border-slate-800">
              <div className="flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-sky-400" />
                <span className="font-bold text-white">Settlement Institution</span>
              </div>
              <span className="text-slate-400">{selectedMerchant.bankName}</span>
            </div>
          </div>

          <div className="text-[11px] text-slate-400 bg-slate-950 p-3 rounded border border-slate-800/80">
            e₹ P2M payments clear instantly on the central ledger, providing immediate merchant balance availability with zero merchant discount rate (MDR) drag.
          </div>
        </div>

      </div>

    </div>
  );
};
