import React from 'react';
import { Activity, Cpu, Database, Server, Wifi, ShieldCheck } from 'lucide-react';
import { MetricChart } from '../common/MetricChart';

export const NetworkOpsModule: React.FC = () => {
  const tpsSeries = [
    { label: '00:00', value: 4200 },
    { label: '04:00', value: 2800 },
    { label: '08:00', value: 9400 },
    { label: '12:00', value: 14820 },
    { label: '16:00', value: 12100 },
  ];

  return (
    <div className="space-y-6 font-mono">
      
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Activity className="w-5 h-5 text-amber-400" />
            <span>NATIONAL e₹ PAYMENT NETWORK OPERATIONS CENTRE (NOC)</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Real-Time Network Telemetry, Throughput TPS, Ledger Replication & Infrastructure Health
          </p>
        </div>

        <span className="text-xs font-bold text-emerald-400 bg-emerald-950 px-3 py-1.5 rounded border border-emerald-800">
          ● ALL SUBSYSTEMS HEALTHY
        </span>
      </div>

      {/* KPI Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg">
          <div className="text-slate-400 uppercase">Current Throughput</div>
          <div className="text-2xl font-bold text-emerald-400 mt-1">14,820 TPS</div>
          <div className="text-[10px] text-slate-500 mt-1">Peak: 100,000 TPS</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg">
          <div className="text-slate-400 uppercase">Average Latency</div>
          <div className="text-2xl font-bold text-amber-400 mt-1">12 ms</div>
          <div className="text-[10px] text-emerald-400 mt-1">Sub-second Finality</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg">
          <div className="text-slate-400 uppercase">System Uptime</div>
          <div className="text-2xl font-bold text-white mt-1">99.999%</div>
          <div className="text-[10px] text-slate-500 mt-1">Zero Downtime SLA</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg">
          <div className="text-slate-400 uppercase">Node Consensus Synchronization</div>
          <div className="text-2xl font-bold text-sky-400 mt-1">100% SYNCED</div>
          <div className="text-[10px] text-slate-500 mt-1">12 National Data Centres</div>
        </div>
      </div>

      {/* Throughput Chart */}
      <MetricChart
        title="Intraday Network Throughput (Transactions Per Second - TPS)"
        subtitle="Sovereign Ledger Transaction Traffic across All Channels"
        data={tpsSeries}
        type="area"
        color="emerald"
        unit="TPS"
      />

    </div>
  );
};
