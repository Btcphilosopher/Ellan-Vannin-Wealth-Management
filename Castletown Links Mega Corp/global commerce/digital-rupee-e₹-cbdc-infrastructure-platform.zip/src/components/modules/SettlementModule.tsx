import React from 'react';
import { useCBDCSimulation } from '../../simulation/SimulationContext';
import { formatIndianRupee, formatCompactRupee } from '../../utils/formatters';
import { StatusBadge } from '../common/StatusBadge';
import { CheckCircle2, RefreshCw, Activity, Layers, ShieldCheck, Zap } from 'lucide-react';

export const SettlementModule: React.FC = () => {
  const { settlementQueue, triggerSettlementBatch } = useCBDCSimulation();

  const activeQueue = settlementQueue.filter((s) => s.status === 'PROCESSING' || s.status === 'WAITING');
  const completedQueue = settlementQueue.filter((s) => s.status === 'COMPLETED');

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-amber-400" />
            <span>INTERBANK CLEARING & SETTLEMENT CENTRE</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Real-Time Gross Settlement (RTGS) & Net Intraday Clearing Pipeline for e₹ Central Bank Money
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="bg-slate-950 px-3 py-1.5 rounded border border-slate-800 text-xs font-mono">
            <span className="text-slate-400">Settlement Latency: </span>
            <span className="text-emerald-400 font-bold">42 ms</span>
          </div>

          <button
            onClick={() => triggerSettlementBatch()}
            className="px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white font-mono font-bold text-xs rounded transition-colors flex items-center gap-1.5"
          >
            <Zap className="w-3.5 h-3.5" />
            <span>FLUSH SETTLEMENT QUEUE ({activeQueue.length})</span>
          </button>
        </div>
      </div>

      {/* Processing Pipeline Flowchart requested by prompt */}
      <div className="bg-slate-950 border border-slate-800 p-5 rounded-lg font-mono">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">
          REAL-TIME INTERBANK SETTLEMENT PIPELINE STAGES
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2 text-center text-[11px]">
          <div className="bg-slate-900 border border-slate-800 p-2.5 rounded text-slate-200">
            <span className="text-[9px] text-slate-500 block">STAGE 1</span>
            <span className="font-bold">Transaction Received</span>
          </div>

          <div className="bg-slate-900 border border-slate-800 p-2.5 rounded text-slate-200">
            <span className="text-[9px] text-slate-500 block">STAGE 2</span>
            <span className="font-bold">Validation</span>
          </div>

          <div className="bg-slate-900 border border-slate-800 p-2.5 rounded text-slate-200">
            <span className="text-[9px] text-slate-500 block">STAGE 3</span>
            <span className="font-bold">Balance Check</span>
          </div>

          <div className="bg-slate-900 border border-slate-800 p-2.5 rounded text-slate-200">
            <span className="text-[9px] text-slate-500 block">STAGE 4</span>
            <span className="font-bold">Risk Check</span>
          </div>

          <div className="bg-slate-900 border border-amber-500/40 p-2.5 rounded text-amber-300">
            <span className="text-[9px] text-amber-500 block">STAGE 5</span>
            <span className="font-bold">Settlement</span>
          </div>

          <div className="bg-slate-900 border border-slate-800 p-2.5 rounded text-slate-200">
            <span className="text-[9px] text-slate-500 block">STAGE 6</span>
            <span className="font-bold">Ledger Update</span>
          </div>

          <div className="bg-emerald-950/80 border border-emerald-700/60 p-2.5 rounded text-emerald-300 font-bold">
            <span className="text-[9px] text-emerald-500 block">STAGE 7</span>
            <span>Completed</span>
          </div>
        </div>
      </div>

      {/* Live Queue Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 font-mono">
        <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
          <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
            LIVE INTERBANK SETTLEMENT QUEUE
          </h3>
          <span className="text-[10px] text-amber-400 font-bold">
            QUEUE DEPTH: {settlementQueue.length} TRANSACTIONS
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="text-[10px] text-slate-400 uppercase bg-slate-950 border-b border-slate-800">
              <tr>
                <th className="p-2.5">Settlement ID</th>
                <th className="p-2.5">TXN Reference</th>
                <th className="p-2.5">Originating Institution</th>
                <th className="p-2.5">Receiving Institution</th>
                <th className="p-2.5 text-right">Amount</th>
                <th className="p-2.5 text-center">Status</th>
                <th className="p-2.5 text-right">Latency</th>
                <th className="p-2.5 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {settlementQueue.map((item) => (
                <tr key={item.id} className="hover:bg-slate-800/40">
                  <td className="p-2.5 font-bold text-amber-400">{item.id}</td>
                  <td className="p-2.5 text-slate-400">{item.reference}</td>
                  <td className="p-2.5 font-medium text-white">{item.originatingInstitution}</td>
                  <td className="p-2.5 font-medium text-white">{item.receivingInstitution}</td>
                  <td className="p-2.5 text-right font-bold text-emerald-400">
                    {formatIndianRupee(item.amount)}
                  </td>
                  <td className="p-2.5 text-center">
                    <StatusBadge status={item.status} />
                  </td>
                  <td className="p-2.5 text-right text-slate-400">{item.latencyMs} ms</td>
                  <td className="p-2.5 text-right">
                    {item.status !== 'COMPLETED' && (
                      <button
                        onClick={() => triggerSettlementBatch(item.id)}
                        className="px-2 py-0.5 rounded text-[10px] bg-emerald-900 hover:bg-emerald-800 text-emerald-200 font-bold"
                      >
                        Clear Now
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
