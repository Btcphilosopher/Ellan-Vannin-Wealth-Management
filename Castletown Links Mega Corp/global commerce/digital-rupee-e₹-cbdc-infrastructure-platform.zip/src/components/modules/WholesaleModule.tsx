import React, { useState } from 'react';
import { useCBDCSimulation } from '../../simulation/SimulationContext';
import { formatIndianRupee, formatCompactRupee } from '../../utils/formatters';
import { StatusBadge } from '../common/StatusBadge';
import { Building2, ArrowRightLeft, ShieldCheck, CheckCircle2, LineChart } from 'lucide-react';

export const WholesaleModule: React.FC = () => {
  const { institutions, transactions, sendWalletPayment } = useCBDCSimulation();

  const [originInst, setOriginInst] = useState<string>(institutions[1]?.id || '');
  const [destInst, setDestInst] = useState<string>(institutions[2]?.id || '');
  const [amountStr, setAmountStr] = useState<string>('125000000'); // ₹12.5 Cr
  const [purposeStr, setPurposeStr] = useState<string>('Intraday Net Settlement Liquidity Buffer');
  const [feedback, setFeedback] = useState<string | null>(null);

  const totalWholesaleOutstanding = institutions.reduce((acc, i) => acc + i.eRupeeBalance, 0);
  const interbankTxns = transactions.filter((t) => t.type === 'INTERBANK');

  const handleInterbankTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    const amt = parseFloat(amountStr);
    if (isNaN(amt) || amt <= 0) return;

    const src = institutions.find((i) => i.id === originInst);
    const dst = institutions.find((i) => i.id === destInst);

    if (!src || !dst) return;

    const res = sendWalletPayment({
      sourceWalletId: src.id,
      targetWalletIdOrUpi: dst.id,
      amount: amt,
      narration: purposeStr,
      channel: 'INTERBANK_RTGS',
    });

    if (res.success) {
      setFeedback(`✓ Wholesale RTGS Settlement Complete: Transferred ${formatCompactRupee(amt)} from ${src.name} to ${dst.name}`);
    } else {
      setFeedback(`❌ ${res.message}`);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Building2 className="w-5 h-5 text-amber-400" />
            <span>WHOLESALE e₹ INSTITUTIONAL ENVIRONMENT</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Commercial Banks, Financial Institutions, Settlement Participants & Institutional Treasury Clearing
          </p>
        </div>

        <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-950 px-3 py-1.5 rounded border border-emerald-800">
          ● RTGS e₹ CLEARING ACTIVE
        </span>
      </div>

      {/* KPI Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 font-mono">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg">
          <div className="text-xs text-slate-400 uppercase">Wholesale e₹ Outstanding</div>
          <div className="text-xl font-bold text-white mt-1">{formatIndianRupee(totalWholesaleOutstanding)}</div>
          <div className="text-[10px] text-amber-400 mt-1">≈ {formatCompactRupee(totalWholesaleOutstanding)}</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg">
          <div className="text-xs text-slate-400 uppercase">Interbank Txn Volume</div>
          <div className="text-xl font-bold text-white mt-1">{interbankTxns.length + 1280} Txns</div>
          <div className="text-[10px] text-emerald-400 mt-1">100% Finalized</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg">
          <div className="text-xs text-slate-400 uppercase">Intraday Settlement Value</div>
          <div className="text-xl font-bold text-white mt-1">{formatIndianRupee(184500000000)}</div>
          <div className="text-[10px] text-sky-400 mt-1">₹18,450 Cr Gross</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg">
          <div className="text-xs text-slate-400 uppercase">Avg Settlement Latency</div>
          <div className="text-xl font-bold text-emerald-400 mt-1">38 ms</div>
          <div className="text-[10px] text-slate-500 mt-1">Sub-second finality</div>
        </div>
      </div>

      {/* Interbank Transfer Simulator */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 font-mono space-y-4">
        <h3 className="text-sm font-bold text-white border-b border-slate-800 pb-2 flex items-center gap-2">
          <ArrowRightLeft className="w-4 h-4 text-amber-400" />
          <span>INTERBANK WHOLESALE e₹ TRANSFER SIMULATOR</span>
        </h3>

        {feedback && (
          <div className="p-3 bg-slate-950 border border-amber-500/50 rounded text-amber-300 text-xs">
            {feedback}
          </div>
        )}

        <form onSubmit={handleInterbankTransfer} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
          <div>
            <label className="block text-slate-400 mb-1">Originating Bank</label>
            <select
              value={originInst}
              onChange={(e) => setOriginInst(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-white focus:border-amber-500 outline-none"
            >
              {institutions.map((i) => (
                <option key={i.id} value={i.id}>
                  {i.name} ({i.code})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-slate-400 mb-1">Receiving Bank</label>
            <select
              value={destInst}
              onChange={(e) => setDestInst(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-white focus:border-amber-500 outline-none"
            >
              {institutions.map((i) => (
                <option key={i.id} value={i.id}>
                  {i.name} ({i.code})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-slate-400 mb-1">Transfer Amount (₹)</label>
            <input
              type="number"
              value={amountStr}
              onChange={(e) => setAmountStr(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-white focus:border-amber-500 outline-none"
            />
          </div>

          <div className="flex items-end">
            <button
              type="submit"
              className="w-full py-2 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded transition-colors text-xs"
            >
              EXECUTE SETTLEMENT
            </button>
          </div>
        </form>
      </div>

      {/* Interbank Transactions Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 font-mono">
        <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider mb-3">
          INSTITUTIONAL SETTLEMENT LEDGER
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="text-[10px] text-slate-400 uppercase bg-slate-950 border-b border-slate-800">
              <tr>
                <th className="p-2.5">Reference ID</th>
                <th className="p-2.5">Originating Institution</th>
                <th className="p-2.5">Receiving Institution</th>
                <th className="p-2.5 text-right">Settlement Amount</th>
                <th className="p-2.5">Purpose / Narration</th>
                <th className="p-2.5 text-center">Status</th>
                <th className="p-2.5 text-right">Timestamp</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {interbankTxns.map((t) => (
                <tr key={t.id} className="hover:bg-slate-800/40">
                  <td className="p-2.5 font-bold text-amber-400">{t.id}</td>
                  <td className="p-2.5 text-white font-medium">{t.sourceInstitution}</td>
                  <td className="p-2.5 text-white font-medium">{t.destinationInstitution}</td>
                  <td className="p-2.5 text-right font-bold text-emerald-400">{formatIndianRupee(t.amount)}</td>
                  <td className="p-2.5 text-slate-400">{t.narration}</td>
                  <td className="p-2.5 text-center">
                    <StatusBadge status={t.status} />
                  </td>
                  <td className="p-2.5 text-right text-slate-500">{t.timestamp}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
