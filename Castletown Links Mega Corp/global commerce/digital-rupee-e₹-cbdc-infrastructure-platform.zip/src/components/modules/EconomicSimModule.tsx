import React, { useState, useEffect } from 'react';
import { useCBDCSimulation } from '../../simulation/SimulationContext';
import { formatIndianRupee, formatCompactRupee } from '../../utils/formatters';
import { MetricChart } from '../common/MetricChart';
import { Play, Pause, RotateCcw, Sliders, Activity, Zap } from 'lucide-react';

export const EconomicSimModule: React.FC = () => {
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [speed, setSpeed] = useState<number>(1);
  const [ticks, setTicks] = useState<number>(0);

  // Economic Parameters
  const [circulationBase, setCirculationBase] = useState<number>(184270); // Cr
  const [adoptionRate, setAdoptionRate] = useState<number>(24); // %
  const [cashSubstitution, setCashSubstitution] = useState<number>(18); // %
  const [depositMigration, setDepositMigration] = useState<number>(2.4); // %

  useEffect(() => {
    let timer: any;
    if (isRunning) {
      timer = setInterval(() => {
        setTicks((prev) => prev + 1);
        setCirculationBase((prev) => prev + (Math.random() * 50 - 20) * speed);
      }, 1000 / speed);
    }
    return () => clearInterval(timer);
  }, [isRunning, speed]);

  const simSeries = [
    { label: 'T-4', value: circulationBase - 400 },
    { label: 'T-3', value: circulationBase - 250 },
    { label: 'T-2', value: circulationBase - 100 },
    { label: 'T-1', value: circulationBase - 40 },
    { label: 'CURRENT', value: circulationBase },
  ];

  return (
    <div className="space-y-6 font-mono">
      
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Sliders className="w-5 h-5 text-amber-400" />
            <span>MACROECONOMIC e₹ SIMULATION & SCENARIO LAB</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Stress-Testing Deposit Disintermediation, Cash Substitution Velocity & Monetary Policy Transmission
          </p>
        </div>

        {/* Simulation Controls requested by prompt */}
        <div className="flex items-center gap-2">
          {!isRunning ? (
            <button
              onClick={() => setIsRunning(true)}
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded flex items-center gap-1.5"
            >
              <Play className="w-3.5 h-3.5" />
              <span>START SIMULATION</span>
            </button>
          ) : (
            <button
              onClick={() => setIsRunning(false)}
              className="px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs rounded flex items-center gap-1.5"
            >
              <Pause className="w-3.5 h-3.5" />
              <span>PAUSE</span>
            </button>
          )}

          <button
            onClick={() => {
              setIsRunning(false);
              setTicks(0);
              setCirculationBase(184270);
            }}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded flex items-center gap-1.5"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>RESET</span>
          </button>

          <select
            value={speed}
            onChange={(e) => setSpeed(parseInt(e.target.value))}
            className="bg-slate-950 border border-slate-700 rounded px-2 py-1.5 text-xs text-amber-400 font-bold outline-none"
          >
            <option value={1}>SPEED: 1x</option>
            <option value={10}>SPEED: 10x</option>
            <option value={100}>SPEED: 100x</option>
          </select>
        </div>
      </div>

      {/* Parameter Controls & Output Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Sliders */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
          <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider border-b border-slate-800 pb-2">
            MACROECONOMIC PARAMETER INPUTS
          </h3>

          <div className="space-y-4 text-xs">
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Wallet Adoption Rate</span>
                <span className="font-bold text-amber-400">{adoptionRate}%</span>
              </div>
              <input
                type="range"
                min="5"
                max="80"
                value={adoptionRate}
                onChange={(e) => setAdoptionRate(parseInt(e.target.value))}
                className="w-full accent-amber-500 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Physical Cash Substitution Ratio</span>
                <span className="font-bold text-emerald-400">{cashSubstitution}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="60"
                value={cashSubstitution}
                onChange={(e) => setCashSubstitution(parseInt(e.target.value))}
                className="w-full accent-emerald-500 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Bank Deposit Migration Rate</span>
                <span className="font-bold text-rose-400">{depositMigration}%</span>
              </div>
              <input
                type="range"
                min="0.1"
                max="10"
                step="0.1"
                value={depositMigration}
                onChange={(e) => setDepositMigration(parseFloat(e.target.value))}
                className="w-full accent-rose-500 cursor-pointer"
              />
            </div>
          </div>

          <div className="p-3 bg-slate-950 border border-slate-800 rounded text-[11px] text-slate-400">
            Simulated tick count: <span className="font-bold text-white">{ticks}</span>. Central bank tier-2 holding caps mitigate deposit migration stress.
          </div>
        </div>

        {/* Chart & Results */}
        <div className="lg:col-span-2 space-y-4">
          <MetricChart
            title="Projected e₹ Circulation Trajectory (in Cr)"
            subtitle="Simulated real-time money velocity under current parameter configuration"
            data={simSeries}
            type="area"
            color="amber"
            unit="Cr"
          />

          <div className="grid grid-cols-3 gap-3 text-xs bg-slate-900 border border-slate-800 p-4 rounded-lg">
            <div>
              <span className="text-slate-400 text-[10px] uppercase block">Bank Deposit Impact</span>
              <span className="font-bold text-rose-400 text-sm">-₹{(depositMigration * 1800).toFixed(0)} Cr</span>
            </div>
            <div>
              <span className="text-slate-400 text-[10px] uppercase block">Physical Currency Reduced</span>
              <span className="font-bold text-emerald-400 text-sm">-₹{(cashSubstitution * 2400).toFixed(0)} Cr</span>
            </div>
            <div>
              <span className="text-slate-400 text-[10px] uppercase block">Seigniorage Cost Saved</span>
              <span className="font-bold text-amber-400 text-sm">₹1,840 Cr / yr</span>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
