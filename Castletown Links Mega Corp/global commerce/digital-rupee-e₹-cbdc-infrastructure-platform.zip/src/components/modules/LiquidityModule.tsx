import React from 'react';
import { useCBDCSimulation } from '../../simulation/SimulationContext';
import { formatIndianRupee, formatCompactRupee } from '../../utils/formatters';
import { MetricChart } from '../common/MetricChart';
import { TrendingUp, Landmark, ShieldCheck, Activity } from 'lucide-react';

export const LiquidityModule: React.FC = () => {
  const { institutions } = useCBDCSimulation();

  const totalLiquidity = institutions.reduce((acc, i) => acc + i.eRupeeBalance + i.liquidityBuffer, 0);

  const liquidityData = [
    { label: 'BNB', value: 38000 },
    { label: 'MCB', value: 24500 },
    { label: 'DEC', value: 18200 },
    { label: 'GNG', value: 14000 },
    { label: 'WIB', value: 11500 },
    { label: 'SOU', value: 9800 },
  ];

  return (
    <div className="space-y-6 font-mono">
      
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-amber-400" />
            <span>CENTRAL BANK & PARTICIPANT LIQUIDITY MANAGEMENT</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Intraday e₹ Liquidity Reserves, Net Settlement Demand & System-Wide Collateral Monitoring
          </p>
        </div>

        <span className="text-xs font-bold text-emerald-400 bg-emerald-950 px-3 py-1.5 rounded border border-emerald-800">
          ● LIQUIDITY RATIO: OPTIMAL (142%)
        </span>
      </div>

      {/* KPI Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg">
          <div className="text-xs text-slate-400 uppercase">System Liquidity Pool</div>
          <div className="text-xl font-bold text-white mt-1">{formatIndianRupee(totalLiquidity)}</div>
          <div className="text-[10px] text-amber-400 mt-1">≈ {formatCompactRupee(totalLiquidity)}</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg">
          <div className="text-xs text-slate-400 uppercase">Intraday Settlement Demand</div>
          <div className="text-xl font-bold text-white mt-1">{formatIndianRupee(38500000000)}</div>
          <div className="text-[10px] text-emerald-400 mt-1">100% Covered</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg">
          <div className="text-xs text-slate-400 uppercase">Standing e₹ Facility</div>
          <div className="text-xl font-bold text-white mt-1">{formatIndianRupee(50000000000)}</div>
          <div className="text-[10px] text-sky-400 mt-1">Central Bank Facility</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg">
          <div className="text-xs text-slate-400 uppercase">Interbank Net Grid Stress</div>
          <div className="text-xl font-bold text-emerald-400 mt-1">LOW (0.04)</div>
          <div className="text-[10px] text-slate-500 mt-1">No Bottlenecks</div>
        </div>
      </div>

      {/* Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <MetricChart
          title="Participant Bank Liquidity Distribution (in Crore)"
          subtitle="e₹ Holdings & Collateral Buffers across pilot institutions"
          data={liquidityData}
          type="bar"
          color="emerald"
          unit="Cr"
        />

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-3">
          <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider border-b border-slate-800 pb-2">
            INSTITUTIONAL LIQUIDITY POSITION BREAKDOWN
          </h3>

          <div className="space-y-2 text-xs">
            {institutions.map((i) => (
              <div key={i.id} className="flex items-center justify-between p-2 bg-slate-950 rounded border border-slate-800">
                <div>
                  <div className="font-bold text-white">{i.name}</div>
                  <div className="text-[10px] text-slate-400">Buffer: {formatCompactRupee(i.liquidityBuffer)}</div>
                </div>
                <div className="text-right font-bold text-emerald-400">
                  {formatIndianRupee(i.eRupeeBalance)}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

    </div>
  );
};
