import React, { useState } from 'react';
import { useCBDCSimulation } from '../../simulation/SimulationContext';
import { formatIndianRupee } from '../../utils/formatters';
import { Wifi, WifiOff, Smartphone, ShieldCheck, CheckCircle2, RefreshCw, AlertTriangle } from 'lucide-react';

export const OfflineModule: React.FC = () => {
  const { offlineTxnBuffer, toggleNetworkStatus, executeOfflineTxn, syncOfflineTxns, isNetworkOnline } =
    useCBDCSimulation();

  const [payeeId, setPayeeId] = useState<string>('WLT-IND-1002');
  const [payAmount, setPayAmount] = useState<string>('350');
  const [offlineFeedback, setOfflineFeedback] = useState<string | null>(null);

  const handleTapAndPay = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(payAmount) || 350;

    const res = executeOfflineTxn({
      payerId: 'WLT-IND-1001',
      payeeId,
      amount: amt,
    });

    if (res.success) {
      setOfflineFeedback(`✓ Offline NFC Tap-and-Pay Complete! Stored in Secure Device Vault.`);
    } else {
      setOfflineFeedback(`❌ Offline Failure: ${res.message}`);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <WifiOff className="w-5 h-5 text-amber-400" />
            <span>OFFLINE e₹ & DUAL-OFFLINE PAYMENT ENVIRONMENT</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Proximity NFC & Secure Element Offline Value Transfer in Zero-Connectivity Zones
          </p>
        </div>

        {/* Network Toggle Button */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => toggleNetworkStatus()}
            className={`px-4 py-2 font-mono font-bold text-xs rounded border transition-all flex items-center gap-2 ${
              isNetworkOnline
                ? 'bg-emerald-950 text-emerald-300 border-emerald-700'
                : 'bg-rose-950 text-rose-300 border-rose-700 animate-pulse'
            }`}
          >
            {isNetworkOnline ? <Wifi className="w-4 h-4 text-emerald-400" /> : <WifiOff className="w-4 h-4 text-rose-400" />}
            <span>NETWORK STATUS: {isNetworkOnline ? 'ONLINE' : 'OFFLINE (ZERO CON)'}</span>
          </button>
        </div>
      </div>

      {/* Offline Architecture Flowchart requested by prompt */}
      <div className="bg-slate-950 border border-slate-800 p-5 rounded-lg font-mono">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">
          DUAL-OFFLINE SECURE ELEMENT PROTOCOL
        </h3>

        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-2 text-center text-[10px]">
          <div className="bg-slate-900 border border-slate-800 p-2 rounded">
            <span className="text-amber-400 font-bold block">1. DEVICE</span>
            <span>Mobile NFC</span>
          </div>
          <div className="bg-slate-900 border border-slate-800 p-2 rounded">
            <span className="text-amber-400 font-bold block">2. VAULT</span>
            <span>Secure Element</span>
          </div>
          <div className="bg-slate-900 border border-slate-800 p-2 rounded">
            <span className="text-amber-400 font-bold block">3. PROXIMITY</span>
            <span>Local NFC Tap</span>
          </div>
          <div className="bg-slate-900 border border-slate-800 p-2 rounded">
            <span className="text-amber-400 font-bold block">4. SIGNATURE</span>
            <span>Device Key</span>
          </div>
          <div className="bg-slate-900 border border-slate-800 p-2 rounded">
            <span className="text-amber-400 font-bold block">5. BUFFER</span>
            <span>Local Storage</span>
          </div>
          <div className="bg-slate-900 border border-slate-800 p-2 rounded">
            <span className="text-amber-400 font-bold block">6. RESTORE</span>
            <span>Net Re-connect</span>
          </div>
          <div className="bg-slate-900 border border-slate-800 p-2 rounded">
            <span className="text-amber-400 font-bold block">7. SYNC</span>
            <span>Reconciliation</span>
          </div>
          <div className="bg-emerald-950 border border-emerald-700 p-2 rounded text-emerald-300 font-bold">
            <span>8. SETTLE</span>
            <span>Ledger Final</span>
          </div>
        </div>
      </div>

      {/* Offline Tap and Pay Terminal */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Executor */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 font-mono space-y-4">
          <h3 className="text-sm font-bold text-white border-b border-slate-800 pb-2 flex items-center justify-between">
            <span>PROXIMITY DUAL-OFFLINE TERMINAL SIMULATOR</span>
            <span className="text-xs text-amber-400 font-bold">OFFLINE LIMIT: ₹10,000</span>
          </h3>

          {offlineFeedback && (
            <div className="p-3 bg-slate-950 border border-amber-500/50 rounded text-amber-300 text-xs">
              {offlineFeedback}
            </div>
          )}

          <form onSubmit={handleTapAndPay} className="space-y-3 text-xs">
            <div>
              <label className="block text-slate-400 mb-1">Payee Wallet ID</label>
              <input
                type="text"
                value={payeeId}
                onChange={(e) => setPayeeId(e.target.value)}
                required
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-white outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1">Amount (₹ INR)</label>
              <input
                type="number"
                value={payAmount}
                onChange={(e) => setPayAmount(e.target.value)}
                required
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-white outline-none focus:border-amber-500"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded transition-colors flex items-center justify-center gap-2"
            >
              <Smartphone className="w-4 h-4" />
              <span>TAP & PAY (OFFLINE NFC TRANSFER)</span>
            </button>
          </form>
        </div>

        {/* Sync Controls & Buffer */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 font-mono space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h3 className="text-sm font-bold text-white">DEVICE LOCAL BUFFER ({offlineTxnBuffer.length})</h3>
            <button
              onClick={() => syncOfflineTxns()}
              disabled={!isNetworkOnline || offlineTxnBuffer.length === 0}
              className="px-3 py-1 bg-emerald-700 hover:bg-emerald-600 disabled:opacity-40 text-white font-bold text-xs rounded transition-colors flex items-center gap-1.5"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>SYNC TO CENTRAL LEDGER</span>
            </button>
          </div>

          <div className="space-y-2 max-h-60 overflow-y-auto">
            {offlineTxnBuffer.length === 0 ? (
              <div className="text-xs text-slate-500 text-center py-6">
                Local offline buffer empty. Perform tap-and-pay transactions above.
              </div>
            ) : (
              offlineTxnBuffer.map((item: any) => (
                <div
                  key={item.id}
                  className="p-2.5 bg-slate-950 border border-slate-800 rounded flex items-center justify-between text-xs"
                >
                  <div>
                    <div className="font-bold text-amber-400">{item.id}</div>
                    <div className="text-[10px] text-slate-400">
                      {item.payerId} → {item.payeeId}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-emerald-400">{formatIndianRupee(item.amount)}</div>
                    <span className="text-[9px] text-amber-300 font-bold">UNSYNCED LOCAL</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

      </div>

    </div>
  );
};
