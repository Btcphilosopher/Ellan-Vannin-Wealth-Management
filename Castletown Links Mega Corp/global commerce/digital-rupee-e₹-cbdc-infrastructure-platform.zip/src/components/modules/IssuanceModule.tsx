import React, { useState } from 'react';
import { useCBDCSimulation } from '../../simulation/SimulationContext';
import { formatIndianRupee, formatCompactRupee } from '../../utils/formatters';
import { StatusBadge } from '../common/StatusBadge';
import { Coins, ArrowDownRight, RefreshCw, CheckCircle2, ShieldCheck, Landmark, Building } from 'lucide-react';

export const IssuanceModule: React.FC = () => {
  const { institutions, issuanceBatches, issueERupee, redeemERupee, auditEvents } = useCBDCSimulation();

  // Active tab
  const [activeSubTab, setActiveSubTab] = useState<'ISSUANCE' | 'REDEMPTION' | 'BATCHES' | 'BALANCES'>('ISSUANCE');

  // Form states
  const [selectedInstId, setSelectedInstId] = useState<string>(institutions[1]?.id || '');
  const [amountInput, setAmountInput] = useState<string>('5000000000'); // ₹500 Cr default
  const [purposeInput, setPurposeInput] = useState<string>('Retail Pilot Liquidity Allocation Phase IV');
  const [accountInput, setAccountInput] = useState<string>('RBI-RTGS-ACCT-BNB-01');
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const selectedInst = institutions.find((i) => i.id === selectedInstId) || institutions[1];

  const handleExecuteIssuance = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    const amt = parseFloat(amountInput);
    if (isNaN(amt) || amt <= 0) {
      setFeedback({ type: 'error', message: 'Please enter a valid numeric issuance amount.' });
      return;
    }

    const result = issueERupee({
      institutionId: selectedInstId,
      amount: amt,
      purpose: purposeInput,
      settlementAccount: accountInput,
    });

    if (result.success) {
      setFeedback({ type: 'success', message: result.message });
    } else {
      setFeedback({ type: 'error', message: result.message });
    }
  };

  const handleExecuteRedemption = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    const amt = parseFloat(amountInput);
    if (isNaN(amt) || amt <= 0) {
      setFeedback({ type: 'error', message: 'Please enter a valid numeric redemption amount.' });
      return;
    }

    const result = redeemERupee({
      institutionId: selectedInstId,
      amount: amt,
      purpose: purposeInput,
    });

    if (result.success) {
      setFeedback({ type: 'success', message: result.message });
    } else {
      setFeedback({ type: 'error', message: result.message });
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Coins className="w-5 h-5 text-amber-400" />
            <span>e₹ ISSUANCE & REDEMPTION ENGINE</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Central Bank Sovereign Money Creation, Distribution to Pilot Institutions & Token Lifecycle Management
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <button
            onClick={() => setActiveSubTab('ISSUANCE')}
            className={`px-3 py-1.5 rounded border transition-colors ${
              activeSubTab === 'ISSUANCE'
                ? 'bg-amber-600 text-white border-amber-500 font-bold'
                : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
            }`}
          >
            e₹ ISSUANCE
          </button>
          <button
            onClick={() => setActiveSubTab('REDEMPTION')}
            className={`px-3 py-1.5 rounded border transition-colors ${
              activeSubTab === 'REDEMPTION'
                ? 'bg-amber-600 text-white border-amber-500 font-bold'
                : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
            }`}
          >
            REDEMPTION
          </button>
          <button
            onClick={() => setActiveSubTab('BATCHES')}
            className={`px-3 py-1.5 rounded border transition-colors ${
              activeSubTab === 'BATCHES'
                ? 'bg-amber-600 text-white border-amber-500 font-bold'
                : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
            }`}
          >
            BATCHES
          </button>
          <button
            onClick={() => setActiveSubTab('BALANCES')}
            className={`px-3 py-1.5 rounded border transition-colors ${
              activeSubTab === 'BALANCES'
                ? 'bg-amber-600 text-white border-amber-500 font-bold'
                : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
            }`}
          >
            INSTITUTION BALANCES
          </button>
        </div>
      </div>

      {/* Sovereign Lifecycle Flowchart */}
      <div className="bg-slate-950 border border-slate-800 p-4 rounded-lg font-mono">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">
          SOVEREIGN e₹ TOKEN LIFECYCLE PIPELINE
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-2 text-center text-[11px]">
          <div className="bg-slate-900 border border-amber-500/40 p-2.5 rounded text-amber-300 font-semibold flex flex-col items-center">
            <Landmark className="w-4 h-4 mb-1 text-amber-400" />
            <span>CENTRAL BANK</span>
            <span className="text-[9px] text-slate-400">Sovereign Issuer</span>
          </div>

          <div className="flex items-center justify-center text-slate-600 font-bold">↓</div>

          <div className="bg-slate-900 border border-slate-700 p-2.5 rounded text-slate-200 font-semibold flex flex-col items-center">
            <Coins className="w-4 h-4 mb-1 text-emerald-400" />
            <span>e₹ ISSUANCE</span>
            <span className="text-[9px] text-slate-400">Mint & Credit</span>
          </div>

          <div className="flex items-center justify-center text-slate-600 font-bold">↓</div>

          <div className="bg-slate-900 border border-slate-700 p-2.5 rounded text-slate-200 font-semibold flex flex-col items-center">
            <Building className="w-4 h-4 mb-1 text-sky-400" />
            <span>COMMERCIAL BANK</span>
            <span className="text-[9px] text-slate-400">Treasury Account</span>
          </div>

          <div className="flex items-center justify-center text-slate-600 font-bold">↓</div>

          <div className="bg-slate-900 border border-slate-700 p-2.5 rounded text-slate-200 font-semibold flex flex-col items-center">
            <CheckCircle2 className="w-4 h-4 mb-1 text-emerald-400" />
            <span>CUSTOMER WALLET</span>
            <span className="text-[9px] text-slate-400">Retail & P2M</span>
          </div>
        </div>
      </div>

      {/* Simulator Section */}
      {(activeSubTab === 'ISSUANCE' || activeSubTab === 'REDEMPTION') && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Interactive Form */}
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 font-mono space-y-4">
            <h3 className="text-sm font-bold text-white border-b border-slate-800 pb-2 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-amber-400" />
              <span>
                {activeSubTab === 'ISSUANCE' ? 'NEW e₹ ISSUANCE REQUEST' : 'REDEMPTION REQUEST'}
              </span>
            </h3>

            {feedback && (
              <div
                className={`p-3 rounded border text-xs font-sans ${
                  feedback.type === 'success'
                    ? 'bg-emerald-950 text-emerald-200 border-emerald-700'
                    : 'bg-rose-950 text-rose-200 border-rose-700'
                }`}
              >
                {feedback.message}
              </div>
            )}

            <form onSubmit={activeSubTab === 'ISSUANCE' ? handleExecuteIssuance : handleExecuteRedemption} className="space-y-4">
              <div>
                <label className="block text-xs text-slate-400 mb-1">Target Financial Institution</label>
                <select
                  value={selectedInstId}
                  onChange={(e) => setSelectedInstId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-xs text-white focus:border-amber-500 outline-none"
                >
                  {institutions
                    .filter((i) => i.code !== 'RBDC')
                    .map((inst) => (
                      <option key={inst.id} value={inst.id}>
                        {inst.name} ({inst.code}) — Bal: {formatCompactRupee(inst.eRupeeBalance)}
                      </option>
                    ))}
                </select>
              </div>

              <div>
                <label className="block text-xs text-slate-400 mb-1">Amount (in ₹ INR)</label>
                <input
                  type="number"
                  value={amountInput}
                  onChange={(e) => setAmountInput(e.target.value)}
                  placeholder="e.g. 5000000000"
                  className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-xs text-white focus:border-amber-500 outline-none"
                />
                <span className="text-[10px] text-amber-400 mt-1 block">
                  Format: {formatIndianRupee(parseFloat(amountInput) || 0)} ({formatCompactRupee(parseFloat(amountInput) || 0)})
                </span>
              </div>

              <div>
                <label className="block text-xs text-slate-400 mb-1">Purpose / Regulatory Reference</label>
                <input
                  type="text"
                  value={purposeInput}
                  onChange={(e) => setPurposeInput(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-xs text-white focus:border-amber-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs text-slate-400 mb-1">Central Bank Settlement Account</label>
                <input
                  type="text"
                  value={accountInput}
                  onChange={(e) => setAccountInput(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-xs text-white focus:border-amber-500 outline-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs rounded transition-colors flex items-center justify-center gap-2 shadow"
              >
                <Coins className="w-4 h-4" />
                <span>
                  {activeSubTab === 'ISSUANCE' ? 'EXECUTE SOVEREIGN e₹ ISSUANCE' : 'EXECUTE REDEMPTION'}
                </span>
              </button>
            </form>
          </div>

          {/* Live Projection Box */}
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 font-mono space-y-4">
            <h3 className="text-sm font-bold text-slate-200 border-b border-slate-800 pb-2">
              REAL-TIME SIMULATION OUTPUT PROJECTION
            </h3>

            <div className="bg-slate-950 border border-slate-800 p-4 rounded-md space-y-3 text-xs">
              <div className="flex justify-between border-b border-slate-800/80 pb-2">
                <span className="text-slate-400">Institution:</span>
                <span className="text-white font-bold">{selectedInst?.name}</span>
              </div>
              <div className="flex justify-between border-b border-slate-800/80 pb-2">
                <span className="text-slate-400">Previous e₹ Balance:</span>
                <span className="text-slate-300">{formatIndianRupee(selectedInst?.eRupeeBalance || 0)}</span>
              </div>
              <div className="flex justify-between border-b border-slate-800/80 pb-2">
                <span className="text-slate-400">
                  {activeSubTab === 'ISSUANCE' ? 'Amount to Issue:' : 'Amount to Redeem:'}
                </span>
                <span className="text-amber-400 font-bold">
                  {formatIndianRupee(parseFloat(amountInput) || 0)}
                </span>
              </div>
              <div className="flex justify-between border-b border-slate-800/80 pb-2">
                <span className="text-slate-400">Projected New Balance:</span>
                <span className="text-emerald-400 font-bold">
                  {formatIndianRupee(
                    (selectedInst?.eRupeeBalance || 0) +
                      (activeSubTab === 'ISSUANCE' ? parseFloat(amountInput) || 0 : -(parseFloat(amountInput) || 0))
                  )}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Central Bank Audit State:</span>
                <span className="text-emerald-400">VERIFIED & SIGNED</span>
              </div>
            </div>

            <div className="text-[11px] text-slate-500 bg-slate-950/60 p-3 rounded border border-slate-800">
              Note: Central bank issuance increases sovereign money supply in e₹ circulation, crediting the participant bank's RTGS settlement account directly.
            </div>
          </div>
        </div>
      )}

      {/* Batches Table */}
      {(activeSubTab === 'BATCHES' || activeSubTab === 'ISSUANCE') && (
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 font-mono">
          <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider mb-3">
            COMPLETED CENTRAL BANK ISSUANCE BATCHES
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="text-[10px] text-slate-400 uppercase bg-slate-950 border-b border-slate-800">
                <tr>
                  <th className="p-2.5">Batch ID</th>
                  <th className="p-2.5">Date & Time</th>
                  <th className="p-2.5">Participant Institution</th>
                  <th className="p-2.5 text-right">Issued Amount</th>
                  <th className="p-2.5">Purpose</th>
                  <th className="p-2.5 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {issuanceBatches.map((batch) => (
                  <tr key={batch.id} className="hover:bg-slate-800/40">
                    <td className="p-2.5 font-bold text-amber-400">{batch.id}</td>
                    <td className="p-2.5 text-slate-400">{batch.timestamp}</td>
                    <td className="p-2.5 font-medium text-white">{batch.institutionName}</td>
                    <td className="p-2.5 text-right font-bold text-emerald-400">
                      {formatIndianRupee(batch.amount)}
                    </td>
                    <td className="p-2.5 text-slate-400">{batch.purpose}</td>
                    <td className="p-2.5 text-center">
                      <StatusBadge status={batch.processingStatus} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Institution Balances */}
      {activeSubTab === 'BALANCES' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {institutions.map((inst) => (
            <div key={inst.id} className="bg-slate-900 border border-slate-800 p-4 rounded-lg font-mono space-y-2">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="font-bold text-white text-sm">{inst.name}</span>
                <span className="text-xs text-amber-400 font-bold bg-amber-950 px-2 py-0.5 rounded border border-amber-800">
                  {inst.code}
                </span>
              </div>

              <div className="text-xs space-y-1.5 pt-1">
                <div className="flex justify-between">
                  <span className="text-slate-400">e₹ Holding:</span>
                  <span className="font-bold text-emerald-400">{formatIndianRupee(inst.eRupeeBalance)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Liquidity Buffer:</span>
                  <span className="text-slate-300">{formatCompactRupee(inst.liquidityBuffer)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Active Wallets:</span>
                  <span className="text-slate-300">{inst.customerWalletsCount.toLocaleString('en-IN')}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

    </div>
  );
};
