import React from 'react';
import { Cpu, Database, ShieldCheck, Layers, Landmark, Building, Smartphone, ArrowDown } from 'lucide-react';

export const SystemArchModule: React.FC = () => {
  return (
    <div className="space-y-6 font-mono">
      
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Layers className="w-5 h-5 text-amber-400" />
            <span>e₹ CBDC SYSTEM ARCHITECTURE & TECHNICAL SPECIFICATION</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Two-Tier Sovereign Architecture, Cryptographic Ledger & Interbank Settlement Topology
          </p>
        </div>

        <span className="text-xs font-bold text-amber-400 bg-amber-950 px-3 py-1.5 rounded border border-amber-800">
          ● TWO-TIER DISTRIBUTION MODEL
        </span>
      </div>

      {/* Interactive Topology Diagram */}
      <div className="bg-slate-950 border border-slate-800 p-6 rounded-lg space-y-6 text-center">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest">
          END-TO-END SOVEREIGN TECHNICAL TOPOLOGY
        </h3>

        {/* Tier 1 */}
        <div className="bg-amber-950/40 border border-amber-500/50 p-4 rounded-xl max-w-2xl mx-auto space-y-2">
          <div className="flex items-center justify-center gap-2 text-amber-400 font-bold text-sm">
            <Landmark className="w-5 h-5" />
            <span>TIER 1 — RESERVE BANK OF INDIA (CENTRAL BANK CORE)</span>
          </div>
          <p className="text-xs text-slate-300">
            Sovereign e₹ Token Minting, Central Authoritative Ledger, Policy Caps & RTGS Clearing
          </p>
        </div>

        <div className="flex justify-center text-amber-500 font-bold">
          <ArrowDown className="w-6 h-6 animate-bounce" />
        </div>

        {/* Tier 2 */}
        <div className="bg-slate-900 border border-slate-700 p-4 rounded-xl max-w-3xl mx-auto space-y-2">
          <div className="flex items-center justify-center gap-2 text-sky-400 font-bold text-sm">
            <Building className="w-5 h-5" />
            <span>TIER 2 — PARTICIPATING BANKS & PAYMENT SERVICE PROVIDERS (PSPs)</span>
          </div>
          <p className="text-xs text-slate-300">
            Wallet Provisioning, KYC Verification, Customer Onboarding & P2P / P2M Acquiring
          </p>
        </div>

        <div className="flex justify-center text-amber-500 font-bold">
          <ArrowDown className="w-6 h-6 animate-bounce" />
        </div>

        {/* End Users */}
        <div className="bg-slate-900 border border-slate-700 p-4 rounded-xl max-w-4xl mx-auto space-y-2">
          <div className="flex items-center justify-center gap-2 text-emerald-400 font-bold text-sm">
            <Smartphone className="w-5 h-5" />
            <span>END USERS — RETAIL CONSUMERS & MERCHANT ACCEPTANCE TERMINALS</span>
          </div>
          <p className="text-xs text-slate-300">
            Mobile Wallet Applications, Proximity Offline NFC Tap & Interoperable UPI QR Scanning
          </p>
        </div>
      </div>

      {/* Deep Technical Spec Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-lg space-y-3">
          <h4 className="font-bold text-white text-sm border-b border-slate-800 pb-2 flex items-center gap-2">
            <Database className="w-4 h-4 text-amber-400" />
            <span>Core Ledger Mechanics</span>
          </h4>
          <p className="text-slate-300">
            Centrally governed, cryptographically signed append-only ledger designed for ultra-high throughput (100,000+ TPS) with deterministic finality in under 50 milliseconds.
          </p>
          <ul className="list-disc pl-4 text-slate-400 space-y-1">
            <li>Zero intermediary credit or liquidity risk</li>
            <li>Direct central bank liability tokenization</li>
            <li>Quantum-resistant signature schemes</li>
          </ul>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-5 rounded-lg space-y-3">
          <h4 className="font-bold text-white text-sm border-b border-slate-800 pb-2 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Privacy & Anonymity Tiers</span>
          </h4>
          <p className="text-slate-300">
            Configurable privacy model mimicking physical cash for small-value transactions while enforcing full FIU-IND AML monitoring for high-value transfers.
          </p>
          <ul className="list-disc pl-4 text-slate-400 space-y-1">
            <li>Tier 1: Small cash-like anonymity (&lt; ₹10,000)</li>
            <li>Tier 2: Full Aadhaar/PAN KYC verified wallets</li>
            <li>Automated structuring alert triggers</li>
          </ul>
        </div>
      </div>

    </div>
  );
};
