import React, { useState } from 'react';
import { useCBDCSimulation } from '../../simulation/SimulationContext';
import { formatIndianRupee } from '../../utils/formatters';
import { StatusBadge } from '../common/StatusBadge';
import { ShieldAlert, AlertTriangle, Lock, Unlock, Eye, CheckCircle2 } from 'lucide-react';

export const RiskModule: React.FC = () => {
  const { riskAlerts, updateRiskAlertStatus, freezeWallet } = useCBDCSimulation();

  const highSeverityCount = riskAlerts.filter((a) => a.severity === 'HIGH').length;
  const investigatingCount = riskAlerts.filter((a) => a.status === 'INVESTIGATING').length;

  return (
    <div className="space-y-6 font-mono">
      
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-rose-400" />
            <span>CBDC RISK, COMPLIANCE & AML MONITORING CENTRE</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Real-Time Suspicious Transaction Detection, Structuring Alerts, Velocity Anomaly & Freeze Actions
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs text-rose-400 bg-rose-950 px-3 py-1.5 rounded border border-rose-800">
          <AlertTriangle className="w-3.5 h-3.5 animate-pulse" />
          <span>{highSeverityCount} CRITICAL ANOMALIES DETECTED</span>
        </div>
      </div>

      {/* KPI Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg">
          <div className="text-slate-400 uppercase">Total Flagged Events</div>
          <div className="text-xl font-bold text-white mt-1">{riskAlerts.length} Events</div>
          <div className="text-[10px] text-rose-400 mt-1">Rule Engine Active</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg">
          <div className="text-slate-400 uppercase">Under Active Investigation</div>
          <div className="text-xl font-bold text-amber-400 mt-1">{investigatingCount} Alerts</div>
          <div className="text-[10px] text-slate-400 mt-1">FIU-IND Notification</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg">
          <div className="text-slate-400 uppercase">Compliant Wallet Ratio</div>
          <div className="text-xl font-bold text-emerald-400 mt-1">99.98%</div>
          <div className="text-[10px] text-emerald-400 mt-1">Clean Retail Ecosystem</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg">
          <div className="text-slate-400 uppercase">AML Structuring Threshold</div>
          <div className="text-xl font-bold text-amber-300 mt-1">₹2,00,000 / day</div>
          <div className="text-[10px] text-slate-500 mt-1">PMLA Standard</div>
        </div>
      </div>

      {/* Risk Alerts Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
        <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider mb-3">
          RISK & COMPLIANCE ANOMALY FEED
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="text-[10px] text-slate-400 uppercase bg-slate-950 border-b border-slate-800">
              <tr>
                <th className="p-2.5">Alert ID</th>
                <th className="p-2.5">Target Entity / Wallet</th>
                <th className="p-2.5">Triggered Anomaly Rule</th>
                <th className="p-2.5">Severity</th>
                <th className="p-2.5 text-right">Involved Amount</th>
                <th className="p-2.5 text-center">Status</th>
                <th className="p-2.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {riskAlerts.map((alert) => (
                <tr key={alert.id} className="hover:bg-slate-800/40">
                  <td className="p-2.5 font-bold text-amber-400">{alert.id}</td>
                  <td className="p-2.5">
                    <div className="font-bold text-white">{alert.entityName}</div>
                    <div className="text-[10px] text-slate-400">{alert.entityId}</div>
                  </td>
                  <td className="p-2.5 text-slate-300">{alert.ruleTriggered}</td>
                  <td className="p-2.5 font-bold">
                    <span
                      className={`px-1.5 py-0.5 rounded text-[10px] ${
                        alert.severity === 'HIGH'
                          ? 'bg-rose-950 text-rose-300 border border-rose-700'
                          : 'bg-amber-950 text-amber-300 border border-amber-700'
                      }`}
                    >
                      {alert.severity}
                    </span>
                  </td>
                  <td className="p-2.5 text-right font-bold text-white">
                    {formatIndianRupee(alert.amount)}
                  </td>
                  <td className="p-2.5 text-center">
                    <StatusBadge status={alert.status} />
                  </td>
                  <td className="p-2.5 text-right space-x-1">
                    {alert.status === 'INVESTIGATING' && (
                      <>
                        <button
                          onClick={() => {
                            updateRiskAlertStatus(alert.id, 'RESOLVED');
                          }}
                          className="px-2 py-0.5 rounded text-[10px] bg-emerald-900 hover:bg-emerald-800 text-emerald-200 font-bold"
                        >
                          Clear
                        </button>
                        <button
                          onClick={() => {
                            freezeWallet(alert.entityId || alert.institutionId);
                            updateRiskAlertStatus(alert.id, 'ACTION_TAKEN');
                          }}
                          className="px-2 py-0.5 rounded text-[10px] bg-rose-900 hover:bg-rose-800 text-rose-200 font-bold"
                        >
                          Freeze
                        </button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
