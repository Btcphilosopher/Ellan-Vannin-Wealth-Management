import React, { useState } from 'react';
import { useCBDCSimulation } from '../../simulation/SimulationContext';
import { formatIndianRupee, formatCompactRupee } from '../../utils/formatters';
import { StatusBadge } from '../common/StatusBadge';
import { Code, CheckCircle2, AlertCircle, Cpu, Zap, FileText } from 'lucide-react';

export const ProgrammableModule: React.FC = () => {
  const { programmableContracts, createProgrammableContract, triggerProgrammableContract } = useCBDCSimulation();

  const [titleStr, setTitleStr] = useState<string>('PM-Kisan Agri Subsidy Fertilizer Disbursement');
  const [purposeStr, setPurposeStr] = useState<string>('Government Subsidy');
  const [targetVal, setTargetVal] = useState<string>('Fertilizer Retailers Only (MCC 5191)');
  const [amountStr, setAmountStr] = useState<string>('12500000'); // ₹1.25 Cr
  const [feedback, setFeedback] = useState<string | null>(null);

  const handleCreateContract = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(amountStr);
    if (isNaN(amt) || amt <= 0) return;

    createProgrammableContract({
      title: titleStr,
      purpose: purposeStr,
      conditionRule: targetVal,
      amount: amt,
      sourceWalletId: 'RBDC-TREASURY-01',
      beneficiaryWalletId: 'PM-KISAN-POOL-8821',
      expiryDate: '2026-12-31',
    });

    setFeedback('✓ Smart Programmable Rule Contract Deployed to e₹ Sovereign Ledger!');
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Code className="w-5 h-5 text-amber-400" />
            <span>PROGRAMMABLE e₹ & PURPOSE-BOUND MONEY ENGINE</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Conditional Sovereign Token Execution for DBT Subsidies, Supplier Milestones & Targeted Corporate Disbursements
          </p>
        </div>

        <span className="text-xs font-mono font-bold text-amber-400 bg-amber-950 px-3 py-1.5 rounded border border-amber-800">
          ● SMART CONTRACT LEDGER ACTIVE
        </span>
      </div>

      {/* Preset Rule Templates Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-3 font-mono text-xs">
        <button
          onClick={() => {
            setTitleStr('PM-Kisan Agri Subsidy Disbursement');
            setPurposeStr('Government Subsidy');
            setTargetVal('Fertilizer & Seed Retailers (MCC 5191)');
          }}
          className="p-3 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded text-left space-y-1"
        >
          <div className="font-bold text-amber-400">Agri Subsidy</div>
          <div className="text-[10px] text-slate-400">Targeted MCC Merchants</div>
        </button>

        <button
          onClick={() => {
            setTitleStr('Corporate Employee Food & Health Voucher');
            setPurposeStr('Salary / Allowance');
            setTargetVal('Approved Health & Groceries Only');
          }}
          className="p-3 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded text-left space-y-1"
        >
          <div className="font-bold text-emerald-400">Employee Allowance</div>
          <div className="text-[10px] text-slate-400">Category-Restricted Token</div>
        </button>

        <button
          onClick={() => {
            setTitleStr('Automated Supplier Logistics Invoice INV-20481');
            setPurposeStr('Supplier Payment');
            setTargetVal('POD Digital Signature Hash Match');
          }}
          className="p-3 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded text-left space-y-1"
        >
          <div className="font-bold text-sky-400">Supplier Escrow</div>
          <div className="text-[10px] text-slate-400">Milestone Auto-Release</div>
        </button>

        <button
          onClick={() => {
            setTitleStr('Conditional Infrastructure Grant Phase III');
            setPurposeStr('Govt Infrastructure');
            setTargetVal('Geotagged Construction Proof');
          }}
          className="p-3 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded text-left space-y-1"
        >
          <div className="font-bold text-purple-400">Infra Milestone</div>
          <div className="text-[10px] text-slate-400">Oracle Verified Release</div>
        </button>

        <button
          onClick={() => {
            setTitleStr('Ayushman Bharat Health Reimbursement');
            setPurposeStr('Healthcare');
            setTargetVal('Emplaneled Hospital ID Match');
          }}
          className="p-3 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded text-left space-y-1"
        >
          <div className="font-bold text-rose-400">Healthcare Voucher</div>
          <div className="text-[10px] text-slate-400">Direct-to-Provider</div>
        </button>

        <button
          onClick={() => {
            setTitleStr('Education Scholarship Token Bundle');
            setPurposeStr('Education');
            setTargetVal('University Fee Counter Only');
          }}
          className="p-3 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded text-left space-y-1"
        >
          <div className="font-bold text-indigo-400">Scholarship Token</div>
          <div className="text-[10px] text-slate-400">Non-transferable Cash</div>
        </button>
      </div>

      {/* Contract Builder & Contract Registry */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 font-mono">
        
        {/* Builder Form */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
          <h3 className="text-sm font-bold text-white border-b border-slate-800 pb-2 flex items-center gap-2">
            <Zap className="w-4 h-4 text-amber-400" />
            <span>DEPLOY PROGRAMMABLE RULE</span>
          </h3>

          {feedback && (
            <div className="p-3 bg-slate-950 border border-amber-500/50 rounded text-amber-300 text-xs">
              {feedback}
            </div>
          )}

          <form onSubmit={handleCreateContract} className="space-y-3 text-xs">
            <div>
              <label className="block text-slate-400 mb-1">Contract Title</label>
              <input
                type="text"
                value={titleStr}
                onChange={(e) => setTitleStr(e.target.value)}
                required
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-white outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1">Purpose Category</label>
              <input
                type="text"
                value={purposeStr}
                onChange={(e) => setPurposeStr(e.target.value)}
                required
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-white outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1">Execution Rule / Condition</label>
              <input
                type="text"
                value={targetVal}
                onChange={(e) => setTargetVal(e.target.value)}
                required
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-white outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1">Amount Locked in Smart Escrow (₹)</label>
              <input
                type="number"
                value={amountStr}
                onChange={(e) => setAmountStr(e.target.value)}
                required
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-white outline-none focus:border-amber-500"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded transition-colors"
            >
              DEPLOY PROGRAMMABLE RULE
            </button>
          </form>
        </div>

        {/* Contract Table */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-4 font-mono">
          <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider mb-3">
            DEPLOYED PROGRAMMABLE SMART CONTRACTS
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="text-[10px] text-slate-400 uppercase bg-slate-950 border-b border-slate-800">
                <tr>
                  <th className="p-2.5">Contract ID</th>
                  <th className="p-2.5">Title & Condition</th>
                  <th className="p-2.5 text-right">Escrow Amount</th>
                  <th className="p-2.5 text-center">Status</th>
                  <th className="p-2.5 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {programmableContracts.map((c: any) => (
                  <tr key={c.id} className="hover:bg-slate-800/40">
                    <td className="p-2.5 font-bold text-amber-400">{c.id}</td>
                    <td className="p-2.5">
                      <div className="font-bold text-white">{c.title}</div>
                      <div className="text-[10px] text-slate-400">Rule: {c.conditionRule}</div>
                    </td>
                    <td className="p-2.5 text-right font-bold text-emerald-400">
                      {formatIndianRupee(c.amount)}
                    </td>
                    <td className="p-2.5 text-center">
                      <StatusBadge status={c.status} />
                    </td>
                    <td className="p-2.5 text-right">
                      {c.status === 'ACTIVE' && (
                        <button
                          onClick={() => triggerProgrammableContract(c.id)}
                          className="px-2 py-1 bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-[10px] rounded"
                        >
                          Trigger Release
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

      </div>

    </div>
  );
};
