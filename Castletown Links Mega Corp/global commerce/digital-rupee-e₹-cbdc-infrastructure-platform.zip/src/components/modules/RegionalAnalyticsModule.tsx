import React, { useState } from 'react';
import { useCBDCSimulation } from '../../simulation/SimulationContext';
import { formatIndianRupee, formatCompactRupee, formatIndianNumber } from '../../utils/formatters';
import { IndiaMapSVG } from '../common/IndiaMapSVG';
import { MapPin, Globe, Activity, Filter } from 'lucide-react';

export const RegionalAnalyticsModule: React.FC = () => {
  const { regionalMetrics } = useCBDCSimulation();

  const [selectedRegionCode, setSelectedRegionCode] = useState<string>('NORTH');
  const [filterMode, setFilterMode] = useState<'RETAIL' | 'WHOLESALE' | 'MERCHANT' | 'UPI' | 'OFFLINE'>('RETAIL');

  const selectedMetric =
    regionalMetrics.find((m) => m.regionCode === selectedRegionCode) || regionalMetrics[0];

  return (
    <div className="space-y-6 font-mono">
      
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Globe className="w-5 h-5 text-amber-400" />
            <span>REGIONAL e₹ ADOPTION ANALYTICS & NATIONAL HEATMAP</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Zonal Distribution of Retail & Wholesale Digital Rupee Circulation Across Indian Regions
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400">Filter Mode:</span>
          <select
            value={filterMode}
            onChange={(e) => setFilterMode(e.target.value as any)}
            className="bg-slate-950 border border-slate-700 rounded px-3 py-1 text-xs text-amber-400 font-bold outline-none"
          >
            <option value="RETAIL">RETAIL ADOPTION</option>
            <option value="WHOLESALE">WHOLESALE SETTLEMENT</option>
            <option value="MERCHANT">MERCHANT DENSITY</option>
            <option value="UPI">UPI INTEROP BRIDGE</option>
            <option value="OFFLINE">OFFLINE VOLUME</option>
          </select>
        </div>
      </div>

      {/* Main Grid: Interactive Map + Selected Region Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Vector Map */}
        <div className="lg:col-span-2">
          <IndiaMapSVG
            selectedRegion={selectedRegionCode}
            onSelectRegion={(code) => setSelectedRegionCode(code)}
            regionalMetrics={regionalMetrics}
            filterMode={filterMode}
          />
        </div>

        {/* Region Inspector */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
            <div>
              <span className="text-[10px] text-amber-400 font-bold uppercase">SELECTED ZONE ANALYTICS</span>
              <h3 className="text-lg font-bold text-white flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-amber-400" />
                <span>{selectedMetric.regionName}</span>
              </h3>
            </div>
            <span className="text-xs font-bold text-emerald-400 bg-emerald-950 px-2.5 py-1 rounded border border-emerald-800">
              HIGH ADOPTION
            </span>
          </div>

          <div className="space-y-3 text-xs">
            <div className="bg-slate-950 p-3 rounded border border-slate-800">
              <span className="text-slate-400 text-[10px] uppercase">e₹ Regional Circulation</span>
              <div className="text-xl font-bold text-emerald-400 mt-0.5">
                {formatIndianRupee(selectedMetric.circulation || selectedMetric.transactionValue)}
              </div>
              <span className="text-[10px] text-amber-400">≈ {formatCompactRupee(selectedMetric.circulation || selectedMetric.transactionValue)}</span>
            </div>

            <div className="bg-slate-950 p-3 rounded border border-slate-800">
              <span className="text-slate-400 text-[10px] uppercase">Daily Transaction Volume</span>
              <div className="text-lg font-bold text-white mt-0.5">
                {formatIndianNumber(selectedMetric.transactionVolume)} Txns
              </div>
            </div>

            <div className="bg-slate-950 p-3 rounded border border-slate-800">
              <span className="text-slate-400 text-[10px] uppercase">Active Registered Wallets</span>
              <div className="text-lg font-bold text-slate-200 mt-0.5">
                {formatIndianNumber(selectedMetric.activeWallets)}
              </div>
            </div>

            <div className="bg-slate-950 p-3 rounded border border-slate-800">
              <span className="text-slate-400 text-[10px] uppercase">Offline Adoption Ratio</span>
              <div className="text-lg font-bold text-sky-400 mt-0.5">
                {((selectedMetric.offlineRatio || 0.12) * 100).toFixed(1)}%
              </div>
            </div>

            <div className="pt-2 border-t border-slate-800">
              <span className="text-[10px] text-slate-400 uppercase font-bold block mb-1">MAJOR METROPOLITAN HUBS</span>
              <div className="flex flex-wrap gap-1.5">
                {selectedMetric.majorCities.map((c) => (
                  <span key={c} className="px-2 py-0.5 bg-slate-800 text-slate-200 rounded text-[10px]">
                    {c}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
