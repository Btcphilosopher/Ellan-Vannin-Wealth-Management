import React from 'react';

interface StatusBadgeProps {
  status: string;
  size?: 'sm' | 'md';
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status, size = 'sm' }) => {
  const norm = status.toUpperCase();

  let colorClasses = 'bg-slate-800 text-slate-300 border-slate-700';

  if (['COMPLETED', 'ACTIVE', 'OPERATIONAL', 'SUCCESS', 'VERIFIED', 'CLEARED'].includes(norm)) {
    colorClasses = 'bg-emerald-950/80 text-emerald-300 border-emerald-700/60';
  } else if (['SETTLING', 'PROCESSING', 'PENDING', 'TIER_1', 'INVESTIGATING', 'SYNCING'].includes(norm)) {
    colorClasses = 'bg-amber-950/80 text-amber-300 border-amber-700/60';
  } else if (['HELD', 'HELD_RISK', 'FLAGGED', 'REVIEW_REQUIRED', 'HIGH', 'DEGRADED'].includes(norm)) {
    colorClasses = 'bg-rose-950/80 text-rose-300 border-rose-700/60';
  } else if (['FROZEN', 'SUSPENDED', 'OFFLINE', 'REJECTED', 'FAILED', 'CRITICAL'].includes(norm)) {
    colorClasses = 'bg-red-950 text-red-300 border-red-800';
  }

  const px = size === 'sm' ? 'px-2 py-0.5 text-[10px]' : 'px-2.5 py-1 text-xs';

  return (
    <span className={`inline-flex items-center gap-1 font-mono font-semibold rounded border ${px} ${colorClasses}`}>
      <span className="w-1.5 h-1.5 rounded-full bg-current"></span>
      <span>{norm.replace(/_/g, ' ')}</span>
    </span>
  );
};
