import React from 'react';
import { LucideIcon } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: string;
  compactValue?: string;
  subtext?: string;
  icon?: LucideIcon;
  trend?: { value: string; isPositive: boolean };
  badgeText?: string;
  accentColor?: 'amber' | 'emerald' | 'blue' | 'slate' | 'rose';
}

export const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  compactValue,
  subtext,
  icon: Icon,
  trend,
  badgeText,
  accentColor = 'amber',
}) => {
  const accentClasses = {
    amber: 'text-amber-400 border-amber-500/20 bg-amber-500/5',
    emerald: 'text-emerald-400 border-emerald-500/20 bg-emerald-500/5',
    blue: 'text-sky-400 border-sky-500/20 bg-sky-500/5',
    slate: 'text-slate-300 border-slate-700/50 bg-slate-800/30',
    rose: 'text-rose-400 border-rose-500/20 bg-rose-500/5',
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col justify-between relative overflow-hidden shadow-sm group hover:border-slate-700 transition-colors">
      <div className="flex items-start justify-between gap-2 mb-2">
        <span className="text-xs font-mono text-slate-400 uppercase tracking-wider font-medium">
          {title}
        </span>
        {Icon && (
          <div className={`p-1.5 rounded-md border ${accentClasses[accentColor]}`}>
            <Icon className="w-4 h-4" />
          </div>
        )}
      </div>

      <div className="space-y-1">
        <div className="text-xl lg:text-2xl font-bold font-mono text-white tracking-tight break-all">
          {value}
        </div>
        {compactValue && (
          <div className="text-xs font-mono text-amber-400/90 font-medium">
            ≈ {compactValue}
          </div>
        )}
      </div>

      {(subtext || trend || badgeText) && (
        <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs font-mono text-slate-400">
          <span>{subtext}</span>
          {trend && (
            <span className={trend.isPositive ? 'text-emerald-400 font-semibold' : 'text-rose-400 font-semibold'}>
              {trend.isPositive ? '↑' : '↓'} {trend.value}
            </span>
          )}
          {badgeText && (
            <span className="px-1.5 py-0.5 rounded text-[10px] bg-slate-800 text-slate-300 border border-slate-700 font-medium">
              {badgeText}
            </span>
          )}
        </div>
      )}
    </div>
  );
};
