import React from 'react';
import { RegionalMetric } from '../../types';

interface IndiaMapSVGProps {
  selectedRegion: string | null;
  onSelectRegion: (code: string) => void;
  regionalMetrics: RegionalMetric[];
  filterMode?: 'RETAIL' | 'WHOLESALE' | 'MERCHANT' | 'UPI' | 'OFFLINE';
}

export const IndiaMapSVG: React.FC<IndiaMapSVGProps> = ({
  selectedRegion,
  onSelectRegion,
  regionalMetrics,
  filterMode = 'RETAIL',
}) => {
  // Region SVG Polygons / Abstract Shapes for India Regions
  const regions = [
    {
      code: 'NORTH',
      name: 'North Zone',
      path: 'M 140,50 L 190,40 L 220,70 L 210,110 L 160,120 L 120,100 Z',
      cities: [{ name: 'Delhi', x: 165, y: 85 }, { name: 'Jaipur', x: 145, y: 105 }, { name: 'Lucknow', x: 190, y: 100 }],
    },
    {
      code: 'WEST',
      name: 'West Zone',
      path: 'M 120,100 L 160,120 L 150,170 L 110,180 L 80,140 Z',
      cities: [{ name: 'Mumbai', x: 115, y: 175 }, { name: 'Pune', x: 125, y: 185 }, { name: 'Ahmedabad', x: 110, y: 130 }],
    },
    {
      code: 'SOUTH',
      name: 'South Zone',
      path: 'M 110,180 L 150,170 L 170,220 L 140,270 L 120,250 Z',
      cities: [{ name: 'Bengaluru', x: 135, y: 220 }, { name: 'Chennai', x: 155, y: 225 }, { name: 'Hyderabad', x: 145, y: 185 }],
    },
    {
      code: 'EAST',
      name: 'East Zone',
      path: 'M 210,110 L 260,120 L 250,170 L 200,160 L 190,120 Z',
      cities: [{ name: 'Kolkata', x: 235, y: 145 }],
    },
    {
      code: 'CENTRAL',
      name: 'Central Zone',
      path: 'M 160,120 L 200,120 L 200,160 L 150,170 Z',
      cities: [{ name: 'Bhopal', x: 165, y: 135 }, { name: 'Indore', x: 145, y: 140 }],
    },
    {
      code: 'NORTHEAST',
      name: 'Northeast Zone',
      path: 'M 260,120 L 310,100 L 320,130 L 270,140 Z',
      cities: [{ name: 'Guwahati', x: 285, y: 115 }],
    },
  ];

  return (
    <div className="relative w-full h-[380px] bg-slate-950 border border-slate-800 rounded-lg p-3 flex flex-col items-center justify-center overflow-hidden">
      <div className="absolute top-3 left-3 text-xs font-mono text-slate-400">
        <span className="font-bold text-amber-400">e₹ NATIONAL MAP & HEATMAP</span>
        <span className="block text-[10px] text-slate-500">Filter: {filterMode} | Click region to inspect</span>
      </div>

      <svg viewBox="0 0 360 300" className="w-full h-full max-h-[340px]">
        {/* SVG Glow Filter */}
        <defs>
          <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="3" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>

        {/* Region Paths */}
        {regions.map((reg) => {
          const metric = regionalMetrics.find((m) => m.regionCode === reg.code);
          const isSelected = selectedRegion === reg.code;

          // Intensity calculation
          const intensity = metric ? Math.min(1, metric.transactionVolume / 900000) : 0.4;
          const fillColor = isSelected
            ? '#d97706' // amber-600
            : `rgba(16, 185, 129, ${0.15 + intensity * 0.45})`; // emerald pulse

          return (
            <g key={reg.code} className="cursor-pointer group" onClick={() => onSelectRegion(reg.code)}>
              <path
                d={reg.path}
                fill={fillColor}
                stroke={isSelected ? '#f59e0b' : '#334155'}
                strokeWidth={isSelected ? '2' : '1'}
                className="transition-all duration-300 hover:fill-amber-500/40"
                filter={isSelected ? 'url(#glow)' : undefined}
              />
              <text
                x={getRegionCenter(reg.code).x}
                y={getRegionCenter(reg.code).y}
                fill={isSelected ? '#ffffff' : '#94a3b8'}
                fontSize="9"
                fontWeight="bold"
                fontFamily="monospace"
                textAnchor="middle"
                className="pointer-events-none select-none"
              >
                {reg.name.replace(' Zone', '')}
              </text>
            </g>
          );
        })}

        {/* City Marker Dots & Pulse */}
        {regions.flatMap((r) =>
          r.cities.map((city, idx) => (
            <g key={`${r.code}-${idx}`} className="pointer-events-none">
              <circle cx={city.x} cy={city.y} r="3" fill="#38bdf8" />
              <circle cx={city.x} cy={city.y} r="6" fill="#38bdf8" opacity="0.3" className="animate-ping" />
              <text x={city.x + 5} y={city.y + 3} fill="#cbd5e1" fontSize="8" fontFamily="sans-serif">
                {city.name}
              </text>
            </g>
          ))
        )}
      </svg>

      <div className="absolute bottom-3 right-3 flex items-center gap-2 text-[10px] font-mono text-slate-400 bg-slate-900/90 px-2 py-1 rounded border border-slate-800">
        <span className="w-2.5 h-2.5 rounded bg-emerald-500/30 border border-emerald-500"></span>
        <span>Normal Activity</span>
        <span className="w-2.5 h-2.5 rounded bg-amber-600 border border-amber-500"></span>
        <span>Selected Zone</span>
      </div>
    </div>
  );
};

function getRegionCenter(code: string): { x: number; y: number } {
  switch (code) {
    case 'NORTH':
      return { x: 170, y: 80 };
    case 'WEST':
      return { x: 125, y: 140 };
    case 'SOUTH':
      return { x: 140, y: 220 };
    case 'EAST':
      return { x: 225, y: 145 };
    case 'CENTRAL':
      return { x: 175, y: 145 };
    case 'NORTHEAST':
      return { x: 290, y: 120 };
    default:
      return { x: 180, y: 150 };
  }
}
