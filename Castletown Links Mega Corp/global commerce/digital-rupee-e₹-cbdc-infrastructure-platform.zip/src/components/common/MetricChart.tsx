import React from 'react';

interface MetricChartProps {
  title: string;
  subtitle?: string;
  data: { label: string; value: number; secondaryValue?: number }[];
  type?: 'area' | 'bar' | 'line';
  height?: number;
  color?: 'amber' | 'emerald' | 'sky' | 'indigo';
  unit?: string;
}

export const MetricChart: React.FC<MetricChartProps> = ({
  title,
  subtitle,
  data,
  type = 'area',
  height = 180,
  color = 'amber',
  unit = '',
}) => {
  if (!data || data.length === 0) return null;

  const maxValue = Math.max(...data.map((d) => d.value), 1);
  const padding = 20;
  const graphWidth = 500;
  const graphHeight = height - padding * 2;

  const points = data.map((d, index) => {
    const x = padding + (index / (data.length - 1 || 1)) * (graphWidth - padding * 2);
    const y = height - padding - (d.value / maxValue) * graphHeight;
    return { x, y, label: d.label, value: d.value };
  });

  const pathD = points.reduce((acc, point, index) => {
    return index === 0 ? `M ${point.x} ${point.y}` : `${acc} L ${point.x} ${point.y}`;
  }, '');

  const areaD = `${pathD} L ${points[points.length - 1].x} ${height - padding} L ${points[0].x} ${
    height - padding
  } Z`;

  const colorHex = {
    amber: { stroke: '#f59e0b', fill: '#f59e0b20' },
    emerald: { stroke: '#10b981', fill: '#10b98120' },
    sky: { stroke: '#0284c7', fill: '#0284c720' },
    indigo: { stroke: '#6366f1', fill: '#6366f120' },
  }[color];

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 font-mono">
      <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
        <div>
          <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider">{title}</h3>
          {subtitle && <p className="text-[10px] text-slate-500">{subtitle}</p>}
        </div>
        <span className="text-[10px] text-slate-400 bg-slate-800/80 px-2 py-0.5 rounded border border-slate-700">
          MAX: {maxValue.toLocaleString('en-IN')} {unit}
        </span>
      </div>

      <div className="w-full overflow-hidden">
        <svg viewBox={`0 0 ${graphWidth} ${height}`} className="w-full h-auto text-xs overflow-visible">
          {/* Grid lines */}
          {[0, 0.33, 0.66, 1].map((ratio, i) => {
            const y = height - padding - ratio * graphHeight;
            return (
              <g key={i}>
                <line
                  x1={padding}
                  y1={y}
                  x2={graphWidth - padding}
                  y2={y}
                  stroke="#334155"
                  strokeWidth="0.5"
                  strokeDasharray="2 2"
                />
              </g>
            );
          })}

          {/* Area / Bar / Line */}
          {type === 'area' && (
            <>
              <path d={areaD} fill={colorHex.fill} />
              <path d={pathD} fill="none" stroke={colorHex.stroke} strokeWidth="2" />
            </>
          )}

          {type === 'line' && (
            <path d={pathD} fill="none" stroke={colorHex.stroke} strokeWidth="2" />
          )}

          {type === 'bar' &&
            points.map((p, i) => {
              const barWidth = (graphWidth - padding * 2) / data.length - 4;
              const barHeight = height - padding - p.y;
              return (
                <rect
                  key={i}
                  x={p.x - barWidth / 2}
                  y={p.y}
                  width={Math.max(2, barWidth)}
                  height={barHeight}
                  fill={colorHex.stroke}
                  rx="1"
                  className="opacity-80 hover:opacity-100 transition-opacity"
                />
              );
            })}

          {/* Dots */}
          {points.map((p, i) => (
            <circle key={i} cx={p.x} cy={p.y} r="3" fill={colorHex.stroke} className="hover:r-5 transition-all" />
          ))}

          {/* Labels on X Axis */}
          {data.map((d, i) => {
            if (i % Math.ceil(data.length / 6) === 0 || i === data.length - 1) {
              const x = padding + (i / (data.length - 1 || 1)) * (graphWidth - padding * 2);
              return (
                <text key={i} x={x} y={height - 2} fill="#64748b" fontSize="8" textAnchor="middle">
                  {d.label}
                </text>
              );
            }
            return null;
          })}
        </svg>
      </div>
    </div>
  );
};
