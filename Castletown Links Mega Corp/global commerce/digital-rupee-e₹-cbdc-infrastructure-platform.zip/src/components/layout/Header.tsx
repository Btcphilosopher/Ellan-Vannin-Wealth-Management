import React, { useState, useEffect } from 'react';
import { useCBDCSimulation } from '../../simulation/SimulationContext';
import { formatTimestampIST } from '../../utils/formatters';
import { Globe, ShieldCheck, Activity, RefreshCw, Landmark } from 'lucide-react';

export const Header: React.FC = () => {
  const { language, setLanguage, resetSimulationData, networkOfflineMode, setNetworkOfflineMode } = useCBDCSimulation();
  const [timeStr, setTimeStr] = useState<string>(formatTimestampIST());

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeStr(formatTimestampIST());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <header className="bg-slate-950 border-b border-slate-800 text-slate-100 sticky top-0 z-30 shadow-md">
      <div className="max-w-[1800px] mx-auto px-4 lg:px-6 py-2.5 flex items-center justify-between gap-4">
        
        {/* Left: Product Designation & Emblem Concept */}
        <div className="flex items-center gap-3.5">
          <div className="relative flex items-center justify-center w-11 h-11 rounded-md bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 border border-slate-700/80 shadow-inner group">
            {/* Subtle Sovereign Emblem Symbol */}
            <div className="text-amber-500 font-bold text-xl font-mono tracking-tighter flex items-center justify-center">
              e₹
            </div>
            <div className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-slate-950"></div>
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg lg:text-xl font-bold tracking-tight text-white flex items-center gap-2">
                <span>DIGITAL RUPEE</span>
                <span className="text-xs px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/30 font-mono font-semibold">
                  e₹ CBDC
                </span>
              </h1>
              <span className="text-xs text-slate-400 font-mono hidden md:inline">
                | {language === 'hi' ? 'डिजिटल रुपया अवसंरचना' : 'CENTRAL BANK INFRASTRUCTURE'}
              </span>
            </div>
            <p className="text-xs text-slate-400 hidden sm:block">
              {language === 'hi'
                ? 'केंद्रीय बैंक डिजिटल मुद्रा संचालन, समाशोधन और भुगतान सिमुलेशन'
                : 'Central Bank Digital Currency Operations, Settlement & Payments Simulation'}
            </p>
          </div>
        </div>

        {/* Right: Operational Status, Controls, Clock & Language */}
        <div className="flex items-center gap-3 sm:gap-4">
          
          {/* System Operational Indicator */}
          <div className="hidden xl:flex items-center gap-2 bg-slate-900/90 px-3 py-1.5 rounded-md border border-slate-800">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
            </span>
            <span className="text-xs font-mono font-medium text-emerald-400 tracking-wide">
              SYSTEM OPERATIONAL
            </span>
          </div>

          {/* Network Condition Toggle */}
          <button
            onClick={() => setNetworkOfflineMode(!networkOfflineMode)}
            title="Simulate network offline/online connectivity state"
            className={`px-2.5 py-1 text-xs font-mono rounded border transition-colors flex items-center gap-1.5 ${
              networkOfflineMode
                ? 'bg-red-950/80 text-red-300 border-red-700/60'
                : 'bg-slate-900 text-slate-300 border-slate-700 hover:border-slate-600'
            }`}
          >
            <Activity className="w-3.5 h-3.5" />
            <span className="hidden md:inline">
              {networkOfflineMode ? 'NETWORK: OFFLINE' : 'NETWORK: ONLINE'}
            </span>
          </button>

          {/* Live Clock IST */}
          <div className="hidden lg:flex flex-col items-end text-right font-mono text-xs">
            <span className="text-slate-200 font-medium">{timeStr}</span>
            <span className="text-[10px] text-slate-500">IST (UTC+05:30)</span>
          </div>

          {/* Language Selector */}
          <div className="flex items-center bg-slate-900 rounded-md border border-slate-800 p-0.5 font-mono text-xs">
            <button
              onClick={() => setLanguage('en')}
              className={`px-2 py-1 rounded ${
                language === 'en'
                  ? 'bg-amber-600 text-white font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              EN
            </button>
            <button
              onClick={() => setLanguage('hi')}
              className={`px-2 py-1 rounded ${
                language === 'hi'
                  ? 'bg-amber-600 text-white font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              हिन्दी
            </button>
          </div>

          {/* Reset Simulation Button */}
          <button
            onClick={resetSimulationData}
            title="Reset simulation state to baseline"
            className="p-1.5 text-slate-400 hover:text-white bg-slate-900 hover:bg-slate-800 rounded border border-slate-800 transition-colors"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>

      </div>
    </header>
  );
};
