import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Shield, Cpu, Activity, Database, CheckCircle2 } from 'lucide-react';

export const StartupOverlay: React.FC = () => {
  const [show, setShow] = useState<boolean>(true);
  const [step, setStep] = useState<number>(0);

  useEffect(() => {
    const timer1 = setTimeout(() => setStep(1), 800);
    const timer2 = setTimeout(() => setStep(2), 1600);
    const timer3 = setTimeout(() => setStep(3), 2400);
    const timer4 = setTimeout(() => setShow(false), 3200);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
      clearTimeout(timer4);
    };
  }, []);

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, transition: { duration: 0.6 } }}
          className="fixed inset-0 z-50 bg-slate-950 flex flex-col items-center justify-center p-6 text-slate-100 select-none font-sans"
        >
          <div className="max-w-xl w-full text-center space-y-6">
            
            {/* Sovereign Emblem Concept */}
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.5 }}
              className="mx-auto w-20 h-20 rounded-2xl bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 border border-slate-700/80 shadow-2xl flex items-center justify-center relative"
            >
              <span className="text-amber-500 font-extrabold text-3xl font-mono">e₹</span>
              <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-emerald-500 ring-4 ring-slate-950 flex items-center justify-center">
                <CheckCircle2 className="w-3 h-3 text-slate-950" />
              </div>
            </motion.div>

            {/* Title & Subtitle */}
            <div className="space-y-2">
              <motion.h1
                initial={{ y: 10, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.2 }}
                className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white font-sans"
              >
                DIGITAL RUPEE
              </motion.h1>
              <motion.p
                initial={{ y: 10, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.3 }}
                className="text-amber-400 font-mono text-sm tracking-widest font-semibold uppercase"
              >
                e₹ CENTRAL BANK DIGITAL CURRENCY INFRASTRUCTURE
              </motion.p>
              <motion.p
                initial={{ y: 10, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.4 }}
                className="text-slate-400 text-xs max-w-md mx-auto"
              >
                Central Bank Digital Currency Operations, Settlement & Payments Simulation
              </motion.p>
            </div>

            {/* Status Pills */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
              className="flex flex-wrap items-center justify-center gap-3 pt-2 font-mono text-xs"
            >
              <div className="bg-emerald-950/80 text-emerald-400 border border-emerald-700/50 px-3 py-1.5 rounded-md flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                <span className="font-bold">● SYSTEM OPERATIONAL</span>
              </div>
              <div className="bg-amber-950/80 text-amber-300 border border-amber-700/50 px-3 py-1.5 rounded-md">
                <span>SIMULATION ENVIRONMENT</span>
              </div>
              <div className="bg-slate-900 text-slate-300 border border-slate-700 px-3 py-1.5 rounded-md">
                <span>SIMULATED DATA</span>
              </div>
            </motion.div>

            {/* Progress / Step indicators */}
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 font-mono text-xs space-y-2 text-left max-w-md mx-auto">
              <div className="flex items-center justify-between text-slate-400 border-b border-slate-800 pb-2">
                <span>Core Boot Sequence</span>
                <span className="text-amber-400">{Math.min(100, (step + 1) * 25)}%</span>
              </div>

              <div className="space-y-1.5 text-[11px]">
                <div className="flex items-center gap-2">
                  <Cpu className={`w-3.5 h-3.5 ${step >= 0 ? 'text-emerald-400' : 'text-slate-600'}`} />
                  <span className={step >= 0 ? 'text-slate-200' : 'text-slate-600'}>
                    Initializing e₹ Sovereign Ledger Engine...
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <Database className={`w-3.5 h-3.5 ${step >= 1 ? 'text-emerald-400' : 'text-slate-600'}`} />
                  <span className={step >= 1 ? 'text-slate-200' : 'text-slate-600'}>
                    Loading Participant Financial Institutions & Wallets...
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <Activity className={`w-3.5 h-3.5 ${step >= 2 ? 'text-emerald-400' : 'text-slate-600'}`} />
                  <span className={step >= 2 ? 'text-slate-200' : 'text-slate-600'}>
                    Connecting UPI x e₹ Interoperability Bridge...
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <Shield className={`w-3.5 h-3.5 ${step >= 3 ? 'text-emerald-400' : 'text-slate-600'}`} />
                  <span className={step >= 3 ? 'text-slate-200' : 'text-slate-600'}>
                    Establishing National Operations Dashboard...
                  </span>
                </div>
              </div>
            </div>

          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
