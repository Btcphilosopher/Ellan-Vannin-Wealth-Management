import React from 'react';
import { useCBDCSimulation } from '../../simulation/SimulationContext';
import { NavSection } from '../../types';
import { t } from '../../utils/i18n';
import {
  LayoutDashboard,
  Building2,
  Coins,
  Wallet,
  Building,
  Store,
  ArrowRightLeft,
  CheckCircle2,
  WifiOff,
  Code2,
  LineChart,
  ShieldAlert,
  Database,
  MapPin,
  TrendingUp,
  Network,
  Activity,
  FileText,
  Sliders,
  Smartphone,
} from 'lucide-react';

interface NavItem {
  id: NavSection;
  labelKey: any;
  icon: React.ElementType;
  badge?: string;
  category?: string;
}

export const SidebarNav: React.FC = () => {
  const { currentSection, setNavSection, language, riskAlerts, settlementQueue, offlineBuffer } = useCBDCSimulation();

  const pendingRiskCount = riskAlerts.filter((a) => a.status === 'REVIEW_REQUIRED').length;
  const pendingSettlementCount = settlementQueue.filter((s) => s.status === 'PROCESSING' || s.status === 'WAITING').length;
  const offlineBufferCount = offlineBuffer.filter((o) => o.syncStatus === 'LOCAL_BUFFER').length;

  const navGroups: { groupName: string; items: NavItem[] }[] = [
    {
      groupName: language === 'hi' ? 'राष्ट्रीय सिमुलेशन' : 'NATIONAL OVERVIEW',
      items: [
        { id: 'overview', labelKey: 'overview', icon: LayoutDashboard },
        { id: 'issuance', labelKey: 'issuance', icon: Coins },
        { id: 'regional_analytics', labelKey: 'regional_analytics', icon: MapPin },
        { id: 'economic_sim', labelKey: 'economic_sim', icon: TrendingUp },
      ],
    },
    {
      groupName: language === 'hi' ? 'भुगतान एवं वॉलेट्स' : 'PAYMENTS & WALLETS',
      items: [
        { id: 'retail', labelKey: 'retail', icon: Wallet },
        { id: 'consumer_wallet', labelKey: 'consumer_wallet', icon: Smartphone, badge: 'DEMO' },
        { id: 'wholesale', labelKey: 'wholesale', icon: Building2 },
        { id: 'banks', labelKey: 'banks', icon: Building },
        { id: 'merchants', labelKey: 'merchants', icon: Store },
        { id: 'upi_interop', labelKey: 'upi_interop', icon: ArrowRightLeft, badge: 'UPI × e₹' },
      ],
    },
    {
      groupName: language === 'hi' ? 'सेटलमेंट एवं विशेष कार्य' : 'SETTLEMENT & SPECIALIZED',
      items: [
        { id: 'settlement', labelKey: 'settlement', icon: CheckCircle2, badge: pendingSettlementCount > 0 ? `${pendingSettlementCount}` : undefined },
        { id: 'offline', labelKey: 'offline', icon: WifiOff, badge: offlineBufferCount > 0 ? `${offlineBufferCount}` : undefined },
        { id: 'programmable', labelKey: 'programmable', icon: Code2 },
        { id: 'liquidity', labelKey: 'liquidity', icon: LineChart },
        { id: 'risk', labelKey: 'risk', icon: ShieldAlert, badge: pendingRiskCount > 0 ? `${pendingRiskCount}` : undefined },
      ],
    },
    {
      groupName: language === 'hi' ? 'कोर लेजर एवं ऑपरेशन्स' : 'CORE LEDGER & OPS',
      items: [
        { id: 'ledger', labelKey: 'ledger', icon: Database },
        { id: 'system_arch', labelKey: 'system_arch', icon: Network },
        { id: 'network_ops', labelKey: 'network_ops', icon: Activity },
        { id: 'audit', labelKey: 'audit', icon: FileText },
        { id: 'system_ops', labelKey: 'system_ops', icon: Sliders },
      ],
    },
  ];

  return (
    <aside className="w-64 bg-slate-950 text-slate-300 border-r border-slate-800 shrink-0 flex flex-col h-[calc(100vh-80px)] sticky top-[57px] overflow-y-auto custom-scrollbar select-none">
      <div className="p-3">
        {navGroups.map((group, idx) => (
          <div key={idx} className="mb-4">
            <h2 className="px-3 text-[10px] font-mono font-semibold uppercase tracking-wider text-slate-500 mb-1.5">
              {group.groupName}
            </h2>
            <nav className="space-y-0.5">
              {group.items.map((item) => {
                const Icon = item.icon;
                const isActive = currentSection === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setNavSection(item.id)}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-md text-xs font-medium transition-all group ${
                      isActive
                        ? 'bg-amber-600/20 text-amber-300 border border-amber-600/40 shadow-sm font-semibold'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 truncate">
                      <Icon
                        className={`w-4 h-4 shrink-0 transition-colors ${
                          isActive ? 'text-amber-400' : 'text-slate-500 group-hover:text-slate-300'
                        }`}
                      />
                      <span className="truncate">{t(language, item.labelKey)}</span>
                    </div>

                    {item.badge && (
                      <span
                        className={`text-[10px] font-mono font-bold px-1.5 py-0.2 rounded ${
                          isActive
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                            : 'bg-slate-800 text-slate-400 group-hover:text-slate-200'
                        }`}
                      >
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>
          </div>
        ))}
      </div>

      {/* Footer institutional indicator */}
      <div className="mt-auto p-3 border-t border-slate-800/80 bg-slate-950 text-[10px] text-slate-500 font-mono flex flex-col gap-1">
        <div className="flex items-center justify-between text-slate-400">
          <span>Sovereign Ledger v4.2</span>
          <span className="text-emerald-400 font-bold">STABLE</span>
        </div>
        <div className="text-slate-600 text-[9px] leading-tight">
          Non-Production Enterprise Simulator for e₹ Digital Rupee Operations.
        </div>
      </div>
    </aside>
  );
};
