import React from 'react';
import { useCBDCSimulation } from '../../simulation/SimulationContext';
import { AlertCircle } from 'lucide-react';

export const SimulationBanner: React.FC = () => {
  const { language } = useCBDCSimulation();

  return (
    <div className="bg-amber-950/80 border-b border-amber-600/30 text-amber-200 px-4 py-1.5 text-xs font-mono flex flex-wrap items-center justify-between gap-2 shadow-inner">
      <div className="flex items-center gap-2">
        <span className="inline-flex items-center justify-center w-2 h-2 rounded-full bg-amber-500 animate-pulse"></span>
        <span className="font-bold tracking-wider text-amber-400 uppercase">
          {language === 'hi' ? 'सिमुलेशन वातावरण' : 'SIMULATION ENVIRONMENT'}
        </span>
        <span className="text-amber-500/60">|</span>
        <span className="tracking-wide">
          {language === 'hi' ? 'सिम्युलेटेड डेटा' : 'SIMULATED DATA'}
        </span>
        <span className="text-amber-500/60 hidden sm:inline">|</span>
        <span className="text-amber-300/80 text-[11px] hidden sm:inline">
          {language === 'hi'
            ? 'काल्पनिक रिज़र्व बैंक डिजिटल रुपया अवसंरचना सिमुलेटर — गैर-उत्पादन प्रणाली'
            : 'Fictional Indian Central Bank Digital Currency Simulation Platform — Non-Production'}
        </span>
      </div>

      <div className="flex items-center gap-3 text-[11px] text-amber-400/90 font-sans">
        <span className="flex items-center gap-1 bg-amber-900/50 px-2 py-0.5 rounded border border-amber-700/40">
          <AlertCircle className="w-3 h-3 text-amber-400" />
          <span>{language === 'hi' ? 'सिम्युलेटेड सेंट्रल बैंक मुद्रा' : 'Simulated Central-Bank Sovereign Money'}</span>
        </span>
      </div>
    </div>
  );
};
