package com.example.data

import com.example.model.CustomBowl
import com.example.model.IngredientCategory
import com.example.model.IngredientOption
import com.example.model.MenuItem
import com.example.model.Order
import com.example.model.OrderStatus
import com.example.model.OrderType
import com.example.model.CartItem
import com.example.model.Restaurant
import com.example.model.Reward

object CavaSeedData {

    val sampleRestaurants = listOf(
        Restaurant(
            id = "rest_dc_1",
            name = "CAVA Penn Quarter",
            address = "701 7th St NW",
            city = "Washington",
            state = "DC",
            zip = "20001",
            phone = "(202) 638-0200",
            hours = "10:45 AM - 10:00 PM",
            estPrepTimeMinutes = 10,
            distanceMiles = 0.4
        ),
        Restaurant(
            id = "rest_nyc_1",
            name = "CAVA Flatiron District",
            address = "143 5th Ave",
            city = "New York",
            state = "NY",
            zip = "10010",
            phone = "(212) 255-2282",
            hours = "10:30 AM - 10:00 PM",
            estPrepTimeMinutes = 15,
            distanceMiles = 1.2
        ),
        Restaurant(
            id = "rest_aus_1",
            name = "CAVA Downtown Austin",
            address = "500 W 2nd St",
            city = "Austin",
            state = "TX",
            zip = "78701",
            phone = "(512) 480-0080",
            hours = "10:45 AM - 9:30 PM",
            estPrepTimeMinutes = 12,
            distanceMiles = 2.5
        ),
        Restaurant(
            id = "rest_chi_1",
            name = "CAVA Chicago Loop",
            address = "180 N Wabash Ave",
            city = "Chicago",
            state = "IL",
            zip = "60601",
            phone = "(312) 750-1111",
            hours = "11:00 AM - 9:00 PM",
            estPrepTimeMinutes = 14,
            distanceMiles = 3.8
        )
    )

    // Ingredients
    val bases = listOf(
        IngredientOption("b1", IngredientCategory.BASE, "SuperGreens", "Organic kale, baby spinach, arugula", 0.0, 35, 3, 5, 1, isVegan = true, isGlutenFree = true),
        IngredientOption("b2", IngredientCategory.BASE, "Saffron Basmati Rice", "Fluffy basmati with aromatic turmeric & saffron", 0.0, 180, 4, 38, 2, isVegan = true, isGlutenFree = true),
        IngredientOption("b3", IngredientCategory.BASE, "Brown Basmati Rice", "Wholesome nutty brown basmati grain", 0.0, 160, 4, 34, 2, isVegan = true, isGlutenFree = true),
        IngredientOption("b4", IngredientCategory.BASE, "RightRice® Mediterranean", "High-protein grain made from chickpeas & lentils", 0.0, 180, 10, 27, 2, isVegan = true, isGlutenFree = true),
        IngredientOption("b5", IngredientCategory.BASE, "Splendid Romaine & Spinach", "Crisp romaine hearts & tender spinach mix", 0.0, 25, 2, 4, 0, isVegan = true, isGlutenFree = true)
    )

    val dips = listOf(
        IngredientOption("d1", IngredientCategory.DIP_SPREAD, "Crazy Feta®", "Feta whipped with jalapeños & olive oil", 0.0, 110, 4, 2, 9, allergens = listOf("Dairy"), isVegetarian = true, isGlutenFree = true),
        IngredientOption("d2", IngredientCategory.DIP_SPREAD, "Harissa Spread", "Fiery red pepper & spice chili blend", 0.0, 45, 1, 3, 3, isVegan = true, isGlutenFree = true),
        IngredientOption("d3", IngredientCategory.DIP_SPREAD, "Tzatziki", "Greek yogurt with cucumber, garlic & dill", 0.0, 35, 2, 2, 2, allergens = listOf("Dairy"), isVegetarian = true, isGlutenFree = true),
        IngredientOption("d4", IngredientCategory.DIP_SPREAD, "Traditional Hummus", "Creamy chickpeas, tahini, lemon & cumin", 0.0, 80, 3, 7, 5, allergens = listOf("Sesame"), isVegan = true, isGlutenFree = true),
        IngredientOption("d5", IngredientCategory.DIP_SPREAD, "Red Pepper Hummus", "Roasted red peppers blended into smooth hummus", 0.0, 85, 3, 8, 5, allergens = listOf("Sesame"), isVegan = true, isGlutenFree = true),
        IngredientOption("d6", IngredientCategory.DIP_SPREAD, "Eggplant Dip", "Fire-roasted roasted eggplant with olive oil", 0.0, 50, 1, 4, 3, isVegan = true, isGlutenFree = true)
    )

    val proteins = listOf(
        IngredientOption("p1", IngredientCategory.PROTEIN, "Harissa Honey Chicken", "Grilled chicken thighs tossed in sweet & spicy honey harissa", 0.0, 240, 28, 6, 11, isGlutenFree = true),
        IngredientOption("p2", IngredientCategory.PROTEIN, "Grilled Chicken", "Herb-marinated fire-grilled chicken breast", 0.0, 210, 32, 1, 8, isGlutenFree = true),
        IngredientOption("p3", IngredientCategory.PROTEIN, "Braised Lamb", "Slow-cooked savory lamb with aromatic spices", 2.50, 280, 26, 2, 18, isGlutenFree = true),
        IngredientOption("p4", IngredientCategory.PROTEIN, "Falafel", "Crispy house-made chickpea & herb fritters", 0.0, 230, 8, 22, 12, allergens = listOf("Sesame"), isVegan = true, isGlutenFree = true),
        IngredientOption("p5", IngredientCategory.PROTEIN, "Grilled Meatballs", "Beef & lamb meatballs spiced with cumin & oregano", 1.50, 260, 22, 5, 16, isGlutenFree = true),
        IngredientOption("p6", IngredientCategory.PROTEIN, "Roasted Vegetables", "Charred zucchini, bell peppers, onion & herbs", 0.0, 90, 3, 11, 4, isVegan = true, isGlutenFree = true)
    )

    val toppings = listOf(
        IngredientOption("t1", IngredientCategory.TOPPING, "Pickled Red Onions", "Bright tangy vinegar pickled onions", 0.0, 15, 0, 3, 0, isVegan = true, isGlutenFree = true),
        IngredientOption("t2", IngredientCategory.TOPPING, "Diced Cucumber", "Fresh crisp English cucumbers", 0.0, 10, 0, 2, 0, isVegan = true, isGlutenFree = true),
        IngredientOption("t3", IngredientCategory.TOPPING, "Tomato & Cucumber Salad", "Tossed with parsley & lemon olive oil", 0.0, 25, 1, 4, 1, isVegan = true, isGlutenFree = true),
        IngredientOption("t4", IngredientCategory.TOPPING, "Crumbled Feta", "Authentic sheep's milk tangy Greek feta", 0.0, 70, 4, 1, 6, allergens = listOf("Dairy"), isVegetarian = true, isGlutenFree = true),
        IngredientOption("t5", IngredientCategory.TOPPING, "Kalamata Olives", "Briny pitted Mediterranean olives", 0.0, 45, 0, 1, 4, isVegan = true, isGlutenFree = true),
        IngredientOption("t6", IngredientCategory.TOPPING, "Pita Crisps", "House-baked seasoned pita crunchies", 0.0, 60, 2, 10, 2, allergens = listOf("Gluten/Wheat"), isVegan = true),
        IngredientOption("t7", IngredientCategory.TOPPING, "Fire-Roasted Corn", "Sweet corn charred with chili lime seasoning", 0.0, 40, 1, 8, 1, isVegan = true, isGlutenFree = true),
        IngredientOption("t8", IngredientCategory.TOPPING, "Cabbage Slaw", "Shredded cabbage with red wine vinaigrette", 0.0, 20, 1, 3, 1, isVegan = true, isGlutenFree = true)
    )

    val dressings = listOf(
        IngredientOption("dr1", IngredientCategory.DRESSING, "Garlic Dressing", "Creamy roast garlic & tahini emulsion", 0.0, 90, 1, 2, 9, allergens = listOf("Sesame"), isVegan = true, isGlutenFree = true),
        IngredientOption("dr2", IngredientCategory.DRESSING, "Lemon Herb Vinaigrette", "Fresh zesty lemon, extra virgin olive oil & oregano", 0.0, 70, 0, 1, 7, isVegan = true, isGlutenFree = true),
        IngredientOption("dr3", IngredientCategory.DRESSING, "Greek Vinaigrette", "Classic olive oil, red wine vinegar & Mediterranean herbs", 0.0, 80, 0, 1, 8, isVegan = true, isGlutenFree = true),
        IngredientOption("dr4", IngredientCategory.DRESSING, "Ska's Hot Harissa Vinaigrette", "Spicy pepper kick with citrus notes", 0.0, 60, 0, 2, 6, isVegan = true, isGlutenFree = true),
        IngredientOption("dr5", IngredientCategory.DRESSING, "Tahini Caesar", "Plant-based tahini caesar with nutritional yeast & garlic", 0.0, 85, 2, 3, 8, allergens = listOf("Sesame"), isVegan = true, isGlutenFree = true)
    )

    val extras = listOf(
        IngredientOption("e1", IngredientCategory.EXTRA, "Warm Pita Bread", "Fluffy stone-baked Mediterranean pita", 1.95, 180, 5, 36, 1, allergens = listOf("Gluten/Wheat"), isVegan = true),
        IngredientOption("e2", IngredientCategory.EXTRA, "Pita Chips & Hummus", "Crispy salted pita chips with traditional hummus", 3.75, 340, 8, 44, 15, allergens = listOf("Gluten/Wheat", "Sesame"), isVegan = true),
        IngredientOption("e3", IngredientCategory.EXTRA, "Side of Crazy Feta®", "Extra 4oz side of spicy whipped feta", 2.50, 220, 8, 4, 18, allergens = listOf("Dairy"), isVegetarian = true, isGlutenFree = true),
        IngredientOption("e4", IngredientCategory.EXTRA, "Cucumber Lime Mint Juice", "House-brewed fresh botanical crisp drink (20 oz)", 2.95, 80, 0, 20, 0, isVegan = true, isGlutenFree = true),
        IngredientOption("e5", IngredientCategory.EXTRA, "Blueberry Lavender Tonic", "Refreshing lightly sparkling botanical brew", 2.95, 70, 0, 17, 0, isVegan = true, isGlutenFree = true)
    )

    // Preset Signature Bowls
    val signatureBowls = listOf(
        MenuItem(
            id = "sig_1",
            categoryId = "cat_signature",
            name = "Harissa Avocado Bowl",
            description = "Harissa Honey Chicken, Crazy Feta®, SuperGreens, Saffron Basmati Rice, Pickled Onions, Cucumber & Hot Harissa Vinaigrette.",
            price = 14.25,
            calories = 680,
            imageResName = "cava_hero_bowl",
            allergens = listOf("Dairy"),
            isPopular = true,
            customBowl = CustomBowl(
                name = "Harissa Avocado Bowl",
                bases = listOf(bases[0], bases[1]),
                dips = listOf(dips[0], dips[1], dips[2]),
                protein = proteins[0],
                toppings = listOf(toppings[0], toppings[1], toppings[3]),
                dressings = listOf(dressings[3])
            )
        ),
        MenuItem(
            id = "sig_2",
            categoryId = "cat_signature",
            name = "Tahini Caesar Chicken Bowl",
            description = "Grilled Chicken, Romaine, Brown Basmati Rice, Tzatziki, Red Pepper Hummus, Pita Crisps, Feta & Tahini Caesar Dressing.",
            price = 13.95,
            calories = 620,
            imageResName = "cava_hero_bowl",
            allergens = listOf("Dairy", "Gluten/Wheat", "Sesame"),
            isPopular = true,
            customBowl = CustomBowl(
                name = "Tahini Caesar Chicken Bowl",
                bases = listOf(bases[2], bases[4]),
                dips = listOf(dips[2], dips[4]),
                protein = proteins[1],
                toppings = listOf(toppings[3], toppings[5], toppings[1]),
                dressings = listOf(dressings[4])
            )
        ),
        MenuItem(
            id = "sig_3",
            categoryId = "cat_signature",
            name = "Crispy Falafel Pita",
            description = "Golden Falafel wrapped in warm pita with Traditional Hummus, Tomato-Cucumber salad, Pickled Red Onions & Garlic Dressing.",
            price = 11.75,
            calories = 540,
            imageResName = "cava_kiosk_banner",
            allergens = listOf("Gluten/Wheat", "Sesame"),
            isPopular = true,
            customBowl = CustomBowl(
                name = "Crispy Falafel Pita",
                bases = listOf(bases[4]),
                dips = listOf(dips[3]),
                protein = proteins[3],
                toppings = listOf(toppings[0], toppings[2]),
                dressings = listOf(dressings[0]),
                extras = listOf(extras[0])
            )
        ),
        MenuItem(
            id = "sig_4",
            categoryId = "cat_signature",
            name = "Garlic RightRice® Bowl",
            description = "High-protein RightRice® base with Slow-Braised Lamb, Eggplant Dip, Tzatziki, Charred Corn & Lemon Herb Vinaigrette.",
            price = 15.50,
            calories = 710,
            imageResName = "cava_hero_bowl",
            allergens = listOf("Dairy"),
            isPopular = false,
            customBowl = CustomBowl(
                name = "Garlic RightRice® Bowl",
                bases = listOf(bases[3]),
                dips = listOf(dips[2], dips[5]),
                protein = proteins[2],
                toppings = listOf(toppings[6], toppings[4], toppings[0]),
                dressings = listOf(dressings[1])
            )
        )
    )

    val sampleRewards = listOf(
        Reward("rew_1", "Free Side Dip & Pita Chips", "Redeem a free side of Crazy Feta or Hummus with Chips", 250, "restaurant"),
        Reward("rew_2", "$5 Off Any Signature Bowl", "Get $5 off your next custom or signature Mediterranean bowl", 400, "local_offer"),
        Reward("rew_3", "Free Fountain/Botanical Beverage", "Redeem a free Cucumber Mint or Lavender Tonic drink", 180, "local_drink"),
        Reward("rew_4", "Free Extra Protein Upgrade", "Double up your chicken, lamb or falafel on us", 300, "fitness_center")
    )

    val seedOrders = listOf(
        Order(
            id = "ord_1001",
            orderNumber = "1001",
            restaurantId = "rest_dc_1",
            restaurantName = "CAVA Penn Quarter",
            customerName = "Alex Rivera",
            customerEmail = "alex@example.com",
            customerPhone = "(202) 555-0192",
            items = listOf(
                CartItem(
                    id = "ci_1",
                    customBowl = signatureBowls[0].customBowl,
                    quantity = 1,
                    specialInstructions = "Extra pickled onions please!"
                )
            ),
            subtotal = 14.25,
            tax = 1.43,
            tip = 2.00,
            total = 17.68,
            orderType = OrderType.PICKUP,
            status = OrderStatus.PREPARING,
            estPickupTime = "10 min",
            qrPickupCode = "CAVA-ORD-1001"
        ),
        Order(
            id = "ord_1002",
            orderNumber = "1002",
            restaurantId = "rest_dc_1",
            restaurantName = "CAVA Penn Quarter",
            customerName = "Sarah Chen",
            customerEmail = "sarah@example.com",
            customerPhone = "(202) 555-0144",
            items = listOf(
                CartItem(
                    id = "ci_2",
                    customBowl = signatureBowls[1].customBowl,
                    quantity = 1,
                    specialInstructions = "Dressing on the side"
                )
            ),
            subtotal = 13.95,
            tax = 1.40,
            tip = 2.50,
            total = 17.85,
            orderType = OrderType.PICKUP,
            status = OrderStatus.READY_FOR_PICKUP,
            estPickupTime = "Ready now",
            qrPickupCode = "CAVA-ORD-1002",
            isCheckedIn = true
        ),
        Order(
            id = "ord_1003",
            orderNumber = "1003",
            restaurantId = "rest_dc_1",
            restaurantName = "CAVA Penn Quarter",
            customerName = "Marcus Vance",
            customerEmail = "marcus@example.com",
            customerPhone = "(202) 555-0188",
            items = listOf(
                CartItem(
                    id = "ci_3",
                    customBowl = signatureBowls[2].customBowl,
                    quantity = 2
                )
            ),
            subtotal = 23.50,
            tax = 2.35,
            tip = 3.00,
            total = 28.85,
            orderType = OrderType.DINE_IN,
            status = OrderStatus.RESTAURANT_ACCEPTED,
            estPickupTime = "15 min",
            qrPickupCode = "CAVA-ORD-1003"
        )
    )
}
