package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Mediterranean CAVA Inspired Palette
val CavaOliveGreen = Color(0xFF4A6B35)
val CavaDarkOlive = Color(0xFF324A22)
val CavaOliveContainer = Color(0xFFE2F0D9)
val CavaOnOliveContainer = Color(0xFF14240B)

val CavaTerracotta = Color(0xFFC85A32)
val CavaTerracottaDark = Color(0xFF9E3E1A)
val CavaTerracottaContainer = Color(0xFFFCEBE1)
val CavaOnTerracottaContainer = Color(0xFF3F1404)

val CavaSandBackground = Color(0xFFFAF7F2)
val CavaSurfaceWarm = Color(0xFFFFFDF9)
val CavaSurfaceVariantWarm = Color(0xFFF3EDE2)
val CavaCharcoal = Color(0xFF222521)
val CavaGoldAccent = Color(0xFFE5A93C)
val CavaCardBorder = Color(0xFFE4DDD2)

// Dark Palette
val CavaDarkBackground = Color(0xFF191C18)
val CavaDarkSurface = Color(0xFF212520)
val CavaDarkSurfaceVariant = Color(0xFF2C322B)
val CavaDarkOlivePrimary = Color(0xFFA5D686)
val CavaDarkTerracottaSecondary = Color(0xFFFFB59C)
