package com.example.repository

import com.example.data.CavaSeedData
import com.example.model.AppMode
import com.example.model.CartItem
import com.example.model.CheckInToken
import com.example.model.CustomBowl
import com.example.model.IngredientOption
import com.example.model.LoyaltyAccount
import com.example.model.MenuItem
import com.example.model.Order
import com.example.model.OrderStatus
import com.example.model.OrderType
import com.example.model.Restaurant
import com.example.model.Reward
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.UUID

class CavaRepository private constructor() {

    private val _appMode = MutableStateFlow(AppMode.CUSTOMER)
    val appMode: StateFlow<AppMode> = _appMode.asStateFlow()

    private val _restaurants = MutableStateFlow(CavaSeedData.sampleRestaurants)
    val restaurants: StateFlow<List<Restaurant>> = _restaurants.asStateFlow()

    private val _selectedRestaurant = MutableStateFlow(CavaSeedData.sampleRestaurants.first())
    val selectedRestaurant: StateFlow<Restaurant> = _selectedRestaurant.asStateFlow()

    private val _cartItems = MutableStateFlow<List<CartItem>>(emptyList())
    val cartItems: StateFlow<List<CartItem>> = _cartItems.asStateFlow()

    private val _appliedPromoCode = MutableStateFlow<String?>(null)
    val appliedPromoCode: StateFlow<String?> = _appliedPromoCode.asStateFlow()

    private val _orders = MutableStateFlow<List<Order>>(CavaSeedData.seedOrders)
    val orders: StateFlow<List<Order>> = _orders.asStateFlow()

    private val _activeCheckIns = MutableStateFlow<List<CheckInToken>>(emptyList())
    val activeCheckIns: StateFlow<List<CheckInToken>> = _activeCheckIns.asStateFlow()

    private val _loyaltyAccount = MutableStateFlow(
        LoyaltyAccount(
            pointsBalance = 450,
            tierName = "Terracotta Silver",
            nextTierPoints = 600,
            lifetimePoints = 1250,
            rewardsAvailable = CavaSeedData.sampleRewards
        )
    )
    val loyaltyAccount: StateFlow<LoyaltyAccount> = _loyaltyAccount.asStateFlow()

    // 86ed Stock Map: ingredientId -> inStock (true by default)
    private val _stockMap = MutableStateFlow<Map<String, Boolean>>(emptyMap())
    val stockMap: StateFlow<Map<String, Boolean>> = _stockMap.asStateFlow()

    // Active Customer Selected Order for tracking
    private val _activeTrackingOrderId = MutableStateFlow<String?>(CavaSeedData.seedOrders.first().id)
    val activeTrackingOrderId: StateFlow<String?> = _activeTrackingOrderId.asStateFlow()

    // Store Throttling & Hours Overrides
    private val _isStoreOrderingActive = MutableStateFlow(true)
    val isStoreOrderingActive: StateFlow<Boolean> = _isStoreOrderingActive.asStateFlow()

    fun setAppMode(mode: AppMode) {
        _appMode.value = mode
    }

    fun selectRestaurant(restaurant: Restaurant) {
        _selectedRestaurant.value = restaurant
    }

    fun addToCart(cartItem: CartItem) {
        _cartItems.update { current ->
            current + cartItem
        }
    }

    fun removeCartItem(itemId: String) {
        _cartItems.update { current ->
            current.filterNot { it.id == itemId }
        }
    }

    fun updateCartItemQuantity(itemId: String, delta: Int) {
        _cartItems.update { current ->
            current.mapNotNull { item ->
                if (item.id == itemId) {
                    val newQty = item.quantity + delta
                    if (newQty > 0) item.copy(quantity = newQty) else null
                } else {
                    item
                }
            }
        }
    }

    fun applyPromoCode(code: String): Boolean {
        val trimmed = code.trim().uppercase()
        if (trimmed == "CAVA10" || trimmed == "MEDITERRANEAN" || trimmed == "GOLDEN") {
            _appliedPromoCode.value = trimmed
            return true
        }
        return false
    }

    fun clearCart() {
        _cartItems.value = emptyList()
        _appliedPromoCode.value = null
    }

    val cartSubtotal: Double
        get() = _cartItems.value.sumOf { it.itemTotal }

    val discountAmount: Double
        get() = if (_appliedPromoCode.value != null) cartSubtotal * 0.15 else 0.0

    val taxAmount: Double
        get() = (cartSubtotal - discountAmount) * 0.10

    val cartTotal: Double
        get() = (cartSubtotal - discountAmount + taxAmount).coerceAtLeast(0.0)

    fun placeOrder(
        customerName: String = "Taylor Swift",
        customerEmail: String = "taylor@cava.com",
        customerPhone: String = "(202) 555-0199",
        orderType: OrderType = OrderType.PICKUP,
        tipAmount: Double = 2.00,
        specialNotes: String = ""
    ): Order {
        val currentItems = _cartItems.value
        val nextNum = (1000 + _orders.value.size + 1).toString()
        val rest = _selectedRestaurant.value

        val newOrder = Order(
            id = UUID.randomUUID().toString(),
            orderNumber = nextNum,
            restaurantId = rest.id,
            restaurantName = rest.name,
            customerName = customerName.ifBlank { "Valued Guest" },
            customerEmail = customerEmail.ifBlank { "guest@cava.com" },
            customerPhone = customerPhone,
            items = currentItems,
            subtotal = cartSubtotal,
            tax = taxAmount,
            tip = tipAmount,
            total = cartTotal + tipAmount,
            orderType = orderType,
            status = OrderStatus.PAYMENT_CONFIRMED,
            timestamp = System.currentTimeMillis(),
            estPickupTime = "${rest.estPrepTimeMinutes} min",
            qrPickupCode = "CAVA-ORD-$nextNum",
            specialNotes = specialNotes
        )

        _orders.update { current -> listOf(newOrder) + current }
        _activeTrackingOrderId.value = newOrder.id

        // Award loyalty points (10 pts per $1 spent)
        val earnedPts = (newOrder.subtotal * 10).toInt()
        _loyaltyAccount.update { acct ->
            acct.copy(
                pointsBalance = acct.pointsBalance + earnedPts,
                lifetimePoints = acct.lifetimePoints + earnedPts
            )
        }

        clearCart()
        return newOrder
    }

    fun checkInOrder(orderId: String, arrivalMethod: String = "QR Scan"): CheckInToken? {
        val order = _orders.value.find { it.id == orderId } ?: return null
        val token = CheckInToken(
            orderId = order.id,
            orderNumber = order.orderNumber,
            customerName = order.customerName,
            restaurantId = order.restaurantId,
            arrivalMethod = arrivalMethod
        )

        _orders.update { list ->
            list.map {
                if (it.id == orderId) it.copy(isCheckedIn = true, checkInTimestamp = System.currentTimeMillis()) else it
            }
        }
        _activeCheckIns.update { list -> listOf(token) + list }
        return token
    }

    fun updateOrderStatus(orderId: String, newStatus: OrderStatus) {
        _orders.update { list ->
            list.map {
                if (it.id == orderId) it.copy(status = newStatus) else it
            }
        }
    }

    fun setActiveTrackingOrder(orderId: String) {
        _activeTrackingOrderId.value = orderId
    }

    fun toggleIngredientStock(ingredientId: String, inStock: Boolean) {
        _stockMap.update { current ->
            current.toMutableMap().apply { put(ingredientId, inStock) }
        }
    }

    fun redeemReward(reward: Reward): Boolean {
        val current = _loyaltyAccount.value
        if (current.pointsBalance >= reward.pointsCost) {
            _loyaltyAccount.value = current.copy(
                pointsBalance = current.pointsBalance - reward.pointsCost
            )
            return true
        }
        return false
    }

    fun toggleStoreOrderingActive() {
        _isStoreOrderingActive.update { !it }
    }

    companion object {
        @Volatile
        private var INSTANCE: CavaRepository? = null

        fun getInstance(): CavaRepository {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: CavaRepository().also { INSTANCE = it }
            }
        }
    }
}
