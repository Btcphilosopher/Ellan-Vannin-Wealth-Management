package com.example.ui.tracking

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Order
import com.example.model.OrderStatus
import com.example.repository.CavaRepository
import com.example.ui.theme.CavaGoldAccent
import com.example.ui.theme.CavaOliveGreen
import com.example.ui.theme.CavaSandBackground
import com.example.ui.theme.CavaTerracotta
import java.util.Locale

@Composable
fun LiveOrderTrackingScreen(
    repository: CavaRepository,
    onNavigateToHome: () -> Unit
) {
    val orders by repository.orders.collectAsState()
    val activeTrackingId by repository.activeTrackingOrderId.collectAsState()
    val selectedRestaurant by repository.selectedRestaurant.collectAsState()

    val currentOrder = orders.find { it.id == activeTrackingId } ?: orders.firstOrNull()
    val scrollState = rememberScrollState()

    if (currentOrder == null) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("No active orders found.", style = MaterialTheme.typography.titleMedium)
                Button(onClick = onNavigateToHome) { Text("Back to Home") }
            }
        }
        return
    }

    val allStatuses = listOf(
        OrderStatus.ORDER_RECEIVED,
        OrderStatus.PAYMENT_CONFIRMED,
        OrderStatus.RESTAURANT_ACCEPTED,
        OrderStatus.PREPARING,
        OrderStatus.READY_FOR_PICKUP,
        OrderStatus.COLLECTED
    )

    val currentStatusIdx = allStatuses.indexOf(currentOrder.status).coerceAtLeast(0)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CavaSandBackground)
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Order #${currentOrder.orderNumber}",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${currentOrder.restaurantName} • ${currentOrder.orderType.label}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Surface(
                color = when (currentOrder.status) {
                    OrderStatus.READY_FOR_PICKUP -> CavaTerracotta
                    OrderStatus.COLLECTED -> CavaOliveGreen
                    else -> CavaGoldAccent
                },
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = currentOrder.status.label.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = if (currentOrder.status == OrderStatus.READY_FOR_PICKUP || currentOrder.status == OrderStatus.COLLECTED) Color.White else Color.Black,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Status Timeline Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "LIVE KITCHEN PROGRESSION",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = CavaOliveGreen
                )

                Spacer(modifier = Modifier.height(12.dp))

                allStatuses.forEachIndexed { idx, st ->
                    val isDone = idx <= currentStatusIdx
                    val isCurrent = idx == currentStatusIdx

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = when {
                                isCurrent -> CavaTerracotta
                                isDone -> CavaOliveGreen
                                else -> MaterialTheme.colorScheme.surfaceVariant
                            },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                if (isDone) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                } else {
                                    Text("${idx + 1}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = st.label,
                                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                                color = if (isDone) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline
                            )
                            Text(
                                text = st.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    if (idx < allStatuses.size - 1) {
                        Box(
                            modifier = Modifier
                                .padding(start = 13.dp)
                                .width(2.dp)
                                .height(12.dp)
                                .background(if (idx < currentStatusIdx) CavaOliveGreen else MaterialTheme.colorScheme.surfaceVariant)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Scannable Pickup QR Code Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "PICKUP COUNTER CREDENTIAL",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Spacer(modifier = Modifier.height(8.dp))

                Surface(
                    color = Color.White,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.padding(8.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.QrCode2,
                            contentDescription = "Pickup QR Code",
                            modifier = Modifier.size(140.dp),
                            tint = Color.Black
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = currentOrder.qrPickupCode,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = Color.Black
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Show this QR code at the pickup shelf or to line staff upon arrival.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Interactive Simulation Step Advance Button
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "⚙️ Simulation Mode Controls",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Advance order status in real time to test kitchen & customer synchronization:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = {
                        val nextIdx = (currentStatusIdx + 1) % allStatuses.size
                        repository.updateOrderStatus(currentOrder.id, allStatuses[nextIdx])
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("simulate_advance_order_status"),
                    colors = ButtonDefaults.buttonColors(containerColor = CavaOliveGreen)
                ) {
                    Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("ADVANCE STATUS TO: " + allStatuses[(currentStatusIdx + 1) % allStatuses.size].label)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Items Summary Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Order Summary (${currentOrder.items.size} items)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                currentOrder.items.forEach { item ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("${item.quantity}x ${item.itemTitle}")
                        Text(String.format(Locale.US, "$%.2f", item.itemTotal), fontWeight = FontWeight.Bold)
                    }
                }
                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Total Paid", fontWeight = FontWeight.Bold)
                    Text(
                        String.format(Locale.US, "$%.2f", currentOrder.total),
                        fontWeight = FontWeight.Bold,
                        color = CavaOliveGreen
                    )
                }
            }
        }
    }
}
