package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppMode
import com.example.model.Restaurant
import com.example.repository.CavaRepository
import com.example.ui.theme.CavaOliveGreen
import com.example.ui.theme.CavaSandBackground
import com.example.ui.theme.CavaTerracotta

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CavaHeader(
    repository: CavaRepository,
    onOpenCart: () -> Unit
) {
    val currentMode by repository.appMode.collectAsState()
    val selectedRestaurant by repository.selectedRestaurant.collectAsState()
    val restaurants by repository.restaurants.collectAsState()
    val cartItems by repository.cartItems.collectAsState()

    var showModeDropdown by remember { mutableStateOf(false) }
    var showStoreDropdown by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(CavaSandBackground)
    ) {
        // Mode & Store Selector Top Banner
        Surface(
            color = MaterialTheme.colorScheme.primaryContainer,
            shadowElevation = 2.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // App Mode Switcher Pill
                Box {
                    Surface(
                        onClick = { showModeDropdown = true },
                        shape = RoundedCornerShape(20.dp),
                        color = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.testTag("app_mode_selector")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = when (currentMode) {
                                    AppMode.CUSTOMER -> Icons.Default.Person
                                    AppMode.KIOSK -> Icons.Default.TouchApp
                                    AppMode.KITCHEN_DISPLAY -> Icons.Default.SoupKitchen
                                    AppMode.EMPLOYEE_POS -> Icons.Default.Badge
                                    AppMode.MANAGER_DASHBOARD -> Icons.Default.Analytics
                                    AppMode.ADMIN_PORTAL -> Icons.Default.Domain
                                    AppMode.AI_CONCIERGE -> Icons.Default.AutoAwesome
                                },
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = currentMode.label,
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = "Switch App Mode",
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    DropdownMenu(
                        expanded = showModeDropdown,
                        onDismissRequest = { showModeDropdown = false }
                    ) {
                        Text(
                            text = "SYSTEM ROLES & MODES",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.outline,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                        HorizontalDivider()
                        AppMode.values().forEach { mode ->
                            DropdownMenuItem(
                                text = {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(
                                            imageVector = when (mode) {
                                                AppMode.CUSTOMER -> Icons.Default.Person
                                                AppMode.KIOSK -> Icons.Default.TouchApp
                                                AppMode.KITCHEN_DISPLAY -> Icons.Default.SoupKitchen
                                                AppMode.EMPLOYEE_POS -> Icons.Default.Badge
                                                AppMode.MANAGER_DASHBOARD -> Icons.Default.Analytics
                                                AppMode.ADMIN_PORTAL -> Icons.Default.Domain
                                                AppMode.AI_CONCIERGE -> Icons.Default.AutoAwesome
                                            },
                                            contentDescription = null,
                                            tint = if (mode == currentMode) CavaOliveGreen else MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = mode.label,
                                            fontWeight = if (mode == currentMode) FontWeight.Bold else FontWeight.Normal
                                        )
                                    }
                                },
                                onClick = {
                                    repository.setAppMode(mode)
                                    showModeDropdown = false
                                }
                            )
                        }
                    }
                }

                // Active Restaurant Selector Pill (if customer/kiosk/employee)
                Box {
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .clickable { showStoreDropdown = true }
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Place,
                            contentDescription = "Store Location",
                            tint = CavaTerracotta,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = selectedRestaurant.name,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Icon(
                            imageVector = Icons.Default.KeyboardArrowDown,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    DropdownMenu(
                        expanded = showStoreDropdown,
                        onDismissRequest = { showStoreDropdown = false }
                    ) {
                        Text(
                            text = "SELECT RESTAURANT",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.outline,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                        HorizontalDivider()
                        restaurants.forEach { rest ->
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(
                                            text = rest.name,
                                            fontWeight = if (rest.id == selectedRestaurant.id) FontWeight.Bold else FontWeight.Normal
                                        )
                                        Text(
                                            text = "${rest.address} • ${rest.estPrepTimeMinutes}m prep",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                },
                                onClick = {
                                    repository.selectRestaurant(rest)
                                    showStoreDropdown = false
                                }
                            )
                        }
                    }
                }

                // Cart Icon with Badge
                if (currentMode == AppMode.CUSTOMER || currentMode == AppMode.KIOSK || currentMode == AppMode.AI_CONCIERGE) {
                    BadgedBox(
                        badge = {
                            if (cartItems.isNotEmpty()) {
                                Badge(
                                    containerColor = CavaTerracotta,
                                    contentColor = Color.White
                                ) {
                                    Text(cartItems.sumOf { it.quantity }.toString())
                                }
                            }
                        },
                        modifier = Modifier
                            .padding(end = 4.dp)
                            .testTag("cart_badge_button")
                    ) {
                        IconButton(onClick = onOpenCart) {
                            Icon(
                                imageVector = Icons.Default.ShoppingBag,
                                contentDescription = "View Cart",
                                tint = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                }
            }
        }
    }
}
