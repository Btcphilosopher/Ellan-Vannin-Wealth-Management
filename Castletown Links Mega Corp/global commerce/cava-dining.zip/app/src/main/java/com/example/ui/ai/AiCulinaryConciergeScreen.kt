package com.example.ui.ai

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CavaSeedData
import com.example.model.CartItem
import com.example.model.CustomBowl
import com.example.repository.CavaRepository
import com.example.ui.theme.CavaGoldAccent
import com.example.ui.theme.CavaOliveGreen
import com.example.ui.theme.CavaSandBackground
import com.example.ui.theme.CavaTerracotta
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun AiCulinaryConciergeScreen(
    repository: CavaRepository,
    onBowlLoadedToCart: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val scrollState = rememberScrollState()

    var userGoalInput by remember { mutableStateOf("") }
    var isAnalyzing by remember { mutableStateOf(false) }
    var aiRecommendedBowl by remember { mutableStateOf<CustomBowl?>(null) }
    var aiExplanation by remember { mutableStateOf<String?>(null) }

    val presetGoals = listOf(
        "High Protein Muscle Fuel (>40g Protein)",
        "Keto Friendly Low Carb (<15g Carbs)",
        "Vegan Clean Greens & Grains",
        "Low Calorie Mediterranean Light (<500 kcal)"
    )

    fun generateAiRecommendation(prompt: String) {
        coroutineScope.launch {
            isAnalyzing = true
            aiRecommendedBowl = null
            aiExplanation = null
            delay(1200) // Simulate AI reasoning & Gemini structured output

            val lower = prompt.lowercase()
            when {
                lower.contains("protein") || lower.contains("muscle") -> {
                    aiRecommendedBowl = CustomBowl(
                        name = "AI High Protein Power Bowl",
                        bases = listOf(CavaSeedData.bases[3]), // RightRice
                        dips = listOf(CavaSeedData.dips[0], CavaSeedData.dips[3]), // Crazy Feta & Hummus
                        protein = CavaSeedData.proteins[0], // Harissa Honey Chicken
                        toppings = listOf(CavaSeedData.toppings[0], CavaSeedData.toppings[3], CavaSeedData.toppings[1]),
                        dressings = listOf(CavaSeedData.dressings[0]) // Garlic
                    )
                    aiExplanation = "Generated a high-protein power bowl with RightRice® lentils (10g P) and Harissa Honey Chicken (28g P) for maximum muscle recovery!"
                }
                lower.contains("keto") || lower.contains("carb") -> {
                    aiRecommendedBowl = CustomBowl(
                        name = "AI Keto Mediterranean Salad",
                        bases = listOf(CavaSeedData.bases[0]), // SuperGreens
                        dips = listOf(CavaSeedData.dips[2], CavaSeedData.dips[5]), // Tzatziki & Eggplant
                        protein = CavaSeedData.proteins[1], // Grilled Chicken
                        toppings = listOf(CavaSeedData.toppings[1], CavaSeedData.toppings[3], CavaSeedData.toppings[4]),
                        dressings = listOf(CavaSeedData.dressings[1]) // Lemon Herb
                    )
                    aiExplanation = "Selected SuperGreens base with Grilled Chicken and avocado tzatziki to keep carbs under 12g while maximizing healthy fats!"
                }
                lower.contains("vegan") || lower.contains("plant") -> {
                    aiRecommendedBowl = CustomBowl(
                        name = "AI Plant-Based Super Bowl",
                        bases = listOf(CavaSeedData.bases[0], CavaSeedData.bases[2]),
                        dips = listOf(CavaSeedData.dips[1], CavaSeedData.dips[3]),
                        protein = CavaSeedData.proteins[3], // Falafel
                        toppings = listOf(CavaSeedData.toppings[0], CavaSeedData.toppings[2], CavaSeedData.toppings[6]),
                        dressings = listOf(CavaSeedData.dressings[4]) // Tahini Caesar
                    )
                    aiExplanation = "Crafted 100% plant-based meal featuring golden crisp Falafel, Tahini Caesar, and traditional hummus."
                }
                else -> {
                    aiRecommendedBowl = CustomBowl(
                        name = "AI Balanced Mediterranean Craft",
                        bases = listOf(CavaSeedData.bases[0], CavaSeedData.bases[1]),
                        dips = listOf(CavaSeedData.dips[0], CavaSeedData.dips[2]),
                        protein = CavaSeedData.proteins[0],
                        toppings = listOf(CavaSeedData.toppings[0], CavaSeedData.toppings[1], CavaSeedData.toppings[3]),
                        dressings = listOf(CavaSeedData.dressings[1])
                    )
                    aiExplanation = "Balanced Mediterranean micro-nutrient ratio optimized for energy, digestion, and authentic Mediterranean flavor."
                }
            }
            isAnalyzing = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CavaSandBackground)
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = CavaOliveGreen,
                modifier = Modifier.size(40.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, tint = Color.White)
                }
            }
            Column {
                Text(
                    text = "AI Culinary Concierge",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Smart Gemini Dietary & Recipe Optimization",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Preset Goal Chips
        Text("Quick Preset Dietary Goals", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)

        Spacer(modifier = Modifier.height(6.dp))

        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            presetGoals.forEach { goal ->
                SuggestionChip(
                    onClick = {
                        userGoalInput = goal
                        generateAiRecommendation(goal)
                    },
                    label = { Text(goal, fontSize = 12.sp) },
                    colors = SuggestionChipDefaults.suggestionChipColors(containerColor = MaterialTheme.colorScheme.surface)
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Prompt Input Field
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text("Describe your nutritional goals or cravings", fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = userGoalInput,
                    onValueChange = { userGoalInput = it },
                    placeholder = { Text("e.g. High protein bowl with tzatziki & no gluten under 600 cal") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = { generateAiRecommendation(userGoalInput) },
                    enabled = userGoalInput.isNotBlank() && !isAnalyzing,
                    colors = ButtonDefaults.buttonColors(containerColor = CavaOliveGreen),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("generate_ai_bowl_recommendation")
                ) {
                    if (isAnalyzing) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("AI CONCIERGE THINKING...")
                    } else {
                        Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("GENERATE PERFECT BOWL")
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // AI Recommendation Result Card
        aiRecommendedBowl?.let { bowl ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = bowl.name,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Surface(color = CavaGoldAccent, shape = RoundedCornerShape(8.dp)) {
                            Text("GEMINI MATCH 98%", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(4.dp), color = Color.Black)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    aiExplanation?.let { exp ->
                        Text(
                            text = exp,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.9f)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Macro Badges
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Calories: ${bowl.totalCalories} kcal", fontWeight = FontWeight.Bold)
                        Text("Protein: ${bowl.totalProtein}g", fontWeight = FontWeight.Bold, color = CavaOliveGreen)
                        Text("Carbs: ${bowl.totalCarbs}g", fontWeight = FontWeight.Bold)
                        Text("Fat: ${bowl.totalFat}g", fontWeight = FontWeight.Bold)
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                    // Ingredient List
                    Text("Selected AI Ingredients:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                    Text("• Base: ${bowl.bases.joinToString { it.name }}", style = MaterialTheme.typography.bodySmall)
                    Text("• Dips: ${bowl.dips.joinToString { it.name }}", style = MaterialTheme.typography.bodySmall)
                    bowl.protein?.let { Text("• Protein: ${it.name}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold) }
                    Text("• Toppings: ${bowl.toppings.joinToString { it.name }}", style = MaterialTheme.typography.bodySmall)
                    Text("• Dressing: ${bowl.dressings.joinToString { it.name }}", style = MaterialTheme.typography.bodySmall)

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            repository.addToCart(CartItem(customBowl = bowl))
                            onBowlLoadedToCart()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CavaTerracotta),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("add_ai_bowl_to_cart")
                    ) {
                        Text(
                            text = "ADD AI BOWL TO CART • " + String.format(Locale.US, "$%.2f", bowl.totalPrice),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
