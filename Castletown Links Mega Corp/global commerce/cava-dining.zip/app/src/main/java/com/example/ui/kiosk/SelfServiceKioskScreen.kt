package com.example.ui.kiosk

import androidx.compose.animation.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CavaSeedData
import com.example.model.CartItem
import com.example.model.OrderType
import com.example.repository.CavaRepository
import com.example.ui.theme.CavaGoldAccent
import com.example.ui.theme.CavaOliveGreen
import com.example.ui.theme.CavaSandBackground
import com.example.ui.theme.CavaTerracotta
import java.util.Locale

@Composable
fun SelfServiceKioskScreen(
    repository: CavaRepository,
    onKioskOrderPlaced: (String) -> Unit
) {
    val selectedRestaurant by repository.selectedRestaurant.collectAsState()
    val cartItems by repository.cartItems.collectAsState()

    var kioskLanguage by remember { mutableStateOf("English") }
    var isKioskStarted by remember { mutableStateOf(false) }
    var showReceiptModal by remember { mutableStateOf(false) }
    var lastKioskOrderNum by remember { mutableStateOf("1004") }

    if (!isKioskStarted) {
        // Welcome Touchscreen Idle View
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clickable { isKioskStarted = true }
        ) {
            Image(
                painter = painterResource(id = com.example.R.drawable.cava_kiosk_banner_1793957736825),
                contentDescription = "CAVA Mediterranean Kiosk",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.55f))
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Top Kiosk Branding & Language Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "CAVA IN-STORE KIOSK • ${selectedRestaurant.name}",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("English", "Español", "Français").forEach { lang ->
                            FilterChip(
                                selected = (kioskLanguage == lang),
                                onClick = { kioskLanguage = lang },
                                label = { Text(lang, color = if (kioskLanguage == lang) Color.Black else Color.White) },
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = CavaGoldAccent)
                            )
                        }
                    }
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.TouchApp,
                        contentDescription = "Touch to Start",
                        tint = Color.White,
                        modifier = Modifier.size(80.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = when (kioskLanguage) {
                            "Español" -> "TOCA LA PANTALLA PARA EMPEZAR"
                            "Français" -> "TOUCHEZ L'ÉCRAN POUR COMMENCER"
                            else -> "TOUCH SCREEN TO START ORDERING"
                        },
                        style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                    Text(
                        text = "Build Your Mediterranean Bowl • Fast Contactless Checkout",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White.copy(alpha = 0.85f)
                    )
                }

                Surface(
                    color = CavaTerracotta,
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(
                        text = "EAT IN OR TAKE OUT AVAILABLE",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                }
            }
        }
    } else {
        // Active Kiosk Ordering Interface
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(CavaSandBackground)
                .padding(16.dp)
        ) {
            // Header Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "TOUCHSCREEN KIOSK",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Surface(color = CavaGoldAccent, shape = RoundedCornerShape(8.dp)) {
                        Text("AUTO-RESET 60s", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(4.dp))
                    }
                }

                Button(
                    onClick = { isKioskStarted = false },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("CANCEL SESSION")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Signature Kiosk Bowls Cards
            Text(
                text = "Select Preset Bowl or Build Custom Bowl",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(12.dp))

            LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                items(CavaSeedData.signatureBowls) { bowl ->
                    Card(
                        modifier = Modifier
                            .width(260.dp)
                            .height(280.dp),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(bowl.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(bowl.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    String.format(Locale.US, "$%.2f", bowl.price),
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 20.sp,
                                    color = CavaOliveGreen
                                )

                                Button(
                                    onClick = {
                                        repository.addToCart(CartItem(menuItem = bowl, quantity = 1))
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = CavaOliveGreen),
                                    modifier = Modifier.testTag("kiosk_add_item_${bowl.id}")
                                ) {
                                    Text("ADD ITEM", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            // Kiosk Cart & Contactless Payment Bottom Bar
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 8.dp,
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "${cartItems.sumOf { it.quantity }} Items in Cart",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = String.format(Locale.US, "Total: $%.2f", repository.cartTotal),
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = CavaOliveGreen
                        )
                    }

                    Button(
                        onClick = {
                            if (cartItems.isNotEmpty()) {
                                val order = repository.placeOrder(
                                    customerName = "Kiosk Guest",
                                    orderType = OrderType.DINE_IN
                                )
                                lastKioskOrderNum = order.orderNumber
                                showReceiptModal = true
                            }
                        },
                        enabled = cartItems.isNotEmpty(),
                        modifier = Modifier
                            .height(56.dp)
                            .testTag("kiosk_pay_now_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = CavaTerracotta),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(imageVector = Icons.Default.Contactless, contentDescription = null)
                            Text("TAP CARD TO PAY", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                    }
                }
            }
        }
    }

    // Receipt Simulation Modal
    if (showReceiptModal) {
        AlertDialog(
            onDismissRequest = {
                showReceiptModal = false
                isKioskStarted = false
            },
            title = { Text("Receipt Printed! Order #${lastKioskOrderNum}") },
            text = {
                Column {
                    Text("Your order was sent to the kitchen line!")
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Order #${lastKioskOrderNum} is preparing at ${selectedRestaurant.name}.")
                    Text("Please watch the KDS overhead screen for your number.")
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showReceiptModal = false
                        isKioskStarted = false
                        onKioskOrderPlaced(lastKioskOrderNum)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CavaOliveGreen)
                ) {
                    Text("FINISH & RETURN HOME")
                }
            }
        )
    }
}
