package com.example.ui.builder

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CavaSeedData
import com.example.model.CartItem
import com.example.model.CustomBowl
import com.example.model.IngredientCategory
import com.example.model.IngredientOption
import com.example.repository.CavaRepository
import com.example.ui.theme.CavaGoldAccent
import com.example.ui.theme.CavaOliveGreen
import com.example.ui.theme.CavaSandBackground
import com.example.ui.theme.CavaSurfaceVariantWarm
import com.example.ui.theme.CavaTerracotta
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun InteractiveBowlBuilderScreen(
    repository: CavaRepository,
    onBowlAdded: () -> Unit
) {
    val stockMap by repository.stockMap.collectAsState()

    var currentStep by remember { mutableIntStateOf(0) }
    val steps = IngredientCategory.values()

    var selectedBases by remember { mutableStateOf<List<IngredientOption>>(listOf(CavaSeedData.bases[0])) }
    var selectedDips by remember { mutableStateOf<List<IngredientOption>>(listOf(CavaSeedData.dips[0], CavaSeedData.dips[2])) }
    var selectedProtein by remember { mutableStateOf<IngredientOption?>(CavaSeedData.proteins[0]) }
    var selectedToppings by remember { mutableStateOf<List<IngredientOption>>(listOf(CavaSeedData.toppings[0], CavaSeedData.toppings[1], CavaSeedData.toppings[3])) }
    var selectedDressings by remember { mutableStateOf<List<IngredientOption>>(listOf(CavaSeedData.dressings[1])) }
    var selectedExtras by remember { mutableStateOf<List<IngredientOption>>(emptyList()) }
    var bowlNotes by remember { mutableStateOf("") }

    val currentBowl = remember(selectedBases, selectedDips, selectedProtein, selectedToppings, selectedDressings, selectedExtras, bowlNotes) {
        CustomBowl(
            bases = selectedBases,
            dips = selectedDips,
            protein = selectedProtein,
            toppings = selectedToppings,
            dressings = selectedDressings,
            extras = selectedExtras,
            specialNotes = bowlNotes
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CavaSandBackground)
    ) {
        // Macro & Visual Bowl Composition Top Card
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 4.dp
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "CUSTOM MEDITERRANEAN BOWL",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = CavaTerracotta
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Visual Bowl Preview (Composition Chips in ceramic container)
                Surface(
                    color = CavaSurfaceVariantWarm,
                    shape = RoundedCornerShape(16.dp),
                    border = TableBorderHorizontal(color = CavaTerracotta.copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .padding(12.dp)
                            .fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "🥣 Bowl Composition",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = CavaOliveGreen
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            selectedBases.forEach {
                                AssistChip(onClick = {}, label = { Text("Base: ${it.name}", fontSize = 11.sp) })
                            }
                            selectedDips.forEach {
                                AssistChip(onClick = {}, label = { Text("Dip: ${it.name}", fontSize = 11.sp) })
                            }
                            selectedProtein?.let {
                                SuggestionChip(onClick = {}, label = { Text("Protein: ${it.name}", fontSize = 11.sp, fontWeight = FontWeight.Bold) })
                            }
                            selectedToppings.forEach {
                                AssistChip(onClick = {}, label = { Text("Top: ${it.name}", fontSize = 11.sp) })
                            }
                            selectedDressings.forEach {
                                AssistChip(onClick = {}, label = { Text("Dress: ${it.name}", fontSize = 11.sp) })
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Nutrition Summary Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    MacroPill(label = "Calories", value = "${currentBowl.totalCalories} kcal")
                    MacroPill(label = "Protein", value = "${currentBowl.totalProtein}g")
                    MacroPill(label = "Carbs", value = "${currentBowl.totalCarbs}g")
                    MacroPill(label = "Fat", value = "${currentBowl.totalFat}g")
                }

                if (currentBowl.allAllergens.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Allergen Warning",
                            tint = CavaTerracotta,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "Allergens: " + currentBowl.allAllergens.joinToString(", "),
                            style = MaterialTheme.typography.labelSmall,
                            color = CavaTerracotta
                        )
                    }
                }
            }
        }

        // Step Tabs Header
        ScrollableTabRow(
            selectedTabIndex = currentStep,
            edgePadding = 16.dp,
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ) {
            steps.forEachIndexed { index, cat ->
                Tab(
                    selected = currentStep == index,
                    onClick = { currentStep = index },
                    text = {
                        Text(
                            text = "${index + 1}. ${cat.name.replace("_", " ")}",
                            fontWeight = if (currentStep == index) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                )
            }
        }

        val activeCategory = steps[currentStep]
        val categoryOptions = when (activeCategory) {
            IngredientCategory.BASE -> CavaSeedData.bases
            IngredientCategory.DIP_SPREAD -> CavaSeedData.dips
            IngredientCategory.PROTEIN -> CavaSeedData.proteins
            IngredientCategory.TOPPING -> CavaSeedData.toppings
            IngredientCategory.DRESSING -> CavaSeedData.dressings
            IngredientCategory.EXTRA -> CavaSeedData.extras
        }

        // Options List for Active Step
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Text(
                    text = activeCategory.label,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = CavaOliveGreen
                )
            }

            items(categoryOptions) { option ->
                val isInStock = stockMap[option.id] ?: true
                val isSelected = when (activeCategory) {
                    IngredientCategory.BASE -> selectedBases.any { it.id == option.id }
                    IngredientCategory.DIP_SPREAD -> selectedDips.any { it.id == option.id }
                    IngredientCategory.PROTEIN -> selectedProtein?.id == option.id
                    IngredientCategory.TOPPING -> selectedToppings.any { it.id == option.id }
                    IngredientCategory.DRESSING -> selectedDressings.any { it.id == option.id }
                    IngredientCategory.EXTRA -> selectedExtras.any { it.id == option.id }
                }

                Card(
                    onClick = {
                        if (!isInStock) return@Card
                        when (activeCategory) {
                            IngredientCategory.BASE -> {
                                if (isSelected) {
                                    if (selectedBases.size > 1) selectedBases = selectedBases.filterNot { it.id == option.id }
                                } else if (selectedBases.size < 2) {
                                    selectedBases = selectedBases + option
                                }
                            }
                            IngredientCategory.DIP_SPREAD -> {
                                if (isSelected) {
                                    selectedDips = selectedDips.filterNot { it.id == option.id }
                                } else if (selectedDips.size < 3) {
                                    selectedDips = selectedDips + option
                                }
                            }
                            IngredientCategory.PROTEIN -> {
                                selectedProtein = option
                            }
                            IngredientCategory.TOPPING -> {
                                if (isSelected) {
                                    selectedToppings = selectedToppings.filterNot { it.id == option.id }
                                } else {
                                    selectedToppings = selectedToppings + option
                                }
                            }
                            IngredientCategory.DRESSING -> {
                                if (isSelected) {
                                    selectedDressings = selectedDressings.filterNot { it.id == option.id }
                                } else if (selectedDressings.size < 2) {
                                    selectedDressings = selectedDressings + option
                                }
                            }
                            IngredientCategory.EXTRA -> {
                                if (isSelected) {
                                    selectedExtras = selectedExtras.filterNot { it.id == option.id }
                                } else {
                                    selectedExtras = selectedExtras + option
                                }
                            }
                        }
                    },
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) CavaOliveGreen.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface
                    ),
                    border = CardDefaults.outlinedCardBorder(enabled = isSelected),
                    enabled = isInStock,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = option.name,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                if (!isInStock) {
                                    Surface(color = MaterialTheme.colorScheme.error, shape = RoundedCornerShape(4.dp)) {
                                        Text("OUT OF STOCK 86", color = Color.White, fontSize = 10.sp, modifier = Modifier.padding(2.dp))
                                    }
                                }
                            }
                            if (option.description.isNotBlank()) {
                                Text(
                                    text = option.description,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(
                                text = "${option.calories} cal • P:${option.proteinGrams}g C:${option.carbsGrams}g F:${option.fatGrams}g",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.outline
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            if (option.extraPrice > 0) {
                                Text(
                                    text = String.format(Locale.US, "+$%.2f", option.extraPrice),
                                    fontWeight = FontWeight.Bold,
                                    color = CavaTerracotta
                                )
                            }
                            Checkbox(
                                checked = isSelected,
                                onCheckedChange = null,
                                colors = CheckboxDefaults.colors(checkedColor = CavaOliveGreen)
                            )
                        }
                    }
                }
            }
        }

        // Bottom Nav Action Bar (Previous / Next / Add to Cart)
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 8.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (currentStep > 0) {
                    OutlinedButton(
                        onClick = { currentStep-- },
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("PREV")
                    }
                } else {
                    Spacer(modifier = Modifier.width(64.dp))
                }

                Button(
                    onClick = {
                        if (currentStep < steps.size - 1) {
                            currentStep++
                        } else {
                            repository.addToCart(CartItem(customBowl = currentBowl))
                            onBowlAdded()
                        }
                    },
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (currentStep == steps.size - 1) CavaTerracotta else CavaOliveGreen
                    ),
                    modifier = Modifier
                        .height(48.dp)
                        .testTag("add_custom_bowl_to_cart")
                ) {
                    Text(
                        text = if (currentStep < steps.size - 1) "NEXT STEP ➔" else "ADD TO CART • " + String.format(Locale.US, "$%.2f", currentBowl.totalPrice),
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun MacroPill(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
        Text(text = value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = CavaOliveGreen)
    }
}

private fun TableBorderHorizontal(color: Color): androidx.compose.foundation.BorderStroke {
    return androidx.compose.foundation.BorderStroke(1.dp, color)
}
