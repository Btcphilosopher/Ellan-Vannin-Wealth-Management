package com.example.ui.kitchen

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Order
import com.example.model.OrderStatus
import com.example.repository.CavaRepository
import com.example.ui.theme.CavaGoldAccent
import com.example.ui.theme.CavaOliveGreen
import com.example.ui.theme.CavaTerracotta
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KitchenDisplaySystemScreen(
    repository: CavaRepository
) {
    val orders by repository.orders.collectAsState()
    val selectedRestaurant by repository.selectedRestaurant.collectAsState()

    // Filter active kitchen tickets (excluding collected or cancelled)
    val kitchenTickets = orders.filter {
        it.restaurantId == selectedRestaurant.id &&
                it.status != OrderStatus.COLLECTED &&
                it.status != OrderStatus.CANCELLED
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1E221C))
            .padding(16.dp)
    ) {
        // Kitchen Header Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Icon(
                    imageVector = Icons.Default.SoupKitchen,
                    contentDescription = null,
                    tint = CavaGoldAccent,
                    modifier = Modifier.size(32.dp)
                )
                Column {
                    Text(
                        text = "KITCHEN DISPLAY SYSTEM (KDS)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "${selectedRestaurant.name} • ${kitchenTickets.size} Active Line Tickets",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.7f)
                    )
                }
            }

            Surface(
                color = CavaOliveGreen,
                shape = RoundedCornerShape(8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(imageVector = Icons.Default.VolumeUp, contentDescription = "Chime Active", tint = Color.White, modifier = Modifier.size(16.dp))
                    Text("LIVE CHIME ON", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (kitchenTickets.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.DoneAll,
                        contentDescription = null,
                        tint = Color.Gray,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Line is clear! No active tickets.",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.Gray
                    )
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 280.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(kitchenTickets) { ticket ->
                    val elapsedMins = ((System.currentTimeMillis() - ticket.timestamp) / 60000).toInt()
                    val timerColor = when {
                        elapsedMins > 10 -> CavaTerracotta
                        elapsedMins > 5 -> CavaGoldAccent
                        else -> CavaOliveGreen
                    }

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF2C322B))
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            // Ticket Top Bar
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(
                                        text = "#${ticket.orderNumber}",
                                        fontSize = 22.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color.White
                                    )
                                    if (ticket.isCheckedIn) {
                                        Surface(color = CavaTerracotta, shape = RoundedCornerShape(4.dp)) {
                                            Text("ARRIVED", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(2.dp))
                                        }
                                    }
                                }

                                Surface(color = timerColor, shape = RoundedCornerShape(8.dp)) {
                                    Text(
                                        text = "${elapsedMins}m elapsed",
                                        color = if (timerColor == CavaGoldAccent) Color.Black else Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            Text(
                                text = "${ticket.customerName} • ${ticket.orderType.label}",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.8f)
                            )

                            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = Color.Gray.copy(alpha = 0.3f))

                            // Order Customization Ticket Line Items
                            ticket.items.forEach { item ->
                                Column(modifier = Modifier.padding(vertical = 4.dp)) {
                                    Text(
                                        text = "${item.quantity}x ${item.itemTitle}",
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        fontSize = 15.sp
                                    )

                                    item.customBowl?.let { bowl ->
                                        Text("• Bases: ${bowl.bases.joinToString { it.name }}", color = Color.LightGray, fontSize = 12.sp)
                                        Text("• Dips: ${bowl.dips.joinToString { it.name }}", color = Color.LightGray, fontSize = 12.sp)
                                        bowl.protein?.let { Text("• Protein: ${it.name}", color = CavaGoldAccent, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                                        Text("• Toppings: ${bowl.toppings.joinToString { it.name }}", color = Color.LightGray, fontSize = 12.sp)
                                        Text("• Dressings: ${bowl.dressings.joinToString { it.name }}", color = Color.LightGray, fontSize = 12.sp)

                                        if (bowl.allAllergens.isNotEmpty()) {
                                            Surface(
                                                color = CavaTerracotta,
                                                shape = RoundedCornerShape(4.dp),
                                                modifier = Modifier.padding(top = 4.dp)
                                            ) {
                                                Text(
                                                    text = "⚠️ ALLERGENS: " + bowl.allAllergens.joinToString(", "),
                                                    color = Color.White,
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(4.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            if (ticket.specialNotes.isNotBlank()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "NOTE: ${ticket.specialNotes}",
                                    color = CavaGoldAccent,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Kitchen State Action Controls
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                when (ticket.status) {
                                    OrderStatus.ORDER_RECEIVED, OrderStatus.PAYMENT_CONFIRMED -> {
                                        Button(
                                            onClick = { repository.updateOrderStatus(ticket.id, OrderStatus.PREPARING) },
                                            colors = ButtonDefaults.buttonColors(containerColor = CavaOliveGreen),
                                            modifier = Modifier
                                                .weight(1f)
                                                .testTag("kds_start_prep_${ticket.id}")
                                        ) {
                                            Text("START PREP")
                                        }
                                    }
                                    OrderStatus.RESTAURANT_ACCEPTED, OrderStatus.PREPARING -> {
                                        Button(
                                            onClick = { repository.updateOrderStatus(ticket.id, OrderStatus.READY_FOR_PICKUP) },
                                            colors = ButtonDefaults.buttonColors(containerColor = CavaTerracotta),
                                            modifier = Modifier
                                                .weight(1f)
                                                .testTag("kds_mark_ready_${ticket.id}")
                                        ) {
                                            Text("MARK READY")
                                        }
                                    }
                                    OrderStatus.READY_FOR_PICKUP -> {
                                        Button(
                                            onClick = { repository.updateOrderStatus(ticket.id, OrderStatus.COLLECTED) },
                                            colors = ButtonDefaults.buttonColors(containerColor = CavaOliveGreen),
                                            modifier = Modifier
                                                .weight(1f)
                                                .testTag("kds_mark_collected_${ticket.id}")
                                        ) {
                                            Text("HAND TO GUEST")
                                        }
                                    }
                                    else -> {}
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
