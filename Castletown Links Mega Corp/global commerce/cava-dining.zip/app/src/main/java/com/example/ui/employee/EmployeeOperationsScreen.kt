package com.example.ui.employee

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CavaSeedData
import com.example.model.OrderStatus
import com.example.repository.CavaRepository
import com.example.ui.theme.CavaGoldAccent
import com.example.ui.theme.CavaOliveGreen
import com.example.ui.theme.CavaSandBackground
import com.example.ui.theme.CavaTerracotta

@Composable
fun EmployeeOperationsScreen(
    repository: CavaRepository
) {
    val orders by repository.orders.collectAsState()
    val selectedRestaurant by repository.selectedRestaurant.collectAsState()
    val stockMap by repository.stockMap.collectAsState()

    var activeTab by remember { mutableIntStateOf(0) }
    var scanInput by remember { mutableStateOf("") }
    var scanResultMsg by remember { mutableStateOf<String?>(null) }

    val readyOrders = orders.filter { it.restaurantId == selectedRestaurant.id && it.status == OrderStatus.READY_FOR_PICKUP }
    val allIngredients = CavaSeedData.bases + CavaSeedData.dips + CavaSeedData.proteins + CavaSeedData.toppings + CavaSeedData.dressings

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CavaSandBackground)
            .padding(16.dp)
    ) {
        // Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(imageVector = Icons.Default.Badge, contentDescription = null, tint = CavaOliveGreen)
            Text(
                text = "Employee Operations Hub",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Tab Selector
        TabRow(selectedTabIndex = activeTab) {
            Tab(
                selected = activeTab == 0,
                onClick = { activeTab = 0 },
                text = { Text("Pickup Shelf (${readyOrders.size})") }
            )
            Tab(
                selected = activeTab == 1,
                onClick = { activeTab = 1 },
                text = { Text("QR Scanner") }
            )
            Tab(
                selected = activeTab == 2,
                onClick = { activeTab = 2 },
                text = { Text("86 Stock Board") }
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        when (activeTab) {
            0 -> {
                // Pickup Shelf View
                if (readyOrders.isEmpty()) {
                    Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                        Text("No orders waiting on pickup shelf.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(readyOrders) { order ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("Order #${order.orderNumber}", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                        Text("${order.customerName} • ${order.customerPhone}", style = MaterialTheme.typography.bodySmall)
                                        Text("Credential: ${order.qrPickupCode}", style = MaterialTheme.typography.labelSmall, color = CavaTerracotta)
                                    }

                                    Button(
                                        onClick = {
                                            repository.updateOrderStatus(order.id, OrderStatus.COLLECTED)
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = CavaOliveGreen),
                                        modifier = Modifier.testTag("employee_mark_collected_${order.id}")
                                    ) {
                                        Text("HAND TO GUEST")
                                    }
                                }
                            }
                        }
                    }
                }
            }
            1 -> {
                // Scanner Simulation
                Column(modifier = Modifier.weight(1f)) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Scan Customer Pickup QR Code", fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedTextField(
                                value = scanInput,
                                onValueChange = { scanInput = it },
                                placeholder = { Text("Enter QR code string e.g. CAVA-ORD-1002") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = {
                                    val matched = orders.find { it.qrPickupCode.equals(scanInput.trim(), ignoreCase = true) }
                                    if (matched != null) {
                                        repository.updateOrderStatus(matched.id, OrderStatus.COLLECTED)
                                        scanResultMsg = "SUCCESS! Verified Order #${matched.orderNumber} for ${matched.customerName}."
                                    } else {
                                        scanResultMsg = "INVALID CREDENTIAL! QR Code not found in system."
                                    }
                                    scanInput = ""
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = CavaTerracotta),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("verify_qr_pickup_code")
                            ) {
                                Text("VERIFY & COMPLETE COLLECTION")
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    scanResultMsg?.let { msg ->
                        Surface(
                            color = if (msg.startsWith("SUCCESS")) CavaOliveGreen else MaterialTheme.colorScheme.error,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = msg,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }
                }
            }
            2 -> {
                // 86 Item Toggle Board
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "86 Stock Control (Toggle items unavailable across store)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(allIngredients) { ingredient ->
                            val isAvailable = stockMap[ingredient.id] ?: true
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(ingredient.name, fontWeight = FontWeight.Bold)
                                        Text(ingredient.category.label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }

                                    Switch(
                                        checked = isAvailable,
                                        onCheckedChange = { inStock ->
                                            repository.toggleIngredientStock(ingredient.id, inStock)
                                        },
                                        colors = SwitchDefaults.colors(checkedThumbColor = CavaOliveGreen)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
