package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.AppMode
import com.example.repository.CavaRepository
import com.example.ui.admin.EnterpriseAdminScreen
import com.example.ui.ai.AiCulinaryConciergeScreen
import com.example.ui.builder.InteractiveBowlBuilderScreen
import com.example.ui.checkin.SmartCheckInScreen
import com.example.ui.components.CartBottomSheet
import com.example.ui.components.CavaHeader
import com.example.ui.customer.CustomerHomeScreen
import com.example.ui.employee.EmployeeOperationsScreen
import com.example.ui.kiosk.SelfServiceKioskScreen
import com.example.ui.kitchen.KitchenDisplaySystemScreen
import com.example.ui.manager.ManagerDashboardScreen
import com.example.ui.rewards.LoyaltyRewardsScreen
import com.example.ui.theme.CavaOliveGreen
import com.example.ui.theme.CavaTerracotta
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.tracking.LiveOrderTrackingScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val repository = CavaRepository.getInstance()

        setContent {
            MyApplicationTheme {
                MainAppContent(repository = repository)
            }
        }
    }
}

enum class CustomerTab(val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    HOME("Home", Icons.Default.Home),
    ORDER_BUILDER("Order", Icons.Default.SoupKitchen),
    CHECK_IN("Check-In", Icons.Default.QrCodeScanner),
    TRACKING("Track Order", Icons.Default.DirectionsRun),
    REWARDS("Rewards", Icons.Default.Stars)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppContent(repository: CavaRepository) {
    val currentMode by repository.appMode.collectAsState()
    var selectedCustomerTab by remember { mutableStateOf(CustomerTab.HOME) }
    var showCartSheet by remember { mutableStateOf(false) }

    // Intercept back button when not on Home tab or not on Customer mode
    BackHandler(enabled = (currentMode != AppMode.CUSTOMER || selectedCustomerTab != CustomerTab.HOME)) {
        if (currentMode != AppMode.CUSTOMER) {
            repository.setAppMode(AppMode.CUSTOMER)
        } else {
            selectedCustomerTab = CustomerTab.HOME
        }
    }

    Scaffold(
        topBar = {
            CavaHeader(
                repository = repository,
                onOpenCart = { showCartSheet = true }
            )
        },
        bottomBar = {
            if (currentMode == AppMode.CUSTOMER) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp
                ) {
                    CustomerTab.values().forEach { tab ->
                        NavigationBarItem(
                            selected = (selectedCustomerTab == tab),
                            onClick = { selectedCustomerTab = tab },
                            icon = {
                                Icon(
                                    imageVector = tab.icon,
                                    contentDescription = tab.title,
                                    tint = if (selectedCustomerTab == tab) CavaOliveGreen else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            },
                            label = {
                                Text(
                                    text = tab.title,
                                    fontWeight = if (selectedCustomerTab == tab) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                        )
                    }
                }
            }
        },
        contentWindowInsets = WindowInsets.systemBars
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentMode) {
                AppMode.CUSTOMER -> {
                    when (selectedCustomerTab) {
                        CustomerTab.HOME -> {
                            CustomerHomeScreen(
                                repository = repository,
                                onNavigateToBuilder = { selectedCustomerTab = CustomerTab.ORDER_BUILDER },
                                onNavigateToCheckIn = { selectedCustomerTab = CustomerTab.CHECK_IN },
                                onNavigateToTracking = { selectedCustomerTab = CustomerTab.TRACKING },
                                onNavigateToRewards = { selectedCustomerTab = CustomerTab.REWARDS }
                            )
                        }
                        CustomerTab.ORDER_BUILDER -> {
                            InteractiveBowlBuilderScreen(
                                repository = repository,
                                onBowlAdded = { showCartSheet = true }
                            )
                        }
                        CustomerTab.CHECK_IN -> {
                            SmartCheckInScreen(
                                repository = repository,
                                onNavigateToTracking = { selectedCustomerTab = CustomerTab.TRACKING }
                            )
                        }
                        CustomerTab.TRACKING -> {
                            LiveOrderTrackingScreen(
                                repository = repository,
                                onNavigateToHome = { selectedCustomerTab = CustomerTab.HOME }
                            )
                        }
                        CustomerTab.REWARDS -> {
                            LoyaltyRewardsScreen(repository = repository)
                        }
                    }
                }
                AppMode.KIOSK -> {
                    SelfServiceKioskScreen(
                        repository = repository,
                        onKioskOrderPlaced = { orderNum ->
                            repository.setAppMode(AppMode.KITCHEN_DISPLAY)
                        }
                    )
                }
                AppMode.KITCHEN_DISPLAY -> {
                    KitchenDisplaySystemScreen(repository = repository)
                }
                AppMode.EMPLOYEE_POS -> {
                    EmployeeOperationsScreen(repository = repository)
                }
                AppMode.MANAGER_DASHBOARD -> {
                    ManagerDashboardScreen(repository = repository)
                }
                AppMode.ADMIN_PORTAL -> {
                    EnterpriseAdminScreen(repository = repository)
                }
                AppMode.AI_CONCIERGE -> {
                    AiCulinaryConciergeScreen(
                        repository = repository,
                        onBowlLoadedToCart = { showCartSheet = true }
                    )
                }
            }

            if (showCartSheet) {
                CartBottomSheet(
                    repository = repository,
                    onDismiss = { showCartSheet = false },
                    onOrderPlaced = { orderId ->
                        showCartSheet = false
                        repository.setActiveTrackingOrder(orderId)
                        repository.setAppMode(AppMode.CUSTOMER)
                        selectedCustomerTab = CustomerTab.TRACKING
                    }
                )
            }
        }
    }
}
