package com.example.model

import java.util.UUID

enum class AppMode(val label: String, val iconName: String) {
    CUSTOMER("Customer Mobile", "person"),
    KIOSK("Self-Service Kiosk", "touch_app"),
    KITCHEN_DISPLAY("Kitchen KDS", "soup_kitchen"),
    EMPLOYEE_POS("Employee Ops", "badge"),
    MANAGER_DASHBOARD("Manager Hub", "analytics"),
    ADMIN_PORTAL("Enterprise Admin", "domain"),
    AI_CONCIERGE("AI Concierge", "auto_awesome")
}

enum class OrderStatus(val label: String, val description: String) {
    ORDER_RECEIVED("Received", "Order placed by customer"),
    PAYMENT_CONFIRMED("Paid", "Payment validated"),
    RESTAURANT_ACCEPTED("Accepted", "Sent to kitchen line"),
    PREPARING("Preparing", "Cooks assembling your bowl"),
    READY_FOR_PICKUP("Ready for Pickup", "On the pickup shelf!"),
    COLLECTED("Collected", "Order handed to customer"),
    CANCELLED("Cancelled", "Order cancelled")
}

enum class OrderType(val label: String) {
    PICKUP("Pickup"),
    DINE_IN("Dine-In"),
    DELIVERY("Delivery")
}

enum class IngredientCategory(val label: String, val maxSelect: Int) {
    BASE("Choose Base (Up to 2)", 2),
    DIP_SPREAD("Choose Dips & Spreads (Up to 3)", 3),
    PROTEIN("Choose Protein (1)", 1),
    TOPPING("Choose Toppings (Unlimited)", 8),
    DRESSING("Choose Dressing (Up to 2)", 2),
    EXTRA("Add Extras & Sides", 5)
}

data class IngredientOption(
    val id: String,
    val category: IngredientCategory,
    val name: String,
    val description: String = "",
    val extraPrice: Double = 0.0,
    val calories: Int = 0,
    val proteinGrams: Int = 0,
    val carbsGrams: Int = 0,
    val fatGrams: Int = 0,
    val allergens: List<String> = emptyList(),
    val isVegan: Boolean = false,
    val isVegetarian: Boolean = false,
    val isGlutenFree: Boolean = false,
    val isAvailable: Boolean = true
)

data class CustomBowl(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Custom Mediterranean Bowl",
    val bases: List<IngredientOption> = emptyList(),
    val dips: List<IngredientOption> = emptyList(),
    val protein: IngredientOption? = null,
    val toppings: List<IngredientOption> = emptyList(),
    val dressings: List<IngredientOption> = emptyList(),
    val extras: List<IngredientOption> = emptyList(),
    val specialNotes: String = ""
) {
    val totalPrice: Double
        get() {
            val baseCost = 11.95
            val proteinCost = protein?.extraPrice ?: 0.0
            val extrasCost = extras.sumOf { it.extraPrice }
            val dipsCost = dips.mapIndexed { idx, item -> if (idx >= 3) item.extraPrice else 0.0 }.sum()
            return baseCost + proteinCost + extrasCost + dipsCost
        }

    val totalCalories: Int
        get() = (bases.sumOf { it.calories } +
                dips.sumOf { it.calories } +
                (protein?.calories ?: 0) +
                toppings.sumOf { it.calories } +
                dressings.sumOf { it.calories } +
                extras.sumOf { it.calories })

    val totalProtein: Int
        get() = (bases.sumOf { it.proteinGrams } +
                dips.sumOf { it.proteinGrams } +
                (protein?.proteinGrams ?: 0) +
                toppings.sumOf { it.proteinGrams } +
                dressings.sumOf { it.proteinGrams } +
                extras.sumOf { it.proteinGrams })

    val totalCarbs: Int
        get() = (bases.sumOf { it.carbsGrams } +
                dips.sumOf { it.carbsGrams } +
                (protein?.carbsGrams ?: 0) +
                toppings.sumOf { it.carbsGrams } +
                dressings.sumOf { it.carbsGrams } +
                extras.sumOf { it.carbsGrams })

    val totalFat: Int
        get() = (bases.sumOf { it.fatGrams } +
                dips.sumOf { it.fatGrams } +
                (protein?.fatGrams ?: 0) +
                toppings.sumOf { it.fatGrams } +
                dressings.sumOf { it.fatGrams } +
                extras.sumOf { it.fatGrams })

    val allAllergens: List<String>
        get() = (bases.flatMap { it.allergens } +
                dips.flatMap { it.allergens } +
                (protein?.allergens ?: emptyList()) +
                toppings.flatMap { it.allergens } +
                dressings.flatMap { it.allergens } +
                extras.flatMap { it.allergens }).distinct()
}

data class MenuItem(
    val id: String,
    val categoryId: String,
    val name: String,
    val description: String,
    val price: Double,
    val calories: Int,
    val imageResName: String = "",
    val customBowl: CustomBowl? = null,
    val allergens: List<String> = emptyList(),
    val isPopular: Boolean = false,
    val isAvailable: Boolean = true
)

data class CartItem(
    val id: String = UUID.randomUUID().toString(),
    val menuItem: MenuItem? = null,
    val customBowl: CustomBowl? = null,
    val quantity: Int = 1,
    val specialInstructions: String = ""
) {
    val unitPrice: Double
        get() = customBowl?.totalPrice ?: menuItem?.price ?: 0.0

    val itemTotal: Double
        get() = unitPrice * quantity

    val itemTitle: String
        get() = customBowl?.name ?: menuItem?.name ?: "Item"
}

data class Restaurant(
    val id: String,
    val name: String,
    val address: String,
    val city: String,
    val state: String,
    val zip: String,
    val phone: String,
    val hours: String,
    val estPrepTimeMinutes: Int = 12,
    val isPickupAvailable: Boolean = true,
    val isOpen: Boolean = true,
    val distanceMiles: Double = 0.8,
    val qrCodeId: String = "QR_STORE_${id}"
)

data class Order(
    val id: String = UUID.randomUUID().toString(),
    val orderNumber: String,
    val restaurantId: String,
    val restaurantName: String,
    val customerName: String,
    val customerEmail: String,
    val customerPhone: String,
    val items: List<CartItem>,
    val subtotal: Double,
    val tax: Double,
    val tip: Double,
    val total: Double,
    val orderType: OrderType = OrderType.PICKUP,
    val status: OrderStatus = OrderStatus.ORDER_RECEIVED,
    val timestamp: Long = System.currentTimeMillis(),
    val estPickupTime: String = "15-20 min",
    val qrPickupCode: String = "CAVA-ORD-${orderNumber}",
    val isCheckedIn: Boolean = false,
    val checkInTimestamp: Long? = null,
    val specialNotes: String = ""
)

data class CheckInToken(
    val tokenId: String = UUID.randomUUID().toString(),
    val orderId: String,
    val orderNumber: String,
    val customerName: String,
    val restaurantId: String,
    val timestamp: Long = System.currentTimeMillis(),
    val arrivalMethod: String = "QR Code Scan",
    val status: String = "Customer Arrived"
)

data class LoyaltyAccount(
    val pointsBalance: Int = 450,
    val tierName: String = "Terracotta Silver",
    val nextTierPoints: Int = 600,
    val lifetimePoints: Int = 1250,
    val rewardsAvailable: List<Reward> = emptyList()
)

data class Reward(
    val id: String,
    val title: String,
    val description: String,
    val pointsCost: Int,
    val iconName: String
)
