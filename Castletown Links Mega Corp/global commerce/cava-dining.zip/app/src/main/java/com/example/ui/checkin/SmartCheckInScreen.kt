package com.example.ui.checkin

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CheckInToken
import com.example.repository.CavaRepository
import com.example.ui.theme.CavaGoldAccent
import com.example.ui.theme.CavaOliveGreen
import com.example.ui.theme.CavaSandBackground
import com.example.ui.theme.CavaTerracotta
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SmartCheckInScreen(
    repository: CavaRepository,
    onNavigateToTracking: () -> Unit
) {
    val selectedRestaurant by repository.selectedRestaurant.collectAsState()
    val orders by repository.orders.collectAsState()
    val activeCheckIns by repository.activeCheckIns.collectAsState()

    var manualOrderNumInput by remember { mutableStateOf("") }
    var lastCheckInToken by remember { mutableStateOf<CheckInToken?>(null) }
    var isScanningSim by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CavaSandBackground)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = Icons.Default.QrCodeScanner,
                contentDescription = null,
                tint = CavaTerracotta,
                modifier = Modifier.size(28.dp)
            )
            Text(
                text = "Smart Store Check-In",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
        }

        Text(
            text = "At ${selectedRestaurant.name} (${selectedRestaurant.address})",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Simulated QR Viewfinder Box
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(120.dp)
                            .border(3.dp, if (isScanningSim) CavaGoldAccent else CavaOliveGreen, RoundedCornerShape(16.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.QrCode2,
                            contentDescription = "Scan Store QR Code",
                            modifier = Modifier.size(72.dp),
                            tint = CavaOliveGreen
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = if (isScanningSim) "Verifying signed location token..." else "Align restaurant QR code inside frame",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 1-Tap Geolocation / Instant Check-In Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = {
                    isScanningSim = true
                    // Pick active order or first order to check in
                    val target = orders.firstOrNull { !it.isCheckedIn } ?: orders.firstOrNull()
                    if (target != null) {
                        lastCheckInToken = repository.checkInOrder(target.id, "QR Scanner")
                    }
                    isScanningSim = false
                },
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp)
                    .testTag("scan_qr_checkin_button"),
                colors = ButtonDefaults.buttonColors(containerColor = CavaOliveGreen),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(imageVector = Icons.Default.CameraAlt, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("SCAN STORE QR", fontWeight = FontWeight.Bold)
            }

            OutlinedButton(
                onClick = {
                    val target = orders.firstOrNull { !it.isCheckedIn } ?: orders.firstOrNull()
                    if (target != null) {
                        lastCheckInToken = repository.checkInOrder(target.id, "Geofence GPS")
                    }
                },
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp)
                    .testTag("gps_arrival_checkin_button"),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(imageVector = Icons.Default.MyLocation, contentDescription = null, tint = CavaTerracotta)
                Spacer(modifier = Modifier.width(6.dp))
                Text("I'M HERE (GPS)", fontWeight = FontWeight.Bold, color = CavaTerracotta)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Manual Order # Input Check-In Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "Manual Order Check-In",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = manualOrderNumInput,
                        onValueChange = { manualOrderNumInput = it },
                        placeholder = { Text("Enter Order # (e.g., 1001)") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = {
                            val found = orders.find { it.orderNumber == manualOrderNumInput.trim() }
                            if (found != null) {
                                lastCheckInToken = repository.checkInOrder(found.id, "Manual Order #")
                                manualOrderNumInput = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CavaTerracotta)
                    ) {
                        Text("Check In")
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Check-In Success Confirmation Card
        AnimatedVisibility(visible = lastCheckInToken != null) {
            lastCheckInToken?.let { token ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = CavaOliveGreen),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = Color.White)
                            Text(
                                text = "CHECK-IN SUCCESSFUL!",
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                style = MaterialTheme.typography.titleMedium
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Order #${token.orderNumber} is flagged for kitchen priority assembly.",
                            color = Color.White.copy(alpha = 0.9f),
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = "Signed Token: ${token.tokenId.take(8).uppercase()}",
                            color = CavaGoldAccent,
                            style = MaterialTheme.typography.labelSmall
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = onNavigateToTracking,
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = CavaOliveGreen)
                        ) {
                            Text("VIEW LIVE TRACKER ➔", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Active Check-Ins Log
        Text(
            text = "Recent Store Check-Ins",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.align(Alignment.Start)
        )

        Spacer(modifier = Modifier.height(6.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(activeCheckIns) { token ->
                val timeStr = SimpleDateFormat("h:mm:ss a", Locale.US).format(Date(token.timestamp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Order #${token.orderNumber} • ${token.customerName}",
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Method: ${token.arrivalMethod} at $timeStr",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Surface(
                            color = CavaOliveGreen.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "Notified KDS",
                                color = CavaOliveGreen,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
