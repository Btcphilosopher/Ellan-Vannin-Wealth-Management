package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = CavaDarkOlivePrimary,
    onPrimary = CavaDarkOlive,
    primaryContainer = CavaDarkOlive,
    onPrimaryContainer = CavaOliveContainer,
    secondary = CavaDarkTerracottaSecondary,
    onSecondary = CavaTerracottaDark,
    secondaryContainer = CavaTerracottaDark,
    onSecondaryContainer = CavaTerracottaContainer,
    tertiary = CavaGoldAccent,
    background = CavaDarkBackground,
    onBackground = CavaSurfaceVariantWarm,
    surface = CavaDarkSurface,
    onSurface = CavaSurfaceWarm,
    surfaceVariant = CavaDarkSurfaceVariant,
    onSurfaceVariant = CavaSurfaceVariantWarm
)

private val LightColorScheme = lightColorScheme(
    primary = CavaOliveGreen,
    onPrimary = Color.White,
    primaryContainer = CavaOliveContainer,
    onPrimaryContainer = CavaOnOliveContainer,
    secondary = CavaTerracotta,
    onSecondary = Color.White,
    secondaryContainer = CavaTerracottaContainer,
    onSecondaryContainer = CavaOnTerracottaContainer,
    tertiary = CavaGoldAccent,
    background = CavaSandBackground,
    onBackground = CavaCharcoal,
    surface = CavaSurfaceWarm,
    onSurface = CavaCharcoal,
    surfaceVariant = CavaSurfaceVariantWarm,
    onSurfaceVariant = CavaCharcoal
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Set false to preserve signature Mediterranean identity
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = androidx.compose.ui.platform.LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
