package com.example.ui.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.repository.CavaRepository
import com.example.ui.theme.CavaGoldAccent
import com.example.ui.theme.CavaOliveGreen
import com.example.ui.theme.CavaSandBackground
import com.example.ui.theme.CavaTerracotta
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun EnterpriseAdminScreen(
    repository: CavaRepository
) {
    val restaurants by repository.restaurants.collectAsState()
    val orders by repository.orders.collectAsState()

    var pointsMultiplier by remember { java.lang.Float.valueOf(1.0f).let { mutableStateOf(1.0f) } }
    var basePriceOverride by remember { mutableStateOf("11.95") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CavaSandBackground)
            .padding(16.dp)
    ) {
        // Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(imageVector = Icons.Default.Domain, contentDescription = null, tint = CavaOliveGreen)
            Text(
                text = "Enterprise Multi-Location Portal",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Multi-Location Revenue Breakdown
        Text("Multi-Location Performance Overview", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(restaurants) { rest ->
                val restOrders = orders.filter { it.restaurantId == rest.id }
                val rev = restOrders.sumOf { it.total }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(rest.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text("${rest.address}, ${rest.city}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("${restOrders.size} Orders Processed", style = MaterialTheme.typography.labelSmall, color = CavaOliveGreen)
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(String.format(Locale.US, "$%.2f", rev), fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = CavaOliveGreen)
                            Surface(color = CavaGoldAccent.copy(alpha = 0.2f), shape = RoundedCornerShape(6.dp)) {
                                Text("ONLINE", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(4.dp))
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(12.dp))
                // Central Pricing & Loyalty Multiplier Overrides Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Central Enterprise Overrides", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Standard Bowl Base Price")
                            OutlinedTextField(
                                value = basePriceOverride,
                                onValueChange = { basePriceOverride = it },
                                singleLine = true,
                                modifier = Modifier.width(100.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Loyalty Campaign Multiplier: ${String.format(Locale.US, "%.1fx", pointsMultiplier)}")
                        Slider(
                            value = pointsMultiplier,
                            onValueChange = { pointsMultiplier = it },
                            valueRange = 1.0f..3.0f,
                            steps = 3,
                            colors = SliderDefaults.colors(thumbColor = CavaOliveGreen)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Security & Audit Log Stream
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Enterprise Audit & Security Ledger", fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(8.dp))
                        val nowStr = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
                        AuditRow("Token Auth: Location check-in verified at Penn Quarter", nowStr)
                        AuditRow("Payment Webhook: Tokenized charge $17.68 cleared", nowStr)
                        AuditRow("RBAC Audit: Employee #4102 updated item 86 stock status", nowStr)
                    }
                }
            }
        }
    }
}

@Composable
private fun AuditRow(event: String, time: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text("• $event", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
        Text(time, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
    }
}
