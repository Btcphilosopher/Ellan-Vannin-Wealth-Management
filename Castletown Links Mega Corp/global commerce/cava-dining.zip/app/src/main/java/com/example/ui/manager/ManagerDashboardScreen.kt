package com.example.ui.manager

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.repository.CavaRepository
import com.example.ui.theme.CavaGoldAccent
import com.example.ui.theme.CavaOliveGreen
import com.example.ui.theme.CavaSandBackground
import com.example.ui.theme.CavaTerracotta
import java.util.Locale

@Composable
fun ManagerDashboardScreen(
    repository: CavaRepository
) {
    val selectedRestaurant by repository.selectedRestaurant.collectAsState()
    val orders by repository.orders.collectAsState()
    val isStoreActive by repository.isStoreOrderingActive.collectAsState()

    val storeOrders = orders.filter { it.restaurantId == selectedRestaurant.id }
    val totalRevenue = storeOrders.sumOf { it.total }
    val avgOrderVal = if (storeOrders.isNotEmpty()) totalRevenue / storeOrders.size else 0.0

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CavaSandBackground)
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(imageVector = Icons.Default.Analytics, contentDescription = null, tint = CavaTerracotta)
            Text(
                text = "Restaurant Manager Hub",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        }

        Text(
            text = "Location: ${selectedRestaurant.name} (${selectedRestaurant.city})",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Store Operational Status Controls Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Store Digital Ordering", fontWeight = FontWeight.Bold)
                    Text(
                        text = if (isStoreActive) "ONLINE • Accepting Mobile & Kiosk Orders" else "OFFLINE • Ordering Suspended",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (isStoreActive) CavaOliveGreen else MaterialTheme.colorScheme.error
                    )
                }

                Switch(
                    checked = isStoreActive,
                    onCheckedChange = { repository.toggleStoreOrderingActive() },
                    modifier = Modifier.testTag("toggle_store_online_status"),
                    colors = SwitchDefaults.colors(checkedThumbColor = CavaOliveGreen)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Key Metric Cards Grid
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricCard(
                title = "Total Revenue",
                value = String.format(Locale.US, "$%.2f", totalRevenue),
                icon = Icons.Default.AttachMoney,
                color = CavaOliveGreen,
                modifier = Modifier.weight(1f)
            )

            MetricCard(
                title = "Orders Today",
                value = "${storeOrders.size}",
                icon = Icons.Default.Receipt,
                color = CavaTerracotta,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricCard(
                title = "Avg Order Value",
                value = String.format(Locale.US, "$%.2f", avgOrderVal),
                icon = Icons.Default.TrendingUp,
                color = CavaGoldAccent,
                modifier = Modifier.weight(1f)
            )

            MetricCard(
                title = "Avg Prep Time",
                value = "${selectedRestaurant.estPrepTimeMinutes} min",
                icon = Icons.Default.Timer,
                color = CavaOliveGreen,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Popular Ingredient Consumption Summary
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("High Volume Ingredients (Today)", fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                IngredientUsageRow("Harissa Honey Chicken", "84 lbs used", "12 lbs remaining", CavaOliveGreen)
                IngredientUsageRow("Crazy Feta® Spread", "42 tubs used", "8 tubs remaining", CavaGoldAccent)
                IngredientUsageRow("SuperGreens Mix", "65 bags used", "4 bags remaining (LOW)", CavaTerracotta)
            }
        }
    }
}

@Composable
private fun MetricCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
                Text(title, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(value, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = color)
        }
    }
}

@Composable
private fun IngredientUsageRow(name: String, used: String, status: String, color: Color) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(name, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(used, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Surface(color = color.copy(alpha = 0.15f), shape = RoundedCornerShape(6.dp)) {
            Text(status, color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(6.dp))
        }
    }
}
