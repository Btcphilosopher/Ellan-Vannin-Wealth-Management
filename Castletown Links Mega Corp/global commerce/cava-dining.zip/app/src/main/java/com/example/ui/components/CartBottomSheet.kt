package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.OrderType
import com.example.repository.CavaRepository
import com.example.ui.theme.CavaOliveGreen
import com.example.ui.theme.CavaTerracotta
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CartBottomSheet(
    repository: CavaRepository,
    onDismiss: () -> Unit,
    onOrderPlaced: (String) -> Unit
) {
    val cartItems by repository.cartItems.collectAsState()
    val appliedPromo by repository.appliedPromoCode.collectAsState()
    val selectedRestaurant by repository.selectedRestaurant.collectAsState()

    var promoInput by remember { mutableStateOf("") }
    var promoError by remember { mutableStateOf(false) }
    var selectedOrderType by remember { mutableStateOf(OrderType.PICKUP) }
    var tipAmount by remember { mutableStateOf(2.00) }
    var isSubmitting by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ShoppingBag,
                        contentDescription = null,
                        tint = CavaOliveGreen
                    )
                    Text(
                        text = "Your CAVA Cart",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                }

                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                }
            }

            Text(
                text = "Ordering from ${selectedRestaurant.name}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            if (cartItems.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.RemoveShoppingCart,
                            contentDescription = null,
                            modifier = Modifier.size(48.dp),
                            tint = MaterialTheme.colorScheme.outline
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Your cart is currently empty.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f, fill = false),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(cartItems) { item ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = item.itemTitle,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    item.customBowl?.let { bowl ->
                                        Text(
                                            text = "Base: ${bowl.bases.joinToString { it.name }}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        if (bowl.protein != null) {
                                            Text(
                                                text = "Protein: ${bowl.protein.name}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        if (bowl.dips.isNotEmpty()) {
                                            Text(
                                                text = "Dips: ${bowl.dips.joinToString { it.name }}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                    Text(
                                        text = String.format(Locale.US, "$%.2f each", item.unitPrice),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = CavaOliveGreen
                                    )
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(
                                        onClick = { repository.updateCartItemQuantity(item.id, -1) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Remove, contentDescription = "Decrease")
                                    }
                                    Text(
                                        text = "${item.quantity}",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp)
                                    )
                                    IconButton(
                                        onClick = { repository.updateCartItemQuantity(item.id, 1) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Add, contentDescription = "Increase")
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Order Type Selector
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OrderType.values().forEach { type ->
                        FilterChip(
                            selected = (selectedOrderType == type),
                            onClick = { selectedOrderType = type },
                            label = { Text(type.label) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Promo Code Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = promoInput,
                        onValueChange = {
                            promoInput = it
                            promoError = false
                        },
                        placeholder = { Text("Promo Code (Try CAVA10)") },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        isError = promoError
                    )
                    Button(
                        onClick = {
                            if (!repository.applyPromoCode(promoInput)) {
                                promoError = true
                            } else {
                                promoInput = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CavaOliveGreen)
                    ) {
                        Text("Apply")
                    }
                }
                if (appliedPromo != null) {
                    Text(
                        text = "Promo '$appliedPromo' Applied: 15% OFF!",
                        style = MaterialTheme.typography.labelSmall,
                        color = CavaOliveGreen
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Cost Summary
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Subtotal")
                            Text(String.format(Locale.US, "$%.2f", repository.cartSubtotal))
                        }
                        if (appliedPromo != null) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Discount (15%)", color = CavaTerracotta)
                                Text(String.format(Locale.US, "-$%.2f", repository.discountAmount), color = CavaTerracotta)
                            }
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Est. Tax (10%)")
                            Text(String.format(Locale.US, "$%.2f", repository.taxAmount))
                        }
                        HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Total", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text(
                                String.format(Locale.US, "$%.2f", repository.cartTotal + tipAmount),
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = CavaOliveGreen
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Checkout Button
                Button(
                    onClick = {
                        isSubmitting = true
                        val newOrder = repository.placeOrder(
                            orderType = selectedOrderType,
                            tipAmount = tipAmount
                        )
                        isSubmitting = false
                        onOrderPlaced(newOrder.id)
                    },
                    enabled = !isSubmitting,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("submit_checkout_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = CavaTerracotta)
                ) {
                    if (isSubmitting) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                    } else {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Lock, contentDescription = null)
                            Text(
                                text = "PLACE ORDER • " + String.format(Locale.US, "$%.2f", repository.cartTotal + tipAmount),
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
