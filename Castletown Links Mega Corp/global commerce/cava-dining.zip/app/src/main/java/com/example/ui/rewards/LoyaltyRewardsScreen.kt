package com.example.ui.rewards

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Reward
import com.example.repository.CavaRepository
import com.example.ui.theme.CavaGoldAccent
import com.example.ui.theme.CavaOliveGreen
import com.example.ui.theme.CavaSandBackground
import com.example.ui.theme.CavaTerracotta

@Composable
fun LoyaltyRewardsScreen(
    repository: CavaRepository
) {
    val loyaltyAccount by repository.loyaltyAccount.collectAsState()
    var redemptionMessage by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CavaSandBackground)
            .padding(16.dp)
    ) {
        // Header Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "CAVA REWARDS",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = CavaTerracotta
                        )
                        Text(
                            text = loyaltyAccount.tierName,
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Surface(
                        shape = CircleShape,
                        color = CavaGoldAccent,
                        modifier = Modifier.size(48.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(imageVector = Icons.Default.Stars, contentDescription = null, tint = Color.Black)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "${loyaltyAccount.pointsBalance} Points",
                    fontSize = 32.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = CavaOliveGreen
                )

                Spacer(modifier = Modifier.height(8.dp))

                val progress = (loyaltyAccount.pointsBalance.toFloat() / loyaltyAccount.nextTierPoints.toFloat()).coerceIn(0f, 1f)
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp),
                    color = CavaOliveGreen,
                    trackColor = CavaOliveGreen.copy(alpha = 0.2f)
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "${loyaltyAccount.nextTierPoints - loyaltyAccount.pointsBalance} pts until Golden Harissa Tier",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        redemptionMessage?.let { msg ->
            Surface(
                color = CavaOliveGreen,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = msg,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(12.dp)
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
        }

        Text(
            text = "Redeem Rewards",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(loyaltyAccount.rewardsAvailable) { reward ->
                val canAfford = loyaltyAccount.pointsBalance >= reward.pointsCost

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = CavaOliveGreen.copy(alpha = 0.15f),
                                modifier = Modifier.size(44.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(imageVector = Icons.Default.CardGiftcard, contentDescription = null, tint = CavaOliveGreen)
                                }
                            }

                            Column {
                                Text(
                                    text = reward.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = reward.description,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "${reward.pointsCost} PTS",
                                    fontWeight = FontWeight.Bold,
                                    color = CavaTerracotta,
                                    style = MaterialTheme.typography.labelMedium
                                )
                            }
                        }

                        Button(
                            onClick = {
                                if (repository.redeemReward(reward)) {
                                    redemptionMessage = "Voucher Redeemed: ${reward.title}!"
                                }
                            },
                            enabled = canAfford,
                            colors = ButtonDefaults.buttonColors(containerColor = CavaTerracotta),
                            modifier = Modifier.testTag("redeem_reward_${reward.id}")
                        ) {
                            Text("REDEEM", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
