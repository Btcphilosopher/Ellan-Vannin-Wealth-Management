package com.example

import com.example.data.model.CartItem
import com.example.ui.viewmodel.CartTotals
import org.junit.Assert.assertEquals
import org.junit.Test

class ExampleUnitTest {

    // Helper method that replicates the ViewModel's calculation logic to test domain formulas
    private fun calculateTotals(items: List<CartItem>, promo: String?): CartTotals {
        val subtotal = items.sumOf { it.totalPrice }
        var discount = 0.0
        val promoAppliedText = ""

        if (promo != null) {
            when (promo.uppercase()) {
                "APPFRIES" -> {
                    val hasFries = items.any { it.menuItemId == "crinklefries" || it.menuItemId == "cheesefries" }
                    if (hasFries && subtotal >= 15.0) {
                        val friesItem = items.find { it.menuItemId == "crinklefries" }
                            ?: items.find { it.menuItemId == "cheesefries" }
                        discount = friesItem?.basePrice ?: 3.25
                    }
                }
                "AUTUMNSHAKE" -> {
                    val shakeItemsTotal = items.filter { it.menuItemId.contains("shake") }.sumOf { it.totalPrice }
                    if (shakeItemsTotal > 0) {
                        discount = shakeItemsTotal * 0.15
                    }
                }
                "SHACKBDAY" -> {
                    discount = subtotal * 0.20
                }
                "REWARDFRIES" -> {
                    val friesItem = items.find { it.menuItemId == "crinklefries" || it.menuItemId == "cheesefries" }
                    if (friesItem != null) {
                        discount = friesItem.basePrice
                    }
                }
                "REWARDSHAKE" -> {
                    val shakeItem = items.find { it.menuItemId.contains("shake") }
                    if (shakeItem != null) {
                        discount = shakeItem.basePrice
                    }
                }
                "REWARD5OFF" -> {
                    if (subtotal >= 15.0) {
                        discount = 5.00
                    }
                }
            }
        }

        val netSubtotal = (subtotal - discount).coerceAtLeast(0.0)
        val tax = netSubtotal * 0.20 // 20% VAT
        val total = netSubtotal + tax

        return CartTotals(subtotal, discount, tax, total, promoAppliedText)
    }

    @Test
    fun testPricingModifiersDoublePatty() {
        val baseBurgerPrice = 7.95
        
        // Single Patty
        val pattyCountSingle = 1
        var calculatedPrice = baseBurgerPrice
        if (pattyCountSingle == 2) calculatedPrice += 3.0
        assertEquals(7.95, calculatedPrice, 0.01)

        // Double Patty (Adds £3.00)
        val pattyCountDouble = 2
        calculatedPrice = baseBurgerPrice
        if (pattyCountDouble == 2) calculatedPrice += 3.0
        assertEquals(10.95, calculatedPrice, 0.01)
    }

    @Test
    fun testBaseCartSubtotalCalculations() {
        val item1 = CartItem(
            menuItemId = "shackburger",
            name = "ShackBurger",
            basePrice = 7.95,
            quantity = 1,
            selectedToppings = "Lettuce",
            selectedPattyCount = 1,
            selectedCheese = true,
            totalPrice = 7.95
        )
        val item2 = CartItem(
            menuItemId = "crinklefries",
            name = "Crinkle Cut Fries",
            basePrice = 3.25,
            quantity = 2,
            selectedToppings = "",
            selectedPattyCount = 1,
            selectedCheese = false,
            totalPrice = 6.50
        )

        val totals = calculateTotals(listOf(item1, item2), null)
        assertEquals(14.45, totals.subtotal, 0.01)
        assertEquals(0.0, totals.discount, 0.01)
        assertEquals(14.45 * 0.20, totals.tax, 0.01)
        assertEquals(14.45 * 1.20, totals.total, 0.01)
    }

    @Test
    fun testBirthdayPromoDiscount() {
        val item = CartItem(
            menuItemId = "shackburger",
            name = "ShackBurger",
            basePrice = 7.95,
            quantity = 2,
            selectedToppings = "Lettuce",
            selectedPattyCount = 1,
            selectedCheese = true,
            totalPrice = 15.90
        )

        val totals = calculateTotals(listOf(item), "SHACKBDAY")
        assertEquals(15.90, totals.subtotal, 0.01)
        assertEquals(15.90 * 0.20, totals.discount, 0.01) // 20% off
        
        val expectedNet = 15.90 * 0.80
        assertEquals(expectedNet, totals.subtotal - totals.discount, 0.01)
        assertEquals(expectedNet * 0.20, totals.tax, 0.01)
    }

    @Test
    fun testAutumnShakePromoDiscount() {
        val item1 = CartItem(
            menuItemId = "vanillashake",
            name = "Vanilla Shake",
            basePrice = 4.95,
            quantity = 1,
            selectedToppings = "",
            selectedPattyCount = 1,
            selectedCheese = false,
            totalPrice = 4.95
        )
        val item2 = CartItem(
            menuItemId = "shackburger",
            name = "ShackBurger",
            basePrice = 7.95,
            quantity = 1,
            selectedToppings = "Lettuce",
            selectedPattyCount = 1,
            selectedCheese = true,
            totalPrice = 7.95
        )

        val totals = calculateTotals(listOf(item1, item2), "AUTUMNSHAKE")
        assertEquals(12.90, totals.subtotal, 0.01)
        assertEquals(4.95 * 0.15, totals.discount, 0.01) // 15% off only the shake item
    }

    @Test
    fun testAppFriesPromoCode() {
        val burger = CartItem(
            menuItemId = "shackburger",
            name = "ShackBurger",
            basePrice = 12.00,
            quantity = 1,
            selectedToppings = "",
            selectedPattyCount = 1,
            selectedCheese = false,
            totalPrice = 12.00
        )
        val fries = CartItem(
            menuItemId = "crinklefries",
            name = "Crinkle Cut Fries",
            basePrice = 3.25,
            quantity = 1,
            selectedToppings = "",
            selectedPattyCount = 1,
            selectedCheese = false,
            totalPrice = 3.25
        )

        // Subtotal = 15.25 (>= 15.0), and has fries -> Fries are free!
        val totalsWithFries = calculateTotals(listOf(burger, fries), "APPFRIES")
        assertEquals(15.25, totalsWithFries.subtotal, 0.01)
        assertEquals(3.25, totalsWithFries.discount, 0.01)

        // If subtotal is < 15, APPFRIES should not apply discount
        val totalsLowSubtotal = calculateTotals(listOf(fries), "APPFRIES")
        assertEquals(3.25, totalsLowSubtotal.subtotal, 0.01)
        assertEquals(0.0, totalsLowSubtotal.discount, 0.01)
    }

    @Test
    fun testLoyaltyPointsRedemptionCalculation() {
        val burger = CartItem(
            menuItemId = "shackburger",
            name = "ShackBurger",
            basePrice = 7.95,
            quantity = 1,
            selectedToppings = "",
            selectedPattyCount = 1,
            selectedCheese = false,
            totalPrice = 7.95
        )

        // £5 off if subtotal >= 15
        val totalsUnderLimit = calculateTotals(listOf(burger), "REWARD5OFF")
        assertEquals(7.95, totalsUnderLimit.subtotal, 0.01)
        assertEquals(0.0, totalsUnderLimit.discount, 0.01)

        val multipleBurgers = CartItem(
            menuItemId = "shackburger",
            name = "ShackBurger",
            basePrice = 7.95,
            quantity = 3,
            selectedToppings = "",
            selectedPattyCount = 1,
            selectedCheese = false,
            totalPrice = 23.85
        )
        val totalsOverLimit = calculateTotals(listOf(multipleBurgers), "REWARD5OFF")
        assertEquals(23.85, totalsOverLimit.subtotal, 0.01)
        assertEquals(5.00, totalsOverLimit.discount, 0.01)
    }
}
