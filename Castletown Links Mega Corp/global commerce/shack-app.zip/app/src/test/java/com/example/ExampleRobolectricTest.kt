package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.ShackDatabase
import com.example.data.model.UserPoints
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    private lateinit var db: ShackDatabase

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, ShackDatabase::class.java)
            .allowMainThreadQueries()
            .build()
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun testAppLabelMatchesShackApp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("ShackApp", appName.replace(" ", ""))
    }

    @Test
    fun testDatabaseWriteAndReadSynchronous() = runBlocking {
        val dao = db.shackDao()
        
        // Write to database
        dao.insertUserPoints(UserPoints(id = 1, points = 420))
        
        // Read directly and synchronously to avoid background Flow subscription hangs in unit tests
        val points = dao.getUserPoints()?.points ?: 0
        assertEquals(420, points)
    }
}
