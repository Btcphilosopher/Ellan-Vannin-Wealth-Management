package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.*

@Database(
    entities = [
        ShackLocation::class,
        MenuItem::class,
        CartItem::class,
        OrderEntity::class,
        RewardEntity::class,
        UserPoints::class,
        PromotionEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class ShackDatabase : RoomDatabase() {
    abstract fun shackDao(): ShackDao

    companion object {
        @Volatile
        private var INSTANCE: ShackDatabase? = null

        fun getDatabase(context: Context): ShackDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ShackDatabase::class.java,
                    "shack_app_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
