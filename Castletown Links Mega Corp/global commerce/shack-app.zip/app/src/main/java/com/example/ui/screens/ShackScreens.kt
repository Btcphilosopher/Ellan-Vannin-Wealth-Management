package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.ShackScreen
import com.example.ui.viewmodel.ShackViewModel
import java.text.SimpleDateFormat
import java.util.*

// --- CUSTOM INTERACTIVE VECTOR CANVAS FOOD ILLUSTRATIONS ---

@Composable
fun BurgerIllustration(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        // Top Bun
        val bunPath = Path().apply {
            moveTo(w * 0.1f, h * 0.4f)
            cubicTo(w * 0.1f, h * 0.1f, w * 0.9f, h * 0.1f, w * 0.9f, h * 0.4f)
            close()
        }
        drawPath(bunPath, Color(0xFFE5A65D))

        // Sesame Seeds
        drawCircle(Color(0xFFFFF3E0), 4f, Offset(w * 0.35f, h * 0.22f))
        drawCircle(Color(0xFFFFF3E0), 4f, Offset(w * 0.5f, h * 0.2f))
        drawCircle(Color(0xFFFFF3E0), 4f, Offset(w * 0.65f, h * 0.25f))

        // Lettuce (Wavy green line)
        drawRoundRect(
            color = Color(0xFF5C963E),
            topLeft = Offset(w * 0.05f, h * 0.4f),
            size = Size(w * 0.9f, h * 0.08f),
            cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
        )

        // Tomato Slits
        drawRoundRect(
            color = Color(0xFFD32F2F),
            topLeft = Offset(w * 0.15f, h * 0.48f),
            size = Size(w * 0.7f, h * 0.07f),
            cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
        )

        // Cheese Melt (Vibrant yellow spilling)
        val cheesePath = Path().apply {
            moveTo(w * 0.08f, h * 0.55f)
            lineTo(w * 0.92f, h * 0.55f)
            lineTo(w * 0.8f, h * 0.68f)
            lineTo(w * 0.65f, h * 0.55f)
            lineTo(w * 0.45f, h * 0.72f) // Drip
            lineTo(w * 0.3f, h * 0.55f)
            close()
        }
        drawPath(cheesePath, Color(0xFFFFC107))

        // Beef Patty
        drawRoundRect(
            color = Color(0xFF5D4037),
            topLeft = Offset(w * 0.07f, h * 0.58f),
            size = Size(w * 0.86f, h * 0.16f),
            cornerRadius = CornerRadius(8.dp.toPx(), 8.dp.toPx())
        )

        // Bottom Bun
        drawRoundRect(
            color = Color(0xFFE5A65D),
            topLeft = Offset(w * 0.1f, h * 0.74f),
            size = Size(w * 0.8f, h * 0.14f),
            cornerRadius = CornerRadius(8.dp.toPx(), 8.dp.toPx())
        )
    }
}

@Composable
fun FriesIllustration(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        // Fries Holder Sleeve (Red with off-white Shack logo background)
        val sleevePath = Path().apply {
            moveTo(w * 0.2f, h * 0.45f)
            lineTo(w * 0.8f, h * 0.45f)
            lineTo(w * 0.7f, h * 0.95f)
            lineTo(w * 0.3f, h * 0.95f)
            close()
        }
        // Golden Fries sticking out
        val fryColor = Color(0xFFFFD54F)
        val fryWidth = w * 0.07f

        // Draw multiple yellow crinkle cut fries pointing up
        for (i in 0..6) {
            val startX = w * 0.25f + (i * w * 0.08f)
            val fryHeight = h * 0.35f + (Math.sin(i.toDouble() * 1.5).toFloat() * h * 0.08f)
            drawRoundRect(
                color = fryColor,
                topLeft = Offset(startX, h * 0.48f - fryHeight),
                size = Size(fryWidth, fryHeight),
                cornerRadius = CornerRadius(3.dp.toPx(), 3.dp.toPx())
            )
            // Draw small crinkle ridges (horizontal dark lines)
            for (y in 1..4) {
                val lineY = h * 0.48f - fryHeight + (y * fryHeight * 0.2f)
                if (lineY < h * 0.45f) {
                    drawLine(
                        color = Color(0xFFF57F17),
                        start = Offset(startX, lineY),
                        end = Offset(startX + fryWidth, lineY),
                        strokeWidth = 2.dp.toPx()
                    )
                }
            }
        }

        // Draw sleeve
        drawPath(sleevePath, Color(0xFFD32F2F))

        // Sleeve graphic (Logo green badge)
        drawCircle(
            color = Color.White,
            radius = w * 0.12f,
            center = Offset(w * 0.5f, h * 0.7f)
        )
        drawCircle(
            color = ShackGreen,
            radius = w * 0.09f,
            center = Offset(w * 0.5f, h * 0.7f)
        )
    }
}

@Composable
fun ShakeIllustration(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        // Straw (Angled line)
        drawLine(
            color = Color(0xFFD32F2F),
            start = Offset(w * 0.6f, h * 0.05f),
            end = Offset(w * 0.45f, h * 0.4f),
            strokeWidth = 6.dp.toPx()
        )

        // Whipped Cream (Domes at top)
        drawCircle(Color(0xFFFFF9C4), w * 0.15f, Offset(w * 0.5f, h * 0.32f))
        drawCircle(Color(0xFFFFF9C4), w * 0.12f, Offset(w * 0.4f, h * 0.35f))
        drawCircle(Color(0xFFFFF9C4), w * 0.12f, Offset(w * 0.6f, h * 0.35f))

        // Cup Body (Trapezoid, translucent white)
        val cupPath = Path().apply {
            moveTo(w * 0.25f, h * 0.4f)
            lineTo(w * 0.75f, h * 0.4f)
            lineTo(w * 0.65f, h * 0.95f)
            lineTo(w * 0.35f, h * 0.95f)
            close()
        }
        drawPath(cupPath, Color(0xFFEEEEEE))

        // Liquid fill inside (Vanilla creamy color or Chocolate)
        val fillPath = Path().apply {
            moveTo(w * 0.27f, h * 0.45f)
            lineTo(w * 0.73f, h * 0.45f)
            lineTo(w * 0.66f, h * 0.93f)
            lineTo(w * 0.34f, h * 0.93f)
            close()
        }
        drawPath(fillPath, Color(0xFFFFFDE7))

        // Retro Cup lines
        drawLine(
            color = ShackGreen,
            start = Offset(w * 0.3f, h * 0.6f),
            end = Offset(w * 0.7f, h * 0.6f),
            strokeWidth = 3.dp.toPx()
        )
        drawLine(
            color = ShackGreen,
            start = Offset(w * 0.32f, h * 0.66f),
            end = Offset(w * 0.68f, h * 0.66f),
            strokeWidth = 3.dp.toPx()
        )
    }
}

@Composable
fun DrinkIllustration(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        // Cap (Translucent rounded top)
        drawRoundRect(
            color = Color(0xFFCFD8DC),
            topLeft = Offset(w * 0.23f, h * 0.33f),
            size = Size(w * 0.54f, h * 0.08f),
            cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
        )

        // Straw (Angled line)
        drawLine(
            color = Color(0xFF549C30),
            start = Offset(w * 0.5f, h * 0.1f),
            end = Offset(w * 0.5f, h * 0.35f),
            strokeWidth = 6.dp.toPx()
        )

        // Cup Body
        val cupPath = Path().apply {
            moveTo(w * 0.25f, h * 0.4f)
            lineTo(w * 0.75f, h * 0.4f)
            lineTo(w * 0.65f, h * 0.95f)
            lineTo(w * 0.35f, h * 0.95f)
            close()
        }
        drawPath(cupPath, Color(0xFFECEFF1))

        // Lemon Juice Fill (Vibrant Yellow)
        val fillPath = Path().apply {
            moveTo(w * 0.27f, h * 0.45f)
            lineTo(w * 0.73f, h * 0.45f)
            lineTo(w * 0.66f, h * 0.93f)
            lineTo(w * 0.34f, h * 0.93f)
            close()
        }
        drawPath(fillPath, Color(0xFFFFEE58))

        // Small Lemon outline
        drawCircle(
            color = Color(0xFFFFF59D),
            radius = w * 0.1f,
            center = Offset(w * 0.5f, h * 0.68f)
        )
    }
}

@Composable
fun FoodGraphic(category: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(Color.White, RoundedCornerShape(12.dp))
            .padding(8.dp),
        contentAlignment = Alignment.Center
    ) {
        when (category.uppercase()) {
            "BURGERS" -> BurgerIllustration(modifier = Modifier.fillMaxSize())
            "FRIES" -> FriesIllustration(modifier = Modifier.fillMaxSize())
            "SHAKES" -> ShakeIllustration(modifier = Modifier.fillMaxSize())
            "DRINKS", "LEMONADE" -> DrinkIllustration(modifier = Modifier.fillMaxSize())
            else -> BurgerIllustration(modifier = Modifier.fillMaxSize()) // Fallback
        }
    }
}


// --- SCREEN: HOME ---

@Composable
fun HomeScreen(viewModel: ShackViewModel) {
    val selectedLoc by viewModel.selectedLocation.collectAsState()
    val userPts by viewModel.userPoints.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        // Brand Header & Location Quick-Selector
        item {
            Column(modifier = Modifier.padding(top = 16.dp)) {
                Text(
                    text = "SHAKE SHACK",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 24.sp,
                    color = DarkCharcoal,
                    letterSpacing = 1.5.sp
                )
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .background(CreamSand, RoundedCornerShape(8.dp))
                        .clickable { viewModel.navigateTo(ShackScreen.LOCATION_SELECTOR) }
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = "Location Pin",
                        tint = ShackGreen,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = selectedLoc?.name ?: "Select a Shack Location",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = DarkCharcoal
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.Default.ArrowDropDown,
                        contentDescription = "Expand Location Selector",
                        tint = DarkGray,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // Hero Graphic & Primary CTAs
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CreamSand),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.5.dp, DarkCharcoal, RoundedCornerShape(16.dp))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1.2f)) {
                        Text(
                            text = "GOOD FOOD.\nGOOD MOOD.",
                            fontWeight = FontWeight.Black,
                            fontSize = 26.sp,
                            lineHeight = 32.sp,
                            color = DarkCharcoal
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = { viewModel.navigateTo(ShackScreen.MENU) },
                            colors = ButtonDefaults.buttonColors(containerColor = ShackGreen),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .testTag("order_now_button")
                                .border(1.dp, DarkCharcoal, RoundedCornerShape(8.dp))
                        ) {
                            Text("ORDER NOW", fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                    Box(modifier = Modifier.weight(0.8f).height(120.dp)) {
                        BurgerIllustration(modifier = Modifier.fillMaxSize())
                    }
                }
            }
        }

        // Loyalty Quick Panel
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCharcoal),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.navigateTo(ShackScreen.REWARDS) }
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("SHACK REWARDS", fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = ShackGreen)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("$userPts Points Available", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = Color.White)
                    }
                    Button(
                        onClick = { viewModel.navigateTo(ShackScreen.REWARDS) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text("REDEEM", color = DarkCharcoal, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }

        // "Order Again" Section
        item {
            Column {
                Text(
                    text = "ORDER AGAIN",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 18.sp,
                    color = DarkCharcoal,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, LightGray, RoundedCornerShape(12.dp))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Leicester Square Order", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = DarkCharcoal)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("ShackBurger + Fries + Shake", fontSize = 13.sp, color = DarkGray)
                        }

                        Button(
                            onClick = {
                                // Trigger instant demo order-again
                                val fakeOrder = OrderEntity(
                                    id = "PREV-1",
                                    locationId = "london_leicester_square",
                                    locationName = "Leicester Square",
                                    status = "COMPLETED",
                                    subtotal = 16.15,
                                    tax = 3.23,
                                    total = 19.38,
                                    timestamp = 1727284800000L,
                                    readyTime = "12:30",
                                    itemsSummaryJson = "1x ShackBurger, 1x Crinkle Cut Fries, 1x Vanilla Shake"
                                )
                                viewModel.repeatOrder(fakeOrder)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CreamSand),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, DarkCharcoal)
                        ) {
                            Text("REORDER", color = DarkCharcoal, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // "What's New" Section
        item {
            Column {
                Text(
                    text = "WHAT'S NEW",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 18.sp,
                    color = DarkCharcoal,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    item {
                        EditorialCard(
                            tag = "NEW",
                            title = "Black Truffle Burger",
                            desc = "Our limited chef collaboration burger. Fresh black truffle sauce.",
                            illustration = { BurgerIllustration(modifier = Modifier.fillMaxSize()) },
                            onClick = {
                                viewModel.navigateTo(ShackScreen.MENU)
                            }
                        )
                    }
                    item {
                        EditorialCard(
                            tag = "LIMITED TIME",
                            title = "Autumn Pumpkin Shake",
                            desc = "Hand-spun pumpkin custard, whipped cream & spiced crunch.",
                            illustration = { ShakeIllustration(modifier = Modifier.fillMaxSize()) },
                            onClick = {
                                viewModel.navigateTo(ShackScreen.MENU)
                            }
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun EditorialCard(tag: String, title: String, desc: String, illustration: @Composable () -> Unit, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .width(280.dp)
            .clickable { onClick() }
            .border(1.dp, LightGray, RoundedCornerShape(12.dp)),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = CreamSand)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Box(
                modifier = Modifier
                    .background(ShackGreen, RoundedCornerShape(4.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(tag, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = Color.White)
            }
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1.2f)) {
                    Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = DarkCharcoal)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(desc, fontSize = 12.sp, color = DarkGray, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
                Box(modifier = Modifier.size(70.dp).weight(0.8f)) {
                    illustration()
                }
            }
        }
    }
}


// --- SCREEN: LOCATION SELECTOR ---

@Composable
fun LocationSelectorScreen(viewModel: ShackViewModel) {
    val locations by viewModel.locations.collectAsState()
    var searchVal by remember { mutableStateOf("") }
    val focusManager = LocalFocusManager.current

    BackHandler {
        viewModel.navigateBack()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(bottom = 16.dp)
        ) {
            IconButton(onClick = { viewModel.navigateBack() }) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = DarkCharcoal)
            }
            Text("Find a Shack", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, color = DarkCharcoal)
        }

        OutlinedTextField(
            value = searchVal,
            onValueChange = { searchVal = it },
            placeholder = { Text("Search by City, Postcode or Neighbourhood...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search Icon") },
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color.White,
                unfocusedContainerColor = Color.White,
                focusedIndicatorColor = ShackGreen,
                unfocusedIndicatorColor = LightGray
            ),
            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { focusManager.clearFocus() })
        )

        val filtered = locations.filter {
            it.name.contains(searchVal, ignoreCase = true) || it.city.contains(searchVal, ignoreCase = true)
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            if (filtered.isEmpty()) {
                item {
                    Text(
                        "No Shacks found matching your search.",
                        color = DarkGray,
                        fontSize = 14.sp,
                        modifier = Modifier.padding(top = 16.dp),
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                items(filtered) { shack ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = CreamSand),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.selectLocation(shack) }
                            .border(1.dp, LightGray, RoundedCornerShape(12.dp))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = shack.name,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 16.sp,
                                    color = DarkCharcoal,
                                    modifier = Modifier.weight(1.2f)
                                )
                                Text(
                                    text = "${shack.distance} mi",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = ShackGreen
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(shack.openingHours, fontSize = 12.sp, color = DarkGray)
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    if (shack.pickupAvailable) {
                                        Badge(containerColor = ShackGreen) {
                                            Text("Pickup", color = Color.White, fontSize = 10.sp, modifier = Modifier.padding(4.dp))
                                        }
                                    }
                                    if (shack.dineInAvailable) {
                                        Badge(containerColor = DarkCharcoal) {
                                            Text("Dine In", color = Color.White, fontSize = 10.sp, modifier = Modifier.padding(4.dp))
                                        }
                                    }
                                }
                                Text(
                                    "Ready in ~${shack.estimatedPrepTime} min",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 12.sp,
                                    color = DarkCharcoal
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}


// --- SCREEN: MENU ---

@Composable
fun MenuScreen(viewModel: ShackViewModel) {
    val items by viewModel.menuItems.collectAsState()
    val categories = listOf("BURGERS", "CHICKEN", "HOT DOGS", "FRIES", "SHAKES", "DRINKS", "LIMITED TIME")
    var selectedCategory by remember { mutableStateOf("BURGERS") }

    BackHandler {
        viewModel.navigateBack()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Toolbar / Back
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateBack() }) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Text("Order Ahead", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, color = DarkCharcoal)
        }

        // Horizontal Category Tab Bar
        ScrollableTabRow(
            selectedTabIndex = categories.indexOf(selectedCategory),
            containerColor = CreamSand,
            contentColor = ShackGreen,
            edgePadding = 16.dp
        ) {
            categories.forEachIndexed { index, title ->
                Tab(
                    selected = selectedCategory == title,
                    onClick = { selectedCategory = title },
                    text = { Text(title, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp) },
                    selectedContentColor = ShackGreen,
                    unselectedContentColor = DarkGray
                )
            }
        }

        // Menu Items List
        val filteredItems = items.filter { it.category.uppercase() == selectedCategory.uppercase() }

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(filteredItems) { menuItem ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.selectMenuItem(menuItem) }
                        .border(1.dp, LightGray, RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FoodGraphic(
                            category = menuItem.id,
                            modifier = Modifier
                                .size(80.dp)
                                .border(1.dp, CreamSand, RoundedCornerShape(12.dp))
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1.2f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    menuItem.name,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 16.sp,
                                    color = DarkCharcoal
                                )
                                if (menuItem.isAppExclusive) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Box(
                                        modifier = Modifier
                                            .background(DarkCharcoal, RoundedCornerShape(4.dp))
                                            .padding(horizontal = 4.dp, vertical = 2.dp)
                                    ) {
                                        Text("App Exclusive", fontSize = 8.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                menuItem.description,
                                fontSize = 12.sp,
                                color = DarkGray,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                "£${String.format("%.2f", menuItem.basePrice)}",
                                fontWeight = FontWeight.Black,
                                fontSize = 15.sp,
                                color = ShackGreen
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = { viewModel.selectMenuItem(menuItem) },
                            colors = ButtonDefaults.buttonColors(containerColor = ShackGreen),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .testTag("${menuItem.id}_add")
                                .border(1.dp, DarkCharcoal, RoundedCornerShape(8.dp))
                        ) {
                            Text("ADD", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}


// --- SCREEN: MENU ITEM DETAIL (CUSTOMISE) ---

@Composable
fun ItemDetailScreen(viewModel: ShackViewModel) {
    val menuItem by viewModel.selectedMenuItem.collectAsState()
    val pattyCount by viewModel.selectedPattyCount.collectAsState()
    val cheeseChecked by viewModel.selectedCheese.collectAsState()
    val toppingsChecked by viewModel.selectedToppings.collectAsState()
    val qty by viewModel.quantitySelector.collectAsState()
    val dynamicPrice by viewModel.dynamicItemPrice.collectAsState()

    var showNutritionModal by remember { mutableStateOf(false) }

    BackHandler {
        viewModel.navigateBack()
    }

    val item = menuItem ?: return

    Scaffold(
        bottomBar = {
            Surface(
                tonalElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Quantity Control
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.background(CreamSand, RoundedCornerShape(8.dp))
                    ) {
                        IconButton(onClick = { if (qty > 1) viewModel.quantitySelector.value = qty - 1 }) {
                            Icon(Icons.Default.Remove, contentDescription = "Decrease Quantity")
                        }
                        Text("$qty", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        IconButton(onClick = { viewModel.quantitySelector.value = qty + 1 }) {
                            Icon(Icons.Default.Add, contentDescription = "Increase Quantity")
                        }
                    }

                    // Add to Order button with dynamic pricing
                    Button(
                        onClick = { viewModel.addToCart() },
                        colors = ButtonDefaults.buttonColors(containerColor = ShackGreen),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .testTag("add_to_order_button")
                            .border(1.dp, DarkCharcoal, RoundedCornerShape(8.dp))
                            .height(48.dp)
                    ) {
                        Text(
                            text = "ADD TO ORDER · £${String.format("%.2f", dynamicPrice * qty)}",
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(innerPadding)
        ) {
            // Header Image Box with FoodGraphic
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(240.dp)
                    .background(CreamSand)
            ) {
                IconButton(
                    onClick = { viewModel.navigateBack() },
                    modifier = Modifier
                        .padding(16.dp)
                        .background(Color.White, CircleShape)
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Close details")
                }

                FoodGraphic(
                    category = item.id,
                    modifier = Modifier
                        .size(160.dp)
                        .align(Alignment.Center)
                )
            }

            // Product Details
            Column(modifier = Modifier.padding(16.dp)) {
                Text(item.name, fontWeight = FontWeight.Black, fontSize = 24.sp, color = DarkCharcoal)
                Spacer(modifier = Modifier.height(8.dp))
                Text(item.description, fontSize = 14.sp, color = DarkGray, lineHeight = 20.sp)
                Spacer(modifier = Modifier.height(16.dp))

                // Nutrition Info trigger
                OutlinedButton(
                    onClick = { showNutritionModal = true },
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, DarkCharcoal)
                ) {
                    Icon(Icons.Outlined.Info, contentDescription = "Nutrition Info", modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("ALLERGENS & NUTRITION", fontWeight = FontWeight.Bold, color = DarkCharcoal)
                }

                Spacer(modifier = Modifier.height(24.dp))
                Divider(color = LightGray)
                Spacer(modifier = Modifier.height(16.dp))

                // Customizations (only if BURGERS category)
                if (item.category.uppercase() == "BURGERS") {
                    Text("CUSTOMISE YOUR BURGER", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = DarkCharcoal)
                    Spacer(modifier = Modifier.height(16.dp))

                    // Single or Double Patty Selector
                    Text("PATTY COUNT", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = DarkGray)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .weight(1f)
                                .background(if (pattyCount == 1) CreamSand else Color.White, RoundedCornerShape(8.dp))
                                .border(1.5.dp, if (pattyCount == 1) ShackGreen else LightGray, RoundedCornerShape(8.dp))
                                .clickable { viewModel.selectedPattyCount.value = 1 }
                                .padding(12.dp)
                        ) {
                            RadioButton(selected = pattyCount == 1, onClick = { viewModel.selectedPattyCount.value = 1 })
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Single", fontWeight = FontWeight.Bold)
                        }
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .weight(1f)
                                .background(if (pattyCount == 2) CreamSand else Color.White, RoundedCornerShape(8.dp))
                                .border(1.5.dp, if (pattyCount == 2) ShackGreen else LightGray, RoundedCornerShape(8.dp))
                                .clickable { viewModel.selectedPattyCount.value = 2 }
                                .padding(12.dp)
                        ) {
                            RadioButton(selected = pattyCount == 2, onClick = { viewModel.selectedPattyCount.value = 2 })
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Double (+£3.00)", fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Cheese toggle
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.selectedCheese.value = !cheeseChecked }
                            .padding(vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("MELTED CHEESE", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("Classic melted American cheese slices", fontSize = 11.sp, color = DarkGray)
                        }
                        Switch(
                            checked = cheeseChecked,
                            onCheckedChange = { viewModel.selectedCheese.value = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = ShackGreen, checkedTrackColor = CreamSand)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Divider(color = LightGray)
                    Spacer(modifier = Modifier.height(16.dp))

                    // Toppings List (Toggle)
                    Text("TOPPINGS", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = DarkGray)
                    Spacer(modifier = Modifier.height(8.dp))

                    val allToppings = listOf("Lettuce", "Tomato", "Pickles", "ShackSauce", "Applewood Smoked Bacon")

                    allToppings.forEach { topping ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    val current = toppingsChecked.toMutableList()
                                    if (current.contains(topping)) {
                                        current.remove(topping)
                                    } else {
                                        current.add(topping)
                                    }
                                    viewModel.selectedToppings.value = current
                                }
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = toppingsChecked.contains(topping),
                                onCheckedChange = {
                                    val current = toppingsChecked.toMutableList()
                                    if (it) current.add(topping) else current.remove(topping)
                                    viewModel.selectedToppings.value = current
                                }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(topping, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        }
                    }
                } else {
                    // Simple informational modifiers for other categories
                    Text("PREPARATION", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = DarkCharcoal)
                    Spacer(modifier = Modifier.height(12.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = CreamSand),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            "This item is freshly hand-made to order using premium, local ingredients according to our rigorous signature standards.",
                            modifier = Modifier.padding(12.dp),
                            fontSize = 12.sp,
                            color = DarkGray,
                            lineHeight = 18.sp
                        )
                    }
                }
            }
        }
    }

    // Nutrition Modal
    if (showNutritionModal) {
        Dialog(onDismissRequest = { showNutritionModal = false }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .border(2.dp, DarkCharcoal, RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Nutrition & Allergens", fontWeight = FontWeight.Black, fontSize = 18.sp, color = DarkCharcoal)
                        IconButton(onClick = { showNutritionModal = false }) {
                            Icon(Icons.Default.Close, contentDescription = "Close Modal")
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))

                    Text("NUTRITIONAL INFORMATION", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = DarkGray)
                    Spacer(modifier = Modifier.height(8.dp))

                    NutritionItemRow("Calories", "${item.calories} kcal")
                    NutritionItemRow("Protein", item.protein)
                    NutritionItemRow("Fat", item.fat)
                    NutritionItemRow("Carbohydrates", item.carbohydrates)
                    NutritionItemRow("Sodium", item.sodium)

                    Spacer(modifier = Modifier.height(16.dp))
                    Divider()
                    Spacer(modifier = Modifier.height(16.dp))

                    Text("ALLERGEN CHECKLIST", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = DarkGray)
                    Spacer(modifier = Modifier.height(8.dp))
                    if (item.allergens.isEmpty()) {
                        Text("No major allergens reported.", fontSize = 14.sp)
                    } else {
                        val allergenList = item.allergens.split(", ")
                        allergenList.forEach { allergen ->
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Warning, contentDescription = "Allergen Warning", tint = TomatoRed, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("CONTAINS: $allergen", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        "*Synthetic data listed for product-testing purposes only. Changes in preparation may alter allergen and nutritional statistics.",
                        fontSize = 10.sp,
                        color = DarkGray,
                        lineHeight = 14.sp
                    )
                }
            }
        }
    }
}

@Composable
fun NutritionItemRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontWeight = FontWeight.SemiBold, color = DarkGray, fontSize = 14.sp)
        Text(value, fontWeight = FontWeight.Bold, color = DarkCharcoal, fontSize = 14.sp)
    }
}


// --- SCREEN: CART ---

@Composable
fun CartScreen(viewModel: ShackViewModel) {
    val items by viewModel.cartItems.collectAsState()
    val totals by viewModel.cartTotals.collectAsState()
    val promoApplied by viewModel.appliedPromoCode.collectAsState()
    val promoError by viewModel.promoError.collectAsState()

    var textPromoCode by remember { mutableStateOf("") }
    val focusManager = LocalFocusManager.current

    BackHandler {
        viewModel.navigateBack()
    }

    Scaffold(
        bottomBar = {
            if (items.isNotEmpty()) {
                Surface(
                    tonalElevation = 8.dp
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("ESTIMATED TOTAL", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = DarkGray)
                            Text("£${String.format("%.2f", totals.total)}", fontWeight = FontWeight.Black, fontSize = 20.sp, color = ShackGreen)
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = { viewModel.navigateTo(ShackScreen.CHECKOUT) },
                            colors = ButtonDefaults.buttonColors(containerColor = ShackGreen),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("continue_to_checkout_button")
                                .border(1.dp, DarkCharcoal, RoundedCornerShape(8.dp))
                                .height(48.dp)
                        ) {
                            Text("CONTINUE TO CHECKOUT", fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(bottom = 16.dp)
            ) {
                IconButton(onClick = { viewModel.navigateBack() }) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                }
                Text("Your Order", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, color = DarkCharcoal)
            }

            if (items.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Outlined.ShoppingCart,
                            contentDescription = "Empty Basket",
                            tint = DarkGray,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("Your cart is empty!", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Add some legendary burgers or custard shakes to start order.", color = DarkGray, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { viewModel.navigateTo(ShackScreen.MENU) },
                            colors = ButtonDefaults.buttonColors(containerColor = ShackGreen)
                        ) {
                            Text("VIEW MENU", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(items) { cartItem ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, LightGray, RoundedCornerShape(12.dp)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        "${cartItem.quantity}x ${cartItem.name}",
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 16.sp,
                                        color = DarkCharcoal
                                    )
                                    if (cartItem.selectedToppings.isNotEmpty()) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            "Toppings: ${cartItem.selectedToppings}",
                                            fontSize = 11.sp,
                                            color = DarkGray
                                        )
                                    }
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        "£${String.format("%.2f", cartItem.totalPrice)}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    IconButton(onClick = { viewModel.deleteCartItem(cartItem) }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete item", tint = TomatoRed)
                                    }
                                }
                            }
                        }
                    }

                    // Promo Code Input Row
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = CreamSand),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("PROMO CODE", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = DarkGray)
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    OutlinedTextField(
                                        value = textPromoCode,
                                        onValueChange = { textPromoCode = it },
                                        placeholder = { Text("Enter code (e.g., APPFRIES)", fontSize = 13.sp) },
                                        colors = TextFieldDefaults.colors(
                                            focusedContainerColor = Color.White,
                                            unfocusedContainerColor = Color.White,
                                            focusedIndicatorColor = ShackGreen
                                        ),
                                        modifier = Modifier.weight(1f),
                                        singleLine = true,
                                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                                        keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() })
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Button(
                                        onClick = {
                                            viewModel.applyPromoCode(textPromoCode)
                                            focusManager.clearFocus()
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = ShackGreen),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text("APPLY", fontWeight = FontWeight.Bold)
                                    }
                                }

                                if (promoError != null) {
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(promoError ?: "", color = TomatoRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }

                                if (promoApplied != null) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.CheckCircle, contentDescription = "Applied", tint = ShackGreen, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("CODE APPLIED: $promoApplied", fontWeight = FontWeight.Bold, color = ShackGreen, fontSize = 12.sp)
                                        }
                                        TextButton(onClick = { viewModel.removePromoCode() }) {
                                            Text("REMOVE", color = TomatoRed, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        }
                                    }
                                    if (totals.promoAppliedText.isNotEmpty()) {
                                        Text(totals.promoAppliedText, fontSize = 11.sp, color = DarkGray)
                                    }
                                }
                            }
                        }
                    }

                    // Price Summary breakdown
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = CreamSand),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                SummaryRow("Subtotal", "£${String.format("%.2f", totals.subtotal)}")
                                if (totals.discount > 0) {
                                    SummaryRow("Discount", "-£${String.format("%.2f", totals.discount)}", tintColor = TomatoRed)
                                }
                                SummaryRow("VAT (20%)", "£${String.format("%.2f", totals.tax)}")
                                Spacer(modifier = Modifier.height(8.dp))
                                Divider()
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Grand Total", fontWeight = FontWeight.Black, fontSize = 16.sp, color = DarkCharcoal)
                                    Text("£${String.format("%.2f", totals.total)}", fontWeight = FontWeight.Black, fontSize = 18.sp, color = ShackGreen)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SummaryRow(label: String, value: String, tintColor: Color = DarkCharcoal) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 13.sp, color = DarkGray, fontWeight = FontWeight.SemiBold)
        Text(value, fontSize = 13.sp, color = tintColor, fontWeight = FontWeight.Bold)
    }
}


// --- SCREEN: CHECKOUT ---

@Composable
fun CheckoutScreen(viewModel: ShackViewModel) {
    val selectedLoc by viewModel.selectedLocation.collectAsState()
    val totals by viewModel.cartTotals.collectAsState()
    val cartItems by viewModel.cartItems.collectAsState()

    val timeOptions = listOf("AS SOON AS POSSIBLE", "12:15 PM", "12:30 PM", "12:45 PM", "01:00 PM", "01:15 PM")
    val selectedTime by viewModel.selectedPickupTime.collectAsState()

    val paymentOptions = listOf("Google Pay", "Apple Pay", "Simulated Credit Card")
    val selectedPayment by viewModel.selectedPaymentMethod.collectAsState()

    BackHandler {
        viewModel.navigateBack()
    }

    Scaffold(
        bottomBar = {
            Surface(
                tonalElevation = 8.dp
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Button(
                        onClick = { viewModel.placeOrder() },
                        colors = ButtonDefaults.buttonColors(containerColor = ShackGreen),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("submit_checkout")
                            .border(1.dp, DarkCharcoal, RoundedCornerShape(8.dp))
                            .height(48.dp)
                    ) {
                        Text(
                            "PLACE ORDER · £${String.format("%.2f", totals.total)}",
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(bottom = 16.dp)
            ) {
                IconButton(onClick = { viewModel.navigateBack() }) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                }
                Text("Checkout", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, color = DarkCharcoal)
            }

            // Order Summary
            Text("ORDER SUMMARY", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, color = DarkGray)
            Spacer(modifier = Modifier.height(8.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, LightGray),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    cartItems.forEach { item ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("${item.quantity}x ${item.name}", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            Text("£${String.format("%.2f", item.totalPrice)}", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Divider(modifier = Modifier.padding(vertical = 8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Checkout Total", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("£${String.format("%.2f", totals.total)}", fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, color = ShackGreen)
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Pickup Location
            Text("PICKUP LOCATION", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, color = DarkGray)
            Spacer(modifier = Modifier.height(8.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = CreamSand),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.LocationOn, contentDescription = "Location Pin", tint = ShackGreen)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(selectedLoc?.name ?: "Leicester Square", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text("Ready around ${selectedLoc?.estimatedPrepTime ?: 10} minutes after ordering", fontSize = 12.sp, color = DarkGray)
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Pickup Schedule Choices
            Text("PICKUP TIME", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, color = DarkGray)
            Spacer(modifier = Modifier.height(4.dp))
            Text("Your Shack will start cooking your order at the right time to guarantee made-to-order quality.", fontSize = 11.sp, color = DarkGray)
            Spacer(modifier = Modifier.height(12.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(timeOptions) { time ->
                    val isSel = time == selectedTime
                    Box(
                        modifier = Modifier
                            .background(if (isSel) ShackGreen else Color.White, RoundedCornerShape(8.dp))
                            .border(1.5.dp, if (isSel) ShackGreen else LightGray, RoundedCornerShape(8.dp))
                            .clickable { viewModel.selectedPickupTime.value = time }
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                    ) {
                        Text(
                            text = time,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = if (isSel) Color.White else DarkCharcoal
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Payment Methods Choice
            Text("SECURE PAYMENT", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, color = DarkGray)
            Spacer(modifier = Modifier.height(4.dp))
            Text("Simulated transaction environment. No real funds collected.", fontSize = 11.sp, color = TomatoRed)
            Spacer(modifier = Modifier.height(12.dp))

            paymentOptions.forEach { method ->
                val isSel = method == selectedPayment
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                        .background(if (isSel) CreamSand else Color.White, RoundedCornerShape(8.dp))
                        .border(1.5.dp, if (isSel) ShackGreen else LightGray, RoundedCornerShape(8.dp))
                        .clickable { viewModel.selectedPaymentMethod.value = method }
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (method.contains("Pay")) Icons.Default.CheckCircle else Icons.Default.CreditCard,
                            contentDescription = "Payment Icon",
                            tint = if (isSel) ShackGreen else DarkGray
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(method, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    RadioButton(selected = isSel, onClick = { viewModel.selectedPaymentMethod.value = method })
                }
            }
        }
    }
}


// --- SCREEN: ORDER TRACKER (LIVE & RECEIPTS) ---

@Composable
fun OrderTrackerScreen(viewModel: ShackViewModel) {
    val activeOrder by viewModel.activeOrder.collectAsState()

    BackHandler {
        // Clear to Home to avoid back loops
        viewModel.clearToHome()
    }

    val order = activeOrder ?: return

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Tracker Toolbar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Live Tracker", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, color = DarkCharcoal)
            IconButton(onClick = { viewModel.clearToHome() }) {
                Icon(Icons.Default.Home, contentDescription = "Home", tint = ShackGreen)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Large status illustration card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = CreamSand),
            modifier = Modifier
                .fillMaxWidth()
                .border(2.dp, DarkCharcoal, RoundedCornerShape(16.dp))
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "ORDER STATUS",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = ShackGreen,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                // Transition Status Text
                val statusText = when (order.status) {
                    "ORDER_CREATED" -> "ORDER PLACED"
                    "PAYMENT_PENDING" -> "AUTHORISING PAYMENT"
                    "PAYMENT_AUTHORISED" -> "PAYMENT COMPLETED"
                    "ORDER_ACCEPTED" -> "ACCEPTED & QUEUED"
                    "PREPARING" -> "COOKING YOUR FOOD"
                    "READY" -> "READY FOR PICKUP!"
                    else -> "COLLECTED & ENJOYED!"
                }

                Text(
                    text = statusText,
                    fontWeight = FontWeight.Black,
                    fontSize = 24.sp,
                    color = DarkCharcoal,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Visual Custom Indicator Progress
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val steps = listOf("PAYMENT_AUTHORISED", "ORDER_ACCEPTED", "PREPARING", "READY")
                    val currentIdx = steps.indexOf(order.status)

                    steps.forEachIndexed { idx, _ ->
                        val isFinished = idx <= currentIdx || order.status == "COMPLETED"
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(6.dp)
                                .background(if (isFinished) ShackGreen else LightGray, RoundedCornerShape(3.dp))
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Custom Graphic changing dynamically based on status
                Box(modifier = Modifier.size(100.dp)) {
                    when (order.status) {
                        "PREPARING" -> BurgerIllustration(modifier = Modifier.fillMaxSize())
                        "READY" -> FriesIllustration(modifier = Modifier.fillMaxSize())
                        else -> ShakeIllustration(modifier = Modifier.fillMaxSize())
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Order Number: ${order.id}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = DarkCharcoal
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Location: ${order.locationName}",
                    fontSize = 12.sp,
                    color = DarkGray
                )

                if (order.status == "READY") {
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = { viewModel.collectOrder(order.id) },
                        colors = ButtonDefaults.buttonColors(containerColor = ShackGreen),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, DarkCharcoal, RoundedCornerShape(8.dp))
                    ) {
                        Text("COLLECT FOOD NOW", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Head to the pickup counter and show this receipt.", fontSize = 11.sp, color = DarkGray)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Thermal Receipt Style Design Block
        Text("DIGITAL RECEIPT", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, color = DarkGray)
        Spacer(modifier = Modifier.height(8.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, LightGray, RoundedCornerShape(0.dp)) // Thermal flat look
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    "SHAKE SHACK",
                    fontWeight = FontWeight.Black,
                    fontSize = 18.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    order.locationName.uppercase(),
                    fontSize = 11.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                    color = DarkGray
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text("----------------------------------------", color = LightGray, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())

                val sdf = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.UK)
                val formattedDate = sdf.format(Date(order.timestamp))

                ReceiptItemRow("Date", formattedDate)
                ReceiptItemRow("Order ID", order.id)
                ReceiptItemRow("Status", order.status)
                ReceiptItemRow("Pickup Time", order.readyTime)

                Text("----------------------------------------", color = LightGray, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(8.dp))

                // Breakdown items
                val itemsSummaryList = order.itemsSummaryJson.split(", ")
                itemsSummaryList.forEach { part ->
                    val qtyName = part.split("x ")
                    val qty = qtyName.getOrNull(0) ?: "1"
                    val name = qtyName.getOrNull(1) ?: "ShackBurger"
                    ReceiptItemRow("$qty x $name", "")
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text("----------------------------------------", color = LightGray, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())

                ReceiptItemRow("Subtotal", "£${String.format("%.2f", order.subtotal)}")
                ReceiptItemRow("VAT (20%)", "£${String.format("%.2f", order.tax)}")
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("TOTAL AMOUNT", fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                    Text("£${String.format("%.2f", order.total)}", fontWeight = FontWeight.Black, fontSize = 16.sp, color = ShackGreen)
                }

                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    "Thank you for ordering digital with Shack!",
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                    fontSize = 11.sp,
                    color = DarkGray
                )
            }
        }
    }
}

@Composable
fun ReceiptItemRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 12.sp, color = DarkCharcoal, fontWeight = FontWeight.SemiBold)
        Text(value, fontSize = 12.sp, color = DarkGray, fontWeight = FontWeight.Bold)
    }
}


// --- SCREEN: REWARDS ---

@Composable
fun RewardsScreen(viewModel: ShackViewModel) {
    val points by viewModel.userPoints.collectAsState()
    val rewardsList by viewModel.rewards.collectAsState()
    val msg by viewModel.rewardsMessage.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text("Shack Rewards", fontWeight = FontWeight.ExtraBold, fontSize = 22.sp, color = DarkCharcoal)
        Spacer(modifier = Modifier.height(16.dp))

        // Progress Bar to next reward (FREE SHAKE at 300 or FREE FRIES at 150)
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = DarkCharcoal),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("YOUR REWARDS LEVEL", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = ShackGreen)
                    Text("$points Points", fontWeight = FontWeight.Black, fontSize = 18.sp, color = Color.White)
                }
                Spacer(modifier = Modifier.height(12.dp))

                // Progress to 500 max (£5 Off)
                val target = 500
                val progress = (points.toFloat() / target.toFloat()).coerceIn(0f, 1f)

                LinearProgressIndicator(
                    progress = progress,
                    color = ShackGreen,
                    trackColor = LightGray,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                )

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "You are ${target - points} points away from the £5 OFF premium reward tier!",
                    fontSize = 11.sp,
                    color = Color.LightGray
                )
            }
        }

        if (msg != null) {
            Spacer(modifier = Modifier.height(12.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = ShackGreen),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    msg ?: "",
                    modifier = Modifier.padding(12.dp),
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    fontSize = 13.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text("AVAILABLE LOYALTY CLAIMS", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = DarkGray)
        Spacer(modifier = Modifier.height(12.dp))

        rewardsList.forEach { reward ->
            val canClaim = points >= reward.pointsCost
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, LightGray),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Left: Icon Badge
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .background(CreamSand, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Star, contentDescription = "Points Star", tint = ShackGreen)
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    // Center Details
                    Column(modifier = Modifier.weight(1f)) {
                        Text(reward.title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(reward.description, fontSize = 12.sp, color = DarkGray, lineHeight = 16.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("${reward.pointsCost} POINTS", color = ShackGreen, fontWeight = FontWeight.Black, fontSize = 12.sp)
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Right Claim action button
                    Button(
                        onClick = { viewModel.claimReward(reward) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (canClaim) ShackGreen else LightGray
                        ),
                        shape = RoundedCornerShape(8.dp),
                        enabled = canClaim
                    ) {
                        Text("REDEEM", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Editorial Promotions banner inside rewards
        Text("ACTIVE APP OFFERS", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = DarkGray)
        Spacer(modifier = Modifier.height(12.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = CreamSand),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().border(1.dp, LightGray, RoundedCornerShape(12.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Box(
                    modifier = Modifier
                        .background(DarkCharcoal, RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text("HOT OFFER", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text("Double Point Tuesdays!", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text("Order any limited-time Black Truffle Burger on Tuesdays and earn 2x loyalty score on your digital account.", fontSize = 12.sp, color = DarkGray)
            }
        }
    }
}


// --- SCREEN: ACCOUNT ---

@Composable
fun AccountScreen(viewModel: ShackViewModel) {
    var emailNotification by remember { mutableStateOf(true) }
    var allergenPreferenceMilk by remember { mutableStateOf(false) }
    var allergenPreferenceWheat by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text("Your Account", fontWeight = FontWeight.ExtraBold, fontSize = 22.sp, color = DarkCharcoal)
        Spacer(modifier = Modifier.height(20.dp))

        // Fake Profile details
        Card(
            colors = CardDefaults.cardColors(containerColor = CreamSand),
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .background(ShackGreen, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text("T", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 24.sp)
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text("Tom Ah", fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
                    Text("tom@ahyx.org", fontSize = 13.sp, color = DarkGray)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Shack Member since 2024", fontSize = 11.sp, color = ShackGreen, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text("DIETARY ALLERGEN FILTERS", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, color = DarkGray)
        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Filter Milk Products", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Checkbox(checked = allergenPreferenceMilk, onCheckedChange = { allergenPreferenceMilk = it })
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Filter Wheat Products", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Checkbox(checked = allergenPreferenceWheat, onCheckedChange = { allergenPreferenceWheat = it })
        }

        Spacer(modifier = Modifier.height(20.dp))
        Divider()
        Spacer(modifier = Modifier.height(20.dp))

        Text("COMMUNICATION PREFERENCES", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, color = DarkGray)
        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1.2f)) {
                Text("Email Newsletters", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("Receive exclusive limited-time menus, chef collaboration previews and birthday promotions.", fontSize = 11.sp, color = DarkGray)
            }
            Switch(
                checked = emailNotification,
                onCheckedChange = { emailNotification = it },
                colors = SwitchDefaults.colors(checkedThumbColor = ShackGreen)
            )
        }

        Spacer(modifier = Modifier.height(30.dp))

        Button(
            onClick = { /* Simulated logout */ },
            colors = ButtonDefaults.buttonColors(containerColor = TomatoRed),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("SIGN OUT", fontWeight = FontWeight.Bold, color = Color.White)
        }
    }
}
