package com.example.data.repository

import com.example.data.local.ShackDao
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class ShackRepository(private val shackDao: ShackDao) {

    val locations: Flow<List<ShackLocation>> = shackDao.getAllLocations()
    val menuItems: Flow<List<MenuItem>> = shackDao.getAllMenuItems()
    val cartItems: Flow<List<CartItem>> = shackDao.getCartItems()
    val orders: Flow<List<OrderEntity>> = shackDao.getAllOrders()
    val rewards: Flow<List<RewardEntity>> = shackDao.getAllRewards()
    val userPoints: Flow<UserPoints?> = shackDao.getUserPointsFlow()
    val promotions: Flow<List<PromotionEntity>> = shackDao.getAllPromotions()

    suspend fun getMenuItemById(id: String): MenuItem? = shackDao.getMenuItemById(id)
    suspend fun getLocationById(id: String): ShackLocation? = shackDao.getLocationById(id)

    suspend fun seedDatabaseIfEmpty() {
        // Checking if locations are already seeded
        val existingLocations = locations.first()
        if (existingLocations.isEmpty()) {
            // Seed locations
            shackDao.insertLocations(listOf(
                ShackLocation(
                    id = "london_leicester_square",
                    name = "London — Leicester Square",
                    city = "London",
                    country = "United Kingdom",
                    distance = 0.4,
                    isOpen = true,
                    openingHours = "11:00 AM - 11:00 PM",
                    pickupAvailable = true,
                    dineInAvailable = true,
                    estimatedPrepTime = 10,
                    latitude = 51.5113,
                    longitude = -0.1303,
                    currentQueue = "Lunch Peak"
                ),
                ShackLocation(
                    id = "london_brent_cross",
                    name = "London — Brent Cross",
                    city = "London",
                    country = "United Kingdom",
                    distance = 5.1,
                    isOpen = true,
                    openingHours = "11:30 AM - 10:00 PM",
                    pickupAvailable = true,
                    dineInAvailable = true,
                    estimatedPrepTime = 15,
                    latitude = 51.5761,
                    longitude = -0.2223,
                    currentQueue = "Moderate"
                ),
                ShackLocation(
                    id = "ny_madison_square",
                    name = "New York — Madison Square Park",
                    city = "New York",
                    country = "United States",
                    distance = 3450.0,
                    isOpen = true,
                    openingHours = "11:00 AM - 10:00 PM",
                    pickupAvailable = true,
                    dineInAvailable = true,
                    estimatedPrepTime = 12,
                    latitude = 40.7420,
                    longitude = -73.9880,
                    currentQueue = "High Demand"
                ),
                ShackLocation(
                    id = "ny_upper_west_side",
                    name = "New York — Upper West Side",
                    city = "New York",
                    country = "United States",
                    distance = 3452.2,
                    isOpen = true,
                    openingHours = "11:00 AM - 11:00 PM",
                    pickupAvailable = true,
                    dineInAvailable = true,
                    estimatedPrepTime = 10,
                    latitude = 40.7812,
                    longitude = -73.9798,
                    currentQueue = "Low Demand"
                ),
                ShackLocation(
                    id = "chicago_fulton_market",
                    name = "Chicago — Fulton Market",
                    city = "Chicago",
                    country = "United States",
                    distance = 3951.5,
                    isOpen = true,
                    openingHours = "11:00 AM - 10:00 PM",
                    pickupAvailable = true,
                    dineInAvailable = true,
                    estimatedPrepTime = 14,
                    latitude = 41.8868,
                    longitude = -87.6534,
                    currentQueue = "Moderate"
                ),
                ShackLocation(
                    id = "la_west_hollywood",
                    name = "Los Angeles — West Hollywood",
                    city = "Los Angeles",
                    country = "United States",
                    distance = 5431.0,
                    isOpen = false,
                    openingHours = "11:00 AM - Midnight",
                    pickupAvailable = false,
                    dineInAvailable = true,
                    estimatedPrepTime = 20,
                    latitude = 34.0900,
                    longitude = -118.3617,
                    currentQueue = "Low Demand"
                )
            ))

            // Seed Menu Items
            shackDao.insertMenuItems(listOf(
                MenuItem(
                    id = "shackburger",
                    name = "ShackBurger",
                    description = "Single or double cheeseburger topped with lettuce, tomato, and our signature ShackSauce on a toasted potato bun.",
                    category = "BURGERS",
                    basePrice = 7.95,
                    imageName = "shackburger",
                    calories = 540,
                    protein = "28g",
                    fat = "31g",
                    carbohydrates = "42g",
                    sodium = "1140mg",
                    allergens = "Milk, Wheat, Soy, Eggs",
                    isSeasonal = false,
                    isAppExclusive = false
                ),
                MenuItem(
                    id = "smokeshack",
                    name = "SmokeShack",
                    description = "Single or double cheeseburger topped with applewood smoked bacon, chopped cherry peppers, and ShackSauce.",
                    category = "BURGERS",
                    basePrice = 9.45,
                    imageName = "smokeshack",
                    calories = 620,
                    protein = "34g",
                    fat = "38g",
                    carbohydrates = "43g",
                    sodium = "1650mg",
                    allergens = "Milk, Wheat, Soy, Eggs",
                    isSeasonal = false,
                    isAppExclusive = false
                ),
                MenuItem(
                    id = "shroomburger",
                    name = "Shroom Burger",
                    description = "Crisp-fried portobello mushroom filled with melted muenster and cheddar cheeses, topped with lettuce, tomato, and ShackSauce.",
                    category = "BURGERS",
                    basePrice = 8.75,
                    imageName = "shroomburger",
                    calories = 550,
                    protein = "18g",
                    fat = "30g",
                    carbohydrates = "49g",
                    sodium = "950mg",
                    allergens = "Milk, Wheat, Soy, Eggs",
                    isSeasonal = false,
                    isAppExclusive = false
                ),
                MenuItem(
                    id = "chickenshack",
                    name = "Chicken Shack",
                    description = "Crispy chicken breast topped with shredded lettuce, pickles, and our signature herb mayo on a potato bun.",
                    category = "CHICKEN",
                    basePrice = 8.25,
                    imageName = "chickenshack",
                    calories = 590,
                    protein = "31g",
                    fat = "31g",
                    carbohydrates = "47g",
                    sodium = "1170mg",
                    allergens = "Milk, Wheat, Eggs",
                    isSeasonal = false,
                    isAppExclusive = false
                ),
                MenuItem(
                    id = "chickenbites",
                    name = "Chicken Bites",
                    description = "Crispy, whole-white-meat chicken bites cooked fresh to order. Served with your choice of honey mustard or BBQ sauce.",
                    category = "CHICKEN",
                    basePrice = 6.45,
                    imageName = "chickenbites",
                    calories = 300,
                    protein = "22g",
                    fat = "14g",
                    carbohydrates = "19g",
                    sodium = "710mg",
                    allergens = "Wheat, Eggs",
                    isSeasonal = false,
                    isAppExclusive = false
                ),
                MenuItem(
                    id = "flattopdog",
                    name = "Flat-Top Dog",
                    description = "All-natural Vienna Beef hot dog split down the middle and griddled crisp on our flat-top.",
                    category = "HOT DOGS",
                    basePrice = 4.95,
                    imageName = "flattopdog",
                    calories = 350,
                    protein = "14g",
                    fat = "21g",
                    carbohydrates = "27g",
                    sodium = "890mg",
                    allergens = "Wheat",
                    isSeasonal = false,
                    isAppExclusive = false
                ),
                MenuItem(
                    id = "crinklefries",
                    name = "Crinkle Cut Fries",
                    description = "Crispy, premium golden crinkle-cut potatoes salted perfectly. A classic Shack accompaniment.",
                    category = "FRIES",
                    basePrice = 3.25,
                    imageName = "crinklefries",
                    calories = 420,
                    protein = "5g",
                    fat = "19g",
                    carbohydrates = "56g",
                    sodium = "710mg",
                    allergens = "",
                    isSeasonal = false,
                    isAppExclusive = false
                ),
                MenuItem(
                    id = "cheesefries",
                    name = "Cheese Fries",
                    description = "Our classic crinkle-cut golden fries loaded with our special blend of warm cheddar and American cheese sauce.",
                    category = "FRIES",
                    basePrice = 4.25,
                    imageName = "cheesefries",
                    calories = 560,
                    protein = "8g",
                    fat = "31g",
                    carbohydrates = "61g",
                    sodium = "1150mg",
                    allergens = "Milk",
                    isSeasonal = false,
                    isAppExclusive = false
                ),
                MenuItem(
                    id = "vanillashake",
                    name = "Vanilla Shake",
                    description = "Our rich, hand-spun classic vanilla frozen custard shake. Thick, creamy and delicious.",
                    category = "SHAKES",
                    basePrice = 4.95,
                    imageName = "vanillashake",
                    calories = 680,
                    protein = "12g",
                    fat = "34g",
                    carbohydrates = "82g",
                    sodium = "380mg",
                    allergens = "Milk, Eggs",
                    isSeasonal = false,
                    isAppExclusive = false
                ),
                MenuItem(
                    id = "chocolateshake",
                    name = "Chocolate Shake",
                    description = "Our rich, hand-spun classic chocolate frozen custard shake. Satisfies any chocolate craving.",
                    category = "SHAKES",
                    basePrice = 4.95,
                    imageName = "chocolateshake",
                    calories = 720,
                    protein = "13g",
                    fat = "36g",
                    carbohydrates = "88g",
                    sodium = "390mg",
                    allergens = "Milk, Eggs",
                    isSeasonal = false,
                    isAppExclusive = false
                ),
                MenuItem(
                    id = "strawberryshake",
                    name = "Strawberry Shake",
                    description = "Premium strawberry purée blended with our vanilla custard. A fruity custard indulgence.",
                    category = "SHAKES",
                    basePrice = 4.95,
                    imageName = "strawberryshake",
                    calories = 710,
                    protein = "12g",
                    fat = "33g",
                    carbohydrates = "86g",
                    sodium = "380mg",
                    allergens = "Milk, Eggs",
                    isSeasonal = false,
                    isAppExclusive = false
                ),
                MenuItem(
                    id = "lemonade",
                    name = "Shack Lemonade",
                    description = "Freshly squeezed real lemons blended with real sugar and pure water. Refreshing and tart.",
                    category = "DRINKS",
                    basePrice = 2.95,
                    imageName = "lemonade",
                    calories = 160,
                    protein = "0g",
                    fat = "0g",
                    carbohydrates = "41g",
                    sodium = "15mg",
                    allergens = "",
                    isSeasonal = false,
                    isAppExclusive = false
                ),
                MenuItem(
                    id = "pumpkinshake",
                    name = "Autumn Pumpkin Shake",
                    description = "Limited-time spiced pumpkin custard blended with fall spices, topped with whipped cream and spiced crunch.",
                    category = "LIMITED TIME",
                    basePrice = 5.95,
                    imageName = "pumpkinshake",
                    calories = 780,
                    protein = "14g",
                    fat = "39g",
                    carbohydrates = "94g",
                    sodium = "410mg",
                    allergens = "Milk, Eggs, Wheat",
                    isSeasonal = true,
                    isAppExclusive = false
                ),
                MenuItem(
                    id = "truffleburger",
                    name = "Black Truffle Burger",
                    description = "Cheeseburger topped with black truffle sauce, melted Swiss cheese, and crispy shallots on our toasted potato bun.",
                    category = "LIMITED TIME",
                    basePrice = 9.95,
                    imageName = "truffleburger",
                    calories = 690,
                    protein = "36g",
                    fat = "43g",
                    carbohydrates = "45g",
                    sodium = "1480mg",
                    allergens = "Milk, Wheat, Soy, Eggs",
                    isSeasonal = true,
                    isAppExclusive = true
                )
            ))

            // Seed Rewards
            shackDao.insertRewards(listOf(
                RewardEntity(
                    id = "reward_free_fries",
                    title = "FREE CRINKLE FRIES",
                    pointsCost = 150,
                    isClaimed = false,
                    promoCode = "REWARDFRIES",
                    description = "Redeem 150 points for a free portion of our hot, crispy crinkle-cut fries."
                ),
                RewardEntity(
                    id = "reward_free_shake",
                    title = "FREE HAND-SPUN SHAKE",
                    pointsCost = 300,
                    isClaimed = false,
                    promoCode = "REWARDSHAKE",
                    description = "Redeem 300 points for any delicious, rich hand-spun classic custard shake."
                ),
                RewardEntity(
                    id = "reward_5_off",
                    title = "£5 OFF YOUR BILL",
                    pointsCost = 500,
                    isClaimed = false,
                    promoCode = "REWARD5OFF",
                    description = "Redeem 500 points to get £5.00 off your total digital order of £15.00 or more."
                )
            ))

            // Seed Promotions
            shackDao.insertPromotions(listOf(
                PromotionEntity(
                    id = "promo_free_fries",
                    title = "APP EXCLUSIVE: FREE FRIES",
                    description = "Get a free portion of Crinkle Cut Fries on orders over £15 using code APPFRIES.",
                    code = "APPFRIES",
                    bannerImageName = "promo_fries",
                    isAppExclusive = true,
                    discountPercent = 0.0 // Custom manual discount check in cart
                ),
                PromotionEntity(
                    id = "promo_autumn_shake",
                    title = "LIMITED TIME: 15% SHAKES",
                    description = "Enjoy 15% off any classic or seasonal shake with code AUTUMNSHAKE.",
                    code = "AUTUMNSHAKE",
                    bannerImageName = "promo_shakes",
                    isAppExclusive = false,
                    discountPercent = 15.0
                ),
                PromotionEntity(
                    id = "promo_birthday_gift",
                    title = "HAPPY BIRTHDAY FROM SHACK",
                    description = "Our present to you: 20% off your entire Shack order with code SHACKBDAY.",
                    code = "SHACKBDAY",
                    bannerImageName = "promo_birthday",
                    isAppExclusive = true,
                    discountPercent = 20.0
                )
            ))

            // Seed User Points (Start at 420 as requested for the demo! Progress 420/500)
            shackDao.insertUserPoints(UserPoints(id = 1, points = 420))
        }
    }

    // Methods to operate on items
    suspend fun insertCartItem(item: CartItem) = shackDao.insertCartItem(item)
    suspend fun updateCartItem(item: CartItem) = shackDao.updateCartItem(item)
    suspend fun deleteCartItem(item: CartItem) = shackDao.deleteCartItem(item)
    suspend fun clearCart() = shackDao.clearCart()

    suspend fun insertOrder(order: OrderEntity) = shackDao.insertOrder(order)
    suspend fun updateOrderStatus(id: String, status: String) = shackDao.updateOrderStatus(id, status)
    fun getOrderFlowById(id: String): Flow<OrderEntity?> = shackDao.getOrderFlowById(id)

    suspend fun updateReward(reward: RewardEntity) = shackDao.updateReward(reward)
    suspend fun updateUserPoints(points: Int) = shackDao.insertUserPoints(UserPoints(id = 1, points = points))
    suspend fun getUserPoints(): Int = shackDao.getUserPoints()?.points ?: 0

    suspend fun updatePromotion(promotion: PromotionEntity) = shackDao.updatePromotion(promotion)
}
