package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.repository.ShackRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

enum class ShackScreen {
    HOME, LOCATION_SELECTOR, MENU, ITEM_DETAIL, CART, CHECKOUT, ORDER_TRACKER, REWARDS, ACCOUNT
}

class ShackViewModel(private val repository: ShackRepository) : ViewModel() {

    // Seeding database
    init {
        viewModelScope.launch {
            repository.seedDatabaseIfEmpty()
            // Set initial location
            val locs = repository.locations.first()
            _selectedLocation.value = locs.find { it.id == "london_leicester_square" } ?: locs.firstOrNull()
        }
    }

    // Navigation Stack
    private val _navigationStack = MutableStateFlow<List<ShackScreen>>(listOf(ShackScreen.HOME))
    val currentScreen: StateFlow<ShackScreen> = _navigationStack
        .map { it.lastOrNull() ?: ShackScreen.HOME }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ShackScreen.HOME)

    fun navigateTo(screen: ShackScreen) {
        val current = _navigationStack.value.toMutableList()
        current.add(screen)
        _navigationStack.value = current
    }

    fun navigateBack() {
        val current = _navigationStack.value.toMutableList()
        if (current.size > 1) {
            current.removeAt(current.size - 1)
            _navigationStack.value = current
        }
    }

    fun clearToHome() {
        _navigationStack.value = listOf(ShackScreen.HOME)
    }

    // Selected Location
    private val _selectedLocation = MutableStateFlow<ShackLocation?>(null)
    val selectedLocation: StateFlow<ShackLocation?> = _selectedLocation.asStateFlow()

    fun selectLocation(location: ShackLocation) {
        _selectedLocation.value = location
        // Go back to previous screen or HOME
        navigateBack()
    }

    // Reactive Lists from DB
    val locations: StateFlow<List<ShackLocation>> = repository.locations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val menuItems: StateFlow<List<MenuItem>> = repository.menuItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val cartItems: StateFlow<List<CartItem>> = repository.cartItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val orders: StateFlow<List<OrderEntity>> = repository.orders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val rewards: StateFlow<List<RewardEntity>> = repository.rewards
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val promotions: StateFlow<List<PromotionEntity>> = repository.promotions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userPoints: StateFlow<Int> = repository.userPoints
        .map { it?.points ?: 420 }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 420)

    // Screen-specific: Item Detail State
    private val _selectedMenuItem = MutableStateFlow<MenuItem?>(null)
    val selectedMenuItem: StateFlow<MenuItem?> = _selectedMenuItem.asStateFlow()

    // Modifier States
    var selectedPattyCount = MutableStateFlow(1) // 1 or 2
    var selectedCheese = MutableStateFlow(true)
    var selectedToppings = MutableStateFlow(listOf("Lettuce", "Tomato", "ShackSauce")) // Customize toppings
    var quantitySelector = MutableStateFlow(1)

    fun selectMenuItem(item: MenuItem) {
        _selectedMenuItem.value = item
        // Reset modifiers based on category
        selectedPattyCount.value = 1
        selectedCheese.value = item.category == "BURGERS"
        selectedToppings.value = if (item.category == "BURGERS") {
            listOf("Lettuce", "Tomato", "ShackSauce")
        } else {
            emptyList()
        }
        quantitySelector.value = 1
        navigateTo(ShackScreen.ITEM_DETAIL)
    }

    // Computed dynamic item price
    val dynamicItemPrice: StateFlow<Double> = combine(
        _selectedMenuItem, selectedPattyCount, selectedCheese
    ) { item, pattyCount, cheese ->
        if (item == null) return@combine 0.0
        var price = item.basePrice
        if (pattyCount == 2) {
            price += 3.00 // Double adds £3.00
        }
        price
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    fun addToCart() {
        val item = _selectedMenuItem.value ?: return
        viewModelScope.launch {
            val toppings = selectedToppings.value.joinToString(", ")
            val singlePrice = dynamicItemPrice.value
            val total = singlePrice * quantitySelector.value

            val cartItem = CartItem(
                menuItemId = item.id,
                name = if (selectedPattyCount.value == 2) "Double ${item.name}" else item.name,
                basePrice = singlePrice,
                quantity = quantitySelector.value,
                selectedToppings = toppings,
                selectedPattyCount = selectedPattyCount.value,
                selectedCheese = selectedCheese.value,
                totalPrice = total
            )
            repository.insertCartItem(cartItem)
            navigateBack()
        }
    }

    fun deleteCartItem(item: CartItem) {
        viewModelScope.launch {
            repository.deleteCartItem(item)
        }
    }

    // Promo Code Application State
    private val _appliedPromoCode = MutableStateFlow<String?>(null)
    val appliedPromoCode: StateFlow<String?> = _appliedPromoCode.asStateFlow()

    private val _promoError = MutableStateFlow<String?>(null)
    val promoError: StateFlow<String?> = _promoError.asStateFlow()

    fun applyPromoCode(code: String) {
        val trimmed = code.trim().uppercase()
        viewModelScope.launch {
            val allPromos = repository.promotions.first()
            val allRewards = repository.rewards.first()

            val isValidPromo = allPromos.any { it.code.uppercase() == trimmed }
            val isValidRewardCode = allRewards.any { it.promoCode.uppercase() == trimmed }

            if (isValidPromo || isValidRewardCode) {
                _appliedPromoCode.value = trimmed
                _promoError.value = null
            } else {
                _promoError.value = "Invalid Promo or Reward Code"
            }
        }
    }

    fun removePromoCode() {
        _appliedPromoCode.value = null
        _promoError.value = null
    }

    // Checkout: Timing & Payment State
    var selectedPickupTime = MutableStateFlow("AS SOON AS POSSIBLE")
    var selectedPaymentMethod = MutableStateFlow("Google Pay")

    // Reactive Total Calculations
    val cartTotals: StateFlow<CartTotals> = combine(
        cartItems, _appliedPromoCode
    ) { items, promo ->
        val subtotal = items.sumOf { it.totalPrice }
        var discount = 0.0
        var promoAppliedText = ""

        if (promo != null) {
            when (promo) {
                "APPFRIES" -> {
                    // Free Crinkle Cut Fries if in cart and subtotal >= 15
                    val hasFries = items.any { it.menuItemId == "crinklefries" || it.menuItemId == "cheesefries" }
                    if (hasFries && subtotal >= 15.0) {
                        val friesItem = items.find { it.menuItemId == "crinklefries" }
                            ?: items.find { it.menuItemId == "cheesefries" }
                        discount = friesItem?.basePrice ?: 3.25
                        promoAppliedText = "Free Fries Promo applied (-£${String.format("%.2f", discount)})"
                    } else if (!hasFries) {
                        _promoError.value = "Add Crinkle Cut Fries to your order first"
                    } else {
                        _promoError.value = "Subtotal must be at least £15.00"
                    }
                }
                "AUTUMNSHAKE" -> {
                    // 15% off shakes
                    val shakeItemsTotal = items.filter { it.menuItemId.contains("shake") }.sumOf { it.totalPrice }
                    if (shakeItemsTotal > 0) {
                        discount = shakeItemsTotal * 0.15
                        promoAppliedText = "15% Shake discount applied (-£${String.format("%.2f", discount)})"
                    } else {
                        _promoError.value = "Add a shake to apply this discount"
                    }
                }
                "SHACKBDAY" -> {
                    // 20% off entire bill
                    discount = subtotal * 0.20
                    promoAppliedText = "Birthday 20% discount applied (-£${String.format("%.2f", discount)})"
                }
                "REWARDFRIES" -> {
                    // Free fries reward
                    val friesItem = items.find { it.menuItemId == "crinklefries" || it.menuItemId == "cheesefries" }
                    if (friesItem != null) {
                        discount = friesItem.basePrice
                        promoAppliedText = "Free Fries Reward applied (-£${String.format("%.2f", discount)})"
                    } else {
                        _promoError.value = "Add Fries to apply Free Fries Reward"
                    }
                }
                "REWARDSHAKE" -> {
                    // Free shake reward
                    val shakeItem = items.find { it.menuItemId.contains("shake") }
                    if (shakeItem != null) {
                        discount = shakeItem.basePrice
                        promoAppliedText = "Free Shake Reward applied (-£${String.format("%.2f", discount)})"
                    } else {
                        _promoError.value = "Add a Shake to apply Free Shake Reward"
                    }
                }
                "REWARD5OFF" -> {
                    // £5 off order if subtotal >= 15
                    if (subtotal >= 15.0) {
                        discount = 5.00
                        promoAppliedText = "£5 Off Reward applied (-£5.00)"
                    } else {
                        _promoError.value = "Subtotal must be at least £15.00"
                    }
                }
            }
        }

        val netSubtotal = (subtotal - discount).coerceAtLeast(0.0)
        val tax = netSubtotal * 0.20 // 20% VAT in UK
        val total = netSubtotal + tax

        CartTotals(subtotal, discount, tax, total, promoAppliedText)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), CartTotals())

    // Active tracking order ID
    private val _activeOrderId = MutableStateFlow<String?>(null)
    val activeOrderId: StateFlow<String?> = _activeOrderId.asStateFlow()

    val activeOrder: StateFlow<OrderEntity?> = _activeOrderId
        .flatMapLatest { id ->
            if (id == null) flowOf(null) else repository.getOrderFlowById(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    fun placeOrder() {
        val currentLoc = _selectedLocation.value ?: return
        val currentCart = cartItems.value
        if (currentCart.isEmpty()) return

        val totals = cartTotals.value
        val orderId = "SHAKE-${(1000..9999).random()}"

        val summary = currentCart.joinToString(", ") { "${it.quantity}x ${it.name}" }

        val order = OrderEntity(
            id = orderId,
            locationId = currentLoc.id,
            locationName = currentLoc.name,
            status = "ORDER_CREATED",
            subtotal = totals.subtotal,
            tax = totals.tax,
            total = totals.total,
            timestamp = System.currentTimeMillis(),
            readyTime = selectedPickupTime.value,
            itemsSummaryJson = summary
        )

        viewModelScope.launch {
            repository.insertOrder(order)
            repository.clearCart()
            _activeOrderId.value = orderId

            // Add points based on spent (10 pts per pound)
            val currentPoints = repository.getUserPoints()
            val earned = (totals.total * 10).toInt()
            repository.updateUserPoints(currentPoints + earned)

            // Remove applied promo code
            _appliedPromoCode.value = null

            // Navigate to tracking
            navigateTo(ShackScreen.ORDER_TRACKER)

            // Start Order Simulator
            simulateOrderTransitions(orderId)
        }
    }

    private fun simulateOrderTransitions(id: String) {
        viewModelScope.launch {
            delay(2000)
            repository.updateOrderStatus(id, "PAYMENT_AUTHORISED")
            delay(2500)
            repository.updateOrderStatus(id, "ORDER_ACCEPTED")
            delay(3000)
            repository.updateOrderStatus(id, "PREPARING") // Cooking
            delay(4000)
            repository.updateOrderStatus(id, "READY") // Ready for pickup
        }
    }

    fun collectOrder(id: String) {
        viewModelScope.launch {
            repository.updateOrderStatus(id, "COMPLETED")
        }
    }

    fun repeatOrder(pastOrder: OrderEntity) {
        // Find items from summary and populate cart
        viewModelScope.launch {
            repository.clearCart()
            // Simulating parsing summary (e.g. "1x ShackBurger, 1x Crinkle Cut Fries")
            val parts = pastOrder.itemsSummaryJson.split(", ")
            for (part in parts) {
                val qtyName = part.split("x ")
                val qty = qtyName.getOrNull(0)?.toIntOrNull() ?: 1
                val name = qtyName.getOrNull(1) ?: "ShackBurger"

                // Match menu item
                val menuList = repository.menuItems.first()
                val menuItem = menuList.find { name.contains(it.name, ignoreCase = true) } ?: menuList.first()

                val price = menuItem.basePrice
                repository.insertCartItem(CartItem(
                    menuItemId = menuItem.id,
                    name = name,
                    basePrice = price,
                    quantity = qty,
                    selectedToppings = "Lettuce, Tomato, ShackSauce",
                    selectedPattyCount = if (name.contains("Double", ignoreCase = true)) 2 else 1,
                    selectedCheese = true,
                    totalPrice = price * qty
                ))
            }
            // Navigate to Cart
            navigateTo(ShackScreen.CART)
        }
    }

    // Loyalty Redemption Mechanics
    private val _rewardsMessage = MutableStateFlow<String?>(null)
    val rewardsMessage: StateFlow<String?> = _rewardsMessage.asStateFlow()

    fun claimReward(reward: RewardEntity) {
        viewModelScope.launch {
            val points = repository.getUserPoints()
            if (points >= reward.pointsCost) {
                // Deduct points
                repository.updateUserPoints(points - reward.pointsCost)
                // Mark reward as claimed
                repository.updateReward(reward.copy(isClaimed = true))
                // Apply promo code automatically
                _appliedPromoCode.value = reward.promoCode
                _rewardsMessage.value = "Success! ${reward.title} unlocked. Code ${reward.promoCode} applied to your checkout!"
            } else {
                _rewardsMessage.value = "Need more points! You have $points / ${reward.pointsCost} points."
            }
            delay(4000)
            _rewardsMessage.value = null
        }
    }
}

data class CartTotals(
    val subtotal: Double = 0.0,
    val discount: Double = 0.0,
    val tax: Double = 0.0,
    val total: Double = 0.0,
    val promoAppliedText: String = ""
)
