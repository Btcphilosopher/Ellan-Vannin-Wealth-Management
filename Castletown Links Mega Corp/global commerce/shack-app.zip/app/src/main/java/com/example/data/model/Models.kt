package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "locations")
data class ShackLocation(
    @PrimaryKey val id: String,
    val name: String,
    val city: String,
    val country: String,
    val distance: Double,
    val isOpen: Boolean,
    val openingHours: String,
    val pickupAvailable: Boolean,
    val dineInAvailable: Boolean,
    val estimatedPrepTime: Int, // in minutes
    val latitude: Double,
    val longitude: Double,
    val currentQueue: String // e.g. "Low Demand", "Moderate", "Lunch Peak"
)

@Entity(tableName = "menu_items")
data class MenuItem(
    @PrimaryKey val id: String,
    val name: String,
    val description: String,
    val category: String, // BURGERS, CHICKEN, HOT DOGS, FRIES, SHAKES, etc.
    val basePrice: Double,
    val imageName: String,
    val calories: Int,
    val protein: String,
    val fat: String,
    val carbohydrates: String,
    val sodium: String,
    val allergens: String, // comma-separated, e.g., "Milk, Wheat, Soy"
    val isSeasonal: Boolean,
    val isAppExclusive: Boolean
)

@Entity(tableName = "cart_items")
data class CartItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val menuItemId: String,
    val name: String,
    val basePrice: Double,
    val quantity: Int,
    val selectedToppings: String, // comma-separated
    val selectedPattyCount: Int, // 1 for Single, 2 for Double
    val selectedCheese: Boolean,
    val totalPrice: Double
)

@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey val id: String, // e.g. "SHAKE-1048"
    val locationId: String,
    val locationName: String,
    val status: String, // ORDER_CREATED -> PAYMENT_PENDING -> ... -> READY -> COLLECTED
    val subtotal: Double,
    val tax: Double,
    val total: Double,
    val timestamp: Long,
    val readyTime: String,
    val itemsSummaryJson: String, // comma-separated or JSON list of item names and quantities
    val isSimulated: Boolean = true
)

@Entity(tableName = "rewards")
data class RewardEntity(
    @PrimaryKey val id: String,
    val title: String,
    val pointsCost: Int,
    val isClaimed: Boolean,
    val promoCode: String,
    val description: String
)

@Entity(tableName = "user_points")
data class UserPoints(
    @PrimaryKey val id: Int = 1, // Single-row singleton
    val points: Int
)

@Entity(tableName = "promotions")
data class PromotionEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val code: String,
    val bannerImageName: String,
    val isAppExclusive: Boolean,
    val discountPercent: Double,
    val isRedeemed: Boolean = false
)
