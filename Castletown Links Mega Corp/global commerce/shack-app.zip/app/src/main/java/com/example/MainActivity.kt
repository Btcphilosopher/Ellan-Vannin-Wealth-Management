package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModelProvider
import com.example.data.model.OrderEntity
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import com.example.data.local.ShackDatabase
import com.example.data.repository.ShackRepository
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.ShackGreen
import com.example.ui.theme.CreamSand
import com.example.ui.theme.DarkCharcoal
import com.example.ui.viewmodel.ShackScreen
import com.example.ui.viewmodel.ShackViewModel
import com.example.ui.viewmodel.ShackViewModelFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Core dependency creation
        val database = ShackDatabase.getDatabase(applicationContext)
        val repository = ShackRepository(database.shackDao())
        val factory = ShackViewModelFactory(repository)
        val viewModel = ViewModelProvider(this, factory)[ShackViewModel::class.java]

        setContent {
            MyApplicationTheme {
                MainContent(viewModel)
            }
        }
    }
}

@Composable
fun MainContent(viewModel: ShackViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val cartItems by viewModel.cartItems.collectAsState()
    val activeOrder by viewModel.activeOrder.collectAsState()

    // Determine if we should show bottom navigation
    // Typically hide bottom bars on transaction-focused secondary sheets
    val showBottomBar = currentScreen in listOf(
        ShackScreen.HOME,
        ShackScreen.MENU,
        ShackScreen.ORDER_TRACKER,
        ShackScreen.REWARDS,
        ShackScreen.ACCOUNT
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            if (showBottomBar) {
                Column {
                    // Floating Context Alert Bars (Cart or Live Tracker)
                    // Prominently shown above Bottom Nav if user is browsing other screens
                    if (cartItems.isNotEmpty() && currentScreen != ShackScreen.CART) {
                        val cartCount = cartItems.sumOf { it.quantity }
                        val cartTotal = cartItems.sumOf { it.totalPrice }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(ShackGreen)
                                .clickable { viewModel.navigateTo(ShackScreen.CART) }
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.ShoppingCart, contentDescription = "Cart", tint = Color.White)
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = "VIEW CART ($cartCount items)",
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White,
                                    fontSize = 14.sp
                                )
                            }
                            Text(
                                text = "£${String.format("%.2f", cartTotal)} >",
                                fontWeight = FontWeight.Black,
                                color = Color.White,
                                fontSize = 14.sp
                            )
                        }
                    } else if (activeOrder != null && activeOrder?.status != "COMPLETED" && currentScreen != ShackScreen.ORDER_TRACKER) {
                        val oId = activeOrder?.id ?: ""
                        val oStatus = activeOrder?.status ?: ""
                        val statusText = when (oStatus) {
                            "PREPARING" -> "Cooking your food..."
                            "READY" -> "Ready for pickup!"
                            else -> "Preparing order..."
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(DarkCharcoal)
                                .clickable { viewModel.navigateTo(ShackScreen.ORDER_TRACKER) }
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Schedule, contentDescription = "Order Clock", tint = ShackGreen)
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = "ACTIVE ORDER: $oId",
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontSize = 13.sp
                                )
                            }
                            Text(
                                text = "$statusText >",
                                fontWeight = FontWeight.Bold,
                                color = ShackGreen,
                                fontSize = 13.sp
                            )
                        }
                    }

                    // Standard Material 3 NavigationBar
                    NavigationBar(
                        containerColor = CreamSand,
                        tonalElevation = 8.dp,
                        modifier = Modifier
                    ) {
                        NavigationBarItemHelper(
                            selected = currentScreen == ShackScreen.HOME,
                            onClick = { viewModel.clearToHome() },
                            icon = Icons.Default.Home,
                            label = "HOME",
                            testTag = "nav_home"
                        )
                        NavigationBarItemHelper(
                            selected = currentScreen == ShackScreen.MENU,
                            onClick = { viewModel.navigateTo(ShackScreen.MENU) },
                            icon = Icons.Default.Fastfood,
                            label = "ORDER",
                            testTag = "nav_order"
                        )
                        NavigationBarItemHelper(
                            selected = currentScreen == ShackScreen.ORDER_TRACKER,
                            onClick = { viewModel.navigateTo(ShackScreen.ORDER_TRACKER) },
                            icon = Icons.Default.ReceiptLong,
                            label = "ORDERS",
                            testTag = "nav_orders"
                        )
                        NavigationBarItemHelper(
                            selected = currentScreen == ShackScreen.REWARDS,
                            onClick = { viewModel.navigateTo(ShackScreen.REWARDS) },
                            icon = Icons.Default.MilitaryTech,
                            label = "REWARDS",
                            testTag = "nav_rewards"
                        )
                        NavigationBarItemHelper(
                            selected = currentScreen == ShackScreen.ACCOUNT,
                            onClick = { viewModel.navigateTo(ShackScreen.ACCOUNT) },
                            icon = Icons.Default.Person,
                            label = "ACCOUNT",
                            testTag = "nav_account"
                        )
                    }
                }
            }
        }
    ) { paddingValues ->
        // Handle full-bleed system bar overlap correctly using safe padding
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .safeDrawingPadding()
        ) {
            when (currentScreen) {
                ShackScreen.HOME -> HomeScreen(viewModel)
                ShackScreen.LOCATION_SELECTOR -> LocationSelectorScreen(viewModel)
                ShackScreen.MENU -> MenuScreen(viewModel)
                ShackScreen.ITEM_DETAIL -> ItemDetailScreen(viewModel)
                ShackScreen.CART -> CartScreen(viewModel)
                ShackScreen.CHECKOUT -> CheckoutScreen(viewModel)
                ShackScreen.ORDER_TRACKER -> {
                    // Check if there are past orders but no active order, show a list of past orders with "Order Again" button
                    val allOrders by viewModel.orders.collectAsState()
                    if (activeOrder == null) {
                        PastOrdersList(viewModel, allOrders)
                    } else {
                        OrderTrackerScreen(viewModel)
                    }
                }
                ShackScreen.REWARDS -> RewardsScreen(viewModel)
                ShackScreen.ACCOUNT -> AccountScreen(viewModel)
            }
        }
    }
}

@Composable
fun RowScope.NavigationBarItemHelper(
    selected: Boolean,
    onClick: () -> Unit,
    icon: ImageVector,
    label: String,
    testTag: String
) {
    NavigationBarItem(
        selected = selected,
        onClick = onClick,
        icon = { Icon(icon, contentDescription = label) },
        label = { Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold) },
        colors = NavigationBarItemDefaults.colors(
            selectedIconColor = ShackGreen,
            selectedTextColor = ShackGreen,
            unselectedIconColor = Color.DarkGray,
            unselectedTextColor = Color.DarkGray,
            indicatorColor = Color.Transparent
        ),
        modifier = Modifier.testTag(testTag)
    )
}

@Composable
fun PastOrdersList(viewModel: ShackViewModel, orders: List<OrderEntity>) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Text("Your Order History", fontWeight = FontWeight.ExtraBold, fontSize = 22.sp, color = DarkCharcoal)
        Spacer(modifier = Modifier.height(16.dp))

        if (orders.isEmpty()) {
            Box(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.ReceiptLong, contentDescription = "No receipts", tint = Color.LightGray, modifier = Modifier.size(64.dp))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("No past orders yet", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Orders you place will appear here.", color = Color.Gray, fontSize = 13.sp)
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.weight(1f).fillMaxWidth()
            ) {
                items(orders) { order ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, Color.LightGray, RoundedCornerShape(12.dp))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(order.id, fontWeight = FontWeight.Black, fontSize = 16.sp, color = DarkCharcoal)
                                Text("£${String.format("%.2f", order.total)}", fontWeight = FontWeight.Black, fontSize = 16.sp, color = ShackGreen)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(order.locationName, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.DarkGray)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(order.itemsSummaryJson, fontSize = 12.sp, color = Color.Gray)
                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Completed",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = ShackGreen
                                )

                                Button(
                                    onClick = { viewModel.repeatOrder(order) },
                                    colors = ButtonDefaults.buttonColors(containerColor = CreamSand),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.border(1.dp, DarkCharcoal, RoundedCornerShape(6.dp))
                                ) {
                                    Text("ORDER AGAIN", color = DarkCharcoal, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
