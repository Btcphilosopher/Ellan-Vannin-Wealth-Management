package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ShackGreen = Color(0xFF549C30)      // Premium vibrant brand green
val DarkCharcoal = Color(0xFF1C1C1E)    // High contrast black/charcoal
val OffWhite = Color(0xFFFAF9F6)        // Clean, organic off-white
val CreamSand = Color(0xFFF5F2EB)       // Tactile paper texture background
val TomatoRed = Color(0xFFD32F2F)       // Tomato red accents
val MustardYellow = Color(0xFFFFB300)   // Mustard accent
val LightGray = Color(0xFFE5E5EA)
val DarkGray = Color(0xFF636366)
val White = Color(0xFFFFFFFF)
