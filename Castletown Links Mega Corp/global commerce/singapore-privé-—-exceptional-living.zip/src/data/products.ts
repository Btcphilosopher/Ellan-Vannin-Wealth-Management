import { Product } from '../types';

export const PRODUCTS_DATA: Product[] = [
  // ----------------------------------------------------
  // WATCHES (12 items)
  // ----------------------------------------------------
  {
    id: 'w-01',
    slug: 'rolex-submariner-date-126618lb',
    brand: 'Rolex',
    brandSlug: 'rolex',
    name: 'Submariner Date 18k Yellow Gold',
    subtitle: 'Royal Blue Dial & Ceramic Bezel',
    category: 'watches',
    subcategory: 'Sporting Complications',
    priceSGD: 54800,
    images: [
      'https://images.unsplash.com/photo-1547996160-01ff2474867f?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1523275335684-37898b6baf30?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'The archetype of the diver’s watch. Crafted in solid 18k yellow gold with an iconic royal blue dial and Cerachrom bezel insert. Waterproof to 300 metres.',
    story: 'Preserved under Singapore climate-controlled private vaults. Delivered with original green leather presentation box and international 5-year guarantee card.',
    specifications: {
      'Model Reference': '126618LB',
      'Case Diameter': '41 mm',
      'Material': '18k Yellow Gold',
      'Bezel': 'Unidirectional rotatable 60-minute graduated Cerachrom bezel',
      'Movement': 'Calibre 3235, Manufacture Rolex',
      'Power Reserve': 'Approximately 70 hours',
      'Water Resistance': '300 metres / 1,000 feet'
    },
    provenance: {
      origin: 'Geneva, Switzerland',
      year: '2025',
      certificate: 'Rolex Superlative Chronometer Certification & COSC',
      authenticityGuarantee: 'Verified by Singapore Privé Horology Vault'
    },
    availability: 'available',
    featuredInSingaporeEdit: true,
    tags: ['Rolex', 'Yellow Gold', 'Submariner', 'Diver'],
    isDemonstrationData: true
  },
  {
    id: 'w-02',
    slug: 'patek-philippe-nautilus-5711-1r',
    brand: 'Patek Philippe',
    brandSlug: 'patek-philippe',
    name: 'Nautilus Rose Gold 5711/1R',
    subtitle: 'Brown Gradated Dial with Gold Applied Hour Markers',
    category: 'watches',
    subcategory: 'Haute Horlogerie',
    priceSGD: 188000,
    images: [
      'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1509042239860-f550ce710b93?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'The pinnacle of sport-chic horlogerie. Designed by Gérald Genta, executing a porthole-inspired 18k rose gold case with satinated hand finishing.',
    specifications: {
      'Model Reference': '5711/1R-001',
      'Case Dimensions': '40 mm x 8.3 mm',
      'Material': '18k Rose Gold',
      'Movement': 'Self-winding Calibre 26-330 S C',
      'Hallmark': 'Patek Philippe Seal',
      'Water Resistance': '120 metres'
    },
    provenance: {
      origin: 'Plan-les-Ouates, Geneva',
      year: '2024',
      certificate: 'Extract from Patek Philippe Archives & Original Certificate of Origin',
      authenticityGuarantee: 'Guaranteed Authentic'
    },
    availability: 'limited',
    limitedEditionNumber: 'Vault Piece No. 04/12',
    featuredInSingaporeEdit: true,
    tags: ['Patek Philippe', 'Nautilus', 'Rose Gold'],
    isDemonstrationData: true
  },
  {
    id: 'w-03',
    slug: 'audemars-piguet-royal-oak-double-balance-skeleton',
    brand: 'Audemars Piguet',
    brandSlug: 'audemars-piguet',
    name: 'Royal Oak Double Balance Wheel Openworked',
    subtitle: 'Frosted White Gold 41mm',
    category: 'watches',
    subcategory: 'Complications',
    priceSGD: 245000,
    images: [
      'https://images.unsplash.com/photo-1523275335684-37898b6baf30?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1547996160-01ff2474867f?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'Patented double balance wheel geometry visible through openworked architecture. Hand-hammered Frosted 18k White Gold case crafted in Le Brassus.',
    specifications: {
      'Model Reference': '15407ST.OO.1220ST.01',
      'Case Diameter': '41 mm',
      'Material': '18k Frosted White Gold',
      'Movement': 'Self-winding Calibre 3132',
      'Dial': 'Openworked slate grey dial, luminescent white gold hands'
    },
    provenance: {
      origin: 'Le Brassus, Switzerland',
      year: '2025',
      certificate: 'Audemars Piguet International Warranty Book',
      authenticityGuarantee: 'Verified by Singapore Privé Horology Vault'
    },
    availability: 'limited',
    featuredInSingaporeEdit: true,
    tags: ['Audemars Piguet', 'Royal Oak', 'Openworked'],
    isDemonstrationData: true
  },
  {
    id: 'w-04',
    slug: 'vacheron-constantin-overseas-tourbillon-pink-gold',
    brand: 'Vacheron Constantin',
    brandSlug: 'vacheron-constantin',
    name: 'Overseas Tourbillon Ultra-Thin',
    subtitle: '18k 5N Pink Gold with Blue Lacquered Dial',
    category: 'watches',
    subcategory: 'Tourbillon',
    priceSGD: 218000,
    images: [
      'https://images.unsplash.com/photo-1509042239860-f550ce710b93?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'Ultra-thin automatic movement equipped with a peripheral rotor and Malta-Cross tourbillon cage. Includes 3 interchangeable straps.',
    specifications: {
      'Model Reference': '6000V/110R-B733',
      'Thickness': '10.39 mm',
      'Movement': 'Calibre 2160 Ultra-Thin Tourbillon',
      'Certification': 'Hallmark of Geneva (Poinçon de Genève)',
      'Power Reserve': '80 hours'
    },
    provenance: {
      origin: 'Geneva, Switzerland',
      year: '2025',
      certificate: 'Geneva Seal Certificate',
      authenticityGuarantee: 'Vault Sealed'
    },
    availability: 'available',
    featuredInSingaporeEdit: false,
    tags: ['Vacheron Constantin', 'Tourbillon', 'Overseas'],
    isDemonstrationData: true
  },
  {
    id: 'w-05',
    slug: 'richard-mille-rm-67-02-singapore-edition',
    brand: 'Richard Mille',
    brandSlug: 'audemars-piguet',
    name: 'RM 67-02 Automatic Extra Flat',
    subtitle: 'Carbon TPT & Quartz TPT Ultra-Light Edition',
    category: 'watches',
    subcategory: 'High Performance',
    priceSGD: 480000,
    images: [
      'https://images.unsplash.com/photo-1523275335684-37898b6baf30?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1547996160-01ff2474867f?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'Weighing only 32 grams including strap, designed for athletic endurance. Crafted in Carbon TPT and Red Quartz TPT with titanium baseplate.',
    specifications: {
      'Weight': '32 grams total',
      'Movement': 'Calibre CRMA7 Extra-Flat',
      'Baseplate': 'Grade 5 Titanium with DLC treatment',
      'Strap': 'Seamless comfort elastic wristband'
    },
    provenance: {
      origin: 'Les Breuleux, Switzerland',
      year: '2024',
      certificate: 'Richard Mille NFC Authenticity Certificate',
      authenticityGuarantee: 'Singapore Privé Direct Concierge Provenance'
    },
    availability: 'limited',
    limitedEditionNumber: 'Private Collection 02/05',
    featuredInSingaporeEdit: true,
    tags: ['Richard Mille', 'Carbon TPT', 'Ultra Light'],
    isDemonstrationData: true
  },
  {
    id: 'w-06',
    slug: 'f-p-journe-chronometre-bleu',
    brand: 'F.P. Journe',
    brandSlug: 'patek-philippe',
    name: 'Chronomètre Bleu Tantalum Case',
    subtitle: 'Solid Rose Gold Movement & Chrome Blue Dial',
    category: 'watches',
    subcategory: 'Independent Watchmaking',
    priceSGD: 135000,
    images: [
      'https://images.unsplash.com/photo-1509042239860-f550ce710b93?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'Housed in a dense 39mm dark grey Tantalum case with a brilliant mirror-finished metallic blue dial and hand-finished 18k rose gold movement.',
    specifications: {
      'Case Material': 'Tantalum (Rare refractory metal)',
      'Movement': 'Manual wind Calibre 1304 in 18k solid rose gold',
      'Dial': 'Chrome Blue with cream Arabic numerals',
      'Diameter': '39 mm'
    },
    provenance: {
      origin: 'Geneva, Switzerland',
      year: '2023',
      certificate: 'F.P. Journe Official Certificate of Origin',
      authenticityGuarantee: 'Vault Inspected'
    },
    availability: 'sold-out',
    tags: ['FP Journe', 'Independent', 'Tantalum'],
    isDemonstrationData: true
  },
  {
    id: 'w-07',
    slug: 'lange-sohne-lange-1-time-zone-honeygold',
    brand: 'A. Lange & Söhne',
    brandSlug: 'vacheron-constantin',
    name: 'Lange 1 Time Zone Honeygold',
    subtitle: '750 Honey Gold Case with Silver Dial',
    category: 'watches',
    subcategory: 'World Time',
    priceSGD: 98000,
    images: [
      'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'Glashütte precision engineering featuring Lange’s proprietary Honeygold alloy, outsize date display, and ring-shaped day/night indication.',
    specifications: {
      'Case Material': 'Proprietary 18k Honeygold',
      'Movement': 'Hand-wound Calibre L141.1 with twin mainspring barrels',
      'Complications': 'Dual time zone, outsize date, power reserve',
      'Diameter': '41.9 mm'
    },
    provenance: {
      origin: 'Glashütte, Saxony, Germany',
      year: '2025',
      certificate: 'Lange & Söhne Guarantee Certificate',
      authenticityGuarantee: 'Verified'
    },
    availability: 'available',
    tags: ['Lange Sohne', 'Honeygold', 'Lange 1'],
    isDemonstrationData: true
  },
  {
    id: 'w-08',
    slug: 'cartier-tank-louis-skeleton-sapphire',
    brand: 'Cartier',
    brandSlug: 'cartier',
    name: 'Tank Louis Cartier Skeleton Sapphire',
    subtitle: '950 Platinum Case with Roman Numerals Movement',
    category: 'watches',
    subcategory: 'Haute Horlogerie',
    priceSGD: 78500,
    images: [
      'https://images.unsplash.com/photo-1547996160-01ff2474867f?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'The iconic Tank geometry rendered in 950 Platinum. Structural movement bridges form the Roman numeral hour markers.',
    specifications: {
      'Case': '950 Platinum with faceted sapphire crown',
      'Movement': 'Manual-winding Calibre 9622 MC',
      'Strap': 'Bespoke navy alligator leather with platinum ardillon buckle'
    },
    provenance: {
      origin: 'Paris / La Chaux-de-Fonds',
      year: '2024',
      certificate: 'Cartier Certificate of Authenticity',
      authenticityGuarantee: 'Full Service Provenance'
    },
    availability: 'available',
    tags: ['Cartier', 'Tank', 'Platinum'],
    isDemonstrationData: true
  },
  {
    id: 'w-09',
    slug: 'jaeger-lecoultre-reverso-tribute-chronograph',
    brand: 'Jaeger-LeCoultre',
    brandSlug: 'vacheron-constantin',
    name: 'Reverso Tribute Chronograph',
    subtitle: '18k Pink Gold Swivelling Case',
    category: 'watches',
    subcategory: 'Reversible Complications',
    priceSGD: 62000,
    images: [
      'https://images.unsplash.com/photo-1523275335684-37898b6baf30?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'Dual-faced reversible art deco case revealing a sunray blue dial on front and a fully openworked chronograph mechanism on the reverse side.',
    specifications: {
      'Movement': 'Calibre 860 Manual Wind',
      'Power Reserve': '52 hours',
      'Straps': 'Casa Fagliano canvas-and-leather straps included'
    },
    provenance: {
      origin: 'Le Sentier, Vallée de Joux, Switzerland',
      year: '2025',
      certificate: '1000 Hours Control Certification',
      authenticityGuarantee: 'Vault Sealed'
    },
    availability: 'available',
    tags: ['JLC', 'Reverso', 'Chronograph'],
    isDemonstrationData: true
  },
  {
    id: 'w-10',
    slug: 'omega-speedmaster-calibre-321-canopus-gold',
    brand: 'Omega',
    brandSlug: 'rolex',
    name: 'Speedmaster Calibre 321 Canopus Gold',
    subtitle: 'Deep Onyx Dial with Vintage Seahorse Engraving',
    category: 'watches',
    subcategory: 'Heritage Chronographs',
    priceSGD: 118000,
    images: [
      'https://images.unsplash.com/photo-1509042239860-f550ce710b93?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'Crafted in 18k Canopus Gold, Omega’s exclusive white gold alloy. Powered by the legendary rebuilt Calibre 321 column-wheel movement.',
    specifications: {
      'Case Material': '18k Canopus Gold',
      'Movement': 'Calibre 321 Manual Wind',
      'Dial': 'Step dial in natural black Onyx stone'
    },
    provenance: {
      origin: 'Bienne, Switzerland',
      year: '2025',
      certificate: 'Master Chronometer METAS Card',
      authenticityGuarantee: 'Verified'
    },
    availability: 'available',
    tags: ['Omega', 'Speedmaster', 'Canopus Gold'],
    isDemonstrationData: true
  },
  {
    id: 'w-11',
    slug: 'mb-and-f-legacy-machine-perpetual-evo',
    brand: 'MB&F',
    brandSlug: 'audemars-piguet',
    name: 'Legacy Machine Perpetual EVO Zirconium',
    subtitle: 'Suspended Balance Wheel & FlexRing Shock Protection',
    category: 'watches',
    subcategory: 'Avant-Garde Horology',
    priceSGD: 295000,
    images: [
      'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'A revolutionary mechanical perpetual calendar architecture designed by Stephen McDonnell, featuring a 14mm suspended balance wheel above the dial.',
    specifications: {
      'Case': 'Zirconium with screw-down crown',
      'Water Resistance': '80 metres',
      'Movement': 'Fully integrated 581-component perpetual calendar'
    },
    provenance: {
      origin: 'Geneva, Switzerland',
      year: '2024',
      certificate: 'MB&F Passport of Authenticity signed by Maximilian Büsser',
      authenticityGuarantee: 'Singapore Privé VIP Allocation'
    },
    availability: 'limited',
    limitedEditionNumber: 'No. 08/15 Worldwide',
    tags: ['MB&F', 'Avant Garde', 'Perpetual Calendar'],
    isDemonstrationData: true
  },
  {
    id: 'w-12',
    slug: 'de-bethune-db28-xp-kind-of-blue',
    brand: 'De Bethune',
    brandSlug: 'patek-philippe',
    name: 'DB28 XP Kind of Blue Tourbillon',
    subtitle: 'Thermal Blued Grade 5 Titanium',
    category: 'watches',
    subcategory: 'Independent Tourbillon',
    priceSGD: 360000,
    images: [
      'https://images.unsplash.com/photo-1523275335684-37898b6baf30?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'Flame-blued titanium case with floating lugs. Ultra-light 0.18 gram silicon-titanium tourbillon rotating every 30 seconds.',
    specifications: {
      'Case': 'Blued Grade 5 Titanium with mirror polish',
      'Movement': 'Calibre DB2009 v2 with 6 days power reserve',
      'Lugs': 'Patented floating lug system adapting to wrist'
    },
    provenance: {
      origin: 'L’Auberson, Switzerland',
      year: '2025',
      certificate: 'De Bethune Master Watchmaker Certificate',
      authenticityGuarantee: 'Vault Verified'
    },
    availability: 'limited',
    tags: ['De Bethune', 'Titanium', 'Blued'],
    isDemonstrationData: true
  },

  // ----------------------------------------------------
  // FASHION (12 items)
  // ----------------------------------------------------
  {
    id: 'f-01',
    slug: 'hermes-birkin-25-faubourg-day-edition',
    brand: 'Hermès',
    brandSlug: 'hermes',
    name: 'Birkin 25 Sellier Faubourg Day',
    subtitle: 'Madame, Epsom, Sombrero & Swift Leathers with Palladium Hardware',
    category: 'fashion',
    subcategory: 'Haute Leatherware',
    priceSGD: 298000,
    images: [
      'https://images.unsplash.com/photo-1584917865442-de89df76afd3?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1590874103328-eac38a683ce7?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'The holy grail of leather goods. Recreating the architectural façade of the flagship at 24 Rue du Faubourg Saint-Honoré in Paris across intricate hand-stitched leathers.',
    story: 'Directly sourced for Singapore Privé VIP clients. Includes original orange box, rain cover, keys, clochette, and official Hermès store receipt.',
    specifications: {
      'Dimensions': '25 cm x 20 cm x 13 cm',
      'Stamp': 'W Stamp (2024)',
      'Hardware': 'Palladium Plated',
      'Condition': 'Store Fresh Pristine Unused'
    },
    provenance: {
      origin: 'Paris, France',
      year: '2024',
      certificate: 'Hermès Official Invoice & Singapore Privé Authenticity Seal',
      authenticityGuarantee: '100% Lifetime Authenticity Guarantee'
    },
    availability: 'limited',
    limitedEditionNumber: 'Exclusive Allocation',
    featuredInSingaporeEdit: true,
    tags: ['Hermes', 'Birkin', 'Faubourg', 'Rare Leather'],
    isDemonstrationData: true
  },
  {
    id: 'f-02',
    slug: 'bottega-veneta-andiamo-crocodile-large',
    brand: 'Bottega Veneta',
    brandSlug: 'bottega-veneta',
    name: 'Large Andiamo Tote in Porosus Crocodile',
    subtitle: 'Earthy Espresso Matte Finish with Knot Brass Clasp',
    category: 'fashion',
    subcategory: 'Bespoke Bags',
    priceSGD: 82000,
    images: [
      'https://images.unsplash.com/photo-1590874103328-eac38a683ce7?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1584917865442-de89df76afd3?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'Crafted from CITES-certified Porosus crocodile skins in a supple unstructured silhouette. Features sliding braided strap with signature metal brass knot.',
    specifications: {
      'Material': '100% Porosus Crocodile Skin & Lambskin Lining',
      'Hardware': 'Hand-brushed Gold Finish Brass',
      'Dimensions': '42 cm x 35 cm x 18 cm'
    },
    provenance: {
      origin: 'Montebello Vicentino, Italy',
      year: '2025',
      certificate: 'CITES Passport & Bottega Veneta Certificate of Craft',
      authenticityGuarantee: 'Verified'
    },
    availability: 'available',
    featuredInSingaporeEdit: true,
    tags: ['Bottega Veneta', 'Crocodile', 'Andiamo'],
    isDemonstrationData: true
  },
  {
    id: 'f-03',
    slug: 'loro-piana-vicuna-double-cashmere-overcoat',
    brand: 'Loro Piana',
    brandSlug: 'loro-piana',
    name: 'Bespoke Vicuña & Baby Cashmere Grand Overcoat',
    subtitle: 'Natural Vicuña Cinnamon Hue with Sable Fur Collar',
    category: 'fashion',
    subcategory: 'Haute Couture Outerwear',
    priceSGD: 46000,
    images: [
      'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'Harvested under strict sustainable conservation in the Andean highlands. Unrivalled softness and natural thermal regulation, hand-sewn in Quarona.',
    specifications: {
      'Material': '100% Peruvian Vicuña & 100% Baby Cashmere',
      'Collar': 'Detachable Russian Sable',
      'Origin of Fibre': 'Peruvian High Andes'
    },
    provenance: {
      origin: 'Quarona, Italy',
      year: '2025',
      certificate: 'Loro Piana Vicuña Guarantee of Origin Certificate',
      authenticityGuarantee: 'Certified Authentic'
    },
    availability: 'available',
    featuredInSingaporeEdit: false,
    tags: ['Loro Piana', 'Vicuna', 'Bespoke Outerwear'],
    isDemonstrationData: true
  },
  {
    id: 'f-04',
    slug: 'hermes-kelly-20-mini-alligator-vert-emerald',
    brand: 'Hermès',
    brandSlug: 'hermes',
    name: 'Mini Kelly 20 Shiny Alligator Vert Émeraude',
    subtitle: 'Gold Hardware with Tonal Stitching',
    category: 'fashion',
    subcategory: 'Exotic Leatherware',
    priceSGD: 142000,
    images: [
      'https://images.unsplash.com/photo-1584917865442-de89df76afd3?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'A striking jewel-toned statement bag. Hand-selected Mississippiensis alligator skin in deep emerald green, polished to a high porcelain sheen.',
    specifications: {
      'Dimensions': '20 cm x 12 cm x 6 cm',
      'Material': 'Shiny Alligator Mississippiensis',
      'Hardware': '18k Gold Plated'
    },
    provenance: {
      origin: 'Paris, France',
      year: '2025',
      certificate: 'CITES Export Permit & Original Receipt',
      authenticityGuarantee: 'Vault Authenticated'
    },
    availability: 'limited',
    featuredInSingaporeEdit: true,
    tags: ['Hermes', 'Kelly', 'Alligator', 'Emerald'],
    isDemonstrationData: true
  },
  {
    id: 'f-05',
    slug: 'brioni-bespoke-vicuna-silk-tuxedo',
    brand: 'Brioni',
    brandSlug: 'loro-piana',
    name: 'Master Bespoke Vicuña & Silk Dinner Suit',
    subtitle: 'Midnight Navy Satin Shawl Lapel',
    category: 'fashion',
    subcategory: 'Tailoring',
    priceSGD: 38000,
    images: [
      'https://images.unsplash.com/photo-1507679799987-c73779587ccf?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'Tailored by master artisans in Penne over 220 manual steps. Lightweight vicuña silk blend engineered specifically for Singapore tropical galas.',
    specifications: {
      'Fabric': '65% Vicuña, 35% Pure Mulberry Silk',
      'Construction': 'Full Floating Canvas with Silk Hand Stitching',
      'Buttons': 'Natural Horn wrapped in silk trim'
    },
    provenance: {
      origin: 'Penne, Abruzzo, Italy',
      year: '2025',
      certificate: 'Brioni Bespoke Tailoring Certificate',
      authenticityGuarantee: 'Verified'
    },
    availability: 'available',
    tags: ['Brioni', 'Tuxedo', 'Tailoring'],
    isDemonstrationData: true
  },
  {
    id: 'f-06',
    slug: 'chanel-metiers-dart-strass-evening-clutch',
    brand: 'Chanel',
    brandSlug: 'hermes',
    name: 'Métiers d’Art Minaudière Crystal Cage',
    subtitle: '24k Gold Gilt Metal & Swarovski Strass',
    category: 'fashion',
    subcategory: 'Eveningwear',
    priceSGD: 34500,
    images: [
      'https://images.unsplash.com/photo-1566150905458-1bf1fc113f0d?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'Handcrafted by Lesage and Goossens for Chanel Métiers d’Art. Intricate gold birdcage frame encrusted with baguette-cut clear crystals.',
    specifications: {
      'Dimensions': '16 cm x 11 cm x 5 cm',
      'Chain Drop': '55 cm gold chain with leather strap',
      'Edition': 'Runway Collector Piece'
    },
    provenance: {
      origin: 'Paris, France',
      year: '2024',
      certificate: 'Chanel Hologram & Authenticity Card',
      authenticityGuarantee: 'Guaranteed'
    },
    availability: 'limited',
    tags: ['Chanel', 'Minaudiere', 'Metiers d Art'],
    isDemonstrationData: true
  },
  {
    id: 'f-07',
    slug: 'delvaux-tempete-mm-ostrich-gold',
    brand: 'Delvaux',
    brandSlug: 'bottega-veneta',
    name: 'Tempête MM Ostrich Leather in Safran',
    subtitle: 'Golden Ostrich Leather with Brushed Brass Clasps',
    category: 'fashion',
    subcategory: 'Haute Leatherware',
    priceSGD: 29500,
    images: [
      'https://images.unsplash.com/photo-1590874103328-eac38a683ce7?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'Founded in Brussels in 1829, Delvaux is the world’s oldest fine leather luxury house. The Tempête features architectural sail-inspired studs.',
    specifications: {
      'Material': 'Full Ostrich Leather',
      'Dimensions': '27.5 cm x 21 cm x 10.5 cm',
      'Hardware': 'Jewellery-grade Brushed Gold Finish'
    },
    provenance: {
      origin: 'Brussels, Belgium',
      year: '2025',
      certificate: 'Delvaux Royal Warrant Seal',
      authenticityGuarantee: 'Verified'
    },
    availability: 'available',
    tags: ['Delvaux', 'Ostrich', 'Leather'],
    isDemonstrationData: true
  },
  {
    id: 'f-08',
    slug: 'tom-ford-silk-velvet-smoking-jacket',
    brand: 'Tom Ford',
    brandSlug: 'loro-piana',
    name: 'Bespoke Emerald Silk Velvet Smoking Jacket',
    subtitle: 'Black Grosgrain Silk Trim & Quilted Cuffs',
    category: 'fashion',
    subcategory: 'Tailoring',
    priceSGD: 12800,
    images: [
      'https://images.unsplash.com/photo-1507679799987-c73779587ccf?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'Rich deep emerald silk velvet woven in Como, Italy. Features hand-braided frog fastenings and quilted silk lining.',
    specifications: {
      'Material': '100% Silk Velvet Outer, 100% Cupro Lining',
      'Details': 'Traditional Frog Fastening'
    },
    provenance: {
      origin: 'Milan, Italy',
      year: '2025',
      certificate: 'Tom Ford Atelier Tag',
      authenticityGuarantee: 'Verified'
    },
    availability: 'available',
    tags: ['Tom Ford', 'Smoking Jacket', 'Velvet'],
    isDemonstrationData: true
  },
  {
    id: 'f-09',
    slug: 'louis-vuitton-courrier-lozine-110-trunk',
    brand: 'Louis Vuitton',
    brandSlug: 'hermes',
    name: 'Courrier Lozine 110 Monogram Heritage Trunk',
    subtitle: 'Brass Hardware, Leather Trim & Custom Hand-Painted Monogram',
    category: 'fashion',
    subcategory: 'Malleterie & Trunks',
    priceSGD: 52000,
    images: [
      'https://images.unsplash.com/photo-1584917865442-de89df76afd3?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'Crafted in Asnières-sur-Seine using 19th-century trunkmaking techniques. Wood structure lined in gaboon wood, lozine borders, and solid brass locks.',
    specifications: {
      'Dimensions': '110 cm x 55 cm x 48 cm',
      'Structure': 'Poplar wood frame, solid brass locks',
      'Lock Number': 'Unique registered lock key set'
    },
    provenance: {
      origin: 'Asnières-sur-Seine, France',
      year: '2024',
      certificate: 'Louis Vuitton Asnières Registry Certificate',
      authenticityGuarantee: 'Direct LV Heritage Provenance'
    },
    availability: 'available',
    tags: ['Louis Vuitton', 'Trunk', 'Heritage'],
    isDemonstrationData: true
  },
  {
    id: 'f-10',
    slug: 'brunello-cucinelli-shearling-cashmere-puffer',
    brand: 'Brunello Cucinelli',
    brandSlug: 'loro-piana',
    name: 'Hand-Finished Shearling & Cashmere Travel Coat',
    subtitle: 'Monili Beaded Trim in Warm Sand Tone',
    category: 'fashion',
    subcategory: 'Luxury Travelwear',
    priceSGD: 24800,
    images: [
      'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'Crafted in Solomeo, Italy. Ultra-light curly shearling paired with water-resistant double cashmere for high-altitude private aviation.',
    specifications: {
      'Material': 'Merino Shearling & Double Cashmere',
      'Accent': 'Signature brass Monili glass beads'
    },
    provenance: {
      origin: 'Solomeo, Umbria, Italy',
      year: '2025',
      certificate: 'Solomeo Artisan Tag',
      authenticityGuarantee: 'Verified'
    },
    availability: 'available',
    tags: ['Brunello Cucinelli', 'Cashmere', 'Shearling'],
    isDemonstrationData: true
  },
  {
    id: 'f-11',
    slug: 'moynat-limousine-handbag-alligator-black',
    brand: 'Moynat',
    brandSlug: 'hermes',
    name: 'Moynat Limousine 28 Matte Black Alligator',
    subtitle: 'Curved Trunk Base with Palladium Jewel Clasp',
    category: 'fashion',
    subcategory: 'Haute Leatherware',
    priceSGD: 68000,
    images: [
      'https://images.unsplash.com/photo-1590874103328-eac38a683ce7?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'Inspired by the curved automobile trunks created by Pauline Moynat in 1902 to match the contour of limousine roofs.',
    specifications: {
      'Dimensions': '28 cm x 18 cm x 11 cm',
      'Material': 'Matte Alligator Mississippiensis'
    },
    provenance: {
      origin: 'Paris, France',
      year: '2025',
      certificate: 'CITES Certificate & Moynat Trunkmaker Book',
      authenticityGuarantee: 'Verified'
    },
    availability: 'available',
    tags: ['Moynat', 'Alligator', 'Trunk Bag'],
    isDemonstrationData: true
  },
  {
    id: 'f-12',
    slug: 'berluti-alessandro-galet-python-oxfords',
    brand: 'Berluti',
    brandSlug: 'bottega-veneta',
    name: 'Alessandro Galet Patinated Python Oxfords',
    subtitle: 'Whole-cut Python with Venezia Leather Inlays',
    category: 'fashion',
    subcategory: 'Footwear',
    priceSGD: 16500,
    images: [
      'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'Single-piece wholecut oxford crafted from python skin with hand-applied tobacco patina developed in Paris by Olga Berluti.',
    specifications: {
      'Construction': 'Goodyear Welted with Hand-Pegged Waist',
      'Leather': 'Reticulated Python Skin with Venezia Calfskin'
    },
    provenance: {
      origin: 'Paris / Gaibanella, Italy',
      year: '2025',
      certificate: 'Berluti Master Shoemaker Card',
      authenticityGuarantee: 'Verified'
    },
    availability: 'available',
    tags: ['Berluti', 'Python', 'Oxfords'],
    isDemonstrationData: true
  },

  // ----------------------------------------------------
  // JEWELLERY (12 items)
  // ----------------------------------------------------
  {
    id: 'j-01',
    slug: 'cartier-panthere-high-jewellery-diamond-necklace',
    brand: 'Cartier',
    brandSlug: 'cartier',
    name: 'Panthère de Cartier High Jewellery Necklace',
    subtitle: '18k White Gold, Brilliant-Cut Diamonds, Emerald Eyes & Onyx Spots',
    category: 'jewellery',
    subcategory: 'Haute Joaillerie',
    priceSGD: 385000,
    images: [
      'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1605100804763-247f67b3557e?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'The panther, icon of Cartier haute joaillerie. Set with over 1,400 round brilliant-cut diamonds totaling 28.5 carats, two pear-shaped emerald eyes, and hand-sculpted onyx spots.',
    specifications: {
      'Gemstones': '28.50 carats D-F color IF-VVS diamonds, 2 Emeralds (0.85 ct), Onyx cabochons',
      'Metal': '18k White Gold (Rhodeated)',
      'Hallmark': 'Cartier Atelier Seal & Serialized Unique Stamp'
    },
    provenance: {
      origin: 'Rue de la Paix, Paris',
      year: '2024',
      certificate: 'GIA Diamond Dossiers & Cartier Haute Joaillerie Certificate',
      authenticityGuarantee: 'Direct Cartier VIP Concierge Deposit'
    },
    availability: 'limited',
    limitedEditionNumber: 'Unique Piece No. 01/01',
    featuredInSingaporeEdit: true,
    tags: ['Cartier', 'Panthere', 'Diamond', 'Haute Joaillerie'],
    isDemonstrationData: true
  },
  {
    id: 'j-02',
    slug: 'van-cleef-arpels-mystery-set-ruby-peony-ring',
    brand: 'Van Cleef & Arpels',
    brandSlug: 'van-cleef-arpels',
    name: 'Peony Mystery Set Burmese Ruby Ring',
    subtitle: 'Serti Mystérieux Rubies (18.2 ct) with Diamond Leaves in Platinum',
    category: 'jewellery',
    subcategory: 'Mystery Set',
    priceSGD: 420000,
    images: [
      'https://images.unsplash.com/photo-1605100804763-247f67b3557e?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'Utilizing Van Cleef & Arpels’ patented 1933 Serti Mystérieux technique. No metal prongs are visible, creating an uninterrupted velvet sea of vivid unheated Burmese rubies.',
    specifications: {
      'Rubies': '18.20 carats Natural Unheated Burmese Rubies',
      'Diamonds': '3.40 carats Marquise & Round Diamonds',
      'Metal': 'Platinum & 18k Yellow Gold'
    },
    provenance: {
      origin: 'Place Vendôme, Paris',
      year: '2025',
      certificate: 'SSEF & Gübelin Gemstone Reports (Unheated Burma Pigeon Blood)',
      authenticityGuarantee: 'Vault Sealed'
    },
    availability: 'limited',
    limitedEditionNumber: 'One-of-a-kind Masterpiece',
    featuredInSingaporeEdit: true,
    tags: ['Van Cleef', 'Mystery Set', 'Burmese Ruby'],
    isDemonstrationData: true
  },
  {
    id: 'j-03',
    slug: 'boucheron-question-mark-emerald-necklace',
    brand: 'Boucheron',
    brandSlug: 'boucheron',
    name: 'Point d’Interrogation Emerald Lierre Necklace',
    subtitle: 'Column of Colombian Emeralds & Paved Diamond Ivy Leaves',
    category: 'jewellery',
    subcategory: 'Haute Joaillerie',
    priceSGD: 310000,
    images: [
      'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'Invented by Frédéric Boucheron in 1879, the clasp-free question mark necklace wraps seamlessly around the neck. Features an extraordinary 8.50 ct Muzo emerald drop.',
    specifications: {
      'Center Stone': '8.50 carat Octagonal Step-Cut Colombian Emerald (Minor Oil)',
      'Side Diamonds': '14.20 carats E-F VVS diamonds',
      'Metal': '18k White Gold'
    },
    provenance: {
      origin: 'Paris, France',
      year: '2025',
      certificate: 'Gübelin Emerald Report',
      authenticityGuarantee: 'Guaranteed Authentic'
    },
    availability: 'available',
    featuredInSingaporeEdit: true,
    tags: ['Boucheron', 'Emerald', 'Question Mark'],
    isDemonstrationData: true
  },
  {
    id: 'j-04',
    slug: 'graff-fancy-vivid-yellow-diamond-earrings',
    brand: 'Graff',
    brandSlug: 'cartier',
    name: 'Fancy Vivid Yellow Diamond Drop Earrings',
    subtitle: '12.4 Carats Total Fancy Vivid Yellow Cushion Diamonds',
    category: 'jewellery',
    subcategory: 'Rare Diamonds',
    priceSGD: 560000,
    images: [
      'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'Matching pair of intense golden yellow cushion-cut diamonds suspended from white pear-shaped diamond clusters. Hand-mounted in London.',
    specifications: {
      'Yellow Diamonds': '6.15 ct & 6.25 ct Fancy Vivid Yellow VVS1',
      'White Diamonds': '4.10 carats Collection Quality Pear Cuts',
      'Metal': 'Platinum & 18k Yellow Gold'
    },
    provenance: {
      origin: 'Mayfair, London',
      year: '2025',
      certificate: 'Dual GIA Gemological Reports',
      authenticityGuarantee: 'Graff Certificate of Quality'
    },
    availability: 'available',
    tags: ['Graff', 'Yellow Diamond', 'Rare Gemstones'],
    isDemonstrationData: true
  },
  {
    id: 'j-05',
    slug: 'bulgari-serpenti-haute-joaillerie-cuff',
    brand: 'Bulgari',
    brandSlug: 'boucheron',
    name: 'Serpenti Secret Diamond & Sapphire Cuff Bracelet',
    subtitle: '18k White Gold, Royal Blue Sapphires & Brilliant Diamonds',
    category: 'jewellery',
    subcategory: 'Secret Watches & Cuffs',
    priceSGD: 260000,
    images: [
      'https://images.unsplash.com/photo-1605100804763-247f67b3557e?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'Coiling around the wrist with tactile geometric articulation. The snake head opens to reveal a secret diamond paved watch dial.',
    specifications: {
      'Sapphires': '14.50 carats Ceylon Sapphires',
      'Diamonds': '18.80 carats Pavé Diamonds',
      'Mechanism': 'Quartz B033 secret movement'
    },
    provenance: {
      origin: 'Rome, Italy',
      year: '2024',
      certificate: 'Bulgari High Jewellery Certificate',
      authenticityGuarantee: 'Verified'
    },
    availability: 'available',
    tags: ['Bulgari', 'Serpenti', 'Sapphire'],
    isDemonstrationData: true
  },
  {
    id: 'j-06',
    slug: 'piaget-aura-high-jewellery-diamond-cuff',
    brand: 'Piaget',
    brandSlug: 'cartier',
    name: 'Aura Seamless Baguette Diamond Bracelet',
    subtitle: 'Fully Paved Baguette-Cut Diamonds in 18k White Gold',
    category: 'jewellery',
    subcategory: 'Baguette Cut',
    priceSGD: 225000,
    images: [
      'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'An unbroken ribbon of sparkling baguette-cut diamonds fitted around the wrist with invisible stone setting precision.',
    specifications: {
      'Diamonds': '32.40 carats Baguette Diamonds (F-G color, VVS clarity)',
      'Metal': '18k White Gold'
    },
    provenance: {
      origin: 'Geneva / La Côte-aux-Fées',
      year: '2025',
      certificate: 'Piaget Gemmological Certificate',
      authenticityGuarantee: 'Verified'
    },
    availability: 'available',
    tags: ['Piaget', 'Baguette Diamond', 'Bracelet'],
    isDemonstrationData: true
  },
  {
    id: 'j-07',
    slug: 'chaumet-josephine-aigrette-tiara-ring',
    brand: 'Chaumet',
    brandSlug: 'van-cleef-arpels',
    name: 'Joséphine Aigrette Impériale Sapphire Tiara Ring',
    subtitle: '5.20 ct Royal Blue Sapphire & Pear Diamond Halo',
    category: 'jewellery',
    subcategory: 'Rings',
    priceSGD: 168000,
    images: [
      'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'Inspired by Empress Joséphine’s royal tiaras. Features a central unheated Ceylon sapphire crowned with V-shaped diamond tiara bands.',
    specifications: {
      'Sapphire': '5.20 ct Unheated Ceylon Sapphire',
      'Diamonds': '2.80 ct Pear & Round Diamonds',
      'Metal': 'Platinum'
    },
    provenance: {
      origin: 'Place Vendôme, Paris',
      year: '2025',
      certificate: 'GRS Gemresearch Swisslab Sapphire Report',
      authenticityGuarantee: 'Verified'
    },
    availability: 'available',
    tags: ['Chaumet', 'Josephine', 'Sapphire Ring'],
    isDemonstrationData: true
  },
  {
    id: 'j-08',
    slug: 'chopard-red-carpet-collection-paraiba-necklace',
    brand: 'Chopard',
    brandSlug: 'boucheron',
    name: 'Red Carpet Collection Paraíba Tourmaline Pendant',
    subtitle: '11.8 ct Neon Blue Paraíba Tourmaline & Diamond Choker',
    category: 'jewellery',
    subcategory: 'Rare Tourmalines',
    priceSGD: 490000,
    images: [
      'https://images.unsplash.com/photo-1605100804763-247f67b3557e?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'Electric neon turquoise-blue copper-bearing Paraíba tourmaline from Mozambique, cradled in Fairmined 18k white gold and ethical diamonds.',
    specifications: {
      'Paraíba Tourmaline': '11.80 carats Oval Mixed Cut',
      'Metal': '18k Fairmined White Gold',
      'Ethical Certification': 'Chopard Journey to Sustainable Luxury'
    },
    provenance: {
      origin: 'Geneva, Switzerland',
      year: '2025',
      certificate: 'Gübelin Gemmological Report',
      authenticityGuarantee: 'Verified'
    },
    availability: 'limited',
    tags: ['Chopard', 'Paraiba', 'Tourmaline'],
    isDemonstrationData: true
  },
  {
    id: 'j-09',
    slug: 'tiffany-and-co-schlumberger-bird-on-a-rock',
    brand: 'Tiffany & Co.',
    brandSlug: 'cartier',
    name: 'Jean Schlumberger Bird on a Rock Brooch',
    subtitle: '42.5 ct Aquamarine with Diamond & Ruby Bird in Platinum',
    category: 'jewellery',
    subcategory: 'Brooches & High Jewellery',
    priceSGD: 198000,
    images: [
      'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'Designed by Jean Schlumberger in 1965. A whimsical platinum diamond bird perched atop a breathtaking 42.5-carat cushion-cut sea-blue aquamarine.',
    specifications: {
      'Aquamarine': '42.50 carats Cushion Cut',
      'Bird Accent': '3.20 ct Pavé Diamonds with Pink Sapphire Eye',
      'Metal': 'Platinum & 18k Yellow Gold'
    },
    provenance: {
      origin: 'New York, USA',
      year: '2024',
      certificate: 'Tiffany & Co. Diamond & Gemstone Certificate',
      authenticityGuarantee: 'Verified'
    },
    availability: 'available',
    tags: ['Tiffany', 'Schlumberger', 'Aquamarine'],
    isDemonstrationData: true
  },
  {
    id: 'j-10',
    slug: 'david-morris-pink-diamond-eternity-band',
    brand: 'David Morris',
    brandSlug: 'cartier',
    name: 'Argyle Pink Diamond Eternity Band',
    subtitle: 'Full Circle Natural Intense Pink Oval Cut Diamonds',
    category: 'jewellery',
    subcategory: 'Rings',
    priceSGD: 285000,
    images: [
      'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'Crafted from original mined stones from the now-closed Argyle Mine in Australia. 18 matching Fancy Intense Pink oval diamonds.',
    specifications: {
      'Pink Diamonds': '6.80 carats Total Weight (Fancy Intense Pink)',
      'Metal': '18k Rose Gold'
    },
    provenance: {
      origin: 'Bond Street, London',
      year: '2023',
      certificate: 'Argyle Pink Diamonds Lot Numbers & GIA Certificates',
      authenticityGuarantee: 'Verified'
    },
    availability: 'limited',
    tags: ['David Morris', 'Pink Diamond', 'Argyle'],
    isDemonstrationData: true
  },
  {
    id: 'j-11',
    slug: 'mikimoto-white-south-sea-pearl-strand',
    brand: 'Mikimoto',
    brandSlug: 'van-cleef-arpels',
    name: 'The Empress South Sea Pearl & Diamond Choker',
    subtitle: '14mm-16.8mm Perfect Round Australian South Sea Pearls',
    category: 'jewellery',
    subcategory: 'High Pearls',
    priceSGD: 138000,
    images: [
      'https://images.unsplash.com/photo-1605100804763-247f67b3557e?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'Selected from the top 0.01% of Australian South Sea pearl harvests. Deep silken luster with pink overtones and a diamond ball clasp.',
    specifications: {
      'Pearls': '29 Graduated South Sea Cultured Pearls (14mm to 16.8mm)',
      'Clasp': '18k White Gold Ball Clasp with 2.50 ct Pavé Diamonds'
    },
    provenance: {
      origin: 'Ginza, Tokyo, Japan',
      year: '2025',
      certificate: 'Mikimoto Pearl Guarantee & Inspection Certificate',
      authenticityGuarantee: 'Verified'
    },
    availability: 'available',
    tags: ['Mikimoto', 'South Sea Pearls', 'Choker'],
    isDemonstrationData: true
  },
  {
    id: 'j-12',
    slug: 'de-beers-the-alchemist-of-light-cuff',
    brand: 'De Beers',
    brandSlug: 'cartier',
    name: 'Alchemist of Light Optical Wonder Cuff',
    subtitle: 'Black Aluminum, Titanium & Rough/Polished White Diamonds',
    category: 'jewellery',
    subcategory: 'Contemporary High Jewellery',
    priceSGD: 215000,
    images: [
      'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'Contrasting black anodized aluminum with rough natural octahedral diamonds and flawless polished princess-cut diamonds.',
    specifications: {
      'Diamonds': '14.80 carats Total Diamond Weight',
      'Materials': 'Anodized Black Aluminum & Titanium'
    },
    provenance: {
      origin: 'London, UK',
      year: '2025',
      certificate: 'De Beers Code of Origin Certificate',
      authenticityGuarantee: 'Verified'
    },
    availability: 'available',
    tags: ['De Beers', 'High Jewellery', 'Diamonds'],
    isDemonstrationData: true
  },

  // ----------------------------------------------------
  // ART & COLLECTIBLES (12 items)
  // ----------------------------------------------------
  {
    id: 'a-01',
    slug: 'gerhard-richter-abstraktes-bild-2018',
    brand: 'Gagosian & Private Advisory',
    brandSlug: 'gagosian-singapore',
    name: 'Abstraktes Bild (889-4)',
    subtitle: 'Oil on Canvas, 120 x 100 cm by Gerhard Richter',
    category: 'art',
    subcategory: 'Contemporary Masters',
    priceSGD: 4200000,
    images: [
      'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1541701494587-cb58502866ab?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'A monument of contemporary abstract painting created using Richter’s master squeegee dragging technique. Multilayered primary pigments on heavy linen.',
    story: 'Directly acquired from a private Swiss collection. Stored in Singapore FreePort Bonded Vaults under inert atmospheric conditions.',
    specifications: {
      'Medium': 'Oil on Canvas',
      'Dimensions': '120 cm x 100 cm (47.2 in x 39.4 in)',
      'Signature': 'Signed and dated on reverse "Richter 2018 / 889-4"',
      'Catalogue Raisonné': 'Vol. 5, No. 889-4'
    },
    provenance: {
      origin: 'Cologne / Zurich Private Collection',
      year: '2018',
      certificate: 'Gerhard Richter Archiv Certificate & Gagosian Advisory Provenance',
      authenticityGuarantee: 'Full Museum-Grade Provenance Documentation'
    },
    availability: 'limited',
    limitedEditionNumber: 'Unique Original Work',
    featuredInSingaporeEdit: true,
    tags: ['Gerhard Richter', 'Oil Painting', 'Contemporary Art', 'Museum Grade'],
    isDemonstrationData: true
  },
  {
    id: 'a-02',
    slug: 'yayoi-kusama-bronze-pumpkin-sculpture-2022',
    brand: 'Gagosian & Private Advisory',
    brandSlug: 'gagosian-singapore',
    name: 'Bronze Pumpkin (Yellow & Black Polka Dots)',
    subtitle: 'Hand-Finished Cast Bronze with Patinated Enamel',
    category: 'art',
    subcategory: 'Sculpture',
    priceSGD: 1850000,
    images: [
      'https://images.unsplash.com/photo-1541701494587-cb58502866ab?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'An iconic Kusama motif embodying eternal cosmic infinity. Cast bronze with hand-painted yellow enamel and deep black polka dot perforations.',
    specifications: {
      'Medium': 'Cast Bronze with Enamel Paint',
      'Dimensions': '65 cm x 70 cm x 70 cm',
      'Weight': '88 kg',
      'Edition': 'Edition of 8 + 2 Artist Proofs'
    },
    provenance: {
      origin: 'Tokyo, Japan',
      year: '2022',
      certificate: 'Yayoi Kusama Studio Certificate of Authenticity',
      authenticityGuarantee: 'Verified Studio Provenance'
    },
    availability: 'limited',
    limitedEditionNumber: 'No. 03/08',
    featuredInSingaporeEdit: true,
    tags: ['Yayoi Kusama', 'Pumpkin', 'Bronze Sculpture'],
    isDemonstrationData: true
  },
  {
    id: 'a-03',
    slug: 'namiki-emperor-dragon-maki-e-fountain-pen',
    brand: 'Namiki',
    brandSlug: 'gagosian-singapore',
    name: 'Emperor Collection Five-Clawed Dragon Maki-e Pen',
    subtitle: 'Taka-Maki-e Lacquerware with 18k Gold Nib No. 50',
    category: 'art',
    subcategory: 'Rare Collectibles',
    priceSGD: 48000,
    images: [
      'https://images.unsplash.com/photo-1583485088034-697b5bc54ccd?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'Handcrafted in Hiratsuka by Kokokai master artisan Kyusai Yoshida over 18 months. Raised relief Maki-e lacquering using pure gold and silver powders.',
    specifications: {
      'Nib': '18k Gold Size #50 Jumbo Nib',
      'Filling System': 'Eyedropper filling with traditional Japanese shut-off valve',
      'Body Material': 'Ebonite dipped in Urushi Lacquer'
    },
    provenance: {
      origin: 'Hiratsuka, Japan',
      year: '2024',
      certificate: 'Hand-signed Wooden Paulownia Box & Master Artisan Certificate',
      authenticityGuarantee: 'Verified'
    },
    availability: 'available',
    featuredInSingaporeEdit: true,
    tags: ['Namiki', 'Maki-e', 'Fountain Pen', 'Urushi'],
    isDemonstrationData: true
  },
  {
    id: 'a-04',
    slug: 'macallan-77-year-old-the-reach-single-malt',
    brand: 'The Macallan',
    brandSlug: 'gagosian-singapore',
    name: 'The Macallan 77-Year-Old Single Malt Whisky',
    subtitle: 'The Reach Collection Decanter suspended on Sculpted Bronze Hands',
    category: 'art',
    subcategory: 'Rare Spirits & Casks',
    priceSGD: 210000,
    images: [
      'https://images.unsplash.com/photo-1527281400683-1aae777175f8?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'Distilled in 1940 and aged in a single sherry-seasoned oak cask. Presented in a mouth-blown glass decanter cradled by three bronze hands sculpted by Saskia Robinson.',
    specifications: {
      'ABV': '41.6% Vol',
      'Volume': '700 ml Mouth-Blown Crystal Decanter',
      'Maturation': '77 Years Single Sherry Cask'
    },
    provenance: {
      origin: 'Speyside, Scotland',
      year: '1940 Distillation / 2022 Bottling',
      certificate: 'The Macallan Archive Certificate & Hand-Numbered Ledger',
      authenticityGuarantee: 'Singapore Privé Sealed Vault Cask'
    },
    availability: 'limited',
    limitedEditionNumber: 'Decanter No. 18/288',
    featuredInSingaporeEdit: true,
    tags: ['Macallan', 'Whisky', 'Rare Spirits', '1940 Vintage'],
    isDemonstrationData: true
  },
  {
    id: 'a-05',
    slug: 'chateau-lafite-rothschild-1982-imperiale-6l',
    brand: 'Château Lafite Rothschild',
    brandSlug: 'gagosian-singapore',
    name: '1982 Château Lafite Rothschild Impériale (6 Litres)',
    subtitle: 'Pauillac First Growth — Pristine Original Wooden Case',
    category: 'art',
    subcategory: 'Wine & Cellars',
    priceSGD: 85000,
    images: [
      'https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'The legendary 100-point 1982 vintage in a rare 6-litre Impériale format. Cellared since release at 12°C in professional Singapore Freeport bonded storage.',
    specifications: {
      'Volume': '6 Litres (Equivalent to 8 standard bottles)',
      'Ullage': 'High Neck / Bottom Neck',
      'Score': '100 Points Robert Parker'
    },
    provenance: {
      origin: 'Pauillac, Bordeaux, France',
      year: '1982 Vintage',
      certificate: 'Château Lafite ProProof NFC Anti-Counterfeit Seal',
      authenticityGuarantee: 'Temperature Logged Cellar History'
    },
    availability: 'available',
    tags: ['Lafite Rothschild', '1982 Vintage', 'Bordeaux', 'Imperiale'],
    isDemonstrationData: true
  },
  {
    id: 'a-06',
    slug: 'zaha-hadid-design-liquid-glacial-dining-table',
    brand: 'Zaha Hadid Design',
    brandSlug: 'rolls-royce-bespoke',
    name: 'Liquid Glacial Acrylic Dining Table',
    subtitle: 'Hand-Carved Polished Clear Acrylic Fluid Furniture',
    category: 'art',
    subcategory: 'Architectural Furniture',
    priceSGD: 240000,
    images: [
      'https://images.unsplash.com/photo-1538688525198-9b88f6f53126?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'Designed by Zaha Hadid. The table embeds geometry that mimics ice melting into swirling water vortices, refracting light like pure crystal.',
    specifications: {
      'Dimensions': '300 cm x 140 cm x 75 cm',
      'Material': 'Optical Grade Hand-Polished Acrylic Resin',
      'Weight': '320 kg'
    },
    provenance: {
      origin: 'London, UK / David Gill Gallery',
      year: '2023',
      certificate: 'Zaha Hadid Design Authenticity Certificate',
      authenticityGuarantee: 'Verified'
    },
    availability: 'limited',
    tags: ['Zaha Hadid', 'Liquid Glacial', 'Architectural Furniture'],
    isDemonstrationData: true
  },
  {
    id: 'a-07',
    slug: 'patek-philippe-dome-table-clock-maki-e-orchid',
    brand: 'Patek Philippe',
    brandSlug: 'patek-philippe',
    name: 'Dome Table Clock "Singapore Orchids"',
    subtitle: 'Unique Grand Feu Enamel & Cloisonné Gold Wire Clock',
    category: 'art',
    subcategory: 'Horological Art',
    priceSGD: 390000,
    images: [
      'https://images.unsplash.com/photo-1509042239860-f550ce710b93?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'A masterpiece of Rare Handcrafts created to commemorate Singapore’s botanical heritage. Cloisonné enamel depicting Vanda Miss Joaquim orchids.',
    specifications: {
      'Movement': 'Calibre 1782 PEND Mechanical winding by electric motor',
      'Enamel Wire': '24k Fine Gold Wire (approx. 22 metres used)',
      'Dimensions': '213.5 mm height'
    },
    provenance: {
      origin: 'Geneva, Switzerland',
      year: '2024',
      certificate: 'Patek Philippe Certificate of Unique Piece',
      authenticityGuarantee: 'Direct Private Salon Allocation'
    },
    availability: 'limited',
    limitedEditionNumber: 'Unique Piece 1/1',
    featuredInSingaporeEdit: true,
    tags: ['Patek Philippe', 'Dome Clock', 'Cloisonne Enamel'],
    isDemonstrationData: true
  },
  {
    id: 'a-08',
    slug: 'steinway-sons-spirio-r-custom-ebony',
    brand: 'Steinway & Sons',
    brandSlug: 'gagosian-singapore',
    name: 'Steinway & Sons Model B Spirio | r Masterwork',
    subtitle: 'High-Resolution Live Performance Recording & Playback Piano',
    category: 'art',
    subcategory: 'Acoustic Masterpieces',
    priceSGD: 288000,
    images: [
      'https://images.unsplash.com/photo-1520523839897-bd0b52f945a0?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'Handcrafted in Hamburg. The Spirio | r system allows real-time acoustic recording and ultra-high definition playback of legendary concerts inside your residence.',
    specifications: {
      'Length': '211 cm (6 ft 11 in)',
      'Finish': 'Polished Ebony with Brass Accents',
      'Technology': 'Spirio | r High-Definition Recording & iPad Pro Interface'
    },
    provenance: {
      origin: 'Hamburg, Germany',
      year: '2025',
      certificate: 'Steinway & Sons Hamburg Factory Certificate',
      authenticityGuarantee: 'Verified'
    },
    availability: 'available',
    tags: ['Steinway', 'Spirio', 'Grand Piano'],
    isDemonstrationData: true
  },
  {
    id: 'a-09',
    slug: 'hermes-equestrian-leather-saddle-bespoke',
    brand: 'Hermès',
    brandSlug: 'hermes',
    name: 'Hermès Vivace Bespoke Equestrian Saddle',
    subtitle: 'Hand-Stitched Taurillon Clemence Leather in Fauve',
    category: 'art',
    subcategory: 'Bespoke Saddlery',
    priceSGD: 28500,
    images: [
      'https://images.unsplash.com/photo-1584917865442-de89df76afd3?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'Embodying Hermès’ founding heritage as saddlemakers since 1837. Custom-fitted tree engineered for maximum freedom of movement.',
    specifications: {
      'Leather': 'Taurillon Clemence & Barenia Calfskin',
      'Tree': 'Carbon fibre tree with injected foam panels'
    },
    provenance: {
      origin: '24 Faubourg Saint-Honoré, Paris',
      year: '2025',
      certificate: 'Hermès Master Saddler Certificate',
      authenticityGuarantee: 'Verified'
    },
    availability: 'available',
    tags: ['Hermes', 'Saddle', 'Equestrian'],
    isDemonstrationData: true
  },
  {
    id: 'a-10',
    slug: 'baccarat-tsuyama-crystal-chandelier-gold',
    brand: 'Baccarat',
    brandSlug: 'gagosian-singapore',
    name: 'Baccarat Zenith 36-Light Gold Crystal Chandelier',
    subtitle: 'Clear & 24k Amber Gold Powdered Crystal Prisms',
    category: 'art',
    subcategory: 'Crystal & Lighting',
    priceSGD: 195000,
    images: [
      'https://images.unsplash.com/photo-1513519245088-0e12902e5a38?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'An emblem of French art de vivre. 36 crystal arms draped with octagonal prisms and the legendary single red crystal drop signed by Baccarat.',
    specifications: {
      'Height': '180 cm',
      'Diameter': '125 cm',
      'Weight': '115 kg'
    },
    provenance: {
      origin: 'Baccarat, Lorraine, France',
      year: '2025',
      certificate: 'Baccarat Certificate of Origin',
      authenticityGuarantee: 'Verified'
    },
    availability: 'available',
    tags: ['Baccarat', 'Chandelier', 'Crystal'],
    isDemonstrationData: true
  },
  {
    id: 'a-11',
    slug: 'saporiti-italia-1970s-vintage-leather-lounger',
    brand: 'Saporiti Italia',
    brandSlug: 'gagosian-singapore',
    name: 'Vintage 1974 Miamina Lounge Chair in Saddle Leather',
    subtitle: 'Architectural Chrome Frame & Hand-Patinated Italian Cognac Leather',
    category: 'art',
    subcategory: 'Mid-Century Design',
    priceSGD: 36000,
    images: [
      'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'Designed by Alberto Rosselli in 1974. Features a cross-legged chromed steel frame supporting a sling seat in original full-grain cognac saddle leather.',
    specifications: {
      'Dimensions': '98 cm x 92 cm x 88 cm',
      'Condition': 'Museum Quality Vintage Preservation'
    },
    provenance: {
      origin: 'Milan, Italy',
      year: '1974',
      certificate: 'Archivio Alberto Rosselli Authenticity Certificate',
      authenticityGuarantee: 'Verified'
    },
    availability: 'available',
    tags: ['Saporiti', 'Mid Century', 'Italian Design'],
    isDemonstrationData: true
  },
  {
    id: 'a-12',
    slug: 'patek-philippe-rare-handcrafts-pocket-watch-tiger',
    brand: 'Patek Philippe',
    brandSlug: 'patek-philippe',
    name: 'Rare Handcrafts Pocket Watch "Asian Tiger"',
    subtitle: 'Grand Feu Cloisonné Enamel Pocket Watch in Yellow Gold',
    category: 'art',
    subcategory: 'Rare Collectibles',
    priceSGD: 450000,
    images: [
      'https://images.unsplash.com/photo-1509042239860-f550ce710b93?q=80&w=1200&auto=format&fit=crop'
    ],
    description: 'Created using 52 cm of fine 24k gold wire and 24 enamel colors fired up to 12 times at 800°C. Crown set with a cabochon spessartite garnet.',
    specifications: {
      'Movement': 'Manual wind Calibre 1731 PS IRM with power reserve',
      'Case': '18k Yellow Gold, 44mm diameter'
    },
    provenance: {
      origin: 'Geneva, Switzerland',
      year: '2024',
      certificate: 'Patek Philippe Archives Certificate',
      authenticityGuarantee: 'Vault Sealed'
    },
    availability: 'limited',
    limitedEditionNumber: 'Unique 1/1',
    featuredInSingaporeEdit: true,
    tags: ['Patek Philippe', 'Pocket Watch', 'Enamel Art'],
    isDemonstrationData: true
  }
];
