import { EditorialArticle } from '../types';

export const EDITORIAL_ARTICLES: EditorialArticle[] = [
  {
    id: 'ed-01',
    slug: 'singapore-after-dark',
    title: 'SINGAPORE AFTER DARK',
    categoryTag: 'NIGHTLIFE & SALONS',
    subtitle: 'Inside Marina Bay’s Most Exclusive Private Members’ Vaults',
    excerpt: 'When the tropical sun sets behind the glass skyscrapers of Marina Bay, Singapore’s most private collectors assemble in quiet subterranean salons and high-altitude penthouses.',
    author: 'Alistair Tan',
    readTime: '6 min read',
    publishedDate: 'September 2026',
    heroImage: 'https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?q=80&w=1600&auto=format&fit=crop',
    secondaryImages: [
      'https://images.unsplash.com/photo-1547996160-01ff2474867f?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1509042239860-f550ce710b93?q=80&w=1200&auto=format&fit=crop'
    ],
    contentParagraphs: [
      'Singapore after dusk possesses an ethereal tranquility. High above the illuminated Gardens by the Bay, private entertaining has evolved from ostentatious displays into refined, intimate gatherings centered around rare vintages and haute horlogerie.',
      'In private suites overlooking the Straits of Singapore, time operates at a different tempo. Master watchmakers fly in directly from Geneva to present piece-unique minute repeaters to collectors who prefer handshakes over contract signings.',
      'The Singapore Privé salon at Marina Bay Sands remains the epicenter of these confidential encounters, where champagne from 1996 meets 18k yellow gold timepieces crafted for generations to come.'
    ],
    featuredProductsSlugs: [
      'rolex-submariner-date-126618lb',
      'patek-philippe-nautilus-5711-1r',
      'macallan-77-year-old-the-reach-single-malt'
    ]
  },
  {
    id: 'ed-02',
    slug: 'the-art-of-the-penthouse',
    title: 'THE ART OF THE PENTHOUSE',
    categoryTag: 'ARCHITECTURAL RESIDENCES',
    subtitle: 'Curating Museum-Grade Masterpieces 60 Stories Above Wallich Street',
    excerpt: 'Architectural serenity meets high-value fine art in Singapore’s tallest residential sky villas.',
    author: 'Elena Vance',
    readTime: '8 min read',
    publishedDate: 'August 2026',
    heroImage: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?q=80&w=1600&auto=format&fit=crop',
    secondaryImages: [
      'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1538688525198-9b88f6f53126?q=80&w=1200&auto=format&fit=crop'
    ],
    contentParagraphs: [
      'To inhabit a penthouse in Singapore is to live within a canvas of blue ocean and glass monoliths. Natural light is both a design luxury and an environmental factor that requires specializedUV filtration for blue-chip canvas art.',
      'Top interior architects in the city-state are eschewing traditional heavy furniture in favor of fluid acrylics, travertine marble monoliths, and bespoke sculptural pieces that echo the surrounding maritime architecture.',
      'When displaying works by Gerhard Richter or Yayoi Kusama at high elevations, climate stability and museum lighting become seamlessly integrated into smart home automation.'
    ],
    featuredProductsSlugs: [
      'gerhard-richter-abstraktes-bild-2018',
      'zaha-hadid-design-liquid-glacial-dining-table',
      'steinway-sons-spirio-r-custom-ebony'
    ]
  },
  {
    id: 'ed-03',
    slug: 'the-watch-collector',
    title: 'THE WATCH COLLECTOR',
    categoryTag: 'HAUTE HORLOGERIE',
    subtitle: 'Why Singapore Has Become the Global Capital of Independent Watchmaking',
    excerpt: 'How a passionate community of Singaporean connoisseurs transformed the Lion City into the most sophisticated watch market in the world.',
    author: 'Marcus Chen',
    readTime: '7 min read',
    publishedDate: 'September 2026',
    heroImage: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?q=80&w=1600&auto=format&fit=crop',
    secondaryImages: [
      'https://images.unsplash.com/photo-1523275335684-37898b6baf30?q=80&w=1200&auto=format&fit=crop'
    ],
    contentParagraphs: [
      'For decades, Geneva was considered the sole heartbeat of high watchmaking. Today, the world’s most discerning independent watchmakers—from F.P. Journe to MB&F and De Bethune—regularly debut their most ambitious creations in Singapore.',
      'Singaporean collectors possess an unmatched technical literacy. They do not merely collect brands; they understand escapement geometry, anglage beveling, and thermal blued titanium processes with academic precision.',
      'Singapore Privé maintains a confidential inventory of independent masterworks reserved strictly for local horological patrons.'
    ],
    featuredProductsSlugs: [
      'audemars-piguet-royal-oak-double-balance-skeleton',
      'f-p-journe-chronometre-bleu',
      'richard-mille-rm-67-02-singapore-edition'
    ]
  },
  {
    id: 'ed-04',
    slug: 'modern-asian-design',
    title: 'MODERN ASIAN DESIGN',
    categoryTag: 'CULTURE & CRAFT',
    subtitle: 'The Fusion of Imperial Craft Traditions and 2030s Minimalism',
    excerpt: 'Exploring Maki-e Japanese lacquerware, silk embroidery, and contemporary jade in high-end living spaces.',
    author: 'Mei-Ling Zhou',
    readTime: '5 min read',
    publishedDate: 'July 2026',
    heroImage: 'https://images.unsplash.com/photo-1583485088034-697b5bc54ccd?q=80&w=1600&auto=format&fit=crop',
    secondaryImages: [
      'https://images.unsplash.com/photo-1509042239860-f550ce710b93?q=80&w=1200&auto=format&fit=crop'
    ],
    contentParagraphs: [
      'Modern Asian luxury is defined by patience. A single Maki-e lacquer fountain pen or cloisonné enamel clock can take up to two years of solitary craftsmanship by an imperial artisan.',
      'By pairing ancient Asian artisan techniques with contemporary European minimalism, Singapore Privé curates pieces that honor heritage while remaining visually contemporary.',
      'In a world of fast digital consumerism, tactile objects imbued with decades of human dedication are the ultimate luxury.'
    ],
    featuredProductsSlugs: [
      'namiki-emperor-dragon-maki-e-fountain-pen',
      'patek-philippe-dome-table-clock-maki-e-orchid',
      'patek-philippe-rare-handcrafts-pocket-watch-tiger'
    ]
  },
  {
    id: 'ed-05',
    slug: 'the-new-singapore',
    title: 'THE NEW SINGAPORE',
    categoryTag: 'CITY & FUTURE',
    subtitle: 'Where Tropical Nature Meets Ultra-Secure Private Wealth Management',
    excerpt: 'Singapore’s unique urban philosophy: vertical biophilic gardens, zero-crime infrastructure, and world-leading family office institutions.',
    author: 'Jonathan Sterling',
    readTime: '6 min read',
    publishedDate: 'September 2026',
    heroImage: 'https://images.unsplash.com/photo-1525625293386-3f8f99389edd?q=80&w=1600&auto=format&fit=crop',
    secondaryImages: [
      'https://images.unsplash.com/photo-1566150905458-1bf1fc113f0d?q=80&w=1200&auto=format&fit=crop'
    ],
    contentParagraphs: [
      'Singapore stands as the world’s premier city-state for exceptional living. With its lush botanical canopy intertwined with ultra-modern glass towers, the city offers a sanctuary of safety and sophistication.',
      'Family offices from Zurich, London, New York, and Tokyo have established their global headquarters in Singapore, drawn by transparent rule of law and world-class private banking.',
      'Singapore Privé serves as the digital private salon for this discerning international community.'
    ],
    featuredProductsSlugs: [
      'hermes-birkin-25-faubourg-day-edition',
      'cartier-panthere-high-jewellery-diamond-necklace'
    ]
  },
  {
    id: 'ed-06',
    slug: 'private-islands',
    title: 'PRIVATE ISLANDS',
    categoryTag: 'YACHTING & HAVENS',
    subtitle: 'Sailing From Marina at Keppel Bay to Bintan’s Exclusive Private Atolls',
    excerpt: 'Exploring the archipelago of untouched sanctuaries just a 30-minute private yacht charter from Singapore harbour.',
    author: 'Captain Arthur Vance',
    readTime: '8 min read',
    publishedDate: 'June 2026',
    heroImage: 'https://images.unsplash.com/photo-1540555700478-4be289fbecef?q=80&w=1600&auto=format&fit=crop',
    secondaryImages: [
      'https://images.unsplash.com/photo-1507679799987-c73779587ccf?q=80&w=1200&auto=format&fit=crop'
    ],
    contentParagraphs: [
      'For Singapore’s yacht owners, weekend escapes do not involve long flights. Within minutes of stepping aboard a custom 40-metre motor yacht at Keppel Bay, one enters pristine coral waters.',
      'High fashion on the high seas demands breathable vicuña linen, water-resistant tourbillons, and bespoke leather travel trunks engineered for maritime conditions.',
      'Singapore Privé offers white-glove hand delivery directly to private yachts moored anywhere in the Singapore Straits.'
    ],
    featuredProductsSlugs: [
      'vacheron-constantin-overseas-tourbillon-pink-gold',
      'loro-piana-vicuna-double-cashmere-overcoat',
      'louis-vuitton-courrier-lozine-110-trunk'
    ]
  },
  {
    id: 'ed-07',
    slug: 'the-business-of-beauty',
    title: 'THE BUSINESS OF BEAUTY',
    categoryTag: 'HAUTE JOAILLERIE',
    subtitle: 'Investing in Rare Fancy Colored Diamonds and Unheated Burmese Rubies',
    excerpt: 'Gemstone investment analysis: Why fancy vivid pink and yellow diamonds continue to outperform traditional asset classes.',
    author: 'Dr. Sophia Kuan',
    readTime: '9 min read',
    publishedDate: 'August 2026',
    heroImage: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?q=80&w=1600&auto=format&fit=crop',
    secondaryImages: [
      'https://images.unsplash.com/photo-1605100804763-247f67b3557e?q=80&w=1200&auto=format&fit=crop'
    ],
    contentParagraphs: [
      'As central banks expand liquidity, tangible assets of extreme rarity have solidified their status as premier wealth storage vehicles.',
      'Natural fancy colored diamonds, particularly Argyle pinks and intense yellow cushions, represent an irreplaceable natural finite supply. Every stone is certified by GIA and Gübelin before joining the Singapore Privé Vault collection.',
      'High jewellery is no longer viewed solely as ornamental; it is a portable, tangible piece of human art history.'
    ],
    featuredProductsSlugs: [
      'van-cleef-arpels-mystery-set-ruby-peony-ring',
      'graff-fancy-vivid-yellow-diamond-earrings',
      'david-morris-pink-diamond-eternity-band'
    ]
  },
  {
    id: 'ed-08',
    slug: 'the-collectors-room',
    title: 'THE COLLECTOR’S ROOM',
    categoryTag: 'PRIVATE VAULTS',
    subtitle: 'Behind Closed Doors: Building an Heirloom Legacy Collection',
    excerpt: 'Practical advice from senior private wealth advisors on insurance, humidity control, and provenance verification.',
    author: 'Bernard Rochat',
    readTime: '6 min read',
    publishedDate: 'September 2026',
    heroImage: 'https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?q=80&w=1600&auto=format&fit=crop',
    secondaryImages: [
      'https://images.unsplash.com/photo-1527281400683-1aae777175f8?q=80&w=1200&auto=format&fit=crop'
    ],
    contentParagraphs: [
      'Building an heirloom collection requires a clear philosophy. Whether focusing on vintage Patek Philippe references, 1982 Bordeaux first growths, or rare bronze sculptures, disciplined documentation is essential.',
      'Singapore Privé provides every client with immutable digital provenance certificates and physical vault storage documentation.',
      'True wealth is measured not by quantity, but by the story and integrity of each exceptional piece.'
    ],
    featuredProductsSlugs: [
      'chateau-lafite-rothschild-1982-imperiale-6l',
      'patek-philippe-nautilus-5711-1r',
      'yayoi-kusama-bronze-pumpkin-sculpture-2022'
    ]
  }
];
