import React from 'react';
import { useStore } from '../lib/store';
import { ProductCard } from '../components/product/ProductCard';
import { Heart, ArrowRight } from 'lucide-react';

interface WishlistPageProps {
  onNavigate: (path: string) => void;
}

export const WishlistPage: React.FC<WishlistPageProps> = ({ onNavigate }) => {
  const { wishlistIds } = useStore();
  const { PRODUCTS_DATA } = require('../data/products');

  const savedProducts = PRODUCTS_DATA.filter((p: any) => wishlistIds.includes(p.id));

  return (
    <div className="bg-[#11100E] text-[#F5F1E8] pt-32 pb-24 min-h-screen">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        {/* HEADER */}
        <div className="text-center max-w-2xl mx-auto space-y-4 mb-16">
          <div className="flex items-center justify-center gap-2 text-[#C8B28A]">
            <Heart className="w-5 h-5 fill-current" />
            <span className="text-[10px] uppercase tracking-[0.35em] font-medium">
              SAVED ACQUISITIONS
            </span>
          </div>
          <h1 className="font-serif-luxury text-4xl md:text-5xl text-[#FAF8F3]">
            YOUR PRIVATE WISHLIST
          </h1>
          <p className="text-xs text-[#B7B0A3] font-light">
            Pieces you have selected for confidential consideration or future salon viewing.
          </p>
        </div>

        {savedProducts.length === 0 ? (
          <div className="bg-[#181613] border border-[#C8B28A]/20 p-16 text-center space-y-4 max-w-xl mx-auto">
            <Heart className="w-12 h-12 text-[#C8B28A]/40 mx-auto" />
            <h3 className="font-serif-luxury text-2xl text-[#FAF8F3]">
              Your wishlist is currently empty.
            </h3>
            <p className="text-xs text-[#B7B0A3]">
              Click the heart icon on any haute horlogerie or fine jewellery creation to save it to your private portfolio.
            </p>
            <button
              onClick={() => onNavigate('/shop')}
              className="mt-4 bg-[#C8B28A] text-[#11100E] px-8 py-3.5 text-xs uppercase tracking-[0.25em] font-medium hover:bg-[#A78B5A] transition-colors inline-flex items-center gap-2"
            >
              EXPLORE COLLECTIONS
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {savedProducts.map((product: any) => (
              <ProductCard key={product.id} product={product} onNavigate={onNavigate} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
