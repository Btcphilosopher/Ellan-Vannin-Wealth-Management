import React, { useState } from 'react';
import { useStore } from '../lib/store';
import { formatPrice } from '../lib/currency';
import { ProductCard } from '../components/product/ProductCard';
import { PRODUCTS_DATA } from '../data/products';
import { OrderRecord, AppointmentRecord, Product } from '../types';
import { Package } from 'lucide-react';

interface AccountPageProps {
  onNavigate: (path: string) => void;
}

export const AccountPage: React.FC<AccountPageProps> = ({ onNavigate }) => {
  const { user, wishlistIds, currency, openConsultation } = useStore();

  const [activeTab, setActiveTab] = useState<'acquisitions' | 'appointments' | 'wishlist' | 'profile'>('acquisitions');

  const savedProducts = PRODUCTS_DATA.filter((p) => wishlistIds.includes(p.id));

  return (
    <div className="bg-[#11100E] text-[#F5F1E8] pt-32 pb-24 min-h-screen">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        {/* MEMBER HEADER CARD */}
        <div className="bg-[#181613] border border-[#C8B28A]/30 p-8 md:p-10 mb-12 flex flex-col md:flex-row items-center justify-between gap-6 shadow-2xl">
          <div className="flex items-center gap-6">
            <div className="w-20 h-20 bg-[#11100E] border-2 border-[#C8B28A] rounded-full flex items-center justify-center text-[#C8B28A] font-serif-luxury text-2xl font-bold">
              {user.name.split(' ').map((n: string) => n[0]).join('')}
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="text-[10px] uppercase tracking-[0.3em] bg-[#C8B28A] text-[#11100E] px-2.5 py-0.5 font-bold">
                  {user.membershipStatus}
                </span>
                <span className="text-[10px] uppercase tracking-[0.2em] text-[#B7B0A3]">
                  MEMBER NO. {user.tierNumber}
                </span>
              </div>
              <h1 className="font-serif-luxury text-3xl text-[#FAF8F3]">
                {user.name}
              </h1>
              <p className="text-xs text-[#B7B0A3]">
                Dedicated Client Director: <span className="text-[#C8B28A] font-medium">Mr. Henry Laurent</span>
              </p>
            </div>
          </div>

          <button
            onClick={() => openConsultation(null)}
            className="bg-[#C8B28A] text-[#11100E] px-6 py-3 text-xs uppercase tracking-[0.2em] font-medium hover:bg-[#A78B5A] transition-colors"
          >
            CONTACT CLIENT DIRECTOR
          </button>
        </div>

        {/* DASHBOARD TABS */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 border-b border-[#C8B28A]/20 pb-6 mb-12">
          <button
            onClick={() => setActiveTab('acquisitions')}
            className={`py-3 text-xs uppercase tracking-[0.2em] transition-all border ${
              activeTab === 'acquisitions'
                ? 'border-[#C8B28A] bg-[#C8B28A] text-[#11100E] font-medium'
                : 'border-[#C8B28A]/20 text-[#B7B0A3] hover:text-[#FAF8F3]'
            }`}
          >
            MY ACQUISITIONS ({user.orders.length})
          </button>

          <button
            onClick={() => setActiveTab('appointments')}
            className={`py-3 text-xs uppercase tracking-[0.2em] transition-all border ${
              activeTab === 'appointments'
                ? 'border-[#C8B28A] bg-[#C8B28A] text-[#11100E] font-medium'
                : 'border-[#C8B28A]/20 text-[#B7B0A3] hover:text-[#FAF8F3]'
            }`}
          >
            SALON APPOINTMENTS ({user.appointments.length})
          </button>

          <button
            onClick={() => setActiveTab('wishlist')}
            className={`py-3 text-xs uppercase tracking-[0.2em] transition-all border ${
              activeTab === 'wishlist'
                ? 'border-[#C8B28A] bg-[#C8B28A] text-[#11100E] font-medium'
                : 'border-[#C8B28A]/20 text-[#B7B0A3] hover:text-[#FAF8F3]'
            }`}
          >
            SAVED WISHLIST ({wishlistIds.length})
          </button>

          <button
            onClick={() => setActiveTab('profile')}
            className={`py-3 text-xs uppercase tracking-[0.2em] transition-all border ${
              activeTab === 'profile'
                ? 'border-[#C8B28A] bg-[#C8B28A] text-[#11100E] font-medium'
                : 'border-[#C8B28A]/20 text-[#B7B0A3] hover:text-[#FAF8F3]'
            }`}
          >
            PERSONAL PROFILE
          </button>
        </div>

        {/* TAB CONTENTS */}
        {activeTab === 'acquisitions' && (
          <div className="space-y-6">
            <h2 className="font-serif-luxury text-2xl text-[#FAF8F3]">
              ACQUISITION HISTORY & VAULT RECORD
            </h2>

            {user.orders.map((order: OrderRecord) => (
              <div key={order.id} className="bg-[#181613] p-6 border border-[#C8B28A]/20 space-y-4 text-xs">
                <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-[#C8B28A]/15 pb-4 gap-2">
                  <div>
                    <span className="text-[10px] uppercase tracking-[0.2em] text-[#C8B28A] block">
                      REFERENCE: {order.id}
                    </span>
                    <span className="text-[#B7B0A3]">{order.date}</span>
                  </div>

                  <div className="flex items-center gap-4">
                    <span className="font-mono text-sm text-[#FAF8F3] font-medium">
                      {order.totalFormatted}
                    </span>
                    <span className="bg-[#11100E] text-[#C8B28A] px-3 py-1 border border-[#C8B28A]/30 uppercase text-[10px] tracking-[0.2em]">
                      {order.status}
                    </span>
                  </div>
                </div>

                <div className="space-y-3">
                  {order.items.map((item, idx: number) => (
                    <div key={idx} className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Package className="w-4 h-4 text-[#C8B28A]" />
                        <span className="font-serif-luxury text-sm text-[#FAF8F3]">
                          {item.brand} — {item.productName}
                        </span>
                      </div>
                      <span className="font-mono text-[#C8B28A]">
                        {item.priceFormatted}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'appointments' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="font-serif-luxury text-2xl text-[#FAF8F3]">
                CONFIDENTIAL SALON VIEWINGS
              </h2>
              <button
                onClick={() => openConsultation(null)}
                className="bg-[#C8B28A] text-[#11100E] px-4 py-2 text-xs uppercase tracking-[0.2em]"
              >
                + SCHEDULE NEW VIEWING
              </button>
            </div>

            {user.appointments.map((app: AppointmentRecord) => (
              <div key={app.id} className="bg-[#181613] p-6 border border-[#C8B28A]/20 space-y-3 text-xs">
                <div className="flex items-center justify-between border-b border-[#C8B28A]/15 pb-3">
                  <span className="font-serif-luxury text-lg text-[#FAF8F3]">
                    {app.serviceType}
                  </span>
                  <span className="text-[#C8B28A] uppercase tracking-[0.2em] text-[10px]">
                    {app.status}
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-[#B7B0A3]">
                  <div>
                    <span className="block text-[10px] uppercase text-[#C8B28A]">DATE & TIME</span>
                    <span className="text-[#FAF8F3]">{app.date} @ {app.time}</span>
                  </div>
                  <div className="md:col-span-2">
                    <span className="block text-[10px] uppercase text-[#C8B28A]">LOCATION</span>
                    <span className="text-[#FAF8F3]">{app.location}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'wishlist' && (
          <div className="space-y-6">
            <h2 className="font-serif-luxury text-2xl text-[#FAF8F3]">
              SAVED WISHLIST PORTFOLIO
            </h2>
            {savedProducts.length === 0 ? (
              <p className="text-xs text-[#B7B0A3]">No saved pieces in your portfolio.</p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {savedProducts.map((p: Product) => (
                  <ProductCard key={p.id} product={p} onNavigate={onNavigate} />
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'profile' && (
          <div className="bg-[#181613] p-8 border border-[#C8B28A]/30 space-y-6 text-xs max-w-2xl">
            <h2 className="font-serif-luxury text-2xl text-[#FAF8F3]">
              CONFIDENTIAL CLIENT DOSSIER
            </h2>

            <div className="space-y-4 text-[#B7B0A3]">
              <div className="flex justify-between py-2 border-b border-[#C8B28A]/10">
                <span>FULL NAME</span>
                <span className="text-[#FAF8F3] font-medium">{user.name}</span>
              </div>
              <div className="flex justify-between py-2 border-b border-[#C8B28A]/10">
                <span>CONFIDENTIAL EMAIL</span>
                <span className="text-[#FAF8F3] font-medium">{user.email}</span>
              </div>
              <div className="flex justify-between py-2 border-b border-[#C8B28A]/10">
                <span>TELEPHONE / WHATSAPP</span>
                <span className="text-[#FAF8F3] font-medium">{user.phone}</span>
              </div>
              <div className="flex justify-between py-2 border-b border-[#C8B28A]/10">
                <span>MEMBER STATUS</span>
                <span className="text-[#C8B28A] font-medium">{user.membershipStatus}</span>
              </div>
              <div className="flex justify-between py-2 border-b border-[#C8B28A]/10">
                <span>REGISTERED RESIDENCE</span>
                <span className="text-[#FAF8F3] font-medium text-right">8 Marina Boulevard, Penthouse 62-01, Singapore 018981</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
