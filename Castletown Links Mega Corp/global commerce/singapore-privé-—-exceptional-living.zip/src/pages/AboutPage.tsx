import React from 'react';
import { useStore } from '../lib/store';
import { ShieldCheck, MapPin, Building, Award, Clock, ArrowRight } from 'lucide-react';

interface AboutPageProps {
  onNavigate: (path: string) => void;
}

export const AboutPage: React.FC<AboutPageProps> = ({ onNavigate }) => {
  const { openConsultation } = useStore();

  return (
    <div className="bg-[#11100E] text-[#F5F1E8] pt-32 pb-24 min-h-screen">
      <div className="max-w-7xl mx-auto px-6 md:px-12 space-y-24">
        {/* HERO SECTION */}
        <div className="text-center max-w-3xl mx-auto space-y-6">
          <span className="text-[10px] uppercase tracking-[0.35em] text-[#C8B28A] font-medium block">
            ABOUT SINGAPORE PRIVÉ
          </span>
          <h1 className="font-serif-luxury text-4xl md:text-6xl text-[#FAF8F3] leading-tight">
            A digital private salon for exceptional goods. Not simply an online store.
          </h1>
          <p className="text-xs md:text-sm text-[#B7B0A3] font-light leading-relaxed">
            Founded in Singapore to serve collectors across Southeast Asia and global high-net-worth individuals, Singapore Privé unites European haute horlogerie, Parisian fashion houses, and rare art advisories under one confidential roof.
          </p>
        </div>

        {/* MARINA BAY SALON PHOTOGRAPHY SPOTLIGHT */}
        <div className="relative aspect-[21/9] bg-[#181613] border border-[#C8B28A]/30 overflow-hidden shadow-2xl">
          <img
            src="https://images.unsplash.com/photo-1512917774080-9991f1c4c750?q=80&w=1600&auto=format&fit=crop"
            alt="Singapore Privé Marina Bay Salon"
            className="w-full h-full object-cover brightness-[0.7]"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#11100E] via-transparent to-transparent"></div>
          <div className="absolute bottom-8 left-8 right-8 p-6 bg-[#181613]/90 border border-[#C8B28A]/30 backdrop-blur-md max-w-lg space-y-2">
            <span className="text-[10px] uppercase tracking-[0.25em] text-[#C8B28A] font-medium">
              MARINA BAY SANDS FLAGSHIP
            </span>
            <h3 className="font-serif-luxury text-2xl text-[#FAF8F3]">
              The Level 1 Private Salon
            </h3>
            <p className="text-xs text-[#B7B0A3]">
              Overlooking the Marina Bay waterfront terrace, our private salon provides champagne-served confidential viewings and armored courier dispatches.
            </p>
          </div>
        </div>

        {/* CORE THREE PILLARS */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-[#181613] p-8 border border-[#C8B28A]/20 space-y-4">
            <ShieldCheck className="w-8 h-8 text-[#C8B28A]" />
            <h3 className="font-serif-luxury text-2xl text-[#FAF8F3]">
              Guaranteed Provenance
            </h3>
            <p className="text-xs text-[#B7B0A3] font-light leading-relaxed">
              Every timepiece, gem, and handbag is physically inspected at our Singapore Vault. Archives certificates from Patek Philippe, Rolex, and Hermès accompany every physical handover.
            </p>
          </div>

          <div className="bg-[#181613] p-8 border border-[#C8B28A]/20 space-y-4">
            <Building className="w-8 h-8 text-[#C8B28A]" />
            <h3 className="font-serif-luxury text-2xl text-[#FAF8F3]">
              Freeport Vault Holding
            </h3>
            <p className="text-xs text-[#B7B0A3] font-light leading-relaxed">
              Clients acquiring art, fine wine, or high jewellery may opt for climate-controlled tax-exempt storage inside the Singapore Freeport bonded vault at Changi Airport.
            </p>
          </div>

          <div className="bg-[#181613] p-8 border border-[#C8B28A]/20 space-y-4">
            <Award className="w-8 h-8 text-[#C8B28A]" />
            <h3 className="font-serif-luxury text-2xl text-[#FAF8F3]">
              White-Glove Courier
            </h3>
            <p className="text-xs text-[#B7B0A3] font-light leading-relaxed">
              Armored hand delivery for Singapore residences, Keppel Bay berths, or Nassim Hill estates, as well as insured global courier services for international clients.
            </p>
          </div>
        </div>

        {/* CALL TO ACTION */}
        <div className="bg-[#181613] p-12 border border-[#C8B28A]/30 text-center space-y-6 max-w-3xl mx-auto">
          <span className="text-[10px] uppercase tracking-[0.35em] text-[#C8B28A] font-medium">
            EXECUTIVE CONCIERGE
          </span>
          <h2 className="font-serif-luxury text-3xl md:text-4xl text-[#FAF8F3]">
            Experience Singapore Privé in Person
          </h2>
          <p className="text-xs text-[#B7B0A3] font-light leading-relaxed max-w-lg mx-auto">
            Schedule a private consultation at our Marina Bay Sands salon or request an armored courier presentation at your private residence.
          </p>

          <button
            onClick={() => openConsultation(null)}
            className="inline-flex items-center gap-2 bg-[#C8B28A] hover:bg-[#A78B5A] text-[#11100E] px-8 py-4 text-xs uppercase tracking-[0.25em] font-medium transition-colors"
          >
            REQUEST PRIVATE APPOINTMENT
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
