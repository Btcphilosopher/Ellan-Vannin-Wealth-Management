import React, { useState, useEffect } from 'react';
import { PRODUCTS_DATA } from '../data/products';
import { EDITORIAL_ARTICLES } from '../data/editorial';
import { ProductCard } from '../components/product/ProductCard';
import { useStore } from '../lib/store';
import { ArrowRight, Sparkles, MessageSquare, ShieldCheck, MapPin, Clock, ChevronDown } from 'lucide-react';

interface HomePageProps {
  onNavigate: (path: string) => void;
}

export const HomePage: React.FC<HomePageProps> = ({ onNavigate }) => {
  const { openConsultation } = useStore();
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const featuredProducts = PRODUCTS_DATA.filter((p) => p.featuredInSingaporeEdit).slice(0, 6);
  const featuredEditorials = EDITORIAL_ARTICLES.slice(0, 3);

  return (
    <div className="bg-[#11100E] text-[#F5F1E8] overflow-hidden">
      {/* ---------------------------------------------------- */}
      {/* 5. HERO SECTION */}
      {/* ---------------------------------------------------- */}
      <section className="relative h-screen min-h-[700px] w-full flex items-center justify-center overflow-hidden">
        {/* CINEMATIC PARALLAX BACKGROUND IMAGE */}
        <div
          className="absolute inset-0 w-full h-full scale-110 transition-transform duration-100 ease-out pointer-events-none"
          style={{
            transform: `translateY(${scrollY * 0.25}px)`
          }}
        >
          {/* High resolution Marina Bay sunset terrace photography */}
          <img
            src="https://images.unsplash.com/photo-1525625293386-3f8f99389edd?q=80&w=2000&auto=format&fit=crop"
            alt="Singapore Marina Bay Sands Sunset Waterfront Luxury Terrace"
            className="w-full h-full object-cover object-center brightness-[0.75] contrast-[1.05]"
          />
          {/* Subtle Golden-Hour & Obsidian Dark Gradients */}
          <div className="absolute inset-0 bg-gradient-to-t from-[#11100E] via-[#11100E]/40 to-transparent"></div>
          <div className="absolute inset-0 bg-gradient-to-r from-[#11100E]/80 via-transparent to-[#11100E]/80"></div>
        </div>

        {/* HERO OVERLAY CONTENT */}
        <div className="relative z-10 max-w-5xl mx-auto px-6 text-center space-y-8 pt-20">
          {/* SMALL UPPERCASE LABEL */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-[#11100E]/80 border border-[#C8B28A]/40 backdrop-blur-md animate-fade-in">
            <Sparkles className="w-3.5 h-3.5 text-[#C8B28A]" />
            <span className="text-[10px] sm:text-xs uppercase tracking-[0.35em] text-[#C8B28A] font-medium">
              RARE BRANDS. EXCEPTIONAL LIVING.
            </span>
          </div>

          {/* MAIN HEADING */}
          <h1 className="font-serif-luxury text-4xl sm:text-6xl md:text-7xl lg:text-8xl font-normal text-[#FAF8F3] tracking-wide leading-[1.05] drop-shadow-2xl">
            THE WORLD'S FINEST,
            <br />
            <span className="italic font-light text-[#C8B28A]">CURATED FOR SINGAPORE</span>
          </h1>

          {/* SUPPORTING COPY */}
          <p className="text-xs sm:text-sm md:text-base text-[#FAF8F3]/90 font-light max-w-2xl mx-auto leading-relaxed tracking-wide drop-shadow">
            Discover a handpicked collection of the world's most exclusive goods — from haute horlogerie and fine jewellery to bespoke fashion, art and rare collectibles.
          </p>

          {/* EXPLORE BUTTON */}
          <div className="pt-4">
            <button
              onClick={() => onNavigate('/shop')}
              className="inline-flex items-center gap-3 bg-[#C8B28A] hover:bg-[#A78B5A] text-[#11100E] px-10 py-4 text-xs uppercase tracking-[0.3em] font-medium transition-all duration-300 shadow-2xl hover:scale-105 group"
            >
              EXPLORE COLLECTION
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
            </button>
          </div>
        </div>

        {/* SCROLL INDICATOR */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 text-center animate-bounce">
          <span className="text-[9px] uppercase tracking-[0.3em] text-[#C8B28A] block mb-1">
            SCROLL TO DISCOVER
          </span>
          <ChevronDown className="w-4 h-4 text-[#C8B28A] mx-auto" />
        </div>
      </section>

      {/* ---------------------------------------------------- */}
      {/* 6. CATEGORY GRID */}
      {/* ---------------------------------------------------- */}
      <section className="max-w-7xl mx-auto px-6 md:px-12 py-24 border-b border-[#C8B28A]/15">
        <div className="text-center max-w-xl mx-auto mb-16 space-y-2">
          <span className="text-[10px] uppercase tracking-[0.35em] text-[#C8B28A] font-medium">
            FOUR PILLARS OF LUXURY
          </span>
          <h2 className="font-serif-luxury text-3xl md:text-4xl text-[#FAF8F3]">
            Curated Categories
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* WATCHES */}
          <div
            onClick={() => onNavigate('/shop/watches')}
            className="group relative aspect-[3/4] bg-[#181613] border border-[#C8B28A]/20 overflow-hidden cursor-pointer shadow-2xl"
          >
            <img
              src="https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?q=80&w=1000&auto=format&fit=crop"
              alt="Luxury Mechanical Watch"
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ease-out brightness-[0.85]"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#11100E] via-[#11100E]/30 to-transparent"></div>
            <div className="absolute inset-0 p-8 flex flex-col justify-end text-left space-y-2">
              <span className="text-[9px] uppercase tracking-[0.3em] text-[#C8B28A]">
                TIMELESS EXCELLENCE
              </span>
              <h3 className="font-serif-luxury text-2xl text-[#FAF8F3] group-hover:text-[#C8B28A] transition-colors">
                WATCHES
              </h3>
              <div className="pt-2 flex items-center gap-2 text-[10px] uppercase tracking-[0.25em] text-[#FAF8F3] group-hover:translate-x-1 transition-transform">
                <span>EXPLORE</span>
                <ArrowRight className="w-3.5 h-3.5 text-[#C8B28A]" />
              </div>
            </div>
          </div>

          {/* FASHION */}
          <div
            onClick={() => onNavigate('/shop/fashion')}
            className="group relative aspect-[3/4] bg-[#181613] border border-[#C8B28A]/20 overflow-hidden cursor-pointer shadow-2xl"
          >
            <img
              src="https://images.unsplash.com/photo-1584917865442-de89df76afd3?q=80&w=1000&auto=format&fit=crop"
              alt="Exceptional Leather Handbag in Penthouse"
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ease-out brightness-[0.85]"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#11100E] via-[#11100E]/30 to-transparent"></div>
            <div className="absolute inset-0 p-8 flex flex-col justify-end text-left space-y-2">
              <span className="text-[9px] uppercase tracking-[0.3em] text-[#C8B28A]">
                ICONIC BRANDS
              </span>
              <h3 className="font-serif-luxury text-2xl text-[#FAF8F3] group-hover:text-[#C8B28A] transition-colors">
                FASHION
              </h3>
              <div className="pt-2 flex items-center gap-2 text-[10px] uppercase tracking-[0.25em] text-[#FAF8F3] group-hover:translate-x-1 transition-transform">
                <span>EXPLORE</span>
                <ArrowRight className="w-3.5 h-3.5 text-[#C8B28A]" />
              </div>
            </div>
          </div>

          {/* JEWELLERY */}
          <div
            onClick={() => onNavigate('/shop/jewellery')}
            className="group relative aspect-[3/4] bg-[#181613] border border-[#C8B28A]/20 overflow-hidden cursor-pointer shadow-2xl"
          >
            <img
              src="https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?q=80&w=1000&auto=format&fit=crop"
              alt="Diamond Necklace on Velvet"
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ease-out brightness-[0.85]"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#11100E] via-[#11100E]/30 to-transparent"></div>
            <div className="absolute inset-0 p-8 flex flex-col justify-end text-left space-y-2">
              <span className="text-[9px] uppercase tracking-[0.3em] text-[#C8B28A]">
                LASTING BEAUTY
              </span>
              <h3 className="font-serif-luxury text-2xl text-[#FAF8F3] group-hover:text-[#C8B28A] transition-colors">
                JEWELLERY
              </h3>
              <div className="pt-2 flex items-center gap-2 text-[10px] uppercase tracking-[0.25em] text-[#FAF8F3] group-hover:translate-x-1 transition-transform">
                <span>EXPLORE</span>
                <ArrowRight className="w-3.5 h-3.5 text-[#C8B28A]" />
              </div>
            </div>
          </div>

          {/* ART & COLLECTIBLES */}
          <div
            onClick={() => onNavigate('/shop/art')}
            className="group relative aspect-[3/4] bg-[#181613] border border-[#C8B28A]/20 overflow-hidden cursor-pointer shadow-2xl"
          >
            <img
              src="https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?q=80&w=1000&auto=format&fit=crop"
              alt="Contemporary Artwork in Private Residence"
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ease-out brightness-[0.85]"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#11100E] via-[#11100E]/30 to-transparent"></div>
            <div className="absolute inset-0 p-8 flex flex-col justify-end text-left space-y-2">
              <span className="text-[9px] uppercase tracking-[0.3em] text-[#C8B28A]">
                EXTRAORDINARY PIECES
              </span>
              <h3 className="font-serif-luxury text-2xl text-[#FAF8F3] group-hover:text-[#C8B28A] transition-colors">
                ART & COLLECTIBLES
              </h3>
              <div className="pt-2 flex items-center gap-2 text-[10px] uppercase tracking-[0.25em] text-[#FAF8F3] group-hover:translate-x-1 transition-transform">
                <span>EXPLORE</span>
                <ArrowRight className="w-3.5 h-3.5 text-[#C8B28A]" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ---------------------------------------------------- */}
      {/* 7. FEATURED COLLECTION: THE SINGAPORE EDIT */}
      {/* ---------------------------------------------------- */}
      <section className="max-w-7xl mx-auto px-6 md:px-12 py-24 border-b border-[#C8B28A]/15">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div className="space-y-2">
            <span className="text-[10px] uppercase tracking-[0.35em] text-[#C8B28A] font-medium">
              CURATED FOR THE CITY
            </span>
            <h2 className="font-serif-luxury text-3xl md:text-5xl text-[#FAF8F3]">
              THE SINGAPORE EDIT
            </h2>
          </div>

          <button
            onClick={() => onNavigate('/shop')}
            className="text-xs uppercase tracking-[0.25em] text-[#C8B28A] hover:text-[#FAF8F3] flex items-center gap-2 group self-start md:self-auto"
          >
            VIEW ALL ACQUISITIONS
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        {/* 6 PRODUCTS GRID */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {featuredProducts.map((product) => (
            <ProductCard key={product.id} product={product} onNavigate={onNavigate} />
          ))}
        </div>
      </section>

      {/* ---------------------------------------------------- */}
      {/* 9. PRIVATE CLIENT SERVICES SECTION */}
      {/* ---------------------------------------------------- */}
      <section className="bg-[#181613] py-24 border-b border-[#C8B28A]/20 relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            <div className="lg:col-span-7 space-y-6">
              <span className="text-[10px] uppercase tracking-[0.35em] text-[#C8B28A] font-medium">
                PRIVATE CLIENT SERVICES
              </span>
              <h2 className="font-serif-luxury text-4xl md:text-5xl text-[#FAF8F3] font-normal leading-tight">
                "Some acquisitions deserve a conversation."
              </h2>
              <p className="text-sm text-[#B7B0A3] font-light leading-relaxed max-w-xl">
                Our Singapore private client advisors provide direct access to off-market haute horlogerie, unheated gemstones, bespoke leather commissions, and museum art acquisitions.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4">
                <button
                  onClick={() => openConsultation(null)}
                  className="bg-[#C8B28A] hover:bg-[#A78B5A] text-[#11100E] p-4 text-xs uppercase tracking-[0.2em] font-medium transition-colors text-left flex items-center justify-between group"
                >
                  <span>REQUEST A PRIVATE APPOINTMENT</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>

                <button
                  onClick={() => openConsultation(null)}
                  className="bg-[#11100E] border border-[#C8B28A]/30 hover:border-[#C8B28A] text-[#FAF8F3] p-4 text-xs uppercase tracking-[0.2em] font-medium transition-colors text-left flex items-center justify-between group"
                >
                  <span>SPEAK WITH A CLIENT ADVISOR</span>
                  <MessageSquare className="w-4 h-4 text-[#C8B28A]" />
                </button>

                <button
                  onClick={() => openConsultation(null)}
                  className="bg-[#11100E] border border-[#C8B28A]/30 hover:border-[#C8B28A] text-[#FAF8F3] p-4 text-xs uppercase tracking-[0.2em] font-medium transition-colors text-left flex items-center justify-between group"
                >
                  <span>REQUEST A PRIVATE VIEWING</span>
                  <MapPin className="w-4 h-4 text-[#C8B28A]" />
                </button>

                <button
                  onClick={() => openConsultation(null)}
                  className="bg-[#11100E] border border-[#C8B28A]/30 hover:border-[#C8B28A] text-[#FAF8F3] p-4 text-xs uppercase tracking-[0.2em] font-medium transition-colors text-left flex items-center justify-between group"
                >
                  <span>ENQUIRE ABOUT A RARE PIECE</span>
                  <Sparkles className="w-4 h-4 text-[#C8B28A]" />
                </button>
              </div>
            </div>

            <div className="lg:col-span-5 relative">
              <div className="aspect-[4/5] bg-[#11100E] border border-[#C8B28A]/30 relative overflow-hidden shadow-2xl">
                <img
                  src="https://images.unsplash.com/photo-1512917774080-9991f1c4c750?q=80&w=1200&auto=format&fit=crop"
                  alt="Singapore Privé Marina Bay Sands Salon"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#11100E] via-transparent to-transparent"></div>
                <div className="absolute bottom-6 left-6 right-6 p-4 bg-[#181613]/90 border border-[#C8B28A]/30 backdrop-blur-md text-xs space-y-1">
                  <span className="text-[#C8B28A] font-medium uppercase tracking-[0.2em] block text-[10px]">
                    FLAGSHIP SALON
                  </span>
                  <p className="text-[#FAF8F3] font-serif-luxury text-sm">
                    The Shoppes at Marina Bay Sands
                  </p>
                  <p className="text-[#B7B0A3] text-[11px]">
                    Level 1 Private Salon • By Confidential Appointment
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ---------------------------------------------------- */}
      {/* 11. EDITORIAL MAGAZINE TEASER SECTION */}
      {/* ---------------------------------------------------- */}
      <section className="max-w-7xl mx-auto px-6 md:px-12 py-24">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div className="space-y-2">
            <span className="text-[10px] uppercase tracking-[0.35em] text-[#C8B28A] font-medium">
              LUXURY JOURNAL & ESSAYS
            </span>
            <h2 className="font-serif-luxury text-3xl md:text-5xl text-[#FAF8F3]">
              THE SINGAPORE EDIT
            </h2>
          </div>

          <button
            onClick={() => onNavigate('/singapore-edit')}
            className="text-xs uppercase tracking-[0.25em] text-[#C8B28A] hover:text-[#FAF8F3] flex items-center gap-2 group self-start md:self-auto"
          >
            READ MAGAZINE
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {featuredEditorials.map((article) => (
            <div
              key={article.id}
              onClick={() => onNavigate('/singapore-edit')}
              className="group cursor-pointer space-y-4"
            >
              <div className="aspect-[16/10] bg-[#181613] overflow-hidden border border-[#C8B28A]/20">
                <img
                  src={article.heroImage}
                  alt={article.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
              </div>
              <div className="space-y-2">
                <div className="flex items-center gap-3 text-[10px] uppercase tracking-[0.25em] text-[#C8B28A]">
                  <span>{article.categoryTag}</span>
                  <span>•</span>
                  <span>{article.readTime}</span>
                </div>
                <h3 className="font-serif-luxury text-2xl text-[#FAF8F3] group-hover:text-[#C8B28A] transition-colors leading-snug">
                  {article.title}
                </h3>
                <p className="text-xs text-[#B7B0A3] font-light line-clamp-2 leading-relaxed">
                  {article.subtitle}
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
