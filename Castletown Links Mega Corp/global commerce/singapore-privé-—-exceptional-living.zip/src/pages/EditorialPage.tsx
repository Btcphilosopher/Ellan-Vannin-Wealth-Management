import React, { useState } from 'react';
import { EDITORIAL_ARTICLES } from '../data/editorial';
import { PRODUCTS_DATA } from '../data/products';
import { EditorialArticle } from '../types';
import { ProductCard } from '../components/product/ProductCard';
import { Sparkles, ArrowRight } from 'lucide-react';

interface EditorialPageProps {
  onNavigate: (path: string) => void;
}

export const EditorialPage: React.FC<EditorialPageProps> = ({ onNavigate }) => {
  const [selectedArticle, setSelectedArticle] = useState<EditorialArticle | null>(null);

  if (selectedArticle) {
    const relatedProducts = PRODUCTS_DATA.filter((p) =>
      selectedArticle.featuredProductsSlugs.includes(p.slug)
    );

    return (
      <div className="bg-[#11100E] text-[#F5F1E8] pt-32 pb-24 min-h-screen">
        <div className="max-w-4xl mx-auto px-6">
          <button
            onClick={() => setSelectedArticle(null)}
            className="text-xs uppercase tracking-[0.25em] text-[#C8B28A] hover:underline mb-8 inline-block"
          >
            ← BACK TO MAGAZINE DIRECTORY
          </button>

          {/* ARTICLE HEADER */}
          <div className="space-y-4 mb-12 text-center">
            <span className="text-[10px] uppercase tracking-[0.35em] text-[#C8B28A] font-medium block">
              {selectedArticle.categoryTag} • {selectedArticle.readTime}
            </span>
            <h1 className="font-serif-luxury text-4xl md:text-6xl text-[#FAF8F3] leading-tight">
              {selectedArticle.title}
            </h1>
            <p className="text-sm md:text-base text-[#B7B0A3] font-light max-w-2xl mx-auto leading-relaxed italic">
              "{selectedArticle.subtitle}"
            </p>

            <div className="flex items-center justify-center gap-4 text-xs text-[#B7B0A3] pt-4 border-t border-[#C8B28A]/20">
              <span>By {selectedArticle.author}</span>
              <span>•</span>
              <span>{selectedArticle.publishedDate}</span>
            </div>
          </div>

          {/* ARTICLE HERO IMAGE */}
          <div className="aspect-[16/9] bg-[#181613] border border-[#C8B28A]/30 overflow-hidden mb-12 shadow-2xl">
            <img
              src={selectedArticle.heroImage}
              alt={selectedArticle.title}
              className="w-full h-full object-cover"
            />
          </div>

          {/* ARTICLE BODY */}
          <div className="prose prose-invert max-w-none text-sm leading-relaxed text-[#B7B0A3] font-light space-y-6">
            {selectedArticle.contentParagraphs.map((paragraph: string, idx: number) => (
              <p key={idx} className="first-letter:text-4xl first-letter:font-serif-luxury first-letter:text-[#C8B28A] first-letter:mr-1">
                {paragraph}
              </p>
            ))}
          </div>

          {/* INLINE EMBEDDED PRODUCTS */}
          {relatedProducts.length > 0 && (
            <div className="mt-16 pt-12 border-t border-[#C8B28A]/20 space-y-6">
              <span className="text-[10px] uppercase tracking-[0.3em] text-[#C8B28A] font-medium block">
                CURATED ACQUISITIONS FEATURED IN THIS ESSAY
              </span>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {relatedProducts.map((p) => (
                  <ProductCard key={p.id} product={p} onNavigate={onNavigate} />
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#11100E] text-[#F5F1E8] pt-32 pb-24 min-h-screen">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        {/* HEADER */}
        <div className="text-center max-w-2xl mx-auto space-y-4 mb-16">
          <span className="text-[10px] uppercase tracking-[0.35em] text-[#C8B28A] font-medium">
            SINGAPORE PRIVÉ JOURNAL
          </span>
          <h1 className="font-serif-luxury text-4xl md:text-6xl text-[#FAF8F3]">
            THE SINGAPORE EDIT
          </h1>
          <p className="text-xs text-[#B7B0A3] font-light leading-relaxed">
            Essays on high horology, contemporary architecture, fine wine, private island living, and the art of collecting in Southeast Asia.
          </p>
        </div>

        {/* HERO ARTICLE HIGHLIGHT */}
        {EDITORIAL_ARTICLES[0] && (
          <div
            onClick={() => setSelectedArticle(EDITORIAL_ARTICLES[0])}
            className="group grid grid-cols-1 lg:grid-cols-12 gap-8 bg-[#181613] border border-[#C8B28A]/30 p-6 md:p-10 cursor-pointer hover:border-[#C8B28A] transition-all duration-500 mb-20 shadow-2xl"
          >
            <div className="lg:col-span-7 aspect-[16/10] overflow-hidden bg-[#11100E] border border-[#C8B28A]/20">
              <img
                src={EDITORIAL_ARTICLES[0].heroImage}
                alt={EDITORIAL_ARTICLES[0].title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              />
            </div>

            <div className="lg:col-span-5 flex flex-col justify-between space-y-6">
              <div className="space-y-4">
                <div className="flex items-center gap-3 text-[10px] uppercase tracking-[0.25em] text-[#C8B28A]">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>COVER STORY</span>
                  <span>•</span>
                  <span>{EDITORIAL_ARTICLES[0].readTime}</span>
                </div>

                <h2 className="font-serif-luxury text-3xl md:text-4xl text-[#FAF8F3] group-hover:text-[#C8B28A] transition-colors leading-tight">
                  {EDITORIAL_ARTICLES[0].title}
                </h2>

                <p className="text-xs text-[#B7B0A3] font-light leading-relaxed">
                  {EDITORIAL_ARTICLES[0].subtitle}
                </p>
              </div>

              <div className="pt-4 border-t border-[#C8B28A]/15 flex items-center justify-between text-xs text-[#C8B28A]">
                <span>READ FULL JOURNAL ARTICLE</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-2 transition-transform" />
              </div>
            </div>
          </div>
        )}

        {/* ARTICLES GRID */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {EDITORIAL_ARTICLES.map((article) => (
            <div
              key={article.id}
              onClick={() => setSelectedArticle(article)}
              className="group bg-[#181613] border border-[#C8B28A]/20 hover:border-[#C8B28A] transition-all duration-500 cursor-pointer flex flex-col justify-between overflow-hidden shadow-xl"
            >
              <div className="aspect-[16/10] bg-[#11100E] overflow-hidden">
                <img
                  src={article.heroImage}
                  alt={article.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
              </div>

              <div className="p-6 space-y-4 flex-1 flex flex-col justify-between">
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-[10px] text-[#C8B28A] uppercase tracking-[0.2em]">
                    <span>{article.categoryTag}</span>
                    <span>{article.readTime}</span>
                  </div>

                  <h3 className="font-serif-luxury text-xl text-[#FAF8F3] group-hover:text-[#C8B28A] transition-colors leading-snug">
                    {article.title}
                  </h3>

                  <p className="text-xs text-[#B7B0A3] font-light line-clamp-2 leading-relaxed">
                    {article.subtitle}
                  </p>
                </div>

                <div className="pt-4 border-t border-[#C8B28A]/15 flex items-center justify-between text-xs text-[#C8B28A]">
                  <span className="text-[10px] uppercase tracking-[0.2em]">READ JOURNAL ARTICLE</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
