import React, { useState, useMemo } from 'react';
import { PRODUCTS_DATA } from '../data/products';
import { Category, Product, AvailabilityStatus } from '../types';
import { ProductCard } from '../components/product/ProductCard';
import { Filter, SlidersHorizontal, Grid3X3, Grid2X2, Sparkles, X } from 'lucide-react';

interface ShopPageProps {
  initialCategory?: Category | 'all';
  onNavigate: (path: string) => void;
}

export const ShopPage: React.FC<ShopPageProps> = ({ initialCategory = 'all', onNavigate }) => {
  const [selectedCategory, setSelectedCategory] = useState<Category | 'all'>(initialCategory);
  const [selectedBrand, setSelectedBrand] = useState<string>('all');
  const [selectedAvailability, setSelectedAvailability] = useState<AvailabilityStatus | 'all'>('all');
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'brand'>('featured');
  const [gridCols, setGridCols] = useState<3 | 4>(3);

  // Extract unique brands for filter
  const brands = useMemo(() => {
    const list = Array.from(new Set(PRODUCTS_DATA.map((p) => p.brand))).sort();
    return ['all', ...list];
  }, []);

  // Filter products
  const filteredProducts = useMemo(() => {
    let result = [...PRODUCTS_DATA];

    if (selectedCategory !== 'all') {
      result = result.filter((p) => p.category === selectedCategory);
    }

    if (selectedBrand !== 'all') {
      result = result.filter((p) => p.brand === selectedBrand);
    }

    if (selectedAvailability !== 'all') {
      result = result.filter((p) => p.availability === selectedAvailability);
    }

    // Sort
    if (sortBy === 'price-asc') {
      result.sort((a, b) => a.priceSGD - b.priceSGD);
    } else if (sortBy === 'price-desc') {
      result.sort((a, b) => b.priceSGD - a.priceSGD);
    } else if (sortBy === 'brand') {
      result.sort((a, b) => a.brand.localeCompare(b.brand));
    }

    return result;
  }, [selectedCategory, selectedBrand, selectedAvailability, sortBy]);

  const getCategoryTitle = () => {
    switch (selectedCategory) {
      case 'watches':
        return 'HAUTE HORLOGERIE';
      case 'fashion':
        return 'BESPOKE FASHION';
      case 'jewellery':
        return 'FINE JEWELLERY';
      case 'art':
        return 'ART & COLLECTIBLES';
      default:
        return 'ALL CURATED ACQUISITIONS';
    }
  };

  return (
    <div className="bg-[#11100E] text-[#F5F1E8] pt-32 pb-24 min-h-screen">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        {/* HEADER */}
        <div className="space-y-4 text-center max-w-2xl mx-auto mb-16">
          <span className="text-[10px] uppercase tracking-[0.35em] text-[#C8B28A] font-medium block">
            SINGAPORE PRIVÉ COLLECTION
          </span>
          <h1 className="font-serif-luxury text-4xl md:text-6xl text-[#FAF8F3]">
            {getCategoryTitle()}
          </h1>
          <p className="text-xs text-[#B7B0A3] font-light leading-relaxed">
            Every piece is inspected in our Singapore Vault and accompanied by lifetime provenance certificates and white-glove hand delivery.
          </p>
        </div>

        {/* CATEGORY TABS BAR */}
        <div className="flex flex-wrap items-center justify-center gap-3 border-b border-[#C8B28A]/20 pb-8 mb-12">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-6 py-2.5 text-xs uppercase tracking-[0.25em] transition-all border ${
              selectedCategory === 'all'
                ? 'border-[#C8B28A] bg-[#C8B28A] text-[#11100E] font-medium'
                : 'border-[#C8B28A]/20 text-[#B7B0A3] hover:text-[#FAF8F3]'
            }`}
          >
            ALL
          </button>
          <button
            onClick={() => setSelectedCategory('watches')}
            className={`px-6 py-2.5 text-xs uppercase tracking-[0.25em] transition-all border ${
              selectedCategory === 'watches'
                ? 'border-[#C8B28A] bg-[#C8B28A] text-[#11100E] font-medium'
                : 'border-[#C8B28A]/20 text-[#B7B0A3] hover:text-[#FAF8F3]'
            }`}
          >
            WATCHES
          </button>
          <button
            onClick={() => setSelectedCategory('fashion')}
            className={`px-6 py-2.5 text-xs uppercase tracking-[0.25em] transition-all border ${
              selectedCategory === 'fashion'
                ? 'border-[#C8B28A] bg-[#C8B28A] text-[#11100E] font-medium'
                : 'border-[#C8B28A]/20 text-[#B7B0A3] hover:text-[#FAF8F3]'
            }`}
          >
            FASHION
          </button>
          <button
            onClick={() => setSelectedCategory('jewellery')}
            className={`px-6 py-2.5 text-xs uppercase tracking-[0.25em] transition-all border ${
              selectedCategory === 'jewellery'
                ? 'border-[#C8B28A] bg-[#C8B28A] text-[#11100E] font-medium'
                : 'border-[#C8B28A]/20 text-[#B7B0A3] hover:text-[#FAF8F3]'
            }`}
          >
            JEWELLERY
          </button>
          <button
            onClick={() => setSelectedCategory('art')}
            className={`px-6 py-2.5 text-xs uppercase tracking-[0.25em] transition-all border ${
              selectedCategory === 'art'
                ? 'border-[#C8B28A] bg-[#C8B28A] text-[#11100E] font-medium'
                : 'border-[#C8B28A]/20 text-[#B7B0A3] hover:text-[#FAF8F3]'
            }`}
          >
            ART & COLLECTIBLES
          </button>
        </div>

        {/* CONTROLS BAR: FILTERS, SORT & GRID TOGGLE */}
        <div className="bg-[#181613] p-4 border border-[#C8B28A]/20 mb-12 flex flex-col md:flex-row items-center justify-between gap-4 text-xs">
          <div className="flex flex-wrap items-center gap-4 w-full md:w-auto">
            {/* BRAND FILTER */}
            <div className="flex items-center gap-2">
              <span className="text-[10px] uppercase tracking-[0.2em] text-[#C8B28A]">
                HOUSE:
              </span>
              <select
                value={selectedBrand}
                onChange={(e) => setSelectedBrand(e.target.value)}
                className="bg-[#11100E] border border-[#C8B28A]/30 px-3 py-1.5 text-xs text-[#FAF8F3] focus:outline-none focus:border-[#C8B28A]"
              >
                <option value="all">ALL HOUSES</option>
                {brands.filter((b) => b !== 'all').map((b) => (
                  <option key={b} value={b}>
                    {b}
                  </option>
                ))}
              </select>
            </div>

            {/* AVAILABILITY FILTER */}
            <div className="flex items-center gap-2">
              <span className="text-[10px] uppercase tracking-[0.2em] text-[#C8B28A]">
                STATUS:
              </span>
              <select
                value={selectedAvailability}
                onChange={(e) => setSelectedAvailability(e.target.value as any)}
                className="bg-[#11100E] border border-[#C8B28A]/30 px-3 py-1.5 text-xs text-[#FAF8F3] focus:outline-none focus:border-[#C8B28A]"
              >
                <option value="all">ALL STATUSES</option>
                <option value="available">AVAILABLE</option>
                <option value="limited">LIMITED ALLOCATION</option>
                <option value="sold-out">RESERVED</option>
              </select>
            </div>

            {(selectedBrand !== 'all' || selectedAvailability !== 'all') && (
              <button
                onClick={() => {
                  setSelectedBrand('all');
                  setSelectedAvailability('all');
                }}
                className="text-[10px] uppercase tracking-[0.2em] text-[#C8B28A] hover:underline flex items-center gap-1"
              >
                <X className="w-3 h-3" />
                CLEAR FILTERS
              </button>
            )}
          </div>

          <div className="flex items-center gap-6 w-full md:w-auto justify-between md:justify-end">
            {/* SORT BY */}
            <div className="flex items-center gap-2">
              <span className="text-[10px] uppercase tracking-[0.2em] text-[#C8B28A]">
                SORT BY:
              </span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-[#11100E] border border-[#C8B28A]/30 px-3 py-1.5 text-xs text-[#FAF8F3] focus:outline-none focus:border-[#C8B28A]"
              >
                <option value="featured">CURATED FEATURED</option>
                <option value="price-asc">PRICE: LOW TO HIGH</option>
                <option value="price-desc">PRICE: HIGH TO LOW</option>
                <option value="brand">BRAND HOUSE A-Z</option>
              </select>
            </div>

            {/* GRID COLS TOGGLE */}
            <div className="hidden lg:flex items-center gap-1 border-l border-[#C8B28A]/20 pl-4">
              <button
                onClick={() => setGridCols(3)}
                className={`p-1.5 transition-colors ${
                  gridCols === 3 ? 'text-[#C8B28A]' : 'text-[#B7B0A3]/50 hover:text-[#FAF8F3]'
                }`}
                aria-label="3 Columns"
              >
                <Grid2X2 className="w-4 h-4" />
              </button>
              <button
                onClick={() => setGridCols(4)}
                className={`p-1.5 transition-colors ${
                  gridCols === 4 ? 'text-[#C8B28A]' : 'text-[#B7B0A3]/50 hover:text-[#FAF8F3]'
                }`}
                aria-label="4 Columns"
              >
                <Grid3X3 className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* RESULTS COUNT */}
        <div className="mb-8 flex items-center justify-between text-xs text-[#B7B0A3]">
          <span>SHOWING {filteredProducts.length} ACQUISITIONS</span>
          <span className="text-[10px] uppercase tracking-[0.2em] text-[#C8B28A]">
            SINGAPORE VAULT SEALED
          </span>
        </div>

        {/* PRODUCTS GRID */}
        {filteredProducts.length === 0 ? (
          <div className="text-center py-24 bg-[#181613] border border-[#C8B28A]/20 p-8 space-y-4">
            <Sparkles className="w-10 h-10 text-[#C8B28A] mx-auto opacity-50" />
            <h3 className="font-serif-luxury text-2xl text-[#FAF8F3]">
              No pieces match your selected criteria.
            </h3>
            <p className="text-xs text-[#B7B0A3] max-w-md mx-auto">
              Contact our private client advisors to source off-market watches, rare exotics, and private high jewellery.
            </p>
            <button
              onClick={() => {
                setSelectedCategory('all');
                setSelectedBrand('all');
                setSelectedAvailability('all');
              }}
              className="inline-block bg-[#C8B28A] text-[#11100E] px-6 py-3 text-xs uppercase tracking-[0.2em] font-medium"
            >
              RESET ALL FILTERS
            </button>
          </div>
        ) : (
          <div
            className={`grid grid-cols-1 sm:grid-cols-2 ${
              gridCols === 4 ? 'lg:grid-cols-4' : 'lg:grid-cols-3'
            } gap-8`}
          >
            {filteredProducts.map((product) => (
              <ProductCard key={product.id} product={product} onNavigate={onNavigate} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
