import React, { useState } from 'react';
import { PRODUCTS_DATA } from '../data/products';
import { Product } from '../types';
import { useStore } from '../lib/store';
import { formatPrice } from '../lib/currency';
import { ProductCard } from '../components/product/ProductCard';
import {
  Heart,
  ShoppingBag,
  MessageSquare,
  ShieldCheck,
  Award,
  Truck,
  RotateCcw,
  Maximize2,
  X,
  ChevronRight,
  Sparkles,
  CheckCircle2
} from 'lucide-react';

interface ProductDetailPageProps {
  slug: string;
  onNavigate: (path: string) => void;
}

export const ProductDetailPage: React.FC<ProductDetailPageProps> = ({ slug, onNavigate }) => {
  const {
    currency,
    addToCart,
    toggleWishlist,
    isInWishlist,
    openConsultation
  } = useStore();

  const product = PRODUCTS_DATA.find((p) => p.slug === slug) || PRODUCTS_DATA[0];

  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [isFullscreenViewerOpen, setIsFullscreenViewerOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'specifications' | 'provenance' | 'delivery'>('specifications');

  const isSaved = isInWishlist(product.id);

  // Related products from same category or brand
  const relatedProducts = PRODUCTS_DATA.filter(
    (p) => (p.category === product.category || p.brand === product.brand) && p.id !== product.id
  ).slice(0, 3);

  return (
    <div className="bg-[#11100E] text-[#F5F1E8] pt-28 pb-24 min-h-screen">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        {/* BREADCRUMB */}
        <div className="flex items-center gap-2 text-xs uppercase tracking-[0.2em] text-[#B7B0A3] mb-8">
          <button onClick={() => onNavigate('/')} className="hover:text-[#FAF8F3]">
            HOME
          </button>
          <ChevronRight className="w-3 h-3 text-[#C8B28A]" />
          <button onClick={() => onNavigate('/shop')} className="hover:text-[#FAF8F3]">
            SHOP
          </button>
          <ChevronRight className="w-3 h-3 text-[#C8B28A]" />
          <button onClick={() => onNavigate(`/shop/${product.category}`)} className="hover:text-[#FAF8F3]">
            {product.category}
          </button>
          <ChevronRight className="w-3 h-3 text-[#C8B28A]" />
          <span className="text-[#C8B28A] truncate">{product.name}</span>
        </div>

        {/* MAIN PRODUCT LAYOUT GRID */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          {/* LEFT: GALLERY (7 COLS) */}
          <div className="lg:col-span-7 space-y-4">
            <div className="aspect-[4/5] bg-[#181613] border border-[#C8B28A]/30 relative overflow-hidden group shadow-2xl">
              <img
                src={product.images[activeImageIndex]}
                alt={product.name}
                className="w-full h-full object-cover object-center transition-all duration-500"
              />

              {/* FULLSCREEN ZOOM BUTTON */}
              <button
                onClick={() => setIsFullscreenViewerOpen(true)}
                className="absolute top-4 right-4 bg-[#11100E]/80 text-[#FAF8F3] hover:text-[#C8B28A] p-2.5 border border-[#C8B28A]/30 backdrop-blur-md transition-colors"
                aria-label="View Fullscreen Photo"
              >
                <Maximize2 className="w-4 h-4" />
              </button>

              <div className="absolute bottom-4 left-4">
                <span className="text-[10px] uppercase tracking-[0.25em] bg-[#11100E]/90 text-[#C8B28A] px-3 py-1 border border-[#C8B28A]/40 backdrop-blur-md">
                  {product.availability === 'limited'
                    ? 'LIMITED ALLOCATION'
                    : product.availability === 'sold-out'
                    ? 'RESERVED'
                    : 'AVAILABLE IN VAULT'}
                </span>
              </div>
            </div>

            {/* THUMBNAILS ROW */}
            {product.images.length > 1 && (
              <div className="flex gap-4 overflow-x-auto pb-2">
                {product.images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveImageIndex(idx)}
                    className={`w-20 h-24 shrink-0 border transition-all ${
                      activeImageIndex === idx
                        ? 'border-[#C8B28A] scale-105 shadow-xl'
                        : 'border-[#C8B28A]/20 opacity-60 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt={`Angle ${idx}`} className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* RIGHT: DETAILS & ACTIONS (5 COLS) */}
          <div className="lg:col-span-5 space-y-8 bg-[#181613] p-8 md:p-10 border border-[#C8B28A]/30 shadow-2xl">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs uppercase tracking-[0.35em] text-[#C8B28A] font-medium">
                  {product.brand}
                </span>
                {product.limitedEditionNumber && (
                  <span className="text-[10px] uppercase tracking-[0.2em] text-[#C8B28A] bg-[#11100E] px-2.5 py-1 border border-[#C8B28A]/30">
                    {product.limitedEditionNumber}
                  </span>
                )}
              </div>

              <h1 className="font-serif-luxury text-3xl md:text-4xl text-[#FAF8F3] font-normal leading-tight">
                {product.name}
              </h1>

              {product.subtitle && (
                <p className="text-xs text-[#B7B0A3] font-light leading-relaxed">
                  {product.subtitle}
                </p>
              )}

              <div className="pt-4 border-t border-[#C8B28A]/20 flex items-baseline justify-between">
                <div>
                  <span className="text-[10px] uppercase tracking-[0.2em] text-[#B7B0A3] block mb-1">
                    ACQUISITION VALUE
                  </span>
                  <span className="font-mono text-2xl md:text-3xl text-[#C8B28A] font-medium">
                    {formatPrice(product.priceSGD, currency)}
                  </span>
                </div>
                <span className="text-[10px] uppercase tracking-[0.2em] text-[#B7B0A3]/70">
                  SINGAPORE GST INCL.
                </span>
              </div>
            </div>

            {/* DESCRIPTION */}
            <p className="text-xs text-[#FAF8F3]/90 font-light leading-relaxed">
              {product.description}
            </p>

            {/* ACTION BUTTONS */}
            <div className="space-y-3 pt-2">
              <div className="flex gap-3">
                <button
                  onClick={() => addToCart(product)}
                  disabled={product.availability === 'sold-out'}
                  className={`flex-1 py-4 text-xs uppercase tracking-[0.25em] font-medium transition-colors flex items-center justify-center gap-2 ${
                    product.availability === 'sold-out'
                      ? 'bg-[#2A2621] text-[#B7B0A3] cursor-not-allowed'
                      : 'bg-[#C8B28A] hover:bg-[#A78B5A] text-[#11100E]'
                  }`}
                >
                  <ShoppingBag className="w-4 h-4" />
                  {product.availability === 'sold-out' ? 'RESERVED IN VAULT' : 'ADD TO PRIVATE BAG'}
                </button>

                <button
                  onClick={() => toggleWishlist(product)}
                  className={`p-4 border transition-colors ${
                    isSaved
                      ? 'border-[#C8B28A] bg-[#C8B28A] text-[#11100E]'
                      : 'border-[#C8B28A]/40 text-[#FAF8F3] hover:text-[#C8B28A]'
                  }`}
                  aria-label="Toggle Wishlist"
                >
                  <Heart className={`w-4 h-4 ${isSaved ? 'fill-current' : ''}`} />
                </button>
              </div>

              <button
                onClick={() => openConsultation(product)}
                className="w-full bg-[#11100E] hover:bg-[#2A2621] text-[#FAF8F3] border border-[#C8B28A]/40 py-3.5 text-xs uppercase tracking-[0.25em] font-medium transition-colors flex items-center justify-center gap-2"
              >
                <MessageSquare className="w-4 h-4 text-[#C8B28A]" />
                REQUEST PRIVATE CONSULTATION
              </button>
            </div>

            {/* VAULT GUARANTEE BADGES */}
            <div className="space-y-3 pt-6 border-t border-[#C8B28A]/20 text-xs text-[#B7B0A3]">
              <div className="flex items-center gap-3">
                <ShieldCheck className="w-4 h-4 text-[#C8B28A] shrink-0" />
                <span>{product.provenance.authenticityGuarantee}</span>
              </div>
              <div className="flex items-center gap-3">
                <Truck className="w-4 h-4 text-[#C8B28A] shrink-0" />
                <span>Complimentary Singapore Armored Hand Delivery & Global Courier</span>
              </div>
              <div className="flex items-center gap-3">
                <Award className="w-4 h-4 text-[#C8B28A] shrink-0" />
                <span>Certified Origin: {product.provenance.origin} ({product.provenance.year})</span>
              </div>
            </div>
          </div>
        </div>

        {/* DETAILED TABS: SPECIFICATIONS, PROVENANCE, DELIVERY */}
        <div className="mt-20 bg-[#181613] border border-[#C8B28A]/30 p-8 md:p-12">
          <div className="flex flex-wrap gap-6 border-b border-[#C8B28A]/20 pb-6 mb-8">
            <button
              onClick={() => setActiveTab('specifications')}
              className={`text-xs uppercase tracking-[0.25em] font-medium pb-2 border-b-2 transition-all ${
                activeTab === 'specifications'
                  ? 'border-[#C8B28A] text-[#C8B28A]'
                  : 'border-transparent text-[#B7B0A3] hover:text-[#FAF8F3]'
              }`}
            >
              SPECIFICATIONS & DETAILS
            </button>

            <button
              onClick={() => setActiveTab('provenance')}
              className={`text-xs uppercase tracking-[0.25em] font-medium pb-2 border-b-2 transition-all ${
                activeTab === 'provenance'
                  ? 'border-[#C8B28A] text-[#C8B28A]'
                  : 'border-transparent text-[#B7B0A3] hover:text-[#FAF8F3]'
              }`}
            >
              PROVENANCE & AUTHENTICITY
            </button>

            <button
              onClick={() => setActiveTab('delivery')}
              className={`text-xs uppercase tracking-[0.25em] font-medium pb-2 border-b-2 transition-all ${
                activeTab === 'delivery'
                  ? 'border-[#C8B28A] text-[#C8B28A]'
                  : 'border-transparent text-[#B7B0A3] hover:text-[#FAF8F3]'
              }`}
            >
              WHITE-GLOVE DELIVERY & VAULT
            </button>
          </div>

          {activeTab === 'specifications' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-xs">
              <div className="space-y-4">
                <h3 className="font-serif-luxury text-xl text-[#FAF8F3] mb-4">
                  Technical Specifications
                </h3>
                {Object.entries(product.specifications).map(([key, val]) => (
                  <div key={key} className="flex justify-between py-2 border-b border-[#C8B28A]/10">
                    <span className="text-[#B7B0A3] uppercase tracking-wider">{key}</span>
                    <span className="text-[#FAF8F3] font-medium text-right">{val}</span>
                  </div>
                ))}
              </div>

              <div className="space-y-4">
                <h3 className="font-serif-luxury text-xl text-[#FAF8F3] mb-4">
                  Curator's Notes
                </h3>
                <p className="text-[#B7B0A3] font-light leading-relaxed">
                  {product.story || product.description}
                </p>
                <div className="p-4 bg-[#11100E] border border-[#C8B28A]/20 space-y-2 mt-4">
                  <span className="text-[10px] uppercase tracking-[0.2em] text-[#C8B28A] block">
                    DEMONSTRATION DATA NOTICE
                  </span>
                  <p className="text-[11px] text-[#B7B0A3]">
                    This piece is catalogued as demonstration inventory for the Singapore Privé digital experience. Real acquisitions undergo physical inspection at our Marina Bay Sands salon.
                  </p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'provenance' && (
            <div className="max-w-2xl space-y-6 text-xs text-[#B7B0A3]">
              <h3 className="font-serif-luxury text-2xl text-[#FAF8F3]">
                Guaranteed Authenticity & Archive Provenance
              </h3>
              <p className="leading-relaxed">
                Every timepiece, high jewellery creation, and fine art masterpiece curated by Singapore Privé undergoes rigorous inspection by independent master watchmakers, GIA/Gübelin gemmologists, and museum provenance researchers.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div className="bg-[#11100E] p-4 border border-[#C8B28A]/20 space-y-1">
                  <span className="text-[10px] uppercase tracking-[0.2em] text-[#C8B28A] block">
                    COUNTRY OF ORIGIN
                  </span>
                  <span className="text-[#FAF8F3] font-serif-luxury text-lg">{product.provenance.origin}</span>
                </div>

                <div className="bg-[#11100E] p-4 border border-[#C8B28A]/20 space-y-1">
                  <span className="text-[10px] uppercase tracking-[0.2em] text-[#C8B28A] block">
                    CREATION / MANUFACTURE YEAR
                  </span>
                  <span className="text-[#FAF8F3] font-serif-luxury text-lg">{product.provenance.year}</span>
                </div>
              </div>

              <div className="bg-[#11100E] p-4 border border-[#C8B28A]/20 space-y-1">
                <span className="text-[10px] uppercase tracking-[0.2em] text-[#C8B28A] block">
                  OFFICIAL ARCHIVE CERTIFICATE
                </span>
                <span className="text-[#FAF8F3] font-medium">{product.provenance.certificate}</span>
              </div>
            </div>
          )}

          {activeTab === 'delivery' && (
            <div className="max-w-2xl space-y-6 text-xs text-[#B7B0A3]">
              <h3 className="font-serif-luxury text-2xl text-[#FAF8F3]">
                Singapore Armored Courier & Global Vault Logistics
              </h3>
              <p className="leading-relaxed">
                For Singapore residences and private yachts moored in Keppel Bay or Marina South, deliveries are executed via armed courier escort in climate-controlled security vehicles.
              </p>

              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-4 h-4 text-[#C8B28A] shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-[#FAF8F3] block">Same-Day Singapore Hand Delivery</strong>
                    <span>Orders placed before 14:00 SGT are delivered hand-to-hand by 18:00 SGT.</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-4 h-4 text-[#C8B28A] shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-[#FAF8F3] block">Singapore Freeport Storage</strong>
                    <span>Clients may elect complimentary bonded vault holding at Singapore Freeport Changi for tax exemption.</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* RELATED ACQUISITIONS */}
        {relatedProducts.length > 0 && (
          <div className="mt-24">
            <div className="mb-12 space-y-2">
              <span className="text-[10px] uppercase tracking-[0.35em] text-[#C8B28A] font-medium">
                RECOMMENDED COMPLEMENTS
              </span>
              <h2 className="font-serif-luxury text-3xl text-[#FAF8F3]">
                CURATED FOR THE DISCERNING COLLECTOR
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {relatedProducts.map((rel) => (
                <ProductCard key={rel.id} product={rel} onNavigate={onNavigate} />
              ))}
            </div>
          </div>
        )}
      </div>

      {/* FULLSCREEN IMAGE MODAL */}
      {isFullscreenViewerOpen && (
        <div className="fixed inset-0 z-50 bg-[#11100E]/98 backdrop-blur-2xl flex items-center justify-center p-4">
          <button
            onClick={() => setIsFullscreenViewerOpen(false)}
            className="absolute top-6 right-6 text-[#B7B0A3] hover:text-[#FAF8F3] p-2 bg-[#181613] border border-[#C8B28A]/30"
          >
            <X className="w-6 h-6" />
          </button>
          <img
            src={product.images[activeImageIndex]}
            alt={product.name}
            className="max-w-full max-h-[90vh] object-contain shadow-2xl"
          />
        </div>
      )}
    </div>
  );
};
