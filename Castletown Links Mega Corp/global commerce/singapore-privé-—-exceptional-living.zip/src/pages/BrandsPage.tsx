import React, { useState } from 'react';
import { BRANDS_DATA } from '../data/brands';
import { PRODUCTS_DATA } from '../data/products';
import { Brand } from '../types';
import { ProductCard } from '../components/product/ProductCard';
import { MapPin, ArrowRight, Sparkles, Building2, Globe } from 'lucide-react';

interface BrandsPageProps {
  selectedBrandSlug?: string | null;
  onNavigate: (path: string) => void;
}

export const BrandsPage: React.FC<BrandsPageProps> = ({ selectedBrandSlug, onNavigate }) => {
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<string>('all');

  const selectedBrand = selectedBrandSlug
    ? BRANDS_DATA.find((b) => b.slug === selectedBrandSlug)
    : null;

  if (selectedBrand) {
    const brandProducts = PRODUCTS_DATA.filter(
      (p) => p.brandSlug === selectedBrand.slug || p.brand.toLowerCase() === selectedBrand.name.toLowerCase()
    );

    return (
      <div className="bg-[#11100E] text-[#F5F1E8] pt-32 pb-24 min-h-screen">
        <div className="max-w-7xl mx-auto px-6 md:px-12">
          {/* BRAND HERO */}
          <div className="relative aspect-[21/9] bg-[#181613] border border-[#C8B28A]/30 overflow-hidden mb-16">
            <img
              src={selectedBrand.heroImage}
              alt={selectedBrand.name}
              className="w-full h-full object-cover brightness-[0.7]"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#11100E] via-[#11100E]/40 to-transparent"></div>
            <div className="absolute bottom-8 left-8 right-8 space-y-2">
              <span className="text-[10px] uppercase tracking-[0.3em] text-[#C8B28A]">
                {selectedBrand.country} • FOUNDED {selectedBrand.founded}
              </span>
              <h1 className="font-serif-luxury text-4xl md:text-6xl text-[#FAF8F3]">
                {selectedBrand.name}
              </h1>
              <p className="text-xs text-[#B7B0A3] font-light max-w-xl italic">
                "{selectedBrand.description}"
              </p>
            </div>
          </div>

          {/* BRAND PHILOSOPHY & FLAGSHIP */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 bg-[#181613] p-8 md:p-12 border border-[#C8B28A]/20 mb-16 text-xs">
            <div className="space-y-3">
              <span className="text-[10px] uppercase tracking-[0.3em] text-[#C8B28A]">
                HERITAGE & PHILOSOPHY
              </span>
              <p className="text-[#FAF8F3] font-light leading-relaxed">
                {selectedBrand.philosophy}
              </p>
            </div>

            <div className="space-y-3 border-t md:border-t-0 md:border-l border-[#C8B28A]/20 pt-6 md:pt-0 md:pl-8">
              <span className="text-[10px] uppercase tracking-[0.3em] text-[#C8B28A]">
                SINGAPORE FLAGSHIP SALON
              </span>
              <div className="flex items-start gap-2.5 text-[#FAF8F3]">
                <MapPin className="w-4 h-4 text-[#C8B28A] shrink-0 mt-0.5" />
                <span className="font-serif-luxury text-sm">{selectedBrand.flagshipLocation}</span>
              </div>
              <p className="text-[#B7B0A3] text-[11px]">
                Private client appointments, bespoke sizing, and horological servicing available upon request.
              </p>
            </div>
          </div>

          {/* BRAND PRODUCTS */}
          <div className="space-y-8">
            <h2 className="font-serif-luxury text-3xl text-[#FAF8F3]">
              CURATED {selectedBrand.name.toUpperCase()} ACQUISITIONS
            </h2>

            {brandProducts.length === 0 ? (
              <div className="p-12 bg-[#181613] border border-[#C8B28A]/20 text-center space-y-4">
                <p className="font-serif-luxury text-xl text-[#FAF8F3]">
                  Off-market pieces available via private client advisory.
                </p>
                <button
                  onClick={() => onNavigate('/shop')}
                  className="bg-[#C8B28A] text-[#11100E] px-6 py-2.5 text-xs uppercase tracking-[0.2em]"
                >
                  EXPLORE ALL COLLECTIONS
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {brandProducts.map((p) => (
                  <ProductCard key={p.id} product={p} onNavigate={onNavigate} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  // ALL BRANDS DIRECTORY PAGE
  const categories = ['all', 'watches', 'fashion', 'jewellery', 'art', 'automotive'];

  const filteredBrands = activeCategoryFilter === 'all'
    ? BRANDS_DATA
    : BRANDS_DATA.filter((b) => b.category === activeCategoryFilter);

  return (
    <div className="bg-[#11100E] text-[#F5F1E8] pt-32 pb-24 min-h-screen">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="text-center max-w-2xl mx-auto space-y-4 mb-16">
          <span className="text-[10px] uppercase tracking-[0.35em] text-[#C8B28A] font-medium">
            SINGAPORE PRIVÉ HOUSES
          </span>
          <h1 className="font-serif-luxury text-4xl md:text-6xl text-[#FAF8F3]">
            FEATURED BRANDS & HOUSES
          </h1>
          <p className="text-xs text-[#B7B0A3] font-light leading-relaxed">
            Partnering directly with Geneva’s independent watch manufactures, Parisian haute couture ateliers, and premier international art advisories.
          </p>
        </div>

        {/* CATEGORY FILTER */}
        <div className="flex flex-wrap items-center justify-center gap-3 border-b border-[#C8B28A]/20 pb-8 mb-16">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategoryFilter(cat)}
              className={`px-6 py-2.5 text-xs uppercase tracking-[0.25em] transition-all border ${
                activeCategoryFilter === cat
                  ? 'border-[#C8B28A] bg-[#C8B28A] text-[#11100E] font-medium'
                  : 'border-[#C8B28A]/20 text-[#B7B0A3] hover:text-[#FAF8F3]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* BRANDS DIRECTORY GRID */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredBrands.map((brand) => (
            <div
              key={brand.id}
              onClick={() => onNavigate(`/brands/${brand.slug}`)}
              className="group bg-[#181613] border border-[#C8B28A]/20 hover:border-[#C8B28A] transition-all duration-500 overflow-hidden cursor-pointer flex flex-col justify-between"
            >
              <div className="aspect-[16/10] bg-[#11100E] overflow-hidden relative">
                <img
                  src={brand.heroImage}
                  alt={brand.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <span className="absolute top-3 left-3 text-[9px] uppercase tracking-[0.2em] bg-[#11100E]/80 text-[#C8B28A] px-2.5 py-1 border border-[#C8B28A]/30">
                  {brand.category}
                </span>
              </div>

              <div className="p-6 space-y-3 flex-1 flex flex-col justify-between">
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-[10px] text-[#C8B28A] uppercase tracking-[0.2em]">
                    <span>{brand.country}</span>
                    <span>EST. {brand.founded}</span>
                  </div>
                  <h3 className="font-serif-luxury text-2xl text-[#FAF8F3] group-hover:text-[#C8B28A] transition-colors">
                    {brand.name}
                  </h3>
                  <p className="text-xs text-[#B7B0A3] font-light italic line-clamp-2">
                    "{brand.description}"
                  </p>
                </div>

                <div className="pt-4 border-t border-[#C8B28A]/15 flex items-center justify-between text-xs text-[#C8B28A]">
                  <span className="text-[10px] uppercase tracking-[0.2em]">VIEW BRAND SALON</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
