import React, { useState } from 'react';
import { useStore } from '../lib/store';
import { formatPrice } from '../lib/currency';
import {
  ShieldCheck,
  Truck,
  CreditCard,
  Building2,
  CheckCircle2,
  ArrowRight,
  Lock,
  User,
  Mail,
  Phone,
  MapPin,
  Sparkles
} from 'lucide-react';

interface CheckoutPageProps {
  onNavigate: (path: string) => void;
}

export const CheckoutPage: React.FC<CheckoutPageProps> = ({ onNavigate }) => {
  const { cart, cartTotalSGD, currency, clearCart, addToast } = useStore();

  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);

  // Form State
  const [fullName, setFullName] = useState('Sir Jonathan Tan');
  const [email, setEmail] = useState('jonathan.tan@prive.sg');
  const [phone, setPhone] = useState('+65 9182 8888');
  const [address, setAddress] = useState('28 Nassim Hill, Penthouse 04-01');
  const [postalCode, setPostalCode] = useState('Singapore 258472');

  const [deliveryOption, setDeliveryOption] = useState<'armored' | 'freeport' | 'salon' | 'global'>('armored');
  const [paymentOption, setPaymentOption] = useState<'card' | 'wire' | 'applepay'>('card');

  // Payment Form
  const [cardNumber, setCardNumber] = useState('•••• •••• •••• 8888');
  const [cardExpiry, setCardExpiry] = useState('11/28');
  const [cardCvc, setCardCvc] = useState('•••');

  const [orderCode, setOrderCode] = useState('');

  const gstSGD = Math.round(cartTotalSGD * 0.09);

  const handleCompleteOrder = (e: React.FormEvent) => {
    e.preventDefault();
    const generatedCode = `SGP-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    setOrderCode(generatedCode);
    setStep(4);
    clearCart();
    addToast(
      'Acquisition Confirmed',
      `Order ${generatedCode} registered. Your assigned Client Director Alexandre De Witt will contact you shortly.`,
      'gold'
    );
  };

  if (cart.length === 0 && step !== 4) {
    return (
      <div className="bg-[#11100E] text-[#F5F1E8] pt-32 pb-24 min-h-screen text-center">
        <div className="max-w-md mx-auto p-8 bg-[#181613] border border-[#C8B28A]/20 space-y-4">
          <h2 className="font-serif-luxury text-2xl text-[#FAF8F3]">
            Your shopping bag is empty.
          </h2>
          <p className="text-xs text-[#B7B0A3]">
            Please add an acquisition before proceeding to private checkout.
          </p>
          <button
            onClick={() => onNavigate('/shop')}
            className="bg-[#C8B28A] text-[#11100E] px-6 py-3 text-xs uppercase tracking-[0.2em]"
          >
            EXPLORE COLLECTIONS
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#11100E] text-[#F5F1E8] pt-32 pb-24 min-h-screen">
      <div className="max-w-6xl mx-auto px-6 md:px-12">
        {/* CHECKOUT HEADER STEPS */}
        <div className="mb-12 border-b border-[#C8B28A]/20 pb-8">
          <span className="text-[10px] uppercase tracking-[0.35em] text-[#C8B28A] block mb-2 font-medium">
            SINGAPORE PRIVÉ SECURE CHECKOUT
          </span>
          <h1 className="font-serif-luxury text-3xl md:text-5xl text-[#FAF8F3]">
            ACQUISITION PROTOCOL
          </h1>

          {/* STEP INDICATORS */}
          <div className="grid grid-cols-4 gap-2 mt-8 text-xs">
            <div
              onClick={() => step > 1 && setStep(1)}
              className={`pb-2 border-b-2 cursor-pointer transition-all ${
                step === 1 ? 'border-[#C8B28A] text-[#C8B28A] font-medium' : step > 1 ? 'border-[#C8B28A]/60 text-[#FAF8F3]' : 'border-transparent text-[#B7B0A3]/40'
              }`}
            >
              01 CLIENT INFO
            </div>

            <div
              onClick={() => step > 2 && setStep(2)}
              className={`pb-2 border-b-2 cursor-pointer transition-all ${
                step === 2 ? 'border-[#C8B28A] text-[#C8B28A] font-medium' : step > 2 ? 'border-[#C8B28A]/60 text-[#FAF8F3]' : 'border-transparent text-[#B7B0A3]/40'
              }`}
            >
              02 DELIVERY
            </div>

            <div
              onClick={() => step > 3 && setStep(3)}
              className={`pb-2 border-b-2 cursor-pointer transition-all ${
                step === 3 ? 'border-[#C8B28A] text-[#C8B28A] font-medium' : step > 3 ? 'border-[#C8B28A]/60 text-[#FAF8F3]' : 'border-transparent text-[#B7B0A3]/40'
              }`}
            >
              03 PAYMENT
            </div>

            <div
              className={`pb-2 border-b-2 transition-all ${
                step === 4 ? 'border-[#C8B28A] text-[#C8B28A] font-medium' : 'border-transparent text-[#B7B0A3]/40'
              }`}
            >
              04 CONFIRMATION
            </div>
          </div>
        </div>

        {/* MAIN CHECKOUT BODY GRID */}
        {step === 4 ? (
          /* STEP 04: CONFIRMATION */
          <div className="bg-[#181613] p-8 md:p-12 border border-[#C8B28A]/40 max-w-2xl mx-auto space-y-8 text-center animate-fade-in">
            <div className="w-16 h-16 bg-[#C8B28A]/10 border border-[#C8B28A] rounded-full flex items-center justify-center mx-auto text-[#C8B28A]">
              <Sparkles className="w-8 h-8" />
            </div>

            <div className="space-y-2">
              <span className="text-[10px] uppercase tracking-[0.3em] text-[#C8B28A] font-medium">
                ACQUISITION CONFIRMED
              </span>
              <h2 className="font-serif-luxury text-3xl md:text-4xl text-[#FAF8F3]">
                Order Reference: {orderCode}
              </h2>
              <p className="text-xs text-[#B7B0A3] font-light max-w-md mx-auto">
                Thank you for acquiring with Singapore Privé. Your order is safely sealed in our Singapore Vault.
              </p>
            </div>

            <div className="bg-[#11100E] p-6 border border-[#C8B28A]/20 text-left space-y-3 text-xs">
              <span className="text-[10px] uppercase tracking-[0.2em] text-[#C8B28A] block">
                ASSIGNED CLIENT DIRECTOR
              </span>
              <p className="text-[#FAF8F3] font-serif-luxury text-base">
                Mr. Alexandre De Witt
              </p>
              <p className="text-[#B7B0A3]">
                Senior Director, Private Client Relations • Marina Bay Sands Salon
              </p>
              <p className="text-[#B7B0A3] text-[11px] pt-2 border-t border-[#C8B28A]/10">
                Direct Line: +65 6888 8829 | Email: alexandre.dewitt@singaporeprive.sg
              </p>
            </div>

            <button
              onClick={() => onNavigate('/')}
              className="bg-[#C8B28A] text-[#11100E] px-8 py-3.5 text-xs uppercase tracking-[0.25em] font-medium hover:bg-[#A78B5A] transition-colors"
            >
              RETURN TO HOME SALON
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
            {/* LEFT: FORM STEPS */}
            <div className="lg:col-span-7 bg-[#181613] p-8 border border-[#C8B28A]/30 space-y-8">
              {step === 1 && (
                /* STEP 1: INFORMATION */
                <div className="space-y-6">
                  <h3 className="font-serif-luxury text-2xl text-[#FAF8F3]">
                    01. Client Information
                  </h3>

                  <div className="space-y-4 text-xs">
                    <div>
                      <label className="block text-[10px] uppercase tracking-[0.2em] text-[#C8B28A] mb-1.5">
                        FULL LEGAL NAME
                      </label>
                      <input
                        type="text"
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                        required
                        className="w-full bg-[#11100E] border border-[#C8B28A]/30 p-3 text-[#FAF8F3] focus:outline-none focus:border-[#C8B28A]"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[10px] uppercase tracking-[0.2em] text-[#C8B28A] mb-1.5">
                          CONFIDENTIAL EMAIL
                        </label>
                        <input
                          type="email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          required
                          className="w-full bg-[#11100E] border border-[#C8B28A]/30 p-3 text-[#FAF8F3] focus:outline-none focus:border-[#C8B28A]"
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] uppercase tracking-[0.2em] text-[#C8B28A] mb-1.5">
                          TELEPHONE NUMBER
                        </label>
                        <input
                          type="text"
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          required
                          className="w-full bg-[#11100E] border border-[#C8B28A]/30 p-3 text-[#FAF8F3] focus:outline-none focus:border-[#C8B28A]"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[10px] uppercase tracking-[0.2em] text-[#C8B28A] mb-1.5">
                        DELIVERY RESIDENCE ADDRESS
                      </label>
                      <input
                        type="text"
                        value={address}
                        onChange={(e) => setAddress(e.target.value)}
                        required
                        className="w-full bg-[#11100E] border border-[#C8B28A]/30 p-3 text-[#FAF8F3] focus:outline-none focus:border-[#C8B28A]"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] uppercase tracking-[0.2em] text-[#C8B28A] mb-1.5">
                        SINGAPORE POSTAL CODE / REGION
                      </label>
                      <input
                        type="text"
                        value={postalCode}
                        onChange={(e) => setPostalCode(e.target.value)}
                        required
                        className="w-full bg-[#11100E] border border-[#C8B28A]/30 p-3 text-[#FAF8F3] focus:outline-none focus:border-[#C8B28A]"
                      />
                    </div>
                  </div>

                  <button
                    onClick={() => setStep(2)}
                    className="w-full bg-[#C8B28A] hover:bg-[#A78B5A] text-[#11100E] py-4 text-xs uppercase tracking-[0.25em] font-medium transition-colors flex items-center justify-center gap-2"
                  >
                    CONTINUE TO DELIVERY METHOD →
                  </button>
                </div>
              )}

              {step === 2 && (
                /* STEP 2: DELIVERY OPTIONS */
                <div className="space-y-6">
                  <h3 className="font-serif-luxury text-2xl text-[#FAF8F3]">
                    02. Choose Delivery Protocol
                  </h3>

                  <div className="space-y-4">
                    <label
                      onClick={() => setDeliveryOption('armored')}
                      className={`p-4 border flex items-start gap-4 cursor-pointer transition-all ${
                        deliveryOption === 'armored'
                          ? 'border-[#C8B28A] bg-[#11100E]'
                          : 'border-[#C8B28A]/20 bg-[#181613]'
                      }`}
                    >
                      <Truck className="w-5 h-5 text-[#C8B28A] shrink-0 mt-1" />
                      <div className="space-y-1 text-xs">
                        <span className="font-serif-luxury text-base text-[#FAF8F3] block">
                          Singapore Armored Hand-Delivery
                        </span>
                        <p className="text-[#B7B0A3] font-light">
                          Hand-to-hand delivery by armed security courier at your private residence, yacht berth, or penthouse.
                        </p>
                        <span className="text-[10px] uppercase tracking-[0.2em] text-[#C8B28A] block pt-1">
                          COMPLIMENTARY SAME-DAY / NEXT-DAY
                        </span>
                      </div>
                    </label>

                    <label
                      onClick={() => setDeliveryOption('freeport')}
                      className={`p-4 border flex items-start gap-4 cursor-pointer transition-all ${
                        deliveryOption === 'freeport'
                          ? 'border-[#C8B28A] bg-[#11100E]'
                          : 'border-[#C8B28A]/20 bg-[#181613]'
                      }`}
                    >
                      <Building2 className="w-5 h-5 text-[#C8B28A] shrink-0 mt-1" />
                      <div className="space-y-1 text-xs">
                        <span className="font-serif-luxury text-base text-[#FAF8F3] block">
                          Singapore Freeport Vault Bonded Holding
                        </span>
                        <p className="text-[#B7B0A3] font-light">
                          Stored in climate-controlled bonded holding at Changi Airport Freeport for duty-exempt storage.
                        </p>
                        <span className="text-[10px] uppercase tracking-[0.2em] text-[#C8B28A] block pt-1">
                          COMPLIMENTARY BONDED HOLDING
                        </span>
                      </div>
                    </label>

                    <label
                      onClick={() => setDeliveryOption('salon')}
                      className={`p-4 border flex items-start gap-4 cursor-pointer transition-all ${
                        deliveryOption === 'salon'
                          ? 'border-[#C8B28A] bg-[#11100E]'
                          : 'border-[#C8B28A]/20 bg-[#181613]'
                      }`}
                    >
                      <MapPin className="w-5 h-5 text-[#C8B28A] shrink-0 mt-1" />
                      <div className="space-y-1 text-xs">
                        <span className="font-serif-luxury text-base text-[#FAF8F3] block">
                          Marina Bay Sands Salon Handover
                        </span>
                        <p className="text-[#B7B0A3] font-light">
                          Private presentation over champagne at our Level 1 Private Salon in The Shoppes at Marina Bay Sands.
                        </p>
                      </div>
                    </label>
                  </div>

                  <div className="flex gap-4">
                    <button
                      onClick={() => setStep(1)}
                      className="px-6 py-4 border border-[#C8B28A]/30 text-xs uppercase tracking-[0.2em]"
                    >
                      BACK
                    </button>
                    <button
                      onClick={() => setStep(3)}
                      className="flex-1 bg-[#C8B28A] hover:bg-[#A78B5A] text-[#11100E] py-4 text-xs uppercase tracking-[0.25em] font-medium transition-colors"
                    >
                      CONTINUE TO PAYMENT METHOD →
                    </button>
                  </div>
                </div>
              )}

              {step === 3 && (
                /* STEP 3: PAYMENT */
                <form onSubmit={handleCompleteOrder} className="space-y-6">
                  <h3 className="font-serif-luxury text-2xl text-[#FAF8F3]">
                    03. Secure Settlement
                  </h3>

                  <div className="grid grid-cols-3 gap-2">
                    <button
                      type="button"
                      onClick={() => setPaymentOption('card')}
                      className={`py-3 text-[10px] uppercase tracking-[0.2em] border transition-all ${
                        paymentOption === 'card'
                          ? 'border-[#C8B28A] bg-[#C8B28A] text-[#11100E] font-medium'
                          : 'border-[#C8B28A]/20 text-[#B7B0A3]'
                      }`}
                    >
                      CREDIT CARD
                    </button>
                    <button
                      type="button"
                      onClick={() => setPaymentOption('wire')}
                      className={`py-3 text-[10px] uppercase tracking-[0.2em] border transition-all ${
                        paymentOption === 'wire'
                          ? 'border-[#C8B28A] bg-[#C8B28A] text-[#11100E] font-medium'
                          : 'border-[#C8B28A]/20 text-[#B7B0A3]'
                      }`}
                    >
                      WIRE TRANSFER
                    </button>
                    <button
                      type="button"
                      onClick={() => setPaymentOption('applepay')}
                      className={`py-3 text-[10px] uppercase tracking-[0.2em] border transition-all ${
                        paymentOption === 'applepay'
                          ? 'border-[#C8B28A] bg-[#C8B28A] text-[#11100E] font-medium'
                          : 'border-[#C8B28A]/20 text-[#B7B0A3]'
                      }`}
                    >
                      APPLE / GOOGLE PAY
                    </button>
                  </div>

                  {paymentOption === 'card' && (
                    <div className="space-y-4 text-xs bg-[#11100E] p-6 border border-[#C8B28A]/20">
                      <div>
                        <label className="block text-[10px] uppercase tracking-[0.2em] text-[#C8B28A] mb-1.5">
                          CARD NUMBER
                        </label>
                        <div className="relative">
                          <CreditCard className="w-4 h-4 text-[#B7B0A3] absolute left-3 top-3" />
                          <input
                            type="text"
                            required
                            value={cardNumber}
                            onChange={(e) => setCardNumber(e.target.value)}
                            className="w-full bg-[#181613] border border-[#C8B28A]/30 pl-10 pr-4 py-2.5 text-[#FAF8F3] font-mono focus:outline-none focus:border-[#C8B28A]"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-[10px] uppercase tracking-[0.2em] text-[#C8B28A] mb-1.5">
                            EXPIRY DATE
                          </label>
                          <input
                            type="text"
                            required
                            value={cardExpiry}
                            onChange={(e) => setCardExpiry(e.target.value)}
                            className="w-full bg-[#181613] border border-[#C8B28A]/30 p-2.5 text-[#FAF8F3] font-mono focus:outline-none focus:border-[#C8B28A]"
                          />
                        </div>

                        <div>
                          <label className="block text-[10px] uppercase tracking-[0.2em] text-[#C8B28A] mb-1.5">
                            CVC / CVV
                          </label>
                          <input
                            type="password"
                            required
                            value={cardCvc}
                            onChange={(e) => setCardCvc(e.target.value)}
                            className="w-full bg-[#181613] border border-[#C8B28A]/30 p-2.5 text-[#FAF8F3] font-mono focus:outline-none focus:border-[#C8B28A]"
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {paymentOption === 'wire' && (
                    <div className="bg-[#11100E] p-6 border border-[#C8B28A]/20 space-y-2 text-xs text-[#B7B0A3]">
                      <span className="text-[10px] uppercase tracking-[0.2em] text-[#C8B28A] block">
                        BANK TELEGRAPHIC TRANSFER INSTRUCTIONS
                      </span>
                      <p>Bank: DBS Bank Singapore (Private Banking Division)</p>
                      <p>Account Name: Singapore Privé Pte. Ltd.</p>
                      <p>SWIFT Code: DBSSSGSG</p>
                      <p className="text-[11px] pt-2 text-[#FAF8F3]">
                        Your Client Director will issue formal invoice documentation upon order submission.
                      </p>
                    </div>
                  )}

                  <div className="flex items-center gap-2 text-[10px] text-[#C8B28A]">
                    <Lock className="w-3.5 h-3.5" />
                    <span>256-bit Bank Grade Encrypted Settlement Protocol</span>
                  </div>

                  <div className="flex gap-4">
                    <button
                      type="button"
                      onClick={() => setStep(2)}
                      className="px-6 py-4 border border-[#C8B28A]/30 text-xs uppercase tracking-[0.2em]"
                    >
                      BACK
                    </button>
                    <button
                      type="submit"
                      className="flex-1 bg-[#C8B28A] hover:bg-[#A78B5A] text-[#11100E] py-4 text-xs uppercase tracking-[0.25em] font-medium transition-colors"
                    >
                      AUTHORIZE ACQUISITION →
                    </button>
                  </div>
                </form>
              )}
            </div>

            {/* RIGHT: ORDER SUMMARY */}
            <div className="lg:col-span-5 bg-[#181613] p-8 border border-[#C8B28A]/30 space-y-6">
              <h3 className="font-serif-luxury text-xl text-[#FAF8F3] border-b border-[#C8B28A]/20 pb-4">
                ACQUISITION SUMMARY
              </h3>

              <div className="space-y-4 max-h-80 overflow-y-auto">
                {cart.map(({ product, quantity }) => (
                  <div key={product.id} className="flex gap-4 text-xs">
                    <img
                      src={product.images[0]}
                      alt={product.name}
                      className="w-16 h-20 object-cover border border-[#C8B28A]/20 shrink-0"
                    />
                    <div className="flex-1">
                      <span className="text-[9px] uppercase tracking-[0.2em] text-[#C8B28A]">
                        {product.brand}
                      </span>
                      <h4 className="font-serif-luxury text-sm text-[#FAF8F3] line-clamp-1">
                        {product.name}
                      </h4>
                      <p className="text-xs font-mono text-[#C8B28A] mt-1">
                        {formatPrice(product.priceSGD * quantity, currency)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="pt-4 border-t border-[#C8B28A]/20 space-y-2 text-xs text-[#B7B0A3]">
                <div className="flex justify-between">
                  <span>SUBTOTAL</span>
                  <span className="font-mono text-[#FAF8F3]">{formatPrice(cartTotalSGD, currency)}</span>
                </div>
                <div className="flex justify-between text-[11px]">
                  <span>EST. SINGAPORE GST (9% INCL.)</span>
                  <span className="font-mono">{formatPrice(gstSGD, currency)}</span>
                </div>
                <div className="flex justify-between text-[11px]">
                  <span>ARMORED HAND DELIVERY</span>
                  <span className="text-[#C8B28A]">COMPLIMENTARY</span>
                </div>
                <div className="flex justify-between text-base font-medium text-[#FAF8F3] pt-2 border-t border-[#C8B28A]/20">
                  <span>TOTAL ACQUISITION</span>
                  <span className="font-mono text-[#C8B28A]">{formatPrice(cartTotalSGD, currency)}</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
