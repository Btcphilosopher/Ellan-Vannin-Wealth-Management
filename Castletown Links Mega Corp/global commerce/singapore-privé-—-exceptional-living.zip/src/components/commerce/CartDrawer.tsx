import React from 'react';
import { useStore } from '../../lib/store';
import { formatPrice } from '../../lib/currency';
import { X, Trash2, Plus, Minus, ShoppingBag, ArrowRight, Shield } from 'lucide-react';

interface CartDrawerProps {
  onNavigate: (path: string) => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({ onNavigate }) => {
  const {
    cart,
    isCartOpen,
    setIsCartOpen,
    removeFromCart,
    updateCartQuantity,
    cartTotalSGD,
    currency
  } = useStore();

  if (!isCartOpen) return null;

  // Singapore GST 9% included estimation
  const gstSGD = Math.round(cartTotalSGD * 0.09);

  return (
    <div className="fixed inset-0 z-50 bg-[#11100E]/80 backdrop-blur-md flex justify-end animate-fade-in text-[#F5F1E8]">
      <div className="w-full max-w-lg bg-[#181613] border-l border-[#C8B28A]/30 h-full flex flex-col justify-between shadow-2xl relative animate-slide-left">
        {/* HEADER */}
        <div className="p-6 md:p-8 border-b border-[#C8B28A]/20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <ShoppingBag className="w-5 h-5 text-[#C8B28A]" />
            <span className="font-serif-luxury text-xl text-[#FAF8F3]">
              YOUR PRIVATE BAG
            </span>
          </div>
          <button
            onClick={() => setIsCartOpen(false)}
            className="text-[#B7B0A3] hover:text-[#FAF8F3] transition-colors p-2"
            aria-label="Close Shopping Bag"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* CART ITEMS LIST */}
        <div className="p-6 md:p-8 flex-1 overflow-y-auto space-y-6">
          {cart.length === 0 ? (
            <div className="text-center py-20 space-y-4">
              <ShoppingBag className="w-12 h-12 text-[#C8B28A]/40 mx-auto" />
              <p className="font-serif-luxury text-xl text-[#FAF8F3]">
                Your shopping bag is currently empty.
              </p>
              <p className="text-xs text-[#B7B0A3] max-w-xs mx-auto">
                Explore our curated acquisitions in haute horlogerie, fine jewellery, and bespoke fashion.
              </p>
              <button
                onClick={() => {
                  setIsCartOpen(false);
                  onNavigate('/shop');
                }}
                className="mt-4 inline-block bg-[#C8B28A] text-[#11100E] px-6 py-3 text-xs uppercase tracking-[0.25em] font-medium hover:bg-[#A78B5A] transition-colors"
              >
                EXPLORE COLLECTIONS
              </button>
            </div>
          ) : (
            cart.map(({ product, quantity }) => (
              <div
                key={product.id}
                className="flex gap-4 bg-[#11100E] p-4 border border-[#C8B28A]/20 relative"
              >
                <div className="w-20 h-24 bg-[#181613] overflow-hidden shrink-0 border border-[#C8B28A]/20">
                  <img
                    src={product.images[0]}
                    alt={product.name}
                    className="w-full h-full object-cover"
                  />
                </div>

                <div className="flex-1 flex flex-col justify-between">
                  <div>
                    <span className="text-[9px] uppercase tracking-[0.25em] text-[#C8B28A]">
                      {product.brand}
                    </span>
                    <h4 className="font-serif-luxury text-sm text-[#FAF8F3] line-clamp-1">
                      {product.name}
                    </h4>
                    <p className="font-mono text-xs text-[#C8B28A] font-medium mt-1">
                      {formatPrice(product.priceSGD * quantity, currency)}
                    </p>
                  </div>

                  <div className="flex items-center justify-between pt-2">
                    <div className="flex items-center border border-[#C8B28A]/30 bg-[#181613]">
                      <button
                        onClick={() => updateCartQuantity(product.id, quantity - 1)}
                        className="px-2 py-1 text-[#B7B0A3] hover:text-[#FAF8F3]"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="px-3 text-xs font-mono text-[#FAF8F3]">
                        {quantity}
                      </span>
                      <button
                        onClick={() => updateCartQuantity(product.id, quantity + 1)}
                        className="px-2 py-1 text-[#B7B0A3] hover:text-[#FAF8F3]"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>

                    <button
                      onClick={() => removeFromCart(product.id)}
                      className="text-[#B7B0A3] hover:text-rose-400 p-1"
                      aria-label="Remove item"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* FOOTER TOTALS & CHECKOUT */}
        {cart.length > 0 && (
          <div className="p-6 md:p-8 bg-[#11100E] border-t border-[#C8B28A]/20 space-y-4">
            <div className="space-y-2 text-xs text-[#B7B0A3]">
              <div className="flex justify-between">
                <span>SUBTOTAL</span>
                <span className="font-mono text-[#FAF8F3] font-medium">
                  {formatPrice(cartTotalSGD, currency)}
                </span>
              </div>
              <div className="flex justify-between text-[11px] text-[#B7B0A3]/70">
                <span>ESTIMATED SINGAPORE GST (9% INCL.)</span>
                <span className="font-mono">{formatPrice(gstSGD, currency)}</span>
              </div>
              <div className="flex justify-between text-[11px] text-[#B7B0A3]/70">
                <span>ARMORED HAND DELIVERY</span>
                <span className="text-[#C8B28A] font-medium">COMPLIMENTARY</span>
              </div>
              <div className="flex justify-between text-sm font-medium text-[#FAF8F3] pt-2 border-t border-[#C8B28A]/20">
                <span>TOTAL ACQUISITION</span>
                <span className="font-mono text-[#C8B28A] text-base">
                  {formatPrice(cartTotalSGD, currency)}
                </span>
              </div>
            </div>

            <div className="space-y-2 pt-2">
              <button
                onClick={() => {
                  setIsCartOpen(false);
                  onNavigate('/checkout');
                }}
                className="w-full bg-[#C8B28A] hover:bg-[#A78B5A] text-[#11100E] py-4 text-xs uppercase tracking-[0.25em] font-medium transition-colors flex items-center justify-center gap-2 group"
              >
                PROCEED TO CHECKOUT
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                onClick={() => setIsCartOpen(false)}
                className="w-full bg-transparent text-[#B7B0A3] hover:text-[#FAF8F3] py-2 text-center text-[10px] uppercase tracking-[0.2em]"
              >
                CONTINUE SHOPPING
              </button>
            </div>

            <div className="flex items-center justify-center gap-2 text-[10px] text-[#C8B28A] pt-2">
              <Shield className="w-3.5 h-3.5" />
              <span>Singapore Freeport Vault Insured & White-Glove Handled</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
