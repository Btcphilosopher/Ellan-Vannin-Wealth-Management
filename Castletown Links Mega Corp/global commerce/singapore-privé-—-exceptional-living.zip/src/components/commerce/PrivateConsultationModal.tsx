import React, { useState } from 'react';
import { useStore } from '../../lib/store';
import { X, ShieldCheck, Calendar, Clock, MapPin, User, Mail, Phone, MessageSquare, Sparkles } from 'lucide-react';

export const PrivateConsultationModal: React.FC = () => {
  const { isConsultationOpen, setIsConsultationOpen, consultationProduct, requestAppointment, addToast } = useStore();

  const [activeTab, setActiveTab] = useState<'appointment' | 'advisor' | 'viewing' | 'rare'>('appointment');

  // Form fields
  const [clientName, setClientName] = useState('Sir Jonathan Tan');
  const [clientEmail, setClientEmail] = useState('jonathan.tan@prive.sg');
  const [clientPhone, setClientPhone] = useState('+65 9182 8888');
  const [appointmentDate, setAppointmentDate] = useState('2026-09-28');
  const [appointmentTime, setAppointmentTime] = useState('15:00');
  const [location, setLocation] = useState('The Shoppes at Marina Bay Sands Private Salon');
  const [specialNotes, setSpecialNotes] = useState('');

  if (!isConsultationOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    let serviceType = 'Private Client Appointment';
    if (activeTab === 'viewing') serviceType = 'Private Viewing Salon';
    if (activeTab === 'advisor') serviceType = 'Client Director Call';
    if (activeTab === 'rare') serviceType = 'Rare Piece Sourcing Request';

    if (consultationProduct) {
      serviceType += ` (${consultationProduct.brand} ${consultationProduct.name})`;
    }

    requestAppointment(serviceType, appointmentDate, `${appointmentTime} SGT`, location, specialNotes);
    setIsConsultationOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#11100E]/90 backdrop-blur-xl flex items-center justify-center p-4 md:p-8 overflow-y-auto animate-fade-in text-[#F5F1E8]">
      <div className="bg-[#181613] border border-[#C8B28A]/40 max-w-3xl w-full max-h-[90vh] overflow-y-auto relative shadow-2xl p-6 md:p-10 flex flex-col justify-between">
        {/* CLOSE BUTTON */}
        <button
          onClick={() => setIsConsultationOpen(false)}
          className="absolute top-6 right-6 text-[#B7B0A3] hover:text-[#FAF8F3] p-2 transition-colors"
          aria-label="Close Consultation"
        >
          <X className="w-5 h-5" />
        </button>

        <div>
          {/* HEADER */}
          <div className="space-y-2 border-b border-[#C8B28A]/20 pb-6">
            <div className="flex items-center gap-2 text-[#C8B28A]">
              <Sparkles className="w-4 h-4" />
              <span className="text-[10px] uppercase tracking-[0.35em] font-medium">
                PRIVATE CLIENT SERVICES
              </span>
            </div>
            <h2 className="font-serif-luxury text-3xl md:text-4xl text-[#FAF8F3] font-normal">
              Some acquisitions deserve a conversation.
            </h2>
            <p className="text-xs text-[#B7B0A3] font-light max-w-xl">
              Connect with a senior Singapore Privé Client Director for bespoke horological sourcing, private vault viewings, or off-market acquisitions.
            </p>
          </div>

          {/* PRESELECTED PRODUCT PREVIEW IF ANY */}
          {consultationProduct && (
            <div className="mt-6 bg-[#11100E] p-4 border border-[#C8B28A]/30 flex items-center gap-4">
              <img
                src={consultationProduct.images[0]}
                alt={consultationProduct.name}
                className="w-16 h-16 object-cover border border-[#C8B28A]/20"
              />
              <div>
                <span className="text-[9px] uppercase tracking-[0.25em] text-[#C8B28A] block">
                  REGARDING ACQUISITION
                </span>
                <h4 className="font-serif-luxury text-base text-[#FAF8F3]">
                  {consultationProduct.brand} — {consultationProduct.name}
                </h4>
              </div>
            </div>
          )}

          {/* SERVICE TABS */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 my-6">
            <button
              type="button"
              onClick={() => setActiveTab('appointment')}
              className={`py-3 px-3 text-[10px] uppercase tracking-[0.2em] border transition-all text-center ${
                activeTab === 'appointment'
                  ? 'border-[#C8B28A] bg-[#C8B28A] text-[#11100E] font-medium'
                  : 'border-[#C8B28A]/20 text-[#B7B0A3] hover:text-[#FAF8F3] hover:border-[#C8B28A]/40'
              }`}
            >
              PRIVATE APPOINTMENT
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('advisor')}
              className={`py-3 px-3 text-[10px] uppercase tracking-[0.2em] border transition-all text-center ${
                activeTab === 'advisor'
                  ? 'border-[#C8B28A] bg-[#C8B28A] text-[#11100E] font-medium'
                  : 'border-[#C8B28A]/20 text-[#B7B0A3] hover:text-[#FAF8F3] hover:border-[#C8B28A]/40'
              }`}
            >
              SPEAK WITH ADVISOR
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('viewing')}
              className={`py-3 px-3 text-[10px] uppercase tracking-[0.2em] border transition-all text-center ${
                activeTab === 'viewing'
                  ? 'border-[#C8B28A] bg-[#C8B28A] text-[#11100E] font-medium'
                  : 'border-[#C8B28A]/20 text-[#B7B0A3] hover:text-[#FAF8F3] hover:border-[#C8B28A]/40'
              }`}
            >
              PRIVATE VIEWING
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('rare')}
              className={`py-3 px-3 text-[10px] uppercase tracking-[0.2em] border transition-all text-center ${
                activeTab === 'rare'
                  ? 'border-[#C8B28A] bg-[#C8B28A] text-[#11100E] font-medium'
                  : 'border-[#C8B28A]/20 text-[#B7B0A3] hover:text-[#FAF8F3] hover:border-[#C8B28A]/40'
              }`}
            >
              ENQUIRE RARE PIECE
            </button>
          </div>

          {/* FORM */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-[10px] uppercase tracking-[0.2em] text-[#C8B28A] mb-1.5">
                  CLIENT FULL NAME
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-[#B7B0A3] absolute left-3 top-3" />
                  <input
                    type="text"
                    required
                    value={clientName}
                    onChange={(e) => setClientName(e.target.value)}
                    className="w-full bg-[#11100E] border border-[#C8B28A]/30 pl-10 pr-4 py-2.5 text-xs text-[#FAF8F3] focus:outline-none focus:border-[#C8B28A]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] uppercase tracking-[0.2em] text-[#C8B28A] mb-1.5">
                  CONFIDENTIAL EMAIL
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-[#B7B0A3] absolute left-3 top-3" />
                  <input
                    type="email"
                    required
                    value={clientEmail}
                    onChange={(e) => setClientEmail(e.target.value)}
                    className="w-full bg-[#11100E] border border-[#C8B28A]/30 pl-10 pr-4 py-2.5 text-xs text-[#FAF8F3] focus:outline-none focus:border-[#C8B28A]"
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-[10px] uppercase tracking-[0.2em] text-[#C8B28A] mb-1.5">
                  TELEPHONE / WHATSAPP
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-[#B7B0A3] absolute left-3 top-3" />
                  <input
                    type="text"
                    required
                    value={clientPhone}
                    onChange={(e) => setClientPhone(e.target.value)}
                    className="w-full bg-[#11100E] border border-[#C8B28A]/30 pl-10 pr-4 py-2.5 text-xs text-[#FAF8F3] focus:outline-none focus:border-[#C8B28A]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] uppercase tracking-[0.2em] text-[#C8B28A] mb-1.5">
                  PREFERRED DATE
                </label>
                <div className="relative">
                  <Calendar className="w-4 h-4 text-[#B7B0A3] absolute left-3 top-3" />
                  <input
                    type="date"
                    required
                    value={appointmentDate}
                    onChange={(e) => setAppointmentDate(e.target.value)}
                    className="w-full bg-[#11100E] border border-[#C8B28A]/30 pl-10 pr-4 py-2.5 text-xs text-[#FAF8F3] focus:outline-none focus:border-[#C8B28A]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] uppercase tracking-[0.2em] text-[#C8B28A] mb-1.5">
                  PREFERRED TIME (SGT)
                </label>
                <div className="relative">
                  <Clock className="w-4 h-4 text-[#B7B0A3] absolute left-3 top-3" />
                  <select
                    value={appointmentTime}
                    onChange={(e) => setAppointmentTime(e.target.value)}
                    className="w-full bg-[#11100E] border border-[#C8B28A]/30 pl-10 pr-4 py-2.5 text-xs text-[#FAF8F3] focus:outline-none focus:border-[#C8B28A]"
                  >
                    <option value="10:00">10:00 SGT (Morning)</option>
                    <option value="12:00">12:00 SGT (Midday)</option>
                    <option value="15:00">15:00 SGT (Afternoon)</option>
                    <option value="18:00">18:00 SGT (Evening)</option>
                    <option value="20:00">20:00 SGT (Private After-Hours)</option>
                  </select>
                </div>
              </div>
            </div>

            <div>
              <label className="block text-[10px] uppercase tracking-[0.2em] text-[#C8B28A] mb-1.5">
                PREFERRED LOCATION
              </label>
              <div className="relative">
                <MapPin className="w-4 h-4 text-[#B7B0A3] absolute left-3 top-3" />
                <select
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="w-full bg-[#11100E] border border-[#C8B28A]/30 pl-10 pr-4 py-2.5 text-xs text-[#FAF8F3] focus:outline-none focus:border-[#C8B28A]"
                >
                  <option value="The Shoppes at Marina Bay Sands Private Salon">
                    The Shoppes at Marina Bay Sands — Level 1 Private Salon
                  </option>
                  <option value="Singapore Freeport Bonded Vault">
                    Singapore Freeport Bonded Vault — Changi Airport
                  </option>
                  <option value="Client Private Residence / Residence Suite">
                    Client Private Residence (Armored Courier Escort)
                  </option>
                  <option value="Confidential Virtual Consultation">
                    Encrypted Video Consultation
                  </option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-[10px] uppercase tracking-[0.2em] text-[#C8B28A] mb-1.5">
                SPECIAL REQUESTS OR SPECIFIC REFERENCES
              </label>
              <textarea
                rows={3}
                value={specialNotes}
                onChange={(e) => setSpecialNotes(e.target.value)}
                placeholder="Indicate desired horological complications, ring sizes, or vintage preferences..."
                className="w-full bg-[#11100E] border border-[#C8B28A]/30 p-3 text-xs text-[#FAF8F3] placeholder-[#B7B0A3]/40 focus:outline-none focus:border-[#C8B28A]"
              ></textarea>
            </div>

            <div className="pt-4 flex items-center justify-between">
              <div className="flex items-center gap-2 text-[10px] text-[#C8B28A]">
                <ShieldCheck className="w-4 h-4" />
                <span>Strictly Confidential & Non-Binding</span>
              </div>

              <button
                type="submit"
                className="bg-[#C8B28A] hover:bg-[#A78B5A] text-[#11100E] px-8 py-3.5 text-xs uppercase tracking-[0.25em] font-medium transition-colors"
              >
                REQUEST APPOINTMENT →
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
