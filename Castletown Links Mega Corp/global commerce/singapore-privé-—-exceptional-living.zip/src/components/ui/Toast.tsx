import React from 'react';
import { useStore } from '../../lib/store';
import { X, CheckCircle2, Info, Sparkles } from 'lucide-react';

export const ToastContainer: React.FC = () => {
  const { toasts, removeToast } = useStore();

  if (toasts.length === 0) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-3 max-w-md w-full px-4 pointer-events-none">
      {toasts.map((toast) => (
        <div
          key={toast.id}
          className="pointer-events-auto flex items-start gap-4 p-5 rounded-none bg-[#181613]/95 backdrop-blur-md border border-[#C8B28A]/40 shadow-2xl text-[#F5F1E8] transition-all duration-300 animate-slide-up"
        >
          <div className="mt-0.5 text-[#C8B28A]">
            {toast.type === 'gold' ? (
              <Sparkles className="w-5 h-5 text-[#C8B28A]" />
            ) : toast.type === 'success' ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            ) : (
              <Info className="w-5 h-5 text-[#B7B0A3]" />
            )}
          </div>
          <div className="flex-1">
            <h4 className="text-xs uppercase tracking-[0.2em] font-medium text-[#C8B28A]">
              {toast.title}
            </h4>
            {toast.description && (
              <p className="mt-1 text-xs text-[#B7B0A3] leading-relaxed font-light">
                {toast.description}
              </p>
            )}
          </div>
          <button
            onClick={() => removeToast(toast.id)}
            className="text-[#B7B0A3] hover:text-[#F5F1E8] transition-colors p-1"
            aria-label="Dismiss notification"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      ))}
    </div>
  );
};
