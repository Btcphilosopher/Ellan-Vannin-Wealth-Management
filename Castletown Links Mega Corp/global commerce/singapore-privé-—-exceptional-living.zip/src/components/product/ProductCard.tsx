import React from 'react';
import { Product } from '../../types';
import { useStore } from '../../lib/store';
import { formatPrice } from '../../lib/currency';
import { Heart, Eye, ShoppingBag, MessageSquare } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  onNavigate: (path: string) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onNavigate }) => {
  const {
    currency,
    addToCart,
    toggleWishlist,
    isInWishlist,
    setQuickViewProduct,
    openConsultation
  } = useStore();

  const isSaved = isInWishlist(product.id);

  return (
    <div className="group bg-[#181613] border border-[#C8B28A]/20 hover:border-[#C8B28A]/70 transition-all duration-500 flex flex-col h-full relative">
      {/* IMAGE CONTAINER */}
      <div className="relative aspect-[4/5] bg-[#11100E] overflow-hidden cursor-pointer" onClick={() => onNavigate(`/product/${product.slug}`)}>
        <img
          src={product.images[0]}
          alt={product.name}
          className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 ease-out"
          loading="lazy"
        />

        {/* Secondary Image hover reveal */}
        {product.images[1] && (
          <img
            src={product.images[1]}
            alt={`${product.name} alternate angle`}
            className="w-full h-full object-cover object-center absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-700 ease-out"
            loading="lazy"
          />
        )}

        {/* Availability Badge */}
        <div className="absolute top-3 left-3 z-10">
          {product.availability === 'limited' ? (
            <span className="text-[9px] uppercase tracking-[0.25em] bg-[#181613]/90 text-[#C8B28A] px-2.5 py-1 border border-[#C8B28A]/40 backdrop-blur-md">
              LIMITED ALLOCATION
            </span>
          ) : product.availability === 'sold-out' ? (
            <span className="text-[9px] uppercase tracking-[0.25em] bg-[#11100E]/90 text-rose-300 px-2.5 py-1 border border-rose-500/30 backdrop-blur-md">
              RESERVED
            </span>
          ) : (
            <span className="text-[9px] uppercase tracking-[0.25em] bg-[#11100E]/80 text-[#FAF8F3] px-2.5 py-1 border border-[#FAF8F3]/20 backdrop-blur-md">
              AVAILABLE
            </span>
          )}
        </div>

        {/* WISHLIST BUTTON */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            toggleWishlist(product);
          }}
          className={`absolute top-3 right-3 z-10 p-2 rounded-full backdrop-blur-md transition-all duration-300 ${
            isSaved
              ? 'bg-[#C8B28A] text-[#11100E]'
              : 'bg-[#11100E]/70 text-[#FAF8F3] hover:text-[#C8B28A] hover:bg-[#11100E]'
          }`}
          aria-label="Add to Wishlist"
        >
          <Heart className={`w-4 h-4 ${isSaved ? 'fill-current' : ''}`} />
        </button>

        {/* HOVER QUICK ACTIONS OVERLAY */}
        <div className="absolute inset-x-0 bottom-0 p-3 bg-gradient-to-t from-[#11100E] via-[#11100E]/80 to-transparent translate-y-full group-hover:translate-y-0 transition-transform duration-300 flex items-center justify-center gap-2 z-20">
          <button
            onClick={(e) => {
              e.stopPropagation();
              setQuickViewProduct(product);
            }}
            className="flex-1 bg-[#181613]/90 hover:bg-[#FAF8F3] hover:text-[#11100E] text-[#FAF8F3] border border-[#C8B28A]/40 text-[10px] uppercase tracking-[0.2em] py-2.5 px-3 transition-colors flex items-center justify-center gap-1.5"
          >
            <Eye className="w-3.5 h-3.5" />
            QUICK VIEW
          </button>
        </div>
      </div>

      {/* CARD CONTENT */}
      <div className="p-6 flex flex-col flex-1 justify-between space-y-4">
        <div className="space-y-1">
          <span className="text-[10px] uppercase tracking-[0.3em] text-[#C8B28A] font-medium block">
            {product.brand}
          </span>
          <h3
            onClick={() => onNavigate(`/product/${product.slug}`)}
            className="font-serif-luxury text-lg text-[#FAF8F3] group-hover:text-[#C8B28A] transition-colors cursor-pointer line-clamp-1 leading-snug"
          >
            {product.name}
          </h3>
          {product.subtitle && (
            <p className="text-xs text-[#B7B0A3] font-light line-clamp-1">
              {product.subtitle}
            </p>
          )}
        </div>

        <div className="pt-3 border-t border-[#C8B28A]/15 flex items-center justify-between">
          <div>
            <span className="text-[9px] uppercase tracking-[0.2em] text-[#B7B0A3]/70 block">
              ACQUISITION PRICE
            </span>
            <span className="font-mono text-sm text-[#FAF8F3] font-medium">
              {formatPrice(product.priceSGD, currency)}
            </span>
          </div>

          <div>
            {product.availability === 'sold-out' ? (
              <button
                onClick={() => openConsultation(product)}
                className="text-[10px] uppercase tracking-[0.2em] text-[#C8B28A] border border-[#C8B28A]/40 px-3 py-1.5 hover:bg-[#C8B28A] hover:text-[#11100E] transition-all flex items-center gap-1"
              >
                <MessageSquare className="w-3 h-3" />
                ENQUIRE
              </button>
            ) : (
              <button
                onClick={() => addToCart(product)}
                className="text-[10px] uppercase tracking-[0.2em] bg-[#C8B28A] text-[#11100E] px-3.5 py-1.5 hover:bg-[#A78B5A] transition-colors font-medium flex items-center gap-1"
              >
                <ShoppingBag className="w-3 h-3" />
                ADD TO BAG
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
