import React, { useState } from 'react';
import { useStore } from '../../lib/store';
import { formatPrice } from '../../lib/currency';
import { X, Heart, ShoppingBag, MessageSquare, ShieldCheck, ArrowRight, Check } from 'lucide-react';

interface QuickViewModalProps {
  onNavigate: (path: string) => void;
}

export const QuickViewModal: React.FC<QuickViewModalProps> = ({ onNavigate }) => {
  const {
    quickViewProduct,
    setQuickViewProduct,
    currency,
    addToCart,
    toggleWishlist,
    isInWishlist,
    openConsultation
  } = useStore();

  const [activeImageIndex, setActiveImageIndex] = useState(0);

  if (!quickViewProduct) return null;

  const isSaved = isInWishlist(quickViewProduct.id);

  return (
    <div className="fixed inset-0 z-50 bg-[#11100E]/90 backdrop-blur-xl flex items-center justify-center p-4 md:p-8 overflow-y-auto animate-fade-in">
      <div className="bg-[#181613] border border-[#C8B28A]/30 max-w-4xl w-full max-h-[90vh] overflow-y-auto relative text-[#F5F1E8] shadow-2xl flex flex-col md:flex-row">
        {/* CLOSE BUTTON */}
        <button
          onClick={() => setQuickViewProduct(null)}
          className="absolute top-4 right-4 z-20 bg-[#11100E]/80 text-[#B7B0A3] hover:text-[#FAF8F3] p-2 border border-[#C8B28A]/30 backdrop-blur-md transition-colors"
          aria-label="Close Quick View"
        >
          <X className="w-5 h-5" />
        </button>

        {/* LEFT: GALLERY */}
        <div className="w-full md:w-1/2 p-6 md:p-8 bg-[#11100E] flex flex-col justify-between">
          <div className="aspect-[4/5] relative overflow-hidden mb-4 border border-[#C8B28A]/20">
            <img
              src={quickViewProduct.images[activeImageIndex]}
              alt={quickViewProduct.name}
              className="w-full h-full object-cover"
            />
          </div>

          {/* THUMBNAILS */}
          {quickViewProduct.images.length > 1 && (
            <div className="flex gap-2 overflow-x-auto pb-2">
              {quickViewProduct.images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveImageIndex(idx)}
                  className={`w-16 h-16 shrink-0 border transition-all ${
                    activeImageIndex === idx ? 'border-[#C8B28A] scale-105' : 'border-[#C8B28A]/20 opacity-60 hover:opacity-100'
                  }`}
                >
                  <img src={img} alt={`Thumbnail ${idx}`} className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* RIGHT: DETAILS */}
        <div className="w-full md:w-1/2 p-6 md:p-8 flex flex-col justify-between space-y-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs uppercase tracking-[0.3em] text-[#C8B28A] font-medium">
                {quickViewProduct.brand}
              </span>
              <span className="text-[10px] uppercase tracking-[0.2em] text-[#FAF8F3]/70 bg-[#11100E] px-2.5 py-1 border border-[#C8B28A]/20">
                {quickViewProduct.availability}
              </span>
            </div>

            <h2 className="font-serif-luxury text-2xl md:text-3xl text-[#FAF8F3]">
              {quickViewProduct.name}
            </h2>

            <div className="text-xl font-mono text-[#C8B28A] font-medium border-b border-[#C8B28A]/20 pb-4">
              {formatPrice(quickViewProduct.priceSGD, currency)}
            </div>

            <p className="text-xs text-[#B7B0A3] leading-relaxed font-light line-clamp-4">
              {quickViewProduct.description}
            </p>

            {/* KEY SPECS */}
            <div className="bg-[#11100E] p-4 border border-[#C8B28A]/20 space-y-2 text-xs">
              <span className="text-[10px] uppercase tracking-[0.2em] text-[#C8B28A] block mb-1">
                SPECIFICATIONS PREVIEW
              </span>
              {Object.entries(quickViewProduct.specifications).slice(0, 3).map(([key, val]) => (
                <div key={key} className="flex justify-between text-[#B7B0A3]">
                  <span>{key}:</span>
                  <span className="text-[#FAF8F3] font-medium">{val}</span>
                </div>
              ))}
            </div>

            <div className="flex items-center gap-2 text-xs text-[#C8B28A]">
              <ShieldCheck className="w-4 h-4" />
              <span>{quickViewProduct.provenance.authenticityGuarantee}</span>
            </div>
          </div>

          {/* ACTIONS */}
          <div className="space-y-3 pt-4 border-t border-[#C8B28A]/20">
            <div className="flex gap-3">
              <button
                onClick={() => {
                  addToCart(quickViewProduct);
                  setQuickViewProduct(null);
                }}
                className="flex-1 bg-[#C8B28A] hover:bg-[#A78B5A] text-[#11100E] py-3.5 text-xs uppercase tracking-[0.25em] font-medium transition-colors flex items-center justify-center gap-2"
              >
                <ShoppingBag className="w-4 h-4" />
                ADD TO BAG
              </button>

              <button
                onClick={() => toggleWishlist(quickViewProduct)}
                className={`p-3.5 border transition-colors ${
                  isSaved
                    ? 'border-[#C8B28A] bg-[#C8B28A] text-[#11100E]'
                    : 'border-[#C8B28A]/40 text-[#FAF8F3] hover:text-[#C8B28A]'
                }`}
                aria-label="Wishlist"
              >
                <Heart className={`w-4 h-4 ${isSaved ? 'fill-current' : ''}`} />
              </button>
            </div>

            <button
              onClick={() => {
                setQuickViewProduct(null);
                openConsultation(quickViewProduct);
              }}
              className="w-full bg-[#11100E] hover:bg-[#2A2621] text-[#FAF8F3] border border-[#C8B28A]/40 py-3 text-xs uppercase tracking-[0.2em] transition-colors flex items-center justify-center gap-2"
            >
              <MessageSquare className="w-4 h-4 text-[#C8B28A]" />
              REQUEST PRIVATE CONSULTATION
            </button>

            <button
              onClick={() => {
                const slug = quickViewProduct.slug;
                setQuickViewProduct(null);
                onNavigate(`/product/${slug}`);
              }}
              className="w-full text-center text-[10px] uppercase tracking-[0.25em] text-[#C8B28A] hover:underline pt-2 block"
            >
              VIEW FULL DETAILS & PROVENANCE STORY →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
