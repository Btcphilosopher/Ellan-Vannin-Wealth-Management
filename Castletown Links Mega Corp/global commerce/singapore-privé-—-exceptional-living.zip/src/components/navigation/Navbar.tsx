import React, { useState, useEffect } from 'react';
import { useStore } from '../../lib/store';
import { CurrencyCode } from '../../types';
import { CURRENCY_SYMBOLS } from '../../lib/currency';
import { Search, User, Heart, ShoppingBag, Menu, X, ChevronDown } from 'lucide-react';

interface NavbarProps {
  currentPath: string;
  onNavigate: (path: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentPath, onNavigate }) => {
  const {
    currency,
    setCurrency,
    cartCount,
    wishlistIds,
    setIsSearchOpen,
    setIsCartOpen
  } = useStore();

  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isShopDropdownOpen, setIsShopDropdownOpen] = useState(false);
  const [isCurrencyOpen, setIsCurrencyOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 40) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const currencies: CurrencyCode[] = ['SGD', 'USD', 'GBP', 'EUR', 'JPY', 'HKD'];

  const isHeroPage = currentPath === '/';

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-500 ${
          isScrolled || !isHeroPage
            ? 'bg-[#11100E]/90 backdrop-blur-md border-b border-[#C8B28A]/20 py-4 shadow-2xl'
            : 'bg-gradient-to-b from-[#11100E]/80 via-[#11100E]/30 to-transparent py-6'
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 md:px-12 flex items-center justify-between">
          {/* LEFT: LOGO */}
          <button
            onClick={() => {
              onNavigate('/');
              setIsMobileMenuOpen(false);
            }}
            className="flex items-center gap-3 text-left group focus:outline-none"
          >
            {/* Lotus Lotus-inspired Geometric Icon */}
            <div className="relative w-8 h-8 flex items-center justify-center text-[#C8B28A] group-hover:scale-105 transition-transform duration-300">
              <svg viewBox="0 0 100 100" className="w-full h-full fill-current">
                <path d="M50 10 C55 35 75 45 90 50 C75 55 55 65 50 90 C45 65 25 55 10 50 C25 45 45 35 50 10 Z" />
                <path d="M50 25 C58 40 70 48 80 50 C70 52 58 60 50 75 C42 60 30 52 20 50 C30 48 42 40 50 25 Z" opacity="0.6" />
                <circle cx="50" cy="50" r="4" className="fill-[#FAF8F3]" />
              </svg>
            </div>
            <div className="flex flex-col">
              <span className="font-serif-luxury text-lg md:text-xl font-normal tracking-[0.25em] text-[#FAF8F3] group-hover:text-[#C8B28A] transition-colors leading-none">
                SINGAPORE PRIVÉ
              </span>
              <span className="text-[9px] uppercase tracking-[0.35em] text-[#C8B28A] font-light mt-1">
                EXCEPTIONAL LIVING
              </span>
            </div>
          </button>

          {/* CENTER: DESKTOP NAVIGATION */}
          <nav className="hidden lg:flex items-center gap-8">
            <button
              onClick={() => onNavigate('/')}
              className={`text-xs uppercase tracking-[0.22em] font-medium transition-colors py-1 ${
                currentPath === '/' ? 'text-[#C8B28A] border-b border-[#C8B28A]' : 'text-[#FAF8F3]/80 hover:text-[#C8B28A]'
              }`}
            >
              HOME
            </button>

            {/* SHOP WITH DROPDOWN */}
            <div
              className="relative"
              onMouseEnter={() => setIsShopDropdownOpen(true)}
              onMouseLeave={() => setIsShopDropdownOpen(false)}
            >
              <button
                onClick={() => onNavigate('/shop')}
                className={`flex items-center gap-1 text-xs uppercase tracking-[0.22em] font-medium transition-colors py-1 ${
                  currentPath.startsWith('/shop') ? 'text-[#C8B28A] border-b border-[#C8B28A]' : 'text-[#FAF8F3]/80 hover:text-[#C8B28A]'
                }`}
              >
                SHOP
                <ChevronDown className="w-3 h-3 text-[#C8B28A]" />
              </button>

              {isShopDropdownOpen && (
                <div className="absolute top-full left-0 mt-2 w-56 bg-[#181613] border border-[#C8B28A]/30 p-4 shadow-2xl backdrop-blur-lg flex flex-col gap-2 transition-all duration-300">
                  <button
                    onClick={() => {
                      onNavigate('/shop');
                      setIsShopDropdownOpen(false);
                    }}
                    className="text-left text-xs uppercase tracking-[0.2em] text-[#FAF8F3] hover:text-[#C8B28A] py-1.5 border-b border-[#C8B28A]/10"
                  >
                    ALL COLLECTIONS
                  </button>
                  <button
                    onClick={() => {
                      onNavigate('/shop/watches');
                      setIsShopDropdownOpen(false);
                    }}
                    className="text-left text-xs uppercase tracking-[0.2em] text-[#B7B0A3] hover:text-[#C8B28A] py-1.5"
                  >
                    HAUTE HORLOGERIE
                  </button>
                  <button
                    onClick={() => {
                      onNavigate('/shop/fashion');
                      setIsShopDropdownOpen(false);
                    }}
                    className="text-left text-xs uppercase tracking-[0.2em] text-[#B7B0A3] hover:text-[#C8B28A] py-1.5"
                  >
                    BESPOKE FASHION
                  </button>
                  <button
                    onClick={() => {
                      onNavigate('/shop/jewellery');
                      setIsShopDropdownOpen(false);
                    }}
                    className="text-left text-xs uppercase tracking-[0.2em] text-[#B7B0A3] hover:text-[#C8B28A] py-1.5"
                  >
                    FINE JEWELLERY
                  </button>
                  <button
                    onClick={() => {
                      onNavigate('/shop/art');
                      setIsShopDropdownOpen(false);
                    }}
                    className="text-left text-xs uppercase tracking-[0.2em] text-[#B7B0A3] hover:text-[#C8B28A] py-1.5"
                  >
                    ART & COLLECTIBLES
                  </button>
                </div>
              )}
            </div>

            <button
              onClick={() => onNavigate('/brands')}
              className={`text-xs uppercase tracking-[0.22em] font-medium transition-colors py-1 ${
                currentPath.startsWith('/brands') ? 'text-[#C8B28A] border-b border-[#C8B28A]' : 'text-[#FAF8F3]/80 hover:text-[#C8B28A]'
              }`}
            >
              BRANDS
            </button>

            <button
              onClick={() => onNavigate('/singapore-edit')}
              className={`text-xs uppercase tracking-[0.22em] font-medium transition-colors py-1 ${
                currentPath === '/singapore-edit' ? 'text-[#C8B28A] border-b border-[#C8B28A]' : 'text-[#FAF8F3]/80 hover:text-[#C8B28A]'
              }`}
            >
              THE SINGAPORE EDIT
            </button>

            <button
              onClick={() => onNavigate('/about')}
              className={`text-xs uppercase tracking-[0.22em] font-medium transition-colors py-1 ${
                currentPath === '/about' ? 'text-[#C8B28A] border-b border-[#C8B28A]' : 'text-[#FAF8F3]/80 hover:text-[#C8B28A]'
              }`}
            >
              ABOUT
            </button>
          </nav>

          {/* RIGHT: CURRENCY & ACTION ICONS */}
          <div className="flex items-center gap-5 md:gap-6">
            {/* Currency Selector Dropdown */}
            <div className="relative">
              <button
                onClick={() => setIsCurrencyOpen(!isCurrencyOpen)}
                className="flex items-center gap-1 text-[11px] uppercase tracking-[0.2em] text-[#C8B28A] hover:text-[#FAF8F3] transition-colors py-1 border-b border-[#C8B28A]/30"
              >
                <span>{currency}</span>
                <ChevronDown className="w-3 h-3" />
              </button>

              {isCurrencyOpen && (
                <div className="absolute top-full right-0 mt-2 w-28 bg-[#181613] border border-[#C8B28A]/30 shadow-2xl py-2 z-50">
                  {currencies.map((code) => (
                    <button
                      key={code}
                      onClick={() => {
                        setCurrency(code);
                        setIsCurrencyOpen(false);
                      }}
                      className={`w-full text-left px-4 py-1.5 text-[11px] tracking-[0.2em] transition-colors ${
                        currency === code ? 'text-[#C8B28A] bg-[#2A2621]/50 font-medium' : 'text-[#B7B0A3] hover:text-[#FAF8F3]'
                      }`}
                    >
                      {code} ({CURRENCY_SYMBOLS[code].trim()})
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Search Trigger */}
            <button
              onClick={() => setIsSearchOpen(true)}
              className="text-[#FAF8F3] hover:text-[#C8B28A] transition-colors p-1"
              aria-label="Search Singapore Privé"
            >
              <Search className="w-5 h-5 stroke-[1.5]" />
            </button>

            {/* Account Link */}
            <button
              onClick={() => onNavigate('/account')}
              className={`transition-colors p-1 ${
                currentPath === '/account' ? 'text-[#C8B28A]' : 'text-[#FAF8F3] hover:text-[#C8B28A]'
              }`}
              aria-label="My Account"
            >
              <User className="w-5 h-5 stroke-[1.5]" />
            </button>

            {/* Wishlist Link */}
            <button
              onClick={() => onNavigate('/wishlist')}
              className={`relative transition-colors p-1 ${
                currentPath === '/wishlist' ? 'text-[#C8B28A]' : 'text-[#FAF8F3] hover:text-[#C8B28A]'
              }`}
              aria-label="Wishlist"
            >
              <Heart className="w-5 h-5 stroke-[1.5]" />
              {wishlistIds.length > 0 && (
                <span className="absolute -top-1 -right-1.5 bg-[#C8B28A] text-[#11100E] text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                  {wishlistIds.length}
                </span>
              )}
            </button>

            {/* Shopping Bag Trigger */}
            <button
              onClick={() => setIsCartOpen(true)}
              className="relative text-[#FAF8F3] hover:text-[#C8B28A] transition-colors p-1"
              aria-label="Shopping Bag"
            >
              <ShoppingBag className="w-5 h-5 stroke-[1.5]" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1.5 bg-[#C8B28A] text-[#11100E] text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </button>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden text-[#FAF8F3] hover:text-[#C8B28A] transition-colors p-1 ml-1"
              aria-label="Toggle mobile menu"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </header>

      {/* MOBILE MENU DRAWER */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 top-[70px] z-30 bg-[#11100E]/98 backdrop-blur-2xl flex flex-col p-8 border-t border-[#C8B28A]/20 lg:hidden overflow-y-auto animate-fade-in">
          <div className="flex flex-col gap-6 py-6 border-b border-[#C8B28A]/10">
            <button
              onClick={() => {
                onNavigate('/');
                setIsMobileMenuOpen(false);
              }}
              className="text-left text-sm uppercase tracking-[0.3em] font-serif-luxury text-[#FAF8F3] hover:text-[#C8B28A]"
            >
              HOME
            </button>
            <button
              onClick={() => {
                onNavigate('/shop');
                setIsMobileMenuOpen(false);
              }}
              className="text-left text-sm uppercase tracking-[0.3em] font-serif-luxury text-[#FAF8F3] hover:text-[#C8B28A]"
            >
              SHOP ALL COLLECTIONS
            </button>
            <div className="pl-4 flex flex-col gap-3 text-xs uppercase tracking-[0.2em] text-[#B7B0A3]">
              <button
                onClick={() => {
                  onNavigate('/shop/watches');
                  setIsMobileMenuOpen(false);
                }}
                className="text-left hover:text-[#C8B28A]"
              >
                — HAUTE HORLOGERIE
              </button>
              <button
                onClick={() => {
                  onNavigate('/shop/fashion');
                  setIsMobileMenuOpen(false);
                }}
                className="text-left hover:text-[#C8B28A]"
              >
                — BESPOKE FASHION
              </button>
              <button
                onClick={() => {
                  onNavigate('/shop/jewellery');
                  setIsMobileMenuOpen(false);
                }}
                className="text-left hover:text-[#C8B28A]"
              >
                — FINE JEWELLERY
              </button>
              <button
                onClick={() => {
                  onNavigate('/shop/art');
                  setIsMobileMenuOpen(false);
                }}
                className="text-left hover:text-[#C8B28A]"
              >
                — ART & COLLECTIBLES
              </button>
            </div>
            <button
              onClick={() => {
                onNavigate('/brands');
                setIsMobileMenuOpen(false);
              }}
              className="text-left text-sm uppercase tracking-[0.3em] font-serif-luxury text-[#FAF8F3] hover:text-[#C8B28A]"
            >
              BRANDS
            </button>
            <button
              onClick={() => {
                onNavigate('/singapore-edit');
                setIsMobileMenuOpen(false);
              }}
              className="text-left text-sm uppercase tracking-[0.3em] font-serif-luxury text-[#FAF8F3] hover:text-[#C8B28A]"
            >
              THE SINGAPORE EDIT
            </button>
            <button
              onClick={() => {
                onNavigate('/about');
                setIsMobileMenuOpen(false);
              }}
              className="text-left text-sm uppercase tracking-[0.3em] font-serif-luxury text-[#FAF8F3] hover:text-[#C8B28A]"
            >
              ABOUT SINGAPORE PRIVÉ
            </button>
          </div>

          <div className="mt-8 flex flex-col gap-4">
            <span className="text-[10px] uppercase tracking-[0.3em] text-[#C8B28A]">
              CURRENCY SELECTOR
            </span>
            <div className="grid grid-cols-3 gap-2">
              {currencies.map((code) => (
                <button
                  key={code}
                  onClick={() => setCurrency(code)}
                  className={`py-2 text-center text-xs tracking-[0.2em] border transition-colors ${
                    currency === code
                      ? 'border-[#C8B28A] text-[#C8B28A] bg-[#C8B28A]/10'
                      : 'border-[#C8B28A]/20 text-[#B7B0A3]'
                  }`}
                >
                  {code}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </>
  );
};
