import React, { useState, useEffect, useRef } from 'react';
import { useStore } from '../../lib/store';
import { PRODUCTS_DATA } from '../../data/products';
import { formatPrice } from '../../lib/currency';
import { Search, X, ArrowRight, Sparkles } from 'lucide-react';

interface SearchModalProps {
  onNavigate: (path: string) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({ onNavigate }) => {
  const { isSearchOpen, setIsSearchOpen, currency } = useStore();
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isSearchOpen) {
      setTimeout(() => {
        inputRef.current?.focus();
      }, 100);
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto';
    }
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, [isSearchOpen]);

  if (!isSearchOpen) return null;

  const suggestedTerms = [
    'Luxury Watches',
    'Fine Jewellery',
    'Italian Leather',
    'Rolex',
    'Hermès',
    'Patek Philippe',
    'Art',
    'Rare Collectibles'
  ];

  const filteredProducts = query.trim() === ''
    ? []
    : PRODUCTS_DATA.filter((p) => {
        const q = query.toLowerCase();
        return (
          p.name.toLowerCase().includes(q) ||
          p.brand.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q) ||
          (p.subcategory && p.subcategory.toLowerCase().includes(q)) ||
          p.description.toLowerCase().includes(q)
        );
      }).slice(0, 8);

  return (
    <div className="fixed inset-0 z-50 bg-[#11100E]/98 backdrop-blur-2xl flex flex-col p-6 md:p-12 overflow-y-auto animate-fade-in text-[#F5F1E8]">
      <div className="max-w-5xl mx-auto w-full flex-1 flex flex-col">
        {/* TOP BAR */}
        <div className="flex items-center justify-between pb-8 border-b border-[#C8B28A]/20">
          <div className="flex items-center gap-3">
            <Sparkles className="w-5 h-5 text-[#C8B28A]" />
            <span className="text-xs uppercase tracking-[0.3em] font-medium text-[#C8B28A]">
              SINGAPORE PRIVÉ SEARCH
            </span>
          </div>
          <button
            onClick={() => setIsSearchOpen(false)}
            className="flex items-center gap-2 text-xs uppercase tracking-[0.2em] text-[#B7B0A3] hover:text-[#FAF8F3] transition-colors p-2"
          >
            <span>CLOSE</span>
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* INPUT SECTION */}
        <div className="py-12 border-b border-[#C8B28A]/20">
          <div className="relative flex items-center">
            <Search className="w-8 h-8 text-[#C8B28A] absolute left-0" />
            <input
              ref={inputRef}
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="SEARCH SINGAPORE PRIVÉ..."
              className="w-full bg-transparent pl-14 pr-6 text-2xl md:text-4xl font-serif-luxury tracking-wide text-[#FAF8F3] placeholder-[#B7B0A3]/30 focus:outline-none"
            />
            {query && (
              <button
                onClick={() => setQuery('')}
                className="text-[#B7B0A3] hover:text-[#FAF8F3] p-2"
              >
                <X className="w-6 h-6" />
              </button>
            )}
          </div>

          {/* SUGGESTED SEARCHES */}
          <div className="mt-8 flex flex-wrap items-center gap-3">
            <span className="text-[10px] uppercase tracking-[0.25em] text-[#B7B0A3]/80 mr-2">
              SUGGESTED:
            </span>
            {suggestedTerms.map((term) => (
              <button
                key={term}
                onClick={() => setQuery(term)}
                className="text-xs uppercase tracking-[0.2em] text-[#C8B28A] bg-[#181613] border border-[#C8B28A]/30 px-4 py-2 hover:bg-[#C8B28A] hover:text-[#11100E] transition-all"
              >
                {term}
              </button>
            ))}
          </div>
        </div>

        {/* DYNAMIC RESULTS GRID */}
        <div className="py-12 flex-1">
          {query.trim() !== '' && filteredProducts.length === 0 && (
            <div className="text-center py-16 space-y-4">
              <p className="font-serif-luxury text-2xl text-[#FAF8F3]">
                No acquisitions match "{query}"
              </p>
              <p className="text-xs text-[#B7B0A3] max-w-md mx-auto">
                Our private concierge can locate off-market timepieces, rare gemstones, and high art upon confidential request.
              </p>
            </div>
          )}

          {filteredProducts.length > 0 && (
            <div>
              <h4 className="text-xs uppercase tracking-[0.3em] font-medium text-[#C8B28A] mb-8">
                ACQUISITION RESULTS ({filteredProducts.length})
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {filteredProducts.map((product) => (
                  <div
                    key={product.id}
                    onClick={() => {
                      setIsSearchOpen(false);
                      onNavigate(`/product/${product.slug}`);
                    }}
                    className="group bg-[#181613] border border-[#C8B28A]/20 p-4 cursor-pointer hover:border-[#C8B28A] transition-all duration-300 flex flex-col"
                  >
                    <div className="aspect-square bg-[#11100E] overflow-hidden relative mb-4">
                      <img
                        src={product.images[0]}
                        alt={product.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                      <span className="absolute top-2 left-2 text-[9px] uppercase tracking-[0.2em] bg-[#11100E]/80 text-[#C8B28A] px-2 py-0.5 border border-[#C8B28A]/30">
                        {product.category}
                      </span>
                    </div>

                    <span className="text-[10px] uppercase tracking-[0.25em] text-[#C8B28A] font-medium">
                      {product.brand}
                    </span>
                    <h5 className="font-serif-luxury text-sm text-[#FAF8F3] group-hover:text-[#C8B28A] transition-colors mt-1 line-clamp-1">
                      {product.name}
                    </h5>
                    <p className="text-xs text-[#FAF8F3] font-light mt-2 font-mono">
                      {formatPrice(product.priceSGD, currency)}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
