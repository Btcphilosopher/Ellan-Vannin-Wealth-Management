import React, { useState } from 'react';
import { useStore } from '../../lib/store';
import { ArrowRight, ShieldCheck, MapPin, Phone, Mail } from 'lucide-react';

interface FooterProps {
  onNavigate: (path: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const { addToast, openConsultation } = useStore();
  const [email, setEmail] = useState('');

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    addToast(
      'Welcome to the Private List',
      'You have been subscribed to Singapore Privé confidential updates and editorial invitations.',
      'gold'
    );
    setEmail('');
  };

  return (
    <footer className="bg-[#181613] text-[#F5F1E8] border-t border-[#C8B28A]/20 pt-24 pb-12 relative overflow-hidden">
      {/* Subtle Background Lotus Pattern overlay */}
      <div className="absolute inset-0 opacity-[0.02] pointer-events-none flex items-center justify-center">
        <svg viewBox="0 0 100 100" className="w-[800px] h-[800px] fill-[#C8B28A]">
          <path d="M50 10 C55 35 75 45 90 50 C75 55 55 65 50 90 C45 65 25 55 10 50 C25 45 45 35 50 10 Z" />
        </svg>
      </div>

      <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
        {/* TOP NEWSLETTER BANNER */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 pb-20 border-b border-[#C8B28A]/15 items-center">
          <div className="lg:col-span-6">
            <span className="text-[10px] uppercase tracking-[0.35em] text-[#C8B28A] font-medium block mb-2">
              JOIN THE PRIVATE LIST
            </span>
            <h3 className="font-serif-luxury text-3xl md:text-4xl text-[#FAF8F3] font-normal leading-tight">
              Receive carefully selected new arrivals, private invitations and Singapore editorial.
            </h3>
          </div>

          <div className="lg:col-span-6">
            <form onSubmit={handleNewsletterSubmit} className="flex flex-col sm:flex-row gap-0">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="YOUR EMAIL ADDRESS"
                required
                className="bg-[#11100E] border border-[#C8B28A]/30 px-6 py-4 text-xs tracking-[0.2em] text-[#FAF8F3] placeholder-[#B7B0A3]/60 focus:outline-none focus:border-[#C8B28A] flex-1"
              />
              <button
                type="submit"
                className="bg-[#C8B28A] hover:bg-[#A78B5A] text-[#11100E] px-8 py-4 text-xs uppercase tracking-[0.25em] font-medium transition-colors flex items-center justify-center gap-2 group shrink-0 mt-3 sm:mt-0"
              >
                JOIN
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>
            </form>
            <p className="text-[10px] text-[#B7B0A3]/70 tracking-wider mt-3">
              By subscribing you agree to receive confidential communications from Singapore Privé.
            </p>
          </div>
        </div>

        {/* MAIN FOOTER NAVIGATION GRID */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12 py-20 border-b border-[#C8B28A]/15">
          {/* BRAND COLUMN */}
          <div className="lg:col-span-1 space-y-6">
            <div className="flex flex-col">
              <span className="font-serif-luxury text-xl tracking-[0.25em] text-[#FAF8F3]">
                SINGAPORE PRIVÉ
              </span>
              <span className="text-[9px] uppercase tracking-[0.35em] text-[#C8B28A] mt-1">
                EXCEPTIONAL LIVING
              </span>
            </div>
            <p className="text-xs text-[#B7B0A3] font-light leading-relaxed">
              The world's finest goods, curated for Singapore. Haute horlogerie, fine jewellery, bespoke fashion, art, and rare collectibles.
            </p>

            <div className="space-y-3 pt-2 text-xs text-[#B7B0A3]">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#C8B28A] shrink-0 mt-0.5" />
                <span>The Shoppes at Marina Bay Sands, Level 1 Private Salon, 1 Bayfront Ave, Singapore 018971</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-[#C8B28A] shrink-0" />
                <span>+65 6888 8829</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-[#C8B28A] shrink-0" />
                <span>concierge@singaporeprive.sg</span>
              </div>
            </div>
          </div>

          {/* SHOP COLUMN */}
          <div className="space-y-4">
            <h4 className="text-xs uppercase tracking-[0.3em] font-medium text-[#C8B28A]">
              SHOP
            </h4>
            <ul className="space-y-2.5 text-xs text-[#B7B0A3]">
              <li>
                <button onClick={() => onNavigate('/shop/watches')} className="hover:text-[#FAF8F3] transition-colors">
                  Haute Horlogerie
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/shop/fashion')} className="hover:text-[#FAF8F3] transition-colors">
                  Bespoke Fashion
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/shop/jewellery')} className="hover:text-[#FAF8F3] transition-colors">
                  Fine Jewellery
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/shop/art')} className="hover:text-[#FAF8F3] transition-colors">
                  Art & Collectibles
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/brands')} className="hover:text-[#FAF8F3] transition-colors">
                  Featured Houses
                </button>
              </li>
            </ul>
          </div>

          {/* SERVICES COLUMN */}
          <div className="space-y-4">
            <h4 className="text-xs uppercase tracking-[0.3em] font-medium text-[#C8B28A]">
              SERVICES
            </h4>
            <ul className="space-y-2.5 text-xs text-[#B7B0A3]">
              <li>
                <button onClick={() => openConsultation(null)} className="hover:text-[#FAF8F3] transition-colors">
                  Private Client Services
                </button>
              </li>
              <li>
                <button onClick={() => openConsultation(null)} className="hover:text-[#FAF8F3] transition-colors">
                  Private Viewing Salon
                </button>
              </li>
              <li>
                <button onClick={() => openConsultation(null)} className="hover:text-[#FAF8F3] transition-colors">
                  Armored Hand Delivery
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/about')} className="hover:text-[#FAF8F3] transition-colors">
                  Singapore Freeport Vault
                </button>
              </li>
              <li>
                <button onClick={() => openConsultation(null)} className="hover:text-[#FAF8F3] transition-colors">
                  Provenance Guarantee
                </button>
              </li>
            </ul>
          </div>

          {/* ABOUT COLUMN */}
          <div className="space-y-4">
            <h4 className="text-xs uppercase tracking-[0.3em] font-medium text-[#C8B28A]">
              ABOUT
            </h4>
            <ul className="space-y-2.5 text-xs text-[#B7B0A3]">
              <li>
                <button onClick={() => onNavigate('/about')} className="hover:text-[#FAF8F3] transition-colors">
                  Our Story
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/singapore-edit')} className="hover:text-[#FAF8F3] transition-colors">
                  The Singapore Edit
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/brands')} className="hover:text-[#FAF8F3] transition-colors">
                  Brand Directory
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/about')} className="hover:text-[#FAF8F3] transition-colors">
                  Private Client Advisors
                </button>
              </li>
            </ul>
          </div>

          {/* LEGAL COLUMN */}
          <div className="space-y-4">
            <h4 className="text-xs uppercase tracking-[0.3em] font-medium text-[#C8B28A]">
              LEGAL & PRIVACY
            </h4>
            <ul className="space-y-2.5 text-xs text-[#B7B0A3]">
              <li>
                <span className="hover:text-[#FAF8F3] cursor-pointer">Privacy Charter</span>
              </li>
              <li>
                <span className="hover:text-[#FAF8F3] cursor-pointer">Terms of Acquisition</span>
              </li>
              <li>
                <span className="hover:text-[#FAF8F3] cursor-pointer">Singapore Tax & Customs</span>
              </li>
              <li>
                <span className="hover:text-[#FAF8F3] cursor-pointer">Cookie Settings</span>
              </li>
            </ul>
          </div>
        </div>

        {/* BOTTOM COPYRIGHT */}
        <div className="pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-[11px] text-[#B7B0A3]/60 tracking-wider">
          <div>
            © {new Date().getFullYear()} SINGAPORE PRIVÉ PTE. LTD. ALL RIGHTS RESERVED. REGISTERED IN SINGAPORE.
          </div>

          <div className="flex items-center gap-6">
            <span className="flex items-center gap-1.5 text-[#C8B28A]">
              <ShieldCheck className="w-4 h-4" />
              100% Guaranteed Provenance
            </span>
            <span>MARINA BAY • ORCHARD • GENEVA</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
