import { CurrencyCode } from '../types';

export const CURRENCY_SYMBOLS: Record<CurrencyCode, string> = {
  SGD: 'SGD $',
  USD: '$',
  GBP: '£',
  EUR: '€',
  JPY: '¥',
  HKD: 'HK$',
};

export const EXCHANGE_RATES_FROM_SGD: Record<CurrencyCode, number> = {
  SGD: 1.0,
  USD: 0.76,
  GBP: 0.58,
  EUR: 0.69,
  JPY: 112.5,
  HKD: 5.92,
};

export function convertCurrency(amountInSGD: number, targetCurrency: CurrencyCode): number {
  const rate = EXCHANGE_RATES_FROM_SGD[targetCurrency] || 1.0;
  return Math.round(amountInSGD * rate);
}

export function formatPrice(amountInSGD: number, currency: CurrencyCode = 'SGD'): string {
  const converted = convertCurrency(amountInSGD, currency);
  const symbol = CURRENCY_SYMBOLS[currency];

  if (currency === 'JPY') {
    return `${symbol}${converted.toLocaleString('en-US')}`;
  }

  return `${symbol}${converted.toLocaleString('en-US')}`;
}
