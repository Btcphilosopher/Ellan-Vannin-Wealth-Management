import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product, CartItem, CurrencyCode, UserProfile, ToastMessage, OrderRecord, AppointmentRecord } from '../types';

interface StoreContextType {
  // Currency
  currency: CurrencyCode;
  setCurrency: (c: CurrencyCode) => void;

  // Cart
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number) => void;
  removeFromCart: (productId: string) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  cartTotalSGD: number;
  cartCount: number;

  // Wishlist
  wishlistIds: string[];
  toggleWishlist: (product: Product) => void;
  isInWishlist: (productId: string) => boolean;

  // Search Modal
  isSearchOpen: boolean;
  setIsSearchOpen: (open: boolean) => void;

  // Private Consultation Modal
  isConsultationOpen: boolean;
  setIsConsultationOpen: (open: boolean) => void;
  consultationProduct: Product | null;
  openConsultation: (product?: Product | null) => void;

  // Quick View Modal
  quickViewProduct: Product | null;
  setQuickViewProduct: (product: Product | null) => void;

  // Toast Notifications
  toasts: ToastMessage[];
  addToast: (title: string, description?: string, type?: 'success' | 'info' | 'gold') => void;
  removeToast: (id: string) => void;

  // User Profile
  user: UserProfile;
  updateUser: (fields: Partial<UserProfile>) => void;
  placeOrder: (cartItems: CartItem[], deliveryAddress: string) => OrderRecord;
  requestAppointment: (serviceType: string, date: string, time: string, location: string, notes?: string) => AppointmentRecord;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

const DEFAULT_USER: UserProfile = {
  name: 'Sir Jonathan Tan',
  email: 'jonathan.tan@prive.sg',
  phone: '+65 9182 8888',
  membershipStatus: 'Singapore Privé Black Vault Member',
  tierNumber: 'SG-PRIVÉ-00892',
  savedAddresses: [
    {
      id: 'addr-1',
      title: 'Marina Bay Residence',
      addressLine1: '8 Marina Boulevard, Penthouse 62-01',
      addressLine2: 'Marina Bay Suites',
      postalCode: '018981',
      country: 'Singapore',
      isDefault: true
    },
    {
      id: 'addr-2',
      title: 'Nassim Hill Bungalow',
      addressLine1: '12 Nassim Hill',
      postalCode: '258480',
      country: 'Singapore',
      isDefault: false
    }
  ],
  orders: [
    {
      id: 'SG-PRV-99182',
      date: '14 August 2026',
      items: [
        {
          productName: 'Submariner Date 18k Yellow Gold',
          brand: 'Rolex',
          priceFormatted: 'SGD 54,800',
          image: 'https://images.unsplash.com/photo-1547996160-01ff2474867f?q=80&w=600&auto=format&fit=crop',
          quantity: 1
        }
      ],
      totalFormatted: 'SGD 54,800',
      status: 'Hand Delivered',
      deliveryAddress: '8 Marina Boulevard, Penthouse 62-01, Singapore',
      trackingNumber: 'SG-ARM-99182'
    }
  ],
  appointments: [
    {
      id: 'APT-8821',
      serviceType: 'Private Horology Viewing',
      date: '25 September 2026',
      time: '15:00 SGT',
      location: 'The Shoppes at Marina Bay Sands Salon',
      advisorName: 'Mr. Henry Laurent (Senior Vice President)',
      status: 'Confirmed',
      notes: 'Private presentation of Patek Philippe & F.P. Journe timepieces'
    }
  ]
};

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currency, setCurrencyState] = useState<CurrencyCode>(() => {
    const saved = localStorage.getItem('singapore_prive_currency');
    return (saved as CurrencyCode) || 'SGD';
  });

  const setCurrency = (c: CurrencyCode) => {
    setCurrencyState(c);
    localStorage.setItem('singapore_prive_currency', c);
  };

  // Cart
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('singapore_prive_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [isCartOpen, setIsCartOpen] = useState(false);

  useEffect(() => {
    localStorage.setItem('singapore_prive_cart', JSON.stringify(cart));
  }, [cart]);

  // Wishlist
  const [wishlistIds, setWishlistIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('singapore_prive_wishlist');
      return saved ? JSON.parse(saved) : ['w-01', 'f-01', 'j-01'];
    } catch {
      return ['w-01', 'f-01', 'j-01'];
    }
  });

  useEffect(() => {
    localStorage.setItem('singapore_prive_wishlist', JSON.stringify(wishlistIds));
  }, [wishlistIds]);

  // Modals
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isConsultationOpen, setIsConsultationOpen] = useState(false);
  const [consultationProduct, setConsultationProduct] = useState<Product | null>(null);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);

  // Toasts
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = (title: string, description?: string, type: 'success' | 'info' | 'gold' = 'gold') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, title, description, type }]);
    setTimeout(() => {
      removeToast(id);
    }, 4500);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // User
  const [user, setUser] = useState<UserProfile>(DEFAULT_USER);

  const updateUser = (fields: Partial<UserProfile>) => {
    setUser((prev) => ({ ...prev, ...fields }));
  };

  const addToCart = (product: Product, quantity: number = 1) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { product, quantity }];
    });
    addToast(
      'Added to Private Bag',
      `${product.brand} — ${product.name} has been reserved in your shopping bag.`,
      'gold'
    );
    setIsCartOpen(true);
  };

  const removeFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const updateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) =>
        item.product.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const clearCart = () => {
    setCart([]);
  };

  const cartTotalSGD = cart.reduce(
    (sum, item) => sum + item.product.priceSGD * item.quantity,
    0
  );

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const toggleWishlist = (product: Product) => {
    const exists = wishlistIds.includes(product.id);
    if (exists) {
      setWishlistIds((prev) => prev.filter((id) => id !== product.id));
      addToast('Removed from Wishlist', `${product.name} removed.`, 'info');
    } else {
      setWishlistIds((prev) => [...prev, product.id]);
      addToast(
        'Added to Private Collection',
        `${product.brand} — ${product.name} saved to your wishlist.`,
        'gold'
      );
    }
  };

  const isInWishlist = (productId: string) => wishlistIds.includes(productId);

  const openConsultation = (product: Product | null = null) => {
    setConsultationProduct(product);
    setIsConsultationOpen(true);
  };

  const placeOrder = (cartItems: CartItem[], deliveryAddress: string): OrderRecord => {
    const orderId = `SG-PRV-${Math.floor(10000 + Math.random() * 90000)}`;
    const totalSGD = cartItems.reduce((sum, i) => sum + i.product.priceSGD * i.quantity, 0);

    const newOrder: OrderRecord = {
      id: orderId,
      date: new Date().toLocaleDateString('en-SG', { day: 'numeric', month: 'long', year: 'numeric' }),
      items: cartItems.map((item) => ({
        productName: item.product.name,
        brand: item.product.brand,
        priceFormatted: `SGD ${item.product.priceSGD.toLocaleString()}`,
        image: item.product.images[0],
        quantity: item.quantity
      })),
      totalFormatted: `SGD ${totalSGD.toLocaleString()}`,
      status: 'In Private Courier Transit',
      deliveryAddress,
      trackingNumber: `SG-ARM-${Math.floor(100000 + Math.random() * 900000)}`
    };

    setUser((prev) => ({
      ...prev,
      orders: [newOrder, ...prev.orders]
    }));

    clearCart();
    return newOrder;
  };

  const requestAppointment = (
    serviceType: string,
    date: string,
    time: string,
    location: string,
    notes?: string
  ): AppointmentRecord => {
    const newAppointment: AppointmentRecord = {
      id: `APT-${Math.floor(1000 + Math.random() * 9000)}`,
      serviceType,
      date,
      time,
      location,
      advisorName: 'Mr. Henry Laurent (Senior Client Director)',
      status: 'Confirmed',
      notes
    };

    setUser((prev) => ({
      ...prev,
      appointments: [newAppointment, ...prev.appointments]
    }));

    addToast(
      'Private Appointment Requested',
      `Your advisor will confirm details for ${date} at ${time}.`,
      'gold'
    );

    return newAppointment;
  };

  return (
    <StoreContext.Provider
      value={{
        currency,
        setCurrency,
        cart,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        isCartOpen,
        setIsCartOpen,
        cartTotalSGD,
        cartCount,
        wishlistIds,
        toggleWishlist,
        isInWishlist,
        isSearchOpen,
        setIsSearchOpen,
        isConsultationOpen,
        setIsConsultationOpen,
        consultationProduct,
        openConsultation,
        quickViewProduct,
        setQuickViewProduct,
        toasts,
        addToast,
        removeToast,
        user,
        updateUser,
        placeOrder,
        requestAppointment
      }}
    >
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
};
