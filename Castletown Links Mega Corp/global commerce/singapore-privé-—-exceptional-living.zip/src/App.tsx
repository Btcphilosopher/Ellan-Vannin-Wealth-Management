import React, { useState, useEffect } from 'react';
import { StoreProvider } from './lib/store';
import { Navbar } from './components/navigation/Navbar';
import { Footer } from './components/navigation/Footer';
import { SearchModal } from './components/navigation/SearchModal';
import { QuickViewModal } from './components/product/QuickViewModal';
import { CartDrawer } from './components/commerce/CartDrawer';
import { PrivateConsultationModal } from './components/commerce/PrivateConsultationModal';
import { ToastContainer } from './components/ui/Toast';

import { HomePage } from './pages/HomePage';
import { ShopPage } from './pages/ShopPage';
import { ProductDetailPage } from './pages/ProductDetailPage';
import { BrandsPage } from './pages/BrandsPage';
import { EditorialPage } from './pages/EditorialPage';
import { AboutPage } from './pages/AboutPage';
import { WishlistPage } from './pages/WishlistPage';
import { CheckoutPage } from './pages/CheckoutPage';
import { AccountPage } from './pages/AccountPage';

function AppContent() {
  const [currentPath, setCurrentPath] = useState('/');

  // Scroll to top on path change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentPath]);

  const handleNavigate = (path: string) => {
    setCurrentPath(path);
  };

  // ROUTER LOGIC
  const renderCurrentPage = () => {
    if (currentPath === '/') {
      return <HomePage onNavigate={handleNavigate} />;
    }

    if (currentPath === '/shop') {
      return <ShopPage initialCategory="all" onNavigate={handleNavigate} />;
    }

    if (currentPath === '/shop/watches') {
      return <ShopPage initialCategory="watches" onNavigate={handleNavigate} />;
    }

    if (currentPath === '/shop/fashion') {
      return <ShopPage initialCategory="fashion" onNavigate={handleNavigate} />;
    }

    if (currentPath === '/shop/jewellery') {
      return <ShopPage initialCategory="jewellery" onNavigate={handleNavigate} />;
    }

    if (currentPath === '/shop/art') {
      return <ShopPage initialCategory="art" onNavigate={handleNavigate} />;
    }

    if (currentPath.startsWith('/product/')) {
      const slug = currentPath.replace('/product/', '');
      return <ProductDetailPage slug={slug} onNavigate={handleNavigate} />;
    }

    if (currentPath === '/brands') {
      return <BrandsPage onNavigate={handleNavigate} />;
    }

    if (currentPath.startsWith('/brands/')) {
      const brandSlug = currentPath.replace('/brands/', '');
      return <BrandsPage selectedBrandSlug={brandSlug} onNavigate={handleNavigate} />;
    }

    if (currentPath === '/singapore-edit') {
      return <EditorialPage onNavigate={handleNavigate} />;
    }

    if (currentPath === '/about') {
      return <AboutPage onNavigate={handleNavigate} />;
    }

    if (currentPath === '/wishlist') {
      return <WishlistPage onNavigate={handleNavigate} />;
    }

    if (currentPath === '/checkout') {
      return <CheckoutPage onNavigate={handleNavigate} />;
    }

    if (currentPath === '/account') {
      return <AccountPage onNavigate={handleNavigate} />;
    }

    // Default Fallback
    return <HomePage onNavigate={handleNavigate} />;
  };

  return (
    <div className="min-h-screen bg-[#11100E] text-[#F5F1E8] font-sans antialiased selection:bg-[#C8B28A] selection:text-[#11100E] flex flex-col justify-between">
      {/* GLOBAL TOP NAVIGATION */}
      <Navbar currentPath={currentPath} onNavigate={handleNavigate} />

      {/* ACTIVE PAGE CONTENT */}
      <main className="flex-1">{renderCurrentPage()}</main>

      {/* GLOBAL EDITORIAL FOOTER */}
      <Footer onNavigate={handleNavigate} />

      {/* OVERLAY MODALS & DRAWERS */}
      <SearchModal onNavigate={handleNavigate} />
      <QuickViewModal onNavigate={handleNavigate} />
      <CartDrawer onNavigate={handleNavigate} />
      <PrivateConsultationModal />
      <ToastContainer />
    </div>
  );
}

export default function App() {
  return (
    <StoreProvider>
      <AppContent />
    </StoreProvider>
  );
}
