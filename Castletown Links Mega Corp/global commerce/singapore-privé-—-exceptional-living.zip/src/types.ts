export type Category = 'watches' | 'fashion' | 'jewellery' | 'art';

export type AvailabilityStatus = 'available' | 'limited' | 'sold-out';

export type CurrencyCode = 'SGD' | 'USD' | 'GBP' | 'EUR' | 'JPY' | 'HKD';

export interface Product {
  id: string;
  slug: string;
  brand: string;
  brandSlug: string;
  name: string;
  subtitle?: string;
  category: Category;
  subcategory?: string;
  priceSGD: number; // Stored in base SGD currency
  images: string[];
  description: string;
  story?: string;
  specifications: Record<string, string>;
  provenance: {
    origin: string;
    year: string;
    certificate: string;
    authenticityGuarantee: string;
  };
  availability: AvailabilityStatus;
  limitedEditionNumber?: string;
  featuredInSingaporeEdit?: boolean;
  tags?: string[];
  isDemonstrationData: boolean;
}

export interface Brand {
  id: string;
  slug: string;
  name: string;
  category: Category | 'automotive' | 'design' | 'collectibles';
  country: string;
  founded: string;
  heroImage: string;
  logoText: string;
  description: string;
  philosophy: string;
  flagshipLocation: string;
}

export interface EditorialArticle {
  id: string;
  slug: string;
  title: string;
  categoryTag: string;
  subtitle: string;
  excerpt: string;
  author: string;
  readTime: string;
  heroImage: string;
  secondaryImages: string[];
  contentParagraphs: string[];
  featuredProductsSlugs: string[];
  publishedDate: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface UserProfile {
  name: string;
  email: string;
  phone: string;
  membershipStatus: string; // e.g., 'Singapore Privé Black Vault'
  tierNumber: string;
  savedAddresses: Array<{
    id: string;
    title: string;
    addressLine1: string;
    addressLine2?: string;
    postalCode: string;
    country: string;
    isDefault: boolean;
  }>;
  orders: OrderRecord[];
  appointments: AppointmentRecord[];
}

export interface OrderRecord {
  id: string;
  date: string;
  items: Array<{
    productName: string;
    brand: string;
    priceFormatted: string;
    image: string;
    quantity: number;
  }>;
  totalFormatted: string;
  status: 'In Private Courier Transit' | 'Hand Delivered' | 'Vault Reserved' | 'Processing';
  deliveryAddress: string;
  trackingNumber: string;
}

export interface AppointmentRecord {
  id: string;
  serviceType: string;
  date: string;
  time: string;
  location: string;
  advisorName: string;
  status: 'Confirmed' | 'Pending Concierge Contact' | 'Completed';
  notes?: string;
}

export interface ToastMessage {
  id: string;
  title: string;
  description?: string;
  type?: 'success' | 'info' | 'gold';
}
