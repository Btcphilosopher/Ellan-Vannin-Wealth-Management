/**
 * Currency and Integer Minor Unit Accounting Helpers
 * 1 QAR = 100 dirhams
 */

export function dirhamsToQAR(dirhams: number): number {
  return dirhams / 100;
}

export function qarToDirhams(qar: number): number {
  return Math.round(qar * 100);
}

export function formatQAR(dirhams: number, locale: 'en' | 'ar' = 'en', showSymbol = true): string {
  const qar = dirhamsToQAR(dirhams);
  
  if (locale === 'ar') {
    const formatted = new Intl.NumberFormat('ar-QA', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(qar);
    return showSymbol ? `${formatted} ر.ق` : formatted;
  }

  const formatted = new Intl.NumberFormat('en-QA', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(qar);

  return showSymbol ? `QAR ${formatted}` : formatted;
}

export function formatCompactQAR(dirhams: number, locale: 'en' | 'ar' = 'en'): string {
  const qar = dirhamsToQAR(dirhams);
  const billion = 1000000000;
  const million = 1000000;

  if (qar >= billion) {
    const num = (qar / billion).toFixed(2);
    return locale === 'ar' ? `ر.ق ${num} مليار` : `QAR ${num}bn`;
  }
  if (qar >= million) {
    const num = (qar / million).toFixed(2);
    return locale === 'ar' ? `ر.ق ${num} مليون` : `QAR ${num}m`;
  }

  return formatQAR(dirhams, locale, true);
}

export function generateHash(prefix: string, seed: string | number): string {
  const str = `${prefix}-${seed}-${Date.now()}-${Math.random()}`;
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0;
  }
  const hex = Math.abs(hash).toString(16).padStart(8, '0').toUpperCase();
  const hex2 = Math.abs(hash * 31).toString(16).padStart(8, '0').toUpperCase();
  return `${prefix}-${hex}${hex2}`;
}

export function formatTimestamp(timestampStr: string, locale: 'en' | 'ar' = 'en'): string {
  const date = new Date(timestampStr);
  return date.toLocaleString(locale === 'ar' ? 'ar-QA' : 'en-US', {
    hour12: false,
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    day: '2-digit',
    month: 'short',
    year: 'numeric'
  });
}
