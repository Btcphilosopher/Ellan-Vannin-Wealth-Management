import React from 'react';
import { CBDCProvider, useCBDC } from './context/CBDCContext';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { OverviewView } from './components/views/OverviewView';
import { IssuanceRedemptionView } from './components/views/IssuanceRedemptionView';
import { WholesaleDvPView } from './components/views/WholesaleDvPView';
import { SecuritiesView } from './components/views/SecuritiesView';
import { ParticipantsView } from './components/views/ParticipantsView';
import { LedgerView } from './components/views/LedgerView';
import { LiquidityResearchView } from './components/views/LiquidityResearchView';
import { StressLabView } from './components/views/StressLabView';
import { RetailLabView } from './components/views/RetailLabView';
import { DohaMapView } from './components/views/DohaMapView';
import { DemoWizardsView } from './components/views/DemoWizardsView';
import { ComplianceAuditView } from './components/views/ComplianceAuditView';

const MainLayout: React.FC = () => {
  const { activeView, locale } = useCBDC();

  const renderView = () => {
    switch (activeView) {
      case 'OVERVIEW':
        return <OverviewView />;
      case 'ISSUANCE_REDEMPTION':
        return <IssuanceRedemptionView />;
      case 'WHOLESALE_DVP':
        return <WholesaleDvPView />;
      case 'SECURITIES':
        return <SecuritiesView />;
      case 'PARTICIPANTS':
        return <ParticipantsView />;
      case 'LEDGER':
        return <LedgerView />;
      case 'LIQUIDITY_RESEARCH':
        return <LiquidityResearchView />;
      case 'STRESS_LAB':
        return <StressLabView />;
      case 'RETAIL_LAB':
        return <RetailLabView />;
      case 'DOHA_MAP':
        return <DohaMapView />;
      case 'DEMO_WIZARDS':
        return <DemoWizardsView />;
      case 'COMPLIANCE_AUDIT':
        return <ComplianceAuditView />;
      default:
        return <OverviewView />;
    }
  };

  return (
    <div dir={locale === 'ar' ? 'rtl' : 'ltr'} className="min-h-screen bg-[#0B0E14] text-slate-100 flex flex-col font-sans">
      <Header />
      <div className="flex flex-1 overflow-hidden">
        <Sidebar />
        <main className="flex-1 p-4 lg:p-6 overflow-y-auto max-w-[1600px] mx-auto w-full">
          {renderView()}
        </main>
      </div>
    </div>
  );
};

export default function App() {
  return (
    <CBDCProvider>
      <MainLayout />
    </CBDCProvider>
  );
}
