export const translations = {
  en: {
    appTitle: "QATAR RIYAL DIGITAL",
    subTitle: "CENTRAL BANK DIGITAL CURRENCY",
    institutionalCode: "QAR-CBDC",
    qcbFull: "QATAR CENTRAL BANK",
    simulationBanner: "SIMULATION — NO REAL FUNDS",
    simulationSub: "Research & Monetary Infrastructure Testbed",
    
    // Navigation
    navOverview: "System Overview",
    navIssuance: "Issuance & Redemption",
    navWholesaleDvP: "Wholesale & DvP Settlement",
    navSecurities: "Digital Securities",
    navParticipants: "Participant Banks",
    navLedger: "Permissioned Ledger",
    navLiquidity: "Liquidity & Monetary Lab",
    navStressLab: "CBDC Stress Lab",
    navRetailLab: "Experimental Retail Lab",
    navDohaMap: "Doha Money Flow Map",
    navDemos: "Guided Demos",
    navCompliance: "Compliance & Audit",

    // Roles
    roleAdmin: "QCB Governor / Admin",
    roleSettlement: "Bank Settlement Officer",
    roleCompliance: "Compliance & AML Auditor",
    roleResearcher: "Monetary Economist",
    roleCitizen: "Retail Citizen / Merchant",

    // Common Metrics
    circulation: "CBDC in Circulation",
    activeParticipants: "Active Participants",
    txToday: "Transactions Today",
    settlementValue: "Settlement Value",
    availableLiquidity: "Available Liquidity",
    pendingSettlement: "Pending Settlement",
    digitalSecurities: "Digital Securities",
    systemStatus: "System Status",
    operational: "OPERATIONAL",
    
    // Actions
    issueCBDC: "Issue CBDC",
    redeemCBDC: "Redeem CBDC",
    initiateTransfer: "Initiate Transfer",
    executeDvP: "Execute DvP Swap",
    runStressTest: "Run Stress Scenario",
    simulateRetailTx: "Simulate Retail Payment",
    verifyLedger: "Verify Ledger Hash",
    exportReport: "Export Audit Log",
    
    // Units
    ratio1to1: "1 QAR-CBDC = 1 QAR",
    centralBankLiability: "Direct Central Bank Liability",
    minorUnitNotice: "Accounting Unit: Integer Dirhams (1 QAR = 100 dirhams)",

    // Sections
    wholesaleVsRetail: "Wholesale vs Retail Allocation",
    rtgsCollateral: "RTGS Reserve Collateral",
    ledgerEvents: "Permissioned Ledger Events",
    liveFlows: "Live Monetary Transactions",
    atomicDvPTitle: "Atomic Delivery vs Payment (DvP)",
    offlineLabTitle: "Device-to-Device Offline Cash Simulation",
    
    // Buttons
    pauseSim: "Pause Engine",
    resumeSim: "Resume Engine",
    speed1x: "1x Realtime",
    speed10x: "10x Fast",
    speed100x: "100x Accelerated",
    speed1000x: "1000x Turbo",
    
    // Language
    languageName: "English",
    switchToAr: "العربية"
  },
  ar: {
    appTitle: "الريال القطري الرقمي",
    subTitle: "العملة الرقمية للبنك المركزي",
    institutionalCode: "QAR-CBDC",
    qcbFull: "مصرف قطر المركزي",
    simulationBanner: "محاكاة — لا توجد أموال حقيقية",
    simulationSub: "منصة أبحاث واختبار البنية التحتية النقدية",
    
    // Navigation
    navOverview: "نظرة عامة على النظام",
    navIssuance: "الإصدار والاسترداد",
    navWholesaleDvP: "تسوية الجملة و التسوية مقابل التسليم",
    navSecurities: "الأوراق المالية الرقمية",
    navParticipants: "البنوك المشاركة",
    navLedger: "دفتر الأستاذ المصرح",
    navLiquidity: "مختبر السيولة والسياسة النقدية",
    navStressLab: "مختبر اختبارات الضغط",
    navRetailLab: "مختبر التجزئة التجريبي",
    navDohaMap: "خريطة التدفقات النقدية - الدوحة",
    navDemos: "العروض التوضيحية التفاعلية",
    navCompliance: "الامتثال والتدقيق",

    // Roles
    roleAdmin: "محافظ البنك المركزي / مسؤول",
    roleSettlement: "مسؤول تسويات بنكية",
    roleCompliance: "مدقق الامتثال ومكافحة غسل الأموال",
    roleResearcher: "خبير اقتصاد نقدي",
    roleCitizen: "مواطن / تاجر تجزئة",

    // Common Metrics
    circulation: "النقد الرقمي المتداول",
    activeParticipants: "المشاركون النشطون",
    txToday: "معاملات اليوم",
    settlementValue: "قيمة التسويات",
    availableLiquidity: "السيولة المتاحة",
    pendingSettlement: "التسويات المعلقة",
    digitalSecurities: "الأوراق المالية الرقمية",
    systemStatus: "حالة النظام",
    operational: "يعمل بكفاءة",
    
    // Actions
    issueCBDC: "إصدار العملة الرقمية",
    redeemCBDC: "استرداد العملة الرقمية",
    initiateTransfer: "بدء تحويل مالي",
    executeDvP: "تنفيذ تبادل DvP الآلي",
    runStressTest: "تشغيل سيناريو الضغط",
    simulateRetailTx: "محاكاة دفع التجزئة",
    verifyLedger: "التحقق من تجزئة الدفتر",
    exportReport: "تصدير سجل التدقيق",
    
    // Units
    ratio1to1: "1 ريال رقمي = 1 ريال قطري",
    centralBankLiability: "التزام مباشر على البنك المركزي",
    minorUnitNotice: "وحدة المحاسبة: درهم صحيح (1 ريال = 100 درهم)",

    // Sections
    wholesaleVsRetail: "توزيع الجملة مقابل التجزئة",
    rtgsCollateral: "ضمانات احتياطي التسوية اللحظية RTGS",
    ledgerEvents: "سجل أحداث دفتر الأستاذ المصرح",
    liveFlows: "التدفقات النقدية المباشرة",
    atomicDvPTitle: "التسوية الآلية مقابل التسليم (DvP)",
    offlineLabTitle: "محاكاة الدفع اللانمطي عبر الأجهزة (أوفلاين)",
    
    // Buttons
    pauseSim: "إيقاف المحاكاة",
    resumeSim: "استئناف المحاكاة",
    speed1x: "1x عادي",
    speed10x: "10x سريع",
    speed100x: "100x تسارع",
    speed1000x: "1000x فائق",
    
    // Language
    languageName: "العربية",
    switchToAr: "English"
  }
};

export type Language = 'en' | 'ar';
