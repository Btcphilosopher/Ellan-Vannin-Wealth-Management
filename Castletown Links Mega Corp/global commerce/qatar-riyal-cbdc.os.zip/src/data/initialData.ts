import { ParticipantBank, DigitalSecurity, CBDCTransaction, AuditEvent, RetailWallet, MerchantAccount } from '../types/cbdc';
import { qarToDirhams, generateHash } from '../utils/formatters';

export const INITIAL_BANKS: ParticipantBank[] = [
  {
    id: 'BANK-QNB',
    code: 'QNB',
    nameEn: 'Qatar National Bank (QNB) — SIMULATION',
    nameAr: 'بنك قطر الوطني — محاكاة',
    swiftCode: 'QNBAQAQA-SIM',
    logo: 'QNB',
    rtgsBalanceDirhams: qarToDirhams(12500000000), // 12.5B QAR
    cbdcBalanceDirhams: qarToDirhams(2100000000), // 2.1B QAR
    reserveRequirementDirhams: qarToDirhams(1000000000),
    liquidityRatio: 1.34,
    status: 'ACTIVE',
    securitiesVolumeDirhams: qarToDirhams(2500000000),
    customerAccountsCount: 480000
  },
  {
    id: 'BANK-CBQ',
    code: 'CBQ',
    nameEn: 'Commercial Bank of Qatar — SIMULATION',
    nameAr: 'البنك التجاري القطري — محاكاة',
    swiftCode: 'CBQAQAQA-SIM',
    logo: 'CBQ',
    rtgsBalanceDirhams: qarToDirhams(6200000000), // 6.2B QAR
    cbdcBalanceDirhams: qarToDirhams(1100000000), // 1.1B QAR
    reserveRequirementDirhams: qarToDirhams(500000000),
    liquidityRatio: 1.28,
    status: 'ACTIVE',
    securitiesVolumeDirhams: qarToDirhams(1400000000),
    customerAccountsCount: 220000
  },
  {
    id: 'BANK-QIB',
    code: 'QIB',
    nameEn: 'Qatar Islamic Bank — SIMULATION',
    nameAr: 'مصرف قطر الإسلامي — محاكاة',
    swiftCode: 'QIBAQAQA-SIM',
    logo: 'QIB',
    rtgsBalanceDirhams: qarToDirhams(7500000000), // 7.5B QAR
    cbdcBalanceDirhams: qarToDirhams(9500000000 / 10), // 950M QAR
    reserveRequirementDirhams: qarToDirhams(600000000),
    liquidityRatio: 1.31,
    status: 'ACTIVE',
    securitiesVolumeDirhams: qarToDirhams(1800000000),
    customerAccountsCount: 310000
  },
  {
    id: 'BANK-DOHA',
    code: 'DOHA',
    nameEn: 'Doha Bank — SIMULATION',
    nameAr: 'بنك الدوحة — محاكاة',
    swiftCode: 'DOHAQAQA-SIM',
    logo: 'DOHA',
    rtgsBalanceDirhams: qarToDirhams(4800000000), // 4.8B QAR
    cbdcBalanceDirhams: qarToDirhams(720000000), // 720M QAR
    reserveRequirementDirhams: qarToDirhams(400000000),
    liquidityRatio: 1.22,
    status: 'ACTIVE',
    securitiesVolumeDirhams: qarToDirhams(850000000),
    customerAccountsCount: 175000
  },
  {
    id: 'BANK-DUKHAN',
    code: 'DUKHAN',
    nameEn: 'Dukhan Bank — SIMULATION',
    nameAr: 'بنك دخان — محاكاة',
    swiftCode: 'DUKHQAQA-SIM',
    logo: 'DUKHAN',
    rtgsBalanceDirhams: qarToDirhams(3100000000), // 3.1B QAR
    cbdcBalanceDirhams: qarToDirhams(410000000), // 410M QAR
    reserveRequirementDirhams: qarToDirhams(250000000),
    liquidityRatio: 1.25,
    status: 'ACTIVE',
    securitiesVolumeDirhams: qarToDirhams(500000000),
    customerAccountsCount: 95000
  },
  {
    id: 'BANK-RAYAN',
    code: 'RAYAN',
    nameEn: 'Masraf Al Rayan — SIMULATION',
    nameAr: 'مصرف الريان — محاكاة',
    swiftCode: 'MARAQAQA-SIM',
    logo: 'RAYAN',
    rtgsBalanceDirhams: qarToDirhams(4200000000), // 4.2B QAR
    cbdcBalanceDirhams: qarToDirhams(540000000), // 540M QAR
    reserveRequirementDirhams: qarToDirhams(350000000),
    liquidityRatio: 1.29,
    status: 'ACTIVE',
    securitiesVolumeDirhams: qarToDirhams(660000000),
    customerAccountsCount: 140000
  }
];

export const INITIAL_SECURITIES: DigitalSecurity[] = [
  {
    isin: 'QA-GOV-2029-01',
    titleEn: 'State of Qatar Sovereign Digital Bond 2029',
    titleAr: 'سندات حكومة قطر الرقمية السيادية 2029',
    issuerId: 'QCB-CENTRAL',
    issuerNameEn: 'State of Qatar / Ministry of Finance',
    issuerNameAr: 'دولة قطر / وزارة المالية',
    type: 'GOV_BOND',
    maturityDate: '2029-11-15',
    couponPercent: 4.25,
    nominalPriceDirhams: qarToDirhams(100),
    marketPriceDirhams: qarToDirhams(99.42),
    totalVolume: 25000000, // 25M units x 100 QAR = 2.5B QAR
    availableVolume: 8500000,
    yieldPercent: 4.38,
    isTokenized: true,
    imagePath: '/src/assets/images/qatar_sovereign_bond_1790344478673.jpg'
  },
  {
    isin: 'QA-SUKUK-2028-02',
    titleEn: 'Qatar Treasury Sovereign Sukuk 2028',
    titleAr: 'صكوك الخزينة القطرية السيادية 2028',
    issuerId: 'QCB-CENTRAL',
    issuerNameEn: 'Qatar Central Bank Treasury',
    issuerNameAr: 'خزينة مصرف قطر المركزي',
    type: 'SUKUK',
    maturityDate: '2028-06-30',
    couponPercent: 4.60,
    nominalPriceDirhams: qarToDirhams(1000),
    marketPriceDirhams: qarToDirhams(1002.10),
    totalVolume: 1800000,
    availableVolume: 420000,
    yieldPercent: 4.52,
    isTokenized: true,
    imagePath: '/src/assets/images/qatar_sovereign_bond_1790344478673.jpg'
  },
  {
    isin: 'QNB-PAPER-2027',
    titleEn: 'QNB Tokenised Institutional Paper 2027',
    titleAr: 'أوراق QNB التجارية الرقمية للمؤسسات 2027',
    issuerId: 'BANK-QNB',
    issuerNameEn: 'Qatar National Bank Treasury',
    issuerNameAr: 'خزينة بنك قطر الوطني',
    type: 'BANK_PAPER',
    maturityDate: '2027-12-01',
    couponPercent: 5.10,
    nominalPriceDirhams: qarToDirhams(500),
    marketPriceDirhams: qarToDirhams(498.50),
    totalVolume: 2000000,
    availableVolume: 610000,
    yieldPercent: 5.22,
    isTokenized: true
  },
  {
    isin: 'CBQ-GREEN-2030',
    titleEn: 'Qatar Green Infrastructure Sukuk 2030',
    titleAr: 'صكوك البنية التحتية الخضراء القطرية 2030',
    issuerId: 'BANK-CBQ',
    issuerNameEn: 'Commercial Bank Sustainable Finance',
    issuerNameAr: 'التمويل المستدام بالبنك التجاري',
    type: 'SUKUK',
    maturityDate: '2030-03-20',
    couponPercent: 4.15,
    nominalPriceDirhams: qarToDirhams(100),
    marketPriceDirhams: qarToDirhams(100.00),
    totalVolume: 9100000,
    availableVolume: 3200000,
    yieldPercent: 4.15,
    isTokenized: true
  }
];

export const INITIAL_LEDGER: CBDCTransaction[] = [
  {
    id: 'TX-QAR-0001001',
    txHash: '0x8F9A1B2C3D4E5F6A7B8C9D0E1F2A3B4C5D6E7F8A',
    prevHash: '0x0000000000000000000000000000000000000000',
    timestamp: '2026-09-25T08:15:22.102Z',
    type: 'ISSUANCE',
    senderId: 'QCB-MINT',
    senderNameEn: 'QCB Core Issuance Engine',
    senderNameAr: 'محرك إصدار مصرف قطر المركزي',
    receiverId: 'BANK-QNB',
    receiverNameEn: 'Qatar National Bank (QNB)',
    receiverNameAr: 'بنك قطر الوطني',
    amountDirhams: qarToDirhams(250000000), // 250M QAR
    currency: 'QAR-CBDC',
    status: 'SETTLED',
    complianceStatus: 'CLEARED',
    auditRef: 'AUD-ISSUE-99201',
    memo: 'Primary RTGS Conversion to QAR-CBDC Collateral',
    blockNumber: 104820
  },
  {
    id: 'TX-QAR-0001002',
    txHash: '0x7A8B9C0D1E2F3A4B5C6D7E8F9A0B1C2D3E4F5A6B',
    prevHash: '0x8F9A1B2C3D4E5F6A7B8C9D0E1F2A3B4C5D6E7F8A',
    timestamp: '2026-09-25T08:42:17.238Z',
    type: 'WHOLESALE_TRANSFER',
    senderId: 'BANK-QNB',
    senderNameEn: 'Qatar National Bank',
    senderNameAr: 'بنك قطر الوطني',
    receiverId: 'BANK-CBQ',
    receiverNameEn: 'Commercial Bank of Qatar',
    receiverNameAr: 'البنك التجاري القطري',
    amountDirhams: qarToDirhams(18500000), // 18.5M QAR
    currency: 'QAR-CBDC',
    status: 'SETTLED',
    complianceStatus: 'CLEARED',
    auditRef: 'AUD-SETTLE-44819',
    memo: 'Intraday Liquidity Balancing — RTGS Settlement Bridge',
    blockNumber: 104821
  },
  {
    id: 'TX-QAR-0001003',
    txHash: '0x6B7C8D9E0F1A2B3C4D5E6F7A8B9C0D1E2F3A4B5C',
    prevHash: '0x7A8B9C0D1E2F3A4B5C6D7E8F9A0B1C2D3E4F5A6B',
    timestamp: '2026-09-25T09:05:00.000Z',
    type: 'DVP_SETTLEMENT',
    senderId: 'BANK-CBQ',
    senderNameEn: 'Commercial Bank of Qatar',
    senderNameAr: 'البنك التجاري القطري',
    receiverId: 'BANK-QIB',
    receiverNameEn: 'Qatar Islamic Bank',
    receiverNameAr: 'مصرف قطر الإسلامي',
    amountDirhams: qarToDirhams(99420000), // 99.42M QAR
    currency: 'QAR-CBDC',
    status: 'SETTLED',
    complianceStatus: 'CLEARED',
    auditRef: 'AUD-DVP-88102',
    memo: 'Atomic DvP Swap: QA-GOV-2029-01 Sovereign Bond Purchase',
    blockNumber: 104822
  }
];

export const INITIAL_AUDIT_LOGS: AuditEvent[] = [
  {
    id: 'AUD-001',
    timestamp: '2026-09-25T08:15:22.102Z',
    actorId: 'QCB_OFFICER_04',
    actorRole: 'QCB_ADMIN',
    action: 'APPROVED_CBDC_ISSUANCE',
    amountDirhams: qarToDirhams(250000000),
    targetEntity: 'BANK-QNB',
    eventHash: 'SIM-AUD-8E91A0B2C3D4',
    prevHash: 'SIM-AUD-000000000000',
    status: 'VERIFIED'
  },
  {
    id: 'AUD-002',
    timestamp: '2026-09-25T09:05:00.000Z',
    actorId: 'AUTOMATED_DVP_ENGINE',
    actorRole: 'BANK_SETTLEMENT',
    action: 'ATOMIC_SWAP_EXECUTED',
    amountDirhams: qarToDirhams(99420000),
    targetEntity: 'DVP-CONTRACT-QA-GOV-01',
    eventHash: 'SIM-AUD-9F02B1C3D4E5',
    prevHash: 'SIM-AUD-8E91A0B2C3D4',
    status: 'VERIFIED'
  }
];

export const INITIAL_RETAIL_WALLETS: RetailWallet[] = [
  {
    id: 'W-QAT-881029',
    citizenNameEn: 'Tariq Al-Mansoori',
    citizenNameAr: 'طارق المنصوري',
    qid: '28863401928',
    tier: 'TIER_2_VERIFIED',
    balanceDirhams: qarToDirhams(8420.75),
    dailyLimitDirhams: qarToDirhams(50000),
    remainingDailyLimitDirhams: qarToDirhams(41579.25),
    offlineBalanceDirhams: qarToDirhams(1250.00),
    deviceHardwareId: 'SEC-ELEMENT-QAT-0912',
    isOfflineActive: true
  },
  {
    id: 'W-QAT-992011',
    citizenNameEn: 'Fatima Al-Kuwari',
    citizenNameAr: 'فاطمة الكواري',
    qid: '29263408819',
    tier: 'TIER_2_VERIFIED',
    balanceDirhams: qarToDirhams(15300.00),
    dailyLimitDirhams: qarToDirhams(50000),
    remainingDailyLimitDirhams: qarToDirhams(50000),
    offlineBalanceDirhams: qarToDirhams(500.00),
    deviceHardwareId: 'SEC-ELEMENT-QAT-1102',
    isOfflineActive: true
  }
];

export const INITIAL_MERCHANTS: MerchantAccount[] = [
  {
    id: 'MCH-DOHA-METRO',
    businessNameEn: 'Doha Metro — Qatar Rail',
    businessNameAr: 'رَيل قطر — مترو الدوحة',
    category: 'Public Transport',
    crNumber: 'CR-99201-QA',
    balanceDirhams: qarToDirhams(1420500.00),
    settledTodayDirhams: qarToDirhams(125000.00),
    qrCodeData: 'QAR-CBDC:MCH-DOHA-METRO:PARAM'
  },
  {
    id: 'MCH-KATARA-CAFE',
    businessNameEn: 'Katara Cultural Village Hospitality',
    businessNameAr: 'ضيافة الحي الثقافي كُتارا',
    category: 'Dining & Tourism',
    crNumber: 'CR-88102-QA',
    balanceDirhams: qarToDirhams(680250.00),
    settledTodayDirhams: qarToDirhams(42100.00),
    qrCodeData: 'QAR-CBDC:MCH-KATARA-CAFE:PARAM'
  }
];
