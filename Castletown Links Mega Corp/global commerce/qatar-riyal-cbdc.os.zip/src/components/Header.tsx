import React from 'react';
import { useCBDC } from '../context/CBDCContext';
import { SystemRole } from '../types/cbdc';
import { Play, Pause, FastForward, ShieldAlert, Globe, ChevronDown } from 'lucide-react';

export const Header: React.FC = () => {
  const {
    t,
    locale,
    setLocale,
    activeRole,
    setActiveRole,
    simulationSpeed,
    setSimulationSpeed,
    systemMetrics,
    invariantAlert
  } = useCBDC();

  const handleRoleChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setActiveRole(e.target.value as SystemRole);
  };

  return (
    <header className="sticky top-0 z-50 bg-[#0B0E14]/95 backdrop-blur-md border-b border-[#1E2633] px-4 lg:px-6 py-2.5">
      {/* Simulation Banner Notice */}
      <div className="bg-[#8A1538]/20 border border-[#8A1538]/40 rounded-md px-3 py-1 mb-2.5 flex items-center justify-between text-xs">
        <div className="flex items-center gap-2 text-amber-300 font-semibold tracking-wide">
          <ShieldAlert className="w-4 h-4 text-[#8A1538] shrink-0" />
          <span>{t.simulationBanner}</span>
          <span className="hidden md:inline text-slate-400 font-normal">— {t.simulationSub}</span>
        </div>
        <div className="flex items-center gap-3 text-slate-300 text-[11px] font-mono tabular-nums">
          <span className="hidden sm:inline bg-[#161F2E] px-2 py-0.5 rounded border border-slate-700">{t.ratio1to1}</span>
          <span className="text-[#10B981] flex items-center gap-1 font-medium">
            <span className="w-2 h-2 rounded-full bg-[#10B981] animate-pulse"></span>
            {t.operational}
          </span>
        </div>
      </div>

      {/* Main Header Row (Top Bar Contract: 3 Zones) */}
      <div className="flex items-center justify-between gap-4">
        {/* Zone 1: Brand Title & QCB Emblem */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-[#8A1538]/30 border border-[#8A1538]/60 p-0.5 shrink-0 flex items-center justify-center">
            <img 
              src="/src/assets/images/qcb_emblem_seal_179034448564.jpg" 
              alt="QCB Emblem" 
              className="w-full h-full object-cover rounded-full" 
              onError={(e) => {
                // Fallback SVG seal if image fails
                (e.target as HTMLElement).style.display = 'none';
              }}
            />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base lg:text-lg font-bold tracking-tight text-white font-sans whitespace-nowrap">
                {t.appTitle}
              </h1>
              <span className="bg-[#8A1538] text-white text-[10px] font-bold px-1.5 py-0.5 rounded tracking-wider uppercase">
                {t.institutionalCode}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-medium tracking-wide hidden sm:block">
              {t.qcbFull} · MONETARY INFRASTRUCTURE OS
            </p>
          </div>
        </div>

        {/* Zone 2: Simulation Speed & Controls */}
        <div className="hidden lg:flex items-center gap-3 bg-[#131924] p-1.5 rounded-lg border border-[#222C3D]">
          <span className="text-xs text-slate-400 font-medium px-2">Simulation Engine:</span>
          
          <button
            onClick={() => setSimulationSpeed(simulationSpeed === 0 ? 1 : 0)}
            className={`p-1.5 rounded-md text-xs font-semibold flex items-center gap-1 transition-colors ${
              simulationSpeed === 0 
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' 
                : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
            }`}
            title={simulationSpeed === 0 ? t.resumeSim : t.pauseSim}
          >
            {simulationSpeed === 0 ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />}
            <span className="whitespace-nowrap">{simulationSpeed === 0 ? 'PAUSED' : 'LIVE'}</span>
          </button>

          <div className="flex items-center gap-1 border-l border-slate-700 pl-2">
            {[1, 10, 100, 1000].map(speed => (
              <button
                key={speed}
                onClick={() => setSimulationSpeed(speed)}
                className={`px-2 py-1 text-xs font-mono rounded transition-colors ${
                  simulationSpeed === speed
                    ? 'bg-[#8A1538] text-white font-bold'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                }`}
              >
                {speed}x
              </button>
            ))}
          </div>
        </div>

        {/* Zone 3: Role Switcher & Language Toggle */}
        <div className="flex items-center gap-3">
          {/* Active Role Selector */}
          <div className="relative">
            <select
              value={activeRole}
              onChange={handleRoleChange}
              className="appearance-none bg-[#131924] border border-[#2A3447] text-slate-200 text-xs rounded-lg px-3 py-1.5 pr-8 focus:outline-none focus:border-[#8A1538] font-medium cursor-pointer"
            >
              <option value="QCB_ADMIN">{t.roleAdmin}</option>
              <option value="BANK_SETTLEMENT">{t.roleSettlement}</option>
              <option value="COMPLIANCE_AUDITOR">{t.roleCompliance}</option>
              <option value="RESEARCHER">{t.roleResearcher}</option>
              <option value="RETAIL_CITIZEN">{t.roleCitizen}</option>
            </select>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>

          {/* Language Toggle */}
          <button
            onClick={() => setLocale(locale === 'en' ? 'ar' : 'en')}
            className="flex items-center gap-1.5 bg-[#131924] border border-[#2A3447] hover:border-[#8A1538] text-slate-200 text-xs px-2.5 py-1.5 rounded-lg transition-colors font-medium"
            title="Switch Language / تغيير اللغة"
          >
            <Globe className="w-3.5 h-3.5 text-[#8A1538]" />
            <span>{t.switchToAr}</span>
          </button>
        </div>
      </div>

      {/* Invariant Warning if ledger anomaly */}
      {invariantAlert && (
        <div className="mt-2 bg-red-900/80 text-white text-xs px-3 py-1.5 rounded border border-red-500 flex items-center justify-between animate-bounce">
          <span className="font-bold">⚠️ LEDGER INVARIANT ALERT: Monetary supply mismatch detected!</span>
          <span className="font-mono text-[11px]">System integrity check active</span>
        </div>
      )}
    </header>
  );
};
