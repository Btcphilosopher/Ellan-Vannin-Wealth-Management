import React from 'react';
import { useCBDC } from '../context/CBDCContext';
import { ActiveView } from '../types/cbdc';
import {
  Building2,
  Coins,
  ArrowLeftRight,
  Landmark,
  Layers,
  BarChart3,
  Flame,
  Smartphone,
  MapPin,
  PlayCircle,
  ShieldCheck,
  LayoutDashboard
} from 'lucide-react';

export const Sidebar: React.FC = () => {
  const { activeView, setActiveView, t, locale } = useCBDC();

  const navItems: { id: ActiveView; label: string; icon: React.ReactNode; badge?: string }[] = [
    { id: 'OVERVIEW', label: t.navOverview, icon: <LayoutDashboard className="w-4 h-4" /> },
    { id: 'ISSUANCE_REDEMPTION', label: t.navIssuance, icon: <Coins className="w-4 h-4" /> },
    { id: 'WHOLESALE_DVP', label: t.navWholesaleDvP, icon: <ArrowLeftRight className="w-4 h-4" />, badge: 'Atomic' },
    { id: 'SECURITIES', label: t.navSecurities, icon: <Landmark className="w-4 h-4" /> },
    { id: 'PARTICIPANTS', label: t.navParticipants, icon: <Building2 className="w-4 h-4" /> },
    { id: 'LEDGER', label: t.navLedger, icon: <Layers className="w-4 h-4" /> },
    { id: 'LIQUIDITY_RESEARCH', label: t.navLiquidity, icon: <BarChart3 className="w-4 h-4" /> },
    { id: 'STRESS_LAB', label: t.navStressLab, icon: <Flame className="w-4 h-4" /> },
    { id: 'RETAIL_LAB', label: t.navRetailLab, icon: <Smartphone className="w-4 h-4" />, badge: 'Lab' },
    { id: 'DOHA_MAP', label: t.navDohaMap, icon: <MapPin className="w-4 h-4" /> },
    { id: 'DEMO_WIZARDS', label: t.navDemos, icon: <PlayCircle className="w-4 h-4" />, badge: '1-4' },
    { id: 'COMPLIANCE_AUDIT', label: t.navCompliance, icon: <ShieldCheck className="w-4 h-4" /> }
  ];

  return (
    <aside className="w-64 bg-[#0E131D] border-r border-[#1E2633] flex flex-col shrink-0 min-h-[calc(100vh-65px)]">
      {/* Navigation Label */}
      <div className="px-4 py-3 border-b border-[#1E2633]/60 text-[10px] font-bold text-slate-500 uppercase tracking-wider">
        QCB MONETARY NAVIGATION
      </div>

      {/* Navigation Links */}
      <nav className="p-2 space-y-1 flex-1 overflow-y-auto">
        {navItems.map(item => {
          const isActive = activeView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveView(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-medium transition-all ${
                isActive
                  ? 'bg-[#8A1538] text-white shadow-lg shadow-[#8A1538]/20 font-semibold'
                  : 'text-slate-400 hover:text-white hover:bg-[#161F2E]'
              }`}
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <span className={isActive ? 'text-white' : 'text-slate-400'}>{item.icon}</span>
                <span className="truncate">{item.label}</span>
              </div>
              {item.badge && (
                <span
                  className={`text-[9px] px-1.5 py-0.5 rounded uppercase font-mono font-bold shrink-0 ${
                    isActive
                      ? 'bg-white/20 text-white'
                      : 'bg-[#1E2633] text-slate-400'
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Footer Info */}
      <div className="p-4 border-t border-[#1E2633] bg-[#0A0D14] text-[11px] text-slate-500 space-y-1 font-mono">
        <div className="flex items-center justify-between">
          <span>QCB LEDGER HEIGHT</span>
          <span className="text-slate-300 font-bold">#104,823</span>
        </div>
        <div className="flex items-center justify-between text-[10px]">
          <span>NETWORK LATENCY</span>
          <span className="text-emerald-400 font-bold">14ms</span>
        </div>
      </div>
    </aside>
  );
};
