import React, { useState } from 'react';
import { useCBDC } from '../../context/CBDCContext';
import { formatQAR, formatCompactQAR } from '../../utils/formatters';
import { Coins, Flame, ArrowRight, ShieldCheck, CheckCircle2, AlertCircle, Lock, RefreshCw } from 'lucide-react';

export const IssuanceRedemptionView: React.FC = () => {
  const { banks, issueCBDC, redeemCBDC, t, locale } = useCBDC();

  // Issuance State
  const [issueBankId, setIssueBankId] = useState<string>(banks[0]?.id || '');
  const [issueAmountQAR, setIssueAmountQAR] = useState<number>(50000000); // 50M QAR
  const [issueMemo, setIssueMemo] = useState<string>('Primary RTGS Collateral Conversion');
  const [issueResult, setIssueResult] = useState<{ success: boolean; message: string; txHash?: string } | null>(null);

  // Redemption State
  const [redeemBankId, setRedeemBankId] = useState<string>(banks[0]?.id || '');
  const [redeemAmountQAR, setRedeemAmountQAR] = useState<number>(25000000); // 25M QAR
  const [redeemMemo, setRedeemMemo] = useState<string>('CBDC Burning for RTGS Unlocking');
  const [redeemResult, setRedeemResult] = useState<{ success: boolean; message: string; txHash?: string } | null>(null);

  const selectedIssueBank = banks.find(b => b.id === issueBankId);
  const selectedRedeemBank = banks.find(b => b.id === redeemBankId);

  const handleIssueSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIssueResult(null);
    const res = issueCBDC(issueBankId, issueAmountQAR, issueMemo);
    setIssueResult(res);
  };

  const handleRedeemSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setRedeemResult(null);
    const res = redeemCBDC(redeemBankId, redeemAmountQAR, redeemMemo);
    setRedeemResult(res);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="border-b border-[#1E2633] pb-4">
        <h2 className="text-xl font-bold text-white">Central Bank Issuance & Redemption Engine</h2>
        <p className="text-xs text-slate-400 mt-1">
          Sovereign Minting & Burning Workflows Backed 1:1 by RTGS Settlement Balances
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Issuance Engine Card (Prompt Section 8) */}
        <div className="bg-[#111622] border border-[#1E2633] rounded-xl p-5 space-y-5">
          <div className="flex items-center justify-between border-b border-[#1E2633] pb-3">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-lg bg-[#8A1538]/20 text-[#8A1538]">
                <Coins className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Issue CBDC (Mint)</h3>
                <p className="text-[11px] text-slate-400">Convert RTGS Balance to QAR-CBDC</p>
              </div>
            </div>
            <span className="text-[10px] font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded">
              Ratio 1:1
            </span>
          </div>

          <form onSubmit={handleIssueSubmit} className="space-y-4">
            {/* Select Participant Bank */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">Participant Bank</label>
              <select
                value={issueBankId}
                onChange={e => setIssueBankId(e.target.value)}
                className="w-full bg-[#161F2E] border border-[#2A3447] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#8A1538]"
              >
                {banks.map(b => (
                  <option key={b.id} value={b.id}>
                    {locale === 'ar' ? b.nameAr : b.nameEn} ({formatCompactQAR(b.rtgsBalanceDirhams, locale)} RTGS)
                  </option>
                ))}
              </select>
            </div>

            {/* Selected Bank Live Collateral Status */}
            {selectedIssueBank && (
              <div className="bg-[#161F2E] border border-[#222C3D] p-3 rounded-lg grid grid-cols-2 gap-2 text-xs font-mono">
                <div>
                  <span className="text-slate-400 text-[10px] block">Available RTGS Balance</span>
                  <span className="text-white font-bold">{formatQAR(selectedIssueBank.rtgsBalanceDirhams, locale)}</span>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px] block">Current CBDC Balance</span>
                  <span className="text-emerald-400 font-bold">{formatQAR(selectedIssueBank.cbdcBalanceDirhams, locale)}</span>
                </div>
              </div>
            )}

            {/* Requested Amount */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">Requested Amount (QAR)</label>
              <div className="relative">
                <input
                  type="number"
                  min="100000"
                  step="100000"
                  value={issueAmountQAR}
                  onChange={e => setIssueAmountQAR(Number(e.target.value))}
                  className="w-full bg-[#161F2E] border border-[#2A3447] rounded-lg px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-[#8A1538]"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">QAR</span>
              </div>
            </div>

            {/* Memo */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">Issuance Authorization Memo</label>
              <input
                type="text"
                value={issueMemo}
                onChange={e => setIssueMemo(e.target.value)}
                className="w-full bg-[#161F2E] border border-[#2A3447] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#8A1538]"
              />
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full bg-[#8A1538] hover:bg-[#A31942] text-white text-xs font-bold py-2.5 rounded-lg transition-colors flex items-center justify-center gap-2 shadow-lg shadow-[#8A1538]/20"
            >
              <Coins className="w-4 h-4" />
              <span>Authorize QCB Mint Event & Lock RTGS</span>
            </button>
          </form>

          {/* Issue Result Notification */}
          {issueResult && (
            <div className={`p-3.5 rounded-lg text-xs space-y-1 font-mono ${issueResult.success ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-300' : 'bg-red-500/10 border border-red-500/30 text-red-300'}`}>
              <div className="flex items-center gap-2 font-bold font-sans">
                {issueResult.success ? <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" /> : <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />}
                <span>{issueResult.success ? 'CBDC Minting Confirmed' : 'Issuance Rejected'}</span>
              </div>
              <p>{issueResult.message}</p>
              {issueResult.txHash && (
                <div className="text-[10px] text-slate-400 pt-1 border-t border-slate-700/50">
                  Ledger Tx Hash: <span className="text-slate-200">{issueResult.txHash}</span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Redemption Engine Card (Prompt Section 9) */}
        <div className="bg-[#111622] border border-[#1E2633] rounded-xl p-5 space-y-5">
          <div className="flex items-center justify-between border-b border-[#1E2633] pb-3">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-lg bg-amber-500/20 text-amber-400">
                <Flame className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Redeem CBDC (Burn)</h3>
                <p className="text-[11px] text-slate-400">Burn CBDC & Unlock RTGS Balance</p>
              </div>
            </div>
            <span className="text-[10px] font-mono bg-amber-500/10 text-amber-400 border border-amber-500/30 px-2 py-0.5 rounded">
              Burn Workflow
            </span>
          </div>

          <form onSubmit={handleRedeemSubmit} className="space-y-4">
            {/* Select Bank */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">Participant Bank</label>
              <select
                value={redeemBankId}
                onChange={e => setRedeemBankId(e.target.value)}
                className="w-full bg-[#161F2E] border border-[#2A3447] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#8A1538]"
              >
                {banks.map(b => (
                  <option key={b.id} value={b.id}>
                    {locale === 'ar' ? b.nameAr : b.nameEn} ({formatCompactQAR(b.cbdcBalanceDirhams, locale)} CBDC)
                  </option>
                ))}
              </select>
            </div>

            {/* Selected Bank Live Balances */}
            {selectedRedeemBank && (
              <div className="bg-[#161F2E] border border-[#222C3D] p-3 rounded-lg grid grid-cols-2 gap-2 text-xs font-mono">
                <div>
                  <span className="text-slate-400 text-[10px] block">Current CBDC Balance</span>
                  <span className="text-white font-bold">{formatQAR(selectedRedeemBank.cbdcBalanceDirhams, locale)}</span>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px] block">RTGS Balance After Unlocking</span>
                  <span className="text-emerald-400 font-bold">{formatQAR(selectedRedeemBank.rtgsBalanceDirhams, locale)}</span>
                </div>
              </div>
            )}

            {/* Amount */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">Redemption Amount (QAR)</label>
              <div className="relative">
                <input
                  type="number"
                  min="100000"
                  step="100000"
                  value={redeemAmountQAR}
                  onChange={e => setRedeemAmountQAR(Number(e.target.value))}
                  className="w-full bg-[#161F2E] border border-[#2A3447] rounded-lg px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-[#8A1538]"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">QAR</span>
              </div>
            </div>

            {/* Memo */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">Redemption Audit Memo</label>
              <input
                type="text"
                value={redeemMemo}
                onChange={e => setRedeemMemo(e.target.value)}
                className="w-full bg-[#161F2E] border border-[#2A3447] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#8A1538]"
              />
            </div>

            {/* Submit */}
            <button
              type="submit"
              className="w-full bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold py-2.5 rounded-lg transition-colors flex items-center justify-center gap-2 shadow-lg shadow-amber-600/20"
            >
              <Flame className="w-4 h-4" />
              <span>Authorize QCB Burn & Restore RTGS Balance</span>
            </button>
          </form>

          {/* Result */}
          {redeemResult && (
            <div className={`p-3.5 rounded-lg text-xs space-y-1 font-mono ${redeemResult.success ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-300' : 'bg-red-500/10 border border-red-500/30 text-red-300'}`}>
              <div className="flex items-center gap-2 font-bold font-sans">
                {redeemResult.success ? <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" /> : <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />}
                <span>{redeemResult.success ? 'CBDC Burn Confirmed' : 'Redemption Rejected'}</span>
              </div>
              <p>{redeemResult.message}</p>
              {redeemResult.txHash && (
                <div className="text-[10px] text-slate-400 pt-1 border-t border-slate-700/50">
                  Ledger Tx Hash: <span className="text-slate-200">{redeemResult.txHash}</span>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
