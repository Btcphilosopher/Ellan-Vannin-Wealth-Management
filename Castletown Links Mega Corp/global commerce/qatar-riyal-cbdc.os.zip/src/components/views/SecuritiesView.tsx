import React from 'react';
import { useCBDC } from '../../context/CBDCContext';
import { formatQAR, formatCompactQAR, dirhamsToQAR } from '../../utils/formatters';
import { Landmark, ArrowUpRight, ShieldCheck, Tag, Calendar, Percent } from 'lucide-react';

export const SecuritiesView: React.FC = () => {
  const { securities, dvpContracts, t, locale, setActiveView } = useCBDC();

  return (
    <div className="space-y-6">
      {/* View Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#1E2633] pb-4">
        <div>
          <h2 className="text-xl font-bold text-white">Digital Securities Market & Sovereign Sukuk Ledger</h2>
          <p className="text-xs text-slate-400 mt-1">
            Tokenized Qatari Treasury Bonds, Corporate Sukuk & Commercial Paper Ready for Atomic CBDC DvP
          </p>
        </div>
        <button
          onClick={() => setActiveView('WHOLESALE_DVP')}
          className="bg-[#8A1538] hover:bg-[#A31942] text-white text-xs font-bold px-3.5 py-2 rounded-lg transition-colors flex items-center gap-1.5 self-start sm:self-auto"
        >
          <span>Initiate DvP Purchase</span>
          <ArrowUpRight className="w-4 h-4" />
        </button>
      </div>

      {/* Sovereign Digital Securities Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {securities.map(s => {
          const marketPriceQAR = dirhamsToQAR(s.marketPriceDirhams);
          const nominalPriceQAR = dirhamsToQAR(s.nominalPriceDirhams);
          const totalValueDirhams = s.totalVolume * s.marketPriceDirhams;

          return (
            <div key={s.isin} className="bg-[#111622] border border-[#1E2633] hover:border-[#8A1538]/50 rounded-xl p-5 space-y-4 transition-all">
              {/* Card Header */}
              <div className="flex items-start justify-between gap-3 border-b border-[#1E2633] pb-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="bg-[#8A1538] text-white text-[10px] font-bold px-2 py-0.5 rounded font-mono">
                      {s.isin}
                    </span>
                    <span className="text-[10px] bg-blue-500/10 text-blue-400 border border-blue-500/30 px-2 py-0.5 rounded font-mono font-bold">
                      {s.type}
                    </span>
                  </div>
                  <h3 className="text-sm font-bold text-white mt-1.5 font-sans">
                    {locale === 'ar' ? s.titleAr : s.titleEn}
                  </h3>
                  <p className="text-xs text-slate-400">
                    Issuer: {locale === 'ar' ? s.issuerNameAr : s.issuerNameEn}
                  </p>
                </div>
                <Landmark className="w-6 h-6 text-[#8A1538] shrink-0" />
              </div>

              {/* Financial Attributes Grid */}
              <div className="grid grid-cols-3 gap-3 bg-[#161F2E] p-3 rounded-lg text-xs font-mono">
                <div>
                  <span className="text-slate-400 text-[10px] block flex items-center gap-1">
                    <Tag className="w-3 h-3 text-slate-500" /> Market Price
                  </span>
                  <span className="text-white font-bold">QAR {marketPriceQAR.toFixed(2)}</span>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px] block flex items-center gap-1">
                    <Percent className="w-3 h-3 text-slate-500" /> Coupon / Yield
                  </span>
                  <span className="text-emerald-400 font-bold">{s.couponPercent}% / {s.yieldPercent}%</span>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px] block flex items-center gap-1">
                    <Calendar className="w-3 h-3 text-slate-500" /> Maturity
                  </span>
                  <span className="text-slate-200 font-bold">{s.maturityDate}</span>
                </div>
              </div>

              {/* Volume & Capitalization */}
              <div className="flex items-center justify-between text-xs pt-1">
                <span className="text-slate-400 font-medium">Market Capitalization:</span>
                <span className="text-white font-bold font-mono">
                  {formatCompactQAR(totalValueDirhams, locale)}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Atomic DvP Settlement Contracts History Table */}
      <div className="bg-[#111622] border border-[#1E2633] rounded-xl p-5 space-y-4">
        <div className="border-b border-[#1E2633] pb-3">
          <h3 className="text-sm font-bold text-white">DvP Atomic Settlement Contracts Log</h3>
          <p className="text-xs text-slate-400">Completed Securities Swaps Settled against QAR-CBDC</p>
        </div>

        {dvpContracts.length === 0 ? (
          <div className="text-center py-8 text-xs text-slate-500 font-mono">
            No atomic DvP contracts executed in this session yet. Launch a DvP swap from the Wholesale tab or Signature Demos.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-[#1E2633] text-slate-400 font-medium">
                  <th className="py-2 px-3">Contract Ref</th>
                  <th className="py-2 px-3">Security ISIN</th>
                  <th className="py-2 px-3">Buyer → Seller</th>
                  <th className="py-2 px-3 text-right">Volume</th>
                  <th className="py-2 px-3 text-right">CBDC Amount</th>
                  <th className="py-2 px-3 text-center">Latency</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1E2633]/50 text-slate-300 font-mono">
                {dvpContracts.map(c => (
                  <tr key={c.id} className="hover:bg-[#161F2E]">
                    <td className="py-2.5 px-3 text-[#8A1538] font-bold">{c.id}</td>
                    <td className="py-2.5 px-3">{c.securityIsin}</td>
                    <td className="py-2.5 px-3 font-sans">
                      {c.buyerNameEn} → {c.sellerNameEn}
                    </td>
                    <td className="py-2.5 px-3 text-right">{c.quantity.toLocaleString()} units</td>
                    <td className="py-2.5 px-3 text-right font-bold text-emerald-400">
                      {formatQAR(c.totalCbdcAmountDirhams, locale)}
                    </td>
                    <td className="py-2.5 px-3 text-center text-emerald-400 font-bold">
                      {c.atomicExecutionTimeMs}ms
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
