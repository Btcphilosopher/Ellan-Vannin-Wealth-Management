import React from 'react';
import { useCBDC } from '../../context/CBDCContext';
import { formatQAR, formatTimestamp } from '../../utils/formatters';
import { ShieldCheck, Lock, CheckCircle2, FileText, UserCheck } from 'lucide-react';

export const ComplianceAuditView: React.FC = () => {
  const { auditLogs, transactions, t, locale } = useCBDC();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="border-b border-[#1E2633] pb-4">
        <h2 className="text-xl font-bold text-white">Central Bank Compliance & Audit Engine</h2>
        <p className="text-xs text-slate-400 mt-1">
          Automated Anti-Money Laundering (AML), Sanctions Screening & Immutable Audit Trail
        </p>
      </div>

      {/* Compliance Rule Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-[#111622] border border-[#1E2633] rounded-xl p-4 space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>KYC Tier 1 / Tier 2 Limit</span>
            <UserCheck className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-lg font-bold text-white font-mono">QAR 50,000 / Day</div>
          <p className="text-[10px] text-slate-500 font-mono">Automated Citizen Limit Enforcer</p>
        </div>

        <div className="bg-[#111622] border border-[#1E2633] rounded-xl p-4 space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Large Value Flagging Threshold</span>
            <ShieldCheck className="w-4 h-4 text-[#8A1538]" />
          </div>
          <div className="text-lg font-bold text-white font-mono">QAR 50,000,000</div>
          <p className="text-[10px] text-slate-500 font-mono">Real-time AML Sanction Check</p>
        </div>

        <div className="bg-[#111622] border border-[#1E2633] rounded-xl p-4 space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Audit Trail Verification</span>
            <Lock className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-lg font-bold text-emerald-400 font-mono">100% Cryptographic Match</div>
          <p className="text-[10px] text-slate-500 font-mono">Tamper-Evident Event Stream</p>
        </div>
      </div>

      {/* Audit Log Table */}
      <div className="bg-[#111622] border border-[#1E2633] rounded-xl overflow-hidden">
        <div className="p-4 border-b border-[#1E2633] flex items-center justify-between">
          <h3 className="text-sm font-bold text-white">Immutable Operational Audit Trail</h3>
          <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/30">
            {auditLogs.length} Verified Events
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="bg-[#161F2E] text-slate-400 border-b border-[#1E2633]">
                <th className="py-3 px-4 font-semibold">Audit Ref</th>
                <th className="py-3 px-4 font-semibold font-sans">Officer / Actor</th>
                <th className="py-3 px-4 font-semibold">Action Executed</th>
                <th className="py-3 px-4 text-right font-semibold">Amount (QAR)</th>
                <th className="py-3 px-4 font-semibold">Event Hash</th>
                <th className="py-3 px-4 text-center font-semibold">Verification</th>
                <th className="py-3 px-4 text-right font-semibold">Timestamp</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1E2633] text-slate-300">
              {auditLogs.map(a => (
                <tr key={a.id} className="hover:bg-[#161F2E]">
                  <td className="py-3 px-4 font-bold text-[#8A1538]">{a.id}</td>
                  <td className="py-3 px-4 font-sans text-white font-medium">
                    {a.actorId} ({a.actorRole})
                  </td>
                  <td className="py-3 px-4 font-bold text-slate-200">{a.action}</td>
                  <td className="py-3 px-4 text-right font-bold text-emerald-400">
                    {a.amountDirhams ? formatQAR(a.amountDirhams, locale) : 'N/A'}
                  </td>
                  <td className="py-3 px-4 text-slate-400">{a.eventHash.slice(0, 12)}...</td>
                  <td className="py-3 px-4 text-center">
                    <span className="inline-flex items-center gap-1 text-[10px] text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 rounded font-sans">
                      <CheckCircle2 className="w-3 h-3" />
                      VERIFIED
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right text-slate-400 text-[11px]">
                    {formatTimestamp(a.timestamp, locale)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
