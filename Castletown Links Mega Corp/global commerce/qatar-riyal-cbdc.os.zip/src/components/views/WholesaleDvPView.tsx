import React, { useState } from 'react';
import { useCBDC } from '../../context/CBDCContext';
import { formatQAR, formatCompactQAR, dirhamsToQAR } from '../../utils/formatters';
import { ArrowLeftRight, Landmark, ShieldCheck, Zap, AlertTriangle, CheckCircle2, RefreshCw } from 'lucide-react';

export const WholesaleDvPView: React.FC = () => {
  const { banks, securities, dvpContracts, transferWholesale, executeDvPSwap, t, locale } = useCBDC();

  // Wholesale Transfer Form
  const [senderId, setSenderId] = useState<string>(banks[0]?.id || '');
  const [receiverId, setReceiverId] = useState<string>(banks[1]?.id || '');
  const [transferAmountQAR, setTransferAmountQAR] = useState<number>(10000000); // 10M QAR
  const [transferMemo, setTransferMemo] = useState<string>('Interbank Intraday Settlement');
  const [transferRes, setTransferRes] = useState<{ success: boolean; message: string; txHash?: string } | null>(null);

  // DvP Swap Form
  const [buyerId, setBuyerId] = useState<string>(banks[0]?.id || '');
  const [sellerId, setSellerId] = useState<string>(banks[1]?.id || '');
  const [selectedIsin, setSelectedIsin] = useState<string>(securities[0]?.isin || '');
  const [dvpQuantity, setDvpQuantity] = useState<number>(500000); // 500k units
  const [dvpRes, setDvpRes] = useState<{ success: boolean; message: string; contractId?: string } | null>(null);

  const selectedSecurity = securities.find(s => s.isin === selectedIsin);
  const totalDvpAmountDirhams = selectedSecurity ? dvpQuantity * selectedSecurity.marketPriceDirhams : 0;
  const totalDvpAmountQAR = dirhamsToQAR(totalDvpAmountDirhams);

  const handleTransferSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setTransferRes(null);
    const res = transferWholesale(senderId, receiverId, transferAmountQAR, transferMemo);
    setTransferRes(res);
  };

  const handleDvPSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setDvpRes(null);
    const res = executeDvPSwap(buyerId, sellerId, selectedIsin, dvpQuantity);
    setDvpRes(res);
  };

  return (
    <div className="space-y-6">
      {/* View Title Header */}
      <div className="border-b border-[#1E2633] pb-4">
        <h2 className="text-xl font-bold text-white">Wholesale Settlement & Atomic DvP Engine</h2>
        <p className="text-xs text-slate-400 mt-1">
          24/7 Interbank Gross Settlement & Instant Atomic Delivery vs Payment for Sovereign Securities
        </p>
      </div>

      {/* Grid: Left = Interbank Transfer, Right = Flagship DvP Swap */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Wholesale Interbank Transfer */}
        <div className="bg-[#111622] border border-[#1E2633] rounded-xl p-5 space-y-5">
          <div className="flex items-center justify-between border-b border-[#1E2633] pb-3">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-lg bg-blue-500/20 text-blue-400">
                <ArrowLeftRight className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Wholesale Bank → Bank Transfer</h3>
                <p className="text-[11px] text-slate-400">Immediate Interbank Gross Settlement</p>
              </div>
            </div>
            <span className="text-[10px] font-mono bg-blue-500/10 text-blue-400 border border-blue-500/30 px-2 py-0.5 rounded">
              24/7 RTGS Finality
            </span>
          </div>

          <form onSubmit={handleTransferSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              {/* Sender */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">Sender Bank</label>
                <select
                  value={senderId}
                  onChange={e => setSenderId(e.target.value)}
                  className="w-full bg-[#161F2E] border border-[#2A3447] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#8A1538]"
                >
                  {banks.map(b => (
                    <option key={b.id} value={b.id}>
                      {b.code} ({formatCompactQAR(b.cbdcBalanceDirhams, locale)})
                    </option>
                  ))}
                </select>
              </div>

              {/* Receiver */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">Receiver Bank</label>
                <select
                  value={receiverId}
                  onChange={e => setReceiverId(e.target.value)}
                  className="w-full bg-[#161F2E] border border-[#2A3447] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#8A1538]"
                >
                  {banks.map(b => (
                    <option key={b.id} value={b.id}>
                      {b.code} ({formatCompactQAR(b.cbdcBalanceDirhams, locale)})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Transfer Amount */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">Transfer Amount (QAR)</label>
              <div className="relative">
                <input
                  type="number"
                  min="100000"
                  step="100000"
                  value={transferAmountQAR}
                  onChange={e => setTransferAmountQAR(Number(e.target.value))}
                  className="w-full bg-[#161F2E] border border-[#2A3447] rounded-lg px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-[#8A1538]"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">QAR</span>
              </div>
            </div>

            {/* Memo */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">Settlement Reference / Memo</label>
              <input
                type="text"
                value={transferMemo}
                onChange={e => setTransferMemo(e.target.value)}
                className="w-full bg-[#161F2E] border border-[#2A3447] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#8A1538]"
              />
            </div>

            {/* Submit */}
            <button
              type="submit"
              className="w-full bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold py-2.5 rounded-lg transition-colors flex items-center justify-center gap-2 shadow-lg shadow-blue-600/20"
            >
              <Zap className="w-4 h-4" />
              <span>Execute Gross Interbank Transfer</span>
            </button>
          </form>

          {transferRes && (
            <div className={`p-3.5 rounded-lg text-xs space-y-1 font-mono ${transferRes.success ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-300' : 'bg-red-500/10 border border-red-500/30 text-red-300'}`}>
              <div className="flex items-center gap-2 font-bold font-sans">
                {transferRes.success ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <AlertTriangle className="w-4 h-4 text-red-400" />}
                <span>{transferRes.success ? 'Settlement Finalized' : 'Transfer Failed'}</span>
              </div>
              <p>{transferRes.message}</p>
              {transferRes.txHash && <p className="text-[10px] text-slate-400">Tx Hash: {transferRes.txHash}</p>}
            </div>
          )}
        </div>

        {/* Atomic Delivery versus Payment (DvP) Engine (Prompt Section 13) */}
        <div className="bg-[#111622] border border-[#8A1538]/50 rounded-xl p-5 space-y-5 shadow-xl shadow-[#8A1538]/5">
          <div className="flex items-center justify-between border-b border-[#1E2633] pb-3">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-lg bg-[#8A1538]/20 text-[#8A1538]">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Atomic DvP Settlement Engine</h3>
                <p className="text-[11px] text-slate-400">Simultaneous Security & CBDC Atomic Swap</p>
              </div>
            </div>
            <span className="text-[10px] font-mono bg-[#8A1538] text-white px-2 py-0.5 rounded font-bold">
              Flagship Feature
            </span>
          </div>

          {/* DvP Atomic Visualization Diagram */}
          <div className="bg-[#161F2E] border border-[#222C3D] p-3 rounded-lg flex items-center justify-between text-xs font-mono">
            <div className="text-center">
              <span className="text-slate-400 text-[10px] block">SECURITY LEAF</span>
              <span className="text-emerald-400 font-bold">Digital Sovereign Bond</span>
            </div>
            <div className="text-[#8A1538] font-bold flex flex-col items-center">
              <RefreshCw className="w-4 h-4 animate-spin text-[#8A1538]" />
              <span className="text-[9px] mt-0.5 text-slate-300">14ms Atomic Swap</span>
            </div>
            <div className="text-center">
              <span className="text-slate-400 text-[10px] block">PAYMENT LEAF</span>
              <span className="text-white font-bold">QAR-CBDC Ledger</span>
            </div>
          </div>

          <form onSubmit={handleDvPSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              {/* Buyer */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">Buyer Bank (CBDC Holder)</label>
                <select
                  value={buyerId}
                  onChange={e => setBuyerId(e.target.value)}
                  className="w-full bg-[#161F2E] border border-[#2A3447] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#8A1538]"
                >
                  {banks.map(b => (
                    <option key={b.id} value={b.id}>
                      {b.code} ({formatCompactQAR(b.cbdcBalanceDirhams, locale)})
                    </option>
                  ))}
                </select>
              </div>

              {/* Seller */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">Seller Bank (Security Owner)</label>
                <select
                  value={sellerId}
                  onChange={e => setSellerId(e.target.value)}
                  className="w-full bg-[#161F2E] border border-[#2A3447] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#8A1538]"
                >
                  {banks.map(b => (
                    <option key={b.id} value={b.id}>
                      {b.code}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Select Security */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">Digital Security Instrument</label>
              <select
                value={selectedIsin}
                onChange={e => setSelectedIsin(e.target.value)}
                className="w-full bg-[#161F2E] border border-[#2A3447] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#8A1538]"
              >
                {securities.map(s => (
                  <option key={s.isin} value={s.isin}>
                    {s.titleEn} ({s.isin} — Market Price: QAR {(s.marketPriceDirhams / 100).toFixed(2)})
                  </option>
                ))}
              </select>
            </div>

            {/* Quantity */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">Units Quantity</label>
              <input
                type="number"
                min="1000"
                step="1000"
                value={dvpQuantity}
                onChange={e => setDvpQuantity(Number(e.target.value))}
                className="w-full bg-[#161F2E] border border-[#2A3447] rounded-lg px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-[#8A1538]"
              />
            </div>

            {/* Total Calculation Display */}
            <div className="bg-[#161F2E] p-3 rounded-lg border border-[#222C3D] flex items-center justify-between text-xs font-mono">
              <span className="text-slate-400">Total CBDC Settlement Value:</span>
              <span className="text-lg font-bold text-emerald-400">{formatQAR(totalDvpAmountDirhams, locale)}</span>
            </div>

            {/* Execute DvP Button */}
            <button
              type="submit"
              className="w-full bg-[#8A1538] hover:bg-[#A31942] text-white text-xs font-bold py-2.5 rounded-lg transition-colors flex items-center justify-center gap-2 shadow-lg shadow-[#8A1538]/20"
            >
              <Zap className="w-4 h-4" />
              <span>Execute Atomic DvP Swap</span>
            </button>
          </form>

          {dvpRes && (
            <div className={`p-3.5 rounded-lg text-xs space-y-1 font-mono ${dvpRes.success ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-300' : 'bg-red-500/10 border border-red-500/30 text-red-300'}`}>
              <div className="flex items-center gap-2 font-bold font-sans">
                {dvpRes.success ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <AlertTriangle className="w-4 h-4 text-red-400" />}
                <span>{dvpRes.success ? 'Atomic DvP Swap Settled (14ms)' : 'DvP Execution Failed'}</span>
              </div>
              <p>{dvpRes.message}</p>
              {dvpRes.contractId && <p className="text-[10px] text-slate-400">Contract Ref: {dvpRes.contractId}</p>}
            </div>
          )}
        </div>
      </div>

      {/* Comparison Box: Atomic DvP vs Traditional Settlement Risk */}
      <div className="bg-[#111622] border border-[#1E2633] rounded-xl p-5 space-y-3">
        <h3 className="text-sm font-bold text-white">DvP Architectural Advantage vs Legacy T+2 Rails</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <div className="bg-red-950/20 border border-red-500/30 p-3.5 rounded-lg space-y-1 text-slate-300">
            <span className="text-red-400 font-bold block font-sans">Traditional T+2 / Deferred Settlement</span>
            <p>Cash and security move through separate decoupled legacy systems. Risk of principal loss if counterpart defaults between trade and cash settlement.</p>
          </div>
          <div className="bg-emerald-950/20 border border-emerald-500/30 p-3.5 rounded-lg space-y-1 text-slate-300">
            <span className="text-emerald-400 font-bold block font-sans">QAR-CBDC Atomic Delivery vs Payment</span>
            <p>Cryptographically bound smart ledger swap. CBDC and digital security transfer execute simultaneously or both abort cleanly. Zero settlement lag or principal risk.</p>
          </div>
        </div>
      </div>
    </div>
  );
};
