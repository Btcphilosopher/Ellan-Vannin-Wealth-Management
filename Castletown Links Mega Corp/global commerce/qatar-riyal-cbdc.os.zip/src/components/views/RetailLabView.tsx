import React, { useState } from 'react';
import { useCBDC } from '../../context/CBDCContext';
import { formatQAR, formatCompactQAR, dirhamsToQAR } from '../../utils/formatters';
import { Smartphone, QrCode, WifiOff, RefreshCw, Send, ArrowDownLeft, CheckCircle2, ShieldCheck, Zap } from 'lucide-react';

export const RetailLabView: React.FC = () => {
  const { retailWallets, merchants, executeRetailPayment, syncOfflineWallet, t, locale } = useCBDC();

  const selectedWallet = retailWallets[0];
  const [merchantId, setMerchantId] = useState<string>(merchants[0]?.id || '');
  const [payAmountQAR, setPayAmountQAR] = useState<number>(125.00); // QAR 125.00 (e.g. Doha Metro)
  const [isOfflineMode, setIsOfflineMode] = useState<boolean>(false);
  const [payRes, setPayRes] = useState<{ success: boolean; message: string } | null>(null);

  const handlePayment = (e: React.FormEvent) => {
    e.preventDefault();
    setPayRes(null);
    if (!selectedWallet) return;
    const res = executeRetailPayment(selectedWallet.id, merchantId, payAmountQAR, isOfflineMode);
    setPayRes(res);
  };

  const handleSync = () => {
    if (!selectedWallet) return;
    const res = syncOfflineWallet(selectedWallet.id);
    alert(res.message);
  };

  return (
    <div className="space-y-6">
      {/* Header with Lab Disclaimer Banner */}
      <div className="border-b border-[#1E2633] pb-4">
        <div className="flex items-center gap-2">
          <h2 className="text-xl font-bold text-white">Experimental Retail CBDC & Offline Payment Lab</h2>
          <span className="bg-purple-500/20 text-purple-300 border border-purple-500/40 text-[10px] font-mono px-2 py-0.5 rounded font-bold uppercase">
            EXPERIMENTAL RETAIL MODEL
          </span>
        </div>
        <p className="text-xs text-slate-400 mt-1">
          Simulated Citizen Digital Wallets, QR Instant POS Settlement & Hardware-Encrypted Device-to-Device Offline Transfers
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Mobile Citizen Wallet Frame (Prompt Section 17 UI mockup) */}
        <div className="bg-[#111622] border border-[#1E2633] rounded-2xl p-6 space-y-6 shadow-2xl relative overflow-hidden">
          {/* Top Status Bar */}
          <div className="flex items-center justify-between text-xs text-slate-400 border-b border-[#1E2633] pb-3">
            <span className="font-bold text-white tracking-wide">QATAR RIYAL DIGITAL</span>
            <div className="flex items-center gap-2 font-mono">
              <span className="bg-[#8A1538] text-white text-[9px] px-1.5 py-0.5 rounded font-bold">CITIZEN</span>
              {isOfflineMode ? (
                <span className="text-amber-400 flex items-center gap-1 text-[10px]">
                  <WifiOff className="w-3 h-3" /> OFFLINE HARDWARE
                </span>
              ) : (
                <span className="text-emerald-400 text-[10px]">● ONLINE</span>
              )}
            </div>
          </div>

          {/* Citizen Balance Display (Section 17 Format) */}
          <div className="bg-gradient-to-br from-[#161F2E] to-[#111622] border border-[#222C3D] p-5 rounded-xl space-y-2 text-center">
            <span className="text-xs text-slate-400 font-medium">Available Balance</span>
            <div className="text-3xl font-extrabold text-white tracking-tight tabular-nums">
              {formatQAR(selectedWallet.balanceDirhams, locale)}
            </div>
            <div className="flex items-center justify-center gap-4 text-xs font-mono pt-2 text-slate-400 border-t border-slate-800">
              <span>Offline Enclave: <strong className="text-emerald-400">{formatQAR(selectedWallet.offlineBalanceDirhams, locale)}</strong></span>
            </div>
          </div>

          {/* Wallet Action Buttons Grid */}
          <div className="grid grid-cols-4 gap-2">
            <button className="bg-[#161F2E] hover:bg-[#8A1538] text-slate-200 hover:text-white p-3 rounded-xl flex flex-col items-center gap-1 transition-colors text-xs font-medium">
              <Send className="w-4 h-4" />
              <span>{locale === 'ar' ? 'إرسال' : 'SEND'}</span>
            </button>
            <button className="bg-[#161F2E] hover:bg-[#8A1538] text-slate-200 hover:text-white p-3 rounded-xl flex flex-col items-center gap-1 transition-colors text-xs font-medium">
              <ArrowDownLeft className="w-4 h-4" />
              <span>{locale === 'ar' ? 'طلب' : 'REQUEST'}</span>
            </button>
            <button className="bg-[#161F2E] hover:bg-[#8A1538] text-slate-200 hover:text-white p-3 rounded-xl flex flex-col items-center gap-1 transition-colors text-xs font-medium">
              <QrCode className="w-4 h-4" />
              <span>{locale === 'ar' ? 'مسح' : 'SCAN'}</span>
            </button>
            <button
              onClick={handleSync}
              className="bg-[#161F2E] hover:bg-emerald-600 text-slate-200 hover:text-white p-3 rounded-xl flex flex-col items-center gap-1 transition-colors text-xs font-medium"
            >
              <RefreshCw className="w-4 h-4" />
              <span>{locale === 'ar' ? 'مزامنة' : 'SYNC'}</span>
            </button>
          </div>

          {/* Mode Switcher: Online vs Device-to-Device Offline */}
          <div className="bg-[#161F2E] p-1.5 rounded-lg flex items-center justify-between text-xs">
            <span className="text-slate-300 font-medium px-2">Payment Mechanism:</span>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setIsOfflineMode(false)}
                className={`px-3 py-1 rounded text-xs font-semibold transition-colors ${!isOfflineMode ? 'bg-[#8A1538] text-white' : 'text-slate-400 hover:text-white'}`}
              >
                Online QR
              </button>
              <button
                onClick={() => setIsOfflineMode(true)}
                className={`px-3 py-1 rounded text-xs font-semibold transition-colors ${isOfflineMode ? 'bg-amber-600 text-white' : 'text-slate-400 hover:text-white'}`}
              >
                D2D Offline
              </button>
            </div>
          </div>
        </div>

        {/* Instant Merchant QR Simulator */}
        <div className="bg-[#111622] border border-[#1E2633] rounded-2xl p-6 space-y-5">
          <div className="border-b border-[#1E2633] pb-3">
            <h3 className="text-sm font-bold text-white">Merchant Instant Settlement Terminal</h3>
            <p className="text-xs text-slate-400">Simulate POS Merchant QR Code Payment or Offline Tap</p>
          </div>

          <form onSubmit={handlePayment} className="space-y-4">
            {/* Merchant Selector */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">Target Merchant / Outlet</label>
              <select
                value={merchantId}
                onChange={e => setMerchantId(e.target.value)}
                className="w-full bg-[#161F2E] border border-[#2A3447] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#8A1538]"
              >
                {merchants.map(m => (
                  <option key={m.id} value={m.id}>
                    {locale === 'ar' ? m.businessNameAr : m.businessNameEn} ({m.category})
                  </option>
                ))}
              </select>
            </div>

            {/* Payment Amount */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">Payment Amount (QAR)</label>
              <div className="relative">
                <input
                  type="number"
                  min="1"
                  step="0.5"
                  value={payAmountQAR}
                  onChange={e => setPayAmountQAR(Number(e.target.value))}
                  className="w-full bg-[#161F2E] border border-[#2A3447] rounded-lg px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-[#8A1538]"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">QAR</span>
              </div>
            </div>

            {/* Submit */}
            <button
              type="submit"
              className={`w-full text-white text-xs font-bold py-3 rounded-xl transition-colors flex items-center justify-center gap-2 shadow-lg ${
                isOfflineMode ? 'bg-amber-600 hover:bg-amber-700 shadow-amber-600/20' : 'bg-[#8A1538] hover:bg-[#A31942] shadow-[#8A1538]/20'
              }`}
            >
              <QrCode className="w-4 h-4" />
              <span>{isOfflineMode ? 'Execute Device-to-Device Offline Payment' : 'Execute Instant QR Retail Settlement'}</span>
            </button>
          </form>

          {/* Payment Receipt */}
          {payRes && (
            <div className={`p-4 rounded-xl text-xs space-y-1.5 font-mono ${payRes.success ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-300' : 'bg-red-500/10 border border-red-500/30 text-red-300'}`}>
              <div className="flex items-center gap-2 font-bold font-sans">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>PAID — SETTLED</span>
              </div>
              <p>{payRes.message}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
