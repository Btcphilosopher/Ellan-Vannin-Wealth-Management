import React, { useState } from 'react';
import { useCBDC } from '../../context/CBDCContext';
import { Flame, AlertTriangle, Play, ShieldCheck, CheckCircle2, Activity } from 'lucide-react';

export const StressLabView: React.FC = () => {
  const { triggerStressScenario, setSimulationSpeed, simulationSpeed, t } = useCBDC();
  const [activeScenario, setActiveScenario] = useState<string>('NORMAL');
  const [log, setLog] = useState<string[]>(['[08:00:00] Stress Lab Initialized. System Nominal.']);

  const runScenario = (id: 'VOLUME_SURGE' | 'BANK_DISCONNECT' | 'LIQUIDITY_FREEZE', name: string) => {
    setActiveScenario(id);
    const timestamp = new Date().toLocaleTimeString();
    setLog(prev => [
      `[${timestamp}] INJECTED SCENARIO: ${name}`,
      `[${timestamp}] Monitoring Queue Capacity & Auto-Hedging...`,
      ...prev
    ]);
    triggerStressScenario(id);
  };

  const resetNormal = () => {
    setActiveScenario('NORMAL');
    setSimulationSpeed(1);
    const timestamp = new Date().toLocaleTimeString();
    setLog(prev => [`[${timestamp}] RESTORED NORMAL OPERATING CONDITIONS.`, ...prev]);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="border-b border-[#1E2633] pb-4">
        <div className="flex items-center gap-2">
          <h2 className="text-xl font-bold text-white">Central Bank Resilience & Stress Testing Lab</h2>
          <span className="bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-mono px-2 py-0.5 rounded font-bold">
            Simulated Shock Tests
          </span>
        </div>
        <p className="text-xs text-slate-400 mt-1">
          Evaluate System Finality, Liquidity Buffer Queues & Participant Failures Under Extremes
        </p>
      </div>

      {/* Scenario Selection Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Scenario 1: Payment Volume Surge */}
        <div className={`bg-[#111622] border rounded-xl p-5 space-y-4 transition-all ${activeScenario === 'VOLUME_SURGE' ? 'border-amber-500 bg-amber-950/10' : 'border-[#1E2633]'}`}>
          <div className="flex items-center justify-between border-b border-[#1E2633] pb-3">
            <div className="flex items-center gap-2">
              <Activity className="w-5 h-5 text-amber-400" />
              <h3 className="text-sm font-bold text-white">Payment Surge (+300%)</h3>
            </div>
            <span className="text-[10px] font-mono bg-amber-500/10 text-amber-300 px-2 py-0.5 rounded">High Throughput</span>
          </div>
          <p className="text-xs text-slate-400">
            Inject +300% transaction surge across all wholesale participant banks. Test processing queue bounds.
          </p>
          <button
            onClick={() => runScenario('VOLUME_SURGE', '300% Intraday Volume Surge')}
            className="w-full bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold py-2 rounded-lg transition-colors flex items-center justify-center gap-2"
          >
            <Play className="w-3.5 h-3.5" />
            <span>Inject Volume Surge</span>
          </button>
        </div>

        {/* Scenario 2: Node Failure / Bank Disconnect */}
        <div className={`bg-[#111622] border rounded-xl p-5 space-y-4 transition-all ${activeScenario === 'BANK_DISCONNECT' ? 'border-red-500 bg-red-950/10' : 'border-[#1E2633]'}`}>
          <div className="flex items-center justify-between border-b border-[#1E2633] pb-3">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-red-400" />
              <h3 className="text-sm font-bold text-white">Participant Disconnection</h3>
            </div>
            <span className="text-[10px] font-mono bg-red-500/10 text-red-300 px-2 py-0.5 rounded">Node Outage</span>
          </div>
          <p className="text-xs text-slate-400">
            Simulate sudden network outage for Doha Bank. Verify interbank liquidity re-routing and pending queue safety.
          </p>
          <button
            onClick={() => runScenario('BANK_DISCONNECT', 'Doha Bank Node Outage')}
            className="w-full bg-red-600 hover:bg-red-700 text-white text-xs font-bold py-2 rounded-lg transition-colors flex items-center justify-center gap-2"
          >
            <Play className="w-3.5 h-3.5" />
            <span>Simulate Node Failure</span>
          </button>
        </div>

        {/* Scenario 3: Liquidity Shock & Freeze */}
        <div className={`bg-[#111622] border rounded-xl p-5 space-y-4 transition-all ${activeScenario === 'LIQUIDITY_FREEZE' ? 'border-purple-500 bg-purple-950/10' : 'border-[#1E2633]'}`}>
          <div className="flex items-center justify-between border-b border-[#1E2633] pb-3">
            <div className="flex items-center gap-2">
              <Flame className="w-5 h-5 text-purple-400" />
              <h3 className="text-sm font-bold text-white">Intraday Liquidity Freeze</h3>
            </div>
            <span className="text-[10px] font-mono bg-purple-500/10 text-purple-300 px-2 py-0.5 rounded">Emergency Facility</span>
          </div>
          <p className="text-xs text-slate-400">
            Simulate interbank liquidity gridlock. Trigger automated QCB Intraday Collateralized Liquidity Injection.
          </p>
          <button
            onClick={() => runScenario('LIQUIDITY_FREEZE', 'QCB Emergency Liquidity Injection')}
            className="w-full bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold py-2 rounded-lg transition-colors flex items-center justify-center gap-2"
          >
            <Play className="w-3.5 h-3.5" />
            <span>Trigger Liquidity Facility</span>
          </button>
        </div>
      </div>

      {/* Restore Nominal State Button */}
      <div className="flex items-center justify-between bg-[#111622] p-4 rounded-xl border border-[#1E2633]">
        <div>
          <h4 className="text-sm font-bold text-white">System Status Control</h4>
          <p className="text-xs text-slate-400">Current Mode: <span className="text-emerald-400 font-mono font-bold">{activeScenario}</span></p>
        </div>
        <button
          onClick={resetNormal}
          className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-4 py-2 rounded-lg transition-colors flex items-center gap-2"
        >
          <CheckCircle2 className="w-4 h-4" />
          <span>Restore Nominal Operations</span>
        </button>
      </div>

      {/* Live Stress Console Execution Log */}
      <div className="bg-[#0B0E14] border border-[#1E2633] rounded-xl p-4 font-mono text-xs space-y-2">
        <div className="flex items-center justify-between text-slate-400 text-[11px] border-b border-slate-800 pb-2">
          <span>STRESS TEST TELEMETRY STREAM</span>
          <span className="text-emerald-400">STATUS: AUDITED</span>
        </div>
        <div className="space-y-1.5 h-40 overflow-y-auto text-slate-300 text-[11px]">
          {log.map((entry, idx) => (
            <div key={idx} className={entry.includes('INJECTED') ? 'text-amber-300 font-bold' : entry.includes('RESTORED') ? 'text-emerald-400 font-bold' : 'text-slate-400'}>
              {entry}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
