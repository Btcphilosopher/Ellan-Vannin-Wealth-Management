import React from 'react';
import { useCBDC } from '../../context/CBDCContext';
import { MapPin, Navigation, Landmark, Zap } from 'lucide-react';

export const DohaMapView: React.FC = () => {
  const { transactions, locale } = useCBDC();

  // Nodes in Doha Geographic Simulation Abstraction
  const nodes = [
    { id: 'QCB', nameEn: 'QCB West Bay HQ', nameAr: 'مقر البنك المركزي - الدوحة', x: 50, y: 35, color: '#8A1538', type: 'Central Bank' },
    { id: 'QNB', nameEn: 'QNB Financial Center', nameAr: 'مركز QNB المالي', x: 42, y: 40, color: '#10B981', type: 'Commercial Bank' },
    { id: 'HIA', nameEn: 'Hamad International Airport', nameAr: 'مطار حمد الدولي', x: 75, y: 70, color: '#3B82F6', type: 'Trade & Logistics' },
    { id: 'LUSAIL', nameEn: 'Lusail Financial Hub', nameAr: 'مدينة لوسيل المالي', x: 38, y: 20, color: '#F59E0B', type: 'Digital Smart Hub' },
    { id: 'KATARA', nameEn: 'Katara Hospitality Hub', nameAr: 'الحي الثقافي كتارا', x: 48, y: 28, color: '#EC4899', type: 'Retail & Tourism' },
    { id: 'PORT', nameEn: 'Doha Commercial Port', nameAr: 'ميناء الدوحة التجاري', x: 68, y: 45, color: '#8B5CF6', type: 'Maritime Settlement' }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="border-b border-[#1E2633] pb-4">
        <h2 className="text-xl font-bold text-white">Doha Digital Money Flow — Spatial Simulation</h2>
        <p className="text-xs text-slate-400 mt-1">
          Simulated Real-time Settlement Vectors Across Qatari Monetary Hubs (West Bay, Lusail, HIA, Katara & Ports)
        </p>
      </div>

      {/* Interactive Spatial Canvas Card */}
      <div className="bg-[#111622] border border-[#1E2633] rounded-2xl p-6 relative overflow-hidden">
        {/* Background Image Scrim */}
        <div className="absolute inset-0 opacity-20 pointer-events-none">
          <img
            src="/src/assets/images/doha_skyline_dusk_1790344462247.jpg"
            alt="Doha Skyline"
            className="w-full h-full object-cover filter blur-sm"
          />
        </div>

        {/* Map Header Overlay */}
        <div className="relative z-10 flex items-center justify-between border-b border-[#1E2633] pb-4 mb-4">
          <div className="flex items-center gap-2">
            <Navigation className="w-5 h-5 text-[#8A1538]" />
            <span className="text-sm font-bold text-white font-mono">DOHA SETTLEMENT MAP NODE VECTOR ENGINE</span>
          </div>
          <span className="text-xs bg-[#161F2E] text-emerald-400 border border-emerald-500/30 px-2.5 py-1 rounded font-mono">
            ● 6 Active Nodes Connected
          </span>
        </div>

        {/* Spatial Map SVG Canvas */}
        <div className="relative z-10 w-full h-[400px] bg-[#0B0E14]/80 rounded-xl border border-[#1E2633] overflow-hidden flex items-center justify-center">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            {/* Animated Connector Rays */}
            <line x1="50" y1="35" x2="42" y2="40" stroke="#8A1538" strokeWidth="0.8" strokeDasharray="1,1" className="animate-pulse" />
            <line x1="50" y1="35" x2="75" y2="70" stroke="#3B82F6" strokeWidth="0.8" strokeDasharray="1,1" />
            <line x1="50" y1="35" x2="38" y2="20" stroke="#F59E0B" strokeWidth="0.8" strokeDasharray="1,1" />
            <line x1="50" y1="35" x2="48" y2="28" stroke="#EC4899" strokeWidth="0.8" strokeDasharray="1,1" />
            <line x1="50" y1="35" x2="68" y2="45" stroke="#8B5CF6" strokeWidth="0.8" strokeDasharray="1,1" />

            {/* Nodes */}
            {nodes.map(n => (
              <g key={n.id} className="cursor-pointer">
                {/* Outer Glow Ring */}
                <circle cx={n.x} cy={n.y} r="3" fill={n.color} fillOpacity="0.2">
                  <animate attributeName="r" values="3;5;3" dur="3s" repeatCount="indefinite" />
                </circle>
                {/* Solid Point */}
                <circle cx={n.x} cy={n.y} r="1.5" fill={n.color} stroke="#FFFFFF" strokeWidth="0.3" />
                {/* Text Label */}
                <text x={n.x + 2.5} y={n.y + 1} fill="#F1F5F9" fontSize="2.8" fontWeight="bold" fontFamily="sans-serif">
                  {locale === 'ar' ? n.nameAr : n.nameEn}
                </text>
              </g>
            ))}
          </svg>
        </div>

        {/* Legend */}
        <div className="relative z-10 mt-4 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2 text-xs font-mono">
          {nodes.map(n => (
            <div key={n.id} className="bg-[#161F2E] p-2 rounded-lg border border-[#222C3D] flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: n.color }}></span>
              <span className="text-slate-300 truncate">{n.id}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
