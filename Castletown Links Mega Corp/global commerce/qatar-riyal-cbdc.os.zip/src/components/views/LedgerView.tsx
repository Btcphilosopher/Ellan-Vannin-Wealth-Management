import React, { useState } from 'react';
import { useCBDC } from '../../context/CBDCContext';
import { formatQAR, formatTimestamp } from '../../utils/formatters';
import { Layers, Search, CheckCircle2, ShieldCheck, Copy, Check, Filter } from 'lucide-react';

export const LedgerView: React.FC = () => {
  const { transactions, t, locale } = useCBDC();
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterType, setFilterType] = useState<string>('ALL');
  const [copiedHash, setCopiedHash] = useState<string | null>(null);

  const filteredTxs = transactions.filter(tx => {
    const matchesSearch = 
      tx.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tx.txHash.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tx.senderNameEn.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tx.receiverNameEn.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesType = filterType === 'ALL' || tx.type === filterType;

    return matchesSearch && matchesType;
  });

  const handleCopy = (hash: string) => {
    navigator.clipboard.writeText(hash);
    setCopiedHash(hash);
    setTimeout(() => setCopiedHash(null), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="border-b border-[#1E2633] pb-4">
        <h2 className="text-xl font-bold text-white">Permissioned CBDC Cryptographic Ledger</h2>
        <p className="text-xs text-slate-400 mt-1">
          Append-Only Dual-Entry Event Stream with Previous Hash Chaining & Instant Finality Verification
        </p>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-[#111622] p-3 rounded-xl border border-[#1E2633]">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by TX ID, Hash, Bank..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full bg-[#161F2E] border border-[#2A3447] text-white text-xs rounded-lg pl-9 pr-3 py-2 focus:outline-none focus:border-[#8A1538]"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <Filter className="w-4 h-4 text-slate-400" />
          <select
            value={filterType}
            onChange={e => setFilterType(e.target.value)}
            className="bg-[#161F2E] border border-[#2A3447] text-slate-200 text-xs rounded-lg px-3 py-2 focus:outline-none focus:border-[#8A1538]"
          >
            <option value="ALL">All Event Types</option>
            <option value="ISSUANCE">Issuance (Mint)</option>
            <option value="REDEMPTION">Redemption (Burn)</option>
            <option value="WHOLESALE_TRANSFER">Wholesale Interbank</option>
            <option value="DVP_SETTLEMENT">Atomic DvP Swap</option>
            <option value="RETAIL_TRANSFER">Retail Transfer</option>
          </select>
        </div>
      </div>

      {/* Ledger Table */}
      <div className="bg-[#111622] border border-[#1E2633] rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="bg-[#161F2E] text-slate-400 border-b border-[#1E2633]">
                <th className="py-3 px-4 font-semibold">Block / TX Ref</th>
                <th className="py-3 px-4 font-semibold">Event Hash Chain</th>
                <th className="py-3 px-4 font-semibold">Type</th>
                <th className="py-3 px-4 font-semibold font-sans">Sender → Receiver</th>
                <th className="py-3 px-4 text-right font-semibold">Amount (QAR)</th>
                <th className="py-3 px-4 text-center font-semibold">Finality</th>
                <th className="py-3 px-4 text-right font-semibold">Timestamp</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1E2633]">
              {filteredTxs.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-500 font-sans">
                    No matching ledger records found.
                  </td>
                </tr>
              ) : (
                filteredTxs.map(tx => (
                  <tr key={tx.id} className="hover:bg-[#161F2E] transition-colors">
                    <td className="py-3 px-4">
                      <div className="font-bold text-white">#{tx.blockNumber}</div>
                      <span className="text-[10px] text-slate-500">{tx.id}</span>
                    </td>

                    {/* Hash & Previous Hash Stack */}
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-1.5 text-[#8A1538] font-bold">
                        <span>{tx.txHash.slice(0, 12)}...{tx.txHash.slice(-6)}</span>
                        <button
                          onClick={() => handleCopy(tx.txHash)}
                          className="p-1 hover:bg-[#8A1538]/20 rounded text-slate-400 hover:text-white transition-colors"
                          title="Copy Event Hash"
                        >
                          {copiedHash === tx.txHash ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                        </button>
                      </div>
                      <div className="text-[10px] text-slate-500">
                        Prev: {tx.prevHash.slice(0, 10)}...
                      </div>
                    </td>

                    <td className="py-3 px-4">
                      <span className="bg-[#161F2E] text-slate-300 text-[10px] font-bold px-2 py-0.5 rounded border border-slate-700">
                        {tx.type}
                      </span>
                    </td>

                    <td className="py-3 px-4 font-sans">
                      <div className="text-white font-medium">
                        {locale === 'ar' ? tx.senderNameAr : tx.senderNameEn}
                      </div>
                      <div className="text-[11px] text-slate-400">
                        → {locale === 'ar' ? tx.receiverNameAr : tx.receiverNameEn}
                      </div>
                    </td>

                    <td className="py-3 px-4 text-right font-bold text-emerald-400 text-sm">
                      {formatQAR(tx.amountDirhams, locale)}
                    </td>

                    <td className="py-3 px-4 text-center">
                      <span className="inline-flex items-center gap-1 text-[10px] text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 rounded font-sans">
                        <CheckCircle2 className="w-3 h-3" />
                        SETTLED
                      </span>
                    </td>

                    <td className="py-3 px-4 text-right text-slate-400 text-[11px]">
                      {formatTimestamp(tx.timestamp, locale)}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
