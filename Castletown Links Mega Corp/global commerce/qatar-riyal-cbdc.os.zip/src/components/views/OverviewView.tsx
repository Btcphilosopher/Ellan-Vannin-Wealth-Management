import React from 'react';
import { useCBDC } from '../../context/CBDCContext';
import { formatCompactQAR, formatQAR, formatTimestamp } from '../../utils/formatters';
import {
  TrendingUp,
  Coins,
  Building2,
  ArrowUpRight,
  ShieldCheck,
  Zap,
  Activity,
  Layers,
  CheckCircle2,
  Lock
} from 'lucide-react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';

export const OverviewView: React.FC = () => {
  const { systemMetrics, transactions, banks, t, locale, setActiveView } = useCBDC();

  // Chart data for liquidity allocation
  const pieData = banks.map(b => ({
    name: b.code,
    value: b.cbdcBalanceDirhams / 100,
    color: b.code === 'QNB' ? '#8A1538' : b.code === 'CBQ' ? '#10B981' : b.code === 'QIB' ? '#3B82F6' : '#F59E0B'
  }));

  // Synthetic 24h settlement activity curve
  const activityData = [
    { time: '08:00', volume: 1.2 },
    { time: '09:00', volume: 4.8 },
    { time: '10:00', volume: 8.5 },
    { time: '11:00', volume: 12.1 },
    { time: '12:00', volume: 9.4 },
    { time: '13:00', volume: 15.8 },
    { time: '14:00', volume: 18.2 },
    { time: '15:00', volume: 22.4 },
    { time: '16:00', volume: 31.7 }
  ];

  return (
    <div className="space-y-6">
      {/* Top Section Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#1E2633] pb-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold text-white font-sans">{t.appTitle}</h2>
            <span className="text-xs bg-[#161F2E] text-emerald-400 border border-emerald-500/30 font-mono px-2 py-0.5 rounded">
              CENTRAL BANK CONSOLE
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time Sovereign Monetary Operations, Wholesale Settlement & Ledger Governance
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveView('DEMO_WIZARDS')}
            className="bg-[#8A1538] hover:bg-[#A31942] text-white text-xs font-semibold px-3.5 py-2 rounded-lg transition-colors flex items-center gap-1.5 shadow-lg shadow-[#8A1538]/20"
          >
            <Zap className="w-4 h-4" />
            <span>Launch Signature Demos</span>
          </button>
        </div>
      </div>

      {/* Primary Central Bank KPI Dashboard Grid (Matches Prompt Section 7 Specification) */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {/* Metric 1: CBDC in Circulation */}
        <div className="bg-[#111622] border border-[#1E2633] rounded-xl p-4 space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400 font-medium">
            <span>{t.circulation}</span>
            <Coins className="w-4 h-4 text-[#8A1538]" />
          </div>
          <div className="text-xl font-bold text-white tabular-nums">
            {formatCompactQAR(systemMetrics.totalCirculationDirhams, locale)}
          </div>
          <div className="text-[11px] text-emerald-400 flex items-center gap-1 font-mono">
            <TrendingUp className="w-3 h-3" />
            <span>Direct Central Bank Liability</span>
          </div>
        </div>

        {/* Metric 2: Active Participants */}
        <div className="bg-[#111622] border border-[#1E2633] rounded-xl p-4 space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400 font-medium">
            <span>{t.activeParticipants}</span>
            <Building2 className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-xl font-bold text-white tabular-nums">
            {systemMetrics.activeParticipantsCount} Banks & Entities
          </div>
          <div className="text-[11px] text-slate-400 font-mono">
            RTGS Connected & Audited
          </div>
        </div>

        {/* Metric 3: Transactions Today */}
        <div className="bg-[#111622] border border-[#1E2633] rounded-xl p-4 space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400 font-medium">
            <span>{t.txToday}</span>
            <Activity className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-xl font-bold text-white tabular-nums">
            {systemMetrics.transactionsTodayCount.toLocaleString()}
          </div>
          <div className="text-[11px] text-emerald-400 font-mono">
            100% Finalized (0 Rejections)
          </div>
        </div>

        {/* Metric 4: Settlement Value */}
        <div className="bg-[#111622] border border-[#1E2633] rounded-xl p-4 space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-400 font-medium">
            <span>{t.settlementValue}</span>
            <Zap className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-xl font-bold text-white tabular-nums">
            {formatCompactQAR(systemMetrics.settlementVolumeTodayDirhams, locale)}
          </div>
          <div className="text-[11px] text-slate-400 font-mono">
            Avg Finality: 14ms
          </div>
        </div>
      </div>

      {/* Secondary Metrics Bar */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-[#111622] border border-[#1E2633] rounded-xl p-3.5 flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-400 font-medium">{t.availableLiquidity}</div>
            <div className="text-base font-bold text-white tabular-nums mt-0.5">
              {formatCompactQAR(systemMetrics.rtgsCollateralLockedDirhams, locale)}
            </div>
          </div>
          <Lock className="w-5 h-5 text-emerald-400 bg-emerald-500/10 p-1 rounded" />
        </div>

        <div className="bg-[#111622] border border-[#1E2633] rounded-xl p-3.5 flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-400 font-medium">{t.pendingSettlement}</div>
            <div className="text-base font-bold text-amber-300 tabular-nums mt-0.5">
              {formatCompactQAR(systemMetrics.pendingSettlementDirhams, locale)}
            </div>
          </div>
          <Layers className="w-5 h-5 text-amber-400 bg-amber-500/10 p-1 rounded" />
        </div>

        <div className="bg-[#111622] border border-[#1E2633] rounded-xl p-3.5 flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-400 font-medium">{t.digitalSecurities}</div>
            <div className="text-base font-bold text-white tabular-nums mt-0.5">
              {formatCompactQAR(systemMetrics.digitalSecuritiesValueDirhams, locale)}
            </div>
          </div>
          <ShieldCheck className="w-5 h-5 text-blue-400 bg-blue-500/10 p-1 rounded" />
        </div>
      </div>

      {/* Main Charts & Distribution Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Intraday Settlement Throughput Chart */}
        <div className="lg:col-span-2 bg-[#111622] border border-[#1E2633] rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-[#1E2633] pb-3">
            <div>
              <h3 className="text-sm font-bold text-white">Intraday CBDC Settlement Velocity</h3>
              <p className="text-xs text-slate-400">Cumulative Real-time Gross Settlement Value (QAR Billions)</p>
            </div>
            <span className="text-xs font-mono bg-[#161F2E] text-emerald-400 px-2.5 py-1 rounded border border-emerald-500/30">
              Live Feed
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={activityData}>
                <defs>
                  <linearGradient id="colorVolume" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#8A1538" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#8A1538" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="time" stroke="#64748B" fontSize={11} />
                <YAxis stroke="#64748B" fontSize={11} unit="B" />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0B0E14', borderColor: '#1E2633', borderRadius: '8px' }}
                  labelStyle={{ color: '#94A3B8' }}
                  formatter={(value: any) => [`QAR ${value}bn`, 'Settlement Volume']}
                />
                <Area type="monotone" dataKey="volume" stroke="#8A1538" strokeWidth={2} fillOpacity={1} fill="url(#colorVolume)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* CBDC Participant Allocation Pie Chart */}
        <div className="bg-[#111622] border border-[#1E2633] rounded-xl p-5 space-y-4">
          <div className="border-b border-[#1E2633] pb-3">
            <h3 className="text-sm font-bold text-white">Participant Liquidity Allocation</h3>
            <p className="text-xs text-slate-400">CBDC Holdings Distribution by Bank</p>
          </div>

          <div className="h-48 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={45}
                  outerRadius={70}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0B0E14', borderColor: '#1E2633', borderRadius: '8px' }}
                  formatter={(val: any) => [`QAR ${(val / 1000000).toFixed(0)}M`, 'CBDC Balance']}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="space-y-1.5 pt-2">
            {banks.slice(0, 4).map(b => (
              <div key={b.id} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full" style={{ backgroundColor: b.code === 'QNB' ? '#8A1538' : b.code === 'CBQ' ? '#10B981' : b.code === 'QIB' ? '#3B82F6' : '#F59E0B' }}></span>
                  <span className="text-slate-300 font-medium">{b.code}</span>
                </div>
                <span className="text-slate-200 font-mono font-semibold">
                  {formatCompactQAR(b.cbdcBalanceDirhams, locale)}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Live Permissioned Ledger Activity Feed */}
      <div className="bg-[#111622] border border-[#1E2633] rounded-xl p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-[#1E2633] pb-3">
          <div>
            <h3 className="text-sm font-bold text-white">Live Permissioned Ledger Events</h3>
            <p className="text-xs text-slate-400">Append-Only Event Stream with Hash Verification</p>
          </div>
          <button
            onClick={() => setActiveView('LEDGER')}
            className="text-xs text-[#8A1538] hover:text-[#A31942] font-semibold flex items-center gap-1"
          >
            <span>Open Full Ledger Explorer</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-[#1E2633] text-slate-400 font-medium">
                <th className="py-2 px-3">TX Hash</th>
                <th className="py-2 px-3">Type</th>
                <th className="py-2 px-3">Sender → Receiver</th>
                <th className="py-2 px-3 text-right">Amount</th>
                <th className="py-2 px-3 text-center">Status</th>
                <th className="py-2 px-3 text-right">Timestamp</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1E2633]/50 text-slate-300 font-mono">
              {transactions.slice(0, 5).map(tx => (
                <tr key={tx.id} className="hover:bg-[#161F2E] transition-colors">
                  <td className="py-2.5 px-3 text-[#8A1538] font-semibold">
                    {tx.txHash.slice(0, 10)}...{tx.txHash.slice(-6)}
                  </td>
                  <td className="py-2.5 px-3">
                    <span className="bg-[#161F2E] text-slate-300 text-[10px] px-2 py-0.5 rounded border border-slate-700">
                      {tx.type}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 font-sans">
                    <span className="text-slate-200">{locale === 'ar' ? tx.senderNameAr : tx.senderNameEn}</span>
                    <span className="text-slate-500 mx-1.5">→</span>
                    <span className="text-slate-200">{locale === 'ar' ? tx.receiverNameAr : tx.receiverNameEn}</span>
                  </td>
                  <td className="py-2.5 px-3 text-right font-bold text-white">
                    {formatQAR(tx.amountDirhams, locale)}
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    <span className="inline-flex items-center gap-1 text-[10px] text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 rounded">
                      <CheckCircle2 className="w-3 h-3" />
                      SETTLED
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-400 text-[11px]">
                    {formatTimestamp(tx.timestamp, locale)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
