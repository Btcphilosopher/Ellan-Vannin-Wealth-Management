import React, { useState } from 'react';
import { useCBDC } from '../../context/CBDCContext';
import { formatQAR } from '../../utils/formatters';
import { PlayCircle, CheckCircle2, ArrowRight, ShieldCheck, Zap, RefreshCw } from 'lucide-react';

export const DemoWizardsView: React.FC = () => {
  const { issueCBDC, transferWholesale, executeDvPSwap, triggerStressScenario, t, locale, setActiveView } = useCBDC();
  
  const [activeDemo, setActiveDemo] = useState<number>(1);
  const [demoStep, setDemoStep] = useState<number>(1);
  const [demoLog, setDemoLog] = useState<string>('');

  // Demo 1 Handler
  const runDemo1Step = () => {
    if (demoStep === 1) {
      const res = issueCBDC('BANK-QNB', 100000000, 'DEMO 01: RTGS Conversion to QAR-CBDC');
      setDemoLog(res.message);
      setDemoStep(2);
    } else if (demoStep === 2) {
      const res = transferWholesale('BANK-QNB', 'BANK-CBQ', 25000000, 'DEMO 01: Interbank CBDC Transfer');
      setDemoLog(res.message);
      setDemoStep(3);
    }
  };

  // Demo 2 Handler
  const runDemo2Step = () => {
    if (demoStep === 1) {
      const res = executeDvPSwap('BANK-QNB', 'BANK-CBQ', 'QA-GOV-2029-01', 500000);
      setDemoLog(res.message);
      setDemoStep(2);
    }
  };

  // Demo 3 Handler
  const runDemo3Step = () => {
    triggerStressScenario('VOLUME_SURGE');
    setDemoLog('Injected +300% Volume Surge. QCB Auto-Hedging Facility active.');
    setDemoStep(2);
  };

  const resetDemo = (demoNum: number) => {
    setActiveDemo(demoNum);
    setDemoStep(1);
    setDemoLog('');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="border-b border-[#1E2633] pb-4">
        <h2 className="text-xl font-bold text-white">Interactive Institutional Signature Demonstrations</h2>
        <p className="text-xs text-slate-400 mt-1">
          Guided Walkthroughs Demonstrating Core Monetary Mechanics (Issuance, Wholesale, DvP, Shock Resilience)
        </p>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-[#1E2633] pb-2">
        <button
          onClick={() => resetDemo(1)}
          className={`px-4 py-2 text-xs font-bold rounded-lg transition-colors ${activeDemo === 1 ? 'bg-[#8A1538] text-white' : 'text-slate-400 hover:text-white bg-[#161F2E]'}`}
        >
          DEMO 01 — Wholesale Settlement
        </button>
        <button
          onClick={() => resetDemo(2)}
          className={`px-4 py-2 text-xs font-bold rounded-lg transition-colors ${activeDemo === 2 ? 'bg-[#8A1538] text-white' : 'text-slate-400 hover:text-white bg-[#161F2E]'}`}
        >
          DEMO 02 — Digital Security DvP
        </button>
        <button
          onClick={() => resetDemo(3)}
          className={`px-4 py-2 text-xs font-bold rounded-lg transition-colors ${activeDemo === 3 ? 'bg-[#8A1538] text-white' : 'text-slate-400 hover:text-white bg-[#161F2E]'}`}
        >
          DEMO 03 — Liquidity Shock
        </button>
      </div>

      {/* Demo 1 Workspace */}
      {activeDemo === 1 && (
        <div className="bg-[#111622] border border-[#1E2633] rounded-2xl p-6 space-y-6">
          <div className="border-b border-[#1E2633] pb-3">
            <h3 className="text-base font-bold text-white">DEMO 01: Wholesale Issuance & Interbank Transfer</h3>
            <p className="text-xs text-slate-400">Step-by-step conversion of QAR 100M RTGS balance to QAR-CBDC and interbank settlement to CBQ</p>
          </div>

          <div className="grid grid-cols-3 gap-4 font-mono text-xs">
            <div className={`p-4 rounded-xl border ${demoStep >= 1 ? 'bg-[#161F2E] border-[#8A1538] text-white' : 'bg-[#0B0E14] border-slate-800 text-slate-500'}`}>
              <span className="text-[10px] text-slate-400 block font-sans">STEP 1</span>
              <strong className="text-sm block font-sans mt-1">Convert RTGS Balance</strong>
              <p className="text-[11px] mt-1 text-slate-300 font-sans">QNB converts QAR 100M RTGS to QAR-CBDC collateral.</p>
            </div>

            <div className={`p-4 rounded-xl border ${demoStep >= 2 ? 'bg-[#161F2E] border-[#8A1538] text-white' : 'bg-[#0B0E14] border-slate-800 text-slate-500'}`}>
              <span className="text-[10px] text-slate-400 block font-sans">STEP 2</span>
              <strong className="text-sm block font-sans mt-1">Interbank Transfer</strong>
              <p className="text-[11px] mt-1 text-slate-300 font-sans">QNB sends QAR 25M to Commercial Bank.</p>
            </div>

            <div className={`p-4 rounded-xl border ${demoStep >= 3 ? 'bg-emerald-950/20 border-emerald-500 text-emerald-300' : 'bg-[#0B0E14] border-slate-800 text-slate-500'}`}>
              <span className="text-[10px] text-slate-400 block font-sans">STEP 3</span>
              <strong className="text-sm block font-sans mt-1">Finality Verified</strong>
              <p className="text-[11px] mt-1 text-slate-300 font-sans">Ledger updated, double-entry audit receipt logged.</p>
            </div>
          </div>

          {demoStep < 3 ? (
            <button
              onClick={runDemo1Step}
              className="w-full bg-[#8A1538] hover:bg-[#A31942] text-white text-xs font-bold py-3 rounded-xl transition-colors flex items-center justify-center gap-2 shadow-lg shadow-[#8A1538]/20"
            >
              <Zap className="w-4 h-4" />
              <span>{demoStep === 1 ? 'Execute Step 1: Issue QAR 100M CBDC' : 'Execute Step 2: Transfer QAR 25M to CBQ'}</span>
            </button>
          ) : (
            <div className="bg-emerald-500/10 border border-emerald-500/30 p-4 rounded-xl text-xs text-emerald-300 font-mono space-y-2">
              <div className="flex items-center gap-2 font-bold font-sans text-sm">
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                <span>DEMO 01 COMPLETE — Finalized in Ledger</span>
              </div>
              <p>{demoLog}</p>
              <button onClick={() => resetDemo(1)} className="text-xs text-slate-300 underline font-sans">Restart Demo 01</button>
            </div>
          )}
        </div>
      )}

      {/* Demo 2 Workspace */}
      {activeDemo === 2 && (
        <div className="bg-[#111622] border border-[#1E2633] rounded-2xl p-6 space-y-6">
          <div className="border-b border-[#1E2633] pb-3">
            <h3 className="text-base font-bold text-white">DEMO 02: Sovereign Digital Security DvP Atomic Swap</h3>
            <p className="text-xs text-slate-400">Atomic simultaneous execution of QAR 50M Digital Bond purchase</p>
          </div>

          <div className="p-4 bg-[#161F2E] rounded-xl border border-[#222C3D] text-xs font-mono space-y-2">
            <div className="flex justify-between">
              <span className="text-slate-400">Security:</span>
              <span className="text-white font-bold">QA-GOV-2029-01 Sovereign Digital Bond</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Volume:</span>
              <span className="text-white font-bold">500,000 units</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Execution Mode:</span>
              <span className="text-emerald-400 font-bold">Atomic Swap (14ms)</span>
            </div>
          </div>

          {demoStep === 1 ? (
            <button
              onClick={runDemo2Step}
              className="w-full bg-[#8A1538] hover:bg-[#A31942] text-white text-xs font-bold py-3 rounded-xl transition-colors flex items-center justify-center gap-2"
            >
              <Zap className="w-4 h-4" />
              <span>Execute Atomic DvP Bond Purchase</span>
            </button>
          ) : (
            <div className="bg-emerald-500/10 border border-emerald-500/30 p-4 rounded-xl text-xs text-emerald-300 font-mono space-y-2">
              <div className="flex items-center gap-2 font-bold font-sans text-sm">
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                <span>DEMO 02 ATOMIC DVP COMPLETE</span>
              </div>
              <p>{demoLog}</p>
              <button onClick={() => resetDemo(2)} className="text-xs text-slate-300 underline font-sans">Restart Demo 02</button>
            </div>
          )}
        </div>
      )}

      {/* Demo 3 Workspace */}
      {activeDemo === 3 && (
        <div className="bg-[#111622] border border-[#1E2633] rounded-2xl p-6 space-y-6">
          <div className="border-b border-[#1E2633] pb-3">
            <h3 className="text-base font-bold text-white">DEMO 03: Liquidity Shock & Auto-Recovery</h3>
            <p className="text-xs text-slate-400">Simulate +300% volume surge and test QCB emergency buffer auto-hedging</p>
          </div>

          <button
            onClick={runDemo3Step}
            className="w-full bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold py-3 rounded-xl transition-colors flex items-center justify-center gap-2"
          >
            <Zap className="w-4 h-4" />
            <span>Inject +300% Volume Shock</span>
          </button>

          {demoLog && (
            <div className="p-4 bg-amber-500/10 border border-amber-500/30 rounded-xl text-xs text-amber-300 font-mono">
              {demoLog}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
