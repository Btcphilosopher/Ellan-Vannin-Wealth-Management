import React, { useState } from 'react';
import { useCBDC } from '../../context/CBDCContext';
import { formatCompactQAR, formatQAR } from '../../utils/formatters';
import { BarChart3, Sliders, TrendingUp, Activity, Calculator, PieChart } from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  Legend
} from 'recharts';

export const LiquidityResearchView: React.FC = () => {
  const { systemMetrics, t, locale } = useCBDC();

  // Research Sliders State
  const [velocityFactor, setVelocityFactor] = useState<number>(4.2);
  const [depositSubstitution, setDepositSubstitution] = useState<number>(12); // 12% deposit shift
  const [cbdcRemuneration, setCbdcRemuneration] = useState<number>(0.0); // 0% non-interest bearing
  const [adoptionRate, setAdoptionRate] = useState<number>(28); // 28% adoption

  // Calculated quantitative outputs (R-style simulation formulas)
  const baseCirculationQAR = systemMetrics.totalCirculationDirhams / 100;
  const projectedVelocity = (velocityFactor * (1 + adoptionRate / 100)).toFixed(2);
  const depositMigrationQAR = (baseCirculationQAR * (depositSubstitution / 100)).toFixed(0);
  const liquidityGapRiskPercent = Math.max(0, (depositSubstitution - 15) * 1.5).toFixed(1);

  // Chart data: Liquidity migration impact on Commercial Bank Balance Sheets vs QCB CBDC
  const migrationData = [
    { name: 'Baseline', bankDeposits: 120, cbdcCirculation: 4.82 },
    { name: '+10% Shift', bankDeposits: 108, cbdcCirculation: 16.82 },
    { name: '+20% Shift', bankDeposits: 96, cbdcCirculation: 28.82 },
    { name: '+30% Shift', bankDeposits: 84, cbdcCirculation: 40.82 }
  ];

  // Intraday liquidity utilization curve
  const curveData = [
    { hour: '06:00', utilization: 12 },
    { hour: '08:00', utilization: 34 },
    { hour: '10:00', utilization: 82 },
    { hour: '12:00', utilization: 65 },
    { hour: '14:00', utilization: 94 }, // Peak requirement
    { hour: '16:00', utilization: 48 },
    { hour: '18:00', utilization: 22 }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="border-b border-[#1E2633] pb-4">
        <div className="flex items-center gap-2">
          <h2 className="text-xl font-bold text-white">Monetary Policy & Liquidity Research Lab</h2>
          <span className="bg-purple-500/20 text-purple-300 border border-purple-500/40 text-[10px] font-mono px-2 py-0.5 rounded font-bold">
            R-Quantitative Engine
          </span>
        </div>
        <p className="text-xs text-slate-400 mt-1">
          Simulating Deposit Substitution, Money Velocity & Intraday Liquidity Stress Dynamics
        </p>
      </div>

      {/* Econometric Parameter Sliders Control Panel */}
      <div className="bg-[#111622] border border-[#1E2633] rounded-xl p-5 space-y-4">
        <div className="flex items-center gap-2 border-b border-[#1E2633] pb-3">
          <Sliders className="w-5 h-5 text-[#8A1538]" />
          <h3 className="text-sm font-bold text-white">Research Variable Controls</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {/* Slider 1: Velocity Factor */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300 font-medium">Money Velocity (V)</span>
              <span className="text-emerald-400 font-mono font-bold">{velocityFactor}x</span>
            </div>
            <input
              type="range"
              min="1.0"
              max="10.0"
              step="0.1"
              value={velocityFactor}
              onChange={e => setVelocityFactor(Number(e.target.value))}
              className="w-full accent-[#8A1538] bg-[#161F2E] cursor-pointer"
            />
            <span className="text-[10px] text-slate-500 block font-mono">
              Annual Velocity Turnover
            </span>
          </div>

          {/* Slider 2: Deposit Substitution */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300 font-medium">Deposit Substitution</span>
              <span className="text-amber-400 font-mono font-bold">{depositSubstitution}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="40"
              step="1"
              value={depositSubstitution}
              onChange={e => setDepositSubstitution(Number(e.target.value))}
              className="w-full accent-[#8A1538] bg-[#161F2E] cursor-pointer"
            />
            <span className="text-[10px] text-slate-500 block font-mono">
              Bank Deposit Shift to CBDC
            </span>
          </div>

          {/* Slider 3: CBDC Remuneration */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300 font-medium">CBDC Remuneration</span>
              <span className="text-blue-400 font-mono font-bold">{cbdcRemuneration}%</span>
            </div>
            <input
              type="range"
              min="0.0"
              max="5.0"
              step="0.25"
              value={cbdcRemuneration}
              onChange={e => setCbdcRemuneration(Number(e.target.value))}
              className="w-full accent-[#8A1538] bg-[#161F2E] cursor-pointer"
            />
            <span className="text-[10px] text-slate-500 block font-mono">
              Interest Paid on CBDC Holdings
            </span>
          </div>

          {/* Slider 4: Retail Adoption */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300 font-medium">Retail Adoption Rate</span>
              <span className="text-purple-400 font-mono font-bold">{adoptionRate}%</span>
            </div>
            <input
              type="range"
              min="5"
              max="90"
              step="1"
              value={adoptionRate}
              onChange={e => setAdoptionRate(Number(e.target.value))}
              className="w-full accent-[#8A1538] bg-[#161F2E] cursor-pointer"
            />
            <span className="text-[10px] text-slate-500 block font-mono">
              Citizen Population Penetration
            </span>
          </div>
        </div>
      </div>

      {/* Calculated Econometric Outputs */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-[#111622] border border-[#1E2633] p-4 rounded-xl space-y-1">
          <span className="text-xs text-slate-400 font-medium">Projected Annual Velocity</span>
          <div className="text-xl font-bold text-emerald-400 font-mono">{projectedVelocity}</div>
          <p className="text-[10px] text-slate-500 font-mono">V = (P × Y) / M under high adoption</p>
        </div>

        <div className="bg-[#111622] border border-[#1E2633] p-4 rounded-xl space-y-1">
          <span className="text-xs text-slate-400 font-medium">Deposit Migration Volume</span>
          <div className="text-xl font-bold text-amber-300 font-mono">
            QAR {(Number(depositMigrationQAR) / 1000000000).toFixed(2)}bn
          </div>
          <p className="text-[10px] text-slate-500 font-mono">Commercial Bank Disintermediation</p>
        </div>

        <div className="bg-[#111622] border border-[#1E2633] p-4 rounded-xl space-y-1">
          <span className="text-xs text-slate-400 font-medium">Liquidity Gap Risk</span>
          <div className={`text-xl font-bold font-mono ${Number(liquidityGapRiskPercent) > 10 ? 'text-red-400' : 'text-slate-200'}`}>
            {liquidityGapRiskPercent}%
          </div>
          <p className="text-[10px] text-slate-500 font-mono">Peak Intraday Buffer Deficit Risk</p>
        </div>
      </div>

      {/* Econometric Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart 1: Deposit Migration Impact */}
        <div className="bg-[#111622] border border-[#1E2633] rounded-xl p-5 space-y-4">
          <div className="border-b border-[#1E2633] pb-3">
            <h3 className="text-sm font-bold text-white">Commercial Bank Disintermediation Simulation</h3>
            <p className="text-xs text-slate-400">Shift from Commercial Bank Deposits to Central Bank Liability (QAR Billions)</p>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={migrationData}>
                <XAxis dataKey="name" stroke="#64748B" fontSize={11} />
                <YAxis stroke="#64748B" fontSize={11} />
                <Tooltip contentStyle={{ backgroundColor: '#0B0E14', borderColor: '#1E2633', borderRadius: '8px' }} />
                <Legend />
                <Bar dataKey="bankDeposits" name="Bank Commercial Deposits" fill="#3B82F6" />
                <Bar dataKey="cbdcCirculation" name="QAR-CBDC Outstanding" fill="#8A1538" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Intraday Liquidity Curve */}
        <div className="bg-[#111622] border border-[#1E2633] rounded-xl p-5 space-y-4">
          <div className="border-b border-[#1E2633] pb-3">
            <h3 className="text-sm font-bold text-white">Intraday Peak Settlement Requirement Curve</h3>
            <p className="text-xs text-slate-400">Liquidity Utilization (% of Available Reserve Buffer)</p>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={curveData}>
                <XAxis dataKey="hour" stroke="#64748B" fontSize={11} />
                <YAxis stroke="#64748B" fontSize={11} unit="%" />
                <Tooltip contentStyle={{ backgroundColor: '#0B0E14', borderColor: '#1E2633', borderRadius: '8px' }} />
                <Line type="monotone" dataKey="utilization" name="Reserve Utilization %" stroke="#10B981" strokeWidth={3} dot={{ r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
