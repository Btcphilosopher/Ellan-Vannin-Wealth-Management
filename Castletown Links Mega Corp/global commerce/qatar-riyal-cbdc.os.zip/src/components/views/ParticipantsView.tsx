import React from 'react';
import { useCBDC } from '../../context/CBDCContext';
import { formatQAR, formatCompactQAR } from '../../utils/formatters';
import { Building2, ShieldCheck, Lock, Activity, Users, Landmark } from 'lucide-react';

export const ParticipantsView: React.FC = () => {
  const { banks, t, locale, setActiveView } = useCBDC();

  return (
    <div className="space-y-6">
      {/* View Header */}
      <div className="border-b border-[#1E2633] pb-4">
        <h2 className="text-xl font-bold text-white">Regulated Participant Commercial Banks</h2>
        <p className="text-xs text-slate-400 mt-1">
          Authorized Institutional Nodes with Direct Central Bank Settlement & RTGS Collateral Vaults
        </p>
      </div>

      {/* Grid of Commercial Banks */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {banks.map(bank => {
          const isWarning = bank.status === 'WARNING';
          const isSuspended = bank.status === 'SUSPENDED';

          return (
            <div
              key={bank.id}
              className={`bg-[#111622] border rounded-xl p-5 space-y-4 transition-all ${
                isSuspended
                  ? 'border-red-500/50 bg-red-950/10'
                  : isWarning
                  ? 'border-amber-500/50'
                  : 'border-[#1E2633] hover:border-[#8A1538]/50'
              }`}
            >
              {/* Header */}
              <div className="flex items-start justify-between gap-3 border-b border-[#1E2633] pb-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-base font-bold text-white font-sans">
                      {bank.code}
                    </span>
                    <span
                      className={`text-[9px] px-2 py-0.5 rounded font-mono font-bold uppercase ${
                        isSuspended
                          ? 'bg-red-500/20 text-red-300 border border-red-500/40'
                          : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      }`}
                    >
                      {bank.status}
                    </span>
                  </div>
                  <h3 className="text-xs font-medium text-slate-300 mt-1">
                    {locale === 'ar' ? bank.nameAr : bank.nameEn}
                  </h3>
                  <span className="text-[10px] text-slate-500 font-mono">
                    SWIFT: {bank.swiftCode}
                  </span>
                </div>
                <Building2 className="w-6 h-6 text-[#8A1538] shrink-0" />
              </div>

              {/* Balance & Liquidity Metrics */}
              <div className="space-y-2 text-xs font-mono">
                <div className="bg-[#161F2E] p-2.5 rounded-lg flex items-center justify-between">
                  <span className="text-slate-400 flex items-center gap-1.5 font-sans">
                    <Lock className="w-3.5 h-3.5 text-slate-500" /> RTGS Balance:
                  </span>
                  <span className="text-white font-bold">
                    {formatCompactQAR(bank.rtgsBalanceDirhams, locale)}
                  </span>
                </div>

                <div className="bg-[#161F2E] p-2.5 rounded-lg flex items-center justify-between">
                  <span className="text-slate-400 flex items-center gap-1.5 font-sans">
                    <ShieldCheck className="w-3.5 h-3.5 text-[#8A1538]" /> CBDC Reserve:
                  </span>
                  <span className="text-emerald-400 font-bold">
                    {formatCompactQAR(bank.cbdcBalanceDirhams, locale)}
                  </span>
                </div>

                <div className="bg-[#161F2E] p-2.5 rounded-lg flex items-center justify-between text-[11px]">
                  <span className="text-slate-400 flex items-center gap-1.5 font-sans">
                    <Activity className="w-3.5 h-3.5 text-blue-400" /> Liquidity Ratio:
                  </span>
                  <span className="text-slate-200 font-bold">
                    {(bank.liquidityRatio * 100).toFixed(0)}% (Compliant)
                  </span>
                </div>

                <div className="bg-[#161F2E] p-2.5 rounded-lg flex items-center justify-between text-[11px]">
                  <span className="text-slate-400 flex items-center gap-1.5 font-sans">
                    <Users className="w-3.5 h-3.5 text-amber-400" /> Retail Accounts:
                  </span>
                  <span className="text-slate-200 font-bold">
                    {bank.customerAccountsCount.toLocaleString()} Wallets
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 flex items-center gap-2">
                <button
                  onClick={() => setActiveView('ISSUANCE_REDEMPTION')}
                  className="w-full bg-[#161F2E] hover:bg-[#8A1538] text-slate-200 hover:text-white text-xs font-semibold py-2 rounded-lg transition-colors border border-[#2A3447]"
                >
                  Issue / Redeem
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
