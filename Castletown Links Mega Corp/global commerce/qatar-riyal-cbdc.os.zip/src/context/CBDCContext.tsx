import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import {
  ParticipantBank,
  DigitalSecurity,
  CBDCTransaction,
  AuditEvent,
  RetailWallet,
  MerchantAccount,
  SystemMetrics,
  SystemRole,
  ActiveView,
  DvPContract
} from '../types/cbdc';
import {
  INITIAL_BANKS,
  INITIAL_SECURITIES,
  INITIAL_LEDGER,
  INITIAL_AUDIT_LOGS,
  INITIAL_RETAIL_WALLETS,
  INITIAL_MERCHANTS
} from '../data/initialData';
import { generateHash, qarToDirhams, dirhamsToQAR } from '../utils/formatters';
import { Language, translations } from '../locales/i18n';

interface CBDCContextType {
  // State
  banks: ParticipantBank[];
  securities: DigitalSecurity[];
  transactions: CBDCTransaction[];
  auditLogs: AuditEvent[];
  retailWallets: RetailWallet[];
  merchants: MerchantAccount[];
  dvpContracts: DvPContract[];
  systemMetrics: SystemMetrics;
  
  // Settings & Controls
  activeRole: SystemRole;
  activeView: ActiveView;
  locale: Language;
  simulationSpeed: number; // 0, 1, 10, 100, 1000
  invariantAlert: boolean;
  
  // Actions
  setLocale: (lang: Language) => void;
  setActiveRole: (role: SystemRole) => void;
  setActiveView: (view: ActiveView) => void;
  setSimulationSpeed: (speed: number) => void;
  
  issueCBDC: (bankId: string, amountQAR: number, memo?: string) => { success: boolean; message: string; txHash?: string };
  redeemCBDC: (bankId: string, amountQAR: number, memo?: string) => { success: boolean; message: string; txHash?: string };
  transferWholesale: (senderId: string, receiverId: string, amountQAR: number, memo?: string) => { success: boolean; message: string; txHash?: string };
  executeDvPSwap: (buyerId: string, sellerId: string, isin: string, quantity: number) => { success: boolean; message: string; contractId?: string };
  executeRetailPayment: (walletId: string, merchantId: string, amountQAR: number, isOffline?: boolean) => { success: boolean; message: string; txHash?: string };
  syncOfflineWallet: (walletId: string) => { success: boolean; message: string };
  triggerStressScenario: (scenarioType: 'VOLUME_SURGE' | 'BANK_DISCONNECT' | 'LIQUIDITY_FREEZE') => void;
  
  // Translations
  t: typeof translations.en;
}

const CBDCContext = createContext<CBDCContextType | undefined>(undefined);

export const CBDCProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [banks, setBanks] = useState<ParticipantBank[]>(INITIAL_BANKS);
  const [securities, setSecurities] = useState<DigitalSecurity[]>(INITIAL_SECURITIES);
  const [transactions, setTransactions] = useState<CBDCTransaction[]>(INITIAL_LEDGER);
  const [auditLogs, setAuditLogs] = useState<AuditEvent[]>(INITIAL_AUDIT_LOGS);
  const [retailWallets, setRetailWallets] = useState<RetailWallet[]>(INITIAL_RETAIL_WALLETS);
  const [merchants, setMerchants] = useState<MerchantAccount[]>(INITIAL_MERCHANTS);
  const [dvpContracts, setDvpContracts] = useState<DvPContract[]>([]);
  
  const [activeRole, setActiveRole] = useState<SystemRole>('QCB_ADMIN');
  const [activeView, setActiveView] = useState<ActiveView>('OVERVIEW');
  const [locale, setLocale] = useState<Language>('en');
  const [simulationSpeed, setSimulationSpeed] = useState<number>(1);
  const [invariantAlert, setInvariantAlert] = useState<boolean>(false);

  // Calculate system metrics
  const calculateMetrics = useCallback((): SystemMetrics => {
    const wholesaleSum = banks.reduce((acc, b) => acc + b.cbdcBalanceDirhams, 0);
    const retailSum = retailWallets.reduce((acc, w) => acc + w.balanceDirhams + w.offlineBalanceDirhams, 0);
    const totalCirculation = wholesaleSum + retailSum;
    const rtgsCollateral = banks.reduce((acc, b) => acc + (b.rtgsBalanceDirhams < 0 ? 0 : b.rtgsBalanceDirhams), 0);
    const securitiesValue = securities.reduce((acc, s) => acc + (s.totalVolume * s.marketPriceDirhams), 0);
    const settlementVolume = transactions.reduce((acc, t) => acc + t.amountDirhams, 0);

    return {
      totalCirculationDirhams: totalCirculation,
      wholesaleCirculationDirhams: wholesaleSum,
      retailCirculationDirhams: retailSum,
      rtgsCollateralLockedDirhams: rtgsCollateral,
      transactionsTodayCount: transactions.length + 1842390, // Include baseline synthetic
      settlementVolumeTodayDirhams: settlementVolume + qarToDirhams(31700000000), // QAR 31.7bn synthetic base
      activeParticipantsCount: banks.filter(b => b.status === 'ACTIVE').length + 6,
      pendingSettlementDirhams: qarToDirhams(184000000),
      digitalSecuritiesValueDirhams: securitiesValue,
      averageSettlementTimeMs: 240,
      ledgerBlockHeight: 104823 + transactions.length,
      systemStatus: 'OPERATIONAL'
    };
  }, [banks, retailWallets, securities, transactions]);

  const [systemMetrics, setSystemMetrics] = useState<SystemMetrics>(calculateMetrics());

  // Check accounting invariant
  useEffect(() => {
    const metrics = calculateMetrics();
    setSystemMetrics(metrics);

    // Invariant check: Wholesale + Retail must be exact
    const wholesaleSum = banks.reduce((acc, b) => acc + b.cbdcBalanceDirhams, 0);
    const retailSum = retailWallets.reduce((acc, w) => acc + w.balanceDirhams + w.offlineBalanceDirhams, 0);
    const total = wholesaleSum + retailSum;
    
    if (isNaN(total) || total < 0) {
      setInvariantAlert(true);
    } else {
      setInvariantAlert(false);
    }
  }, [banks, retailWallets, transactions, calculateMetrics]);

  // Simulation tick loop for live institutional feel
  useEffect(() => {
    if (simulationSpeed === 0) return;

    const intervalMs = Math.max(200, 3000 / simulationSpeed);
    const timer = setInterval(() => {
      // Pick two random active banks for synthetic background flow
      const activeBanks = banks.filter(b => b.status === 'ACTIVE');
      if (activeBanks.length >= 2) {
        const senderIdx = Math.floor(Math.random() * activeBanks.length);
        let receiverIdx = Math.floor(Math.random() * activeBanks.length);
        while (receiverIdx === senderIdx) {
          receiverIdx = Math.floor(Math.random() * activeBanks.length);
        }

        const sender = activeBanks[senderIdx];
        const receiver = activeBanks[receiverIdx];
        const randomQAR = Math.floor(Math.random() * 5000000) + 500000; // 500k - 5.5M QAR
        const amountDirhams = qarToDirhams(randomQAR);

        if (sender.cbdcBalanceDirhams >= amountDirhams) {
          // Perform silent background transfer
          setBanks(prev => prev.map(b => {
            if (b.id === sender.id) return { ...b, cbdcBalanceDirhams: b.cbdcBalanceDirhams - amountDirhams };
            if (b.id === receiver.id) return { ...b, cbdcBalanceDirhams: b.cbdcBalanceDirhams + amountDirhams };
            return b;
          }));

          const lastTx = transactions[transactions.length - 1];
          const newTx: CBDCTransaction = {
            id: `TX-QAR-${(1001 + transactions.length).toString().padStart(7, '0')}`,
            txHash: generateHash('0x', transactions.length + 100),
            prevHash: lastTx ? lastTx.txHash : '0x0000000000000000000000000000000000000000',
            timestamp: new Date().toISOString(),
            type: 'WHOLESALE_TRANSFER',
            senderId: sender.id,
            senderNameEn: sender.nameEn,
            senderNameAr: sender.nameAr,
            receiverId: receiver.id,
            receiverNameEn: receiver.nameEn,
            receiverNameAr: receiver.nameAr,
            amountDirhams,
            currency: 'QAR-CBDC',
            status: 'SETTLED',
            complianceStatus: 'CLEARED',
            auditRef: `AUD-AUTO-${Math.floor(Math.random() * 90000 + 10000)}`,
            memo: 'Automated Intraday Wholesale Settlement Queue',
            blockNumber: 104823 + transactions.length
          };

          setTransactions(prev => [newTx, ...prev.slice(0, 49)]); // Keep last 50
        }
      }
    }, intervalMs);

    return () => clearInterval(timer);
  }, [simulationSpeed, banks, transactions]);

  // Issue CBDC Action
  const issueCBDC = (bankId: string, amountQAR: number, memo?: string) => {
    const amountDirhams = qarToDirhams(amountQAR);
    const targetBank = banks.find(b => b.id === bankId);

    if (!targetBank) {
      return { success: false, message: 'Participant bank not found.' };
    }
    if (targetBank.rtgsBalanceDirhams < amountDirhams) {
      return { success: false, message: 'Insufficient RTGS balance to collateralize CBDC issuance.' };
    }

    // Lock RTGS balance and mint CBDC 1:1
    setBanks(prev => prev.map(b => {
      if (b.id === bankId) {
        return {
          ...b,
          rtgsBalanceDirhams: b.rtgsBalanceDirhams - amountDirhams,
          cbdcBalanceDirhams: b.cbdcBalanceDirhams + amountDirhams
        };
      }
      return b;
    }));

    const lastTx = transactions[0];
    const txHash = generateHash('0x', Date.now());
    const newTx: CBDCTransaction = {
      id: `TX-QAR-${(1001 + transactions.length).toString().padStart(7, '0')}`,
      txHash,
      prevHash: lastTx ? lastTx.txHash : '0x0000000000000000000000000000000000000000',
      timestamp: new Date().toISOString(),
      type: 'ISSUANCE',
      senderId: 'QCB-MINT',
      senderNameEn: 'QCB Core Issuance Engine',
      senderNameAr: 'محرك إصدار مصرف قطر المركزي',
      receiverId: targetBank.id,
      receiverNameEn: targetBank.nameEn,
      receiverNameAr: targetBank.nameAr,
      amountDirhams,
      currency: 'QAR-CBDC',
      status: 'SETTLED',
      complianceStatus: 'CLEARED',
      auditRef: `AUD-ISSUE-${Math.floor(Math.random() * 90000 + 10000)}`,
      memo: memo || 'Primary RTGS Conversion to QAR-CBDC Collateral',
      blockNumber: 104823 + transactions.length
    };

    setTransactions(prev => [newTx, ...prev]);

    // Append Audit Event
    const lastAudit = auditLogs[0];
    const auditEvent: AuditEvent = {
      id: `AUD-${(auditLogs.length + 1).toString().padStart(3, '0')}`,
      timestamp: new Date().toISOString(),
      actorId: 'QCB_OFFICER_CURRENT',
      actorRole: activeRole,
      action: 'APPROVED_CBDC_ISSUANCE',
      amountDirhams,
      targetEntity: targetBank.code,
      eventHash: generateHash('SIM-AUD', Date.now()),
      prevHash: lastAudit ? lastAudit.eventHash : 'SIM-AUD-000000000000',
      status: 'VERIFIED'
    };
    setAuditLogs(prev => [auditEvent, ...prev]);

    return { success: true, message: `Successfully issued ${amountQAR.toLocaleString()} QAR-CBDC to ${targetBank.nameEn}`, txHash };
  };

  // Redeem CBDC Action
  const redeemCBDC = (bankId: string, amountQAR: number, memo?: string) => {
    const amountDirhams = qarToDirhams(amountQAR);
    const targetBank = banks.find(b => b.id === bankId);

    if (!targetBank) {
      return { success: false, message: 'Participant bank not found.' };
    }
    if (targetBank.cbdcBalanceDirhams < amountDirhams) {
      return { success: false, message: 'Insufficient CBDC balance for redemption.' };
    }

    // Burn CBDC and unlock RTGS balance 1:1
    setBanks(prev => prev.map(b => {
      if (b.id === bankId) {
        return {
          ...b,
          cbdcBalanceDirhams: b.cbdcBalanceDirhams - amountDirhams,
          rtgsBalanceDirhams: b.rtgsBalanceDirhams + amountDirhams
        };
      }
      return b;
    }));

    const lastTx = transactions[0];
    const txHash = generateHash('0x', Date.now());
    const newTx: CBDCTransaction = {
      id: `TX-QAR-${(1001 + transactions.length).toString().padStart(7, '0')}`,
      txHash,
      prevHash: lastTx ? lastTx.txHash : '0x0000000000000000000000000000000000000000',
      timestamp: new Date().toISOString(),
      type: 'REDEMPTION',
      senderId: targetBank.id,
      senderNameEn: targetBank.nameEn,
      senderNameAr: targetBank.nameAr,
      receiverId: 'QCB-BURN',
      receiverNameEn: 'QCB Core Redemption Engine',
      receiverNameAr: 'محرك استرداد مصرف قطر المركزي',
      amountDirhams,
      currency: 'QAR-CBDC',
      status: 'SETTLED',
      complianceStatus: 'CLEARED',
      auditRef: `AUD-BURN-${Math.floor(Math.random() * 90000 + 10000)}`,
      memo: memo || 'CBDC Redemption to Primary RTGS Balance',
      blockNumber: 104823 + transactions.length
    };

    setTransactions(prev => [newTx, ...prev]);

    const lastAudit = auditLogs[0];
    const auditEvent: AuditEvent = {
      id: `AUD-${(auditLogs.length + 1).toString().padStart(3, '0')}`,
      timestamp: new Date().toISOString(),
      actorId: 'QCB_OFFICER_CURRENT',
      actorRole: activeRole,
      action: 'APPROVED_CBDC_REDEMPTION',
      amountDirhams,
      targetEntity: targetBank.code,
      eventHash: generateHash('SIM-AUD', Date.now()),
      prevHash: lastAudit ? lastAudit.eventHash : 'SIM-AUD-000000000000',
      status: 'VERIFIED'
    };
    setAuditLogs(prev => [auditEvent, ...prev]);

    return { success: true, message: `Successfully redeemed ${amountQAR.toLocaleString()} QAR-CBDC to RTGS balance for ${targetBank.nameEn}`, txHash };
  };

  // Transfer Wholesale Action
  const transferWholesale = (senderId: string, receiverId: string, amountQAR: number, memo?: string) => {
    const amountDirhams = qarToDirhams(amountQAR);
    const sender = banks.find(b => b.id === senderId);
    const receiver = banks.find(b => b.id === receiverId);

    if (!sender || !receiver) {
      return { success: false, message: 'Invalid sender or receiver bank.' };
    }
    if (sender.cbdcBalanceDirhams < amountDirhams) {
      return { success: false, message: 'Insufficient CBDC balance for transfer.' };
    }

    setBanks(prev => prev.map(b => {
      if (b.id === senderId) return { ...b, cbdcBalanceDirhams: b.cbdcBalanceDirhams - amountDirhams };
      if (b.id === receiverId) return { ...b, cbdcBalanceDirhams: b.cbdcBalanceDirhams + amountDirhams };
      return b;
    }));

    const lastTx = transactions[0];
    const txHash = generateHash('0x', Date.now());
    const newTx: CBDCTransaction = {
      id: `TX-QAR-${(1001 + transactions.length).toString().padStart(7, '0')}`,
      txHash,
      prevHash: lastTx ? lastTx.txHash : '0x0000000000000000000000000000000000000000',
      timestamp: new Date().toISOString(),
      type: 'WHOLESALE_TRANSFER',
      senderId: sender.id,
      senderNameEn: sender.nameEn,
      senderNameAr: sender.nameAr,
      receiverId: receiver.id,
      receiverNameEn: receiver.nameEn,
      receiverNameAr: receiver.nameAr,
      amountDirhams,
      currency: 'QAR-CBDC',
      status: 'SETTLED',
      complianceStatus: 'CLEARED',
      auditRef: `AUD-XFER-${Math.floor(Math.random() * 90000 + 10000)}`,
      memo: memo || 'Interbank Wholesale CBDC Liquidity Transfer',
      blockNumber: 104823 + transactions.length
    };

    setTransactions(prev => [newTx, ...prev]);

    return { success: true, message: `Transferred ${amountQAR.toLocaleString()} QAR-CBDC from ${sender.code} to ${receiver.code}`, txHash };
  };

  // Atomic DvP Swap Action
  const executeDvPSwap = (buyerId: string, sellerId: string, isin: string, quantity: number) => {
    const buyer = banks.find(b => b.id === buyerId);
    const seller = banks.find(b => b.id === sellerId);
    const sec = securities.find(s => s.isin === isin);

    if (!buyer || !seller || !sec) {
      return { success: false, message: 'Invalid buyer, seller, or security instrument.' };
    }

    const totalCbdcDirhams = quantity * sec.marketPriceDirhams;
    const totalCbdcQAR = dirhamsToQAR(totalCbdcDirhams);

    if (buyer.cbdcBalanceDirhams < totalCbdcDirhams) {
      return { success: false, message: `Buyer ${buyer.code} has insufficient CBDC balance (${dirhamsToQAR(buyer.cbdcBalanceDirhams).toLocaleString()} QAR) for this DvP purchase (${totalCbdcQAR.toLocaleString()} QAR required).` };
    }
    if (sec.availableVolume < quantity) {
      return { success: false, message: `Insufficient available security volume (${sec.availableVolume.toLocaleString()} units available).` };
    }

    // Atomic Swap: simultaneous CBDC transfer and Security ownership transfer
    setBanks(prev => prev.map(b => {
      if (b.id === buyerId) {
        return {
          ...b,
          cbdcBalanceDirhams: b.cbdcBalanceDirhams - totalCbdcDirhams,
          securitiesVolumeDirhams: b.securitiesVolumeDirhams + totalCbdcDirhams
        };
      }
      if (b.id === sellerId) {
        return {
          ...b,
          cbdcBalanceDirhams: b.cbdcBalanceDirhams + totalCbdcDirhams,
          securitiesVolumeDirhams: b.securitiesVolumeDirhams - totalCbdcDirhams
        };
      }
      return b;
    }));

    setSecurities(prev => prev.map(s => {
      if (s.isin === isin) {
        return { ...s, availableVolume: s.availableVolume - quantity };
      }
      return s;
    }));

    const contractId = `DVP-${Math.floor(Math.random() * 900000 + 100000)}`;
    const newContract: DvPContract = {
      id: contractId,
      contractHash: generateHash('DVP-HASH', Date.now()),
      buyerId: buyer.id,
      buyerNameEn: buyer.nameEn,
      sellerId: seller.id,
      sellerNameEn: seller.nameEn,
      securityIsin: isin,
      securityTitleEn: sec.titleEn,
      quantity,
      pricePerUnitDirhams: sec.marketPriceDirhams,
      totalCbdcAmountDirhams: totalCbdcDirhams,
      status: 'ATOMIC_SETTLED',
      timestamp: new Date().toISOString(),
      atomicExecutionTimeMs: 14 // 14 millisecond atomic resolution!
    };

    setDvpContracts(prev => [newContract, ...prev]);

    // Record ledger transaction
    const lastTx = transactions[0];
    const newTx: CBDCTransaction = {
      id: `TX-QAR-${(1001 + transactions.length).toString().padStart(7, '0')}`,
      txHash: generateHash('0x', Date.now()),
      prevHash: lastTx ? lastTx.txHash : '0x0000000000000000000000000000000000000000',
      timestamp: new Date().toISOString(),
      type: 'DVP_SETTLEMENT',
      senderId: buyer.id,
      senderNameEn: buyer.nameEn,
      senderNameAr: buyer.nameAr,
      receiverId: seller.id,
      receiverNameEn: seller.nameEn,
      receiverNameAr: seller.nameAr,
      amountDirhams: totalCbdcDirhams,
      currency: 'QAR-CBDC',
      status: 'SETTLED',
      complianceStatus: 'CLEARED',
      auditRef: `AUD-DVP-${contractId}`,
      memo: `Atomic DvP Settlement: ${quantity.toLocaleString()} units of ${sec.titleEn}`,
      blockNumber: 104823 + transactions.length
    };

    setTransactions(prev => [newTx, ...prev]);

    return { success: true, message: `Atomic DvP Settlement Complete! Swapped ${dirhamsToQAR(totalCbdcDirhams).toLocaleString()} QAR-CBDC for ${quantity.toLocaleString()} units of ${sec.titleEn} in 14ms.`, contractId };
  };

  // Execute Retail Payment
  const executeRetailPayment = (walletId: string, merchantId: string, amountQAR: number, isOffline = false) => {
    const amountDirhams = qarToDirhams(amountQAR);
    const wallet = retailWallets.find(w => w.id === walletId);
    const merchant = merchants.find(m => m.id === merchantId);

    if (!wallet || !merchant) {
      return { success: false, message: 'Invalid retail wallet or merchant account.' };
    }

    if (isOffline) {
      if (wallet.offlineBalanceDirhams < amountDirhams) {
        return { success: false, message: 'Insufficient offline wallet hardware balance.' };
      }

      setRetailWallets(prev => prev.map(w => {
        if (w.id === walletId) {
          return { ...w, offlineBalanceDirhams: w.offlineBalanceDirhams - amountDirhams };
        }
        return w;
      }));

      setMerchants(prev => prev.map(m => {
        if (m.id === merchantId) {
          return {
            ...m,
            balanceDirhams: m.balanceDirhams + amountDirhams,
            settledTodayDirhams: m.settledTodayDirhams + amountDirhams
          };
        }
        return m;
      }));

      return { success: true, message: `Device-to-Device Offline Voucher Transfer of QAR ${amountQAR.toFixed(2)} completed!` };
    } else {
      if (wallet.balanceDirhams < amountDirhams) {
        return { success: false, message: 'Insufficient online wallet balance.' };
      }

      setRetailWallets(prev => prev.map(w => {
        if (w.id === walletId) {
          return { ...w, balanceDirhams: w.balanceDirhams - amountDirhams };
        }
        return w;
      }));

      setMerchants(prev => prev.map(m => {
        if (m.id === merchantId) {
          return {
            ...m,
            balanceDirhams: m.balanceDirhams + amountDirhams,
            settledTodayDirhams: m.settledTodayDirhams + amountDirhams
          };
        }
        return m;
      }));

      const lastTx = transactions[0];
      const newTx: CBDCTransaction = {
        id: `TX-QAR-${(1001 + transactions.length).toString().padStart(7, '0')}`,
        txHash: generateHash('0x', Date.now()),
        prevHash: lastTx ? lastTx.txHash : '0x0000000000000000000000000000000000000000',
        timestamp: new Date().toISOString(),
        type: 'RETAIL_TRANSFER',
        senderId: wallet.id,
        senderNameEn: wallet.citizenNameEn,
        senderNameAr: wallet.citizenNameAr,
        receiverId: merchant.id,
        receiverNameEn: merchant.businessNameEn,
        receiverNameAr: merchant.businessNameAr,
        amountDirhams,
        currency: 'QAR-CBDC',
        status: 'SETTLED',
        complianceStatus: 'CLEARED',
        auditRef: `AUD-RETAIL-${Math.floor(Math.random() * 90000 + 10000)}`,
        memo: `Retail Instant POS QR Payment to ${merchant.businessNameEn}`,
        blockNumber: 104823 + transactions.length
      };

      setTransactions(prev => [newTx, ...prev]);

      return { success: true, message: `Retail payment of QAR ${amountQAR.toFixed(2)} settled to ${merchant.businessNameEn}` };
    }
  };

  // Offline Sync
  const syncOfflineWallet = (walletId: string) => {
    const wallet = retailWallets.find(w => w.id === walletId);
    if (!wallet) return { success: false, message: 'Wallet not found.' };

    return {
      success: true,
      message: `Offline secure hardware counter synchronized for ${wallet.citizenNameEn}. Ledger records updated.`
    };
  };

  // Trigger Stress Scenario
  const triggerStressScenario = (scenarioType: 'VOLUME_SURGE' | 'BANK_DISCONNECT' | 'LIQUIDITY_FREEZE') => {
    if (scenarioType === 'VOLUME_SURGE') {
      setSimulationSpeed(100);
      alert('STRESS INJECTED: +300% Intraday Payment Volume Surge! Processing queue handling capacity...');
    } else if (scenarioType === 'BANK_DISCONNECT') {
      setBanks(prev => prev.map((b, idx) => idx === 3 ? { ...b, status: 'SUSPENDED' } : b));
      alert('STRESS INJECTED: Simulated Node Disconnection for Doha Bank. Interbank queuing activated.');
    } else if (scenarioType === 'LIQUIDITY_FREEZE') {
      alert('STRESS INJECTED: Liquidity Shock. Auto-triggering QCB Emergency Intraday Liquidity Facility.');
    }
  };

  const t = translations[locale];

  return (
    <CBDCContext.Provider
      value={{
        banks,
        securities,
        transactions,
        auditLogs,
        retailWallets,
        merchants,
        dvpContracts,
        systemMetrics,
        activeRole,
        activeView,
        locale,
        simulationSpeed,
        invariantAlert,
        setLocale,
        setActiveRole,
        setActiveView,
        setSimulationSpeed,
        issueCBDC,
        redeemCBDC,
        transferWholesale,
        executeDvPSwap,
        executeRetailPayment,
        syncOfflineWallet,
        triggerStressScenario,
        t
      }}
    >
      {children}
    </CBDCContext.Provider>
  );
};

export const useCBDC = () => {
  const context = useContext(CBDCContext);
  if (!context) {
    throw new Error('useCBDC must be used within a CBDCProvider');
  }
  return context;
};
