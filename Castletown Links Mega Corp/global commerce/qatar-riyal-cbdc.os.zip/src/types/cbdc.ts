export type SystemRole = 
  | 'QCB_ADMIN'
  | 'BANK_SETTLEMENT'
  | 'COMPLIANCE_AUDITOR'
  | 'RESEARCHER'
  | 'RETAIL_CITIZEN';

export type ActiveView = 
  | 'OVERVIEW'
  | 'ISSUANCE_REDEMPTION'
  | 'WHOLESALE_DVP'
  | 'SECURITIES'
  | 'PARTICIPANTS'
  | 'LEDGER'
  | 'LIQUIDITY_RESEARCH'
  | 'STRESS_LAB'
  | 'RETAIL_LAB'
  | 'DOHA_MAP'
  | 'DEMO_WIZARDS'
  | 'COMPLIANCE_AUDIT';

export type TxType = 
  | 'ISSUANCE'
  | 'REDEMPTION'
  | 'WHOLESALE_TRANSFER'
  | 'RETAIL_TRANSFER'
  | 'DVP_SETTLEMENT'
  | 'PROGRAMMED_PAYMENT'
  | 'OFFLINE_RECONCILIATION';

export type TxStatus = 
  | 'PENDING'
  | 'CLEARED'
  | 'SETTLED'
  | 'REJECTED'
  | 'HELD_COMPLIANCE';

export interface ParticipantBank {
  id: string;
  code: string;
  nameEn: string;
  nameAr: string;
  swiftCode: string;
  logo: string;
  rtgsBalanceDirhams: number; // 1 QAR = 100 dirhams
  cbdcBalanceDirhams: number;
  reserveRequirementDirhams: number;
  liquidityRatio: number; // e.g. 1.28 (128%)
  status: 'ACTIVE' | 'WARNING' | 'SUSPENDED';
  securitiesVolumeDirhams: number;
  customerAccountsCount: number;
}

export interface CBDCTransaction {
  id: string;
  txHash: string;
  prevHash: string;
  timestamp: string;
  type: TxType;
  senderId: string;
  senderNameEn: string;
  senderNameAr: string;
  receiverId: string;
  receiverNameEn: string;
  receiverNameAr: string;
  amountDirhams: number;
  currency: 'QAR-CBDC';
  status: TxStatus;
  complianceStatus: 'CLEARED' | 'FLAGGED' | 'REVIEW';
  auditRef: string;
  memo?: string;
  blockNumber: number;
}

export interface DigitalSecurity {
  isin: string;
  titleEn: string;
  titleAr: string;
  issuerId: string;
  issuerNameEn: string;
  issuerNameAr: string;
  type: 'GOV_BOND' | 'SUKUK' | 'BANK_PAPER' | 'CORP_BOND';
  maturityDate: string;
  couponPercent: number;
  nominalPriceDirhams: number;
  marketPriceDirhams: number;
  totalVolume: number;
  availableVolume: number;
  yieldPercent: number;
  isTokenized: boolean;
  imagePath?: string;
}

export interface DvPContract {
  id: string;
  contractHash: string;
  buyerId: string;
  buyerNameEn: string;
  sellerId: string;
  sellerNameEn: string;
  securityIsin: string;
  securityTitleEn: string;
  quantity: number;
  pricePerUnitDirhams: number;
  totalCbdcAmountDirhams: number;
  status: 'INITIATED' | 'LOCKED' | 'ATOMIC_SETTLED' | 'ABORTED';
  timestamp: string;
  atomicExecutionTimeMs: number;
}

export interface AuditEvent {
  id: string;
  timestamp: string;
  actorId: string;
  actorRole: SystemRole;
  action: string;
  amountDirhams?: number;
  targetEntity: string;
  eventHash: string;
  prevHash: string;
  status: 'VERIFIED' | 'TAMPER_ALERT';
}

export interface RetailWallet {
  id: string;
  citizenNameEn: string;
  citizenNameAr: string;
  qid: string;
  tier: 'TIER_1_BASIC' | 'TIER_2_VERIFIED' | 'TIER_3_MERCHANT';
  balanceDirhams: number;
  dailyLimitDirhams: number;
  remainingDailyLimitDirhams: number;
  offlineBalanceDirhams: number;
  deviceHardwareId: string;
  isOfflineActive: boolean;
}

export interface MerchantAccount {
  id: string;
  businessNameEn: string;
  businessNameAr: string;
  category: string;
  crNumber: string;
  balanceDirhams: number;
  settledTodayDirhams: number;
  qrCodeData: string;
}

export interface SystemMetrics {
  totalCirculationDirhams: number; // Wholesale + Retail
  wholesaleCirculationDirhams: number;
  retailCirculationDirhams: number;
  rtgsCollateralLockedDirhams: number;
  transactionsTodayCount: number;
  settlementVolumeTodayDirhams: number;
  activeParticipantsCount: number;
  pendingSettlementDirhams: number;
  digitalSecuritiesValueDirhams: number;
  averageSettlementTimeMs: number;
  ledgerBlockHeight: number;
  systemStatus: 'OPERATIONAL' | 'HIGH_LOAD' | 'MAINTENANCE_MODE';
}

export interface StressScenario {
  id: string;
  titleEn: string;
  titleAr: string;
  descriptionEn: string;
  descriptionAr: string;
  volumeMultiplier: number;
  participantFailureId?: string;
  liquidityShockPercent: number;
  networkInterruption: boolean;
  active: boolean;
}
