package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

// --- ENUMS & STATUS TYPOLOGY ---

enum class RestaurantStatus {
    OPEN, CLOSED, OPENING_SOON, HIGH_DEMAND, LIMITED_MENU, TEMPORARILY_CLOSED, SYSTEM_OFFLINE
}

enum class OrderType {
    TOGO, CURBSIDE
}

enum class OrderStatus {
    ORDERED, PREPARING, READY, ARRIVING, ARRIVED, STAFF_NOTIFIED, HANDED_OVER, COMPLETE, EXCEPTION
}

enum class WaitlistStatus {
    AVAILABLE, JOINING, CONFIRMED, WAITING, NEARLY_READY, READY, CHECKED_IN, SEATED, CANCELLED, EXPIRED
}

enum class InventoryStatus {
    AVAILABLE, LIMITED, UNAVAILABLE
}

enum class OfferStatus {
    AVAILABLE, CLAIMED, APPLIED, EXPIRED, INELIGIBLE
}

// --- ROOM ENTITIES ---

@Entity(tableName = "restaurants")
data class Restaurant(
    @PrimaryKey val id: String,
    val name: String,
    val address: String,
    val phone: String,
    val distance: Double, // in miles
    val currentWaitMin: Int,
    val openTime: String,
    val closeTime: String,
    val serviceWaitlist: Boolean = true,
    val serviceToGo: Boolean = true,
    val serviceCurbside: Boolean = true,
    val kitchenCapacityPercent: Int = 40,
    val status: RestaurantStatus = RestaurantStatus.OPEN,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val version: Int = 1,
    val provenance: String = "SYNTHETIC"
)

@Entity(tableName = "menu_items")
data class MenuItem(
    @PrimaryKey val id: String,
    val name: String,
    val category: String, // "STEAKS", "SIDES", "DESSERTS", etc.
    val description: String,
    val price: Double,
    val calories: Int,
    val cutType: String = "", // e.g. "Ribeye", "Filet", "Sirloin"
    val weightOz: Int = 0,
    val recommendedDoneness: String = "MEDIUM_RARE",
    val signatureSeasoning: String = "Bold Prairie",
    val imageUrl: String = "",
    val isAvailable: Boolean = true,
    val isFeatured: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val version: Int = 1,
    val provenance: String = "SYNTHETIC"
)

@Entity(tableName = "cart_items")
data class CartItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val menuItemId: String,
    val itemName: String,
    val category: String,
    val quantity: Int,
    val doneness: String = "MEDIUM_RARE",
    val side1Name: String = "None",
    val side2Name: String = "None",
    val addOnName: String = "None",
    val specialInstructions: String = "",
    val unitPrice: Double = 0.0,
    val totalPrice: Double = 0.0
)

@Entity(tableName = "orders")
data class Order(
    @PrimaryKey val id: String,
    val orderNumber: String,
    val restaurantId: String,
    val restaurantName: String,
    val customerName: String,
    val customerPhone: String,
    val itemsSummary: String, // JSON or descriptive text summary
    val orderType: OrderType = OrderType.TOGO,
    val pickupTime: String = "ASAP",
    // Curbside Info
    val parkingSpace: String = "",
    val vehicleDescription: String = "",
    val vehicleColor: String = "",
    val licensePlate: String = "",
    val totalAmount: Double = 0.0,
    val orderStatus: OrderStatus = OrderStatus.ORDERED,
    val paymentStatus: String = "PAID", // "PAID", "UNPAID"
    val paymentDetails: String = "Mock Abstract Payment Card",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val version: Int = 1,
    val provenance: String = "SYNTHETIC"
)

@Entity(tableName = "waitlist_entries")
data class WaitlistEntry(
    @PrimaryKey val id: String,
    val restaurantId: String,
    val restaurantName: String,
    val partySize: Int,
    val customerName: String,
    val customerPhone: String,
    val customerEmail: String = "",
    val estWaitMin: Int = 20,
    val status: WaitlistStatus = WaitlistStatus.CONFIRMED,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val version: Int = 1,
    val provenance: String = "SYNTHETIC"
)

@Entity(tableName = "gift_cards")
data class GiftCard(
    @PrimaryKey val id: String,
    val cardNumber: String,
    val balance: Double,
    val originalBalance: Double = 50.0,
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val version: Int = 1,
    val provenance: String = "SYNTHETIC"
)

@Entity(tableName = "offers")
data class Offer(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val promoCode: String,
    val discountPercent: Int,
    val status: OfferStatus = OfferStatus.AVAILABLE,
    val expirationDate: String = "12/31/2026",
    val provenance: String = "SYNTHETIC"
)

@Entity(tableName = "favourites")
data class Favourite(
    @PrimaryKey val id: String, // usually composite or matches menuItemId
    val menuItemId: String,
    val itemName: String,
    val itemCategory: String,
    val price: Double,
    val description: String,
    val imageUrl: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "inventory")
data class InventoryRecord(
    @PrimaryKey val id: String,
    val ingredientName: String,
    val quantity: Double,
    val unit: String = "lbs",
    val reorderThreshold: Double = 10.0,
    val status: InventoryStatus = InventoryStatus.AVAILABLE,
    val restaurantId: String,
    val updatedAt: Long = System.currentTimeMillis(),
    val provenance: String = "SYNTHETIC"
)

@Entity(tableName = "audit_events")
data class AuditEvent(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val entityName: String,
    val entityId: String,
    val actionType: String, // "INSERT", "UPDATE_STATUS", "INVENTORY_CHANGE"
    val oldState: String,
    val newState: String,
    val timestamp: Long = System.currentTimeMillis(),
    val performedBy: String = "SYSTEM_HQ",
    val provenance: String = "SYNTHETIC"
)
