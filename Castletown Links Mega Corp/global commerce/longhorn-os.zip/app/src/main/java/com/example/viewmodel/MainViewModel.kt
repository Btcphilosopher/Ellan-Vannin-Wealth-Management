package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.model.*
import com.example.data.repository.AppRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: AppRepository

    // --- REACTIVE DATABASE FLOWS ---
    val restaurants: StateFlow<List<Restaurant>>
    val menuItems: StateFlow<List<MenuItem>>
    val cartItems: StateFlow<List<CartItem>>
    val orders: StateFlow<List<Order>>
    val waitlistEntries: StateFlow<List<WaitlistEntry>>
    val giftCards: StateFlow<List<GiftCard>>
    val offers: StateFlow<List<Offer>>
    val favourites: StateFlow<List<Favourite>>
    val inventory: StateFlow<List<InventoryRecord>>
    val auditEvents: StateFlow<List<AuditEvent>>

    // --- ACTIVE INTERACTION STATES ---
    val selectedRestaurant = MutableStateFlow<Restaurant?>(null)
    val selectedMenuItem = MutableStateFlow<MenuItem?>(null)
    val trackingOrderId = MutableStateFlow<String?>(null)
    val trackingWaitlistId = MutableStateFlow<String?>(null)

    // User profile simulation (customer)
    val customerName = MutableStateFlow("Tom")
    val customerPhone = MutableStateFlow("555-0199")
    val customerEmail = MutableStateFlow("tom@ahyx.org")
    val eClubSignedUp = MutableStateFlow(false)

    // View tracking
    val isHqMode = MutableStateFlow(false)

    init {
        val database = AppDatabase.getDatabase(application)
        repository = AppRepository(database.appDao())

        // Start database seeding if empty (will run once upon database creation)
        viewModelScope.launch {
            val existing = database.appDao().getRestaurantById("R1")
            if (existing == null) {
                AppDatabase.seedDatabase(database)
            }
        }

        // Initialize StateFlows with subscription scopes
        restaurants = repository.allRestaurants
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        menuItems = repository.allMenuItems
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        cartItems = repository.cartItems
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        orders = repository.allOrders
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        waitlistEntries = repository.allWaitlistEntries
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        giftCards = repository.allGiftCards
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        offers = repository.allOffers
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        favourites = repository.allFavourites
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        inventory = repository.allInventory
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        auditEvents = repository.allAuditEvents
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

        // Auto-select Buckhead restaurant as default nearby
        viewModelScope.launch {
            restaurants.collectFirst { list ->
                if (list.isNotEmpty() && selectedRestaurant.value == null) {
                    selectedRestaurant.value = list.first()
                }
            }
        }
    }

    // --- FLOW UTILS ---
    private suspend fun <T> StateFlow<List<T>>.collectFirst(action: suspend (List<T>) -> Unit) {
        this.filter { it.isNotEmpty() }.take(1).collect { action(it) }
    }

    // --- CUSTOMER ACTIONS ---

    fun addToCart(
        menuItem: MenuItem,
        quantity: Int,
        doneness: String,
        side1: String,
        side2: String,
        specialInstructions: String
    ) {
        viewModelScope.launch {
            val itemPrice = menuItem.price
            val totalPrice = itemPrice * quantity
            val cartItem = CartItem(
                menuItemId = menuItem.id,
                itemName = menuItem.name,
                category = menuItem.category,
                quantity = quantity,
                doneness = doneness,
                side1Name = side1,
                side2Name = side2,
                specialInstructions = specialInstructions,
                unitPrice = itemPrice,
                totalPrice = totalPrice
            )
            repository.addToCart(cartItem)
        }
    }

    fun deleteCartItem(item: CartItem) {
        viewModelScope.launch {
            repository.removeFromCart(item)
        }
    }

    fun clearCart() {
        viewModelScope.launch {
            repository.clearCart()
        }
    }

    fun toggleFavourite(menuItem: MenuItem) {
        viewModelScope.launch {
            repository.toggleFavourite(menuItem)
        }
    }

    fun submitOrder(
        orderType: OrderType,
        pickupTime: String,
        vehicleDesc: String,
        vehicleColor: String,
        licensePlate: String,
        parkingSpace: String,
        appliedOffer: Offer?,
        giftCardPaymentNumber: String = ""
    ) {
        viewModelScope.launch {
            val currentCart = cartItems.value
            if (currentCart.isEmpty()) return@launch

            val restaurant = selectedRestaurant.value ?: restaurants.value.first()
            val totalBeforeDiscount = currentCart.sumOf { it.totalPrice }
            val discount = if (appliedOffer != null) {
                totalBeforeDiscount * (appliedOffer.discountPercent / 100.0)
            } else 0.0
            val finalAmount = totalBeforeDiscount - discount

            val itemsSummaryText = currentCart.joinToString("; ") {
                "${it.quantity}x ${it.itemName} (${it.doneness}, Sides: ${it.side1Name}/${it.side2Name})"
            }

            val orderId = "ORD-" + UUID.randomUUID().toString().substring(0, 8).uppercase()
            val orderNum = "LH-" + (1000 + orders.value.size + 1)

            // Deduct gift card if specified
            var paymentDetails = "Mock Credit Card"
            if (giftCardPaymentNumber.isNotEmpty()) {
                val success = repository.applyGiftCardPayment(giftCardPaymentNumber, finalAmount)
                if (success) {
                    paymentDetails = "Gift Card $giftCardPaymentNumber"
                }
            }

            val newOrder = Order(
                id = orderId,
                orderNumber = orderNum,
                restaurantId = restaurant.id,
                restaurantName = restaurant.name,
                customerName = customerName.value,
                customerPhone = customerPhone.value,
                itemsSummary = itemsSummaryText,
                orderType = orderType,
                pickupTime = pickupTime,
                parkingSpace = parkingSpace,
                vehicleDescription = vehicleDesc,
                vehicleColor = vehicleColor,
                licensePlate = licensePlate,
                totalAmount = finalAmount,
                orderStatus = OrderStatus.ORDERED,
                paymentStatus = "PAID",
                paymentDetails = paymentDetails
            )

            repository.createOrder(newOrder)
            trackingOrderId.value = orderId
            repository.clearCart()

            // Update restaurant capacity briefly
            val updatedCap = (restaurant.kitchenCapacityPercent + 10).coerceAtMost(100)
            repository.updateRestaurant(restaurant.copy(kitchenCapacityPercent = updatedCap))
        }
    }

    fun joinWaitlist(partySize: Int) {
        viewModelScope.launch {
            val restaurant = selectedRestaurant.value ?: restaurants.value.first()
            val entryId = "WLT-" + UUID.randomUUID().toString().substring(0, 8).uppercase()
            val estWait = if (restaurant.currentWaitMin > 0) restaurant.currentWaitMin else 15

            val entry = WaitlistEntry(
                id = entryId,
                restaurantId = restaurant.id,
                restaurantName = restaurant.name,
                partySize = partySize,
                customerName = customerName.value,
                customerPhone = customerPhone.value,
                customerEmail = customerEmail.value,
                estWaitMin = estWait,
                status = WaitlistStatus.CONFIRMED
            )

            repository.joinWaitlist(entry)
            trackingWaitlistId.value = entryId

            // Dynamically increment waitlist time for other customers
            val updatedWait = restaurant.currentWaitMin + (partySize * 3)
            repository.updateRestaurant(restaurant.copy(currentWaitMin = updatedWait))
        }
    }

    fun leaveWaitlist() {
        viewModelScope.launch {
            val activeId = trackingWaitlistId.value ?: return@launch
            repository.leaveWaitlist(activeId)
            trackingWaitlistId.value = null
        }
    }

    fun checkInWaitlist() {
        viewModelScope.launch {
            val activeId = trackingWaitlistId.value ?: return@launch
            repository.updateWaitlistStatus(activeId, WaitlistStatus.CHECKED_IN, 0)
        }
    }

    fun claimOffer(offerId: String) {
        viewModelScope.launch {
            repository.updateOfferStatus(offerId, OfferStatus.CLAIMED)
        }
    }

    fun checkGiftCard(number: String, onResult: (GiftCard?) -> Unit) {
        viewModelScope.launch {
            val card = repository.getGiftCardByNumber(number)
            onResult(card)
        }
    }

    fun purchaseGiftCard(number: String, amount: Double) {
        viewModelScope.launch {
            repository.purchaseGiftCard(number, amount)
        }
    }

    fun subscribeEClub() {
        eClubSignedUp.value = true
        // Grant a welcome offer!
        viewModelScope.launch {
            repository.logAudit(
                entityName = "Customer",
                entityId = customerPhone.value,
                actionType = "SUBSCRIBE_ECLUB",
                oldState = "NOT_SUBSCRIBED",
                newState = "SUBSCRIBED"
            )
        }
    }


    // --- HQ ACTIONS ---

    fun updateOrderStatusHq(orderId: String, nextStatus: OrderStatus) {
        viewModelScope.launch {
            repository.updateOrderStatus(orderId, nextStatus)
        }
    }

    fun updateWaitlistStatusHq(entryId: String, nextStatus: WaitlistStatus) {
        viewModelScope.launch {
            val entry = waitlistEntries.value.firstOrNull { it.id == entryId } ?: return@launch
            val newWait = if (nextStatus == WaitlistStatus.SEATED || nextStatus == WaitlistStatus.CANCELLED) 0 else entry.estWaitMin
            repository.updateWaitlistStatus(entryId, nextStatus, newWait)

            // If seated, decrement restaurant wait time
            if (nextStatus == WaitlistStatus.SEATED) {
                val res = restaurants.value.firstOrNull { it.id == entry.restaurantId }
                if (res != null) {
                    val decrementedWait = (res.currentWaitMin - (entry.partySize * 3)).coerceAtLeast(0)
                    repository.updateRestaurant(res.copy(currentWaitMin = decrementedWait))
                }
            }
        }
    }

    fun updateInventoryHq(recordId: String, nextQuantity: Double) {
        viewModelScope.launch {
            repository.updateInventoryQuantity(recordId, nextQuantity)
        }
    }

    fun toggleMenuItemAvailabilityHq(itemId: String, nextAvailable: Boolean) {
        viewModelScope.launch {
            repository.updateMenuItemAvailability(itemId, nextAvailable)
        }
    }

    fun triggerSimulatedGrillLoad() {
        viewModelScope.launch {
            // Simulated heavy queue loads for the cooking visualization
            repository.logAudit(
                entityName = "Kitchen",
                entityId = "Grill-Cluster",
                actionType = "SIMULATE_GRILL_LOAD",
                oldState = "Standard load",
                newState = "Grill 01: Outlaw Ribeye MED-RARE [Active], Grill 02: Flo's Filet MED [Active]"
            )
        }
    }
}
