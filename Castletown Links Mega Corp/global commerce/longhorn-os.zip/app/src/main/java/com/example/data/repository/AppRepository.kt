package com.example.data.repository

import com.example.data.dao.AppDao
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class AppRepository(private val appDao: AppDao) {

    // --- RESTAURANTS ---
    val allRestaurants: Flow<List<Restaurant>> = appDao.getAllRestaurants()

    suspend fun getRestaurantById(id: String): Restaurant? = appDao.getRestaurantById(id)

    fun getRestaurantFlowById(id: String): Flow<Restaurant?> = appDao.getRestaurantFlowById(id)

    suspend fun updateRestaurant(restaurant: Restaurant) {
        val old = appDao.getRestaurantById(restaurant.id)
        appDao.updateRestaurant(restaurant)
        logAudit(
            entityName = "Restaurant",
            entityId = restaurant.id,
            actionType = "UPDATE_RESTAURANT",
            oldState = old?.status?.name ?: "UNKNOWN",
            newState = restaurant.status.name
        )
    }

    // --- MENU ITEMS ---
    val allMenuItems: Flow<List<MenuItem>> = appDao.getAllMenuItems()

    suspend fun getMenuItemById(id: String): MenuItem? = appDao.getMenuItemById(id)

    suspend fun updateMenuItemAvailability(id: String, isAvailable: Boolean) {
        val oldItem = appDao.getMenuItemById(id)
        val oldState = if (oldItem?.isAvailable == true) "AVAILABLE" else "UNAVAILABLE"
        val newState = if (isAvailable) "AVAILABLE" else "UNAVAILABLE"

        appDao.updateMenuItemAvailability(id, isAvailable)
        logAudit(
            entityName = "MenuItem",
            entityId = id,
            actionType = "UPDATE_AVAILABILITY",
            oldState = oldState,
            newState = newState
        )
    }

    // --- CART ---
    val cartItems: Flow<List<CartItem>> = appDao.getCartItems()

    suspend fun addToCart(item: CartItem) {
        appDao.insertCartItem(item)
    }

    suspend fun updateCartItem(item: CartItem) {
        appDao.updateCartItem(item)
    }

    suspend fun removeFromCart(item: CartItem) {
        appDao.deleteCartItem(item)
    }

    suspend fun clearCart() {
        appDao.clearCart()
    }

    // --- ORDERS ---
    val allOrders: Flow<List<Order>> = appDao.getAllOrders()

    suspend fun getOrderById(id: String): Order? = appDao.getOrderById(id)

    fun getOrderFlowById(id: String): Flow<Order?> = appDao.getOrderFlowById(id)

    suspend fun createOrder(order: Order) {
        appDao.insertOrder(order)
        logAudit(
            entityName = "Order",
            entityId = order.id,
            actionType = "PLACE_ORDER",
            oldState = "NONE",
            newState = order.orderStatus.name
        )
    }

    suspend fun updateOrderStatus(id: String, status: OrderStatus) {
        val oldOrder = appDao.getOrderById(id)
        val oldStatus = oldOrder?.orderStatus ?: OrderStatus.ORDERED
        appDao.updateOrderStatus(id, status)
        logAudit(
            entityName = "Order",
            entityId = id,
            actionType = "UPDATE_ORDER_STATUS",
            oldState = oldStatus.name,
            newState = status.name
        )
    }

    // --- WAITLIST ---
    val allWaitlistEntries: Flow<List<WaitlistEntry>> = appDao.getAllWaitlistEntries()

    fun getWaitlistForRestaurant(restaurantId: String): Flow<List<WaitlistEntry>> =
        appDao.getWaitlistForRestaurant(restaurantId)

    suspend fun getWaitlistEntry(id: String): WaitlistEntry? = appDao.getWaitlistEntry(id)

    fun getWaitlistEntryFlow(id: String): Flow<WaitlistEntry?> = appDao.getWaitlistEntryFlow(id)

    suspend fun joinWaitlist(entry: WaitlistEntry) {
        appDao.insertWaitlist(entry)
        logAudit(
            entityName = "Waitlist",
            entityId = entry.id,
            actionType = "JOIN_WAITLIST",
            oldState = "NONE",
            newState = entry.status.name
        )
    }

    suspend fun updateWaitlistStatus(id: String, status: WaitlistStatus, estWait: Int) {
        val oldEntry = appDao.getWaitlistEntry(id)
        val oldStatus = oldEntry?.status ?: WaitlistStatus.CONFIRMED
        appDao.updateWaitlistStatus(id, status, estWait)
        logAudit(
            entityName = "Waitlist",
            entityId = id,
            actionType = "UPDATE_WAITLIST_STATUS",
            oldState = oldStatus.name,
            newState = status.name
        )
    }

    suspend fun leaveWaitlist(id: String) {
        val entry = appDao.getWaitlistEntry(id)
        if (entry != null) {
            appDao.updateWaitlistStatus(id, WaitlistStatus.CANCELLED, 0)
            logAudit(
                entityName = "Waitlist",
                entityId = id,
                actionType = "CANCEL_WAITLIST",
                oldState = entry.status.name,
                newState = "CANCELLED"
            )
        }
    }

    // --- GIFT CARDS ---
    val allGiftCards: Flow<List<GiftCard>> = appDao.getAllGiftCards()

    suspend fun getGiftCardByNumber(number: String): GiftCard? = appDao.getGiftCardByNumber(number)

    suspend fun applyGiftCardPayment(number: String, amountToDeduct: Double): Boolean {
        val card = appDao.getGiftCardByNumber(number)
        return if (card != null && card.isActive && card.balance >= amountToDeduct) {
            val oldBalance = card.balance
            val newBalance = card.balance - amountToDeduct
            val updated = card.copy(balance = newBalance)
            appDao.updateGiftCard(updated)
            logAudit(
                entityName = "GiftCard",
                entityId = card.id,
                actionType = "APPLY_PAYMENT",
                oldState = "Balance: $oldBalance",
                newState = "Balance: $newBalance"
            )
            true
        } else {
            false
        }
    }

    suspend fun purchaseGiftCard(cardNumber: String, originalBalance: Double) {
        val newCard = GiftCard(
            id = UUID.randomUUID().toString(),
            cardNumber = cardNumber,
            balance = originalBalance,
            originalBalance = originalBalance
        )
        appDao.insertGiftCard(newCard)
        logAudit(
            entityName = "GiftCard",
            entityId = newCard.id,
            actionType = "PURCHASE_GIFT_CARD",
            oldState = "NONE",
            newState = "Active Card with balance $$originalBalance"
        )
    }

    // --- OFFERS ---
    val allOffers: Flow<List<Offer>> = appDao.getAllOffers()

    suspend fun getOfferById(id: String): Offer? = appDao.getOfferById(id)

    suspend fun updateOfferStatus(id: String, status: OfferStatus) {
        val old = appDao.getOfferById(id)
        if (old != null) {
            appDao.updateOffer(old.copy(status = status))
            logAudit(
                entityName = "Offer",
                entityId = id,
                actionType = "UPDATE_OFFER_STATUS",
                oldState = old.status.name,
                newState = status.name
            )
        }
    }

    // --- FAVOURITES ---
    val allFavourites: Flow<List<Favourite>> = appDao.getAllFavourites()

    suspend fun toggleFavourite(menuItem: MenuItem) {
        val existing = appDao.getFavouriteByMenuItemId(menuItem.id)
        if (existing != null) {
            appDao.deleteFavouriteByMenuItemId(menuItem.id)
            logAudit(
                entityName = "Favourite",
                entityId = menuItem.id,
                actionType = "REMOVE_FAVOURITE",
                oldState = "FAVOURITE",
                newState = "NONE"
            )
        } else {
            val favourite = Favourite(
                id = menuItem.id,
                menuItemId = menuItem.id,
                itemName = menuItem.name,
                itemCategory = menuItem.category,
                price = menuItem.price,
                description = menuItem.description,
                imageUrl = menuItem.imageUrl
            )
            appDao.insertFavourite(favourite)
            logAudit(
                entityName = "Favourite",
                entityId = menuItem.id,
                actionType = "ADD_FAVOURITE",
                oldState = "NONE",
                newState = "FAVOURITE"
            )
        }
    }

    // --- INVENTORY ---
    val allInventory: Flow<List<InventoryRecord>> = appDao.getAllInventory()

    fun getInventoryForRestaurant(restaurantId: String): Flow<List<InventoryRecord>> =
        appDao.getInventoryForRestaurant(restaurantId)

    suspend fun updateInventoryQuantity(id: String, newQuantity: Double) {
        val record = appDao.getInventoryById(id)
        if (record != null) {
            val oldQty = record.quantity
            val oldStatus = record.status

            val newStatus = when {
                newQuantity <= 0.0 -> InventoryStatus.UNAVAILABLE
                newQuantity <= record.reorderThreshold -> InventoryStatus.LIMITED
                else -> InventoryStatus.AVAILABLE
            }

            val updated = record.copy(quantity = newQuantity, status = newStatus, updatedAt = System.currentTimeMillis())
            appDao.updateInventory(updated)

            logAudit(
                entityName = "Inventory",
                entityId = id,
                actionType = "UPDATE_INVENTORY",
                oldState = "Qty: $oldQty, Status: ${oldStatus.name}",
                newState = "Qty: $newQuantity, Status: ${newStatus.name}"
            )

            // Dynamic connection between Inventory and MenuItem Availability (Section 40)
            // If inventory name matches a steak cut, let's sync the corresponding menu item!
            val menuItemToSync = when {
                record.ingredientName.contains("Ribeye") -> "M1"
                record.ingredientName.contains("Filet") -> "M2"
                record.ingredientName.contains("Sirloin") -> "M3"
                else -> null
            }

            if (menuItemToSync != null) {
                val isAvailable = newStatus != InventoryStatus.UNAVAILABLE
                appDao.updateMenuItemAvailability(menuItemToSync, isAvailable)
                logAudit(
                    entityName = "MenuItem",
                    entityId = menuItemToSync,
                    actionType = "SYNC_FROM_INVENTORY",
                    oldState = "Inventory status changed for ${record.ingredientName}",
                    newState = "Set MenuItem isAvailable = $isAvailable"
                )
            }
        }
    }

    // --- AUDIT ---
    val allAuditEvents: Flow<List<AuditEvent>> = appDao.getAllAuditEvents()

    suspend fun logAudit(
        entityName: String,
        entityId: String,
        actionType: String,
        oldState: String,
        newState: String
    ) {
        val audit = AuditEvent(
            entityName = entityName,
            entityId = entityId,
            actionType = actionType,
            oldState = oldState,
            newState = newState,
            timestamp = System.currentTimeMillis(),
            performedBy = "SYSTEM_HQ"
        )
        appDao.insertAuditEvent(audit)
    }
}
