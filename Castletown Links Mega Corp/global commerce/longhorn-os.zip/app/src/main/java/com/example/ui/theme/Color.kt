package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// LongHorn Steakhouse-inspired color palette
val CharcoalBg = Color(0xFF121212)       // Near-black dark background
val DarkWood = Color(0xFF1A110B)         // Deep timber wood color
val CastIron = Color(0xFF261D17)         // Deep warm grey/brown cast iron surface
val BurntRed = Color(0xFFB22222)         // Primary action / Steakhouse red
val FlameOrange = Color(0xFFFF6D00)      // Accent fire grill orange
val AgedBrass = Color(0xFFC5A059)        // Accent warm brass
val WarmCream = Color(0xFFFAF5EF)        // Soft warm background for light contrast
val SageGreen = Color(0xFF556B2F)        // Sage/olive secondary tone
val WarmGrey = Color(0xFF757575)         // Smoke grey
val TanLeather = Color(0xFFD27D2D)       // Tooled leather accent

// Dark theme defaults
val PrimaryDark = BurntRed
val SecondaryDark = AgedBrass
val TertiaryDark = TanLeather
val BackgroundDark = CharcoalBg
val SurfaceDark = CastIron

// Light theme defaults (for the HQ operational view, which is clean, precise, operational)
val PrimaryLight = BurntRed
val SecondaryLight = SageGreen
val TertiaryLight = AgedBrass
val BackgroundLight = WarmCream
val SurfaceLight = Color.White
