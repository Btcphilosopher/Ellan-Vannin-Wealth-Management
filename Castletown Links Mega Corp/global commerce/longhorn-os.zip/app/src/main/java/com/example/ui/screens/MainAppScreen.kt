package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.*
import com.example.ui.theme.*
import com.example.viewmodel.MainViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Simple screen routing
enum class CustomerTab {
    HOME, MENU, CART, WAITLIST, PROFILE
}

enum class HqTab {
    DASHBOARD, ORDERS, KITCHEN, WAITLIST, INVENTORY, AUDIT
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen(viewModel: MainViewModel) {
    val hqMode by viewModel.isHqMode.collectAsStateWithLifecycle()
    val activeCustomerTab = remember { mutableStateOf(CustomerTab.HOME) }
    val activeHqTab = remember { mutableStateOf(HqTab.DASHBOARD) }

    // Navigation backstacks or modal sheets
    val selectedItem by viewModel.selectedMenuItem.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = if (hqMode) Color(0xFF1E1E1E) else DarkWood,
                    titleContentColor = WarmCream
                ),
                title = {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.LocalFireDepartment,
                                contentDescription = "Fire logo",
                                tint = FlameOrange,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "LONGHORN OS",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.5.sp
                                )
                            )
                        }

                        // Mode switcher: Customer vs HQ
                        Surface(
                            modifier = Modifier
                                .padding(end = 12.dp)
                                .clip(RoundedCornerShape(50))
                                .clickable {
                                    viewModel.isHqMode.value = !hqMode
                                },
                            color = if (hqMode) BurntRed else CastIron,
                            contentColor = WarmCream
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (hqMode) Icons.Default.Terminal else Icons.Default.Restaurant,
                                    contentDescription = "Mode Switch",
                                    modifier = Modifier.size(16.dp),
                                    tint = if (hqMode) Color.White else AgedBrass
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (hqMode) "HQ SYSTEM" else "CUSTOMER APP",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 0.5.sp
                                    )
                                )
                            }
                        }
                    }
                }
            )
        },
        bottomBar = {
            if (!hqMode) {
                NavigationBar(
                    containerColor = DarkWood,
                    tonalElevation = 8.dp
                ) {
                    val tabs = listOf(
                        Triple(CustomerTab.HOME, Icons.Default.Home, "Home"),
                        Triple(CustomerTab.MENU, Icons.Default.RestaurantMenu, "Menu"),
                        Triple(CustomerTab.CART, Icons.Default.ShoppingCart, "Cart"),
                        Triple(CustomerTab.WAITLIST, Icons.Default.FormatListNumbered, "Waitlist"),
                        Triple(CustomerTab.PROFILE, Icons.Default.Person, "eClub")
                    )
                    tabs.forEach { (tab, icon, label) ->
                        val selected = activeCustomerTab.value == tab
                        NavigationBarItem(
                            selected = selected,
                            onClick = { activeCustomerTab.value = tab },
                            icon = { Icon(imageVector = icon, contentDescription = label) },
                            label = { Text(text = label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.White,
                                selectedTextColor = AgedBrass,
                                indicatorColor = BurntRed,
                                unselectedIconColor = WarmGrey,
                                unselectedTextColor = WarmGrey
                            ),
                            modifier = Modifier.testTag("nav_tab_${label.lowercase()}")
                        )
                    }
                }
            } else {
                NavigationBar(
                    containerColor = Color(0xFF1E1E1E),
                    tonalElevation = 4.dp
                ) {
                    val tabs = listOf(
                        Triple(HqTab.DASHBOARD, Icons.Default.Dashboard, "Stats"),
                        Triple(HqTab.ORDERS, Icons.Default.ReceiptLong, "Orders"),
                        Triple(HqTab.KITCHEN, Icons.Default.LocalPizza, "KDS"),
                        Triple(HqTab.WAITLIST, Icons.Default.People, "Waitlist"),
                        Triple(HqTab.INVENTORY, Icons.Default.Warehouse, "Stock"),
                        Triple(HqTab.AUDIT, Icons.Default.HistoryEdu, "Audit")
                    )
                    tabs.forEach { (tab, icon, label) ->
                        val selected = activeHqTab.value == tab
                        NavigationBarItem(
                            selected = selected,
                            onClick = { activeHqTab.value = tab },
                            icon = { Icon(imageVector = icon, contentDescription = label) },
                            label = { Text(text = label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.White,
                                selectedTextColor = AgedBrass,
                                indicatorColor = SageGreen,
                                unselectedIconColor = Color.Gray,
                                unselectedTextColor = Color.Gray
                            )
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(if (hqMode) Color(0xFF151515) else CharcoalBg)
        ) {
            AnimatedContent(
                targetState = hqMode,
                transitionSpec = {
                    fadeIn(animationSpec = tween(300)) togetherWith fadeOut(animationSpec = tween(300))
                },
                label = "ModeTransition"
            ) { targetHqMode ->
                if (!targetHqMode) {
                    // CUSTOMER SPACE
                    when (activeCustomerTab.value) {
                        CustomerTab.HOME -> CustomerHomeScreen(viewModel, { activeCustomerTab.value = CustomerTab.MENU }, { activeCustomerTab.value = CustomerTab.WAITLIST })
                        CustomerTab.MENU -> CustomerMenuScreen(viewModel)
                        CustomerTab.CART -> CartScreen(viewModel)
                        CustomerTab.WAITLIST -> WaitlistScreen(viewModel)
                        CustomerTab.PROFILE -> ProfileScreen(viewModel)
                    }
                } else {
                    // HQ OPERATING SYSTEM SPACE
                    when (activeHqTab.value) {
                        HqTab.DASHBOARD -> HqDashboardScreen(viewModel)
                        HqTab.ORDERS -> HqOrdersScreen(viewModel)
                        HqTab.KITCHEN -> HqKitchenKdsScreen(viewModel)
                        HqTab.WAITLIST -> HqWaitlistScreen(viewModel)
                        HqTab.INVENTORY -> HqInventoryScreen(viewModel)
                        HqTab.AUDIT -> HqAuditScreen(viewModel)
                    }
                }
            }

            // Global Full-Screen Steak Detail customization page overlay
            selectedItem?.let { menuItem ->
                SteakDetailScreen(
                    menuItem = menuItem,
                    viewModel = viewModel,
                    onDismiss = { viewModel.selectedMenuItem.value = null }
                )
            }
        }
    }
}

// ==========================================
// --- CUSTOMER PORTAL SCREENS ---
// ==========================================

@Composable
fun CustomerHomeScreen(
    viewModel: MainViewModel,
    onNavigateToMenu: () -> Unit,
    onNavigateToWaitlist: () -> Unit
) {
    val favourites by viewModel.favourites.collectAsStateWithLifecycle()
    val orders by viewModel.orders.collectAsStateWithLifecycle()
    val selectedRes by viewModel.selectedRestaurant.collectAsStateWithLifecycle()
    val restaurants by viewModel.restaurants.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Card (Section 5: Customer Home)
        item {
            Spacer(modifier = Modifier.height(12.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(240.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(DarkWood)
                    .drawBehind {
                        // Drawing rustic grill smoke marks background
                        val brush = Brush.verticalGradient(
                            colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f)),
                            startY = 0f
                        )
                        drawRect(brush)
                    }
                    .padding(16.dp),
                contentAlignment = Alignment.BottomStart
            ) {
                // Fire Flame embers drawing in canvas
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val path = Stroke(width = 5f)
                    // Fire embers simulation lines
                    drawCircle(FlameOrange.copy(alpha = 0.2f), radius = 120f, center = Offset(size.width - 100f, size.height - 50f))
                    drawCircle(BurntRed.copy(alpha = 0.15f), radius = 180f, center = Offset(size.width - 50f, size.height - 20f))
                }

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "STEAK DONE RIGHT.",
                        style = MaterialTheme.typography.displayLarge.copy(
                            color = WarmCream,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 32.sp
                        )
                    )
                    Text(
                        text = "Fire-grilled cuts. Signature sides. Your table is waiting.",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = AgedBrass,
                            lineHeight = 18.sp
                        )
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onNavigateToMenu,
                            colors = ButtonDefaults.buttonColors(containerColor = BurntRed),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("order_to_go_home_button")
                        ) {
                            Text("ORDER TO GO", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = onNavigateToWaitlist,
                            colors = ButtonDefaults.buttonColors(containerColor = CastIron),
                            border = BorderStroke(1.dp, AgedBrass),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("join_waitlist_home_button")
                        ) {
                            Text("JOIN LIST", color = WarmCream, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Restaurant Selector (Call Ahead Waiting & Services)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CastIron),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "NEARBY STEAKHOUSE",
                                style = MaterialTheme.typography.labelSmall.copy(color = AgedBrass, letterSpacing = 1.sp)
                            )
                            Text(
                                text = selectedRes?.name ?: "Find Restaurant",
                                style = MaterialTheme.typography.titleLarge.copy(color = WarmCream)
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.Place,
                            contentDescription = "Location icon",
                            tint = FlameOrange,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    selectedRes?.let { res ->
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = res.address, style = MaterialTheme.typography.bodySmall, color = WarmGrey)
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Schedule, "Time", tint = AgedBrass, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Open until ${res.closeTime}", style = MaterialTheme.typography.bodySmall, color = WarmCream)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.PeopleOutline, "Wait", tint = AgedBrass, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (res.currentWaitMin > 0) "${res.currentWaitMin} mins wait" else "No waitlist",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (res.currentWaitMin > 30) BurntRed else SageGreen
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Quick switcher for restaurant demo purposes
                    var expanded by remember { mutableStateOf(false) }
                    Box {
                        OutlinedButton(
                            onClick = { expanded = true },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = AgedBrass),
                            border = BorderStroke(1.dp, AgedBrass),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("CHANGE LOCATION")
                        }
                        DropdownMenu(
                            expanded = expanded,
                            onDismissRequest = { expanded = false },
                            modifier = Modifier.background(CastIron)
                        ) {
                            restaurants.forEach { r ->
                                DropdownMenuItem(
                                    text = { Text("${r.name} (${r.distance} mi) - Wait: ${r.currentWaitMin}m", color = WarmCream) },
                                    onClick = {
                                        viewModel.selectedRestaurant.value = r
                                        expanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        // Quick Reorder: Order Your Usual (Section 17)
        val lastOrder = orders.firstOrNull { it.customerPhone == viewModel.customerPhone.value }
        if (lastOrder != null) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "ORDER YOUR USUAL",
                        style = MaterialTheme.typography.titleMedium,
                        color = WarmCream
                    )
                    Card(
                        colors = CardDefaults.cardColors(containerColor = CastIron),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = lastOrder.itemsSummary,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = WarmCream,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "From: ${lastOrder.restaurantName} • Total: $${String.format("%.2f", lastOrder.totalAmount)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = WarmGrey
                                )
                            }
                            Button(
                                onClick = {
                                    // Simulated quick reorder placement logic:
                                    // Add to order and auto checkout!
                                    viewModel.submitOrder(
                                        orderType = lastOrder.orderType,
                                        pickupTime = "ASAP",
                                        vehicleDesc = lastOrder.vehicleDescription,
                                        vehicleColor = lastOrder.vehicleColor,
                                        licensePlate = lastOrder.licensePlate,
                                        parkingSpace = lastOrder.parkingSpace,
                                        appliedOffer = null
                                    )
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = BurntRed),
                                modifier = Modifier.testTag("reorder_button")
                            ) {
                                Text("REORDER")
                            }
                        }
                    }
                }
            }
        }

        // Favourite Steaks (Section 18)
        if (favourites.isNotEmpty()) {
            item {
                Text(
                    text = "MY FAVOURITE CUTS",
                    style = MaterialTheme.typography.titleMedium,
                    color = WarmCream
                )
            }
            items(favourites) { fav ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            // Find corresponding menu item and open details!
                            val item = viewModel.menuItems.value.firstOrNull { it.id == fav.menuItemId }
                            if (item != null) {
                                viewModel.selectedMenuItem.value = item
                            }
                        },
                    colors = CardDefaults.cardColors(containerColor = CastIron)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Star, "Fav", tint = AgedBrass, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(text = fav.itemName, style = MaterialTheme.typography.titleMedium, color = WarmCream, fontWeight = FontWeight.Bold)
                            }
                            Text(text = fav.itemCategory, style = MaterialTheme.typography.bodySmall, color = WarmGrey)
                        }
                        Text(text = "$${fav.price}", style = MaterialTheme.typography.titleMedium, color = AgedBrass, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
fun CustomerMenuScreen(viewModel: MainViewModel) {
    val items by viewModel.menuItems.collectAsStateWithLifecycle()
    val favourites by viewModel.favourites.collectAsStateWithLifecycle()
    val selectedCategory = remember { mutableStateOf("STEAKS") }

    val categories = listOf("STEAKS", "SIDES", "DESSERTS", "BEVERAGES")

    Column(modifier = Modifier.fillMaxSize()) {
        // Category Scroll Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            categories.forEach { cat ->
                val selected = selectedCategory.value == cat
                FilterChip(
                    selected = selected,
                    onClick = { selectedCategory.value = cat },
                    label = { Text(cat, fontWeight = FontWeight.Bold) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = BurntRed,
                        selectedLabelColor = Color.White,
                        containerColor = CastIron,
                        labelColor = WarmGrey
                    )
                )
            }
        }

        // Menu Items List
        val filtered = items.filter { it.category == selectedCategory.value }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (filtered.isEmpty()) {
                item {
                    Text(
                        "No items available in this category.",
                        color = WarmGrey,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 40.dp)
                    )
                }
            } else {
                items(filtered) { item ->
                    val isFav = favourites.any { it.menuItemId == item.id }

                    Card(
                        colors = CardDefaults.cardColors(containerColor = CastIron),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                if (item.isAvailable) {
                                    viewModel.selectedMenuItem.value = item
                                }
                            }
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Top
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = item.name,
                                            style = MaterialTheme.typography.titleLarge.copy(color = WarmCream)
                                        )
                                        if (item.isFeatured) {
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Surface(
                                                color = FlameOrange.copy(alpha = 0.2f),
                                                contentColor = FlameOrange,
                                                shape = RoundedCornerShape(4.dp)
                                            ) {
                                                Text(
                                                    "FEATURED",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = item.description,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = WarmGrey
                                    )
                                }

                                IconButton(
                                    onClick = { viewModel.toggleFavourite(item) }
                                ) {
                                    Icon(
                                        imageVector = if (isFav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                        contentDescription = "Fav",
                                        tint = if (isFav) BurntRed else WarmGrey
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    if (item.weightOz > 0) {
                                        Text(
                                            text = "${item.weightOz} oz cut",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = AgedBrass
                                        )
                                    }
                                    Text(
                                        text = "${item.calories} Calories",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = WarmGrey
                                    )
                                }

                                if (!item.isAvailable) {
                                    Text(
                                        text = "OUT OF STOCK",
                                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                        color = BurntRed
                                    )
                                } else {
                                    Text(
                                        text = "$${item.price}",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            color = AgedBrass,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// Steak Customization Screen (Sections 9, 10: Steak Customization & Detail Page)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SteakDetailScreen(
    menuItem: MenuItem,
    viewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    val donenessOptions = listOf("RARE", "MEDIUM_RARE", "MEDIUM", "MEDIUM_WELL", "WELL_DONE")
    val side1Options = listOf("Loaded Idaho Baked Potato", "Steakhouse Mac & Cheese", "Fresh Steamed Asparagus", "Mashed Potatoes", "French Fries")
    val side2Options = listOf("None", "Loaded Idaho Baked Potato", "Steakhouse Mac & Cheese", "Fresh Steamed Asparagus", "Mashed Potatoes", "French Fries")
    val addOnOptions = listOf("None", "Redrock Grilled Shrimp Skewer ($5.99)", "Parmesan Cheese Crust ($2.49)", "Sautéed Mushrooms ($1.99)")

    var selectedDoneness by remember { mutableStateOf(menuItem.recommendedDoneness) }
    var selectedSide1 by remember { mutableStateOf(side1Options[0]) }
    var selectedSide2 by remember { mutableStateOf(side2Options[0]) }
    var selectedAddOn by remember { mutableStateOf(addOnOptions[0]) }
    var quantity by remember { mutableStateOf(1) }
    var specialInstructions by remember { mutableStateOf("") }

    val computedPrice = remember(quantity, selectedAddOn) {
        val addOnCost = when (selectedAddOn) {
            addOnOptions[1] -> 5.99
            addOnOptions[2] -> 2.49
            addOnOptions[3] -> 1.99
            else -> 0.0
        }
        (menuItem.price + addOnCost) * quantity
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.85f))
            .clickable { onDismiss() } // dismiss on background click
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.92f)
                .align(Alignment.BottomCenter)
                .clickable(enabled = false) {}, // prevent click-through
            colors = CardDefaults.cardColors(containerColor = CastIron),
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(24.dp)
            ) {
                // Top Header Dismiss drag bar
                Box(
                    modifier = Modifier
                        .width(40.dp)
                        .height(4.dp)
                        .clip(RoundedCornerShape(50))
                        .background(WarmGrey)
                        .align(Alignment.CenterHorizontally)
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = menuItem.name.uppercase(),
                        style = MaterialTheme.typography.displayMedium,
                        color = WarmCream
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, "Close", tint = WarmCream)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = menuItem.description,
                    style = MaterialTheme.typography.bodyLarge,
                    color = WarmGrey
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Cut details
                if (menuItem.category == "STEAKS") {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = DarkWood),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("Cut Style", style = MaterialTheme.typography.bodySmall, color = WarmGrey)
                                Text(menuItem.cutType, style = MaterialTheme.typography.titleMedium, color = AgedBrass)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("Weight", style = MaterialTheme.typography.bodySmall, color = WarmGrey)
                                Text("${menuItem.weightOz} oz", style = MaterialTheme.typography.titleMedium, color = AgedBrass)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("Seasoning", style = MaterialTheme.typography.bodySmall, color = WarmGrey)
                                Text(menuItem.signatureSeasoning, style = MaterialTheme.typography.titleMedium, color = AgedBrass)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Doneness Selector (Section 9)
                    Text("CHOOSE YOUR DONENESS", style = MaterialTheme.typography.titleMedium, color = AgedBrass)
                    Spacer(modifier = Modifier.height(8.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        donenessOptions.forEach { opt ->
                            val active = selectedDoneness == opt
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (active) BurntRed else Color.Black.copy(alpha = 0.3f))
                                    .clickable { selectedDoneness = opt }
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = opt.replace("_", " "),
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                    color = if (active) Color.White else WarmGrey
                                )
                                RadioButton(
                                    selected = active,
                                    onClick = { selectedDoneness = opt },
                                    colors = RadioButtonDefaults.colors(
                                        selectedColor = Color.White,
                                        unselectedColor = WarmGrey
                                    )
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))
                }

                // Side Option 1 Selection
                Text("CHOOSE FIRST SIGNATURE SIDE", style = MaterialTheme.typography.titleMedium, color = AgedBrass)
                Spacer(modifier = Modifier.height(8.dp))
                var side1Expanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(
                    expanded = side1Expanded,
                    onExpandedChange = { side1Expanded = !side1Expanded }
                ) {
                    OutlinedTextField(
                        value = selectedSide1,
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = side1Expanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = CastIron,
                            unfocusedContainerColor = CastIron,
                            focusedTextColor = WarmCream,
                            unfocusedTextColor = WarmCream
                        )
                    )
                    ExposedDropdownMenu(
                        expanded = side1Expanded,
                        onDismissRequest = { side1Expanded = false },
                        modifier = Modifier.background(CastIron)
                    ) {
                        side1Options.forEach { side ->
                            DropdownMenuItem(
                                text = { Text(side, color = WarmCream) },
                                onClick = {
                                    selectedSide1 = side
                                    side1Expanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Side Option 2 Selection
                Text("CHOOSE SECOND SIDE", style = MaterialTheme.typography.titleMedium, color = AgedBrass)
                Spacer(modifier = Modifier.height(8.dp))
                var side2Expanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(
                    expanded = side2Expanded,
                    onExpandedChange = { side2Expanded = !side2Expanded }
                ) {
                    OutlinedTextField(
                        value = selectedSide2,
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = side2Expanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = CastIron,
                            unfocusedContainerColor = CastIron,
                            focusedTextColor = WarmCream,
                            unfocusedTextColor = WarmCream
                        )
                    )
                    ExposedDropdownMenu(
                        expanded = side2Expanded,
                        onDismissRequest = { side2Expanded = false },
                        modifier = Modifier.background(CastIron)
                    ) {
                        side2Options.forEach { side ->
                            DropdownMenuItem(
                                text = { Text(side, color = WarmCream) },
                                onClick = {
                                    selectedSide2 = side
                                    side2Expanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Add Ons Selection
                Text("ADD STEAKHOUSE ENHANCEMENT", style = MaterialTheme.typography.titleMedium, color = AgedBrass)
                Spacer(modifier = Modifier.height(8.dp))
                var addOnExpanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(
                    expanded = addOnExpanded,
                    onExpandedChange = { addOnExpanded = !addOnExpanded }
                ) {
                    OutlinedTextField(
                        value = selectedAddOn,
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = addOnExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = CastIron,
                            unfocusedContainerColor = CastIron,
                            focusedTextColor = WarmCream,
                            unfocusedTextColor = WarmCream
                        )
                    )
                    ExposedDropdownMenu(
                        expanded = addOnExpanded,
                        onDismissRequest = { addOnExpanded = false },
                        modifier = Modifier.background(CastIron)
                    ) {
                        addOnOptions.forEach { addOn ->
                            DropdownMenuItem(
                                text = { Text(addOn, color = WarmCream) },
                                onClick = {
                                    selectedAddOn = addOn
                                    addOnExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Special Instructions text input
                Text("SPECIAL INSTRUCTIONS", style = MaterialTheme.typography.titleMedium, color = AgedBrass)
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = specialInstructions,
                    onValueChange = { specialInstructions = it },
                    placeholder = { Text("How can the grillmaster make it perfect?") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = WarmCream,
                        unfocusedTextColor = WarmCream,
                        focusedBorderColor = AgedBrass,
                        unfocusedBorderColor = WarmGrey
                    )
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Quantity & Add to Cart Action
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        IconButton(
                            onClick = { if (quantity > 1) quantity-- },
                            modifier = Modifier
                                .background(CastIron, RoundedCornerShape(50))
                                .size(36.dp)
                        ) {
                            Icon(Icons.Default.Remove, "-", tint = WarmCream)
                        }
                        Text(quantity.toString(), color = WarmCream, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        IconButton(
                            onClick = { quantity++ },
                            modifier = Modifier
                                .background(CastIron, RoundedCornerShape(50))
                                .size(36.dp)
                        ) {
                            Icon(Icons.Default.Add, "+", tint = WarmCream)
                        }
                    }

                    Button(
                        onClick = {
                            viewModel.addToCart(
                                menuItem = menuItem,
                                quantity = quantity,
                                doneness = selectedDoneness,
                                side1 = selectedSide1,
                                side2 = selectedSide2,
                                specialInstructions = "$specialInstructions [AddOn: $selectedAddOn]"
                            )
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BurntRed),
                        modifier = Modifier
                            .height(48.dp)
                            .testTag("add_to_order_button")
                    ) {
                        Text("ADD TO ORDER • $${String.format("%.2f", computedPrice)}", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun CartScreen(viewModel: MainViewModel) {
    val items by viewModel.cartItems.collectAsStateWithLifecycle()
    val offers by viewModel.offers.collectAsStateWithLifecycle()
    val trackingId by viewModel.trackingOrderId.collectAsStateWithLifecycle()
    val orders by viewModel.orders.collectAsStateWithLifecycle()

    // Checkout configurations
    var orderType by remember { mutableStateOf(OrderType.TOGO) }
    var selectedOffer by remember { mutableStateOf<Offer?>(null) }
    var pickupTime by remember { mutableStateOf("15 Mins") }
    var parkingSpace by remember { mutableStateOf("") }
    var vehicleDesc by remember { mutableStateOf("") }
    var vehicleColor by remember { mutableStateOf("") }
    var licensePlate by remember { mutableStateOf("") }
    var giftCardNumber by remember { mutableStateOf("") }

    if (trackingId != null) {
        // Active Order Tracking screen view! (Section 16: Order Tracking)
        val activeOrder = orders.firstOrNull { it.id == trackingId }
        if (activeOrder != null) {
            OrderTrackingScreen(activeOrder = activeOrder, viewModel = viewModel)
        } else {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Retrieving order tracker...", color = WarmCream)
            }
        }
        return
    }

    if (items.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(Icons.Default.LocalMall, "Empty cart", tint = WarmGrey, modifier = Modifier.size(64.dp))
                Text("YOUR SIZZLING CART IS EMPTY.", style = MaterialTheme.typography.titleMedium, color = WarmCream)
                Text("Browse the Menu to discover perfectly grilled cuts.", style = MaterialTheme.typography.bodySmall, color = WarmGrey)
            }
        }
        return
    }

    val totalBeforeDiscount = items.sumOf { it.totalPrice }
    val discount = if (selectedOffer != null) totalBeforeDiscount * (selectedOffer!!.discountPercent / 100.0) else 0.0
    val finalTotal = totalBeforeDiscount - discount

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("REVIEW YOUR ORDER", style = MaterialTheme.typography.displaySmall, color = WarmCream)
        }

        items(items) { item ->
            Card(
                colors = CardDefaults.cardColors(containerColor = CastIron),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "${item.quantity}x ${item.itemName}", style = MaterialTheme.typography.titleMedium, color = WarmCream)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "Prep: ${item.doneness} • Sides: ${item.side1Name}, ${item.side2Name}", style = MaterialTheme.typography.bodySmall, color = WarmGrey)
                        if (item.specialInstructions.isNotEmpty()) {
                            Text(text = "Note: ${item.specialInstructions}", style = MaterialTheme.typography.bodySmall, color = AgedBrass)
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(text = "$${String.format("%.2f", item.totalPrice)}", style = MaterialTheme.typography.titleMedium, color = AgedBrass, fontWeight = FontWeight.Bold)
                        IconButton(onClick = { viewModel.deleteCartItem(item) }) {
                            Icon(Icons.Default.DeleteOutline, "Remove", tint = BurntRed)
                        }
                    }
                }
            }
        }

        // Checkout configurations
        item {
            Text("PICKUP METHOD", style = MaterialTheme.typography.titleMedium, color = AgedBrass)
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { orderType = OrderType.TOGO },
                    colors = ButtonDefaults.buttonColors(containerColor = if (orderType == OrderType.TOGO) BurntRed else CastIron),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("STANDARD PICKUP")
                }
                Button(
                    onClick = { orderType = OrderType.CURBSIDE },
                    colors = ButtonDefaults.buttonColors(containerColor = if (orderType == OrderType.CURBSIDE) BurntRed else CastIron),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("CURBSIDE PICKUP")
                }
            }
        }

        if (orderType == OrderType.CURBSIDE) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkWood),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("CURBSIDE VEHICLE DETAILS", style = MaterialTheme.typography.titleSmall, color = AgedBrass)
                        OutlinedTextField(
                            value = vehicleDesc,
                            onValueChange = { vehicleDesc = it },
                            label = { Text("Vehicle Make & Model (e.g. Ford F-150)") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = WarmCream, unfocusedTextColor = WarmCream)
                        )
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = vehicleColor,
                                onValueChange = { vehicleColor = it },
                                label = { Text("Vehicle Color") },
                                modifier = Modifier.weight(1f),
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = WarmCream, unfocusedTextColor = WarmCream)
                            )
                            OutlinedTextField(
                                value = parkingSpace,
                                onValueChange = { parkingSpace = it },
                                label = { Text("Parking Space #") },
                                modifier = Modifier.weight(1f),
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = WarmCream, unfocusedTextColor = WarmCream)
                            )
                        }
                    }
                }
            }
        }

        // Apply Offer
        item {
            Text("PROMOTIONS & OFFERS", style = MaterialTheme.typography.titleMedium, color = AgedBrass)
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                var expanded by remember { mutableStateOf(false) }
                Box(modifier = Modifier.weight(1f)) {
                    OutlinedButton(
                        onClick = { expanded = true },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = WarmCream),
                        border = BorderStroke(1.dp, AgedBrass),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(selectedOffer?.title ?: "Select Coupon / Offer")
                    }
                    DropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false },
                        modifier = Modifier.background(CastIron)
                    ) {
                        DropdownMenuItem(
                            text = { Text("None", color = WarmCream) },
                            onClick = {
                                selectedOffer = null
                                expanded = false
                            }
                        )
                        offers.filter { it.status == OfferStatus.AVAILABLE || it.status == OfferStatus.CLAIMED }.forEach { offer ->
                            DropdownMenuItem(
                                text = { Text("${offer.title} (${offer.discountPercent}% off)", color = WarmCream) },
                                onClick = {
                                    selectedOffer = offer
                                    expanded = false
                                }
                            )
                        }
                    }
                }
            }
        }

        // Gift Card Payment option
        item {
            Text("PAY WITH GIFT CARD", style = MaterialTheme.typography.titleMedium, color = AgedBrass)
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = giftCardNumber,
                onValueChange = { giftCardNumber = it },
                placeholder = { Text("Enter GC Number (e.g. 7777-8888-9999-1111)") },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = WarmCream, unfocusedTextColor = WarmCream)
            )
        }

        // Order Total Calculations (Section 9 Invariant: Never hardcode final order price in frontend)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CastIron),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Subtotal", color = WarmGrey)
                        Text("$${String.format("%.2f", totalBeforeDiscount)}", color = WarmCream)
                    }
                    if (discount > 0) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Discount (${selectedOffer?.promoCode})", color = BurntRed)
                            Text("-$${String.format("%.2f", discount)}", color = BurntRed)
                        }
                    }
                    Divider(color = WarmGrey.copy(alpha = 0.3f))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("TOTAL AMOUNT", style = MaterialTheme.typography.titleMedium, color = WarmCream)
                        Text("$${String.format("%.2f", finalTotal)}", style = MaterialTheme.typography.titleLarge, color = AgedBrass, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Submit Button
        item {
            Button(
                onClick = {
                    viewModel.submitOrder(
                        orderType = orderType,
                        pickupTime = pickupTime,
                        vehicleDesc = vehicleDesc,
                        vehicleColor = vehicleColor,
                        licensePlate = licensePlate,
                        parkingSpace = parkingSpace,
                        appliedOffer = selectedOffer,
                        giftCardPaymentNumber = giftCardNumber
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = BurntRed),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("submit_order_button")
            ) {
                Text("PLACE TO GO ORDER", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
fun OrderTrackingScreen(activeOrder: Order, viewModel: MainViewModel) {
    val stages = listOf(
        OrderStatus.ORDERED to "ORDER PLACED",
        OrderStatus.PREPARING to "GRILLING",
        OrderStatus.READY to "READY FOR PICKUP",
        OrderStatus.ARRIVED to "CUSTOMER ARRIVED",
        OrderStatus.STAFF_NOTIFIED to "STAFF DISPATCHED",
        OrderStatus.COMPLETE to "COMPLETE"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "TRACK YOUR STEAK",
            style = MaterialTheme.typography.displayMedium,
            color = WarmCream
        )

        Card(
            colors = CardDefaults.cardColors(containerColor = CastIron),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("ORDER ID: ${activeOrder.orderNumber}", style = MaterialTheme.typography.titleMedium, color = AgedBrass)
                Text("Steakhouse: ${activeOrder.restaurantName}", style = MaterialTheme.typography.bodyMedium, color = WarmCream)
                Text("Items: ${activeOrder.itemsSummary}", style = MaterialTheme.typography.bodySmall, color = WarmGrey)
                Text("Payment: ${activeOrder.paymentDetails}", style = MaterialTheme.typography.bodySmall, color = WarmGrey)
            }
        }

        // Timeline Progress Indicators
        Column(modifier = Modifier.fillMaxWidth()) {
            stages.forEachIndexed { index, (stage, title) ->
                val activeOrCompleted = activeOrder.orderStatus.ordinal >= stage.ordinal
                val current = activeOrder.orderStatus == stage

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(RoundedCornerShape(50))
                            .background(
                                when {
                                    current -> FlameOrange
                                    activeOrCompleted -> BurntRed
                                    else -> WarmGrey
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (activeOrCompleted && !current) {
                            Icon(Icons.Default.Check, "Done", tint = Color.White, modifier = Modifier.size(14.dp))
                        }
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Text(
                        text = title,
                        style = MaterialTheme.typography.bodyLarge.copy(
                            fontWeight = if (current) FontWeight.Bold else FontWeight.Normal
                        ),
                        color = if (activeOrCompleted) WarmCream else WarmGrey
                    )
                }

                if (index < stages.lastIndex) {
                    val nextStage = stages[index + 1].first
                    val lineCompleted = activeOrder.orderStatus.ordinal >= nextStage.ordinal
                    Box(
                        modifier = Modifier
                            .padding(start = 11.dp)
                            .width(2.dp)
                            .height(24.dp)
                            .background(if (lineCompleted) BurntRed else WarmGrey)
                    )
                }
            }
        }

        // Curbside interaction: I'm Here! (Section 15)
        if (activeOrder.orderType == OrderType.CURBSIDE && activeOrder.orderStatus == OrderStatus.READY) {
            Button(
                onClick = {
                    viewModel.updateOrderStatusHq(activeOrder.id, OrderStatus.ARRIVED)
                },
                colors = ButtonDefaults.buttonColors(containerColor = FlameOrange),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("curbside_im_here_button")
            ) {
                Text("I'M HERE - NOTIFY KITCHEN", fontWeight = FontWeight.Bold, color = Color.White)
            }
        }

        // Completion status
        if (activeOrder.orderStatus == OrderStatus.COMPLETE) {
            Surface(
                color = SageGreen.copy(alpha = 0.2f),
                contentColor = SageGreen,
                shape = RoundedCornerShape(8.dp)
            ) {
                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CheckCircle, "Done", modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Text("Order is picked up. Enjoy your fire-grilled feast!", fontWeight = FontWeight.Bold)
                }
            }
        }

        Button(
            onClick = { viewModel.trackingOrderId.value = null },
            colors = ButtonDefaults.buttonColors(containerColor = CastIron),
            border = BorderStroke(1.dp, AgedBrass)
        ) {
            Text("BACK TO HOME", color = WarmCream)
        }
    }
}

@Composable
fun WaitlistScreen(viewModel: MainViewModel) {
    val waitlistId by viewModel.trackingWaitlistId.collectAsStateWithLifecycle()
    val allEntries by viewModel.waitlistEntries.collectAsStateWithLifecycle()
    val selectedRes by viewModel.selectedRestaurant.collectAsStateWithLifecycle()

    var partySize by remember { mutableStateOf(4) }

    val activeEntry = allEntries.firstOrNull { it.id == waitlistId }

    if (activeEntry != null) {
        // Waitlist entry details view (Section 13)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Default.FormatListNumbered, "List icon", tint = AgedBrass, modifier = Modifier.size(64.dp))

            Text("YOU'RE ON THE LIST!", style = MaterialTheme.typography.displayMedium, color = WarmCream)

            Card(
                colors = CardDefaults.cardColors(containerColor = CastIron),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(text = activeEntry.restaurantName.uppercase(), style = MaterialTheme.typography.titleMedium, color = AgedBrass)
                    Text(text = "Party of ${activeEntry.partySize}", style = MaterialTheme.typography.bodyLarge, color = WarmCream)
                    Text(text = "ESTIMATED WAIT TIME", style = MaterialTheme.typography.bodySmall, color = WarmGrey)
                    Text(
                        text = if (activeEntry.estWaitMin > 0) "${activeEntry.estWaitMin} MIN" else "READY TO BE SEATED",
                        style = MaterialTheme.typography.displayLarge,
                        color = FlameOrange,
                        fontWeight = FontWeight.Bold
                    )
                    Text(text = "Status: ${activeEntry.status.name}", style = MaterialTheme.typography.bodyMedium, color = WarmCream)
                }
            }

            if (activeEntry.status == WaitlistStatus.READY) {
                Button(
                    onClick = { viewModel.checkInWaitlist() },
                    colors = ButtonDefaults.buttonColors(containerColor = SageGreen),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("CHECK IN AT ENTRANCE", color = Color.White)
                }
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(
                    onClick = { viewModel.leaveWaitlist() },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = BurntRed),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("LEAVE WAITLIST")
                }
                Button(
                    onClick = { /* simulated refresh */ },
                    colors = ButtonDefaults.buttonColors(containerColor = CastIron),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("REFRESH", color = WarmCream)
                }
            }
        }
        return
    }

    // Join waitlist form (Section 13)
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Text("JOIN THE WAITLIST", style = MaterialTheme.typography.displaySmall, color = WarmCream)
        Text("No reservations. Join our live call-ahead queue to secure your table.", style = MaterialTheme.typography.bodyLarge, color = WarmGrey)

        selectedRes?.let { res ->
            Card(
                colors = CardDefaults.cardColors(containerColor = CastIron),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(res.name.uppercase(), style = MaterialTheme.typography.titleMedium, color = AgedBrass)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Current Wait: ${res.currentWaitMin} mins", style = MaterialTheme.typography.bodySmall, color = WarmCream)
                }
            }
        }

        Text("SELECT PARTY SIZE", style = MaterialTheme.typography.titleMedium, color = AgedBrass)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { if (partySize > 1) partySize-- },
                modifier = Modifier.background(CastIron, RoundedCornerShape(50))
            ) {
                Icon(Icons.Default.Remove, "-", tint = WarmCream)
            }
            Text("$partySize Guests", style = MaterialTheme.typography.displayMedium, color = WarmCream)
            IconButton(
                onClick = { partySize++ },
                modifier = Modifier.background(CastIron, RoundedCornerShape(50))
            ) {
                Icon(Icons.Default.Add, "+", tint = WarmCream)
            }
        }

        // Confirmed details
        OutlinedTextField(
            value = viewModel.customerName.value,
            onValueChange = { viewModel.customerName.value = it },
            label = { Text("Your Name") },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = WarmCream, unfocusedTextColor = WarmCream)
        )

        OutlinedTextField(
            value = viewModel.customerPhone.value,
            onValueChange = { viewModel.customerPhone.value = it },
            label = { Text("Mobile Phone Number") },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = WarmCream, unfocusedTextColor = WarmCream)
        )

        Button(
            onClick = { viewModel.joinWaitlist(partySize) },
            colors = ButtonDefaults.buttonColors(containerColor = BurntRed),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .testTag("submit_waitlist_button")
        ) {
            Text("JOIN THE LIST NOW", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}

@Composable
fun ProfileScreen(viewModel: MainViewModel) {
    val eClubSignedUp by viewModel.eClubSignedUp.collectAsStateWithLifecycle()
    val giftCards by viewModel.giftCards.collectAsStateWithLifecycle()

    var gcNumberCheck by remember { mutableStateOf("") }
    var gcQueryResult by remember { mutableStateOf<GiftCard?>(null) }
    var gcCheckAttempted by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // eClub Sign Up (Section 19)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CastIron),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("JOIN THE LONGHORN eCLUB", style = MaterialTheme.typography.titleLarge, color = AgedBrass)
                    if (!eClubSignedUp) {
                        Text("Get fresh offers, seasonal secrets, and a free appetizer welcoming you on your next visit.", style = MaterialTheme.typography.bodySmall, color = WarmGrey)
                        Button(
                            onClick = { viewModel.subscribeEClub() },
                            colors = ButtonDefaults.buttonColors(containerColor = BurntRed),
                            modifier = Modifier.testTag("eclub_signup_button")
                        ) {
                            Text("SIGN UP NOW")
                        }
                    } else {
                        Surface(
                            color = SageGreen.copy(alpha = 0.2f),
                            contentColor = SageGreen,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Verified, "Verified")
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("You're a member! Welcome coupon applied.", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Gift Cards Manager (Section 20)
        item {
            Text("GIFT CARDS", style = MaterialTheme.typography.titleMedium, color = AgedBrass)
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CastIron),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("CHECK GIFT CARD BALANCE", style = MaterialTheme.typography.titleSmall, color = WarmCream)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = gcNumberCheck,
                            onValueChange = { gcNumberCheck = it },
                            placeholder = { Text("7777-8888-...") },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = WarmCream, unfocusedTextColor = WarmCream)
                        )
                        Button(
                            onClick = {
                                viewModel.checkGiftCard(gcNumberCheck) { card ->
                                    gcQueryResult = card
                                    gcCheckAttempted = true
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CastIron),
                            border = BorderStroke(1.dp, AgedBrass)
                        ) {
                            Text("CHECK")
                        }
                    }

                    if (gcCheckAttempted) {
                        gcQueryResult?.let { card ->
                            Text("Balance: $${String.format("%.2f", card.balance)} / $${card.originalBalance}", color = SageGreen, fontWeight = FontWeight.Bold)
                        } ?: Text("Gift card number not found.", color = BurntRed)
                    }
                }
            }
        }

        // Purchase new Gift Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CastIron),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("BUY DIGITAL GIFT CARD", style = MaterialTheme.typography.titleSmall, color = WarmCream)
                    var gcValue by remember { mutableStateOf(50.0) }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                        listOf(25.0, 50.0, 100.0).forEach { amt ->
                            ElevatedFilterChip(
                                selected = gcValue == amt,
                                onClick = { gcValue = amt },
                                label = { Text("$$amt") },
                                colors = FilterChipDefaults.elevatedFilterChipColors(
                                    selectedContainerColor = BurntRed,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    Button(
                        onClick = {
                            val rNum = "GC-${(100000..999999).random()}"
                            viewModel.purchaseGiftCard(rNum, gcValue)
                            gcNumberCheck = rNum
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BurntRed),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("PURCHASE FOR $$gcValue")
                    }
                }
            }
        }
    }
}


// ==========================================
// --- RESTAURANT OPERATING SYSTEM HQ ---
// ==========================================

@Composable
fun HqDashboardScreen(viewModel: MainViewModel) {
    val orders by viewModel.orders.collectAsStateWithLifecycle()
    val waitlist by viewModel.waitlistEntries.collectAsStateWithLifecycle()
    val inventory by viewModel.inventory.collectAsStateWithLifecycle()

    val activeToGo = orders.filter { it.orderStatus != OrderStatus.COMPLETE && it.orderStatus != OrderStatus.EXCEPTION }
    val activeGrilling = orders.filter { it.orderStatus == OrderStatus.PREPARING }
    val lowStock = inventory.filter { it.status == InventoryStatus.LIMITED || it.status == InventoryStatus.UNAVAILABLE }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("HQ METRICS BOARD", style = MaterialTheme.typography.displaySmall, color = WarmCream)
                Surface(
                    color = SageGreen.copy(alpha = 0.2f),
                    contentColor = SageGreen,
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text("LIVE FEED", modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp), fontWeight = FontWeight.Bold, fontSize = 10.sp)
                }
            }
        }

        // Live grid statistics
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Card(colors = CardDefaults.cardColors(containerColor = CastIron), modifier = Modifier.weight(1f)) {
                    Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("ACTIVE ORDERS", style = MaterialTheme.typography.bodySmall, color = WarmGrey)
                        Text("${activeToGo.size}", style = MaterialTheme.typography.displayMedium, color = AgedBrass, fontWeight = FontWeight.Bold)
                    }
                }
                Card(colors = CardDefaults.cardColors(containerColor = CastIron), modifier = Modifier.weight(1f)) {
                    Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("ON GRILLS", style = MaterialTheme.typography.bodySmall, color = WarmGrey)
                        Text("${activeGrilling.size}", style = MaterialTheme.typography.displayMedium, color = FlameOrange, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Card(colors = CardDefaults.cardColors(containerColor = CastIron), modifier = Modifier.weight(1f)) {
                    Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("WAITLIST SIZE", style = MaterialTheme.typography.bodySmall, color = WarmGrey)
                        Text("${waitlist.filter { it.status != WaitlistStatus.SEATED && it.status != WaitlistStatus.CANCELLED }.size}", style = MaterialTheme.typography.displayMedium, color = WarmCream, fontWeight = FontWeight.Bold)
                    }
                }
                Card(colors = CardDefaults.cardColors(containerColor = CastIron), modifier = Modifier.weight(1f)) {
                    Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("LOW STOCK CUTS", style = MaterialTheme.typography.bodySmall, color = WarmGrey)
                        Text("${lowStock.size}", style = MaterialTheme.typography.displayMedium, color = BurntRed, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Simulated action trigger
        item {
            Button(
                onClick = { viewModel.triggerSimulatedGrillLoad() },
                colors = ButtonDefaults.buttonColors(containerColor = CastIron),
                border = BorderStroke(1.dp, AgedBrass),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.LocalFireDepartment, "Fire")
                Spacer(modifier = Modifier.width(8.dp))
                Text("TRIGGER SIMULATED GRILL DIAGNOSTICS", color = WarmCream)
            }
        }
    }
}

@Composable
fun HqOrdersScreen(viewModel: MainViewModel) {
    val orders by viewModel.orders.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("ORDER OPERATIONS KANBAN", style = MaterialTheme.typography.displaySmall, color = WarmCream)
        }

        if (orders.isEmpty()) {
            item {
                Text("No orders placed yet.", color = WarmGrey, modifier = Modifier.padding(24.dp))
            }
        } else {
            items(orders) { order ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = CastIron),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Ticket: ${order.orderNumber}", style = MaterialTheme.typography.titleMedium, color = AgedBrass)
                            Text(
                                text = order.orderStatus.name,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (order.orderStatus == OrderStatus.COMPLETE) SageGreen else FlameOrange
                            )
                        }

                        Text("Customer: ${order.customerName} (${order.customerPhone})", color = WarmCream, style = MaterialTheme.typography.bodyMedium)
                        Text("Items: ${order.itemsSummary}", color = WarmGrey, style = MaterialTheme.typography.bodySmall)

                        if (order.vehicleDescription.isNotEmpty()) {
                            Text("Curbside: Space #${order.parkingSpace} • ${order.vehicleColor} ${order.vehicleDescription}", color = AgedBrass, style = MaterialTheme.typography.bodySmall)
                        }

                        // Status transitions
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val next = when (order.orderStatus) {
                                OrderStatus.ORDERED -> OrderStatus.PREPARING to "ACCEPT & START GRILL"
                                OrderStatus.PREPARING -> OrderStatus.READY to "MARK READY"
                                OrderStatus.READY, OrderStatus.ARRIVED -> OrderStatus.COMPLETE to "HAND OVER TO CUSTOMER"
                                else -> null
                            }

                            next?.let { (nextStatus, label) ->
                                Button(
                                    onClick = { viewModel.updateOrderStatusHq(order.id, nextStatus) },
                                    colors = ButtonDefaults.buttonColors(containerColor = if (nextStatus == OrderStatus.COMPLETE) SageGreen else BurntRed)
                                ) {
                                    Text(label, color = Color.White)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HqKitchenKdsScreen(viewModel: MainViewModel) {
    val orders by viewModel.orders.collectAsStateWithLifecycle()
    val preparingTickets = orders.filter { it.orderStatus == OrderStatus.PREPARING || it.orderStatus == OrderStatus.ORDERED }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("KITCHEN DISPLAY BOARD (KDS)", style = MaterialTheme.typography.displaySmall, color = WarmCream)

        // Simulated Grill Status Indicators (Section 26)
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth(),
            border = BorderStroke(1.dp, FlameOrange)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("ACTIVE GRILL SLOTS (SIMULATED LOAD)", style = MaterialTheme.typography.labelSmall, color = FlameOrange)
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(modifier = Modifier.weight(1f).background(CastIron).padding(8.dp)) {
                        Text("GRILL 01\nOutlaw Ribeye\nMED RARE - Active", color = WarmCream, style = MaterialTheme.typography.bodySmall)
                    }
                    Box(modifier = Modifier.weight(1f).background(CastIron).padding(8.dp)) {
                        Text("GRILL 02\nFlo's Filet\nMEDIUM - Active", color = WarmCream, style = MaterialTheme.typography.bodySmall)
                    }
                    Box(modifier = Modifier.weight(1f).background(CastIron).padding(8.dp)) {
                        Text("GRILL 03\nRenegade Sirloin\nWELL DONE - Active", color = WarmCream, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (preparingTickets.isEmpty()) {
                item {
                    Text("No active tickets on the grill queue.", color = WarmGrey, modifier = Modifier.padding(12.dp))
                }
            } else {
                items(preparingTickets) { ticket ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = CastIron),
                        border = BorderStroke(1.dp, AgedBrass)
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Ticket: ${ticket.orderNumber}", style = MaterialTheme.typography.titleMedium, color = AgedBrass)
                                Text("03:12 mins", style = MaterialTheme.typography.labelSmall, color = FlameOrange)
                            }
                            Text(text = ticket.itemsSummary, style = MaterialTheme.typography.bodyMedium, color = WarmCream)

                            Button(
                                onClick = { viewModel.updateOrderStatusHq(ticket.id, OrderStatus.READY) },
                                colors = ButtonDefaults.buttonColors(containerColor = BurntRed),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("SERVE & READY")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HqWaitlistScreen(viewModel: MainViewModel) {
    val entries by viewModel.waitlistEntries.collectAsStateWithLifecycle()
    val activeEntries = entries.filter { it.status != WaitlistStatus.SEATED && it.status != WaitlistStatus.CANCELLED }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("WAITLIST MANAGER", style = MaterialTheme.typography.displaySmall, color = WarmCream)
        }

        if (activeEntries.isEmpty()) {
            item {
                Text("No customers currently in the call-ahead queue.", color = WarmGrey, modifier = Modifier.padding(24.dp))
            }
        } else {
            items(activeEntries) { entry ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = CastIron),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${entry.customerName} - Party of ${entry.partySize}", style = MaterialTheme.typography.titleMedium, color = WarmCream)
                            Text("Est Wait: ${entry.estWaitMin} mins", style = MaterialTheme.typography.bodyMedium, color = AgedBrass)
                        }
                        Text("Phone: ${entry.customerPhone} • Status: ${entry.status.name}", color = WarmGrey, style = MaterialTheme.typography.bodySmall)

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (entry.status == WaitlistStatus.CONFIRMED) {
                                Button(
                                    onClick = { viewModel.updateWaitlistStatusHq(entry.id, WaitlistStatus.READY) },
                                    colors = ButtonDefaults.buttonColors(containerColor = FlameOrange)
                                ) {
                                    Text("MARK READY")
                                }
                            }

                            Button(
                                onClick = { viewModel.updateWaitlistStatusHq(entry.id, WaitlistStatus.SEATED) },
                                colors = ButtonDefaults.buttonColors(containerColor = SageGreen)
                            ) {
                                Text("SEAT TABLE")
                            }

                            OutlinedButton(
                                onClick = { viewModel.updateWaitlistStatusHq(entry.id, WaitlistStatus.CANCELLED) },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = BurntRed)
                            ) {
                                Text("CANCEL")
                            }
                        }
                    }
                }
            }
        }
    }
}

// Operational Inventory (Section 28, 40: Inventory Integration)
@Composable
fun HqInventoryScreen(viewModel: MainViewModel) {
    val stockList by viewModel.inventory.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("STEAKHOUSE INVENTORY MANAGER", style = MaterialTheme.typography.displaySmall, color = WarmCream)
            Spacer(modifier = Modifier.height(4.dp))
            Text("Adjusting quantities updates ingredient states which automatically propagates to customer app Menu item availability.", style = MaterialTheme.typography.bodySmall, color = WarmGrey)
        }

        items(stockList) { record ->
            Card(
                colors = CardDefaults.cardColors(containerColor = CastIron),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(record.ingredientName, style = MaterialTheme.typography.titleMedium, color = WarmCream)
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("Current stock: ${record.quantity} ${record.unit}", style = MaterialTheme.typography.bodySmall, color = AgedBrass)
                            Text(
                                text = "Status: ${record.status.name}",
                                style = MaterialTheme.typography.labelSmall,
                                color = when (record.status) {
                                    InventoryStatus.AVAILABLE -> SageGreen
                                    InventoryStatus.LIMITED -> FlameOrange
                                    InventoryStatus.UNAVAILABLE -> BurntRed
                                }
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        IconButton(
                            onClick = { viewModel.updateInventoryHq(record.id, (record.quantity - 1.0).coerceAtLeast(0.0)) },
                            modifier = Modifier.background(Color.Black.copy(alpha = 0.3f))
                        ) {
                            Icon(Icons.Default.Remove, "-", tint = WarmCream)
                        }
                        IconButton(
                            onClick = { viewModel.updateInventoryHq(record.id, record.quantity + 5.0) },
                            modifier = Modifier.background(Color.Black.copy(alpha = 0.3f))
                        ) {
                            Icon(Icons.Default.Add, "+", tint = WarmCream)
                        }
                    }
                }
            }
        }
    }
}

// System Audit Logs Trail (Section 41, 42)
@Composable
fun HqAuditScreen(viewModel: MainViewModel) {
    val audits by viewModel.auditEvents.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("OPERATIONS AUDIT TRAIL", style = MaterialTheme.typography.displaySmall, color = WarmCream)
        }

        if (audits.isEmpty()) {
            item {
                Text("No audits logged yet.", color = WarmGrey, modifier = Modifier.padding(24.dp))
            }
        } else {
            items(audits) { audit ->
                val timeString = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(audit.timestamp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${audit.actionType} [${audit.entityName}]", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = AgedBrass)
                            Text(timeString, style = MaterialTheme.typography.labelSmall, color = WarmGrey)
                        }
                        Text("Id: ${audit.entityId} • Performed by: ${audit.performedBy}", style = MaterialTheme.typography.bodySmall, color = WarmGrey)
                        Text("Old: ${audit.oldState}", style = MaterialTheme.typography.bodySmall, color = WarmGrey)
                        Text("New: ${audit.newState}", style = MaterialTheme.typography.bodySmall, color = WarmCream)
                    }
                }
            }
        }
    }
}
