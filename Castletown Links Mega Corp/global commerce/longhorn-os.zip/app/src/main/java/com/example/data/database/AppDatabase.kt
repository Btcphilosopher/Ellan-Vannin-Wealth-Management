package com.example.data.database

import android.content.Context
import androidx.room.*
import com.example.data.dao.AppDao
import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class Converters {
    @TypeConverter
    fun fromRestaurantStatus(value: RestaurantStatus) = value.name
    @TypeConverter
    fun toRestaurantStatus(value: String) = try { RestaurantStatus.valueOf(value) } catch (e: Exception) { RestaurantStatus.OPEN }

    @TypeConverter
    fun fromOrderType(value: OrderType) = value.name
    @TypeConverter
    fun toOrderType(value: String) = try { OrderType.valueOf(value) } catch (e: Exception) { OrderType.TOGO }

    @TypeConverter
    fun fromOrderStatus(value: OrderStatus) = value.name
    @TypeConverter
    fun toOrderStatus(value: String) = try { OrderStatus.valueOf(value) } catch (e: Exception) { OrderStatus.ORDERED }

    @TypeConverter
    fun fromWaitlistStatus(value: WaitlistStatus) = value.name
    @TypeConverter
    fun toWaitlistStatus(value: String) = try { WaitlistStatus.valueOf(value) } catch (e: Exception) { WaitlistStatus.CONFIRMED }

    @TypeConverter
    fun fromInventoryStatus(value: InventoryStatus) = value.name
    @TypeConverter
    fun toInventoryStatus(value: String) = try { InventoryStatus.valueOf(value) } catch (e: Exception) { InventoryStatus.AVAILABLE }

    @TypeConverter
    fun fromOfferStatus(value: OfferStatus) = value.name
    @TypeConverter
    fun toOfferStatus(value: String) = try { OfferStatus.valueOf(value) } catch (e: Exception) { OfferStatus.AVAILABLE }
}

@Database(
    entities = [
        Restaurant::class,
        MenuItem::class,
        CartItem::class,
        Order::class,
        WaitlistEntry::class,
        GiftCard::class,
        Offer::class,
        Favourite::class,
        InventoryRecord::class,
        AuditEvent::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun appDao(): AppDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "longhorn_steakhouse_db"
                )
                .fallbackToDestructiveMigration()
                .addCallback(object : RoomDatabase.Callback() {
                    override fun onCreate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                        super.onCreate(db)
                        // Seed database in background coroutine
                        INSTANCE?.let { database ->
                            CoroutineScope(Dispatchers.IO).launch {
                                seedDatabase(database)
                            }
                        }
                    }
                })
                .build()
                INSTANCE = instance
                instance
            }
        }

        suspend fun seedDatabase(db: AppDatabase) {
            val dao = db.appDao()

            // 1. Seed Restaurants (Section 35: Seed 5 key locations with varied states)
            val restaurants = listOf(
                Restaurant("R1", "Atlanta Buckhead", "3215 Peachtree Rd NE, Atlanta, GA 30305", "(404) 266-0120", 0.8, 15, "11:00 AM", "10:00 PM", status = RestaurantStatus.OPEN),
                Restaurant("R2", "Dallas West End", "2001 N Griffin St, Dallas, TX 75202", "(214) 720-0010", 2.3, 35, "11:00 AM", "11:00 PM", status = RestaurantStatus.HIGH_DEMAND),
                Restaurant("R3", "Austin Central", "2702 W Anderson Ln, Austin, TX 78757", "(512) 343-2280", 4.1, 0, "11:30 AM", "10:00 PM", status = RestaurantStatus.OPEN),
                Restaurant("R4", "Orlando Sand Lake", "8150 International Dr, Orlando, FL 32819", "(407) 354-1120", 12.5, 45, "11:00 AM", "10:00 PM", status = RestaurantStatus.HIGH_DEMAND),
                Restaurant("R5", "Houston Galleria", "840 Meyerland Plaza, Houston, TX 77096", "(713) 660-9110", 18.2, 0, "11:00 AM", "09:30 PM", status = RestaurantStatus.LIMITED_MENU)
            )
            dao.insertRestaurants(restaurants)

            // 2. Seed Menu Items (Succulent cuts, sides, desserts, drinks)
            val menuItems = listOf(
                MenuItem("M1", "Outlaw Ribeye", "STEAKS", "Bold, generously marbled and fire-grilled for a steakhouse finish. Bone-in cut.", 31.99, 1120, "Ribeye", 20, "MEDIUM_RARE", "Prairie Dust", isFeatured = true),
                MenuItem("M2", "Flo's Filet", "STEAKS", "Our signature, most tender center-cut filet grilled to perfection. Incredibly lean.", 26.49, 410, "Filet Mignon", 9, "MEDIUM", "Grillmaster Blend", isFeatured = true),
                MenuItem("M3", "Renegade Sirloin", "STEAKS", "Lean and hearty USDA Choice center-cut sirloin, seasoned with our signature Prairie Dust.", 16.99, 390, "Sirloin", 8, "MEDIUM_RARE", "Prairie Dust", isFeatured = false),
                MenuItem("M4", "LongHorn Porterhouse", "STEAKS", "The biggest cut: a combination of NY Strip and tender Filet Mignon on a single bone.", 34.99, 1280, "T-Bone Porterhouse", 22, "MEDIUM_RARE", "Grillmaster Blend", isFeatured = false),
                MenuItem("M5", "Redrock Grilled Shrimp", "SEAFOOD", "Glazed and grilled shrimp served over rice with garlic butter. Tender and juicy.", 19.99, 560, isFeatured = false),
                MenuItem("M6", "Parmesan Crusted Chicken", "CHICKEN", "Fresh, grilled chicken breasts topped with a creamy, crunchy parmesan crust.", 18.49, 650, isFeatured = false),
                MenuItem("M7", "The LH Burger", "BURGERS & HANDHELDS", "Thick juicy burger with lettuce, onion, tomato, cheese and bacon on a toasted brioche bun.", 13.99, 820, isFeatured = false),
                MenuItem("M8", "Loaded Idaho Baked Potato", "SIDES", "A massive Idaho potato loaded with butter, sour cream, cheddar cheese, and bacon bits.", 4.99, 450, isFeatured = false),
                MenuItem("M9", "Steakhouse Mac & Cheese", "SIDES", "Cavatappi pasta baked in a creamy, rich four-cheese sauce topped with toasted breadcrumbs.", 5.49, 610, isFeatured = false),
                MenuItem("M10", "Fresh Steamed Asparagus", "SIDES", "Fresh asparagus spears seasoned with lemon pepper, lightly steamed to a perfect crunch.", 4.49, 90, isFeatured = false),
                MenuItem("M11", "Chocolate Stampede", "DESSERTS", "Six kinds of chocolate in peaks and layers, served with vanilla bean ice cream.", 9.49, 1200, isFeatured = true),
                MenuItem("M12", "Montana Mule", "BEVERAGES", "Jim Beam Bourbon, ginger beer, and lime juice served in an icy copper mug.", 8.49, 210, isFeatured = false)
            )
            dao.insertMenuItems(menuItems)

            // 3. Seed Inventory Records
            val inventory = listOf(
                InventoryRecord("I1", "Outlaw Bone-in Ribeye", 25.0, "pcs", 5.0, InventoryStatus.AVAILABLE, "R1"),
                InventoryRecord("I2", "Flo's Filet Cut", 3.0, "pcs", 5.0, InventoryStatus.LIMITED, "R1"), // Limited to trigger Demo 5!
                InventoryRecord("I3", "Renegade Sirloin Cut", 0.0, "pcs", 2.0, InventoryStatus.UNAVAILABLE, "R1"), // Out of stock to trigger Demo 5!
                InventoryRecord("I4", "Loaded Baked Potatoes", 100.0, "pcs", 10.0, InventoryStatus.AVAILABLE, "R1"),
                InventoryRecord("I5", "Fresh Asparagus Spears", 45.0, "lbs", 8.0, InventoryStatus.AVAILABLE, "R1"),
                InventoryRecord("I6", "Chocolate Cakes", 12.0, "pcs", 2.0, InventoryStatus.AVAILABLE, "R1")
            )
            dao.insertInventory(inventory)

            // 4. Seed Active Offers
            val offers = listOf(
                Offer("O1", "eClub Welcome Gift", "Enjoy a free appetizer with purchase of any adult steak entree.", "WELCOMEAPP", 0, OfferStatus.AVAILABLE),
                Offer("O2", "Grillmaster Special", "Take 10% off any signature cut for a limited time.", "GRILL10", 10, OfferStatus.AVAILABLE),
                Offer("O3", "Sizzling Celebration", "Receive $10 off your order of $50 or more.", "STEAK10", 20, OfferStatus.AVAILABLE)
            )
            dao.insertOffers(offers)

            // 5. Seed some initial Gift Cards
            dao.insertGiftCard(GiftCard("G1", "7777-8888-9999-1111", 50.00, 50.00))
            dao.insertGiftCard(GiftCard("G2", "1234-5678-9012-3456", 15.25, 25.00))

            // 6. Seed a few existing orders for History (Section 35)
            dao.insertOrder(Order(
                id = "ORD1001",
                orderNumber = "LH-1001",
                restaurantId = "R1",
                restaurantName = "Atlanta Buckhead",
                customerName = "Tom",
                customerPhone = "555-0199",
                itemsSummary = "1x Outlaw Ribeye (Medium Rare, Potato, Asparagus)",
                orderType = OrderType.TOGO,
                totalAmount = 31.99,
                orderStatus = OrderStatus.COMPLETE,
                paymentStatus = "PAID",
                createdAt = System.currentTimeMillis() - 86400000 * 2 // 2 days ago
            ))

            // 7. Seed an initial audit event
            dao.insertAuditEvent(AuditEvent(
                entityName = "Database",
                entityId = "System",
                actionType = "INITIAL_SEED",
                oldState = "None",
                newState = "Seeded with 5 Restaurants, 12 Menu Items, Inventory and Offers.",
                performedBy = "SYSTEM_HQ"
            ))
        }
    }
}
