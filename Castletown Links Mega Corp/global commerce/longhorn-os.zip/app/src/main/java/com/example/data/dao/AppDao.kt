package com.example.data.dao

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {

    // --- RESTAURANTS ---
    @Query("SELECT * FROM restaurants ORDER BY distance ASC")
    fun getAllRestaurants(): Flow<List<Restaurant>>

    @Query("SELECT * FROM restaurants WHERE id = :id")
    suspend fun getRestaurantById(id: String): Restaurant?

    @Query("SELECT * FROM restaurants WHERE id = :id")
    fun getRestaurantFlowById(id: String): Flow<Restaurant?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRestaurants(restaurants: List<Restaurant>)

    @Update
    suspend fun updateRestaurant(restaurant: Restaurant)


    // --- MENU ITEMS ---
    @Query("SELECT * FROM menu_items ORDER BY category DESC, name ASC")
    fun getAllMenuItems(): Flow<List<MenuItem>>

    @Query("SELECT * FROM menu_items WHERE id = :id")
    suspend fun getMenuItemById(id: String): MenuItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMenuItems(menuItems: List<MenuItem>)

    @Update
    suspend fun updateMenuItem(menuItem: MenuItem)

    @Query("UPDATE menu_items SET isAvailable = :isAvailable WHERE id = :id")
    suspend fun updateMenuItemAvailability(id: String, isAvailable: Boolean)


    // --- CART ITEMS ---
    @Query("SELECT * FROM cart_items")
    fun getCartItems(): Flow<List<CartItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCartItem(cartItem: CartItem)

    @Update
    suspend fun updateCartItem(cartItem: CartItem)

    @Delete
    suspend fun deleteCartItem(cartItem: CartItem)

    @Query("DELETE FROM cart_items")
    suspend fun clearCart()


    // --- ORDERS ---
    @Query("SELECT * FROM orders ORDER BY createdAt DESC")
    fun getAllOrders(): Flow<List<Order>>

    @Query("SELECT * FROM orders WHERE id = :id")
    suspend fun getOrderById(id: String): Order?

    @Query("SELECT * FROM orders WHERE id = :id")
    fun getOrderFlowById(id: String): Flow<Order?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: Order)

    @Update
    suspend fun updateOrder(order: Order)

    @Query("UPDATE orders SET orderStatus = :status, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateOrderStatus(id: String, status: OrderStatus, updatedAt: Long = System.currentTimeMillis())


    // --- WAITLIST ---
    @Query("SELECT * FROM waitlist_entries ORDER BY createdAt ASC")
    fun getAllWaitlistEntries(): Flow<List<WaitlistEntry>>

    @Query("SELECT * FROM waitlist_entries WHERE restaurantId = :restaurantId ORDER BY createdAt ASC")
    fun getWaitlistForRestaurant(restaurantId: String): Flow<List<WaitlistEntry>>

    @Query("SELECT * FROM waitlist_entries WHERE id = :id")
    suspend fun getWaitlistEntry(id: String): WaitlistEntry?

    @Query("SELECT * FROM waitlist_entries WHERE id = :id")
    fun getWaitlistEntryFlow(id: String): Flow<WaitlistEntry?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWaitlist(entry: WaitlistEntry)

    @Update
    suspend fun updateWaitlist(entry: WaitlistEntry)

    @Query("UPDATE waitlist_entries SET status = :status, estWaitMin = :estWait, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateWaitlistStatus(id: String, status: WaitlistStatus, estWait: Int, updatedAt: Long = System.currentTimeMillis())

    @Query("DELETE FROM waitlist_entries WHERE id = :id")
    suspend fun deleteWaitlistEntry(id: String)


    // --- GIFT CARDS ---
    @Query("SELECT * FROM gift_cards ORDER BY createdAt DESC")
    fun getAllGiftCards(): Flow<List<GiftCard>>

    @Query("SELECT * FROM gift_cards WHERE cardNumber = :number")
    suspend fun getGiftCardByNumber(number: String): GiftCard?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGiftCard(card: GiftCard)

    @Update
    suspend fun updateGiftCard(card: GiftCard)


    // --- OFFERS ---
    @Query("SELECT * FROM offers")
    fun getAllOffers(): Flow<List<Offer>>

    @Query("SELECT * FROM offers WHERE id = :id")
    suspend fun getOfferById(id: String): Offer?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOffers(offers: List<Offer>)

    @Update
    suspend fun updateOffer(offer: Offer)


    // --- FAVOURITES ---
    @Query("SELECT * FROM favourites ORDER BY createdAt DESC")
    fun getAllFavourites(): Flow<List<Favourite>>

    @Query("SELECT * FROM favourites WHERE menuItemId = :menuItemId")
    suspend fun getFavouriteByMenuItemId(menuItemId: String): Favourite?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavourite(favourite: Favourite)

    @Query("DELETE FROM favourites WHERE menuItemId = :menuItemId")
    suspend fun deleteFavouriteByMenuItemId(menuItemId: String)


    // --- INVENTORY ---
    @Query("SELECT * FROM inventory ORDER BY ingredientName ASC")
    fun getAllInventory(): Flow<List<InventoryRecord>>

    @Query("SELECT * FROM inventory WHERE restaurantId = :restaurantId ORDER BY ingredientName ASC")
    fun getInventoryForRestaurant(restaurantId: String): Flow<List<InventoryRecord>>

    @Query("SELECT * FROM inventory WHERE id = :id")
    suspend fun getInventoryById(id: String): InventoryRecord?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInventory(records: List<InventoryRecord>)

    @Update
    suspend fun updateInventory(record: InventoryRecord)


    // --- AUDIT ---
    @Query("SELECT * FROM audit_events ORDER BY timestamp DESC")
    fun getAllAuditEvents(): Flow<List<AuditEvent>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditEvent(event: AuditEvent)
}
