package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.database.AppDatabase
import com.example.data.model.*
import com.example.data.repository.AppRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.IOException

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34]) // standard Robolectric SDK target
class ExampleRobolectricTest {

    private lateinit var db: AppDatabase
    private lateinit var repository: AppRepository

    @Before
    fun createDb() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = AppRepository(db.appDao())
    }

    @After
    @Throws(IOException::class)
    fun closeDb() {
        db.close()
    }

    @Test
    fun readAppNameFromContext() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("LongHorn OS", appName)
    }

    @Test
    fun testWaitlistCreationAndFlow() = runBlocking {
        // Seed restaurant
        val res = Restaurant("R_TEST", "Test Steakhouse", "123 Main St", "555-0100", 1.0, 15, "11:00 AM", "10:00 PM")
        db.appDao().insertRestaurants(listOf(res))

        val entry = WaitlistEntry(
            id = "W_TEST",
            restaurantId = "R_TEST",
            restaurantName = "Test Steakhouse",
            partySize = 4,
            customerName = "Tom",
            customerPhone = "555-0199",
            status = WaitlistStatus.CONFIRMED
        )

        repository.joinWaitlist(entry)

        // Retrieve and assert
        val list = repository.getWaitlistForRestaurant("R_TEST").first()
        assertEquals(1, list.size)
        assertEquals("Tom", list[0].customerName)
        assertEquals(WaitlistStatus.CONFIRMED, list[0].status)

        // Advance waitlist status
        repository.updateWaitlistStatus("W_TEST", WaitlistStatus.READY, 5)
        val updated = repository.getWaitlistEntry("W_TEST")
        assertEquals(WaitlistStatus.READY, updated?.status)
    }

    @Test
    fun testCheckoutPricingAndOffers() = runBlocking {
        val item1 = MenuItem("M_TEST_1", "Outlaw Ribeye", "STEAKS", "Ribeye", 30.00, 1000)
        val item2 = MenuItem("M_TEST_2", "Loaded Potato", "SIDES", "Potato", 5.00, 400)
        db.appDao().insertMenuItems(listOf(item1, item2))

        // Populate Cart
        val cart1 = CartItem(id = 1, menuItemId = "M_TEST_1", itemName = "Outlaw Ribeye", category = "STEAKS", quantity = 1, totalPrice = 30.00)
        val cart2 = CartItem(id = 2, menuItemId = "M_TEST_2", itemName = "Loaded Potato", category = "SIDES", quantity = 2, totalPrice = 10.00)
        repository.addToCart(cart1)
        repository.addToCart(cart2)

        val cartList = repository.cartItems.first()
        assertEquals(2, cartList.size)
        val totalAmount = cartList.sumOf { it.totalPrice }
        assertEquals(40.00, totalAmount, 0.001)

        // Applying a simulated 10% offer discount
        val offer = Offer("OFFER_TEST", "Test Promo", "Save 10%", "SAVE10", 10)
        val discount = totalAmount * (offer.discountPercent / 100.0)
        assertEquals(4.00, discount, 0.001)
        assertEquals(36.00, totalAmount - discount, 0.001)
    }

    @Test
    fun testConnectedLoopInventorySync() = runBlocking {
        // Seed menu item and matching inventory record
        val item = MenuItem("M1", "Outlaw Ribeye", "STEAKS", "Ribeye Cut", 31.99, 1120)
        db.appDao().insertMenuItems(listOf(item))

        val record = InventoryRecord("I1", "Outlaw Bone-in Ribeye", 20.0, "pcs", 5.0, InventoryStatus.AVAILABLE, "R1")
        db.appDao().insertInventory(listOf(record))

        // Assert initial availability is true
        val initialItem = db.appDao().getMenuItemById("M1")
        assertTrue(initialItem?.isAvailable == true)

        // Decrement stock to 0 (Unavailable)
        repository.updateInventoryQuantity("I1", 0.0)

        // Verify MenuItem is automatically set to unavailable via connected state propagation!
        val syncedItem = db.appDao().getMenuItemById("M1")
        assertFalse(syncedItem?.isAvailable == true)

        // Restock to 10 (Available again)
        repository.updateInventoryQuantity("I1", 10.0)
        val restockedItem = db.appDao().getMenuItemById("M1")
        assertTrue(restockedItem?.isAvailable == true)
    }
}
