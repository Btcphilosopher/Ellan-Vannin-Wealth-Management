package com.example

import com.example.model.FuelGrade
import com.example.model.RewardOffer
import com.example.model.RewardsRulesEngine
import com.example.repository.AppRepository
import java.math.BigDecimal
import org.junit.Assert.assertEquals
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun test_haversine_distance_calculation() {
        // Test distance from Dallas mock user coordinates to Dallas North station (approx 0.7 miles)
        val distance = AppRepository.calculateDistanceMiles(
            AppRepository.MOCK_USER_LAT,
            AppRepository.MOCK_USER_LON,
            32.7867, // Dallas North Lat
            -96.7970  // Dallas North Lon
        )
        // Since we are at 32.7767, -96.7970, lat difference of 0.01 degrees is ~0.69 miles
        assertEquals(0.7, distance, 0.1)
    }

    @Test
    fun test_rewards_rules_engine_discount_stacking() {
        val offers = listOf(
            RewardOffer(
                offerID = "o1",
                title = "10c off Regular",
                description = "Regular promo",
                discountType = "CENTS_PER_GAL",
                discountValue = 0.10,
                eligibleFuel = "REGULAR",
                stackingPolicy = "STACKABLE",
                startAt = 0,
                endAt = System.currentTimeMillis() + 1000000
            ),
            RewardOffer(
                offerID = "o2",
                title = "5c off Any",
                description = "Any promo",
                discountType = "CENTS_PER_GAL",
                discountValue = 0.05,
                eligibleFuel = "ANY",
                stackingPolicy = "STACKABLE",
                startAt = 0,
                endAt = System.currentTimeMillis() + 1000000
            ),
            RewardOffer(
                offerID = "o3",
                title = "Non-stackable premium discount",
                description = "15c off Premium",
                discountType = "CENTS_PER_GAL",
                discountValue = 0.15,
                eligibleFuel = "PREMIUM",
                stackingPolicy = "NON_STACKABLE",
                startAt = 0,
                endAt = System.currentTimeMillis() + 1000000
            )
        )

        // For Regular: Member discount (0.05) + Stacking regular (0.10) + Stacking any (0.05) = 0.20
        val discountRegular = RewardsRulesEngine.calculateEffectiveDiscount(
            fuelGrade = FuelGrade.REGULAR,
            stationID = "TX00142",
            availableOffers = offers,
            redeemRewardDollars = 0.0
        )
        assertEquals(0.20, discountRegular, 0.0001)

        // For Premium: Since non-stackable premium exists (0.15), it should compare non-stackable premium with stackable any.
        // Non-stackable premium: 0.15
        // Stackable any (0.05) = 0.05
        // Best promo chosen is 0.15. Standard base member discount of 0.05 is added on top.
        // Total = 0.15 + 0.05 = 0.20
        val discountPremium = RewardsRulesEngine.calculateEffectiveDiscount(
            fuelGrade = FuelGrade.PREMIUM,
            stationID = "TX00142",
            availableOffers = offers,
            redeemRewardDollars = 0.0
        )
        assertEquals(0.20, discountPremium, 0.0001)
    }

    @Test
    fun test_rewards_rules_engine_transaction_finalization() {
        val gallons = 10.0
        val ppg = 3.50
        val discountPerGal = 0.20 // Member discount (5c) + Offer (15c)
        val redeemedRewardDollars = 2.0 // $2.00 deduction from points

        val result = RewardsRulesEngine.finalizeTransaction(
            gallons = gallons,
            pricePerGallon = ppg,
            discountPerGallon = discountPerGal,
            redeemedRewardsDollars = redeemedRewardDollars
        )

        // Gross: 10 * 3.50 = 35.00
        // Total savings from fuel discount: 10 * 0.20 = 2.00
        // Sells price: 35.00 - 2.00 = 33.00
        // After points redemption deduction: 33.00 - 2.00 = 31.00 net
        // Points earned: 1 point per gallon (10.0 gallons rounded down) = 10 points
        assertEquals(35.0, result.grossAmount, 0.001)
        assertEquals(4.0, result.totalSavings, 0.001) // 2.00 fuel + 2.00 cash
        assertEquals(31.0, result.netAmount, 0.001)
        assertEquals(10, result.pointsEarned)
    }
}
