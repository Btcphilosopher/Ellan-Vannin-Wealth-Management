package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DriveEta
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun VehicleGarageScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val vehicles by viewModel.vehicles.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BrandLightBg)
    ) {
        Surface(color = BrandNavy, contentColor = BrandWhite, tonalElevation = 4.dp) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(Icons.Default.DriveEta, contentDescription = null, tint = BrandWhite, modifier = Modifier.size(36.dp))
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "VEHICLE GARAGE",
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Manage your vehicle profiles for fuel economy and capacity tracking",
                    fontSize = 11.sp,
                    color = BrandSilver.copy(alpha = 0.7f)
                )
            }
        }

        Column(modifier = Modifier.padding(16.dp).weight(1f)) {
            SectionHeader("Registered Vehicles")

            if (vehicles.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No vehicles configured.", color = BrandGraphite.copy(alpha = 0.5f))
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize().testTag("vehicles_garage_list")
                ) {
                    items(vehicles) { vehicle ->
                        VehicleGarageRow(vehicle = vehicle, onDelete = { viewModel.deleteVehicle(vehicle.id) })
                    }
                }
            }
        }
    }
}
