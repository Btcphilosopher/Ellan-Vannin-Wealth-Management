package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DriveEta
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PaymentMethod
import com.example.model.Vehicle

@Composable
fun AccountScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val vehicles by viewModel.vehicles.collectAsState()
    val paymentMethods by viewModel.paymentMethods.collectAsState()

    val simulatePaymentDeclined by viewModel.simulatePaymentDeclined.collectAsState()
    val simulatePumpOffline by viewModel.simulatePumpOffline.collectAsState()

    var showAddVehicleDialog by remember { mutableStateOf(false) }
    var showAddCardDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BrandLightBg)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- Profile Summary Header ---
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BrandSilver, RoundedCornerShape(12.dp)),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = BrandWhite)
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(RoundedCornerShape(27.dp))
                        .background(BrandNavy),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Person, contentDescription = null, tint = BrandWhite, modifier = Modifier.size(28.dp))
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(
                        text = "Tom Thompson",
                        fontWeight = FontWeight.Bold,
                        color = BrandNavy,
                        fontSize = 18.sp
                    )
                    Text(
                        text = "tom@ahyx.org",
                        fontSize = 13.sp,
                        color = BrandGraphite.copy(alpha = 0.6f)
                    )
                }
            }
        }

        // --- Stored Wallet Payment Cards ---
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            SectionHeader("Saved Payment Methods")
            IconButton(
                onClick = { showAddCardDialog = true },
                modifier = Modifier.testTag("add_card_button")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Card", tint = BrandRed)
            }
        }

        if (paymentMethods.isEmpty()) {
            Text("No cards stored in your wallet.", fontSize = 12.sp, color = BrandGraphite.copy(alpha = 0.5f))
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                paymentMethods.forEach { card ->
                    PaymentMethodRow(card = card, onDelete = { viewModel.deleteCard(card.id) })
                }
            }
        }

        // --- Vehicles Garage Section ---
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            SectionHeader("My Garage (Vehicles)")
            IconButton(
                onClick = { showAddVehicleDialog = true },
                modifier = Modifier.testTag("add_vehicle_button")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Vehicle", tint = BrandRed)
            }
        }

        if (vehicles.isEmpty()) {
            Text("No vehicles configured.", fontSize = 12.sp, color = BrandGraphite.copy(alpha = 0.5f))
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                vehicles.forEach { vehicle ->
                    VehicleGarageRow(vehicle = vehicle, onDelete = { viewModel.deleteVehicle(vehicle.id) })
                }
            }
        }

        // --- Troubleshooting / Failure Simulations ---
        SectionHeader("Failure Simulations (Testing)")
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BrandSilver, RoundedCornerShape(12.dp)),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = BrandWhite)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Simulate Payment Declined", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = BrandNavy)
                        Text("Triggers a pre-auth failure during payment authorization step.", fontSize = 11.sp, color = BrandGraphite.copy(alpha = 0.5f))
                    }
                    Switch(
                        checked = simulatePaymentDeclined,
                        onCheckedChange = { viewModel.toggleSimulatePaymentDeclined(it) },
                        colors = SwitchDefaults.colors(checkedThumbColor = BrandWhite, checkedTrackColor = BrandRed),
                        modifier = Modifier.testTag("toggle_payment_declined")
                    )
                }

                Divider(color = BrandSilver)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Simulate Pump Offline", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = BrandNavy)
                        Text("Locks pump activation, simulating a forecourt terminal failure.", fontSize = 11.sp, color = BrandGraphite.copy(alpha = 0.5f))
                    }
                    Switch(
                        checked = simulatePumpOffline,
                        onCheckedChange = { viewModel.toggleSimulatePumpOffline(it) },
                        colors = SwitchDefaults.colors(checkedThumbColor = BrandWhite, checkedTrackColor = BrandRed),
                        modifier = Modifier.testTag("toggle_pump_offline")
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }

    // --- Card Add Dialog ---
    if (showAddCardDialog) {
        var cardBrand by remember { mutableStateOf("VISA") }
        AlertDialog(
            onDismissRequest = { showAddCardDialog = false },
            title = { Text("Add Synthetic Card", fontWeight = FontWeight.Bold, color = BrandNavy) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Select a synthetic card brand to store in your wallet.", fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        listOf("VISA", "MASTERCARD", "DISCOVER", "AMEX").forEach { brand ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (cardBrand == brand) BrandNavy else BrandSilver)
                                    .clickable { cardBrand = brand }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    brand,
                                    color = if (cardBrand == brand) BrandWhite else BrandGraphite,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.addCard(cardBrand)
                        showAddCardDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BrandNavy)
                ) {
                    Text("ADD CARD")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddCardDialog = false }) {
                    Text("CANCEL")
                }
            }
        )
    }

    // --- Vehicle Add Dialog ---
    if (showAddVehicleDialog) {
        var make by remember { mutableStateOf("") }
        var model by remember { mutableStateOf("") }
        var year by remember { mutableStateOf("2024") }
        var fuelType by remember { mutableStateOf("Gasoline") }
        var tankCapacity by remember { mutableStateOf("15") }
        var fuelEconomy by remember { mutableStateOf("24") }
        var nickname by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddVehicleDialog = false },
            title = { Text("Add Vehicle Profile", fontWeight = FontWeight.Bold, color = BrandNavy) },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(value = make, onValueChange = { make = it }, label = { Text("Make (e.g. Ford)") })
                    OutlinedTextField(value = model, onValueChange = { model = it }, label = { Text("Model (e.g. F-150)") })
                    OutlinedTextField(value = year, onValueChange = { year = it }, label = { Text("Year (e.g. 2023)") })
                    OutlinedTextField(value = nickname, onValueChange = { nickname = it }, label = { Text("Nickname (e.g. My Truck)") })
                    OutlinedTextField(value = tankCapacity, onValueChange = { tankCapacity = it }, label = { Text("Tank Capacity (GAL)") })
                    OutlinedTextField(value = fuelEconomy, onValueChange = { fuelEconomy = it }, label = { Text("Fuel Economy (MPG)") })
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (make.isNotEmpty() && model.isNotEmpty()) {
                            viewModel.addVehicle(
                                make = make,
                                model = model,
                                year = year.toIntOrNull() ?: 2024,
                                fuelType = fuelType,
                                tankCapacity = tankCapacity.toDoubleOrNull() ?: 15.0,
                                fuelEconomy = fuelEconomy.toDoubleOrNull() ?: 24.0,
                                nickname = nickname.ifEmpty { "$make $model" }
                            )
                        }
                        showAddVehicleDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BrandNavy)
                ) {
                    Text("SAVE VEHICLE")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddVehicleDialog = false }) {
                    Text("CANCEL")
                }
            }
        )
    }
}

@Composable
fun PaymentMethodRow(
    card: PaymentMethod,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, BrandSilver, RoundedCornerShape(8.dp)),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = BrandWhite)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CreditCard, contentDescription = null, tint = BrandBlue, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(text = card.displayName.uppercase(), fontWeight = FontWeight.Bold, color = BrandNavy, fontSize = 13.sp)
                    Text(text = "Synthetic Tokenized · Ready", fontSize = 10.sp, color = BrandGreen, fontWeight = FontWeight.Bold)
                }
            }

            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = BrandRed.copy(alpha = 0.6f))
            }
        }
    }
}

@Composable
fun VehicleGarageRow(
    vehicle: Vehicle,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, BrandSilver, RoundedCornerShape(8.dp)),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = BrandWhite)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.DriveEta, contentDescription = null, tint = BrandNavy, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(text = vehicle.nickname, fontWeight = FontWeight.Bold, color = BrandNavy, fontSize = 13.sp)
                    Text(
                        text = "${vehicle.year} ${vehicle.make} ${vehicle.model} · ${vehicle.fuelType}",
                        fontSize = 11.sp,
                        color = BrandGraphite.copy(alpha = 0.6f)
                    )
                    Text(
                        text = "${vehicle.tankCapacity} Gal Tank · ${vehicle.fuelEconomy} MPG avg",
                        fontSize = 10.sp,
                        color = BrandGraphite.copy(alpha = 0.5f)
                    )
                }
            }

            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = BrandRed.copy(alpha = 0.6f))
            }
        }
    }
}
