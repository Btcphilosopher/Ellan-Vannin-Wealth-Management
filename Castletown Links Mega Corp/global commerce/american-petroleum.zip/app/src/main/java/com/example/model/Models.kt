package com.example.model

import androidx.room.Entity
import androidx.room.PrimaryKey

// --- Data Provenance ---
enum class DataProvenance {
    SYNTHETIC, // Generated programmatically
    MODELLED,  // Simulated/Calculated by business logic
    USER_ENTERED, // Input from user
    SIMULATED  // Real-time telemetry updates
}

// --- Stations & Forecourt ---
@Entity(tableName = "stations")
data class Station(
    @PrimaryKey val stationID: String,
    val name: String,
    val address: String,
    val city: String,
    val state: String,
    val zip: String,
    val latitude: Double,
    val longitude: Double,
    val openingHours: String,
    val phone: String,
    val amenities: String, // Comma separated, e.g. "Convenience Store, Car Wash, Restroom, Air, ATM"
    val priceUpdatedAt: Long,
    val status: String, // "OPEN", "CLOSED"
    val regPrice: Double,
    val midPrice: Double,
    val premPrice: Double,
    val dieselPrice: Double,
    val e85Price: Double,
    val provenance: DataProvenance = DataProvenance.SYNTHETIC
)

data class Pump(
    val pumpID: String,
    val stationID: String,
    val number: Int,
    val status: String, // "AVAILABLE", "BUSY", "OUT_OF_SERVICE", "MAINTENANCE", "OFFLINE"
    val fuelGrades: List<String>,
    val nozzleCount: Int = 1,
    val terminalID: String,
    val lastHeartbeat: Long = System.currentTimeMillis(),
    val maintenanceStatus: String = "OPERATIONAL",
    val provenance: DataProvenance = DataProvenance.SYNTHETIC
)

enum class FuelGrade(val displayName: String, val octane: Int, val ethanolPercentage: Double) {
    REGULAR("Regular", 87, 10.0),
    MIDGRADE("Plus", 89, 10.0),
    PREMIUM("Premium", 93, 10.0),
    DIESEL("Diesel", 40, 0.0),
    E85("E85 Flex Fuel", 100, 85.0);

    companion object {
        fun fromId(id: String): FuelGrade {
            return when (id.uppercase()) {
                "REGULAR" -> REGULAR
                "MIDGRADE", "PLUS" -> MIDGRADE
                "PREMIUM" -> PREMIUM
                "DIESEL" -> DIESEL
                "E85" -> E85
                else -> REGULAR
            }
        }
    }
}

// --- Payments & Authorisation ---
@Entity(tableName = "payment_methods")
data class PaymentMethod(
    @PrimaryKey val id: String,
    val type: String, // "CARD", "GOOGLE_PAY", "APPLE_PAY"
    val displayName: String, // e.g. "VISA •••• 4821"
    val token: String,
    val provenance: DataProvenance = DataProvenance.USER_ENTERED
)

enum class PaymentAuthorisationStatus {
    REQUESTED, AUTHORISED, DECLINED, EXPIRED, CANCELLED, CAPTURED, VOIDED
}

data class PaymentAuthorisation(
    val id: String,
    val transactionID: String,
    val paymentMethodID: String,
    val requestedAmount: Double,
    val authorisedAmount: Double,
    val status: PaymentAuthorisationStatus,
    val createdAt: Long = System.currentTimeMillis(),
    val expiresAt: Long = System.currentTimeMillis() + 600000, // 10 minutes
    val providerReference: String,
    val provenance: DataProvenance = DataProvenance.MODELLED
)

// --- Pump Session State ---
enum class PumpSessionStatus {
    CREATED, PUMP_IDENTIFIED, FUEL_SELECTED, PAYMENT_PENDING, AUTHORISED, READY_TO_FUEL, FUELLING, STOPPED, FINALISING, COMPLETED, FAILED, CANCELLED
}

data class PumpSession(
    val sessionID: String,
    val customerID: String,
    val stationID: String,
    val pumpID: String,
    val fuelGrade: FuelGrade?,
    val authorisationID: String?,
    val requestedAmount: Double, // -1.0 for full tank
    val dispensedGallons: Double = 0.0,
    val currentAmount: Double = 0.0,
    val status: PumpSessionStatus = PumpSessionStatus.CREATED,
    val startedAt: Long = System.currentTimeMillis(),
    val completedAt: Long = 0L,
    val provenance: DataProvenance = DataProvenance.SIMULATED
)

// --- Loyalty & Rewards ---
@Entity(tableName = "rewards_account")
data class RewardsAccount(
    @PrimaryKey val customerID: String,
    val pointsBalance: Int,
    val availableRewardDollars: Double,
    val provenance: DataProvenance = DataProvenance.MODELLED
)

@Entity(tableName = "rewards_ledger")
data class RewardsLedgerEntry(
    @PrimaryKey val id: String,
    val customerID: String,
    val transactionID: String?,
    val points: Int,
    val type: String, // "EARNED", "PENDING", "REDEEMED", "EXPIRED", "REVERSED", "ADJUSTED"
    val timestamp: Long = System.currentTimeMillis(),
    val description: String,
    val balanceAfter: Int,
    val provenance: DataProvenance = DataProvenance.MODELLED
)

@Entity(tableName = "offers")
data class RewardOffer(
    @PrimaryKey val offerID: String,
    val title: String,
    val description: String,
    val discountType: String, // "CENTS_PER_GAL", "BONUS_POINTS", "FREE_ITEM"
    val discountValue: Double,
    val startAt: Long,
    val endAt: Long,
    val eligibleFuel: String, // "ANY" or "REGULAR", "PREMIUM", etc.
    val eligibleStation: String = "ANY",
    val minimumGallons: Double = 0.0,
    val maximumGallons: Double = 20.0,
    val stackingPolicy: String = "STACKABLE", // "STACKABLE", "NON_STACKABLE"
    val isClaimed: Boolean = false,
    val provenance: DataProvenance = DataProvenance.SYNTHETIC
)

// --- Digital Receipts ---
@Entity(tableName = "receipts")
data class Receipt(
    @PrimaryKey val receiptID: String,
    val transactionID: String,
    val stationID: String,
    val stationName: String,
    val stationAddress: String,
    val pumpNumber: Int,
    val dateTime: Long,
    val fuelGrade: String,
    val gallons: Double,
    val pricePerGallon: Double,
    val grossAmount: Double,
    val discount: Double,
    val netAmount: Double,
    val rewardsEarned: Int,
    val paymentMethod: String,
    val provenance: DataProvenance = DataProvenance.MODELLED
)

// --- Garage / Vehicles ---
@Entity(tableName = "vehicles")
data class Vehicle(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val make: String,
    val model: String,
    val year: Int,
    val fuelType: String, // "Gasoline", "Diesel", "Hybrid", "Electric"
    val tankCapacity: Double, // Gallons
    val fuelEconomy: Double, // MPG
    val nickname: String,
    val provenance: DataProvenance = DataProvenance.USER_ENTERED
)

// --- Station Favourites ---
@Entity(tableName = "favorite_stations")
data class FavoriteStation(
    @PrimaryKey val stationID: String,
    val nickname: String, // "HOME", "WORK", "FAVORITE"
    val visitCount: Int = 0,
    val lastVisit: Long = 0L,
    val provenance: DataProvenance = DataProvenance.USER_ENTERED
)

// --- Convenience Store ---
data class StoreProduct(
    val id: String,
    val name: String,
    val category: String, // "coffee", "food", "drinks", "snacks", "motor oil", "car accessories"
    val price: Double,
    val description: String,
    val provenance: DataProvenance = DataProvenance.SYNTHETIC
)
