package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Receipt
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ReceiptsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val receipts by viewModel.receipts.collectAsState()
    var receiptSearchQuery by remember { mutableStateOf("") }

    val filteredReceipts = receipts.filter {
        it.stationName.contains(receiptSearchQuery, ignoreCase = true) ||
        it.fuelGrade.contains(receiptSearchQuery, ignoreCase = true) ||
        it.receiptID.contains(receiptSearchQuery, ignoreCase = true)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BrandLightBg)
    ) {
        // --- Search header ---
        Surface(
            color = BrandNavy,
            contentColor = BrandWhite,
            tonalElevation = 4.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                TextField(
                    value = receiptSearchQuery,
                    onValueChange = { receiptSearchQuery = it },
                    placeholder = { Text("Search receipts by station or fuel grade...", color = BrandSilver.copy(alpha = 0.7f)) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .testTag("receipts_search_input"),
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = BrandWhite) },
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = BrandWhite.copy(alpha = 0.15f),
                        unfocusedContainerColor = BrandWhite.copy(alpha = 0.12f),
                        disabledContainerColor = BrandWhite.copy(alpha = 0.05f),
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        focusedTextColor = BrandWhite,
                        unfocusedTextColor = BrandWhite
                    )
                )
            }
        }

        // --- History List ---
        if (filteredReceipts.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.ReceiptLong,
                        contentDescription = null,
                        tint = BrandSilver,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "No digital receipts found.",
                        color = BrandGraphite.copy(alpha = 0.5f),
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(vertical = 16.dp)
            ) {
                item {
                    SectionHeader("Past Fuel Fills Receipts")
                }
                items(filteredReceipts) { receipt ->
                    ReceiptListItemCard(receipt = receipt, onClick = { viewModel.selectReceipt(receipt) })
                }
            }
        }
    }
}

@Composable
fun ReceiptListItemCard(
    receipt: Receipt,
    onClick: () -> Unit
) {
    val sdf = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
    val formattedDate = sdf.format(Date(receipt.dateTime))

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .border(1.dp, BrandSilver, RoundedCornerShape(12.dp)),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = BrandWhite)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Fuel pump icon visual
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(BrandNavy.copy(alpha = 0.06f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.LocalGasStation,
                    contentDescription = null,
                    tint = BrandNavy,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = receipt.stationName,
                    fontWeight = FontWeight.Bold,
                    color = BrandNavy,
                    fontSize = 14.sp,
                    maxLines = 1
                )
                Text(
                    text = "$formattedDate · Pump ${receipt.pumpNumber} · ${receipt.fuelGrade}",
                    fontSize = 11.sp,
                    color = BrandGraphite.copy(alpha = 0.6f)
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "$${String.format("%.2f", receipt.netAmount)}",
                    fontWeight = FontWeight.Black,
                    color = BrandNavy,
                    fontSize = 16.sp
                )
                Text(
                    text = "${String.format("%.2f", receipt.gallons)} GAL",
                    fontSize = 11.sp,
                    color = BrandGraphite.copy(alpha = 0.5f)
                )
            }
        }
    }
}

@Composable
fun ReceiptDetailScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val receipt by viewModel.selectedReceipt.collectAsState()

    val current = receipt ?: return

    val sdf = SimpleDateFormat("EEEE, MMM dd, yyyy · hh:mm a", Locale.getDefault())
    val formattedDateTime = sdf.format(Date(current.dateTime))

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BrandNavy)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // --- Ticket Header Banner ---
        Text(
            text = "TRANSACTION SUCCESSFUL",
            color = BrandGreen,
            fontWeight = FontWeight.Black,
            fontSize = 16.sp,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        // --- Classical Paper Ticket rendering ---
        Card(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .border(2.dp, BrandSilver, RoundedCornerShape(8.dp)),
            shape = RoundedCornerShape(8.dp),
            colors = CardDefaults.cardColors(containerColor = BrandWhite)
        ) {
            Column(
                modifier = Modifier
                    .padding(24.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Brand logo on ticket
                Text(
                    text = "AMERICAN PETROLEUM",
                    fontWeight = FontWeight.Black,
                    fontSize = 18.sp,
                    color = BrandNavy,
                    letterSpacing = 1.sp,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "STATION ID: ${current.stationID}",
                    fontSize = 10.sp,
                    color = BrandGraphite.copy(alpha = 0.5f)
                )
                Text(
                    text = current.stationAddress,
                    fontSize = 11.sp,
                    color = BrandGraphite.copy(alpha = 0.6f),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(16.dp))
                Divider(color = BrandSilver, thickness = 1.dp)
                Spacer(modifier = Modifier.height(16.dp))

                // Line items
                TicketLineItem("RECEIPT ID", current.receiptID)
                TicketLineItem("TRANSACTION ID", current.transactionID)
                TicketLineItem("DATE & TIME", formattedDateTime)
                TicketLineItem("PUMP NUMBER", String.format("%02d", current.pumpNumber))
                TicketLineItem("FUEL TYPE", current.fuelGrade.uppercase())
                TicketLineItem("GALLONS", String.format("%.3f GAL", current.gallons))
                TicketLineItem("PRICE / GALLON", "$${String.format("%.3f", current.pricePerGallon)}")

                Spacer(modifier = Modifier.height(16.dp))
                Divider(color = BrandSilver, thickness = 1.dp)
                Spacer(modifier = Modifier.height(16.dp))

                // Financial details
                TicketLineItem("GROSS TOTAL", "$${String.format("%.2f", current.grossAmount)}")
                TicketLineItem("REWARDS DISCOUNTS", "-$${String.format("%.2f", current.discount)}", color = BrandGreen)
                
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "TOTAL CHARGED",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 16.sp,
                        color = BrandNavy
                    )
                    Text(
                        text = "$${String.format("%.2f", current.netAmount)}",
                        fontWeight = FontWeight.Black,
                        fontSize = 22.sp,
                        color = BrandNavy,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
                Divider(color = BrandSilver, thickness = 1.dp)
                Spacer(modifier = Modifier.height(16.dp))

                // Loyalty details
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BrandGreen.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "LOYALTY POINTS EARNED: +${current.rewardsEarned}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = BrandGreen
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "PAYMENT METHOD: ${current.paymentMethod.uppercase()}",
                    fontSize = 10.sp,
                    color = BrandGraphite.copy(alpha = 0.6f),
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Actions
        Row(
            modifier = Modifier.fillMaxWidth(0.92f),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedButton(
                onClick = { /* Share mock */ },
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = BrandWhite),
                border = BorderStroke(1.dp, BrandWhite),
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("SHARE", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = { viewModel.exitFlow() },
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BrandRed, contentColor = BrandWhite),
                modifier = Modifier.weight(1.2f).testTag("receipt_done_button")
            ) {
                Text("DONE", fontSize = 12.sp, fontWeight = FontWeight.Black)
            }
        }
    }
}

@Composable
fun TicketLineItem(
    label: String,
    value: String,
    color: Color = BrandNavy
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = FontWeight.Medium,
            color = BrandGraphite.copy(alpha = 0.5f)
        )
        Text(
            text = value,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = color,
            fontFamily = FontFamily.Monospace
        )
    }
}
