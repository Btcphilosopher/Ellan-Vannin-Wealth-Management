package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Station
import com.example.repository.AppRepository

@Composable
fun StationsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val stations by viewModel.filteredStations.collectAsState()
    val favorites by viewModel.favoriteStations.collectAsState()
    val selectedId by viewModel.selectedStationId.collectAsState()
    val selectedStation by viewModel.selectedStation.collectAsState()

    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedFuelFilter by viewModel.selectedFuelFilter.collectAsState()
    val selectedAmenities by viewModel.selectedAmenityFilter.collectAsState()
    val locationPermissionGranted by viewModel.locationPermissionGranted.collectAsState()
    val zipCode by viewModel.userZipCode.collectAsState()

    var activeTab by remember { mutableStateOf("LIST") } // "LIST" vs "MAP"
    var showFiltersDrawer by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BrandLightBg)
    ) {
        // --- Search bar & Mode toggler ---
        Surface(
            color = BrandNavy,
            contentColor = BrandWhite,
            tonalElevation = 4.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .padding(top = 8.dp, bottom = 12.dp)
            ) {
                // Search box
                TextField(
                    value = searchQuery,
                    onValueChange = { viewModel.updateSearchQuery(it) },
                    placeholder = { Text("Search city, ZIP, or station name...", color = BrandSilver.copy(alpha = 0.7f)) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .testTag("station_search_input"),
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = BrandWhite) },
                    trailingIcon = {
                        IconButton(onClick = { showFiltersDrawer = !showFiltersDrawer }) {
                            Icon(
                                Icons.Default.FilterList,
                                contentDescription = "Filter",
                                tint = if (selectedFuelFilter != null || selectedAmenities.isNotEmpty()) BrandRed else BrandWhite
                            )
                        }
                    },
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = BrandWhite.copy(alpha = 0.15f),
                        unfocusedContainerColor = BrandWhite.copy(alpha = 0.12f),
                        disabledContainerColor = BrandWhite.copy(alpha = 0.05f),
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        focusedTextColor = BrandWhite,
                        unfocusedTextColor = BrandWhite
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Location mode if permission is denied
                if (!locationPermissionGranted) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(BrandRed.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Location access denied. Please enter ZIP code:",
                            fontSize = 11.sp,
                            color = BrandWhite,
                            modifier = Modifier.weight(1f)
                        )
                        TextField(
                            value = zipCode,
                            onValueChange = { viewModel.searchByZipCode(it) },
                            placeholder = { Text("Zip Code", fontSize = 11.sp, color = BrandSilver) },
                            modifier = Modifier
                                .width(90.dp)
                                .height(36.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = BrandWhite,
                                unfocusedContainerColor = BrandWhite
                            )
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }

                // Tab Switcher (LIST vs MAP)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BrandWhite.copy(alpha = 0.1f), RoundedCornerShape(6.dp))
                        .padding(2.dp)
                ) {
                    TabToggleItem(
                        title = "List View",
                        active = activeTab == "LIST",
                        modifier = Modifier.weight(1f),
                        onClick = { activeTab = "LIST" }
                    )
                    TabToggleItem(
                        title = "Map View",
                        active = activeTab == "MAP",
                        modifier = Modifier.weight(1f),
                        onClick = { activeTab = "MAP" }
                    )
                }
            }
        }

        // --- Filters list panel (collapsible) ---
        AnimatedVisibility(visible = showFiltersDrawer) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BrandWhite)
                    .border(1.dp, BrandSilver)
                    .padding(16.dp)
            ) {
                Text("Fuel Grade Filter", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = BrandNavy)
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        FilterChip(
                            label = "Regular",
                            selected = selectedFuelFilter == "Regular",
                            onClick = { viewModel.toggleFuelFilter("Regular") }
                        )
                    }
                    item {
                        FilterChip(
                            label = "Premium",
                            selected = selectedFuelFilter == "Premium",
                            onClick = { viewModel.toggleFuelFilter("Premium") }
                        )
                    }
                    item {
                        FilterChip(
                            label = "Diesel",
                            selected = selectedFuelFilter == "Diesel",
                            onClick = { viewModel.toggleFuelFilter("Diesel") }
                        )
                    }
                    item {
                        FilterChip(
                            label = "E85",
                            selected = selectedFuelFilter == "E85",
                            onClick = { viewModel.toggleFuelFilter("E85") }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                Text("Amenities Filter", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = BrandNavy)
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val list = listOf("Car Wash", "Convenience Store", "ATM", "EV Charging")
                    list.forEach { amenity ->
                        FilterChip(
                            label = amenity,
                            selected = selectedAmenities.contains(amenity),
                            onClick = { viewModel.toggleAmenityFilter(amenity) }
                        )
                    }
                }
            }
        }

        // --- Content Area ---
        if (activeTab == "MAP") {
            Box(modifier = Modifier.weight(1f)) {
                // Mock Map View
                MockMapView(stations = stations, selectedId = selectedId, onStationSelected = { viewModel.selectStation(it.stationID) })

                // Selected station summary floating card
                selectedStation?.let { station ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomCenter)
                            .padding(16.dp)
                    ) {
                        StationListItemCard(
                            station = station,
                            isFavorite = favorites.any { it.stationID == station.stationID },
                            onFavoriteToggle = { viewModel.toggleStationFavorite(station.stationID) },
                            onClick = { /* Detail screen */ },
                            onPayAtPump = {
                                viewModel.selectStation(station.stationID)
                                viewModel.navigateTo(AppScreen.PUMP_SETUP)
                            }
                        )
                    }
                }
            }
        } else {
            // LIST Tab
            if (stations.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("No stations match your filters.", color = BrandGraphite.copy(alpha = 0.5f))
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            colors = ButtonDefaults.buttonColors(containerColor = BrandNavy),
                            onClick = {
                                viewModel.updateSearchQuery("")
                                viewModel.toggleFuelFilter(null)
                                // reset sets
                                viewModel.searchByZipCode("")
                            }
                        ) {
                            Text("Reset Filters")
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(vertical = 16.dp)
                ) {
                    items(stations) { station ->
                        StationListItemCard(
                            station = station,
                            isFavorite = favorites.any { it.stationID == station.stationID },
                            onFavoriteToggle = { viewModel.toggleStationFavorite(station.stationID) },
                            onClick = { viewModel.selectStation(station.stationID) },
                            onPayAtPump = {
                                viewModel.selectStation(station.stationID)
                                viewModel.navigateTo(AppScreen.PUMP_SETUP)
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TabToggleItem(
    title: String,
    active: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(if (active) BrandWhite else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = title,
            fontSize = 12.sp,
            fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
            color = if (active) BrandNavy else BrandWhite
        )
    }
}

@Composable
fun FilterChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .border(
                1.dp,
                if (selected) BrandRed else BrandSilver,
                RoundedCornerShape(16.dp)
            ),
        color = if (selected) BrandRed.copy(alpha = 0.1f) else BrandLightBg,
        contentColor = if (selected) BrandRed else BrandGraphite
    ) {
        Text(
            text = label,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun StationListItemCard(
    station: Station,
    isFavorite: Boolean,
    onFavoriteToggle: () -> Unit,
    onClick: () -> Unit,
    onPayAtPump: () -> Unit
) {
    val distance = AppRepository.calculateDistanceMiles(
        AppRepository.MOCK_USER_LAT,
        AppRepository.MOCK_USER_LON,
        station.latitude,
        station.longitude
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .border(1.dp, BrandSilver, RoundedCornerShape(12.dp)),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = BrandWhite)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = station.name,
                            fontWeight = FontWeight.Bold,
                            color = BrandNavy,
                            fontSize = 16.sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        IconButton(
                            onClick = onFavoriteToggle,
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                contentDescription = "Favorite",
                                tint = BrandRed,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                    Text(
                        text = "${station.address}, ${station.city}, ${station.state}",
                        fontSize = 12.sp,
                        color = BrandGraphite.copy(alpha = 0.6f)
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "${String.format("%.1f", distance)} MI",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black,
                        color = BrandBlue
                    )
                    Text(
                        text = station.status,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (station.status == "OPEN") BrandGreen else BrandRed
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Divider(color = BrandSilver)
            Spacer(modifier = Modifier.height(10.dp))

            // Fuel Pricing blocks
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SmallFuelPriceBox("REGULAR", station.regPrice, modifier = Modifier.weight(1f))
                SmallFuelPriceBox("PREMIUM", station.premPrice, modifier = Modifier.weight(1f))
                if (station.dieselPrice > 0) {
                    SmallFuelPriceBox("DIESEL", station.dieselPrice, modifier = Modifier.weight(1f))
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            
            // Amenities tags preview
            Text(
                text = "Amenities: ${station.amenities}",
                fontSize = 11.sp,
                color = BrandGraphite.copy(alpha = 0.5f),
                maxLines = 1
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Directions button
                OutlinedButton(
                    onClick = { /* Nav launcher */ },
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = BrandNavy),
                    border = BorderStroke(1.dp, BrandNavy)
                ) {
                    Icon(Icons.Default.Directions, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("MAP & NAV", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                // Pay At Pump direct button
                Button(
                    onClick = onPayAtPump,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.weight(1.2f),
                    colors = ButtonDefaults.buttonColors(containerColor = BrandRed, contentColor = BrandWhite)
                ) {
                    Text("PAY AT PUMP", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                }
            }
        }
    }
}

@Composable
fun SmallFuelPriceBox(label: String, price: Double, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(BrandLightBg, RoundedCornerShape(4.dp))
            .padding(vertical = 4.dp, horizontal = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(label, fontSize = 8.sp, color = BrandGraphite.copy(alpha = 0.5f), fontWeight = FontWeight.Bold)
        Text("$${String.format("%.3f", price)}", fontSize = 13.sp, fontWeight = FontWeight.Black, color = BrandNavy)
    }
}

@Composable
fun MockMapView(
    stations: List<Station>,
    selectedId: String?,
    onStationSelected: (Station) -> Unit,
    modifier: Modifier = Modifier
) {
    // Elegant pulsing animation for the user's location pin
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseSize by infiniteTransition.animateFloat(
        initialValue = 10f,
        targetValue = 28f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFE9ECEF))
    ) {
        Canvas(modifier = Modifier.fillMaxSize().clickable { /* Clear focus */ }) {
            val width = size.width
            val height = size.height

            // 1. Draw grids representing a modern navigation map
            val gridSpacing = 120f
            for (x in 0..(width / gridSpacing).toInt()) {
                drawLine(
                    color = BrandSilver,
                    start = Offset(x * gridSpacing, 0f),
                    end = Offset(x * gridSpacing, height),
                    strokeWidth = 2f
                )
            }
            for (y in 0..(height / gridSpacing).toInt()) {
                drawLine(
                    color = BrandSilver,
                    start = Offset(0f, y * gridSpacing),
                    end = Offset(width, y * gridSpacing),
                    strokeWidth = 2f
                )
            }

            // 2. Draw mock highway/roads
            drawLine(
                color = BrandWhite,
                start = Offset(0f, height * 0.4f),
                end = Offset(width, height * 0.4f),
                strokeWidth = 32f
            )
            drawLine(
                color = BrandWhite,
                start = Offset(width * 0.5f, 0f),
                end = Offset(width * 0.5f, height),
                strokeWidth = 24f
            )

            // 3. Draw user's central location (Dallas coordinates mock)
            val userX = width * 0.5f
            val userY = height * 0.5f

            // Pulsing radar ripple
            drawCircle(
                color = BrandBlue.copy(alpha = 0.2f),
                radius = pulseSize * 1.5f,
                center = Offset(userX, userY)
            )

            // Outer dark blue ring
            drawCircle(
                color = BrandWhite,
                radius = 10f,
                center = Offset(userX, userY)
            )

            // Inner solid location dot
            drawCircle(
                color = BrandBlue,
                radius = 6f,
                center = Offset(userX, userY)
            )
        }

        // 4. Overlap station markers as clickable absolute components
        stations.take(15).forEachIndexed { index, station ->
            // Map synthetic geo coordinates around user Dallas center to screen coordinates
            // user lat/lon: 32.7767, -96.7970
            // stations relative offset
            val latDiff = station.latitude - AppRepository.MOCK_USER_LAT
            val lonDiff = station.longitude - AppRepository.MOCK_USER_LON

            // Scaling coordinates relative to center
            val screenXOffset = (lonDiff * 8000f).toFloat()
            val screenYOffset = -(latDiff * 8000f).toFloat() // Inverted Y-axis

            Box(
                modifier = Modifier
                    .offset(
                        x = 180.dp + screenXOffset.dp,
                        y = 250.dp + screenYOffset.dp
                    )
            ) {
                val isSelected = station.stationID == selectedId
                Box(
                    modifier = Modifier
                        .size(if (isSelected) 36.dp else 24.dp)
                        .clip(CircleShape)
                        .background(if (isSelected) BrandRed else BrandNavy)
                        .border(2.dp, BrandWhite, CircleShape)
                        .clickable { onStationSelected(station) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "AP",
                        fontSize = if (isSelected) 10.sp else 8.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = BrandWhite
                    )
                }
            }
        }
    }
}
