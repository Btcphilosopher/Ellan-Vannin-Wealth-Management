package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.DriveEta
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.FuelGrade
import com.example.model.Station

@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val currentStation by viewModel.selectedStation.collectAsState()
    val rewardsAccount by viewModel.rewardsAccount.collectAsState()
    val vehicles by viewModel.vehicles.collectAsState()
    val receipts by viewModel.receipts.collectAsState()

    // Default mock distance is 0.7 mi for Dallas North station
    val nearestStation = currentStation ?: Station(
        stationID = "TX00142",
        name = "American Petroleum Dallas North",
        address = "7420 Dallas Parkway",
        city = "Dallas",
        state = "TX",
        zip = "75201",
        latitude = 32.7867,
        longitude = -96.7970,
        openingHours = "24 Hours",
        phone = "(214) 555-0142",
        amenities = "Convenience Store, Car Wash, Restroom, Air, Vacuum, ATM",
        priceUpdatedAt = System.currentTimeMillis() - 480000,
        status = "OPEN",
        regPrice = 3.199,
        midPrice = 3.399,
        premPrice = 3.599,
        dieselPrice = 3.749,
        e85Price = 2.899
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BrandLightBg)
            .verticalScroll(rememberScrollState())
    ) {
        // --- Industrial Hero Header ---
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(BrandNavy)
                .padding(vertical = 24.dp, horizontal = 16.dp)
        ) {
            Column {
                Text(
                    text = "AMERICAN PETROLEUM",
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Black,
                    color = BrandWhite,
                    letterSpacing = 1.5.sp
                )
                Text(
                    text = "Good morning, Tom",
                    fontSize = 16.sp,
                    color = BrandWhite.copy(alpha = 0.7f),
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }

        Column(modifier = Modifier.padding(16.dp)) {
            // --- Quick Actions ---
            SectionHeader("Quick Actions")
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                QuickActionItem(
                    title = "Find Gas",
                    icon = Icons.Default.Directions,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.navigateTo(AppScreen.STATIONS) },
                    testTag = "action_find_gas"
                )
                QuickActionItem(
                    title = "Pay At Pump",
                    icon = Icons.Default.Payment,
                    modifier = Modifier.weight(1f),
                    onClick = {
                        viewModel.selectStation(nearestStation.stationID)
                        viewModel.navigateTo(AppScreen.PUMP_SETUP)
                    },
                    testTag = "action_pay_at_pump"
                )
                QuickActionItem(
                    title = "Rewards",
                    icon = Icons.Default.Star,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.navigateTo(AppScreen.REWARDS) },
                    testTag = "action_rewards"
                )
                QuickActionItem(
                    title = "Receipts",
                    icon = Icons.Default.ReceiptLong,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.navigateTo(AppScreen.RECEIPTS) },
                    testTag = "action_receipts"
                )
            }

            // --- Nearest Station Card ---
            SectionHeader("Your Nearest Station")
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
                    .border(1.dp, BrandSilver, RoundedCornerShape(12.dp)),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = BrandWhite)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = nearestStation.name,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = BrandNavy
                                )
                            )
                            Text(
                                text = "${nearestStation.address}, ${nearestStation.city}",
                                fontSize = 12.sp,
                                color = BrandGraphite.copy(alpha = 0.6f)
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "0.7 MI",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                color = BrandBlue
                            )
                            Text(
                                text = nearestStation.status,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (nearestStation.status == "OPEN") BrandGreen else BrandRed
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Divider(color = BrandSilver)
                    Spacer(modifier = Modifier.height(12.dp))

                    // Fuel prices blocks
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        FuelPriceBlock("Regular", nearestStation.regPrice)
                        FuelPriceBlock("Plus", nearestStation.midPrice)
                        FuelPriceBlock("Premium", nearestStation.premPrice)
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    PrimaryActionButton(
                        text = "Pay At Pump",
                        onClick = {
                            viewModel.selectStation(nearestStation.stationID)
                            viewModel.navigateTo(AppScreen.PUMP_SETUP)
                        },
                        testTag = "pay_at_pump_home_button"
                    )
                }
            }

            // --- Rewards Card ---
            SectionHeader("Your Rewards")
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
                    .clickable { viewModel.navigateTo(AppScreen.REWARDS) }
                    .border(1.dp, BrandSilver, RoundedCornerShape(12.dp)),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = BrandWhite)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "AMERICAN REWARDS",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = BrandNavy,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "${rewardsAccount?.pointsBalance ?: 0} POINTS",
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Black,
                                color = BrandRed
                            )
                        }
                        Text(
                            text = "$${String.format("%.2f", rewardsAccount?.availableRewardDollars ?: 0.0)} AVAILABLE",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = BrandGreen
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Progress to next $5 reward",
                        fontSize = 11.sp,
                        color = BrandGraphite.copy(alpha = 0.6f)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    
                    // Simple progress bar toward 1500 points
                    val currentPoints = rewardsAccount?.pointsBalance ?: 0
                    val progressFraction = (currentPoints % 500).toFloat() / 500f
                    LinearProgressIndicator(
                        progress = { progressFraction },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = BrandRed,
                        trackColor = BrandSilver
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Tap to view rewards ledger & campaigns >",
                        fontSize = 12.sp,
                        color = BrandBlue,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // --- Vehicle / Last Fill Double Row ---
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Garage item
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { viewModel.navigateTo(AppScreen.VEHICLE_GARAGE) }
                        .border(1.dp, BrandSilver, RoundedCornerShape(12.dp)),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = BrandWhite)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Icon(
                            imageVector = Icons.Default.DriveEta,
                            contentDescription = null,
                            tint = BrandNavy,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "YOUR VEHICLE",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = BrandGraphite.copy(alpha = 0.5f)
                        )
                        val primaryVehicle = vehicles.firstOrNull()
                        Text(
                            text = primaryVehicle?.let { "${it.make} ${it.model}" } ?: "Add Vehicle",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = BrandNavy
                        )
                        Text(
                            text = primaryVehicle?.fuelType ?: "Tap to configure",
                            fontSize = 11.sp,
                            color = BrandGraphite.copy(alpha = 0.6f)
                        )
                    }
                }

                // Last Fill item
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { viewModel.navigateTo(AppScreen.RECEIPTS) }
                        .border(1.dp, BrandSilver, RoundedCornerShape(12.dp)),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = BrandWhite)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Icon(
                            imageVector = Icons.Default.LocalGasStation,
                            contentDescription = null,
                            tint = BrandBlue,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "LAST FILL",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = BrandGraphite.copy(alpha = 0.5f)
                        )
                        val lastReceipt = receipts.firstOrNull()
                        Text(
                            text = lastReceipt?.let { "${String.format("%.1f", it.gallons)} GAL" } ?: "No Fills",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = BrandNavy
                        )
                        Text(
                            text = lastReceipt?.let { "$${String.format("%.2f", it.netAmount)}" } ?: "Tap to start",
                            fontSize = 11.sp,
                            color = BrandGraphite.copy(alpha = 0.6f)
                        )
                        if (lastReceipt != null) {
                            Text(
                                text = "+${lastReceipt.rewardsEarned} PTS",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = BrandGreen
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun QuickActionItem(
    title: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = ""
) {
    Card(
        modifier = modifier
            .testTag(testTag)
            .clickable(onClick = onClick)
            .border(1.dp, BrandSilver, RoundedCornerShape(8.dp)),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = BrandWhite)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = BrandNavy,
                modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = title.uppercase(),
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = BrandNavy,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun FuelPriceBlock(grade: String, price: Double) {
    Column(
        modifier = Modifier
            .background(BrandLightBg, RoundedCornerShape(6.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = grade.uppercase(),
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = BrandGraphite.copy(alpha = 0.6f)
        )
        Text(
            text = "$${String.format("%.3f", price)}",
            fontSize = 16.sp,
            fontWeight = FontWeight.Black,
            color = BrandNavy
        )
        Text(
            text = "PER GAL",
            fontSize = 8.sp,
            color = BrandGraphite.copy(alpha = 0.5f)
        )
    }
}
