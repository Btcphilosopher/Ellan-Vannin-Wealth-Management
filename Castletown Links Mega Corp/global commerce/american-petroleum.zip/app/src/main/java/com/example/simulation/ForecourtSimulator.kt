package com.example.simulation

import com.example.model.FuelGrade
import com.example.model.PumpSessionStatus
import java.math.BigDecimal
import java.math.RoundingMode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class NozzleState {
    RETURNED, LIFTED, DISPENSING, STOPPED
}

data class SimulatorState(
    val sessionID: String = "",
    val stationID: String = "",
    val pumpNumber: Int = 1,
    val selectedGrade: FuelGrade? = null,
    val pricePerGallon: BigDecimal = BigDecimal.ZERO,
    val presetLimitAmount: BigDecimal = BigDecimal.ZERO, // BigDecimal.ZERO for unlimited/full tank
    val isFullTank: Boolean = false,
    val dispensedGallons: BigDecimal = BigDecimal.ZERO,
    val currentAmount: BigDecimal = BigDecimal.ZERO,
    val flowRateGPM: BigDecimal = BigDecimal("8.2"), // 8.2 gallons per minute
    val nozzleState: NozzleState = NozzleState.RETURNED,
    val sessionStatus: PumpSessionStatus = PumpSessionStatus.CREATED,
    val estimatedSavings: BigDecimal = BigDecimal.ZERO,
    val rewardsPointsEarned: Int = 0
)

class ForecourtSimulator {
    private val _state = MutableStateFlow(SimulatorState())
    val state: StateFlow<SimulatorState> = _state.asStateFlow()

    private val scope = CoroutineScope(Dispatchers.Default)
    private var simulationJob: Job? = null

    fun reset() {
        simulationJob?.cancel()
        simulationJob = null
        _state.value = SimulatorState()
    }

    fun startSession(
        sessionID: String,
        stationID: String,
        pumpNumber: Int,
        grade: FuelGrade,
        price: Double,
        presetAmount: Double,
        isFullTank: Boolean,
        savingsPerGal: Double
    ) {
        reset()
        val priceBD = BigDecimal(price).setScale(3, RoundingMode.HALF_UP)
        val limitBD = if (isFullTank) BigDecimal.ZERO else BigDecimal(presetAmount).setScale(2, RoundingMode.HALF_UP)
        
        _state.value = SimulatorState(
            sessionID = sessionID,
            stationID = stationID,
            pumpNumber = pumpNumber,
            selectedGrade = grade,
            pricePerGallon = priceBD,
            presetLimitAmount = limitBD,
            isFullTank = isFullTank,
            nozzleState = NozzleState.RETURNED,
            sessionStatus = PumpSessionStatus.AUTHORISED,
            estimatedSavings = BigDecimal(savingsPerGal).setScale(2, RoundingMode.HALF_UP)
        )
    }

    fun liftNozzle() {
        val current = _state.value
        if (current.sessionStatus == PumpSessionStatus.AUTHORISED || current.sessionStatus == PumpSessionStatus.READY_TO_FUEL) {
            _state.value = current.copy(
                nozzleState = NozzleState.LIFTED,
                sessionStatus = PumpSessionStatus.READY_TO_FUEL
            )
        }
    }

    fun squeezeTrigger() {
        val current = _state.value
        if (current.nozzleState == NozzleState.LIFTED || current.nozzleState == NozzleState.STOPPED) {
            _state.value = current.copy(
                nozzleState = NozzleState.DISPENSING,
                sessionStatus = PumpSessionStatus.FUELLING
            )
            startFlowTimer()
        }
    }

    fun releaseTrigger() {
        val current = _state.value
        if (current.nozzleState == NozzleState.DISPENSING) {
            simulationJob?.cancel()
            _state.value = current.copy(
                nozzleState = NozzleState.STOPPED,
                sessionStatus = PumpSessionStatus.STOPPED
            )
        }
    }

    fun returnNozzle() {
        val current = _state.value
        simulationJob?.cancel()
        if (current.sessionStatus == PumpSessionStatus.STOPPED || current.sessionStatus == PumpSessionStatus.FUELLING || current.sessionStatus == PumpSessionStatus.READY_TO_FUEL) {
            _state.value = current.copy(
                nozzleState = NozzleState.RETURNED,
                sessionStatus = PumpSessionStatus.FINALISING
            )
        }
    }

    fun setStatus(status: PumpSessionStatus) {
        _state.value = _state.value.copy(sessionStatus = status)
    }

    private fun startFlowTimer() {
        simulationJob?.cancel()
        simulationJob = scope.launch {
            val stepMs = 500L
            val flowRatePerSec = _state.value.flowRateGPM.divide(BigDecimal("60"), 6, RoundingMode.HALF_UP)
            val flowRatePerStep = flowRatePerSec.multiply(BigDecimal(stepMs).divide(BigDecimal("1000"), 6, RoundingMode.HALF_UP))

            while (_state.value.nozzleState == NozzleState.DISPENSING) {
                delay(stepMs)
                val current = _state.value
                val newGallons = current.dispensedGallons.add(flowRatePerStep).setScale(4, RoundingMode.HALF_UP)
                
                // Calculate gross amount
                var newAmount = newGallons.multiply(current.pricePerGallon).setScale(2, RoundingMode.HALF_UP)
                
                // Check limit
                var shouldStop = false
                if (!current.isFullTank && current.presetLimitAmount > BigDecimal.ZERO) {
                    if (newAmount >= current.presetLimitAmount) {
                        newAmount = current.presetLimitAmount
                        // Recalculate exact gallons based on max amount limit
                        val exactGallons = current.presetLimitAmount.divide(current.pricePerGallon, 4, RoundingMode.HALF_DOWN)
                        _state.value = current.copy(
                            dispensedGallons = exactGallons,
                            currentAmount = newAmount,
                            nozzleState = NozzleState.STOPPED,
                            sessionStatus = PumpSessionStatus.STOPPED,
                            rewardsPointsEarned = exactGallons.setScale(0, RoundingMode.FLOOR).toInt()
                        )
                        shouldStop = true
                    }
                }

                if (!shouldStop) {
                    val pts = newGallons.setScale(0, RoundingMode.FLOOR).toInt()
                    _state.value = current.copy(
                        dispensedGallons = newGallons,
                        currentAmount = newAmount,
                        rewardsPointsEarned = pts
                    )
                }

                if (shouldStop) {
                    break
                }
            }
        }
    }
}
