package com.example.model

import java.math.BigDecimal
import java.math.RoundingMode

object RewardsRulesEngine {
    
    // Constant loyalty ratios
    const val POINTS_PER_GALLON = 1
    const val POINTS_TO_DOLLAR_RATIO = 100 // 100 points = $1.00

    /**
     * Calculates the total stacked discount (cents per gallon) for a fuel purchase.
     * Enforces rules around:
     * - Stacking policy ("STACKABLE" vs "NON_STACKABLE")
     * - Eligible fuel grades
     * - Eligible stations
     * - Start and end dates
     */
    fun calculateEffectiveDiscount(
        fuelGrade: FuelGrade,
        stationID: String,
        availableOffers: List<RewardOffer>,
        redeemRewardDollars: Double = 0.0
    ): Double {
        val now = System.currentTimeMillis()
        
        // 1. Filter valid offers based on time, fuel grade, and station eligibility
        val validOffers = availableOffers.filter { offer ->
            val isTimeValid = now in offer.startAt..offer.endAt
            val isFuelEligible = offer.eligibleFuel == "ANY" || offer.eligibleFuel.uppercase() == fuelGrade.name.uppercase()
            val isStationEligible = offer.eligibleStation == "ANY" || offer.eligibleStation == stationID
            isTimeValid && isFuelEligible && isStationEligible && offer.discountType == "CENTS_PER_GAL"
        }

        // 2. Separate stackable and non-stackable offers
        val stackableOffers = validOffers.filter { it.stackingPolicy == "STACKABLE" }
        val nonStackableOffers = validOffers.filter { it.stackingPolicy == "NON_STACKABLE" }

        // 3. Sum all stackable cents-per-gallon discounts
        var stackedDiscount = stackableOffers.sumOf { it.discountValue }

        // 4. Compare with the highest single non-stackable discount
        val maxNonStackable = nonStackableOffers.maxOfOrNull { it.discountValue } ?: 0.0
        
        // Final promotional discount rate
        var promoDiscount = maxOf(stackedDiscount, maxNonStackable)

        // 5. Add standard member discount if no better promo applies, or as a base (e.g. 5 cents base)
        // Let's assume member discount is 5 cents standard ($0.05) if the user has no other greater discount.
        // We can treat it as a stackable base of $0.05
        val baseMemberDiscount = 0.05
        promoDiscount += baseMemberDiscount

        // 6. Add reward dollars redemption converted to cents-per-gallon discount
        // Say, if redeeming $10.00 rewards on a standard 20-gallon limit, it acts as an additional discount or absolute savings.
        // For pay-at-pump, we can stack the cents-per-gallon or apply the rewards at the end of the transaction.
        // Let's stack the cents-per-gallon based on a typical fill size of 15 gallons for authorization, or apply it directly to net amount!
        // To keep it simple, cents-per-gallon discounts apply at the pump price, and reward point dollars are deducted from final net amount.
        
        return promoDiscount
    }

    /**
     * Calculates the net pricing and points earned for a completed fill.
     */
    fun finalizeTransaction(
        gallons: Double,
        pricePerGallon: Double,
        discountPerGallon: Double,
        redeemedRewardsDollars: Double
    ): TransactionResult {
        val gallonsBD = BigDecimal(gallons).setScale(4, RoundingMode.HALF_UP)
        val ppgBD = BigDecimal(pricePerGallon).setScale(3, RoundingMode.HALF_UP)
        val discountBD = BigDecimal(discountPerGallon).setScale(3, RoundingMode.HALF_UP)
        val redeemedDollarsBD = BigDecimal(redeemedRewardsDollars).setScale(2, RoundingMode.HALF_UP)

        // Gross = Gallons * PPG
        val grossBD = gallonsBD.multiply(ppgBD).setScale(2, RoundingMode.HALF_UP)

        // Savings = Gallons * DiscountPerGallon
        val fuelSavingsBD = gallonsBD.multiply(discountBD).setScale(2, RoundingMode.HALF_UP)

        // Net before reward dollars
        var netBD = grossBD.subtract(fuelSavingsBD)

        // Apply direct reward dollars deduction
        if (netBD > redeemedDollarsBD) {
            netBD = netBD.subtract(redeemedDollarsBD).setScale(2, RoundingMode.HALF_UP)
        } else {
            netBD = BigDecimal.ZERO
        }

        // Points earned: 1 point per gallon (rounded down)
        val pointsEarned = gallonsBD.setScale(0, RoundingMode.FLOOR).toInt() * POINTS_PER_GALLON

        return TransactionResult(
            grossAmount = grossBD.toDouble(),
            totalSavings = fuelSavingsBD.add(redeemedDollarsBD).toDouble(),
            netAmount = netBD.toDouble(),
            pointsEarned = pointsEarned
        )
    }
}

data class TransactionResult(
    val grossAmount: Double,
    val totalSavings: Double,
    val netAmount: Double,
    val pointsEarned: Int
)
