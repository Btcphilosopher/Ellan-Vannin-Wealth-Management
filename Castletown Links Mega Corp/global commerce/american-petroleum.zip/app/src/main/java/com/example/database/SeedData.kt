package com.example.database

import com.example.model.*
import kotlin.random.Random

object SeedData {
    // Current user mock location (Dallas, TX)
    const val MOCK_USER_LAT = 32.7767
    const val MOCK_USER_LON = -96.7970

    val STATES = listOf(
        StateConfig("TX", "Texas", 26.0, 34.0, -106.0, -94.0),
        StateConfig("CA", "California", 32.0, 42.0, -124.0, -114.0),
        StateConfig("FL", "Florida", 25.0, 31.0, -87.0, -80.0),
        StateConfig("NY", "New York", 40.0, 45.0, -79.0, -72.0),
        StateConfig("PA", "Pennsylvania", 39.7, 42.0, -80.5, -74.7),
        StateConfig("OH", "Ohio", 38.4, 41.9, -84.8, -80.5),
        StateConfig("IL", "Illinois", 37.0, 42.5, -91.5, -87.5),
        StateConfig("GA", "Georgia", 30.3, 35.0, -85.6, -80.8),
        StateConfig("AZ", "Arizona", 31.3, 37.0, -114.8, -109.0),
        StateConfig("CO", "Colorado", 37.0, 41.0, -109.0, -102.0),
        StateConfig("NC", "North Carolina", 33.8, 36.6, -84.3, -75.4),
        StateConfig("TN", "Tennessee", 35.0, 36.7, -90.3, -81.6),
        StateConfig("VA", "Virginia", 36.5, 39.5, -83.7, -75.2),
        StateConfig("MI", "Michigan", 41.7, 47.5, -90.4, -82.4)
    )

    data class StateConfig(
        val code: String,
        val name: String,
        val minLat: Double,
        val maxLat: Double,
        val minLon: Double,
        val maxLon: Double
    )

    private val CITIES_BY_STATE = mapOf(
        "TX" to listOf("Dallas", "Houston", "Austin", "San Antonio", "Fort Worth", "El Paso"),
        "CA" to listOf("Los Angeles", "San Francisco", "San Diego", "Sacramento", "San Jose"),
        "FL" to listOf("Miami", "Orlando", "Tampa", "Jacksonville", "Tallahassee"),
        "NY" to listOf("New York City", "Buffalo", "Rochester", "Syracuse", "Albany"),
        "PA" to listOf("Philadelphia", "Pittsburgh", "Allentown", "Erie"),
        "OH" to listOf("Columbus", "Cleveland", "Cincinnati", "Toledo"),
        "IL" to listOf("Chicago", "Springfield", "Peoria", "Rockford"),
        "GA" to listOf("Atlanta", "Savannah", "Augusta", "Columbus"),
        "AZ" to listOf("Phoenix", "Tucson", "Mesa", "Chandler"),
        "CO" to listOf("Denver", "Colorado Springs", "Aurora", "Fort Collins"),
        "NC" to listOf("Charlotte", "Raleigh", "Greensboro", "Durham"),
        "TN" to listOf("Nashville", "Memphis", "Knoxville", "Chattanooga"),
        "VA" to listOf("Richmond", "Virginia Beach", "Norfolk", "Alexandria"),
        "MI" to listOf("Detroit", "Grand Rapids", "Lansing", "Ann Arbor")
    )

    private val STREET_NAMES = listOf(
        "Main St", "Broadway", "Oak Ave", "Pine St", "Maple Dr", "Washington Blvd",
        "Elm St", "Cedar Rd", "Hillside Ave", "Northwest Hwy", "Commerce St", "Industrial Blvd"
    )

    fun generateStations(): List<Station> {
        val list = ArrayList<Station>()
        val random = Random(42) // Deterministic random seed

        // 1. First, create the exact master demonstration station:
        // Name: American Petroleum Dallas North
        // ID: TX00142
        // Location: Exactly Lat 32.7867, Lon -96.7970. Since mock user is 32.7767, -96.7970,
        // the difference is exactly +0.01 Lat, which is roughly 0.69 miles (rounded to 0.7 mi).
        val dallasNorth = Station(
            stationID = "TX00142",
            name = "American Petroleum Dallas North",
            address = "7420 Dallas Parkway",
            city = "Dallas",
            state = "TX",
            zip = "75201",
            latitude = 32.7867,
            longitude = -96.7970,
            openingHours = "24 Hours",
            phone = "(214) 555-0142",
            amenities = "Convenience Store, Car Wash, Restroom, Air, Vacuum, ATM, Food",
            priceUpdatedAt = System.currentTimeMillis() - 480000, // 8 minutes ago
            status = "OPEN",
            regPrice = 3.199,
            midPrice = 3.399,
            premPrice = 3.599,
            dieselPrice = 3.749,
            e85Price = 2.899,
            provenance = DataProvenance.SYNTHETIC
        )
        list.add(dallasNorth)

        // 2. Generate the remaining 499 stations
        for (i in 2..500) {
            val stateCfg = STATES[random.nextInt(STATES.size)]
            val cities = CITIES_BY_STATE[stateCfg.code] ?: listOf("Central City")
            val city = cities[random.nextInt(cities.size)]
            val id = "${stateCfg.code}${String.format("%05d", i)}"
            
            // Randomly place coordinates in state bounds
            val lat = random.nextDouble(stateCfg.minLat, stateCfg.maxLat)
            val lon = random.nextDouble(stateCfg.minLon, stateCfg.maxLon)
            
            val streetNum = random.nextInt(100, 9999)
            val street = STREET_NAMES[random.nextInt(STREET_NAMES.size)]
            val address = "$streetNum $street"
            val zip = String.format("%05d", random.nextInt(10000, 99999))
            
            // Generate realistic fuel prices with small random variations (e.g. baseline Regular $3.00 - $3.60)
            val baseReg = 3.00 + random.nextDouble(0.0, 0.60)
            val reg = Math.round(baseReg * 1000.0) / 1000.0
            val mid = Math.round((reg + 0.20) * 1000.0) / 1000.0
            val prem = Math.round((reg + 0.40) * 1000.0) / 1000.0
            val diesel = Math.round((reg + 0.55) * 1000.0) / 1000.0
            val e85 = Math.round((reg - 0.30) * 1000.0) / 1000.0

            val possibleAmenities = listOf("Convenience Store", "Restroom", "Air", "Vacuum", "ATM", "Car Wash", "Food", "Truck Diesel", "EV Charging")
            val stationAmenities = possibleAmenities.filter { random.nextDouble() > 0.4 }
            val amenitiesString = if (stationAmenities.isEmpty()) "Convenience Store" else stationAmenities.joinToString(", ")

            list.add(
                Station(
                    stationID = id,
                    name = "American Petroleum $city ${street.replace(" St", "").replace(" Ave", "")}",
                    address = address,
                    city = city,
                    state = stateCfg.code,
                    zip = zip,
                    latitude = lat,
                    longitude = lon,
                    openingHours = if (random.nextBoolean()) "24 Hours" else "6:00 AM - 11:00 PM",
                    phone = "(${random.nextInt(200, 999)}) 555-${String.format("%04d", random.nextInt(1000))}",
                    amenities = amenitiesString,
                    priceUpdatedAt = System.currentTimeMillis() - random.nextLong(60000, 7200000), // 1 min to 2 hours ago
                    status = "OPEN",
                    regPrice = reg,
                    midPrice = mid,
                    premPrice = prem,
                    dieselPrice = diesel,
                    e85Price = e85,
                    provenance = DataProvenance.SYNTHETIC
                )
            )
        }
        return list
    }

    fun getSeedPaymentMethods(): List<PaymentMethod> {
        return listOf(
            PaymentMethod(
                id = "pm_google_pay",
                type = "GOOGLE_PAY",
                displayName = "Google Pay",
                token = "token_gpay_9812487"
            ),
            PaymentMethod(
                id = "pm_visa_4821",
                type = "CARD",
                displayName = "VISA •••• 4821",
                token = "token_visa_4821"
            )
        )
    }

    fun getSeedVehicles(): List<Vehicle> {
        return listOf(
            Vehicle(
                id = 1,
                make = "Ford",
                model = "F-150",
                year = 2023,
                fuelType = "Gasoline",
                tankCapacity = 36.0,
                fuelEconomy = 21.0,
                nickname = "My Truck"
            )
        )
    }

    fun getSeedOffers(): List<RewardOffer> {
        val now = System.currentTimeMillis()
        val oneDay = 24 * 60 * 60 * 1000L
        return listOf(
            RewardOffer(
                offerID = "off_member_disc",
                title = "Member Fuel Discount",
                description = "Save 5¢ per gallon on any fuel purchase as a rewards member.",
                discountType = "CENTS_PER_GAL",
                discountValue = 0.05,
                startAt = now - oneDay,
                endAt = now + 30 * oneDay,
                eligibleFuel = "ANY"
            ),
            RewardOffer(
                offerID = "off_premium_boost",
                title = "Premium Power Offer",
                description = "Get 10¢ off per gallon when you fill up with Premium.",
                discountType = "CENTS_PER_GAL",
                discountValue = 0.10,
                startAt = now - oneDay,
                endAt = now + 10 * oneDay,
                eligibleFuel = "PREMIUM"
            ),
            RewardOffer(
                offerID = "off_double_points",
                title = "2x Points Weekend",
                description = "Earn double rewards points on any gasoline purchase.",
                discountType = "BONUS_POINTS",
                discountValue = 2.0, // 2x multiplier
                startAt = now - oneDay,
                endAt = now + 3 * oneDay,
                eligibleFuel = "ANY"
            ),
            RewardOffer(
                offerID = "off_expired_co",
                title = "Special Summer Bonus",
                description = "Save 20¢/gal on fuel. Expired offer example.",
                discountType = "CENTS_PER_GAL",
                discountValue = 0.20,
                startAt = now - 10 * oneDay,
                endAt = now - oneDay, // Expired
                eligibleFuel = "ANY"
            )
        )
    }

    fun getSeedRewardsAccount(): RewardsAccount {
        return RewardsAccount(
            customerID = "cust_991824",
            pointsBalance = 1240,
            availableRewardDollars = 12.40
        )
    }

    fun getSeedLedgerEntries(): List<RewardsLedgerEntry> {
        val baseTime = System.currentTimeMillis() - 2 * 24 * 60 * 60 * 1000L
        return listOf(
            RewardsLedgerEntry(
                id = "led_1",
                customerID = "cust_991824",
                transactionID = "tx_901182",
                points = 18,
                type = "EARNED",
                timestamp = baseTime,
                description = "Fuel Fill (Regular, 18.2 GAL)",
                balanceAfter = 1240
            ),
            RewardsLedgerEntry(
                id = "led_2",
                customerID = "cust_991824",
                transactionID = null,
                points = -500,
                type = "REDEEMED",
                timestamp = baseTime - 4 * 3600000,
                description = "Redeemed $5.00 Fuel Reward",
                balanceAfter = 1222
            )
        )
    }

    fun getSeedReceipts(): List<Receipt> {
        val baseTime = System.currentTimeMillis() - 2 * 24 * 60 * 60 * 1000L
        return listOf(
            Receipt(
                receiptID = "rec_901182",
                transactionID = "tx_901182",
                stationID = "TX00142",
                stationName = "American Petroleum Dallas North",
                stationAddress = "7420 Dallas Parkway",
                pumpNumber = 7,
                dateTime = baseTime,
                fuelGrade = "Regular",
                gallons = 18.7,
                pricePerGallon = 3.199,
                grossAmount = 59.82,
                discount = 0.17,
                netAmount = 59.65,
                rewardsEarned = 59,
                paymentMethod = "VISA •••• 4821"
            )
        )
    }
}
