package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DataProvenance

// --- Theme Brand Colors ---
val BrandNavy = Color(0xFF0A1E3F)
val BrandWhite = Color(0xFFFFFFFF)
val BrandGraphite = Color(0xFF212529)
val BrandSilver = Color(0xFFDEE2E6)
val BrandLightBg = Color(0xFFF4F6F8)
val BrandRed = Color(0xFFD92525)
val BrandBlue = Color(0xFF1B64A3)
val BrandGreen = Color(0xFF2B8A3E)

@Composable
fun PrimaryActionButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    containerColor: Color = BrandRed,
    contentColor: Color = BrandWhite,
    testTag: String = ""
) {
    Button(
        onClick = onClick,
        modifier = modifier
            .fillMaxWidth()
            .height(54.dp)
            .testTag(testTag),
        enabled = enabled,
        shape = RoundedCornerShape(8.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = containerColor,
            contentColor = contentColor,
            disabledContainerColor = BrandSilver,
            disabledContentColor = BrandGraphite.copy(alpha = 0.5f)
        )
    ) {
        Text(
            text = text.uppercase(),
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp
            )
        )
    }
}

@Composable
fun ProvenanceTag(provenance: DataProvenance) {
    Row(
        modifier = Modifier
            .background(BrandSilver.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Default.Info,
            contentDescription = null,
            tint = BrandGraphite.copy(alpha = 0.6f),
            modifier = Modifier.size(10.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = provenance.name,
            fontSize = 9.sp,
            color = BrandGraphite.copy(alpha = 0.6f),
            fontWeight = FontWeight.Medium,
            letterSpacing = 0.5.sp
        )
    }
}

@Composable
fun SectionHeader(title: String, modifier: Modifier = Modifier) {
    Text(
        text = title.uppercase(),
        style = MaterialTheme.typography.titleSmall.copy(
            fontWeight = FontWeight.Bold,
            color = BrandNavy,
            letterSpacing = 1.2.sp
        ),
        modifier = modifier.padding(vertical = 8.dp)
    )
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = BrandGraphite.copy(alpha = 0.6f), fontSize = 14.sp)
        Text(text = value, color = BrandGraphite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    }
}

@Composable
fun BrandTopBar(
    title: String,
    onBackClick: (() -> Unit)? = null
) {
    Surface(
        color = BrandNavy,
        contentColor = BrandWhite,
        tonalElevation = 4.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .height(64.dp)
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (onBackClick != null) {
                IconButton(onClick = onBackClick) {
                    Text("<", color = BrandWhite, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                }
                Spacer(modifier = Modifier.width(8.dp))
            }
            Text(
                text = title.uppercase(),
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.5.sp
                ),
                modifier = Modifier.weight(1f)
            )
        }
    }
}
