package com.example.database

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.Update
import com.example.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface StationDao {
    @Query("SELECT * FROM stations")
    fun getAllStations(): Flow<List<Station>>

    @Query("SELECT * FROM stations WHERE stationID = :id")
    suspend fun getStationById(id: String): Station?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStations(stations: List<Station>)

    @Update
    suspend fun updateStation(station: Station)
}

@Dao
interface PaymentMethodDao {
    @Query("SELECT * FROM payment_methods")
    fun getPaymentMethods(): Flow<List<PaymentMethod>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPaymentMethod(paymentMethod: PaymentMethod)

    @Query("DELETE FROM payment_methods WHERE id = :id")
    suspend fun deletePaymentMethod(id: String)
}

@Dao
interface RewardsDao {
    @Query("SELECT * FROM rewards_account WHERE customerID = :customerId")
    fun getRewardsAccount(customerId: String): Flow<RewardsAccount?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRewardsAccount(account: RewardsAccount)

    @Query("SELECT * FROM rewards_ledger WHERE customerID = :customerId ORDER BY timestamp DESC")
    fun getLedgerEntries(customerId: String): Flow<List<RewardsLedgerEntry>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLedgerEntry(entry: RewardsLedgerEntry)
}

@Dao
interface OfferDao {
    @Query("SELECT * FROM offers")
    fun getOffers(): Flow<List<RewardOffer>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOffers(offers: List<RewardOffer>)

    @Update
    suspend fun updateOffer(offer: RewardOffer)
}

@Dao
interface ReceiptDao {
    @Query("SELECT * FROM receipts ORDER BY dateTime DESC")
    fun getReceipts(): Flow<List<Receipt>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReceipt(receipt: Receipt)
}

@Dao
interface VehicleDao {
    @Query("SELECT * FROM vehicles ORDER BY id DESC")
    fun getVehicles(): Flow<List<Vehicle>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVehicle(vehicle: Vehicle)

    @Query("DELETE FROM vehicles WHERE id = :id")
    suspend fun deleteVehicle(id: Int)
}

@Dao
interface FavoriteStationDao {
    @Query("SELECT * FROM favorite_stations")
    fun getFavorites(): Flow<List<FavoriteStation>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavorite(favorite: FavoriteStation)

    @Query("DELETE FROM favorite_stations WHERE stationID = :stationId")
    suspend fun deleteFavorite(stationId: String)
}

@Database(
    entities = [
        Station::class,
        PaymentMethod::class,
        RewardsAccount::class,
        RewardsLedgerEntry::class,
        RewardOffer::class,
        Receipt::class,
        Vehicle::class,
        FavoriteStation::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun stationDao(): StationDao
    abstract fun paymentMethodDao(): PaymentMethodDao
    abstract fun rewardsDao(): RewardsDao
    abstract fun offerDao(): OfferDao
    abstract fun receiptDao(): ReceiptDao
    abstract fun vehicleDao(): VehicleDao
    abstract fun favoriteStationDao(): FavoriteStationDao
}
