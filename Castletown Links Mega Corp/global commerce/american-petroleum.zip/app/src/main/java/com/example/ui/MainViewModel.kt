package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.*
import com.example.repository.AppRepository
import com.example.simulation.ForecourtSimulator
import com.example.simulation.NozzleState
import com.example.simulation.SimulatorState
import java.math.BigDecimal
import java.math.RoundingMode
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class AppScreen {
    HOME, STATIONS, REWARDS, RECEIPTS, ACCOUNT, PUMP_SETUP, PUMP_FUELLING, RECEIPT_DETAIL, CONVENIENCE_STORE, VEHICLE_GARAGE
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = AppRepository.getInstance(application)
    val simulator = ForecourtSimulator()

    // --- Custom Navigation Routing ---
    private val _currentScreen = MutableStateFlow(AppScreen.HOME)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val navigationStack = mutableListOf<AppScreen>()

    fun navigateTo(screen: AppScreen) {
        navigationStack.add(_currentScreen.value)
        _currentScreen.value = screen
    }

    fun navigateBack() {
        if (navigationStack.isNotEmpty()) {
            _currentScreen.value = navigationStack.removeAt(navigationStack.size - 1)
        } else {
            _currentScreen.value = AppScreen.HOME
        }
    }

    // --- Location Settings & Mock Permissions ---
    private val _locationPermissionGranted = MutableStateFlow(true) // Start granted for rich experience
    val locationPermissionGranted: StateFlow<Boolean> = _locationPermissionGranted.asStateFlow()

    private val _userZipCode = MutableStateFlow("")
    val userZipCode: StateFlow<String> = _userZipCode.asStateFlow()

    fun setLocationPermission(granted: Boolean) {
        _locationPermissionGranted.value = granted
    }

    fun searchByZipCode(zip: String) {
        _userZipCode.value = zip
    }

    // --- App States & Flows from DB ---
    val allStations: StateFlow<List<Station>> = repository.allStations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favoriteStations: StateFlow<List<FavoriteStation>> = repository.favoriteStations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val paymentMethods: StateFlow<List<PaymentMethod>> = repository.paymentMethods
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeOffers: StateFlow<List<RewardOffer>> = repository.activeOffers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val receipts: StateFlow<List<Receipt>> = repository.receipts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val vehicles: StateFlow<List<Vehicle>> = repository.vehicles
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val rewardsAccount: StateFlow<RewardsAccount?> = repository.rewardsAccount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val ledgerEntries: StateFlow<List<RewardsLedgerEntry>> = repository.ledgerEntries
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Station Details View & Selection ---
    private val _selectedStationId = MutableStateFlow<String?>("TX00142") // Default to Dallas North for demo
    val selectedStationId: StateFlow<String?> = _selectedStationId.asStateFlow()

    val selectedStation: StateFlow<Station?> = _selectedStationId
        .map { id -> id?.let { repository.getStationById(it) } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    fun selectStation(id: String) {
        _selectedStationId.value = id
    }

    // --- Station Search, Sorting, and Filtering ---
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedFuelFilter = MutableStateFlow<String?>(null) // "Regular", "Premium", etc.
    val selectedFuelFilter: StateFlow<String?> = _selectedFuelFilter.asStateFlow()

    private val _selectedAmenityFilter = MutableStateFlow<Set<String>>(emptySet())
    val selectedAmenityFilter: StateFlow<Set<String>> = _selectedAmenityFilter.asStateFlow()

    val filteredStations: StateFlow<List<Station>> = combine(
        allStations,
        _searchQuery,
        _selectedFuelFilter,
        _selectedAmenityFilter,
        _locationPermissionGranted,
        _userZipCode
    ) { array ->
        @Suppress("UNCHECKED_CAST")
        val stations = array[0] as List<Station>
        val query = array[1] as String
        val fuelFilter = array[2] as? String
        @Suppress("UNCHECKED_CAST")
        val amenities = array[3] as Set<String>
        val locationGranted = array[4] as Boolean
        val zip = array[5] as String

        var list = stations

        // Filter by location / ZIP
        if (!locationGranted && zip.isNotEmpty()) {
            list = list.filter { it.zip == zip || it.city.contains(zip, ignoreCase = true) }
        }

        // Filter by Query (City, Name, Address)
        if (query.isNotEmpty()) {
            list = list.filter {
                it.name.contains(query, ignoreCase = true) ||
                it.city.contains(query, ignoreCase = true) ||
                it.address.contains(query, ignoreCase = true)
            }
        }

        // Filter by Fuel availability (E85/Diesel, EV, etc.)
        if (fuelFilter != null) {
            list = list.filter {
                when (fuelFilter.uppercase()) {
                    "DIESEL" -> it.dieselPrice > 0
                    "E85" -> it.e85Price > 0
                    "EV CHARGING" -> it.amenities.contains("EV Charging", ignoreCase = true)
                    else -> true
                }
            }
        }

        // Filter by Amenities
        if (amenities.isNotEmpty()) {
            list = list.filter { station ->
                amenities.all { amenity ->
                    station.amenities.contains(amenity, ignoreCase = true)
                }
            }
        }

        // Order by proximity (Dallas North is always first if location is Dallas)
        list.sortedBy { station ->
            AppRepository.calculateDistanceMiles(
                AppRepository.MOCK_USER_LAT,
                AppRepository.MOCK_USER_LON,
                station.latitude,
                station.longitude
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun toggleFuelFilter(filter: String?) {
        _selectedFuelFilter.value = if (_selectedFuelFilter.value == filter) null else filter
    }

    fun toggleAmenityFilter(amenity: String) {
        val current = _selectedAmenityFilter.value
        _selectedAmenityFilter.value = if (current.contains(amenity)) {
            current - amenity
        } else {
            current + amenity
        }
    }

    fun toggleStationFavorite(stationID: String) {
        viewModelScope.launch {
            repository.toggleFavorite(stationID)
        }
    }

    fun claimOffer(offerID: String) {
        viewModelScope.launch {
            repository.claimOffer(offerID)
        }
    }

    // --- Active Pay At Pump Session ---
    val activeSession: StateFlow<PumpSession?> = repository.activeSession

    // Selected Pump and QR Parsing state
    private val _scannedPumpNumber = MutableStateFlow<Int?>(null)
    val scannedPumpNumber: StateFlow<Int?> = _scannedPumpNumber.asStateFlow()

    private val _pumpSetupError = MutableStateFlow<String?>(null)
    val pumpSetupError: StateFlow<String?> = _pumpSetupError.asStateFlow()

    // Failure Demonstration Toggles
    private val _simulatePaymentDeclined = MutableStateFlow(false)
    val simulatePaymentDeclined: StateFlow<Boolean> = _simulatePaymentDeclined.asStateFlow()

    private val _simulatePumpOffline = MutableStateFlow(false)
    val simulatePumpOffline: StateFlow<Boolean> = _simulatePumpOffline.asStateFlow()

    fun toggleSimulatePaymentDeclined(declined: Boolean) {
        _simulatePaymentDeclined.value = declined
    }

    fun toggleSimulatePumpOffline(offline: Boolean) {
        _simulatePumpOffline.value = offline
    }

    fun selectPump(number: Int) {
        val station = selectedStation.value ?: return
        
        if (_simulatePumpOffline.value) {
            _pumpSetupError.value = "Pump $number is currently offline."
            return
        }

        _pumpSetupError.value = null
        _scannedPumpNumber.value = number
        repository.initPumpSession(station.stationID, number)
    }

    fun parsePumpQR(qrPayload: String) {
        // e.g. AP|STATION=TX00142|PUMP=07|VERSION=1
        try {
            if (!qrPayload.startsWith("AP|STATION=")) {
                _pumpSetupError.value = "Invalid QR: Incorrect format payload"
                return
            }
            val parts = qrPayload.split("|")
            val stationPart = parts.find { it.startsWith("STATION=") }?.substringAfter("=" )
            val pumpPart = parts.find { it.startsWith("PUMP=") }?.substringAfter("=")
            val versionPart = parts.find { it.startsWith("VERSION=") }?.substringAfter("=")

            if (stationPart == null || pumpPart == null) {
                _pumpSetupError.value = "Invalid QR: Missing station or pump identifier"
                return
            }

            if (versionPart != "1") {
                _pumpSetupError.value = "Unsupported QR Version: $versionPart"
                return
            }

            viewModelScope.launch {
                val dbStation = repository.getStationById(stationPart)
                if (dbStation == null) {
                    _pumpSetupError.value = "Station does not exist: $stationPart"
                    return@launch
                }

                val pumpNum = pumpPart.toIntOrNull()
                if (pumpNum == null || pumpNum !in 1..8) {
                    _pumpSetupError.value = "Invalid pump number: $pumpPart"
                    return@launch
                }

                if (_simulatePumpOffline.value) {
                    _pumpSetupError.value = "Pump $pumpNum is currently offline."
                    return@launch
                }

                _selectedStationId.value = stationPart
                _scannedPumpNumber.value = pumpNum
                _pumpSetupError.value = null
                repository.initPumpSession(stationPart, pumpNum)
            }
        } catch (e: Exception) {
            _pumpSetupError.value = "QR Scanning failed: ${e.message}"
        }
    }

    fun clearPumpSetupError() {
        _pumpSetupError.value = null
    }

    fun selectFuelGrade(grade: FuelGrade) {
        repository.selectGradeInSession(grade)
    }

    fun selectPaymentMethod(pmID: String) {
        repository.selectPaymentInSession(pmID)
    }

    fun authorizeFuelSession(presetAmount: Double, isFullTank: Boolean, discountPerGallon: Double) {
        viewModelScope.launch {
            val session = activeSession.value ?: return@launch
            val station = selectedStation.value ?: return@launch
            
            if (_simulatePaymentDeclined.value) {
                _pumpSetupError.value = "Card Declined: Insufficient Funds."
                repository.updateSessionStatus(PumpSessionStatus.FAILED)
                return@launch
            }

            val success = repository.preAuthorizeSession(presetAmount, isFullTank)
            if (success) {
                // Initialize the live simulator
                val finalPrice = getPriceForGrade(station, session.fuelGrade ?: FuelGrade.REGULAR)
                simulator.startSession(
                    sessionID = session.sessionID,
                    stationID = session.stationID,
                    pumpNumber = session.pumpID.toIntOrNull() ?: 1,
                    grade = session.fuelGrade ?: FuelGrade.REGULAR,
                    price = finalPrice,
                    presetAmount = presetAmount,
                    isFullTank = isFullTank,
                    savingsPerGal = discountPerGallon
                )
                navigateTo(AppScreen.PUMP_FUELLING)
            }
        }
    }

    private fun getPriceForGrade(station: Station, grade: FuelGrade): Double {
        return when (grade) {
            FuelGrade.REGULAR -> station.regPrice
            FuelGrade.MIDGRADE -> station.midPrice
            FuelGrade.PREMIUM -> station.premPrice
            FuelGrade.DIESEL -> station.dieselPrice
            FuelGrade.E85 -> station.e85Price
        }
    }

    // --- Live Simulator Operations ---
    val simulatorState: StateFlow<SimulatorState> = simulator.state

    fun liftNozzle() {
        simulator.liftNozzle()
    }

    fun squeezeTrigger() {
        simulator.squeezeTrigger()
    }

    fun releaseTrigger() {
        simulator.releaseTrigger()
    }

    fun returnNozzleAndFinalize() {
        simulator.returnNozzle()
        viewModelScope.launch {
            val simVal = simulatorState.value
            val session = activeSession.value ?: return@launch
            
            // Wait brief moment for final figures
            repository.updateSessionStatus(PumpSessionStatus.FINALISING)
            
            // Determine active offers for saving calculation
            val offers = activeOffers.value.filter { it.isClaimed }
            val basePpg = getPriceForGrade(repository.getStationById(session.stationID)!!, simVal.selectedGrade ?: FuelGrade.REGULAR)
            val discountRate = RewardsRulesEngine.calculateEffectiveDiscount(
                fuelGrade = simVal.selectedGrade ?: FuelGrade.REGULAR,
                stationID = session.stationID,
                availableOffers = offers,
                redeemRewardDollars = 0.0 // Applied at final ledger
            )

            val results = RewardsRulesEngine.finalizeTransaction(
                gallons = simVal.dispensedGallons.toDouble(),
                pricePerGallon = basePpg,
                discountPerGallon = discountRate,
                redeemedRewardsDollars = 0.0
            )

            val pms = paymentMethods.value
            val selectedPm = pms.find { it.id == session.authorisationID }?.displayName ?: "Google Pay"

            val receipt = repository.finalizePumpSession(
                gallons = simVal.dispensedGallons.toDouble(),
                grossAmount = results.grossAmount,
                discountPerGallon = discountRate,
                totalSavings = results.totalSavings,
                netAmount = results.netAmount,
                pointsEarned = results.pointsEarned,
                paymentDisplayName = selectedPm
            )

            _selectedReceipt.value = receipt
            navigateTo(AppScreen.RECEIPT_DETAIL)
        }
    }

    // --- Receipt Detail View ---
    private val _selectedReceipt = MutableStateFlow<Receipt?>(null)
    val selectedReceipt: StateFlow<Receipt?> = _selectedReceipt.asStateFlow()

    fun selectReceipt(receipt: Receipt) {
        _selectedReceipt.value = receipt
        navigateTo(AppScreen.RECEIPT_DETAIL)
    }

    // --- Loyalty Reward Redemption ---
    fun redeemRewards(dollars: Double) {
        viewModelScope.launch {
            repository.redeemLoyaltyRewardDollars(dollars)
        }
    }

    // --- Garage Operations ---
    fun addVehicle(make: String, model: String, year: Int, fuelType: String, tankCapacity: Double, fuelEconomy: Double, nickname: String) {
        viewModelScope.launch {
            repository.addVehicle(make, model, year, fuelType, tankCapacity, fuelEconomy, nickname)
        }
    }

    fun deleteVehicle(id: Int) {
        viewModelScope.launch {
            repository.deleteVehicle(id)
        }
    }

    // --- Stored Card Operations ---
    fun addCard(brand: String) {
        viewModelScope.launch {
            val displayName = "$brand •••• ${kotlin.random.Random.nextInt(1000, 9999)}"
            repository.addPaymentCard(displayName)
        }
    }

    fun deleteCard(id: String) {
        viewModelScope.launch {
            repository.deletePaymentMethod(id)
        }
    }

    // --- Convenience Store Products ---
    val storeProducts = listOf(
        StoreProduct("st_1", "Premium Dark Roast Coffee", "coffee", 2.49, "Freshly brewed bold Arabica blend coffee."),
        StoreProduct("st_2", "Hot Ham & Cheese Panini", "food", 5.99, "Toasted country bread with melted cheddar and black forest ham."),
        StoreProduct("st_3", "Sports Energy Drink 20oz", "drinks", 2.89, "Electrolyte-rich hydration drink, blue raspberry flavour."),
        StoreProduct("st_4", "Premium Salted Kettle Chips", "snacks", 1.99, "Crunchy thick-cut sea salt potato chips."),
        StoreProduct("st_5", "Synthetic Motor Oil 1QT 5W-30", "motor oil", 8.49, "Fully synthetic high performance engine lubricant."),
        StoreProduct("st_6", "Microfiber Polishing Cloths (3 Pack)", "car accessories", 4.99, "Ultra soft scratch-free cloths for visual detailing.")
    )

    fun exitFlow() {
        repository.clearActiveSession()
        simulator.reset()
        _scannedPumpNumber.value = null
        _pumpSetupError.value = null
        navigateTo(AppScreen.HOME)
    }
}
