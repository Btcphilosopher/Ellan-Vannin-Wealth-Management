package com.example.repository

import android.content.Context
import androidx.room.Room
import com.example.database.AppDatabase
import com.example.database.SeedData
import com.example.model.*
import java.math.BigDecimal
import java.math.RoundingMode
import java.util.UUID
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AppRepository private constructor(context: Context) {

    private val db = Room.databaseBuilder(
        context.applicationContext,
        AppDatabase::class.java,
        "american_petroleum.db"
    ).build()

    private val scope = CoroutineScope(Dispatchers.IO)

    // Exposed flows from DAOs
    val allStations: Flow<List<Station>> = db.stationDao().getAllStations().flowOn(Dispatchers.IO)
    val favoriteStations: Flow<List<FavoriteStation>> = db.favoriteStationDao().getFavorites().flowOn(Dispatchers.IO)
    val paymentMethods: Flow<List<PaymentMethod>> = db.paymentMethodDao().getPaymentMethods().flowOn(Dispatchers.IO)
    val activeOffers: Flow<List<RewardOffer>> = db.offerDao().getOffers().flowOn(Dispatchers.IO)
    val receipts: Flow<List<Receipt>> = db.receiptDao().getReceipts().flowOn(Dispatchers.IO)
    val vehicles: Flow<List<Vehicle>> = db.vehicleDao().getVehicles().flowOn(Dispatchers.IO)

    // Current Customer ID (Default synthetic account)
    val currentCustomerId = "cust_991824"

    val rewardsAccount: Flow<RewardsAccount?> = db.rewardsDao().getRewardsAccount(currentCustomerId).flowOn(Dispatchers.IO)
    val ledgerEntries: Flow<List<RewardsLedgerEntry>> = db.rewardsDao().getLedgerEntries(currentCustomerId).flowOn(Dispatchers.IO)

    // Active Pay At Pump Session State
    private val _activeSession = MutableStateFlow<PumpSession?>(null)
    val activeSession: StateFlow<PumpSession?> = _activeSession.asStateFlow()

    init {
        scope.launch {
            seedDatabaseIfEmpty()
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: AppRepository? = null

        const val MOCK_USER_LAT = 32.7767
        const val MOCK_USER_LON = -96.7970

        fun getInstance(context: Context): AppRepository {
            return INSTANCE ?: synchronized(this) {
                val instance = AppRepository(context)
                INSTANCE = instance
                instance
            }
        }

        /**
         * Helper to calculate distance in miles using Haversine formula
         */
        fun calculateDistanceMiles(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
            val r = 3958.8 // Earth radius in miles
            val dLat = Math.toRadians(lat2 - lat1)
            val dLon = Math.toRadians(lon2 - lon1)
            val a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                    Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                    Math.sin(dLon / 2) * Math.sin(dLon / 2)
            val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
            return Math.round(r * c * 10.0) / 10.0
        }
    }

    private suspend fun seedDatabaseIfEmpty() = withContext(Dispatchers.IO) {
        val stationsList = db.stationDao().getAllStations().first()
        if (stationsList.isEmpty()) {
            // Seed stations
            db.stationDao().insertStations(SeedData.generateStations())
            
            // Seed payment methods
            for (pm in SeedData.getSeedPaymentMethods()) {
                db.paymentMethodDao().insertPaymentMethod(pm)
            }

            // Seed vehicles
            for (v in SeedData.getSeedVehicles()) {
                db.vehicleDao().insertVehicle(v)
            }

            // Seed offers
            db.offerDao().insertOffers(SeedData.getSeedOffers())

            // Seed rewards account
            db.rewardsDao().insertRewardsAccount(SeedData.getSeedRewardsAccount())

            // Seed ledger entries
            for (le in SeedData.getSeedLedgerEntries()) {
                db.rewardsDao().insertLedgerEntry(le)
            }

            // Seed receipts
            for (rec in SeedData.getSeedReceipts()) {
                db.receiptDao().insertReceipt(rec)
            }
        }
    }

    // --- Station Operations ---
    suspend fun getStationById(id: String): Station? = withContext(Dispatchers.IO) {
        db.stationDao().getStationById(id)
    }

    suspend fun toggleFavorite(stationID: String) = withContext(Dispatchers.IO) {
        val favoritesList = db.favoriteStationDao().getFavorites().first()
        val existing = favoritesList.find { it.stationID == stationID }
        if (existing != null) {
            db.favoriteStationDao().deleteFavorite(stationID)
        } else {
            db.favoriteStationDao().insertFavorite(
                FavoriteStation(
                    stationID = stationID,
                    nickname = "FAVORITE",
                    lastVisit = System.currentTimeMillis()
                )
            )
        }
    }

    // --- Vehicle Operations ---
    suspend fun addVehicle(make: String, model: String, year: Int, fuelType: String, tankCapacity: Double, fuelEconomy: Double, nickname: String) = withContext(Dispatchers.IO) {
        db.vehicleDao().insertVehicle(
            Vehicle(
                make = make,
                model = model,
                year = year,
                fuelType = fuelType,
                tankCapacity = tankCapacity,
                fuelEconomy = fuelEconomy,
                nickname = nickname
            )
        )
    }

    suspend fun deleteVehicle(id: Int) = withContext(Dispatchers.IO) {
        db.vehicleDao().deleteVehicle(id)
    }

    // --- Payment Methods ---
    suspend fun addPaymentCard(displayName: String) = withContext(Dispatchers.IO) {
        val id = "pm_" + UUID.randomUUID().toString().take(8)
        db.paymentMethodDao().insertPaymentMethod(
            PaymentMethod(
                id = id,
                type = "CARD",
                displayName = displayName,
                token = "token_" + UUID.randomUUID().toString()
            )
        )
    }

    suspend fun deletePaymentMethod(id: String) = withContext(Dispatchers.IO) {
        db.paymentMethodDao().deletePaymentMethod(id)
    }

    // --- Offers ---
    suspend fun claimOffer(offerID: String) = withContext(Dispatchers.IO) {
        val all = db.offerDao().getOffers().first()
        val target = all.find { it.offerID == offerID }
        if (target != null) {
            db.offerDao().updateOffer(target.copy(isClaimed = true))
        }
    }

    // --- Pay-At-Pump & Session State Machine ---
    fun initPumpSession(stationID: String, pumpNumber: Int) {
        _activeSession.value = PumpSession(
            sessionID = "sess_" + UUID.randomUUID().toString().take(8),
            customerID = currentCustomerId,
            stationID = stationID,
            pumpID = pumpNumber.toString(),
            fuelGrade = null,
            authorisationID = null,
            requestedAmount = -1.0,
            status = PumpSessionStatus.PUMP_IDENTIFIED
        )
    }

    fun selectGradeInSession(grade: FuelGrade) {
        val current = _activeSession.value ?: return
        _activeSession.value = current.copy(
            fuelGrade = grade,
            status = PumpSessionStatus.FUEL_SELECTED
        )
    }

    fun selectPaymentInSession(paymentMethodID: String) {
        val current = _activeSession.value ?: return
        _activeSession.value = current.copy(
            authorisationID = paymentMethodID,
            status = PumpSessionStatus.PAYMENT_PENDING
        )
    }

    suspend fun preAuthorizeSession(amount: Double, isFullTank: Boolean): Boolean = withContext(Dispatchers.IO) {
        val current = _activeSession.value ?: return@withContext false
        
        // Simulating synthetic pre-authorization validation
        // In realistic environments, we block for credit checks / auth tokens
        _activeSession.value = current.copy(status = PumpSessionStatus.PAYMENT_PENDING)
        withContext(Dispatchers.Default) {
            delay(1000) // Realistic latency
        }

        // Fails pre-auth if preset amount is exactly $99.99 (for failure testing)
        if (amount == 99.99) {
            _activeSession.value = current.copy(status = PumpSessionStatus.FAILED)
            return@withContext false
        }

        _activeSession.value = current.copy(
            requestedAmount = if (isFullTank) -1.0 else amount,
            status = PumpSessionStatus.AUTHORISED
        )
        return@withContext true
    }

    fun updateSessionStatus(status: PumpSessionStatus) {
        val current = _activeSession.value ?: return
        _activeSession.value = current.copy(status = status)
    }

    fun updateSessionLiveTelemetry(gallons: Double, amount: Double) {
        val current = _activeSession.value ?: return
        _activeSession.value = current.copy(
            dispensedGallons = gallons,
            currentAmount = amount,
            status = PumpSessionStatus.FUELLING
        )
    }

    suspend fun finalizePumpSession(
        gallons: Double,
        grossAmount: Double,
        discountPerGallon: Double,
        totalSavings: Double,
        netAmount: Double,
        pointsEarned: Int,
        paymentDisplayName: String
    ): Receipt = withContext(Dispatchers.IO) {
        val session = _activeSession.value ?: throw IllegalStateException("No active pump session to finalize")
        val station = db.stationDao().getStationById(session.stationID) ?: throw IllegalStateException("Station not found")

        val receiptID = "rec_" + UUID.randomUUID().toString().replace("-", "").take(8).uppercase()
        val transactionID = "tx_" + UUID.randomUUID().toString().replace("-", "").take(8).lowercase()

        val receipt = Receipt(
            receiptID = receiptID,
            transactionID = transactionID,
            stationID = station.stationID,
            stationName = station.name,
            stationAddress = station.address,
            pumpNumber = session.pumpID.toIntOrNull() ?: 1,
            dateTime = System.currentTimeMillis(),
            fuelGrade = session.fuelGrade?.displayName ?: "Regular",
            gallons = gallons,
            pricePerGallon = session.fuelGrade?.let { 
                when(it) {
                    FuelGrade.REGULAR -> station.regPrice
                    FuelGrade.MIDGRADE -> station.midPrice
                    FuelGrade.PREMIUM -> station.premPrice
                    FuelGrade.DIESEL -> station.dieselPrice
                    FuelGrade.E85 -> station.e85Price
                }
            } ?: station.regPrice,
            grossAmount = grossAmount,
            discount = totalSavings,
            netAmount = netAmount,
            rewardsEarned = pointsEarned,
            paymentMethod = paymentDisplayName
        )

        // Write receipt to DB
        db.receiptDao().insertReceipt(receipt)

        // Update rewards ledger and balance
        val currentAccount = db.rewardsDao().getRewardsAccount(currentCustomerId).first() ?: RewardsAccount(currentCustomerId, 0, 0.0)
        val newPointsBalance = currentAccount.pointsBalance + pointsEarned
        val newRewardDollars = newPointsBalance.toDouble() / 100.0

        db.rewardsDao().insertRewardsAccount(
            RewardsAccount(
                customerID = currentCustomerId,
                pointsBalance = newPointsBalance,
                availableRewardDollars = newRewardDollars
            )
        )

        db.rewardsDao().insertLedgerEntry(
            RewardsLedgerEntry(
                id = "led_" + UUID.randomUUID().toString().take(8),
                customerID = currentCustomerId,
                transactionID = transactionID,
                points = pointsEarned,
                type = "EARNED",
                timestamp = System.currentTimeMillis(),
                description = "Fuel Fill (${session.fuelGrade?.displayName ?: "Regular"}, ${String.format("%.1f", gallons)} GAL)",
                balanceAfter = newPointsBalance
            )
        )

        // Clear active session
        _activeSession.value = session.copy(
            dispensedGallons = gallons,
            currentAmount = netAmount,
            status = PumpSessionStatus.COMPLETED,
            completedAt = System.currentTimeMillis()
        )

        return@withContext receipt
    }

    suspend fun redeemLoyaltyRewardDollars(dollars: Double) = withContext(Dispatchers.IO) {
        val currentAccount = db.rewardsDao().getRewardsAccount(currentCustomerId).first() ?: return@withContext
        val pointsToDeduct = (dollars * 100).toInt()
        
        if (currentAccount.pointsBalance >= pointsToDeduct) {
            val newPointsBalance = currentAccount.pointsBalance - pointsToDeduct
            val newRewardDollars = newPointsBalance.toDouble() / 100.0

            db.rewardsDao().insertRewardsAccount(
                RewardsAccount(
                    customerID = currentCustomerId,
                    pointsBalance = newPointsBalance,
                    availableRewardDollars = newRewardDollars
                )
            )

            db.rewardsDao().insertLedgerEntry(
                RewardsLedgerEntry(
                    id = "led_" + UUID.randomUUID().toString().take(8),
                    customerID = currentCustomerId,
                    transactionID = null,
                    points = -pointsToDeduct,
                    type = "REDEEMED",
                    timestamp = System.currentTimeMillis(),
                    description = "Redeemed \$${String.format("%.2f", dollars)} Fuel Reward",
                    balanceAfter = newPointsBalance
                )
            )
        }
    }

    fun clearActiveSession() {
        _activeSession.value = null
    }
}
