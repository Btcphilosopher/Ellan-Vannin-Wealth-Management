package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.FuelGrade
import com.example.model.PumpSessionStatus
import com.example.model.RewardsRulesEngine

@Composable
fun PumpScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val station by viewModel.selectedStation.collectAsState()
    val session by viewModel.activeSession.collectAsState()
    val scannedPumpNumber by viewModel.scannedPumpNumber.collectAsState()
    val pumpSetupError by viewModel.pumpSetupError.collectAsState()
    val paymentMethods by viewModel.paymentMethods.collectAsState()
    val offers by viewModel.activeOffers.collectAsState()

    var showQrSimDialog by remember { mutableStateOf(false) }
    var selectedPresetAmount by remember { mutableStateOf(40.0) }
    var isFullTank by remember { mutableStateOf(false) }
    var selectedPmId by remember { mutableStateOf("pm_google_pay") }
    var isAuthorizing by remember { mutableStateOf(false) }

    val currentStation = station ?: return

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BrandLightBg)
    ) {
        // Top station details banner
        Surface(color = BrandNavy, contentColor = BrandWhite, tonalElevation = 4.dp) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text(
                    text = currentStation.name.uppercase(),
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp,
                    letterSpacing = 1.sp
                )
                Text(
                    text = currentStation.address,
                    fontSize = 12.sp,
                    color = BrandSilver.copy(alpha = 0.7f)
                )
            }
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // --- Error banner ---
            if (pumpSetupError != null) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = BrandRed.copy(alpha = 0.1f)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = pumpSetupError ?: "",
                            color = BrandRed,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = { viewModel.clearPumpSetupError() }) {
                            Text("DISMISS", color = BrandRed, fontSize = 11.sp, fontWeight = FontWeight.Black)
                        }
                    }
                }
            }

            // --- STEP 1: Pump Identification ---
            SectionHeader("Step 1: Identify Your Pump")
            if (scannedPumpNumber == null) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Select your physical pump terminal number below:", fontSize = 12.sp)

                    // 4x2 grid of pump buttons
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            (1..4).forEach { num ->
                                PumpSelectorButton(
                                    num = num,
                                    onClick = { viewModel.selectPump(num) },
                                    modifier = Modifier.weight(1f),
                                    testTag = "pump_select_$num"
                                )
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            (5..8).forEach { num ->
                                PumpSelectorButton(
                                    num = num,
                                    onClick = { viewModel.selectPump(num) },
                                    modifier = Modifier.weight(1f),
                                    testTag = "pump_select_$num"
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    
                    // QR Scanner button
                    OutlinedButton(
                        onClick = { showQrSimDialog = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("scan_qr_prompt"),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = BrandNavy),
                        border = BorderStroke(1.5.dp, BrandNavy)
                    ) {
                        Icon(Icons.Default.QrCodeScanner, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("SCAN PUMP QR CODE", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            } else {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BrandWhite, RoundedCornerShape(8.dp))
                        .border(1.dp, BrandSilver, RoundedCornerShape(8.dp))
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .background(BrandGreen),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("✓", color = BrandWhite, fontWeight = FontWeight.Black, fontSize = 16.sp)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Pump identified successfully", fontSize = 11.sp, color = BrandGreen, fontWeight = FontWeight.Bold)
                        Text("PUMP TERMINAL: ${String.format("%02d", scannedPumpNumber)}", fontWeight = FontWeight.Black, color = BrandNavy, fontSize = 14.sp)
                    }
                    TextButton(onClick = { viewModel.exitFlow() }) {
                        Text("RESET", color = BrandRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // --- STEP 2: Fuel Selection ---
            if (scannedPumpNumber != null) {
                SectionHeader("Step 2: Select Your Fuel Grade")
                Text("Select a grade. Display prices reflect active rewards coupons:", fontSize = 12.sp)

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    val grades = listOf(FuelGrade.REGULAR, FuelGrade.MIDGRADE, FuelGrade.PREMIUM, FuelGrade.DIESEL)
                    
                    // Compute discounts
                    val claimedOffers = offers.filter { it.isClaimed }
                    
                    grades.forEach { grade ->
                        val basePrice = when(grade) {
                            FuelGrade.REGULAR -> currentStation.regPrice
                            FuelGrade.MIDGRADE -> currentStation.midPrice
                            FuelGrade.PREMIUM -> currentStation.premPrice
                            FuelGrade.DIESEL -> currentStation.dieselPrice
                            FuelGrade.E85 -> currentStation.e85Price
                        }

                        val discount = RewardsRulesEngine.calculateEffectiveDiscount(
                            fuelGrade = grade,
                            stationID = currentStation.stationID,
                            availableOffers = claimedOffers
                        )

                        val finalPrice = basePrice - discount
                        val isSelected = session?.fuelGrade == grade

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) BrandNavy.copy(alpha = 0.05f) else BrandWhite)
                                .border(
                                    2.dp,
                                    if (isSelected) BrandNavy else BrandSilver,
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable { viewModel.selectFuelGrade(grade) }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = isSelected,
                                onClick = { viewModel.selectFuelGrade(grade) },
                                colors = RadioButtonDefaults.colors(selectedColor = BrandNavy)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = grade.displayName,
                                    fontWeight = FontWeight.Bold,
                                    color = BrandNavy,
                                    fontSize = 14.sp
                               )
                                Text(
                                    text = "Octane: ${grade.octane} · Ethanol: ${grade.ethanolPercentage.toInt()}%",
                                    fontSize = 10.sp,
                                    color = BrandGraphite.copy(alpha = 0.5f)
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "$${String.format("%.3f", finalPrice)}/GAL",
                                    fontWeight = FontWeight.Black,
                                    color = BrandNavy,
                                    fontSize = 15.sp
                                )
                                if (discount > 0) {
                                    Text(
                                        text = "Saved ${String.format("%.0f", discount * 100)}¢/gal",
                                        color = BrandGreen,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // --- STEP 3: Preset Amount ---
            if (scannedPumpNumber != null && session?.fuelGrade != null) {
                SectionHeader("Step 3: Select Fill Limit")
                
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val presets = listOf(20.0, 30.0, 40.0, 50.0, 75.0, 100.0)
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            presets.take(3).forEach { amount ->
                                PresetAmountButton(
                                    amount = amount,
                                    selected = selectedPresetAmount == amount && !isFullTank,
                                    onClick = {
                                        selectedPresetAmount = amount
                                        isFullTank = false
                                    },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            presets.takeLast(3).forEach { amount ->
                                PresetAmountButton(
                                    amount = amount,
                                    selected = selectedPresetAmount == amount && !isFullTank,
                                    onClick = {
                                        selectedPresetAmount = amount
                                        isFullTank = false
                                    },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }

                // Full tank toggle
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isFullTank) BrandNavy.copy(alpha = 0.05f) else BrandWhite)
                        .border(1.dp, if (isFullTank) BrandNavy else BrandSilver, RoundedCornerShape(8.dp))
                        .clickable { isFullTank = true }
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(
                            selected = isFullTank,
                            onClick = { isFullTank = true },
                            colors = RadioButtonDefaults.colors(selectedColor = BrandNavy)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("FILL TO FULL TANK", fontWeight = FontWeight.Bold, color = BrandNavy, fontSize = 13.sp)
                            Text("Automatic stop on nozzle trigger snap.", fontSize = 10.sp, color = BrandGraphite.copy(alpha = 0.5f))
                        }
                    }
                    Text("MAX $125", fontSize = 12.sp, color = BrandGraphite.copy(alpha = 0.6f), fontWeight = FontWeight.Bold)
                }
            }

            // --- STEP 4: Choose Payment & Authorise ---
            if (scannedPumpNumber != null && session?.fuelGrade != null) {
                SectionHeader("Step 4: Select Payment Wallet")
                
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Google Pay option
                    PaymentMethodSelectorRow(
                        id = "pm_google_pay",
                        title = "Google Pay",
                        selected = selectedPmId == "pm_google_pay",
                        onClick = {
                            selectedPmId = "pm_google_pay"
                            viewModel.selectPaymentMethod("pm_google_pay")
                        }
                    )

                    // Stored credit cards
                    paymentMethods.forEach { method ->
                        PaymentMethodSelectorRow(
                            id = method.id,
                            title = method.displayName,
                            selected = selectedPmId == method.id,
                            onClick = {
                                selectedPmId = method.id
                                viewModel.selectPaymentMethod(method.id)
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Large action pre-auth trigger button
                if (isAuthorizing) {
                    Box(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = BrandRed)
                    }
                } else {
                    val claimedOffers = offers.filter { it.isClaimed }
                    val savingsPerGal = RewardsRulesEngine.calculateEffectiveDiscount(
                        fuelGrade = session?.fuelGrade ?: FuelGrade.REGULAR,
                        stationID = currentStation.stationID,
                        availableOffers = claimedOffers
                    )

                    PrimaryActionButton(
                        text = "Authorize & Start pump",
                        onClick = {
                            isAuthorizing = true
                            viewModel.authorizeFuelSession(
                                presetAmount = if (isFullTank) -1.0 else selectedPresetAmount,
                                isFullTank = isFullTank,
                                discountPerGallon = savingsPerGal
                            )
                        },
                        testTag = "authorize_session_button"
                    )
                }
            }
        }
    }

    // --- QR Simulation scanner modal dialog ---
    if (showQrSimDialog) {
        var qrInputText by remember { mutableStateOf("AP|STATION=TX00142|PUMP=07|VERSION=1") }
        AlertDialog(
            onDismissRequest = { showQrSimDialog = false },
            title = { Text("Simulate Pump QR Scanner", fontWeight = FontWeight.Bold, color = BrandNavy) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Enter raw QR payload token. Our verified format standard:", fontSize = 12.sp)
                    Text("AP|STATION={id}|PUMP={number}|VERSION=1", fontWeight = FontWeight.Bold, color = BrandRed, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = qrInputText,
                        onValueChange = { qrInputText = it },
                        modifier = Modifier.fillMaxWidth().testTag("qr_input_dialog"),
                        textStyle = LocalTextStyle.current.copy(fontSize = 13.sp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.parsePumpQR(qrInputText)
                        showQrSimDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BrandNavy),
                    modifier = Modifier.testTag("qr_confirm_dialog_btn")
                ) {
                    Text("CONFIRM SCAN")
                }
            },
            dismissButton = {
                TextButton(onClick = { showQrSimDialog = false }) {
                    Text("CANCEL")
                }
            }
        )
    }
}

@Composable
fun PumpSelectorButton(
    num: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = ""
) {
    Box(
        modifier = modifier
            .testTag(testTag)
            .height(50.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(BrandWhite)
            .border(1.dp, BrandNavy, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = String.format("%02d", num),
            fontWeight = FontWeight.ExtraBold,
            fontSize = 16.sp,
            color = BrandNavy
        )
    }
}

@Composable
fun PresetAmountButton(
    amount: Double,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .height(44.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(if (selected) BrandRed else BrandWhite)
            .border(1.dp, if (selected) BrandRed else BrandSilver, RoundedCornerShape(6.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "$${amount.toInt()}",
            fontWeight = FontWeight.Bold,
            color = if (selected) BrandWhite else BrandNavy,
            fontSize = 14.sp
        )
    }
}

@Composable
fun PaymentMethodSelectorRow(
    id: String,
    title: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(if (selected) BrandNavy.copy(alpha = 0.05f) else BrandWhite)
            .border(1.dp, if (selected) BrandNavy else BrandSilver, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(
            selected = selected,
            onClick = onClick,
            colors = RadioButtonDefaults.colors(selectedColor = BrandNavy)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Icon(Icons.Default.CreditCard, contentDescription = null, tint = BrandBlue, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.width(10.dp))
        Text(
            text = title.uppercase(),
            fontWeight = FontWeight.Bold,
            color = BrandNavy,
            fontSize = 13.sp
        )
    }
}
