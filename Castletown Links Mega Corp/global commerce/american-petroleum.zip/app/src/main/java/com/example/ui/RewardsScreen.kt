package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.LocalActivity
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.RewardOffer
import com.example.model.RewardsLedgerEntry
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun RewardsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val rewardsAccount by viewModel.rewardsAccount.collectAsState()
    val ledgerEntries by viewModel.ledgerEntries.collectAsState()
    val offers by viewModel.activeOffers.collectAsState()

    var activeSubTab by remember { mutableStateOf("OFFERS") } // "OFFERS" vs "HISTORY"

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BrandLightBg)
    ) {
        // --- Premium Loyalty Header Card ---
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(BrandNavy)
                .padding(16.dp)
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BrandSilver.copy(alpha = 0.3f), RoundedCornerShape(12.dp)),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = BrandNavy)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "AMERICAN REWARDS",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = BrandSilver,
                        letterSpacing = 2.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${rewardsAccount?.pointsBalance ?: 0}",
                        fontSize = 48.sp,
                        fontWeight = FontWeight.Black,
                        color = BrandRed,
                        letterSpacing = (-1).sp
                    )
                    Text(
                        text = "TOTAL AVAILABLE POINTS",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = BrandWhite.copy(alpha = 0.6f)
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                    Divider(color = BrandSilver.copy(alpha = 0.2f))
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Available Reward Cash",
                                fontSize = 11.sp,
                                color = BrandWhite.copy(alpha = 0.7f)
                            )
                            Text(
                                text = "$${String.format("%.2f", rewardsAccount?.availableRewardDollars ?: 0.0)}",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Black,
                                color = BrandGreen
                            )
                        }

                        // Point redemption trigger
                        Button(
                            onClick = {
                                if ((rewardsAccount?.pointsBalance ?: 0) >= 500) {
                                    viewModel.redeemRewards(5.0)
                                }
                            },
                            enabled = (rewardsAccount?.pointsBalance ?: 0) >= 500,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = BrandGreen,
                                contentColor = BrandWhite,
                                disabledContainerColor = BrandSilver.copy(alpha = 0.15f)
                            ),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text("REDEEM $5.00", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // --- Tab Switcher (OFFERS vs HISTORY) ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(BrandWhite)
                .padding(vertical = 12.dp, horizontal = 16.dp)
        ) {
            SubTabToggleItem(
                title = "Active Offers",
                active = activeSubTab == "OFFERS",
                modifier = Modifier.weight(1f),
                onClick = { activeSubTab = "OFFERS" }
            )
            SubTabToggleItem(
                title = "Ledger History",
                active = activeSubTab == "HISTORY",
                modifier = Modifier.weight(1f),
                onClick = { activeSubTab = "HISTORY" }
            )
        }

        // --- Tab Contents ---
        if (activeSubTab == "OFFERS") {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(vertical = 16.dp)
            ) {
                item {
                    SectionHeader("Available Fuel & Store Coupons")
                }
                items(offers) { offer ->
                    OfferItemCard(offer = offer, onClaim = { viewModel.claimOffer(offer.offerID) })
                }
            }
        } else {
            // HISTORY Tab
            if (ledgerEntries.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No rewards transactions found.", color = BrandGraphite.copy(alpha = 0.5f))
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(vertical = 16.dp)
                ) {
                    item {
                        SectionHeader("Rewards Points Balance Ledger")
                    }
                    items(ledgerEntries) { entry ->
                        LedgerEntryListItem(entry = entry)
                    }
                }
            }
        }
    }
}

@Composable
fun SubTabToggleItem(
    title: String,
    active: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = title.uppercase(),
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = if (active) BrandRed else BrandGraphite.copy(alpha = 0.5f),
            letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(6.dp))
        Box(
            modifier = Modifier
                .width(40.dp)
                .height(3.dp)
                .background(if (active) BrandRed else Color.Transparent)
        )
    }
}

@Composable
fun OfferItemCard(
    offer: RewardOffer,
    onClaim: () -> Unit
) {
    val isExpired = offer.endAt < System.currentTimeMillis()
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (offer.isClaimed) BrandGreen.copy(alpha = 0.6f) else BrandSilver,
                RoundedCornerShape(12.dp)
            ),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (offer.isClaimed) BrandGreen.copy(alpha = 0.03f) else BrandWhite
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = offer.title,
                        fontWeight = FontWeight.Bold,
                        color = BrandNavy,
                        fontSize = 15.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = offer.description,
                        fontSize = 12.sp,
                        color = BrandGraphite.copy(alpha = 0.7f)
                    )
                }

                // Promo tag visual
                Box(
                    modifier = Modifier
                        .background(
                            if (isExpired) BrandSilver else if (offer.discountType == "CENTS_PER_GAL") BrandRed else BrandBlue,
                            RoundedCornerShape(4.dp)
                        )
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isExpired) "EXPIRED" else if (offer.discountType == "CENTS_PER_GAL") "SAVE ${String.format("%.0f", offer.discountValue * 100)}¢" else "2x PTS",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black,
                        color = BrandWhite
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Divider(color = BrandSilver)
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Stackable: ${offer.stackingPolicy}",
                        fontSize = 10.sp,
                        color = BrandGraphite.copy(alpha = 0.5f),
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "Eligible Grades: ${offer.eligibleFuel}",
                        fontSize = 10.sp,
                        color = BrandGraphite.copy(alpha = 0.5f)
                    )
                }

                if (isExpired) {
                    Text("EXPIRED", color = BrandRed, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                } else if (offer.isClaimed) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = BrandGreen, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("ACTIVE / CLAIMED", color = BrandGreen, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                } else {
                    Button(
                        onClick = onClaim,
                        colors = ButtonDefaults.buttonColors(containerColor = BrandNavy, contentColor = BrandWhite),
                        shape = RoundedCornerShape(4.dp),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                        modifier = Modifier.height(32.dp).testTag("claim_button_${offer.offerID}")
                    ) {
                        Text("CLAIM OFFER", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun LedgerEntryListItem(
    entry: RewardsLedgerEntry
) {
    val isDeduction = entry.points < 0
    val sdf = SimpleDateFormat("MMM dd, yyyy · hh:mm a", Locale.getDefault())
    val formattedDate = sdf.format(Date(entry.timestamp))

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, BrandSilver, RoundedCornerShape(8.dp)),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = BrandWhite)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = entry.description,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = BrandNavy
                )
                Text(
                    text = formattedDate,
                    fontSize = 10.sp,
                    color = BrandGraphite.copy(alpha = 0.5f)
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = if (isDeduction) "${entry.points} PTS" else "+${entry.points} PTS",
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp,
                    color = if (isDeduction) BrandRed else BrandGreen
                )
                Text(
                    text = "Bal: ${entry.balanceAfter}",
                    fontSize = 10.sp,
                    color = BrandGraphite.copy(alpha = 0.5f)
                )
            }
        }
    }
}
