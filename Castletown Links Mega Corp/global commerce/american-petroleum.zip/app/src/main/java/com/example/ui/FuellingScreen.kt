package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.simulation.NozzleState
import com.example.model.PumpSessionStatus

@Composable
fun FuellingScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val simState by viewModel.simulatorState.collectAsState()

    val ppg = simState.pricePerGallon
    val gallons = simState.dispensedGallons
    val amount = simState.currentAmount
    val nozzle = simState.nozzleState
    val status = simState.sessionStatus

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BrandNavy)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // --- Station & Pump ID Banner ---
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(top = 16.dp)
        ) {
            Text(
                text = "AMERICAN PETROLEUM",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = BrandSilver,
                letterSpacing = 2.sp
            )
            Text(
                text = "PUMP ${String.format("%02d", simState.pumpNumber)}",
                fontSize = 28.sp,
                fontWeight = FontWeight.Black,
                color = BrandWhite
            )
            Text(
                text = "${simState.selectedGrade?.displayName?.uppercase() ?: "REGULAR"} · $${String.format("%.3f", ppg)}/GAL",
                fontSize = 14.sp,
                color = BrandSilver.copy(alpha = 0.7f),
                fontWeight = FontWeight.Bold
            )
        }

        // --- Live Meter Panel ---
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(2.dp, BrandSilver.copy(alpha = 0.3f), RoundedCornerShape(12.dp)),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = BrandGraphite)
        ) {
            Column(
                modifier = Modifier
                    .padding(24.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Live Dollars Amount
                Text(
                    text = "$${String.format("%.2f", amount.toDouble())}",
                    fontSize = 54.sp,
                    fontWeight = FontWeight.Black,
                    color = BrandWhite,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.testTag("live_amount_text")
                )
                Text(
                    text = "AMOUNT CHARGED (USD)",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = BrandSilver.copy(alpha = 0.5f),
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                Divider(color = BrandSilver.copy(alpha = 0.1f))

                Spacer(modifier = Modifier.height(16.dp))

                // Live Gallons Amount
                Text(
                    text = String.format("%.3f", gallons.toDouble()),
                    fontSize = 36.sp,
                    fontWeight = FontWeight.Bold,
                    color = BrandBlue,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.testTag("live_gallons_text")
                )
                Text(
                    text = "GALLONS DISPENSED",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = BrandSilver.copy(alpha = 0.5f)
                )

                // If preset limit is present, show small reminder progress bar
                if (simState.presetLimitAmount > java.math.BigDecimal.ZERO) {
                    Spacer(modifier = Modifier.height(12.dp))
                    val progress = if (amount.toDouble() > 0) (amount.toDouble() / simState.presetLimitAmount.toDouble()).toFloat() else 0f
                    LinearProgressIndicator(
                        progress = { progress.coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = BrandRed,
                        trackColor = BrandSilver.copy(alpha = 0.1f)
                    )
                    Text(
                        text = "Preset Stop Limit: $${String.format("%.2f", simState.presetLimitAmount.toDouble())}",
                        fontSize = 9.sp,
                        color = BrandSilver.copy(alpha = 0.6f),
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }

        // --- Real-Time Savings & Loyalty Accrual Row ---
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Live Savings Box
            Card(
                modifier = Modifier.weight(1f),
                colors = CardDefaults.cardColors(containerColor = BrandWhite.copy(alpha = 0.06f))
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    val accumulatedSavings = gallons.multiply(simState.estimatedSavings).toDouble()
                    Text(
                        text = "$${String.format("%.2f", accumulatedSavings)}",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = BrandGreen
                    )
                    Text(
                        text = "ESTIMATED SAVINGS",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = BrandSilver.copy(alpha = 0.5f)
                    )
                }
            }

            // Live Rewards Points Box
            Card(
                modifier = Modifier.weight(1f),
                colors = CardDefaults.cardColors(containerColor = BrandWhite.copy(alpha = 0.06f))
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "+${simState.rewardsPointsEarned}",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = BrandRed
                    )
                    Text(
                        text = "REWARDS EARNED",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = BrandSilver.copy(alpha = 0.5f)
                    )
                }
            }
        }

        // --- Interactive Hardware Simulator Triggers ---
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = when (nozzle) {
                    NozzleState.RETURNED -> "Nozzle returned. LIFT NOZZLE to prepare pump."
                    NozzleState.LIFTED -> "Nozzle lifted. PRESS AND HOLD trigger below to fuel."
                    NozzleState.DISPENSING -> "FUELLING... (Release trigger to stop flow)"
                    NozzleState.STOPPED -> "Nozzle flow stopped. Return nozzle to finish."
                }.uppercase(),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (nozzle == NozzleState.DISPENSING) BrandGreen else BrandSilver,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (nozzle == NozzleState.RETURNED) {
                    Button(
                        onClick = { viewModel.liftNozzle() },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = BrandWhite, contentColor = BrandNavy),
                        modifier = Modifier.weight(1f).height(50.dp).testTag("lift_nozzle_button")
                    ) {
                        Text("LIFT NOZZLE", fontWeight = FontWeight.Bold)
                    }
                }

                if (nozzle == NozzleState.LIFTED || nozzle == NozzleState.DISPENSING || nozzle == NozzleState.STOPPED) {
                    // Tactile hold trigger button
                    Button(
                        onClick = {}, // Handled by pointer input
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (nozzle == NozzleState.DISPENSING) BrandGreen else BrandRed
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .testTag("hold_trigger_button")
                            .pointerInput(Unit) {
                                detectTapGestures(
                                    onPress = {
                                        viewModel.squeezeTrigger()
                                        tryAwaitRelease()
                                        viewModel.releaseTrigger()
                                    }
                                )
                            }
                    ) {
                        Text(
                            text = if (nozzle == NozzleState.DISPENSING) "DISPENSING..." else "HOLD TO DISPENSE",
                            fontWeight = FontWeight.Black
                        )
                    }

                    // Return nozzle button
                    Button(
                        onClick = { viewModel.returnNozzleAndFinalize() },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = BrandSilver, contentColor = BrandGraphite),
                        modifier = Modifier.weight(0.8f).height(50.dp).testTag("return_nozzle_button")
                    ) {
                        Text("RETURN NOZZLE", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}
