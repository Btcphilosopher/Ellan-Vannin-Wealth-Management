package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocalCafe
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.StoreProduct

@Composable
fun ConvenienceStoreScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val products = viewModel.storeProducts

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BrandLightBg)
    ) {
        // Top Banner info
        Surface(color = BrandNavy, contentColor = BrandWhite, tonalElevation = 4.dp) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(Icons.Default.ShoppingBag, contentDescription = null, tint = BrandWhite, modifier = Modifier.size(36.dp))
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "AMERICAN CONVENIENCE STORE",
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Open 24 Hours · Hot Coffee · Fresh Paninis · Automotive Care",
                    fontSize = 11.sp,
                    color = BrandSilver.copy(alpha = 0.7f),
                    textAlign = TextAlign.Center
                )
            }
        }

        Column(modifier = Modifier.padding(16.dp).weight(1f)) {
            SectionHeader("Freshly Brewed & Prepared Menu")
            
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize().testTag("store_products_grid")
            ) {
                items(products) { product ->
                    StoreProductCard(product = product)
                }
            }
        }
    }
}

@Composable
fun StoreProductCard(product: StoreProduct) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, BrandSilver, RoundedCornerShape(12.dp)),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = BrandWhite)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Icon Placeholder
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(90.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(BrandLightBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.LocalCafe,
                    contentDescription = null,
                    tint = BrandNavy.copy(alpha = 0.4f),
                    modifier = Modifier.size(32.dp)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = product.name,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = BrandNavy,
                maxLines = 1
            )
            
            Text(
                text = product.description,
                fontSize = 10.sp,
                color = BrandGraphite.copy(alpha = 0.6f),
                maxLines = 2,
                modifier = Modifier.height(30.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "$${String.format("%.2f", product.price)}",
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp,
                    color = BrandNavy
                )
                
                Box(
                    modifier = Modifier
                        .background(BrandRed.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "10x PTS",
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        color = BrandRed
                    )
                }
            }
        }
    }
}
