package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.*
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val viewModel: MainViewModel = viewModel()
                MainAppLayout(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainAppLayout(viewModel: MainViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()

    // Determine if we show the bottom navigation bar (only on main tabs)
    val showBottomBar = when (currentScreen) {
        AppScreen.HOME, AppScreen.STATIONS, AppScreen.REWARDS, AppScreen.RECEIPTS, AppScreen.ACCOUNT -> true
        else -> false
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(
                    containerColor = BrandNavy,
                    contentColor = BrandWhite,
                    tonalElevation = 8.dp
                ) {
                    NavigationBarItem(
                        selected = currentScreen == AppScreen.HOME,
                        onClick = { viewModel.navigateTo(AppScreen.HOME) },
                        icon = { Icon(Icons.Default.Home, contentDescription = "Home", modifier = Modifier.size(24.dp)) },
                        label = { Text("Home", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = BrandRed,
                            selectedTextColor = BrandWhite,
                            unselectedIconColor = BrandSilver.copy(alpha = 0.6f),
                            unselectedTextColor = BrandSilver.copy(alpha = 0.6f),
                            indicatorColor = BrandNavy
                        ),
                        modifier = Modifier.testTag("nav_tab_home")
                    )

                    NavigationBarItem(
                        selected = currentScreen == AppScreen.STATIONS,
                        onClick = { viewModel.navigateTo(AppScreen.STATIONS) },
                        icon = { Icon(Icons.Default.Directions, contentDescription = "Stations", modifier = Modifier.size(24.dp)) },
                        label = { Text("Stations", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = BrandRed,
                            selectedTextColor = BrandWhite,
                            unselectedIconColor = BrandSilver.copy(alpha = 0.6f),
                            unselectedTextColor = BrandSilver.copy(alpha = 0.6f),
                            indicatorColor = BrandNavy
                        ),
                        modifier = Modifier.testTag("nav_tab_stations")
                    )

                    NavigationBarItem(
                        selected = currentScreen == AppScreen.REWARDS,
                        onClick = { viewModel.navigateTo(AppScreen.REWARDS) },
                        icon = { Icon(Icons.Default.Star, contentDescription = "Rewards", modifier = Modifier.size(24.dp)) },
                        label = { Text("Rewards", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = BrandRed,
                            selectedTextColor = BrandWhite,
                            unselectedIconColor = BrandSilver.copy(alpha = 0.6f),
                            unselectedTextColor = BrandSilver.copy(alpha = 0.6f),
                            indicatorColor = BrandNavy
                        ),
                        modifier = Modifier.testTag("nav_tab_rewards")
                    )

                    NavigationBarItem(
                        selected = currentScreen == AppScreen.RECEIPTS,
                        onClick = { viewModel.navigateTo(AppScreen.RECEIPTS) },
                        icon = { Icon(Icons.Default.ReceiptLong, contentDescription = "Receipts", modifier = Modifier.size(24.dp)) },
                        label = { Text("Receipts", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = BrandRed,
                            selectedTextColor = BrandWhite,
                            unselectedIconColor = BrandSilver.copy(alpha = 0.6f),
                            unselectedTextColor = BrandSilver.copy(alpha = 0.6f),
                            indicatorColor = BrandNavy
                        ),
                        modifier = Modifier.testTag("nav_tab_receipts")
                    )

                    NavigationBarItem(
                        selected = currentScreen == AppScreen.ACCOUNT,
                        onClick = { viewModel.navigateTo(AppScreen.ACCOUNT) },
                        icon = { Icon(Icons.Default.Settings, contentDescription = "Account", modifier = Modifier.size(24.dp)) },
                        label = { Text("Account", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = BrandRed,
                            selectedTextColor = BrandWhite,
                            unselectedIconColor = BrandSilver.copy(alpha = 0.6f),
                            unselectedTextColor = BrandSilver.copy(alpha = 0.6f),
                            indicatorColor = BrandNavy
                        ),
                        modifier = Modifier.testTag("nav_tab_account")
                    )
                }
            }
        }
    ) { innerPadding ->
        val screenModifier = Modifier.padding(innerPadding)

        when (currentScreen) {
            AppScreen.HOME -> HomeScreen(viewModel = viewModel, modifier = screenModifier)
            AppScreen.STATIONS -> StationsScreen(viewModel = viewModel, modifier = screenModifier)
            AppScreen.REWARDS -> RewardsScreen(viewModel = viewModel, modifier = screenModifier)
            AppScreen.RECEIPTS -> ReceiptsScreen(viewModel = viewModel, modifier = screenModifier)
            AppScreen.ACCOUNT -> AccountScreen(viewModel = viewModel, modifier = screenModifier)
            AppScreen.PUMP_SETUP -> PumpScreen(viewModel = viewModel, modifier = screenModifier)
            AppScreen.PUMP_FUELLING -> FuellingScreen(viewModel = viewModel, modifier = screenModifier)
            AppScreen.RECEIPT_DETAIL -> ReceiptDetailScreen(viewModel = viewModel, modifier = screenModifier)
            AppScreen.CONVENIENCE_STORE -> ConvenienceStoreScreen(viewModel = viewModel, modifier = screenModifier)
            AppScreen.VEHICLE_GARAGE -> VehicleGarageScreen(viewModel = viewModel, modifier = screenModifier)
        }
    }
}
