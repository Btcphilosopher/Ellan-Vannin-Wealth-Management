package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import com.example.ui.theme.SouthernValueAirTheme
import com.example.ui.components.TopNavBar
import com.example.localization.AppLanguage

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [36])
class GreetingScreenshotTest {

  @get:Rule val composeTestRule = createComposeRule()

  @Test
  fun greeting_screenshot() {
    composeTestRule.setContent {
      SouthernValueAirTheme {
        TopNavBar(
          currentLanguage = AppLanguage.ZH_CN,
          unreadNotificationCount = 2,
          onToggleLanguage = {},
          onOpenNotifications = {}
        )
      }
    }

    composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/greeting.png")
  }
}
