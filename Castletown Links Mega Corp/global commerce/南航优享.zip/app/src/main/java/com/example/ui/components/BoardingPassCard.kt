package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.theme.MetallicGold
import androidx.compose.ui.unit.sp
import com.example.localization.AppLanguage
import com.example.model.BoardingPass
import com.example.ui.theme.*

@Composable
fun BoardingPassCard(
    pass: BoardingPass,
    currentLanguage: AppLanguage
) {
    val isZh = currentLanguage == AppLanguage.ZH_CN

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = SurfaceCardWhite,
        shadowElevation = 4.dp,
        border = BorderStroke(1.dp, BorderLight),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Navy Header Banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DeepAirlineBlue)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.FlightTakeoff, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isZh) "南航优享 电子登机牌" else "SOUTHERN VALUE BOARDING PASS",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = ControlledRed
                    ) {
                        Text(
                            text = if (isZh) "已值机" else "CHECKED-IN",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Column(modifier = Modifier.padding(16.dp)) {
                // Route Display
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(pass.origin.cityZh, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text(pass.origin.code, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = DeepAirlineBlue)
                        Text("${pass.origin.nameZh} ${pass.terminal}", fontSize = 12.sp, color = TextSecondary)
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(pass.flightNumber, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = DeepAirlineBlue)
                        Text(pass.dateStr, fontSize = 12.sp, color = TextSecondary)
                        Icon(Icons.Default.FlightTakeoff, contentDescription = null, tint = DeepAirlineBlue, modifier = Modifier.size(20.dp))
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(pass.destination.cityZh, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text(pass.destination.code, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = DeepAirlineBlue)
                        Text(pass.destination.nameZh, fontSize = 12.sp, color = TextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Dashed Cutout Divider
                Canvas(modifier = Modifier.fillMaxWidth().height(1.dp)) {
                    drawLine(
                        color = Color.Gray.copy(alpha = 0.4f),
                        start = Offset(0f, 0f),
                        end = Offset(size.width, 0f),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Key Info Grid: Seat, Gate, Boarding Time, Departure Time
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    InfoTile(label = if (isZh) "座位号" else "SEAT", value = pass.seatNo, isHighlight = true)
                    InfoTile(label = if (isZh) "登机口" else "GATE", value = pass.gate, isHighlight = true)
                    InfoTile(label = if (isZh) "登机时间" else "BOARDING", value = pass.boardingTime, isHighlight = false)
                    InfoTile(label = if (isZh) "起飞时间" else "DEPARTURE", value = pass.departureTime, isHighlight = false)
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Passenger & Sequence Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(VeryLightBlue, RoundedCornerShape(8.dp))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(if (isZh) "旅客姓名 Passenger" else "Passenger Name", fontSize = 11.sp, color = TextSecondary)
                        Text(pass.passengerName, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextDarkPrimary)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(if (isZh) "登机序号" else "Seq No.", fontSize = 11.sp, color = TextSecondary)
                        Text("#${pass.sequenceNo}", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = DeepAirlineBlue)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // QR Code Display
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, BorderLight),
                        color = Color.White,
                        modifier = Modifier.padding(8.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.QrCode,
                                contentDescription = "QR Code",
                                tint = TextDarkPrimary,
                                modifier = Modifier.size(120.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = pass.qrCodePayload,
                                fontSize = 10.sp,
                                color = TextSecondary
                            )
                        }
                    }

                    Text(
                        text = if (isZh) "请在安检及登机口出示此电子二维码" else "Present QR code at security & boarding gate",
                        fontSize = 11.sp,
                        color = TextSecondary,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}

@Composable
private fun InfoTile(label: String, value: String, isHighlight: Boolean) {
    Column {
        Text(label, fontSize = 10.sp, color = TextSecondary, fontWeight = FontWeight.Medium)
        Text(
            text = value,
            fontSize = if (isHighlight) 20.sp else 16.sp,
            fontWeight = FontWeight.ExtraBold,
            color = if (isHighlight) ControlledRed else TextDarkPrimary
        )
    }
}
