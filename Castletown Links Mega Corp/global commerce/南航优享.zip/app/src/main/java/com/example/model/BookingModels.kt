package com.example.model

enum class DocType(val zh: String, val en: String) {
    ID_CARD("居民身份证", "PRC ID Card"),
    PASSPORT("护照", "Passport"),
    HK_MACAO_PASS("港澳居民来往内地通行证", "Mainland Travel Permit for HK/Macao")
}

data class Passenger(
    val id: String,
    val name: String,
    val docType: DocType = DocType.ID_CARD,
    val docNumber: String,
    val nationality: String = "中国 China",
    val birthDate: String = "1992-08-18",
    val phone: String = "138****8888",
    val selectedSeatNo: String? = null
)

enum class PaymentMethod(val id: String, val nameZh: String, val nameEn: String, val iconName: String) {
    WECHAT("wechat", "微信支付", "WeChat Pay", "ic_wechat"),
    ALIPAY("alipay", "支付宝", "Alipay", "ic_alipay"),
    UNIONPAY("unionpay", "云闪付 / 银联", "UnionPay", "ic_unionpay"),
    AIRLINE_WALLET("wallet", "优享钱包 (余额 ¥1,850)", "Southern Wallet", "ic_wallet"),
    BANK_CARD("card", "快捷银行卡", "Credit/Debit Card", "ic_card")
}

enum class PaymentStatus(val zh: String, val en: String) {
    PENDING("待支付", "Pending Payment"),
    PROCESSING("支付处理中", "Payment Processing"),
    PAID("已出票", "Ticket Issued"),
    CANCELLED("已取消", "Cancelled"),
    REFUNDED("已退票", "Refunded")
}

data class Booking(
    val bookingRef: String, // 6 char code, e.g. CZ8892
    val flight: Flight,
    val fareType: FareType,
    val cabinClass: CabinClass = CabinClass.ECONOMY,
    val passengers: List<Passenger>,
    val ancillaryServices: List<AncillaryService> = emptyList(),
    val totalPrice: Int,
    val paymentStatus: PaymentStatus = PaymentStatus.PENDING,
    val paymentMethod: PaymentMethod? = null,
    val createdAtTimestamp: Long = System.currentTimeMillis(),
    val isCheckedIn: Boolean = false,
    val checkedInSeats: Map<String, String> = emptyMap() // passengerId -> seatNo
)

data class BoardingPass(
    val passId: String,
    val bookingRef: String,
    val flightNumber: String,
    val origin: Airport,
    val destination: Airport,
    val dateStr: String,
    val passengerName: String,
    val seatNo: String,
    val cabinClass: String,
    val gate: String,
    val terminal: String,
    val boardingTime: String,
    val departureTime: String,
    val sequenceNo: String = "042",
    val qrCodePayload: String = "CZ3128-CAN-SHA-24A-PASSENGER-VALID"
)

enum class BaggageStatus(val zh: String, val en: String) {
    CHECKED_IN("已托运 / 收运", "Checked-in"),
    IN_TRANSIT("运输中", "In Transit"),
    LOADED("已装机", "Loaded on Board"),
    ARRIVED("已到达", "Arrived at Dest"),
    ON_CAROUSEL("传送中", "On Baggage Carousel"),
    CLAIMED("已领取", "Claimed"),
    DELAYED("行李异常", "Disrupted / Delayed")
}

data class BaggageItem(
    val tagNumber: String, // e.g. CZ123456
    val bookingRef: String,
    val passengerName: String,
    val weightKg: Int = 18,
    val status: BaggageStatus = BaggageStatus.CHECKED_IN,
    val carousel: String = "18",
    val lastUpdateLocation: String = "广州白云 T2 Baggage Hub A"
)
