package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.AppLanguage
import com.example.ui.theme.*
import com.example.viewmodel.MainViewModel

@Composable
fun CustomerServiceAndProfileScreen(
    viewModel: MainViewModel,
    initialTab: Int = 0 // 0: Profile, 1: Chat Assistant
) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isZh = currentLanguage == AppLanguage.ZH_CN
    val isCorporateMode by viewModel.isCorporateMode.collectAsState()
    val chatMessages by viewModel.chatMessages.collectAsState()

    var subTab by remember { mutableStateOf(initialTab) }
    var chatInputText by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmGreyBackground)
    ) {
        // Sub-Tab Navigation Bar
        Surface(color = SurfaceCardWhite, shadowElevation = 2.dp) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .background(WarmGreyBackground, RoundedCornerShape(8.dp))
                    .padding(4.dp)
            ) {
                TabChip(title = if (isZh) "个人中心" else "Profile", isSelected = subTab == 0, modifier = Modifier.weight(1f)) {
                    subTab = 0
                }
                TabChip(title = if (isZh) "在线智能客服" else "Customer Care", isSelected = subTab == 1, modifier = Modifier.weight(1f)) {
                    subTab = 1
                }
            }
        }

        if (subTab == 0) {
            // Passenger Profile Screen
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // User Header Card
                item {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = SurfaceCardWhite,
                        border = BorderStroke(1.dp, BorderLight),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.AccountCircle, contentDescription = null, tint = DeepAirlineBlue, modifier = Modifier.size(52.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text("张伟 WEI ZHANG", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextDarkPrimary)
                                Text("138****8888 • ${if (isZh) "普通/银卡会员" else "Silver Card"}", fontSize = 12.sp, color = TextSecondary)
                            }
                        }
                    }
                }

                // Corporate Travel Mode Toggle (企业差旅模式)
                item {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = SurfaceCardWhite,
                        border = BorderStroke(1.dp, BorderLight),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(if (isZh) "企业差旅管理模式" else "Corporate Travel Mode", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextDarkPrimary)
                                Text(if (isZh) "统一企业支付，自动开具电子发票" else "Corporate billing & e-invoicing", fontSize = 12.sp, color = TextSecondary)
                            }
                            Switch(
                                checked = isCorporateMode,
                                onCheckedChange = { viewModel.toggleCorporateMode() },
                                colors = SwitchDefaults.colors(checkedThumbColor = DeepAirlineBlue)
                            )
                        }
                    }
                }

                // Options List
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        ProfileOptionRow(icon = Icons.Default.People, title = if (isZh) "常用乘机人管理" else "Frequent Passengers", isZh = isZh)
                        ProfileOptionRow(icon = Icons.Default.Receipt, title = if (isZh) "电子发票与报销凭证" else "E-Invoices & Receipts", isZh = isZh)
                        ProfileOptionRow(icon = Icons.Default.Payment, title = if (isZh) "快捷支付方式设置" else "Saved Payment Methods", isZh = isZh)
                        ProfileOptionRow(icon = Icons.Default.Translate, title = if (isZh) "语言设置 (Language)" else "Language Settings", isZh = isZh) {
                            viewModel.toggleLanguage()
                        }
                        ProfileOptionRow(icon = Icons.Default.Map, title = if (isZh) "南航优享全国航线网络图" else "Route Network Map", isZh = isZh)
                        ProfileOptionRow(icon = Icons.Default.Security, title = if (isZh) "隐私政策与客运规章" else "Privacy & Carriage Rules", isZh = isZh)
                    }
                }
            }
        } else {
            // Customer Service AI Assistant Chat View
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(chatMessages) { msg ->
                        ChatBubble(msg = msg)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Input Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = chatInputText,
                        onValueChange = { chatInputText = it },
                        placeholder = { Text(if (isZh) "输入您的咨询问题..." else "Type message...") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(20.dp),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = {
                            viewModel.sendCustomerServiceMessage(chatInputText)
                            chatInputText = ""
                        },
                        modifier = Modifier
                            .size(44.dp)
                            .background(DeepAirlineBlue, RoundedCornerShape(22.dp))
                    ) {
                        Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.White, modifier = Modifier.size(20.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun ChatBubble(msg: com.example.viewmodel.ChatMessage) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (msg.isUser) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = if (msg.isUser) DeepAirlineBlue else SurfaceCardWhite,
            border = if (msg.isUser) null else BorderStroke(1.dp, BorderLight),
            shadowElevation = 1.dp,
            modifier = Modifier.widthIn(max = 280.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = msg.text,
                    fontSize = 14.sp,
                    color = if (msg.isUser) Color.White else TextDarkPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = msg.timestamp,
                    fontSize = 10.sp,
                    color = if (msg.isUser) Color.White.copy(alpha = 0.7f) else TextSecondary,
                    modifier = Modifier.align(Alignment.End)
                )
            }
        }
    }
}

@Composable
private fun ProfileOptionRow(icon: ImageVector, title: String, isZh: Boolean, onClick: () -> Unit = {}) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = SurfaceCardWhite,
        border = BorderStroke(1.dp, BorderLight),
        modifier = Modifier.fillMaxWidth().clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = icon, contentDescription = null, tint = DeepAirlineBlue, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Text(title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = TextDarkPrimary)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = TextSecondary)
        }
    }
}

@Composable
private fun TabChip(title: String, isSelected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = if (isSelected) SurfaceCardWhite else Color.Transparent,
        modifier = modifier.padding(2.dp),
        onClick = onClick
    ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(vertical = 8.dp)) {
            Text(
                text = title,
                fontSize = 13.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) DeepAirlineBlue else TextSecondary
            )
        }
    }
}
