package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "bookings")
data class BookingEntity(
    @PrimaryKey val bookingRef: String,
    val flightId: String,
    val originCode: String,
    val destCode: String,
    val dateStr: String,
    val flightNumber: String,
    val departureTime: String,
    val arrivalTime: String,
    val fareTypeName: String,
    val cabinClassName: String,
    val passengersJson: String, // serialized json list
    val ancillaryJson: String,   // serialized json list
    val totalPrice: Int,
    val paymentStatusName: String,
    val paymentMethodId: String?,
    val isCheckedIn: Boolean,
    val checkedInSeatsJson: String,
    val createdAtTimestamp: Long
)

@Entity(tableName = "flights")
data class FlightEntity(
    @PrimaryKey val id: String,
    val flightNumber: String,
    val originCode: String,
    val destCode: String,
    val departureTime: String,
    val arrivalTime: String,
    val dateStr: String,
    val durationMinutes: Int,
    val aircraftType: String,
    val basePrice: Int,
    val statusName: String,
    val gate: String,
    val terminal: String,
    val checkinDesk: String,
    val securityZone: String,
    val baggageCarousel: String,
    val isDirect: Boolean,
    val delayMinutes: Int,
    val delayReasonZh: String?,
    val delayReasonEn: String?
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey val id: String,
    val titleZh: String,
    val titleEn: String,
    val messageZh: String,
    val messageEn: String,
    val timestamp: String,
    val isRead: Boolean
)

@Entity(tableName = "baggage")
data class BaggageEntity(
    @PrimaryKey val tagNumber: String,
    val bookingRef: String,
    val passengerName: String,
    val weightKg: Int,
    val statusName: String,
    val carousel: String,
    val lastUpdateLocation: String
)
