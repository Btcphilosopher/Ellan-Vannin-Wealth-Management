package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.AppLanguage
import com.example.ui.theme.*

@Composable
fun SeatMapComposable(
    currentLanguage: AppLanguage,
    selectedSeatNo: String?,
    onSeatSelected: (String) -> Unit
) {
    val isZh = currentLanguage == AppLanguage.ZH_CN

    // Generate synthetic seat states
    val occupiedSeats = remember { setOf("1A", "1C", "2B", "3D", "4A", "4E", "5F", "6B", "7C", "8A", "9D", "10F") }
    val colsLeft = listOf("A", "B", "C")
    val colsRight = listOf("D", "E", "F")

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(SurfaceCardWhite, RoundedCornerShape(12.dp))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Seat Legend Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            SeatLegendItem(color = SurfaceCardWhite, border = BorderLight, label = if (isZh) "可选" else "Available")
            SeatLegendItem(color = DeepAirlineBlue, border = DeepAirlineBlue, label = if (isZh) "已选" else "Selected")
            SeatLegendItem(color = Color.LightGray, border = Color.LightGray, label = if (isZh) "已占用" else "Occupied")
            SeatLegendItem(color = SkyLightBlue, border = DeepAirlineBlue, label = if (isZh) "宽座 +¥39" else "Legroom +¥39")
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Airplane Front Nose Indicator
        Surface(
            shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
            color = WarmGreyBackground,
            border = BorderStroke(1.dp, BorderLight),
            modifier = Modifier
                .width(220.dp)
                .height(32.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(
                    text = if (isZh) "▲ 机头 前方 ▲" else "▲ FRONT OF AIRCRAFT ▲",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondary
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Column Labels Row (A B C | AISLE | D E F)
        Row(
            modifier = Modifier.width(300.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                colsLeft.forEach { col ->
                    Box(modifier = Modifier.size(36.dp), contentAlignment = Alignment.Center) {
                        Text(col, fontWeight = FontWeight.Bold, color = DeepAirlineBlue)
                    }
                }
            }
            Text(if (isZh) "过道" else "Aisle", fontSize = 11.sp, color = TextSecondary)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                colsRight.forEach { col ->
                    Box(modifier = Modifier.size(36.dp), contentAlignment = Alignment.Center) {
                        Text(col, fontWeight = FontWeight.Bold, color = DeepAirlineBlue)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Seat Rows
        LazyColumn(
            modifier = Modifier.height(320.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(12) { index ->
                val rowNum = index + 1
                val isExtraLegroom = rowNum <= 2

                Row(
                    modifier = Modifier.width(300.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Left 3 seats (A, B, C)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        colsLeft.forEach { col ->
                            val seatId = "$rowNum$col"
                            val isOccupied = occupiedSeats.contains(seatId)
                            val isSelected = selectedSeatNo == seatId

                            SeatButton(
                                seatId = seatId,
                                isOccupied = isOccupied,
                                isSelected = isSelected,
                                isExtraLegroom = isExtraLegroom,
                                onClick = { if (!isOccupied) onSeatSelected(seatId) }
                            )
                        }
                    }

                    // Row number indicator
                    Text(
                        text = "$rowNum",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextSecondary,
                        modifier = Modifier.width(24.dp)
                    )

                    // Right 3 seats (D, E, F)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        colsRight.forEach { col ->
                            val seatId = "$rowNum$col"
                            val isOccupied = occupiedSeats.contains(seatId)
                            val isSelected = selectedSeatNo == seatId

                            SeatButton(
                                seatId = seatId,
                                isOccupied = isOccupied,
                                isSelected = isSelected,
                                isExtraLegroom = isExtraLegroom,
                                onClick = { if (!isOccupied) onSeatSelected(seatId) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SeatLegendItem(color: Color, border: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(16.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(color)
                .border(1.dp, border, RoundedCornerShape(4.dp))
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(label, fontSize = 10.sp, color = TextSecondary)
    }
}

@Composable
private fun SeatButton(
    seatId: String,
    isOccupied: Boolean,
    isSelected: Boolean,
    isExtraLegroom: Boolean,
    onClick: () -> Unit
) {
    val bgColor = when {
        isSelected -> DeepAirlineBlue
        isOccupied -> Color(0xFFE2E8F0)
        isExtraLegroom -> SkyLightBlue
        else -> SurfaceCardWhite
    }

    val borderColor = when {
        isSelected -> DeepAirlineBlue
        isOccupied -> Color.Transparent
        isExtraLegroom -> DeepAirlineBlue
        else -> BorderLight
    }

    val textColor = when {
        isSelected -> Color.White
        isOccupied -> Color.Gray
        else -> TextDarkPrimary
    }

    Box(
        modifier = Modifier
            .size(36.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .border(1.dp, borderColor, RoundedCornerShape(6.dp))
            .clickable(enabled = !isOccupied) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        if (isSelected) {
            Icon(Icons.Default.Check, contentDescription = "Selected", tint = Color.White, modifier = Modifier.size(18.dp))
        } else {
            Text(
                text = seatId,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = textColor
            )
        }
    }
}
