package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.AppLanguage
import com.example.model.BoardingPass
import com.example.model.Booking
import com.example.ui.components.BoardingPassCard
import com.example.ui.theme.*
import com.example.viewmodel.MainViewModel

@Composable
fun TripsAndAirportModeScreen(
    viewModel: MainViewModel,
    onNavigateToStatus: () -> Unit,
    onNavigateToBaggage: () -> Unit
) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isZh = currentLanguage == AppLanguage.ZH_CN
    val allBookings by viewModel.allBookings.collectAsState()

    var activeSubTab by remember { mutableStateOf(0) } // 0: 我的行程 Trips, 1: 机场模式 Airport Mode

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmGreyBackground)
    ) {
        // Sub-Tab Toggle Bar
        Surface(color = SurfaceCardWhite, shadowElevation = 2.dp) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .background(WarmGreyBackground, RoundedCornerShape(8.dp))
                    .padding(4.dp)
            ) {
                TabChip(title = if (isZh) "即将出发行程" else "My Trips", isSelected = activeSubTab == 0, modifier = Modifier.weight(1f)) {
                    activeSubTab = 0
                }
                TabChip(title = if (isZh) "机场模式 (广州CAN)" else "Airport Mode", isSelected = activeSubTab == 1, modifier = Modifier.weight(1f)) {
                    activeSubTab = 1
                }
            }
        }

        if (activeSubTab == 0) {
            // My Trips View
            if (allBookings.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.CardTravel, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(if (isZh) "暂无出行行程" else "No active trips", fontSize = 16.sp, color = TextSecondary)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(allBookings) { booking ->
                        TripDetailCard(
                            booking = booking,
                            currentLanguage = currentLanguage,
                            onPerformCheckIn = { seatNo ->
                                val pId = booking.passengers.firstOrNull()?.id ?: "P101"
                                viewModel.performCheckIn(booking.bookingRef, mapOf(pId to seatNo))
                            },
                            onViewBaggage = onNavigateToBaggage,
                            onViewStatus = onNavigateToStatus
                        )
                    }
                }
            }
        } else {
            // Airport Mode View (机场模式)
            val firstBooking = allBookings.firstOrNull()
            AirportModeView(booking = firstBooking, currentLanguage = currentLanguage)
        }
    }
}

@Composable
private fun TripDetailCard(
    booking: Booking,
    currentLanguage: AppLanguage,
    onPerformCheckIn: (String) -> Unit,
    onViewBaggage: () -> Unit,
    onViewStatus: () -> Unit
) {
    val isZh = currentLanguage == AppLanguage.ZH_CN
    var showBoardingPassModal by remember { mutableStateOf(false) }

    val pass = BoardingPass(
        passId = "PASS_" + booking.bookingRef,
        bookingRef = booking.bookingRef,
        flightNumber = booking.flight.flightNumber,
        origin = booking.flight.origin,
        destination = booking.flight.destination,
        dateStr = booking.flight.dateStr,
        passengerName = booking.passengers.firstOrNull()?.name ?: "张伟",
        seatNo = booking.checkedInSeats.values.firstOrNull() ?: "24A",
        cabinClass = booking.cabinClass.zh,
        gate = booking.flight.gate,
        terminal = booking.flight.terminal,
        boardingTime = "07:35",
        departureTime = booking.flight.departureTime
    )

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = SurfaceCardWhite,
        shadowElevation = 3.dp,
        border = BorderStroke(1.dp, BorderLight),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(shape = RoundedCornerShape(4.dp), color = DeepAirlineBlue) {
                        Text(booking.flight.flightNumber, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(booking.flight.dateStr, fontSize = 13.sp, color = TextSecondary)
                }

                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = if (booking.isCheckedIn) SuccessGreen.copy(alpha = 0.15f) else ControlledRed.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = if (booking.isCheckedIn) (if (isZh) "已在线值机" else "Checked-In") else (if (isZh) "开放在线值机" else "Check-in Open"),
                        color = if (booking.isCheckedIn) SuccessGreen else ControlledRed,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(booking.flight.departureTime, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = TextDarkPrimary)
                    Text(booking.flight.origin.getDisplayName(isZh), fontSize = 13.sp, color = TextSecondary)
                }
                Icon(Icons.Default.ArrowForward, contentDescription = null, tint = DeepAirlineBlue)
                Column(horizontalAlignment = Alignment.End) {
                    Text(booking.flight.arrivalTime, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = TextDarkPrimary)
                    Text(booking.flight.destination.getDisplayName(isZh), fontSize = 13.sp, color = TextSecondary)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = BorderLight)
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                if (!booking.isCheckedIn) {
                    Button(
                        onClick = { onPerformCheckIn("24A") },
                        colors = ButtonDefaults.buttonColors(containerColor = DeepAirlineBlue),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(if (isZh) "一键在线值机" else "Check In", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                } else {
                    Button(
                        onClick = { showBoardingPassModal = true },
                        colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.QrCode, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (isZh) "电子登机牌" else "Boarding Pass", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                OutlinedButton(
                    onClick = onViewStatus,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(if (isZh) "航班动态" else "Status", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    if (showBoardingPassModal) {
        AlertDialog(
            onDismissRequest = { showBoardingPassModal = false },
            confirmButton = {
                TextButton(onClick = { showBoardingPassModal = false }) {
                    Text(if (isZh) "关闭" else "Close", fontWeight = FontWeight.Bold)
                }
            },
            text = {
                BoardingPassCard(pass = pass, currentLanguage = currentLanguage)
            }
        )
    }
}

@Composable
private fun AirportModeView(
    booking: Booking?,
    currentLanguage: AppLanguage
) {
    val isZh = currentLanguage == AppLanguage.ZH_CN

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = AviationBlueHeader,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isZh) "广州白云国际机场 CAN (T2)" else "Guangzhou Baiyun CAN (T2)",
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Surface(shape = RoundedCornerShape(4.dp), color = ControlledRed) {
                            Text(if (isZh) "机场模式已激活" else "Active Mode", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = if (isZh) "距离航班 CZ 3128 登机还有 42 分钟" else "42 minutes until boarding for CZ 3128",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        item {
            Text(if (isZh) "机场全流程导航指引" else "Airport Journey Navigation", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextDarkPrimary)
            Spacer(modifier = Modifier.height(8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                AirportGuideTile(step = "1", title = if (isZh) "人工 / 自助值机柜台" else "Check-in Desk", location = "T2 航站楼 A区 12-18号", isZh = isZh)
                AirportGuideTile(step = "2", title = if (isZh) "安全检查通道" else "Security Control", location = "T2 B区 快捷安检 02通道", isZh = isZh)
                AirportGuideTile(step = "3", title = if (isZh) "登机口" else "Boarding Gate", location = "T2 B23 登机口 (预计07:35开始登机)", isZh = isZh)
                AirportGuideTile(step = "4", title = if (isZh) "到达托运行李提取" else "Baggage Claim", location = "到达层 18号转盘", isZh = isZh)
            }
        }
    }
}

@Composable
private fun TabChip(title: String, isSelected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = if (isSelected) SurfaceCardWhite else Color.Transparent,
        modifier = modifier.padding(2.dp),
        onClick = onClick
    ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(vertical = 8.dp)) {
            Text(
                text = title,
                fontSize = 13.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) DeepAirlineBlue else TextSecondary
            )
        }
    }
}

@Composable
private fun AirportGuideTile(step: String, title: String, location: String, isZh: Boolean) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = SurfaceCardWhite,
        border = BorderStroke(1.dp, BorderLight),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = DeepAirlineBlue,
                modifier = Modifier.size(32.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(step, color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextDarkPrimary)
                Text(location, fontSize = 12.sp, color = DeepAirlineBlue, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}
