package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.AppLanguage
import com.example.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.viewmodel.BookingStep
import com.example.viewmodel.MainViewModel

@Composable
fun FlightSearchAndBookingScreen(
    viewModel: MainViewModel,
    onFinishBooking: () -> Unit
) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isZh = currentLanguage == AppLanguage.ZH_CN

    val bookingStep by viewModel.bookingStep.collectAsState()
    val searchResults by viewModel.searchResults.collectAsState()
    val isSearching by viewModel.isSearching.collectAsState()
    val selectedFlight by viewModel.selectedFlight.collectAsState()
    val selectedFareType by viewModel.selectedFareType.collectAsState()
    val passengerDetails by viewModel.passengerDetails.collectAsState()
    val selectedSeats by viewModel.selectedSeats.collectAsState()
    val selectedAncillaries by viewModel.selectedAncillaries.collectAsState()
    val selectedPaymentMethod by viewModel.selectedPaymentMethod.collectAsState()
    val isPaymentProcessing by viewModel.isPaymentProcessing.collectAsState()
    val latestBooking by viewModel.latestConfirmedBooking.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmGreyBackground)
    ) {
        // Step Indicator Banner (if in booking flow)
        if (bookingStep != BookingStep.FLIGHT_LIST && bookingStep != BookingStep.CONFIRMATION) {
            Surface(color = SurfaceCardWhite, shadowElevation = 2.dp) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { viewModel.resetBookingFlow() }) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = DeepAirlineBlue)
                        }
                        Text(
                            text = when (bookingStep) {
                                BookingStep.FARE_SELECTION -> if (isZh) "1. 选择票价等级" else "1. Select Fare"
                                BookingStep.PASSENGER_INFO -> if (isZh) "2. 填写乘客信息" else "2. Passengers"
                                BookingStep.SEAT_SELECTION -> if (isZh) "3. 在线选择座位" else "3. Select Seat"
                                BookingStep.ANCILLARY_SERVICES -> if (isZh) "4. 增值服务选购" else "4. Add Services"
                                BookingStep.PAYMENT -> if (isZh) "5. 确认支付出票" else "5. Payment"
                                else -> ""
                            },
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = DeepAirlineBlue
                        )
                    }
                    Text(
                        text = selectedFlight?.flightNumber ?: "",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextSecondary
                    )
                }
            }
        }

        // Screen Body based on BookingStep
        when (bookingStep) {
            BookingStep.FLIGHT_LIST -> {
                FlightListStep(
                    searchResults = searchResults,
                    isSearching = isSearching,
                    currentLanguage = currentLanguage,
                    onSelectFlight = { viewModel.startBooking(it) }
                )
            }
            BookingStep.FARE_SELECTION -> {
                FareSelectionStep(
                    flight = selectedFlight!!,
                    selectedFareType = selectedFareType,
                    currentLanguage = currentLanguage,
                    onSelectFare = { viewModel.selectFare(it) }
                )
            }
            BookingStep.PASSENGER_INFO -> {
                PassengerInfoStep(
                    passengers = passengerDetails,
                    currentLanguage = currentLanguage,
                    onConfirmPassengers = { viewModel.updatePassengerInfo(it) }
                )
            }
            BookingStep.SEAT_SELECTION -> {
                SeatSelectionStep(
                    passengers = passengerDetails,
                    selectedSeats = selectedSeats,
                    currentLanguage = currentLanguage,
                    onSeatSelected = { pId, seatNo -> viewModel.selectSeatForPassenger(pId, seatNo) },
                    onProceed = { viewModel.proceedToAncillaries() }
                )
            }
            BookingStep.ANCILLARY_SERVICES -> {
                AncillaryServicesStep(
                    selectedAncillaries = selectedAncillaries,
                    currentLanguage = currentLanguage,
                    onToggleService = { viewModel.toggleAncillaryService(it) },
                    onProceedToPayment = { viewModel.proceedToPayment() }
                )
            }
            BookingStep.PAYMENT -> {
                PaymentSheet(
                    totalPrice = viewModel.calculateTotalPrice(),
                    selectedMethod = selectedPaymentMethod,
                    isProcessing = isPaymentProcessing,
                    currentLanguage = currentLanguage,
                    onMethodSelected = { viewModel.selectPaymentMethod(it) },
                    onConfirmPayment = { viewModel.executePaymentAndConfirm() }
                )
            }
            BookingStep.CONFIRMATION -> {
                ConfirmationStep(
                    booking = latestBooking,
                    currentLanguage = currentLanguage,
                    onFinish = onFinishBooking
                )
            }
        }
    }
}

@Composable
private fun FlightListStep(
    searchResults: List<Flight>,
    isSearching: Boolean,
    currentLanguage: AppLanguage,
    onSelectFlight: (Flight) -> Unit
) {
    val isZh = currentLanguage == AppLanguage.ZH_CN

    if (isSearching) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator(color = DeepAirlineBlue)
                Spacer(modifier = Modifier.height(12.dp))
                Text(if (isZh) "正在实时查询南航优享航班..." else "Searching flights...", color = TextSecondary)
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isZh) "找到 ${searchResults.size} 个可用航班" else "Found ${searchResults.size} flights",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextDarkPrimary
                    )
                    Text(
                        text = if (isZh) "按价格排序 ↓" else "Sort by Price ↓",
                        fontSize = 12.sp,
                        color = DeepAirlineBlue,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            items(searchResults) { flight ->
                FlightCard(
                    flight = flight,
                    currentLanguage = currentLanguage,
                    onSelectFlight = onSelectFlight
                )
            }
        }
    }
}

@Composable
private fun FareSelectionStep(
    flight: Flight,
    selectedFareType: FareType,
    currentLanguage: AppLanguage,
    onSelectFare: (FareType) -> Unit
) {
    val isZh = currentLanguage == AppLanguage.ZH_CN

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = if (isZh) "机票票价等级对比与选择" else "Fare Category Comparison",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = DeepAirlineBlue
        )
        Text(
            text = if (isZh) "透明消费 • 按需购买 • 无隐性费用" else "Transparent pricing • No hidden fees",
            fontSize = 12.sp,
            color = TextSecondary
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Fare comparison cards
        val fares = listOf(FareType.BASIC, FareType.STANDARD, FareType.FLEXIBLE)

        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            fares.forEach { fare ->
                val calculatedPrice = (flight.basePrice * fare.priceMultiplier).toInt()

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = SurfaceCardWhite,
                    border = BorderStroke(2.dp, if (selectedFareType == fare) DeepAirlineBlue else BorderLight),
                    shadowElevation = if (selectedFareType == fare) 4.dp else 1.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectFare(fare) }
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = if (selectedFareType == fare) DeepAirlineBlue else VeryLightBlue
                                ) {
                                    Text(
                                        text = if (isZh) fare.zh else fare.en,
                                        color = if (selectedFareType == fare) Color.White else DeepAirlineBlue,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                                if (fare == FareType.STANDARD) {
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Surface(shape = RoundedCornerShape(4.dp), color = ControlledRed) {
                                        Text(if (isZh) "推荐" else "POPULAR", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                    }
                                }
                            }

                            Row(verticalAlignment = Alignment.Bottom) {
                                Text("¥", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = ControlledRed)
                                Text("$calculatedPrice", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = ControlledRed)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            FareBenefitRow(label = if (isZh) "托运行李" else "Baggage", value = fare.checkedBaggageAllowance, isZh = isZh)
                            FareBenefitRow(label = if (isZh) "选座服务" else "Seat Select", value = if (fare.seatSelectionFree) (if (isZh) "免费规则选座" else "Free Selection") else (if (isZh) "付费选座" else "Paid Selection"), isZh = isZh)
                            FareBenefitRow(label = if (isZh) "改签规则" else "Rebooking", value = if (isZh) fare.changePolicyZh else fare.changePolicyEn, isZh = isZh)
                            FareBenefitRow(label = if (isZh) "退票规则" else "Refund", value = if (isZh) fare.refundPolicyZh else fare.refundPolicyEn, isZh = isZh)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FareBenefitRow(label: String, value: String, isZh: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 12.sp, color = TextSecondary)
        Text(value, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextDarkPrimary)
    }
}

@Composable
private fun PassengerInfoStep(
    passengers: List<Passenger>,
    currentLanguage: AppLanguage,
    onConfirmPassengers: (List<Passenger>) -> Unit
) {
    val isZh = currentLanguage == AppLanguage.ZH_CN
    var pName by remember { mutableStateOf(passengers.firstOrNull()?.name ?: "张伟") }
    var pDocNum by remember { mutableStateOf(passengers.firstOrNull()?.docNumber ?: "440105199208188888") }
    var pPhone by remember { mutableStateOf("13888888888") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(if (isZh) "乘机人信息" else "Passenger Information", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = DeepAirlineBlue)
        Text(if (isZh) "请核对证件姓名及号码，需与乘机证件一致" else "Name must match official photo ID", fontSize = 12.sp, color = TextSecondary)

        Spacer(modifier = Modifier.height(16.dp))

        Surface(
            shape = RoundedCornerShape(12.dp),
            color = SurfaceCardWhite,
            border = BorderStroke(1.dp, BorderLight),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                OutlinedTextField(
                    value = pName,
                    onValueChange = { pName = it },
                    label = { Text(if (isZh) "乘机人姓名" else "Passenger Full Name") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = pDocNum,
                    onValueChange = { pDocNum = it },
                    label = { Text(if (isZh) "身份证件号码" else "ID / Passport Number") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = pPhone,
                    onValueChange = { pPhone = it },
                    label = { Text(if (isZh) "联系手机号 (接收航班通知)" else "Contact Mobile") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    singleLine = true
                )
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        Button(
            onClick = {
                val updated = listOf(
                    Passenger("P101", pName, DocType.ID_CARD, pDocNum, "中国 China", "1992-08-18", pPhone)
                )
                onConfirmPassengers(updated)
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            colors = ButtonDefaults.buttonColors(containerColor = DeepAirlineBlue),
            shape = RoundedCornerShape(10.dp)
        ) {
            Text(if (isZh) "下一步：选择座位" else "Next: Select Seat", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SeatSelectionStep(
    passengers: List<Passenger>,
    selectedSeats: Map<String, String>,
    currentLanguage: AppLanguage,
    onSeatSelected: (String, String) -> Unit,
    onProceed: () -> Unit
) {
    val isZh = currentLanguage == AppLanguage.ZH_CN
    val passenger = passengers.firstOrNull() ?: return
    val currentSeat = selectedSeats[passenger.id] ?: "24A"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(if (isZh) "选择座位" else "Select Seat", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = DeepAirlineBlue)
                Text("${passenger.name} (${if (isZh) "已选" else "Selected"}: $currentSeat)", fontSize = 13.sp, color = ControlledRed, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        SeatMapComposable(
            currentLanguage = currentLanguage,
            selectedSeatNo = currentSeat,
            onSeatSelected = { seatNo -> onSeatSelected(passenger.id, seatNo) }
        )

        Spacer(modifier = Modifier.weight(1f))

        Button(
            onClick = onProceed,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            colors = ButtonDefaults.buttonColors(containerColor = DeepAirlineBlue),
            shape = RoundedCornerShape(10.dp)
        ) {
            Text(if (isZh) "下一步：选购增值服务" else "Next: Add Services", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun AncillaryServicesStep(
    selectedAncillaries: List<AncillaryService>,
    currentLanguage: AppLanguage,
    onToggleService: (AncillaryService) -> Unit,
    onProceedToPayment: () -> Unit
) {
    val isZh = currentLanguage == AppLanguage.ZH_CN

    val availableServices = listOf(
        AncillaryService("MEAL01", "精选云端机上餐食", "Inflight Gourmet Meal", 45, "含粤式广式点心 / 经典商务正餐", "Includes Cantonese Dim Sum / Deluxe Meal", "ic_meal"),
        AncillaryService("WIFI01", "全程机上高速 Wi-Fi", "Inflight High-Speed Wi-Fi", 25, "空中畅连，支持即时通讯与网页浏览", "Full flight messaging and web browsing", "ic_wifi"),
        AncillaryService("LOUNGE01", "广州白云 T2 贵宾休息室", "Guangzhou T2 VIP Lounge Pass", 80, "含自助餐饮、舒适休憩区及优先登机提示", "Includes buffet, lounge and priority alert", "ic_lounge"),
        AncillaryService("BAG01", "额外托运行李 10kg", "Extra Baggage 10kg", 120, "预购优惠价，机场现场原价 ¥200", "Pre-purchase discount price", "ic_baggage")
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(if (isZh) "增值服务选购" else "Ancillary Services Marketplace", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = DeepAirlineBlue)
        Text(if (isZh) "实惠出行 • 自由搭配" else "Tailor your journey", fontSize = 12.sp, color = TextSecondary)

        Spacer(modifier = Modifier.height(16.dp))

        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            availableServices.forEach { service ->
                val isSelected = selectedAncillaries.any { it.id == service.id }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = SurfaceCardWhite,
                    border = BorderStroke(1.dp, if (isSelected) DeepAirlineBlue else BorderLight),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onToggleService(service) }
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(if (isZh) service.nameZh else service.nameEn, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextDarkPrimary)
                            Text(if (isZh) service.descriptionZh else service.descriptionEn, fontSize = 12.sp, color = TextSecondary)
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("¥${service.price}", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = ControlledRed)
                            Spacer(modifier = Modifier.width(8.dp))
                            Checkbox(
                                checked = isSelected,
                                onCheckedChange = { onToggleService(service) },
                                colors = CheckboxDefaults.colors(checkedColor = DeepAirlineBlue)
                            )
                        }
                    }
                }
            }
        }

        Button(
            onClick = onProceedToPayment,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            colors = ButtonDefaults.buttonColors(containerColor = ControlledRed),
            shape = RoundedCornerShape(10.dp)
        ) {
            Text(if (isZh) "前往结算支付" else "Proceed to Payment", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun ConfirmationStep(
    booking: Booking?,
    currentLanguage: AppLanguage,
    onFinish: () -> Unit
) {
    val isZh = currentLanguage == AppLanguage.ZH_CN
    val b = booking ?: return

    val dummyPass = BoardingPass(
        passId = "PASS_" + b.bookingRef,
        bookingRef = b.bookingRef,
        flightNumber = b.flight.flightNumber,
        origin = b.flight.origin,
        destination = b.flight.destination,
        dateStr = b.flight.dateStr,
        passengerName = b.passengers.firstOrNull()?.name ?: "张伟",
        seatNo = b.checkedInSeats.values.firstOrNull() ?: "24A",
        cabinClass = b.cabinClass.zh,
        gate = b.flight.gate,
        terminal = b.flight.terminal,
        boardingTime = "07:35",
        departureTime = b.flight.departureTime
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Icon(Icons.Default.CheckCircle, contentDescription = "Success", tint = SuccessGreen, modifier = Modifier.size(56.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text(if (isZh) "订票成功 • 电子客票已生成" else "Booking Confirmed & Ticket Issued!", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = DeepAirlineBlue)
            Text("${if (isZh) "订单编号" else "Booking Ref"}: ${b.bookingRef}", fontSize = 14.sp, color = TextSecondary, fontWeight = FontWeight.Bold)

            Spacer(modifier = Modifier.height(20.dp))

            // Boarding Pass Card View
            BoardingPassCard(pass = dummyPass, currentLanguage = currentLanguage)

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = onFinish,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = DeepAirlineBlue),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text(if (isZh) "查看【我的行程】" else "View My Trips", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
