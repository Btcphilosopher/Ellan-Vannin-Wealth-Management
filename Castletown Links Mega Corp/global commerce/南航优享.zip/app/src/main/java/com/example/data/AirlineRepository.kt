package com.example.data

import com.example.model.*
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID

class AirlineRepository(private val dao: AirlineDao) {
    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
    private val passengerListAdapter = moshi.adapter<List<Passenger>>(
        Types.newParameterizedType(List::class.java, Passenger::class.java)
    )
    private val ancillaryListAdapter = moshi.adapter<List<AncillaryService>>(
        Types.newParameterizedType(List::class.java, AncillaryService::class.java)
    )
    private val mapAdapter = moshi.adapter<Map<String, String>>(
        Types.newParameterizedType(Map::class.java, String::class.java, String::class.java)
    )

    // Generate initial synthetic flight schedules
    fun getSyntheticFlights(): List<Flight> {
        val CAN = SyntheticAirports.CAN
        val SHA = SyntheticAirports.SHA
        val PVG = SyntheticAirports.PVG
        val PKX = SyntheticAirports.PKX
        val SZX = SyntheticAirports.SZX
        val TFU = SyntheticAirports.TFU
        val CKG = SyntheticAirports.CKG
        val WUH = SyntheticAirports.WUH
        val HGH = SyntheticAirports.HGH
        val XIY = SyntheticAirports.XIY
        val KMG = SyntheticAirports.KMG

        return listOf(
            Flight("F101", "CZ 3128", CAN, SHA, "08:10", "10:25", "10月18日", 135, "A350-900", 620, FlightStatus.SCHEDULED, "B23", "T2", "A区 12-18", "B区 02通道", "18"),
            Flight("F102", "CZ 3501", CAN, SHA, "12:30", "14:45", "10月18日", 135, "B787-9", 580, FlightStatus.SCHEDULED, "B25", "T2", "A区 12-18", "B区 02通道", "16"),
            Flight("F103", "CZ 3810", CAN, SHA, "17:15", "19:30", "10月18日", 135, "A321neo", 650, FlightStatus.SCHEDULED, "A12", "T2", "A区 08-14", "A区 01通道", "12"),
            Flight("F104", "CZ 3102", CAN, PVG, "09:00", "11:20", "10月18日", 140, "A350-900", 590, FlightStatus.SCHEDULED, "B18", "T2", "A区 01-06", "B区 03通道", "10"),
            Flight("F105", "CZ 3115", CAN, PKX, "07:30", "10:40", "10月18日", 190, "B787-9", 780, FlightStatus.SCHEDULED, "B10", "T2", "A区 15-20", "B区 01通道", "22"),
            Flight("F106", "CZ 6822", SZX, XIY, "10:15", "13:00", "10月18日", 165, "A320neo", 520, FlightStatus.SCHEDULED, "C08", "T3", "B区 01-05", "C区 安检", "05"),
            Flight("F107", "CZ 3403", CAN, TFU, "11:00", "13:25", "10月18日", 145, "A350-900", 480, FlightStatus.SCHEDULED, "B30", "T2", "A区 10-15", "B区 02通道", "14"),
            Flight("F108", "CZ 3455", CAN, CKG, "14:20", "16:30", "10月18日", 130, "B737-800", 430, FlightStatus.SCHEDULED, "B12", "T2", "A区 10-15", "B区 02通道", "08"),
            Flight("F109", "CZ 3360", CAN, WUH, "15:40", "17:25", "10月18日", 105, "A320neo", 410, FlightStatus.SCHEDULED, "A05", "T2", "A区 01-05", "A区 安检", "04"),
            Flight("F110", "CZ 3801", HGH, CKG, "18:00", "20:30", "10月18日", 150, "A321neo", 490, FlightStatus.SCHEDULED, "D15", "T4", "C区 02-08", "D区 安检", "09")
        )
    }

    suspend fun initDefaultDataIfNeeded() {
        val synthetic = getSyntheticFlights()
        val entities = synthetic.map { it.toEntity() }
        dao.insertFlights(entities)

        // Pre-insert initial notifications
        val initialNotifs = listOf(
            NotificationEntity(
                id = "N101",
                titleZh = "欢迎体验南航优享",
                titleEn = "Welcome to Southern Value Air",
                messageZh = "高品质大众航空服务，竭诚为您提供高性价比出行体验！",
                messageEn = "High-quality airline service at an accessible price. Enjoy your journey!",
                timestamp = "2026-09-21 08:00",
                isRead = false
            ),
            NotificationEntity(
                id = "N102",
                titleZh = "本周特惠航线已上线",
                titleEn = "Weekly Special Routes Available",
                messageZh = "广州→成都 ¥480起，深圳→西安 ¥520起，立即前往【机票】选购。",
                messageEn = "Guangzhou to Chengdu from ¥480, Shenzhen to Xi'an from ¥520.",
                timestamp = "2026-09-20 10:00",
                isRead = true
            )
        )
        initialNotifs.forEach { dao.insertNotification(it) }
    }

    fun getAllBookings(): Flow<List<Booking>> {
        return dao.getAllBookings().map { list ->
            list.map { entity -> entity.toDomain() }
        }
    }

    suspend fun getBookingByRef(ref: String): Booking? {
        return dao.getBookingByRef(ref)?.toDomain()
    }

    suspend fun saveBooking(booking: Booking) {
        dao.insertBooking(booking.toEntity())
        // Auto create synthetic baggage tag if baggage was included
        if (booking.fareType != FareType.BASIC || booking.ancillaryServices.any { it.id.contains("baggage") }) {
            val tag = "CZ" + (100000..999999).random()
            val baggage = BaggageEntity(
                tagNumber = tag,
                bookingRef = booking.bookingRef,
                passengerName = booking.passengers.firstOrNull()?.name ?: "张伟",
                weightKg = 18,
                statusName = BaggageStatus.CHECKED_IN.name,
                carousel = booking.flight.baggageCarousel,
                lastUpdateLocation = "${booking.flight.origin.cityZh}${booking.flight.origin.nameZh} ${booking.flight.terminal} 行李托运中心"
            )
            dao.insertBaggage(baggage)
        }
    }

    suspend fun updateBooking(booking: Booking) {
        dao.updateBooking(booking.toEntity())
    }

    fun getBaggageForBooking(bookingRef: String): Flow<List<BaggageItem>> {
        return dao.getBaggageByBooking(bookingRef).map { list ->
            list.map { entity ->
                BaggageItem(
                    tagNumber = entity.tagNumber,
                    bookingRef = entity.bookingRef,
                    passengerName = entity.passengerName,
                    weightKg = entity.weightKg,
                    status = try { BaggageStatus.valueOf(entity.statusName) } catch (e: Exception) { BaggageStatus.CHECKED_IN },
                    carousel = entity.carousel,
                    lastUpdateLocation = entity.lastUpdateLocation
                )
            }
        }
    }

    fun getAllNotifications(): Flow<List<NotificationItem>> {
        return dao.getAllNotifications().map { list ->
            list.map { entity ->
                NotificationItem(
                    id = entity.id,
                    titleZh = entity.titleZh,
                    titleEn = entity.titleEn,
                    messageZh = entity.messageZh,
                    messageEn = entity.messageEn,
                    timestamp = entity.timestamp,
                    isRead = entity.isRead
                )
            }
        }
    }

    suspend fun addNotification(titleZh: String, titleEn: String, msgZh: String, msgEn: String) {
        val entity = NotificationEntity(
            id = "N" + System.currentTimeMillis().toString().takeLast(6),
            titleZh = titleZh,
            titleEn = titleEn,
            messageZh = msgZh,
            messageEn = msgEn,
            timestamp = "今天 " + String.format("%02d:%02d", (6..21).random(), (10..59).random()),
            isRead = false
        )
        dao.insertNotification(entity)
    }

    suspend fun updateFlightStatus(flightId: String, newStatus: FlightStatus, gate: String? = null, delayMins: Int = 0) {
        val flight = dao.getFlightById(flightId) ?: return
        val updated = flight.copy(
            statusName = newStatus.name,
            gate = gate ?: flight.gate,
            delayMinutes = delayMins
        )
        dao.updateFlight(updated)
    }

    // Mapping extensions
    private fun Flight.toEntity() = FlightEntity(
        id = id,
        flightNumber = flightNumber,
        originCode = origin.code,
        destCode = destination.code,
        departureTime = departureTime,
        arrivalTime = arrivalTime,
        dateStr = dateStr,
        durationMinutes = durationMinutes,
        aircraftType = aircraftType,
        basePrice = basePrice,
        statusName = status.name,
        gate = gate,
        terminal = terminal,
        checkinDesk = checkinDesk,
        securityZone = securityZone,
        baggageCarousel = baggageCarousel,
        isDirect = isDirect,
        delayMinutes = delayMinutes,
        delayReasonZh = delayReasonZh,
        delayReasonEn = delayReasonEn
    )

    private fun FlightEntity.toDomain() = Flight(
        id = id,
        flightNumber = flightNumber,
        origin = SyntheticAirports.findByCode(originCode),
        destination = SyntheticAirports.findByCode(destCode),
        departureTime = departureTime,
        arrivalTime = arrivalTime,
        dateStr = dateStr,
        durationMinutes = durationMinutes,
        aircraftType = aircraftType,
        basePrice = basePrice,
        status = try { FlightStatus.valueOf(statusName) } catch (e: Exception) { FlightStatus.SCHEDULED },
        gate = gate,
        terminal = terminal,
        checkinDesk = checkinDesk,
        securityZone = securityZone,
        baggageCarousel = baggageCarousel,
        isDirect = isDirect,
        delayMinutes = delayMinutes,
        delayReasonZh = delayReasonZh,
        delayReasonEn = delayReasonEn
    )

    private fun Booking.toEntity() = BookingEntity(
        bookingRef = bookingRef,
        flightId = flight.id,
        originCode = flight.origin.code,
        destCode = flight.destination.code,
        dateStr = flight.dateStr,
        flightNumber = flight.flightNumber,
        departureTime = flight.departureTime,
        arrivalTime = flight.arrivalTime,
        fareTypeName = fareType.name,
        cabinClassName = cabinClass.name,
        passengersJson = passengerListAdapter.toJson(passengers),
        ancillaryJson = ancillaryListAdapter.toJson(ancillaryServices),
        totalPrice = totalPrice,
        paymentStatusName = paymentStatus.name,
        paymentMethodId = paymentMethod?.id,
        isCheckedIn = isCheckedIn,
        checkedInSeatsJson = mapAdapter.toJson(checkedInSeats),
        createdAtTimestamp = createdAtTimestamp
    )

    private fun BookingEntity.toDomain(): Booking {
        val dummyFlight = getSyntheticFlights().find { it.flightNumber == flightNumber }
            ?: Flight(
                id = flightId,
                flightNumber = flightNumber,
                origin = SyntheticAirports.findByCode(originCode),
                destination = SyntheticAirports.findByCode(destCode),
                departureTime = departureTime,
                arrivalTime = arrivalTime,
                dateStr = dateStr,
                durationMinutes = 135,
                aircraftType = "A350-900",
                basePrice = 620
            )

        val passList = try { passengerListAdapter.fromJson(passengersJson) ?: emptyList() } catch (e: Exception) { emptyList() }
        val ancList = try { ancillaryListAdapter.fromJson(ancillaryJson) ?: emptyList() } catch (e: Exception) { emptyList() }
        val seatsMap = try { mapAdapter.fromJson(checkedInSeatsJson) ?: emptyMap() } catch (e: Exception) { emptyMap() }

        val fare = try { FareType.valueOf(fareTypeName) } catch (e: Exception) { FareType.STANDARD }
        val cabin = try { CabinClass.valueOf(cabinClassName) } catch (e: Exception) { CabinClass.ECONOMY }
        val pStatus = try { PaymentStatus.valueOf(paymentStatusName) } catch (e: Exception) { PaymentStatus.PAID }
        val pMethod = PaymentMethod.values().find { it.id == paymentMethodId }

        return Booking(
            bookingRef = bookingRef,
            flight = dummyFlight,
            fareType = fare,
            cabinClass = cabin,
            passengers = passList,
            ancillaryServices = ancList,
            totalPrice = totalPrice,
            paymentStatus = pStatus,
            paymentMethod = pMethod,
            createdAtTimestamp = createdAtTimestamp,
            isCheckedIn = isCheckedIn,
            checkedInSeats = seatsMap
        )
    }
}
