package com.example.localization

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class AppLanguage(val code: String, val displayName: String) {
    ZH_CN("zh-CN", "简体中文"),
    EN_GB("en-GB", "English")
}

object LocalizationManager {
    private val _currentLanguage = MutableStateFlow(AppLanguage.ZH_CN)
    val currentLanguage: StateFlow<AppLanguage> = _currentLanguage.asStateFlow()

    fun setLanguage(language: AppLanguage) {
        _currentLanguage.value = language
    }

    fun toggleLanguage() {
        _currentLanguage.value = if (_currentLanguage.value == AppLanguage.ZH_CN) AppLanguage.EN_GB else AppLanguage.ZH_CN
    }

    fun getString(zh: String, en: String): String {
        return if (_currentLanguage.value == AppLanguage.ZH_CN) zh else en
    }
}
