package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.AppLanguage
import com.example.model.NotificationItem
import com.example.ui.components.BottomNavBar
import com.example.ui.components.TopNavBar
import com.example.ui.screens.*
import com.example.ui.theme.BorderLight
import com.example.ui.theme.DeepAirlineBlue
import com.example.ui.theme.SouthernValueAirTheme
import com.example.ui.theme.TextDarkPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.AppTab
import com.example.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            SouthernValueAirTheme {
                MainAppScreen(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainAppScreen(viewModel: MainViewModel) {
    val activeTab by viewModel.activeTab.collectAsState()
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isZh = currentLanguage == AppLanguage.ZH_CN
    val notifications by viewModel.notifications.collectAsState()

    var showNotificationDialog by remember { mutableStateOf(false) }
    val unreadCount = notifications.count { !it.isRead }

    // Navigation state overrides for quick actions
    var statusSubTab by remember { mutableStateOf(0) }
    var customerServiceSubTab by remember { mutableStateOf(0) }

    if (showNotificationDialog) {
        AlertDialog(
            onDismissRequest = { showNotificationDialog = false },
            confirmButton = {
                TextButton(onClick = { showNotificationDialog = false }) {
                    Text(if (isZh) "关闭" else "Close", fontWeight = FontWeight.Bold)
                }
            },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (isZh) "航班及出行通知" else "Flight Notifications", fontWeight = FontWeight.Bold, color = DeepAirlineBlue)
                }
            },
            text = {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 300.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(notifications) { notif ->
                        NotificationTile(notif = notif, isZh = isZh)
                    }
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopNavBar(
                currentLanguage = currentLanguage,
                unreadNotificationCount = unreadCount,
                onToggleLanguage = { viewModel.toggleLanguage() },
                onOpenNotifications = { showNotificationDialog = true }
            )
        },
        bottomBar = {
            BottomNavBar(
                activeTab = activeTab,
                currentLanguage = currentLanguage,
                onTabSelected = { tab -> viewModel.selectTab(tab) }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (activeTab) {
                AppTab.HOME -> {
                    HomeScreen(
                        viewModel = viewModel,
                        onNavigateToTab = { tab -> viewModel.selectTab(tab) },
                        onNavigateToStatus = {
                            statusSubTab = 0
                            viewModel.selectTab(AppTab.TRIPS)
                        },
                        onNavigateToBaggage = {
                            statusSubTab = 1
                            viewModel.selectTab(AppTab.TRIPS)
                        },
                        onNavigateToAirportMode = {
                            viewModel.selectTab(AppTab.TRIPS)
                        },
                        onNavigateToCustomerService = {
                            customerServiceSubTab = 1
                            viewModel.selectTab(AppTab.PROFILE)
                        }
                    )
                }
                AppTab.TRIPS -> {
                    TripsAndAirportModeScreen(
                        viewModel = viewModel,
                        onNavigateToStatus = { statusSubTab = 0 },
                        onNavigateToBaggage = { statusSubTab = 1 }
                    )
                }
                AppTab.SEARCH_BOOK -> {
                    FlightSearchAndBookingScreen(
                        viewModel = viewModel,
                        onFinishBooking = { viewModel.selectTab(AppTab.TRIPS) }
                    )
                }
                AppTab.LOYALTY -> {
                    LoyaltyAndOffersScreen(viewModel = viewModel)
                }
                AppTab.PROFILE -> {
                    CustomerServiceAndProfileScreen(
                        viewModel = viewModel,
                        initialTab = customerServiceSubTab
                    )
                }
            }
        }
    }
}

@Composable
private fun NotificationTile(notif: NotificationItem, isZh: Boolean) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = if (notif.isRead) Color(0xFFF8FAFC) else Color(0xFFEDF5FF),
        border = BorderStroke(1.dp, BorderLight),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isZh) notif.titleZh else notif.titleEn,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = DeepAirlineBlue
                )
                Text(notif.timestamp, fontSize = 10.sp, color = TextSecondary)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = if (isZh) notif.messageZh else notif.messageEn,
                fontSize = 12.sp,
                color = TextDarkPrimary
            )
        }
    }
}
