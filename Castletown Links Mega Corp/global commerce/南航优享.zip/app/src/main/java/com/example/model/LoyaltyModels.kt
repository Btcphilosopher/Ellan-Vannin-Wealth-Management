package com.example.model

enum class LoyaltyTier(val zh: String, val en: String, val minMiles: Int) {
    REGULAR("普通会员", "Regular", 0),
    SILVER("银卡", "Silver Card", 20000),
    GOLD("金卡", "Gold Card", 50000)
}

data class LoyaltyAccount(
    val memberId: String = "CZ88092811",
    val memberName: String = "张伟 / WEI ZHANG",
    val tier: LoyaltyTier = LoyaltyTier.SILVER,
    val points: Int = 18420,
    val pointsToNextTier: Int = 3200,
    val annualKm: Int = 24820,
    val flightCountThisYear: Int = 14,
    val vouchers: List<Coupon> = listOf(
        Coupon("C1001", "机上Wi-Fi 体验券", "Inflight Wi-Fi Voucher", "2026-12-31"),
        Coupon("C1002", "优选座位 50元抵扣券", "Seat Discount ¥50", "2026-11-15"),
        Coupon("C1003", "贵宾休息室 体验券", "Lounge Pass", "2026-10-30")
    )
)

data class Coupon(
    val id: String,
    val nameZh: String,
    val nameEn: String,
    val validUntil: String
)

data class DisruptionInfo(
    val isDisrupted: Boolean = false,
    val flightNumber: String = "CZ 3128",
    val originalTime: String = "08:10",
    val estimatedTime: String = "09:05",
    val reasonZh: String = "天气原因导致航路流量管控",
    val reasonEn: String = "Air traffic control due to weather conditions",
    val optionsAvailable: List<String> = listOf("免费改签", "全额退票", "领取餐食补偿券")
)

data class NotificationItem(
    val id: String,
    val titleZh: String,
    val titleEn: String,
    val messageZh: String,
    val messageEn: String,
    val timestamp: String,
    val isRead: Boolean = false
)
