package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.AppLanguage
import com.example.model.Flight
import com.example.ui.theme.*

@Composable
fun FlightCard(
    flight: Flight,
    currentLanguage: AppLanguage,
    onSelectFlight: (Flight) -> Unit
) {
    val isZh = currentLanguage == AppLanguage.ZH_CN

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = SurfaceCardWhite,
        shadowElevation = 2.dp,
        border = BorderStroke(1.dp, BorderLight),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            // Header Tag Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = DeepAirlineBlue
                    ) {
                        Text(
                            text = flight.flightNumber,
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "${if (isZh) "机型" else "Aircraft"}: ${flight.aircraftType}",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                }

                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = VeryLightBlue
                ) {
                    Text(
                        text = if (isZh) "准点率 98%" else "On-time 98%",
                        color = DeepAirlineBlue,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Route & Departure / Arrival Time Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Origin
                Column(horizontalAlignment = Alignment.Start) {
                    Text(
                        text = flight.departureTime,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextDarkPrimary
                    )
                    Text(
                        text = flight.origin.getDisplayName(isZh),
                        fontSize = 13.sp,
                        color = TextSecondary
                    )
                }

                // Flight Line & Duration
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = if (isZh) flight.getFormattedDuration() else flight.getFormattedDurationEn(),
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        HorizontalDivider(
                            modifier = Modifier.width(36.dp),
                            color = DeepAirlineBlue.copy(alpha = 0.5f)
                        )
                        Icon(
                            imageVector = Icons.Default.ArrowForward,
                            contentDescription = null,
                            tint = DeepAirlineBlue,
                            modifier = Modifier.size(16.dp)
                        )
                        HorizontalDivider(
                            modifier = Modifier.width(36.dp),
                            color = DeepAirlineBlue.copy(alpha = 0.5f)
                        )
                    }
                    Text(
                        text = if (isZh) "直达" else "Direct",
                        fontSize = 11.sp,
                        color = SuccessGreen,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Destination
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = flight.arrivalTime,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextDarkPrimary
                    )
                    Text(
                        text = flight.destination.getDisplayName(isZh),
                        fontSize = 13.sp,
                        color = TextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = BorderLight)
            Spacer(modifier = Modifier.height(10.dp))

            // Lower Row: Perks & Price / CTA
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Included perks
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (isZh) "含随身行李" else "Carry-on included", fontSize = 11.sp, color = TextSecondary)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (isZh) "支持在线值机" else "Online check-in", fontSize = 11.sp, color = TextSecondary)
                    }
                }

                // Price and Select Button
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(horizontalAlignment = Alignment.End) {
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                text = "¥",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = ControlledRed
                            )
                            Text(
                                text = "${flight.basePrice}",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = ControlledRed
                            )
                            Text(
                                text = if (isZh) " 起" else " up",
                                fontSize = 12.sp,
                                color = TextSecondary
                            )
                        }
                        Text(
                            text = if (isZh) "经济舱" else "Economy",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Button(
                        onClick = { onSelectFlight(flight) },
                        colors = ButtonDefaults.buttonColors(containerColor = DeepAirlineBlue),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Text(if (isZh) "选票" else "Select", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
