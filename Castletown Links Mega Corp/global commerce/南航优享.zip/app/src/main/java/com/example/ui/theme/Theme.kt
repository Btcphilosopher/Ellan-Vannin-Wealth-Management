package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LightColorScheme = lightColorScheme(
    primary = DeepAirlineBlue,
    onPrimary = SurfaceCardWhite,
    primaryContainer = VeryLightBlue,
    onPrimaryContainer = DeepAirlineBlue,
    secondary = AviationBlueHeader,
    onSecondary = SurfaceCardWhite,
    tertiary = ControlledRed,
    onTertiary = SurfaceCardWhite,
    background = WarmGreyBackground,
    onBackground = TextDarkPrimary,
    surface = SurfaceCardWhite,
    onSurface = TextDarkPrimary,
    surfaceVariant = VeryLightBlue,
    onSurfaceVariant = TextSecondary,
    outline = BorderLight
)

@Composable
fun SouthernValueAirTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = LightColorScheme // Force refined high-contrast airline light palette
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = DeepAirlineBlue.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
