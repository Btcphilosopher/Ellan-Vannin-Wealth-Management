package com.example.model

data class Airport(
    val code: String,
    val nameZh: String,
    val nameEn: String,
    val cityZh: String,
    val cityEn: String,
    val defaultTerminal: String = "T2"
) {
    fun getDisplayName(isZh: Boolean): String {
        return if (isZh) "$cityZh$nameZh ($code)" else "$cityEn $nameEn ($code)"
    }

    fun getCityName(isZh: Boolean): String {
        return if (isZh) cityZh else cityEn
    }
}

object SyntheticAirports {
    val CAN = Airport("CAN", "白云", "Baiyun", "广州", "Guangzhou", "T2")
    val SHA = Airport("SHA", "虹桥", "Hongqiao", "上海", "Shanghai", "T2")
    val PVG = Airport("PVG", "浦东", "Pudong", "上海", "Shanghai", "T1")
    val PKX = Airport("PKX", "大兴", "Daxing", "北京", "Beijing", "T1")
    val SZX = Airport("SZX", "宝安", "Bao'an", "深圳", "Shenzhen", "T3")
    val TFU = Airport("TFU", "天府", "Tianfu", "成都", "Chengdu", "T2")
    val CKG = Airport("CKG", "江北", "Jiangbei", "重庆", "Chongqing", "T3A")
    val WUH = Airport("WUH", "天河", "Tianhe", "武汉", "Wuhan", "T3")
    val HGH = Airport("HGH", "萧山", "Xiaoshan", "杭州", "Hangzhou", "T4")
    val XIY = Airport("XIY", "咸阳", "Xianyang", "西安", "Xi'an", "T3")
    val KMG = Airport("KMG", "长水", "Changshui", "昆明", "Kunming", "T1")

    val allAirports = listOf(CAN, SHA, PVG, PKX, SZX, TFU, CKG, WUH, HGH, XIY, KMG)

    fun findByCode(code: String): Airport {
        return allAirports.find { it.code.equals(code, ignoreCase = true) } ?: CAN
    }
}
