package com.example.simulation

import com.example.data.AirlineRepository
import com.example.model.BaggageStatus
import com.example.model.FlightStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class FlightSimulator(private val repository: AirlineRepository) {
    private val _simulatedStatus = MutableStateFlow(FlightStatus.SCHEDULED)
    val simulatedStatus: StateFlow<FlightStatus> = _simulatedStatus.asStateFlow()

    private val _isAutoSimulating = MutableStateFlow(false)
    val isAutoSimulating: StateFlow<Boolean> = _isAutoSimulating.asStateFlow()

    fun advanceStatusManually(targetFlightNumber: String = "CZ 3128") {
        val nextStatus = when (_simulatedStatus.value) {
            FlightStatus.SCHEDULED -> FlightStatus.CHECKIN_OPEN
            FlightStatus.CHECKIN_OPEN -> FlightStatus.BOARDING
            FlightStatus.BOARDING -> FlightStatus.FINAL_CALL
            FlightStatus.FINAL_CALL -> FlightStatus.DEPARTED
            FlightStatus.DEPARTED -> FlightStatus.AIRBORNE
            FlightStatus.AIRBORNE -> FlightStatus.ARRIVED
            FlightStatus.ARRIVED -> FlightStatus.SCHEDULED
            FlightStatus.DELAYED -> FlightStatus.BOARDING
            FlightStatus.CANCELLED -> FlightStatus.SCHEDULED
        }
        _simulatedStatus.value = nextStatus
        triggerEventsForStatus(nextStatus, targetFlightNumber)
    }

    fun setSpecificStatus(status: FlightStatus, targetFlightNumber: String = "CZ 3128") {
        _simulatedStatus.value = status
        triggerEventsForStatus(status, targetFlightNumber)
    }

    private fun triggerEventsForStatus(status: FlightStatus, flightNo: String) {
        CoroutineScope(Dispatchers.IO).launch {
            when (status) {
                FlightStatus.CHECKIN_OPEN -> {
                    repository.addNotification(
                        titleZh = "值机开放提醒",
                        titleEn = "Check-in Open Alert",
                        msgZh = "您的航班 $flightNo 现已在线开放选座值机，请尽早完成！",
                        msgEn = "Flight $flightNo online check-in is now open. Choose your seat now!"
                    )
                }
                FlightStatus.BOARDING -> {
                    repository.addNotification(
                        titleZh = "登机提醒",
                        titleEn = "Boarding Alert",
                        msgZh = "$flightNo 现已开始登机，请前往 B23 登机口有序登机。",
                        msgEn = "Flight $flightNo is now boarding at Gate B23."
                    )
                }
                FlightStatus.FINAL_CALL -> {
                    repository.addNotification(
                        titleZh = "催促登机 Final Call",
                        titleEn = "Final Call for Boarding",
                        msgZh = "紧急广播：$flightNo 即将关闭登机口，请未登机旅客速至 B23 登机口！",
                        msgEn = "Final call for $flightNo at Gate B23. Gate closing soon!"
                    )
                }
                FlightStatus.DEPARTED, FlightStatus.AIRBORNE -> {
                    repository.addNotification(
                        titleZh = "起飞动态",
                        titleEn = "Flight Departed",
                        msgZh = "您的航班 $flightNo 已成功起飞，预计准时到达目的地。",
                        msgEn = "Flight $flightNo has departed. On-time arrival expected."
                    )
                }
                FlightStatus.ARRIVED -> {
                    repository.addNotification(
                        titleZh = "航班到达提醒",
                        titleEn = "Flight Arrived",
                        msgZh = "欢迎抵达上海！请前往 18 号传送带提取托运行李。",
                        msgEn = "Welcome to Shanghai! Please pick up baggage at Carousel 18."
                    )
                }
                FlightStatus.DELAYED -> {
                    repository.addNotification(
                        titleZh = "航班延误通知",
                        titleEn = "Flight Delay Notice",
                        msgZh = "受天气影响，$flightNo 预计延误 55 分钟。为您带来不便敬请谅解。",
                        msgEn = "Flight $flightNo delayed by 55 mins due to weather conditions."
                    )
                }
                else -> {}
            }
        }
    }
}
