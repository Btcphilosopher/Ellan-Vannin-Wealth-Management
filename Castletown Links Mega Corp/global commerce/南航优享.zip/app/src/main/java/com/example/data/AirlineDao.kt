package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AirlineDao {
    @Query("SELECT * FROM bookings ORDER BY createdAtTimestamp DESC")
    fun getAllBookings(): Flow<List<BookingEntity>>

    @Query("SELECT * FROM bookings WHERE bookingRef = :ref LIMIT 1")
    suspend fun getBookingByRef(ref: String): BookingEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBooking(booking: BookingEntity)

    @Update
    suspend fun updateBooking(booking: BookingEntity)

    @Query("SELECT * FROM flights")
    fun getAllFlights(): Flow<List<FlightEntity>>

    @Query("SELECT * FROM flights WHERE id = :id LIMIT 1")
    suspend fun getFlightById(id: String): FlightEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFlights(flights: List<FlightEntity>)

    @Update
    suspend fun updateFlight(flight: FlightEntity)

    @Query("SELECT * FROM notifications ORDER BY timestamp DESC")
    fun getAllNotifications(): Flow<List<NotificationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationEntity)

    @Query("SELECT * FROM baggage WHERE bookingRef = :ref")
    fun getBaggageByBooking(ref: String): Flow<List<BaggageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBaggage(baggage: BaggageEntity)

    @Update
    suspend fun updateBaggage(baggage: BaggageEntity)
}
