package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.AppLanguage
import com.example.model.BaggageStatus
import com.example.model.FlightStatus
import com.example.ui.components.TimelineComposable
import com.example.ui.theme.*
import com.example.viewmodel.MainViewModel

@Composable
fun FlightStatusAndBaggageScreen(
    viewModel: MainViewModel,
    initialTab: Int = 0 // 0: Flight Status, 1: Baggage
) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isZh = currentLanguage == AppLanguage.ZH_CN
    val simStatus by viewModel.simulator.simulatedStatus.collectAsState()

    var subTab by remember { mutableStateOf(initialTab) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmGreyBackground)
    ) {
        // Sub-Tab Switcher
        Surface(color = SurfaceCardWhite, shadowElevation = 2.dp) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .background(WarmGreyBackground, RoundedCornerShape(8.dp))
                    .padding(4.dp)
            ) {
                SubTabChip(title = if (isZh) "航班动态追踪" else "Flight Status", isSelected = subTab == 0, modifier = Modifier.weight(1f)) {
                    subTab = 0
                }
                SubTabChip(title = if (isZh) "托运行李跟踪" else "Baggage Tracking", isSelected = subTab == 1, modifier = Modifier.weight(1f)) {
                    subTab = 1
                }
            }
        }

        if (subTab == 0) {
            // Live Flight Status Simulator View
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = SurfaceCardWhite,
                        shadowElevation = 3.dp,
                        border = BorderStroke(1.dp, BorderLight),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("CZ 3128", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = DeepAirlineBlue)
                                Surface(shape = RoundedCornerShape(4.dp), color = DeepAirlineBlue) {
                                    Text(
                                        text = if (isZh) simStatus.zh else simStatus.en,
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("08:10", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                                    Text(if (isZh) "广州白云 CAN (T2)" else "Guangzhou CAN", fontSize = 12.sp, color = TextSecondary)
                                }
                                Icon(Icons.Default.ArrowForward, contentDescription = null, tint = DeepAirlineBlue)
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("10:25", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                                    Text(if (isZh) "上海虹桥 SHA (T2)" else "Shanghai SHA", fontSize = 12.sp, color = TextSecondary)
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))
                            HorizontalDivider(color = BorderLight)
                            Spacer(modifier = Modifier.height(12.dp))

                            // Interactive Timeline Tracker
                            TimelineComposable(currentStatus = simStatus, currentLanguage = currentLanguage)

                            Spacer(modifier = Modifier.height(12.dp))

                            // Simulator Controls Box
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = VeryLightBlue,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(if (isZh) "⚙️ 航班运行引擎模拟器 (点击推进节点)" else "Flight Simulator Control", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = DeepAirlineBlue)
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(
                                            onClick = { viewModel.simulator.advanceStatusManually() },
                                            colors = ButtonDefaults.buttonColors(containerColor = DeepAirlineBlue),
                                            shape = RoundedCornerShape(6.dp),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text(if (isZh) "模拟推进下一状态" else "Advance Status", fontSize = 11.sp)
                                        }
                                        OutlinedButton(
                                            onClick = { viewModel.simulator.setSpecificStatus(FlightStatus.DELAYED) },
                                            shape = RoundedCornerShape(6.dp),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text(if (isZh) "模拟延误" else "Simulate Delay", fontSize = 11.sp, color = ControlledRed)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // Baggage Tracking View
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = SurfaceCardWhite,
                        shadowElevation = 3.dp,
                        border = BorderStroke(1.dp, BorderLight),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(if (isZh) "托运行李卡号 CZ123456" else "Tag CZ123456", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = DeepAirlineBlue)
                                Surface(shape = RoundedCornerShape(4.dp), color = SuccessGreen.copy(alpha = 0.15f)) {
                                    Text(if (isZh) "已托运" else "Checked-in", color = SuccessGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Text(if (isZh) "乘机人：张伟 (1件 / 18kg)" else "Passenger: Wei Zhang (18kg)", fontSize = 13.sp, color = TextDarkPrimary)
                            Text(if (isZh) "最新位置：广州白云 T2 行李分拣中心" else "Last location: Guangzhou T2 Hub", fontSize = 12.sp, color = TextSecondary)

                            Spacer(modifier = Modifier.height(16.dp))

                            Text(if (isZh) "行李节点流程" else "Baggage Timeline", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = DeepAirlineBlue)
                            Spacer(modifier = Modifier.height(8.dp))

                            BaggageStepRow(title = if (isZh) "1. 柜台收运 / 托运" else "Checked-in at desk", isDone = true, isZh = isZh)
                            BaggageStepRow(title = if (isZh) "2. 传送带运输中" else "In Transit to Aircraft", isDone = true, isZh = isZh)
                            BaggageStepRow(title = if (isZh) "3. 装机确认" else "Loaded on Board", isDone = false, isZh = isZh)
                            BaggageStepRow(title = if (isZh) "4. 目的地到达 (传送带 18)" else "Arrived at Carousel 18", isDone = false, isZh = isZh)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SubTabChip(title: String, isSelected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = if (isSelected) SurfaceCardWhite else Color.Transparent,
        modifier = modifier.padding(2.dp),
        onClick = onClick
    ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(vertical = 8.dp)) {
            Text(
                text = title,
                fontSize = 13.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) DeepAirlineBlue else TextSecondary
            )
        }
    }
}

@Composable
private fun BaggageStepRow(title: String, isDone: Boolean, isZh: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = if (isDone) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
            contentDescription = null,
            tint = if (isDone) SuccessGreen else Color.Gray,
            modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(10.dp))
        Text(title, fontSize = 13.sp, fontWeight = if (isDone) FontWeight.Bold else FontWeight.Normal, color = if (isDone) TextDarkPrimary else TextSecondary)
    }
}
