package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

@Database(
    entities = [BookingEntity::class, FlightEntity::class, NotificationEntity::class, BaggageEntity::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AirlineDatabase : RoomDatabase() {
    abstract fun airlineDao(): AirlineDao

    companion object {
        @Volatile
        private var INSTANCE: AirlineDatabase? = null

        fun getDatabase(context: Context): AirlineDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AirlineDatabase::class.java,
                    "southern_value_air_db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
