package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.AppLanguage
import com.example.model.Airport
import com.example.model.Booking
import com.example.model.Flight
import com.example.model.SyntheticAirports
import com.example.ui.components.AirportPickerModal
import com.example.ui.theme.*
import com.example.viewmodel.AppTab
import com.example.viewmodel.MainViewModel

@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    onNavigateToTab: (AppTab) -> Unit,
    onNavigateToStatus: () -> Unit,
    onNavigateToBaggage: () -> Unit,
    onNavigateToAirportMode: () -> Unit,
    onNavigateToCustomerService: () -> Unit
) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isZh = currentLanguage == AppLanguage.ZH_CN

    val searchOrigin by viewModel.searchOrigin.collectAsState()
    val searchDest by viewModel.searchDest.collectAsState()
    val searchDate by viewModel.searchDate.collectAsState()
    val passengerCount by viewModel.passengerCount.collectAsState()
    val allBookings by viewModel.allBookings.collectAsState()

    val upcomingBooking = allBookings.firstOrNull()

    var showOriginPicker by remember { mutableStateOf(false) }
    var showDestPicker by remember { mutableStateOf(false) }

    if (showOriginPicker) {
        AirportPickerModal(
            title = if (isZh) "选择出发城市" else "Select Departure Airport",
            currentLanguage = currentLanguage,
            onAirportSelected = { viewModel.setSearchOrigin(it) },
            onDismiss = { showOriginPicker = false }
        )
    }

    if (showDestPicker) {
        AirportPickerModal(
            title = if (isZh) "选择到达城市" else "Select Destination Airport",
            currentLanguage = currentLanguage,
            onAirportSelected = { viewModel.setSearchDest(it) },
            onDismiss = { showDestPicker = false }
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmGreyBackground)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 24.dp)
    ) {
        // Hero Airline Status Bar Banner
        item {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = AviationBlueHeader,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (isZh) "南航优享 • 高品质大众航空" else "SOUTHERN VALUE AIR • VALUE TRAVEL",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isZh) "高效运营 • 透明票价 • 极致体验" else "High Efficiency • Transparent Fares",
                            color = Color.White.copy(alpha = 0.8f),
                            fontSize = 11.sp
                        )
                    }
                    Button(
                        onClick = {
                            viewModel.performFlightSearch()
                            onNavigateToTab(AppTab.SEARCH_BOOK)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ControlledRed),
                        shape = RoundedCornerShape(20.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                    ) {
                        Text(if (isZh) "搜索机票" else "Search", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Upcoming Active Trip Widget (if user has a booking)
        if (upcomingBooking != null) {
            item {
                ActiveTripCardWidget(
                    booking = upcomingBooking,
                    isZh = isZh,
                    onOpenBoardingPass = { onNavigateToTab(AppTab.TRIPS) },
                    onOpenAirportMode = onNavigateToAirportMode
                )
                Spacer(modifier = Modifier.height(14.dp))
            }
        }

        // Main Flight Search Module Card
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = SurfaceCardWhite,
                shadowElevation = 4.dp,
                border = BorderStroke(1.dp, BorderLight),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Search Type Tabs (单程 One Way / 往返 Round Trip / 多程 Multi-City)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(WarmGreyBackground, RoundedCornerShape(8.dp))
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        SearchTabChip(title = if (isZh) "单程" else "One Way", isSelected = true)
                        SearchTabChip(title = if (isZh) "往返" else "Round Trip", isSelected = false)
                        SearchTabChip(title = if (isZh) "多程" else "Multi-City", isSelected = false)
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Airport Selection Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Origin
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .clickable { showOriginPicker = true }
                                .padding(8.dp)
                        ) {
                            Text(if (isZh) "出发地" else "Departure", fontSize = 11.sp, color = TextSecondary)
                            Text(searchOrigin.cityZh, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = TextDarkPrimary)
                            Text("${searchOrigin.nameZh} (${searchOrigin.code})", fontSize = 12.sp, color = DeepAirlineBlue, fontWeight = FontWeight.Bold)
                        }

                        // Swap Icon
                        IconButton(
                            onClick = { viewModel.swapAirports() },
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(18.dp))
                                .background(VeryLightBlue)
                        ) {
                            Icon(Icons.Default.SwapHoriz, contentDescription = "Swap", tint = DeepAirlineBlue)
                        }

                        // Destination
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .clickable { showDestPicker = true }
                                .padding(8.dp),
                            horizontalAlignment = Alignment.End
                        ) {
                            Text(if (isZh) "目的地" else "Destination", fontSize = 11.sp, color = TextSecondary)
                            Text(searchDest.cityZh, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = TextDarkPrimary)
                            Text("${searchDest.nameZh} (${searchDest.code})", fontSize = 12.sp, color = DeepAirlineBlue, fontWeight = FontWeight.Bold)
                        }
                    }

                    HorizontalDivider(color = BorderLight, modifier = Modifier.padding(vertical = 12.dp))

                    // Date & Passengers Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(if (isZh) "出发日期" else "Date", fontSize = 11.sp, color = TextSecondary)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(searchDate, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextDarkPrimary)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(if (isZh) "周日" else "Sun", fontSize = 12.sp, color = TextSecondary)
                            }
                        }

                        Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                            Text(if (isZh) "乘客" else "Passengers", fontSize = 11.sp, color = TextSecondary)
                            Text("$passengerCount ${if (isZh) "成人" else "Adult"}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextDarkPrimary)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Search Button
                    Button(
                        onClick = {
                            viewModel.performFlightSearch()
                            onNavigateToTab(AppTab.SEARCH_BOOK)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = DeepAirlineBlue),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Search, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(if (isZh) "搜索航班" else "Search Flights", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // Quick Actions Grid (6 items)
        item {
            Text(if (isZh) "快捷服务" else "Quick Services", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextDarkPrimary)
            Spacer(modifier = Modifier.height(10.dp))

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    QuickActionButton(
                        modifier = Modifier.weight(1f),
                        icon = Icons.Default.ConfirmationNumber,
                        label = if (isZh) "在线值机" else "Check-in",
                        onClick = { onNavigateToTab(AppTab.TRIPS) }
                    )
                    QuickActionButton(
                        modifier = Modifier.weight(1f),
                        icon = Icons.Default.Flight,
                        label = if (isZh) "航班动态" else "Flight Status",
                        onClick = onNavigateToStatus
                    )
                    QuickActionButton(
                        modifier = Modifier.weight(1f),
                        icon = Icons.Default.Luggage,
                        label = if (isZh) "行李跟踪" else "Baggage",
                        onClick = onNavigateToBaggage
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    QuickActionButton(
                        modifier = Modifier.weight(1f),
                        icon = Icons.Default.Place,
                        label = if (isZh) "机场模式" else "Airport Mode",
                        onClick = onNavigateToAirportMode
                    )
                    QuickActionButton(
                        modifier = Modifier.weight(1f),
                        icon = Icons.Default.Star,
                        label = if (isZh) "会员中心" else "Loyalty",
                        onClick = { onNavigateToTab(AppTab.LOYALTY) }
                    )
                    QuickActionButton(
                        modifier = Modifier.weight(1f),
                        icon = Icons.Default.HeadsetMic,
                        label = if (isZh) "在线客服" else "Customer Care",
                        onClick = onNavigateToCustomerService
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }

        // Promotional Area / Offers (本周特惠)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(if (isZh) "本周特惠航线" else "Weekly Special Deals", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextDarkPrimary)
                Text(if (isZh) "查看更多 >" else "More >", fontSize = 12.sp, color = DeepAirlineBlue, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(10.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OfferCard(route = "广州 CAN → 成都 TFU", price = "¥480", discountTag = "限时7.2折", isZh = isZh) {
                    viewModel.setSearchOrigin(SyntheticAirports.CAN)
                    viewModel.setSearchDest(SyntheticAirports.TFU)
                    onNavigateToTab(AppTab.SEARCH_BOOK)
                }
                OfferCard(route = "深圳 SZX → 西安 XIY", price = "¥520", discountTag = "热卖航线", isZh = isZh) {
                    viewModel.setSearchOrigin(SyntheticAirports.SZX)
                    viewModel.setSearchDest(SyntheticAirports.XIY)
                    onNavigateToTab(AppTab.SEARCH_BOOK)
                }
                OfferCard(route = "广州 CAN → 重庆 CKG", price = "¥430", discountTag = "超值推荐", isZh = isZh) {
                    viewModel.setSearchOrigin(SyntheticAirports.CAN)
                    viewModel.setSearchDest(SyntheticAirports.CKG)
                    onNavigateToTab(AppTab.SEARCH_BOOK)
                }
            }
        }
    }
}

@Composable
private fun ActiveTripCardWidget(
    booking: Booking,
    isZh: Boolean,
    onOpenBoardingPass: () -> Unit,
    onOpenAirportMode: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = DeepAirlineBlue,
        shadowElevation = 3.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(shape = RoundedCornerShape(4.dp), color = ControlledRed) {
                        Text(if (isZh) "即将出发" else "Upcoming Trip", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(booking.flight.flightNumber, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
                Text(booking.flight.dateStr, color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(booking.flight.origin.cityZh, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(booking.flight.departureTime, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                }
                Icon(Icons.Default.ArrowForward, contentDescription = null, tint = Color.White)
                Column(horizontalAlignment = Alignment.End) {
                    Text(booking.flight.destination.cityZh, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(booking.flight.arrivalTime, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Button(
                    onClick = onOpenBoardingPass,
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(if (isZh) "查看电子登机牌" else "Boarding Pass", color = DeepAirlineBlue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.width(10.dp))
                OutlinedButton(
                    onClick = onOpenAirportMode,
                    border = BorderStroke(1.dp, Color.White),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(if (isZh) "机场导航" else "Airport Guide", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun SearchTabChip(title: String, isSelected: Boolean) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = if (isSelected) SurfaceCardWhite else Color.Transparent,
        modifier = Modifier.padding(2.dp)
    ) {
        Text(
            text = title,
            fontSize = 13.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) DeepAirlineBlue else TextSecondary,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
        )
    }
}

@Composable
private fun QuickActionButton(
    modifier: Modifier,
    icon: ImageVector,
    label: String,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = SurfaceCardWhite,
        border = BorderStroke(1.dp, BorderLight),
        modifier = modifier.clickable { onClick() }
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(imageVector = icon, contentDescription = label, tint = DeepAirlineBlue, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.height(6.dp))
            Text(label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextDarkPrimary)
        }
    }
}

@Composable
private fun OfferCard(route: String, price: String, discountTag: String, isZh: Boolean, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = SurfaceCardWhite,
        border = BorderStroke(1.dp, BorderLight),
        modifier = Modifier.fillMaxWidth().clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(route, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextDarkPrimary)
                Spacer(modifier = Modifier.height(2.dp))
                Surface(shape = RoundedCornerShape(4.dp), color = SkyLightBlue) {
                    Text(discountTag, fontSize = 10.sp, color = DeepAirlineBlue, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                }
            }
            Row(verticalAlignment = Alignment.Bottom) {
                Text(price, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = ControlledRed)
                Text(if (isZh) " 起" else " up", fontSize = 12.sp, color = TextSecondary)
            }
        }
    }
}
