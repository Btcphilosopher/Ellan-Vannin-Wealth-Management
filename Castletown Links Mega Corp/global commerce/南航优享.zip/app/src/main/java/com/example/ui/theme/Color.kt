package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DeepAirlineBlue = Color(0xFF0D3B66)
val DeepAirlineBlueDark = Color(0xFF0A2B4C)
val AviationBlueHeader = Color(0xFF103254)
val VeryLightBlue = Color(0xFFEDF5FF)
val SkyLightBlue = Color(0xFFD6E8FA)
val ControlledRed = Color(0xFFD9381E)
val WarmGreyBackground = Color(0xFFF4F6F9)
val SurfaceCardWhite = Color(0xFFFFFFFF)
val TextDarkPrimary = Color(0xFF1E293B)
val TextSecondary = Color(0xFF64748B)
val BorderLight = Color(0xFFE2E8F0)
val MetallicGold = Color(0xFFC5A059)
val SuccessGreen = Color(0xFF16A34A)
val WarningOrange = Color(0xFFEA580C)
