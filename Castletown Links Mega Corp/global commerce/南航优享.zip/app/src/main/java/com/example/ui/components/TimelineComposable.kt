package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.AppLanguage
import com.example.model.FlightStatus
import com.example.ui.theme.DeepAirlineBlue
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextSecondary

@Composable
fun TimelineComposable(
    currentStatus: FlightStatus,
    currentLanguage: AppLanguage
) {
    val isZh = currentLanguage == AppLanguage.ZH_CN

    val steps = listOf(
        if (isZh) "值机" else "Check-in",
        if (isZh) "安检" else "Security",
        if (isZh) "登机" else "Boarding",
        if (isZh) "起飞" else "Depart",
        if (isZh) "抵达" else "Arrive"
    )

    // Map current flight status to step index (0 to 4)
    val activeStepIndex = when (currentStatus) {
        FlightStatus.SCHEDULED -> 0
        FlightStatus.CHECKIN_OPEN -> 0
        FlightStatus.BOARDING, FlightStatus.FINAL_CALL -> 2
        FlightStatus.DEPARTED, FlightStatus.AIRBORNE -> 3
        FlightStatus.ARRIVED -> 4
        else -> 1
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        steps.forEachIndexed { index, title ->
            val isCompleted = index < activeStepIndex
            val isCurrent = index == activeStepIndex

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (index > 0) {
                        HorizontalDivider(
                            modifier = Modifier.weight(1f),
                            color = if (index <= activeStepIndex) SuccessGreen else Color.LightGray.copy(alpha = 0.5f),
                            thickness = 2.dp
                        )
                    } else {
                        Spacer(modifier = Modifier.weight(1f))
                    }

                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(
                                when {
                                    isCompleted -> SuccessGreen
                                    isCurrent -> DeepAirlineBlue
                                    else -> Color.LightGray.copy(alpha = 0.4f)
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isCompleted) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                        } else {
                            Text(
                                text = "${index + 1}",
                                color = if (isCurrent) Color.White else Color.DarkGray,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    if (index < steps.size - 1) {
                        HorizontalDivider(
                            modifier = Modifier.weight(1f),
                            color = if (index < activeStepIndex) SuccessGreen else Color.LightGray.copy(alpha = 0.5f),
                            thickness = 2.dp
                        )
                    } else {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = title,
                    fontSize = 11.sp,
                    fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                    color = if (isCurrent) DeepAirlineBlue else TextSecondary
                )
            }
        }
    }
}
