package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AirlineDatabase
import com.example.data.AirlineRepository
import com.example.localization.AppLanguage
import com.example.localization.LocalizationManager
import com.example.model.*
import com.example.simulation.FlightSimulator
import java.util.UUID
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class AppTab {
    HOME,
    TRIPS,
    SEARCH_BOOK,
    LOYALTY,
    PROFILE
}

enum class BookingStep {
    FLIGHT_LIST,
    FARE_SELECTION,
    PASSENGER_INFO,
    SEAT_SELECTION,
    ANCILLARY_SERVICES,
    PAYMENT,
    CONFIRMATION
}

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AirlineDatabase.getDatabase(application)
    val repository = AirlineRepository(db.airlineDao())
    val simulator = FlightSimulator(repository)

    // Current Navigation Tab
    private val _activeTab = MutableStateFlow(AppTab.HOME)
    val activeTab: StateFlow<AppTab> = _activeTab.asStateFlow()

    // Language state
    val currentLanguage = LocalizationManager.currentLanguage

    // Flight Search Parameters
    private val _searchOrigin = MutableStateFlow(SyntheticAirports.CAN)
    val searchOrigin: StateFlow<Airport> = _searchOrigin.asStateFlow()

    private val _searchDest = MutableStateFlow(SyntheticAirports.SHA)
    val searchDest: StateFlow<Airport> = _searchDest.asStateFlow()

    private val _searchDate = MutableStateFlow("10月18日")
    val searchDate: StateFlow<String> = _searchDate.asStateFlow()

    private val _passengerCount = MutableStateFlow(1)
    val passengerCount: StateFlow<Int> = _passengerCount.asStateFlow()

    private val _searchCabin = MutableStateFlow(CabinClass.ECONOMY)
    val searchCabin: StateFlow<CabinClass> = _searchCabin.asStateFlow()

    private val _isDirectOnly = MutableStateFlow(true)
    val isDirectOnly: StateFlow<Boolean> = _isDirectOnly.asStateFlow()

    // Search Results State
    private val _searchResults = MutableStateFlow<List<Flight>>(emptyList())
    val searchResults: StateFlow<List<Flight>> = _searchResults.asStateFlow()

    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching.asStateFlow()

    // Booking Flow State
    private val _bookingStep = MutableStateFlow(BookingStep.FLIGHT_LIST)
    val bookingStep: StateFlow<BookingStep> = _bookingStep.asStateFlow()

    private val _selectedFlight = MutableStateFlow<Flight?>(null)
    val selectedFlight: StateFlow<Flight?> = _selectedFlight.asStateFlow()

    private val _selectedFareType = MutableStateFlow(FareType.STANDARD)
    val selectedFareType: StateFlow<FareType> = _selectedFareType.asStateFlow()

    private val _passengerDetails = MutableStateFlow(
        listOf(Passenger("P101", "张伟", DocType.ID_CARD, "44010519920818****", "中国 China", "1992-08-18", "13888888888"))
    )
    val passengerDetails: StateFlow<List<Passenger>> = _passengerDetails.asStateFlow()

    private val _selectedSeats = MutableStateFlow<Map<String, String>>(emptyMap()) // passengerId -> seatNo
    val selectedSeats: StateFlow<Map<String, String>> = _selectedSeats.asStateFlow()

    private val _selectedAncillaries = MutableStateFlow<List<AncillaryService>>(emptyList())
    val selectedAncillaries: StateFlow<List<AncillaryService>> = _selectedAncillaries.asStateFlow()

    private val _selectedPaymentMethod = MutableStateFlow(PaymentMethod.ALIPAY)
    val selectedPaymentMethod: StateFlow<PaymentMethod> = _selectedPaymentMethod.asStateFlow()

    private val _isPaymentProcessing = MutableStateFlow(false)
    val isPaymentProcessing: StateFlow<Boolean> = _isPaymentProcessing.asStateFlow()

    private val _latestConfirmedBooking = MutableStateFlow<Booking?>(null)
    val latestConfirmedBooking: StateFlow<Booking?> = _latestConfirmedBooking.asStateFlow()

    // Database Flows
    val allBookings: StateFlow<List<Booking>> = repository.getAllBookings()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notifications: StateFlow<List<NotificationItem>> = repository.getAllNotifications()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Loyalty Account
    private val _loyaltyAccount = MutableStateFlow(LoyaltyAccount())
    val loyaltyAccount: StateFlow<LoyaltyAccount> = _loyaltyAccount.asStateFlow()

    // Corporate Travel Mode
    private val _isCorporateMode = MutableStateFlow(false)
    val isCorporateMode: StateFlow<Boolean> = _isCorporateMode.asStateFlow()

    // Customer Service Chat
    private val _chatMessages = MutableStateFlow(
        listOf(
            ChatMessage("1", false, "您好！我是南航优享智能助手。请问有什么可以帮您？例如查询机票、行程值机或行李状态。", "08:00")
        )
    )
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    init {
        viewModelScope.launch {
            repository.initDefaultDataIfNeeded()
            performFlightSearch()
        }
    }

    fun selectTab(tab: AppTab) {
        _activeTab.value = tab
    }

    fun toggleLanguage() {
        LocalizationManager.toggleLanguage()
    }

    fun swapAirports() {
        val temp = _searchOrigin.value
        _searchOrigin.value = _searchDest.value
        _searchDest.value = temp
        performFlightSearch()
    }

    fun setSearchOrigin(airport: Airport) {
        _searchOrigin.value = airport
        performFlightSearch()
    }

    fun setSearchDest(airport: Airport) {
        _searchDest.value = airport
        performFlightSearch()
    }

    fun performFlightSearch() {
        viewModelScope.launch {
            _isSearching.value = true
            delay(300) // slight smooth transition delay
            val originCode = _searchOrigin.value.code
            val destCode = _searchDest.value.code
            val matches = repository.getSyntheticFlights().filter {
                it.origin.code == originCode && it.destination.code == destCode
            }
            _searchResults.value = if (matches.isNotEmpty()) matches else repository.getSyntheticFlights().take(3)
            _isSearching.value = false
        }
    }

    fun startBooking(flight: Flight) {
        _selectedFlight.value = flight
        _bookingStep.value = BookingStep.FARE_SELECTION
        _activeTab.value = AppTab.SEARCH_BOOK
    }

    fun selectFare(fareType: FareType) {
        _selectedFareType.value = fareType
        _bookingStep.value = BookingStep.PASSENGER_INFO
    }

    fun updatePassengerInfo(passengers: List<Passenger>) {
        _passengerDetails.value = passengers
        _bookingStep.value = BookingStep.SEAT_SELECTION
    }

    fun selectSeatForPassenger(passengerId: String, seatNo: String) {
        val current = _selectedSeats.value.toMutableMap()
        current[passengerId] = seatNo
        _selectedSeats.value = current
    }

    fun proceedToAncillaries() {
        _bookingStep.value = BookingStep.ANCILLARY_SERVICES
    }

    fun toggleAncillaryService(service: AncillaryService) {
        val current = _selectedAncillaries.value.toMutableList()
        if (current.any { it.id == service.id }) {
            current.removeAll { it.id == service.id }
        } else {
            current.add(service)
        }
        _selectedAncillaries.value = current
    }

    fun proceedToPayment() {
        _bookingStep.value = BookingStep.PAYMENT
    }

    fun selectPaymentMethod(method: PaymentMethod) {
        _selectedPaymentMethod.value = method
    }

    fun calculateTotalPrice(): Int {
        val flight = _selectedFlight.value ?: return 0
        val base = (flight.basePrice * _selectedFareType.value.priceMultiplier).toInt()
        val seatsCost = _selectedSeats.value.values.sumOf { seatNo ->
            if (seatNo.startsWith("1") || seatNo.startsWith("2")) 39 else 0
        }
        val ancillariesCost = _selectedAncillaries.value.sumOf { it.price }
        return (base + seatsCost + ancillariesCost) * _passengerDetails.value.size
    }

    fun executePaymentAndConfirm() {
        viewModelScope.launch {
            _isPaymentProcessing.value = true
            delay(1500) // simulated Chinese payment latency
            val flight = _selectedFlight.value ?: return@launch
            val ref = "CZ" + (1000..9999).random().toString()
            val booking = Booking(
                bookingRef = ref,
                flight = flight,
                fareType = _selectedFareType.value,
                cabinClass = _searchCabin.value,
                passengers = _passengerDetails.value,
                ancillaryServices = _selectedAncillaries.value,
                totalPrice = calculateTotalPrice(),
                paymentStatus = PaymentStatus.PAID,
                paymentMethod = _selectedPaymentMethod.value,
                createdAtTimestamp = System.currentTimeMillis(),
                isCheckedIn = false,
                checkedInSeats = _selectedSeats.value
            )
            repository.saveBooking(booking)
            _latestConfirmedBooking.value = booking
            _isPaymentProcessing.value = false
            _bookingStep.value = BookingStep.CONFIRMATION

            repository.addNotification(
                titleZh = "出票成功提醒",
                titleEn = "Ticket Issued Successfully",
                msgZh = "您的电子客票 $ref (${flight.origin.cityZh}→${flight.destination.cityZh}) 已出票成功！",
                msgEn = "E-Ticket $ref (${flight.origin.cityEn} to ${flight.destination.cityEn}) issued!"
            )
        }
    }

    fun resetBookingFlow() {
        _bookingStep.value = BookingStep.FLIGHT_LIST
        _selectedFlight.value = null
        _selectedSeats.value = emptyMap()
        _selectedAncillaries.value = emptyList()
    }

    fun performCheckIn(bookingRef: String, passengerSeatMap: Map<String, String>) {
        viewModelScope.launch {
            val booking = repository.getBookingByRef(bookingRef) ?: return@launch
            val updated = booking.copy(
                isCheckedIn = true,
                checkedInSeats = passengerSeatMap
            )
            repository.updateBooking(updated)
            repository.addNotification(
                titleZh = "值机成功",
                titleEn = "Check-in Complete",
                msgZh = "您已成功办理 ${booking.flight.flightNumber} 值机，电子登机牌已生成。",
                msgEn = "Check-in completed for ${booking.flight.flightNumber}. Digital boarding pass ready."
            )
        }
    }

    fun toggleCorporateMode() {
        _isCorporateMode.value = !_isCorporateMode.value
    }

    fun sendCustomerServiceMessage(text: String) {
        if (text.isBlank()) return
        val timeStr = String.format("%02d:%02d", (8..20).random(), (10..59).random())
        val userMsg = ChatMessage(UUID.randomUUID().toString(), true, text, timeStr)
        val current = _chatMessages.value.toMutableList()
        current.add(userMsg)
        _chatMessages.value = current

        viewModelScope.launch {
            delay(800)
            val replyText = generateAssistantReply(text)
            val botMsg = ChatMessage(UUID.randomUUID().toString(), false, replyText, timeStr)
            val updated = _chatMessages.value.toMutableList()
            updated.add(botMsg)
            _chatMessages.value = updated
        }
    }

    private fun generateAssistantReply(text: String): String {
        val isZh = currentLanguage.value == AppLanguage.ZH_CN
        return when {
            text.contains("航班") || text.contains("flight") -> {
                if (isZh) "南航优享主枢纽为广州白云(CAN)与上海(SHA/PVG)，您当前有 ${allBookings.value.size} 个有效行程。点击【行程】标签可随时查看或改签。"
                else "Southern Value Air operates major hubs at CAN & SHA. You currently have ${allBookings.value.size} active trip(s)."
            }
            text.contains("行李") || text.contains("baggage") -> {
                if (isZh) "标准/灵活票价均免费包含20kg-30kg托运行李。您可在【行程】中查询托运状态 CZ123456。"
                else "Standard & Flexible fares include 20kg-30kg checked baggage. Track status under Trips."
            }
            text.contains("退票") || text.contains("改签") || text.contains("refund") -> {
                if (isZh) "灵活客票支持起飞前免费改签与全额退票；标准客票改签免费，退票收取20%手续费。"
                else "Flexible fares support free changes and full refunds. Standard fares allow free rebooking."
            }
            else -> {
                if (isZh) "已收到您的咨询。南航优享7×24小时高品质旅客服务中心竭诚为您服务，如需紧急协助可联系电话客服：400-800-9555。"
                else "Thank you for contacting Southern Value Air Customer Care. For hotline support call 400-800-9555."
            }
        }
    }
}

data class ChatMessage(
    val id: String,
    val isUser: Boolean,
    val text: String,
    val timestamp: String
)
