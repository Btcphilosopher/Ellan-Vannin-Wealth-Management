package com.example.model

enum class FlightStatus(val zh: String, val en: String) {
    SCHEDULED("计划", "Scheduled"),
    CHECKIN_OPEN("开放值机", "Check-in Open"),
    BOARDING("登机中", "Boarding"),
    FINAL_CALL("催促登机", "Final Call"),
    DEPARTED("已起飞", "Departed"),
    AIRBORNE("飞行中", "Airborne"),
    ARRIVED("已到达", "Arrived"),
    DELAYED("延误", "Delayed"),
    CANCELLED("取消", "Cancelled")
}

enum class CabinClass(val zh: String, val en: String) {
    ECONOMY("经济舱", "Economy"),
    PREMIUM_ECONOMY("超级经济舱", "Premium Economy"),
    BUSINESS("公务舱", "Business")
}

enum class FareType(
    val zh: String,
    val en: String,
    val priceMultiplier: Double,
    val baggageIncluded: Boolean,
    val checkedBaggageAllowance: String,
    val seatSelectionFree: Boolean,
    val changePolicyZh: String,
    val changePolicyEn: String,
    val refundPolicyZh: String,
    val refundPolicyEn: String
) {
    BASIC(
        zh = "基础",
        en = "Basic",
        priceMultiplier = 0.85,
        baggageIncluded = false,
        checkedBaggageAllowance = "手提 7kg",
        seatSelectionFree = false,
        changePolicyZh = "付费改签 (¥120)",
        changePolicyEn = "Fee applied (¥120)",
        refundPolicyZh = "不可退票",
        refundPolicyEn = "Non-refundable"
    ),
    STANDARD(
        zh = "标准",
        en = "Standard",
        priceMultiplier = 1.0,
        baggageIncluded = true,
        checkedBaggageAllowance = "托运 20kg + 手提 7kg",
        seatSelectionFree = true,
        changePolicyZh = "起飞前免费改签",
        changePolicyEn = "Free before departure",
        refundPolicyZh = "按规则退票 (20%手续费)",
        refundPolicyEn = "Refundable (20% fee)"
    ),
    FLEXIBLE(
        zh = "灵活",
        en = "Flexible",
        priceMultiplier = 1.25,
        baggageIncluded = true,
        checkedBaggageAllowance = "托运 30kg + 手提 10kg",
        seatSelectionFree = true,
        changePolicyZh = "随时免费改签",
        changePolicyEn = "Free change anytime",
        refundPolicyZh = "全额退票",
        refundPolicyEn = "Fully refundable"
    )
}

data class Flight(
    val id: String,
    val flightNumber: String, // e.g. CZ 3128
    val origin: Airport,
    val destination: Airport,
    val departureTime: String, // e.g. 08:10
    val arrivalTime: String,   // e.g. 10:25
    val dateStr: String,       // e.g. 10月18日 / Oct 18
    val durationMinutes: Int,  // e.g. 135
    val aircraftType: String,  // e.g. A350-900 / B787-9 / ARJ21
    val basePrice: Int,        // e.g. 620
    val status: FlightStatus = FlightStatus.SCHEDULED,
    val gate: String = "B23",
    val terminal: String = "T2",
    val checkinDesk: String = "A区 12-18",
    val securityZone: String = "B区 快捷通道",
    val baggageCarousel: String = "18",
    val isDirect: Boolean = true,
    val delayMinutes: Int = 0,
    val delayReasonZh: String? = null,
    val delayReasonEn: String? = null
) {
    fun getFormattedDuration(): String {
        val hours = durationMinutes / 60
        val mins = durationMinutes % 60
        return "${hours}小时${mins}分钟"
    }

    fun getFormattedDurationEn(): String {
        val hours = durationMinutes / 60
        val mins = durationMinutes % 60
        return "${hours}h ${mins}m"
    }
}

enum class SeatType(val price: Int, val zh: String, val en: String) {
    STANDARD(0, "标准座位", "Standard"),
    EXTRA_LEGROOM(39, "优选宽座", "Extra Legroom"),
    EMERGENCY_EXIT(59, "安全出口", "Emergency Exit"),
    PAID_PREFERRED(20, "前排座位", "Preferred Front")
}

data class Seat(
    val seatNo: String, // e.g. 24A
    val row: Int,
    val col: String,
    val type: SeatType,
    var isOccupied: Boolean = false,
    var isSelected: Boolean = false
)

data class AncillaryService(
    val id: String,
    val nameZh: String,
    val nameEn: String,
    val price: Int,
    val descriptionZh: String,
    val descriptionEn: String,
    val iconName: String
)
