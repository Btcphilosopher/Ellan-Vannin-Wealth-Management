package com.example.ui.components

import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardTravel
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.AppLanguage
import com.example.ui.theme.AviationBlueHeader
import com.example.ui.theme.DeepAirlineBlue
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.AppTab

@Composable
fun BottomNavBar(
    activeTab: AppTab,
    currentLanguage: AppLanguage,
    onTabSelected: (AppTab) -> Unit
) {
    val isZh = currentLanguage == AppLanguage.ZH_CN

    NavigationBar(
        windowInsets = WindowInsets.navigationBars,
        containerColor = Color.White,
        tonalElevation = 8.dp
    ) {
        NavigationBarItem(
            selected = activeTab == AppTab.HOME,
            onClick = { onTabSelected(AppTab.HOME) },
            icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
            label = { Text(if (isZh) "首页" else "Home", fontSize = 11.sp, fontWeight = FontWeight.Medium) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = DeepAirlineBlue,
                selectedTextColor = DeepAirlineBlue,
                indicatorColor = DeepAirlineBlue.copy(alpha = 0.12f),
                unselectedIconColor = TextSecondary,
                unselectedTextColor = TextSecondary
            )
        )

        NavigationBarItem(
            selected = activeTab == AppTab.TRIPS,
            onClick = { onTabSelected(AppTab.TRIPS) },
            icon = { Icon(Icons.Default.CardTravel, contentDescription = "Trips") },
            label = { Text(if (isZh) "行程" else "Trips", fontSize = 11.sp, fontWeight = FontWeight.Medium) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = DeepAirlineBlue,
                selectedTextColor = DeepAirlineBlue,
                indicatorColor = DeepAirlineBlue.copy(alpha = 0.12f),
                unselectedIconColor = TextSecondary,
                unselectedTextColor = TextSecondary
            )
        )

        NavigationBarItem(
            selected = activeTab == AppTab.SEARCH_BOOK,
            onClick = { onTabSelected(AppTab.SEARCH_BOOK) },
            icon = { Icon(Icons.Default.Flight, contentDescription = "Flights") },
            label = { Text(if (isZh) "机票" else "Flights", fontSize = 11.sp, fontWeight = FontWeight.Medium) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = DeepAirlineBlue,
                selectedTextColor = DeepAirlineBlue,
                indicatorColor = DeepAirlineBlue.copy(alpha = 0.12f),
                unselectedIconColor = TextSecondary,
                unselectedTextColor = TextSecondary
            )
        )

        NavigationBarItem(
            selected = activeTab == AppTab.LOYALTY,
            onClick = { onTabSelected(AppTab.LOYALTY) },
            icon = { Icon(Icons.Default.Star, contentDescription = "Membership") },
            label = { Text(if (isZh) "会员" else "Membership", fontSize = 11.sp, fontWeight = FontWeight.Medium) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = DeepAirlineBlue,
                selectedTextColor = DeepAirlineBlue,
                indicatorColor = DeepAirlineBlue.copy(alpha = 0.12f),
                unselectedIconColor = TextSecondary,
                unselectedTextColor = TextSecondary
            )
        )

        NavigationBarItem(
            selected = activeTab == AppTab.PROFILE,
            onClick = { onTabSelected(AppTab.PROFILE) },
            icon = { Icon(Icons.Default.Person, contentDescription = "Profile") },
            label = { Text(if (isZh) "我的" else "Profile", fontSize = 11.sp, fontWeight = FontWeight.Medium) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = DeepAirlineBlue,
                selectedTextColor = DeepAirlineBlue,
                indicatorColor = DeepAirlineBlue.copy(alpha = 0.12f),
                unselectedIconColor = TextSecondary,
                unselectedTextColor = TextSecondary
            )
        )
    }
}
