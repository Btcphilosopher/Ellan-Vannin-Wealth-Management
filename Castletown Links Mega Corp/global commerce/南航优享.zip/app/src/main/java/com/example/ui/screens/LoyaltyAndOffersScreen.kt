package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.AppLanguage
import com.example.model.Coupon
import com.example.ui.theme.*
import com.example.viewmodel.MainViewModel

@Composable
fun LoyaltyAndOffersScreen(viewModel: MainViewModel) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isZh = currentLanguage == AppLanguage.ZH_CN
    val loyaltyAccount by viewModel.loyaltyAccount.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmGreyBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Loyalty Card (银卡 SILVER)
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = AviationBlueHeader,
                shadowElevation = 6.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(if (isZh) "南航优享会员" else "SOUTHERN VALUE CLUB", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            Text(loyaltyAccount.memberName, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                        }
                        Surface(shape = RoundedCornerShape(20.dp), color = MetallicGold) {
                            Text(
                                text = if (isZh) loyaltyAccount.tier.zh else loyaltyAccount.tier.en,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(if (isZh) "可用积分" else "Points Balance", fontSize = 11.sp, color = Color.White.copy(alpha = 0.8f))
                            Text("${loyaltyAccount.points}", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(if (isZh) "本年度飞行" else "Annual Distance", fontSize = 11.sp, color = Color.White.copy(alpha = 0.8f))
                            Text("${loyaltyAccount.annualKm} km", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Progress to Gold Card
                    Text(
                        text = if (isZh) "距离升级金卡还需 3,200 定级里程" else "3,200 miles to Gold Card",
                        fontSize = 11.sp,
                        color = Color.White.copy(alpha = 0.9f)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = 0.85f,
                        modifier = Modifier.fillMaxWidth().height(6.dp),
                        color = MetallicGold,
                        trackColor = Color.White.copy(alpha = 0.3f)
                    )
                }
            }
        }

        // Available Coupons & Vouchers
        item {
            Text(if (isZh) "我的优惠券与礼遇" else "My Vouchers & Perks", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextDarkPrimary)
            Spacer(modifier = Modifier.height(8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                loyaltyAccount.vouchers.forEach { voucher ->
                    VoucherCard(coupon = voucher, isZh = isZh)
                }
            }
        }
    }
}

@Composable
private fun VoucherCard(coupon: Coupon, isZh: Boolean) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = SurfaceCardWhite,
        border = BorderStroke(1.dp, BorderLight),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CardGiftcard, contentDescription = null, tint = DeepAirlineBlue, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(if (isZh) coupon.nameZh else coupon.nameEn, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextDarkPrimary)
                    Text("${if (isZh) "有效期至" else "Valid until"}: ${coupon.validUntil}", fontSize = 11.sp, color = TextSecondary)
                }
            }
            Button(
                onClick = {},
                colors = ButtonDefaults.buttonColors(containerColor = VeryLightBlue),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                shape = RoundedCornerShape(6.dp)
            ) {
                Text(if (isZh) "使用" else "Use", color = DeepAirlineBlue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
