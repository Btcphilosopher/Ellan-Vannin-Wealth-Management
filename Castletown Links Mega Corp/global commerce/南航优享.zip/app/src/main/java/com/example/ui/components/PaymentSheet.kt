package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.AppLanguage
import com.example.model.PaymentMethod
import com.example.ui.theme.*

@Composable
fun PaymentSheet(
    totalPrice: Int,
    selectedMethod: PaymentMethod,
    isProcessing: Boolean,
    currentLanguage: AppLanguage,
    onMethodSelected: (PaymentMethod) -> Unit,
    onConfirmPayment: () -> Unit
) {
    val isZh = currentLanguage == AppLanguage.ZH_CN

    Surface(
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
        color = SurfaceCardWhite,
        shadowElevation = 8.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Text(
                text = if (isZh) "订单确认与支付" else "Order Confirmation & Payment",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = DeepAirlineBlue
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Total Amount Display
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isZh) "应付总金额" else "Total Payable",
                    fontSize = 15.sp,
                    color = TextSecondary
                )
                Row(verticalAlignment = Alignment.Bottom) {
                    Text("¥", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = ControlledRed)
                    Text("$totalPrice", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = ControlledRed)
                }
            }

            HorizontalDivider(color = BorderLight)
            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = if (isZh) "选择支付方式" else "Select Payment Method",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = TextDarkPrimary
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Payment Methods Selection List
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                PaymentMethodItem(
                    method = PaymentMethod.ALIPAY,
                    icon = Icons.Default.QrCodeScanner,
                    iconTint = Color(0xFF1677FF),
                    isSelected = selectedMethod == PaymentMethod.ALIPAY,
                    isZh = isZh,
                    onClick = { onMethodSelected(PaymentMethod.ALIPAY) }
                )

                PaymentMethodItem(
                    method = PaymentMethod.WECHAT,
                    icon = Icons.Default.Payment,
                    iconTint = Color(0xFF07C160),
                    isSelected = selectedMethod == PaymentMethod.WECHAT,
                    isZh = isZh,
                    onClick = { onMethodSelected(PaymentMethod.WECHAT) }
                )

                PaymentMethodItem(
                    method = PaymentMethod.AIRLINE_WALLET,
                    icon = Icons.Default.AccountBalanceWallet,
                    iconTint = DeepAirlineBlue,
                    isSelected = selectedMethod == PaymentMethod.AIRLINE_WALLET,
                    isZh = isZh,
                    onClick = { onMethodSelected(PaymentMethod.AIRLINE_WALLET) }
                )

                PaymentMethodItem(
                    method = PaymentMethod.UNIONPAY,
                    icon = Icons.Default.CreditCard,
                    iconTint = Color(0xFFE60012),
                    isSelected = selectedMethod == PaymentMethod.UNIONPAY,
                    isZh = isZh,
                    onClick = { onMethodSelected(PaymentMethod.UNIONPAY) }
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Confirm Pay Button
            Button(
                onClick = onConfirmPayment,
                enabled = !isProcessing,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = ControlledRed),
                shape = RoundedCornerShape(12.dp)
            ) {
                if (isProcessing) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(if (isZh) "正在安全支付并出票..." else "Processing payment...", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                } else {
                    Text(
                        text = if (isZh) "确认并支付 ¥$totalPrice" else "Pay ¥$totalPrice Now",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = if (isZh) "🔒 256位安全加密 • 模拟示范交易环境" else "🔒 Safe payment • Simulated environment",
                fontSize = 11.sp,
                color = TextSecondary,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
        }
    }
}

@Composable
private fun PaymentMethodItem(
    method: PaymentMethod,
    icon: ImageVector,
    iconTint: Color,
    isSelected: Boolean,
    isZh: Boolean,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, if (isSelected) DeepAirlineBlue else BorderLight),
        color = if (isSelected) VeryLightBlue.copy(alpha = 0.5f) else Color.White,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = if (isZh) method.nameZh else method.nameEn,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextDarkPrimary
                )
            }
            if (isSelected) {
                Icon(Icons.Default.CheckCircle, contentDescription = "Selected", tint = DeepAirlineBlue, modifier = Modifier.size(20.dp))
            }
        }
    }
}
