/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import {
  Bank,
  MonetaryAggregates,
  MacroVariables,
  TokenizedSecurity,
  RepoTransaction,
  Scenario,
  Transaction,
  EventLog,
  SystemResiliency
} from "../types";
import {
  Activity,
  ArrowRight,
  TrendingUp,
  AlertOctagon,
  Building2,
  Lock,
  Unlock,
  Coins,
  Shield,
  HelpCircle,
  Database,
  Play,
  Pause,
  AlertTriangle,
  Flame,
  Globe2
} from "lucide-react";

interface CentralBankDashboardProps {
  // Sim Clock
  isPaused: boolean;
  onTogglePlayPause: () => void;
  dateTime: Date;
  clockSpeed: string;
  onSpeedChange: (speed: any) => void;

  // Data
  aggregates: MonetaryAggregates;
  macro: MacroVariables;
  banks: Bank[];
  securities: TokenizedSecurity[];
  repos: RepoTransaction[];
  ledger: Transaction[];
  eventLogs: EventLog[];
  scenarios: Scenario[];
  activeScenarioId: string;
  resiliency: SystemResiliency;

  // Actions
  onApplyScenario: (id: string) => void;
  onToggleResiliencyNode: (node: keyof SystemResiliency) => void;
  onChangePolicyRate: (bp: number) => void;
  onExecuteDvp: (secId: string, buyerId: string, sellerId: string, vol: number) => void;
  onRepo: (bankId: string, secId: string, amt: number) => void;
  onDisburseGov: (cat: string, amt: number) => void;
  onPayTax: (id: string) => void;
  taxObligations: any[];
  govFunds: any;
}

export default function CentralBankDashboard({
  isPaused,
  onTogglePlayPause,
  dateTime,
  clockSpeed,
  onSpeedChange,
  aggregates,
  macro,
  banks,
  securities,
  repos,
  ledger,
  eventLogs,
  scenarios,
  activeScenarioId,
  resiliency,
  onApplyScenario,
  onToggleResiliencyNode,
  onChangePolicyRate,
  onExecuteDvp,
  onRepo,
  onDisburseGov,
  onPayTax,
  taxObligations,
  govFunds
}: CentralBankDashboardProps) {
  const [activeTab, setActiveTab] = useState<string>("MONEDA");
  
  // Local state for interactive tools
  const [dvpSecId, setDvpSecId] = useState(securities[0]?.id || "");
  const [dvpBuyerId, setDvpBuyerId] = useState(banks[0]?.id || "");
  const [dvpSellerId, setDvpSellerId] = useState(banks[1]?.id || "");
  const [dvpVol, setDvpVol] = useState("10000");

  const [repoBankId, setRepoBankId] = useState(banks[0]?.id || "");
  const [repoSecId, setRepoSecId] = useState(securities[0]?.id || "");
  const [repoAmt, setRepoAmt] = useState("100000");

  const [govCat, setGovCat] = useState("Pensiones Bienestar");
  const [govAmt, setGovAmt] = useState("1000000");

  const currentScenario = scenarios.find(s => s.id === activeScenarioId);

  // Compute central bank balance sheet
  const totalBankReserves = banks.reduce((sum, b) => sum + b.reserves, 0);
  const totalWholesaleMdbc = banks.reduce((sum, b) => sum + b.digitalPesoWholesale, 0);
  const totalRepoSecuritiesCollateral = repos.reduce((sum, r) => sum + r.principalAmount, 0);

  return (
    <div className="bg-[#18181b] border border-[#27272a] rounded-lg overflow-hidden flex flex-col md:flex-row h-full" id="central-control-dashboard">
      
      {/* Left side Control Room Hub Menu */}
      <div className="w-full md:w-60 bg-[#09090b] border-r border-[#27272a] flex flex-col justify-between">
        <div className="p-4 space-y-4">
          <div className="space-y-1">
            <span className="text-[10px] text-[#10b981] font-bold uppercase tracking-widest block">CONTROL CENTRAL</span>
            <h2 className="text-sm font-bold text-white tracking-wider">BANCO DE MÉXICO</h2>
          </div>

          {/* Nav tabs list */}
          <nav className="space-y-1">
            {[
              "MONEDA",
              "PAGOS",
              "BANCOS",
              "LIQUIDEZ",
              "FX",
              "VALORES",
              "GOBIERNO",
              "RIESGO",
              "MACRO",
              "RESILIENCIA"
            ].map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`w-full text-left text-xs px-3 py-2 font-bold transition-all flex items-center justify-between ${
                  activeTab === tab
                    ? "bg-[#18181b] border-l-4 border-[#10b981] text-[#10b981]"
                    : "text-[#71717a] hover:text-[#a1a1aa] hover:bg-[#18181b]/50"
                }`}
              >
                <span>{tab}</span>
                <ArrowRight className="w-3 h-3 opacity-60" />
              </button>
            ))}
          </nav>
        </div>

        {/* Global Clock Control block */}
        <div className="p-4 border-t border-[#27272a] space-y-3 bg-[#121214]">
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-[#71717a] font-bold uppercase">RELOJ DE SIMULACIÓN</span>
            <span className="text-[10px] text-white font-mono">{dateTime.toLocaleTimeString()}</span>
          </div>

          <div className="flex space-x-2">
            <button
              onClick={onTogglePlayPause}
              className={`flex-1 py-1 px-3 text-xs font-bold rounded flex items-center justify-center space-x-1 ${
                isPaused
                  ? "bg-[#10b981] text-[#09090b]"
                  : "bg-red-600 text-white"
              }`}
            >
              {isPaused ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />}
              <span>{isPaused ? "REUNUDAR" : "PAUSA"}</span>
            </button>
          </div>
          <p className="text-[8px] text-[#71717a] leading-relaxed">
            * El reloj propaga flujos de compensación sintéticos que alteran la balanza de reservas interbancarias.
          </p>
        </div>
      </div>

      {/* Main Panel Content Area */}
      <div className="flex-1 p-6 overflow-y-auto max-h-[640px] space-y-6">
        
        {/* Active Scenario Banner */}
        {currentScenario && (
          <div className="bg-[#121214] border border-[#27272a] p-4 flex items-center justify-between">
            <div className="space-y-1">
              <span className="text-[9px] bg-white/10 text-white font-bold px-1.5 py-0.5 rounded uppercase">
                ESCENARIO EXPERIMENTAL EN CURSO
              </span>
              <h3 className="text-sm font-extrabold text-[#10b981]">
                {currentScenario.title}: {currentScenario.subtitle}
              </h3>
              <p className="text-[11px] text-[#71717a] max-w-2xl leading-relaxed">
                {currentScenario.description}
              </p>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* TABS IMPLEMENTATIONS */}
        {/* ======================================================== */}

        {activeTab === "MONEDA" && (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-extrabold text-white">INDICADORES DE AGREGADOS MONETARIOS</h3>
              <p className="text-xs text-[#71717a]">Estructuración dual de la oferta de dinero soberano y comercial en México.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-[#09090b] border border-[#27272a] p-4">
                <span className="text-[10px] text-[#71717a] font-bold uppercase">M0 - Base Monetaria Sólida</span>
                <div className="text-xl font-black text-white mt-1">
                  ${(aggregates.baseMoney / 1000).toFixed(1)}B <span className="text-xs text-[#71717a]">MXN</span>
                </div>
                <div className="mt-2 text-[10px] text-[#71717a] space-y-1 border-t border-[#27272a] pt-2">
                  <div className="flex justify-between">
                    <span>Efectivo Físico:</span>
                    <span className="font-bold text-white">${(aggregates.banknotesAndCoins / 1000).toFixed(1)}B</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Reservas Bancarias:</span>
                    <span className="font-bold text-white">${(aggregates.reserves / 1000).toFixed(1)}B</span>
                  </div>
                  <div className="flex justify-between text-[#10b981]">
                    <span>Peso Digital (Circulación):</span>
                    <span className="font-bold">${(aggregates.digitalPesoSupply / 1000).toFixed(1)}B</span>
                  </div>
                </div>
              </div>

              <div className="bg-[#09090b] border border-[#27272a] p-4">
                <span className="text-[10px] text-[#71717a] font-bold uppercase">M1 - Dinero Transaccional</span>
                <div className="text-xl font-black text-white mt-1">
                  ${(aggregates.broadMoneyM1 / 1000).toFixed(1)}B <span className="text-xs text-[#71717a]">MXN</span>
                </div>
                <div className="mt-2 text-[10px] text-[#71717a] space-y-1 border-t border-[#27272a] pt-2">
                  <div className="flex justify-between">
                    <span>Cuentas de Cheques:</span>
                    <span className="font-bold text-white">${(aggregates.bankDepositsRetail / 1000).toFixed(1)}B</span>
                  </div>
                  <div className="flex justify-between text-[#10b981]">
                    <span>Billeteras Retail MDBC:</span>
                    <span className="font-bold">${(aggregates.digitalPesoSupply / 1000).toFixed(1)}B</span>
                  </div>
                </div>
              </div>

              <div className="bg-[#09090b] border border-[#27272a] p-4">
                <span className="text-[10px] text-[#71717a] font-bold uppercase">M2 - Oferta Monetaria Amplia</span>
                <div className="text-xl font-black text-white mt-1">
                  ${(aggregates.broadMoneyM2 / 1000).toFixed(1)}B <span className="text-xs text-[#71717a]">MXN</span>
                </div>
                <div className="mt-2 text-[10px] text-[#71717a] space-y-1 border-t border-[#27272a] pt-2">
                  <div className="flex justify-between">
                    <span>Ahorros a Plazo:</span>
                    <span className="font-bold text-white">${(aggregates.savingsDeposits / 1000).toFixed(1)}B</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Depósitos Tokenizados:</span>
                    <span className="font-bold text-white">${(aggregates.tokenizedDeposits / 1000).toFixed(1)}B</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Banco de México institutional double entry Balance Sheet */}
            <div className="bg-[#09090b] border border-[#27272a] p-5">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">
                ESTADO DE SITUACIÓN FINANCIERA (CONTABILIDAD DUAL BANXICO)
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs border-t border-[#27272a] pt-4">
                <div className="space-y-2">
                  <span className="text-[#10b981] font-bold block">ACTIVOS (Garantías & Divisas)</span>
                  <div className="space-y-1">
                    <div className="flex justify-between border-b border-[#1f1f23] pb-1">
                      <span>Divisas Extranjeras (Reserva):</span>
                      <span className="font-bold text-white">$125,420,000 MXN</span>
                    </div>
                    <div className="flex justify-between border-b border-[#1f1f23] pb-1">
                      <span>Valores Gubernamentales held:</span>
                      <span className="font-bold text-white">$45,000,000 MXN</span>
                    </div>
                    <div className="flex justify-between border-b border-[#1f1f23] pb-1">
                      <span>Créditos de Liquidez a Intermediarios:</span>
                      <span className="font-bold text-white">${totalRepoSecuritiesCollateral.toLocaleString()} MXN</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <span className="text-[#ef4444] font-bold block">PASIVOS & CAPITAL (Pasivos Soberanos directos)</span>
                  <div className="space-y-1">
                    <div className="flex justify-between border-b border-[#1f1f23] pb-1">
                      <span>Efectivo Físico Emitido:</span>
                      <span className="font-bold text-white">$105,000,000 MXN</span>
                    </div>
                    <div className="flex justify-between border-b border-[#1f1f23] pb-1">
                      <span>Saldos de Cuenta de Enlace Único (SPEI):</span>
                      <span className="font-bold text-white">${totalBankReserves.toLocaleString()} MXN</span>
                    </div>
                    <div className="flex justify-between border-b border-[#1f1f23] pb-1 text-[#10b981]">
                      <span>Moneda Digital de Banco Central (MDBC):</span>
                      <span className="font-bold">${aggregates.digitalPesoSupply.toLocaleString()} MXN</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === "PAGOS" && (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-extrabold text-white">RED NACIONAL DE LIQUIDACIÓN Y COMPENSACIÓN</h3>
              <p className="text-xs text-[#71717a]">Historial de transacciones ejecutadas y canales de compensación interbancaria.</p>
            </div>

            {/* Audit ledger list of double entry txs */}
            <div className="bg-[#09090b] border border-[#27272a] p-4 space-y-4">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                REGISTRO DEL LIBRO CONTABLE SINO-AUDITABLE
              </h4>
              <div className="space-y-2.5 max-h-[350px] overflow-y-auto pr-2 text-[11px] font-mono">
                {ledger.map((tx) => (
                  <div key={tx.id} className="border border-[#27272a] bg-[#121214] p-3 rounded space-y-2">
                    <div className="flex justify-between items-center text-[10px]">
                      <span className="bg-[#10b981]/10 text-[#10b981] font-bold px-1.5 py-0.5 rounded">
                        {tx.type}
                      </span>
                      <span className="text-[#71717a]">{tx.simTime} • TX: {tx.id}</span>
                    </div>
                    <div className="flex justify-between">
                      <div>
                        <div className="text-white font-semibold">Payer: <span className="text-gray-300 font-normal">{tx.payer}</span></div>
                        <div className="text-white font-semibold">Payee: <span className="text-gray-300 font-normal">{tx.payee}</span></div>
                      </div>
                      <div className="text-right">
                        <div className="font-extrabold text-[#10b981]">${tx.amount.toLocaleString()} {tx.currency}</div>
                        <div className="text-[9px] text-[#71717a]">{tx.instrument}</div>
                      </div>
                    </div>
                    
                    {/* Ledger Entries */}
                    <div className="bg-black/60 p-2 text-[9px] text-[#71717a] space-y-1">
                      <div>CONTABILIDAD DE ASIENTOS:</div>
                      {tx.ledgerEntries.map((e, idx) => (
                        <div key={idx} className="flex justify-between font-mono">
                          <span>{e.entityName} ({e.accountId})</span>
                          <span className={e.accountType === "DEBIT" ? "text-red-400" : "text-[#10b981]"}>
                            {e.accountType}: ${e.amount.toLocaleString()}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === "BANCOS" && (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-extrabold text-white">SISTEMA DE INTERMEDIARIOS FINANCIEROS (BANCOS)</h3>
              <p className="text-xs text-[#71717a]">Balance contable y adecuación de capital de los 10 bancos sintéticos comerciales.</p>
            </div>

            <div className="space-y-4">
              {banks.map((b) => (
                <div key={b.id} className="bg-[#09090b] border border-[#27272a] p-4 rounded-md space-y-3">
                  <div className="flex justify-between items-center border-b border-[#27272a] pb-2">
                    <span className="font-bold text-white text-xs">{b.name}</span>
                    <div className="flex space-x-2 text-[9px] font-bold uppercase">
                      <span className="text-[#10b981]">Ratio Liq: {b.liquidityRatio}%</span>
                      <span className="text-[#3b82f6]">ICAP Adecuación: {b.capitalAdequacyRatio}%</span>
                    </div>
                  </div>

                  {/* Financial items */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-[11px] leading-relaxed">
                    <div>
                      <div className="text-[#71717a]">Reservas en Banxico</div>
                      <div className="font-extrabold text-white">${b.reserves.toLocaleString()} MXN</div>
                    </div>
                    <div>
                      <div className="text-[#71717a]">MXN-Digital Mayorista</div>
                      <div className="font-extrabold text-white">${b.digitalPesoWholesale.toLocaleString()} MXN</div>
                    </div>
                    <div>
                      <div className="text-[#71717a]">Cartera de Crédito</div>
                      <div className="font-extrabold text-white">${b.loans.toLocaleString()} MXN</div>
                    </div>
                    <div>
                      <div className="text-[#71717a]">Obligaciones con Clientes (Depósitos)</div>
                      <div className="font-extrabold text-[#ef4444]">${(b.depositsRetail + b.depositsCorporate).toLocaleString()} MXN</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === "LIQUIDEZ" && (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-extrabold text-white">LIQUIDEZ INTERBANCARIA Y OPERACIONES DE REPO</h3>
              <p className="text-xs text-[#71717a]">Asistencia de liquidez de última instancia y reportos garantizados.</p>
            </div>

            {/* Repo generator */}
            <div className="bg-[#09090b] border border-[#27272a] p-5 space-y-4">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">CREAR NUEVO CONTRATO REPO (REPORTOS)</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] text-[#71717a] font-bold">Banco Solicitante</label>
                  <select
                    value={repoBankId}
                    onChange={(e) => setRepoBankId(e.target.value)}
                    className="w-full bg-[#18181b] border border-[#27272a] text-xs p-1.5 text-white"
                  >
                    {banks.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-[#71717a] font-bold">Garantía / Colateral</label>
                  <select
                    value={repoSecId}
                    onChange={(e) => setRepoSecId(e.target.value)}
                    className="w-full bg-[#18181b] border border-[#27272a] text-xs p-1.5 text-white"
                  >
                    {securities.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-[#71717a] font-bold">Principal a Recibir ($ MXN)</label>
                  <div className="flex space-x-2">
                    <input
                      type="number"
                      value={repoAmt}
                      onChange={(e) => setRepoAmt(e.target.value)}
                      className="bg-[#18181b] border border-[#27272a] text-xs p-1 w-full text-white"
                    />
                    <button
                      onClick={() => onRepo(repoBankId, repoSecId, parseFloat(repoAmt))}
                      className="bg-[#10b981] hover:bg-[#10b981]/90 text-[#09090b] font-bold text-xs px-3 rounded"
                    >
                      Pactar
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Repos list */}
            <div className="bg-[#09090b] border border-[#27272a] p-4">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">CONTRATOS REPO ACTIVOS CON BANXICO</h4>
              {repos.length > 0 ? (
                <div className="space-y-2">
                  {repos.map((r) => (
                    <div key={r.id} className="border border-[#27272a] p-3 text-xs flex justify-between items-center bg-[#121214]">
                      <div>
                        <div className="font-bold text-white">Reporto: {r.id}</div>
                        <div className="text-[10px] text-[#71717a]">Banco Deudor: {r.borrowerBankId} • Plazo: {r.maturityDays} Días</div>
                      </div>
                      <div className="text-right">
                        <div className="font-black text-[#10b981]">${r.principalAmount.toLocaleString()} MXN</div>
                        <div className="text-[9px] text-[#71717a]">Aforado con {r.collateralSecurityId} ({r.haircut}% aforo)</div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-6 text-[#71717a] text-xs">
                  Sin reportos activos. Utilice la caja superior para pactar liquidez de emergencia.
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === "FX" && (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-extrabold text-white">MESA CAMBIARIA Y PARIDADES DE DIVISAS (FX LAB)</h3>
              <p className="text-xs text-[#71717a]">Control de tipos de cambio spot y arbitrajes multilaterales frente al peso.</p>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              {[
                { name: "Dólar Americano (USD/MXN)", rate: macro.exchangeRateUSD },
                { name: "Euro (EUR/MXN)", rate: macro.exchangeRateEUR },
                { name: "Dólar Canadiense (CAD/MXN)", rate: macro.exchangeRateCAD },
                { name: "Yen Japonés (JPY/MXN)", rate: macro.exchangeRateJPY },
                { name: "Yuan Chino (CNY/MXN)", rate: macro.exchangeRateCNY },
                { name: "Libra Esterlina (GBP/MXN)", rate: macro.exchangeRateGBP }
              ].map((fx, idx) => (
                <div key={idx} className="bg-[#09090b] border border-[#27272a] p-4 text-center">
                  <span className="text-[10px] text-[#71717a] font-bold block">{fx.name}</span>
                  <div className="text-2xl font-black text-[#10b981] mt-1">
                    ${fx.rate.toFixed(4)} <span className="text-[10px] text-[#71717a]">MXN</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === "VALORES" && (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-extrabold text-white">MERCADO DE VALORES TOKENIZADOS SOBERANOS</h3>
              <p className="text-xs text-[#71717a]">Liquidación inmediata Delivery Versus Payment (DvP) libre de riesgo de entrega.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {securities.map((sec) => (
                <div key={sec.id} className="bg-[#09090b] border border-[#27272a] p-4 text-xs space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-white text-xs">{sec.name}</span>
                    <span className="text-[#10b981] font-bold">Rendimiento: {sec.yieldToMaturity}%</span>
                  </div>
                  <div className="flex justify-between text-[11px] text-[#71717a]">
                    <span>Valor Nominal: ${sec.faceValue} MXN</span>
                    <span>Mercado: ${sec.marketPrice} MXN</span>
                  </div>
                </div>
              ))}
            </div>

            {/* DVP trade executor */}
            <div className="bg-[#09090b] border border-[#27272a] p-5 space-y-4">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">MESA LIQUIDADORA DVP ATÓMICA</h4>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs">
                <div className="space-y-1">
                  <label className="text-[#71717a]">Papel Gubernamental</label>
                  <select value={dvpSecId} onChange={e => setDvpSecId(e.target.value)} className="w-full bg-[#18181b] border border-[#27272a] p-1 text-white">
                    {securities.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-[#71717a]">Banco Comprador</label>
                  <select value={dvpBuyerId} onChange={e => setDvpBuyerId(e.target.value)} className="w-full bg-[#18181b] border border-[#27272a] p-1 text-white">
                    {banks.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-[#71717a]">Banco Vendedor</label>
                  <select value={dvpSellerId} onChange={e => setDvpSellerId(e.target.value)} className="w-full bg-[#18181b] border border-[#27272a] p-1 text-white">
                    {banks.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-[#71717a]">Volumen Títulos</label>
                  <div className="flex space-x-2">
                    <input type="number" value={dvpVol} onChange={e => setDvpVol(e.target.value)} className="bg-[#18181b] border border-[#27272a] p-1 w-full text-white" />
                    <button onClick={() => onExecuteDvp(dvpSecId, dvpBuyerId, dvpSellerId, parseInt(dvpVol))} className="bg-[#10b981] text-[#09090b] font-bold px-3 py-1 rounded">Sellar</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === "GOBIERNO" && (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-extrabold text-white">GOBIERNO DIGITAL Y RECAUDACIÓN FISCAL</h3>
              <p className="text-xs text-[#71717a]">Simulador de dispersión presupuestaria de la Tesorería de la Federación y recaudación del SAT.</p>
            </div>

            {/* Disburse forms */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-[#09090b] border border-[#27272a] p-5 space-y-4">
                <h4 className="text-xs font-bold text-white uppercase tracking-wider">DISPERSAR BIENESTAR SOCIAL (TESOFE)</h4>
                <div className="space-y-3">
                  <div className="space-y-1">
                    <label className="text-[10px] text-[#71717a] font-bold">Programa / Destino</label>
                    <select value={govCat} onChange={e => setGovCat(e.target.value)} className="w-full bg-[#18181b] border border-[#27272a] text-xs p-1.5 text-white">
                      <option value="Pensión Adultos Mayores">Pensión Adultos Mayores</option>
                      <option value="Sembrando Vida">Sembrando Vida</option>
                      <option value="Beca Benito Juárez">Beca Benito Juárez</option>
                      <option value="Sueldos Sector Salud">Sueldos Sector Salud</option>
                    </select>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] text-[#71717a] font-bold">Importe Presupuestal ($ MXN)</label>
                    <div className="flex space-x-2">
                      <input type="number" value={govAmt} onChange={e => setGovAmt(e.target.value)} className="bg-[#18181b] border border-[#27272a] text-xs p-1.5 w-full text-white" />
                      <button onClick={() => onDisburseGov(govCat, parseFloat(govAmt))} className="bg-[#10b981] text-[#09090b] font-bold text-xs px-4 rounded">Dispersar</button>
                    </div>
                  </div>
                </div>
              </div>

              {/* SAT Tax collector */}
              <div className="bg-[#09090b] border border-[#27272a] p-5 space-y-4">
                <h4 className="text-xs font-bold text-white uppercase tracking-wider">RECAUDACIÓN SAT SÍNCRONA</h4>
                <div className="space-y-2 max-h-[160px] overflow-y-auto pr-2">
                  {taxObligations.map((obl) => (
                    <div key={obl.id} className="border border-[#27272a] p-2 text-[11px] flex justify-between items-center bg-[#121214]">
                      <div>
                        <div className="font-bold text-white">{obl.payerName}</div>
                        <div className="text-[9px] text-[#71717a]">{obl.type}</div>
                      </div>
                      <div>
                        {obl.paid ? (
                          <span className="text-[#10b981] font-bold text-[9px] uppercase">PAGADO</span>
                        ) : (
                          <button onClick={() => onPayTax(obl.id)} className="bg-[#ef4444] text-white font-bold text-[9px] px-2 py-0.5 rounded">Cobrar</button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === "RIESGO" && (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-extrabold text-white">CENTRO DE AUDITORÍA Y MONITOREO DE CUMPLIMIENTO AML</h3>
              <p className="text-xs text-[#71717a]">Detección automatizada de anomalías, estructuración, cuentas mula y velocidades atípicas.</p>
            </div>

            <div className="bg-[#09090b] border border-[#27272a] p-4 text-xs space-y-3">
              <h4 className="text-xs font-bold text-[#ef4444] uppercase tracking-wider">EVENTOS DE RIESGO DE ALTA PRIORIDAD DETECTADOS</h4>
              <div className="space-y-2">
                <div className="bg-[#121214] border border-red-500/20 p-3 rounded flex justify-between items-start">
                  <div>
                    <div className="font-bold text-white">ALERTA AML: Estructuración sospechosa</div>
                    <div className="text-[9px] text-[#71717a]">Detalle: Múltiples transferencias bajo el umbral legal para evadir reporte.</div>
                  </div>
                  <span className="text-[9px] bg-red-600 text-white font-bold px-1.5 py-0.5 rounded">Riesgo Alto</span>
                </div>

                <div className="bg-[#121214] border border-yellow-500/20 p-3 rounded flex justify-between items-start">
                  <div>
                    <div className="font-bold text-white">ALERTA AML: Anomalía de Velocidad Transaccional</div>
                    <div className="text-[9px] text-[#71717a]">Detalle: Cuenta puente 99X recibe depósitos y reenvía fondos en menos de 1.5s.</div>
                  </div>
                  <span className="text-[9px] bg-yellow-500 text-[#09090b] font-bold px-1.5 py-0.5 rounded">Riesgo Medio</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === "MACRO" && (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-extrabold text-white">VISTA MACROECONÓMICA Y MOTOR DE INFLACIÓN</h3>
              <p className="text-xs text-[#71717a]">Simulador de correlaciones dinámicas: Tasa Objetivo, PIB Nominal, Inflación y Tipos de Cambio.</p>
            </div>

            <div className="bg-[#09090b] border border-[#27272a] p-5 space-y-4">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">CÁMARA DE INTERRUPCIÓN DE LA TASA OBJETIVO SOBERANA</h4>
              <div className="flex items-center justify-between border-b border-[#27272a] pb-4">
                <div>
                  <span className="text-xs text-[#71717a] block">TASA DE INTERÉS OBJETIVO ACTUAL</span>
                  <div className="text-3xl font-black text-[#10b981]">{macro.policyRate.toFixed(2)}%</div>
                </div>
                <div className="flex space-x-2">
                  <button onClick={() => onChangePolicyRate(-25)} className="bg-[#18181b] border border-[#27272a] hover:bg-[#27272a] text-white font-bold text-xs py-2 px-4 rounded">-25 pb</button>
                  <button onClick={() => onChangePolicyRate(25)} className="bg-[#18181b] border border-[#27272a] hover:bg-[#27272a] text-[#10b981] font-bold text-xs py-2 px-4 rounded">+25 pb</button>
                  <button onClick={() => onChangePolicyRate(100)} className="bg-[#10b981]/10 border border-[#10b981]/30 hover:bg-[#10b981]/20 text-[#10b981] font-bold text-xs py-2 px-4 rounded">+100 pb</button>
                </div>
              </div>

              {/* MV = PY inspect block */}
              <div className="bg-[#121214] border border-[#27272a] p-4 rounded text-xs space-y-2">
                <div className="font-bold text-white">MODELO MACRO SINTÉTICO (Ecuación de Cambio):</div>
                <div className="text-sm font-mono text-[#a1a1aa] flex justify-around p-2 bg-black/40">
                  <span>M (Oferta) * V (Velocidad) = P (Precios) * Y (PIB Real)</span>
                </div>
                <p className="text-[10px] text-[#71717a] leading-relaxed">
                  Las expansiones monetarias en MXN-Digital potencian la velocidad del dinero (V) incrementando el PIB Nominal, pero con una tasa de interés restrictiva, Banxico contrae el crédito protegiendo el poder adquisitivo.
                </p>
              </div>
            </div>
          </div>
        )}

        {activeTab === "RESILIENCIA" && (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-extrabold text-white">MONITOR DE RESILIENCIA Y SUPERVIVENCIA NACIONAL</h3>
              <p className="text-xs text-[#71717a]">Modelado de apagones de telecomunicaciones y resiliencia de la infraestructura de pagos.</p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {[
                { label: "Libro Registro Central (Banxico)", node: "centralLedgerAvailable" as const },
                { label: "Cámara SPEI", node: "speiAvailable" as const },
                { label: "Canal QR CoDi", node: "codiAvailable" as const },
                { label: "Telecom / Red Móvil LTE", node: "mobileNetworkAvailable" as const },
                { label: "Red Eléctrica Nacional", node: "powerGridAvailable" as const },
                { label: "Infraestructura Cloud", node: "cloudInfrastructureAvailable" as const }
              ].map((n, idx) => {
                const available = (resiliency as any)[n.node];
                return (
                  <button
                    key={idx}
                    onClick={() => onToggleResiliencyNode(n.node)}
                    className={`p-4 border text-center transition-all flex flex-col justify-between h-24 ${
                      available
                        ? "bg-[#10b981]/10 border-[#10b981]/30 text-[#10b981] hover:bg-[#10b981]/20"
                        : "bg-[#ef4444]/10 border-[#ef4444]/30 text-[#ef4444] hover:bg-[#ef4444]/20"
                    }`}
                  >
                    <span className="text-[10px] font-bold uppercase block text-left text-white">{n.label}</span>
                    <span className="text-xs font-extrabold block text-right mt-3">
                      {available ? "SISTEMA ACTIVO" : "APAGADO / CAÍDO"}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
