/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { OfflineDeviceState } from "../types";
import {
  WifiOff,
  RefreshCw,
  Send,
  Cpu,
  Smartphone,
  ShieldCheck,
  CheckCircle,
  AlertTriangle
} from "lucide-react";

interface OfflineLabProps {
  deviceA: OfflineDeviceState;
  deviceB: OfflineDeviceState;
  isInternetAvailable: boolean;
  onExecuteOfflineTransfer: (amount: number) => void;
  onSyncOffline: () => void;
  onToggleInternet: () => void;
}

export default function OfflineLab({
  deviceA,
  deviceB,
  isInternetAvailable,
  onExecuteOfflineTransfer,
  onSyncOffline,
  onToggleInternet
}: OfflineLabProps) {
  const [amount, setAmount] = useState("200");

  const handleOfflineTransfer = () => {
    const amt = parseFloat(amount);
    if (isNaN(amt) || amt <= 0) return;
    onExecuteOfflineTransfer(amt);
  };

  const hasPending = deviceA.pendingTransactions.length > 0;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="offline-laboratory">
      {/* Offline Transfer controls */}
      <div className="lg:col-span-8 bg-[#18181b] border border-[#27272a] p-6 flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-semibold text-[#a1a1aa] tracking-wider uppercase">
              LABORATORIO DE EXPERIMENTACIÓN OFFLINE
            </h3>
            <span className={`text-[9px] font-bold px-2.5 py-0.5 rounded flex items-center space-x-1 ${
              !isInternetAvailable ? "bg-[#ef4444]/10 text-[#ef4444] border border-[#ef4444]/20" : "bg-[#10b981]/10 text-[#10b981] border border-[#10b981]/20"
            }`}>
              <WifiOff className="w-3 h-3 mr-1" />
              <span>{!isInternetAvailable ? "RED CAÍDA (OFFLINE)" : "CONEXIÓN ESTABLE (ONLINE)"}</span>
            </span>
          </div>
          <p className="text-xs text-[#71717a] mb-6">
            Soporte transaccional directo de dispositivo a dispositivo (P2P) usando chips criptográficos seguros (Hardware Secure Element) sin depender de internet o electricidad celular.
          </p>
        </div>

        {/* Dual devices graphic */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 my-4">
          {/* Device A Payer */}
          <div className="bg-[#09090b] border border-[#27272a] p-5 rounded-lg space-y-4">
            <div className="flex items-center justify-between border-b border-[#27272a] pb-2">
              <div className="flex items-center space-x-2 text-[#38bdf8]">
                <Smartphone className="w-4 h-4" />
                <span className="text-[11px] font-bold uppercase">DISPOSITIVO EMISOR (A)</span>
              </div>
              <Cpu className="w-3.5 h-3.5 text-[#71717a]" />
            </div>

            <div className="space-y-1">
              <span className="text-[9px] text-[#71717a] uppercase font-semibold">
                SALDO CRYPTO CHIP (LOCAL)
              </span>
              <div className="text-2xl font-black text-white">
                ${deviceA.offlineBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })} <span className="text-xs text-[#71717a]">MXN</span>
              </div>
            </div>

            <div className="space-y-2">
              <div className="text-[9px] text-[#71717a] font-semibold uppercase">MONTO DE TRANSFERENCIA P2P</div>
              <div className="flex space-x-2">
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="bg-[#18181b] border border-[#27272a] text-xs font-bold text-white p-1.5 rounded w-full"
                  placeholder="Monto"
                  disabled={isInternetAvailable}
                />
                <button
                  onClick={handleOfflineTransfer}
                  disabled={isInternetAvailable || deviceA.offlineBalance < parseFloat(amount)}
                  className="bg-[#38bdf8] hover:bg-[#38bdf8]/90 disabled:opacity-50 text-[#09090b] text-xs font-extrabold px-4 rounded flex items-center space-x-1 transition-all"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Firmar P2P</span>
                </button>
              </div>
              {isInternetAvailable && (
                <p className="text-[9px] text-yellow-400 italic">
                  * Deshabilite el internet de la red nacional primero para ensayar pagos offline.
                </p>
              )}
            </div>
          </div>

          {/* Device B Payee */}
          <div className="bg-[#09090b] border border-[#27272a] p-5 rounded-lg space-y-4">
            <div className="flex items-center justify-between border-b border-[#27272a] pb-2">
              <div className="flex items-center space-x-2 text-[#10b981]">
                <Smartphone className="w-4 h-4" />
                <span className="text-[11px] font-bold uppercase">DISPOSITIVO RECEPTOR (B)</span>
              </div>
              <Cpu className="w-3.5 h-3.5 text-[#71717a]" />
            </div>

            <div className="space-y-1">
              <span className="text-[9px] text-[#71717a] uppercase font-semibold">
                SALDO CRYPTO CHIP (LOCAL)
              </span>
              <div className="text-2xl font-black text-white">
                ${deviceB.offlineBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })} <span className="text-xs text-[#71717a]">MXN</span>
              </div>
            </div>

            <div className="bg-[#18181b] p-3 border border-[#27272a] rounded text-[10px] space-y-1">
              <span className="text-[#a1a1aa] font-bold">HISTORIAL DE FIRMAS RECIBIDAS (A → B)</span>
              <div className="space-y-1">
                {deviceB.pendingTransactions.length > 0 ? (
                  deviceB.pendingTransactions.map((tx, idx) => (
                    <div key={idx} className="flex justify-between items-center text-[9px] text-white">
                      <span>{tx.timestamp} - Token Recibido</span>
                      <span className="font-bold text-[#10b981]">+${tx.amount} MXN</span>
                    </div>
                  ))
                ) : (
                  <span className="text-[#71717a] italic text-[9px]">Ninguna firma en la sesión offline.</span>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Sync trigger button */}
        <div className="bg-[#09090b] border border-[#27272a] p-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mt-2">
          <div className="space-y-1">
            <h4 className="text-xs font-bold text-white uppercase">Sincronizar y Conciliar Libro Contable</h4>
            <p className="text-[10px] text-[#71717a] max-w-md leading-relaxed">
              Al restablecer la red, las transacciones guardadas en el chip físico se transmiten al Banco de México para conciliación y liquidación irrevocable.
            </p>
          </div>
          <button
            onClick={onSyncOffline}
            disabled={!isInternetAvailable || !hasPending}
            className="bg-[#10b981] hover:bg-[#10b981]/90 disabled:opacity-50 text-[#09090b] font-extrabold text-xs py-2.5 px-6 rounded flex items-center justify-center space-x-1.5 transition-all uppercase"
          >
            <RefreshCw className="w-4 h-4 animate-spin-slow" />
            <span>Sincronizar Libro Central</span>
          </button>
        </div>
      </div>

      {/* Offline Lab Theory and Flow */}
      <div className="lg:col-span-4 bg-[#18181b] border border-[#27272a] p-6 flex flex-col justify-between">
        <div className="space-y-5 text-xs">
          <div>
            <span className="text-[10px] text-yellow-400 font-bold uppercase tracking-widest block mb-1">
              LÍMITES Y PROTECCIÓN CONTRA DOBLE GASTO
            </span>
            <h4 className="text-base font-bold text-white tracking-tight">Arquitectura de Seguridad</h4>
          </div>

          <div className="space-y-3 leading-relaxed text-[#71717a]">
            <div className="flex items-start space-x-2">
              <ShieldCheck className="w-4 h-4 text-[#10b981] shrink-0 mt-0.5" />
              <p>
                <strong className="text-[#a1a1aa]">Secure Element (SE):</strong> Chips sellados físicamente en el teléfono móvil que decrementan y firman criptográficamente la transferencia de forma atómica.
              </p>
            </div>
            <div className="flex items-start space-x-2">
              <AlertTriangle className="w-4 h-4 text-yellow-400 shrink-0 mt-0.5" />
              <p>
                <strong className="text-[#a1a1aa]">Prevención de Doble Gasto:</strong> El hardware imposibilita copiar las llaves numéricas del balance offline, evitando gastos repetidos.
              </p>
            </div>
            <div className="flex items-start space-x-2">
              <CheckCircle className="w-4 h-4 text-[#38bdf8] shrink-0 mt-0.5" />
              <p>
                <strong className="text-[#a1a1aa]">Límite de Hardware ($5,000 MXN):</strong> Umbral máximo permitido para mantener acumulaciones offline sin validación directa con Banxico.
              </p>
            </div>
          </div>

          {/* Simulate Telecom failure switch button */}
          <div className="bg-[#09090b] border border-[#27272a] p-4 text-center space-y-3">
            <span className="text-[9px] text-[#71717a] uppercase font-bold block">CONTROL DE ENTORNO SINTÉTICO</span>
            <button
              onClick={onToggleInternet}
              className={`w-full text-xs font-bold py-2 rounded transition-all uppercase ${
                isInternetAvailable
                  ? "bg-[#ef4444]/10 border border-[#ef4444]/30 text-[#ef4444] hover:bg-[#ef4444]/20"
                  : "bg-[#10b981]/10 border border-[#10b981]/30 text-[#10b981] hover:bg-[#10b981]/20"
              }`}
            >
              {isInternetAvailable ? "DESCONECTAR RED NACIONAL" : "CONECTAR RED NACIONAL"}
            </button>
            <p className="text-[8px] text-[#71717a] italic">
              Use este botón para gatillar un apagón nacional controlado de red SPEI/CoDi.
            </p>
          </div>
        </div>

        <div className="text-[10px] text-[#71717a] italic mt-6 pt-3 border-t border-[#27272a]">
          * Prototipo bajo estricta simulación experimental matemática determinista.
        </div>
      </div>
    </div>
  );
}
