/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Merchant } from "../types";
import {
  QrCode,
  Wifi,
  FileText,
  Link as LinkIcon,
  Receipt,
  RotateCcw,
  RefreshCw,
  PlusCircle,
  TrendingUp
} from "lucide-react";

interface MerchantTerminalProps {
  merchant: Merchant;
  onReceivePayment: (merchantId: string, amount: number, channel: "CODI" | "SPEI" | "DIGITAL_PESO") => void;
  onRefund: (merchantId: string, amount: number) => void;
}

export default function MerchantTerminal({
  merchant,
  onReceivePayment,
  onRefund
}: MerchantTerminalProps) {
  const [activeChannel, setActiveChannel] = useState<"QR" | "NFC" | "LINK" | "INVOICE">("QR");
  const [requestAmount, setRequestAmount] = useState("150");
  const [invoiceDescription, setInvoiceDescription] = useState("Venta General");
  
  // Stats calculations
  const totalReceipts = merchant.digitalPesoReceipts + merchant.speiReceipts + merchant.codiReceipts;
  const transactionCount = Math.floor(totalReceipts / 180) + (merchant.refundsCount ? 2 : 5);
  const averageTx = transactionCount > 0 ? totalReceipts / transactionCount : 0;

  const handleSimulatePayment = () => {
    const amt = parseFloat(requestAmount);
    if (isNaN(amt) || amt <= 0) return;

    // Map active channel to payment instrument
    const channelMapping = {
      QR: "CODI",
      NFC: "DIGITAL_PESO",
      LINK: "CODI",
      INVOICE: "SPEI"
    } as const;

    onReceivePayment(merchant.id, amt, channelMapping[activeChannel]);
  };

  const handleTriggerRefund = () => {
    const amt = Math.min(100, merchant.todaySales);
    if (amt <= 0) return;
    onRefund(merchant.id, amt);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="merchant-terminal-lab">
      {/* Merchant POS / QR Terminal View */}
      <div className="lg:col-span-7 bg-[#18181b] border border-[#27272a] p-6 flex flex-col justify-between">
        <div>
          <h3 className="text-sm font-semibold text-[#a1a1aa] tracking-wider mb-1">
            TERMINAL DE COBRO DE PESO DIGITAL COMERCIO
          </h3>
          <p className="text-xs text-[#71717a] mb-6">
            Punto de venta (POS) para comercios de cualquier tamaño. Admite compensación multilateral neta en tiempo real.
          </p>
        </div>

        {/* Interactive POS Checkout Machine */}
        <div className="bg-[#09090b] border border-[#27272a] p-5 rounded-lg space-y-5">
          <div className="flex items-center justify-between border-b border-[#27272a] pb-3">
            <span className="text-xs font-bold text-white tracking-wider uppercase">NUEVA ORDEN DE COBRO</span>
            <span className="text-[9px] bg-[#10b981]/10 text-[#10b981] font-bold px-2 py-0.5 border border-[#10b981]/20 rounded">
              MODO CODI ONLINE
            </span>
          </div>

          <div className="grid grid-cols-2 gap-4">
            {/* Input Amount fields */}
            <div className="space-y-2">
              <label className="text-[10px] text-[#71717a] font-bold uppercase">Monto de Solicitud (MXN)</label>
              <div className="relative">
                <span className="absolute left-2.5 top-1/2 transform -translate-y-1/2 text-[#71717a] font-bold">$</span>
                <input
                  type="number"
                  value={requestAmount}
                  onChange={(e) => setRequestAmount(e.target.value)}
                  className="w-full bg-[#18181b] border border-[#27272a] rounded p-2 pl-6 text-sm text-white font-extrabold"
                  placeholder="0.00"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] text-[#71717a] font-bold uppercase">Descripción / Concepto</label>
              <input
                type="text"
                value={invoiceDescription}
                onChange={(e) => setInvoiceDescription(e.target.value)}
                className="w-full bg-[#18181b] border border-[#27272a] rounded p-2 text-xs text-white"
                placeholder="Ej. Consumo"
              />
            </div>
          </div>

          {/* Payment Method Channels Select */}
          <div className="grid grid-cols-4 gap-2">
            {[
              { id: "QR", label: "Código QR", icon: QrCode },
              { id: "NFC", label: "Cobro NFC", icon: Wifi },
              { id: "LINK", label: "Liga Pago", icon: LinkIcon },
              { id: "INVOICE", label: "Factura SPEI", icon: FileText }
            ].map((ch) => {
              const Icon = ch.icon;
              return (
                <button
                  key={ch.id}
                  onClick={() => setActiveChannel(ch.id as any)}
                  className={`flex flex-col items-center justify-center py-2.5 px-1 border transition-all ${
                    activeChannel === ch.id
                      ? "bg-[#10b981]/10 border-[#10b981] text-[#10b981]"
                      : "bg-[#18181b] border-[#27272a] text-[#71717a] hover:text-white"
                  }`}
                >
                  <Icon className="w-4 h-4 mb-1.5" />
                  <span className="text-[9px] font-bold">{ch.label}</span>
                </button>
              );
            })}
          </div>

          {/* Render Active Channel UI */}
          <div className="bg-[#121214] border border-[#27272a] p-4 flex flex-col items-center justify-center min-h-[160px]">
            {activeChannel === "QR" && (
              <div className="flex flex-col items-center text-center space-y-3">
                {/* SVG mock QR code */}
                <div className="w-24 h-24 bg-white p-1 rounded-sm border border-gray-300 flex items-center justify-center">
                  <div className="grid grid-cols-3 gap-1.5 w-full h-full opacity-90 p-1">
                    <div className="bg-black rounded-sm" />
                    <div className="bg-black rounded-sm" />
                    <div className="border border-black rounded-sm" />
                    <div className="border border-black rounded-sm" />
                    <div className="bg-black rounded-sm" />
                    <div className="bg-black rounded-sm" />
                    <div className="bg-black rounded-sm" />
                    <div className="border border-black rounded-sm" />
                    <div className="bg-black rounded-sm" />
                  </div>
                </div>
                <div className="text-[10px] text-[#71717a]">
                  Generando QR dinámico de CoDi. Pídele al cliente escanear desde su app bancaria.
                </div>
              </div>
            )}

            {activeChannel === "NFC" && (
              <div className="flex flex-col items-center text-center space-y-3 py-4">
                <Wifi className="w-10 h-10 text-[#10b981] animate-pulse" />
                <div className="text-[10px] text-white font-bold">CONTACTLESS ACTIVO</div>
                <div className="text-[9px] text-[#71717a] max-w-[280px]">
                  Acerque la tarjeta de débito o el teléfono celular del cliente al lector NFC del terminal.
                </div>
              </div>
            )}

            {activeChannel === "LINK" && (
              <div className="flex flex-col items-center text-center space-y-2 py-4 w-full">
                <div className="bg-[#18181b] p-2 border border-[#27272a] text-[10px] text-white w-full rounded select-all font-mono">
                  https://codi.banxico.org.mx/pay?id=tx_392A&m={requestAmount}
                </div>
                <div className="text-[9px] text-[#71717a]">
                  Enlace de pago para comercio electrónico o chat instantáneo de soporte.
                </div>
              </div>
            )}

            {activeChannel === "INVOICE" && (
              <div className="flex flex-col items-center text-center space-y-2 py-2 w-full">
                <div className="text-[10px] border border-dashed border-[#27272a] p-3 text-[#a1a1aa] w-full text-left font-mono bg-black/40">
                  FACTURA ELECTRÓNICA SAT v4.0<br />
                  Emisor: {merchant.name}<br />
                  Concepto: {invoiceDescription}<br />
                  Importe: ${requestAmount} MXN<br />
                  Riel: Liquidación Interbancaria SPEI
                </div>
                <div className="text-[9px] text-[#71717a]">
                  Factura y solicitud fiscal síncrona lista para envío directo.
                </div>
              </div>
            )}
          </div>

          {/* Trigger settlement Action */}
          <button
            onClick={handleSimulatePayment}
            className="w-full bg-[#10b981] hover:bg-[#10b981]/90 text-[#09090b] font-extrabold text-xs py-2.5 rounded transition-all tracking-wider uppercase"
          >
            SIMULAR ABONO DE CLIENTE (LIQUIDACIÓN INMEDIATA)
          </button>
        </div>
      </div>

      {/* Merchant Financial Dashboard / Analytics */}
      <div className="lg:col-span-5 bg-[#18181b] border border-[#27272a] p-6 flex flex-col justify-between">
        <div className="space-y-6">
          <div>
            <span className="text-xs text-[#10b981] font-semibold tracking-widest uppercase mb-1 block">
              MÉTRICAS OPERATIVAS COMERCIALES
            </span>
            <h2 className="text-2xl font-black text-white tracking-tight">{merchant.name}</h2>
          </div>

          {/* Live balance ledger of merchant */}
          <div className="bg-[#09090b] p-4 border border-[#27272a] space-y-1">
            <span className="text-[9px] text-[#71717a] font-bold uppercase tracking-wider">
              FONDO LÍQUIDO DISPONIBLE COMERCIO
            </span>
            <div className="text-2xl font-black text-[#10b981]">
              ${merchant.liquidity.toLocaleString(undefined, { minimumFractionDigits: 2 })} <span className="text-xs text-[#71717a]">MXN</span>
            </div>
          </div>

          {/* Sales channels statistics */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-[#a1a1aa]">Ventas Acumuladas Hoy</span>
              <span className="font-bold text-white">${merchant.todaySales.toLocaleString()} MXN</span>
            </div>
            
            <div className="space-y-1.5 border-t border-[#27272a] pt-3">
              <div className="flex items-center justify-between text-[11px]">
                <div className="flex items-center space-x-1.5 text-yellow-400">
                  <Wifi className="w-3.5 h-3.5" />
                  <span>Abonos MXN-Digital (NFC)</span>
                </div>
                <span className="font-semibold text-white">${merchant.digitalPesoReceipts.toLocaleString()}</span>
              </div>

              <div className="flex items-center justify-between text-[11px]">
                <div className="flex items-center space-x-1.5 text-[#10b981]">
                  <QrCode className="w-3.5 h-3.5" />
                  <span>Abonos CoDi (QR)</span>
                </div>
                <span className="font-semibold text-white">${merchant.codiReceipts.toLocaleString()}</span>
              </div>

              <div className="flex items-center justify-between text-[11px]">
                <div className="flex items-center space-x-1.5 text-[#3b82f6]">
                  <FileText className="w-3.5 h-3.5" />
                  <span>Abonos SPEI</span>
                </div>
                <span className="font-semibold text-white">${merchant.speiReceipts.toLocaleString()}</span>
              </div>
            </div>
          </div>

          {/* Multi-metrics list */}
          <div className="grid grid-cols-2 gap-3 border-t border-[#27272a] pt-4 text-[10px]">
            <div className="bg-[#09090b] p-2.5 border border-[#27272a]">
              <div className="text-[#71717a] uppercase font-bold">Ticket Promedio</div>
              <div className="text-sm font-bold text-white">${averageTx.toFixed(2)} MXN</div>
            </div>
            <div className="bg-[#09090b] p-2.5 border border-[#27272a]">
              <div className="text-[#71717a] uppercase font-bold">Latencia Liquidación</div>
              <div className="text-sm font-bold text-[#10b981]">{merchant.settlementLatencySec}s <span className="text-[8px] text-[#71717a]">Inmediato</span></div>
            </div>
          </div>
        </div>

        {/* Refunds block */}
        <div className="mt-6 pt-4 border-t border-[#27272a] flex items-center justify-between">
          <button
            onClick={handleTriggerRefund}
            disabled={merchant.todaySales === 0}
            className="flex items-center space-x-1.5 text-xs text-[#ef4444] hover:text-[#ef4444]/80 disabled:opacity-50 transition-colors font-semibold"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Devolver Última Venta ($100)</span>
          </button>
          <span className="text-[9px] text-[#71717a] italic">
            Devoluciones {merchant.refundsCount} procesadas
          </span>
        </div>
      </div>
    </div>
  );
}
