/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import {
  Lock,
  Unlock,
  CheckCircle,
  HelpCircle,
  Play,
  Settings,
  Coins,
  ArrowRight
} from "lucide-react";

interface PrimitiveContract {
  id: string;
  name: string;
  type: string;
  amount: number;
  payer: string;
  payee: string;
  condition: string;
  status: "LOCKED" | "RELEASED" | "PENDING_TRIGGER";
  ruleCode: string;
}

export default function ProgrammableMoneyLab({
  onReleaseContract
}: {
  onReleaseContract: (id: string, amount: number, payer: string, payee: string) => void;
}) {
  const [contracts, setContracts] = useState<PrimitiveContract[]>([
    {
      id: "prog-1",
      name: "Garantía de Arrendamiento (Escrow)",
      type: "ESCROW",
      amount: 12000,
      payer: "Sofía Rodríguez (Inquilino)",
      payee: "Inmobiliaria Centro",
      condition: "Liberación síncrona el 01 de Octubre o firma mutua de conformidad.",
      status: "LOCKED",
      ruleCode: "IF (current_date >= 2026-10-01) OR (signatures.count >= 2) -> RELEASE_FUNDS()"
    },
    {
      id: "prog-2",
      name: "Subsidio Bienestar Alimentario",
      type: "GOVERNMENT_TRANSFER",
      amount: 4500,
      payer: "Tesoraría de la Federación",
      payee: "Tiendas Rurales Liconsa",
      condition: "Solo gastable en abarrotes de canasta básica calificados por SAT.",
      status: "PENDING_TRIGGER",
      ruleCode: "IF (merchant.category_code == 'GROCERY') AND (item.tags.contains('BASIC')) -> APPROVE_PAYMENT()"
    },
    {
      id: "prog-3",
      name: "Liquidación Proveedor Logística",
      type: "SUPPLY_CHAIN",
      amount: 85000,
      payer: "Consorcio Maquilador Norte",
      payee: "Autofletes del Golfo",
      condition: "Liberar al registrar recibo firmado del sensor IoT de aduana de Nuevo Laredo.",
      status: "LOCKED",
      ruleCode: "IF (iot_sensor.status == 'DELIVERED') AND (customs.sign == TRUE) -> RELEASE_FUNDS()"
    },
    {
      id: "prog-4",
      name: "Pago de Peaje Autónomo (M2M)",
      type: "MACHINE_PAYMENT",
      amount: 145,
      payer: "Vehículo Eléctrico de Carga",
      payee: "Caseta de Autopistas de Cuota",
      condition: "Pago instantáneo entre el microcontrolador del camión y el portal RFID.",
      status: "PENDING_TRIGGER",
      ruleCode: "IF (rfid.vehicle_id == vehicle.id) AND (distance <= 0.1m) -> SETTLE_ATOMIC_PAYMENT()"
    }
  ]);

  const triggerRelease = (id: string) => {
    setContracts((prev) =>
      prev.map((c) => {
        if (c.id === id) {
          onReleaseContract(c.id, c.amount, c.payer, c.payee);
          return { ...c, status: "RELEASED" };
        }
        return c;
      })
    );
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="programmable-money-laboratory">
      {/* List of active programmable contracts */}
      <div className="lg:col-span-8 bg-[#18181b] border border-[#27272a] p-6 flex flex-col justify-between">
        <div>
          <h3 className="text-sm font-semibold text-[#a1a1aa] tracking-wider uppercase mb-1">
            CONTRATOS DE PAGO PROGRAMABLES SOBERANOS
          </h3>
          <p className="text-xs text-[#71717a] mb-6">
            Ensayo de lógica transaccional integrada (Smart Rules). A diferencia de las criptomonedas, las reglas de custodia operan directamente en el riel soberano de Banxico bajo cumplimiento regulatorio.
          </p>
        </div>

        {/* Grid of contracts */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {contracts.map((c) => {
            const isLocked = c.status === "LOCKED";
            const isReleased = c.status === "RELEASED";

            return (
              <div
                key={c.id}
                className={`bg-[#09090b] border p-4 rounded flex flex-col justify-between space-y-4 transition-all ${
                  isReleased
                    ? "border-[#10b981]/20 opacity-80"
                    : isLocked
                    ? "border-yellow-500/20"
                    : "border-[#38bdf8]/20"
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-bold text-[#a1a1aa] uppercase tracking-wide">
                      {c.type.replace("_", " ")}
                    </span>
                    {isReleased ? (
                      <span className="text-[9px] bg-[#10b981]/10 text-[#10b981] font-bold px-1.5 py-0.5 rounded border border-[#10b981]/20">
                        LIBERADO
                      </span>
                    ) : isLocked ? (
                      <span className="text-[9px] bg-yellow-500/10 text-yellow-500 font-bold px-1.5 py-0.5 rounded border border-yellow-500/20">
                        BLOQUEADO EN GARANTÍA
                      </span>
                    ) : (
                      <span className="text-[9px] bg-[#38bdf8]/10 text-[#38bdf8] font-bold px-1.5 py-0.5 rounded border border-[#38bdf8]/20">
                        PTE. GATILLAR
                      </span>
                    )}
                  </div>

                  <h4 className="text-xs font-bold text-white mb-1">{c.name}</h4>
                  <div className="text-[13px] font-black text-[#10b981] mb-2">
                    ${c.amount.toLocaleString()} MXN
                  </div>

                  <div className="space-y-1.5 border-t border-[#1f1f23] pt-2 text-[10px] text-[#71717a]">
                    <div>
                      <strong className="text-[#a1a1aa]">Ordenante:</strong> {c.payer}
                    </div>
                    <div>
                      <strong className="text-[#a1a1aa]">Beneficiario:</strong> {c.payee}
                    </div>
                    <div className="italic">
                      <strong className="text-[#a1a1aa] not-italic">Condición:</strong> {c.condition}
                    </div>
                  </div>
                </div>

                {/* Inspect Rule Code */}
                <div className="bg-[#121214] border border-[#27272a] p-2 rounded text-[9px] font-mono text-[#a1a1aa]">
                  {c.ruleCode}
                </div>

                {!isReleased && (
                  <button
                    onClick={() => triggerRelease(c.id)}
                    className="w-full bg-[#18181b] border border-[#27272a] text-white hover:bg-white hover:text-[#09090b] transition-all font-bold text-[10px] py-1.5 rounded uppercase flex items-center justify-center space-x-1"
                  >
                    <Play className="w-3 h-3" />
                    <span>FORZAR DISPARADOR / LIBERAR</span>
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Theory panel */}
      <div className="lg:col-span-4 bg-[#18181b] border border-[#27272a] p-6 flex flex-col justify-between">
        <div className="space-y-5 text-xs text-[#71717a] leading-relaxed">
          <div>
            <span className="text-[10px] text-[#10b981] font-semibold tracking-widest block mb-1">
              REQUISITOS DEL SISTEMA DE PAGOS
            </span>
            <h4 className="text-base font-bold text-white tracking-tight">Custodia de Código</h4>
          </div>

          <p>
            En la infraestructura <strong className="text-[#a1a1aa]">PESO DIGITAL</strong>, la programabilidad es una propiedad intrínseca del dinero soberano. No se delega en blockchains paralelas vulnerables.
          </p>

          <div className="bg-[#09090b] p-3 border border-[#27272a] rounded space-y-1.5">
            <div className="text-[10px] font-bold text-white uppercase flex items-center space-x-1">
              <Settings className="w-3.5 h-3.5 text-[#10b981]" />
              <span>Gobernanza Institucional</span>
            </div>
            <p className="text-[9px]">
              Toda regla de liberación requiere registro y auditoría previa por CNBV para evitar secuestros de liquidez corporativa o fraude fiscal electrónico.
            </p>
          </div>

          <p className="text-[11px] text-white italic bg-[#121214] p-2.5 border border-[#27272a]">
            &ldquo;El dinero programable no es dinero incontrolable. Toda lógica condicional es transparente, auditable y reversible únicamente por mandato de Banco de México o juez fiscal.&rdquo;
          </p>
        </div>

        <div className="text-[10px] text-[#71717a] italic mt-6 pt-3 border-t border-[#27272a]">
          * Simulación regulada bajo directrices de Banxico v2.4.
        </div>
      </div>
    </div>
  );
}
