/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Clock, ShieldCheck, Zap, Activity } from "lucide-react";

interface NationalPaymentMapProps {
  currentClockSpeed: "1_MIN" | "1_HOUR" | "1_DAY" | "1_WEEK" | "1_MONTH";
  onSpeedChange: (speed: "1_MIN" | "1_HOUR" | "1_DAY" | "1_WEEK" | "1_MONTH") => void;
  systemStatus: string;
}

export default function NationalPaymentMap({
  currentClockSpeed,
  onSpeedChange,
  systemStatus
}: NationalPaymentMapProps) {
  // Define positions in a neat symmetrical grid layout for visual nodes
  const nodes = [
    { id: "banxico", label: "BANCO DE MÉXICO", x: 250, y: 50, type: "CENTRAL", details: "Emisor y Liquidador Neto" },
    { id: "spei", label: "INFRAESTRUCTURA SPEI", x: 120, y: 150, type: "INFRA", details: "Cámara de Compensación Nacional" },
    { id: "codi", label: "PLATAFORMA CoDi", x: 380, y: 150, type: "INFRA", details: "Riel de Cobro Móvil / QR" },
    { id: "banks", label: "BANCOS COMERCIALES", x: 100, y: 280, type: "INTERMEDIARY", details: "10 Instituciones Sintéticas" },
    { id: "fintech", label: "INSTITUCIONES FINTECH", x: 400, y: 280, type: "INTERMEDIARY", details: "Wallets Auxiliares / APIs" },
    { id: "gov", label: "GOBIERNO (TESOFE)", x: 250, y: 210, type: "GOV", details: "Tesoraría & Dispersor Fiscal" },
    { id: "households", label: "HOGARES / INDIVIDUOS", x: 160, y: 400, type: "AGENT", details: "Billeteras Minoristas Directas" },
    { id: "merchants", label: "COMERCIOS / PYMES", x: 340, y: 400, type: "AGENT", details: "Terminales de Cobro / SAT" }
  ];

  const edges = [
    { from: "banxico", to: "spei", label: "Reserva / Liquidación", color: "#3b82f6" },
    { from: "banxico", to: "codi", label: "Sincronía de Llaves", color: "#10b981" },
    { from: "spei", to: "banks", label: "SPEI Clearing", color: "#3b82f6" },
    { from: "codi", to: "merchants", label: "Pagos QR / NFC", color: "#10b981" },
    { from: "banks", to: "gov", label: "Abono / Retiro SAT", color: "#f59e0b" },
    { from: "gov", to: "banxico", label: "Depósito Único", color: "#f59e0b" },
    { from: "banks", to: "households", label: "Retiros / Cuentas", color: "#3b82f6" },
    { from: "fintech", to: "households", label: "Peso Digital P2P", color: "#10b981" },
    { from: "households", to: "merchants", label: "MXN-Digital / CoDi", color: "#10b981" },
    { from: "banxico", to: "gov", label: "Emisión de Programas", color: "#ef4444" }
  ];

  return (
    <div className="bg-[#18181b] border border-[#27272a] p-6 flex flex-col justify-between h-full" id="national-network-map">
      <div>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-semibold text-[#a1a1aa] tracking-wider mb-1">
              RED TOPOLÓGICA DE PAGOS NACIONALES
            </h3>
            <p className="text-xs text-[#71717a]">
              Modelo estructural de las conexiones del Peso Digital con cámaras tradicionales.
            </p>
          </div>
          {/* Clock controls */}
          <div className="mt-3 sm:mt-0 flex items-center bg-[#09090b] p-1 border border-[#27272a] rounded">
            <Clock className="w-3.5 h-3.5 text-[#a1a1aa] mx-2" />
            <select
              value={currentClockSpeed}
              onChange={(e) => onSpeedChange(e.target.value as any)}
              className="bg-transparent text-xs text-[#a1a1aa] font-semibold border-none focus:ring-0 outline-none pr-6 py-0.5"
            >
              <option value="1_MIN">1 minuto / paso</option>
              <option value="1_HOUR">1 hora / paso</option>
              <option value="1_DAY">1 día / paso</option>
              <option value="1_WEEK">1 semana / paso</option>
              <option value="1_MONTH">1 mes / paso</option>
            </select>
          </div>
        </div>
      </div>

      {/* Network Map Diagram SVG */}
      <div className="relative bg-[#09090b] border border-[#27272a] p-4 flex items-center justify-center overflow-hidden aspect-[4/3] w-full">
        <svg
          viewBox="0 0 500 480"
          className="w-full h-full max-w-[500px]"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Defs for markers and pulsing */}
          <defs>
            <marker
              id="arrow"
              viewBox="0 0 10 10"
              refX="18"
              refY="5"
              markerWidth="6"
              markerHeight="6"
              orient="auto-start-reverse"
            >
              <path d="M 0 0 L 10 5 L 0 10 z" fill="#3f3f46" />
            </marker>
          </defs>

          {/* Draw Connection Edges */}
          {edges.map((edge, index) => {
            const fromNode = nodes.find((n) => n.id === edge.from);
            const toNode = nodes.find((n) => n.id === edge.to);
            if (!fromNode || !toNode) return null;

            return (
              <g key={`edge-${index}`}>
                {/* Background edge line */}
                <line
                  x1={fromNode.x}
                  y1={fromNode.y}
                  x2={toNode.x}
                  y2={toNode.y}
                  stroke="#27272a"
                  strokeWidth="2"
                  markerEnd="url(#arrow)"
                />
                {/* Pulse line to indicate active simulation traffic */}
                <line
                  x1={fromNode.x}
                  y1={fromNode.y}
                  x2={toNode.x}
                  y2={toNode.y}
                  stroke={edge.color}
                  strokeWidth="1.5"
                  strokeOpacity="0.4"
                  strokeDasharray="5, 15"
                  className="animate-[dash_15s_linear_infinite]"
                />
              </g>
            );
          })}

          {/* Draw Network Nodes */}
          {nodes.map((node) => {
            const isCentral = node.type === "CENTRAL";
            const isInfra = node.type === "INFRA";
            const isAgent = node.type === "AGENT";

            let bgClass = "fill-[#18181b] stroke-[#3f3f46]";
            let textClass = "fill-[#a1a1aa]";

            if (isCentral) {
              bgClass = "fill-[#18181b] stroke-[#10b981] stroke-2";
              textClass = "fill-[#10b981] font-bold";
            } else if (isInfra) {
              bgClass = "fill-[#18181b] stroke-[#3b82f6]";
              textClass = "fill-white";
            } else if (isAgent) {
              bgClass = "fill-[#09090b] stroke-[#71717a]";
              textClass = "fill-[#e4e4e7]";
            }

            return (
              <g key={node.id} className="cursor-pointer group">
                <circle
                  cx={node.x}
                  cy={node.y}
                  r="12"
                  className={`${bgClass} transition-all duration-300 group-hover:scale-125`}
                />
                <circle
                  cx={node.x}
                  cy={node.y}
                  r="18"
                  fill="none"
                  stroke={isCentral ? "#10b981" : "#27272a"}
                  strokeOpacity="0.2"
                  className="animate-ping"
                  style={{ animationDuration: "3s" }}
                />
                {/* Node Label Text */}
                <text
                  x={node.x}
                  y={node.y + 24}
                  textAnchor="middle"
                  className={`text-[9px] font-sans font-semibold ${textClass}`}
                >
                  {node.label}
                </text>
                {/* Subtitle/Details */}
                <text
                  x={node.x}
                  y={node.y + 34}
                  textAnchor="middle"
                  className="fill-[#52525b] text-[7px] font-sans"
                >
                  {node.details}
                </text>
              </g>
            );
          })}
        </svg>

        {/* Floating status */}
        <div className="absolute top-3 right-3 bg-[#18181b] border border-[#27272a] px-2.5 py-1 flex items-center space-x-1.5">
          <Activity className="w-3 h-3 text-[#10b981] animate-pulse" />
          <span className="text-[9px] text-[#a1a1aa] uppercase font-bold tracking-wider">
            SISTEMA: {systemStatus}
          </span>
        </div>
      </div>

      {/* Network Ledger Integrity */}
      <div className="grid grid-cols-2 gap-4 mt-4 pt-4 border-t border-[#27272a]">
        <div className="flex items-start space-x-2">
          <ShieldCheck className="w-4 h-4 text-[#10b981] shrink-0 mt-0.5" />
          <div>
            <div className="text-[10px] font-bold text-[#e4e4e7] uppercase">INTEGRIDAD CRYPTO-LEDGER</div>
            <p className="text-[9px] text-[#71717a]">Validación por firma digital asíncrona de curvas elípticas.</p>
          </div>
        </div>
        <div className="flex items-start space-x-2">
          <Zap className="w-4 h-4 text-[#3b82f6] shrink-0 mt-0.5" />
          <div>
            <div className="text-[10px] font-bold text-[#e4e4e7] uppercase">VELOCIDAD LIQUIDACIÓN</div>
            <p className="text-[9px] text-[#71717a]">Liquidación bruta inmediata con finalidad irrevocable.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
