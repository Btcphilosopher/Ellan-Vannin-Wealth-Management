/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Wallet, Transaction } from "../types";
import {
  DollarSign,
  TrendingUp,
  Shield,
  EyeOff,
  UserCheck,
  Send,
  PlusCircle,
  HelpCircle,
  Smartphone
} from "lucide-react";

interface DigitalPesoWalletProps {
  wallet: Wallet;
  allWallets: Wallet[];
  ledger: Transaction[];
  onMakePayment: (fromId: string, toId: string, amount: number) => void;
  onConvertDeposit: (amount: number, walletId: string, toDigital: boolean) => void;
  onUpdatePrivacy: (walletId: string, setting: any) => void;
}

export default function DigitalPesoWallet({
  wallet,
  allWallets,
  ledger,
  onMakePayment,
  onConvertDeposit,
  onUpdatePrivacy
}: DigitalPesoWalletProps) {
  const [recipientId, setRecipientId] = useState("");
  const [transferAmount, setTransferAmount] = useState("");
  const [conversionAmount, setConversionAmount] = useState("");
  const [conversionType, setConversionType] = useState<"TO_DIGITAL" | "TO_BANK">("TO_DIGITAL");

  // Filter recent transaction history belonging to this wallet Sofia
  const walletTransactions = ledger.filter(
    (tx) => tx.payer === wallet.ownerName || tx.payee === wallet.ownerName
  );

  const handleTransferSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(transferAmount);
    if (isNaN(amt) || amt <= 0 || !recipientId) return;
    onMakePayment(wallet.id, recipientId, amt);
    setTransferAmount("");
  };

  const handleConversionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(conversionAmount);
    if (isNaN(amt) || amt <= 0) return;
    onConvertDeposit(amt, wallet.id, conversionType === "TO_DIGITAL");
    setConversionAmount("");
  };

  const selectedPrivacy = wallet.privacySetting;

  return (
    <div className="grid grid-cols-1 md:grid-cols-12 gap-6" id="retail-wallet-lab">
      {/* Phone Mockup Screen: National Payments Wallet */}
      <div className="md:col-span-7 bg-[#18181b] border border-[#27272a] p-6 flex flex-col justify-between">
        <div>
          <h3 className="text-sm font-semibold text-[#a1a1aa] tracking-wider mb-1">
            BILLETERA DIGITAL PESO (SÓLO MINORISTA)
          </h3>
          <p className="text-xs text-[#71717a] mb-6">
            Prototipo de billetera móvil interoperable para cobros y pagos inmediatos. Las tenencias representan pasivos soberanos directos.
          </p>
        </div>

        {/* Visual Phone Card */}
        <div className="bg-[#09090b] border border-[#27272a] rounded-xl p-5 shadow-2xl relative overflow-hidden">
          {/* Header */}
          <div className="flex items-center justify-between border-b border-[#27272a] pb-4 mb-5">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 rounded-full bg-[#10b981]/10 flex items-center justify-center">
                <Smartphone className="w-4 h-4 text-[#10b981]" />
              </div>
              <div>
                <div className="text-xs font-bold text-white tracking-tight">PESO DIGITAL APPS</div>
                <div className="text-[9px] text-[#71717a]">Sistema de Pagos Electrónicos</div>
              </div>
            </div>
            {/* Identity badge */}
            <div className="flex items-center space-x-1 bg-[#10b981]/10 border border-[#10b981]/20 px-2 py-0.5 rounded-full">
              <UserCheck className="w-2.5 h-2.5 text-[#10b981]" />
              <span className="text-[8px] font-bold text-[#10b981] uppercase">VERIFICADO</span>
            </div>
          </div>

          {/* Account Balances Grid */}
          <div className="grid grid-cols-3 gap-4 mb-6">
            <div className="bg-[#18181b] p-3 border border-[#27272a] rounded-lg">
              <div className="text-[9px] text-[#71717a] font-bold uppercase tracking-wider">SALDO MDBC</div>
              <div className="text-lg font-black text-white">
                ${wallet.balance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </div>
              <span className="text-[8px] text-[#10b981] font-semibold">MXN-Digital</span>
            </div>

            <div className="bg-[#18181b] p-3 border border-[#27272a] rounded-lg">
              <div className="text-[9px] text-[#71717a] font-bold uppercase tracking-wider">AHORRO RENDIMIENTO</div>
              <div className="text-lg font-black text-white">
                ${wallet.savingsBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </div>
              <span className="text-[8px] text-[#71717a] font-semibold">Tasa: 10.5% (Banxico)</span>
            </div>

            <div className="bg-[#18181b] p-3 border border-[#27272a] rounded-lg">
              <div className="text-[9px] text-[#71717a] font-bold uppercase tracking-wider">SALDO OFFLINE</div>
              <div className="text-lg font-black text-white">
                ${wallet.offlineBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </div>
              <span className="text-[8px] text-yellow-400 font-semibold">Firma Local de Chip</span>
            </div>
          </div>

          {/* Limits Progress */}
          <div className="bg-[#18181b] p-3 border border-[#27272a] rounded-lg mb-6 space-y-2">
            <div className="flex justify-between items-center text-[10px]">
              <span className="text-[#a1a1aa] font-semibold">Límite Diario de Gasto Operativo</span>
              <span className="text-white font-bold">
                ${wallet.spentToday.toLocaleString()} / ${wallet.dailySpendingLimit.toLocaleString()} MXN
              </span>
            </div>
            <div className="w-full bg-[#27272a] h-1.5 rounded-full overflow-hidden">
              <div
                className="bg-[#10b981] h-full transition-all"
                style={{ width: `${Math.min((wallet.spentToday / wallet.dailySpendingLimit) * 100, 100)}%` }}
              />
            </div>
          </div>

          {/* Transfer Form inside the App mockup */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Quick send */}
            <form onSubmit={handleTransferSubmit} className="space-y-2 bg-[#121214] p-3 border border-[#27272a] rounded-lg">
              <div className="text-[10px] font-bold text-white uppercase flex items-center space-x-1.5">
                <Send className="w-3 h-3 text-[#10b981]" />
                <span>Enviar Fondos Soberanos</span>
              </div>
              <select
                value={recipientId}
                onChange={(e) => setRecipientId(e.target.value)}
                className="w-full bg-[#18181b] border border-[#27272a] rounded text-xs p-1.5 text-white"
              >
                <option value="">Selecciona destinatario...</option>
                {allWallets
                  .filter((w) => w.id !== wallet.id)
                  .map((w) => (
                    <option key={w.id} value={w.id}>
                      {w.ownerName}
                    </option>
                  ))}
              </select>
              <div className="flex space-x-2">
                <input
                  type="number"
                  value={transferAmount}
                  onChange={(e) => setTransferAmount(e.target.value)}
                  placeholder="Monto MXN"
                  className="w-full bg-[#18181b] border border-[#27272a] rounded text-xs p-1.5 text-white"
                />
                <button type="submit" className="bg-[#10b981] hover:bg-[#10b981]/80 text-[#09090b] font-bold text-xs px-3 rounded">
                  Enviar
                </button>
              </div>
            </form>

            {/* Account Conversion tool */}
            <form onSubmit={handleConversionSubmit} className="space-y-2 bg-[#121214] p-3 border border-[#27272a] rounded-lg">
              <div className="text-[10px] font-bold text-white uppercase flex items-center space-x-1.5">
                <PlusCircle className="w-3 h-3 text-[#3b82f6]" />
                <span>Fondeo / Canje Comercial</span>
              </div>
              <div className="flex border border-[#27272a] rounded overflow-hidden">
                <button
                  type="button"
                  onClick={() => setConversionType("TO_DIGITAL")}
                  className={`flex-1 text-[10px] py-1 font-bold ${conversionType === "TO_DIGITAL" ? "bg-[#3b82f6] text-white" : "bg-[#18181b] text-[#71717a]"}`}
                >
                  Banco → MDBC
                </button>
                <button
                  type="button"
                  onClick={() => setConversionType("TO_BANK")}
                  className={`flex-1 text-[10px] py-1 font-bold ${conversionType === "TO_BANK" ? "bg-[#3b82f6] text-white" : "bg-[#18181b] text-[#71717a]"}`}
                >
                  MDBC → Banco
                </button>
              </div>
              <div className="flex space-x-2">
                <input
                  type="number"
                  value={conversionAmount}
                  onChange={(e) => setConversionAmount(e.target.value)}
                  placeholder="Monto MXN"
                  className="w-full bg-[#18181b] border border-[#27272a] rounded text-xs p-1.5 text-white"
                />
                <button type="submit" className="bg-[#3b82f6] hover:bg-[#3b82f6]/80 text-white font-bold text-xs px-3 rounded">
                  Liquidar
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>

      {/* Right Column: Privacy, AML audit & Local Ledger logs */}
      <div className="md:col-span-5 flex flex-col space-y-6">
        {/* Compliance & Audit Model Panel */}
        <div className="bg-[#18181b] border border-[#27272a] p-6">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-xs font-semibold text-[#a1a1aa] tracking-wider uppercase">
              MODELOS DE PRIVACIDAD SOBERANA
            </h4>
            <Shield className="w-4 h-4 text-[#10b981]" />
          </div>

          <div className="space-y-4">
            <div className="flex border border-[#27272a] p-1 rounded bg-[#09090b] text-[10px]">
              {(["TIERED", "PSEUDONYMOUS", "FULL_TRACEABILITY"] as const).map((setting) => (
                <button
                  key={setting}
                  onClick={() => onUpdatePrivacy(wallet.id, setting)}
                  className={`flex-1 py-1 font-bold rounded ${selectedPrivacy === setting ? "bg-[#10b981]/10 text-[#10b981]" : "text-[#71717a]"}`}
                >
                  {setting === "TIERED" ? "Por Niveles" : setting === "PSEUDONYMOUS" ? "Seudónimo" : "Trazabilidad"}
                </button>
              ))}
            </div>

            {/* Visibility Dashboard representing audit visibility of different players */}
            <div className="bg-[#09090b] p-3 border border-[#27272a] rounded text-[10px] space-y-2">
              <div className="text-[#a1a1aa] font-bold">MATRIZ DE DIVULGACIÓN DE INFORMACIÓN:</div>
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-[#71717a]">Banco Intermediario</span>
                  <span className={`font-bold ${selectedPrivacy === "FULL_TRACEABILITY" ? "text-[#ef4444]" : selectedPrivacy === "TIERED" ? "text-yellow-400" : "text-[#10b981]"}`}>
                    {selectedPrivacy === "FULL_TRACEABILITY" ? "Totalmente Visible" : selectedPrivacy === "TIERED" ? "Limitado (<$3k)" : "Oculto"}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[#71717a]">Banco Central (Banxico)</span>
                  <span className={`font-bold ${selectedPrivacy === "FULL_TRACEABILITY" ? "text-[#ef4444]" : "text-[#10b981]"}`}>
                    {selectedPrivacy === "FULL_TRACEABILITY" ? "Totalmente Visible" : "Sólo Hash Ciego / Firmas"}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[#71717a]">Regulador SAT / CNBV</span>
                  <span className="font-bold text-yellow-400">Sólo bajo orden legal</span>
                </div>
              </div>
            </div>

            <p className="text-[10px] text-[#71717a] leading-relaxed">
              El modelo <strong className="text-[#a1a1aa]">Por Niveles (Tiered)</strong> permite pagos cotidianos sin identificación, pero requiere validación biométrica completa para montos superiores de acumulación interbancaria.
            </p>
          </div>
        </div>

        {/* Local device Transactions */}
        <div className="bg-[#18181b] border border-[#27272a] p-6 flex-1 flex flex-col justify-between">
          <div>
            <h4 className="text-xs font-semibold text-[#a1a1aa] tracking-wider uppercase mb-3">
              TRANSACCIONES RECIENTES DE LA BILLETERA
            </h4>
            <div className="space-y-2 max-h-[160px] overflow-y-auto pr-2">
              {walletTransactions.length > 0 ? (
                walletTransactions.map((tx) => {
                  const isDebit = tx.payer === wallet.ownerName;
                  return (
                    <div
                      key={tx.id}
                      className="bg-[#09090b] border border-[#27272a] p-2 flex items-center justify-between text-[11px]"
                    >
                      <div>
                        <div className="font-semibold text-white">
                          {isDebit ? `Para: ${tx.payee}` : `De: ${tx.payer}`}
                        </div>
                        <div className="text-[9px] text-[#71717a]">{tx.simTime} • {tx.type}</div>
                      </div>
                      <div className={`font-extrabold ${isDebit ? "text-[#ef4444]" : "text-[#10b981]"}`}>
                        {isDebit ? "-" : "+"}${tx.amount.toLocaleString()} MXN
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="text-center py-6 text-[#71717a] text-xs">
                  Sin transacciones recientes en esta sesión.
                </div>
              )}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-[#27272a] flex justify-between items-center text-[9px] text-[#71717a]">
            <span>Canal Seguro: SSL/TLS + HSM Encrypt</span>
            <div className="flex items-center space-x-1">
              <span className="w-1.5 h-1.5 rounded-full bg-[#10b981]" />
              <span className="text-[#10b981] font-semibold">LLAVECENTRAL Conectada</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
