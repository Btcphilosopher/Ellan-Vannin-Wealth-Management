/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from "react";
import { Terminal, CornerDownLeft } from "lucide-react";

interface CliConsoleProps {
  logs: string[];
  onExecuteCommand: (command: string) => string[];
}

export default function CliConsole({ logs, onExecuteCommand }: CliConsoleProps) {
  const [input, setInput] = useState("");
  const consoleEndRef = useRef<HTMLDivElement>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    onExecuteCommand(input);
    setInput("");
  };

  useEffect(() => {
    if (consoleEndRef.current) {
      consoleEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [logs]);

  return (
    <div className="bg-[#09090b] border border-[#27272a] font-mono text-xs flex flex-col h-[320px] rounded-md overflow-hidden">
      {/* Console Header Bar */}
      <div className="bg-[#18181b] px-4 py-2 border-b border-[#27272a] flex items-center justify-between text-[#71717a]">
        <div className="flex items-center space-x-2">
          <Terminal className="w-3.5 h-3.5 text-[#10b981]" />
          <span className="font-semibold text-[10px] tracking-wider text-white">
            CONSOLA DE INVESTIGACIÓN / INTERFAZ DE LÍNEA DE COMANDO
          </span>
        </div>
        <span className="text-[9px]">INTERACTIVO</span>
      </div>

      {/* Terminal Log Output */}
      <div className="flex-1 p-4 overflow-y-auto space-y-1.5 scrollbar-thin select-text selection:bg-[#10b981]/30">
        {logs.map((log, index) => {
          const isCommand = log.startsWith(">");
          return (
            <div
              key={index}
              className={`${
                isCommand ? "text-[#38bdf8]" : log.startsWith("Error:") ? "text-red-400" : log.startsWith("⚠") ? "text-yellow-400" : "text-[#a1a1aa]"
              } whitespace-pre-wrap leading-relaxed`}
            >
              {log}
            </div>
          );
        })}
        <div ref={consoleEndRef} />
      </div>

      {/* Terminal Input Box */}
      <form
        onSubmit={handleSubmit}
        className="bg-[#121214] border-t border-[#27272a] px-3 py-2 flex items-center"
      >
        <span className="text-[#10b981] mr-2 font-bold select-none">$</span>
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Escribe 'help' o 'peso-digital resilience'..."
          className="flex-1 bg-transparent text-[#e4e4e7] border-none outline-none focus:ring-0 font-mono p-0"
        />
        <button
          type="submit"
          className="ml-2 text-[#71717a] hover:text-white transition-colors"
          title="Ejecutar"
        >
          <CornerDownLeft className="w-3.5 h-3.5" />
        </button>
      </form>
    </div>
  );
}
