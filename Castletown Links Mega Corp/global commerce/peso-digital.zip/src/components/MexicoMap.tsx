/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { StateMetrics } from "../types";
import { MapPin, ArrowUpRight, ArrowDownLeft, Users, ShoppingBag, Activity } from "lucide-react";

interface MexicoMapProps {
  states: StateMetrics[];
}

export default function MexicoMap({ states }: MexicoMapProps) {
  const [selectedState, setSelectedState] = useState<StateMetrics | null>(states[0]);

  // Coordinates for rendering a beautiful schematic grid representation of Mexico
  const stateLayouts: { [key: string]: { x: number; y: number; label: string } } = {
    "Ciudad de México": { x: 50, y: 70, label: "CDMX" },
    "Estado de México": { x: 45, y: 65, label: "EDOMEX" },
    "Jalisco": { x: 30, y: 60, label: "JAL" },
    "Nuevo León": { x: 45, y: 35, label: "NL" },
    "Puebla": { x: 55, y: 68, label: "PUE" },
    "Veracruz": { x: 62, y: 62, label: "VER" },
    "Guanajuato": { x: 42, y: 58, label: "GTO" },
    "Baja California": { x: 10, y: 15, label: "BC" },
    "Chihuahua": { x: 28, y: 25, label: "CHIH" },
    "Sonora": { x: 20, y: 22, label: "SON" },
    "Oaxaca": { x: 58, y: 78, label: "OAX" },
    "Chiapas": { x: 68, y: 82, label: "CHIS" },
    "Yucatán": { x: 82, y: 55, label: "YUC" },
    "Quintana Roo": { x: 88, y: 62, label: "QROO" }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="mexico-map-container">
      {/* Interactive Map Visual */}
      <div className="lg:col-span-8 bg-[#18181b] border border-[#27272a] p-6 flex flex-col justify-between">
        <div>
          <h3 className="text-sm font-semibold text-[#a1a1aa] tracking-wider mb-1">
            MONITOR DE FLUJO TRANSACCIONAL REGIONAL
          </h3>
          <p className="text-xs text-[#71717a] mb-6">
            Vista geo-esquemática interactiva de la adopción de Peso Digital y flujo de liquidez nacional. Selecciona un estado para auditar.
          </p>
        </div>

        {/* Schematic SVG Map */}
        <div className="relative w-full aspect-[16/9] bg-[#09090b] border border-[#27272a] overflow-hidden">
          {/* Schematic connections / flows */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <linearGradient id="flowGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#10b981" stopOpacity="0.1" />
                <stop offset="50%" stopColor="#10b981" stopOpacity="0.6" />
                <stop offset="100%" stopColor="#10b981" stopOpacity="0.1" />
              </linearGradient>
            </defs>
            {/* Draw schematic lines connecting states to CDMX */}
            {states.map((st) => {
              const layout = stateLayouts[st.name];
              if (!layout || st.name === "Ciudad de México") return null;
              const cdmx = stateLayouts["Ciudad de México"];
              return (
                <g key={`flow-${st.name}`}>
                  <path
                    d={`M ${layout.x}% ${layout.y}% Q ${(layout.x + cdmx.x) / 2}% ${(layout.y + cdmx.y) / 2 - 5}% ${cdmx.x}% ${cdmx.y}%`}
                    fill="none"
                    stroke="url(#flowGrad)"
                    strokeWidth="1.5"
                    strokeDasharray="4,6"
                    className="animate-[dash_10s_linear_infinite]"
                  />
                </g>
              );
            })}
          </svg>

          {/* State node buttons overlay */}
          {states.map((st) => {
            const layout = stateLayouts[st.name];
            if (!layout) return null;

            const isSelected = selectedState?.name === st.name;
            const adoptionIntensity = Math.min(st.merchantAdoptionRate / 100, 1);

            return (
              <button
                key={st.name}
                onClick={() => setSelectedState(st)}
                style={{ left: `${layout.x}%`, top: `${layout.y}%` }}
                className={`absolute transform -translate-x-1/2 -translate-y-1/2 flex flex-col items-center group transition-all duration-300`}
                title={`${st.name}: ${st.walletsCount.toLocaleString()} cuentas`}
              >
                {/* Node Dot */}
                <div
                  className={`w-6 h-6 rounded-full flex items-center justify-center transition-all ${
                    isSelected
                      ? "bg-[#10b981] text-[#09090b] ring-4 ring-[#10b981]/20 scale-125"
                      : "bg-[#27272a] text-[#a1a1aa] border border-[#3f3f46] hover:bg-[#3f3f46] hover:text-white"
                  }`}
                >
                  <span className="text-[9px] font-bold">{layout.label}</span>
                </div>

                {/* State Label Hover tooltips */}
                <span
                  className={`mt-1 text-[9px] font-semibold px-1 rounded transition-all pointer-events-none whitespace-nowrap ${
                    isSelected
                      ? "bg-[#10b981]/10 text-[#10b981] border border-[#10b981]/30"
                      : "text-[#71717a] group-hover:text-[#a1a1aa] bg-black/60"
                  }`}
                >
                  {st.name}
                </span>
              </button>
            );
          })}

          {/* Map Compass / Info Overlay */}
          <div className="absolute bottom-4 left-4 bg-[#09090b]/80 backdrop-blur-sm p-3 border border-[#27272a] text-[10px] space-y-1">
            <div className="flex items-center space-x-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#10b981]" />
              <span className="text-[#a1a1aa]">Alta Densidad Transaccional</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#27272a]" />
              <span className="text-[#a1a1aa]">Baja Adopción / Uso Rural</span>
            </div>
            <p className="text-[9px] text-[#71717a] border-t border-[#27272a] pt-1 mt-1">
              Las líneas punteadas indican flujos de compensación hacia CDMX.
            </p>
          </div>
        </div>
      </div>

      {/* Selected State Financial Audit Panel */}
      <div className="lg:col-span-4 bg-[#18181b] border border-[#27272a] p-6 flex flex-col justify-between">
        {selectedState ? (
          <div className="space-y-6">
            <div>
              <div className="flex items-center space-x-2 text-[#10b981] mb-1">
                <MapPin className="w-4 h-4" />
                <span className="text-xs font-semibold uppercase tracking-widest">
                  ESTADO AUDITADO
                </span>
              </div>
              <h2 className="text-2xl font-bold text-white tracking-tight">
                {selectedState.name}
              </h2>
            </div>

            {/* Core Metrics List */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-[#09090b] p-3 border border-[#27272a]">
                <div className="flex items-center space-x-1.5 text-[#71717a] mb-1">
                  <Users className="w-3.5 h-3.5" />
                  <span className="text-[10px] font-semibold uppercase">Cuentas Activas</span>
                </div>
                <div className="text-lg font-bold text-white">
                  {selectedState.walletsCount.toLocaleString()}
                </div>
              </div>

              <div className="bg-[#09090b] p-3 border border-[#27272a]">
                <div className="flex items-center space-x-1.5 text-[#71717a] mb-1">
                  <ShoppingBag className="w-3.5 h-3.5" />
                  <span className="text-[10px] font-semibold uppercase">Adopción Com.</span>
                </div>
                <div className="text-lg font-bold text-white">
                  {selectedState.merchantAdoptionRate}%
                </div>
              </div>

              <div className="bg-[#09090b] p-3 border border-[#27272a]">
                <div className="flex items-center space-x-1.5 text-[#71717a] mb-1">
                  <Activity className="w-3.5 h-3.5" />
                  <span className="text-[10px] font-semibold uppercase">Frecuencia Pago</span>
                </div>
                <div className="text-lg font-bold text-white">
                  {selectedState.paymentDensity.toFixed(1)} <span className="text-[10px] text-[#71717a]">tx/min</span>
                </div>
              </div>

              <div className="bg-[#09090b] p-3 border border-[#27272a]">
                <div className="flex items-center space-x-1.5 text-[#71717a] mb-1">
                  <span className="text-[10px] font-semibold uppercase">Pagos Offline</span>
                </div>
                <div className="text-lg font-bold text-white">
                  {selectedState.offlineUsageCount.toLocaleString()}
                </div>
              </div>
            </div>

            {/* Regional Money Flows */}
            <div className="space-y-3 pt-4 border-t border-[#27272a]">
              <h4 className="text-xs font-semibold text-[#a1a1aa] tracking-wider uppercase">
                FLUJOS INTERREGIONALES (DIARIOS)
              </h4>
              <div className="space-y-2">
                <div className="flex items-center justify-between bg-[#09090b] px-3 py-2 border border-[#27272a]">
                  <div className="flex items-center space-x-2 text-[#10b981]">
                    <ArrowDownLeft className="w-4 h-4" />
                    <span className="text-xs text-white">Entradas (Abonos)</span>
                  </div>
                  <span className="text-xs font-bold text-[#10b981]">
                    +${(selectedState.regionalFlowIn / 1000).toFixed(1)}k MXN
                  </span>
                </div>

                <div className="flex items-center justify-between bg-[#09090b] px-3 py-2 border border-[#27272a]">
                  <div className="flex items-center space-x-2 text-[#ef4444]">
                    <ArrowUpRight className="w-4 h-4" />
                    <span className="text-xs text-white">Salidas (Cargos)</span>
                  </div>
                  <span className="text-xs font-bold text-[#ef4444]">
                    -${(selectedState.regionalFlowOut / 1000).toFixed(1)}k MXN
                  </span>
                </div>
              </div>
            </div>

            {/* Liquidity summary */}
            <div className="bg-[#09090b] p-3.5 border border-[#27272a] space-y-1">
              <span className="text-[10px] text-[#71717a] uppercase font-semibold">
                SALDO LÍQUIDO CIRCULANTE DE MDBC
              </span>
              <div className="text-xl font-bold text-[#10b981]">
                ${selectedState.liquidity.toLocaleString()} MXN
              </div>
              <p className="text-[9px] text-[#71717a]">
                Responsabilidad directa de Banco de México radicada en esta demarcación geográfica.
              </p>
            </div>
          </div>
        ) : (
          <div className="text-center text-[#71717a] text-xs py-12">
            Selecciona un estado en el mapa para auditar.
          </div>
        )}

        <div className="text-[10px] text-[#71717a] italic mt-4 pt-2 border-t border-[#27272a]">
          * Nota de Simulación: Toda la información mostrada es generada sintéticamente de manera probabilística.
        </div>
      </div>
    </div>
  );
}
