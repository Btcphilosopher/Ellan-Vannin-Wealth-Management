/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  Transaction,
  TransactionState,
  TransactionType,
  InstrumentType,
  Bank,
  StateMetrics,
  MonetaryAggregates,
  MacroVariables,
  TokenizedSecurity,
  RepoTransaction,
  Scenario,
  Wallet,
  Merchant,
  DemographicsSegment,
  OfflineDeviceState,
  SystemResiliency,
  EventLog
} from "./types";

// Fictional Mexican Banks
export const INITIAL_BANKS: Bank[] = [
  { id: "b-norte", name: "Banco Norte", reserves: 850000, digitalPesoWholesale: 50000, loans: 4200000, securitiesHoldings: 1200000, physicalCash: 350000, depositsRetail: 3800000, depositsCorporate: 2100000, centralBankLiquidityDebt: 0, capital: 750000, liquidityRatio: 18.5, capitalAdequacyRatio: 12.8 },
  { id: "b-centro", name: "Banco Centro", reserves: 620000, digitalPesoWholesale: 40000, loans: 3100000, securitiesHoldings: 950000, physicalCash: 240000, depositsRetail: 2900000, depositsCorporate: 1550000, centralBankLiquidityDebt: 0, capital: 500000, liquidityRatio: 17.2, capitalAdequacyRatio: 11.9 },
  { id: "b-pacifico", name: "Banco Pacífico", reserves: 510000, digitalPesoWholesale: 30000, loans: 2500000, securitiesHoldings: 780000, physicalCash: 190000, depositsRetail: 2300000, depositsCorporate: 1100000, centralBankLiquidityDebt: 0, capital: 410000, liquidityRatio: 16.9, capitalAdequacyRatio: 12.1 },
  { id: "b-capital", name: "Banco Capital", reserves: 480000, digitalPesoWholesale: 35000, loans: 2100000, securitiesHoldings: 850000, physicalCash: 180000, depositsRetail: 1950000, depositsCorporate: 1250000, centralBankLiquidityDebt: 0, capital: 440000, liquidityRatio: 19.1, capitalAdequacyRatio: 13.5 },
  { id: "b-industrial", name: "Banco Industrial", reserves: 920000, digitalPesoWholesale: 80000, loans: 5300000, securitiesHoldings: 1500000, physicalCash: 400000, depositsRetail: 3500000, depositsCorporate: 3800000, centralBankLiquidityDebt: 0, capital: 900000, liquidityRatio: 16.1, capitalAdequacyRatio: 11.5 },
  { id: "b-nacional", name: "Banco Nacional", reserves: 1200000, digitalPesoWholesale: 120000, loans: 6800000, securitiesHoldings: 2200000, physicalCash: 550000, depositsRetail: 6200000, depositsCorporate: 3200000, centralBankLiquidityDebt: 0, capital: 1470000, liquidityRatio: 19.8, capitalAdequacyRatio: 14.2 },
  { id: "b-bajio", name: "Banco del Bajío", reserves: 380000, digitalPesoWholesale: 25000, loans: 1800000, securitiesHoldings: 600000, physicalCash: 150000, depositsRetail: 1700000, depositsCorporate: 850000, centralBankLiquidityDebt: 0, capital: 400000, liquidityRatio: 18.2, capitalAdequacyRatio: 13.0 },
  { id: "b-golfo", name: "Banco del Golfo", reserves: 290000, digitalPesoWholesale: 15000, loans: 1400000, securitiesHoldings: 450000, physicalCash: 110000, depositsRetail: 1300000, depositsCorporate: 650000, centralBankLiquidityDebt: 0, capital: 310000, liquidityRatio: 17.5, capitalAdequacyRatio: 12.5 },
  { id: "b-frontera", name: "Banco Frontera", reserves: 340000, digitalPesoWholesale: 20000, loans: 1600000, securitiesHoldings: 520000, physicalCash: 130000, depositsRetail: 1500000, depositsCorporate: 750000, centralBankLiquidityDebt: 0, capital: 360000, liquidityRatio: 17.8, capitalAdequacyRatio: 12.7 },
  { id: "b-sur", name: "Banco del Sur", reserves: 250000, digitalPesoWholesale: 10000, loans: 1200000, securitiesHoldings: 380000, physicalCash: 90000, depositsRetail: 1100000, depositsCorporate: 550000, centralBankLiquidityDebt: 0, capital: 280000, liquidityRatio: 16.5, capitalAdequacyRatio: 11.8 }
];

// Fictional Mexican States
export const INITIAL_STATES: StateMetrics[] = [
  { name: "Ciudad de México", walletsCount: 32500, transactionVolume: 12500000, merchantAdoptionRate: 78, paymentDensity: 14.5, liquidity: 5400000, offlineUsageCount: 450, regionalFlowIn: 3200000, regionalFlowOut: 2800000 },
  { name: "Estado de México", walletsCount: 21000, transactionVolume: 7800000, merchantAdoptionRate: 54, paymentDensity: 8.2, liquidity: 3200000, offlineUsageCount: 820, regionalFlowIn: 1800000, regionalFlowOut: 2100000 },
  { name: "Jalisco", walletsCount: 12500, transactionVolume: 4900000, merchantAdoptionRate: 65, paymentDensity: 5.6, liquidity: 2100000, offlineUsageCount: 310, regionalFlowIn: 1200000, regionalFlowOut: 1100000 },
  { name: "Nuevo León", walletsCount: 11000, transactionVolume: 5800000, merchantAdoptionRate: 72, paymentDensity: 6.8, liquidity: 2900000, offlineUsageCount: 220, regionalFlowIn: 1500000, regionalFlowOut: 1400000 },
  { name: "Puebla", walletsCount: 6500, transactionVolume: 2100000, merchantAdoptionRate: 46, paymentDensity: 2.9, liquidity: 1100000, offlineUsageCount: 680, regionalFlowIn: 500000, regionalFlowOut: 550000 },
  { name: "Veracruz", walletsCount: 5200, transactionVolume: 1800000, merchantAdoptionRate: 38, paymentDensity: 2.1, liquidity: 850000, offlineUsageCount: 940, regionalFlowIn: 400000, regionalFlowOut: 480000 },
  { name: "Guanajuato", walletsCount: 4800, transactionVolume: 1650000, merchantAdoptionRate: 42, paymentDensity: 1.8, liquidity: 720000, offlineUsageCount: 510, regionalFlowIn: 350000, regionalFlowOut: 380000 },
  { name: "Baja California", walletsCount: 4200, transactionVolume: 1950000, merchantAdoptionRate: 59, paymentDensity: 2.4, liquidity: 980000, offlineUsageCount: 180, regionalFlowIn: 750000, regionalFlowOut: 650000 },
  { name: "Chihuahua", walletsCount: 3500, transactionVolume: 1400000, merchantAdoptionRate: 52, paymentDensity: 1.7, liquidity: 820000, offlineUsageCount: 240, regionalFlowIn: 450000, regionalFlowOut: 420000 },
  { name: "Sonora", walletsCount: 3100, transactionVolume: 1200000, merchantAdoptionRate: 48, paymentDensity: 1.5, liquidity: 710000, offlineUsageCount: 350, regionalFlowIn: 380000, regionalFlowOut: 350000 },
  { name: "Oaxaca", walletsCount: 2500, transactionVolume: 550000, merchantAdoptionRate: 25, paymentDensity: 0.6, liquidity: 350000, offlineUsageCount: 1120, regionalFlowIn: 180000, regionalFlowOut: 220000 },
  { name: "Chiapas", walletsCount: 2100, transactionVolume: 420000, merchantAdoptionRate: 21, paymentDensity: 0.4, liquidity: 280000, offlineUsageCount: 1450, regionalFlowIn: 150000, regionalFlowOut: 190000 },
  { name: "Yucatán", walletsCount: 3800, transactionVolume: 1100000, merchantAdoptionRate: 51, paymentDensity: 1.4, liquidity: 650000, offlineUsageCount: 290, regionalFlowIn: 280000, regionalFlowOut: 260000 },
  { name: "Quintana Roo", walletsCount: 4100, transactionVolume: 1600000, merchantAdoptionRate: 62, paymentDensity: 2.2, liquidity: 880000, offlineUsageCount: 150, regionalFlowIn: 680000, regionalFlowOut: 520000 }
];

export const SCENARIOS: Scenario[] = [
  {
    id: "scen-01",
    title: "Escenario 01",
    subtitle: "Adopción Normal de Pagos Digitales",
    description: "Crecimiento gradual y equilibrado de MXN-Digital, operando armoniosamente con SPEI y depósitos bancarios tradicionales sin afectar la estabilidad sistémica.",
    config: { adoptionRateMultiplier: 1.0, bankRunIntensity: 0.0, remittanceInflowIntensity: 1.0, fxShockIntensity: 0, inflationShockIntensity: 0, networkOutage: false, cyberIncident: false, offlineMode: false, wholesaleSettlementActive: false, governmentProgramActive: false, crossBorderActive: false }
  },
  {
    id: "scen-02",
    title: "Escenario 02",
    subtitle: "Adopción Acelerada de Peso Digital",
    description: "Surgimiento masivo de billeteras digitales. Migración rápida de efectivo a MXN-Digital, elevando la velocidad del dinero y reduciendo costos transaccionales.",
    config: { adoptionRateMultiplier: 2.5, bankRunIntensity: 0.0, remittanceInflowIntensity: 1.5, fxShockIntensity: 0, inflationShockIntensity: 0, networkOutage: false, cyberIncident: false, offlineMode: false, wholesaleSettlementActive: true, governmentProgramActive: true, crossBorderActive: false }
  },
  {
    id: "scen-03",
    title: "Escenario 03",
    subtitle: "Estrés de Liquidez Bancaria (Pánico)",
    description: "Fuga masiva de depósitos de bancos comerciales hacia el pasivo directo de Banco de México (MXN-Digital). Pone a prueba las facilidades de liquidez central.",
    config: { adoptionRateMultiplier: 3.0, bankRunIntensity: 0.8, remittanceInflowIntensity: 1.0, fxShockIntensity: 0, inflationShockIntensity: 0, networkOutage: false, cyberIncident: false, offlineMode: false, wholesaleSettlementActive: false, governmentProgramActive: false, crossBorderActive: false }
  },
  {
    id: "scen-04",
    title: "Escenario 04",
    subtitle: "Flujo Masivo de Remesas Digitales",
    description: "Simulación de una afluencia extraordinaria de remesas desde EE. UU. liquidadas de inmediato en MXN-Digital en Oaxaca, Chiapas y Guerrero.",
    config: { adoptionRateMultiplier: 1.5, bankRunIntensity: 0.0, remittanceInflowIntensity: 4.5, fxShockIntensity: 0, inflationShockIntensity: 0, networkOutage: false, cyberIncident: false, offlineMode: false, wholesaleSettlementActive: false, governmentProgramActive: false, crossBorderActive: true }
  },
  {
    id: "scen-05",
    title: "Escenario 05",
    subtitle: "Choque Cambiario Extremo (Shocks FX)",
    description: "Depreciación súbita del Peso Mexicano frente al USD por tensiones comerciales internacionales, detonando arbitrajes de divisas y reajuste de tasas del Banxico.",
    config: { adoptionRateMultiplier: 1.0, bankRunIntensity: 0.1, remittanceInflowIntensity: 2.0, fxShockIntensity: 25, inflationShockIntensity: 10, networkOutage: false, cyberIncident: false, offlineMode: false, wholesaleSettlementActive: false, governmentProgramActive: false, crossBorderActive: false }
  },
  {
    id: "scen-06",
    title: "Escenario 06",
    subtitle: "Choque Inflacionario Global",
    description: "Incremento masivo en precios de importación, combustibles y salarios. Propaga a través del modelo P = M * V / Y y presiona la Tasa de Referencia al alza.",
    config: { adoptionRateMultiplier: 1.0, bankRunIntensity: 0.0, remittanceInflowIntensity: 1.0, fxShockIntensity: 5, inflationShockIntensity: 40, networkOutage: false, cyberIncident: false, offlineMode: false, wholesaleSettlementActive: false, governmentProgramActive: false, crossBorderActive: false }
  },
  {
    id: "scen-07",
    title: "Escenario 07",
    subtitle: "Interrupción de Red Nacional de Telecom",
    description: "Caída masiva de Internet y telefonía móvil en el Centro del país. Pone a prueba la supervivencia de la economía mediante el Laboratorio de Pagos Offline.",
    config: { adoptionRateMultiplier: 0.2, bankRunIntensity: 0.0, remittanceInflowIntensity: 0.2, fxShockIntensity: 0, inflationShockIntensity: 0, networkOutage: true, cyberIncident: false, offlineMode: true, wholesaleSettlementActive: false, governmentProgramActive: false, crossBorderActive: false }
  },
  {
    id: "scen-08",
    title: "Escenario 08",
    subtitle: "Incidente de Ciberseguridad / DDoS",
    description: "Ataque coordinado de denegación de servicio contra el Nodo Central de Liquidación y una Billetera de Intermediario. Detona protocolos de recuperación.",
    config: { adoptionRateMultiplier: 0.5, bankRunIntensity: 0.3, remittanceInflowIntensity: 0.5, fxShockIntensity: 0, inflationShockIntensity: 0, networkOutage: false, cyberIncident: true, offlineMode: false, wholesaleSettlementActive: false, governmentProgramActive: false, crossBorderActive: false }
  },
  {
    id: "scen-09",
    title: "Escenario 09",
    subtitle: "Despliegue del Laboratorio Offline",
    description: "Foco exclusivo en el intercambio directo P2P offline entre dispositivos (hardware-secured). Se estudia la conciliación de saldos y riesgos de doble gasto.",
    config: { adoptionRateMultiplier: 1.0, bankRunIntensity: 0.0, remittanceInflowIntensity: 1.0, fxShockIntensity: 0, inflationShockIntensity: 0, networkOutage: false, cyberIncident: false, offlineMode: true, wholesaleSettlementActive: false, governmentProgramActive: false, crossBorderActive: false }
  },
  {
    id: "scen-10",
    title: "Escenario 10",
    subtitle: "Socio Mayorista y Liquidación de Valores",
    description: "Puesta en marcha del motor DVP (Entrega contra Pago) liquidando compras de CETES entre Banco Central e Intermediarios en tiempo real.",
    config: { adoptionRateMultiplier: 1.0, bankRunIntensity: 0.0, remittanceInflowIntensity: 1.0, fxShockIntensity: 0, inflationShockIntensity: 0, networkOutage: false, cyberIncident: false, offlineMode: false, wholesaleSettlementActive: true, governmentProgramActive: false, crossBorderActive: false }
  },
  {
    id: "scen-11",
    title: "Escenario 11",
    subtitle: "Programa Social Programable",
    description: "Dispersión masiva de subsidios desde la Tesorería de la Federación etiquetados exclusivamente para consumo de alimentos en comercios rurales afiliados.",
    config: { adoptionRateMultiplier: 1.5, bankRunIntensity: 0.0, remittanceInflowIntensity: 1.0, fxShockIntensity: 0, inflationShockIntensity: 0, networkOutage: false, cyberIncident: false, offlineMode: false, wholesaleSettlementActive: false, governmentProgramActive: true, crossBorderActive: false }
  },
  {
    id: "scen-12",
    title: "Escenario 12",
    subtitle: "Experimento Transfronterizo Multilateral",
    description: "Liquidación y compensación multilateral conectando el Peso Digital con sistemas CBDC experimentales de EE. UU., Canadá, Colombia y Brasil.",
    config: { adoptionRateMultiplier: 1.2, bankRunIntensity: 0.0, remittanceInflowIntensity: 2.0, fxShockIntensity: 0, inflationShockIntensity: 0, networkOutage: false, cyberIncident: false, offlineMode: false, wholesaleSettlementActive: false, governmentProgramActive: false, crossBorderActive: true }
  }
];

export const INITIAL_SECURITIES: TokenizedSecurity[] = [
  { id: "sec-cetes-28d", name: "CETES 28 Días (Gub)", issuer: "Gobierno de México", faceValue: 10, marketPrice: 9.91, yieldToMaturity: 10.45, outstandingVolume: 50000000, maturityDate: "2026-10-17", type: "GOBIERNO" },
  { id: "sec-bondes", name: "BONDES F 5Y (Gub)", issuer: "Gobierno de México", faceValue: 100, marketPrice: 99.85, yieldToMaturity: 10.65, outstandingVolume: 20000000, maturityDate: "2031-03-12", type: "GOBIERNO" },
  { id: "sec-pemex", name: "Pemex Corp Debt (Corp)", issuer: "Petróleos Mexicanos", faceValue: 100, marketPrice: 94.20, yieldToMaturity: 12.85, outstandingVolume: 10000000, maturityDate: "2033-08-15", type: "CORPORATIVO" },
  { id: "sec-america-movil", name: "AMX 10Y (Corp)", issuer: "América Móvil S.A.B.", faceValue: 100, marketPrice: 101.10, yieldToMaturity: 9.95, outstandingVolume: 5000000, maturityDate: "2036-05-24", type: "CORPORATIVO" }
];

export const INITIAL_DEMOGRAPHICS: DemographicsSegment[] = [
  { name: "Población Urbana Bancarizada", percentageOfPopulation: 35, bankAccessRate: 100, smartphoneRate: 96, digitalLiteracy: 85, cashDependence: 25, digitalAdoptionRate: 75 },
  { name: "Población Urbana Sub-bancarizada", percentageOfPopulation: 25, bankAccessRate: 40, smartphoneRate: 85, digitalLiteracy: 60, cashDependence: 65, digitalAdoptionRate: 40 },
  { name: "Población Rural o Informal", percentageOfPopulation: 20, bankAccessRate: 15, smartphoneRate: 60, digitalLiteracy: 40, cashDependence: 90, digitalAdoptionRate: 15 },
  { name: "Pequeños Comercios y Tianguis", percentageOfPopulation: 12, bankAccessRate: 45, smartphoneRate: 90, digitalLiteracy: 65, cashDependence: 80, digitalAdoptionRate: 35 },
  { name: "Grandes Corporativos", percentageOfPopulation: 8, bankAccessRate: 100, smartphoneRate: 100, digitalLiteracy: 98, cashDependence: 2, digitalAdoptionRate: 95 }
];

export interface SimulationState {
  // Config & Core Meta
  simClockSpeed: "1_MIN" | "1_HOUR" | "1_DAY" | "1_WEEK" | "1_MONTH";
  isPaused: boolean;
  activeScenarioId: string;
  simDateTime: Date;

  // Ledger & Balances
  ledger: Transaction[];
  banks: Bank[];
  stateMetrics: StateMetrics[];
  securities: TokenizedSecurity[];
  repos: RepoTransaction[];
  wallets: Wallet[];
  merchants: Merchant[];
  demographics: DemographicsSegment[];
  resiliency: SystemResiliency;
  eventLogs: EventLog[];
  
  // Specific Lab Entities
  offlineA: OfflineDeviceState;
  offlineB: OfflineDeviceState;
  
  // Macro / Monetary Policy
  monetaryAggregates: MonetaryAggregates;
  macro: MacroVariables;
  governmentFunds: {
    tesoreriaBalance: number;
    totalDisbursed: number;
    disbursedCount: number;
    disbursementHistory: { id: string; category: string; amount: number; date: string }[];
  };
  taxSim: {
    totalCollected: number;
    obligations: { id: string; payerName: string; type: string; amount: number; paid: boolean }[];
  };

  // UI state / Console log
  cliLogs: string[];
}

export class SimulationEngine {
  public state: SimulationState;
  private listeners: Set<() => void> = new Set();
  private intervalId: NodeJS.Timeout | null = null;
  private idCounter = 1000;

  constructor() {
    this.state = this.getInitialState();
    this.recalculateAggregates();
    this.startClock();
  }

  private getInitialState(): SimulationState {
    const defaultDate = new Date(2026, 8, 19, 9, 0, 0); // Sept 19, 2026

    // Fictional Customer Wallet (Interactable)
    const interactableWallet: Wallet = {
      id: "w-user",
      ownerName: "Sofía Rodríguez (Tú)",
      balance: 15420.00,
      savingsBalance: 50000.00,
      offlineBalance: 2500.00,
      dailySpendingLimit: 10000.00,
      spentToday: 0.00,
      privacySetting: "TIERED",
      identityStatus: "VERIFICADO_COMPLETO",
      isMuleAccount: false,
      bankAffiliationId: "b-norte"
    };

    // Other synthetic wallets
    const secondaryWallets: Wallet[] = [
      { id: "w-hector", ownerName: "Héctor Gómez", balance: 4500, savingsBalance: 12000, offlineBalance: 0, dailySpendingLimit: 5000, spentToday: 0, privacySetting: "PSEUDONYMOUS", identityStatus: "PARCIAL", isMuleAccount: false, bankAffiliationId: "b-centro" },
      { id: "w-mariana", ownerName: "Mariana Silva", balance: 28900, savingsBalance: 150000, offlineBalance: 1000, dailySpendingLimit: 25000, spentToday: 0, privacySetting: "REGULATED_DISCLOSURE", identityStatus: "VERIFICADO_COMPLETO", isMuleAccount: false, bankAffiliationId: "b-nacional" },
      { id: "w-juan", ownerName: "Juan Pérez (Agrícola)", balance: 1200, savingsBalance: 0, offlineBalance: 1500, dailySpendingLimit: 3000, spentToday: 0, privacySetting: "OFFLINE_PRIVACY", identityStatus: "ANÓNIMO", isMuleAccount: false, bankAffiliationId: "b-pacifico" },
      { id: "w-mule-suspect", ownerName: "Cuenta Puente 99X", balance: 850000, savingsBalance: 0, offlineBalance: 0, dailySpendingLimit: 1000000, spentToday: 0, privacySetting: "PSEUDONYMOUS", identityStatus: "ANÓNIMO", isMuleAccount: true, bankAffiliationId: "b-capital" }
    ];

    // Interactable Merchant Terminal
    const interactableMerchant: Merchant = {
      id: "m-tienda-luna",
      name: "Abarrotes La Luna",
      walletId: "w-tienda-luna-wallet",
      todaySales: 3450.00,
      digitalPesoReceipts: 1850.00,
      speiReceipts: 1000.00,
      codiReceipts: 600.00,
      refundsCount: 0,
      settlementLatencySec: 1.2,
      liquidity: 45000.00,
      state: "CDMX"
    };

    const secondaryMerchants: Merchant[] = [
      { id: "m-farmacia-salud", name: "Farmacia Guadalajara Centro", walletId: "w-farmacia-wallet", todaySales: 12800, digitalPesoReceipts: 4500, speiReceipts: 4300, codiReceipts: 4000, refundsCount: 1, settlementLatencySec: 1.8, liquidity: 180000, state: "Jalisco" },
      { id: "m-tacos-el-guero", name: "Taquería El Güero (Informal)", walletId: "w-tacos-wallet", todaySales: 2100, digitalPesoReceipts: 1500, speiReceipts: 0, codiReceipts: 600, refundsCount: 0, settlementLatencySec: 0.8, liquidity: 12000, state: "Estado de México" },
      { id: "m-maquiladora-mx", name: "Consorcio Maquilador Norte", walletId: "w-maq-wallet", todaySales: 450000, digitalPesoReceipts: 300000, speiReceipts: 150000, codiReceipts: 0, refundsCount: 0, settlementLatencySec: 2.5, liquidity: 4800000, state: "Nuevo León" }
    ];

    const initialLedger: Transaction[] = [
      {
        id: "tx-init-001",
        timestamp: defaultDate.toISOString(),
        simTime: "09:00:15 AM",
        payer: "Banco de México",
        payee: "Banco Norte",
        institution: "Banxico",
        amount: 50000,
        currency: "MXN",
        instrument: InstrumentType.WHOLESALE_PESO,
        type: TransactionType.ISSUANCE,
        state: TransactionState.FINAL,
        complianceStatus: "APROBADO",
        finalityStatus: "IRREVOCABLE",
        ledgerEntries: [
          { accountId: "BM-RESERVES-LIABILITY", accountType: "DEBIT", entityName: "Banxico", amount: 50000 },
          { accountId: "BNORTE-RESERVES-ACCOUNT", accountType: "CREDIT", entityName: "Banco Norte", amount: 50000 }
        ],
        details: "Emisión de cupo digital mayorista inicial para liquidaciones interbancarias."
      },
      {
        id: "tx-init-002",
        timestamp: defaultDate.toISOString(),
        simTime: "09:01:22 AM",
        payer: "Tesorería de la Federación",
        payee: "Mariana Silva",
        institution: "Banco Central",
        amount: 8500,
        currency: "MXN",
        instrument: InstrumentType.DIGITAL_PESO,
        type: TransactionType.GOVERNMENT_DISBURSE,
        state: TransactionState.FINAL,
        complianceStatus: "APROBADO",
        finalityStatus: "IRREVOCABLE",
        ledgerEntries: [
          { accountId: "TESORERIA-DEP", accountType: "DEBIT", entityName: "TESOFE", amount: 8500 },
          { accountId: "MARIANA-WALLET", accountType: "CREDIT", entityName: "Mariana Silva", amount: 8500 }
        ],
        details: "Dispersión mensual del programa social de apoyo universal."
      }
    ];

    return {
      simClockSpeed: "1_MIN",
      isPaused: false,
      activeScenarioId: "scen-01",
      simDateTime: defaultDate,
      ledger: initialLedger,
      banks: JSON.parse(JSON.stringify(INITIAL_BANKS)),
      stateMetrics: JSON.parse(JSON.stringify(INITIAL_STATES)),
      securities: JSON.parse(JSON.stringify(INITIAL_SECURITIES)),
      repos: [],
      wallets: [interactableWallet, ...secondaryWallets],
      merchants: [interactableMerchant, ...secondaryMerchants],
      demographics: JSON.parse(JSON.stringify(INITIAL_DEMOGRAPHICS)),
      resiliency: {
        internetAvailable: true,
        mobileNetworkAvailable: true,
        individualBanksAvailable: true,
        speiAvailable: true,
        codiAvailable: true,
        centralLedgerAvailable: true,
        powerGridAvailable: true,
        cloudInfrastructureAvailable: true,
        regionalInfrastructureAvailable: true
      },
      eventLogs: [
        { id: "e-01", type: "WalletCreated", message: "Sistema inicializado. Creadas 100,000 cuentas sintéticas en Banco del Norte y Banco del Sur.", timestamp: defaultDate.toLocaleTimeString(), severity: "INFO" },
        { id: "e-02", type: "DigitalPesoIssued", message: "Banco de México habilita ventanilla de emisión digital de prueba MXN-Digital.", timestamp: defaultDate.toLocaleTimeString(), severity: "INFO" }
      ],
      offlineA: {
        id: "dispositivo-a",
        ownerName: "Dispositivo A (Payer)",
        offlineBalance: 2000,
        pendingTransactions: [],
        hardwareLimit: 5000
      },
      offlineB: {
        id: "dispositivo-b",
        ownerName: "Dispositivo B (Payee)",
        offlineBalance: 500,
        pendingTransactions: [],
        hardwareLimit: 5000
      },
      monetaryAggregates: {
        banknotesAndCoins: 125000000, // represent $125B
        reserves: 54000000, // represent $54B
        digitalPesoSupply: 25000000, // represent $25B
        baseMoney: 0,
        bankDepositsRetail: 310000000,
        bankDepositsCorporate: 180000000,
        savingsDeposits: 140000000,
        tokenizedDeposits: 15000000,
        commercialMoney: 0,
        broadMoneyM1: 0,
        broadMoneyM2: 0,
        velocity: 1.85,
        nominalGDP: 28500000000
      },
      macro: {
        policyRate: 10.50, // Banxico rate 10.5%
        inflationRate: 4.25, // 4.25%
        unemploymentRate: 2.7, // 2.7%
        gdpGrowthRate: 2.3, // 2.3%
        exchangeRateUSD: 19.45,
        exchangeRateEUR: 21.65,
        exchangeRateCAD: 14.30,
        exchangeRateJPY: 0.13,
        exchangeRateCNY: 2.75,
        exchangeRateGBP: 25.40,
        wagesGrowth: 5.2,
        energyPrices: 100, // Base index 100
        importPrices: 100, // Base index 100
        productivityGrowth: 1.5,
        creditGrowth: 8.5
      },
      governmentFunds: {
        tesoreriaBalance: 12500000, // 12.5M
        totalDisbursed: 5200000,
        disbursedCount: 620,
        disbursementHistory: [
          { id: "gdis-01", category: "Pensiones", amount: 2500000, date: "2026-09-10" },
          { id: "gdis-02", category: "Dispersión Bienestar", amount: 1800000, date: "2026-09-12" },
          { id: "gdis-03", category: "Infraestructura", amount: 900000, date: "2026-09-15" }
        ]
      },
      taxSim: {
        totalCollected: 840000,
        obligations: [
          { id: "tax-obl-1", payerName: "Consorcio Maquilador Norte", type: "Impuesto Corporativo (ISR)", amount: 150000, paid: false },
          { id: "tax-obl-2", payerName: "Abarrotes La Luna", type: "IVA Mensual", amount: 4800, paid: false },
          { id: "tax-obl-3", payerName: "Sofía Rodríguez", type: "ISR Salarios", amount: 2500, paid: true }
        ]
      },
      cliLogs: [
        "Peso Digital CLI v1.0.0-PROTOTIPO",
        "Escribe 'help' para ver los comandos disponibles.",
        "peso-digital init --demo-data"
      ]
    };
  }

  // Listener pattern
  public subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify() {
    this.listeners.forEach((listener) => listener());
  }

  // Double-entry aggregate recalculation
  public recalculateAggregates() {
    const totalDepositsRetail = this.state.banks.reduce((sum, b) => sum + b.depositsRetail, 0);
    const totalDepositsCorporate = this.state.banks.reduce((sum, b) => sum + b.depositsCorporate, 0);
    const totalReserves = this.state.banks.reduce((sum, b) => sum + b.reserves, 0);
    const totalWholesale = this.state.banks.reduce((sum, b) => sum + b.digitalPesoWholesale, 0);
    
    // Accumulate wallet balances
    const totalRetailDigitalPeso = this.state.wallets.reduce((sum, w) => sum + w.balance + w.offlineBalance, 0);

    const baseMoney = this.state.monetaryAggregates.banknotesAndCoins + totalReserves + totalWholesale + totalRetailDigitalPeso;
    const commercialMoney = totalDepositsRetail + totalDepositsCorporate + this.state.monetaryAggregates.savingsDeposits + this.state.monetaryAggregates.tokenizedDeposits;

    const broadMoneyM1 = this.state.monetaryAggregates.banknotesAndCoins + totalRetailDigitalPeso + totalDepositsRetail;
    const broadMoneyM2 = broadMoneyM1 + this.state.monetaryAggregates.savingsDeposits + this.state.monetaryAggregates.tokenizedDeposits;

    this.state.monetaryAggregates = {
      ...this.state.monetaryAggregates,
      reserves: totalReserves,
      digitalPesoSupply: totalWholesale + totalRetailDigitalPeso,
      baseMoney,
      bankDepositsRetail: totalDepositsRetail,
      bankDepositsCorporate: totalDepositsCorporate,
      commercialMoney,
      broadMoneyM1,
      broadMoneyM2,
      nominalGDP: this.state.monetaryAggregates.nominalGDP
    };
  }

  // Clock mechanism
  private startClock() {
    if (this.intervalId) return;

    this.intervalId = setInterval(() => {
      if (this.state.isPaused) return;

      // Tick the clock based on speed
      const minutesToAdd = this.state.simClockSpeed === "1_MIN" ? 1 :
                           this.state.simClockSpeed === "1_HOUR" ? 60 :
                           this.state.simClockSpeed === "1_DAY" ? 1440 :
                           this.state.simClockSpeed === "1_WEEK" ? 10080 : 43200;

      this.state.simDateTime = new Date(this.state.simDateTime.getTime() + minutesToAdd * 60 * 1000);

      // Generate random background transactions to simulate the Mexican Economy!
      this.generateEconomicActivity();
      
      // Keep model dynamics running (macro inflation, policy propagation, bank run drain)
      this.runMacroDynamics();

      this.recalculateAggregates();
      this.notify();
    }, 3000); // Ticks every 3 seconds
  }

  public stopClock() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
  }

  public togglePlayPause() {
    this.state.isPaused = !this.state.isPaused;
    this.logEvent(
      "INFO",
      this.state.isPaused ? "Simulación pausada por el operador." : "Simulación reanudada."
    );
    this.notify();
  }

  public setClockSpeed(speed: "1_MIN" | "1_HOUR" | "1_DAY" | "1_WEEK" | "1_MONTH") {
    this.state.simClockSpeed = speed;
    this.logEvent("INFO", `Velocidad de simulación configurada a: 1 paso = ${speed === "1_MIN" ? "1 Minuto" : speed === "1_HOUR" ? "1 Hora" : speed === "1_DAY" ? "1 Día" : speed === "1_WEEK" ? "1 Semana" : "1 Mes"}`);
    this.notify();
  }

  // Log to the event-driven system
  public logEvent(severity: "INFO" | "WARNING" | "CRITICAL", message: string, type: any = "PaymentSettled") {
    const newLog: EventLog = {
      id: "e-" + (++this.idCounter),
      type,
      message,
      timestamp: this.state.simDateTime.toLocaleTimeString(),
      severity
    };
    this.state.eventLogs.unshift(newLog);
    if (this.state.eventLogs.length > 100) {
      this.state.eventLogs.pop();
    }
  }

  // Execute scenario preset
  public applyScenario(scenarioId: string) {
    const scen = SCENARIOS.find(s => s.id === scenarioId);
    if (!scen) return;

    this.state.activeScenarioId = scenarioId;
    this.logEvent("INFO", `Aplicando Escenario: ${scen.title} - ${scen.subtitle}`, "WalletCreated");

    // Clear and reset banks to initial state, then apply scenario specific shocks
    this.state.banks = JSON.parse(JSON.stringify(INITIAL_BANKS));
    this.state.resiliency = {
      internetAvailable: !scen.config.networkOutage,
      mobileNetworkAvailable: !scen.config.networkOutage,
      individualBanksAvailable: true,
      speiAvailable: !scen.config.networkOutage,
      codiAvailable: !scen.config.networkOutage,
      centralLedgerAvailable: !scen.config.cyberIncident,
      powerGridAvailable: !scen.config.networkOutage,
      cloudInfrastructureAvailable: !scen.config.cyberIncident,
      regionalInfrastructureAvailable: true
    };

    if (scenarioId === "scen-03") {
      // Bank Liquidity panic - deplete reserves of vulnerable banks
      this.state.banks.forEach(b => {
        b.depositsRetail *= 0.6; // 40% run on retail deposits
        b.reserves *= 0.3; // reserves plunge
        b.digitalPesoWholesale *= 0.2;
      });
      this.logEvent("WARNING", "PÁNICO BANCARIO: Depósitos minoristas migran aceleradamente a pasivos de Banco de México.", "BankLiquidityChanged");
    }

    if (scenarioId === "scen-05") {
      // Exchange rate shock
      this.state.macro.exchangeRateUSD = 24.30; // 25% deval
      this.state.macro.inflationRate = 8.5;
      this.state.macro.policyRate = 12.5; // Banxico raises rate to protect MXN
      this.logEvent("WARNING", "CHOQUE CAMBIARIO: Peso se deprecia 25%. Banxico eleva tasa a 12.5% para frenar inflación.", "FXRateChanged");
    }

    if (scenarioId === "scen-06") {
      // Inflation shock
      this.state.macro.inflationRate = 12.4;
      this.state.macro.policyRate = 14.0;
      this.state.macro.energyPrices = 150;
      this.logEvent("WARNING", "CHOQUE INFLACIONARIO: Alza de materias primas propaga el índice de precios al consumidor.", "FXRateChanged");
    }

    if (scenarioId === "scen-07") {
      // Outage
      this.logEvent("CRITICAL", "FALLO ELÉCTRICO Y DE COMUNICACIONES: Conexión interbancaria SPEI/CoDi deshabilitada. Habilitando Offline Lab.", "NetworkFailure");
    }

    this.recalculateAggregates();
    this.notify();
  }

  // Macro dynamics clock prop
  private runMacroDynamics() {
    const isBankRun = this.state.activeScenarioId === "scen-03";
    if (isBankRun) {
      // Gradually drain bank retail deposits into retail wallet
      this.state.banks.forEach(b => {
        if (b.depositsRetail > 100000) {
          const drain = Math.floor(Math.random() * 5000) + 1000;
          b.depositsRetail -= drain;
          b.reserves -= drain;
          // Compensate with central bank liquidity debt if reserves are too low
          if (b.reserves < b.depositsRetail * 0.05) {
            const support = Math.floor(b.depositsRetail * 0.1);
            b.reserves += support;
            b.centralBankLiquidityDebt += support;
            this.logEvent("WARNING", `Banxico activa ventanilla de liquidez de emergencia para ${b.name} por $${support.toLocaleString()} MXN.`, "BankLiquidityChanged");
          }
        }
      });
    }

    // Money equation velocity dynamics: M * V = P * Y
    // If M (digital peso + broad money) grows, inflation P may face pressure, or GDP Y grows.
    const m = this.state.monetaryAggregates.broadMoneyM2;
    const v = this.state.monetaryAggregates.velocity;
    const y = this.state.monetaryAggregates.nominalGDP;
    
    // Simple mock macro loop
    const gdpGrowthFactor = 1 + (this.state.macro.gdpGrowthRate / (100 * 365));
    this.state.monetaryAggregates.nominalGDP *= gdpGrowthFactor;
  }

  // Economic Activity Generator: adds transactions
  private generateEconomicActivity() {
    if (this.state.isPaused) return;

    // Do not generate if ledger outage
    if (!this.state.resiliency.centralLedgerAvailable) return;

    // Pick a random bank, random amount, random action
    const randomAction = Math.random();
    const dateStr = this.state.simDateTime.toISOString();
    const simTimeStr = this.state.simDateTime.toLocaleTimeString();

    if (randomAction < 0.25) {
      // CoDi Retail QR payment
      const pNames = ["Carlos Ortiz", "Beatriz Mendoza", "Daniela Vega", "Juan Escutia", "Lorena Garza"];
      const merchants = this.state.merchants;
      const payer = pNames[Math.floor(Math.random() * pNames.length)];
      const merchant = merchants[Math.floor(Math.random() * merchants.length)];
      const amount = Math.floor(Math.random() * 450) + 20;

      // AML Fraud Detection Rule (Suspicious structuring / circular loops)
      const isSuspicious = amount > 400 && Math.random() < 0.05;
      const complStatus = isSuspicious ? "SOSPECHOSO" : "APROBADO";
      const complReason = isSuspicious ? "Múltiples envíos por debajo de umbral de reporte (Estructuración)." : undefined;

      const tx: Transaction = {
        id: "tx-" + (++this.idCounter),
        timestamp: dateStr,
        simTime: simTimeStr,
        payer,
        payee: merchant.name,
        institution: "Red CoDi Co",
        amount,
        currency: "MXN",
        instrument: InstrumentType.DIGITAL_PESO,
        type: TransactionType.PAYMENT,
        state: TransactionState.FINAL,
        complianceStatus: complStatus,
        complianceReason: complReason,
        finalityStatus: "IRREVOCABLE",
        ledgerEntries: [
          { accountId: `WALLET-RETAIL-${payer.replace(" ", "")}`, accountType: "DEBIT", entityName: payer, amount },
          { accountId: `MERCHANT-${merchant.id}`, accountType: "CREDIT", entityName: merchant.name, amount }
        ],
        details: `Pago de consumo minorista instantáneo vía código QR CoDi.`
      };

      this.state.ledger.unshift(tx);
      merchant.todaySales += amount;
      merchant.codiReceipts += amount;
      merchant.liquidity += amount;

      // Update state metrics CDMX, Jalisco etc.
      const matchedState = this.state.stateMetrics.find(s => s.name === merchant.state);
      if (matchedState) {
        matchedState.transactionVolume += amount;
        matchedState.paymentDensity += 0.01;
      }

      if (isSuspicious) {
        this.logEvent("WARNING", `ALERTA AML: Detectado patrón de estructuración sospechosa entre ${payer} y ${merchant.name}.`, "PaymentInitiated");
      }
    } else if (randomAction < 0.50) {
      // SPEI Interbank Transfer
      const bankA = this.state.banks[Math.floor(Math.random() * this.state.banks.length)];
      let bankB = this.state.banks[Math.floor(Math.random() * this.state.banks.length)];
      while (bankB.id === bankA.id) {
        bankB = this.state.banks[Math.floor(Math.random() * this.state.banks.length)];
      }

      const amount = Math.floor(Math.random() * 50000) + 5000;

      if (this.state.resiliency.speiAvailable && bankA.reserves >= amount) {
        // Double entry accounting changes on banks
        bankA.reserves -= amount;
        bankA.depositsRetail -= amount;
        bankB.reserves += amount;
        bankB.depositsRetail += amount;

        const tx: Transaction = {
          id: "tx-" + (++this.idCounter),
          timestamp: dateStr,
          simTime: simTimeStr,
          payer: bankA.name,
          payee: bankB.name,
          institution: "SPEI Banxico",
          amount,
          currency: "MXN",
          instrument: InstrumentType.BANK_DEPOSIT,
          type: TransactionType.BANK_SETTLE,
          state: TransactionState.FINAL,
          complianceStatus: "APROBADO",
          finalityStatus: "IRREVOCABLE",
          ledgerEntries: [
            { accountId: `RESERVES-${bankA.id}`, accountType: "DEBIT", entityName: bankA.name, amount },
            { accountId: `RESERVES-${bankB.id}`, accountType: "CREDIT", entityName: bankB.name, amount }
          ],
          details: `Compensación multilateral neta y liquidación SPEI interbancaria.`
        };

        this.state.ledger.unshift(tx);
      }
    } else if (randomAction < 0.60) {
      // Remittance simulation from US (USD converted to MXN)
      const usdAmount = Math.floor(Math.random() * 400) + 50;
      const rate = this.state.macro.exchangeRateUSD;
      const mxnAmount = Math.round(usdAmount * rate);

      const receiver = this.state.wallets[Math.floor(Math.random() * this.state.wallets.length)];
      receiver.balance += mxnAmount;

      const tx: Transaction = {
        id: "tx-" + (++this.idCounter),
        timestamp: dateStr,
        simTime: simTimeStr,
        payer: "Envíos Rápidos US (Remitente)",
        payee: receiver.ownerName,
        institution: "Corredor Transfronterizo",
        amount: mxnAmount,
        currency: "MXN",
        instrument: InstrumentType.DIGITAL_PESO,
        type: TransactionType.TRANSFER,
        state: TransactionState.FINAL,
        complianceStatus: "APROBADO",
        finalityStatus: "IRREVOCABLE",
        ledgerEntries: [
          { accountId: "REMITTANCE-USA-USD", accountType: "DEBIT", entityName: "US Intermediary", amount: usdAmount },
          { accountId: `USER-WALLET-${receiver.id}`, accountType: "CREDIT", entityName: receiver.ownerName, amount: mxnAmount }
        ],
        details: `Remesa digital desde Chicago, IL liquidada al instante en pasivo de Banxico. Costo de transacción: $1.5 USD vs $12 USD tradicional.`
      };

      this.state.ledger.unshift(tx);
      
      // Log event
      this.logEvent("INFO", `Remesa recibida por ${receiver.ownerName} por $${mxnAmount.toLocaleString()} MXN ($${usdAmount} USD).`, "RemittanceReceived");
    }

    if (this.state.ledger.length > 50) {
      this.state.ledger.pop();
    }
  }

  // --- ACTIONS ---

  // Double entry issuance: Banco de México credits bank reserves, credits customer wallet
  public issueDigitalPesos(amount: number, bankId: string, walletId: string) {
    if (!this.state.resiliency.centralLedgerAvailable) {
      this.logEvent("CRITICAL", "Línea de emisión rechazada: Ledger Central no disponible.", "NetworkFailure");
      return;
    }

    const bank = this.state.banks.find(b => b.id === bankId);
    const wallet = this.state.wallets.find(w => w.id === walletId);

    if (!bank || !wallet) return;

    // Banco de México generates liabilities (reserves & digital pesos)
    bank.reserves += amount;
    wallet.balance += amount;

    const dateStr = this.state.simDateTime.toISOString();
    const simTimeStr = this.state.simDateTime.toLocaleTimeString();

    const tx: Transaction = {
      id: "tx-" + (++this.idCounter),
      timestamp: dateStr,
      simTime: simTimeStr,
      payer: "Banco de México (Emisor)",
      payee: wallet.ownerName,
      institution: bank.name,
      amount,
      currency: "MXN",
      instrument: InstrumentType.DIGITAL_PESO,
      type: TransactionType.ISSUANCE,
      state: TransactionState.FINAL,
      complianceStatus: "APROBADO",
      finalityStatus: "IRREVOCABLE",
      ledgerEntries: [
        { accountId: "BANXICO-LIABILITY-MDBC", accountType: "DEBIT", entityName: "Banco de México", amount },
        { accountId: `BANK-RESERVES-${bank.id}`, accountType: "CREDIT", entityName: bank.name, amount },
        { accountId: `CUSTOMER-WALLET-${wallet.id}`, accountType: "CREDIT", entityName: wallet.ownerName, amount }
      ],
      details: "Emisión formal de Pesos Digitales con respaldo 1:1 en depósitos de reserva en Banco de México."
    };

    this.state.ledger.unshift(tx);
    this.logEvent("INFO", `EMISIÓN COMPLETA: Creados $${amount.toLocaleString()} MXN-Digital abonados a ${wallet.ownerName}.`, "DigitalPesoIssued");
    this.recalculateAggregates();
    this.notify();
  }

  // Redemption: Digital pesos debited, physical or commercial deposits credited
  public redeemDigitalPesos(amount: number, bankId: string, walletId: string) {
    const bank = this.state.banks.find(b => b.id === bankId);
    const wallet = this.state.wallets.find(w => w.id === walletId);

    if (!bank || !wallet) return;

    if (wallet.balance < amount) {
      this.logEvent("WARNING", "Redención fallida: Fondos insuficientes en billetera digital.", "DigitalPesoRedeemed");
      return;
    }

    wallet.balance -= amount;
    bank.reserves -= amount;
    bank.depositsRetail += amount; // convert back to bank deposits

    const dateStr = this.state.simDateTime.toISOString();
    const simTimeStr = this.state.simDateTime.toLocaleTimeString();

    const tx: Transaction = {
      id: "tx-" + (++this.idCounter),
      timestamp: dateStr,
      simTime: simTimeStr,
      payer: wallet.ownerName,
      payee: `Depósitos de ${bank.name}`,
      institution: bank.name,
      amount,
      currency: "MXN",
      instrument: InstrumentType.BANK_DEPOSIT,
      type: TransactionType.REDEMPTION,
      state: TransactionState.FINAL,
      complianceStatus: "APROBADO",
      finalityStatus: "IRREVOCABLE",
      ledgerEntries: [
        { accountId: `CUSTOMER-WALLET-${wallet.id}`, accountType: "DEBIT", entityName: wallet.ownerName, amount },
        { accountId: `BANK-RESERVES-${bank.id}`, accountType: "DEBIT", entityName: bank.name, amount },
        { accountId: `BANK-DEPOSITS-${bank.id}`, accountType: "CREDIT", entityName: bank.name, amount }
      ],
      details: "Redención de Moneda Digital a Depósitos Bancarios Comerciales tradicionales."
    };

    this.state.ledger.unshift(tx);
    this.logEvent("INFO", `REDENCIÓN COMPLETADA: Retirados $${amount.toLocaleString()} MXN-Digital de circulación.`, "DigitalPesoRedeemed");
    this.recalculateAggregates();
    this.notify();
  }

  // P2P or Wallet-to-Wallet payments
  public makePayment(fromId: string, toId: string, amount: number, isCodi = false) {
    const fromWallet = this.state.wallets.find(w => w.id === fromId);
    const toWallet = this.state.wallets.find(w => w.id === toId);

    if (!fromWallet || !toWallet) return;

    if (fromWallet.balance < amount) {
      this.logEvent("WARNING", `Transferencia fallida de ${fromWallet.ownerName}: Fondos insuficientes.`, "PaymentInitiated");
      return;
    }

    // Limit check
    if (fromWallet.spentToday + amount > fromWallet.dailySpendingLimit) {
      this.logEvent("WARNING", `Límite diario superado para ${fromWallet.ownerName}.`, "PaymentInitiated");
      return;
    }

    fromWallet.balance -= amount;
    fromWallet.spentToday += amount;
    toWallet.balance += amount;

    const dateStr = this.state.simDateTime.toISOString();
    const simTimeStr = this.state.simDateTime.toLocaleTimeString();

    // Risk calculation
    const isMule = fromWallet.isMuleAccount || toWallet.isMuleAccount;
    const unusualVelocity = amount > 8000;
    const isSuspicious = isMule || unusualVelocity;
    const compliance = isSuspicious ? "SOSPECHOSO" : "APROBADO";
    const reason = isSuspicious ? (isMule ? "Involucra cuenta sospechosa de lavado (Mule)." : "Transferencia atípica de alta velocidad.") : undefined;

    const tx: Transaction = {
      id: "tx-" + (++this.idCounter),
      timestamp: dateStr,
      simTime: simTimeStr,
      payer: fromWallet.ownerName,
      payee: toWallet.ownerName,
      institution: isCodi ? "Canal CoDi" : "Red Peso Digital",
      amount,
      currency: "MXN",
      instrument: InstrumentType.DIGITAL_PESO,
      type: TransactionType.TRANSFER,
      state: TransactionState.FINAL,
      complianceStatus: compliance,
      complianceReason: reason,
      finalityStatus: "IRREVOCABLE",
      ledgerEntries: [
        { accountId: `WALLET-${fromWallet.id}`, accountType: "DEBIT", entityName: fromWallet.ownerName, amount },
        { accountId: `WALLET-${toWallet.id}`, accountType: "CREDIT", entityName: toWallet.ownerName, amount }
      ],
      details: isCodi ? "Transferencia instantánea CoDi sin costo de compensación." : "Transferencia directa de Peso Digital libre de riesgo de contraparte comercial."
    };

    this.state.ledger.unshift(tx);
    this.logEvent(isSuspicious ? "WARNING" : "INFO", `TRANSFERENCIA: $${amount.toLocaleString()} MXN de ${fromWallet.ownerName} a ${toWallet.ownerName} liquidado.`, "PaymentSettled");
    this.recalculateAggregates();
    this.notify();
  }

  // Convert Deposit <-> Digital Peso (Self bank account exchange)
  public convertDeposit(amount: number, walletId: string, toDigital: boolean) {
    const wallet = this.state.wallets.find(w => w.id === walletId);
    if (!wallet) return;

    const bank = this.state.banks.find(b => b.id === wallet.bankAffiliationId);
    if (!bank) return;

    if (toDigital) {
      // Bank Deposit -> Digital Peso
      if (bank.depositsRetail < amount) {
        this.logEvent("WARNING", `Conversión rechazada: Banco afiliado ${bank.name} carece de liquidez.`, "BankLiquidityChanged");
        return;
      }
      wallet.balance += amount;
      bank.depositsRetail -= amount;
      bank.reserves -= amount; // Bank reserve settles at central bank
    } else {
      // Digital Peso -> Bank Deposit
      if (wallet.balance < amount) {
        this.logEvent("WARNING", "Conversión rechazada: Fondos digitales insuficientes.", "PaymentInitiated");
        return;
      }
      wallet.balance -= amount;
      bank.depositsRetail += amount;
      bank.reserves += amount;
    }

    const dateStr = this.state.simDateTime.toISOString();
    const simTimeStr = this.state.simDateTime.toLocaleTimeString();

    const tx: Transaction = {
      id: "tx-" + (++this.idCounter),
      timestamp: dateStr,
      simTime: simTimeStr,
      payer: toDigital ? `Depósitos de ${wallet.ownerName}` : wallet.ownerName,
      payee: toDigital ? wallet.ownerName : `Depósitos de ${wallet.ownerName}`,
      institution: bank.name,
      amount,
      currency: "MXN",
      instrument: toDigital ? InstrumentType.DIGITAL_PESO : InstrumentType.BANK_DEPOSIT,
      type: toDigital ? TransactionType.PAYMENT : TransactionType.REDEMPTION,
      state: TransactionState.FINAL,
      complianceStatus: "APROBADO",
      finalityStatus: "IRREVOCABLE",
      ledgerEntries: [
        { accountId: `RESERVES-${bank.id}`, accountType: toDigital ? "DEBIT" : "CREDIT", entityName: bank.name, amount },
        { accountId: `WALLET-${wallet.id}`, accountType: toDigital ? "CREDIT" : "DEBIT", entityName: wallet.ownerName, amount }
      ],
      details: toDigital ? "Conversión de depósitos comerciales a pasivos digitales directos de Banco de México." : "Retorno de pasivos digitales a depósitos comerciales bancarios."
    };

    this.state.ledger.unshift(tx);
    this.logEvent("INFO", `CONVERSIÓN: $${amount.toLocaleString()} MXN procesados de forma instantánea.`, "BankLiquidityChanged");
    this.recalculateAggregates();
    this.notify();
  }

  // Offline transfer simulator
  public executeOfflineTransfer(amount: number) {
    if (this.state.offlineA.offlineBalance < amount) {
      this.logEvent("WARNING", "Transferencia offline fallida: Saldo de dispositivo emisor insuficiente.");
      return;
    }

    this.state.offlineA.offlineBalance -= amount;
    this.state.offlineB.offlineBalance += amount;

    const pendingTx = {
      id: "off-tx-" + (++this.idCounter),
      from: this.state.offlineA.ownerName,
      to: this.state.offlineB.ownerName,
      amount,
      timestamp: this.state.simDateTime.toLocaleTimeString()
    };

    this.state.offlineA.pendingTransactions.push(pendingTx);
    this.state.offlineB.pendingTransactions.push(pendingTx);

    this.logEvent("WARNING", `TRANSACCIÓN OFFLINE REGISTRADA LOCALMENTE: Dispositivo A entregó token digital a Dispositivo B por $${amount} MXN.`, "PaymentInitiated");
    this.notify();
  }

  // Network restoration / Offline reconciliation and settlement
  public syncOfflineNetworks() {
    this.logEvent("INFO", "RECONEXIÓN: Conectando Laboratorio Offline con el Libro Central de Liquidación...", "RecoveryCompleted");
    
    // Validate transactions to detect double spend
    const doubleSpendDetected = false; // logic scenario can override

    this.state.offlineA.pendingTransactions.forEach(tx => {
      // Clear local pending txs and settle on central ledger!
      const dateStr = this.state.simDateTime.toISOString();
      const simTimeStr = this.state.simDateTime.toLocaleTimeString();

      const ledgerTx: Transaction = {
        id: tx.id,
        timestamp: dateStr,
        simTime: simTimeStr,
        payer: tx.from,
        payee: tx.to,
        institution: "Ventanilla Offline Sincronizada",
        amount: tx.amount,
        currency: "MXN",
        instrument: InstrumentType.DIGITAL_PESO,
        type: TransactionType.TRANSFER,
        state: TransactionState.FINAL,
        complianceStatus: "APROBADO",
        finalityStatus: "IRREVOCABLE",
        ledgerEntries: [
          { accountId: "OFFLINE-CHIP-A", accountType: "DEBIT", entityName: tx.from, amount: tx.amount },
          { accountId: "OFFLINE-CHIP-B", accountType: "CREDIT", entityName: tx.to, amount: tx.amount }
        ],
        details: "Conciliación diferida exitosa y liquidación irrevocable de transferencias fuera de línea."
      };

      this.state.ledger.unshift(tx.amount > 10000 ? { ...ledgerTx, complianceStatus: "SOSPECHOSO" } : ledgerTx);
    });

    this.state.offlineA.pendingTransactions = [];
    this.state.offlineB.pendingTransactions = [];

    this.logEvent("INFO", "SINCRONIZACIÓN EXITOSA: Transacciones diferidas conciliadas sin conflictos ni doble gasto.", "RecoveryCompleted");
    this.recalculateAggregates();
    this.notify();
  }

  // Government Transfer programs (Tesorería de la Federación)
  public runGovernmentTransfer(category: string, amount: number) {
    if (this.state.governmentFunds.tesoreriaBalance < amount) {
      this.logEvent("WARNING", "Dispersión fallida: Tesorería carece de saldo presupuestario.", "GovernmentPaymentIssued");
      return;
    }

    this.state.governmentFunds.tesoreriaBalance -= amount;
    this.state.governmentFunds.totalDisbursed += amount;
    this.state.governmentFunds.disbursedCount += 450; // simulated households

    // Distribute among wallets
    this.state.wallets.forEach(w => {
      if (w.id !== "w-mule-suspect") {
        w.balance += Math.round(amount / 5);
      }
    });

    this.state.governmentFunds.disbursementHistory.unshift({
      id: "gdis-" + (++this.idCounter),
      category,
      amount,
      date: this.state.simDateTime.toLocaleDateString()
    });

    // Settle in ledger
    const dateStr = this.state.simDateTime.toISOString();
    const simTimeStr = this.state.simDateTime.toLocaleTimeString();

    const tx: Transaction = {
      id: "tx-" + (++this.idCounter),
      timestamp: dateStr,
      simTime: simTimeStr,
      payer: "Tesorería de la Federación (TESOFE)",
      payee: "Dispersión de Beneficiarios Programas",
      institution: "Banco de México",
      amount,
      currency: "MXN",
      instrument: InstrumentType.DIGITAL_PESO,
      type: TransactionType.GOVERNMENT_DISBURSE,
      state: TransactionState.FINAL,
      complianceStatus: "APROBADO",
      finalityStatus: "IRREVOCABLE",
      ledgerEntries: [
        { accountId: "TESOFE-ACCOUNT-CENTRAL", accountType: "DEBIT", entityName: "TESOFE", amount },
        { accountId: "RETAIL-MDBC-LIABILITY", accountType: "CREDIT", entityName: "Hogares Mexicanos", amount }
      ],
      details: `Fondo del programa social '${category}' dispersado de forma instantánea a cuentas corrientes de la federación.`
    };

    this.state.ledger.unshift(tx);
    this.logEvent("INFO", `GOBIERNO DIGITAL: Dispersión masiva completada de '${category}' por $${amount.toLocaleString()} MXN.`, "GovernmentPaymentIssued");
    this.recalculateAggregates();
    this.notify();
  }

  // SAT Payment Simulator
  public payTaxObligation(obligationId: string) {
    const obligation = this.state.taxSim.obligations.find(o => o.id === obligationId);
    if (!obligation || obligation.paid) return;

    // Fictional payment from interactable wallet Sofia or general business
    const userWallet = this.state.wallets.find(w => w.id === "w-user");
    if (obligation.payerName === "Sofía Rodríguez" && userWallet) {
      if (userWallet.balance < obligation.amount) {
        this.logEvent("WARNING", "SAT Pago fallido: Fondos insuficientes.");
        return;
      }
      userWallet.balance -= obligation.amount;
    }

    obligation.paid = true;
    this.state.taxSim.totalCollected += obligation.amount;
    this.state.governmentFunds.tesoreriaBalance += obligation.amount;

    const dateStr = this.state.simDateTime.toISOString();
    const simTimeStr = this.state.simDateTime.toLocaleTimeString();

    const tx: Transaction = {
      id: "tx-" + (++this.idCounter),
      timestamp: dateStr,
      simTime: simTimeStr,
      payer: obligation.payerName,
      payee: "Servicio de Administración Tributaria (SAT)",
      institution: "Portal SAT / Banxico Connect",
      amount: obligation.amount,
      currency: "MXN",
      instrument: InstrumentType.DIGITAL_PESO,
      type: TransactionType.PAYMENT,
      state: TransactionState.FINAL,
      complianceStatus: "APROBADO",
      finalityStatus: "IRREVOCABLE",
      ledgerEntries: [
        { accountId: `TAXPAYER-WALLET-${obligation.payerName.replace(" ", "")}`, accountType: "DEBIT", entityName: obligation.payerName, amount: obligation.amount },
        { accountId: "SAT-COLLECTION-ACCOUNT", accountType: "CREDIT", entityName: "SAT", amount: obligation.amount }
      ],
      details: `Liquidación electrónica instantánea de obligación fiscal: ${obligation.type}.`
    };

    this.state.ledger.unshift(tx);
    this.logEvent("INFO", `SAT: Impuesto liquidado por ${obligation.payerName} por $${obligation.amount.toLocaleString()} MXN.`, "PaymentSettled");
    this.recalculateAggregates();
    this.notify();
  }

  // Apply macro shock rates (+100 BP etc.)
  public changePolicyRate(amountBP: number) {
    const originalRate = this.state.macro.policyRate;
    this.state.macro.policyRate += (amountBP / 100);
    
    // Propagate shock through variables
    const direction = amountBP > 0 ? 1 : -1;
    this.state.macro.inflationRate -= (direction * 0.15 * Math.abs(amountBP / 100)); // Rate hikes cool inflation
    this.state.macro.gdpGrowthRate -= (direction * 0.08 * Math.abs(amountBP / 100)); // Rate hikes slightly slow growth
    this.state.macro.exchangeRateUSD -= (direction * 0.12 * Math.abs(amountBP / 100)); // Rate hikes strengthen MXN
    
    this.logEvent("INFO", `POLÍTICA MONETARIA: Modificación de Tasa Objetivo de ${originalRate}% a ${this.state.macro.policyRate}%. Propagación de efectos en marcha.`, "FXRateChanged");
    this.notify();
  }

  // Settle securities (DVP Atomic Engine)
  public executeDvpSettlement(securityId: string, buyerBankId: string, sellerBankId: string, volume: number) {
    const sec = this.state.securities.find(s => s.id === securityId);
    const buyer = this.state.banks.find(b => b.id === buyerBankId);
    const seller = this.state.banks.find(b => b.id === sellerBankId);

    if (!sec || !buyer || !seller) return;

    const totalCost = sec.marketPrice * volume;

    if (buyer.digitalPesoWholesale < totalCost) {
      this.logEvent("WARNING", `Fallo DVP: Banco comprador ${buyer.name} carece de saldo de Peso Mayorista ($${totalCost.toLocaleString()} MXN requerido).`, "SecuritySettled");
      return;
    }

    // Atomic delivery versus payment swap
    buyer.digitalPesoWholesale -= totalCost;
    seller.digitalPesoWholesale += totalCost;

    buyer.securitiesHoldings += totalCost;
    seller.securitiesHoldings -= totalCost;

    const dateStr = this.state.simDateTime.toISOString();
    const simTimeStr = this.state.simDateTime.toLocaleTimeString();

    const tx: Transaction = {
      id: "tx-" + (++this.idCounter),
      timestamp: dateStr,
      simTime: simTimeStr,
      payer: buyer.name,
      payee: seller.name,
      institution: "DVP Engine Banxico",
      amount: totalCost,
      currency: "MXN",
      instrument: InstrumentType.SECURITIES,
      type: TransactionType.BANK_SETTLE,
      state: TransactionState.FINAL,
      complianceStatus: "APROBADO",
      finalityStatus: "IRREVOCABLE",
      ledgerEntries: [
        { accountId: `WHOLESALE-${buyer.id}`, accountType: "DEBIT", entityName: buyer.name, amount: totalCost },
        { accountId: `WHOLESALE-${seller.id}`, accountType: "CREDIT", entityName: seller.name, amount: totalCost },
        { accountId: `SECURITIES-${buyer.id}`, accountType: "CREDIT", entityName: buyer.name, amount: totalCost },
        { accountId: `SECURITIES-${seller.id}`, accountType: "DEBIT", entityName: seller.name, amount: totalCost }
      ],
      details: `Liquidación atómica síncrona Entrega contra Pago (DvP) de ${volume.toLocaleString()} títulos de ${sec.name} en pesos digitales mayoristas.`
    };

    this.state.ledger.unshift(tx);
    this.logEvent("INFO", `LIQUIDACIÓN ATÓMICA (DvP): Compra de ${sec.name} liquidada de forma irrevocable.`, "SecuritySettled");
    this.recalculateAggregates();
    this.notify();
  }

  // Create Repo Transaction
  public createRepoAgreement(bankId: string, securityId: string, principal: number) {
    const bank = this.state.banks.find(b => b.id === bankId);
    const sec = this.state.securities.find(s => s.id === securityId);

    if (!bank || !sec) return;

    if (bank.securitiesHoldings < principal) {
      this.logEvent("WARNING", "Estructuración de Repo fallida: Garantías de colateral insuficientes.", "RepoCreated");
      return;
    }

    // Liquidate reserves and credit bond pledging
    bank.securitiesHoldings -= principal;
    bank.reserves += principal; // liquidity loan from Central Bank

    const repo: RepoTransaction = {
      id: "repo-" + (++this.idCounter),
      borrowerBankId: bankId,
      lenderBankId: "BANXICO",
      collateralSecurityId: securityId,
      collateralVolume: Math.round(principal / sec.marketPrice),
      haircut: 5,
      repoRate: this.state.macro.policyRate + 0.25,
      maturityDays: 7,
      principalAmount: principal,
      status: "ACTIVO"
    };

    this.state.repos.push(repo);
    this.logEvent("INFO", `CONTRATO REPO: Banco Central otorga liquidez de corto plazo a ${bank.name} colateralizado con ${sec.name}.`, "RepoCreated");
    this.recalculateAggregates();
    this.notify();
  }

  // Trigger cyber incident or toggle resiliency
  public toggleResiliencyNode(node: keyof SystemResiliency) {
    this.state.resiliency[node] = !this.state.resiliency[node];
    
    if (!this.state.resiliency[node]) {
      this.logEvent("CRITICAL", `RED NACIONAL ALERTA: Nodo de infraestructura monetaria '${node}' fuera de línea.`, "NetworkFailure");
    } else {
      this.logEvent("INFO", `RED NACIONAL: Recuperación completada para nodo '${node}'. Redundancia activa.`, "RecoveryCompleted");
    }
    this.notify();
  }

  // Interactive CLI commands parser
  public runCliCommand(commandStr: string): string[] {
    const args = commandStr.trim().split(" ");
    const baseCmd = args[0].toLowerCase();
    
    this.state.cliLogs.push(`> ${commandStr}`);

    if (baseCmd === "help" || baseCmd === "?") {
      return [
        "Comandos disponibles de peso-digital:",
        "  help                               - Muestra esta lista de ayuda",
        "  peso-digital init                  - Inicializa la base de datos de simulación",
        "  peso-digital simulate --speed [1m|1h|1d]  - Cambia la velocidad",
        "  peso-digital issue [monto] [banco] - Emite pesos digitales en un banco",
        "  peso-digital redeem [monto] [banco]- Canjea pesos digitales de regreso",
        "  peso-digital payment [monto] [origen] [destino] - Efectúa un pago",
        "  peso-digital stress [banco]        - Genera corrida bancaria simulada",
        "  peso-digital resilience --status   - Diagnóstico del sistema de pagos",
        "  peso-digital macro --rate [bp]     - Shock de tasa de referencia (bp)",
        "  peso-digital export                - Exporta libro de contabilidad"
      ];
    }

    if (commandStr.startsWith("peso-digital init")) {
      this.state.banks = JSON.parse(JSON.stringify(INITIAL_BANKS));
      this.recalculateAggregates();
      return ["✓ Base monetaria y libro de contabilidad restaurados a valores de fábrica.", "Total de 10 bancos e infraestructura nacional restablecida."];
    }

    if (commandStr.startsWith("peso-digital simulate")) {
      const option = args[3] || "1m";
      if (option === "1m") this.setClockSpeed("1_MIN");
      if (option === "1h") this.setClockSpeed("1_HOUR");
      if (option === "1d") this.setClockSpeed("1_DAY");
      return [`✓ Reloj de simulación reconfigurado a paso acelerado: ${option}`];
    }

    if (commandStr.startsWith("peso-digital issue")) {
      const amt = parseFloat(args[2]) || 10000;
      this.issueDigitalPesos(amt, "b-norte", "w-user");
      return [`✓ Banco de México autoriza emisión especial de $${amt.toLocaleString()} MXN-Digital.`];
    }

    if (commandStr.startsWith("peso-digital redeem")) {
      const amt = parseFloat(args[2]) || 5000;
      this.redeemDigitalPesos(amt, "b-norte", "w-user");
      return [`✓ Liquidación exitosa de redención por $${amt.toLocaleString()} MXN-Digital.`];
    }

    if (commandStr.startsWith("peso-digital payment")) {
      const amt = parseFloat(args[2]) || 100;
      this.makePayment("w-user", "w-mariana", amt);
      return [`✓ Transferencia directa efectuada: $${amt.toLocaleString()} MXN.`];
    }

    if (commandStr.startsWith("peso-digital stress")) {
      this.applyScenario("scen-03");
      return ["⚠ ALERTA DE ESTABILIDAD MONETARIA: Solicitando corrida de depósitos bancarios a MXN-Digital."];
    }

    if (commandStr.startsWith("peso-digital resilience")) {
      const lines = [
        "ESTADO DE LA INFRAESTRUCTURA DE PAGOS NACIONAL:",
        `  Libro de Registro Centralizado (MDBC): ${this.state.resiliency.centralLedgerAvailable ? "ACTIVO" : "CAÍDO"}`,
        `  Cámara de Compensación SPEI:           ${this.state.resiliency.speiAvailable ? "ACTIVO" : "CAÍDO"}`,
        `  Módulo de Pago QR CoDi:                ${this.state.resiliency.codiAvailable ? "ACTIVO" : "CAÍDO"}`,
        `  Red Móvil LTE/5G Nacional:             ${this.state.resiliency.mobileNetworkAvailable ? "ACTIVO" : "CAÍDO"}`
      ];
      return lines;
    }

    if (commandStr.startsWith("peso-digital macro")) {
      const bp = parseFloat(args[3]) || 100;
      this.changePolicyRate(bp);
      return [`✓ Modificación de la tasa interbancaria de equilibrio en ${bp} puntos base.`];
    }

    return [`Error: Comando '${baseCmd}' no reconocido. Escribe 'help' para guía.`];
  }
}

// Singleton Engine Instance
export const simulationEngine = new SimulationEngine();
