/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export enum TransactionState {
  INITIATED = "INICIADO",
  AUTHENTICATED = "AUTENTICADO",
  COMPLIANCE_CHECK = "VERIFICACIÓN DE CUMPLIMIENTO",
  SETTLEMENT = "LIQUIDACIÓN",
  FINAL = "FINALIZADO"
}

export enum TransactionType {
  PAYMENT = "PAGO",
  TRANSFER = "TRANSFERENCIA",
  ISSUANCE = "EMISIÓN",
  REDEMPTION = "REDENCIÓN",
  REFUND = "REEMBOLSO",
  REVERSAL = "REVERSIÓN",
  ESCROW = "ESCROW",
  CONDITIONAL = "PAGO CONDICIONAL",
  MERCHANT_SETTLE = "LIQUIDACIÓN COMERCIO",
  GOVERNMENT_DISBURSE = "DISPERSIÓN GUBERNAMENTAL",
  BANK_SETTLE = "LIQUIDACIÓN INTERBANCARIA"
}

export enum InstrumentType {
  PHYSICAL = "PESOS FÍSICOS (EFECTIVO)",
  BANK_DEPOSIT = "DEPÓSITOS COMERCIALES",
  CENTRAL_RESERVES = "RESERVAS DE BANCO CENTRAL",
  DIGITAL_PESO = "PESO DIGITAL RETORNO (MXN-DIGITAL)",
  WHOLESALE_PESO = "PESO DIGITAL MAYORISTA",
  TOKENIZED_DEPOSIT = "DEPÓSITOS TOKENIZADOS",
  SECURITIES = "VALORES / BONOS",
  FOREIGN_CURRENCY = "DIVISAS EXTRANJERAS"
}

export interface LedgerEntry {
  accountId: string;
  accountType: "DEBIT" | "CREDIT";
  entityName: string;
  amount: number;
}

export interface Transaction {
  id: string;
  timestamp: string; // ISO String or Simulation time representation
  simTime: string;
  payer: string;
  payee: string;
  institution: string;
  amount: number;
  currency: string; // e.g. "MXN", "USD", etc.
  instrument: InstrumentType;
  type: TransactionType;
  state: TransactionState;
  complianceStatus: "APROBADO" | "SOSPECHOSO" | "BLOQUEADO";
  complianceReason?: string;
  ledgerEntries: LedgerEntry[];
  finalityStatus: "PROVISIONAL" | "IRREVOCABLE";
  details?: string;
}

export interface Bank {
  id: string;
  name: string;
  // Assets
  reserves: number; // central-bank reserves
  digitalPesoWholesale: number; // wholesale digital peso holdings
  loans: number;
  securitiesHoldings: number; // bonds (CETES / Bonos)
  physicalCash: number;
  // Liabilities
  depositsRetail: number; // retail deposits
  depositsCorporate: number; // corporate deposits
  centralBankLiquidityDebt: number; // liquidity facility debt
  capital: number; // equity capital
  // Risk metrics
  liquidityRatio: number;
  capitalAdequacyRatio: number;
}

export interface StateMetrics {
  name: string;
  walletsCount: number;
  transactionVolume: number;
  merchantAdoptionRate: number; // percentage
  paymentDensity: number; // txs / min
  liquidity: number;
  offlineUsageCount: number;
  regionalFlowIn: number;
  regionalFlowOut: number;
}

export interface MonetaryAggregates {
  // BASE MONEY
  banknotesAndCoins: number;
  reserves: number;
  digitalPesoSupply: number; // wholesale + retail
  baseMoney: number; // Banknotes & Coins + Reserves + Digital Peso
  
  // COMMERCIAL MONEY
  bankDepositsRetail: number;
  bankDepositsCorporate: number;
  savingsDeposits: number;
  tokenizedDeposits: number;
  commercialMoney: number; // Retail + Corporate + Savings + Tokenized

  // BROAD MONEY
  broadMoneyM1: number; // Cash + Retail Digital Peso + Bank Deposits
  broadMoneyM2: number; // M1 + Savings + Tokenized Deposits
  velocity: number;
  nominalGDP: number;
}

export interface MacroVariables {
  policyRate: number; // % (e.g., 10.5)
  inflationRate: number; // % (e.g., 4.5)
  unemploymentRate: number; // % (e.g., 2.8)
  gdpGrowthRate: number; // % (e.g., 2.1)
  exchangeRateUSD: number; // MXN per USD (e.g., 19.5)
  exchangeRateEUR: number; // MXN per EUR
  exchangeRateCAD: number; // MXN per CAD
  exchangeRateJPY: number; // MXN per JPY
  exchangeRateCNY: number; // MXN per CNY
  exchangeRateGBP: number; // MXN per GBP
  
  // Micro fundamentals for the inflation engine
  wagesGrowth: number;
  energyPrices: number;
  importPrices: number;
  productivityGrowth: number;
  creditGrowth: number;
}

export interface TokenizedSecurity {
  id: string;
  name: string; // e.g., "CETES 28D", "BONOS M 10Y"
  issuer: string; // e.g., "Gobierno Federal"
  faceValue: number; // Par value in MXN
  marketPrice: number; // Current market price in MXN
  yieldToMaturity: number; // % (e.g., 10.2)
  outstandingVolume: number; // Total bonds issued
  maturityDate: string;
  type: "GOBIERNO" | "CORPORATIVO" | "ACCION" | "PAGARE";
}

export interface RepoTransaction {
  id: string;
  borrowerBankId: string;
  lenderBankId: string; // Usually central bank
  collateralSecurityId: string;
  collateralVolume: number;
  haircut: number; // % (e.g., 5)
  repoRate: number; // %
  maturityDays: number;
  principalAmount: number; // Principal borrowed
  status: "ACTIVO" | "CERRADO" | "CON_LLAMADA_DE_MARGEN";
}

export interface Scenario {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  config: {
    adoptionRateMultiplier: number;
    bankRunIntensity: number; // 0 (none) to 1 (max)
    remittanceInflowIntensity: number; // 1 (normal) to 5 (heavy)
    fxShockIntensity: number; // percentage devaluation
    inflationShockIntensity: number;
    networkOutage: boolean;
    cyberIncident: boolean;
    offlineMode: boolean;
    wholesaleSettlementActive: boolean;
    governmentProgramActive: boolean;
    crossBorderActive: boolean;
  };
}

export interface Wallet {
  id: string;
  ownerName: string;
  balance: number;
  savingsBalance: number;
  offlineBalance: number;
  dailySpendingLimit: number;
  spentToday: number;
  privacySetting: "FULL_TRACEABILITY" | "PSEUDONYMOUS" | "TIERED" | "OFFLINE_PRIVACY" | "REGULATED_DISCLOSURE";
  identityStatus: "VERIFICADO_COMPLETO" | "PARCIAL" | "ANÓNIMO";
  isMuleAccount: boolean;
  bankAffiliationId: string;
}

export interface Merchant {
  id: string;
  name: string;
  walletId: string;
  todaySales: number;
  digitalPesoReceipts: number;
  speiReceipts: number;
  codiReceipts: number;
  refundsCount: number;
  settlementLatencySec: number;
  liquidity: number;
  state: string;
}

export interface DemographicsSegment {
  name: string;
  percentageOfPopulation: number;
  bankAccessRate: number; // %
  smartphoneRate: number; // %
  digitalLiteracy: number; // 0 to 100
  cashDependence: number; // 0 to 100
  digitalAdoptionRate: number; // %
}

export interface OfflineDeviceState {
  id: string;
  ownerName: string;
  offlineBalance: number;
  pendingTransactions: {
    id: string;
    from: string;
    to: string;
    amount: number;
    timestamp: string;
  }[];
  hardwareLimit: number;
}

export interface SystemResiliency {
  internetAvailable: boolean;
  mobileNetworkAvailable: boolean;
  individualBanksAvailable: boolean;
  speiAvailable: boolean;
  codiAvailable: boolean;
  centralLedgerAvailable: boolean;
  powerGridAvailable: boolean;
  cloudInfrastructureAvailable: boolean;
  regionalInfrastructureAvailable: boolean;
}

export interface EventLog {
  id: string;
  type:
    | "PaymentInitiated"
    | "PaymentAuthorised"
    | "PaymentSettled"
    | "WalletCreated"
    | "DigitalPesoIssued"
    | "DigitalPesoRedeemed"
    | "BankLiquidityChanged"
    | "FXRateChanged"
    | "GovernmentPaymentIssued"
    | "RemittanceReceived"
    | "SecuritySettled"
    | "RepoCreated"
    | "MarginCallTriggered"
    | "NetworkFailure"
    | "RecoveryCompleted";
  message: string;
  timestamp: string;
  severity: "INFO" | "WARNING" | "CRITICAL";
}
