/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { simulationEngine, SCENARIOS } from "./simulationEngine";
import {
  Building2,
  Smartphone,
  ShoppingBag,
  WifiOff,
  Code2,
  Compass,
  FileSpreadsheet,
  Globe,
  Terminal as TermIcon,
  Play,
  Pause,
  AlertTriangle
} from "lucide-react";

import CentralBankDashboard from "./components/CentralBankDashboard";
import DigitalPesoWallet from "./components/DigitalPesoWallet";
import MerchantTerminal from "./components/MerchantTerminal";
import OfflineLab from "./components/OfflineLab";
import ProgrammableMoneyLab from "./components/ProgrammableMoneyLab";
import MexicoMap from "./components/MexicoMap";
import NationalPaymentMap from "./components/NationalPaymentMap";
import CliConsole from "./components/CliConsole";

export default function App() {
  const [simState, setSimState] = useState(simulationEngine.state);
  const [activeWorkspace, setActiveWorkspace] = useState<
    "CONTROL_ROOM" | "WALLET" | "MERCHANT" | "OFFLINE" | "PROGRAMMABLE" | "SCENARIO_MAPS"
  >("CONTROL_ROOM");

  // Subscribe to simulation engine state ticks
  useEffect(() => {
    const unsubscribe = simulationEngine.subscribe(() => {
      setSimState({ ...simulationEngine.state });
    });
    return () => {
      unsubscribe();
    };
  }, []);

  // UI Handlers directing to the engine
  const handleApplyScenario = (id: string) => {
    simulationEngine.applyScenario(id);
  };

  const handleToggleResiliencyNode = (node: any) => {
    simulationEngine.toggleResiliencyNode(node);
  };

  const handleMakePayment = (fromId: string, toId: string, amount: number) => {
    simulationEngine.makePayment(fromId, toId, amount);
  };

  const handleConvertDeposit = (amount: number, walletId: string, toDigital: boolean) => {
    simulationEngine.convertDeposit(amount, walletId, toDigital);
  };

  const handleUpdatePrivacy = (walletId: string, setting: any) => {
    const updated = simState.wallets.map((w) =>
      w.id === walletId ? { ...w, privacySetting: setting } : w
    );
    simulationEngine.state.wallets = updated;
    simulationEngine.logEvent("INFO", `PRIVACIDAD: Sofía Rodríguez actualiza modelo a '${setting}'.`);
    simulationEngine.recalculateAggregates();
  };

  const handleReceiveMerchantPayment = (
    merchantId: string,
    amount: number,
    channel: "CODI" | "SPEI" | "DIGITAL_PESO"
  ) => {
    const merch = simState.merchants.find((m) => m.id === merchantId);
    if (!merch) return;

    merch.todaySales += amount;
    merch.liquidity += amount;
    if (channel === "CODI") merch.codiReceipts += amount;
    if (channel === "SPEI") merch.speiReceipts += amount;
    if (channel === "DIGITAL_PESO") merch.digitalPesoReceipts += amount;

    // Trigger ledger entry
    const dateStr = simState.simDateTime.toISOString();
    const simTimeStr = simState.simDateTime.toLocaleTimeString();

    const tx = {
      id: "tx-pos-" + Math.floor(Math.random() * 1000 + 5000),
      timestamp: dateStr,
      simTime: simTimeStr,
      payer: "Consumidor General",
      payee: merch.name,
      institution: "Terminal Comercio",
      amount,
      currency: "MXN",
      instrument: channel === "DIGITAL_PESO" ? "PESO DIGITAL RETORNO (MXN-DIGITAL)" as any : "DEPÓSITOS COMERCIALES" as any,
      type: "PAGO" as any,
      state: "FINAL" as any,
      complianceStatus: "APROBADO" as any,
      finalityStatus: "IRREVOCABLE" as any,
      ledgerEntries: [
        { accountId: "CLIENTE-CASH", accountType: "DEBIT" as const, entityName: "Cliente", amount },
        { accountId: `MERCHANT-${merch.id}`, accountType: "CREDIT" as const, entityName: merch.name, amount }
      ],
      details: `Venta minorista POS liquidada por canal: ${channel}.`
    };

    simulationEngine.state.ledger.unshift(tx);
    simulationEngine.logEvent("INFO", `PAGO POS: Comercio ${merch.name} recibió $${amount.toLocaleString()} MXN.`);
    simulationEngine.recalculateAggregates();
  };

  const handleRefundMerchant = (merchantId: string, amount: number) => {
    const merch = simState.merchants.find((m) => m.id === merchantId);
    if (!merch || merch.todaySales < amount) return;

    merch.todaySales -= amount;
    merch.liquidity -= amount;
    merch.refundsCount += 1;

    simulationEngine.logEvent("WARNING", `REEMBOLSO: Comercio ${merch.name} emitió devolución de $${amount.toLocaleString()} MXN.`);
    simulationEngine.recalculateAggregates();
  };

  const handleExecuteOfflineTransfer = (amount: number) => {
    simulationEngine.executeOfflineTransfer(amount);
  };

  const handleSyncOffline = () => {
    simulationEngine.syncOfflineNetworks();
  };

  const handleReleaseContract = (id: string, amount: number, payer: string, payee: string) => {
    // Settle on ledger
    const dateStr = simState.simDateTime.toISOString();
    const simTimeStr = simState.simDateTime.toLocaleTimeString();

    const tx = {
      id: "tx-prog-" + Math.floor(Math.random() * 1000 + 6000),
      timestamp: dateStr,
      simTime: simTimeStr,
      payer,
      payee,
      institution: "Libro de Reglas Soberanas",
      amount,
      currency: "MXN",
      instrument: "PESO DIGITAL RETORNO (MXN-DIGITAL)" as any,
      type: "TRANSFERENCIA" as any,
      state: "FINAL" as any,
      complianceStatus: "APROBADO" as any,
      finalityStatus: "IRREVOCABLE" as any,
      ledgerEntries: [
        { accountId: "ESCROW-LOCKED", accountType: "DEBIT" as const, entityName: "Garantía Programable", amount },
        { accountId: "BENEFICIARIO-WALLET", accountType: "CREDIT" as const, entityName: payee, amount }
      ],
      details: "Liberación automática de contrato condicional programado."
    };

    simulationEngine.state.ledger.unshift(tx);
    simulationEngine.logEvent("INFO", `CONTRATO DISPARADO: Liberados $${amount.toLocaleString()} MXN para ${payee}.`);
    simulationEngine.recalculateAggregates();
  };

  const handlePayTax = (id: string) => {
    const obl = simState.taxSim.obligations.find((o) => o.id === id);
    if (!obl) return;
    obl.paid = true;
    simulationEngine.logEvent("INFO", `IMPUESTOS: SAT recibió pago de impuestos por $${obl.amount.toLocaleString()} MXN.`);
    simulationEngine.recalculateAggregates();
  };

  const handleExecuteCli = (cmd: string) => {
    const result = simulationEngine.runCliCommand(cmd);
    simulationEngine.state.cliLogs.push(...result);
    setSimState({ ...simulationEngine.state });
    return result;
  };

  return (
    <div className="min-h-screen bg-[#09090b] text-[#e4e4e7] flex flex-col font-sans antialiased selection:bg-[#10b981]/20">
      
      {/* Top National Infrastructure Header */}
      <header className="bg-[#121214] border-b border-[#27272a] px-6 py-4 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded bg-[#10b981]/10 flex items-center justify-center border border-[#10b981]/30">
            <Building2 className="w-5 h-5 text-[#10b981]" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-lg font-black text-white tracking-wider">PESO DIGITAL</h1>
              <span className="text-[9px] bg-red-600/10 text-red-500 font-bold px-2 py-0.5 rounded border border-red-500/20">
                SIMULACIÓN / PROTOTIPO DE INVESTIGACIÓN
              </span>
            </div>
            <p className="text-[10px] text-[#71717a] max-w-xl">
              Fictional Research & Monetary Infrastructure Digital Twin. No representation of launch by Banco de México.
            </p>
          </div>
        </div>

        {/* Global status pill */}
        <div className="flex items-center space-x-4 text-xs">
          <div className="text-right hidden sm:block">
            <div className="text-[9px] text-[#71717a] uppercase font-bold">Reloj del Sistema</div>
            <div className="font-mono text-white text-xs">{simState.simDateTime.toLocaleString("es-MX", { dateStyle: "medium", timeStyle: "short" })}</div>
          </div>
          <div className="bg-[#18181b] border border-[#27272a] px-3 py-1.5 rounded flex items-center space-x-2">
            <span className={`w-2 h-2 rounded-full ${simState.isPaused ? "bg-red-500" : "bg-[#10b981] animate-pulse"}`} />
            <span className="text-[10px] font-bold text-[#a1a1aa] uppercase">
              {simState.isPaused ? "Pausado" : "Live Ticking"}
            </span>
          </div>
        </div>
      </header>

      {/* Control Workspace Selector Navigation tabs */}
      <div className="bg-[#0c0c0e] border-b border-[#27272a] px-6 py-2 flex flex-wrap gap-2">
        {[
          { id: "CONTROL_ROOM", label: "Control Central (Banxico)", icon: Building2 },
          { id: "WALLET", label: "Billetera de Retail", icon: Smartphone },
          { id: "MERCHANT", label: "Terminal POS Comercio", icon: ShoppingBag },
          { id: "OFFLINE", label: "Laboratorio Offline", icon: WifiOff },
          { id: "PROGRAMMABLE", label: "Pagos Programables", icon: Code2 },
          { id: "SCENARIO_MAPS", label: "Simulación Geográfica & CLI", icon: Compass }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeWorkspace === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveWorkspace(tab.id as any)}
              className={`flex items-center space-x-2 px-4 py-2 text-xs font-bold transition-all rounded ${
                isActive
                  ? "bg-[#18181b] text-[#10b981] border border-[#10b981]/20 shadow-sm"
                  : "text-[#71717a] hover:text-[#a1a1aa] hover:bg-[#18181b]/30"
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Core Simulation workspace window */}
      <main className="flex-1 p-6 max-w-7xl w-full mx-auto space-y-6">
        
        {/* Render Workspace Content according to active selector */}
        {activeWorkspace === "CONTROL_ROOM" && (
          <CentralBankDashboard
            isPaused={simState.isPaused}
            onTogglePlayPause={() => simulationEngine.togglePlayPause()}
            dateTime={simState.simDateTime}
            clockSpeed={simState.simClockSpeed}
            onSpeedChange={(speed) => simulationEngine.setClockSpeed(speed)}
            aggregates={simState.monetaryAggregates}
            macro={simState.macro}
            banks={simState.banks}
            securities={simState.securities}
            repos={simState.repos}
            ledger={simState.ledger}
            eventLogs={simState.eventLogs}
            scenarios={SCENARIOS}
            activeScenarioId={simState.activeScenarioId}
            resiliency={simState.resiliency}
            onApplyScenario={handleApplyScenario}
            onToggleResiliencyNode={handleToggleResiliencyNode}
            onChangePolicyRate={(bp) => simulationEngine.changePolicyRate(bp)}
            onExecuteDvp={(secId, buyerId, sellerId, vol) => simulationEngine.executeDvpSettlement(secId, buyerId, sellerId, vol)}
            onRepo={(bankId, secId, amt) => simulationEngine.createRepoAgreement(bankId, secId, amt)}
            onDisburseGov={(cat, amt) => simulationEngine.runGovernmentTransfer(cat, amt)}
            onPayTax={handlePayTax}
            taxObligations={simState.taxSim.obligations}
            govFunds={simState.governmentFunds}
          />
        )}

        {activeWorkspace === "WALLET" && (
          <DigitalPesoWallet
            wallet={simState.wallets.find((w) => w.id === "w-user")!}
            allWallets={simState.wallets}
            ledger={simState.ledger}
            onMakePayment={handleMakePayment}
            onConvertDeposit={handleConvertDeposit}
            onUpdatePrivacy={handleUpdatePrivacy}
          />
        )}

        {activeWorkspace === "MERCHANT" && (
          <MerchantTerminal
            merchant={simState.merchants.find((m) => m.id === "m-tienda-luna")!}
            onReceivePayment={handleReceiveMerchantPayment}
            onRefund={handleRefundMerchant}
          />
        )}

        {activeWorkspace === "OFFLINE" && (
          <OfflineLab
            deviceA={simState.offlineA}
            deviceB={simState.offlineB}
            isInternetAvailable={simState.resiliency.internetAvailable}
            onExecuteOfflineTransfer={handleExecuteOfflineTransfer}
            onSyncOffline={handleSyncOffline}
            onToggleInternet={() => handleToggleResiliencyNode("internetAvailable")}
          />
        )}

        {activeWorkspace === "PROGRAMMABLE" && (
          <ProgrammableMoneyLab onReleaseContract={handleReleaseContract} />
        )}

        {activeWorkspace === "SCENARIO_MAPS" && (
          <div className="space-y-8">
            {/* Scenarios trigger row */}
            <div className="bg-[#18181b] border border-[#27272a] p-6">
              <h3 className="text-sm font-semibold text-[#a1a1aa] tracking-wider uppercase mb-4">
                SELECCIONAR ESCENARIO MACRO-ESTRUCTURAL
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {SCENARIOS.map((scen) => (
                  <button
                    key={scen.id}
                    onClick={() => handleApplyScenario(scen.id)}
                    className={`p-3 text-left border text-xs flex flex-col justify-between h-24 rounded transition-all ${
                      simState.activeScenarioId === scen.id
                        ? "bg-[#10b981]/10 border-[#10b981] text-white font-bold"
                        : "bg-[#09090b] border-[#27272a] text-[#71717a] hover:text-[#a1a1aa] hover:bg-[#18181b]"
                    }`}
                  >
                    <span className="font-bold uppercase text-[9px] block text-[#10b981]">{scen.title}</span>
                    <span className="mt-1 font-semibold text-white block truncate">{scen.subtitle}</span>
                    <span className="text-[8px] text-[#71717a] block mt-2 line-clamp-2">{scen.description}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Interactive geographic flow map of Mexico */}
            <MexicoMap states={simState.stateMetrics} />

            {/* Animated network map topology & CLI terminal console side-by-side */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <NationalPaymentMap
                currentClockSpeed={simState.simClockSpeed}
                onSpeedChange={(speed) => simulationEngine.setClockSpeed(speed)}
                systemStatus={simState.isPaused ? "PAUSADO" : "OPERANDO"}
              />

              <CliConsole logs={simState.cliLogs} onExecuteCommand={handleExecuteCli} />
            </div>
          </div>
        )}

      </main>

      {/* Warning Institutional Footer */}
      <footer className="bg-[#121214] border-t border-[#27272a] px-6 py-4 text-center text-[10px] text-[#71717a] flex flex-col sm:flex-row items-center justify-between gap-4">
        <span>© 2026 Laboratorio de Innovación Monetaria S.A. de C.V. Todos los derechos reservados.</span>
        <div className="flex items-center space-x-1 text-yellow-400">
          <AlertTriangle className="w-3.5 h-3.5" />
          <span>ESTA APLICACIÓN ES UN PROTOTIPO PARA FINES DE INVESTIGACIÓN EXCLUSIVAMENTE.</span>
        </div>
      </footer>
    </div>
  );
}
