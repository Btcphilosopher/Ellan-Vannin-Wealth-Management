'use client';

import React, { useState } from 'react';
import { Cpu, Zap, Shield, Wifi, ChevronRight, Layers, Eye, BatteryCharging } from 'lucide-react';

interface SmartTechSectionProps {
  lang: 'zh' | 'en';
}

export default function SmartTechSection({ lang }: SmartTechSectionProps) {
  const [activeTab, setActiveTab] = useState<'pilot' | 'battery' | 'cockpit' | 'safety'>('pilot');

  const techCards = [
    {
      id: 'pilot',
      titleZh: 'L4 级全场景智能驾驶',
      titleEn: 'L4 Full-Scenario Autopilot',
      badgeZh: '双 Orin-X 1016 TOPS',
      badgeEn: 'Dual Orin-X 1016 TOPS',
      icon: <Cpu className="w-5 h-5 text-cyan-400" />,
      descZh: '全栈自研 Lantu Pilot 4.0 领航辅助驾驶系统。搭载 3 颗超远距激光雷达、12 颗高清摄像头与 5 颗毫米波雷达，具备城市全场景导航辅助与代客自动泊车能力。',
      descEn: 'Full-stack in-house Lantu Pilot 4.0 system equipped with 3 ultra-range LiDARs, 12 HD cameras, and 1,016 TOPS computing power for seamless city navigation and automated valet parking.',
      stats: [
        { labelZh: '算力矩阵', labelEn: 'Compute', val: '1016 TOPS' },
        { labelZh: '超远距激光雷达', labelEn: 'LiDARs', val: '3 颗' },
        { labelZh: '感知覆盖', labelEn: 'Coverage', val: '360° 全天候' },
      ],
    },
    {
      id: 'battery',
      titleZh: '800V 碳化硅高压极速超充',
      titleEn: '800V SiC Ultra-Fast Charging',
      badgeZh: '10分钟补能 400km',
      badgeEn: '10 Min for 400km',
      icon: <Zap className="w-5 h-5 text-amber-400" />,
      descZh: '全域 800V 高压架构与碳化硅功率模块，综合电驱效率高达 98.5%。搭配宁德时代高能量密度电芯与智能全温域脉冲加热，低温续航衰减降低 35%。',
      descEn: 'All-domain 800V high-voltage architecture with Silicon Carbide power modules delivering 98.5% efficiency. Intelligent pulse heating maintains optimal winter performance.',
      stats: [
        { labelZh: '平台电压', labelEn: 'Voltage', val: '800V' },
        { labelZh: '最高充电功率', labelEn: 'Peak Power', val: '480 kW' },
        { labelZh: '电驱效率', labelEn: 'Efficiency', val: '98.5%' },
      ],
    },
    {
      id: 'cockpit',
      titleZh: 'Lantu OS 沉浸多模态智能座舱',
      titleEn: 'Lantu OS Immersive Cockpit',
      badgeZh: '高通 8295P + 70" AR-HUD',
      badgeEn: 'Qualcomm 8295P + AR-HUD',
      icon: <Wifi className="w-5 h-5 text-emerald-400" />,
      descZh: '三联屏一体贯穿联动，70英寸超视距 AR-HUD 平视系统让驾驶信息投射于实景道路。端侧大模型车载 AI 语音助手，支持毫秒级连续对话与车家 5G 万物互联。',
      descEn: 'Triple-screen integrated panorama, 70-inch AR-HUD projecting telemetry onto real roads, and on-device AI voice assistant with 5G ecosystem interconnectivity.',
      stats: [
        { labelZh: '座舱芯片', labelEn: 'Cockpit Chip', val: 'Snapdragon 8295' },
        { labelZh: '全景声通道', labelEn: 'Audio', val: '23 扬声器 7.1.4' },
        { labelZh: '语音唤醒响应', labelEn: 'Voice Latency', val: '< 300 ms' },
      ],
    },
    {
      id: 'safety',
      titleZh: '巨鲸高强钢笼式被动安全',
      titleEn: 'Whale-Shield Ultra-Rigid Safety',
      badgeZh: '全球五星安全碰撞标准',
      badgeEn: 'Global 5-Star Safety',
      icon: <Shield className="w-5 h-5 text-blue-400" />,
      descZh: '2000 MPa 热成型超高强度潜艇级笼式车身结构，全车高强度钢占比超 88%。电池包具备防针刺、防挤压、主动隔热排气技术，实现毫秒级断电与永不起火。',
      descEn: '2,000 MPa submarine-grade thermoformed steel cage structure with over 88% high-strength alloy. Zero thermal runaway battery protection with millisecond high-voltage cutoff.',
      stats: [
        { labelZh: '热成型钢强度', labelEn: 'Steel Strength', val: '2000 MPa' },
        { labelZh: '扭转刚度', labelEn: 'Torsional Rigidity', val: '42,000 N·m/deg' },
        { labelZh: '气囊防护', labelEn: 'Airbags', val: '10 环抱气囊' },
      ],
    },
  ];

  return (
    <section id="tech" className="w-full bg-[#070b12] py-16 sm:py-24 border-t border-white/10 select-none">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
          <div>
            <div className="flex items-center gap-2 text-cyan-400 text-xs font-semibold tracking-widest uppercase mb-2">
              <Layers className="w-4 h-4" />
              <span>{lang === 'zh' ? '自主研发 · 硬核实力' : 'CORE INNOVATIONS'}</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold text-white tracking-tight">
              {lang === 'zh' ? '智能科技，重构出行想象' : 'Intelligent Technology'}
            </h2>
          </div>
          <p className="mt-3 md:mt-0 text-sm text-slate-400 max-w-md">
            {lang === 'zh'
              ? '岚途汽车坚持核心技术自主可控，从高压三电、全场景智能驾驶到智慧座舱，全面领跑新一代智能豪华电动赛道。'
              : 'Pioneering proprietary EV architecture, autonomous piloting, and interconnected cockpit technologies for next-generation luxury mobility.'}
          </p>
        </div>

        {/* 4 Tech Innovation Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {techCards.map((card) => {
            const isCurrent = activeTab === card.id;
            return (
              <div
                key={card.id}
                onClick={() => setActiveTab(card.id as any)}
                className={`p-6 rounded-2xl cursor-pointer transition-all duration-300 border flex flex-col justify-between ${
                  isCurrent
                    ? 'bg-gradient-to-b from-slate-900 via-slate-900 to-cyan-950/30 border-cyan-500/50 shadow-[0_0_25px_rgba(6,182,212,0.15)] ring-1 ring-cyan-500/20'
                    : 'bg-slate-900/40 border-white/10 hover:border-white/25 hover:bg-slate-900/60'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center">
                      {card.icon}
                    </div>
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-white/10 text-cyan-300">
                      {lang === 'zh' ? card.badgeZh : card.badgeEn}
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-white mb-2 tracking-wide">
                    {lang === 'zh' ? card.titleZh : card.titleEn}
                  </h3>

                  <p className="text-xs text-slate-400 leading-relaxed mb-6">
                    {lang === 'zh' ? card.descZh : card.descEn}
                  </p>
                </div>

                {/* Stats Matrix */}
                <div className="pt-4 border-t border-white/10 grid grid-cols-3 gap-2 text-center">
                  {card.stats.map((s, i) => (
                    <div key={i}>
                      <span className="text-[9px] text-white/40 block truncate">
                        {lang === 'zh' ? s.labelZh : s.labelEn}
                      </span>
                      <p className="text-xs font-bold text-white mt-0.5 font-mono">
                        {s.val}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
