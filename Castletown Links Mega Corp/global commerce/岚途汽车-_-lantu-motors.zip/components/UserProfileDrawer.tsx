'use client';

import React, { useState, useEffect } from 'react';
import { X, Calendar, Clock, MapPin, User, CheckCircle2, ChevronRight, Shield, RefreshCw } from 'lucide-react';
import { TestDriveBooking } from '@/lib/types';

interface UserProfileDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenTestDrive: () => void;
  lang: 'zh' | 'en';
}

export default function UserProfileDrawer({
  isOpen,
  onClose,
  onOpenTestDrive,
  lang,
}: UserProfileDrawerProps) {
  const [bookings, setBookings] = useState<TestDriveBooking[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchBookings = () => {
    setLoading(true);
    fetch('/api/test-drive')
      .then((res) => res.json())
      .then((data) => {
        if (data?.data) {
          setBookings(data.data);
        }
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    let ignore = false;
    if (isOpen) {
      fetch('/api/test-drive')
        .then((res) => res.json())
        .then((data) => {
          if (!ignore && data?.data) {
            setBookings(data.data);
          }
        })
        .catch(console.error);
    }
    return () => {
      ignore = true;
    };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-slate-900 border-l border-white/15 h-full flex flex-col justify-between shadow-2xl animate-in slide-in-from-right duration-300">
        {/* Header */}
        <div className="p-5 bg-slate-950 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-cyan-950 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
              <User className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">
                {lang === 'zh' ? '岚途车主及体验中心' : 'Lantu Member Center'}
              </h3>
              <span className="text-xs text-white/50">VIP Member Center</span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-white/60 hover:text-white hover:bg-white/10 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Content */}
        <div className="p-5 flex-1 overflow-y-auto space-y-6">
          {/* Active Reservations Header */}
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-semibold text-white tracking-wide">
              {lang === 'zh' ? '我的试驾预约' : 'My Reservations'} ({bookings.length})
            </h4>
            <button
              onClick={fetchBookings}
              disabled={loading}
              className="p-1.5 text-xs text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              <span>{lang === 'zh' ? '刷新' : 'Refresh'}</span>
            </button>
          </div>

          {/* Bookings List */}
          {bookings.length === 0 ? (
            <div className="p-8 text-center bg-slate-950/60 rounded-xl border border-white/10">
              <p className="text-xs text-slate-400">
                {lang === 'zh' ? '暂无试驾预约记录' : 'No reservations yet'}
              </p>
              <button
                onClick={() => {
                  onClose();
                  onOpenTestDrive();
                }}
                className="mt-3 px-4 py-2 rounded-full bg-white text-slate-950 text-xs font-semibold hover:bg-slate-200"
              >
                {lang === 'zh' ? '立即预约试驾' : 'Book a Test Drive'}
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {bookings.map((b) => (
                <div
                  key={b.id}
                  className="p-4 rounded-xl bg-slate-950/80 border border-white/15 relative overflow-hidden"
                >
                  <div className="flex items-center justify-between border-b border-white/10 pb-2.5 mb-2.5">
                    <span className="text-[11px] font-mono text-cyan-400 font-bold">{b.id}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950 border border-emerald-500/30 text-emerald-300">
                      {lang === 'zh' ? '预约已确认' : 'Confirmed'}
                    </span>
                  </div>

                  <p className="text-sm font-bold text-white mb-2">{b.vehicleName}</p>

                  <div className="space-y-1 text-xs text-slate-300">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                      <span className="truncate">{b.storeName}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                      <span>{b.date} &nbsp;({b.timeSlot})</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <User className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                      <span>{b.customerName} · {b.customerPhone}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Member Privileges */}
          <div className="p-4 rounded-xl bg-gradient-to-br from-cyan-950/30 to-slate-950 border border-cyan-500/20 text-xs space-y-2.5">
            <div className="flex items-center gap-1.5 text-cyan-400 font-semibold">
              <Shield className="w-4 h-4" />
              <span>{lang === 'zh' ? '岚途车主尊享权益' : 'VIP Member Privileges'}</span>
            </div>
            <ul className="text-slate-300 space-y-1.5 pl-4 list-disc text-[11px]">
              <li>免费享受终身 480kW 超充专属车位与优先充能权</li>
              <li>每季度专属 OTA 功能体验先锋官内测资格</li>
              <li>一对一金牌专属服务管家 24 小时随行待命</li>
            </ul>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-950 border-t border-white/10 flex items-center justify-between">
          <span className="text-xs text-white/50">岚途汽车中国官方服务支持</span>
          <button
            onClick={() => {
              onClose();
              onOpenTestDrive();
            }}
            className="px-4 py-2 rounded-full bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold transition-colors"
          >
            {lang === 'zh' ? '新建预约' : 'New Booking'}
          </button>
        </div>
      </div>
    </div>
  );
}
