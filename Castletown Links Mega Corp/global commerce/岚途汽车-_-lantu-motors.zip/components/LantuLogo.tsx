'use client';

import React from 'react';

interface LantuLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  showText?: boolean;
}

export function LantuLogoIcon({ className = 'w-9 h-9' }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Sleek stylized geometric automotive wing monogram */}
      <path
        d="M8 20L22 46L32 26L42 46L56 20"
        stroke="currentColor"
        strokeWidth="4.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M22 46L32 36L42 46"
        stroke="currentColor"
        strokeWidth="3.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle cx="32" cy="16" r="3" fill="currentColor" />
    </svg>
  );
}

export default function LantuLogo({ className = '', size = 'md', showText = true }: LantuLogoProps) {
  const iconSize = size === 'sm' ? 'w-7 h-7' : size === 'lg' ? 'w-11 h-11' : 'w-8 h-8';
  const titleSize = size === 'sm' ? 'text-lg' : size === 'lg' ? 'text-2xl' : 'text-xl';
  const subSize = size === 'sm' ? 'text-[9px]' : size === 'lg' ? 'text-xs' : 'text-[10px]';

  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      <div className="text-white relative group">
        <LantuLogoIcon className={`${iconSize} drop-shadow-[0_0_12px_rgba(255,255,255,0.4)] transition-transform duration-300 group-hover:scale-105`} />
      </div>
      {showText && (
        <div className="flex flex-col tracking-wider">
          <span className={`font-semibold text-white tracking-widest ${titleSize} leading-none font-sans`}>
            岚途汽车
          </span>
          <span className={`text-slate-300 font-light tracking-[0.28em] ${subSize} mt-1 uppercase`}>
            LANTU MOTORS
          </span>
        </div>
      )}
    </div>
  );
}
