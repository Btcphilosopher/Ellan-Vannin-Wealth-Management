'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { X, Calendar, Clock, MapPin, User, Phone, Mail, CheckCircle2, AlertCircle, Sparkles, QrCode } from 'lucide-react';
import { VEHICLES, EXPERIENCE_CENTERS } from '@/lib/vehicle-data';
import { VehicleModel, ExperienceCenter, TestDriveBooking } from '@/lib/types';

interface TestDriveModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultVehicle?: VehicleModel;
  onBookingSuccess: (booking: TestDriveBooking) => void;
  lang: 'zh' | 'en';
}

export default function TestDriveModal({
  isOpen,
  onClose,
  defaultVehicle,
  onBookingSuccess,
  lang,
}: TestDriveModalProps) {
  const [selectedVehicle, setSelectedVehicle] = useState<VehicleModel>(
    defaultVehicle || VEHICLES[0]
  );
  const [selectedCenter, setSelectedCenter] = useState<ExperienceCenter>(
    EXPERIENCE_CENTERS[0]
  );
  const [selectedDate, setSelectedDate] = useState('2026-11-03');
  const [selectedTimeSlot, setSelectedTimeSlot] = useState('14:30 - 15:30');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [notes, setNotes] = useState('');

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [confirmedBooking, setConfirmedBooking] = useState<TestDriveBooking | null>(null);

  if (!isOpen) return null;

  const quickDates = [
    { labelZh: '明日 (周六)', labelEn: 'Tomorrow', date: '2026-10-31' },
    { labelZh: '周日', labelEn: 'Sunday', date: '2026-11-01' },
    { labelZh: '下周一', labelEn: 'Mon Nov 2', date: '2026-11-02' },
    { labelZh: '下周二', labelEn: 'Tue Nov 3', date: '2026-11-03' },
    { labelZh: '下周三', labelEn: 'Wed Nov 4', date: '2026-11-04' },
  ];

  const timeSlots = [
    '10:00 - 11:00',
    '11:30 - 12:30',
    '14:00 - 15:00',
    '15:30 - 16:30',
    '17:00 - 18:00',
    '19:00 - 20:00 (夜间光影试驾)',
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!name.trim()) {
      setError(lang === 'zh' ? '请填写您的称呼' : 'Please provide your name');
      return;
    }
    if (!phone.trim() || phone.length < 8) {
      setError(lang === 'zh' ? '请填写有效的联系电话' : 'Please provide a valid phone number');
      return;
    }

    setLoading(true);

    try {
      const response = await fetch('/api/test-drive', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          vehicleId: selectedVehicle.id,
          vehicleName: `${selectedVehicle.name} (${selectedVehicle.categoryZh})`,
          city: selectedCenter.cityZh,
          storeName: selectedCenter.storeNameZh,
          date: selectedDate,
          timeSlot: selectedTimeSlot,
          customerName: name,
          customerPhone: phone,
          customerEmail: email,
          notes: notes,
        }),
      });

      const result = await response.json();

      if (response.ok && result.status === 'success') {
        setConfirmedBooking(result.booking);
        onBookingSuccess(result.booking);
      } else {
        throw new Error(result.message || '预约提交失败，请重试');
      }
    } catch (err: any) {
      setError(err.message || '网络连接异常，请检查后重试');
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setConfirmedBooking(null);
    setError(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-white/15 rounded-2xl shadow-2xl overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200">
        {/* Top Header */}
        <div className="relative p-5 sm:p-6 bg-gradient-to-r from-slate-950 via-slate-900 to-cyan-950/40 border-b border-white/10 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 text-cyan-400 text-xs font-semibold tracking-widest uppercase">
              <Sparkles className="w-3.5 h-3.5" />
              <span>{lang === 'zh' ? '尊享体验 · 预约试驾' : 'VIP TEST DRIVE RESERVATION'}</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-bold text-white mt-1">
              {lang === 'zh' ? '驭见未来，即刻启程' : 'Experience Next-Gen Mobility'}
            </h3>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-white/60 hover:text-white hover:bg-white/10 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 max-h-[78vh] overflow-y-auto">
          {confirmedBooking ? (
            /* Booking Success VIP Ticket */
            <div className="space-y-6 text-center py-2">
              <div className="w-16 h-16 mx-auto rounded-full bg-emerald-500/20 border border-emerald-500/50 flex items-center justify-center text-emerald-400">
                <CheckCircle2 className="w-9 h-9" />
              </div>

              <div>
                <h4 className="text-2xl font-bold text-white">
                  {lang === 'zh' ? '试驾预约成功！' : 'Reservation Confirmed!'}
                </h4>
                <p className="text-sm text-slate-300 mt-2 max-w-md mx-auto">
                  {lang === 'zh'
                    ? '感谢您对岚途汽车的关注，专属体验顾问已接收您的预约，将在 2 小时内致电与您确认到店试驾细节。'
                    : 'Thank you for choosing Lantu Motors. Your dedicated specialist will contact you within 2 hours to confirm details.'}
                </p>
              </div>

              {/* VIP Pass Card */}
              <div className="p-5 rounded-xl bg-slate-950 border border-white/15 text-left relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/5 rounded-full blur-2xl pointer-events-none" />

                <div className="flex items-center justify-between border-b border-white/10 pb-3 mb-4">
                  <div>
                    <span className="text-[10px] text-white/50 tracking-widest uppercase">Reservation Code</span>
                    <p className="text-base sm:text-lg font-mono font-bold text-cyan-400 tracking-wider">
                      {confirmedBooking.id}
                    </p>
                  </div>
                  <div className="px-2.5 py-1 rounded bg-emerald-950/60 border border-emerald-500/40 text-[11px] font-medium text-emerald-300">
                    {lang === 'zh' ? '已确认' : 'Confirmed'}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 text-xs">
                  <div>
                    <span className="text-white/50">预约车型：</span>
                    <p className="text-white font-medium mt-0.5">{confirmedBooking.vehicleName}</p>
                  </div>
                  <div>
                    <span className="text-white/50">试驾顾问：</span>
                    <p className="text-white font-medium mt-0.5">岚途金牌产品专家</p>
                  </div>
                  <div>
                    <span className="text-white/50">体验中心：</span>
                    <p className="text-white font-medium mt-0.5">{confirmedBooking.storeName}</p>
                  </div>
                  <div>
                    <span className="text-white/50">预约时间：</span>
                    <p className="text-white font-medium mt-0.5">{confirmedBooking.date} {confirmedBooking.timeSlot}</p>
                  </div>
                  <div>
                    <span className="text-white/50">体验人：</span>
                    <p className="text-white font-medium mt-0.5">{confirmedBooking.customerName}</p>
                  </div>
                  <div>
                    <span className="text-white/50">联系电话：</span>
                    <p className="text-white font-medium mt-0.5">{confirmedBooking.customerPhone}</p>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between text-[11px] text-slate-400">
                  <div className="flex items-center gap-1.5">
                    <QrCode className="w-4 h-4 text-cyan-400" />
                    <span>到店出示此验证码即可体验</span>
                  </div>
                  <span className="text-white/40">VIP PASS</span>
                </div>
              </div>

              <div className="flex items-center justify-center gap-4 pt-2">
                <button
                  onClick={handleReset}
                  className="px-6 py-2.5 rounded-full bg-white text-slate-950 font-semibold text-sm hover:bg-slate-200 transition-colors"
                >
                  {lang === 'zh' ? '完成并返回' : 'Done & Return'}
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              {error && (
                <div className="p-3 rounded-lg bg-red-950/60 border border-red-500/40 text-red-200 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                  <span>{error}</span>
                </div>
              )}

              {/* Step 1: Select Model */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-2">
                  {lang === 'zh' ? '1. 选择预约车型' : '1. Select Vehicle'}
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  {VEHICLES.map((v) => {
                    const isSelected = selectedVehicle.id === v.id;
                    return (
                      <button
                        type="button"
                        key={v.id}
                        onClick={() => setSelectedVehicle(v)}
                        className={`p-2.5 rounded-xl border text-left transition-all ${
                          isSelected
                            ? 'bg-cyan-950/40 border-cyan-400 ring-1 ring-cyan-400'
                            : 'bg-slate-950/50 border-white/10 hover:border-white/25'
                        }`}
                      >
                        <div className="relative w-full aspect-[16/9] mb-1.5 rounded overflow-hidden">
                          <Image
                            src={v.cardImage}
                            alt={v.name}
                            fill
                            className="object-cover"
                            referrerPolicy="no-referrer"
                          />
                        </div>
                        <div className="font-semibold text-xs text-white truncate">{v.name}</div>
                        <div className="text-[10px] text-slate-400 truncate">{v.categoryZh}</div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Step 2: Select Experience Center */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-2">
                  {lang === 'zh' ? '2. 选择体验中心' : '2. Experience Center'}
                </label>
                <select
                  value={selectedCenter.id}
                  onChange={(e) => {
                    const found = EXPERIENCE_CENTERS.find((c) => c.id === e.target.value);
                    if (found) setSelectedCenter(found);
                  }}
                  className="w-full bg-slate-950 border border-white/15 rounded-xl px-3.5 py-2.5 text-white text-xs sm:text-sm focus:outline-none focus:border-cyan-400"
                >
                  {EXPERIENCE_CENTERS.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.cityZh} · {c.storeNameZh} ({c.addressZh})
                    </option>
                  ))}
                </select>
                <p className="text-[11px] text-slate-400 mt-1 flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                  <span>{selectedCenter.addressZh} · 电话：{selectedCenter.tel}</span>
                </p>
              </div>

              {/* Step 3: Date & Time Slot */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-2">
                  {lang === 'zh' ? '3. 试驾日期与时段' : '3. Date & Time'}
                </label>
                {/* Date chips */}
                <div className="flex flex-wrap gap-2 mb-3">
                  {quickDates.map((item) => (
                    <button
                      type="button"
                      key={item.date}
                      onClick={() => setSelectedDate(item.date)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
                        selectedDate === item.date
                          ? 'bg-cyan-500 text-slate-950 border-cyan-400 font-semibold'
                          : 'bg-slate-950/60 border-white/10 text-slate-300 hover:border-white/25'
                      }`}
                    >
                      {item.labelZh}
                    </button>
                  ))}
                </div>

                {/* Time slot chips */}
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {timeSlots.map((ts) => (
                    <button
                      type="button"
                      key={ts}
                      onClick={() => setSelectedTimeSlot(ts)}
                      className={`px-3 py-2 rounded-lg text-xs text-center border transition-colors ${
                        selectedTimeSlot === ts
                          ? 'bg-cyan-950/50 border-cyan-400 text-cyan-300 font-semibold'
                          : 'bg-slate-950/40 border-white/10 text-slate-300 hover:border-white/20'
                      }`}
                    >
                      {ts}
                    </button>
                  ))}
                </div>
              </div>

              {/* Step 4: Contact Details */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-2">
                  {lang === 'zh' ? '4. 体验人联系信息' : '4. Contact Details'}
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="relative">
                    <User className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                    <input
                      type="text"
                      placeholder={lang === 'zh' ? '您的姓名 (如：张先生)' : 'Your Name'}
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full bg-slate-950 border border-white/15 rounded-xl pl-9 pr-3 py-2 text-xs sm:text-sm text-white focus:outline-none focus:border-cyan-400"
                      required
                    />
                  </div>

                  <div className="relative">
                    <Phone className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                    <input
                      type="tel"
                      placeholder={lang === 'zh' ? '手机号码 (用于接收短信)' : 'Phone Number'}
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full bg-slate-950 border border-white/15 rounded-xl pl-9 pr-3 py-2 text-xs sm:text-sm text-white focus:outline-none focus:border-cyan-400"
                      required
                    />
                  </div>

                  <div className="relative sm:col-span-2">
                    <Mail className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                    <input
                      type="email"
                      placeholder={lang === 'zh' ? '电子邮箱 (选填，用于同步电子日程)' : 'Email (Optional)'}
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full bg-slate-950 border border-white/15 rounded-xl pl-9 pr-3 py-2 text-xs sm:text-sm text-white focus:outline-none focus:border-cyan-400"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <input
                      type="text"
                      placeholder={lang === 'zh' ? '试驾特殊诉求 (选填：如体验高速领航/儿童座椅等)' : 'Special Requests (Optional)'}
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      className="w-full bg-slate-950 border border-white/15 rounded-xl px-3 py-2 text-xs sm:text-sm text-white focus:outline-none focus:border-cyan-400"
                    />
                  </div>
                </div>
              </div>

              {/* Submit CTA */}
              <div className="pt-2 border-t border-white/10 flex items-center justify-between">
                <span className="text-[11px] text-slate-400">
                  {lang === 'zh' ? '试驾需持有一年以上有效机动车驾驶证' : 'Valid driving license required for test drive'}
                </span>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-6 py-2.5 rounded-full bg-white text-slate-950 font-bold text-xs sm:text-sm hover:bg-slate-200 transition-colors disabled:opacity-50"
                >
                  {loading ? (lang === 'zh' ? '提交中...' : 'Submitting...') : (lang === 'zh' ? '立即提交预约' : 'Confirm Booking')}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
