'use client';

import React from 'react';
import LantuLogo from './LantuLogo';
import MountainMotif from './MountainMotif';
import { PhoneCall, MapPin, Mail, Code2, Globe } from 'lucide-react';

interface FooterProps {
  onOpenTestDrive: () => void;
  onOpenPhpInspector: () => void;
  lang: 'zh' | 'en';
}

export default function Footer({ onOpenTestDrive, onOpenPhpInspector, lang }: FooterProps) {
  return (
    <footer className="w-full bg-[#04060a] border-t border-white/10 text-white/70 select-none pt-14 pb-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-white/10">
          {/* Col 1 & 2: Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <LantuLogo size="md" />
            <p className="text-xs sm:text-sm text-slate-400 max-w-sm leading-relaxed mt-3">
              {lang === 'zh'
                ? '岚途汽车 (LANTU MOTORS) 是领先的高端智能纯电汽车品牌，致力于以世界级前瞻设计、800V碳化硅极速超充与全场景智能驾驶技术，引领全球未来出行变革。'
                : 'Lantu Motors is a premier luxury intelligent EV marque dedicated to advancing the future of global mobility through world-class design and breakthrough engineering.'}
            </p>

            <div className="pt-2 flex flex-col gap-2 text-xs text-slate-300">
              <div className="flex items-center gap-2">
                <PhoneCall className="w-3.5 h-3.5 text-cyan-400" />
                <span>24/7 贵宾专属热线：400-888-9999</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-cyan-400" />
                <span>全球联络：contact@lantu-motors.com</span>
              </div>
            </div>
          </div>

          {/* Col 3: Vehicle Series */}
          <div>
            <h4 className="text-xs font-semibold text-white uppercase tracking-wider mb-4">
              {lang === 'zh' ? '全系车型' : 'Vehicles'}
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li><a href="#models" className="hover:text-cyan-400 transition-colors">岚途 S9 (智能旗舰轿车)</a></li>
              <li><a href="#models" className="hover:text-cyan-400 transition-colors">岚途 X7 (全场景智能SUV)</a></li>
              <li><a href="#models" className="hover:text-cyan-400 transition-colors">岚途 L6 (城市纯电SUV)</a></li>
              <li><a href="#models" className="hover:text-cyan-400 transition-colors">岚途 M8 (高端商务MPV)</a></li>
              <li>
                <button onClick={onOpenTestDrive} className="text-cyan-400 hover:text-cyan-300 font-medium">
                  {lang === 'zh' ? '立即预约试驾 →' : 'Book Test Drive →'}
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Smart Tech */}
          <div>
            <h4 className="text-xs font-semibold text-white uppercase tracking-wider mb-4">
              {lang === 'zh' ? '智能科技' : 'Technology'}
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li><a href="#tech" className="hover:text-cyan-400 transition-colors">Lantu Pilot 4.0 领航驾驶</a></li>
              <li><a href="#tech" className="hover:text-cyan-400 transition-colors">800V 碳化硅极速超充平台</a></li>
              <li><a href="#tech" className="hover:text-cyan-400 transition-colors">70-inch AR-HUD 智联座舱</a></li>
              <li><a href="#tech" className="hover:text-cyan-400 transition-colors">巨鲸笼式超高强车身安全</a></li>
              <li><a href="#services" className="hover:text-cyan-400 transition-colors">全国 3200+ 闪充超充网络</a></li>
            </ul>
          </div>

          {/* Col 5: Backend & Developers */}
          <div>
            <h4 className="text-xs font-semibold text-white uppercase tracking-wider mb-4">
              {lang === 'zh' ? '技术架构 & 支持' : 'Architecture'}
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <button
                  onClick={onOpenPhpInspector}
                  className="inline-flex items-center gap-1.5 text-emerald-400 hover:text-emerald-300 font-mono transition-colors"
                >
                  <Code2 className="w-3.5 h-3.5" />
                  <span>PHP 8.2 API 控制台</span>
                </button>
              </li>
              <li><span className="text-slate-500 font-mono text-[11px]">/public/api/booking.php</span></li>
              <li><span className="text-slate-500 font-mono text-[11px]">/public/api/vehicles.php</span></li>
              <li><span className="text-slate-500 font-mono text-[11px]">Next.js 15 App Router</span></li>
              <li><span className="text-slate-500 font-mono text-[11px]">Tailwind CSS v4 Engine</span></li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-white/50">
          <div className="flex flex-wrap items-center gap-4">
            <span>© 2026 岚途汽车科技股份有限公司 (Lantu Motors Ltd.) 版权所有</span>
            <span className="hidden sm:inline">|</span>
            <a href="#" className="hover:text-white transition-colors">隐私政策</a>
            <a href="#" className="hover:text-white transition-colors">用户服务协议</a>
            <a href="#" className="hover:text-white transition-colors">沪ICP备20260888号-1</a>
          </div>

          <div>
            <MountainMotif className="scale-90" />
          </div>
        </div>
      </div>
    </footer>
  );
}
