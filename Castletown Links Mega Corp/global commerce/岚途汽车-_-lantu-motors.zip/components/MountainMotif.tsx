'use client';

import React from 'react';

export default function MountainMotif({ className = '' }: { className?: string }) {
  return (
    <div className={`flex items-center gap-4 text-white/90 select-none ${className}`}>
      {/* Sleek dual mountain geometric polyline */}
      <svg
        viewBox="0 0 140 40"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-24 h-9 opacity-85 shrink-0"
      >
        {/* Background higher peak */}
        <polyline
          points="25,32 55,8 85,32"
          stroke="rgba(255,255,255,0.4)"
          strokeWidth="1.6"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        {/* Main foreground peak */}
        <polyline
          points="10,35 48,15 78,35"
          stroke="currentColor"
          strokeWidth="1.8"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        {/* Second smaller peak connected */}
        <polyline
          points="70,35 98,18 130,35"
          stroke="currentColor"
          strokeWidth="1.8"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>

      <div className="flex flex-col">
        <span className="text-sm font-medium tracking-[0.22em] text-white whitespace-nowrap">
          中国智造 &nbsp;走向世界
        </span>
        <span className="text-[9px] tracking-[0.25em] text-white/50 uppercase mt-0.5 whitespace-nowrap font-light">
          FROM CHINA &nbsp;TO &nbsp;THE WORLD
        </span>
      </div>
    </div>
  );
}
