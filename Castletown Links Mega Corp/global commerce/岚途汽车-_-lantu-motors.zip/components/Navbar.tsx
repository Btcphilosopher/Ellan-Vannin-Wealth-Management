'use client';

import React, { useState, useEffect } from 'react';
import { Search, User, Menu, X, Globe, Code2 } from 'lucide-react';
import LantuLogo from './LantuLogo';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  lang: 'zh' | 'en';
  setLang: (lang: 'zh' | 'en') => void;
  onOpenTestDrive: () => void;
  onOpenSearch: () => void;
  onOpenProfile: () => void;
  onOpenPhpInspector: () => void;
  reservationCount?: number;
}

export default function Navbar({
  activeTab,
  setActiveTab,
  lang,
  setLang,
  onOpenTestDrive,
  onOpenSearch,
  onOpenProfile,
  onOpenPhpInspector,
  reservationCount = 0,
}: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 30);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { id: 'home', labelZh: '首页', labelEn: 'Home', href: '#hero' },
    { id: 'models', labelZh: '车型系列', labelEn: 'Models', href: '#models' },
    { id: 'tech', labelZh: '智能科技', labelEn: 'Intelligent Tech', href: '#tech' },
    { id: 'story', labelZh: '品牌故事', labelEn: 'Brand Story', href: '#story' },
    { id: 'services', labelZh: '服务与支持', labelEn: 'Services & Support', href: '#services' },
  ];

  const handleNavClick = (id: string, href: string) => {
    setActiveTab(id);
    setMobileMenuOpen(false);
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-slate-950/85 backdrop-blur-md border-b border-white/10 shadow-2xl py-3.5'
          : 'bg-gradient-to-b from-black/60 via-black/20 to-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Brand Logo */}
          <div
            onClick={() => handleNavClick('home', '#hero')}
            className="cursor-pointer"
          >
            <LantuLogo size="md" />
          </div>

          {/* Center Navigation Links (Desktop) */}
          <nav className="hidden md:flex items-center gap-8 lg:gap-10">
            {navItems.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id, item.href)}
                  className="relative group py-2 text-sm lg:text-[15px] font-medium tracking-wider transition-colors select-none"
                >
                  <span
                    className={`${
                      isActive
                        ? 'text-white'
                        : 'text-white/80 hover:text-white'
                    }`}
                  >
                    {lang === 'zh' ? item.labelZh : item.labelEn}
                  </span>

                  {/* Active Indicator Underline (Matches design with sleek solid bar) */}
                  {isActive && (
                    <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-6 h-[2.5px] bg-white rounded-full shadow-[0_0_8px_rgba(255,255,255,0.8)] animate-pulse" />
                  )}
                  {!isActive && (
                    <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-0 h-[2px] bg-white/50 rounded-full transition-all duration-300 group-hover:w-4" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Right Action Icons & CTA */}
          <div className="flex items-center gap-3 sm:gap-4 lg:gap-5">
            {/* Language Switcher */}
            <button
              onClick={() => setLang(lang === 'zh' ? 'en' : 'zh')}
              title={lang === 'zh' ? 'Switch to English' : '切换为中文'}
              className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-full bg-white/5 hover:bg-white/15 text-white/90 border border-white/15 transition-all"
            >
              <Globe className="w-3.5 h-3.5 text-white/80" />
              <span>{lang === 'zh' ? 'EN' : '中'}</span>
            </button>

            {/* PHP Backend Inspector Button */}
            <button
              onClick={onOpenPhpInspector}
              title={lang === 'zh' ? '查看 PHP & Next.js 双引擎后端' : 'Inspect PHP & Next.js API'}
              className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 text-xs font-mono font-medium rounded-full bg-emerald-950/40 hover:bg-emerald-900/60 text-emerald-400 border border-emerald-500/30 transition-all"
            >
              <Code2 className="w-3.5 h-3.5" />
              <span>PHP API</span>
            </button>

            {/* Search Button */}
            <button
              onClick={onOpenSearch}
              title={lang === 'zh' ? '搜索车型与科技' : 'Search models & tech'}
              className="p-2 text-white/80 hover:text-white hover:bg-white/10 rounded-full transition-colors"
              aria-label="Search"
            >
              <Search className="w-4 h-4 sm:w-5 sm:h-5 stroke-[1.8]" />
            </button>

            {/* User Profile / My Bookings */}
            <button
              onClick={onOpenProfile}
              title={lang === 'zh' ? '我的试驾与预订' : 'My Reservations'}
              className="relative p-2 text-white/80 hover:text-white hover:bg-white/10 rounded-full transition-colors"
              aria-label="User Account"
            >
              <User className="w-4 h-4 sm:w-5 sm:h-5 stroke-[1.8]" />
              {reservationCount > 0 && (
                <span className="absolute top-1 right-1 w-2 h-2 bg-blue-500 rounded-full ring-2 ring-slate-950 animate-pulse" />
              )}
            </button>

            {/* "预约试驾" (Book a Test Drive) Outline Pill Button - Exact replica */}
            <button
              onClick={onOpenTestDrive}
              className="hidden sm:inline-flex items-center justify-center px-4 sm:px-5 py-1.5 rounded-full border border-white/85 text-white text-xs sm:text-sm font-medium tracking-wide hover:bg-white hover:text-slate-950 hover:shadow-[0_0_20px_rgba(255,255,255,0.4)] active:scale-95 transition-all duration-300"
            >
              {lang === 'zh' ? '预约试驾' : 'Test Drive'}
            </button>

            {/* Mobile Menu Toggle Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-white hover:bg-white/10 rounded-lg transition-colors"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-slate-950/95 backdrop-blur-xl border-b border-white/10 px-4 pt-4 pb-6 space-y-3 animate-in slide-in-from-top-4 duration-200">
          <div className="flex flex-col space-y-2">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id, item.href)}
                className={`text-left px-4 py-2.5 rounded-lg text-sm font-medium tracking-wide transition-colors ${
                  activeTab === item.id
                    ? 'bg-white/15 text-white font-semibold'
                    : 'text-white/70 hover:bg-white/5 hover:text-white'
                }`}
              >
                {lang === 'zh' ? item.labelZh : item.labelEn}
              </button>
            ))}
          </div>

          <div className="pt-3 border-t border-white/10 flex flex-col gap-2.5">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenTestDrive();
              }}
              className="w-full py-2.5 rounded-full bg-white text-slate-950 text-sm font-semibold tracking-wider hover:bg-slate-200 transition-colors"
            >
              {lang === 'zh' ? '预约试驾' : 'Book a Test Drive'}
            </button>
            <div className="flex items-center justify-between px-2 pt-1">
              <button
                onClick={onOpenPhpInspector}
                className="text-xs font-mono text-emerald-400 flex items-center gap-1"
              >
                <Code2 className="w-3.5 h-3.5" />
                <span>PHP Backend API</span>
              </button>
              <button
                onClick={() => setLang(lang === 'zh' ? 'en' : 'zh')}
                className="text-xs text-white/70 hover:text-white flex items-center gap-1"
              >
                <Globe className="w-3.5 h-3.5" />
                <span>{lang === 'zh' ? 'Switch to English' : '切换至中文'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
