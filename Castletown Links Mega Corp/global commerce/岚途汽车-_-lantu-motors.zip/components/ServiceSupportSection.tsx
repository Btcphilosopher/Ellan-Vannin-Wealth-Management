'use client';

import React from 'react';
import { Zap, Wrench, ShieldCheck, Headphones, MapPin, PhoneCall } from 'lucide-react';
import { EXPERIENCE_CENTERS } from '@/lib/vehicle-data';

interface ServiceSupportSectionProps {
  onOpenTestDrive: () => void;
  lang: 'zh' | 'en';
}

export default function ServiceSupportSection({ onOpenTestDrive, lang }: ServiceSupportSectionProps) {
  const servicePillars = [
    {
      icon: <Zap className="w-5 h-5 text-amber-400" />,
      titleZh: '岚途闪充超级补能网络',
      titleEn: 'Flash Supercharging Grid',
      descZh: '全国铺设超过 3,200 座 480kW 全液冷超充站，支持即插即充与自动无感支付。',
      descEn: 'Over 3,200 liquid-cooled 480kW superchargers offering instant plug & charge.',
    },
    {
      icon: <ShieldCheck className="w-5 h-5 text-cyan-400" />,
      titleZh: '终身质保与三电无忧',
      titleEn: 'Lifetime Powertrain Warranty',
      descZh: '首任非营运车主尊享整车及动力电池组终身质保承诺，原厂纯正配件护航。',
      descEn: 'Lifetime warranty for original owners on vehicle and battery packs.',
    },
    {
      icon: <Wrench className="w-5 h-5 text-emerald-400" />,
      titleZh: '24/7 全天候移动道路救援',
      titleEn: '24/7 VIP Roadside Service',
      descZh: '全年无休专属服务车随行待命，一键呼叫快速直达，免费代步车贴心陪伴。',
      descEn: 'Round-the-clock dedicated rescue fleet with complimentary courtesy cars.',
    },
    {
      icon: <Headphones className="w-5 h-5 text-purple-400" />,
      titleZh: '无感 OTA 软件持续进化',
      titleEn: 'Seamless Lifetime OTA',
      descZh: '整车核心控制器均支持远程固件升级，常用常新，每个季度解锁全新驾控体验。',
      descEn: 'Continuous quarterly over-the-air firmware upgrades for all systems.',
    },
  ];

  return (
    <section id="services" className="w-full bg-[#070b13] py-16 sm:py-24 border-t border-white/10 select-none">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="text-xs font-semibold text-cyan-400 tracking-widest uppercase">
            {lang === 'zh' ? '全生命周期 · 尊享无忧' : 'GLOBAL SERVICES & SUPPORT'}
          </span>
          <h2 className="text-3xl sm:text-4xl font-bold text-white tracking-tight mt-2">
            {lang === 'zh' ? '服务与支持' : 'Services & Support'}
          </h2>
          <p className="text-sm text-slate-400 mt-3 leading-relaxed">
            {lang === 'zh'
              ? '从选车、订车到日常充电维护，岚途全方位尊贵管家式服务随时随地为您守护。'
              : 'End-to-end concierge support across charging, maintenance, and seamless mobility.'}
          </p>
        </div>

        {/* 4 Pillars */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {servicePillars.map((s, idx) => (
            <div
              key={idx}
              className="p-6 rounded-2xl bg-slate-900/40 border border-white/10 hover:border-cyan-500/40 transition-all group"
            >
              <div className="w-11 h-11 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
                {s.icon}
              </div>
              <h3 className="text-base font-bold text-white mb-2 group-hover:text-cyan-300 transition-colors">
                {lang === 'zh' ? s.titleZh : s.titleEn}
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                {lang === 'zh' ? s.descZh : s.descEn}
              </p>
            </div>
          ))}
        </div>

        {/* Experience Center Finder */}
        <div className="p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-slate-950 via-slate-900 to-cyan-950/30 border border-white/15">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 pb-6 border-b border-white/10">
            <div>
              <span className="text-xs text-cyan-400 uppercase tracking-widest font-semibold">
                {lang === 'zh' ? '全球体验空间与交付中心' : 'Global Showrooms'}
              </span>
              <h3 className="text-xl sm:text-2xl font-bold text-white mt-1">
                {lang === 'zh' ? '莅临线下空间，亲身体验岚途之美' : 'Visit Our Flagship Centers'}
              </h3>
            </div>

            <button
              onClick={onOpenTestDrive}
              className="inline-flex items-center justify-center px-6 py-2.5 rounded-full bg-white text-slate-950 font-bold text-xs sm:text-sm hover:bg-slate-200 transition-all shrink-0 shadow-lg"
            >
              {lang === 'zh' ? '预约线下试驾体验' : 'Book a VIP Showroom Visit'}
            </button>
          </div>

          {/* Centers List Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-6 text-xs">
            {EXPERIENCE_CENTERS.slice(0, 4).map((center) => (
              <div key={center.id} className="p-3.5 rounded-xl bg-slate-950/60 border border-white/10">
                <div className="flex items-center justify-between text-slate-300 font-semibold mb-1">
                  <span>{center.cityZh}</span>
                  <span className="text-[10px] text-cyan-400 font-normal">{center.regionZh}</span>
                </div>
                <p className="text-white font-medium truncate">{center.storeNameZh}</p>
                <p className="text-slate-400 text-[11px] mt-1 truncate">{center.addressZh}</p>
                <div className="mt-2 text-[10px] text-white/50 flex items-center gap-1">
                  <PhoneCall className="w-3 h-3 text-cyan-400" />
                  <span>{center.tel}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
