'use client';

import React from 'react';
import MountainMotif from './MountainMotif';

interface TechHighlightsBarProps {
  onSelectTech?: (techId: string) => void;
  lang: 'zh' | 'en';
}

export default function TechHighlightsBar({ onSelectTech, lang }: TechHighlightsBarProps) {
  const highlights = [
    {
      id: 'battery',
      titleZh: '超长续航',
      titleEn: 'Ultra-Long Range',
      descZh: '最高可达 800 公里',
      descEn: 'Up to 800 km CLTC',
      // SVG custom matching icon: battery rectangle with lightning
      icon: (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className="w-6 h-6">
          <rect x="2" y="6" width="17" height="12" rx="2" />
          <path d="M22 10v4" strokeLinecap="round" />
          <path d="M10 9l-2 3h3l-1 3" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      ),
    },
    {
      id: 'pilot',
      titleZh: '智能驾驶',
      titleEn: 'Intelligent Driving',
      descZh: 'L4 级自动驾驶技术',
      descEn: 'L4 Autonomous Tech',
      // SVG custom matching icon: chip processor
      icon: (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className="w-6 h-6">
          <rect x="5" y="5" width="14" height="14" rx="2" />
          <path d="M9 9h6v6H9z" />
          <path d="M9 1v4M15 1v4M9 19v4M15 19v4M1 9h4M1 15h4M19 9h4M19 15h4" strokeLinecap="round" />
        </svg>
      ),
    },
    {
      id: 'cloud',
      titleZh: '全域互联',
      titleEn: 'Omni-Connectivity',
      descZh: '5G + 车家互联',
      descEn: '5G + Car-Home Ecosystem',
      // SVG custom matching icon: cloud with connect node
      icon: (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className="w-6 h-6">
          <path d="M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M12 12v3m-1.5-1.5 3 0" strokeLinecap="round" />
        </svg>
      ),
    },
    {
      id: 'safety',
      titleZh: '安全守护',
      titleEn: 'Safety Shield',
      descZh: '全球五星安全标准',
      descEn: 'Global 5-Star Standards',
      // SVG custom matching icon: shield with lightning
      icon: (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className="w-6 h-6">
          <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M12 7l-2 4h3l-1 4" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      ),
    },
  ];

  return (
    <div className="w-full bg-[#05080d] border-t border-white/10 py-7 px-4 sm:px-6 lg:px-10 select-none">
      <div className="max-w-[1536px] mx-auto flex flex-col xl:flex-row items-center justify-between gap-6 xl:gap-8">
        {/* Left 4 Feature Highlights - Exact Replica of Bottom Strip */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 sm:gap-8 lg:gap-12 w-full xl:w-auto">
          {highlights.map((item) => (
            <div
              key={item.id}
              onClick={() => onSelectTech?.(item.id)}
              className="flex items-center gap-3.5 group cursor-pointer"
            >
              <div className="w-11 h-11 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-white/80 group-hover:text-cyan-300 group-hover:border-cyan-500/40 group-hover:bg-cyan-950/20 transition-all shrink-0">
                {item.icon}
              </div>
              <div className="flex flex-col">
                <span className="text-white text-sm font-semibold tracking-wider group-hover:text-cyan-300 transition-colors">
                  {lang === 'zh' ? item.titleZh : item.titleEn}
                </span>
                <span className="text-white/60 text-xs mt-0.5 tracking-wide">
                  {lang === 'zh' ? item.descZh : item.descEn}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Right Mountain Motif & Slogan - Exact Replica */}
        <div className="shrink-0 pt-4 xl:pt-0 border-t xl:border-t-0 border-white/10 w-full xl:w-auto flex justify-center xl:justify-end">
          <MountainMotif />
        </div>
      </div>
    </div>
  );
}
