'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { X, BatteryCharging, Zap, Shield, Cpu, Gauge, Compass, ArrowRight, Check, DollarSign } from 'lucide-react';
import { VehicleModel, VehicleColor } from '@/lib/types';

interface VehicleDetailModalProps {
  vehicle: VehicleModel | null;
  isOpen: boolean;
  onClose: () => void;
  onOpenTestDrive: (vehicle: VehicleModel) => void;
  lang: 'zh' | 'en';
}

export default function VehicleDetailModal({
  vehicle,
  isOpen,
  onClose,
  onOpenTestDrive,
  lang,
}: VehicleDetailModalProps) {
  const [selectedColor, setSelectedColor] = useState<VehicleColor | null>(null);
  const [downPaymentRatio, setDownPaymentRatio] = useState(20); // 20%
  const [loanMonths, setLoanMonths] = useState(36); // 36 months

  if (!isOpen || !vehicle) return null;

  const currentColor = selectedColor || vehicle.colors[0];

  // Calculate monthly payment
  const downPaymentAmount = Math.round((vehicle.priceStart * downPaymentRatio) / 100);
  const loanPrincipal = vehicle.priceStart - downPaymentAmount;
  const annualInterestRate = 0.0299; // 2.99% promotional rate
  const totalInterest = loanPrincipal * annualInterestRate * (loanMonths / 12);
  const monthlyPayment = Math.round((loanPrincipal + totalInterest) / loanMonths);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-slate-900 border border-white/15 rounded-2xl shadow-2xl overflow-hidden my-6 animate-in fade-in zoom-in-95 duration-200">
        {/* Top Header */}
        <div className="p-4 sm:p-6 bg-gradient-to-r from-slate-950 via-slate-900 to-cyan-950/30 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse" />
            <div>
              <span className="text-xs text-white/50 tracking-widest uppercase">
                {lang === 'zh' ? vehicle.categoryZh : vehicle.categoryEn}
              </span>
              <h3 className="text-xl sm:text-2xl font-bold text-white tracking-wider">
                {vehicle.name}
              </h3>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-white/60 hover:text-white hover:bg-white/10 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Scrollable Content */}
        <div className="p-5 sm:p-7 max-h-[80vh] overflow-y-auto space-y-8">
          {/* Main Visual & Color Customizer */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
            {/* Vehicle Card Hero */}
            <div className="lg:col-span-8 relative aspect-[16/9] rounded-xl overflow-hidden bg-slate-950 border border-white/10 shadow-inner group">
              <Image
                src={vehicle.cardImage}
                alt={vehicle.name}
                fill
                priority
                sizes="(max-width: 1024px) 100vw, 65vw"
                className="object-cover object-center transition-transform duration-700 group-hover:scale-105"
                referrerPolicy="no-referrer"
              />

              {/* Tint overlay based on selected color */}
              <div
                className="absolute inset-0 mix-blend-color opacity-30 transition-colors duration-500 pointer-events-none"
                style={{ backgroundColor: currentColor.hex }}
              />

              {/* Subtle metallic reflection */}
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />

              {/* Price Tag in corner */}
              <div className="absolute bottom-3 left-4 px-3 py-1 rounded-lg bg-black/60 backdrop-blur-md border border-white/15 text-white">
                <span className="text-[10px] text-white/60 uppercase">Starting at</span>
                <p className="text-base sm:text-lg font-bold text-cyan-400">
                  {lang === 'zh' ? vehicle.priceDisplayZh : vehicle.priceDisplayEn}
                </p>
              </div>
            </div>

            {/* Color Switcher & Highlights */}
            <div className="lg:col-span-4 space-y-4">
              <div>
                <span className="text-xs text-white/50 tracking-wider uppercase block mb-1.5">
                  {lang === 'zh' ? '外观车漆选择' : 'Exterior Paint Color'}
                </span>
                <p className="text-sm font-semibold text-white mb-3">
                  {lang === 'zh' ? currentColor.nameZh : currentColor.nameEn}
                </p>

                {/* Color Swatches */}
                <div className="flex items-center gap-2.5">
                  {vehicle.colors.map((color) => {
                    const isSelected = currentColor.id === color.id;
                    return (
                      <button
                        key={color.id}
                        onClick={() => setSelectedColor(color)}
                        title={lang === 'zh' ? color.nameZh : color.nameEn}
                        className={`relative w-8 h-8 rounded-full transition-transform ${
                          isSelected ? 'scale-110 ring-2 ring-cyan-400 ring-offset-2 ring-offset-slate-900' : 'hover:scale-105 opacity-80 hover:opacity-100'
                        }`}
                        style={{ backgroundColor: color.hex }}
                      >
                        {isSelected && (
                          <Check className="w-3.5 h-3.5 text-white drop-shadow mx-auto" />
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Core Performance Numbers */}
              <div className="pt-3 border-t border-white/10 grid grid-cols-2 gap-3 text-xs">
                {vehicle.highlightSpecs.map((h, i) => (
                  <div key={i} className="p-2.5 rounded-lg bg-white/5 border border-white/5">
                    <span className="text-[10px] text-white/50 block">
                      {lang === 'zh' ? h.labelZh : h.labelEn}
                    </span>
                    <p className="text-base font-bold text-white mt-0.5">
                      {h.value} <span className="text-xs font-normal text-cyan-400">{h.unit}</span>
                    </p>
                  </div>
                ))}
              </div>

              {/* Direct Booking CTA */}
              <button
                onClick={() => {
                  onClose();
                  onOpenTestDrive(vehicle);
                }}
                className="w-full py-3 rounded-full bg-white hover:bg-slate-200 text-slate-950 font-bold text-xs sm:text-sm tracking-wide transition-all shadow-lg flex items-center justify-center gap-2"
              >
                <Zap className="w-4 h-4 text-amber-500 fill-amber-500" />
                <span>{lang === 'zh' ? '预约试驾此车型' : 'Book Test Drive Now'}</span>
              </button>
            </div>
          </div>

          {/* Detailed Specs Matrix */}
          <div>
            <h4 className="text-sm font-semibold text-white tracking-widest uppercase mb-3 flex items-center gap-2">
              <Gauge className="w-4 h-4 text-cyan-400" />
              <span>{lang === 'zh' ? '全维核心性能指标' : 'Full Technical Specifications'}</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-950/60 border border-white/10">
                <span className="text-white/50 block">零百加速：</span>
                <p className="text-white font-medium mt-1">{vehicle.specs.acceleration}</p>
              </div>
              <div className="p-3 rounded-xl bg-slate-950/60 border border-white/10">
                <span className="text-white/50 block">CLTC纯电续航：</span>
                <p className="text-white font-medium mt-1">{vehicle.specs.cltcRange}</p>
              </div>
              <div className="p-3 rounded-xl bg-slate-950/60 border border-white/10">
                <span className="text-white/50 block">综合最大动力：</span>
                <p className="text-white font-medium mt-1">{vehicle.specs.maxPower}</p>
              </div>
              <div className="p-3 rounded-xl bg-slate-950/60 border border-white/10">
                <span className="text-white/50 block">峰值扭矩：</span>
                <p className="text-white font-medium mt-1">{vehicle.specs.maxTorque}</p>
              </div>
              <div className="p-3 rounded-xl bg-slate-950/60 border border-white/10">
                <span className="text-white/50 block">动力电池规格：</span>
                <p className="text-white font-medium mt-1">{vehicle.specs.batteryCapacity}</p>
              </div>
              <div className="p-3 rounded-xl bg-slate-950/60 border border-white/10">
                <span className="text-white/50 block">超充架构与速度：</span>
                <p className="text-white font-medium mt-1">{vehicle.specs.chargingSpeed}</p>
              </div>
              <div className="p-3 rounded-xl bg-slate-950/60 border border-white/10">
                <span className="text-white/50 block">驱动形式：</span>
                <p className="text-white font-medium mt-1">{vehicle.specs.driveType}</p>
              </div>
              <div className="p-3 rounded-xl bg-slate-950/60 border border-white/10">
                <span className="text-white/50 block">车身尺寸 / 轴距：</span>
                <p className="text-white font-medium mt-1">{vehicle.specs.dimensions} (轴距 {vehicle.specs.wheelbase})</p>
              </div>
              <div className="p-3 rounded-xl bg-slate-950/60 border border-white/10">
                <span className="text-white/50 block">智驾算力与感知：</span>
                <p className="text-white font-medium mt-1">{vehicle.specs.chipset} · {vehicle.specs.lidarCount}</p>
              </div>
            </div>
          </div>

          {/* Interactive Financing Calculator */}
          <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-slate-950 via-slate-900 to-cyan-950/20 border border-white/10">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <DollarSign className="w-4 h-4 text-emerald-400" />
                <h4 className="text-sm font-semibold text-white tracking-wider">
                  {lang === 'zh' ? '尊享金融购车方案测算' : 'Financial Loan & Lease Estimator'}
                </h4>
              </div>
              <span className="text-xs text-emerald-400 font-mono">
                {lang === 'zh' ? '年费率仅 2.99% 起' : 'Low APR 2.99%'}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 items-center">
              <div>
                <label className="text-xs text-white/60 block mb-1">
                  {lang === 'zh' ? `首付比例: ${downPaymentRatio}% (¥${downPaymentAmount.toLocaleString()})` : `Down Payment: ${downPaymentRatio}%`}
                </label>
                <input
                  type="range"
                  min="15"
                  max="50"
                  step="5"
                  value={downPaymentRatio}
                  onChange={(e) => setDownPaymentRatio(Number(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              <div>
                <label className="text-xs text-white/60 block mb-1">
                  {lang === 'zh' ? `分期期数: ${loanMonths} 个月` : `Term: ${loanMonths} Months`}
                </label>
                <div className="flex gap-1.5">
                  {[24, 36, 48, 60].map((m) => (
                    <button
                      key={m}
                      onClick={() => setLoanMonths(m)}
                      className={`flex-1 py-1 rounded text-xs font-medium border transition-colors ${
                        loanMonths === m
                          ? 'bg-cyan-500 text-slate-950 border-cyan-400 font-bold'
                          : 'bg-white/5 border-white/10 text-white/70 hover:text-white'
                      }`}
                    >
                      {m}期
                    </button>
                  ))}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-cyan-950/40 border border-cyan-500/30 text-center">
                <span className="text-[10px] text-cyan-300 uppercase tracking-widest block">
                  {lang === 'zh' ? '预估月供金额' : 'Estimated Monthly'}
                </span>
                <p className="text-xl font-bold font-mono text-white mt-0.5">
                  ¥ {monthlyPayment.toLocaleString()} <span className="text-xs font-normal text-white/60">/月</span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
