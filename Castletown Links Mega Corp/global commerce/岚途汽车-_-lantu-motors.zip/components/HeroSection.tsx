'use client';

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import { ChevronLeft, ChevronRight, ArrowRight, Zap, Cpu, Sparkles, Eye } from 'lucide-react';
import { VEHICLES } from '@/lib/vehicle-data';
import { VehicleModel } from '@/lib/types';

interface HeroSectionProps {
  currentModel: VehicleModel;
  onSelectModel: (model: VehicleModel) => void;
  onOpenTestDrive: () => void;
  onOpenModelDetail: (model: VehicleModel) => void;
  lang: 'zh' | 'en';
}

export default function HeroSection({
  currentModel,
  onSelectModel,
  onOpenTestDrive,
  onOpenModelDetail,
  lang,
}: HeroSectionProps) {
  const [activeHotspot, setActiveHotspot] = useState<string | null>(null);
  const [showHotspots, setShowHotspots] = useState(false);

  const currentIndex = VEHICLES.findIndex((v) => v.id === currentModel.id);

  const handlePrev = React.useCallback(() => {
    const nextIdx = (currentIndex - 1 + VEHICLES.length) % VEHICLES.length;
    onSelectModel(VEHICLES[nextIdx]);
  }, [currentIndex, onSelectModel]);

  const handleNext = React.useCallback(() => {
    const nextIdx = (currentIndex + 1) % VEHICLES.length;
    onSelectModel(VEHICLES[nextIdx]);
  }, [currentIndex, onSelectModel]);

  // Keyboard navigation for carousel
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') handlePrev();
      if (e.key === 'ArrowRight') handleNext();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleNext, handlePrev]);

  const hotspots = [
    {
      id: 'lightbar',
      top: '59%',
      left: '58%',
      titleZh: '流光矩阵星环贯穿灯',
      titleEn: 'Starlight Matrix Horizon Lightbar',
      descZh: '智能ADB自适应矩阵大灯，像素级分区照明',
      descEn: 'Adaptive intelligent ADB matrix beam',
    },
    {
      id: 'battery',
      top: '74%',
      left: '68%',
      titleZh: '800V 高压碳化硅平台',
      titleEn: '800V High-Voltage SiC Architecture',
      descZh: '充电10分钟，补充续航400公里',
      descEn: '10 min ultra-fast charge for 400km range',
    },
    {
      id: 'lidar',
      top: '46%',
      left: '69%',
      titleZh: '顶置高精激光雷达',
      titleEn: 'Ultra-Range High-Precision LiDAR',
      descZh: '1016 TOPS 双 Orin-X 算力全场景智驾',
      descEn: '1,016 TOPS dual Orin-X intelligent autopilot',
    },
  ];

  return (
    <section
      id="hero"
      className="relative w-full min-h-[92vh] lg:min-h-[96vh] flex items-center overflow-hidden bg-slate-950 pt-16 sm:pt-20 select-none"
    >
      {/* Background Graphic & Scene */}
      <div className="absolute inset-0 z-0">
        <Image
          src="/assets/cars/hero-s9.png"
          alt="岚途 S9 智能旗舰轿车"
          fill
          priority
          sizes="100vw"
          className="object-cover object-center scale-[1.01] transition-transform duration-1000 ease-out"
          referrerPolicy="no-referrer"
        />

        {/* Cinematic atmospheric overlays for depth */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#060a10] via-transparent to-black/35 pointer-events-none" />
        <div className="absolute inset-0 bg-gradient-to-r from-black/40 via-transparent to-transparent pointer-events-none" />

        {/* Interactive Hotspots on Vehicle */}
        {currentModel.id === 's9' && showHotspots && (
          <div className="absolute inset-0 pointer-events-none z-20">
            {hotspots.map((hs) => (
              <div
                key={hs.id}
                style={{ top: hs.top, left: hs.left }}
                className="absolute pointer-events-auto -translate-x-1/2 -translate-y-1/2 group"
                onMouseEnter={() => setActiveHotspot(hs.id)}
                onMouseLeave={() => setActiveHotspot(null)}
              >
                <div className="relative cursor-pointer">
                  <div className="w-6 h-6 rounded-full bg-cyan-400/30 flex items-center justify-center animate-ping absolute inset-0" />
                  <div className="w-5 h-5 rounded-full bg-cyan-400/80 backdrop-blur-md flex items-center justify-center border border-white shadow-[0_0_15px_rgba(6,182,212,0.9)]">
                    <div className="w-2 h-2 rounded-full bg-white" />
                  </div>
                </div>

                {/* Hotspot Popover Tooltip */}
                {activeHotspot === hs.id && (
                  <div className="absolute bottom-8 left-1/2 -translate-x-1/2 w-64 p-3 rounded-xl bg-slate-950/90 backdrop-blur-xl border border-cyan-500/40 shadow-2xl text-white text-left z-30 animate-in fade-in zoom-in-95 duration-200">
                    <div className="flex items-center gap-1.5 text-xs text-cyan-400 font-medium mb-1">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>{lang === 'zh' ? hs.titleZh : hs.titleEn}</span>
                    </div>
                    <p className="text-[11px] text-slate-300 leading-relaxed">
                      {lang === 'zh' ? hs.descZh : hs.descEn}
                    </p>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Main Content Area */}
      <div className="relative z-10 w-full max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 py-12 md:py-20 flex flex-col justify-between min-h-[82vh] lg:min-h-[88vh]">
        {/* Top Left Slogan & Headlines (Pixel-Matched to design) */}
        <div className="max-w-xl pt-6 sm:pt-10">
          {/* Sub-label */}
          <div className="flex items-center gap-2 mb-3 sm:mb-4">
            <span className="text-white/85 text-xs sm:text-sm tracking-[0.28em] font-normal uppercase">
              岚途汽车 &nbsp;LANTU MOTORS
            </span>
          </div>

          {/* Big Bold Headline */}
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold tracking-tight text-white leading-[1.12] drop-shadow-md">
            {lang === 'zh' ? (
              <>
                <span className="block">驭见未来</span>
                <span className="block mt-1 sm:mt-2">与世界同行</span>
              </>
            ) : (
              <>
                <span className="block">DRIVE THE FUTURE</span>
                <span className="block mt-1 sm:mt-2 text-3xl sm:text-4xl font-light text-slate-200">
                  JOURNEY WITH THE WORLD
                </span>
              </>
            )}
          </h1>

          {/* Subtitle / Brand Philosophy */}
          <p className="mt-4 sm:mt-6 text-sm sm:text-base text-white/90 font-light tracking-[0.2em] sm:tracking-[0.25em] drop-shadow">
            {lang === 'zh'
              ? '中国智造 · 全球视野 · 让出行更美好'
              : 'China Smart Tech · Global Vision · Elevating Motion'}
          </p>

          {/* CTA Buttons */}
          <div className="mt-7 sm:mt-9 flex flex-wrap items-center gap-4">
            {/* Primary Pill Button: "探索全车型 →" */}
            <a
              href="#models"
              className="inline-flex items-center justify-center gap-3 px-6 sm:px-7 py-3 rounded-full bg-slate-950/80 hover:bg-slate-900 text-white text-sm sm:text-[15px] font-medium tracking-wider border border-white/20 hover:border-white/50 shadow-lg hover:shadow-[0_0_25px_rgba(255,255,255,0.15)] transition-all duration-300 group"
            >
              <span>{lang === 'zh' ? '探索全车型' : 'Explore All Models'}</span>
              <ArrowRight className="w-4 h-4 text-white/80 transition-transform duration-300 group-hover:translate-x-1" />
            </a>

            {/* Quick Test Drive Button */}
            <button
              onClick={onOpenTestDrive}
              className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-full bg-white/10 hover:bg-white/20 backdrop-blur-md text-white text-sm font-medium tracking-wide border border-white/25 transition-all active:scale-95"
            >
              <Zap className="w-4 h-4 text-amber-300" />
              <span>{lang === 'zh' ? '预约试驾' : 'Book Test Drive'}</span>
            </button>

            {/* Toggle Vehicle Specs Hotspots */}
            {currentModel.id === 's9' && (
              <button
                onClick={() => setShowHotspots(!showHotspots)}
                className={`hidden sm:inline-flex items-center gap-1.5 px-3.5 py-3 rounded-full text-xs font-medium backdrop-blur-md transition-all ${
                  showHotspots
                    ? 'bg-cyan-500/25 border border-cyan-400 text-cyan-300'
                    : 'bg-black/30 border border-white/15 text-white/70 hover:text-white'
                }`}
              >
                <Eye className="w-3.5 h-3.5" />
                <span>{showHotspots ? (lang === 'zh' ? '隐藏热点' : 'Hide Specs') : (lang === 'zh' ? '探索核心科技' : 'View Tech Hotspots')}</span>
              </button>
            )}
          </div>
        </div>

        {/* Bottom Bar Controls of Hero: Carousel Navigation */}
        <div className="flex items-end justify-between w-full pt-8 pb-2">
          {/* Active Model Indicator Tag (Left) */}
          <div
            onClick={() => onOpenModelDetail(currentModel)}
            className="cursor-pointer group flex items-center gap-3 bg-black/40 hover:bg-black/60 backdrop-blur-md border border-white/15 px-4 py-2 rounded-xl transition-all"
          >
            <div className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
            <div className="flex flex-col">
              <span className="text-white text-xs sm:text-sm font-semibold tracking-wider group-hover:text-cyan-300 transition-colors">
                {currentModel.name}
              </span>
              <span className="text-[10px] sm:text-xs text-white/60">
                {lang === 'zh' ? currentModel.categoryZh : currentModel.categoryEn} · {currentModel.specs.cltcRange}
              </span>
            </div>
            <ArrowRight className="w-3.5 h-3.5 text-white/60 group-hover:text-white group-hover:translate-x-0.5 transition-all ml-1" />
          </div>

          {/* Carousel Slide Indicators & Chevron Arrows (Right) */}
          <div className="flex items-center gap-4 sm:gap-6 bg-black/30 backdrop-blur-md px-4 py-2 rounded-full border border-white/10">
            {/* Indicators: 4 Dashes (Active is longer white line, matches design) */}
            <div className="flex items-center gap-1.5 sm:gap-2">
              {VEHICLES.map((vehicle, index) => {
                const isActive = index === currentIndex;
                return (
                  <button
                    key={vehicle.id}
                    onClick={() => onSelectModel(vehicle)}
                    title={vehicle.name}
                    className={`h-[2px] sm:h-[2.5px] rounded-full transition-all duration-300 ${
                      isActive
                        ? 'w-7 sm:w-8 bg-white shadow-[0_0_8px_rgba(255,255,255,0.8)]'
                        : 'w-3 sm:w-4 bg-white/30 hover:bg-white/60'
                    }`}
                    aria-label={`Slide ${index + 1}`}
                  />
                );
              })}
            </div>

            {/* Left Chevron */}
            <button
              onClick={handlePrev}
              title="Previous Model"
              className="p-1 sm:p-1.5 text-white/70 hover:text-white hover:bg-white/15 rounded-full transition-colors active:scale-90"
              aria-label="Previous vehicle"
            >
              <ChevronLeft className="w-4 h-4 sm:w-5 sm:h-5 stroke-[1.5]" />
            </button>

            {/* Right Chevron */}
            <button
              onClick={handleNext}
              title="Next Model"
              className="p-1 sm:p-1.5 text-white/70 hover:text-white hover:bg-white/15 rounded-full transition-colors active:scale-90"
              aria-label="Next vehicle"
            >
              <ChevronRight className="w-4 h-4 sm:w-5 sm:h-5 stroke-[1.5]" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
