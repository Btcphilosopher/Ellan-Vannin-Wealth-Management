'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { ArrowRight, Sparkles, SlidersHorizontal, BatteryCharging } from 'lucide-react';
import { VEHICLES } from '@/lib/vehicle-data';
import { VehicleModel } from '@/lib/types';

interface VehicleSeriesSectionProps {
  currentModel: VehicleModel;
  onSelectModel: (model: VehicleModel) => void;
  onOpenModelDetail: (model: VehicleModel) => void;
  onOpenTestDrive: (model?: VehicleModel) => void;
  lang: 'zh' | 'en';
}

export default function VehicleSeriesSection({
  currentModel,
  onSelectModel,
  onOpenModelDetail,
  onOpenTestDrive,
  lang,
}: VehicleSeriesSectionProps) {
  const [filter, setFilter] = useState<'all' | 'sedan' | 'suv' | 'mpv'>('all');
  const [hoveredVehicleId, setHoveredVehicleId] = useState<string | null>(null);

  const filteredVehicles = VEHICLES.filter((v) => {
    if (filter === 'all') return true;
    if (filter === 'sedan') return v.id === 's9';
    if (filter === 'suv') return v.id === 'x7' || v.id === 'l6';
    if (filter === 'mpv') return v.id === 'm8';
    return true;
  });

  return (
    <section id="models" className="relative w-full bg-[#0a0f16] py-10 md:py-14 border-t border-white/5 select-none">
      <div className="max-w-[1536px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row lg:items-center gap-6 lg:gap-8">
          {/* Left Column: Heading & Slogan matching the image exactly */}
          <div className="lg:w-[220px] shrink-0">
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-white font-sans">
              {lang === 'zh' ? '车型系列' : 'Vehicle Series'}
            </h2>
            <p className="mt-1 text-xs sm:text-sm text-slate-400 tracking-wider">
              {lang === 'zh' ? '多元选择，智享未来' : 'Diverse Choices, Smart Future'}
            </p>
            {/* Sleek horizontal accent bar matching design */}
            <div className="mt-3 w-10 h-[2.5px] bg-white/80 rounded-full" />

            {/* Quick filter tabs */}
            <div className="mt-5 flex flex-wrap gap-1.5 lg:flex-col lg:gap-1 text-xs">
              {[
                { id: 'all', labelZh: '全部车型', labelEn: 'All Models' },
                { id: 'sedan', labelZh: '旗舰轿车', labelEn: 'Flagship Sedan' },
                { id: 'suv', labelZh: '全能SUV', labelEn: 'Smart SUVs' },
                { id: 'mpv', labelZh: '商务MPV', labelEn: 'Executive MPV' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setFilter(tab.id as any)}
                  className={`text-left px-2.5 py-1 rounded transition-colors text-[11px] ${
                    filter === tab.id
                      ? 'text-cyan-400 font-medium bg-cyan-950/30'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {lang === 'zh' ? tab.labelZh : tab.labelEn}
                </button>
              ))}
            </div>
          </div>

          {/* Right Grid: 4 Vehicle Cards - Exact Replica of Attached Design */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5 flex-1">
            {filteredVehicles.map((vehicle) => {
              const isSelected = currentModel.id === vehicle.id;
              const isHovered = hoveredVehicleId === vehicle.id;

              return (
                <div
                  key={vehicle.id}
                  onMouseEnter={() => setHoveredVehicleId(vehicle.id)}
                  onMouseLeave={() => setHoveredVehicleId(null)}
                  onClick={() => {
                    onSelectModel(vehicle);
                    onOpenModelDetail(vehicle);
                  }}
                  className={`group relative flex flex-col cursor-pointer transition-all duration-300 rounded-lg overflow-hidden bg-slate-900/40 hover:bg-slate-900/80 border ${
                    isSelected
                      ? 'border-cyan-500/50 shadow-[0_0_20px_rgba(6,182,212,0.15)] ring-1 ring-cyan-500/30'
                      : 'border-white/10 hover:border-white/30'
                  }`}
                >
                  {/* Card Vehicle Image Container */}
                  <div className="relative w-full aspect-[16/9] overflow-hidden bg-slate-950">
                    <Image
                      src={vehicle.cardImage}
                      alt={vehicle.name}
                      fill
                      sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw"
                      className="object-cover object-center transition-transform duration-500 group-hover:scale-105"
                      referrerPolicy="no-referrer"
                    />

                    {/* Gradient shading */}
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent opacity-60 group-hover:opacity-40 transition-opacity" />

                    {/* Active Badge */}
                    {isSelected && (
                      <div className="absolute top-2.5 left-2.5 px-2 py-0.5 rounded-full bg-cyan-500/90 text-slate-950 text-[10px] font-bold tracking-wider uppercase">
                        Current
                      </div>
                    )}

                    {/* Hover Quick Specs Bar */}
                    <div
                      className={`absolute inset-x-0 bottom-0 p-2 bg-slate-950/90 backdrop-blur-md flex items-center justify-between text-[11px] text-slate-300 border-t border-white/10 transition-transform duration-300 ${
                        isHovered ? 'translate-y-0' : 'translate-y-full'
                      }`}
                    >
                      <span className="flex items-center gap-1 text-cyan-400">
                        <BatteryCharging className="w-3 h-3" />
                        {vehicle.specs.cltcRange.split(' ')[0]}km
                      </span>
                      <span className="text-white font-medium">{vehicle.priceDisplayZh}</span>
                    </div>
                  </div>

                  {/* Card Text & Subtitle & Arrow */}
                  <div className="p-3 sm:p-3.5 flex items-center justify-between">
                    <div>
                      <h3 className="text-white text-sm sm:text-base font-semibold tracking-wider group-hover:text-cyan-300 transition-colors">
                        {vehicle.name}
                      </h3>
                      <p className="text-xs text-slate-400 mt-0.5 tracking-wide">
                        {lang === 'zh' ? vehicle.categoryZh : vehicle.categoryEn}
                      </p>
                    </div>

                    {/* Arrow Button */}
                    <div className="w-8 h-8 rounded-full flex items-center justify-center text-white/70 group-hover:text-white group-hover:bg-white/10 transition-all">
                      <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
