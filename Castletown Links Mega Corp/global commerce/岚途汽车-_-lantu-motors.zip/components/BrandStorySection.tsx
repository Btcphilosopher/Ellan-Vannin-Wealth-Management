'use client';

import React from 'react';
import { Compass, Globe2, Award, Leaf, Building2 } from 'lucide-react';
import MountainMotif from './MountainMotif';

interface BrandStorySectionProps {
  lang: 'zh' | 'en';
}

export default function BrandStorySection({ lang }: BrandStorySectionProps) {
  const milestones = [
    {
      year: '2021',
      titleZh: '全球研发网络创立',
      titleEn: 'Global R&D Inception',
      descZh: '在上海设立全球前瞻造型设计中心，同步在德国慕尼黑设立空气动力学工程中心。',
      descEn: 'Established Shanghai Global Design Center and Munich Aerodynamics Engineering Lab.',
    },
    {
      year: '2023',
      titleZh: '自研800V碳化硅平台下线',
      titleEn: '800V SiC Platform Rolled Out',
      descZh: '首创全栈自研高压高集成电驱与麒麟CTP架构，突破量产纯电超充极限。',
      descEn: 'Pioneered full-stack proprietary 800V powertrain and battery architecture.',
    },
    {
      year: '2025',
      titleZh: '全系全场景智驾量产',
      titleEn: 'Lantu Pilot Full-Scenario NOA',
      descZh: 'Lantu Pilot 4.0 实现全国无图城市领航辅助与跨楼层自主代客泊车。',
      descEn: 'Nationwide map-free urban navigation and autonomous multi-level valet parking.',
    },
    {
      year: '2026',
      titleZh: '迈向全球 · 驭见未来',
      titleEn: 'Global Vision · The World Stage',
      descZh: '岚途汽车全面进入欧洲、中东及东南亚高端豪华电动车市场，打造世界级中国名片。',
      descEn: 'Expanding across Europe, Middle East, and Asia-Pacific as China’s premium EV ambassador.',
    },
  ];

  return (
    <section id="story" className="w-full bg-[#05080e] py-16 sm:py-24 border-t border-white/10 select-none">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Column: Brand Vision */}
          <div className="lg:col-span-5 space-y-6">
            <div className="flex items-center gap-2 text-cyan-400 text-xs font-semibold tracking-widest uppercase">
              <Compass className="w-4 h-4" />
              <span>{lang === 'zh' ? '品牌理念 · 智造全球' : 'BRAND HERITAGE'}</span>
            </div>

            <h2 className="text-3xl sm:text-4xl font-bold text-white tracking-tight leading-snug">
              {lang === 'zh' ? (
                <>
                  以东方美学智慧
                  <br />
                  <span className="text-cyan-400">重塑未来豪华出行</span>
                </>
              ) : (
                <>
                  Pioneering Intelligent Luxury
                  <br />
                  <span className="text-cyan-400">With Global Horizon</span>
                </>
              )}
            </h2>

            <p className="text-sm text-slate-300 leading-relaxed font-light">
              {lang === 'zh'
                ? '岚途汽车诞生于中国高新技术与汽车工业智能化革命的交汇点。我们融合深厚东方哲思与前沿航空级空气动力学设计，以极致技术追求与匠心品质，致力于成为全球信赖的高端智能电动汽车领航品牌。'
                : 'Born at the nexus of technological innovation and modern aerospace aerodynamics, Lantu Motors crafts ultra-luxury electric vehicles that merge philosophical craftsmanship with cutting-edge engineering.'}
            </p>

            <div className="pt-2">
              <MountainMotif />
            </div>

            {/* Core Values Badges */}
            <div className="grid grid-cols-2 gap-4 pt-4 border-t border-white/10 text-xs">
              <div className="flex items-center gap-2.5 text-white/80">
                <Leaf className="w-4 h-4 text-emerald-400" />
                <span>{lang === 'zh' ? '100% 零碳智能绿色超级工厂' : '100% Zero-Carbon Plant'}</span>
              </div>
              <div className="flex items-center gap-2.5 text-white/80">
                <Award className="w-4 h-4 text-amber-400" />
                <span>{lang === 'zh' ? '全球最高五星安全标准' : 'Global 5-Star Certified'}</span>
              </div>
            </div>
          </div>

          {/* Right Column: Timeline / Milestones */}
          <div className="lg:col-span-7 space-y-4">
            {milestones.map((m, idx) => (
              <div
                key={m.year}
                className="p-5 rounded-2xl bg-slate-900/50 border border-white/10 hover:border-cyan-500/30 transition-all flex items-start gap-5 group"
              >
                <div className="w-16 h-12 rounded-xl bg-cyan-950/40 border border-cyan-500/30 flex items-center justify-center text-cyan-300 font-mono font-bold text-base shrink-0 group-hover:scale-105 transition-transform">
                  {m.year}
                </div>
                <div className="flex-1">
                  <h3 className="text-base font-bold text-white group-hover:text-cyan-300 transition-colors">
                    {lang === 'zh' ? m.titleZh : m.titleEn}
                  </h3>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                    {lang === 'zh' ? m.descZh : m.descEn}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
