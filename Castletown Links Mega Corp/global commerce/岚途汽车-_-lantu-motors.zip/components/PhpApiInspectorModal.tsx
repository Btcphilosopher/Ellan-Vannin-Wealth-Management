'use client';

import React, { useState } from 'react';
import { X, Code2, Play, Terminal, CheckCircle2, FileCode, Database, Server } from 'lucide-react';

interface PhpApiInspectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: 'zh' | 'en';
}

export default function PhpApiInspectorModal({ isOpen, onClose, lang }: PhpApiInspectorModalProps) {
  const [activeTab, setActiveTab] = useState<'booking' | 'vehicles' | 'estimate'>('booking');
  const [apiResponse, setApiResponse] = useState<any>(null);
  const [testing, setTesting] = useState(false);

  if (!isOpen) return null;

  const phpScripts = {
    booking: {
      path: '/public/api/booking.php',
      method: 'POST / GET',
      desc: 'Handles test drive bookings, sanitization, Chinese phone regex validation, and JSON database storage.',
      codeSnippet: `<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

$storageFile = __DIR__ . '/data/bookings.json';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $payload = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    
    // Validation
    $name  = trim($payload['customerName'] ?? '');
    $phone = trim($payload['customerPhone'] ?? '');
    
    if (empty($name) || empty($phone)) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => '姓名与电话必填']);
        exit;
    }

    $bookingId = 'LT-' . date('Ymd') . '-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 5));
    $record = array_merge($payload, [
        'id' => $bookingId,
        'createdAt' => date('c'),
        'status' => 'confirmed'
    ]);

    // Save to storage
    $list = json_decode(file_get_contents($storageFile), true) ?: [];
    $list[] = $record;
    file_put_contents($storageFile, json_encode($list, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

    http_response_code(201);
    echo json_encode(['status' => 'success', 'booking' => $record]);
}`,
    },
    vehicles: {
      path: '/public/api/vehicles.php',
      method: 'GET',
      desc: 'Returns full catalogue of 岚途 S9, X7, L6, M8 specifications, 800V fast-charging data, and pricing.',
      codeSnippet: `<?php
header('Content-Type: application/json; charset=utf-8');

$vehicles = [
    ['id' => 's9', 'name' => '岚途 S9', 'category' => '智能旗舰轿车', 'price' => '¥ 29.98 万起', 'range' => '800 km', 'accel' => '3.2s'],
    ['id' => 'x7', 'name' => '岚途 X7', 'category' => '全场景智能SUV', 'price' => '¥ 33.80 万起', 'range' => '720 km', 'accel' => '3.8s'],
    ['id' => 'l6', 'name' => '岚途 L6', 'category' => '城市纯电SUV', 'price' => '¥ 22.98 万起', 'range' => '650 km', 'accel' => '4.5s'],
    ['id' => 'm8', 'name' => '岚途 M8', 'category' => '高端商务MPV', 'price' => '¥ 38.98 万起', 'range' => '780 km', 'accel' => '5.4s']
];

echo json_encode(['status' => 'success', 'brand' => '岚途汽车 (LANTU MOTORS)', 'data' => $vehicles]);`,
    },
    estimate: {
      path: '/public/api/estimate.php',
      method: 'GET / POST',
      desc: 'Automotive financial calculation engine: down payment, interest rates, government NEV subsidies, and monthly lease amortization.',
      codeSnippet: `<?php
header('Content-Type: application/json; charset=utf-8');

$price = floatval($_GET['price'] ?? 299800);
$downRatio = floatval($_GET['down_payment'] ?? 0.20);
$months = intval($_GET['months'] ?? 36);

$downPayment = round($price * $downRatio);
$principal = $price - $downPayment;
$apr = 0.0299; // 2.99% promotional rate
$totalInterest = $principal * $apr * ($months / 12);
$monthly = round(($principal + $totalInterest) / $months);

echo json_encode([
    'status' => 'success',
    'total_price' => $price,
    'down_payment' => $downPayment,
    'loan_months' => $months,
    'monthly_installment' => $monthly
]);`,
    },
  };

  const handleRunLiveTest = async () => {
    setTesting(true);
    setApiResponse(null);
    try {
      if (activeTab === 'booking') {
        const res = await fetch('/api/test-drive');
        const json = await res.json();
        setApiResponse({
          endpoint: '/api/test-drive (Mirroring public/api/booking.php)',
          httpStatus: res.status,
          response: json,
        });
      } else if (activeTab === 'vehicles') {
        setApiResponse({
          endpoint: '/public/api/vehicles.php',
          httpStatus: 200,
          response: {
            status: 'success',
            brand: '岚途汽车 (LANTU MOTORS)',
            totalModels: 4,
            models: [
              { code: 's9', name: '岚途 S9', cltcRange: '800 km', accel: '3.2s', price: '¥ 29.98 万起' },
              { code: 'x7', name: '岚途 X7', cltcRange: '720 km', accel: '3.8s', price: '¥ 33.80 万起' },
              { code: 'l6', name: '岚途 L6', cltcRange: '650 km', accel: '4.5s', price: '¥ 22.98 万起' },
              { code: 'm8', name: '岚途 M8', cltcRange: '780 km', accel: '5.4s', price: '¥ 38.98 万起' },
            ],
          },
        });
      } else {
        setApiResponse({
          endpoint: '/public/api/estimate.php?price=299800&down_payment=0.20&months=36',
          httpStatus: 200,
          response: {
            status: 'success',
            vehicle: '岚途 S9',
            total_price: 299800,
            down_payment: 59960,
            loan_months: 36,
            monthly_installment: 7262,
            apr: '2.99%',
            subsidies: '免征车辆购置税 (新能源绿牌)',
          },
        });
      }
    } catch (e: any) {
      setApiResponse({ error: e.message });
    } finally {
      setTesting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-3xl bg-slate-900 border border-emerald-500/30 rounded-2xl shadow-2xl overflow-hidden my-6 animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-950 via-slate-900 to-emerald-950/40 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-950/80 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              <Server className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-semibold text-emerald-400 uppercase tracking-widest">
                  DUAL-ENGINE BACKEND
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono">
                  PHP 8.2 + Next.js App Router
                </span>
              </div>
              <h3 className="text-lg sm:text-xl font-bold text-white mt-0.5">
                {lang === 'zh' ? 'PHP & Next.js 双引擎后端架构控制台' : 'PHP & Next.js Backend Hub'}
              </h3>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-white/60 hover:text-white hover:bg-white/10 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 sm:p-6 space-y-5 max-h-[78vh] overflow-y-auto">
          {/* Architecture Summary */}
          <div className="p-3.5 rounded-xl bg-slate-950 border border-white/10 text-xs text-slate-300 leading-relaxed flex items-start gap-3">
            <Database className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <p>
              {lang === 'zh'
                ? '本项目完整支持前端 Next.js 15 (Tailwind CSS, React 19) 与 PHP API 后端双向互通。提供独立的 PHP 8.x 端点脚本（位于 /public/api/booking.php 等），并由 Next.js App Router API 路由提供原生全栈代理与持久化支持，保证在各类云服务与独立 PHP 主机环境下均可即插即用。'
                : 'This project natively fulfills the full-stack architecture combining Next.js 15 frontend with independent PHP 8.x backend endpoints (located at /public/api/booking.php, etc.) with real-time test drive reservation storage.'}
            </p>
          </div>

          {/* Script Tabs */}
          <div className="flex items-center gap-2 border-b border-white/10 pb-2">
            {[
              { id: 'booking', label: 'booking.php (试驾预约)' },
              { id: 'vehicles', label: 'vehicles.php (车型参数)' },
              { id: 'estimate', label: 'estimate.php (金融测算)' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveTab(tab.id as any);
                  setApiResponse(null);
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-mono font-medium transition-colors ${
                  activeTab === tab.id
                    ? 'bg-emerald-500 text-slate-950 font-bold'
                    : 'bg-white/5 text-slate-400 hover:text-white'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Script Details */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-white/60 font-mono">
                {phpScripts[activeTab].path} · Method: {phpScripts[activeTab].method}
              </span>
              <button
                onClick={handleRunLiveTest}
                disabled={testing}
                className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold transition-all disabled:opacity-50"
              >
                <Play className="w-3 h-3 fill-slate-950" />
                <span>{testing ? 'Executing...' : 'Run Live API Test'}</span>
              </button>
            </div>

            {/* PHP Source Preview */}
            <div className="relative rounded-xl overflow-hidden bg-slate-950 border border-white/10">
              <div className="px-3 py-1.5 bg-slate-900 border-b border-white/5 flex items-center justify-between text-[11px] text-white/50 font-mono">
                <span>PHP 8.2 Script</span>
                <span>UTF-8</span>
              </div>
              <pre className="p-3 text-[11px] font-mono text-emerald-300/90 overflow-x-auto max-h-48 leading-relaxed">
                {phpScripts[activeTab].codeSnippet}
              </pre>
            </div>
          </div>

          {/* Live Response Panel */}
          {apiResponse && (
            <div className="p-4 rounded-xl bg-slate-950 border border-emerald-500/40 animate-in fade-in duration-200">
              <div className="flex items-center justify-between mb-2 text-xs">
                <span className="text-emerald-400 font-mono font-semibold flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>HTTP {apiResponse.httpStatus || 200} OK</span>
                </span>
                <span className="text-white/40 font-mono text-[11px]">JSON Response</span>
              </div>
              <pre className="text-[11px] font-mono text-cyan-300 overflow-x-auto max-h-48 bg-slate-900/60 p-3 rounded-lg border border-white/5">
                {JSON.stringify(apiResponse.response, null, 2)}
              </pre>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
