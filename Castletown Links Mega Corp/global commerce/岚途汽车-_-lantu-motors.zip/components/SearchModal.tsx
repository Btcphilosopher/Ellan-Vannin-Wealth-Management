'use client';

import React, { useState } from 'react';
import { Search, X, ArrowRight, Zap, Shield, Cpu, Sparkles } from 'lucide-react';
import { VEHICLES } from '@/lib/vehicle-data';
import { VehicleModel } from '@/lib/types';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectVehicle: (v: VehicleModel) => void;
  lang: 'zh' | 'en';
}

export default function SearchModal({ isOpen, onClose, onSelectVehicle, lang }: SearchModalProps) {
  const [query, setQuery] = useState('');

  if (!isOpen) return null;

  const quickKeywords = [
    { label: '岚途 S9', type: 'model' },
    { label: '800V 碳化硅', type: 'tech' },
    { label: '800km 超长续航', type: 'spec' },
    { label: 'L4 自动驾驶', type: 'tech' },
    { label: '岚途 X7 旗舰SUV', type: 'model' },
    { label: '置换补贴与金融', type: 'service' },
  ];

  const filteredVehicles = VEHICLES.filter((v) => {
    if (!query.trim()) return true;
    const q = query.toLowerCase();
    return (
      v.name.toLowerCase().includes(q) ||
      v.categoryZh.toLowerCase().includes(q) ||
      v.sloganZh.toLowerCase().includes(q) ||
      v.descriptionZh.toLowerCase().includes(q)
    );
  });

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center p-4 pt-20 bg-black/85 backdrop-blur-md">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-white/15 rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Search Input Bar */}
        <div className="p-4 bg-slate-950 border-b border-white/10 flex items-center gap-3">
          <Search className="w-5 h-5 text-white/50 shrink-0 ml-1" />
          <input
            type="text"
            autoFocus
            placeholder={lang === 'zh' ? '搜索车型、800V超充、L4智能驾驶、门店信息...' : 'Search models, 800V tech, autonomous driving...'}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="flex-1 bg-transparent text-white placeholder-white/40 text-sm sm:text-base focus:outline-none"
          />
          {query && (
            <button onClick={() => setQuery('')} className="p-1 text-white/40 hover:text-white">
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onClose}
            className="px-3 py-1 rounded-lg bg-white/10 text-white/70 hover:text-white text-xs font-medium"
          >
            Esc
          </button>
        </div>

        {/* Content */}
        <div className="p-5 max-h-[65vh] overflow-y-auto space-y-5">
          {/* Quick Keywords */}
          <div>
            <span className="text-[11px] font-semibold uppercase tracking-wider text-white/40 block mb-2">
              {lang === 'zh' ? '热门搜索词' : 'Trending Keywords'}
            </span>
            <div className="flex flex-wrap gap-2">
              {quickKeywords.map((item, i) => (
                <button
                  key={i}
                  onClick={() => setQuery(item.label)}
                  className="px-3 py-1 rounded-full bg-white/5 hover:bg-white/15 border border-white/10 text-xs text-white/80 transition-colors"
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          {/* Results: Models */}
          <div>
            <span className="text-[11px] font-semibold uppercase tracking-wider text-white/40 block mb-2">
              {lang === 'zh' ? '相关车型' : 'Matching Vehicles'} ({filteredVehicles.length})
            </span>

            <div className="space-y-2">
              {filteredVehicles.map((v) => (
                <div
                  key={v.id}
                  onClick={() => {
                    onSelectVehicle(v);
                    onClose();
                  }}
                  className="p-3 rounded-xl bg-slate-950/60 hover:bg-slate-950 border border-white/10 hover:border-cyan-500/40 cursor-pointer flex items-center justify-between transition-all group"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-white font-semibold text-sm group-hover:text-cyan-300 transition-colors">
                        {v.name}
                      </span>
                      <span className="text-[11px] px-2 py-0.5 rounded-full bg-white/10 text-white/70">
                        {v.categoryZh}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5">
                      {v.specs.cltcRange} · {v.specs.acceleration} · {v.priceDisplayZh}
                    </p>
                  </div>

                  <ArrowRight className="w-4 h-4 text-white/40 group-hover:text-white group-hover:translate-x-1 transition-all" />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
