<?php
/**
 * 岚途汽车 (LANTU MOTORS) - Vehicle Catalogue API (PHP)
 * 
 * Provides structured JSON responses for models, specifications, pricing,
 * colors, and feature highlights.
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

$vehicles = [
    [
        'id' => 's9',
        'code' => '岚途 S9',
        'name' => '岚途 S9',
        'categoryZh' => '智能旗舰轿车',
        'categoryEn' => 'Smart Flagship Sedan',
        'sloganZh' => '驭见未来 · 与世界同行',
        'priceStart' => 299800,
        'priceDisplay' => '¥ 29.98 万起',
        'acceleration' => '3.2s',
        'cltcRange' => '800 km',
        'power' => '500 kW / 680 PS',
        'drag' => 'Cd 0.208'
    ],
    [
        'id' => 'x7',
        'code' => '岚途 X7',
        'name' => '岚途 X7',
        'categoryZh' => '全场景智能SUV',
        'categoryEn' => 'All-Scenario Smart SUV',
        'sloganZh' => '势凌天地 · 智领全境',
        'priceStart' => 338000,
        'priceDisplay' => '¥ 33.80 万起',
        'acceleration' => '3.8s',
        'cltcRange' => '720 km',
        'power' => '480 kW / 653 PS',
        'drag' => 'Cd 0.278'
    ],
    [
        'id' => 'l6',
        'code' => '岚途 L6',
        'name' => '岚途 L6',
        'categoryZh' => '城市纯电SUV',
        'categoryEn' => 'Urban Pure Electric SUV',
        'sloganZh' => '灵动型格 · 智潮随行',
        'priceStart' => 229800,
        'priceDisplay' => '¥ 22.98 万起',
        'acceleration' => '4.5s',
        'cltcRange' => '650 km',
        'power' => '310 kW / 422 PS',
        'drag' => 'Cd 0.236'
    ],
    [
        'id' => 'm8',
        'code' => '岚途 M8',
        'name' => '岚途 M8',
        'categoryZh' => '高端商务MPV',
        'categoryEn' => 'High-End Business MPV',
        'sloganZh' => '尊崇领航 · 境驭未来',
        'priceStart' => 389800,
        'priceDisplay' => '¥ 38.98 万起',
        'acceleration' => '5.4s',
        'cltcRange' => '780 km',
        'power' => '420 kW / 571 PS',
        'drag' => 'Cd 0.265'
    ]
];

$modelId = isset($_GET['id']) ? strtolower(trim($_GET['id'])) : '';

if (!empty($modelId)) {
    foreach ($vehicles as $v) {
        if ($v['id'] === $modelId) {
            echo json_encode(['status' => 'success', 'data' => $v], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
            exit;
        }
    }
    http_response_code(404);
    echo json_encode(['status' => 'error', 'message' => 'Vehicle model not found']);
    exit;
}

echo json_encode([
    'status' => 'success',
    'brand' => '岚途汽车 (LANTU MOTORS)',
    'count' => count($vehicles),
    'data' => $vehicles
], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
