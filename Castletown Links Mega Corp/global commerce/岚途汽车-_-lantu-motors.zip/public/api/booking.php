<?php
/**
 * 岚途汽车 (LANTU MOTORS) - Test Drive Booking API Endpoint
 * 
 * Handles new test drive reservations, input sanitation, validation, 
 * and persistence to JSON data storage.
 * 
 * Supports:
 *  - POST: Submit new test drive reservation
 *  - GET:  Query existing reservations (filter by phone or list latest)
 * 
 * Compatible with PHP 7.4+, 8.0+, 8.1+, 8.2+, 8.3+
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

$storageFile = __DIR__ . '/data/bookings.json';

// Ensure data directory exists
if (!is_dir(__DIR__ . '/data')) {
    mkdir(__DIR__ . '/data', 0755, true);
}

// Initialize file if not present
if (!file_exists($storageFile)) {
    file_put_contents($storageFile, json_encode([
        [
            'id' => 'LT-20261001-8891',
            'vehicleId' => 's9',
            'vehicleName' => '岚途 S9 (智能旗舰轿车)',
            'city' => '上海',
            'storeName' => '岚途上海陆家嘴未来中心',
            'date' => '2026-11-05',
            'timeSlot' => '14:30 - 15:30',
            'customerName' => '王先生',
            'customerPhone' => '13812345678',
            'customerEmail' => 'wang@example.com',
            'notes' => '希望体验高速 NOA 领航辅助与 800V 超充',
            'createdAt' => '2026-10-28T09:30:00Z',
            'status' => 'confirmed'
        ]
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

// --------------------------------------------------------------------------
// GET Request: Retrieve reservations
// --------------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $raw = file_get_contents($storageFile);
    $bookings = json_decode($raw, true) ?: [];
    
    // Filter by phone query parameter if provided
    $phoneFilter = isset($_GET['phone']) ? trim($_GET['phone']) : '';
    if (!empty($phoneFilter)) {
        $filtered = array_values(array_filter($bookings, function($b) use ($phoneFilter) {
            return isset($b['customerPhone']) && strpos($b['customerPhone'], $phoneFilter) !== false;
        }));
        echo json_encode([
            'status' => 'success',
            'count' => count($filtered),
            'data' => $filtered
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        exit;
    }

    echo json_encode([
        'status' => 'success',
        'count' => count($bookings),
        'data' => array_slice(array_reverse($bookings), 0, 20)
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

// --------------------------------------------------------------------------
// POST Request: Create reservation
// --------------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $inputJson = file_get_contents('php://input');
    $payload = json_decode($inputJson, true);

    if (!$payload) {
        // Fallback to standard form post
        $payload = $_POST;
    }

    // Validation
    $vehicleId     = trim($payload['vehicleId'] ?? '');
    $vehicleName   = trim($payload['vehicleName'] ?? '岚途 S9');
    $city          = trim($payload['city'] ?? '');
    $storeName     = trim($payload['storeName'] ?? '');
    $date          = trim($payload['date'] ?? '');
    $timeSlot      = trim($payload['timeSlot'] ?? '');
    $customerName  = trim($payload['customerName'] ?? '');
    $customerPhone = trim($payload['customerPhone'] ?? '');
    $customerEmail = trim($payload['customerEmail'] ?? '');
    $notes         = trim($payload['notes'] ?? '');

    if (empty($customerName) || empty($customerPhone)) {
        http_response_code(400);
        echo json_encode([
            'status' => 'error',
            'message' => '姓名与联系电话为必填项 (Name and phone number are required)'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // Validate phone number format (basic check)
    if (!preg_match('/^[0-9+ -]{7,18}$/', $customerPhone)) {
        http_response_code(400);
        echo json_encode([
            'status' => 'error',
            'message' => '请输入有效的电话号码 (Please enter a valid phone number)'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // Generate unique booking confirmation code
    $bookingId = 'LT-' . date('Ymd') . '-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 5));

    $newRecord = [
        'id' => $bookingId,
        'vehicleId' => $vehicleId ?: 's9',
        'vehicleName' => $vehicleName,
        'city' => $city ?: '上海',
        'storeName' => $storeName ?: '岚途上海陆家嘴未来中心',
        'date' => $date ?: date('Y-m-d', strtotime('+2 days')),
        'timeSlot' => $timeSlot ?: '14:00 - 15:00',
        'customerName' => $customerName,
        'customerPhone' => $customerPhone,
        'customerEmail' => $customerEmail,
        'notes' => $notes,
        'createdAt' => date('c'),
        'status' => 'confirmed'
    ];

    $raw = file_get_contents($storageFile);
    $bookings = json_decode($raw, true) ?: [];
    $bookings[] = $newRecord;

    file_put_contents($storageFile, json_encode($bookings, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

    http_response_code(201);
    echo json_encode([
        'status' => 'success',
        'message' => '试驾预约成功！我们的专属体验专家将在2小时内与您联系确认。',
        'booking' => $newRecord
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

http_response_code(405);
echo json_encode(['status' => 'error', 'message' => 'Method Not Allowed']);
