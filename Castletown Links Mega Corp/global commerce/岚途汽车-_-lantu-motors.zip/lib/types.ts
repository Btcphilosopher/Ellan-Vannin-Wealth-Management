export interface VehicleSpec {
  acceleration: string; // e.g. "3.2s"
  cltcRange: string; // e.g. "800 km"
  maxPower: string; // e.g. "500 kW / 680 PS"
  maxTorque: string; // e.g. "850 N·m"
  batteryCapacity: string; // e.g. "102 kWh"
  chargingSpeed: string; // e.g. "800V 高压超充 · 10-80% 仅需12分钟"
  driveType: string; // e.g. "智能双电机全时四驱"
  dimensions: string; // e.g. "5080 × 1960 × 1460 mm"
  wheelbase: string; // e.g. "3020 mm"
  dragCoefficient: string; // e.g. "Cd 0.208"
  chipset: string; // e.g. "双英伟达 Orin-X (1016 TOPS)"
  lidarCount: string; // e.g. "3 颗超远距高精激光雷达"
}

export interface VehicleColor {
  id: string;
  nameZh: string;
  nameEn: string;
  hex: string;
  accent: string;
}

export interface VehicleModel {
  id: 's9' | 'x7' | 'l6' | 'm8';
  code: string;
  name: string;
  categoryZh: string;
  categoryEn: string;
  sloganZh: string;
  sloganEn: string;
  descriptionZh: string;
  descriptionEn: string;
  priceStart: number;
  priceDisplayZh: string;
  priceDisplayEn: string;
  cardImage: string;
  heroImage: string;
  highlightSpecs: {
    labelZh: string;
    labelEn: string;
    value: string;
    unit?: string;
  }[];
  colors: VehicleColor[];
  specs: VehicleSpec;
  featuresZh: string[];
  featuresEn: string[];
}

export interface ExperienceCenter {
  id: string;
  cityZh: string;
  cityEn: string;
  regionZh: string;
  regionEn: string;
  storeNameZh: string;
  storeNameEn: string;
  addressZh: string;
  addressEn: string;
  tel: string;
}

export interface TestDriveBooking {
  id: string;
  vehicleId: string;
  vehicleName: string;
  city: string;
  storeName: string;
  date: string;
  timeSlot: string;
  customerName: string;
  customerPhone: string;
  customerEmail?: string;
  notes?: string;
  createdAt: string;
  status: 'confirmed' | 'pending' | 'completed' | 'cancelled';
}
