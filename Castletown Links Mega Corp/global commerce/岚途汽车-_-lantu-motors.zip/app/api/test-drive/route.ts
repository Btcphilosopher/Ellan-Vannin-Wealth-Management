import { NextRequest, NextResponse } from 'next/server';
import { TestDriveBooking } from '@/lib/types';

// In-memory persistent storage for development session
let bookingDatabase: TestDriveBooking[] = [
  {
    id: 'LT-20261028-A891',
    vehicleId: 's9',
    vehicleName: '岚途 S9 (智能旗舰轿车)',
    city: '上海',
    storeName: '岚途上海陆家嘴未来中心',
    date: '2026-11-06',
    timeSlot: '14:30 - 15:30',
    customerName: '李先生',
    customerPhone: '13812345678',
    customerEmail: 'li@lantu-vip.com',
    notes: '体验800V碳化硅超充与双电机3.2秒加速',
    createdAt: '2026-10-28T09:30:00Z',
    status: 'confirmed',
  },
  {
    id: 'LT-20261029-C723',
    vehicleId: 'x7',
    vehicleName: '岚途 X7 (全场景智能SUV)',
    city: '北京',
    storeName: '岚途北京国贸旗舰中心',
    date: '2026-11-08',
    timeSlot: '10:00 - 11:00',
    customerName: '张女士',
    customerPhone: '13987654321',
    customerEmail: 'zhang@business.cn',
    notes: '全家六座出行与魔毯智能空气悬挂体验',
    createdAt: '2026-10-29T14:15:00Z',
    status: 'confirmed',
  },
];

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const phone = searchParams.get('phone');

  if (phone) {
    const filtered = bookingDatabase.filter((b) => b.customerPhone.includes(phone));
    return NextResponse.json({
      status: 'success',
      engine: 'Next.js API & PHP Dual-Engine Runtime',
      count: filtered.length,
      data: filtered,
    });
  }

  return NextResponse.json({
    status: 'success',
    engine: 'Next.js API & PHP Dual-Engine Runtime',
    count: bookingDatabase.length,
    data: [...bookingDatabase].reverse(),
  });
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    const {
      vehicleId = 's9',
      vehicleName = '岚途 S9',
      city = '上海',
      storeName = '岚途上海陆家嘴未来中心',
      date = '2026-11-05',
      timeSlot = '14:00 - 15:00',
      customerName = '',
      customerPhone = '',
      customerEmail = '',
      notes = '',
    } = body;

    if (!customerName || !customerPhone) {
      return NextResponse.json(
        {
          status: 'error',
          message: '姓名与联系电话为必填项 (Name and contact number are required)',
        },
        { status: 400 }
      );
    }

    const randomSuffix = Math.random().toString(36).substring(2, 6).toUpperCase();
    const dateStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const bookingId = `LT-${dateStr}-${randomSuffix}`;

    const newBooking: TestDriveBooking = {
      id: bookingId,
      vehicleId,
      vehicleName,
      city,
      storeName,
      date,
      timeSlot,
      customerName,
      customerPhone,
      customerEmail,
      notes,
      createdAt: new Date().toISOString(),
      status: 'confirmed',
    };

    bookingDatabase.push(newBooking);

    return NextResponse.json(
      {
        status: 'success',
        message: '预约成功！专属体验顾问将在 2 小时内致电与您确认试驾细节。',
        booking: newBooking,
      },
      { status: 201 }
    );
  } catch (error) {
    return NextResponse.json(
      {
        status: 'error',
        message: error instanceof Error ? error.message : 'Invalid request payload',
      },
      { status: 400 }
    );
  }
}
