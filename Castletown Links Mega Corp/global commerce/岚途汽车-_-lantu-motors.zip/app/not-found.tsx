import Link from 'next/link';

export default function NotFound() {
  return (
    <div className="min-h-screen bg-[#060a10] flex flex-col items-center justify-center text-center p-6 text-white">
      <h1 className="text-6xl font-bold font-mono text-cyan-400">404</h1>
      <h2 className="text-xl font-semibold mt-4">页面未找到 · Page Not Found</h2>
      <p className="text-sm text-slate-400 mt-2 max-w-md">
        您访问的页面不存在或已迁移。请返回岚途汽车官方首页。
      </p>
      <Link
        href="/"
        className="mt-6 px-6 py-2.5 rounded-full bg-white text-slate-950 font-semibold text-sm hover:bg-slate-200 transition-colors"
      >
        返回首页 / Return Home
      </Link>
    </div>
  );
}
