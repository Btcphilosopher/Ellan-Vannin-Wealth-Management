import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: '岚途汽车 | LANTU MOTORS - 驭见未来 与世界同行',
  description: '岚途汽车官方网站。中国智造，全球视野，让出行更美好。探索岚途S9、X7、L6、M8等高端智能纯电车型，预约试驾尊享未来出行体验。',
  openGraph: {
    title: '岚途汽车 | LANTU MOTORS - 驭见未来 与世界同行',
    description: '岚途汽车官方网站。中国智造，全球视野，让出行更美好。探索高端智能纯电旗舰车型。',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: '岚途汽车 | LANTU MOTORS',
    description: '中国智造 · 全球视野 · 让出行更美好',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
