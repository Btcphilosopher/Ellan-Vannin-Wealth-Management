'use client';

import React, { useState, useEffect } from 'react';
import Navbar from '@/components/Navbar';
import HeroSection from '@/components/HeroSection';
import VehicleSeriesSection from '@/components/VehicleSeriesSection';
import TechHighlightsBar from '@/components/TechHighlightsBar';
import SmartTechSection from '@/components/SmartTechSection';
import BrandStorySection from '@/components/BrandStorySection';
import ServiceSupportSection from '@/components/ServiceSupportSection';
import Footer from '@/components/Footer';

import TestDriveModal from '@/components/TestDriveModal';
import VehicleDetailModal from '@/components/VehicleDetailModal';
import PhpApiInspectorModal from '@/components/PhpApiInspectorModal';
import SearchModal from '@/components/SearchModal';
import UserProfileDrawer from '@/components/UserProfileDrawer';

import { VEHICLES } from '@/lib/vehicle-data';
import { VehicleModel, TestDriveBooking } from '@/lib/types';

export default function Home() {
  const [lang, setLang] = useState<'zh' | 'en'>('zh');
  const [activeTab, setActiveTab] = useState<string>('home');

  // Currently showcased vehicle in hero
  const [currentModel, setCurrentModel] = useState<VehicleModel>(VEHICLES[0]);

  // Model selected for full details / configurator
  const [detailModel, setDetailModel] = useState<VehicleModel | null>(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);

  // Test drive modal
  const [isTestDriveOpen, setIsTestDriveOpen] = useState(false);
  const [testDriveVehicle, setTestDriveVehicle] = useState<VehicleModel | undefined>(undefined);

  // Other modals / drawers
  const [isPhpInspectorOpen, setIsPhpInspectorOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);

  // Saved bookings counter for navbar badge
  const [reservationCount, setReservationCount] = useState<number>(1);

  // Open detail modal
  const handleOpenModelDetail = (model: VehicleModel) => {
    setDetailModel(model);
    setIsDetailOpen(true);
  };

  // Open test drive with optional pre-selected model
  const handleOpenTestDrive = (model?: VehicleModel) => {
    setTestDriveVehicle(model || currentModel);
    setIsTestDriveOpen(true);
  };

  // When a booking completes successfully
  const handleBookingSuccess = (booking: TestDriveBooking) => {
    setReservationCount((prev) => prev + 1);
  };

  return (
    <div className="min-h-screen bg-[#060a10] text-slate-100 font-sans selection:bg-cyan-500 selection:text-slate-950">
      {/* 1. Header Navigation Bar (Matches Attached Design) */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        lang={lang}
        setLang={setLang}
        onOpenTestDrive={() => handleOpenTestDrive(currentModel)}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenProfile={() => setIsProfileOpen(true)}
        onOpenPhpInspector={() => setIsPhpInspectorOpen(true)}
        reservationCount={reservationCount}
      />

      {/* Main Page Content */}
      <main className="w-full overflow-hidden">
        {/* 2. Hero Section (Matches Design: Skyline, S9 Sedan, Slogan, Pill CTA, Carousel Dots & Arrows) */}
        <HeroSection
          currentModel={currentModel}
          onSelectModel={setCurrentModel}
          onOpenTestDrive={() => handleOpenTestDrive(currentModel)}
          onOpenModelDetail={handleOpenModelDetail}
          lang={lang}
        />

        {/* 3. 车型系列 (Vehicle Series 4-Card Grid: S9, X7, L6, M8) */}
        <VehicleSeriesSection
          currentModel={currentModel}
          onSelectModel={setCurrentModel}
          onOpenModelDetail={handleOpenModelDetail}
          onOpenTestDrive={handleOpenTestDrive}
          lang={lang}
        />

        {/* 4. Bottom Feature Strip (Matches Design: Battery, Chip, Cloud, Shield, Mountain Motif) */}
        <TechHighlightsBar
          onSelectTech={(techId) => {
            const el = document.getElementById('tech');
            if (el) el.scrollIntoView({ behavior: 'smooth' });
          }}
          lang={lang}
        />

        {/* 5. 智能科技 (Core Technology Deep Dive: 800V SiC, L4 Autopilot, Cockpit, Safety) */}
        <SmartTechSection lang={lang} />

        {/* 6. 品牌故事 (Brand Vision: Global R&D, Shanghai, Munich, Zero Carbon Plant) */}
        <BrandStorySection lang={lang} />

        {/* 7. 服务与支持 (Charging Grid, Warranty, Roadside Assistance, Showrooms) */}
        <ServiceSupportSection
          onOpenTestDrive={() => handleOpenTestDrive(currentModel)}
          lang={lang}
        />
      </main>

      {/* 8. Global Luxury Automotive Footer */}
      <Footer
        onOpenTestDrive={() => handleOpenTestDrive(currentModel)}
        onOpenPhpInspector={() => setIsPhpInspectorOpen(true)}
        lang={lang}
      />

      {/* Interactive Modals & Drawers */}
      <TestDriveModal
        isOpen={isTestDriveOpen}
        onClose={() => setIsTestDriveOpen(false)}
        defaultVehicle={testDriveVehicle}
        onBookingSuccess={handleBookingSuccess}
        lang={lang}
      />

      <VehicleDetailModal
        vehicle={detailModel}
        isOpen={isDetailOpen}
        onClose={() => setIsDetailOpen(false)}
        onOpenTestDrive={handleOpenTestDrive}
        lang={lang}
      />

      <PhpApiInspectorModal
        isOpen={isPhpInspectorOpen}
        onClose={() => setIsPhpInspectorOpen(false)}
        lang={lang}
      />

      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onSelectVehicle={(v) => {
          setCurrentModel(v);
          handleOpenModelDetail(v);
        }}
        lang={lang}
      />

      <UserProfileDrawer
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        onOpenTestDrive={() => {
          setIsProfileOpen(false);
          handleOpenTestDrive(currentModel);
        }}
        lang={lang}
      />
    </div>
  );
}
