package com.example

import com.example.data.BootsCatalogData
import com.example.models.DeliveryMethod
import com.example.models.Department
import com.example.repositories.AdvantageRepository
import com.example.repositories.BasketRepository
import com.example.repositories.ProductRepository
import com.example.repositories.SortOption
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class BootsRetailUnitTest {

    private lateinit var productRepository: ProductRepository
    private lateinit var basketRepository: BasketRepository
    private lateinit var advantageRepository: AdvantageRepository

    @Before
    fun setUp() {
        productRepository = ProductRepository()
        basketRepository = BasketRepository()
        advantageRepository = AdvantageRepository()
    }

    @Test
    fun testBasketCalculationsAndAdvantageSavings() {
        val no7Serum = BootsCatalogData.PRODUCTS[0] // price 29.95, advantageCardPrice 24.95
        val paracetamol = BootsCatalogData.PRODUCTS[2] // price 0.95

        basketRepository.clearBasket()
        basketRepository.addToBasket(no7Serum, quantity = 1)
        basketRepository.addToBasket(paracetamol, quantity = 2)

        val calc = basketRepository.calculateBasket()

        val expectedRegular = 29.95 * 1 + 0.95 * 2 // 31.85
        val expectedEffective = 24.95 * 1 + 0.95 * 2 // 26.85
        val expectedSavings = expectedRegular - expectedEffective // 5.00

        assertEquals(expectedRegular, calc.regularSubtotal, 0.01)
        assertEquals(expectedEffective, calc.effectiveSubtotal, 0.01)
        assertEquals(expectedSavings, calc.advantageSavings, 0.01)

        // Subtotal 26.85 is >= £25, so standard delivery is FREE
        assertEquals(0.0, calc.deliveryCost, 0.01)
        assertEquals(26.85, calc.grandTotal, 0.01)

        // Points earned: 4 points per £1 spent (26.85 * 4 = 107)
        assertEquals(107, calc.pointsEarned)
    }

    @Test
    fun testPromoCodeDiscount() {
        val no7Serum = BootsCatalogData.PRODUCTS[0]
        basketRepository.clearBasket()
        basketRepository.addToBasket(no7Serum, quantity = 1)

        val success = basketRepository.applyPromoCode("BOOTS10")
        assertTrue(success)

        val calc = basketRepository.calculateBasket()
        val expectedDiscount = 24.95 * 0.10 // 2.495
        assertEquals(expectedDiscount, calc.promoDiscount, 0.01)
    }

    @Test
    fun testAdvantageCardPointsAddAndRedeem() {
        val initialBalance = advantageRepository.cardState.value.pointsBalance

        advantageRepository.addPoints(200, "Test Bonus")
        assertEquals(initialBalance + 200, advantageRepository.cardState.value.pointsBalance)

        val redeemed = advantageRepository.redeemPoints(100, "Redeemed")
        assertTrue(redeemed)
        assertEquals(initialBalance + 100, advantageRepository.cardState.value.pointsBalance)
    }

    @Test
    fun testProductSearchAndFiltering() {
        val no7Results = productRepository.searchProducts(query = "No7")
        assertTrue(no7Results.isNotEmpty())
        assertTrue(no7Results.all { it.brand.equals("No7", ignoreCase = true) || it.name.contains("No7") })

        val healthProducts = productRepository.searchProducts(query = "", department = Department.HEALTH)
        assertTrue(healthProducts.all { it.department == Department.HEALTH })

        val sortedLowToHigh = productRepository.searchProducts(query = "", sortBy = SortOption.PRICE_LOW_HIGH)
        val firstPrice = sortedLowToHigh.first().advantageCardPrice ?: sortedLowToHigh.first().price
        val lastPrice = sortedLowToHigh.last().advantageCardPrice ?: sortedLowToHigh.last().price
        assertTrue(firstPrice <= lastPrice)
    }
}
