package com.example.presentation

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocalPharmacy
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.models.Prescription
import com.example.models.PrescriptionStatus
import com.example.ui.theme.BootsBlueContainer
import com.example.ui.theme.BootsBluePrimary
import com.example.ui.theme.BootsGreen
import com.example.ui.theme.BootsGreyBackground
import com.example.ui.theme.BootsOrange
import com.example.ui.theme.BootsTextPrimary
import com.example.ui.theme.BootsTextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrescriptionsScreen(
    prescriptions: List<Prescription>,
    onRequestRepeat: (String, String, String) -> Unit
) {
    var showRequestSheet by remember { mutableStateOf(false) }
    var medNameInput by remember { mutableStateOf("") }
    var dosageInput by remember { mutableStateOf("") }
    var selectedStore by remember { mutableStateOf("Boots London Piccadilly Circus") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BootsGreyBackground)
            .padding(16.dp)
            .testTag("prescriptions_screen")
    ) {
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column {
                Text("Boots Pharmacy & NHS", style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold, color = BootsTextPrimary))
                Text("Repeat Prescriptions & Health Hub", style = MaterialTheme.typography.bodySmall.copy(color = BootsTextSecondary))
            }

            Button(
                onClick = { showRequestSheet = true },
                colors = ButtonDefaults.buttonColors(containerColor = BootsBluePrimary),
                modifier = Modifier.testTag("request_repeat_button")
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Request Repeat", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Demo Disclaimer Banner
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF8E1)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Info, contentDescription = null, tint = BootsOrange)
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "Demo Environment: All NHS & Pharmacy prescription data is simulated for demonstration purposes. Not real medical advice.",
                    style = MaterialTheme.typography.bodySmall.copy(color = BootsTextPrimary, fontWeight = FontWeight.SemiBold)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Prescriptions List
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(prescriptions, key = { it.id }) { rx ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth().testTag("prescription_card_${rx.id}")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(rx.medicationName, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = BootsTextPrimary))
                                Text("Dosage: ${rx.dosage} • ${rx.quantityText}", style = MaterialTheme.typography.bodySmall.copy(color = BootsTextSecondary))
                                Text("Pickup: ${rx.storeName}", style = MaterialTheme.typography.bodySmall.copy(color = BootsBluePrimary, fontWeight = FontWeight.Bold))
                            }

                            Surface(
                                color = if (rx.status == PrescriptionStatus.READY_FOR_COLLECTION) BootsGreen.copy(alpha = 0.15f) else BootsBlueContainer,
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(
                                    text = rx.status.label,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = if (rx.status == PrescriptionStatus.READY_FOR_COLLECTION) BootsGreen else BootsBluePrimary
                                    ),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Status Stepper Progress Timeline
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            listOf("Request Sent", "Approved GP", "Dispensing", "Ready").forEachIndexed { idx, stepName ->
                                val isPassed = rx.status.stepIndex >= idx
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Box(
                                        contentAlignment = Alignment.Center,
                                        modifier = Modifier
                                            .size(20.dp)
                                            .background(if (isPassed) BootsGreen else BootsGreyBackground, CircleShape)
                                    ) {
                                        if (isPassed) {
                                            Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(stepName, style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, color = if (isPassed) BootsTextPrimary else BootsTextSecondary))
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showRequestSheet) {
        ModalBottomSheet(
            onDismissRequest = { showRequestSheet = false },
            sheetState = rememberModalBottomSheetState()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
            ) {
                Text("Request NHS Repeat Prescription", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold))
                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = medNameInput,
                    onValueChange = { medNameInput = it },
                    label = { Text("Medication Name (e.g. Ventolin, Omeprazole)") },
                    modifier = Modifier.fillMaxWidth().testTag("rx_medname_input")
                )
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = dosageInput,
                    onValueChange = { dosageInput = it },
                    label = { Text("Dosage / Quantity (e.g. 100mcg, 28 Tablets)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        if (medNameInput.isNotBlank()) {
                            onRequestRepeat(medNameInput, dosageInput, selectedStore)
                            showRequestSheet = false
                            medNameInput = ""
                            dosageInput = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BootsBluePrimary),
                    modifier = Modifier.fillMaxWidth().testTag("submit_rx_request_button")
                ) {
                    Text("Submit Request to GP", fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }
    }
}
