package com.example.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.outlined.CardGiftcard
import androidx.compose.material.icons.outlined.CreditCard
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Menu
import androidx.compose.material.icons.outlined.ShoppingBag
import androidx.compose.material.icons.outlined.ShoppingCart
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(
    val route: String,
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    object Home : Screen("home", "Home", Icons.Filled.Home, Icons.Outlined.Home)
    object Shop : Screen("shop", "Shop", Icons.Filled.ShoppingBag, Icons.Outlined.ShoppingBag)
    object MyCard : Screen("my_card", "My Card", Icons.Filled.CreditCard, Icons.Outlined.CreditCard)
    object Basket : Screen("basket", "Basket", Icons.Filled.ShoppingCart, Icons.Outlined.ShoppingCart)
    object More : Screen("more", "More", Icons.Filled.Menu, Icons.Outlined.Menu)

    // Sub-screens
    object Search : Screen("search", "Search", Icons.Filled.Home, Icons.Outlined.Home)
    object ProductDetail : Screen("product_detail/{productId}", "Product Details", Icons.Filled.ShoppingBag, Icons.Outlined.ShoppingBag) {
        fun createRoute(productId: String) = "product_detail/$productId"
    }
    object Checkout : Screen("checkout", "Checkout", Icons.Filled.ShoppingCart, Icons.Outlined.ShoppingCart)
    object OrderConfirmation : Screen("order_confirmation/{orderId}", "Order Confirmed", Icons.Filled.ShoppingCart, Icons.Outlined.ShoppingCart) {
        fun createRoute(orderId: String) = "order_confirmation/$orderId"
    }
    object Orders : Screen("orders", "My Orders", Icons.Filled.ShoppingBag, Icons.Outlined.ShoppingBag)
    object Prescriptions : Screen("prescriptions", "Prescriptions & Health", Icons.Filled.Home, Icons.Outlined.Home)
    object StoreFinder : Screen("store_finder", "Store Finder", Icons.Filled.Home, Icons.Outlined.Home)
    object StoreMode : Screen("store_mode", "In-Store Mode", Icons.Filled.Home, Icons.Outlined.Home)
    object Wishlist : Screen("wishlist", "My Wishlist", Icons.Filled.Home, Icons.Outlined.Home)
    object ShoppingList : Screen("shopping_list", "Shopping List", Icons.Filled.Home, Icons.Outlined.Home)
    object Offers : Screen("offers", "Offers", Icons.Filled.CardGiftcard, Icons.Outlined.CardGiftcard)
    object BeautyHub : Screen("beauty_hub", "Boots Beauty Hub", Icons.Filled.Home, Icons.Outlined.Home)
    object ProductComparison : Screen("product_comparison", "Compare Products", Icons.Filled.Home, Icons.Outlined.Home)
    object Account : Screen("account", "My Account", Icons.Filled.Home, Icons.Outlined.Home)
}

val BOTTOM_BAR_SCREENS = listOf(
    Screen.Home,
    Screen.Shop,
    Screen.MyCard,
    Screen.Basket,
    Screen.More
)
