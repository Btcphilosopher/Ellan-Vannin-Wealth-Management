package com.example.presentation

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.BootsCatalogData
import com.example.models.Department
import com.example.models.Product
import com.example.ui.theme.AdvantagePink
import com.example.ui.theme.AdvantagePinkLight
import com.example.ui.theme.BootsBlueContainer
import com.example.ui.theme.BootsBluePrimary
import com.example.ui.theme.BootsBlueSecondary
import com.example.ui.theme.BootsGold
import com.example.ui.theme.BootsGreen
import com.example.ui.theme.BootsGreyBackground
import com.example.ui.theme.BootsGreyBorder
import com.example.ui.theme.BootsOrange
import com.example.ui.theme.BootsTextPrimary
import com.example.ui.theme.BootsTextSecondary
import com.example.ui.theme.PriceAdvantageBadge

@Composable
fun ProductDetailScreen(
    product: Product,
    onAddToBasket: (Product, Int, String?, String?) -> Unit,
    isWishlisted: Boolean,
    onWishlistToggle: (Product) -> Unit,
    onCompareClick: (Product) -> Unit
) {
    var quantity by remember { mutableIntStateOf(1) }
    var selectedShade by remember { mutableStateOf(product.shadeOptions.firstOrNull()) }
    var selectedSize by remember { mutableStateOf(product.sizeOptions.firstOrNull()) }
    var selectedTabIndex by remember { mutableIntStateOf(0) }

    val tabs = listOf("Description", "Key Benefits", "Ingredients", "Warnings", "Reviews")

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BootsGreyBackground)
            .testTag("product_detail_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(bottom = 90.dp)
        ) {
            // Main Product Image Preview
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(280.dp)
                    .background(Color.White)
            ) {
                AsyncImage(
                    model = product.imageUrl,
                    contentDescription = product.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Wishlist Button Top Right
                IconButton(
                    onClick = { onWishlistToggle(product) },
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(16.dp)
                        .background(Color.White, CircleShape)
                        .testTag("pdp_wishlist_button")
                ) {
                    Icon(
                        imageVector = if (isWishlisted) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Wishlist",
                        tint = if (isWishlisted) AdvantagePink else BootsTextSecondary
                    )
                }
            }

            // Product Header Info Section
            Surface(
                color = Color.White,
                shadowElevation = 1.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = product.brand.uppercase(),
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = BootsBlueSecondary,
                            letterSpacing = 1.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = product.name,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = BootsTextPrimary
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Rating & Reviews Summary
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        repeat(5) { index ->
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = null,
                                tint = if (index < product.rating.toInt()) BootsGold else BootsGreyBorder,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "%.1f (%d reviews)".format(product.rating, product.reviewCount),
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = BootsTextSecondary
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Price Advantage Banner if applicable
                    if (product.advantageCardPrice != null) {
                        Surface(
                            color = AdvantagePinkLight,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.padding(12.dp)
                            ) {
                                Column {
                                    Text(
                                        text = "Boots Price Advantage",
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = PriceAdvantageBadge
                                        )
                                    )
                                    Text(
                                        text = "Save £%.2f with Advantage Card".format(product.price - product.advantageCardPrice),
                                        style = MaterialTheme.typography.bodySmall.copy(color = BootsTextPrimary)
                                    )
                                }
                                Text(
                                    text = "£%.2f".format(product.advantageCardPrice),
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontWeight = FontWeight.Black,
                                        color = PriceAdvantageBadge
                                    )
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                    }

                    // Regular Pricing Row
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(
                            text = "£%.2f".format(product.price),
                            style = MaterialTheme.typography.headlineSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = BootsTextPrimary
                            )
                        )
                        if (product.previousPrice != null) {
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Was £%.2f".format(product.previousPrice),
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    textDecoration = TextDecoration.LineThrough,
                                    color = BootsTextSecondary
                                )
                            )
                        }
                    }

                    // Stock & Aisle Location
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = BootsGreen.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = product.stockStatus.label,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = BootsGreen
                                ),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "In Store: ${product.aisleLocation}",
                            style = MaterialTheme.typography.bodySmall.copy(color = BootsTextSecondary)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Shade & Size Selector if available
            if (product.shadeOptions.isNotEmpty() || product.sizeOptions.isNotEmpty()) {
                Surface(
                    color = Color.White,
                    shadowElevation = 1.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        if (product.shadeOptions.isNotEmpty()) {
                            Text("Select Shade", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                            Spacer(modifier = Modifier.height(8.dp))
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(product.shadeOptions) { shade ->
                                    val isSelected = shade == selectedShade
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = if (isSelected) BootsBluePrimary else BootsGreyBackground,
                                        modifier = Modifier.clickable { selectedShade = shade }
                                    ) {
                                        Text(
                                            text = shade,
                                            style = MaterialTheme.typography.bodyMedium.copy(
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                color = if (isSelected) Color.White else BootsTextPrimary
                                            ),
                                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                                        )
                                    }
                                }
                            }
                        }

                        if (product.sizeOptions.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("Select Size", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                            Spacer(modifier = Modifier.height(8.dp))
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(product.sizeOptions) { size ->
                                    val isSelected = size == selectedSize
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = if (isSelected) BootsBluePrimary else BootsGreyBackground,
                                        modifier = Modifier.clickable { selectedSize = size }
                                    ) {
                                        Text(
                                            text = size,
                                            style = MaterialTheme.typography.bodyMedium.copy(
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                color = if (isSelected) Color.White else BootsTextPrimary
                                            ),
                                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Delivery & Click & Collect Options Summary
            Surface(
                color = Color.White,
                shadowElevation = 1.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.LocalShipping, contentDescription = null, tint = BootsBluePrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text("Standard Delivery £3.95", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                            Text("FREE on orders over £25. Delivered in 2-3 working days.", style = MaterialTheme.typography.bodySmall.copy(color = BootsTextSecondary))
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Storefront, contentDescription = null, tint = BootsGreen)
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text("Click & Collect FREE", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                            Text("Ready in 2 hours at selected Boots stores.", style = MaterialTheme.typography.bodySmall.copy(color = BootsTextSecondary))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Healthcare Warning Box if age restricted or medicines
            if (product.ageRestrictionYears != null || product.department == Department.HEALTH) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF8E1)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = BootsOrange)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Pharmacy & Safety Notice",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = BootsTextPrimary)
                            )
                            if (product.ageRestrictionYears != null) {
                                Text(
                                    text = "Age restriction: Must be ${product.ageRestrictionYears} or older to purchase.",
                                    style = MaterialTheme.typography.bodySmall.copy(color = BootsTextPrimary)
                                )
                            }
                            Text(
                                text = "Always read the label and enclosed leaflet before use. If symptoms persist consult your pharmacist or doctor.",
                                style = MaterialTheme.typography.bodySmall.copy(color = BootsTextSecondary)
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Tabbed Sections (Description, Key Benefits, Ingredients, Warnings, Reviews)
            Surface(
                color = Color.White,
                shadowElevation = 1.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    TabRow(
                        selectedTabIndex = selectedTabIndex,
                        containerColor = Color.White,
                        contentColor = BootsBluePrimary
                    ) {
                        tabs.forEachIndexed { index, title ->
                            Tab(
                                selected = selectedTabIndex == index,
                                onClick = { selectedTabIndex = index },
                                text = { Text(title, fontSize = 12.sp) }
                            )
                        }
                    }

                    Box(modifier = Modifier.padding(16.dp)) {
                        when (selectedTabIndex) {
                            0 -> Column {
                                Text("Product Overview", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(product.description, style = MaterialTheme.typography.bodyMedium.copy(color = BootsTextPrimary))
                            }
                            1 -> Column {
                                Text("Key Benefits", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                                Spacer(modifier = Modifier.height(6.dp))
                                product.keyBenefits.forEach { benefit ->
                                    Row(modifier = Modifier.padding(vertical = 4.dp)) {
                                        Icon(Icons.Default.Check, contentDescription = null, tint = BootsGreen, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(benefit, style = MaterialTheme.typography.bodyMedium)
                                    }
                                }
                            }
                            2 -> Column {
                                Text("Ingredients", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    if (product.ingredients.isNotEmpty()) product.ingredients else "Detailed ingredient list available on product packaging.",
                                    style = MaterialTheme.typography.bodyMedium.copy(color = BootsTextPrimary)
                                )
                            }
                            3 -> Column {
                                Text("Usage & Warnings", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    if (product.howToUse.isNotEmpty()) "How to use:\n" + product.howToUse + "\n\n" else "",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Text(
                                    if (product.warnings.isNotEmpty()) "Warnings:\n" + product.warnings else "Avoid contact with eyes.",
                                    style = MaterialTheme.typography.bodyMedium.copy(color = BootsOrange)
                                )
                            }
                            4 -> Column {
                                Text("Customer Reviews", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                                Spacer(modifier = Modifier.height(10.dp))
                                BootsCatalogData.REVIEWS.forEach { review ->
                                    Column(modifier = Modifier.padding(vertical = 6.dp)) {
                                        Row(
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Text(review.author, fontWeight = FontWeight.Bold)
                                            Text(review.dateText, style = MaterialTheme.typography.bodySmall.copy(color = BootsTextSecondary))
                                        }
                                        Row {
                                            repeat(review.rating) {
                                                Icon(Icons.Default.Star, contentDescription = null, tint = BootsGold, modifier = Modifier.size(14.dp))
                                            }
                                        }
                                        Text(review.title, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(vertical = 2.dp))
                                        Text(review.content, style = MaterialTheme.typography.bodyMedium.copy(color = BootsTextSecondary))
                                        Divider(modifier = Modifier.padding(top = 8.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Compare Product Action Button
            OutlinedButton(
                onClick = { onCompareClick(product) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .testTag("compare_product_button")
            ) {
                Text("Compare with similar products", fontWeight = FontWeight.Bold, color = BootsBluePrimary)
            }
        }

        // Sticky Bottom Add To Basket Bar
        Surface(
            color = Color.White,
            shadowElevation = 12.dp,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.padding(16.dp)
            ) {
                // Quantity Counter
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .background(BootsGreyBackground, RoundedCornerShape(8.dp))
                        .padding(horizontal = 4.dp)
                ) {
                    IconButton(
                        onClick = { if (quantity > 1) quantity-- },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Default.Remove, contentDescription = "Decrease", modifier = Modifier.size(16.dp))
                    }
                    Text(
                        text = quantity.toString(),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                    IconButton(
                        onClick = { quantity++ },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Increase", modifier = Modifier.size(16.dp))
                    }
                }

                Spacer(modifier = Modifier.width(16.dp))

                Button(
                    onClick = { onAddToBasket(product, quantity, selectedShade, selectedSize) },
                    colors = ButtonDefaults.buttonColors(containerColor = BootsBluePrimary),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("pdp_add_to_basket_button")
                ) {
                    Icon(Icons.Default.AddShoppingCart, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Add to Basket",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Color.White)
                    )
                }
            }
        }
    }
}
