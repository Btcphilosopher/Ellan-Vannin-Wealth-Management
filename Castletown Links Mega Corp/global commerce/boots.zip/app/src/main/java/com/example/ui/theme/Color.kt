package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Boots UK Brand Palette
val BootsBluePrimary = Color(0xFF002C6C)       // Deep Boots Royal Blue
val BootsBlueSecondary = Color(0xFF005DAA)     // Classic Boots Blue
val BootsBlueDark = Color(0xFF001B44)          // Deep Navy
val BootsBlueContainer = Color(0xFFE6F0FA)     // Soft Ice Blue Tint

val AdvantagePink = Color(0xFFD6006E)          // Advantage Card Pink / Price Tag
val AdvantagePinkLight = Color(0xFFFDE6F0)     // Pink background tag
val PriceAdvantageBadge = Color(0xFFE4007D)    // Price Advantage Tag

val BootsGold = Color(0xFFFFB800)              // Rating stars & featured badge
val BootsGreen = Color(0xFF00875A)             // In Stock / Success / Prescription Ready
val BootsOrange = Color(0xFFDE350B)            // Warning / Limited Stock
val BootsGreyBackground = Color(0xFFF8F9FA)    // Light crisp background
val BootsGreySurface = Color(0xFFFFFFFF)       // Surface white
val BootsGreyBorder = Color(0xFFE2E8F0)        // Subtle borders
val BootsTextPrimary = Color(0xFF1E293B)       // Dark Slate Text
val BootsTextSecondary = Color(0xFF64748B)     // Subtitle Grey

// Dark Theme Variants
val BootsBlueDarkPrimary = Color(0xFF4D90FE)
val BootsBlueDarkSurface = Color(0xFF0F172A)
