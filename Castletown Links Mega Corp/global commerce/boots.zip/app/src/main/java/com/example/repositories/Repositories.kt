package com.example.repositories

import com.example.data.BootsCatalogData
import com.example.models.AdvantageCard
import com.example.models.AdvantageTransaction
import com.example.models.BasketItem
import com.example.models.Brand
import com.example.models.CategoryItem
import com.example.models.DeliveryMethod
import com.example.models.Department
import com.example.models.Offer
import com.example.models.Order
import com.example.models.OrderStatus
import com.example.models.Prescription
import com.example.models.PrescriptionStatus
import com.example.models.Product
import com.example.models.Store
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.UUID

class ProductRepository {

    fun getProducts(): List<Product> = BootsCatalogData.PRODUCTS

    fun getProductById(id: String): Product? {
        return BootsCatalogData.PRODUCTS.firstOrNull { it.id == id }
    }

    fun getProductsByDepartment(department: Department): List<Product> {
        return BootsCatalogData.PRODUCTS.filter { it.department == department }
    }

    fun getProductsByBrand(brandName: String): List<Product> {
        return BootsCatalogData.PRODUCTS.filter { it.brand.equals(brandName, ignoreCase = true) }
    }

    fun getBrands(): List<Brand> = BootsCatalogData.BRANDS

    fun getCategories(): List<CategoryItem> = BootsCatalogData.CATEGORIES

    fun searchProducts(
        query: String,
        department: Department? = null,
        brandFilter: String? = null,
        minPrice: Double? = null,
        maxPrice: Double? = null,
        onlyOffers: Boolean = false,
        onlyExclusives: Boolean = false,
        onlyVegan: Boolean = false,
        sortBy: SortOption = SortOption.RECOMMENDED
    ): List<Product> {
        val cleanQuery = query.trim().lowercase()

        var filtered = BootsCatalogData.PRODUCTS.filter { product ->
            val matchesQuery = cleanQuery.isEmpty() ||
                    product.name.lowercase().contains(cleanQuery) ||
                    product.brand.lowercase().contains(cleanQuery) ||
                    product.category.lowercase().contains(cleanQuery) ||
                    product.ingredients.lowercase().contains(cleanQuery) ||
                    product.description.lowercase().contains(cleanQuery)

            val matchesDept = department == null || product.department == department
            val matchesBrand = brandFilter == null || product.brand.equals(brandFilter, ignoreCase = true)
            val matchesMinPrice = minPrice == null || product.price >= minPrice
            val matchesMaxPrice = maxPrice == null || product.price <= maxPrice
            val matchesOffers = !onlyOffers || product.advantageCardPrice != null || product.previousPrice != null
            val matchesExclusive = !onlyExclusives || product.isExclusive
            val matchesVegan = !onlyVegan || product.isVegan

            matchesQuery && matchesDept && matchesBrand && matchesMinPrice && matchesMaxPrice && matchesOffers && matchesExclusive && matchesVegan
        }

        filtered = when (sortBy) {
            SortOption.PRICE_LOW_HIGH -> filtered.sortedBy { it.advantageCardPrice ?: it.price }
            SortOption.PRICE_HIGH_LOW -> filtered.sortedByDescending { it.advantageCardPrice ?: it.price }
            SortOption.RATING -> filtered.sortedByDescending { it.rating }
            SortOption.NEWEST -> filtered.sortedByDescending { it.isNew }
            SortOption.BEST_SELLING -> filtered.sortedByDescending { it.reviewCount }
            SortOption.RECOMMENDED -> filtered
        }

        return filtered
    }
}

enum class SortOption(val displayName: String) {
    RECOMMENDED("Recommended"),
    PRICE_LOW_HIGH("Price: Low to High"),
    PRICE_HIGH_LOW("Price: High to Low"),
    RATING("Highest Rated"),
    NEWEST("Newest First"),
    BEST_SELLING("Best Selling")
}

class AdvantageRepository {
    private val _cardState = MutableStateFlow(AdvantageCard())
    val cardState: StateFlow<AdvantageCard> = _cardState.asStateFlow()

    private val _offersState = MutableStateFlow(BootsCatalogData.OFFERS)
    val offersState: StateFlow<List<Offer>> = _offersState.asStateFlow()

    private val _transactionsState = MutableStateFlow(
        listOf(
            AdvantageTransaction("tx1", "Yesterday, 14:20", "Boots Piccadilly", 120, 0, "Earned on No7 & Sun Care"),
            AdvantageTransaction("tx2", "02 Nov 2026", "Boots.com Online", 60, 0, "Earned on CeraVe Cleanser"),
            AdvantageTransaction("tx3", "28 Oct 2026", "Boots Nottingham", 0, 400, "Redeemed £4.00 off order"),
            AdvantageTransaction("tx4", "15 Oct 2026", "Boots Pharmacy", 24, 0, "Earned on Paracetamol & Vitamins")
        )
    )
    val transactionsState: StateFlow<List<AdvantageTransaction>> = _transactionsState.asStateFlow()

    fun toggleOfferActivation(offerId: String) {
        _offersState.update { currentList ->
            currentList.map { offer ->
                if (offer.id == offerId) offer.copy(isActivated = !offer.isActivated) else offer
            }
        }
    }

    fun addPoints(points: Int, description: String, channel: String = "Boots.com Online") {
        if (points <= 0) return
        _cardState.update { it.copy(pointsBalance = it.pointsBalance + points) }
        val newTx = AdvantageTransaction(
            id = "tx_" + System.currentTimeMillis(),
            date = "Just now",
            storeOrChannel = channel,
            pointsEarned = points,
            pointsSpent = 0,
            description = description
        )
        _transactionsState.update { listOf(newTx) + it }
    }

    fun redeemPoints(points: Int, description: String): Boolean {
        if (_cardState.value.pointsBalance < points) return false
        _cardState.update { it.copy(pointsBalance = it.pointsBalance - points) }
        val newTx = AdvantageTransaction(
            id = "tx_" + System.currentTimeMillis(),
            date = "Just now",
            storeOrChannel = "Boots.com Online",
            pointsEarned = 0,
            pointsSpent = points,
            description = description
        )
        _transactionsState.update { listOf(newTx) + it }
        return true
    }
}

class BasketRepository {
    private val _itemsState = MutableStateFlow<List<BasketItem>>(
        listOf(
            BasketItem(product = BootsCatalogData.PRODUCTS[0], quantity = 1),
            BasketItem(product = BootsCatalogData.PRODUCTS[2], quantity = 2)
        )
    )
    val itemsState: StateFlow<List<BasketItem>> = _itemsState.asStateFlow()

    private val _promoCodeState = MutableStateFlow<String?>(null)
    val promoCodeState: StateFlow<String?> = _promoCodeState.asStateFlow()

    private val _deliveryMethodState = MutableStateFlow(DeliveryMethod.STANDARD)
    val deliveryMethodState: StateFlow<DeliveryMethod> = _deliveryMethodState.asStateFlow()

    fun addToBasket(product: Product, quantity: Int = 1, shade: String? = null, size: String? = null) {
        _itemsState.update { current ->
            val existingIndex = current.indexOfFirst {
                it.product.id == product.id && it.selectedShade == shade && it.selectedSize == size
            }
            if (existingIndex >= 0) {
                val updated = current.toMutableList()
                val existing = updated[existingIndex]
                updated[existingIndex] = existing.copy(quantity = existing.quantity + quantity)
                updated
            } else {
                current + BasketItem(product, quantity, shade, size)
            }
        }
    }

    fun updateQuantity(productId: String, quantity: Int) {
        _itemsState.update { current ->
            if (quantity <= 0) {
                current.filterNot { it.product.id == productId }
            } else {
                current.map { item ->
                    if (item.product.id == productId) item.copy(quantity = quantity) else item
                }
            }
        }
    }

    fun removeItem(productId: String) {
        _itemsState.update { current -> current.filterNot { it.product.id == productId } }
    }

    fun clearBasket() {
        _itemsState.value = emptyList()
        _promoCodeState.value = null
    }

    fun applyPromoCode(code: String): Boolean {
        return if (code.trim().equals("BOOTS10", ignoreCase = true) || code.trim().equals("BEAUTY20", ignoreCase = true)) {
            _promoCodeState.value = code.trim().uppercase()
            true
        } else {
            false
        }
    }

    fun removePromoCode() {
        _promoCodeState.value = null
    }

    fun setDeliveryMethod(method: DeliveryMethod) {
        _deliveryMethodState.value = method
    }

    fun calculateBasket(): BasketCalculation {
        val items = _itemsState.value
        val regularSubtotal = items.sumOf { it.totalRegularPrice }
        val effectiveSubtotal = items.sumOf { it.totalPrice }
        val advantageSavings = regularSubtotal - effectiveSubtotal

        val promoCode = _promoCodeState.value
        val promoDiscount = when (promoCode) {
            "BOOTS10" -> effectiveSubtotal * 0.10
            "BEAUTY20" -> effectiveSubtotal * 0.20
            else -> 0.0
        }

        val subtotalAfterPromo = (effectiveSubtotal - promoDiscount).coerceAtLeast(0.0)

        val deliveryMethod = _deliveryMethodState.value
        val deliveryCost = if (subtotalAfterPromo >= 25.00 && deliveryMethod == DeliveryMethod.STANDARD) 0.0 else deliveryMethod.cost

        val grandTotal = subtotalAfterPromo + deliveryCost
        val totalSavings = advantageSavings + promoDiscount

        // Boots Advantage Card calculation: 4 points for every £1 spent
        val pointsEarned = (subtotalAfterPromo * 4).toInt()

        return BasketCalculation(
            regularSubtotal = regularSubtotal,
            effectiveSubtotal = effectiveSubtotal,
            advantageSavings = advantageSavings,
            promoCode = promoCode,
            promoDiscount = promoDiscount,
            deliveryMethod = deliveryMethod,
            deliveryCost = deliveryCost,
            grandTotal = grandTotal,
            totalSavings = totalSavings,
            pointsEarned = pointsEarned
        )
    }
}

data class BasketCalculation(
    val regularSubtotal: Double,
    val effectiveSubtotal: Double,
    val advantageSavings: Double,
    val promoCode: String?,
    val promoDiscount: Double,
    val deliveryMethod: DeliveryMethod,
    val deliveryCost: Double,
    val grandTotal: Double,
    val totalSavings: Double,
    val pointsEarned: Int
)

class OrderRepository {
    private val _ordersState = MutableStateFlow(
        listOf(
            Order(
                id = "BOOTS-UK-984210",
                dateText = "04 Nov 2026",
                items = listOf(
                    BasketItem(product = BootsCatalogData.PRODUCTS[0], quantity = 1),
                    BasketItem(product = BootsCatalogData.PRODUCTS[3], quantity = 1)
                ),
                totalAmount = 36.95,
                savingsAmount = 9.50,
                pointsEarned = 148,
                status = OrderStatus.READY_TO_COLLECT,
                deliveryMethod = DeliveryMethod.CLICK_COLLECT,
                deliveryAddress = "Boots London Piccadilly Circus (Store Pickup)",
                trackingNumber = "GB-984210-CC",
                estimatedDeliveryDate = "Ready Today"
            ),
            Order(
                id = "BOOTS-UK-829104",
                dateText = "22 Oct 2026",
                items = listOf(
                    BasketItem(product = BootsCatalogData.PRODUCTS[6], quantity = 1)
                ),
                totalAmount = 65.00,
                savingsAmount = 95.00,
                pointsEarned = 260,
                status = OrderStatus.DELIVERED,
                deliveryMethod = DeliveryMethod.STANDARD,
                deliveryAddress = "14 Kensington Church Street, London W8 4EP",
                trackingNumber = "RM-482019-GB",
                estimatedDeliveryDate = "Delivered 24 Oct"
            )
        )
    )
    val ordersState: StateFlow<List<Order>> = _ordersState.asStateFlow()

    fun placeOrder(
        items: List<BasketItem>,
        calculation: BasketCalculation,
        deliveryAddress: String,
        deliveryMethod: DeliveryMethod
    ): Order {
        val newOrder = Order(
            id = "BOOTS-UK-" + (100000..999999).random(),
            dateText = "Today",
            items = items,
            totalAmount = calculation.grandTotal,
            savingsAmount = calculation.totalSavings,
            pointsEarned = calculation.pointsEarned,
            status = OrderStatus.PROCESSING,
            deliveryMethod = deliveryMethod,
            deliveryAddress = deliveryAddress,
            trackingNumber = "GB-" + System.currentTimeMillis().toString().takeLast(8),
            estimatedDeliveryDate = if (deliveryMethod == DeliveryMethod.EXPRESS) "Tomorrow by 1pm" else "2-3 Working Days"
        )
        _ordersState.update { listOf(newOrder) + it }
        return newOrder
    }
}

class PrescriptionRepository {
    private val _prescriptionsState = MutableStateFlow(
        listOf(
            Prescription(
                id = "RX-849201",
                patientName = "Sarah Jenkins",
                medicationName = "Ventolin Evohaler 100mcg",
                dosage = "100 micrograms / puff",
                quantityText = "2 Inhalers",
                status = PrescriptionStatus.READY_FOR_COLLECTION,
                requestDate = "04 Nov 2026",
                storeName = "Boots London Piccadilly Circus",
                isRepeat = true,
                repeatsRemaining = 4
            ),
            Prescription(
                id = "RX-739102",
                patientName = "Sarah Jenkins",
                medicationName = "Atorvastatin 20mg Tablets",
                dosage = "20mg daily",
                quantityText = "28 Tablets",
                status = PrescriptionStatus.DISPENSING,
                requestDate = "05 Nov 2026",
                storeName = "Boots London Piccadilly Circus",
                isRepeat = true,
                repeatsRemaining = 2
            )
        )
    )
    val prescriptionsState: StateFlow<List<Prescription>> = _prescriptionsState.asStateFlow()

    fun requestRepeatPrescription(medicationName: String, dosage: String, storeName: String): Prescription {
        val newRx = Prescription(
            id = "RX-" + (100000..999999).random(),
            patientName = "Sarah Jenkins",
            medicationName = medicationName,
            dosage = dosage,
            quantityText = "1 Month Supply",
            status = PrescriptionStatus.REQUEST_SENT,
            requestDate = "Today",
            storeName = storeName,
            isRepeat = true,
            repeatsRemaining = 5
        )
        _prescriptionsState.update { listOf(newRx) + it }
        return newRx
    }
}

class StoreRepository {
    private val _activeStoreState = MutableStateFlow(BootsCatalogData.STORES[0])
    val activeStoreState: StateFlow<Store> = _activeStoreState.asStateFlow()

    fun getStores(): List<Store> = BootsCatalogData.STORES

    fun searchStores(query: String): List<Store> {
        val clean = query.trim().lowercase()
        if (clean.isEmpty()) return BootsCatalogData.STORES
        return BootsCatalogData.STORES.filter {
            it.name.lowercase().contains(clean) ||
                    it.town.lowercase().contains(clean) ||
                    it.postcode.lowercase().contains(clean) ||
                    it.address.lowercase().contains(clean)
        }
    }

    fun setActiveStore(store: Store) {
        _activeStoreState.value = store
    }
}
