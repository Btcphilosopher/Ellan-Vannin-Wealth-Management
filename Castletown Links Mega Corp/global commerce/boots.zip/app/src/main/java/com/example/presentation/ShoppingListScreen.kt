package com.example.presentation

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.example.database.ShoppingListItemEntity
import com.example.ui.theme.AdvantagePink
import com.example.ui.theme.BootsBluePrimary
import com.example.ui.theme.BootsGreyBackground
import com.example.ui.theme.BootsTextPrimary
import com.example.ui.theme.BootsTextSecondary

@Composable
fun ShoppingListScreen(
    items: List<ShoppingListItemEntity>,
    onAddItem: (String, String) -> Unit,
    onToggleItem: (ShoppingListItemEntity) -> Unit,
    onDeleteItem: (Int) -> Unit,
    onClearCompleted: () -> Unit
) {
    var newItemText by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BootsGreyBackground)
            .padding(16.dp)
            .testTag("shopping_list_screen")
    ) {
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column {
                Text("Shopping List", style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold, color = BootsTextPrimary))
                Text("Room Database Persisted", style = MaterialTheme.typography.bodySmall.copy(color = BootsTextSecondary))
            }

            if (items.any { it.isChecked }) {
                TextButton(onClick = onClearCompleted) {
                    Text("Clear Done", color = AdvantagePink, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Input Card to Add Item
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = newItemText,
                    onValueChange = { newItemText = it },
                    placeholder = { Text("Add item (e.g. Paracetamol, Toothpaste)...") },
                    singleLine = true,
                    modifier = Modifier.weight(1f).testTag("add_shopping_item_input")
                )
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = {
                        if (newItemText.isNotBlank()) {
                            onAddItem(newItemText.trim(), "General")
                            newItemText = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BootsBluePrimary),
                    modifier = Modifier.testTag("add_item_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add")
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // List View
        if (items.isEmpty()) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.FormatListNumbered, contentDescription = null, tint = BootsTextSecondary, modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Your shopping list is empty", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    Text("Add items above or from product details.", style = MaterialTheme.typography.bodySmall.copy(color = BootsTextSecondary))
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(items, key = { it.id }) { item ->
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color.White,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(12.dp)
                        ) {
                            Checkbox(
                                checked = item.isChecked,
                                onCheckedChange = { onToggleItem(item) },
                                colors = CheckboxDefaults.colors(checkedColor = BootsBluePrimary)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = item.name,
                                style = MaterialTheme.typography.bodyLarge.copy(
                                    fontWeight = if (item.isChecked) FontWeight.Normal else FontWeight.Bold,
                                    textDecoration = if (item.isChecked) TextDecoration.LineThrough else TextDecoration.None,
                                    color = if (item.isChecked) BootsTextSecondary else BootsTextPrimary
                                ),
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = { onDeleteItem(item.id) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = BootsTextSecondary, modifier = Modifier.size(20.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}
