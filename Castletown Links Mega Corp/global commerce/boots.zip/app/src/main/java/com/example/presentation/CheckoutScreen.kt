package com.example.presentation

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Loyalty
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.models.BasketItem
import com.example.models.DeliveryMethod
import com.example.models.Order
import com.example.repositories.BasketCalculation
import com.example.ui.theme.AdvantagePink
import com.example.ui.theme.AdvantagePinkLight
import com.example.ui.theme.BootsBlueContainer
import com.example.ui.theme.BootsBluePrimary
import com.example.ui.theme.BootsBlueSecondary
import com.example.ui.theme.BootsGreen
import com.example.ui.theme.BootsGreyBackground
import com.example.ui.theme.BootsGreyBorder
import com.example.ui.theme.BootsTextPrimary
import com.example.ui.theme.BootsTextSecondary

@Composable
fun CheckoutScreen(
    items: List<BasketItem>,
    calculation: BasketCalculation,
    onPlaceOrder: (String, DeliveryMethod) -> Order,
    onOrderConfirmed: (Order) -> Unit
) {
    var step by remember { mutableIntStateOf(1) } // Steps 1 to 5

    // Form states
    var streetAddress by remember { mutableStateOf("14 Kensington Church Street") }
    var city by remember { mutableStateOf("London") }
    var postcode by remember { mutableStateOf("W8 4EP") }
    var selectedPayment by remember { mutableStateOf("Visa ending in 4920") }
    var selectedDeliveryMethod by remember { mutableStateOf(calculation.deliveryMethod) }

    val checkoutSteps = listOf("1. Method", "2. Address", "3. Payment", "4. Review")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BootsGreyBackground)
            .testTag("checkout_screen")
    ) {
        // Stepper Progress Header
        Surface(color = Color.White, shadowElevation = 1.dp) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp, horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                checkoutSteps.forEachIndexed { index, title ->
                    val stepNum = index + 1
                    val isCurrent = step == stepNum
                    val isDone = step > stepNum

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(24.dp)
                                .background(
                                    if (isDone) BootsGreen else if (isCurrent) BootsBluePrimary else BootsGreyBorder,
                                    CircleShape
                                )
                        ) {
                            if (isDone) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                            } else {
                                Text(stepNum.toString(), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            title,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                                color = if (isCurrent) BootsBluePrimary else BootsTextSecondary
                            )
                        )
                    }
                }
            }
        }

        // Checkout Body Steps
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            when (step) {
                1 -> {
                    // Step 1: Delivery vs Collection
                    Card(shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Select Delivery / Collection Type", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                            Spacer(modifier = Modifier.height(12.dp))

                            DeliveryOptionRow(
                                method = DeliveryMethod.STANDARD,
                                selected = selectedDeliveryMethod == DeliveryMethod.STANDARD,
                                onSelect = { selectedDeliveryMethod = DeliveryMethod.STANDARD }
                            )
                            DeliveryOptionRow(
                                method = DeliveryMethod.EXPRESS,
                                selected = selectedDeliveryMethod == DeliveryMethod.EXPRESS,
                                onSelect = { selectedDeliveryMethod = DeliveryMethod.EXPRESS }
                            )
                            DeliveryOptionRow(
                                method = DeliveryMethod.CLICK_COLLECT,
                                selected = selectedDeliveryMethod == DeliveryMethod.CLICK_COLLECT,
                                onSelect = { selectedDeliveryMethod = DeliveryMethod.CLICK_COLLECT }
                            )
                        }
                    }
                }

                2 -> {
                    // Step 2: Shipping Address
                    Card(shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Delivery Address (UK)", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                            Spacer(modifier = Modifier.height(12.dp))

                            OutlinedTextField(
                                value = streetAddress,
                                onValueChange = { streetAddress = it },
                                label = { Text("Street Address") },
                                modifier = Modifier.fillMaxWidth().testTag("checkout_address_input")
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = city,
                                    onValueChange = { city = it },
                                    label = { Text("Town / City") },
                                    modifier = Modifier.weight(1f)
                                )
                                OutlinedTextField(
                                    value = postcode,
                                    onValueChange = { postcode = it },
                                    label = { Text("Postcode") },
                                    modifier = Modifier.weight(1f).testTag("checkout_postcode_input")
                                )
                            }
                        }
                    }
                }

                3 -> {
                    // Step 3: Payment Method
                    Card(shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Select Payment Method", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                            Text("Simulated secure checkout", style = MaterialTheme.typography.bodySmall.copy(color = BootsTextSecondary))
                            Spacer(modifier = Modifier.height(12.dp))

                            listOf(
                                "Visa ending in 4920",
                                "Mastercard ending in 8812",
                                "Apple Pay",
                                "PayPal",
                                "Pay with 1,400 Advantage Points (£14.00 off)"
                            ).forEach { option ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { selectedPayment = option }
                                        .padding(vertical = 8.dp)
                                ) {
                                    RadioButton(selected = selectedPayment == option, onClick = { selectedPayment = option })
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Icon(Icons.Default.CreditCard, contentDescription = null, tint = BootsBluePrimary)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(option, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                4 -> {
                    // Step 4: Final Review & Confirmation
                    Card(shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Review Order", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold))
                            Spacer(modifier = Modifier.height(12.dp))

                            Text("Delivery Method: ${selectedDeliveryMethod.title}", fontWeight = FontWeight.Bold)
                            Text("Address: $streetAddress, $city, $postcode", style = MaterialTheme.typography.bodyMedium)
                            Text("Payment: $selectedPayment", style = MaterialTheme.typography.bodyMedium)

                            Divider(modifier = Modifier.padding(vertical = 12.dp))

                            Text("Order Total: £%.2f".format(calculation.grandTotal), style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black, color = BootsBluePrimary))
                            Text("Advantage Points Earned: +${calculation.pointsEarned} pts", style = MaterialTheme.typography.bodyMedium.copy(color = BootsGreen, fontWeight = FontWeight.Bold))
                        }
                    }
                }
            }
        }

        // Bottom Navigation Stepper Controls
        Surface(color = Color.White, shadowElevation = 8.dp, modifier = Modifier.fillMaxWidth()) {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(16.dp)
            ) {
                if (step > 1) {
                    TextButton(onClick = { step-- }) {
                        Text("Back", fontWeight = FontWeight.Bold)
                    }
                } else {
                    Spacer(modifier = Modifier.width(1.dp))
                }

                Button(
                    onClick = {
                        if (step < 4) {
                            step++
                        } else {
                            val fullAddress = "$streetAddress, $city, $postcode"
                            val order = onPlaceOrder(fullAddress, selectedDeliveryMethod)
                            onOrderConfirmed(order)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BootsBluePrimary),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.testTag("checkout_next_button")
                ) {
                    Text(if (step == 4) "Place Order" else "Continue", fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }
    }
}
