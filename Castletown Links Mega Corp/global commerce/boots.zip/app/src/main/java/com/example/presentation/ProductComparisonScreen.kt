package com.example.presentation

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.models.Product
import com.example.ui.theme.AdvantagePink
import com.example.ui.theme.BootsBluePrimary
import com.example.ui.theme.BootsGreyBackground
import com.example.ui.theme.BootsTextPrimary
import com.example.ui.theme.BootsTextSecondary
import com.example.ui.theme.PriceAdvantageBadge

@Composable
fun ProductComparisonScreen(
    productsToCompare: List<Product>
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BootsGreyBackground)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
            .testTag("product_comparison_screen")
    ) {
        Text("Product Comparison Table", style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold, color = BootsTextPrimary))
        Text("Side-by-side spec comparison", style = MaterialTheme.typography.bodySmall.copy(color = BootsTextSecondary))

        Spacer(modifier = Modifier.height(16.dp))

        if (productsToCompare.isEmpty()) {
            Text("No products selected for comparison.", style = MaterialTheme.typography.bodyMedium)
        } else {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Header Row with Product Titles
                    Row(modifier = Modifier.fillMaxWidth()) {
                        Text("Feature", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold), modifier = Modifier.weight(1f))
                        productsToCompare.forEach { p ->
                            Text(p.name, style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = BootsBluePrimary), modifier = Modifier.weight(1f))
                        }
                    }

                    Divider(modifier = Modifier.padding(vertical = 10.dp))

                    ComparisonRow("Brand", productsToCompare.map { it.brand })
                    ComparisonRow("Regular Price", productsToCompare.map { "£%.2f".format(it.price) })
                    ComparisonRow("Advantage Price", productsToCompare.map { if (it.advantageCardPrice != null) "£%.2f".format(it.advantageCardPrice) else "N/A" })
                    ComparisonRow("Rating", productsToCompare.map { "%.1f ★".format(it.rating) })
                    ComparisonRow("Boots Exclusive", productsToCompare.map { if (it.isExclusive) "Yes" else "No" })
                    ComparisonRow("Vegan Suitable", productsToCompare.map { if (it.isVegan) "Yes" else "No" })
                    ComparisonRow("Suitability", productsToCompare.map { if (it.suitability.isNotEmpty()) it.suitability else "All Skin Types" })
                }
            }
        }
    }
}

@Composable
fun ComparisonRow(featureLabel: String, values: List<String>) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(featureLabel, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = BootsTextSecondary), modifier = Modifier.weight(1f))
        values.forEach { valStr ->
            Text(valStr, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold, color = BootsTextPrimary), modifier = Modifier.weight(1f))
        }
    }
    Divider(color = BootsGreyBackground)
}
