package com.example.presentation

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.models.Product
import com.example.repositories.ProductRepository
import com.example.ui.components.ProductCard
import com.example.ui.theme.BootsBluePrimary
import com.example.ui.theme.BootsGreyBackground
import com.example.ui.theme.BootsTextPrimary
import com.example.ui.theme.BootsTextSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SearchScreen(
    productRepository: ProductRepository,
    onProductClick: (Product) -> Unit,
    onQuickAddClick: (Product) -> Unit,
    onWishlistToggle: (Product) -> Unit,
    wishlistedProductIds: Set<String>
) {
    var searchQuery by remember { mutableStateOf("") }
    val popularSearches = listOf("No7 serum", "paracetamol", "shampoo", "SPF 50", "toothpaste", "vitamin D", "CeraVe cleanser", "Dyson airwrap")
    val recentSearches = remember { mutableStateOf(listOf("No7 serum", "Paracetamol", "Sun cream")) }

    val results = remember(searchQuery) {
        if (searchQuery.trim().isEmpty()) emptyList()
        else productRepository.searchProducts(query = searchQuery)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BootsGreyBackground)
            .testTag("search_screen")
    ) {
        // Search Input Header
        Surface(
            color = BootsBluePrimary,
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(modifier = Modifier.padding(16.dp)) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search products, brands, ingredients...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_input_field")
                )
            }
        }

        if (searchQuery.trim().isEmpty()) {
            // Recent & Popular searches
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                // Recent Searches
                if (recentSearches.value.isNotEmpty()) {
                    item {
                        Column {
                            Row(
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.History, contentDescription = null, tint = BootsTextSecondary, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Recent Searches", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = BootsTextPrimary))
                                }
                                Text(
                                    text = "Clear",
                                    style = MaterialTheme.typography.labelMedium.copy(color = BootsTextSecondary, fontWeight = FontWeight.Bold),
                                    modifier = Modifier.clickable { recentSearches.value = emptyList() }
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                recentSearches.value.forEach { item ->
                                    Surface(
                                        shape = RoundedCornerShape(16.dp),
                                        color = Color.White,
                                        modifier = Modifier.clickable { searchQuery = item }
                                    ) {
                                        Text(
                                            text = item,
                                            style = MaterialTheme.typography.bodyMedium.copy(color = BootsTextPrimary),
                                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Popular Searches
                item {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.TrendingUp, contentDescription = null, tint = BootsBluePrimary, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Popular Searches", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = BootsTextPrimary))
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            popularSearches.forEach { item ->
                                Surface(
                                    shape = RoundedCornerShape(16.dp),
                                    color = Color.White,
                                    modifier = Modifier.clickable { searchQuery = item }
                                ) {
                                    Text(
                                        text = item,
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold, color = BootsBluePrimary),
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // Search Results List
            Text(
                text = "${results.size} Results for \"$searchQuery\"",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = BootsTextPrimary),
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
            )

            if (results.isEmpty()) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.fillMaxSize().padding(32.dp)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("No matching products found", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Try searching for 'No7', 'Paracetamol', 'SPF' or 'Cleanser'", style = MaterialTheme.typography.bodySmall.copy(color = BootsTextSecondary))
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(results, key = { it.id }) { product ->
                        ProductCard(
                            product = product,
                            onProductClick = onProductClick,
                            onQuickAddClick = onQuickAddClick,
                            isWishlisted = wishlistedProductIds.contains(product.id),
                            onWishlistToggle = onWishlistToggle
                        )
                    }
                }
            }
        }
    }
}
