package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.room.Room
import com.example.database.BootsDatabase
import com.example.database.ShoppingListItemEntity
import com.example.database.WishlistItemEntity
import com.example.models.Department
import com.example.models.Order
import com.example.models.Product
import com.example.models.Store
import com.example.navigation.BOTTOM_BAR_SCREENS
import com.example.navigation.Screen
import com.example.presentation.AccountScreen
import com.example.presentation.AdvantageCardScreen
import com.example.presentation.BasketScreen
import com.example.presentation.BeautyHubScreen
import com.example.presentation.CheckoutScreen
import com.example.presentation.HomeScreen
import com.example.presentation.OffersScreen
import com.example.presentation.OrdersScreen
import com.example.presentation.PrescriptionsScreen
import com.example.presentation.ProductComparisonScreen
import com.example.presentation.ProductDetailScreen
import com.example.presentation.SearchScreen
import com.example.presentation.ShopScreen
import com.example.presentation.ShoppingListScreen
import com.example.presentation.StoreFinderScreen
import com.example.presentation.StoreModeScreen
import com.example.presentation.WishlistScreen
import com.example.repositories.AdvantageRepository
import com.example.repositories.BasketRepository
import com.example.repositories.OrderRepository
import com.example.repositories.PrescriptionRepository
import com.example.repositories.ProductRepository
import com.example.repositories.StoreRepository
import com.example.ui.components.BootsBottomBar
import com.example.ui.components.BootsTopAppBar
import com.example.ui.theme.BootsTheme
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var database: BootsDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        database = Room.databaseBuilder(
            applicationContext,
            BootsDatabase::class.java,
            "boots_db"
        ).fallbackToDestructiveMigration().build()

        setContent {
            BootsTheme {
                BootsApp(database)
            }
        }
    }
}

@Composable
fun BootsApp(database: BootsDatabase) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    // Repositories
    val productRepo = remember { ProductRepository() }
    val advantageRepo = remember { AdvantageRepository() }
    val basketRepo = remember { BasketRepository() }
    val orderRepo = remember { OrderRepository() }
    val prescriptionRepo = remember { PrescriptionRepository() }
    val storeRepo = remember { StoreRepository() }

    // Navigation State
    var currentScreen by remember { mutableStateOf<Screen>(Screen.Home) }
    var previousScreenStack by remember { mutableStateOf<List<Screen>>(emptyList()) }
    var selectedProduct by remember { mutableStateOf<Product?>(null) }
    var selectedDepartmentForShop by remember { mutableStateOf(Department.BEAUTY) }
    var productsToCompare by remember { mutableStateOf<List<Product>>(emptyList()) }

    // Reactive Data Flows
    val advantageCard by advantageRepo.cardState.collectAsState()
    val offers by advantageRepo.offersState.collectAsState()
    val transactions by advantageRepo.transactionsState.collectAsState()

    val basketItems by basketRepo.itemsState.collectAsState()
    val calculation = remember(basketItems, basketRepo.promoCodeState.collectAsState().value, basketRepo.deliveryMethodState.collectAsState().value) {
        basketRepo.calculateBasket()
    }

    val orders by orderRepo.ordersState.collectAsState()
    val prescriptions by prescriptionRepo.prescriptionsState.collectAsState()
    val activeStore by storeRepo.activeStoreState.collectAsState()

    // Room DB Flows
    val shoppingListItems by database.shoppingListDao().getAllItems().collectAsState(initial = emptyList())
    val wishlistEntities by database.wishlistDao().getAllWishlistItems().collectAsState(initial = emptyList())
    val wishlistedIds = remember(wishlistEntities) { wishlistEntities.map { it.productId }.toSet() }
    val wishlistedProducts = remember(wishlistedIds) {
        productRepo.getProducts().filter { wishlistedIds.contains(it.id) }
    }

    fun navigateTo(screen: Screen) {
        previousScreenStack = previousScreenStack + currentScreen
        currentScreen = screen
    }

    fun navigateBack(): Boolean {
        return if (previousScreenStack.isNotEmpty()) {
            val last = previousScreenStack.last()
            previousScreenStack = previousScreenStack.dropLast(1)
            currentScreen = last
            true
        } else if (currentScreen != Screen.Home) {
            currentScreen = Screen.Home
            true
        } else {
            false
        }
    }

    BackHandler(enabled = currentScreen != Screen.Home) {
        navigateBack()
    }

    val isTopLevelScreen = BOTTOM_BAR_SCREENS.contains(currentScreen)

    Scaffold(
        topBar = {
            BootsTopAppBar(
                title = if (!isTopLevelScreen) currentScreen.title else null,
                showBackButton = !isTopLevelScreen,
                onBackClick = { navigateBack() },
                onSearchClick = { navigateTo(Screen.Search) },
                onAccountClick = { navigateTo(Screen.Account) },
                onNotificationsClick = {
                    scope.launch { snackbarHostState.showSnackbar("Notifications: 2 new Advantage Card offers available!") }
                }
            )
        },
        bottomBar = {
            if (isTopLevelScreen) {
                BootsBottomBar(
                    currentRoute = currentScreen.route,
                    basketItemCount = basketItems.sumOf { it.quantity },
                    onNavigate = { screen -> navigateTo(screen) }
                )
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                Screen.Home -> HomeScreen(
                    advantageCard = advantageCard,
                    onSearchClick = { navigateTo(Screen.Search) },
                    onDepartmentClick = { dept ->
                        selectedDepartmentForShop = dept
                        navigateTo(Screen.Shop)
                    },
                    onProductClick = { p ->
                        selectedProduct = p
                        navigateTo(Screen.ProductDetail)
                    },
                    onQuickAddClick = { p ->
                        basketRepo.addToBasket(p)
                        scope.launch { snackbarHostState.showSnackbar("Added ${p.name} to basket") }
                    },
                    onAdvantageCardClick = { navigateTo(Screen.MyCard) },
                    onPrescriptionsClick = { navigateTo(Screen.Prescriptions) },
                    onStoreFinderClick = { navigateTo(Screen.StoreFinder) },
                    onStoreModeClick = { navigateTo(Screen.StoreMode) },
                    onOffersClick = { navigateTo(Screen.Offers) },
                    onBeautyHubClick = { navigateTo(Screen.BeautyHub) }
                )

                Screen.Shop -> ShopScreen(
                    productRepository = productRepo,
                    initialDepartment = selectedDepartmentForShop,
                    onProductClick = { p ->
                        selectedProduct = p
                        navigateTo(Screen.ProductDetail)
                    },
                    onQuickAddClick = { p ->
                        basketRepo.addToBasket(p)
                        scope.launch { snackbarHostState.showSnackbar("Added ${p.name} to basket") }
                    },
                    onWishlistToggle = { p ->
                        scope.launch {
                            if (wishlistedIds.contains(p.id)) database.wishlistDao().removeFromWishlist(p.id)
                            else database.wishlistDao().addToWishlist(WishlistItemEntity(productId = p.id))
                        }
                    },
                    wishlistedProductIds = wishlistedIds
                )

                Screen.Search -> SearchScreen(
                    productRepository = productRepo,
                    onProductClick = { p ->
                        selectedProduct = p
                        navigateTo(Screen.ProductDetail)
                    },
                    onQuickAddClick = { p ->
                        basketRepo.addToBasket(p)
                        scope.launch { snackbarHostState.showSnackbar("Added ${p.name} to basket") }
                    },
                    onWishlistToggle = { p ->
                        scope.launch {
                            if (wishlistedIds.contains(p.id)) database.wishlistDao().removeFromWishlist(p.id)
                            else database.wishlistDao().addToWishlist(WishlistItemEntity(productId = p.id))
                        }
                    },
                    wishlistedProductIds = wishlistedIds
                )

                Screen.ProductDetail -> {
                    val p = selectedProduct ?: productRepo.getProducts()[0]
                    ProductDetailScreen(
                        product = p,
                        onAddToBasket = { prod, qty, shade, size ->
                            basketRepo.addToBasket(prod, qty, shade, size)
                            scope.launch { snackbarHostState.showSnackbar("Added $qty x ${prod.name} to basket") }
                        },
                        isWishlisted = wishlistedIds.contains(p.id),
                        onWishlistToggle = { prod ->
                            scope.launch {
                                if (wishlistedIds.contains(prod.id)) database.wishlistDao().removeFromWishlist(prod.id)
                                else database.wishlistDao().addToWishlist(WishlistItemEntity(productId = prod.id))
                            }
                        },
                        onCompareClick = { prod ->
                            productsToCompare = listOf(prod) + productRepo.getProducts().filter { it.department == prod.department && it.id != prod.id }.take(2)
                            navigateTo(Screen.ProductComparison)
                        }
                    )
                }

                Screen.MyCard -> AdvantageCardScreen(
                    advantageCard = advantageCard,
                    offers = offers,
                    transactions = transactions,
                    onToggleOffer = { offerId -> advantageRepo.toggleOfferActivation(offerId) }
                )

                Screen.Basket -> BasketScreen(
                    items = basketItems,
                    calculation = calculation,
                    onUpdateQuantity = { id, qty -> basketRepo.updateQuantity(id, qty) },
                    onRemoveItem = { id -> basketRepo.removeItem(id) },
                    onApplyPromoCode = { code -> basketRepo.applyPromoCode(code) },
                    onRemovePromoCode = { basketRepo.removePromoCode() },
                    onSetDeliveryMethod = { method -> basketRepo.setDeliveryMethod(method) },
                    onProceedToCheckout = { navigateTo(Screen.Checkout) },
                    onContinueShopping = { navigateTo(Screen.Shop) }
                )

                Screen.Checkout -> CheckoutScreen(
                    items = basketItems,
                    calculation = calculation,
                    onPlaceOrder = { address, method ->
                        val order = orderRepo.placeOrder(basketItems, calculation, address, method)
                        advantageRepo.addPoints(calculation.pointsEarned, "Earned on Order ${order.id}")
                        basketRepo.clearBasket()
                        order
                    },
                    onOrderConfirmed = { order ->
                        scope.launch { snackbarHostState.showSnackbar("Order ${order.id} Placed Successfully!") }
                        navigateTo(Screen.Orders)
                    }
                )

                Screen.Orders -> OrdersScreen(
                    orders = orders,
                    onReorderClick = { order ->
                        order.items.forEach { basketRepo.addToBasket(it.product, it.quantity) }
                        scope.launch { snackbarHostState.showSnackbar("Reordered items added to basket") }
                        navigateTo(Screen.Basket)
                    }
                )

                Screen.Prescriptions -> PrescriptionsScreen(
                    prescriptions = prescriptions,
                    onRequestRepeat = { med, dosage, store ->
                        prescriptionRepo.requestRepeatPrescription(med, dosage, store)
                        scope.launch { snackbarHostState.showSnackbar("Prescription request submitted to GP") }
                    }
                )

                Screen.StoreFinder -> StoreFinderScreen(
                    storeRepository = storeRepo,
                    onSelectStoreForInStoreMode = { store ->
                        storeRepo.setActiveStore(store)
                        navigateTo(Screen.StoreMode)
                    }
                )

                Screen.StoreMode -> StoreModeScreen(
                    activeStore = activeStore,
                    onProductClick = { p ->
                        selectedProduct = p
                        navigateTo(Screen.ProductDetail)
                    },
                    onQuickAddClick = { p ->
                        basketRepo.addToBasket(p)
                        scope.launch { snackbarHostState.showSnackbar("Added ${p.name} to basket") }
                    },
                    onShoppingListClick = { navigateTo(Screen.ShoppingList) }
                )

                Screen.Wishlist -> WishlistScreen(
                    wishlistedProducts = wishlistedProducts,
                    onProductClick = { p ->
                        selectedProduct = p
                        navigateTo(Screen.ProductDetail)
                    },
                    onQuickAddClick = { p ->
                        basketRepo.addToBasket(p)
                        scope.launch { snackbarHostState.showSnackbar("Added ${p.name} to basket") }
                    },
                    onWishlistToggle = { p ->
                        scope.launch { database.wishlistDao().removeFromWishlist(p.id) }
                    }
                )

                Screen.ShoppingList -> ShoppingListScreen(
                    items = shoppingListItems,
                    onAddItem = { name, cat ->
                        scope.launch { database.shoppingListDao().insertItem(ShoppingListItemEntity(name = name, category = cat)) }
                    },
                    onToggleItem = { item ->
                        scope.launch { database.shoppingListDao().updateItem(item.copy(isChecked = !item.isChecked)) }
                    },
                    onDeleteItem = { id ->
                        scope.launch { database.shoppingListDao().deleteItemById(id) }
                    },
                    onClearCompleted = {
                        scope.launch { database.shoppingListDao().clearCompleted() }
                    }
                )

                Screen.Offers -> OffersScreen(
                    offers = offers,
                    onToggleOffer = { id -> advantageRepo.toggleOfferActivation(id) }
                )

                Screen.BeautyHub -> BeautyHubScreen(
                    onProductClick = { p ->
                        selectedProduct = p
                        navigateTo(Screen.ProductDetail)
                    },
                    onQuickAddClick = { p ->
                        basketRepo.addToBasket(p)
                        scope.launch { snackbarHostState.showSnackbar("Added ${p.name} to basket") }
                    }
                )

                Screen.ProductComparison -> ProductComparisonScreen(
                    productsToCompare = productsToCompare.ifEmpty { productRepo.getProducts().take(2) }
                )

                Screen.Account -> AccountScreen(
                    advantageCard = advantageCard,
                    onNavigateToOrders = { navigateTo(Screen.Orders) },
                    onNavigateToPrescriptions = { navigateTo(Screen.Prescriptions) },
                    onNavigateToStoreFinder = { navigateTo(Screen.StoreFinder) },
                    onNavigateToStoreMode = { navigateTo(Screen.StoreMode) },
                    onNavigateToWishlist = { navigateTo(Screen.Wishlist) },
                    onNavigateToShoppingList = { navigateTo(Screen.ShoppingList) },
                    onNavigateToOffers = { navigateTo(Screen.Offers) },
                    onNavigateToBeautyHub = { navigateTo(Screen.BeautyHub) },
                    onNavigateToComparison = {
                        productsToCompare = productRepo.getProducts().take(2)
                        navigateTo(Screen.ProductComparison)
                    }
                )

                else -> HomeScreen(
                    advantageCard = advantageCard,
                    onSearchClick = { navigateTo(Screen.Search) },
                    onDepartmentClick = { dept ->
                        selectedDepartmentForShop = dept
                        navigateTo(Screen.Shop)
                    },
                    onProductClick = { p ->
                        selectedProduct = p
                        navigateTo(Screen.ProductDetail)
                    },
                    onQuickAddClick = { p -> basketRepo.addToBasket(p) },
                    onAdvantageCardClick = { navigateTo(Screen.MyCard) },
                    onPrescriptionsClick = { navigateTo(Screen.Prescriptions) },
                    onStoreFinderClick = { navigateTo(Screen.StoreFinder) },
                    onStoreModeClick = { navigateTo(Screen.StoreMode) },
                    onOffersClick = { navigateTo(Screen.Offers) },
                    onBeautyHubClick = { navigateTo(Screen.BeautyHub) }
                )
            }
        }
    }
}
