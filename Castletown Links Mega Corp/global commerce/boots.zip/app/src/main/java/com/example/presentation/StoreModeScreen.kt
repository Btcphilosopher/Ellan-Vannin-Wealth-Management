package com.example.presentation

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BootsCatalogData
import com.example.models.Product
import com.example.models.Store
import com.example.ui.components.AdvantageCardBanner
import com.example.ui.theme.AdvantagePink
import com.example.ui.theme.AdvantagePinkLight
import com.example.ui.theme.BootsBlueContainer
import com.example.ui.theme.BootsBluePrimary
import com.example.ui.theme.BootsGreen
import com.example.ui.theme.BootsGreyBackground
import com.example.ui.theme.BootsTextPrimary
import com.example.ui.theme.BootsTextSecondary
import com.example.ui.theme.PriceAdvantageBadge

@Composable
fun StoreModeScreen(
    activeStore: Store,
    onProductClick: (Product) -> Unit,
    onQuickAddClick: (Product) -> Unit,
    onShoppingListClick: () -> Unit
) {
    var scannedBarcodeQuery by remember { mutableStateOf("") }
    var scannedProductResult by remember { mutableStateOf<Product?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BootsGreyBackground)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("store_mode_screen")
    ) {
        // In-Store Active Mode Banner
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = BootsBluePrimary),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Storefront, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Surface(color = BootsGreen, shape = RoundedCornerShape(4.dp)) {
                        Text("IN-STORE MODE ACTIVE", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = Color.White), modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(activeStore.name, style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = Color.White))
                Text("${activeStore.address} • Open until 10:00 PM", style = MaterialTheme.typography.bodySmall.copy(color = Color.White.copy(alpha = 0.85f)))
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Barcode Shelf Price & Aisle Scanner Simulator
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.QrCodeScanner, contentDescription = null, tint = AdvantagePink, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("In-Store Barcode Scanner", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = BootsTextPrimary))
                }
                Text("Scan shelf barcodes to check Price Advantage & Aisle location", style = MaterialTheme.typography.bodySmall.copy(color = BootsTextSecondary))

                Spacer(modifier = Modifier.height(12.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = scannedBarcodeQuery,
                        onValueChange = { scannedBarcodeQuery = it },
                        placeholder = { Text("Enter or scan product name...") },
                        singleLine = true,
                        modifier = Modifier.weight(1f).testTag("barcode_scanner_input")
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val clean = scannedBarcodeQuery.trim().lowercase()
                            scannedProductResult = BootsCatalogData.PRODUCTS.firstOrNull {
                                it.name.lowercase().contains(clean) || it.brand.lowercase().contains(clean)
                            } ?: BootsCatalogData.PRODUCTS[0]
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AdvantagePink),
                        modifier = Modifier.testTag("simulate_scan_button")
                    ) {
                        Text("Scan", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }

                // Scanned Result Box
                if (scannedProductResult != null) {
                    val p = scannedProductResult!!
                    Spacer(modifier = Modifier.height(14.dp))
                    Surface(
                        color = BootsBlueContainer,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().clickable { onProductClick(p) }
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("SCANNED ITEM FOUND", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = BootsBluePrimary))
                            Text(p.name, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = BootsTextPrimary))
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text("Shelf Price: £%.2f".format(p.price), fontWeight = FontWeight.Bold)
                                if (p.advantageCardPrice != null) {
                                    Text("Advantage Price: £%.2f".format(p.advantageCardPrice), fontWeight = FontWeight.Bold, color = PriceAdvantageBadge)
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("Aisle Location: ${p.aisleLocation}", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = BootsGreen))

                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = { onQuickAddClick(p) },
                                colors = ButtonDefaults.buttonColors(containerColor = BootsBluePrimary),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Add to Basket", color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // In-Store Shopping List Shortcut Card
        Card(
            onClick = onShoppingListClick,
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth().testTag("store_shopping_list_card")
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.FormatListNumbered, contentDescription = null, tint = BootsBluePrimary)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text("My In-Store Shopping List", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        Text("Check off items as you walk through aisles", style = MaterialTheme.typography.bodySmall.copy(color = BootsTextSecondary))
                    }
                }
            }
        }
    }
}
