package com.example.presentation

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BootsCatalogData
import com.example.models.Product
import com.example.ui.components.ProductCard
import com.example.ui.theme.AdvantagePink
import com.example.ui.theme.AdvantagePinkLight
import com.example.ui.theme.BootsBlueContainer
import com.example.ui.theme.BootsBluePrimary
import com.example.ui.theme.BootsBlueSecondary
import com.example.ui.theme.BootsGreyBackground
import com.example.ui.theme.BootsTextPrimary
import com.example.ui.theme.BootsTextSecondary

@Composable
fun BeautyHubScreen(
    onProductClick: (Product) -> Unit,
    onQuickAddClick: (Product) -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var selectedSkinType by remember { mutableStateOf("Dry / Normal") }
    var selectedUndertone by remember { mutableStateOf("Neutral") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BootsGreyBackground)
            .testTag("beauty_hub_screen")
    ) {
        // Hero Header
        Surface(color = BootsBluePrimary, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("BOOTS BEAUTY HUB", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = AdvantagePinkLight, letterSpacing = 1.sp))
                Spacer(modifier = Modifier.height(4.dp))
                Text("Your Personal Beauty Studio", style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold, color = Color.White))
                Text("Shade matching, skincare routine builder & expert advice", style = MaterialTheme.typography.bodySmall.copy(color = Color.White.copy(alpha = 0.85f)))
            }
        }

        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color.White,
            contentColor = BootsBluePrimary
        ) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Shade Finder", fontWeight = FontWeight.Bold) })
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Routine Builder", fontWeight = FontWeight.Bold) })
            Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("Inspiration", fontWeight = FontWeight.Bold) })
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            when (selectedTab) {
                0 -> {
                    // Shade Finder Tool
                    Card(shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Palette, contentDescription = null, tint = AdvantagePink)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("No7 Match MADE Shade Matcher", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                            }
                            Spacer(modifier = Modifier.height(12.dp))

                            Text("1. Select Skin Undertone", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("Cool", "Neutral", "Warm").forEach { undertone ->
                                    val isSel = selectedUndertone == undertone
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = if (isSel) BootsBluePrimary else BootsGreyBackground,
                                        modifier = Modifier.weight(1f).clickable { selectedUndertone = undertone }
                                    ) {
                                        Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(10.dp)) {
                                            Text(undertone, color = if (isSel) Color.White else BootsTextPrimary, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Surface(color = AdvantagePinkLight, shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("RECOMMENDED NO7 SHADE MATCH", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = AdvantagePink))
                                    Text("Shade 140 'Calico $selectedUndertone'", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = BootsTextPrimary))
                                    Text("Perfect match for medium skin with $selectedUndertone undertones.", style = MaterialTheme.typography.bodySmall.copy(color = BootsTextSecondary))
                                }
                            }
                        }
                    }

                    Text("Recommended Shade Products", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(BootsCatalogData.PRODUCTS.filter { it.department == com.example.models.Department.BEAUTY }) { product ->
                            ProductCard(
                                product = product,
                                onProductClick = onProductClick,
                                onQuickAddClick = onQuickAddClick,
                                modifier = Modifier.width(160.dp)
                            )
                        }
                    }
                }

                1 -> {
                    // Skincare Routine Builder
                    Card(shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.WbSunny, contentDescription = null, tint = BootsBluePrimary)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("3-Step Daily Skincare Routine", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                            }
                            Spacer(modifier = Modifier.height(12.dp))

                            RoutineStepRow("Step 1: Cleanse", "CeraVe Hydrating Cleanser", "Removes impurities without stripping skin moisture.")
                            RoutineStepRow("Step 2: Treat", "No7 Protect & Perfect Serum", "Target fine lines & boost skin resilience.")
                            RoutineStepRow("Step 3: Protect", "La Roche-Posay Invisible Fluid SPF50", "Broad-spectrum daily UV shield.")
                        }
                    }
                }

                2 -> {
                    // Inspiration Guides
                    listOf(
                        "5 Steps to Glowing Skin this Winter" to "Discover dermatologist-backed tips for locking in moisture during cold months.",
                        "No7 Pro-Ageing Masterclass" to "How Matrixyl 3000 Plus™ works to restore collagen elasticity.",
                        "Fragrance Notes Demystified" to "Understanding top, heart and base notes in designer perfumes."
                    ).forEach { (title, desc) ->
                        Card(shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(title, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = BootsTextPrimary))
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(desc, style = MaterialTheme.typography.bodyMedium.copy(color = BootsTextSecondary))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RoutineStepRow(step: String, productTitle: String, desc: String) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.size(24.dp).background(BootsBlueContainer, CircleShape)) {
            Icon(Icons.Default.Check, contentDescription = null, tint = BootsBluePrimary, modifier = Modifier.size(14.dp))
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column {
            Text(step, style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = BootsBluePrimary))
            Text(productTitle, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = BootsTextPrimary))
            Text(desc, style = MaterialTheme.typography.bodySmall.copy(color = BootsTextSecondary))
        }
    }
}
