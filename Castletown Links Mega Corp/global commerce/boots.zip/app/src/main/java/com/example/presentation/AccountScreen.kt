package com.example.presentation

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Compare
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.LocalPharmacy
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.models.AdvantageCard
import com.example.ui.theme.AdvantagePink
import com.example.ui.theme.BootsBluePrimary
import com.example.ui.theme.BootsBlueSecondary
import com.example.ui.theme.BootsGreyBackground
import com.example.ui.theme.BootsTextPrimary
import com.example.ui.theme.BootsTextSecondary

@Composable
fun AccountScreen(
    advantageCard: AdvantageCard,
    onNavigateToOrders: () -> Unit,
    onNavigateToPrescriptions: () -> Unit,
    onNavigateToStoreFinder: () -> Unit,
    onNavigateToStoreMode: () -> Unit,
    onNavigateToWishlist: () -> Unit,
    onNavigateToShoppingList: () -> Unit,
    onNavigateToOffers: () -> Unit,
    onNavigateToBeautyHub: () -> Unit,
    onNavigateToComparison: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BootsGreyBackground)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("account_screen")
    ) {
        // User Profile Header Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = BootsBluePrimary),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.size(56.dp).background(Color.White, CircleShape)
                ) {
                    Icon(Icons.Default.Person, contentDescription = null, tint = BootsBluePrimary, modifier = Modifier.size(32.dp))
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(advantageCard.memberName, style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = Color.White))
                    Text(advantageCard.tier, style = MaterialTheme.typography.bodySmall.copy(color = AdvantagePink, fontWeight = FontWeight.Bold))
                    Text("Advantage Points: ${advantageCard.pointsBalance} pts", style = MaterialTheme.typography.bodySmall.copy(color = Color.White.copy(alpha = 0.9f)))
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Account Options Navigation Group
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(vertical = 8.dp)) {
                AccountOptionRow("My Orders & History", Icons.Default.ShoppingBag, onNavigateToOrders)
                Divider(modifier = Modifier.padding(horizontal = 16.dp))
                AccountOptionRow("Repeat Prescriptions", Icons.Default.LocalPharmacy, onNavigateToPrescriptions)
                Divider(modifier = Modifier.padding(horizontal = 16.dp))
                AccountOptionRow("Store Locator", Icons.Default.Storefront, onNavigateToStoreFinder)
                Divider(modifier = Modifier.padding(horizontal = 16.dp))
                AccountOptionRow("In-Store Mode Scanner", Icons.Default.Storefront, onNavigateToStoreMode)
                Divider(modifier = Modifier.padding(horizontal = 16.dp))
                AccountOptionRow("My Saved Wishlist", Icons.Default.Favorite, onNavigateToWishlist)
                Divider(modifier = Modifier.padding(horizontal = 16.dp))
                AccountOptionRow("In-Store Shopping List", Icons.Default.FormatListNumbered, onNavigateToShoppingList)
                Divider(modifier = Modifier.padding(horizontal = 16.dp))
                AccountOptionRow("Advantage Offers", Icons.Default.LocalOffer, onNavigateToOffers)
                Divider(modifier = Modifier.padding(horizontal = 16.dp))
                AccountOptionRow("Boots Beauty Hub & Shade Finder", Icons.Default.AutoAwesome, onNavigateToBeautyHub)
                Divider(modifier = Modifier.padding(horizontal = 16.dp))
                AccountOptionRow("Product Comparison Tool", Icons.Default.Compare, onNavigateToComparison)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Settings & Help
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(vertical = 8.dp)) {
                AccountOptionRow("Privacy & Accessibility Settings", Icons.Default.Lock, onClick = {})
                Divider(modifier = Modifier.padding(horizontal = 16.dp))
                AccountOptionRow("Help & Customer FAQs", Icons.Default.HelpOutline, onClick = {})
                Divider(modifier = Modifier.padding(horizontal = 16.dp))
                AccountOptionRow("Sign Out", Icons.Default.Logout, onClick = {}, iconColor = AdvantagePink, textColor = AdvantagePink)
            }
        }
    }
}

@Composable
fun AccountOptionRow(
    title: String,
    icon: ImageVector,
    onClick: () -> Unit,
    iconColor: Color = BootsBluePrimary,
    textColor: Color = BootsTextPrimary
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = iconColor, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(12.dp))
            Text(title, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold, color = textColor))
        }
        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = BootsTextSecondary, modifier = Modifier.size(18.dp))
    }
}
