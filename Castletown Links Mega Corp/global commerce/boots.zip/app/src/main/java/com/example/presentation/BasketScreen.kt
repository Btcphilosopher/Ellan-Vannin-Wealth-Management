package com.example.presentation

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Loyalty
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.models.BasketItem
import com.example.models.DeliveryMethod
import com.example.repositories.BasketCalculation
import com.example.ui.theme.AdvantagePink
import com.example.ui.theme.AdvantagePinkLight
import com.example.ui.theme.BootsBlueContainer
import com.example.ui.theme.BootsBluePrimary
import com.example.ui.theme.BootsBlueSecondary
import com.example.ui.theme.BootsGreen
import com.example.ui.theme.BootsGreyBackground
import com.example.ui.theme.BootsGreyBorder
import com.example.ui.theme.BootsTextPrimary
import com.example.ui.theme.BootsTextSecondary
import com.example.ui.theme.PriceAdvantageBadge

@Composable
fun BasketScreen(
    items: List<BasketItem>,
    calculation: BasketCalculation,
    onUpdateQuantity: (String, Int) -> Unit,
    onRemoveItem: (String) -> Unit,
    onApplyPromoCode: (String) -> Boolean,
    onRemovePromoCode: () -> Unit,
    onSetDeliveryMethod: (DeliveryMethod) -> Unit,
    onProceedToCheckout: () -> Unit,
    onContinueShopping: () -> Unit
) {
    var promoInput by remember { mutableStateOf("") }
    var promoErrorText by remember { mutableStateOf<String?>(null) }

    if (items.isEmpty()) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .fillMaxSize()
                .background(BootsGreyBackground)
                .padding(32.dp)
                .testTag("empty_basket_view")
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.ShoppingBag, contentDescription = null, tint = BootsTextSecondary, modifier = Modifier.size(64.dp))
                Spacer(modifier = Modifier.height(16.dp))
                Text("Your basket is empty", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = BootsTextPrimary))
                Spacer(modifier = Modifier.height(8.dp))
                Text("Explore thousands of beauty, health and pharmacy products.", style = MaterialTheme.typography.bodyMedium.copy(color = BootsTextSecondary))
                Spacer(modifier = Modifier.height(24.dp))
                Button(
                    onClick = onContinueShopping,
                    colors = ButtonDefaults.buttonColors(containerColor = BootsBluePrimary),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.testTag("start_shopping_button")
                ) {
                    Text("Start Shopping", fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }
        return
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BootsGreyBackground)
            .testTag("basket_screen")
    ) {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 90.dp)
        ) {
            // Header Title
            item {
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Your Basket (${items.sumOf { it.quantity }})", style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold, color = BootsTextPrimary))
                    TextButton(onClick = onContinueShopping) {
                        Text("Add Items", color = BootsBlueSecondary, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Advantage Card Points Earned Banner
            item {
                Surface(
                    color = BootsBlueContainer,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Loyalty, contentDescription = null, tint = BootsBluePrimary)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Boots Advantage Card Points", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = BootsBluePrimary))
                            Text("You will earn +${calculation.pointsEarned} Advantage Points on this order!", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = BootsTextPrimary))
                        }
                    }
                }
            }

            // Items List
            items(items, key = { it.product.id }) { item ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Box(
                            modifier = Modifier
                                .size(80.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(BootsGreyBackground)
                        ) {
                            AsyncImage(
                                model = item.product.imageUrl,
                                contentDescription = item.product.name,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.matchParentSize()
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(item.product.brand.uppercase(), style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = BootsBlueSecondary))
                            Text(item.product.name, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = BootsTextPrimary), maxLines = 2)

                            if (item.selectedShade != null || item.selectedSize != null) {
                                Text(
                                    listOfNotNull(item.selectedShade, item.selectedSize).joinToString(" • "),
                                    style = MaterialTheme.typography.bodySmall.copy(color = BootsTextSecondary)
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    "£%.2f".format(item.totalPrice),
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = BootsTextPrimary)
                                )

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(
                                        onClick = { onUpdateQuantity(item.product.id, item.quantity - 1) },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(Icons.Default.Remove, contentDescription = "Decrease", modifier = Modifier.size(16.dp))
                                    }
                                    Text(item.quantity.toString(), fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp))
                                    IconButton(
                                        onClick = { onUpdateQuantity(item.product.id, item.quantity + 1) },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = "Increase", modifier = Modifier.size(16.dp))
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    IconButton(
                                        onClick = { onRemoveItem(item.product.id) },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(Icons.Default.DeleteOutline, contentDescription = "Remove", tint = AdvantagePink, modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Promo Code Section
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Promotional Code", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        Spacer(modifier = Modifier.height(8.dp))

                        if (calculation.promoCode != null) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(AdvantagePinkLight, RoundedCornerShape(8.dp))
                                    .padding(12.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = AdvantagePink)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Promo Code '${calculation.promoCode}' Applied!", fontWeight = FontWeight.Bold, color = AdvantagePink)
                                }
                                TextButton(onClick = onRemovePromoCode) {
                                    Text("Remove", color = AdvantagePink, fontWeight = FontWeight.Bold)
                                }
                            }
                        } else {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                OutlinedTextField(
                                    value = promoInput,
                                    onValueChange = {
                                        promoInput = it
                                        promoErrorText = null
                                    },
                                    placeholder = { Text("Try BOOTS10 or BEAUTY20") },
                                    singleLine = true,
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("promo_code_input")
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Button(
                                    onClick = {
                                        val success = onApplyPromoCode(promoInput)
                                        if (!success) {
                                            promoErrorText = "Invalid promo code. Try BOOTS10"
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = BootsBluePrimary),
                                    modifier = Modifier.testTag("apply_promo_button")
                                ) {
                                    Text("Apply", color = Color.White)
                                }
                            }
                            if (promoErrorText != null) {
                                Text(promoErrorText!!, style = MaterialTheme.typography.bodySmall.copy(color = AdvantagePink), modifier = Modifier.padding(top = 4.dp))
                            }
                        }
                    }
                }
            }

            // Delivery Method Option Selector
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Delivery / Collection Method", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        Spacer(modifier = Modifier.height(8.dp))

                        DeliveryOptionRow(
                            method = DeliveryMethod.STANDARD,
                            selected = calculation.deliveryMethod == DeliveryMethod.STANDARD,
                            onSelect = { onSetDeliveryMethod(DeliveryMethod.STANDARD) }
                        )
                        DeliveryOptionRow(
                            method = DeliveryMethod.EXPRESS,
                            selected = calculation.deliveryMethod == DeliveryMethod.EXPRESS,
                            onSelect = { onSetDeliveryMethod(DeliveryMethod.EXPRESS) }
                        )
                        DeliveryOptionRow(
                            method = DeliveryMethod.CLICK_COLLECT,
                            selected = calculation.deliveryMethod == DeliveryMethod.CLICK_COLLECT,
                            onSelect = { onSetDeliveryMethod(DeliveryMethod.CLICK_COLLECT) }
                        )
                    }
                }
            }

            // Order Summary Breakdown Card
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Order Summary", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        Spacer(modifier = Modifier.height(12.dp))

                        SummaryRow("Subtotal", "£%.2f".format(calculation.regularSubtotal))
                        if (calculation.advantageSavings > 0) {
                            SummaryRow("Price Advantage Savings", "-£%.2f".format(calculation.advantageSavings), isDiscount = true)
                        }
                        if (calculation.promoDiscount > 0) {
                            SummaryRow("Promo Discount (${calculation.promoCode})", "-£%.2f".format(calculation.promoDiscount), isDiscount = true)
                        }
                        SummaryRow("Delivery (${calculation.deliveryMethod.title})", if (calculation.deliveryCost == 0.0) "FREE" else "£%.2f".format(calculation.deliveryCost))

                        Divider(modifier = Modifier.padding(vertical = 12.dp))

                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Total to Pay", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black, color = BootsTextPrimary))
                            Text("£%.2f".format(calculation.grandTotal), style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black, color = BootsBluePrimary))
                        }
                    }
                }
            }
        }

        // Bottom Sticky Checkout Action Bar
        Surface(
            color = Color.White,
            shadowElevation = 12.dp,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.padding(16.dp)
            ) {
                Column {
                    Text("Total Amount", style = MaterialTheme.typography.labelSmall.copy(color = BootsTextSecondary))
                    Text("£%.2f".format(calculation.grandTotal), style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black, color = BootsBluePrimary))
                }

                Button(
                    onClick = onProceedToCheckout,
                    colors = ButtonDefaults.buttonColors(containerColor = BootsBluePrimary),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier
                        .height(48.dp)
                        .testTag("checkout_button")
                ) {
                    Text("Proceed to Checkout", fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}

@Composable
fun DeliveryOptionRow(
    method: DeliveryMethod,
    selected: Boolean,
    onSelect: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelect() }
            .padding(vertical = 6.dp)
    ) {
        RadioButton(
            selected = selected,
            onClick = onSelect,
            colors = RadioButtonDefaults.colors(selectedColor = BootsBluePrimary)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(method.title, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
            Text(method.speed, style = MaterialTheme.typography.bodySmall.copy(color = BootsTextSecondary))
        }
        Text(if (method.cost == 0.0) "FREE" else "£%.2f".format(method.cost), fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SummaryRow(label: String, value: String, isDiscount: Boolean = false) {
    Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium.copy(color = BootsTextSecondary))
        Text(value, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = if (isDiscount) AdvantagePink else BootsTextPrimary))
    }
}
