package com.example.models

enum class Department(val displayName: String) {
    BEAUTY("Beauty"),
    HEALTH("Health"),
    WELLNESS("Wellness"),
    BABY("Baby"),
    TOILETRIES("Toiletries"),
    DENTAL("Dental"),
    MEN("Men"),
    ELECTRICAL("Electrical"),
    GIFTS("Gifts")
}

data class Product(
    val id: String,
    val name: String,
    val brand: String,
    val department: Department,
    val category: String,
    val subcategory: String = "",
    val price: Double,
    val previousPrice: Double? = null,
    val advantageCardPrice: Double? = null,
    val rating: Float,
    val reviewCount: Int,
    val stockStatus: StockStatus = StockStatus.IN_STOCK,
    val imageUrl: String,
    val isNew: Boolean = false,
    val isExclusive: Boolean = false,
    val isVegan: Boolean = false,
    val isCrueltyFree: Boolean = false,
    val description: String,
    val keyBenefits: List<String> = emptyList(),
    val howToUse: String = "",
    val ingredients: String = "",
    val warnings: String = "",
    val specifications: Map<String, String> = emptyMap(),
    val shadeOptions: List<String> = emptyList(),
    val sizeOptions: List<String> = emptyList(),
    val finish: String = "",
    val suitability: String = "",
    val ageRestrictionYears: Int? = null,
    val aisleLocation: String = "Aisle 3"
)

enum class StockStatus(val label: String) {
    IN_STOCK("In Stock"),
    LOW_STOCK("Low Stock - Order Soon"),
    CLICK_COLLECT_ONLY("Click & Collect Only"),
    OUT_OF_STOCK("Out of Stock")
}

data class Brand(
    val id: String,
    val name: String,
    val logoText: String,
    val tagLine: String,
    val category: Department,
    val isPopular: Boolean = true
)

data class CategoryItem(
    val id: String,
    val name: String,
    val department: Department,
    val iconName: String
)

data class Offer(
    val id: String,
    val title: String,
    val department: Department,
    val description: String,
    val advantageCardRequired: Boolean = true,
    val expiryDateText: String = "Valid until 30 Nov",
    val promoCode: String? = null,
    val discountPercent: Int? = null,
    val isActivated: Boolean = false,
    val imageUrl: String = ""
)

data class AdvantageCard(
    val cardNumber: String = "6332 0192 8471 0029",
    val memberName: String = "Sarah Jenkins",
    val pointsBalance: Int = 1480,
    val tier: String = "Advantage Platinum",
    val savingsThisYear: Double = 64.50
) {
    val pointsCashValue: Double
        get() = pointsBalance * 0.01 // 100 points = £1.00
}

data class AdvantageTransaction(
    val id: String,
    val date: String,
    val storeOrChannel: String,
    val pointsEarned: Int,
    val pointsSpent: Int,
    val description: String
)

data class BasketItem(
    val product: Product,
    var quantity: Int = 1,
    val selectedShade: String? = null,
    val selectedSize: String? = null
) {
    val effectiveUnitPrice: Double
        get() = product.advantageCardPrice ?: product.price

    val totalPrice: Double
        get() = effectiveUnitPrice * quantity

    val totalRegularPrice: Double
        get() = product.price * quantity

    val totalSavings: Double
        get() = (product.price - effectiveUnitPrice) * quantity
}

enum class DeliveryMethod(val title: String, val cost: Double, val speed: String) {
    STANDARD("Standard Delivery", 3.95, "2-3 Working Days (FREE over £25)"),
    EXPRESS("Next Day Express", 5.95, "Order before 8pm for tomorrow"),
    CLICK_COLLECT("Click & Collect", 0.00, "Ready in 2 hours at selected store")
}

data class Order(
    val id: String,
    val dateText: String,
    val items: List<BasketItem>,
    val totalAmount: Double,
    val savingsAmount: Double,
    val pointsEarned: Int,
    val status: OrderStatus,
    val deliveryMethod: DeliveryMethod,
    val deliveryAddress: String,
    val trackingNumber: String,
    val estimatedDeliveryDate: String
)

enum class OrderStatus(val label: String, val stepIndex: Int) {
    RECEIVED("Order Received", 0),
    PROCESSING("Processing", 1),
    DISPATCHED("Dispatched", 2),
    OUT_FOR_DELIVERY("Out for Delivery", 3),
    READY_TO_COLLECT("Ready to Collect", 4),
    DELIVERED("Delivered", 4)
}

data class Store(
    val id: String,
    val name: String,
    val address: String,
    val postcode: String,
    val town: String,
    val distanceMiles: Double,
    val openingHoursToday: String,
    val pharmacyHoursToday: String,
    val hasOpticians: Boolean = true,
    val hasHearingCare: Boolean = true,
    val hasClickAndCollect: Boolean = true,
    val hasConsultationRoom: Boolean = true,
    val phone: String = "0115 941 1200"
)

data class Prescription(
    val id: String,
    val patientName: String,
    val medicationName: String,
    val dosage: String,
    val quantityText: String,
    val status: PrescriptionStatus,
    val requestDate: String,
    val storeName: String,
    val isRepeat: Boolean = true,
    val repeatsRemaining: Int = 3
)

enum class PrescriptionStatus(val label: String, val stepIndex: Int) {
    REQUEST_SENT("Request Sent to GP", 0),
    APPROVED_BY_GP("Approved by GP", 1),
    DISPENSING("Dispensing in Pharmacy", 2),
    READY_FOR_COLLECTION("Ready to Collect", 3),
    COLLECTED("Collected", 4)
}

data class Review(
    val id: String,
    val author: String,
    val rating: Int,
    val title: String,
    val content: String,
    val dateText: String,
    val verifiedPurchase: Boolean = true
)

data class BeautyRoutine(
    val id: String,
    val title: String,
    val timeOfDay: String, // "Morning" or "Evening"
    val description: String,
    val products: List<Product>
)
