package com.example.presentation

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Loyalty
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.models.AdvantageCard
import com.example.models.AdvantageTransaction
import com.example.models.Offer
import com.example.ui.theme.AdvantagePink
import com.example.ui.theme.AdvantagePinkLight
import com.example.ui.theme.BootsBluePrimary
import com.example.ui.theme.BootsBlueSecondary
import com.example.ui.theme.BootsGreen
import com.example.ui.theme.BootsGreyBackground
import com.example.ui.theme.BootsGreyBorder
import com.example.ui.theme.BootsTextPrimary
import com.example.ui.theme.BootsTextSecondary
import com.example.ui.theme.PriceAdvantageBadge

@Composable
fun AdvantageCardScreen(
    advantageCard: AdvantageCard,
    offers: List<Offer>,
    transactions: List<AdvantageTransaction>,
    onToggleOffer: (String) -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var isExpandedCardVisible by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BootsGreyBackground)
            .testTag("advantage_card_screen")
    ) {
        // Expanded Digital Card Modal / Card Preview
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = BootsBluePrimary),
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .clickable { isExpandedCardVisible = !isExpandedCardVisible }
                .testTag("digital_advantage_card_card")
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(color = AdvantagePink, shape = RoundedCornerShape(4.dp)) {
                            Text(" ADVANTAGE ", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = Color.White), modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("CARD", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black, color = Color.White, letterSpacing = 2.sp))
                    }
                    Text(advantageCard.tier, style = MaterialTheme.typography.labelMedium.copy(color = AdvantagePinkLight, fontWeight = FontWeight.Bold))
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Text("MEMBER NAME", style = MaterialTheme.typography.labelSmall.copy(color = Color.White.copy(alpha = 0.7f)))
                        Text(advantageCard.memberName, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Color.White))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(advantageCard.cardNumber, style = MaterialTheme.typography.bodyMedium.copy(color = Color.White.copy(alpha = 0.9f)))
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text("BALANCE", style = MaterialTheme.typography.labelSmall.copy(color = Color.White.copy(alpha = 0.7f)))
                        Text("${advantageCard.pointsBalance} pts", style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Black, color = Color.White))
                        Text("£%.2f value".format(advantageCard.pointsCashValue), style = MaterialTheme.typography.titleSmall.copy(color = AdvantagePinkLight, fontWeight = FontWeight.Bold))
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Barcode Simulator View
                Surface(
                    color = Color.White,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(12.dp)
                    ) {
                        SimulatedBarcodeView()
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = advantageCard.cardNumber,
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = BootsTextPrimary,
                                letterSpacing = 3.sp
                            )
                        )
                        Text(
                            text = "Scan at till or online checkout to earn 4 pts per £1",
                            style = MaterialTheme.typography.labelSmall.copy(color = BootsTextSecondary)
                        )
                    }
                }
            }
        }

        // Annual Savings Counter Banner
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = AdvantagePinkLight),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Savings, contentDescription = null, tint = PriceAdvantageBadge, modifier = Modifier.size(28.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("Your Price Advantage Savings", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = PriceAdvantageBadge))
                    Text("You've saved £%.2f this year with Advantage Card prices!".format(advantageCard.savingsThisYear), style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = BootsTextPrimary))
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Tabs: Offers vs Points History
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color.White,
            contentColor = BootsBluePrimary
        ) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Your Offers (${offers.size})", fontWeight = FontWeight.Bold) })
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Points History", fontWeight = FontWeight.Bold) })
        }

        if (selectedTab == 0) {
            // Offers List
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(offers, key = { it.id }) { offer ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Top,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = offer.department.displayName.uppercase(),
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = BootsBlueSecondary)
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = offer.title,
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = BootsTextPrimary)
                                    )
                                }

                                Button(
                                    onClick = { onToggleOffer(offer.id) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (offer.isActivated) BootsGreen else BootsBluePrimary
                                    ),
                                    shape = RoundedCornerShape(20.dp),
                                    modifier = Modifier.testTag("activate_offer_button_${offer.id}")
                                ) {
                                    if (offer.isActivated) {
                                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Activated", fontSize = 12.sp)
                                    } else {
                                        Text("Activate", fontSize = 12.sp)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(offer.description, style = MaterialTheme.typography.bodyMedium.copy(color = BootsTextSecondary))

                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(offer.expiryDateText, style = MaterialTheme.typography.labelSmall.copy(color = AdvantagePink, fontWeight = FontWeight.Bold))
                                if (offer.promoCode != null) {
                                    Text("Code: ${offer.promoCode}", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // Points History List
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(transactions, key = { it.id }) { tx ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color.White,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.padding(14.dp)
                        ) {
                            Column {
                                Text(tx.description, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = BootsTextPrimary))
                                Text("${tx.storeOrChannel} • ${tx.date}", style = MaterialTheme.typography.bodySmall.copy(color = BootsTextSecondary))
                            }

                            if (tx.pointsEarned > 0) {
                                Text("+${tx.pointsEarned} pts", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = BootsGreen))
                            } else {
                                Text("-${tx.pointsSpent} pts", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = AdvantagePink))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SimulatedBarcodeView() {
    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .padding(horizontal = 8.dp)
    ) {
        val width = size.width
        val barCount = 42
        val step = width / barCount
        var x = 0f

        val pattern = listOf(3, 1, 2, 4, 1, 3, 2, 1, 4, 2, 1, 3, 4, 1, 2, 3, 1, 4, 2, 1, 3, 2, 4, 1, 3, 2, 1, 4, 2, 1, 3, 4, 1, 2, 3, 1, 4, 2, 1, 3, 2, 4)

        for (i in pattern.indices) {
            val barWidth = pattern[i] * (step / 3)
            val isBlack = i % 2 == 0
            if (isBlack) {
                drawRect(
                    color = Color.Black,
                    topLeft = Offset(x, 0f),
                    size = Size(barWidth, size.height)
                )
            }
            x += barWidth + (step / 4)
        }
    }
}
