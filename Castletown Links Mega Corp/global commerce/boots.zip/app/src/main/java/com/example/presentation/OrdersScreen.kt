package com.example.presentation

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.models.Order
import com.example.models.OrderStatus
import com.example.models.Product
import com.example.ui.theme.BootsBluePrimary
import com.example.ui.theme.BootsGreen
import com.example.ui.theme.BootsGreyBackground
import com.example.ui.theme.BootsTextPrimary
import com.example.ui.theme.BootsTextSecondary

@Composable
fun OrdersScreen(
    orders: List<Order>,
    onReorderClick: (Order) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BootsGreyBackground)
            .padding(16.dp)
            .testTag("orders_screen")
    ) {
        Text("My Orders (${orders.size})", style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold, color = BootsTextPrimary))
        Spacer(modifier = Modifier.height(16.dp))

        if (orders.isEmpty()) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                Text("No past orders found.", style = MaterialTheme.typography.bodyLarge)
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(orders, key = { it.id }) { order ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth().testTag("order_card_${order.id}")
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column {
                                    Text(order.id, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = BootsTextPrimary))
                                    Text(order.dateText, style = MaterialTheme.typography.bodySmall.copy(color = BootsTextSecondary))
                                }

                                Surface(
                                    color = if (order.status == OrderStatus.DELIVERED || order.status == OrderStatus.READY_TO_COLLECT) BootsGreen.copy(alpha = 0.15f) else BootsBluePrimary.copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text(
                                        text = order.status.label,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = if (order.status == OrderStatus.DELIVERED || order.status == OrderStatus.READY_TO_COLLECT) BootsGreen else BootsBluePrimary
                                        ),
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Order Items Summary
                            order.items.forEach { item ->
                                Row(
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                                ) {
                                    Text("${item.quantity}x ${item.product.name}", style = MaterialTheme.typography.bodyMedium.copy(color = BootsTextPrimary), modifier = Modifier.weight(1f))
                                    Text("£%.2f".format(item.totalPrice), style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                                }
                            }

                            Divider(modifier = Modifier.padding(vertical = 10.dp))

                            Row(
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column {
                                    Text("Total Paid: £%.2f".format(order.totalAmount), style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                                    Text("+${order.pointsEarned} Advantage Points", style = MaterialTheme.typography.bodySmall.copy(color = BootsGreen, fontWeight = FontWeight.Bold))
                                }

                                OutlinedButton(
                                    onClick = { onReorderClick(order) },
                                    modifier = Modifier.testTag("reorder_button_${order.id}")
                                ) {
                                    Icon(Icons.Default.Replay, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Buy Again", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
