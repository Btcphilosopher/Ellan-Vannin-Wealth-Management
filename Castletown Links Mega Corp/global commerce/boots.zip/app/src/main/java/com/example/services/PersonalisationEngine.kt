package com.example.services

import com.example.data.BootsCatalogData
import com.example.models.Department
import com.example.models.Offer
import com.example.models.Product

object PersonalisationEngine {

    fun getRecommendedForYou(favoriteDepartment: Department = Department.BEAUTY): List<Product> {
        return BootsCatalogData.PRODUCTS.filter {
            it.department == favoriteDepartment || it.rating >= 4.8f
        }.take(6)
    }

    fun getBuyAgainProducts(): List<Product> {
        return listOf(
            BootsCatalogData.PRODUCTS[0], // No7 Serum
            BootsCatalogData.PRODUCTS[2], // Paracetamol
            BootsCatalogData.PRODUCTS[3], // CeraVe Cleanser
            BootsCatalogData.PRODUCTS[7]  // Vitamin D3
        )
    }

    fun getYouMayAlsoLike(currentProduct: Product? = null): List<Product> {
        if (currentProduct == null) {
            return BootsCatalogData.PRODUCTS.take(6)
        }
        return BootsCatalogData.PRODUCTS.filter {
            it.id != currentProduct.id && (it.department == currentProduct.department || it.brand == currentProduct.brand)
        }.take(6)
    }

    fun getBecauseYouBought(boughtBrand: String = "No7"): List<Product> {
        return BootsCatalogData.PRODUCTS.filter {
            it.brand.equals(boughtBrand, ignoreCase = true) || it.isExclusive
        }.take(4)
    }

    fun getPersonalisedOffers(): List<Offer> {
        return BootsCatalogData.OFFERS
    }
}
