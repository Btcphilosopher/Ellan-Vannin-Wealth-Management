package com.example.presentation

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.LocalPharmacy
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.models.Store
import com.example.repositories.StoreRepository
import com.example.ui.theme.AdvantagePink
import com.example.ui.theme.BootsBluePrimary
import com.example.ui.theme.BootsBlueSecondary
import com.example.ui.theme.BootsGreen
import com.example.ui.theme.BootsGreyBackground
import com.example.ui.theme.BootsTextPrimary
import com.example.ui.theme.BootsTextSecondary

@Composable
fun StoreFinderScreen(
    storeRepository: StoreRepository,
    onSelectStoreForInStoreMode: (Store) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val stores = remember(searchQuery) { storeRepository.searchStores(searchQuery) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BootsGreyBackground)
            .testTag("store_finder_screen")
    ) {
        // Search Header
        Surface(color = BootsBluePrimary, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Boots Store Locator", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = Color.White))
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Enter UK Postcode or Town (e.g. W1B, NG1)...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    singleLine = true,
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("store_search_input")
                )
            }
        }

        // Map View Simulation Header Card
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFE3F2FD)),
            modifier = Modifier
                .fillMaxWidth()
                .height(110.dp)
                .padding(16.dp)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                SimulatedMapViewCanvas()
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Map, contentDescription = null, tint = BootsBluePrimary, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Interactive UK Map View - Showing ${stores.size} Stores", fontWeight = FontWeight.Bold, color = BootsBluePrimary)
                }
            }
        }

        // Stores List
        LazyColumn(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(stores, key = { it.id }) { store ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth().testTag("store_card_${store.id}")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(store.name, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = BootsTextPrimary))
                                Text("${store.address}, ${store.town} ${store.postcode}", style = MaterialTheme.typography.bodySmall.copy(color = BootsTextSecondary))
                            }
                            Text("${store.distanceMiles} miles", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = BootsBlueSecondary))
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Open Today: ${store.openingHoursToday}", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = BootsGreen))
                        }
                        Text("Pharmacy Hours: ${store.pharmacyHoursToday}", style = MaterialTheme.typography.bodySmall.copy(color = BootsTextSecondary))

                        Spacer(modifier = Modifier.height(10.dp))

                        // Available Services Badges
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (store.hasOpticians) ServiceTag("Opticians", Icons.Default.Visibility)
                            if (store.hasHearingCare) ServiceTag("Hearingcare", Icons.Default.Hearing)
                            if (store.hasClickAndCollect) ServiceTag("Click & Collect", Icons.Default.Storefront)
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = { onSelectStoreForInStoreMode(store) },
                            colors = ButtonDefaults.buttonColors(containerColor = BootsBluePrimary),
                            modifier = Modifier.fillMaxWidth().testTag("enter_store_mode_button_${store.id}")
                        ) {
                            Text("Switch to In-Store Mode", fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ServiceTag(name: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Surface(
        color = BootsGreyBackground,
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Icon(icon, contentDescription = null, tint = BootsBluePrimary, modifier = Modifier.size(12.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(name, style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, color = BootsTextPrimary))
        }
    }
}

@Composable
fun SimulatedMapViewCanvas() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height

        // Background map grid styling
        drawRect(color = Color(0xFFE1F5FE))

        // Draw pin dots
        drawCircle(color = Color(0xFF002C6C), radius = 10f, center = Offset(width * 0.25f, height * 0.5f))
        drawCircle(color = Color(0xFFD6006E), radius = 14f, center = Offset(width * 0.55f, height * 0.4f))
        drawCircle(color = Color(0xFF002C6C), radius = 10f, center = Offset(width * 0.75f, height * 0.65f))
    }
}
