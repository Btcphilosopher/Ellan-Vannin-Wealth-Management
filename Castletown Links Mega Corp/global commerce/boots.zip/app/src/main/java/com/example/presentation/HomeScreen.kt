package com.example.presentation

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.LocalPharmacy
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.Vaccines
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.BootsCatalogData
import com.example.models.AdvantageCard
import com.example.models.Department
import com.example.models.Product
import com.example.ui.components.AdvantageCardBanner
import com.example.ui.components.ProductCard
import com.example.ui.components.SectionHeader
import com.example.ui.theme.AdvantagePink
import com.example.ui.theme.AdvantagePinkLight
import com.example.ui.theme.BootsBlueContainer
import com.example.ui.theme.BootsBluePrimary
import com.example.ui.theme.BootsBlueSecondary
import com.example.ui.theme.BootsGreen
import com.example.ui.theme.BootsGreyBackground
import com.example.ui.theme.BootsGreyBorder
import com.example.ui.theme.BootsTextPrimary
import com.example.ui.theme.BootsTextSecondary
import com.example.ui.theme.PriceAdvantageBadge

@Composable
fun HomeScreen(
    advantageCard: AdvantageCard,
    onSearchClick: () -> Unit,
    onDepartmentClick: (Department) -> Unit,
    onProductClick: (Product) -> Unit,
    onQuickAddClick: (Product) -> Unit,
    onAdvantageCardClick: () -> Unit,
    onPrescriptionsClick: () -> Unit,
    onStoreFinderClick: () -> Unit,
    onStoreModeClick: () -> Unit,
    onOffersClick: () -> Unit,
    onBeautyHubClick: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(BootsGreyBackground)
            .testTag("home_screen_column")
    ) {
        // 1. Top Search Bar Quick Launcher
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BootsBluePrimary)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = Color.White,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSearchClick() }
                        .testTag("home_search_bar_trigger")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = BootsTextSecondary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Search No7, Paracetamol, SPF, Brands...",
                            style = MaterialTheme.typography.bodyMedium.copy(color = BootsTextSecondary)
                        )
                    }
                }
            }
        }

        // 2. Advantage Card Banner
        item {
            Box(modifier = Modifier.padding(16.dp)) {
                AdvantageCardBanner(
                    card = advantageCard,
                    onShowCardClick = onAdvantageCardClick
                )
            }
        }

        // 3. Hero Campaign Banner (Seasonal Beauty & Price Advantage)
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = PriceAdvantageBadge),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .clickable { onOffersClick() }
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Surface(
                            color = Color.White,
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "PRICE ADVANTAGE",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = PriceAdvantageBadge
                                ),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Up to 50% Off 1,000s of Products",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )
                        Text(
                            text = "Exclusively with your Boots Advantage Card",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = Color.White.copy(alpha = 0.9f)
                            )
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.White)
                    ) {
                        AsyncImage(
                            model = "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=200&q=80",
                            contentDescription = "Campaign",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.matchParentSize()
                        )
                    }
                }
            }
        }

        // 4. Healthcare Quick Hub Bar
        item {
            Column(modifier = Modifier.padding(16.dp)) {
                SectionHeader(
                    title = "Healthcare & Store Services",
                    subtitle = "Manage prescriptions and locate nearby Boots"
                )
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    ServiceQuickChip(
                        title = "Prescriptions",
                        subtitle = "NHS Repeat Request",
                        icon = Icons.Default.LocalPharmacy,
                        containerColor = BootsBlueContainer,
                        iconColor = BootsBluePrimary,
                        modifier = Modifier.weight(1f),
                        onClick = onPrescriptionsClick
                    )
                    ServiceQuickChip(
                        title = "Store Finder",
                        subtitle = "Find 2,200 Stores",
                        icon = Icons.Default.Storefront,
                        containerColor = Color(0xFFE8F5E9),
                        iconColor = BootsGreen,
                        modifier = Modifier.weight(1f),
                        onClick = onStoreFinderClick
                    )
                    ServiceQuickChip(
                        title = "In-Store Mode",
                        subtitle = "Scan & Aisle Guide",
                        icon = Icons.Default.MedicalServices,
                        containerColor = AdvantagePinkLight,
                        iconColor = AdvantagePink,
                        modifier = Modifier.weight(1f),
                        onClick = onStoreModeClick
                    )
                }
            }
        }

        // 5. Shop by Department Grid
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                SectionHeader(
                    title = "Shop by Department",
                    actionText = "See All",
                    onActionClick = { onDepartmentClick(Department.BEAUTY) }
                )
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(BootsCatalogData.CATEGORIES) { category ->
                        Card(
                            onClick = { onDepartmentClick(category.department) },
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            modifier = Modifier.width(100.dp)
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .padding(12.dp)
                                    .fillMaxWidth()
                            ) {
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .size(48.dp)
                                        .background(BootsBlueContainer, CircleShape)
                                ) {
                                    Text(
                                        text = category.name.take(2).uppercase(),
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = BootsBluePrimary
                                        )
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = category.name,
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        color = BootsTextPrimary
                                    ),
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }

        // 6. Recommended for You Carousel
        item {
            Column(modifier = Modifier.padding(top = 16.dp)) {
                PaddingValues(horizontal = 16.dp).let {
                    Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                        SectionHeader(
                            title = "Recommended for You",
                            subtitle = "Based on your Advantage Card activity",
                            actionText = "Shop All",
                            onActionClick = { onDepartmentClick(Department.BEAUTY) }
                        )
                    }
                }
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(BootsCatalogData.PRODUCTS.take(6)) { product ->
                        ProductCard(
                            product = product,
                            onProductClick = onProductClick,
                            onQuickAddClick = onQuickAddClick,
                            modifier = Modifier.width(160.dp)
                        )
                    }
                }
            }
        }

        // 7. Popular Brands Showcase
        item {
            Column(modifier = Modifier.padding(16.dp)) {
                SectionHeader(title = "Popular Boots Brands")
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(BootsCatalogData.BRANDS) { brand ->
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = Color.White,
                            shadowElevation = 1.dp,
                            modifier = Modifier.clickable { onDepartmentClick(brand.category) }
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                            ) {
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .size(28.dp)
                                        .background(BootsBluePrimary, CircleShape)
                                ) {
                                    Text(
                                        text = brand.logoText.take(1),
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = brand.name,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = BootsTextPrimary
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }

        // 8. Dedicated Beauty Experience Banner
        item {
            Card(
                onClick = onBeautyHubClick,
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = BootsBluePrimary),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "BOOTS BEAUTY HUB",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = AdvantagePinkLight,
                                letterSpacing = 1.sp
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Find Your Perfect Shade & Routine",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Shade finder tool, skincare routines & expert advice",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = Color.White.copy(alpha = 0.85f)
                            )
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "Explore",
                        tint = Color.White
                    )
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
fun ServiceQuickChip(
    title: String,
    subtitle: String,
    icon: ImageVector,
    containerColor: Color,
    iconColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = containerColor,
        modifier = modifier.clickable { onClick() }
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(12.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = iconColor,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = BootsTextPrimary
                ),
                maxLines = 1
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 10.sp,
                    color = BootsTextSecondary
                ),
                maxLines = 1
            )
        }
    }
}
