package com.example.presentation

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.models.Product
import com.example.ui.components.ProductCard
import com.example.ui.theme.BootsGreyBackground
import com.example.ui.theme.BootsTextPrimary
import com.example.ui.theme.BootsTextSecondary

@Composable
fun WishlistScreen(
    wishlistedProducts: List<Product>,
    onProductClick: (Product) -> Unit,
    onQuickAddClick: (Product) -> Unit,
    onWishlistToggle: (Product) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BootsGreyBackground)
            .padding(16.dp)
            .testTag("wishlist_screen")
    ) {
        Text("My Wishlist (${wishlistedProducts.size})", style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold, color = BootsTextPrimary))
        Spacer(modifier = Modifier.height(16.dp))

        if (wishlistedProducts.isEmpty()) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.FavoriteBorder, contentDescription = null, tint = BootsTextSecondary, modifier = Modifier.size(56.dp))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Your wishlist is empty", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    Text("Tap the heart icon on any product to save it here.", style = MaterialTheme.typography.bodySmall.copy(color = BootsTextSecondary))
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(wishlistedProducts, key = { it.id }) { product ->
                    ProductCard(
                        product = product,
                        onProductClick = onProductClick,
                        onQuickAddClick = onQuickAddClick,
                        isWishlisted = true,
                        onWishlistToggle = onWishlistToggle
                    )
                }
            }
        }
    }
}
