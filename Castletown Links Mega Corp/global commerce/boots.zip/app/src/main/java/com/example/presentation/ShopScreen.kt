package com.example.presentation

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.models.Department
import com.example.models.Product
import com.example.repositories.ProductRepository
import com.example.repositories.SortOption
import com.example.ui.components.ProductCard
import com.example.ui.theme.AdvantagePink
import com.example.ui.theme.BootsBlueContainer
import com.example.ui.theme.BootsBluePrimary
import com.example.ui.theme.BootsGreyBackground
import com.example.ui.theme.BootsGreyBorder
import com.example.ui.theme.BootsTextPrimary
import com.example.ui.theme.BootsTextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShopScreen(
    productRepository: ProductRepository,
    initialDepartment: Department = Department.BEAUTY,
    onProductClick: (Product) -> Unit,
    onQuickAddClick: (Product) -> Unit,
    onWishlistToggle: (Product) -> Unit,
    wishlistedProductIds: Set<String>
) {
    var selectedDepartment by remember { mutableStateOf(initialDepartment) }
    var selectedSortOption by remember { mutableStateOf(SortOption.RECOMMENDED) }
    var selectedBrand by remember { mutableStateOf<String?>(null) }

    var filterOnlyOffers by remember { mutableStateOf(false) }
    var filterOnlyExclusives by remember { mutableStateOf(false) }
    var filterOnlyVegan by remember { mutableStateOf(false) }

    var showSortMenu by remember { mutableStateOf(false) }
    var showFilterSheet by remember { mutableStateOf(false) }

    val products = remember(selectedDepartment, selectedSortOption, selectedBrand, filterOnlyOffers, filterOnlyExclusives, filterOnlyVegan) {
        productRepository.searchProducts(
            query = "",
            department = selectedDepartment,
            brandFilter = selectedBrand,
            onlyOffers = filterOnlyOffers,
            onlyExclusives = filterOnlyExclusives,
            onlyVegan = filterOnlyVegan,
            sortBy = selectedSortOption
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BootsGreyBackground)
            .testTag("shop_screen")
    ) {
        // Department Tabs Header
        ScrollableTabRow(
            selectedTabIndex = Department.values().indexOf(selectedDepartment),
            containerColor = Color.White,
            contentColor = BootsBluePrimary,
            edgePadding = 16.dp,
            indicator = { tabPositions ->
                val index = Department.values().indexOf(selectedDepartment)
                if (index < tabPositions.size) {
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[index]),
                        color = BootsBluePrimary,
                        height = 3.dp
                    )
                }
            }
        ) {
            Department.values().forEach { dept ->
                Tab(
                    selected = selectedDepartment == dept,
                    onClick = {
                        selectedDepartment = dept
                        selectedBrand = null
                    },
                    text = {
                        Text(
                            text = dept.displayName,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = if (selectedDepartment == dept) FontWeight.Bold else FontWeight.Medium
                            )
                        )
                    }
                )
            }
        }

        // Sub-filter & Sorting Bar
        Surface(
            color = Color.White,
            shadowElevation = 1.dp
        ) {
            Column(modifier = Modifier.padding(vertical = 8.dp)) {
                // Quick Filter Chips
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        FilterChip(
                            selected = filterOnlyOffers,
                            onClick = { filterOnlyOffers = !filterOnlyOffers },
                            label = { Text("Price Advantage / Offers") },
                            leadingIcon = if (filterOnlyOffers) { { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) } } else null,
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = AdvantagePink,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                    item {
                        FilterChip(
                            selected = filterOnlyExclusives,
                            onClick = { filterOnlyExclusives = !filterOnlyExclusives },
                            label = { Text("Boots Exclusives") },
                            leadingIcon = if (filterOnlyExclusives) { { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) } } else null,
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BootsBluePrimary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                    item {
                        FilterChip(
                            selected = filterOnlyVegan,
                            onClick = { filterOnlyVegan = !filterOnlyVegan },
                            label = { Text("Vegan") },
                            leadingIcon = if (filterOnlyVegan) { { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) } } else null
                        )
                    }
                }

                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "${products.size} Products",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = BootsTextSecondary,
                            fontWeight = FontWeight.SemiBold
                        )
                    )

                    Row {
                        // Sort Dropdown Button
                        Box {
                            TextButton(
                                onClick = { showSortMenu = true },
                                modifier = Modifier.testTag("sort_button")
                            ) {
                                Icon(Icons.Default.Sort, contentDescription = null, tint = BootsBluePrimary, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = selectedSortOption.displayName,
                                    style = MaterialTheme.typography.labelMedium.copy(color = BootsBluePrimary, fontWeight = FontWeight.Bold)
                                )
                            }

                            DropdownMenu(
                                expanded = showSortMenu,
                                onDismissRequest = { showSortMenu = false }
                            ) {
                                SortOption.values().forEach { option ->
                                    DropdownMenuItem(
                                        text = { Text(option.displayName) },
                                        onClick = {
                                            selectedSortOption = option
                                            showSortMenu = false
                                        }
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        TextButton(
                            onClick = { showFilterSheet = true },
                            modifier = Modifier.testTag("filter_button")
                        ) {
                            Icon(Icons.Default.FilterList, contentDescription = null, tint = BootsBluePrimary, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Filters", style = MaterialTheme.typography.labelMedium.copy(color = BootsBluePrimary, fontWeight = FontWeight.Bold))
                        }
                    }
                }
            }
        }

        // Product Catalogue Grid
        if (products.isEmpty()) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "No products found",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = BootsTextPrimary)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Try clearing your filters or selecting another department.",
                        style = MaterialTheme.typography.bodySmall.copy(color = BootsTextSecondary)
                    )
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(products, key = { it.id }) { product ->
                    ProductCard(
                        product = product,
                        onProductClick = onProductClick,
                        onQuickAddClick = onQuickAddClick,
                        isWishlisted = wishlistedProductIds.contains(product.id),
                        onWishlistToggle = onWishlistToggle
                    )
                }
            }
        }
    }

    if (showFilterSheet) {
        ModalBottomSheet(
            onDismissRequest = { showFilterSheet = false },
            sheetState = rememberModalBottomSheetState()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
            ) {
                Text(
                    text = "Refine Catalogue",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = BootsTextPrimary)
                )
                Spacer(modifier = Modifier.height(16.dp))

                Text("Brand Filter", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold))
                Spacer(modifier = Modifier.height(8.dp))

                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        FilterChip(
                            selected = selectedBrand == null,
                            onClick = { selectedBrand = null },
                            label = { Text("All Brands") }
                        )
                    }
                    items(productRepository.getBrands()) { brand ->
                        FilterChip(
                            selected = selectedBrand.equals(brand.name, ignoreCase = true),
                            onClick = { selectedBrand = if (selectedBrand == brand.name) null else brand.name },
                            label = { Text(brand.name) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                TextButton(
                    onClick = {
                        filterOnlyOffers = false
                        filterOnlyExclusives = false
                        filterOnlyVegan = false
                        selectedBrand = null
                        showFilterSheet = false
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Reset All Filters", color = AdvantagePink, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
