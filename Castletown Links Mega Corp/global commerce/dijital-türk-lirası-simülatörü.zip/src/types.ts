/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// Asset types
export type AssetType = 
  | 'DIJITAL_TL' 
  | 'MEVDUAT' 
  | 'ELEKTRONIK_PARA' 
  | 'TOKENIZE_MEVDUAT' 
  | 'TOKENIZE_TAHVIL' 
  | 'YATIRIM_FONU';

// Wallet types
export type WalletType = 'Bireysel' | 'Ticari' | 'Kurumsal' | 'Kamu' | 'Finansal Kurulus';

// Transaction states as per requirements
export type TransactionStatus = 
  | 'ISLEM_OLUSTURULDU'
  | 'KIMLIK_DOGRULAMA'
  | 'BAKIYE_KONTROLU'
  | 'UYUM_KONTROLU'
  | 'LIKIDITE_KONTROLU'
  | 'YONLENDIRME'
  | 'MUTABAKAT'
  | 'KESINLESME'
  | 'DENETIM_KAYDI';

// Balance sheet structures for accounting integrity
export interface BalanceSheet {
  assets: {
    govSecurities: number; // Devlet tahvilleri
    foreignAssets: number; // Yabancı varlıklar
    loans: number; // Krediler
    reserves: number; // Rezervler (for banks)
    digitalTL: number; // Dijital TL (for banks/institutions)
    collateralizedOps: number; // Teminatlı işlemler
    otherAssets: number;
  };
  liabilities: {
    banknotes: number; // Tedavüldeki banknotlar (TCMB)
    bankReserves: number; // Banka rezervleri (TCMB)
    digitalTL: number; // Dijital TL ihraç (TCMB)
    deposits: number; // Müşteri mevduatları (Banks)
    eMoney: number; // Elektronik para (Fintechs)
    otherLiabilities: number;
  };
  equity: {
    capital: number; // Ödenmiş sermaye / Yedekler
  };
}

// Simulated Institution (Banks)
export interface Bank {
  id: string;
  name: string;
  balanceSheet: BalanceSheet;
  complianceScore: number; // percentage
  apiHealth: 'AKTIF' | 'GECIKMELI' | 'HATA';
  riskLevel: 'DUSUK' | 'ORTA' | 'YUKSEK';
  liquidityRatio: number; // current ratio
}

// Simulated Payment Institution (Fintechs)
export interface PaymentInstitution {
  id: string;
  name: string;
  customerCount: number;
  transactionVolume: number;
  digitalTLBalance: number;
  eMoneyLiability: number;
  liquidityRatio: number;
  riskLevel: 'DUSUK' | 'ORTA' | 'YUKSEK';
  apiHealth: 'AKTIF' | 'PASIF';
  complianceStatus: 'UYUMLU' | 'INCELEMEDE';
}

// Interactive Digital Wallet
export interface Wallet {
  id: string;
  owner: string;
  type: WalletType;
  digitalTLBalance: number;
  availableBalance: number;
  offlineBalance: number;
  dailyLimit: number;
  transactionLimit: number;
  kycStatus: 'DOGRULANMIS' | 'LIMITLI' | 'YETERSİZ';
  intermediary: string; // E.g. Anadolu Dijital Bank
  securityLevel: 'YUKSEK' | 'STANDART';
  programmablePermissions: string[]; // List of allowed conditions
}

// Ledger Entry
export interface LedgerTransaction {
  id: string;
  timestamp: string;
  sender: string;
  receiver: string;
  intermediary: string;
  assetType: AssetType;
  amount: number;
  status: TransactionStatus;
  isVerified: boolean;
  isSettled: boolean;
  smartContractId?: string;
  auditId: string;
  signature: string;
}

// Programmable Payment Contract
export interface ProgrammablePayment {
  id: string;
  title: string;
  amount: number;
  sender: string;
  receiver: string;
  condition: string;
  status: 'BEKLEMEDE' | 'KOSUL_SAGLANDI' | 'TAMAMLANDI' | 'IPTAL_EDILDI';
  verificationStep: string;
  escrowWalletId: string;
}

// Offline Payment Simulation State
export interface OfflinePaymentSimulation {
  deviceA_Name: string;
  deviceB_Name: string;
  deviceA_Balance: number;
  deviceB_Balance: number;
  transferAmount: number;
  isOnline: boolean;
  offlineTransactions: {
    id: string;
    from: string;
    to: string;
    amount: number;
    timestamp: string;
    signature: string;
  }[];
  syncQueue: string[];
}

// Tokenized Securities Instruments
export interface TokenizedSecurity {
  id: string;
  name: string;
  ticker: string;
  type: 'Devlet Tahvili' | 'Hazine Bonosu' | 'Sirket Tahvili' | 'Yatirim Fonu' | 'Para Piyasasi Fonu';
  circulatingSupply: number;
  nominalValue: number;
  yieldRate: number; // percentage
  collateralizedValue: number;
}

// Digital Voucher System (Dijital Destek / Dijital Vale)
export interface DigitalVoucher {
  id: string;
  title: string;
  amount: number;
  recipient: string;
  category: 'Enerji' | 'Ulasim' | 'Egitim' | 'Kultur' | 'Tarim' | 'KOBI' | 'Sosyal Destek';
  expirationDate: string;
  usableFields: string[];
  status: 'AKTIF' | 'KULLANILDI' | 'SURESI_DOLDU';
}

// Compliance / Risk Alerts
export interface ComplianceAlert {
  id: string;
  timestamp: string;
  transactionId: string;
  amount: number;
  riskScore: 'DUSUK' | 'ORTA' | 'YUKSEK';
  reason: string;
  status: 'INCELEMEDE' | 'BLOKE' | 'ONAYLANDI';
}

// Liquidity Stress Event
export interface LiquidityStressEvent {
  bankId: string;
  requiredLiquidity: number;
  availableLiquidity: number;
  deficit: number;
  status: 'LİKİDİTE_ACIGI' | 'COZULDU' | 'TEMINAT_CAGRISI';
}

// Monetary & Economic Lab Variables
export interface EconomicModel {
  digitalTLCirculation: number;
  bankDeposits: number;
  moneySupplyM2: number;
  velocityOfMoney: number;
  totalCreditVolume: number;
  liquidityIndex: number;
  interestRate: number;
  inflationRate: number;
  gdpGrowthRate: number;
  adoptionRate: number;
}

// Cross-Border Currencies
export interface CrossBorderCurrency {
  code: string; // EUR, USD, GBP, JPY, CNY
  name: string;
  exchangeRate: number; // in TRY
  systemName: string; // E.g. wEUR (Wholesale EUR)
  latencySec: number;
  spreadBps: number;
}

// Infrastructure nodes
export interface InfrastructureNode {
  city: string;
  cpu: number;
  memory: number;
  networkLatency: number; // ms
  apiLatency: number; // ms
  tps: number;
  queueDepth: number;
  errorRate: number; // %
  syncStatus: 'SENKRON' | 'SENKRON_EDILIYOR' | 'DEVIATION';
  databaseHealth: 'SAGLIKLI' | 'KRITIK';
}

// Machine-to-Machine simulation
export interface M2MDevice {
  id: string;
  name: string;
  batteryOrFuel: number; // %
  requiredService: string;
  cost: number;
  authorizedMax: number;
  status: 'BEKLEMEDE' | 'DOGRULANIYOR' | 'SARJ_EDILIYOR' | 'TAMAMLANDI';
}

// AI Payment Agent
export interface AIAgent {
  id: string;
  name: string;
  authorizedBalance: number;
  maxTransactionLimit: number;
  approvedCategories: string[];
  status: 'UYKUDA' | 'MERCHANT_ARANIYOR' | 'YETKI_BEKLENIYOR' | 'ODENIYOR' | 'ISLEM_KAYDEDILDI';
}
