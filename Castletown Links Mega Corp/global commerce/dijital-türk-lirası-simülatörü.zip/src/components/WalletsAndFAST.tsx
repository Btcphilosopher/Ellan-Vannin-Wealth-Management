/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useSimulation } from '../context/SimulationContext';
import { Wallet as WalletIcon, RefreshCcw, Send, CheckCircle, ShieldAlert, ArrowLeftRight } from 'lucide-react';

export default function WalletsAndFAST() {
  const {
    wallets,
    selectedWalletId,
    setSelectedWalletId,
    fastMevduatToDijitalTL,
    fastDijitalTLToMevduat,
    banks
  } = useSimulation();

  const [convertAmount, setConvertAmount] = useState<number>(500.00);
  const [fastDirection, setFastDirection] = useState<'MEVDUAT_TO_DTL' | 'DTL_TO_MEVDUAT'>('MEVDUAT_TO_DTL');
  const [fastStatus, setFastStatus] = useState<string | null>(null);
  const [isProcessingFast, setIsProcessingFast] = useState<boolean>(false);

  const activeWallet = wallets.find(w => w.id === selectedWalletId) || wallets[0];

  const handleFASTConversion = (e: React.FormEvent) => {
    e.preventDefault();
    if (convertAmount <= 0) return;

    setIsProcessingFast(true);
    setFastStatus(null);

    setTimeout(() => {
      let success = false;
      if (fastDirection === 'MEVDUAT_TO_DTL') {
        success = fastMevduatToDijitalTL(activeWallet.id, convertAmount);
      } else {
        success = fastDijitalTLToMevduat(activeWallet.id, convertAmount);
      }

      setIsProcessingFast(false);
      if (success) {
        setFastStatus(`FAST İŞLEMİ TAMAMLANDI! ₺${convertAmount.toLocaleString('tr-TR')} mutabakatı gerçekleştirildi. 200ms gecikme süresi.`);
      } else {
        setFastStatus('HATA: Yetersiz banka mevduat likiditesi veya cüzdan limiti aşıldı.');
      }
    }, 800);
  };

  return (
    <div id="wallets-and-fast-interoperability" className="space-y-6">
      
      {/* Module Title */}
      <div className="bg-[#1C2541] border border-[#2A375B] p-4 rounded text-white flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold tracking-tight font-serif uppercase text-[#C00000] flex items-center gap-2">
            <WalletIcon size={20} /> DİJİTAL TÜRK LİRASI CÜZDANLARI & FAST ENTEGRASYONU
          </h2>
          <p className="text-xs text-[#8F9AA6] font-mono uppercase mt-0.5">
            BİREYSEL, TİCARİ VE KAMU CÜZDAN UX VE BANKACILIK ENTEGRASYON KATMANI
          </p>
        </div>
        <div className="text-[10px] font-mono bg-[#0B132B] px-3 py-1 border border-[#2A375B] rounded text-emerald-400 font-bold">
          FAST CORE INTEROP v3.0
        </div>
      </div>

      {/* 1. Wallet UX (Section 11 & 32) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left: Wallet Explorer list */}
        <div className="bg-white border border-[#E2E8F0] p-4 rounded shadow-sm space-y-4">
          <div>
            <h3 className="text-xs font-bold font-mono text-[#0B132B] uppercase">CÜZDAN GEZGİNİ</h3>
            <p className="text-[10px] text-[#5C6B73] font-mono uppercase mt-0.5">GÖRÜNTÜLENECEK SİMÜLE CÜZDAN SEÇİN</p>
          </div>

          <div className="space-y-2 font-mono text-xs">
            {wallets.map(w => (
              <button
                key={w.id}
                onClick={() => setSelectedWalletId(w.id)}
                className={`w-full p-3 rounded text-left border transition ${
                  selectedWalletId === w.id
                    ? 'bg-[#111A35] text-white border-[#C00000]'
                    : 'bg-[#F8FAFC] border-[#E2E8F0] text-[#0B132B] hover:bg-[#F1F5F9]'
                }`}
              >
                <div className="flex justify-between items-center">
                  <span className="font-bold">{w.owner}</span>
                  <span className={`px-1.5 py-0.5 text-[8px] font-bold rounded ${
                    w.type === 'Bireysel' ? 'bg-blue-100 text-blue-800' :
                    w.type === 'Ticari' ? 'bg-amber-100 text-amber-800' :
                    w.type === 'Kamu' ? 'bg-purple-100 text-purple-800' :
                    'bg-green-100 text-green-800'
                  }`}>
                    {w.type}
                  </span>
                </div>
                <div className="mt-2 flex justify-between items-baseline">
                  <span className="text-[10px] text-[#8F9AA6]">Mevcut DTL:</span>
                  <span className="font-bold">₺{w.digitalTLBalance.toLocaleString('tr-TR', { minimumFractionDigits: 2 })}</span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Middle: Active Wallet UX details */}
        <div className="bg-[#0B132B] border border-[#1C2541] p-4 rounded text-[#E0E6ED] space-y-4 relative overflow-hidden flex flex-col justify-between">
          <div>
            <div className="border-b border-[#1C2541] pb-2 flex justify-between items-center">
              <span className="text-[10px] font-bold font-mono text-[#C00000] uppercase">DİJİTAL TÜRK LİRASI CÜZDANI UX</span>
              <span className="text-[9px] font-mono text-emerald-400 bg-emerald-950 px-2 py-0.5 border border-emerald-800 rounded font-bold">
                {activeWallet.kycStatus}
              </span>
            </div>

            <div className="py-4 space-y-1">
              <span className="text-[10px] font-mono text-[#5C6B73] block uppercase">TOPLAM DİJİTAL TL BAKİYESİ</span>
              <span className="text-3xl font-bold font-mono text-white tracking-tight">
                ₺{activeWallet.digitalTLBalance.toLocaleString('tr-TR', { minimumFractionDigits: 2 })}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3 text-[11px] font-mono border-t border-[#1C2541] pt-3">
              <div>
                <span className="text-[#5C6B73] block text-[9px]">KULLANILABİLİR:</span>
                <span className="font-bold text-[#E0E6ED]">₺{activeWallet.availableBalance.toLocaleString('tr-TR', { minimumFractionDigits: 2 })}</span>
              </div>
              <div>
                <span className="text-[#5C6B73] block text-[9px]">ÇEVRİMDIŞI BAKİYE:</span>
                <span className="font-bold text-amber-400">₺{activeWallet.offlineBalance.toLocaleString('tr-TR', { minimumFractionDigits: 2 })}</span>
              </div>
              <div className="mt-2">
                <span className="text-[#5C6B73] block text-[9px]">GÜNLÜK LİMİT:</span>
                <span className="font-bold">₺{activeWallet.dailyLimit.toLocaleString('tr-TR')}</span>
              </div>
              <div className="mt-2">
                <span className="text-[#5C6B73] block text-[9px]">ARACI KURUM:</span>
                <span className="font-bold truncate block">{activeWallet.intermediary}</span>
              </div>
            </div>
          </div>

          <div className="border-t border-[#1C2541] pt-4 mt-4 space-y-2 text-[10px] font-mono">
            <span className="text-[#5C6B73] uppercase">PROGRAMLANABİLİR SÖZLEŞME İZİNLERİ:</span>
            <div className="flex flex-wrap gap-1">
              {activeWallet.programmablePermissions.map((p, idx) => (
                <span key={idx} className="bg-[#1C2541] text-[#E0E6ED] border border-[#2D3E6B] px-1.5 py-0.5 rounded">
                  {p}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Right: FAST Interoperability Simulation (Section 13) */}
        <div className="bg-white border border-[#E2E8F0] p-4 rounded shadow-sm flex flex-col justify-between">
          <div>
            <div className="border-b border-[#F1F5F9] pb-2 mb-3">
              <h3 className="text-xs font-bold font-mono text-[#0B132B] uppercase flex items-center gap-1">
                <ArrowLeftRight size={14} className="text-[#C00000]" /> FAST ENTEGRASYON SİMÜLATÖRÜ
              </h3>
              <p className="text-[10px] text-[#5C6B73] font-mono mt-0.5">BANKA MEVDUAT HESABI ⇄ MERKEZ BANKASI DİJİTAL TL DÖNÜŞÜMÜ</p>
            </div>

            <form onSubmit={handleFASTConversion} className="space-y-4 font-mono text-xs">
              
              <div className="grid grid-cols-2 gap-2 bg-[#F8FAFC] p-1 border border-[#E2E8F0] rounded">
                <button
                  type="button"
                  onClick={() => setFastDirection('MEVDUAT_TO_DTL')}
                  className={`py-1.5 px-2 rounded text-center text-[10px] font-bold uppercase transition ${
                    fastDirection === 'MEVDUAT_TO_DTL'
                      ? 'bg-[#111A35] text-white'
                      : 'text-[#5C6B73] hover:text-[#0B132B]'
                  }`}
                >
                  Mevduat ➔ Dijital TL
                </button>
                <button
                  type="button"
                  onClick={() => setFastDirection('DTL_TO_MEVDUAT')}
                  className={`py-1.5 px-2 rounded text-center text-[10px] font-bold uppercase transition ${
                    fastDirection === 'DTL_TO_MEVDUAT'
                      ? 'bg-[#111A35] text-white'
                      : 'text-[#5C6B73] hover:text-[#0B132B]'
                  }`}
                >
                  Dijital TL ➔ Mevduat
                </button>
              </div>

              <div>
                <label className="text-[10px] text-[#5C6B73] block mb-1">DÖNÜŞTÜRÜLECEK TUTAR (₺):</label>
                <input
                  type="number"
                  step="100"
                  min="100"
                  value={convertAmount}
                  onChange={(e) => setConvertAmount(parseFloat(e.target.value) || 0)}
                  className="w-full border border-[#E2E8F0] p-1.5 rounded font-bold text-right"
                />
              </div>

              <div className="text-[10px] text-[#5C6B73] space-y-1 bg-[#F8FAFC] border border-[#E2E8F0] p-2.5 rounded">
                <div className="flex justify-between"><span>FAST Gecikme Süresi:</span><span className="font-bold text-[#0B132B]">~200 ms</span></div>
                <div className="flex justify-between"><span>İşlem Başarı Oranı:</span><span className="font-bold text-emerald-600">100% (Sentetik)</span></div>
              </div>

              <button
                type="submit"
                disabled={isProcessingFast}
                className="w-full bg-[#0B132B] hover:bg-[#1C2541] disabled:bg-[#5C6B73] text-white py-2 px-4 rounded text-xs uppercase font-bold transition flex justify-center items-center gap-1.5"
              >
                <RefreshCcw size={12} className={isProcessingFast ? 'animate-spin' : ''} />
                {isProcessingFast ? 'DÖNÜŞÜM YAPILIYOR...' : 'FAST DÖNÜŞÜMÜ GERÇEKLEŞTİR'}
              </button>

            </form>
          </div>

          <div className="mt-4">
            {fastStatus && (
              <div className="p-2.5 bg-emerald-50 border border-emerald-200 text-emerald-800 text-[10px] font-mono rounded flex items-start gap-1">
                <CheckCircle size={14} className="text-emerald-600 shrink-0 mt-0.5" />
                <span>{fastStatus}</span>
              </div>
            )}
          </div>
        </div>

      </div>

    </div>
  );
}
