/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useSimulation } from '../context/SimulationContext';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { BarChart2, TrendingUp, DollarSign, Activity, Percent } from 'lucide-react';

export default function EconomicLaboratory() {
  const {
    economicModel,
    changeEconomicScenario,
    currentScenario
  } = useSimulation();

  // Generate projections dynamically from economicModel variables
  const generateChartData = () => {
    const baseM2 = economicModel.moneySupplyM2;
    const baseDigitalTL = economicModel.digitalTLCirculation;
    const velocity = economicModel.velocityOfMoney;
    
    return Array.from({ length: 6 }).map((_, idx) => {
      const year = 2026 + idx;
      const simulatedDigitalTL = baseDigitalTL * (1 + (economicModel.interestRate / 100) * 0.05) * (1 + idx * (economicModel.adoptionRate / 100));
      const simulatedM2 = baseM2 * (1 + idx * (economicModel.gdpGrowthRate / 100));
      return {
        yil: year.toString(),
        'Dijital TL Hacmi (Milyar ₺)': parseFloat(simulatedDigitalTL.toFixed(2)),
        'M2 Para Arzı (Milyar ₺)': parseFloat(simulatedM2.toFixed(2)),
        'Para Dolaşım Hızı (V)': parseFloat((velocity * (1 + idx * 0.02)).toFixed(2))
      };
    });
  };

  const chartData = generateChartData();

  const scenarios = [
    { id: 'BAZ', label: 'BAZ SENARYO', desc: 'Sakin piyasa koşulları altında standart penetrasyon modeli.' },
    { id: 'YUKSEK_KULLANIM', label: 'YÜKSEK ENTEGRASYON', desc: 'Bireysel ve ticari cüzdan kullanım hızı ve penetrasyonu %48’e ulaşır.' },
    { id: 'DUSUK_KULLANIM', label: 'SINIRLI BENİMSENME', desc: 'Kullanıcıların geleneksel bankacılık alışkanlıklarını koruduğu senaryo.' },
    { id: 'LIKIDITE_STRESI', label: 'MÜŞTERİ PANİĞİ / STRES', desc: 'Mevduatların hızla DTL’ye akması sonucu banka likidite stres testi tetiklenir.' },
    { id: 'SINIR_OTESI', label: 'SINIR ÖTESİ ENTEGRASYON', desc: 'Sınır ötesi toptan CBDC transfer koridorları simülasyonu.' }
  ];

  return (
    <div id="economic-research-laboratory" className="space-y-6">
      
      {/* Title */}
      <div className="bg-[#1C2541] border border-[#2A375B] p-4 rounded text-white flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold tracking-tight font-serif uppercase text-[#C00000] flex items-center gap-2">
            <BarChart2 size={20} /> ARAŞTIRMA VE MAKRO EKONOMİ LABORATUVARI
          </h2>
          <p className="text-xs text-[#8F9AA6] font-mono uppercase mt-0.5">
            PARA ARZI PROJEKSİYONLARI, ENFLASYON ETKİLERİ VE MAKRO POLİTİKA MODELLEMESİ
          </p>
        </div>
        <div className="text-[10px] font-mono bg-[#0B132B] px-3 py-1 border border-[#2A375B] rounded text-emerald-400 font-bold">
          MACRO SIM CORE v2.2
        </div>
      </div>

      {/* Metric Cards Banner */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <div className="bg-white border border-[#E2E8F0] p-3 rounded shadow-sm font-mono text-xs">
          <span className="text-[#5C6B73] uppercase text-[9px] block">M2 PARA ARZI</span>
          <span className="text-sm font-bold text-[#0B132B]">₺{economicModel.moneySupplyM2.toFixed(1)} Milyar</span>
        </div>
        <div className="bg-white border border-[#E2E8F0] p-3 rounded shadow-sm font-mono text-xs">
          <span className="text-[#5C6B73] uppercase text-[9px] block">DOLAŞIMDAKİ DTL</span>
          <span className="text-sm font-bold text-emerald-600">₺{economicModel.digitalTLCirculation.toFixed(1)} Milyar</span>
        </div>
        <div className="bg-white border border-[#E2E8F0] p-3 rounded shadow-sm font-mono text-xs">
          <span className="text-[#5C6B73] uppercase text-[9px] block">ENFLASYON ORANI</span>
          <span className="text-sm font-bold text-[#C00000]">%{economicModel.inflationRate.toFixed(1)}</span>
        </div>
        <div className="bg-white border border-[#E2E8F0] p-3 rounded shadow-sm font-mono text-xs">
          <span className="text-[#5C6B73] uppercase text-[9px] block">POLİTİKA FAİZİ</span>
          <span className="text-sm font-bold text-blue-600">%{economicModel.interestRate.toFixed(1)}</span>
        </div>
        <div className="bg-white border border-[#E2E8F0] p-3 rounded shadow-sm font-mono text-xs col-span-2 md:col-span-1">
          <span className="text-[#5C6B73] uppercase text-[9px] block">DOLAŞIM HIZI (V)</span>
          <span className="text-sm font-bold text-indigo-600">{economicModel.velocityOfMoney}x</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Scenario Selector */}
        <div className="bg-white border border-[#E2E8F0] p-4 rounded shadow-sm space-y-4">
          <div>
            <h3 className="text-xs font-bold font-mono text-[#0B132B] uppercase">MAKROEKONOMİK DURUM PROVALARI</h3>
            <p className="text-[10px] text-[#5C6B73] font-mono mt-0.5">SİSTEMİN TEPKİLERİNİ GÖZLEMLEMEK İÇİN BİR SENARYO SEÇİN</p>
          </div>

          <div className="space-y-2 font-mono text-xs">
            {scenarios.map(sc => {
              const isActive = currentScenario === sc.id;
              return (
                <button
                  key={sc.id}
                  onClick={() => changeEconomicScenario(sc.id)}
                  className={`w-full p-3 rounded text-left border transition flex flex-col ${
                    isActive
                      ? 'bg-[#111A35] text-white border-[#C00000]'
                      : 'bg-[#F8FAFC] border-[#E2E8F0] text-[#0B132B] hover:bg-[#F1F5F9]'
                  }`}
                >
                  <span className="font-bold text-[11px] uppercase flex justify-between items-center w-full">
                    {sc.label}
                    {isActive && <span className="inline-block w-2 h-2 rounded-full bg-red-500"></span>}
                  </span>
                  <span className={`text-[10px] mt-1.5 leading-relaxed ${isActive ? 'text-[#8F9AA6]' : 'text-[#5C6B73]'}`}>
                    {sc.desc}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Recharts Projections (Section 42) */}
        <div className="lg:col-span-2 bg-white border border-[#E2E8F0] p-4 rounded shadow-sm flex flex-col justify-between">
          <div>
            <div className="border-b border-[#F1F5F9] pb-2 mb-3">
              <h3 className="text-xs font-bold font-mono text-[#0B132B] uppercase">DİJİTAL TL PROJEKSİYON MODELİ VE M2 UYUM ANALİZİ</h3>
              <p className="text-[10px] text-[#5C6B73] font-mono mt-0.5">SİMÜLE REAKTİF KORİDORLAR VE ETKİ ANALİZLERİ (5 YILLIK PROJEKSİYON)</p>
            </div>

            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData} margin={{ top: 10, right: 30, left: 10, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F1F5F9" />
                  <XAxis dataKey="yil" stroke="#8F9AA6" tick={{ fontSize: 10, fontFamily: 'monospace' }} />
                  <YAxis stroke="#8F9AA6" tick={{ fontSize: 10, fontFamily: 'monospace' }} />
                  <Tooltip contentStyle={{ fontFamily: 'monospace', fontSize: '11px' }} />
                  <Legend wrapperStyle={{ fontFamily: 'monospace', fontSize: '10px' }} />
                  <Line
                    type="monotone"
                    dataKey="Dijital TL Hacmi (Milyar ₺)"
                    stroke="#C00000"
                    strokeWidth={2}
                    activeDot={{ r: 8 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="M2 Para Arzı (Milyar ₺)"
                    stroke="#111A35"
                    strokeWidth={1.5}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="text-[10px] text-[#5C6B73] font-mono border-t border-[#F1F5F9] pt-3 mt-4">
            * Para politikası katsayıları ve benimsenme senaryoları doğrultusunda ekonomik büyüme ve M2 para arzı dengelenmesi modellere yansıtılır.
          </div>
        </div>

      </div>

    </div>
  );
}
