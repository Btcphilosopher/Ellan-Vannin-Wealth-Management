/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useSimulation } from '../context/SimulationContext';
import { Cpu, Zap, Play, RotateCcw, ShieldCheck, Activity } from 'lucide-react';

export default function AiAndM2m() {
  const {
    aiAgent,
    m2mDevices,
    triggerAIAgentSearch,
    triggerM2MCharge,
    resetM2M
  } = useSimulation();

  const handleRunAiAgent = () => {
    triggerAIAgentSearch();
  };

  const handleM2MCharge = () => {
    triggerM2MCharge();
  };

  const handleM2MReset = () => {
    resetM2M();
  };

  return (
    <div id="ai-agents-and-m2m-micro-payments" className="space-y-6">
      
      {/* Title */}
      <div className="bg-[#1C2541] border border-[#2A375B] p-4 rounded text-white flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold tracking-tight font-serif uppercase text-[#C00000] flex items-center gap-2">
            <Cpu size={20} /> YAPAY ZEKA ÖDEME AJANLARI & M2M SİMÜLATÖRÜ
          </h2>
          <p className="text-xs text-[#8F9AA6] font-mono uppercase mt-0.5">
            OTONOM YAPAY ZEKA CÜZDANLARI VE CİHAZLAR ARASI MİKRO ÖDEME PROTOKOLLERİ
          </p>
        </div>
        <div className="text-[10px] font-mono bg-[#0B132B] px-3 py-1 border border-[#2A375B] rounded text-emerald-400 font-bold">
          AGENTS & IOT CORE v2.1
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* 1. AI Agents Panel (Section 28) */}
        <div className="bg-white border border-[#E2E8F0] p-4 rounded shadow-sm flex flex-col justify-between">
          <div>
            <div className="border-b border-[#F1F5F9] pb-2 mb-3">
              <h3 className="text-xs font-bold font-mono text-[#0B132B] uppercase">OTONOM YAPAY ZEKA AJANI</h3>
              <p className="text-[10px] text-[#5C6B73] font-mono mt-0.5">KENDİ KARAR MEKANİZMASIYLA DTL HARCAYAN SİMÜLE BOT</p>
            </div>

            <div className="bg-[#111A35] text-white p-4 rounded border border-[#1C2541] font-mono text-xs space-y-3 mb-4">
              <div className="flex justify-between items-center">
                <span className="font-bold text-white text-[11px]">{aiAgent.name}</span>
                <span className={`px-2 py-0.5 text-[9px] font-bold rounded ${
                  aiAgent.status === 'UYKUDA' ? 'bg-[#1C2541] text-[#8F9AA6]' : 'bg-[#C00000] text-white animate-pulse'
                }`}>
                  {aiAgent.status}
                </span>
              </div>
              
              <div className="space-y-1.5 text-[#8F9AA6] text-[11px]">
                <p>Ajan ID: <strong className="text-white">{aiAgent.id}</strong></p>
                <p>Yetkilendirilmiş Bütçe: <strong className="text-emerald-400">₺{aiAgent.authorizedBalance.toLocaleString('tr-TR')}</strong></p>
                <p>Max İşlem Limiti: <strong className="text-white">₺{aiAgent.maxTransactionLimit.toLocaleString('tr-TR')}</strong></p>
                <p>Onaylı Kategoriler: <strong className="text-white">{aiAgent.approvedCategories.join(', ')}</strong></p>
              </div>
            </div>

            {/* Run Decision Module */}
            <div className="bg-[#F8FAFC] border border-[#E2E8F0] p-3 rounded font-mono text-xs space-y-3">
              <span className="text-[10px] font-bold text-[#C00000] block uppercase">OTONOM KARAR SİMÜLASYONU</span>
              <p className="text-[10px] text-[#5C6B73]">Ajan, kargo faturası ve lojistik masrafları için en uygun rota ve sağlayıcıları bağımsız olarak analiz edip akıllı cüzdan ile ödemesini yapar.</p>

              <button
                onClick={handleRunAiAgent}
                disabled={aiAgent.status !== 'UYKUDA'}
                className="w-full bg-[#0B132B] hover:bg-[#1C2541] disabled:bg-[#5C6B73] text-white font-bold py-2 rounded text-xs uppercase transition flex justify-center items-center gap-1.5"
              >
                <Play size={11} />
                {aiAgent.status === 'UYKUDA' ? 'OTONOM ÖDEME KEŞFİNİ BAŞLAT' : 'İŞLEM SÜRÜYOR...'}
              </button>
            </div>
          </div>

          <div className="mt-4 p-2.5 bg-blue-50 border border-blue-100 text-blue-800 text-[10px] font-mono rounded flex items-center gap-1.5">
            <ShieldCheck size={14} className="text-blue-600 shrink-0" />
            <span>Ajanın tüm mali kararları akıllı sözleşme limitleri ve cüzdan KYC kuralları ile çevrelenmiştir.</span>
          </div>
        </div>

        {/* 2. M2M Payments (IoT Grid) */}
        <div className="bg-[#111A35] border border-[#1C2541] p-4 rounded text-white flex flex-col justify-between">
          <div>
            <div className="border-b border-[#1C2541] pb-2 mb-3">
              <h3 className="text-xs font-bold font-mono text-[#C00000] uppercase">M2M (CİHAZLAR ARASI) ÖDEME GEÇİTLERİ</h3>
              <p className="text-[10px] text-[#8F9AA6] font-mono mt-0.5">İOT ELEKTRİKLİ OTO ŞARJ VE VERİ SENSÖRÜ MİKRO TRANSFER SİMÜLASYONU</p>
            </div>

            <div className="space-y-4">
              {m2mDevices.map(device => (
                <div key={device.id} className="p-3 bg-[#1C2541] border border-[#2D3E6B] rounded space-y-2 font-mono text-xs">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-white flex items-center gap-1">
                      <Zap size={14} className="text-cyan-400" /> {device.name}
                    </span>
                    <span className="text-[9px] text-[#8F9AA6]">{device.id}</span>
                  </div>

                  <div className="text-[10px] text-[#8F9AA6] space-y-1">
                    <p>Batarya Oranı: <strong className="text-white">%{device.batteryOrFuel}</strong></p>
                    <p>Talep Edilen Hizmet: <strong className="text-white">{device.requiredService}</strong></p>
                    <p>Hesaplanan Tutar: <strong className="text-white">₺{device.cost}</strong></p>
                    <p>Onay Durumu: <strong className="text-cyan-400">{device.status}</strong></p>
                  </div>
                </div>
              ))}

              {/* Streaming Controls */}
              <div className="bg-[#0B132B] border border-[#1C2541] p-3 rounded space-y-3">
                <span className="text-[10px] font-bold text-cyan-400 block uppercase">OTONOM SENSÖR VE MUTABAKAT</span>
                <p className="text-[10px] text-[#8F9AA6]">TOGG Akıllı araç, şarj istasyonuna yaklaştığında otonom olarak DTL ödemesini gerçekleştirip elektrik yüklemesini onaylatır.</p>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={handleM2MReset}
                    className="py-2 border border-[#2D3E6B] hover:bg-[#1C2541] rounded text-xs uppercase font-bold transition flex justify-center items-center gap-1"
                  >
                    <RotateCcw size={12} /> SIFIRLA
                  </button>
                  <button
                    onClick={handleM2MCharge}
                    disabled={m2mDevices[0]?.status !== 'BEKLEMEDE'}
                    className="bg-emerald-700 hover:bg-emerald-600 disabled:bg-[#1C2541] disabled:text-[#5C6B73] text-white py-2 rounded text-xs uppercase font-bold transition flex justify-center items-center gap-1.5"
                  >
                    <Activity size={12} className={m2mDevices[0]?.status === 'SARJ_EDILIYOR' ? 'animate-pulse' : ''} />
                    ŞARJ ET VE ÖDE
                  </button>
                </div>
              </div>
            </div>
          </div>

          <div className="text-[9px] text-[#8F9AA6] font-mono border-t border-[#1C2541] pt-3 mt-4">
            * Cihazlar arası ödemeler (M2M), her saniye için donanım tabanlı kripto imzayla (Secure Element) güvenli bir şekilde RTGS ağına yazılır.
          </div>
        </div>

      </div>

    </div>
  );
}
