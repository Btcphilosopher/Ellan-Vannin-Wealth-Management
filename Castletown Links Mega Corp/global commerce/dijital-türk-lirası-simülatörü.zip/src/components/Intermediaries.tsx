/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useSimulation } from '../context/SimulationContext';
import { Building, AlertTriangle, ShieldCheck, Zap, Server, Activity, Play } from 'lucide-react';

export default function Intermediaries() {
  const {
    banks,
    paymentInstitutions,
    stressEvents,
    resolveStressEvent,
    triggerStressEvent
  } = useSimulation();

  const [selectedBankId, setSelectedBankId] = useState<string>('B-ANADOLU');
  const [stressDeficit, setStressDeficit] = useState<number>(1.2); // in Billions

  const activeBank = banks.find(b => b.id === selectedBankId) || banks[0];

  const handleTriggerStress = (bankId: string) => {
    triggerStressEvent(bankId, stressDeficit);
  };

  return (
    <div id="banking-and-intermediaries-module" className="space-y-6">
      
      {/* Title */}
      <div className="bg-[#1C2541] border border-[#2A375B] p-4 rounded text-white flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold tracking-tight font-serif uppercase text-[#C00000] flex items-center gap-2">
            <Building size={20} /> ARACI FİNANSAL KURUMLAR SİSTEMİ
          </h2>
          <p className="text-xs text-[#8F9AA6] font-mono uppercase mt-0.5">
            TİCARİ BANKACILIK SİSTEMİ VE ÖDEME KURULUŞLARI BİLANÇOLARI
          </p>
        </div>
        <div className="text-[10px] font-mono bg-[#0B132B] px-3 py-1 border border-[#2A375B] rounded text-[#C00000] font-bold">
          2-TIER BACKED LEDGER
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left: Bank Selector & Stress triggers */}
        <div className="bg-white border border-[#E2E8F0] p-4 rounded shadow-sm space-y-4">
          <div>
            <h3 className="text-xs font-bold font-mono text-[#0B132B] uppercase">SİMÜLE BANKALAR</h3>
            <p className="text-[10px] text-[#5C6B73] font-mono uppercase mt-0.5">BİLANÇOLARI İNCELEMEK VE STRES TESTİ UYGULAMAK İÇİN SEÇİN</p>
          </div>

          <div className="space-y-2 font-mono text-xs">
            {banks.map(b => {
              const hasStress = stressEvents.some(e => e.bankId === b.id);
              return (
                <div
                  key={b.id}
                  className={`w-full p-3 rounded border transition flex justify-between items-center ${
                    selectedBankId === b.id
                      ? 'bg-[#111A35] text-white border-[#C00000]'
                      : 'bg-[#F8FAFC] border-[#E2E8F0] text-[#0B132B] hover:bg-[#F1F5F9]'
                  }`}
                >
                  <button
                    onClick={() => setSelectedBankId(b.id)}
                    className="text-left font-bold truncate grow"
                  >
                    <div>{b.name}</div>
                    <div className="text-[10px] font-mono mt-1 text-[#8F9AA6] flex gap-2">
                      <span>Risk: {b.riskLevel}</span>
                      <span>API: {b.apiHealth}</span>
                    </div>
                  </button>

                  <div className="flex items-center gap-2 shrink-0">
                    {hasStress ? (
                      <span className="px-1.5 py-0.5 bg-red-900 text-red-200 border border-red-700 text-[9px] rounded animate-pulse font-bold">
                        AÇIK VAR
                      </span>
                    ) : (
                      <button
                        onClick={() => handleTriggerStress(b.id)}
                        className="p-1 rounded bg-[#E2E8F0] hover:bg-[#C00000] hover:text-white transition text-[#5C6B73]"
                        title="Likidite Stresi Tetikle"
                      >
                        <AlertTriangle size={11} />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Middle: Active Bank Balance Sheet (Section 9) */}
        <div className="bg-white border border-[#E2E8F0] p-4 rounded shadow-sm flex flex-col justify-between">
          <div>
            <div className="border-b border-[#F1F5F9] pb-2 mb-3 flex justify-between items-center">
              <span className="text-xs font-bold font-mono text-[#0B132B] uppercase">{activeBank.name} BİLANÇOSU</span>
              <span className="text-[9px] font-mono text-[#C00000] font-bold">ASSETS = LIABILITIES + EQUITY</span>
            </div>

            <div className="space-y-3 font-mono text-xs">
              
              {/* Assets */}
              <div className="bg-[#F8FAFC] border border-[#E2E8F0] p-2.5 rounded">
                <span className="text-[10px] font-bold text-[#C00000] block border-b border-[#E2E8F0] pb-1 mb-1.5 uppercase">AKTİFLER (ASSETS)</span>
                <div className="space-y-1">
                  <div className="flex justify-between"><span>Rezervler (RTGS):</span><span className="font-bold">₺{activeBank.balanceSheet.assets.reserves.toFixed(2)} Milyar</span></div>
                  <div className="flex justify-between"><span>Dijital Türk Lirası:</span><span className="font-bold text-emerald-600">₺{activeBank.balanceSheet.assets.digitalTL.toFixed(2)} Milyar</span></div>
                  <div className="flex justify-between"><span>Devlet Tahvilleri:</span><span className="font-bold">₺{activeBank.balanceSheet.assets.govSecurities.toFixed(2)} Milyar</span></div>
                  <div className="flex justify-between"><span>Krediler:</span><span className="font-bold">₺{activeBank.balanceSheet.assets.loans.toFixed(2)} Milyar</span></div>
                  <div className="flex justify-between font-bold border-t border-[#E2E8F0] pt-1 mt-1 text-[#0B132B]">
                    <span>TOPLAM AKTİF:</span>
                    <span>₺{(
                      activeBank.balanceSheet.assets.reserves + 
                      activeBank.balanceSheet.assets.digitalTL + 
                      activeBank.balanceSheet.assets.govSecurities + 
                      activeBank.balanceSheet.assets.loans
                    ).toFixed(2)} Milyar</span>
                  </div>
                </div>
              </div>

              {/* Liabilities */}
              <div className="bg-[#F8FAFC] border border-[#E2E8F0] p-2.5 rounded">
                <span className="text-[10px] font-bold text-[#0B132B] block border-b border-[#E2E8F0] pb-1 mb-1.5 uppercase">PASİFLER & ÖZ KAYNAK</span>
                <div className="space-y-1">
                  <div className="flex justify-between"><span>Müşteri Mevduatları:</span><span className="font-bold">₺{activeBank.balanceSheet.liabilities.deposits.toFixed(2)} Milyar</span></div>
                  <div className="flex justify-between"><span>Diğer Yükümlülükler:</span><span className="font-bold">₺{activeBank.balanceSheet.liabilities.otherLiabilities.toFixed(2)} Milyar</span></div>
                  <div className="flex justify-between"><span>Öz Kaynak (Sermaye):</span><span className="font-bold">₺{activeBank.balanceSheet.equity.capital.toFixed(2)} Milyar</span></div>
                  <div className="flex justify-between font-bold border-t border-[#E2E8F0] pt-1 mt-1 text-[#0B132B]">
                    <span>TOPLAM PASİF & ÖZ K.:</span>
                    <span>₺{(
                      activeBank.balanceSheet.liabilities.deposits + 
                      activeBank.balanceSheet.liabilities.otherLiabilities + 
                      activeBank.balanceSheet.equity.capital
                    ).toFixed(2)} Milyar</span>
                  </div>
                </div>
              </div>

            </div>
          </div>

          <div className="mt-4 p-2 bg-emerald-50 border border-emerald-200 text-emerald-800 text-[10px] font-mono rounded flex justify-between items-center">
            <span>Muhasebe Değişmezlik Güvencesi</span>
            <span className="font-bold text-emerald-600">DENGELİ</span>
          </div>
        </div>

        {/* Right: Liquidity Stress & Interventions Panel (Section 23) */}
        <div className="bg-[#111A35] border border-[#1C2541] p-4 rounded text-white flex flex-col justify-between">
          <div>
            <div className="border-b border-[#1C2541] pb-2 mb-3">
              <h3 className="text-xs font-bold font-mono text-[#C00000] uppercase">LİKİDİTE YÖNETİM MERKEZİ & STRES İZLEME</h3>
              <p className="text-[10px] text-[#8F9AA6] font-mono mt-0.5">SİSTEMİK RİSKLER VE ACİL DURUM LİKİDİTE DESTEK MEKANİZMASI</p>
            </div>

            <div className="space-y-4 font-mono text-xs">
              <div className="bg-[#1C2541] p-3 rounded border border-[#2D3E6B]">
                <span className="text-[10px] font-bold text-amber-400 block mb-1">STRES SENARYOSU PARAMETRESİ</span>
                <p className="text-[10px] text-[#8F9AA6]">Tetikleyici tetiklendiğinde bankadan rezerv mevduat çıkışı yapılır.</p>
                <div className="mt-2 flex gap-2 items-center">
                  <span className="text-[10px] text-[#8F9AA6]">Çıkış Tutarı:</span>
                  <input
                    type="number"
                    step="0.1"
                    min="0.1"
                    value={stressDeficit}
                    onChange={(e) => setStressDeficit(parseFloat(e.target.value) || 0)}
                    className="w-20 bg-[#0B132B] border border-[#2D3E6B] text-white p-1 rounded text-right font-bold"
                  />
                  <span className="text-[10px] text-[#8F9AA6]">milyar ₺</span>
                </div>
              </div>

              <div className="space-y-2">
                <span className="text-[10px] font-bold text-[#8F9AA6] uppercase block">AKTİF FİNANSAL STRES ALARMLARI</span>
                {stressEvents.length === 0 ? (
                  <div className="p-3 bg-emerald-950/40 border border-emerald-900 rounded text-emerald-400 text-[10px] flex items-center gap-2">
                    <ShieldCheck size={14} /> SİSTEMDE AKTİF LİKİDİTE AÇIĞI SİNYALİ YOKTUR. TÜM ARACILAR GÜVENDE.
                  </div>
                ) : (
                  stressEvents.map(event => (
                    <div key={event.bankId} className="p-3 bg-red-950/60 border border-red-800 rounded text-red-200 text-[10px] space-y-2">
                      <div className="flex items-center gap-1.5 font-bold text-red-400 uppercase">
                        <AlertTriangle size={14} className="animate-pulse" /> LİKİDİTE ACİĞİ ALARMI
                      </div>
                      <p>Bank: <span className="font-bold">{event.bankId}</span></p>
                      <p>Mevcut Rezerv: <span className="font-bold">₺{event.availableLiquidity.toFixed(2)} Milyar</span></p>
                      <p>Sistemik Açık: <span className="font-bold text-red-400">₺{(event.deficit * 1000).toFixed(0)} Milyon</span></p>
                      
                      <button
                        onClick={() => resolveStressEvent(event.bankId)}
                        className="w-full mt-2 bg-emerald-700 hover:bg-emerald-600 text-white font-bold py-1.5 px-3 rounded text-[10px] uppercase transition"
                      >
                        TCMB ACİL LİKİDİTE FONLAMASI SAĞLA
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          <div className="text-[10px] text-[#8F9AA6] font-mono border-t border-[#1C2541] pt-3 mt-4">
            * TCMB Açık Piyasa İşlemleri (APİ) ve munzam karşılık oranları simülasyon motorunca kontrol edilmektedir.
          </div>
        </div>

      </div>

      {/* SECTION B: Payment and Fintech Institutions (Section 10) */}
      <div className="bg-white border border-[#E2E8F0] p-4 rounded shadow-sm">
        <div className="border-b border-[#F1F5F9] pb-2 mb-3">
          <h3 className="text-xs font-bold font-mono text-[#0B132B] uppercase">DİJİTAL ÖDEME VE ELEKTRONİK PARA KURULUŞLARI (FİNTEK)</h3>
          <p className="text-[10px] text-[#5C6B73] font-mono mt-0.5">SİMÜLE FİNTEK KURULUŞLARI OPERASYONEL PARG ALTYAPISI</p>
        </div>

        <div className="overflow-x-auto font-mono text-xs">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-[#F8FAFC] text-[#5C6B73] border-b border-[#E2E8F0]">
                <th className="p-2">KURULUŞ ADI</th>
                <th className="p-2">MÜŞTERİ SAYISI</th>
                <th className="p-2 text-right">İŞLEM HACMİ (Yıllık ₺)</th>
                <th className="p-2 text-right">DİJİTAL PARA BAKİYESİ</th>
                <th className="p-2 text-right">E-PARA YÜKÜMLÜLÜĞÜ</th>
                <th className="p-2">UYUM/AML DURUMU</th>
                <th className="p-2 text-center">API SAĞLIĞI</th>
              </tr>
            </thead>
            <tbody>
              {paymentInstitutions.map(pi => (
                <tr key={pi.id} className="border-b border-[#F1F5F9] hover:bg-[#F8FAFC]">
                  <td className="p-2 font-bold text-[#0B132B]">{pi.name}</td>
                  <td className="p-2">{pi.customerCount.toLocaleString('tr-TR')}</td>
                  <td className="p-2 text-right font-bold">₺{pi.transactionVolume.toFixed(1)} Milyon</td>
                  <td className="p-2 text-right font-bold text-emerald-600">₺{pi.digitalTLBalance.toFixed(1)} Milyon</td>
                  <td className="p-2 text-right">₺{pi.eMoneyLiability.toFixed(1)} Milyon</td>
                  <td className="p-2">
                    <span className={`px-1.5 py-0.5 text-[9px] font-bold rounded ${
                      pi.complianceStatus === 'UYUMLU' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                    }`}>
                      {pi.complianceStatus}
                    </span>
                  </td>
                  <td className="p-2 text-center">
                    <span className="inline-block w-2 h-2 rounded-full bg-emerald-500" title="AKTİF"></span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}
