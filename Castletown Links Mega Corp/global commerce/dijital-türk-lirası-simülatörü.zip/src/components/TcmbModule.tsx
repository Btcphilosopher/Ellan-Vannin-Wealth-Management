/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useSimulation } from '../context/SimulationContext';
import { Landmark, ArrowRight, ShieldCheck, Play, RefreshCw, Scale } from 'lucide-react';

export default function TcmbModule() {
  const {
    tcmbBalanceSheet,
    banks,
    ihracEt,
    itfaEt,
    kurumsalTransfer,
    accountingLog,
    circulationAmount,
    accountingIntegrityStatus
  } = useSimulation();

  const [issueAmount, setIssueAmount] = useState<number>(5.0); // in Billions
  const [redeemAmount, setRedeemAmount] = useState<number>(2.0); // in Billions

  // Corporate transfer states
  const [fromBank, setFromBank] = useState<string>('B-ANADOLU');
  const [toBank, setToBank] = useState<string>('B-MARMARA');
  const [transferAmount, setTransferAmount] = useState<number>(0.5); // in Billions

  const [verificationResult, setVerificationResult] = useState<string | null>(null);
  const [isVerifying, setIsVerifying] = useState<boolean>(false);

  const handleIssue = (e: React.FormEvent) => {
    e.preventDefault();
    ihracEt(issueAmount);
  };

  const handleRedeem = (e: React.FormEvent) => {
    e.preventDefault();
    itfaEt(redeemAmount);
  };

  const handleCorporateTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    kurumsalTransfer(fromBank, toBank, transferAmount);
  };

  const triggerVerification = () => {
    setIsVerifying(true);
    setVerificationResult(null);
    setTimeout(() => {
      setIsVerifying(false);
      if (accountingIntegrityStatus === 'NORMAL') {
        setVerificationResult('TÜM HESAP DEFTERLERİ VE KRİPTOGRAFİK MUTABAKATLAR BAŞARIYLA DOĞRULANDI. AKTİF = PASİF + ÖZ KAYNAK SİGORTASI AKTİF.');
      } else {
        setVerificationResult('HATA: MUHASEBE DEFTERİNDE BALANS UYUMSUZLUĞU TESPİT EDİLDİ!');
      }
    }, 1200);
  };

  return (
    <div id="tcmb-operations-module" className="space-y-6">
      
      {/* Module Title Block */}
      <div className="bg-[#1C2541] border border-[#2A375B] p-4 rounded text-white flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold tracking-tight font-serif uppercase text-[#C00000] flex items-center gap-2">
            <Landmark size={20} /> MERKEZ BANKASI DİJİTAL PARA SİSTEMİ
          </h2>
          <p className="text-xs text-[#8F9AA6] font-mono uppercase mt-0.5">
            DİJİTAL TÜRK LİRASI ARZ SİSTEMLERİ VE MERKEZ BANKASI BİLANÇOSU
          </p>
        </div>
        <div className="text-[10px] font-mono bg-[#0B132B] px-3 py-1 border border-[#2A375B] rounded text-emerald-400 font-bold">
          TCMB EMISSION CORE v4.1
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* SECTION A: TCMB Double-Entry Balance Sheet */}
        <div className="bg-white border border-[#E2E8F0] p-4 rounded shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center border-b border-[#F1F5F9] pb-3 mb-4">
              <h3 className="text-xs font-bold font-mono text-[#0B132B] uppercase flex items-center gap-1">
                <Scale size={14} className="text-[#C00000]" /> SİMÜLE MERKEZ BANKASI BİLANÇOSU (TCMB)
              </h3>
              <span className="text-[10px] font-bold font-mono text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">
                ÇİFT KAYITLI DEFTER
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
              
              {/* Assets Section */}
              <div className="border border-[#E2E8F0] rounded p-3 bg-[#F8FAFC]">
                <h4 className="text-[10px] font-bold text-[#C00000] uppercase border-b border-[#E2E8F0] pb-1.5 mb-2">AKTİFLER (ASSETS)</h4>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Devlet Tahvilleri:</span>
                    <span className="font-bold">₺{tcmbBalanceSheet.assets.govSecurities.toFixed(1)} Milyar</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Dış Varlıklar (FX):</span>
                    <span className="font-bold">₺{tcmbBalanceSheet.assets.foreignAssets.toFixed(1)} Milyar</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Krediler:</span>
                    <span className="font-bold">₺{tcmbBalanceSheet.assets.loans.toFixed(1)} Milyar</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Teminatlı APİ:</span>
                    <span className="font-bold">₺{tcmbBalanceSheet.assets.collateralizedOps.toFixed(1)} Milyar</span>
                  </div>
                  <div className="flex justify-between border-t border-[#E2E8F0] pt-2 font-bold text-[#0B132B]">
                    <span>TOPLAM AKTİF:</span>
                    <span>₺{tcmbBalanceSheet.assets.total.toFixed(1)} Milyar</span>
                  </div>
                </div>
              </div>

              {/* Liabilities and Equity Section */}
              <div className="border border-[#E2E8F0] rounded p-3 bg-[#F8FAFC]">
                <h4 className="text-[10px] font-bold text-[#0B132B] uppercase border-b border-[#E2E8F0] pb-1.5 mb-2">PASİFLER & ÖZ KAYNAK</h4>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Tedavüldeki Banknotlar:</span>
                    <span className="font-bold">₺{tcmbBalanceSheet.liabilities.banknotes.toFixed(1)} Milyar</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Banka Rezervleri (APİ):</span>
                    <span className="font-bold">₺{tcmbBalanceSheet.liabilities.bankReserves.toFixed(1)} Milyar</span>
                  </div>
                  <div className="flex justify-between text-emerald-600 font-semibold">
                    <span>Dijital Türk Lirası:</span>
                    <span className="font-bold">₺{tcmbBalanceSheet.liabilities.digitalTL.toFixed(1)} Milyar</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Diğer Yükümlülükler:</span>
                    <span className="font-bold">₺{tcmbBalanceSheet.liabilities.otherLiabilities.toFixed(1)} Milyar</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Öz Kaynak (Sermaye):</span>
                    <span className="font-bold">₺{tcmbBalanceSheet.equity.capital.toFixed(1)} Milyar</span>
                  </div>
                  <div className="flex justify-between border-t border-[#E2E8F0] pt-2 font-bold text-[#0B132B]">
                    <span>TOPLAM PASİF + ÖZ K.:</span>
                    <span>₺{(tcmbBalanceSheet.liabilities.total + tcmbBalanceSheet.equity.capital).toFixed(1)} Milyar</span>
                  </div>
                </div>
              </div>

            </div>
          </div>

          {/* Validation Alert */}
          <div className="mt-4 p-2.5 bg-emerald-50 border border-emerald-200 text-emerald-800 text-[11px] font-mono rounded flex justify-between items-center">
            <span className="flex items-center gap-1">
              <ShieldCheck size={14} className="text-emerald-600" /> BİLANÇO GÜVENCESİ: AKTİFLER = PASİFLER + ÖZ KAYNAK (DENK)
            </span>
            <span className="font-bold text-emerald-600">DENK</span>
          </div>
        </div>

        {/* SECTION B: Issuance & Redemption Panel */}
        <div className="bg-[#111A35] border border-[#1C2541] p-4 rounded text-white space-y-4">
          <div className="border-b border-[#1C2541] pb-2">
            <h3 className="text-xs font-bold font-mono text-[#C00000] uppercase">DİJİTAL TÜRK LİRASI İHRAÇ VE İTFA MOTORU</h3>
            <p className="text-[10px] text-[#8F9AA6] font-mono mt-0.5">PARA ARZININ PARA POLİTİKASI GEREĞİNCE AYARLANMASI</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Issuance Form */}
            <form onSubmit={handleIssue} className="bg-[#1C2541] p-3 rounded border border-[#2A375B] space-y-3">
              <span className="text-[10px] font-bold font-mono text-emerald-400 uppercase block">İHRAÇ ET (EMIT / ISSUE)</span>
              <p className="text-[10px] text-[#8F9AA6] font-mono">Arzın artırılması için karşılık devlet tahvili bloke edilerek yeni DTL ihraç edilir.</p>
              <div>
                <label className="text-[10px] text-[#8F9AA6] font-mono block mb-1">MİKTAR (MİLYAR ₺):</label>
                <input
                  type="number"
                  step="0.1"
                  min="0.1"
                  value={issueAmount}
                  onChange={(e) => setIssueAmount(parseFloat(e.target.value) || 0)}
                  className="w-full bg-[#0B132B] border border-[#2D3E6B] text-white p-1.5 rounded text-xs font-mono text-right font-bold"
                />
              </div>
              <button
                type="submit"
                className="w-full bg-emerald-700 hover:bg-emerald-600 font-bold text-[11px] font-mono py-1.5 px-3 rounded text-white flex justify-center items-center gap-1 transition"
              >
                <Play size={11} /> İHRAÇ ET
              </button>
            </form>

            {/* Redemption Form */}
            <form onSubmit={handleRedeem} className="bg-[#1C2541] p-3 rounded border border-[#2A375B] space-y-3">
              <span className="text-[10px] font-bold font-mono text-red-400 uppercase block">İTFA ET (BURN / REDEEM)</span>
              <p className="text-[10px] text-[#8F9AA6] font-mono">Dolaşımdaki para azaltılarak Merkez Bankası bilançosundan silinir ve tahviller serbest kalır.</p>
              <div>
                <label className="text-[10px] text-[#8F9AA6] font-mono block mb-1">MİKTAR (MİLYAR ₺):</label>
                <input
                  type="number"
                  step="0.1"
                  min="0.1"
                  value={redeemAmount}
                  onChange={(e) => setRedeemAmount(parseFloat(e.target.value) || 0)}
                  className="w-full bg-[#0B132B] border border-[#2D3E6B] text-white p-1.5 rounded text-xs font-mono text-right font-bold"
                />
              </div>
              <button
                type="submit"
                className="w-full bg-red-700 hover:bg-red-600 font-bold text-[11px] font-mono py-1.5 px-3 rounded text-white flex justify-center items-center gap-1 transition"
              >
                <Play size={11} /> İTFA ET
              </button>
            </form>
          </div>
        </div>

      </div>

      {/* SECTION C: Corporate Interbank Transfers and Ledger Validation */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Interbank Transfer panel */}
        <div className="lg:col-span-2 bg-white border border-[#E2E8F0] p-4 rounded shadow-sm">
          <div className="border-b border-[#F1F5F9] pb-2 mb-3">
            <h3 className="text-xs font-bold font-mono text-[#0B132B] uppercase">KURUMSAL LİKİDİTE TRANSFER SİSTEMİ (RTGS)</h3>
            <p className="text-[10px] text-[#5C6B73] font-mono mt-0.5">SİMÜLE BANKALAR ARASI DİJİTAL TÜRK LİRASI AKTARIMI</p>
          </div>

          <form onSubmit={handleCorporateTransfer} className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end font-mono text-xs">
            <div>
              <label className="text-[10px] text-[#5C6B73] block mb-1">GÖNDEREN BANKA:</label>
              <select
                value={fromBank}
                onChange={(e) => setFromBank(e.target.value)}
                className="w-full border border-[#E2E8F0] bg-white p-1.5 rounded font-bold"
              >
                {banks.map(b => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </select>
            </div>

            <div className="flex justify-center pb-2 hidden md:block">
              <ArrowRight className="text-[#C00000] mx-auto" />
            </div>

            <div>
              <label className="text-[10px] text-[#5C6B73] block mb-1">ALICI BANKA:</label>
              <select
                value={toBank}
                onChange={(e) => setToBank(e.target.value)}
                className="w-full border border-[#E2E8F0] bg-white p-1.5 rounded font-bold"
              >
                {banks.map(b => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[10px] text-[#5C6B73] block mb-1">TUTAR (MİLYAR ₺):</label>
              <input
                type="number"
                step="0.01"
                min="0.01"
                value={transferAmount}
                onChange={(e) => setTransferAmount(parseFloat(e.target.value) || 0)}
                className="w-full border border-[#E2E8F0] p-1.5 rounded text-right font-bold"
              />
            </div>

            <div className="md:col-span-4">
              <button
                type="submit"
                disabled={fromBank === toBank}
                className="w-full bg-[#0B132B] hover:bg-[#1C2541] disabled:bg-[#5C6B73] font-bold py-2 px-4 rounded text-white text-[11px] uppercase transition"
              >
                KURUMSAL TRANSFER GERÇEKLEŞTİR
              </button>
            </div>
          </form>
        </div>

        {/* Ledger Cryptographic Validation */}
        <div className="bg-[#111A35] border border-[#1C2541] p-4 rounded text-white flex flex-col justify-between">
          <div>
            <h3 className="text-xs font-bold font-mono text-[#C00000] uppercase border-b border-[#1C2541] pb-2">
              KRİPTOGRAFİK MUTABAKAT DOĞRULAMA
            </h3>
            <p className="text-[10px] text-[#8F9AA6] font-mono mt-1">AĞ DEFTERİNDEKİ HASH ZİNCİRİNİN VE ÇİFT HARCAMALARIN MATEMATİKSEL KONTROLÜ</p>
          </div>

          <div className="py-2">
            {verificationResult ? (
              <div className="p-2 bg-emerald-950/50 border border-emerald-800 text-emerald-400 text-[10px] font-mono rounded">
                {verificationResult}
              </div>
            ) : (
              <p className="text-[10px] font-mono text-[#8F9AA6]">Motor kontrolü bekleniyor.</p>
            )}
          </div>

          <button
            onClick={triggerVerification}
            disabled={isVerifying}
            className="w-full bg-[#1C2541] hover:bg-[#2A375B] text-white border border-[#2D3E6B] py-2 px-3 rounded flex justify-center items-center gap-2 transition text-[11px] font-mono font-bold"
          >
            <RefreshCw size={12} className={isVerifying ? 'animate-spin' : ''} />
            {isVerifying ? 'HESAPLANIYOR...' : 'DEFTERİ DOĞRULA & MUTABAKAT BAŞLAT'}
          </button>
        </div>

      </div>

      {/* SECTION D: Audit Log from state */}
      <div className="bg-white border border-[#E2E8F0] p-4 rounded shadow-sm">
        <h3 className="text-xs font-bold font-mono text-[#0B132B] uppercase border-b border-[#F1F5F9] pb-2 mb-3">TCMB HESAP DENETİM LOGU (KRONOLOJİK)</h3>
        <div className="space-y-1.5 h-32 overflow-y-auto font-mono text-[10px] text-[#5C6B73]">
          {accountingLog.map((log, idx) => (
            <div key={idx} className="flex gap-2 p-1.5 border-b border-[#F1F5F9] hover:bg-[#F8FAFC]">
              <span className="text-[#C00000] font-bold">▶</span>
              <span>{log}</span>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}
