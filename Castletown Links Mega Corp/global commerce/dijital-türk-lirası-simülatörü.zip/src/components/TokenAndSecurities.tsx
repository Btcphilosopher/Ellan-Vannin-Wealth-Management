/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useSimulation } from '../context/SimulationContext';
import { Layers, ShieldCheck, Play, DollarSign, Award, CreditCard, ShoppingBag } from 'lucide-react';

export default function TokenAndSecurities() {
  const {
    securities,
    vouchers,
    buyTokenizedSecurity,
    useDigitalVoucher,
    selectedWalletId,
    wallets
  } = useSimulation();

  const [tradeAmount, setTradeAmount] = useState<number>(10000.00);
  const [selectedSecurityId, setSelectedSecurityId] = useState<string>('SEC-01');
  const [tradeStatus, setTradeStatus] = useState<string | null>(null);
  const [isTrading, setIsTrading] = useState<boolean>(false);

  const activeWallet = wallets.find(w => w.id === selectedWalletId) || wallets[0];

  const handleBuySecurity = (e: React.FormEvent) => {
    e.preventDefault();
    if (tradeAmount <= 0) return;

    setIsTrading(true);
    setTradeStatus(null);

    setTimeout(() => {
      const success = buyTokenizedSecurity(selectedSecurityId, tradeAmount, activeWallet.id);
      setIsTrading(false);
      if (success) {
        setTradeStatus(`ATOMİK TAKAS TAMAMLANDI! DvP (Teslimat Karşılığı Ödeme) onaylandı. Tahviller cüzdanınıza transfer edildi.`);
      } else {
        setTradeStatus('HATA: Cüzdandaki kullanılabilir bakiye yetersiz.');
      }
    }, 1000);
  };

  const handleSpendVoucher = (voucherId: string, amount: number, recipient: string) => {
    useDigitalVoucher(voucherId, amount, recipient);
  };

  return (
    <div id="tokenization-and-securities-platform" className="space-y-6">
      
      {/* Title */}
      <div className="bg-[#1C2541] border border-[#2A375B] p-4 rounded text-white flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold tracking-tight font-serif uppercase text-[#C00000] flex items-center gap-2">
            <Layers size={20} /> TOKENİZASYON VE TAHVİL PLATFORMU
          </h2>
          <p className="text-xs text-[#8F9AA6] font-mono uppercase mt-0.5">
            DİJİTAL VARLIK TOKENİZASYONU, TAHVİL TAKASLARI (DVP) VE DESTEK SİSTEMLERİ (VALE)
          </p>
        </div>
        <div className="text-[10px] font-mono bg-[#0B132B] px-3 py-1 border border-[#2A375B] rounded text-emerald-400 font-bold">
          DVP COMPLIANT v1.8
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* 1. Securities Trading (DvP) (Section 18) */}
        <div className="bg-white border border-[#E2E8F0] p-4 rounded shadow-sm flex flex-col justify-between">
          <div>
            <div className="border-b border-[#F1F5F9] pb-2 mb-3">
              <h3 className="text-xs font-bold font-mono text-[#0B132B] uppercase">TOKENİZE MENKUL KIYMETLER MARKETİ (DVP)</h3>
              <p className="text-[10px] text-[#5C6B73] font-mono mt-0.5">ATOMİK TAKAS MODELİ İLE DEVLET TAHVİLİ VE BONO ALIM-SATIMI</p>
            </div>

            <div className="space-y-3 font-mono text-xs">
              {securities.map(sec => (
                <div key={sec.id} className="p-3 bg-[#F8FAFC] border border-[#E2E8F0] rounded flex justify-between items-center">
                  <div>
                    <span className="font-bold text-[#0B132B]">{sec.name}</span>
                    <div className="text-[10px] text-[#5C6B73] mt-1 space-x-3">
                      <span>Kodu: <strong className="text-[#0B132B]">{sec.ticker}</strong></span>
                      <span>Yıllık Getiri: <strong className="text-emerald-600">%{sec.yieldRate.toFixed(1)}</strong></span>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] text-[#5C6B73] block">Nominal Değer:</span>
                    <span className="font-bold">₺{sec.nominalValue}</span>
                  </div>
                </div>
              ))}
            </div>

            {/* Trading Form */}
            <form onSubmit={handleBuySecurity} className="mt-4 bg-[#F8FAFC] border border-[#E2E8F0] p-3 rounded space-y-3 font-mono text-xs">
              <span className="text-[10px] font-bold text-[#C00000] block uppercase">ATOMİK TAHVİL SATIN ALIMI</span>
              
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[9px] text-[#5C6B73] block mb-1">ENSTRÜMAN SEÇİN:</label>
                  <select
                    value={selectedSecurityId}
                    onChange={(e) => setSelectedSecurityId(e.target.value)}
                    className="w-full border border-[#E2E8F0] bg-white p-1 rounded font-bold"
                  >
                    {securities.map(s => (
                      <option key={s.id} value={s.id}>{s.name} ({s.ticker})</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-[9px] text-[#5C6B73] block mb-1">TUTAR (TL):</label>
                  <input
                    type="number"
                    step="500"
                    min="500"
                    value={tradeAmount}
                    onChange={(e) => setTradeAmount(parseFloat(e.target.value) || 0)}
                    className="w-full border border-[#E2E8F0] p-1 rounded font-bold text-right"
                  />
                </div>
              </div>

              <div className="text-[9px] text-[#5C6B73] space-y-1 p-2 bg-white border border-[#E2E8F0] rounded">
                <p>Alıcı Cüzdanı: <span className="font-bold text-[#0B132B]">{activeWallet.owner}</span></p>
                <p>Mevcut DTL Bakiye: <span className="font-bold">₺{activeWallet.availableBalance.toLocaleString('tr-TR')}</span></p>
              </div>

              <button
                type="submit"
                disabled={isTrading}
                className="w-full bg-[#0B132B] hover:bg-[#1C2541] text-white font-bold py-2 rounded text-xs uppercase transition flex justify-center items-center gap-1.5"
              >
                <Play size={11} />
                {isTrading ? 'TAKAS YAPILIYOR...' : 'ATOMİK DVP SATIN ALIMI YAP'}
              </button>
            </form>
          </div>

          <div className="mt-4">
            {tradeStatus && (
              <div className="p-2.5 bg-emerald-50 border border-[#A7F3D0] text-emerald-800 text-[10px] font-mono rounded flex items-start gap-1">
                <ShieldCheck size={14} className="text-emerald-600 shrink-0 mt-0.5" />
                <span>{tradeStatus}</span>
              </div>
            )}
          </div>
        </div>

        {/* 2. Digital Vouchers (Dijital Vale / Dijital Destek) (Section 19) */}
        <div className="bg-[#111A35] border border-[#1C2541] p-4 rounded text-white flex flex-col justify-between">
          <div>
            <div className="border-b border-[#1C2541] pb-2 mb-3">
              <h3 className="text-xs font-bold font-mono text-[#C00000] uppercase">DİJİTAL DESTEK VE VALE SİSTEMİ (VOUCHERS)</h3>
              <p className="text-[10px] text-[#8F9AA6] font-mono mt-0.5">DEVLET VE BELEDİYE DESTEKLERİNİN PROGRAMLANABİLİR DAĞITIMI</p>
            </div>

            <div className="space-y-3 font-mono text-xs">
              {vouchers.map(v => (
                <div key={v.id} className="p-3 bg-[#1C2541] border border-[#2D3E6B] rounded space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-white">{v.title}</span>
                    <span className={`px-1.5 py-0.5 text-[8px] font-bold rounded ${
                      v.status === 'AKTIF' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-gray-950 text-gray-500 border border-gray-800'
                    }`}>
                      {v.status}
                    </span>
                  </div>

                  <div className="text-[10px] text-[#8F9AA6] space-y-1">
                    <p>Alıcı: <span className="font-bold text-white">{v.recipient}</span></p>
                    <p>Miktar: <span className="font-bold text-white">₺{v.amount.toLocaleString('tr-TR')}</span></p>
                    <p>Geçerli Alanlar: <span className="text-white font-semibold">{v.usableFields.join(', ')}</span></p>
                    <p>Son Kullanım: <span className="text-amber-400">{v.expirationDate}</span></p>
                  </div>

                  {v.status === 'AKTIF' && (
                    <button
                      onClick={() => handleSpendVoucher(v.id, v.amount, v.recipient)}
                      className="w-full mt-2 bg-emerald-700 hover:bg-emerald-600 text-white font-bold py-1 px-3 rounded text-[10px] uppercase transition flex justify-center items-center gap-1"
                    >
                      <ShoppingBag size={11} /> KUPONU AKTİF ET & HARCA (DİJİTAL TL TRANSFERİ)
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="text-[9px] text-[#8F9AA6] font-mono border-t border-[#1C2541] pt-3 mt-4">
            * Destek kuponları (Dijital Vale), harcama anında akıllı kısıtlamalar doğrultusunda Gelir İdaresi Başkanlığı cüzdanından alıcı cüzdana doğrudan DTL ödemesi yapar.
          </div>
        </div>

      </div>

    </div>
  );
}
