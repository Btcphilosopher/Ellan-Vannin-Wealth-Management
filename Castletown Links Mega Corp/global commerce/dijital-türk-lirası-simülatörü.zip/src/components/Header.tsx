/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useSimulation } from '../context/SimulationContext';
import { Shield, Activity, RefreshCw, Cpu, Database, AlertCircle, Clock } from 'lucide-react';

export default function Header() {
  const {
    simulationTime,
    simulationSpeed,
    setSimulationSpeed,
    accountingIntegrityStatus,
    circulationAmount,
    avgTps,
    pendingTxCount
  } = useSimulation();

  return (
    <header id="tcmb-system-header" className="bg-[#0B132B] border-b border-[#1C2541] text-[#E0E6ED] select-none">
      {/* Persistent Research Disclaimer Banner */}
      <div id="disclaimer-header-banner" className="bg-[#8B0000] text-white text-[11px] font-bold py-1 px-4 text-center tracking-wider uppercase border-b border-[#A30000] flex justify-between items-center">
        <span>SİMÜLASYON ORTAMI • SENTETİK VERİ • ARAŞTIRMA PROTOTİPİ</span>
        <span className="hidden md:inline text-[10px] opacity-90">SIMULATION ENVIRONMENT • SYNTHETIC DATA • RESEARCH PROTOTYPE</span>
      </div>

      <div className="max-w-[1600px] mx-auto px-4 py-3 flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
        {/* Title Block */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded border border-[#C00000] flex items-center justify-center bg-[#1C2541] font-serif text-white font-bold text-lg">
            T
          </div>
          <div>
            <h1 className="text-sm font-semibold tracking-wide text-white uppercase flex items-center gap-2">
              TÜRKİYE CUMHURİYET MERKEZ BANKASI
              <span className="px-1.5 py-0.5 text-[9px] font-mono bg-emerald-950 text-emerald-400 border border-emerald-800 rounded">RE-LAB</span>
            </h1>
            <p className="text-xs text-[#5C6B73] font-mono tracking-tight uppercase">
              DİJİTAL TÜRK LİRASI — PARA VE FİNANSAL ALTYAPI SİMÜLATÖRÜ
            </p>
          </div>
        </div>

        {/* Operational Indicators */}
        <div className="flex flex-wrap items-center gap-2 text-[11px] font-mono w-full lg:w-auto">
          <div className="flex items-center gap-1.5 px-2 py-1 bg-[#1C2541] border border-[#2A375B] rounded">
            <span className="text-[#5C6B73]">SİSTEM:</span>
            <span className="text-emerald-400 font-bold flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span> NORMAL
            </span>
          </div>

          <div className="flex items-center gap-1.5 px-2 py-1 bg-[#1C2541] border border-[#2A375B] rounded">
            <span className="text-[#5C6B73]">DİJİTAL PARA:</span>
            <span className="text-emerald-400 font-bold">AKTİF</span>
          </div>

          <div className="flex items-center gap-1.5 px-2 py-1 bg-[#1C2541] border border-[#2A375B] rounded">
            <span className="text-[#5C6B73]">ANA DEFTER:</span>
            <span className="text-emerald-400 font-bold">SENKRONİZE</span>
          </div>

          <div className="flex items-center gap-1.5 px-2 py-1 bg-[#1C2541] border border-[#2A375B] rounded">
            <span className="text-[#5C6B73]">ÖDEME AĞI:</span>
            <span className="text-emerald-400 font-bold">NORMAL</span>
          </div>

          <div className="flex items-center gap-1.5 px-2 py-1 bg-[#1C2541] border border-[#2A375B] rounded">
            <span className="text-[#5C6B73]">LİKİDİTE:</span>
            <span className="text-emerald-400 font-bold">STABİL</span>
          </div>

          <div className="flex items-center gap-1.5 px-2 py-1 bg-[#1C2541] border border-[#2A375B] rounded">
            <span className="text-[#5C6B73]">RİSK:</span>
            <span className="text-emerald-400 font-bold">DÜŞÜK</span>
          </div>

          <div className="flex items-center gap-1.5 px-2 py-1 bg-[#1C2541] border border-[#2A375B] rounded">
            <span className="text-[#5C6B73]">GÜVENLİK:</span>
            <span className="text-emerald-400 font-bold">NORMAL</span>
          </div>

          <div className="flex items-center gap-1.5 px-2 py-1 bg-[#1C2541] border border-[#2A375B] rounded">
            <span className="text-[#5C6B73]">MUHASEBE:</span>
            <span className={accountingIntegrityStatus === 'NORMAL' ? 'text-emerald-400 font-bold' : 'text-red-400 font-bold animate-pulse'}>
              {accountingIntegrityStatus === 'NORMAL' ? 'DOĞRULANDI' : 'İHLAL SİNYALİ'}
            </span>
          </div>
        </div>
      </div>

      {/* Primary Simulation Metrics Bar & Clock Control */}
      <div className="bg-[#111A35] border-t border-[#1C2541] py-2 px-4 text-xs">
        <div className="max-w-[1600px] mx-auto flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          
          <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-[#8F9AA6] font-mono">
            <div className="flex items-center gap-1.5">
              <Clock size={13} className="text-[#C00000]" />
              <span className="text-[#5C6B73]">SİMÜLASYON SÜRESİ:</span>
              <span className="text-white font-bold tracking-wider">{simulationTime}</span>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-[#5C6B73]">HIZ:</span>
              <div className="flex items-center bg-[#0B132B] border border-[#1C2541] rounded px-1 py-0.5">
                {[1, 10, 100, 1000, 10000].map(speed => (
                  <button
                    key={speed}
                    onClick={() => setSimulationSpeed(speed)}
                    className={`px-1.5 py-0.5 text-[10px] rounded transition-all font-bold ${
                      simulationSpeed === speed
                        ? 'bg-[#C00000] text-white'
                        : 'text-[#8F9AA6] hover:text-white'
                    }`}
                  >
                    {speed}x
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-[11px] font-mono">
            <div className="flex items-center gap-1">
              <span className="text-[#5C6B73]">ARZ:</span>
              <span className="text-white font-bold">₺{circulationAmount.toFixed(1)}Milyar</span>
            </div>
            <div className="text-[#1C2541] hidden md:inline">|</div>
            <div className="flex items-center gap-1">
              <span className="text-[#5C6B73]">ORT. TPS:</span>
              <span className="text-[#E0E6ED] font-bold">{avgTps.toLocaleString()}</span>
            </div>
            <div className="text-[#1C2541] hidden md:inline">|</div>
            <div className="flex items-center gap-1">
              <span className="text-[#5C6B73]">BEKLEYEN İŞLEM:</span>
              <span className={`font-bold ${pendingTxCount > 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
                {pendingTxCount}
              </span>
            </div>
          </div>

        </div>
      </div>
    </header>
  );
}
