/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useSimulation } from '../context/SimulationContext';
import { 
  DollarSign, Users, RefreshCw, Layers, TrendingUp, AlertTriangle, ShieldCheck, 
  ExternalLink, HardDrive, Cpu, Zap, Coins, Key, Radio, Globe, Send, Play
} from 'lucide-react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';

export default function Dashboard() {
  const {
    circulationAmount,
    activeWalletCount,
    dailyTxCount,
    dailyTxAmount,
    avgSettlementTime,
    activeInstitutions,
    avgTps,
    pendingTxCount,
    banks,
    ledger,
    aiAgent,
    m2mDevices,
    stressEvents,
    vouchers,
    programmablePayments,
    offlineState,
    economicModel,
    currentScenario,
    changeEconomicScenario,
    ihracEt,
    triggerAIAgentSearch,
    triggerM2MCharge,
    resolveStressEvent,
    setActiveTab
  } = useSimulation();

  // Synthetic trend data for the charts (deterministic based on scenario)
  const getChartData = () => {
    const multiplier = currentScenario === 'YUKSEK_KULLANIM' ? 1.4 : currentScenario === 'DUSUK_KULLANIM' ? 0.7 : 1.0;
    return [
      { time: '09:00', tps: 3800 * multiplier, volume: 1.1 * multiplier },
      { time: '09:10', tps: 4200 * multiplier, volume: 1.3 * multiplier },
      { time: '09:20', tps: 4100 * multiplier, volume: 1.2 * multiplier },
      { time: '09:30', tps: 4900 * multiplier, volume: 1.6 * multiplier },
      { time: '09:40', tps: avgTps * multiplier, volume: dailyTxAmount * multiplier },
    ];
  };

  return (
    <div id="national-command-center" className="space-y-6">
      
      {/* 1. Main System Header & Scenario Controller */}
      <div className="bg-[#1C2541] border border-[#2A375B] p-4 rounded text-white flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-base font-bold tracking-tight font-serif uppercase text-[#C00000]">
            ULUSAL FİNANSAL ALTYAPI KONTROL MERKEZİ
          </h2>
          <p className="text-xs text-[#8F9AA6] font-mono uppercase mt-0.5">
            DİJİTAL TÜRK LİRASI BÜTÜNLEŞİK SİMÜLASYON İZLEME PANELİ
          </p>
        </div>

        {/* Economic Scenario Selector */}
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs font-mono text-[#8F9AA6]">PARA POLİTİKASI SENARYOSU:</span>
          <div className="flex bg-[#0B132B] border border-[#2A375B] rounded p-0.5">
            {[
              { code: 'BAZ', label: 'BAZ SENARYO' },
              { code: 'YUKSEK_KULLANIM', label: 'YÜKSEK DTL KULLANIMI' },
              { code: 'DUSUK_KULLANIM', label: 'DÜŞÜK DTL KULLANIMI' },
              { code: 'LIKIDITE_STRESI', label: 'LİKİDİTE STRESİ' }
            ].map(sc => (
              <button
                key={sc.code}
                onClick={() => changeEconomicScenario(sc.code)}
                className={`px-2 py-1 text-[10px] font-mono rounded font-bold transition-all ${
                  currentScenario === sc.code
                    ? 'bg-[#C00000] text-white'
                    : 'text-[#8F9AA6] hover:text-white'
                }`}
              >
                {sc.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* 2. Key Operational Metrics Grid (Section 6) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-[#E2E8F0] p-4 rounded shadow-sm">
          <div className="flex justify-between items-start">
            <span className="text-[10px] font-bold text-[#5C6B73] font-mono uppercase tracking-wider">DİJİTAL TÜRK LİRASI DOLAŞIMI</span>
            <Coins size={14} className="text-[#C00000]" />
          </div>
          <div className="mt-2 flex items-baseline gap-1.5">
            <span className="text-2xl font-bold font-mono tracking-tight text-[#0B132B]">
              ₺{circulationAmount.toFixed(1)}
            </span>
            <span className="text-xs text-[#5C6B73] font-bold font-mono">milyar</span>
          </div>
          <div className="mt-1 text-[10px] text-emerald-600 font-mono flex items-center gap-1">
            <span>MODEL SİMÜLASYONU</span>
          </div>
        </div>

        <div className="bg-white border border-[#E2E8F0] p-4 rounded shadow-sm">
          <div className="flex justify-between items-start">
            <span className="text-[10px] font-bold text-[#5C6B73] font-mono uppercase tracking-wider">AKTİF CÜZDAN SAYISI</span>
            <Users size={14} className="text-[#0B132B]" />
          </div>
          <div className="mt-2 flex items-baseline gap-1.5">
            <span className="text-2xl font-bold font-mono tracking-tight text-[#0B132B]">
              {activeWalletCount.toFixed(1)}
            </span>
            <span className="text-xs text-[#5C6B73] font-bold font-mono">milyon</span>
          </div>
          <div className="mt-1 text-[10px] text-[#5C6B73] font-mono">
            BENZERSİZ SENTETİK KİMLİK
          </div>
        </div>

        <div className="bg-white border border-[#E2E8F0] p-4 rounded shadow-sm">
          <div className="flex justify-between items-start">
            <span className="text-[10px] font-bold text-[#5C6B73] font-mono uppercase tracking-wider">GÜNLÜK İŞLEM SAYISI</span>
            <Layers size={14} className="text-[#0B132B]" />
          </div>
          <div className="mt-2 flex items-baseline gap-1.5">
            <span className="text-2xl font-bold font-mono tracking-tight text-[#0B132B]">
              {dailyTxCount.toFixed(1)}
            </span>
            <span className="text-xs text-[#5C6B73] font-bold font-mono">milyon</span>
          </div>
          <div className="mt-1 text-[10px] text-[#5C6B73] font-mono">
            YILLIK KÜMÜLATİF PROJEKSİYON
          </div>
        </div>

        <div className="bg-white border border-[#E2E8F0] p-4 rounded shadow-sm">
          <div className="flex justify-between items-start">
            <span className="text-[10px] font-bold text-[#5C6B73] font-mono uppercase tracking-wider">GÜNLÜK İŞLEM TUTARI</span>
            <DollarSign size={14} className="text-[#0B132B]" />
          </div>
          <div className="mt-2 flex items-baseline gap-1.5">
            <span className="text-2xl font-bold font-mono tracking-tight text-[#0B132B]">
              ₺{dailyTxAmount.toFixed(2)}
            </span>
            <span className="text-xs text-[#5C6B73] font-bold font-mono">trilyon</span>
          </div>
          <div className="mt-1 text-[10px] text-[#5C6B73] font-mono">
            BRÜT ANLIK MUTABAKAT (RTGS)
          </div>
        </div>
      </div>

      {/* Auxiliary Metrics Line */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs font-mono">
        <div className="bg-[#111A35] text-white border border-[#1C2541] p-3 rounded flex justify-between items-center">
          <span className="text-[#8F9AA6] text-[10px]">ORT. MUTABAKAT SÜRESİ:</span>
          <span className="font-bold text-emerald-400">{avgSettlementTime} sn</span>
        </div>
        <div className="bg-[#111A35] text-white border border-[#1C2541] p-3 rounded flex justify-between items-center">
          <span className="text-[#8F9AA6] text-[10px]">AKTİF SİMÜLE KURUM:</span>
          <span className="font-bold text-white">{activeInstitutions}</span>
        </div>
        <div className="bg-[#111A35] text-white border border-[#1C2541] p-3 rounded flex justify-between items-center">
          <span className="text-[#8F9AA6] text-[10px]">SİMÜLASYON ANLIK TPS:</span>
          <span className="font-bold text-white">{avgTps.toLocaleString()}</span>
        </div>
        <div className="bg-[#111A35] text-white border border-[#1C2541] p-3 rounded flex justify-between items-center">
          <span className="text-[#8F9AA6] text-[10px]">BEKLEYEN İŞLEM (AĞ):</span>
          <span className="font-bold text-amber-400">{pendingTxCount}</span>
        </div>
      </div>

      {/* 3. Mid-section: Visualizing the Real-time Transaction Traffic */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Graph */}
        <div className="lg:col-span-2 bg-white border border-[#E2E8F0] p-4 rounded shadow-sm flex flex-col justify-between">
          <div className="flex justify-between items-center border-b border-[#F1F5F9] pb-3 mb-4">
            <div>
              <h3 className="text-xs font-bold font-mono text-[#0B132B] uppercase">DİJİTAL TÜRK LİRASI HIZ VE HACİM GRAFİĞİ</h3>
              <p className="text-[10px] text-[#5C6B73] font-mono uppercase mt-0.5">SİNYAL PERİYODU BOYUNCA SİMÜLE EDİLEN TPS DEĞERLERİ</p>
            </div>
            <span className="text-[10px] font-bold font-mono bg-[#F1F5F9] px-2 py-0.5 rounded text-[#0B132B]">
              {currentScenario} MODU
            </span>
          </div>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={getChartData()} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorTps" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#C00000" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#C00000" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F1F5F9" />
                <XAxis dataKey="time" tick={{ fontSize: 10, fill: '#5C6B73', fontFamily: 'monospace' }} />
                <YAxis tick={{ fontSize: 10, fill: '#5C6B73', fontFamily: 'monospace' }} />
                <Tooltip />
                <Area type="monotone" dataKey="tps" name="TPS" stroke="#C00000" strokeWidth={1.5} fillOpacity={1} fill="url(#colorTps)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Rapid Actions Quick Control Panel */}
        <div className="bg-[#111A35] border border-[#1C2541] p-4 rounded text-white flex flex-col justify-between">
          <div>
            <h3 className="text-xs font-bold font-mono tracking-wide text-[#C00000] border-b border-[#1C2541] pb-2 uppercase">
              ACİL DURUM / OPERASYON KISA YOLLARI
            </h3>
            <p className="text-[10px] text-[#8F9AA6] font-mono mt-1 uppercase">SİMÜLASYON MOTORUNU TETİKLEYECEK ANLIK KOMUTLAR</p>
            
            <div className="space-y-2 mt-4 text-[11px] font-mono">
              <button 
                onClick={() => ihracEt(10.0)}
                className="w-full bg-[#1C2541] hover:bg-[#2A375B] text-white border border-[#2D3E6B] py-2 px-3 rounded flex justify-between items-center transition"
              >
                <span>TCMB: ₺10 MİLYAR DTL İHRAÇ ET</span>
                <Play size={12} className="text-emerald-400" />
              </button>

              <button 
                onClick={() => triggerAIAgentSearch()}
                className="w-full bg-[#1C2541] hover:bg-[#2A375B] text-white border border-[#2D3E6B] py-2 px-3 rounded flex justify-between items-center transition"
              >
                <span>AI AJAN: OTONOM SÜREÇ BAŞLAT</span>
                <Zap size={12} className="text-amber-400" />
              </button>

              <button 
                onClick={() => triggerM2MCharge()}
                className="w-full bg-[#1C2541] hover:bg-[#2A375B] text-white border border-[#2D3E6B] py-2 px-3 rounded flex justify-between items-center transition"
              >
                <span>M2M: ARAÇ ŞARJ PROSESİ BAŞLAT</span>
                <Radio size={12} className="text-cyan-400" />
              </button>

              {stressEvents.length > 0 && (
                <button 
                  onClick={() => resolveStressEvent(stressEvents[0].bankId)}
                  className="w-full bg-red-950 hover:bg-red-900 text-red-100 border border-red-700 py-2 px-3 rounded flex justify-between items-center transition animate-pulse"
                >
                  <span>LİKİDİTE GÜVENCESİ SAĞLA ({stressEvents[0].bankId})</span>
                  <AlertTriangle size={12} className="text-red-400" />
                </button>
              )}
            </div>
          </div>

          <div className="border-t border-[#1C2541] pt-3 mt-4 text-[10px] text-[#8F9AA6] font-mono flex items-center justify-between">
            <span>YAPAY ZEKA AJANI DR:</span>
            <span className={aiAgent.status !== 'UYKUDA' ? 'text-amber-400 font-bold' : 'text-emerald-400 font-bold'}>
              {aiAgent.status}
            </span>
          </div>
        </div>
      </div>

      {/* 4. Multi-system Operations Grid Overview */}
      <h3 className="text-xs font-bold font-mono text-[#0B132B] uppercase mt-6 tracking-wider">MODÜLER SİSTEM ÖZETLERİ</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        
        {/* Central Bank */}
        <div className="bg-white border border-[#E2E8F0] p-4 rounded shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center border-b border-[#F1F5F9] pb-2 mb-3">
              <span className="text-xs font-bold font-mono text-[#0B132B]">TCMB BİLANÇO OPERASYONU</span>
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            </div>
            <div className="space-y-1.5 text-xs font-mono">
              <div className="flex justify-between"><span className="text-[#5C6B73]">Toplam Aktif:</span><span className="font-bold">₺400,00 Milyar</span></div>
              <div className="flex justify-between"><span className="text-[#5C6B73]">Dijital Lira Yükümlülüğü:</span><span className="font-bold">₺{circulationAmount.toFixed(2)} Milyar</span></div>
              <div className="flex justify-between"><span className="text-[#5C6B73]">Sermaye Dengesi:</span><span className="text-emerald-600 font-bold">MUTABIK (DENK)</span></div>
            </div>
          </div>
          <button 
            onClick={() => setActiveTab('MERKEZ BANKASI')}
            className="w-full mt-4 text-[11px] font-bold font-mono bg-[#0B132B] text-white hover:bg-[#1C2541] py-1.5 rounded flex justify-center items-center gap-1 transition"
          >
            <span>MERKEZ BANKASI PANELİNE GİT</span>
            <ExternalLink size={11} />
          </button>
        </div>

        {/* Banks and Intermediaries */}
        <div className="bg-white border border-[#E2E8F0] p-4 rounded shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center border-b border-[#F1F5F9] pb-2 mb-3">
              <span className="text-xs font-bold font-mono text-[#0B132B]">ARACI KURUMLAR & BANKALAR</span>
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            </div>
            <div className="space-y-1.5 text-xs font-mono">
              <div className="flex justify-between"><span className="text-[#5C6B73]">Simüle Banka Sayısı:</span><span className="font-bold">8 Kurum</span></div>
              <div className="flex justify-between"><span className="text-[#5C6B73]">Ortalama Likidite Oranı:</span><span className="font-bold">1.28</span></div>
              <div className="flex justify-between"><span className="text-[#5C6B73]">Aktif Stres Alarmı:</span><span className={stressEvents.length > 0 ? 'text-red-500 font-bold' : 'text-emerald-500 font-bold'}>
                {stressEvents.length > 0 ? `${stressEvents.length} LİKİDİTE AÇIĞI` : 'TEMİZ'}
              </span></div>
            </div>
          </div>
          <button 
            onClick={() => setActiveTab('BANKALAR')}
            className="w-full mt-4 text-[11px] font-bold font-mono bg-[#0B132B] text-white hover:bg-[#1C2541] py-1.5 rounded flex justify-center items-center gap-1 transition"
          >
            <span>BANKALARI GÖRÜNTÜLE</span>
            <ExternalLink size={11} />
          </button>
        </div>

        {/* Programmable Contracts & Smart Payments */}
        <div className="bg-white border border-[#E2E8F0] p-4 rounded shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center border-b border-[#F1F5F9] pb-2 mb-3">
              <span className="text-xs font-bold font-mono text-[#0B132B]">PROGRAMLANABİLİR SÖZLEŞMELER</span>
              <span className="w-2 h-2 rounded-full bg-[#C00000]"></span>
            </div>
            <div className="space-y-1.5 text-xs font-mono">
              <div className="flex justify-between"><span className="text-[#5C6B73]">Bekleyen Akıllı Ödeme:</span><span className="font-bold">{programmablePayments.filter(p => p.status === 'BEKLEMEDE').length} Sözleşme</span></div>
              <div className="flex justify-between"><span className="text-[#5C6B73]">Blokeli Teminat Tutarı:</span><span className="font-bold">₺110.000.000</span></div>
              <div className="flex justify-between"><span className="text-[#5C6B73]">Protokol Uyumu:</span><span className="text-emerald-600 font-bold">OTONOM GÜVENLİ</span></div>
            </div>
          </div>
          <button 
            onClick={() => setActiveTab('PROGRAMLANABİLİR ÖDEMELER')}
            className="w-full mt-4 text-[11px] font-bold font-mono bg-[#0B132B] text-white hover:bg-[#1C2541] py-1.5 rounded flex justify-center items-center gap-1 transition"
          >
            <span>AKILLI SÖZLEŞME LABORATUVARI</span>
            <ExternalLink size={11} />
          </button>
        </div>

        {/* Offline Simulation */}
        <div className="bg-white border border-[#E2E8F0] p-4 rounded shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center border-b border-[#F1F5F9] pb-2 mb-3">
              <span className="text-xs font-bold font-mono text-[#0B132B]">ÇEVRİMDIŞI ÖDEME LABORATUVARI</span>
              <span className="w-2 h-2 rounded-full bg-[#5C6B73]"></span>
            </div>
            <div className="space-y-1.5 text-xs font-mono">
              <div className="flex justify-between"><span className="text-[#5C6B73]">Cihaz A (Bireysel):</span><span className="font-bold">₺{offlineState.deviceA_Balance.toFixed(2)}</span></div>
              <div className="flex justify-between"><span className="text-[#5C6B73]">Cihaz B (Esnaf POS):</span><span className="font-bold">₺{offlineState.deviceB_Balance.toFixed(2)}</span></div>
              <div className="flex justify-between"><span className="text-[#5C6B73]">Senkronize Edilecek:</span><span className={`font-bold ${offlineState.offlineTransactions.length > 0 ? 'text-amber-500' : 'text-emerald-600'}`}>{offlineState.offlineTransactions.length} işlem</span></div>
            </div>
          </div>
          <button 
            onClick={() => setActiveTab('ÇEVRİMDIŞI ÖDEMELER')}
            className="w-full mt-4 text-[11px] font-bold font-mono bg-[#0B132B] text-white hover:bg-[#1C2541] py-1.5 rounded flex justify-center items-center gap-1 transition"
          >
            <span>ÇEVRİMDIŞI MOD SİMÜLE ET</span>
            <ExternalLink size={11} />
          </button>
        </div>

        {/* Securities & Bonds Tokenization */}
        <div className="bg-white border border-[#E2E8F0] p-4 rounded shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center border-b border-[#F1F5F9] pb-2 mb-3">
              <span className="text-xs font-bold font-mono text-[#0B132B]">MENKUL KIYMETLER & TOKENİZASYON</span>
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            </div>
            <div className="space-y-1.5 text-xs font-mono">
              <div className="flex justify-between"><span className="text-[#5C6B73]">Sınıflandırma:</span><span className="font-bold">Devlet Tahvili, Bono, Fon</span></div>
              <div className="flex justify-between"><span className="text-[#5C6B73]">Takas Protokolü:</span><span className="font-bold text-[#C00000]">DVP (Atomic Swap)</span></div>
              <div className="flex justify-between"><span className="text-[#5C6B73]">Destek Kuponu (Vale):</span><span className="font-bold text-emerald-600">3 Aktif Destek</span></div>
            </div>
          </div>
          <button 
            onClick={() => setActiveTab('MENKUL KIYMETLER')}
            className="w-full mt-4 text-[11px] font-bold font-mono bg-[#0B132B] text-white hover:bg-[#1C2541] py-1.5 rounded flex justify-center items-center gap-1 transition"
          >
            <span>TAHVİL / VALE PLATFORMU</span>
            <ExternalLink size={11} />
          </button>
        </div>

        {/* Infrastructure & Cybersecurity */}
        <div className="bg-white border border-[#E2E8F0] p-4 rounded shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center border-b border-[#F1F5F9] pb-2 mb-3">
              <span className="text-xs font-bold font-mono text-[#0B132B]">ALTYAPI VE GÜVENLİK SİSTEMİ</span>
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            </div>
            <div className="space-y-1.5 text-xs font-mono">
              <div className="flex justify-between"><span className="text-[#5C6B73]">Bölgesel Sunucular:</span><span className="font-bold">İstanbul, Ankara, İzmir, Bursa</span></div>
              <div className="flex justify-between"><span className="text-[#5C6B73]">API Sunucu Gecikmesi:</span><span className="font-bold">11 ms</span></div>
              <div className="flex justify-between"><span className="text-[#5C6B73]">Siber Saldırı / Olay:</span><span className="text-emerald-600 font-bold">YOK (TEMİZ)</span></div>
            </div>
          </div>
          <button 
            onClick={() => setActiveTab('ALTYAPI')}
            className="w-full mt-4 text-[11px] font-bold font-mono bg-[#0B132B] text-white hover:bg-[#1C2541] py-1.5 rounded flex justify-center items-center gap-1 transition"
          >
            <span>ALTYAPI OPERASYON MERKEZİ</span>
            <ExternalLink size={11} />
          </button>
        </div>

      </div>

      {/* 5. Recent Unified Ledger Activity Feed (Section 14) */}
      <div className="bg-white border border-[#E2E8F0] p-4 rounded shadow-sm">
        <div className="flex justify-between items-center border-b border-[#F1F5F9] pb-2 mb-3">
          <h3 className="text-xs font-bold font-mono text-[#0B132B] uppercase">DİJİTAL TÜRK LİRASI ANA DEFTERİ - SON BLOK HAREKETLERİ</h3>
          <button 
            onClick={() => setActiveTab('ANA DEFTER')}
            className="text-[10px] font-bold font-mono text-[#C00000] hover:underline"
          >
            DEFTER DETAYLARINA GİT ➔
          </button>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono border-collapse">
            <thead>
              <tr className="bg-[#F8FAFC] text-[#5C6B73] border-b border-[#E2E8F0]">
                <th className="p-2">İŞLEM ID</th>
                <th className="p-2">ZAMAN</th>
                <th className="p-2">GÖNDERİCİ</th>
                <th className="p-2">ALICI</th>
                <th className="p-2 text-right">TUTAR</th>
                <th className="p-2">VARLIK TÜRÜ</th>
                <th className="p-2 text-center">DURUM</th>
              </tr>
            </thead>
            <tbody>
              {ledger.slice(0, 5).map(tx => (
                <tr key={tx.id} className="border-b border-[#F1F5F9] hover:bg-[#F8FAFC]">
                  <td className="p-2 text-[#0B132B] font-bold">{tx.id}</td>
                  <td className="p-2 text-[#5C6B73]">{tx.timestamp}</td>
                  <td className="p-2 truncate max-w-[150px]">{tx.sender}</td>
                  <td className="p-2 truncate max-w-[150px]">{tx.receiver}</td>
                  <td className="p-2 text-right font-bold">₺{tx.amount.toLocaleString('tr-TR', { minimumFractionDigits: 2 })}</td>
                  <td className="p-2"><span className="px-1.5 py-0.5 text-[9px] bg-[#E2E8F0] text-[#0B132B] rounded">{tx.assetType}</span></td>
                  <td className="p-2 text-center">
                    <span className={`px-1.5 py-0.5 text-[9px] font-bold rounded ${
                      tx.status === 'DENETIM_KAYDI' 
                        ? 'bg-emerald-100 text-emerald-800' 
                        : 'bg-amber-100 text-amber-800 animate-pulse'
                    }`}>
                      {tx.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}
