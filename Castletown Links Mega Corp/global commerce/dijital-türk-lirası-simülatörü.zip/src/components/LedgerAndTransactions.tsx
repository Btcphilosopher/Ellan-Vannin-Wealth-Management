/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useSimulation } from '../context/SimulationContext';
import { LedgerTransaction, AssetType } from '../types';
import { Layers, ShieldCheck, Play, Trash2, ArrowRight, HelpCircle } from 'lucide-react';

export default function LedgerAndTransactions() {
  const {
    ledger,
    wallets,
    banks,
    executeTransaction,
    clearLedger
  } = useSimulation();

  // Transaction laboratory inputs
  const [sender, setSender] = useState<string>('W-MEHMET-KAYA');
  const [receiver, setReceiver] = useState<string>('W-ASYA-RETAIL');
  const [amount, setAmount] = useState<number>(150.00);
  const [assetType, setAssetType] = useState<AssetType>('DIJITAL_TL');
  const [channel, setChannel] = useState<string>('QR Kod ile Ödeme');
  const [priority, setPriority] = useState<string>('STANDART');

  // Search filter for ledger
  const [searchTerm, setSearchTerm] = useState<string>('');

  const handleCreateTransaction = (e: React.FormEvent) => {
    e.preventDefault();
    if (amount <= 0) return;

    // Resolve name/id
    const senderWallet = wallets.find(w => w.id === sender);
    const receiverWallet = wallets.find(w => w.id === receiver);
    
    const senderName = senderWallet ? senderWallet.owner : sender;
    const receiverName = receiverWallet ? receiverWallet.owner : receiver;

    executeTransaction(
      sender,
      receiver,
      amount,
      assetType,
      `Simülatör Manuel Motoru (${channel})`
    );
  };

  const filteredLedger = ledger.filter(tx => 
    tx.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
    tx.sender.toLowerCase().includes(searchTerm.toLowerCase()) ||
    tx.receiver.toLowerCase().includes(searchTerm.toLowerCase()) ||
    tx.intermediary.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div id="ledger-and-transaction-laboratory" className="space-y-6">
      
      {/* Title */}
      <div className="bg-[#1C2541] border border-[#2A375B] p-4 rounded text-white flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold tracking-tight font-serif uppercase text-[#C00000] flex items-center gap-2">
            <Layers size={20} /> ANA DEFTER & İŞLEM SİMÜLATÖRÜ
          </h2>
          <p className="text-xs text-[#8F9AA6] font-mono uppercase mt-0.5">
            DİJİTAL TÜRK LİRASI BÜTÜNLEŞİK BİRLEŞİK DEFTER SİSTEMİ VE TEST LABORATUVARI
          </p>
        </div>
        <div className="text-[10px] font-mono bg-[#0B132B] px-3 py-1 border border-[#2A375B] rounded text-emerald-400 font-bold">
          DLT PERMISSIONED v2.4
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left: Transaction Laboratory (Section 33) */}
        <div className="bg-white border border-[#E2E8F0] p-4 rounded shadow-sm space-y-4">
          <div>
            <h3 className="text-xs font-bold font-mono text-[#0B132B] uppercase">İŞLEM SİMÜLATÖRÜ</h3>
            <p className="text-[10px] text-[#5C6B73] font-mono uppercase mt-0.5">MANUEL MUTABAKAT VE PARA TRANSFERİ PROVALARI</p>
          </div>

          <form onSubmit={handleCreateTransaction} className="space-y-3 font-mono text-xs">
            <div>
              <label className="text-[10px] text-[#5C6B73] block mb-1">GÖNDEREN TARAF:</label>
              <select
                value={sender}
                onChange={(e) => setSender(e.target.value)}
                className="w-full border border-[#E2E8F0] bg-white p-1.5 rounded font-bold"
              >
                <optgroup label="Dijital Cüzdanlar">
                  {wallets.map(w => (
                    <option key={w.id} value={w.id}>{w.owner} (Cüzdan)</option>
                  ))}
                </optgroup>
                <optgroup label="Ticari Bankalar">
                  {banks.map(b => (
                    <option key={b.id} value={b.id}>{b.name} (Rezerv)</option>
                  ))}
                </optgroup>
              </select>
            </div>

            <div className="flex justify-center py-0.5">
              <ArrowRight className="text-[#C00000] rotate-90 lg:rotate-0" />
            </div>

            <div>
              <label className="text-[10px] text-[#5C6B73] block mb-1">ALICI TARAF:</label>
              <select
                value={receiver}
                onChange={(e) => setReceiver(e.target.value)}
                className="w-full border border-[#E2E8F0] bg-white p-1.5 rounded font-bold"
              >
                <optgroup label="Dijital Cüzdanlar">
                  {wallets.map(w => (
                    <option key={w.id} value={w.id}>{w.owner} (Cüzdan)</option>
                  ))}
                </optgroup>
                <optgroup label="Ticari Bankalar">
                  {banks.map(b => (
                    <option key={b.id} value={b.id}>{b.name} (Rezerv)</option>
                  ))}
                </optgroup>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[10px] text-[#5C6B73] block mb-1">TUTAR (₺):</label>
                <input
                  type="number"
                  step="0.01"
                  min="0.01"
                  value={amount}
                  onChange={(e) => setAmount(parseFloat(e.target.value) || 0)}
                  className="w-full border border-[#E2E8F0] p-1.5 rounded text-right font-bold"
                />
              </div>
              <div>
                <label className="text-[10px] text-[#5C6B73] block mb-1">VARLIK TÜRÜ:</label>
                <select
                  value={assetType}
                  onChange={(e) => setAssetType(e.target.value as AssetType)}
                  className="w-full border border-[#E2E8F0] bg-white p-1.5 rounded font-bold"
                >
                  <option value="DIJITAL_TL">Dijital TL</option>
                  <option value="MEVDUAT">Mevduat</option>
                  <option value="TOKENIZE_MEVDUAT">Tokenize Mevduat</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[10px] text-[#5C6B73] block mb-1">ARAYÜZ / ÖDEME KANALI:</label>
                <select
                  value={channel}
                  onChange={(e) => setChannel(e.target.value)}
                  className="w-full border border-[#E2E8F0] bg-white p-1.5 rounded font-semibold"
                >
                  <option value="QR Kod ile Ödeme">Karekod (QR)</option>
                  <option value="Temassız NFC Ödeme">Temassız (NFC)</option>
                  <option value="İnternet Bankacılığı">Mobil / İnternet</option>
                </select>
              </div>
              <div>
                <label className="text-[10px] text-[#5C6B73] block mb-1">ÖNCELİK KATEGORİSİ:</label>
                <select
                  value={priority}
                  onChange={(e) => setPriority(e.target.value)}
                  className="w-full border border-[#E2E8F0] bg-white p-1.5 rounded font-semibold"
                >
                  <option value="YUKSEK">YÜKSEK (ÖNCELİKLİ)</option>
                  <option value="STANDART">STANDART</option>
                  <option value="DUSUK">DÜŞÜK</option>
                </select>
              </div>
            </div>

            <button
              type="submit"
              disabled={sender === receiver}
              className="w-full mt-4 bg-[#C00000] hover:bg-[#8B0000] disabled:bg-[#5C6B73] text-white py-2 px-4 rounded text-xs uppercase font-bold transition flex justify-center items-center gap-1.5"
            >
              <Play size={11} /> İŞLEMİ GERÇEKLEŞTİR
            </button>
          </form>
        </div>

        {/* Right: Consolidated Live Ledger Log (Section 14) */}
        <div className="lg:col-span-2 bg-white border border-[#E2E8F0] p-4 rounded shadow-sm flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex justify-between items-center border-b border-[#F1F5F9] pb-2">
              <div>
                <h3 className="text-xs font-bold font-mono text-[#0B132B] uppercase">DİJİTAL TÜRK LİRASI ANA DEFTERİ (UNIFIED LEDGER)</h3>
                <p className="text-[10px] text-[#5C6B73] font-mono mt-0.5">GÜVENLİ MUTABAKAT ONAYLI İŞLEMLER</p>
              </div>
              <button
                onClick={clearLedger}
                className="text-red-600 hover:text-red-800 transition p-1.5 rounded border border-red-200 hover:bg-red-50"
                title="Defteri Temizle"
              >
                <Trash2 size={13} />
              </button>
            </div>

            {/* Filter Search Input */}
            <div className="flex bg-[#F8FAFC] border border-[#E2E8F0] p-1.5 rounded font-mono text-xs">
              <input
                type="text"
                placeholder="İşlem ID, gönderici veya alıcı ara..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-transparent focus:outline-none"
              />
            </div>

            <div className="overflow-y-auto max-h-72">
              <table className="w-full text-left text-xs font-mono border-collapse">
                <thead>
                  <tr className="bg-[#F8FAFC] text-[#5C6B73] border-b border-[#E2E8F0]">
                    <th className="p-2">İŞLEM ID</th>
                    <th className="p-2">GÖNDERİCİ</th>
                    <th className="p-2">ALICI</th>
                    <th className="p-2 text-right font-bold">TUTAR</th>
                    <th className="p-2 text-center">DOĞRULAMA</th>
                    <th className="p-2 text-center">DURUM</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredLedger.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="p-4 text-center text-[#5C6B73]">Kayıtlı işlem bulunamadı.</td>
                    </tr>
                  ) : (
                    filteredLedger.map(tx => (
                      <tr key={tx.id} className="border-b border-[#F1F5F9] hover:bg-[#F8FAFC] transition">
                        <td className="p-2 font-bold text-[#0B132B]">{tx.id}</td>
                        <td className="p-2 truncate max-w-[120px]">{tx.sender}</td>
                        <td className="p-2 truncate max-w-[120px]">{tx.receiver}</td>
                        <td className="p-2 text-right font-bold">₺{tx.amount.toLocaleString('tr-TR', { minimumFractionDigits: 2 })}</td>
                        <td className="p-2 text-center">
                          <span className="inline-flex items-center gap-0.5 text-[9px] bg-emerald-50 text-emerald-800 border border-emerald-200 px-1 py-0.2 rounded font-bold">
                            <ShieldCheck size={11} className="text-emerald-600" /> OK
                          </span>
                        </td>
                        <td className="p-2 text-center">
                          <span className={`px-1.5 py-0.5 text-[9px] font-bold rounded ${
                            tx.status === 'DENETIM_KAYDI' 
                              ? 'bg-emerald-100 text-emerald-800' 
                              : 'bg-amber-100 text-amber-800 animate-pulse'
                          }`}>
                            {tx.status}
                          </span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          <div className="mt-4 p-2 bg-[#F8FAFC] border border-[#E2E8F0] text-[10px] font-mono text-[#5C6B73]">
            * Ağ mutabakatları Merkez Bankası RTGS ve akıllı sözleşme doğrulama motorları tarafından kriptografik olarak imzalanır (PKI RSA-2048).
          </div>
        </div>

      </div>

    </div>
  );
}
