/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useSimulation } from '../context/SimulationContext';
import { User, Eye, EyeOff, Shield, ShieldAlert, Award, FileCheck, CheckCircle } from 'lucide-react';

export default function IdentityAndCompliance() {
  const {
    alerts,
    wallets,
    selectedWalletId
  } = useSimulation();

  const [activeIdentityTab, setActiveIdentityTab] = useState<'CREDENTIALS' | 'PRIVACY' | 'KYC'>('CREDENTIALS');
  
  // Selective disclosure checkboxes simulation
  const [discloseAge, setDiscloseAge] = useState<boolean>(true);
  const [discloseTaxID, setDiscloseTaxID] = useState<boolean>(false);
  const [discloseIntermediary, setDiscloseIntermediary] = useState<boolean>(true);

  const activeWallet = wallets.find(w => w.id === selectedWalletId) || wallets[0];

  // Privacy visibility table
  const visibilityData = [
    { field: 'Kullanıcı Gerçek Adı', user: 'GÖRÜNÜR', bank: 'GÖRÜNÜR', tcmb: 'MASKELEMİŞ', auditor: 'İZİNE BAĞLI', law: 'MAHKEME KARARI' },
    { field: 'Cüzdan Bakiyesi', user: 'GÖRÜNÜR', bank: 'MASKELEMİŞ', tcmb: 'GÖRÜNÜR', auditor: 'GÖRÜNÜR', law: 'GÖRÜNÜR' },
    { field: 'Son Harcamalar (Detay)', user: 'GÖRÜNÜR', bank: 'GÖRÜNÜR (Yalnızca aracı)', tcmb: 'YALNIZCA PSEUDONYM', auditor: 'GÖRÜNÜR (Denetim)', law: 'GÖRÜNÜR' },
    { field: 'Kripto İmzalar (PKI)', user: 'GÖRÜNÜR', bank: 'GÖRÜNÜR', tcmb: 'GÖRÜNÜR', auditor: 'GÖRÜNÜR', law: 'GÖRÜNÜR' },
  ];

  return (
    <div id="identity-privacy-compliance" className="space-y-6">
      
      {/* Title */}
      <div className="bg-[#1C2541] border border-[#2A375B] p-4 rounded text-white flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold tracking-tight font-serif uppercase text-[#C00000] flex items-center gap-2">
            <Shield size={20} /> KİMLİK, GİZLİLİK VE UYUM SİSTEMLERİ
          </h2>
          <p className="text-xs text-[#8F9AA6] font-mono uppercase mt-0.5">
            DİJİTAL KİMLİK ENTEGRASYONU, VERİ GİZLİLİĞİ MATRİSİ VE KYC/AML İŞLEM TAKİBİ
          </p>
        </div>
        <div className="text-[10px] font-mono bg-[#0B132B] px-3 py-1 border border-[#2A375B] rounded text-emerald-400 font-bold">
          KYC COMPLIANT v2.0
        </div>
      </div>

      {/* Local Navigation tabs */}
      <div className="flex border-b border-[#E2E8F0] gap-4 font-mono text-xs">
        <button
          onClick={() => setActiveIdentityTab('CREDENTIALS')}
          className={`pb-2 font-bold transition uppercase ${
            activeIdentityTab === 'CREDENTIALS' ? 'border-b-2 border-[#C00000] text-[#0B132B]' : 'text-[#5C6B73] hover:text-[#0B132B]'
          }`}
        >
          DİJİTAL KİMLİK VİZÖRÜ
        </button>
        <button
          onClick={() => setActiveIdentityTab('PRIVACY')}
          className={`pb-2 font-bold transition uppercase ${
            activeIdentityTab === 'PRIVACY' ? 'border-b-2 border-[#C00000] text-[#0B132B]' : 'text-[#5C6B73] hover:text-[#0B132B]'
          }`}
        >
          GİZLİLİK & VERİ ERİŞİM MATRİSİ
        </button>
        <button
          onClick={() => setActiveIdentityTab('KYC')}
          className={`pb-2 font-bold transition uppercase ${
            activeIdentityTab === 'KYC' ? 'border-b-2 border-[#C00000] text-[#0B132B]' : 'text-[#5C6B73] hover:text-[#0B132B]'
          }`}
        >
          AML / KYC ALARMLARI ({alerts.length})
        </button>
      </div>

      {activeIdentityTab === 'CREDENTIALS' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Card Presentation */}
          <div className="bg-white border border-[#E2E8F0] p-4 rounded shadow-sm flex flex-col justify-between">
            <div>
              <div className="border-b border-[#F1F5F9] pb-2 mb-3">
                <h3 className="text-xs font-bold font-mono text-[#0B132B] uppercase">SSI EGEMEN KİMLİK CÜZDANI</h3>
                <p className="text-[10px] text-[#5C6B73] font-mono mt-0.5">DEVLET ONAYLI KRİPTOGRAFİK KİMLİK KARTI PRESENTATION</p>
              </div>

              <div className="bg-[#111A35] text-[#E0E6ED] rounded p-4 border border-[#2D3E6B] font-mono text-xs space-y-3 relative overflow-hidden">
                <div className="absolute top-0 right-0 p-3 text-[#C00000] opacity-10">
                  <User size={100} />
                </div>
                <div className="flex justify-between items-center border-b border-[#2D3E6B] pb-2">
                  <span className="font-bold text-white text-[10px] tracking-wide">T.C. ULUSAL KİMLİK BEYANI</span>
                  <span className="text-[8px] bg-emerald-950 text-emerald-400 border border-emerald-800 rounded px-1.5 py-0.5 font-bold">DOGRULANMIS</span>
                </div>
                <div className="space-y-1.5 text-[11px]">
                  <p>Adı Soyadı: <strong className="text-white">{activeWallet.owner}</strong></p>
                  <p>Cüzdan Türü: <strong className="text-white">{activeWallet.type}</strong></p>
                  <p>Bağlantılı Aracı: <strong className="text-white">{activeWallet.intermediary}</strong></p>
                  <p>DID Numarası: <strong className="text-[#8F9AA6]">did:tcmb:{activeWallet.id.toLowerCase()}</strong></p>
                </div>
              </div>

              {/* Selective disclosure controls */}
              <div className="mt-4 bg-[#F8FAFC] border border-[#E2E8F0] p-3 rounded font-mono text-xs space-y-2">
                <span className="text-[10px] font-bold text-[#0B132B] block uppercase">SEÇİCİ BİLGİ PAYLAŞIMI (SELECTIVE DISCLOSURE)</span>
                <p className="text-[10px] text-[#5C6B73]">Üçüncü parti ödemelerinde paylaşılacak minimum bilgi kapsamı:</p>
                
                <div className="space-y-1.5 pt-2">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" checked={discloseAge} onChange={(e) => setDiscloseAge(e.target.checked)} />
                    <span>Yaş Bilgisi (+18 Doğrulaması)</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" checked={discloseTaxID} onChange={(e) => setDiscloseTaxID(e.target.checked)} />
                    <span>Vergi / TC Kimlik No</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" checked={discloseIntermediary} onChange={(e) => setDiscloseIntermediary(e.target.checked)} />
                    <span>Aracı Banka Adı</span>
                  </label>
                </div>
              </div>
            </div>

            <button
              onClick={() => alert('DİJİTAL KİMLİK DOĞRULAMA KANITI BAŞARIYLA OLUŞTURULDU.')}
              className="w-full mt-4 bg-[#0B132B] hover:bg-[#1C2541] text-white py-1.5 px-3 rounded font-mono text-xs uppercase font-bold transition flex justify-center items-center gap-1.5"
            >
              <FileCheck size={13} /> KRİPTO KANIT SUN (PRESENT PROOF)
            </button>
          </div>

          <div className="lg:col-span-2 bg-[#111A35] border border-[#1C2541] p-4 rounded text-white space-y-4">
            <h3 className="text-xs font-bold font-mono text-[#C00000] uppercase border-b border-[#1C2541] pb-2">SIFIR BİLGİ KANITI (ZERO-KNOWLEDGE PROOFS)</h3>
            <p className="text-xs text-[#8F9AA6] font-mono leading-relaxed">
              Dış işyerlerine veya bankalara kimliğinizi tamamen ifşa etmeden, yalnızca kriterleri karşıladığınıza dair kriptografik kanıtlar (ZKP) sunabilirsiniz. Örneğin, doğum tarihinizi göndermeden yalnızca 18 yaşından büyük olduğunuzu ispat edersiniz.
            </p>
            <div className="p-3 bg-[#1C2541] border border-[#2D3E6B] rounded space-y-2 font-mono text-xs">
              <div className="flex justify-between items-center text-[10px] text-emerald-400 font-bold">
                <span>ZKP-PROOF-01: YAŞ KANITI</span>
                <span>BAŞARILI ONAY</span>
              </div>
              <p className="text-[#8F9AA6] text-[10px]">Cüzdan Sahibi 18 yaşından büyüktür. Gerçek doğum tarihi gizlenmiştir.</p>
              <div className="text-[9px] text-[#5C6B73] break-all bg-[#0B132B] p-1.5 rounded">
                Hash: 0x9f82d8a8b1a2c3d4f5e6a7b8c9d0e1f2a3b4c5d6e7f8a9b0
              </div>
            </div>
          </div>
        </div>
      )}

      {activeIdentityTab === 'PRIVACY' && (
        <div className="bg-white border border-[#E2E8F0] p-4 rounded shadow-sm">
          <div className="border-b border-[#F1F5F9] pb-2 mb-3">
            <h3 className="text-xs font-bold font-mono text-[#0B132B] uppercase">SİSTEM AKTÖRLERİNE GÖRE VERİ GÖRÜNÜRLÜK MATRİSİ</h3>
            <p className="text-[10px] text-[#5C6B73] font-mono mt-0.5">DİJİTAL TL SİSTEMİNDEKİ SIKI VERİ SINIRLARI VE GİZLİLİK KURALLARI</p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono border-collapse">
              <thead>
                <tr className="bg-[#F8FAFC] text-[#5C6B73] border-b border-[#E2E8F0]">
                  <th className="p-2">VERİ ALANI</th>
                  <th className="p-2">CÜZDAN SAHİBİ</th>
                  <th className="p-2">ARACI TİCARİ BANKA</th>
                  <th className="p-2">MERKEZ BANKASI</th>
                  <th className="p-2">FİNANSAL DENETÇİ</th>
                  <th className="p-2">ADLİ MAKAMLAR</th>
                </tr>
              </thead>
              <tbody>
                {visibilityData.map((row, idx) => (
                  <tr key={idx} className="border-b border-[#F1F5F9] hover:bg-[#F8FAFC]">
                    <td className="p-2 font-bold text-[#0B132B]">{row.field}</td>
                    <td className="p-2 text-emerald-600 font-semibold">{row.user}</td>
                    <td className="p-2 text-blue-600 font-semibold">{row.bank}</td>
                    <td className="p-2 text-amber-600 font-semibold">{row.tcmb}</td>
                    <td className="p-2 text-purple-600 font-semibold">{row.auditor}</td>
                    <td className="p-2 text-red-600 font-semibold">{row.law}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeIdentityTab === 'KYC' && (
        <div className="bg-white border border-[#E2E8F0] p-4 rounded shadow-sm">
          <div className="border-b border-[#F1F5F9] pb-2 mb-3 flex justify-between items-center">
            <div>
              <h3 className="text-xs font-bold font-mono text-[#0B132B] uppercase">AML VE ŞÜPHELİ İŞLEM İZLEME RAPORLARI</h3>
              <p className="text-[10px] text-[#5C6B73] font-mono mt-0.5">YAPAY ZEKA VE KURAL TABANLI UYUM ALARMLARI</p>
            </div>
            <span className="px-2 py-0.5 bg-red-100 text-red-800 font-mono text-[9px] font-bold rounded animate-pulse">
              {alerts.length} AKTİF RİSK
            </span>
          </div>

          <div className="space-y-3 font-mono text-xs">
            {alerts.map(alert => (
              <div key={alert.id} className="p-3 bg-red-50 border border-red-200 rounded flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 font-bold text-red-700 text-[11px] uppercase">
                    <ShieldAlert size={14} /> ŞÜPHELİ TRANSFER TETİKLENDİ ({alert.id})
                  </div>
                  <p className="text-[11px] text-[#5C6B73]">
                    Sebep: <strong className="text-[#0B132B]">{alert.reason}</strong>
                  </p>
                  <p className="text-[10px] text-[#5C6B73]">
                    Referans No: <strong className="text-[#0B132B]">{alert.transactionId}</strong> • Tutar: <strong className="text-[#0B132B]">₺{alert.amount.toLocaleString('tr-TR')}</strong>
                  </p>
                </div>

                <div className="flex gap-2">
                  <span className="px-2 py-0.5 bg-amber-100 text-amber-800 text-[9px] font-bold rounded">
                    {alert.status}
                  </span>
                  <button className="px-2 py-0.5 bg-red-700 hover:bg-red-800 text-white text-[9px] font-bold rounded uppercase">
                    CÜZDANI BLOKE ET
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
}
