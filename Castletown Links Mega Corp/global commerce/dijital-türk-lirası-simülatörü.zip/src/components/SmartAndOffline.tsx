/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useSimulation } from '../context/SimulationContext';
import { Play, ToggleLeft, ToggleRight, Wifi, WifiOff, RefreshCcw, Smartphone, Cpu, ShieldAlert, Award } from 'lucide-react';

export default function SmartAndOffline() {
  const {
    programmablePayments,
    executeProgrammablePayment,
    cancelProgrammablePayment,
    offlineState,
    executeOfflinePayment,
    reconnectAndSyncOffline
  } = useSimulation();

  const [offlineAmount, setOfflineAmount] = useState<number>(250.00);
  const [isOfflineMode, setIsOfflineMode] = useState<boolean>(true); // initially offline in laboratory

  const handleOfflineTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    executeOfflinePayment(offlineAmount);
  };

  const handleSync = () => {
    reconnectAndSyncOffline();
  };

  return (
    <div id="programmable-and-offline-payments" className="space-y-6">
      
      {/* Title */}
      <div className="bg-[#1C2541] border border-[#2A375B] p-4 rounded text-white flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold tracking-tight font-serif uppercase text-[#C00000] flex items-center gap-2">
            <Smartphone size={20} /> PROGRAMLANABİLİR VE ÇEVRİMDIŞI ÖDEME LABORATUVARI
          </h2>
          <p className="text-xs text-[#8F9AA6] font-mono uppercase mt-0.5">
            KOŞULLU AKILLI SÖZLEŞMELER VE GÜVENLİ DONANIM TABANLI DEĞER AKTARIM PROTOTİPLERİ
          </p>
        </div>
        <div className="text-[10px] font-mono bg-[#0B132B] px-3 py-1 border border-[#2A375B] rounded text-emerald-400 font-bold">
          RESEARCH LAB v2.0
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* 1. Programmable Payments Smart Contracts Panel (Section 15) */}
        <div className="bg-white border border-[#E2E8F0] p-4 rounded shadow-sm space-y-4 flex flex-col justify-between">
          <div>
            <div className="border-b border-[#F1F5F9] pb-2 mb-3">
              <h3 className="text-xs font-bold font-mono text-[#0B132B] uppercase">PROGRAMLANABİLİR SÖZLEŞMELER (SMART CONTRACTS)</h3>
              <p className="text-[10px] text-[#5C6B73] font-mono mt-0.5">MİLENYUM ALTYAPILI KOŞULLU OTOMATİK TRANSFER PROTOKOLLERİ</p>
            </div>

            <div className="space-y-3 font-mono text-xs">
              {programmablePayments.map(contract => (
                <div key={contract.id} className="border border-[#E2E8F0] rounded p-3 bg-[#F8FAFC]">
                  <div className="flex justify-between items-start">
                    <span className="font-bold text-[#0B132B]">{contract.title}</span>
                    <span className={`px-1.5 py-0.5 text-[9px] font-bold rounded ${
                      contract.status === 'TAMAMLANDI' ? 'bg-emerald-100 text-emerald-800' :
                      contract.status === 'BEKLEMEDE' ? 'bg-amber-100 text-amber-800' :
                      'bg-[#E2E8F0] text-[#5C6B73]'
                    }`}>
                      {contract.status}
                    </span>
                  </div>

                  <div className="mt-3 space-y-1 text-[11px] text-[#5C6B73]">
                    <div className="flex justify-between"><span>Tutar:</span><span className="font-bold text-[#0B132B]">₺{contract.amount.toLocaleString('tr-TR', { minimumFractionDigits: 2 })}</span></div>
                    <div className="flex justify-between"><span>Gönderen:</span><span className="font-bold">{contract.sender}</span></div>
                    <div className="flex justify-between"><span>Alıcı:</span><span className="font-bold">{contract.receiver}</span></div>
                    <div className="flex justify-between"><span>Sözleşme Koşulu:</span><span className="font-bold text-[#C00000]">{contract.condition}</span></div>
                    <div className="flex justify-between border-t border-[#E2E8F0] pt-1.5 mt-1 text-[10px]">
                      <span>Kontrol Noktası:</span>
                      <span className="font-semibold text-[#0B132B]">{contract.verificationStep}</span>
                    </div>
                  </div>

                  {contract.status === 'BEKLEMEDE' && (
                    <div className="mt-3 grid grid-cols-2 gap-2">
                      <button
                        onClick={() => cancelProgrammablePayment(contract.id)}
                        className="py-1 px-2 border border-red-200 hover:bg-red-50 text-red-600 font-bold rounded text-[10px] uppercase transition"
                      >
                        SÖZLEŞMEYİ İPTAL ET
                      </button>
                      <button
                        onClick={() => executeProgrammablePayment(contract.id)}
                        className="py-1 px-2 bg-emerald-700 hover:bg-emerald-600 text-white font-bold rounded text-[10px] uppercase transition flex justify-center items-center gap-1"
                      >
                        <Play size={9} /> KOŞULU DOĞRULA (ÖDE)
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 p-2.5 bg-blue-50 border border-blue-100 text-blue-800 text-[10px] font-mono rounded flex items-center gap-1.5">
            <Award size={14} className="text-blue-600" />
            <span>Sözleşmeler, TCMB otonom escrow havuzları tarafından teminat kontrolünden geçirilerek güvenle icra edilir.</span>
          </div>
        </div>

        {/* 2. Stateful Offline Payments Panel (Section 16) */}
        <div className="bg-[#111A35] border border-[#1C2541] p-4 rounded text-white flex flex-col justify-between">
          <div>
            <div className="border-b border-[#1C2541] pb-2 mb-3 flex justify-between items-center">
              <h3 className="text-xs font-bold font-mono text-[#C00000] uppercase">ÇEVRİMDIŞI ÖDEME LABORATUVARI (OFFLINE PROTOCOLS)</h3>
              <div className="flex items-center gap-1.5 text-[10px] font-mono">
                {isOfflineMode ? (
                  <span className="text-amber-400 font-bold flex items-center gap-1">
                    <WifiOff size={12} /> ÇEVRİMDIŞI MOD (OFFLINE)
                  </span>
                ) : (
                  <span className="text-emerald-400 font-bold flex items-center gap-1">
                    <Wifi size={12} /> ÇEVRİMİÇİ (ONLINE)
                  </span>
                )}
              </div>
            </div>

            <div className="space-y-4">
              
              {/* Device UI */}
              <div className="grid grid-cols-2 gap-4">
                
                {/* Device A */}
                <div className="bg-[#1C2541] border border-[#2D3E6B] p-3 rounded text-center space-y-2">
                  <Smartphone size={24} className="mx-auto text-amber-400" />
                  <span className="text-[10px] font-bold text-[#8F9AA6] block">CİHAZ A (GÖNDEREN)</span>
                  <div className="text-base font-bold font-mono">₺{offlineState.deviceA_Balance.toFixed(2)}</div>
                  <span className="text-[9px] text-[#5C6B73] block font-mono">GÜVENLİ PARG SE SECURE</span>
                </div>

                {/* Device B */}
                <div className="bg-[#1C2541] border border-[#2D3E6B] p-3 rounded text-center space-y-2">
                  <Smartphone size={24} className="mx-auto text-cyan-400" />
                  <span className="text-[10px] font-bold text-[#8F9AA6] block">CİHAZ B (ALICI)</span>
                  <div className="text-base font-bold font-mono">₺{offlineState.deviceB_Balance.toFixed(2)}</div>
                  <span className="text-[9px] text-[#5C6B73] block font-mono">ESNAF POS VERIFICATION</span>
                </div>

              </div>

              {/* Offline Transfer Form */}
              <form onSubmit={handleOfflineTransfer} className="bg-[#0B132B] p-3 rounded border border-[#1C2541] space-y-3">
                <span className="text-[10px] font-bold text-amber-400 block uppercase">ÇEVRİMDIŞI ÖDEME EMİR SİMÜLASYONU</span>
                <p className="text-[10px] text-[#8F9AA6]">Cihazlar arasında internet bağlantısı olmaksızın temassız (NFC) ödeme transferi simüle edin.</p>
                
                <div className="flex gap-2 items-end">
                  <div className="grow">
                    <label className="text-[9px] text-[#8F9AA6] block mb-1">TRANSFER TUTARI (₺):</label>
                    <input
                      type="number"
                      step="10"
                      min="10"
                      value={offlineAmount}
                      onChange={(e) => setOfflineAmount(parseFloat(e.target.value) || 0)}
                      className="w-full bg-[#1C2541] border border-[#2D3E6B] text-white p-1 rounded text-xs font-mono font-bold text-right"
                    />
                  </div>
                  <button
                    type="submit"
                    className="bg-[#C00000] hover:bg-[#8B0000] text-white font-mono text-[10px] font-bold py-1.5 px-3 rounded uppercase shrink-0"
                  >
                    Çevrimdışı ÖDE
                  </button>
                </div>
              </form>

              {/* Offline Transaction queue */}
              <div className="space-y-1.5">
                <span className="text-[10px] font-bold text-[#8F9AA6] uppercase block">CİHAZ BELLEĞİNDEKİ ÇEVRİMDIŞI İŞLEMLER ({offlineState.offlineTransactions.length})</span>
                {offlineState.offlineTransactions.length === 0 ? (
                  <p className="text-[10px] text-[#5C6B73] font-mono">Çevrimdışı işlem yok.</p>
                ) : (
                  <div className="max-h-24 overflow-y-auto space-y-1">
                    {offlineState.offlineTransactions.map((tx, idx) => (
                      <div key={idx} className="p-1.5 bg-[#1C2541] rounded border border-[#2D3E6B] text-[10px] flex justify-between items-center font-mono">
                        <span className="text-amber-400 font-bold">{tx.id}</span>
                        <span>₺{tx.amount.toFixed(2)}</span>
                        <span className="text-[8px] text-[#5C6B73]">{tx.signature}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

            </div>
          </div>

          <div className="border-t border-[#1C2541] pt-3 mt-4 space-y-2">
            <button
              onClick={handleSync}
              disabled={offlineState.offlineTransactions.length === 0}
              className="w-full bg-emerald-700 hover:bg-emerald-600 disabled:bg-[#1C2541] disabled:text-[#5C6B73] text-white py-2 px-3 rounded text-[11px] font-mono font-bold uppercase transition flex justify-center items-center gap-1.5"
            >
              <RefreshCcw size={12} />
              AĞA BAĞLAN VE KUYRUĞU EŞİTLE / MUTABAKAT YAP
            </button>
            <p className="text-[9px] text-[#8F9AA6] font-mono text-center">
              * Senkronizasyon aşamasında, çift harcama kontrolleri ve imza doğrulamaları anlık olarak RTGS defterine kalıcı yazılır.
            </p>
          </div>
        </div>

      </div>

    </div>
  );
}
