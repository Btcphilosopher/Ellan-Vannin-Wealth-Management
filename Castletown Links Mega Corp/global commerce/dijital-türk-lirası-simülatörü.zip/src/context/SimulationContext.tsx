/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import {
  Bank,
  PaymentInstitution,
  Wallet,
  LedgerTransaction,
  ProgrammablePayment,
  OfflinePaymentSimulation,
  TokenizedSecurity,
  DigitalVoucher,
  ComplianceAlert,
  LiquidityStressEvent,
  EconomicModel,
  CrossBorderCurrency,
  InfrastructureNode,
  M2MDevice,
  AIAgent,
  AssetType,
  TransactionStatus
} from '../types';

interface SimulationContextProps {
  simulationTime: string;
  simulationSpeed: number; // 1, 10, 100, 1000, 10000
  setSimulationSpeed: (speed: number) => void;
  
  // States
  tcmbBalanceSheet: {
    assets: { govSecurities: number; foreignAssets: number; loans: number; collateralizedOps: number; total: number };
    liabilities: { banknotes: number; bankReserves: number; digitalTL: number; otherLiabilities: number; total: number };
    equity: { capital: number };
  };
  banks: Bank[];
  paymentInstitutions: PaymentInstitution[];
  wallets: Wallet[];
  ledger: LedgerTransaction[];
  programmablePayments: ProgrammablePayment[];
  offlineState: {
    deviceA_Name: string;
    deviceB_Name: string;
    deviceA_Balance: number;
    deviceB_Balance: number;
    offlineTransactions: any[];
    isOnline: boolean;
  };
  securities: TokenizedSecurity[];
  vouchers: DigitalVoucher[];
  alerts: ComplianceAlert[];
  stressEvents: LiquidityStressEvent[];
  economicModel: EconomicModel;
  crossBorderRates: CrossBorderCurrency[];
  infrastructureNodes: InfrastructureNode[];
  m2mDevices: M2MDevice[];
  aiAgent: AIAgent;
  
  // Selection
  activeTab: string;
  setActiveTab: (tab: string) => void;
  selectedWalletId: string;
  setSelectedWalletId: (id: string) => void;
  
  // Accounting status
  accountingIntegrityStatus: 'NORMAL' | 'IHLAL';
  accountingLog: string[];

  // Simulation Metrics
  circulationAmount: number;
  activeWalletCount: number;
  dailyTxCount: number;
  dailyTxAmount: number;
  avgSettlementTime: number;
  activeInstitutions: number;
  avgTps: number;
  pendingTxCount: number;
  
  // System Controls / Functions
  ihracEt: (amount: number) => boolean;
  itfaEt: (amount: number) => boolean;
  kurumsalTransfer: (fromBankId: string, toBankId: string, amount: number) => boolean;
  executeTransaction: (
    sender: string,
    receiver: string,
    amount: number,
    assetType: AssetType,
    intermediary: string,
    options?: {
      isOffline?: boolean;
      smartContractId?: string;
      voucherId?: string;
    }
  ) => boolean;
  
  fastMevduatToDijitalTL: (walletId: string, amount: number) => boolean;
  fastDijitalTLToMevduat: (walletId: string, amount: number) => boolean;
  
  executeProgrammablePayment: (paymentId: string) => boolean;
  cancelProgrammablePayment: (paymentId: string) => boolean;
  
  executeOfflinePayment: (amount: number) => boolean;
  reconnectAndSyncOffline: () => void;
  
  buyTokenizedSecurity: (securityId: string, amountInTL: number, buyerWalletId: string) => boolean;
  useDigitalVoucher: (voucherId: string, amount: number, recipientName: string) => boolean;
  
  resolveStressEvent: (bankId: string) => void;
  triggerStressEvent: (bankId: string, deficitAmount: number) => void;
  
  triggerAIAgentSearch: () => void;
  triggerM2MCharge: () => void;
  resetM2M: () => void;
  
  changeEconomicScenario: (scenario: string) => void;
  currentScenario: string;
  
  clearLedger: () => void;
}

const SimulationContext = createContext<SimulationContextProps | undefined>(undefined);

// Deterministic starting simulation timestamp
const START_DATE_MS = new Date('2026-09-18T09:42:17').getTime();

export const SimulationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [simulationSpeed, setSimulationSpeed] = useState<number>(1);
  const [simulationTimeMs, setSimulationTimeMs] = useState<number>(START_DATE_MS);
  const [activeTab, setActiveTab] = useState<string>('ANA SAYFA');
  const [selectedWalletId, setSelectedWalletId] = useState<string>('W-MEHMET-KAYA');
  const [currentScenario, setCurrentScenario] = useState<string>('BAZ');
  
  // 1. TCMB Balance Sheet Initial (Values in TRY - e.g., in millions or billions)
  // Let's model in Billions (milyar ₺) to align with ₺284.7 Milyar Circulation
  const [tcmbSheet, setTcmbSheet] = useState({
    assets: {
      govSecurities: 210.0, // ₺210 Milyar
      foreignAssets: 150.0, // ₺150 Milyar
      loans: 80.0,         // ₺80 Milyar
      collateralizedOps: 50.0 // ₺50 Milyar
    },
    liabilities: {
      banknotes: 95.0,     // ₺95 Milyar
      bankReserves: 110.0, // ₺110 Milyar
      digitalTL: 245.0,    // ₺245 Milyar (matches initial circulation targets)
      otherLiabilities: 10.0 // ₺10 Milyar
    },
    equity: {
      capital: 30.0        // ₺30 Milyar
    }
  });

  // 2. Fictional Turkish Banks (Assets & Liabilities aligned with double entry)
  const [banks, setBanks] = useState<Bank[]>([
    {
      id: 'B-ANADOLU',
      name: 'Anadolu Dijital Bank',
      balanceSheet: {
        assets: { govSecurities: 45.0, foreignAssets: 20.0, loans: 65.0, reserves: 22.0, digitalTL: 18.0, collateralizedOps: 5.0, otherAssets: 5.0 },
        liabilities: { banknotes: 0, bankReserves: 0, digitalTL: 0, deposits: 150.0, eMoney: 0, otherLiabilities: 12.0 },
        equity: { capital: 18.0 }
      },
      complianceScore: 98.4,
      apiHealth: 'AKTIF',
      riskLevel: 'DUSUK',
      liquidityRatio: 1.45
    },
    {
      id: 'B-MARMARA',
      name: 'Marmara Bank',
      balanceSheet: {
        assets: { govSecurities: 35.0, foreignAssets: 15.0, loans: 55.0, reserves: 18.0, digitalTL: 12.0, collateralizedOps: 2.0, otherAssets: 3.0 },
        liabilities: { banknotes: 0, bankReserves: 0, digitalTL: 0, deposits: 110.0, eMoney: 0, otherLiabilities: 15.0 },
        equity: { capital: 15.0 }
      },
      complianceScore: 94.2,
      apiHealth: 'AKTIF',
      riskLevel: 'DUSUK',
      liquidityRatio: 1.28
    },
    {
      id: 'B-BOGAZICI',
      name: 'Boğaziçi Finans',
      balanceSheet: {
        assets: { govSecurities: 28.0, foreignAssets: 12.0, loans: 42.0, reserves: 14.0, digitalTL: 10.0, collateralizedOps: 4.0, otherAssets: 2.0 },
        liabilities: { banknotes: 0, bankReserves: 0, digitalTL: 0, deposits: 92.0, eMoney: 0, otherLiabilities: 8.0 },
        equity: { capital: 12.0 }
      },
      complianceScore: 96.7,
      apiHealth: 'AKTIF',
      riskLevel: 'DUSUK',
      liquidityRatio: 1.33
    },
    {
      id: 'B-ANKARA',
      name: 'Ankara Ticaret Bankası',
      balanceSheet: {
        assets: { govSecurities: 30.0, foreignAssets: 10.0, loans: 48.0, reserves: 12.0, digitalTL: 9.0, collateralizedOps: 1.0, otherAssets: 2.0 },
        liabilities: { banknotes: 0, bankReserves: 0, digitalTL: 0, deposits: 85.0, eMoney: 0, otherLiabilities: 9.0 },
        equity: { capital: 10.0 }
      },
      complianceScore: 92.1,
      apiHealth: 'AKTIF',
      riskLevel: 'ORTA',
      liquidityRatio: 1.15
    },
    {
      id: 'B-EGE',
      name: 'Ege Bank',
      balanceSheet: {
        assets: { govSecurities: 22.0, foreignAssets: 8.0, loans: 35.0, reserves: 10.0, digitalTL: 6.0, collateralizedOps: 0.0, otherAssets: 1.0 },
        liabilities: { banknotes: 0, bankReserves: 0, digitalTL: 0, deposits: 65.0, eMoney: 0, otherLiabilities: 9.0 },
        equity: { capital: 8.0 }
      },
      complianceScore: 95.0,
      apiHealth: 'AKTIF',
      riskLevel: 'DUSUK',
      liquidityRatio: 1.24
    },
    {
      id: 'B-KARADENIZ',
      name: 'Karadeniz Finans',
      balanceSheet: {
        assets: { govSecurities: 18.0, foreignAssets: 5.0, loans: 28.0, reserves: 8.0, digitalTL: 5.0, collateralizedOps: 0.0, otherAssets: 1.0 },
        liabilities: { banknotes: 0, bankReserves: 0, digitalTL: 0, deposits: 52.0, eMoney: 0, otherLiabilities: 6.0 },
        equity: { capital: 7.0 }
      },
      complianceScore: 89.5,
      apiHealth: 'GECIKMELI',
      riskLevel: 'ORTA',
      liquidityRatio: 1.12
    },
    {
      id: 'B-ISTANBUL-KATILIM',
      name: 'İstanbul Katılım Bankası',
      balanceSheet: {
        assets: { govSecurities: 25.0, foreignAssets: 15.0, loans: 50.0, reserves: 15.0, digitalTL: 14.0, collateralizedOps: 3.0, otherAssets: 2.0 },
        liabilities: { banknotes: 0, bankReserves: 0, digitalTL: 0, deposits: 100.0, eMoney: 0, otherLiabilities: 10.0 },
        equity: { capital: 14.0 }
      },
      complianceScore: 99.1,
      apiHealth: 'AKTIF',
      riskLevel: 'DUSUK',
      liquidityRatio: 1.41
    },
    {
      id: 'B-AKDENIZ',
      name: 'Akdeniz Bank',
      balanceSheet: {
        assets: { govSecurities: 20.0, foreignAssets: 6.0, loans: 32.0, reserves: 7.0, digitalTL: 4.8, collateralizedOps: 0.0, otherAssets: 1.2 },
        liabilities: { banknotes: 0, bankReserves: 0, digitalTL: 0, deposits: 58.0, eMoney: 0, otherLiabilities: 7.0 },
        equity: { capital: 6.0 }
      },
      complianceScore: 91.3,
      apiHealth: 'AKTIF',
      riskLevel: 'ORTA',
      liquidityRatio: 1.09
    }
  ]);

  // 3. Simulated Payment and E-money Institutions
  const [paymentInstitutions, setPaymentInstitutions] = useState<PaymentInstitution[]>([
    { id: 'PI-AKDENIZ-PAY', name: 'Akdeniz Pay', customerCount: 420000, transactionVolume: 184.2, digitalTLBalance: 2.4, eMoneyLiability: 2.3, liquidityRatio: 1.14, riskLevel: 'DUSUK', apiHealth: 'AKTIF', complianceStatus: 'UYUMLU' },
    { id: 'PI-BOGAZICI-PARA', name: 'Boğaziçi Elektronik Para', customerCount: 850000, transactionVolume: 320.5, digitalTLBalance: 4.1, eMoneyLiability: 4.0, liquidityRatio: 1.18, riskLevel: 'DUSUK', apiHealth: 'AKTIF', complianceStatus: 'UYUMLU' },
    { id: 'PI-MARMARA-HIZLI', name: 'Marmara Hızlı Ödeme', customerCount: 1200000, transactionVolume: 512.9, digitalTLBalance: 6.8, eMoneyLiability: 6.5, liquidityRatio: 1.21, riskLevel: 'DUSUK', apiHealth: 'AKTIF', complianceStatus: 'UYUMLU' },
    { id: 'PI-ANADOLU-TEK', name: 'Anadolu Fintech', customerCount: 250000, transactionVolume: 92.1, digitalTLBalance: 1.2, eMoneyLiability: 1.1, liquidityRatio: 1.08, riskLevel: 'ORTA', apiHealth: 'AKTIF', complianceStatus: 'INCELEMEDE' }
  ]);

  // 4. Custom Stateful Wallets
  const [wallets, setWallets] = useState<Wallet[]>([
    {
      id: 'W-MEHMET-KAYA',
      owner: 'MEHMET KAYA',
      type: 'Bireysel',
      digitalTLBalance: 18420.75,
      availableBalance: 16920.75,
      offlineBalance: 1500.0,
      dailyLimit: 25000.0,
      transactionLimit: 5000.0,
      kycStatus: 'DOGRULANMIS',
      intermediary: 'Anadolu Dijital Bank',
      securityLevel: 'YUKSEK',
      programmablePermissions: ['Kamu Ödemeleri', 'Fatura Ödemeleri', 'Abonelikler']
    },
    {
      id: 'W-ASYA-RETAIL',
      owner: 'ASYA SÜPERMARKETLER A.Ş.',
      type: 'Ticari',
      digitalTLBalance: 24500000.0,
      availableBalance: 24500000.0,
      offlineBalance: 0.0,
      dailyLimit: 5000000.0,
      transactionLimit: 1000000.0,
      kycStatus: 'DOGRULANMIS',
      intermediary: 'Marmara Bank',
      securityLevel: 'YUKSEK',
      programmablePermissions: ['Tedarikçi Ödemeleri', 'Otomatik Vergi']
    },
    {
      id: 'W-TUPRAS-SANAYI',
      owner: 'TÜRKİYE ENERJİ SANAYİ A.Ş.',
      type: 'Kurumsal',
      digitalTLBalance: 420500000.0,
      availableBalance: 395500000.0,
      offlineBalance: 0.0,
      dailyLimit: 50000000.0,
      transactionLimit: 25000000.0,
      kycStatus: 'DOGRULANMIS',
      intermediary: 'Boğaziçi Finans',
      securityLevel: 'YUKSEK',
      programmablePermissions: ['Milestone Ödemeleri', 'Escrow Sözleşmeleri']
    },
    {
      id: 'W-GELIR-IDARESI',
      owner: 'T.C. GELİR İDARESİ BAŞKANLIĞI',
      type: 'Kamu',
      digitalTLBalance: 1840000000.0,
      availableBalance: 1840000000.0,
      offlineBalance: 0.0,
      dailyLimit: 500000000.0,
      transactionLimit: 100000000.0,
      kycStatus: 'DOGRULANMIS',
      intermediary: 'Ankara Ticaret Bankası',
      securityLevel: 'YUKSEK',
      programmablePermissions: ['Sosyal Destek Dağıtımı', 'Kamu Transferleri']
    },
    {
      id: 'W-ANADOLU-BANK-CORP',
      owner: 'ANADOLU DİJİTAL BANK HAZİNESİ',
      type: 'Finansal Kurulus',
      digitalTLBalance: 18000000000.0, // ₺18 Milyar
      availableBalance: 18000000000.0,
      offlineBalance: 0.0,
      dailyLimit: 5000000000.0,
      transactionLimit: 1000000000.0,
      kycStatus: 'DOGRULANMIS',
      intermediary: 'Merkez Bankası',
      securityLevel: 'YUKSEK',
      programmablePermissions: ['Menkul Kıymet Takas', 'FAST Mutabakat']
    }
  ]);

  // 5. Unified Ledger Transactions
  const [ledger, setLedger] = useState<LedgerTransaction[]>([
    {
      id: 'TX-849102',
      timestamp: '18.09.2026 09:41:02',
      sender: 'MEHMET KAYA',
      receiver: 'İSTANBUL KART DOLUM',
      intermediary: 'Anadolu Dijital Bank',
      assetType: 'DIJITAL_TL',
      amount: 120.00,
      status: 'DENETIM_KAYDI',
      isVerified: true,
      isSettled: true,
      auditId: 'AUD-92810',
      signature: '0x8f2d...4a1e'
    },
    {
      id: 'TX-849103',
      timestamp: '18.09.2026 09:41:15',
      sender: 'T.C. ULAŞTIRMA BAKANLIĞI',
      receiver: 'ANKARA BANLİYÖ METRO',
      intermediary: 'Ankara Ticaret Bankası',
      assetType: 'DIJITAL_TL',
      amount: 450000.00,
      status: 'DENETIM_KAYDI',
      isVerified: true,
      isSettled: true,
      auditId: 'AUD-92811',
      signature: '0xc3b4...918a'
    },
    {
      id: 'TX-849104',
      timestamp: '18.09.2026 09:41:45',
      sender: 'ASYA SÜPERMARKETLER A.Ş.',
      receiver: 'MİGROS TEDARİK zinciri',
      intermediary: 'Marmara Bank',
      assetType: 'TOKENIZE_MEVDUAT',
      amount: 125000.00,
      status: 'DENETIM_KAYDI',
      isVerified: true,
      isSettled: true,
      auditId: 'AUD-92812',
      signature: '0x51a2...bc88'
    },
    {
      id: 'TX-849105',
      timestamp: '18.09.2026 09:42:01',
      sender: 'HAZİNE MÜSTEŞARLIĞI',
      receiver: 'ANADOLU DİJİTAL BANK HAZİNESİ',
      intermediary: 'Merkez Bankası',
      assetType: 'TOKENIZE_TAHVIL',
      amount: 50000000.00,
      status: 'DENETIM_KAYDI',
      isVerified: true,
      isSettled: true,
      smartContractId: 'SC-SEC-DVP-01',
      auditId: 'AUD-92813',
      signature: '0x992b...ff10'
    }
  ]);

  // 6. Programmable Payments (Conditional / Smart Contracts)
  const [programmablePayments, setProgrammablePayments] = useState<ProgrammablePayment[]>([
    {
      id: 'PP-001',
      title: 'İNŞAAT TEDARİK ÖDEMESİ',
      amount: 25000000.00,
      sender: 'TÜRKİYE ENERJİ SANAYİ A.Ş.',
      receiver: 'KOLİN İNŞAAT GRUBU',
      condition: 'TESLİMAT DOĞRULANDI',
      status: 'BEKLEMEDE',
      verificationStep: 'BETON YÜKLEME RAPORU BEKLENİYOR',
      escrowWalletId: 'W-TUPRAS-SANAYI'
    },
    {
      id: 'PP-002',
      title: 'TARIMSAL MAZOT DESTEĞİ',
      amount: 85000000.00,
      sender: 'T.C. GELİR İDARESİ BAŞKANLIĞI',
      receiver: 'TARIM KOOP ESNAFI (TOPLU)',
      condition: 'TRAKTÖR PLAKA VE LİTRE ONAYI',
      status: 'BEKLEMEDE',
      verificationStep: 'E-DEVLET ENTEGRASYON SORGUSU',
      escrowWalletId: 'W-GELIR-IDARESI'
    },
    {
      id: 'PP-003',
      title: 'KOBİ TEKNOLOJİ TEŞVİKİ',
      amount: 15000000.00,
      sender: 'T.C. GELİR İDARESİ BAŞKANLIĞI',
      receiver: 'ANKARA TEKNOKENT ARGE A.Ş.',
      condition: 'PROJE KABULÜ VE FATURA',
      status: 'TAMAMLANDI',
      verificationStep: 'ODTÜ TEKNOKENT ONAYLANDI',
      escrowWalletId: 'W-GELIR-IDARESI'
    }
  ]);

  // 7. Offline Payment State (Genely stateful)
  const [offlineState, setOfflineState] = useState<OfflinePaymentSimulation>({
    deviceA_Name: 'Mehmet Kaya Mobil (Device A)',
    deviceB_Name: 'Esnaf POS Terminal (Device B)',
    deviceA_Balance: 1500.0,
    deviceB_Balance: 800.0,
    transferAmount: 250.0,
    isOnline: false,
    offlineTransactions: [],
    syncQueue: []
  });

  // 8. Tokenized Securities
  const [securities, setSecurities] = useState<TokenizedSecurity[]>([
    { id: 'SEC-01', name: 'Devlet Tahvili (2 Yıllık)', ticker: 'TRT180928T12', type: 'Devlet Tahvili', circulatingSupply: 40000000000, nominalValue: 100, yieldRate: 38.5, collateralizedValue: 35000000000 },
    { id: 'SEC-02', name: 'Hazine Bonosu (180 Gün)', ticker: 'TRB150327T10', type: 'Hazine Bonosu', circulatingSupply: 15000000000, nominalValue: 100, yieldRate: 42.0, collateralizedValue: 12000000000 },
    { id: 'SEC-03', name: 'İstanbul Büyükşehir Belediyesi Yeşil Tahvil', ticker: 'TRSIBBGR001', type: 'Sirket Tahvili', circulatingSupply: 5000000000, nominalValue: 1000, yieldRate: 44.5, collateralizedValue: 3800000000 },
    { id: 'SEC-04', name: 'CBRT Likidite Yatırım Fonu', ticker: 'TRY-LIQ-FON', type: 'Yatirim Fonu', circulatingSupply: 85000000000, nominalValue: 1, yieldRate: 46.2, collateralizedValue: 80000000000 }
  ]);

  // 9. Digital Vouchers (Dijital Vale)
  const [vouchers, setVouchers] = useState<DigitalVoucher[]>([
    { id: 'VOU-01', title: 'KOBİ ENERJİ DESTEĞİ', amount: 250000.0, recipient: 'YILMAZ TEKSTİL LTD.', category: 'KOBI', expirationDate: '31.12.2026', usableFields: ['Elektrik Faturası', 'Doğalgaz'], status: 'AKTIF' },
    { id: 'VOU-02', title: 'KIRSAL GÜBRE YARDIMI', amount: 15000.0, recipient: 'AHMET DEMİR (ÇİFTÇİ)', category: 'Tarim', expirationDate: '31.10.2026', usableFields: ['Tarımsal Gübre', 'Tohum'], status: 'AKTIF' },
    { id: 'VOU-03', title: 'SOSYAL ULAŞIM KARTI', amount: 750.0, recipient: 'CANSU ÖZTÜRK (ÖĞRENCİ)', category: 'Ulasim', expirationDate: '31.12.2026', usableFields: ['Metro', 'Marmaray', 'EGO Otobüs'], status: 'AKTIF' }
  ]);

  // 10. Compliance / Risk Alerts
  const [alerts, setAlerts] = useState<ComplianceAlert[]>([
    { id: 'AL-1092', timestamp: '18.09.2026 09:35:12', transactionId: 'TX-847219', amount: 18400000.0, riskScore: 'YUKSEK', reason: 'OLAĞANDIŞI İŞLEM HIZI (Yüksek Frekanslı Kurumsal Transfer)', status: 'INCELEMEDE' },
    { id: 'AL-1093', timestamp: '18.09.2026 09:39:45', transactionId: 'TX-848102', amount: 45000.0, riskScore: 'ORTA', reason: 'COĞRAFİ UYUMSUZLUK (Cüzdan Lokasyon Sapması)', status: 'INCELEMEDE' }
  ]);

  // 11. Liquidity Stress Events
  const [stressEvents, setStressEvents] = useState<LiquidityStressEvent[]>([
    { bankId: 'B-ANKARA', requiredLiquidity: 8.4, availableLiquidity: 7.9, deficit: 0.5, status: 'LİKİDİTE_ACIGI' }
  ]);

  // 12. Economic Model Variables
  const [economicModel, setEconomicModel] = useState<EconomicModel>({
    digitalTLCirculation: 284.7, // ₺284.7 Milyar
    bankDeposits: 14802.3, // ₺14.8 Trilyon
    moneySupplyM2: 15087.0, // ₺15.08 Trilyon
    velocityOfMoney: 3.42,
    totalCreditVolume: 8420.5, // ₺8.42 Trilyon
    liquidityIndex: 94.2,
    interestRate: 45.0, // %45
    inflationRate: 34.2, // %34.2
    gdpGrowthRate: 3.8, // %3.8
    adoptionRate: 18.4 // %18.4
  });

  // 13. Cross-Border Currencies & Mock Exchange Rates
  const [crossBorderRates, setCrossBorderRates] = useState<CrossBorderCurrency[]>([
    { code: 'EUR', name: 'Avrupa Birliği Eurosu', exchangeRate: 38.42, systemName: 'wEUR (Wholesale CBDC)', latencySec: 1.2, spreadBps: 15 },
    { code: 'USD', name: 'Amerikan Doları', exchangeRate: 34.50, systemName: 'FedNow / dUSD', latencySec: 1.5, spreadBps: 12 },
    { code: 'GBP', name: 'İngiliz Sterlini', exchangeRate: 45.18, systemName: 'SterlingFn', latencySec: 1.1, spreadBps: 20 },
    { code: 'JPY', name: 'Japon Yeni', exchangeRate: 0.242, systemName: 'dJPY Ledger', latencySec: 2.1, spreadBps: 25 },
    { code: 'CNY', name: 'Çin Yuanı', exchangeRate: 4.88, systemName: 'e-CNY Platform', latencySec: 0.8, spreadBps: 10 }
  ]);

  // 14. Infrastructure Nodes (Turkish Cities)
  const [infrastructureNodes, setInfrastructureNodes] = useState<InfrastructureNode[]>([
    { city: 'İstanbul', cpu: 42, memory: 58, networkLatency: 4, apiLatency: 8, tps: 2480, queueDepth: 12, errorRate: 0.01, syncStatus: 'SENKRON', databaseHealth: 'SAGLIKLI' },
    { city: 'Ankara', cpu: 31, memory: 44, networkLatency: 6, apiLatency: 11, tps: 1120, queueDepth: 5, errorRate: 0.00, syncStatus: 'SENKRON', databaseHealth: 'SAGLIKLI' },
    { city: 'İzmir', cpu: 28, memory: 39, networkLatency: 12, apiLatency: 16, tps: 840, queueDepth: 2, errorRate: 0.02, syncStatus: 'SENKRON', databaseHealth: 'SAGLIKLI' },
    { city: 'Bursa', cpu: 19, memory: 28, networkLatency: 14, apiLatency: 19, tps: 512, queueDepth: 1, errorRate: 0.01, syncStatus: 'SENKRON', databaseHealth: 'SAGLIKLI' },
    { city: 'Konya', cpu: 14, memory: 22, networkLatency: 18, apiLatency: 24, tps: 342, queueDepth: 0, errorRate: 0.00, syncStatus: 'SENKRON', databaseHealth: 'SAGLIKLI' }
  ]);

  // 15. Machine-to-Machine
  const [m2mDevices, setM2mDevices] = useState<M2MDevice[]>([
    { id: 'M2M-01', name: 'ELEKTRİKLİ ARAÇ (TOGG T10X - 34DTL26)', batteryOrFuel: 38, requiredService: 'Şarj Bataryası Dolumu (50kWh)', cost: 840, authorizedMax: 2000, status: 'BEKLEMEDE' }
  ]);

  // 16. AI Agent
  const [aiAgent, setAiAgent] = useState<AIAgent>({
    id: 'AGENT-ANKA-01',
    name: 'ANKA-01 OTONOM AJAN',
    authorizedBalance: 50000.0,
    maxTransactionLimit: 5000.0,
    approvedCategories: ['Enerji', 'Ulasim', 'KOBI', 'Yazilim'],
    status: 'UYKUDA'
  });

  // 17. Accounting Logs for verification
  const [accountingLog, setAccountingLog] = useState<string[]>([
    'Muhasebe Defteri Başlatıldı: 18.09.2026 09:00:00',
    'TCMB Bilanço Denkliği Doğrulandı: Aktifler = Pasifler (₺400,00 milyar)',
    'Ticari Banka Bilançoları Doğrulandı (8 Kurum)'
  ]);

  const [accountingIntegrityStatus, setAccountingIntegrityStatus] = useState<'NORMAL' | 'IHLAL'>('NORMAL');

  // Simulation speed and ticks
  useEffect(() => {
    const interval = setInterval(() => {
      setSimulationTimeMs(prev => prev + (1000 * simulationSpeed));
    }, 1000);
    return () => clearInterval(interval);
  }, [simulationSpeed]);

  const formatSimulationTime = (timeMs: number) => {
    const date = new Date(timeMs);
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');
    return `${day}.${month}.${year} ${hours}:${minutes}:${seconds}`;
  };

  // Run a deterministic check of absolute Double-Entry Integrity on state changes
  const checkAccountingIntegrity = (currentTcmb: typeof tcmbSheet, currentBanks: Bank[]) => {
    // TCMB: Assets = Liabilities + Equity
    const tcmbAssets = currentTcmb.assets.govSecurities + currentTcmb.assets.foreignAssets + currentTcmb.assets.loans + currentTcmb.assets.collateralizedOps;
    const tcmbLiabsAndEquity = currentTcmb.liabilities.banknotes + currentTcmb.liabilities.bankReserves + currentTcmb.liabilities.digitalTL + currentTcmb.liabilities.otherLiabilities + currentTcmb.equity.capital;
    
    const isTcmbBalanced = Math.abs(tcmbAssets - tcmbLiabsAndEquity) < 0.01;

    // Check bank balances
    let areBanksBalanced = true;
    for (const bank of currentBanks) {
      const bAssets = bank.balanceSheet.assets.govSecurities + bank.balanceSheet.assets.foreignAssets + bank.balanceSheet.assets.loans + bank.balanceSheet.assets.reserves + bank.balanceSheet.assets.digitalTL + bank.balanceSheet.assets.collateralizedOps + bank.balanceSheet.assets.otherAssets;
      const bLiabsAndEquity = bank.balanceSheet.liabilities.banknotes + bank.balanceSheet.liabilities.bankReserves + bank.balanceSheet.liabilities.digitalTL + bank.balanceSheet.liabilities.deposits + bank.balanceSheet.liabilities.eMoney + bank.balanceSheet.liabilities.otherLiabilities + bank.balanceSheet.equity.capital;
      if (Math.abs(bAssets - bLiabsAndEquity) >= 0.01) {
        areBanksBalanced = false;
        break;
      }
    }

    if (!isTcmbBalanced || !areBanksBalanced) {
      setAccountingIntegrityStatus('IHLAL');
      addAccountingLog(`MUHASEBE DEĞİŞMEZLİĞİ İHLALİ! TCMB Dengesi: ${isTcmbBalanced ? 'EVET' : 'HAYIR'}, Banka Dengesi: ${areBanksBalanced ? 'EVET' : 'HAYIR'}`);
    } else {
      setAccountingIntegrityStatus('NORMAL');
    }
  };

  const addAccountingLog = (msg: string) => {
    setAccountingLog(prev => [msg, ...prev.slice(0, 49)]);
  };

  // Core Simulation Metrics calculated from state
  const circulationAmount = tcmbSheet.liabilities.digitalTL; // in Billions
  const activeWalletCount = 18.4; // constant synthetic millions
  const dailyTxCount = 31.8; // constant synthetic millions
  const dailyTxAmount = 1.84; // constant synthetic Trillions
  const avgSettlementTime = 0.41; // seconds
  const activeInstitutions = 184;
  const avgTps = 4812;
  const pendingTxCount = ledger.filter(t => t.status !== 'DENETIM_KAYDI').length;

  // SYSTEM ACTIONS
  
  // 1. İHRAÇ ET (Issue Digital TL)
  const ihracEt = (amountInBillions: number) => {
    if (amountInBillions <= 0) return false;
    
    // Update TCMB sheet (double-entry logic: assets increase, liabilities increase)
    const updatedTcmb = {
      ...tcmbSheet,
      assets: {
        ...tcmbSheet.assets,
        govSecurities: tcmbSheet.assets.govSecurities + amountInBillions
      },
      liabilities: {
        ...tcmbSheet.liabilities,
        digitalTL: tcmbSheet.liabilities.digitalTL + amountInBillions
      }
    };
    
    setTcmbSheet(updatedTcmb);
    
    // Add to unified ledger as a core operation
    const txId = `TX-${Math.floor(100000 + Math.random() * 900000)}`;
    const newTx: LedgerTransaction = {
      id: txId,
      timestamp: formatSimulationTime(simulationTimeMs),
      sender: 'HAZİNE / TCMB SİSTEMİ',
      receiver: 'DOLAŞIMDAKİ DİJİTAL TL',
      intermediary: 'Merkez Bankası',
      assetType: 'DIJITAL_TL',
      amount: amountInBillions * 1000000000, // converted from Billions
      status: 'DENETIM_KAYDI',
      isVerified: true,
      isSettled: true,
      auditId: `AUD-${Math.floor(10000 + Math.random() * 90000)}`,
      signature: '0xSIGN_TCMB_' + Math.random().toString(36).substring(2, 6).toUpperCase()
    };
    
    setLedger(prev => [newTx, ...prev]);
    addAccountingLog(`İHRAÇ İŞLEMİ: ₺${amountInBillions.toFixed(2)} milyar tutarında Dijital TL ihraç edildi. Varlık/Yükümlülük arttı.`);
    checkAccountingIntegrity(updatedTcmb, banks);
    
    // Update economic model
    setEconomicModel(prev => ({
      ...prev,
      digitalTLCirculation: prev.digitalTLCirculation + amountInBillions
    }));

    return true;
  };

  // 2. İTFA ET (Redeem Digital TL)
  const itfaEt = (amountInBillions: number) => {
    if (amountInBillions <= 0 || tcmbSheet.liabilities.digitalTL < amountInBillions) return false;
    
    // Update TCMB sheet (double-entry logic: assets decrease, liabilities decrease)
    const updatedTcmb = {
      ...tcmbSheet,
      assets: {
        ...tcmbSheet.assets,
        govSecurities: tcmbSheet.assets.govSecurities - amountInBillions
      },
      liabilities: {
        ...tcmbSheet.liabilities,
        digitalTL: tcmbSheet.liabilities.digitalTL - amountInBillions
      }
    };
    
    setTcmbSheet(updatedTcmb);
    
    // Add to unified ledger
    const txId = `TX-${Math.floor(100000 + Math.random() * 900000)}`;
    const newTx: LedgerTransaction = {
      id: txId,
      timestamp: formatSimulationTime(simulationTimeMs),
      sender: 'DOLAŞIMDAKİ DİJİTAL TL',
      receiver: 'HAZİNE / TCMB SİSTEMİ',
      intermediary: 'Merkez Bankası',
      assetType: 'DIJITAL_TL',
      amount: amountInBillions * 1000000000,
      status: 'DENETIM_KAYDI',
      isVerified: true,
      isSettled: true,
      auditId: `AUD-${Math.floor(10000 + Math.random() * 90000)}`,
      signature: '0xSIGN_TCMB_ITFA_' + Math.random().toString(36).substring(2, 6).toUpperCase()
    };
    
    setLedger(prev => [newTx, ...prev]);
    addAccountingLog(`İTFA İŞLEMİ: ₺${amountInBillions.toFixed(2)} milyar tutarında Dijital TL itfa edildi. Varlık/Yükümlülük azaldı.`);
    checkAccountingIntegrity(updatedTcmb, banks);

    // Update economic model
    setEconomicModel(prev => ({
      ...prev,
      digitalTLCirculation: Math.max(0, prev.digitalTLCirculation - amountInBillions)
    }));

    return true;
  };

  // 3. KURUMSAL TRANSFER (Interbank Transfer of Digital TL Asset)
  const kurumsalTransfer = (fromBankId: string, toBankId: string, amountInBillions: number) => {
    if (fromBankId === toBankId || amountInBillions <= 0) return false;
    
    const fromBank = banks.find(b => b.id === fromBankId);
    const toBank = banks.find(b => b.id === toBankId);
    if (!fromBank || !toBank || fromBank.balanceSheet.assets.digitalTL < amountInBillions) return false;
    
    // Debit fromBank assets.digitalTL, credit toBank assets.digitalTL
    const updatedBanks = banks.map(b => {
      if (b.id === fromBankId) {
        return {
          ...b,
          balanceSheet: {
            ...b.balanceSheet,
            assets: {
              ...b.balanceSheet.assets,
              digitalTL: b.balanceSheet.assets.digitalTL - amountInBillions
            }
          }
        };
      }
      if (b.id === toBankId) {
        return {
          ...b,
          balanceSheet: {
            ...b.balanceSheet,
            assets: {
              ...b.balanceSheet.assets,
              digitalTL: b.balanceSheet.assets.digitalTL + amountInBillions
            }
          }
        };
      }
      return b;
    });

    setBanks(updatedBanks);
    
    const txId = `TX-${Math.floor(100000 + Math.random() * 900000)}`;
    const newTx: LedgerTransaction = {
      id: txId,
      timestamp: formatSimulationTime(simulationTimeMs),
      sender: fromBank.name,
      receiver: toBank.name,
      intermediary: 'Merkez Bankası (RTGS)',
      assetType: 'DIJITAL_TL',
      amount: amountInBillions * 1000000000,
      status: 'DENETIM_KAYDI',
      isVerified: true,
      isSettled: true,
      auditId: `AUD-${Math.floor(10000 + Math.random() * 90000)}`,
      signature: '0xSIGN_INTERBANK_' + Math.random().toString(36).substring(2, 6).toUpperCase()
    };

    setLedger(prev => [newTx, ...prev]);
    addAccountingLog(`KURUMSAL TRANSFER: ${fromBank.name} ➔ ${toBank.name} | ₺${amountInBillions.toFixed(2)} milyar Dijital TL.`);
    checkAccountingIntegrity(tcmbSheet, updatedBanks);
    return true;
  };

  // 4. GENERAL PAYMENT TRANSACTION ENGINE (Step-by-step state simulation)
  const executeTransaction = (
    sender: string,
    receiver: string,
    amount: number,
    assetType: AssetType,
    intermediary: string,
    options?: { isOffline?: boolean; smartContractId?: string; voucherId?: string }
  ) => {
    if (amount <= 0) return false;

    // Check if sender has enough balance in case of Wallets
    if (assetType === 'DIJITAL_TL') {
      const activeWallet = wallets.find(w => w.owner === sender || w.id === sender);
      if (activeWallet && activeWallet.availableBalance < amount) {
        addAccountingLog(`İŞLEM İPTAL: ${sender} bakiyesi yetersiz (Mevcut: ₺${activeWallet.availableBalance.toFixed(2)}).`);
        return false;
      }
    }

    const txId = `TX-${Math.floor(100000 + Math.random() * 900000)}`;
    const auditId = `AUD-${Math.floor(10000 + Math.random() * 90000)}`;
    const sign = '0xSIGN_EC_' + Math.random().toString(16).substring(2, 10).toUpperCase();

    // Create entry in Ledger
    const newTx: LedgerTransaction = {
      id: txId,
      timestamp: formatSimulationTime(simulationTimeMs),
      sender,
      receiver,
      intermediary,
      assetType,
      amount,
      status: 'ISLEM_OLUSTURULDU',
      isVerified: false,
      isSettled: false,
      smartContractId: options?.smartContractId,
      auditId,
      signature: sign
    };

    setLedger(prev => [newTx, ...prev]);

    // Fast-forward transaction stages mock sequence for realistic display
    setTimeout(() => {
      setLedger(prev => prev.map(t => t.id === txId ? { ...t, status: 'KIMLIK_DOGRULAMA' } : t));
    }, 150);
    setTimeout(() => {
      setLedger(prev => prev.map(t => t.id === txId ? { ...t, status: 'BAKIYE_KONTROLU' } : t));
    }, 300);
    setTimeout(() => {
      setLedger(prev => prev.map(t => t.id === txId ? { ...t, status: 'UYUM_KONTROLU' } : t));
    }, 450);
    setTimeout(() => {
      // AML Trigger for unusually high amounts
      if (amount > 15000000) {
        const newAlert: ComplianceAlert = {
          id: `AL-${Math.floor(1000 + Math.random() * 9000)}`,
          timestamp: formatSimulationTime(simulationTimeMs),
          transactionId: txId,
          amount,
          riskScore: 'YUKSEK',
          reason: 'OLAĞANDIŞI İŞLEM HACMİ (Yüksek Tutarlı Risk Alarmı)',
          status: 'INCELEMEDE'
        };
        setAlerts(prev => [newAlert, ...prev]);
        addAccountingLog(`UYUM UYARISI TETİKLENDİ: ${txId} | ₺${amount.toLocaleString('tr-TR')} olağandışı hacim.`);
      }
      setLedger(prev => prev.map(t => t.id === txId ? { ...t, status: 'LIKIDITE_KONTROLU' } : t));
    }, 600);
    setTimeout(() => {
      setLedger(prev => prev.map(t => t.id === txId ? { ...t, status: 'MUTABAKAT', isVerified: true } : t));
    }, 750);
    setTimeout(() => {
      // Settle balances reactively
      setWallets(prevWallets => prevWallets.map(w => {
        // If wallet is sender (matching ID or Name)
        if (w.id === sender || w.owner === sender) {
          return {
            ...w,
            digitalTLBalance: w.digitalTLBalance - amount,
            availableBalance: w.availableBalance - amount
          };
        }
        // If wallet is receiver (matching ID or Name)
        if (w.id === receiver || w.owner === receiver) {
          return {
            ...w,
            digitalTLBalance: w.digitalTLBalance + amount,
            availableBalance: w.availableBalance + amount
          };
        }
        return w;
      }));

      // If voucher used, update voucher status
      if (options?.voucherId) {
        setVouchers(prevV => prevV.map(v => v.id === options.voucherId ? { ...v, status: 'KULLANILDI' } : v));
      }

      setLedger(prev => prev.map(t => t.id === txId ? { ...t, status: 'DENETIM_KAYDI', isSettled: true } : t));
      addAccountingLog(`NİHAİ MUTABAKAT TAMAMLANDI: ${txId} | ₺${amount.toLocaleString('tr-TR')} | ${sender} ➔ ${receiver}`);
      checkAccountingIntegrity(tcmbSheet, banks);
    }, 900);

    return true;
  };

  // 5. FAST SYSTEM conversions (Interoperability: Bank Deposit to/from Digital TL)
  const fastMevduatToDijitalTL = (walletId: string, amount: number) => {
    if (amount <= 0) return false;
    const targetWallet = wallets.find(w => w.id === walletId);
    if (!targetWallet) return false;

    // Convert matching bank deposits of Mehmet Kaya (intermediary bank deposit decreases)
    // Mehmet is connected to Anadolu Dijital Bank
    const bankId = targetWallet.intermediary === 'Anadolu Dijital Bank' ? 'B-ANADOLU' : 'B-MARMARA';
    const associatedBank = banks.find(b => b.id === bankId);
    
    if (!associatedBank || associatedBank.balanceSheet.liabilities.deposits < amount) {
      addAccountingLog(`FAST İPTAL: ${associatedBank?.name || 'Banka'} mevduat likiditesi yetersiz.`);
      return false;
    }

    // Behind-the-scenes double-entry bank transition:
    // Deposit Liability decreases by amount
    // Digital TL Asset decreases by amount
    const updatedBanks = banks.map(b => {
      if (b.id === bankId) {
        return {
          ...b,
          balanceSheet: {
            ...b.balanceSheet,
            assets: {
              ...b.balanceSheet.assets,
              digitalTL: b.balanceSheet.assets.digitalTL - (amount / 1000000000) // in billions
            },
            liabilities: {
              ...b.balanceSheet.liabilities,
              deposits: b.balanceSheet.liabilities.deposits - (amount / 1000000000)
            }
          }
        };
      }
      return b;
    });

    setBanks(updatedBanks);

    // Update Mehmet's wallet Digital TL balance
    setWallets(prev => prev.map(w => {
      if (w.id === walletId) {
        return {
          ...w,
          digitalTLBalance: w.digitalTLBalance + amount,
          availableBalance: w.availableBalance + amount
        };
      }
      return w;
    }));

    // Record Ledger
    const txId = `TX-${Math.floor(100000 + Math.random() * 900000)}`;
    const newTx: LedgerTransaction = {
      id: txId,
      timestamp: formatSimulationTime(simulationTimeMs),
      sender: `${associatedBank.name} Mevduat Hesabı`,
      receiver: targetWallet.owner,
      intermediary: 'FAST - DTL Entegrasyonu',
      assetType: 'DIJITAL_TL',
      amount,
      status: 'DENETIM_KAYDI',
      isVerified: true,
      isSettled: true,
      auditId: `AUD-${Math.floor(10000 + Math.random() * 90000)}`,
      signature: '0xFAST_CONV_' + Math.random().toString(36).substring(2, 6).toUpperCase()
    };

    setLedger(prev => [newTx, ...prev]);
    addAccountingLog(`FAST DÖNÜŞÜM: Mevduat Hesabı ➔ Dijital TL | ₺${amount.toLocaleString('tr-TR')} | Aracı: ${associatedBank.name}`);
    checkAccountingIntegrity(tcmbSheet, updatedBanks);
    return true;
  };

  const fastDijitalTLToMevduat = (walletId: string, amount: number) => {
    if (amount <= 0) return false;
    const targetWallet = wallets.find(w => w.id === walletId);
    if (!targetWallet || targetWallet.availableBalance < amount) {
      addAccountingLog(`FAST İPTAL: Cüzdan bakiyesi yetersiz.`);
      return false;
    }

    const bankId = targetWallet.intermediary === 'Anadolu Dijital Bank' ? 'B-ANADOLU' : 'B-MARMARA';
    const associatedBank = banks.find(b => b.id === bankId);
    if (!associatedBank) return false;

    // Convert Digital TL to Bank deposit:
    // Bank Deposit Liability increases by amount
    // Bank Digital TL Asset increases by amount
    const updatedBanks = banks.map(b => {
      if (b.id === bankId) {
        return {
          ...b,
          balanceSheet: {
            ...b.balanceSheet,
            assets: {
              ...b.balanceSheet.assets,
              digitalTL: b.balanceSheet.assets.digitalTL + (amount / 1000000000)
            },
            liabilities: {
              ...b.balanceSheet.liabilities,
              deposits: b.balanceSheet.liabilities.deposits + (amount / 1000000000)
            }
          }
        };
      }
      return b;
    });

    setBanks(updatedBanks);

    // Decrease wallet balance
    setWallets(prev => prev.map(w => {
      if (w.id === walletId) {
        return {
          ...w,
          digitalTLBalance: w.digitalTLBalance - amount,
          availableBalance: w.availableBalance - amount
        };
      }
      return w;
    }));

    // Record Ledger
    const txId = `TX-${Math.floor(100000 + Math.random() * 900000)}`;
    const newTx: LedgerTransaction = {
      id: txId,
      timestamp: formatSimulationTime(simulationTimeMs),
      sender: targetWallet.owner,
      receiver: `${associatedBank.name} Mevduat Hesabı`,
      intermediary: 'FAST - DTL Entegrasyonu',
      assetType: 'MEVDUAT',
      amount,
      status: 'DENETIM_KAYDI',
      isVerified: true,
      isSettled: true,
      auditId: `AUD-${Math.floor(10000 + Math.random() * 90000)}`,
      signature: '0xFAST_CONV_' + Math.random().toString(36).substring(2, 6).toUpperCase()
    };

    setLedger(prev => [newTx, ...prev]);
    addAccountingLog(`FAST DÖNÜŞÜM: Dijital TL ➔ Mevduat Hesabı | ₺${amount.toLocaleString('tr-TR')} | Aracı: ${associatedBank.name}`);
    checkAccountingIntegrity(tcmbSheet, updatedBanks);
    return true;
  };

  // 6. PROGRAMMABLE CONTRACT ACTIONS
  const executeProgrammablePayment = (paymentId: string) => {
    const payment = programmablePayments.find(p => p.id === paymentId);
    if (!payment || payment.status !== 'BEKLEMEDE') return false;

    // Transition state
    setProgrammablePayments(prev => prev.map(p => 
      p.id === paymentId 
        ? { ...p, status: 'KOSUL_SAGLANDI', verificationStep: 'KOŞUL DOĞRULANDI, AKILLI SÖZLEŞME TETİKLENDİ' } 
        : p
    ));

    // Execute actual transaction
    setTimeout(() => {
      executeTransaction(
        payment.sender,
        payment.receiver,
        payment.amount,
        'DIJITAL_TL',
        'Akıllı Sözleşme Otonom Motoru',
        { smartContractId: paymentId }
      );

      setProgrammablePayments(prev => prev.map(p => 
        p.id === paymentId 
          ? { ...p, status: 'TAMAMLANDI', verificationStep: 'MUTABAKAT KESİNLEŞTİ' } 
          : p
      ));
    }, 1000);

    return true;
  };

  const cancelProgrammablePayment = (paymentId: string) => {
    setProgrammablePayments(prev => prev.map(p => 
      p.id === paymentId ? { ...p, status: 'IPTAL_EDILDI', verificationStep: 'AKILLI SÖZLEŞME MANUEL İPTAL EDİLDİ' } : p
    ));
    addAccountingLog(`PROGRAMLANABİLİR SÖZLEŞME İPTALİ: ${paymentId}`);
    return true;
  };

  // 7. STATEFUL OFFLINE PAYMENTS
  const executeOfflinePayment = (amount: number) => {
    if (amount <= 0 || offlineState.deviceA_Balance < amount) {
      addAccountingLog('ÇEVRİMDIŞI İŞLEM BAŞARISIZ: Yetersiz çevrimdışı bakiye.');
      return false;
    }

    const txId = `OFF-TX-${Math.floor(1000 + Math.random() * 9000)}`;
    const newOfflineTx = {
      id: txId,
      from: 'Mehmet Kaya Mobil (Device A)',
      to: 'Esnaf POS Terminal (Device B)',
      amount,
      timestamp: formatSimulationTime(simulationTimeMs),
      signature: '0xSE_SECURE_ELEMENT_' + Math.random().toString(16).substring(2, 6).toUpperCase()
    };

    setOfflineState((prev: OfflinePaymentSimulation) => ({
      ...prev,
      deviceA_Balance: prev.deviceA_Balance - amount,
      deviceB_Balance: prev.deviceB_Balance + amount,
      offlineTransactions: [newOfflineTx, ...prev.offlineTransactions],
      syncQueue: [...prev.syncQueue, txId]
    }));

    addAccountingLog(`ÇEVRİMDIŞI ÖDEME GERÇEKLEŞTİ: Device A ➔ Device B | ₺${amount.toFixed(2)} | Güvenli Donanım İmzalı.`);
    return true;
  };

  const reconnectAndSyncOffline = () => {
    if (offlineState.offlineTransactions.length === 0) return;

    setOfflineState((prev: OfflinePaymentSimulation) => ({ ...prev, isOnline: true }));
    addAccountingLog('Cihazlar ağa bağlandı. Çevrimdışı işlem kuyruğu senkronize ediliyor...');

    // Run batch verification on ledger
    offlineState.offlineTransactions.forEach((tx: any, idx: number) => {
      setTimeout(() => {
        executeTransaction(
          'W-MEHMET-KAYA', // Mehmet Kaya wallet
          'W-ASYA-RETAIL', // Merchant wallet
          tx.amount,
          'DIJITAL_TL',
          'Çevrimdışı Mutabakat Arayüzü',
          { isOffline: true }
        );

        // Update main wallet offline balances locally
        setWallets(prevWallets => prevWallets.map(w => {
          if (w.id === 'W-MEHMET-KAYA') {
            return {
              ...w,
              offlineBalance: Math.max(0, w.offlineBalance - tx.amount)
            };
          }
          return w;
        }));

        if (idx === offlineState.offlineTransactions.length - 1) {
          // Clear queue
          setOfflineState((prev: OfflinePaymentSimulation) => ({
            ...prev,
            offlineTransactions: [],
            syncQueue: [],
            isOnline: false // toggle back to offline simulation state
          }));
          addAccountingLog('Tüm çevrimdışı işlemler çift harcama korumasıyla başarıyla deftere yazıldı.');
        }
      }, (idx + 1) * 800);
    });
  };

  // 8. TOKENIZED SECURITIES DvP
  const buyTokenizedSecurity = (securityId: string, amountInTL: number, buyerWalletId: string) => {
    const security = securities.find(s => s.id === securityId);
    const buyerWallet = wallets.find(w => w.id === buyerWalletId);
    if (!security || !buyerWallet || buyerWallet.availableBalance < amountInTL) {
      addAccountingLog('MENKUL KIYMET İŞLEMİ İPTAL: Yetersiz bakiye veya hatalı enstrüman.');
      return false;
    }

    const units = Math.floor(amountInTL / security.nominalValue);

    // DvP atomic swap execution
    executeTransaction(
      buyerWalletId,
      'W-ANADOLU-BANK-CORP', // Seller is Anadolu Treasury
      amountInTL,
      'DIJITAL_TL',
      'MKK Tokenizasyon Platformu (DVP/Atomic)',
      { smartContractId: 'SC-SEC-DVP-01' }
    );

    addAccountingLog(`ATOMİK TAKAS BAŞLATILDI (DVP): ₺${amountInTL.toLocaleString('tr-TR')} nominal tahvil aktarılıyor...`);
    
    // Increment security allocation to buyer
    setTimeout(() => {
      addAccountingLog(`ATOMİK TAKAS TAMAMLANDI (DvP): ${units.toLocaleString('tr-TR')} adet ${security.name} teslim edildi.`);
    }, 1000);

    return true;
  };

  // 9. USE VOUCHERS (Dijital Vale)
  const useDigitalVoucher = (voucherId: string, amount: number, recipientName: string) => {
    const voucher = vouchers.find(v => v.id === voucherId);
    if (!voucher || voucher.status !== 'AKTIF' || voucher.amount < amount) {
      addAccountingLog('DESTEK KUPONU BAŞARISIZ: Geçersiz kupon veya yetersiz limit.');
      return false;
    }

    // Spend the voucher
    executeTransaction(
      'W-GELIR-IDARESI', // Backed by Treasury kamu wallet
      recipientName,
      amount,
      'DIJITAL_TL',
      'Dijital Destek / Kamu Vale Programı',
      { voucherId }
    );

    return true;
  };

  // 10. RESOLVE LIQUIDITY STRESS EVENTS
  const resolveStressEvent = (bankId: string) => {
    const event = stressEvents.find(e => e.bankId === bankId);
    if (!event) return;

    // Central Bank steps in via Repo/Collateralized loan (LİKİDİTE GÜVENCESİ)
    // TCMB Assets: Collateralized Ops increases by deficit
    // Bank Assets: Reserves increases by deficit
    const updatedTcmb = {
      ...tcmbSheet,
      assets: {
        ...tcmbSheet.assets,
        collateralizedOps: tcmbSheet.assets.collateralizedOps + event.deficit
      },
      liabilities: {
        ...tcmbSheet.liabilities,
        bankReserves: tcmbSheet.liabilities.bankReserves + event.deficit
      }
    };
    setTcmbSheet(updatedTcmb);

    const updatedBanks = banks.map(b => {
      if (b.id === bankId) {
        return {
          ...b,
          balanceSheet: {
            ...b.balanceSheet,
            assets: {
              ...b.balanceSheet.assets,
              reserves: b.balanceSheet.assets.reserves + event.deficit
            }
          },
          liquidityRatio: b.liquidityRatio + 0.15,
          riskLevel: 'DUSUK' as const
        };
      }
      return b;
    });
    setBanks(updatedBanks);

    setStressEvents(prev => prev.filter(e => e.bankId !== bankId));
    addAccountingLog(`FİNANSAL İSTİKRAR MÜDAHALESİ: TCMB, ${bankId} bankasına ₺${(event.deficit * 1000).toFixed(0)} milyonluk acil APİ (Açık Piyasa İşlemi) fonlaması sağladı.`);
    checkAccountingIntegrity(updatedTcmb, updatedBanks);
  };

  const triggerStressEvent = (bankId: string, deficitAmount: number) => {
    const bank = banks.find(b => b.id === bankId);
    if (!bank) return;

    // Artificially stress bank reserves
    const updatedBanks = banks.map(b => {
      if (b.id === bankId) {
        const newReserves = Math.max(0.1, b.balanceSheet.assets.reserves - deficitAmount);
        return {
          ...b,
          balanceSheet: {
            ...b.balanceSheet,
            assets: {
              ...b.balanceSheet.assets,
              reserves: newReserves
            }
          },
          liquidityRatio: 0.92,
          riskLevel: 'YUKSEK' as const
        };
      }
      return b;
    });
    setBanks(updatedBanks);

    setStressEvents(prev => [
      ...prev.filter(e => e.bankId !== bankId),
      { bankId, requiredLiquidity: bank.balanceSheet.assets.reserves, availableLiquidity: Math.max(0.1, bank.balanceSheet.assets.reserves - deficitAmount), deficit: deficitAmount, status: 'LİKİDİTE_ACIGI' }
    ]);

    addAccountingLog(`STRES SENARYOSU TETİKLENDİ: ${bank.name} bankasında ₺${(deficitAmount * 1000).toFixed(0)} milyonluk rezerv çıkışı saptandı.`);
    checkAccountingIntegrity(tcmbSheet, updatedBanks);
  };

  // 11. MONETARY SCENARIOS
  const changeEconomicScenario = (scenario: string) => {
    setCurrentScenario(scenario);
    if (scenario === 'YUKSEK_KULLANIM') {
      setEconomicModel(prev => ({
        ...prev,
        adoptionRate: 48.2,
        velocityOfMoney: 4.85,
        inflationRate: 29.5,
        gdpGrowthRate: 4.6
      }));
      addAccountingLog('PARA SENARYOSU GÜNCELLENDİ: Yüksek Dijital TL Kullanımı (Hızlanma & Finansal Kapsayıcılık).');
    } else if (scenario === 'DUSUK_KULLANIM') {
      setEconomicModel(prev => ({
        ...prev,
        adoptionRate: 8.5,
        velocityOfMoney: 2.80,
        inflationRate: 35.1,
        gdpGrowthRate: 3.1
      }));
      addAccountingLog('PARA SENARYOSU GÜNCELLENDİ: Düşük Dijital TL Kullanımı (Geleneksel Alışkanlıklar Korunuyor).');
    } else if (scenario === 'LIKIDITE_STRESI') {
      setEconomicModel(prev => ({
        ...prev,
        liquidityIndex: 68.4,
        totalCreditVolume: 7900.0,
        interestRate: 52.0
      }));
      // Trigger a bank deficit
      triggerStressEvent('B-KARADENIZ', 0.8);
      addAccountingLog('STRES SENARYOSU TETİKLENDİ: Mevduat Göçü ve Bankacılık Likidite Daralması.');
    } else if (scenario === 'SINIR_OTESI') {
      addAccountingLog('SENARYO GÜNCELLENDİ: Sınır Ötesi CBDC Takas Protokolleri Etkin.');
    } else {
      // BAZ
      setEconomicModel({
        digitalTLCirculation: 284.7,
        bankDeposits: 14802.3,
        moneySupplyM2: 15087.0,
        velocityOfMoney: 3.42,
        totalCreditVolume: 8420.5,
        liquidityIndex: 94.2,
        interestRate: 45.0,
        inflationRate: 34.2,
        gdpGrowthRate: 3.8,
        adoptionRate: 18.4
      });
      addAccountingLog('BAZ SENARYO SIFIRLANDI: Makroekonomik değişkenler başlangıç durumuna döndü.');
    }
  };

  // 12. MACHINE TO MACHINE DOLUMU
  const triggerM2MCharge = () => {
    setM2mDevices(prev => prev.map(d => {
      if (d.id === 'M2M-01') {
        return { ...d, status: 'DOGRULANIYOR' };
      }
      return d;
    }));

    setTimeout(() => {
      setM2mDevices(prev => prev.map(d => {
        if (d.id === 'M2M-01') {
          return { ...d, status: 'SARJ_EDILIYOR' };
        }
        return d;
      }));
      addAccountingLog('M2M GÜVENLİ DONANIM ONAYLANDI: Araç batarya dolumu başlatıldı. Otonom cüzdan yetkilendirildi.');
    }, 1000);

    setTimeout(() => {
      // Deduct from Mehmet's wallet
      executeTransaction(
        'W-MEHMET-KAYA',
        'Asya Süpermarketler Şarj İstasyonu',
        840.00,
        'DIJITAL_TL',
        'M2M Otonom Ödeme Protokolü'
      );

      setM2mDevices(prev => prev.map(d => {
        if (d.id === 'M2M-01') {
          return { ...d, status: 'TAMAMLANDI', batteryOrFuel: 100 };
        }
        return d;
      }));
    }, 3000);
  };

  const resetM2M = () => {
    setM2mDevices([{ id: 'M2M-01', name: 'ELEKTRİKLİ ARAÇ (TOGG T10X - 34DTL26)', batteryOrFuel: 38, requiredService: 'Şarj Bataryası Dolumu (50kWh)', cost: 840, authorizedMax: 2000, status: 'BEKLEMEDE' }]);
  };

  // 13. AI AGENT ACTIONS
  const triggerAIAgentSearch = () => {
    setAiAgent(prev => ({ ...prev, status: 'MERCHANT_ARANIYOR' }));
    addAccountingLog('ANKA-01: Aras kargo lojistik faturası için en uygun Dijital TL entegreli kurumsal sağlayıcı aranıyor...');

    setTimeout(() => {
      setAiAgent(prev => ({ ...prev, status: 'YETKI_BEKLENIYOR' }));
      addAccountingLog('ANKA-01: En uygun rota doğrulandı (₺4,250.00). Limit kontrol edildi. İmza yetkilendirmesi bekleniyor...');
    }, 1200);

    setTimeout(() => {
      setAiAgent(prev => ({ ...prev, status: 'ODENIYOR' }));
      executeTransaction(
        'W-TUPRAS-SANAYI', // AI has access to Tupras Kurumsal wallet limited budget
        'ARAS LOJİSTİK DEFTERİ',
        4250.00,
        'DIJITAL_TL',
        'ANKA-01 Yapay Zeka Ödeme Motoru'
      );
    }, 2400);

    setTimeout(() => {
      setAiAgent(prev => ({ ...prev, status: 'ISLEM_KAYDEDILDI' }));
      addAccountingLog('ANKA-01: Lojistik faturası ödendi ve denetim imzası kurumsal deftere başarıyla işlendi.');
    }, 3600);
  };

  const clearLedger = () => {
    setLedger([]);
    addAccountingLog('Ana Defter Sıfırlandı.');
  };

  return (
    <SimulationContext.Provider
      value={{
        simulationTime: formatSimulationTime(simulationTimeMs),
        simulationSpeed,
        setSimulationSpeed,
        tcmbBalanceSheet: {
          ...tcmbSheet,
          assets: { ...tcmbSheet.assets, total: tcmbSheet.assets.govSecurities + tcmbSheet.assets.foreignAssets + tcmbSheet.assets.loans + tcmbSheet.assets.collateralizedOps },
          liabilities: { ...tcmbSheet.liabilities, total: tcmbSheet.liabilities.banknotes + tcmbSheet.liabilities.bankReserves + tcmbSheet.liabilities.digitalTL + tcmbSheet.liabilities.otherLiabilities }
        },
        banks,
        paymentInstitutions,
        wallets,
        ledger,
        programmablePayments,
        offlineState,
        securities,
        vouchers,
        alerts,
        stressEvents,
        economicModel,
        crossBorderRates,
        infrastructureNodes,
        m2mDevices,
        aiAgent,
        activeTab,
        setActiveTab,
        selectedWalletId,
        setSelectedWalletId,
        accountingIntegrityStatus,
        accountingLog,
        circulationAmount,
        activeWalletCount,
        dailyTxCount,
        dailyTxAmount,
        avgSettlementTime,
        activeInstitutions,
        avgTps,
        pendingTxCount,
        
        ihracEt,
        itfaEt,
        kurumsalTransfer,
        executeTransaction,
        fastMevduatToDijitalTL,
        fastDijitalTLToMevduat,
        executeProgrammablePayment,
        cancelProgrammablePayment,
        executeOfflinePayment,
        reconnectAndSyncOffline,
        buyTokenizedSecurity,
        useDigitalVoucher,
        resolveStressEvent,
        triggerStressEvent,
        triggerAIAgentSearch,
        triggerM2MCharge,
        resetM2M,
        changeEconomicScenario,
        currentScenario,
        clearLedger
      }}
    >
      {children}
    </SimulationContext.Provider>
  );
};

export const useSimulation = () => {
  const context = useContext(SimulationContext);
  if (!context) throw new Error('useSimulation must be used within a SimulationProvider');
  return context;
};
