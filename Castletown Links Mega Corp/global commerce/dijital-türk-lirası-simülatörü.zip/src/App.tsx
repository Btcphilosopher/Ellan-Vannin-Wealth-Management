/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { SimulationProvider, useSimulation } from './context/SimulationContext';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import TcmbModule from './components/TcmbModule';
import Intermediaries from './components/Intermediaries';
import WalletsAndFAST from './components/WalletsAndFAST';
import LedgerAndTransactions from './components/LedgerAndTransactions';
import SmartAndOffline from './components/SmartAndOffline';
import TokenAndSecurities from './components/TokenAndSecurities';
import IdentityAndCompliance from './components/IdentityAndCompliance';
import EconomicLaboratory from './components/EconomicLaboratory';
import AiAndM2m from './components/AiAndM2m';

import {
  Home,
  Landmark,
  Building,
  Wallet,
  Layers,
  Smartphone,
  Coins,
  Shield,
  BarChart2,
  Cpu,
  Menu,
  X
} from 'lucide-react';

function AppContent() {
  const { activeTab, setActiveTab } = useSimulation();
  const [isMobileNavOpen, setIsMobileNavOpen] = useState(false);

  // Map tab keys to metadata
  const navItems = [
    { id: 'ANA SAYFA', label: 'MİLLİ KOMUTA MERKEZİ', icon: Home, color: 'text-red-500' },
    { id: 'MERKEZ BANKASI', label: 'MERKEZ BANKASI SİSTEMİ', icon: Landmark, color: 'text-amber-500' },
    { id: 'BANKALAR & FİNTEKLER', label: 'ARACI FİNANSAL SİSTEMLER', icon: Building, color: 'text-blue-500' },
    { id: 'CÜZDANLAR & FAST', label: 'CÜZDANLAR & FAST', icon: Wallet, color: 'text-emerald-500' },
    { id: 'ANA DEFTER & LAB', label: 'ANA DEFTER & İŞLEMLER', icon: Layers, color: 'text-cyan-500' },
    { id: 'PROGRAMLANABİLİR ÖDEME', label: 'PROGRAMLANABİLİR ÖDEMELER', icon: Smartphone, color: 'text-purple-500' },
    { id: 'TOKENİZASYON & TAHVİL', label: 'TOKENİZASYON & TAHVİL', icon: Coins, color: 'text-pink-500' },
    { id: 'KİMLİK & GİZLİLİK', label: 'KİMLİK & GİZLİLİK', icon: Shield, color: 'text-indigo-500' },
    { id: 'EKONOMİ LABORATUVARI', label: 'MAKRO EKONOMİ LAB', icon: BarChart2, color: 'text-orange-500' },
    { id: 'YAPAY ZEKA ÖDEME AJANLARI', label: 'YAPAY ZEKA AJANLARI', icon: Cpu, color: 'text-teal-500' },
  ];

  const renderActiveModule = () => {
    switch (activeTab) {
      case 'ANA SAYFA':
        return <Dashboard />;
      case 'MERKEZ BANKASI':
        return <TcmbModule />;
      case 'BANKALAR & FİNTEKLER':
        return <Intermediaries />;
      case 'CÜZDANLAR & FAST':
        return <WalletsAndFAST />;
      case 'ANA DEFTER & LAB':
        return <LedgerAndTransactions />;
      case 'PROGRAMLANABİLİR ÖDEME':
        return <SmartAndOffline />;
      case 'TOKENİZASYON & TAHVİL':
        return <TokenAndSecurities />;
      case 'KİMLİK & GİZLİLİK':
        return <IdentityAndCompliance />;
      case 'EKONOMİ LABORATUVARI':
        return <EconomicLaboratory />;
      case 'YAPAY ZEKA ÖDEME AJANLARI':
        return <AiAndM2m />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-[#0B132B] flex flex-col font-sans select-none selection:bg-red-200">
      
      {/* 1. Header component */}
      <Header />

      {/* Mobile Nav Trigger */}
      <div className="lg:hidden bg-[#111A35] text-white border-t border-[#2A375B] px-4 py-3 flex items-center justify-between shadow-md">
        <span className="text-xs font-mono font-bold uppercase tracking-wider text-red-500">SİSTÈM ALTYAPISI SEÇİN</span>
        <button
          onClick={() => setIsMobileNavOpen(!isMobileNavOpen)}
          className="p-1 border border-[#2A375B] rounded hover:bg-[#1C2541] transition"
        >
          {isMobileNavOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      {/* 2. Unified Master Layout */}
      <div className="flex-1 flex flex-col lg:flex-row relative">
        
        {/* Left institutional navigation sidebar (Desktop) */}
        <aside className="hidden lg:flex w-72 bg-[#0B132B] text-white flex-col border-r border-[#1C2541] p-4 shrink-0 justify-between">
          <div className="space-y-4">
            <div>
              <span className="text-[10px] font-mono text-[#8F9AA6] tracking-wider uppercase block mb-2 px-2">SİMÜLATÖR PANELİ</span>
              <div className="h-px bg-[#1C2541]"></div>
            </div>

            <nav className="space-y-1.5 font-mono text-xs">
              {navItems.map(item => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded text-left transition uppercase tracking-tight ${
                      isActive
                        ? 'bg-[#C00000] text-white font-bold shadow-md'
                        : 'text-[#8F9AA6] hover:bg-[#111A35] hover:text-white font-medium'
                    }`}
                  >
                    <Icon size={16} className={`${isActive ? 'text-white' : item.color}`} />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>
          </div>

          <div className="pt-4 border-t border-[#1C2541] text-[10px] text-[#5C6B73] font-mono space-y-1">
            <p>TCMB PARG PROTOKOLÜ v4.1</p>
            <p>© 2026 SENTETİK ÇİFT KAYIT AR-GE</p>
          </div>
        </aside>

        {/* Left institutional navigation drawer (Mobile Overlay) */}
        {isMobileNavOpen && (
          <div className="lg:hidden absolute inset-0 z-50 bg-[#0B132B] text-white p-4 space-y-4 flex flex-col justify-between">
            <div>
              <div className="flex justify-between items-center mb-4">
                <span className="text-[10px] font-mono text-[#8F9AA6] tracking-wider uppercase">SİMÜLATÖR PANELİ</span>
                <button
                  onClick={() => setIsMobileNavOpen(false)}
                  className="p-1 border border-[#2A375B] rounded hover:bg-[#1C2541]"
                >
                  <X size={18} />
                </button>
              </div>

              <nav className="space-y-1 font-mono text-xs">
                {navItems.map(item => {
                  const Icon = item.icon;
                  const isActive = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        setActiveTab(item.id);
                        setIsMobileNavOpen(false);
                      }}
                      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded text-left transition uppercase ${
                        isActive
                          ? 'bg-[#C00000] text-white font-bold shadow-md'
                          : 'text-[#8F9AA6] hover:bg-[#111A35] hover:text-white'
                      }`}
                    >
                      <Icon size={15} className={`${isActive ? 'text-white' : item.color}`} />
                      <span>{item.label}</span>
                    </button>
                  );
                })}
              </nav>
            </div>

            <div className="text-[10px] text-[#5C6B73] font-mono">
              TCMB PARG PROTOKOLÜ v4.1
            </div>
          </div>
        )}

        {/* Main interactive module canvas (Responsive Content View) */}
        <main className="flex-1 p-4 lg:p-6 overflow-y-auto max-w-7xl mx-auto w-full">
          {renderActiveModule()}
        </main>

      </div>

    </div>
  );
}

export default function App() {
  return (
    <SimulationProvider>
      <AppContent />
    </SimulationProvider>
  );
}
