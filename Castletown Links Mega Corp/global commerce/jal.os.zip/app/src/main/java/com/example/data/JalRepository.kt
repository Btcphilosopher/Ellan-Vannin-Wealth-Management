package com.example.data

import com.example.domain.models.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class JalRepository(private val dao: JalDao) {

    val activeBooking: Flow<BookingEntity?> = dao.getBookingByPnr("JAL-JL041-2026")
    val notifications: Flow<List<NotificationEntity>> = dao.getAllNotifications()
    val simulationState: Flow<SimulationStateEntity?> = dao.getSimulationState()

    suspend fun saveBooking(booking: BookingEntity) {
        dao.insertOrUpdateBooking(booking)
    }

    suspend fun addNotification(notification: NotificationMessage) {
        dao.insertNotification(
            NotificationEntity(
                id = notification.id,
                titleJa = notification.titleJa,
                titleEn = notification.titleEn,
                bodyJa = notification.bodyJa,
                bodyEn = notification.bodyEn,
                timestamp = notification.timestamp,
                isAlert = notification.isAlert,
                isRead = notification.isRead
            )
        )
    }

    suspend fun updateSimulationStep(stepIndex: Int, gate: String, status: String, prevGate: String? = null) {
        dao.saveSimulationState(
            SimulationStateEntity(
                id = 1,
                stepIndex = stepIndex,
                currentGate = gate,
                previousGate = prevGate,
                flightStatus = status,
                wifiConnected = stepIndex >= 14,
                lastUpdatedTimestamp = System.currentTimeMillis()
            )
        )
    }
}
