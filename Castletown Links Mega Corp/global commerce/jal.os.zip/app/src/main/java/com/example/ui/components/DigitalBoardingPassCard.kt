package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.models.BoardingPassModel
import com.example.i18n.Language
import com.example.ui.theme.*

@Composable
fun DigitalBoardingPassCard(
    boardingPass: BoardingPassModel,
    language: Language
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, BorderGray, RoundedCornerShape(16.dp))
            .testTag("digital_boarding_pass_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            // Top JAL Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "JAPAN AIRLINES",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.5.sp
                        ),
                        color = JalRed
                    )
                    Text(
                        text = "JAL.OS BOARDING PASS",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted
                    )
                }

                Surface(
                    color = JalRedLight,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = boardingPass.statusBadge,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = JalRed,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Flight Route Header (HND -> LHR)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = boardingPass.originCode,
                        style = MaterialTheme.typography.displayLarge.copy(fontWeight = FontWeight.Black),
                        color = CharcoalBlack
                    )
                    Text(
                        text = "TOKYO HANEDA",
                        style = MaterialTheme.typography.labelMedium,
                        color = TextMuted
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = boardingPass.flightNumber,
                        style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                        color = JalRed
                    )
                    Text(
                        text = "✈",
                        style = MaterialTheme.typography.titleLarge,
                        color = TextMuted
                    )
                    Text(
                        text = "BUSINESS (C)",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = boardingPass.destinationCode,
                        style = MaterialTheme.typography.displayLarge.copy(fontWeight = FontWeight.Black),
                        color = CharcoalBlack
                    )
                    Text(
                        text = "LONDON HEATHROW",
                        style = MaterialTheme.typography.labelMedium,
                        color = TextMuted
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Dashed Separator Divider
            Canvas(modifier = Modifier.fillMaxWidth().height(1.dp)) {
                val dashWidth = 8.dp.toPx()
                val gapWidth = 6.dp.toPx()
                var currentX = 0f
                while (currentX < size.width) {
                    drawLine(
                        color = BorderGray,
                        start = Offset(currentX, 0f),
                        end = Offset(currentX + dashWidth, 0f),
                        strokeWidth = 2f
                    )
                    currentX += dashWidth + gapWidth
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Boarding Details Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("PASSENGER", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Text(boardingPass.passengerName, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                }
                Column {
                    Text("DATE", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Text(boardingPass.departureDate, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                }
                Column {
                    Text("DEPARTURE", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Text(boardingPass.departureTime, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = JalRed)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(AirportSilver, RoundedCornerShape(8.dp))
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("GATE", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Text(boardingPass.gate, style = MaterialTheme.typography.displaySmall.copy(fontWeight = FontWeight.Black), color = JalRed)
                }
                Column {
                    Text("BOARDING GROUP", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Text(boardingPass.group, style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold))
                }
                Column {
                    Text("SEAT", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Text(boardingPass.seat, style = MaterialTheme.typography.displaySmall.copy(fontWeight = FontWeight.Black), color = CharcoalBlack)
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Simulated High-Resolution PDF417 / QR Barcode Canvas Component
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "SCAN AT BOARDING GATE & LOUNGE",
                    style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.sp),
                    color = TextMuted
                )
                Spacer(modifier = Modifier.height(8.dp))

                // Synthetic Barcode Canvas Drawing
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp)
                        .background(PureWhite)
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                ) {
                    val barWidths = listOf(3f, 1f, 4f, 2f, 1f, 5f, 2f, 1f, 3f, 2f, 4f, 1f, 2f, 6f, 1f, 3f, 2f, 4f, 1f, 5f, 2f, 3f, 1f, 4f, 2f)
                    var x = 0f
                    val totalBars = 3
                    repeat(totalBars) {
                        for (w in barWidths) {
                            drawRect(
                                color = CharcoalBlack,
                                topLeft = Offset(x, 0f),
                                size = androidx.compose.ui.geometry.Size(w * 2.5f, size.height)
                            )
                            x += (w * 2.5f) + 3f
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = boardingPass.barcodeValue.take(36) + "...",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextMuted
                )
            }
        }
    }
}
