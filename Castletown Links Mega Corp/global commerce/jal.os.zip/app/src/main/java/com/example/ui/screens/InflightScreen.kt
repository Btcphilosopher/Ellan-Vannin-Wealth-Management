package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.domain.models.InflightWiFiState
import com.example.i18n.Language
import com.example.ui.components.InflightDashboardCard
import com.example.ui.theme.*

data class EntertainmentItem(
    val titleJa: String,
    val titleEn: String,
    val category: String,
    val duration: String
)

val jalSkyCatalog = listOf(
    EntertainmentItem("Drive My Car (ドライブ・マイ・カー)", "Drive My Car", "MOVIES", "179 MIN"),
    EntertainmentItem("JAL 787 操縦席からの北極圏風景", "Arctic Route Flight Deck Pass", "DOCUMENTARY", "45 MIN"),
    EntertainmentItem("東京フィルハーモニー和声交響曲", "Tokyo Philharmonic Symphony", "AUDIO", "60 MIN"),
    EntertainmentItem("日本の伝統工芸と美意識", "Japanese Craft & Aesthetic", "CULTURE", "30 MIN")
)

@Composable
fun InflightScreen(
    wifiState: InflightWiFiState,
    onConnectWiFi: () -> Unit,
    language: Language
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
        modifier = Modifier
            .fillMaxSize()
            .testTag("inflight_screen")
    ) {
        // Main Inflight Dashboard & Telemetry
        item {
            InflightDashboardCard(
                wifiState = wifiState,
                onConnectWiFi = onConnectWiFi,
                language = language
            )
        }

        // JAL SKY Entertainment Catalog Section
        item {
            Column {
                Text(
                    text = "JAL SKY ENTERTAINMENT — CATALOG",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = CharcoalBlack
                )
                Spacer(modifier = Modifier.height(10.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(jalSkyCatalog) { item ->
                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier
                                .width(200.dp)
                                .border(1.dp, BorderGray, RoundedCornerShape(10.dp))
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Surface(
                                    color = JalRedLight,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = item.category,
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = JalRed,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Text(
                                    text = if (language == Language.JA) item.titleJa else item.titleEn,
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    maxLines = 2,
                                    color = CharcoalBlack
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(item.duration, style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                    Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = JalRed)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
