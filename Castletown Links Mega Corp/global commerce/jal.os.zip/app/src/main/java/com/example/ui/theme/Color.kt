package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// JAL Brand Palette - Japanese Precision & Quiet Luxury
val JalRed = Color(0xFFC8102E)        // Official JAL Crimson Red
val JalRedDark = Color(0xFFA00C22)
val JalRedLight = Color(0xFFFFF0F2)

val CharcoalBlack = Color(0xFF121212) // Deep Japanese Black
val SoftCharcoal = Color(0xFF262626)
val OffWhite = Color(0xFFFAFAFA)      // Pure Whitespace Background
val PureWhite = Color(0xFFFFFFFF)
val AirportSilver = Color(0xFFF2F4F7) // Architectural Gray
val BorderGray = Color(0xFFE2E4E8)
val TextMuted = Color(0xFF6E747F)

// Operational Status Colors
val StatusEmerald = Color(0xFF00875A) // Completed / On-Time
val StatusGold = Color(0xFFD4AF37)    // Gold Loyalty / Priority
val StatusAmber = Color(0xFFFF9900)   // Warning / Tight Connection
val StatusBlue = Color(0xFF0052CC)    // Active / In Flight
