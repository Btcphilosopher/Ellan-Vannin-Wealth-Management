package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.domain.models.FlightInfo
import com.example.i18n.Language
import com.example.i18n.Strings
import com.example.simulation.SimulationScenarioStep
import com.example.ui.components.WhatToDoNowCard
import com.example.ui.theme.*

data class DestinationCardItem(
    val id: String,
    val cityJa: String,
    val cityEn: String,
    val code: String,
    val subtitleJa: String,
    val subtitleEn: String,
    val drawableRes: Int
)

val discoverDestinations = listOf(
    DestinationCardItem("1", "東京", "Tokyo", "HND / NRT", "現代と伝統が調和する首都", "The vibrant capital of Japan", R.drawable.img_jal_hero_fuji_1790148260419),
    DestinationCardItem("2", "ロンドン", "London", "LHR", "JALフラッグシップ路線", "Flagship daily Boeing 787 service", R.drawable.img_jal_hero_fuji_1790148260419),
    DestinationCardItem("3", "京都", "Kyoto", "KIX", "静寂と美意識の古都", "Ancient capital of tranquility", R.drawable.img_jal_hero_fuji_1790148260419),
    DestinationCardItem("4", "札幌", "Sapporo", "CTS", "北海道の自然と味覚", "Hokkaido natural wilderness", R.drawable.img_jal_hero_fuji_1790148260419)
)

@Composable
fun HomeScreen(
    flight: FlightInfo,
    step: SimulationScenarioStep,
    language: Language,
    onNavigateTab: (String) -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
        modifier = Modifier
            .fillMaxSize()
            .testTag("home_screen_content")
    ) {
        // Hero Banner Artwork
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    Image(
                        painter = painterResource(id = R.drawable.img_jal_hero_fuji_1790148260419),
                        contentDescription = "JAL Aircraft",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(CharcoalBlack.copy(alpha = 0.35f))
                    )
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "JAPAN AIRLINES",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Black,
                                letterSpacing = 2.sp
                            ),
                            color = PureWhite
                        )
                        Text(
                            text = if (language == Language.JA) "静寂と品格、日本の空へ。" else "Quiet luxury and Japanese hospitality in flight.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = PureWhite.copy(alpha = 0.9f)
                        )
                    }
                }
            }
        }

        // Section 1: "WHAT TO DO NOW" Contextual Card
        item {
            WhatToDoNowCard(
                flight = flight,
                step = step,
                language = language,
                onPrimaryAction = {
                    when (step.stepIndex) {
                        in 1..3 -> onNavigateTab("trips")
                        in 4..10 -> onNavigateTab("airport")
                        in 11..16 -> onNavigateTab("inflight")
                        else -> onNavigateTab("trips")
                    }
                },
                onNavigateToAirport = { onNavigateTab("airport") }
            )
        }

        // Section 2: YOUR NEXT FLIGHT summary card
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderGray, RoundedCornerShape(12.dp))
                    .testTag("upcoming_flight_summary_card")
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = Strings.get("your_next_flight", language),
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        ),
                        color = TextMuted
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = flight.flightNumber,
                                style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Black),
                                color = JalRed
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                color = AirportSilver,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = flight.cabinClass,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = CharcoalBlack,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Text(
                            text = flight.dateString,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = CharcoalBlack
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(flight.departureTime, style = MaterialTheme.typography.displayMedium.copy(fontWeight = FontWeight.Black))
                            Text(flight.originNameJa, style = MaterialTheme.typography.bodyMedium, color = TextMuted)
                        }

                        Text("─────►", style = MaterialTheme.typography.titleLarge, color = TextMuted)

                        Column(horizontalAlignment = Alignment.End) {
                            Text(flight.arrivalTime, style = MaterialTheme.typography.displayMedium.copy(fontWeight = FontWeight.Black))
                            Text(flight.destinationNameJa, style = MaterialTheme.typography.bodyMedium, color = TextMuted)
                        }
                    }
                }
            }
        }

        // Section 3: WHERE WILL YOU GO NEXT? Destination Discovery Carousel
        item {
            Column {
                Text(
                    text = Strings.get("where_to_next", language),
                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                    color = CharcoalBlack
                )

                Spacer(modifier = Modifier.height(12.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(discoverDestinations) { item ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .width(220.dp)
                                .height(160.dp)
                                .clickable { onNavigateTab("book") }
                        ) {
                            Box(modifier = Modifier.fillMaxSize()) {
                                Image(
                                    painter = painterResource(id = item.drawableRes),
                                    contentDescription = item.cityEn,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(CharcoalBlack.copy(alpha = 0.4f))
                                )
                                Column(
                                    modifier = Modifier
                                        .align(Alignment.BottomStart)
                                        .padding(12.dp)
                                ) {
                                    Text(
                                        text = "${item.cityJa} (${item.code})",
                                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                                        color = PureWhite
                                    )
                                    Text(
                                        text = if (language == Language.JA) item.subtitleJa else item.subtitleEn,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = PureWhite.copy(alpha = 0.85f)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
