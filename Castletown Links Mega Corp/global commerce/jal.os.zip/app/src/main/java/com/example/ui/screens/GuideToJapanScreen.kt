package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.i18n.Language
import com.example.ui.theme.*

@Composable
fun GuideToJapanScreen(
    onBookFlight: () -> Unit,
    language: Language
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
        modifier = Modifier
            .fillMaxSize()
            .testTag("guide_to_japan_screen")
    ) {
        // Hero Header
        item {
            Column {
                Text(
                    text = "JAL GUIDE TO JAPAN — 旅の美意識",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    ),
                    color = JalRed
                )
                Text(
                    text = "TOKYO 36 HOURS — 伝統と先進が交差する街",
                    style = MaterialTheme.typography.displaySmall.copy(fontWeight = FontWeight.Bold),
                    color = CharcoalBlack
                )
            }
        }

        // Editorial Article Card
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderGray, RoundedCornerShape(12.dp))
            ) {
                Column {
                    Box(modifier = Modifier.fillMaxWidth().height(180.dp)) {
                        Image(
                            painter = painterResource(id = R.drawable.img_jal_hero_fuji_1790148260419),
                            contentDescription = "Tokyo Guide",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = "MORNING — 銀座の静寂と朝茶",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = CharcoalBlack
                        )
                        Text(
                            text = "都会の喧騒が始まる前の静かな銀座。老舗日本茶専門店で淹れ立てのお茶をいただき、洗練された空間の中で心を整えるひととき。",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextMuted
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = "EVENING — 六本木ヒルズの夜景とモダン懐石",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = CharcoalBlack
                        )
                        Text(
                            text = "東京の街並みを一望する高層タワーでのディナー。旬の和の食材を生かしたモダン懐石料理とペアリングワイン。",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextMuted
                        )

                        Spacer(modifier = Modifier.height(18.dp))

                        Button(
                            onClick = onBookFlight,
                            colors = ButtonDefaults.buttonColors(containerColor = JalRed),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth().height(48.dp)
                        ) {
                            Text("東京（羽田）行きのフライトを検索", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        }
                    }
                }
            }
        }
    }
}
