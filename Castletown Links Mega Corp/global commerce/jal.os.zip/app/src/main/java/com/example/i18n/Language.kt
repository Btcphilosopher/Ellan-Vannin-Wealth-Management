package com.example.i18n

enum class Language(val code: String, val displayName: String, val nativeName: String) {
    JA("ja", "Japanese", "日本語"),
    EN("en", "English", "English"),
    ZH_CN("zh-CN", "Chinese (Simplified)", "简体中文"),
    ZH_TW("zh-TW", "Chinese (Traditional)", "繁體中文"),
    KO("ko", "Korean", "한국어"),
    ID("id", "Indonesian", "Bahasa Indonesia"),
    VI("vi", "Vietnamese", "Tiếng Việt"),
    TH("th", "Thai", "ไทย");

    companion object {
        fun fromCode(code: String): Language = values().find { it.code == code } ?: JA
    }
}

object Strings {
    fun get(key: String, lang: Language): String {
        return translations[lang]?.get(key)
            ?: translations[Language.JA]?.get(key)
            ?: translations[Language.EN]?.get(key)
            ?: key
    }

    private val translations: Map<Language, Map<String, String>> = mapOf(
        Language.JA to mapOf(
            "app_subtitle" to "日本航空",
            "what_to_do_now" to "今すぐすること",
            "where_to_next" to "次はどこへ旅しますか？",
            "search_flights" to "航空券を検索",
            "your_next_flight" to "ご搭乗予定のフライト",
            "my_trips" to "ご予約・ご搭乗一覧",
            "boarding_pass" to "モバイル搭乗券",
            "airport_mode" to "羽田空港ナビゲーション",
            "inflight_mode" to "機内モード JAL SKY",
            "mileage_bank" to "JALマイレージバンク",
            "guide_to_japan" to "JALガイド・ディスカバー",
            "status_title" to "ステイタス",
            "checkin_complete" to "搭乗手続き完了",
            "security_recommendation" to "保安検査場通過のご案内",
            "gate_assignment" to "搭乗口",
            "gate_change_alert" to "搭乗口変更のご案内",
            "boarding_in_progress" to "ご搭乗案内中",
            "flight_in_progress" to "飛行中",
            "baggage_belt_ready" to "手荷物返却カウンター",
            "life_status_points" to "LSP Points",
            "sakura_lounge" to "サクララウンジ",
            "connect_wifi" to "JAL SKY Wi-Fi に接続",
            "wifi_connected" to "Wi-Fi 接続中",
            "todays_meal" to "本日のお食事（和食 / 洋食）",
            "sim_controller" to "シナリオシミュレーション (全20ステップ)",
            "step" to "ステップ",
            "offline_cached" to "オフライン保存データ"
        ),
        Language.EN to mapOf(
            "app_subtitle" to "JAPAN AIRLINES",
            "what_to_do_now" to "WHAT TO DO NOW",
            "where_to_next" to "WHERE WILL YOU GO NEXT?",
            "search_flights" to "Search Flights",
            "your_next_flight" to "YOUR NEXT FLIGHT",
            "my_trips" to "My Trips",
            "boarding_pass" to "Boarding Pass",
            "airport_mode" to "Haneda Airport Mode",
            "inflight_mode" to "In-Flight Experience",
            "mileage_bank" to "JAL Mileage Bank",
            "guide_to_japan" to "Guide to Japan",
            "status_title" to "JAL Status",
            "checkin_complete" to "Check-in Complete",
            "security_recommendation" to "Security Recommendation",
            "gate_assignment" to "Gate",
            "gate_change_alert" to "GATE CHANGE NOTICE",
            "boarding_in_progress" to "Boarding Now",
            "flight_in_progress" to "In Flight",
            "baggage_belt_ready" to "Baggage Claim",
            "life_status_points" to "Life Status Points",
            "sakura_lounge" to "Sakura Lounge",
            "connect_wifi" to "Connect to JAL SKY Wi-Fi",
            "wifi_connected" to "Wi-Fi Connected",
            "todays_meal" to "Today's Meal",
            "sim_controller" to "Scenario Simulation (20 Steps)",
            "step" to "Step",
            "offline_cached" to "Offline Cached Data"
        ),
        Language.ZH_CN to mapOf(
            "app_subtitle" to "日本航空",
            "what_to_do_now" to "当前建议操作",
            "where_to_next" to "您的下一个目的地？",
            "search_flights" to "搜索航班",
            "your_next_flight" to "下一个航班",
            "my_trips" to "我的行程",
            "boarding_pass" to "电子登机牌",
            "airport_mode" to "羽田机场导航",
            "inflight_mode" to "机上体验 JAL SKY",
            "mileage_bank" to "JAL里程俱乐部",
            "guide_to_japan" to "探索日本指南",
            "status_title" to "会员级别",
            "checkin_complete" to "值机已完成",
            "gate_change_alert" to "登机口变更通知",
            "boarding_in_progress" to "正在登机",
            "baggage_belt_ready" to "行李领取处",
            "wifi_connected" to "Wi-Fi 已连接"
        ),
        Language.ZH_TW to mapOf(
            "app_subtitle" to "日本航空",
            "what_to_do_now" to "目前建議事項",
            "where_to_next" to "您的下一個目的地？",
            "search_flights" to "搜尋航班",
            "your_next_flight" to "下一個航班",
            "my_trips" to "我的行程",
            "boarding_pass" to "電子登機證",
            "airport_mode" to "羽田機場導航",
            "gate_change_alert" to "登機門變更通知",
            "boarding_in_progress" to "正在登機",
            "wifi_connected" to "Wi-Fi 已連線"
        ),
        Language.KO to mapOf(
            "app_subtitle" to "일본항공",
            "what_to_do_now" to "지금 해야 할 일",
            "where_to_next" to "다음 여행지는 어디인가요?",
            "search_flights" to "항공권 검색",
            "your_next_flight" to "다음 비행편",
            "my_trips" to "내 예약 일정",
            "boarding_pass" to "모바일 탑승권",
            "airport_mode" to "하네다 공항 모드",
            "gate_change_alert" to "탑승구 변경 안내",
            "boarding_in_progress" to "탑승 진행 중",
            "wifi_connected" to "Wi-Fi 연결됨"
        ),
        Language.ID to mapOf(
            "app_subtitle" to "JAPAN AIRLINES",
            "what_to_do_now" to "APA YANG HARUS DILAKUKAN SEKARANG",
            "where_to_next" to "KE MANA TUJUAN ANDA SELANJUTNYA?",
            "search_flights" to "Cari Penerbangan",
            "your_next_flight" to "PENERBANGAN BERIKUTNYA",
            "boarding_pass" to "Tiket Boarding",
            "gate_change_alert" to "PEMBERITAHUAN PERUBAHAN GERBANG"
        ),
        Language.VI to mapOf(
            "app_subtitle" to "JAPAN AIRLINES",
            "what_to_do_now" to "BẠN CẦN LÀM GÌ BÂY GIỜ",
            "where_to_next" to "BẠN SẼ ĐẾN ĐÂU TIẾP THEO?",
            "search_flights" to "Tìm chuyến bay",
            "boarding_pass" to "Thẻ lên máy bay"
        ),
        Language.TH to mapOf(
            "app_subtitle" to "สายการบินแจแปนแอร์ไลน์",
            "what_to_do_now" to "สิ่งที่คุณต้องทำตอนนี้",
            "where_to_next" to "จุดหมายต่อไปของคุณคือที่ไหน?",
            "search_flights" to "ค้นหาเที่ยวบิน",
            "boarding_pass" to "บัตรขึ้นเครื่อง"
        )
    )
}
