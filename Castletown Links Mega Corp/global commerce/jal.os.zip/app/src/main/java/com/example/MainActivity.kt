package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.JalViewModel
import com.example.ui.components.JalBottomNavigation
import com.example.ui.components.JalTopBar
import com.example.ui.components.SimulationControllerSheet
import com.example.ui.screens.*
import com.example.ui.theme.JalTheme

class MainActivity : ComponentActivity() {

    private val viewModel: JalViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            JalTheme {
                val language by viewModel.language.collectAsStateWithLifecycle()
                val activeTab by viewModel.activeTab.collectAsStateWithLifecycle()
                val flight by viewModel.activeFlight.collectAsStateWithLifecycle()
                val step by viewModel.currentStep.collectAsStateWithLifecycle()
                val currentStepIndex by viewModel.currentStepIndex.collectAsStateWithLifecycle()
                val boardingPass by viewModel.boardingPass.collectAsStateWithLifecycle()
                val isOffline by viewModel.isOfflineMode.collectAsStateWithLifecycle()
                val wifiState by viewModel.wifiState.collectAsStateWithLifecycle()
                val mileage by viewModel.mileageAccount.collectAsStateWithLifecycle()
                val seatsList by viewModel.seatsList.collectAsStateWithLifecycle()
                val selectedSeatId by viewModel.selectedSeatId.collectAsStateWithLifecycle()
                val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
                val bookingStep by viewModel.bookingStep.collectAsStateWithLifecycle()

                var showSimulationSheet by remember { mutableStateOf(false) }

                Scaffold(
                    topBar = {
                        JalTopBar(
                            selectedLanguage = language,
                            onLanguageSelected = { viewModel.setLanguage(it) },
                            isOffline = isOffline,
                            onToggleOffline = { viewModel.toggleOfflineMode() },
                            onOpenSimulation = { showSimulationSheet = true },
                            currentStepIndex = currentStepIndex
                        )
                    },
                    bottomBar = {
                        JalBottomNavigation(
                            activeTab = activeTab,
                            onTabSelected = { viewModel.setActiveTab(it) },
                            language = language
                        )
                    },
                    contentWindowInsets = WindowInsets.safeDrawing,
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .background(MaterialTheme.colorScheme.background)
                    ) {
                        when (activeTab) {
                            "home" -> HomeScreen(
                                flight = flight,
                                step = step,
                                language = language,
                                onNavigateTab = { viewModel.setActiveTab(it) }
                            )

                            "trips" -> MyTripScreen(
                                flight = flight,
                                boardingPass = boardingPass,
                                step = step,
                                language = language
                            )

                            "book" -> BookFlightScreen(
                                searchQuery = searchQuery,
                                onUpdateQuery = { viewModel.updateSearchQuery(it) },
                                bookingStep = bookingStep,
                                onStartSearch = { viewModel.startBookingFlow() },
                                onSelectFlight = { viewModel.selectFlightForBooking(it) },
                                seatsList = seatsList,
                                selectedSeatId = selectedSeatId,
                                onSelectSeat = { viewModel.selectSeat(it) },
                                onConfirmBooking = { viewModel.confirmBooking() },
                                onResetBooking = { viewModel.resetBookingFlow() },
                                language = language
                            )

                            "airport" -> AirportScreen(
                                flight = flight,
                                step = step,
                                language = language
                            )

                            "inflight" -> InflightScreen(
                                wifiState = wifiState,
                                onConnectWiFi = { viewModel.connectWiFi() },
                                language = language
                            )

                            "mileage" -> MileageScreen(
                                mileage = mileage,
                                language = language
                            )

                            "guide" -> GuideToJapanScreen(
                                onBookFlight = { viewModel.setActiveTab("book") },
                                language = language
                            )

                            else -> HomeScreen(
                                flight = flight,
                                step = step,
                                language = language,
                                onNavigateTab = { viewModel.setActiveTab(it) }
                            )
                        }

                        if (showSimulationSheet) {
                            SimulationControllerSheet(
                                engine = viewModel.simulationEngine,
                                currentStepIndex = currentStepIndex,
                                onSelectStep = {
                                    viewModel.selectStep(it)
                                },
                                onDismiss = { showSimulationSheet = false },
                                language = language
                            )
                        }
                    }
                }
            }
        }
    }
}
