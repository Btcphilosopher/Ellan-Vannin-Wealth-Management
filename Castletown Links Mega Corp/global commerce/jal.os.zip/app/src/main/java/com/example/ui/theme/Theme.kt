package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val JalLightColorScheme = lightColorScheme(
    primary = JalRed,
    onPrimary = PureWhite,
    primaryContainer = JalRedLight,
    onPrimaryContainer = JalRedDark,
    secondary = CharcoalBlack,
    onSecondary = PureWhite,
    secondaryContainer = AirportSilver,
    onSecondaryContainer = CharcoalBlack,
    tertiary = StatusGold,
    background = OffWhite,
    onBackground = CharcoalBlack,
    surface = PureWhite,
    onSurface = CharcoalBlack,
    surfaceVariant = AirportSilver,
    onSurfaceVariant = TextMuted,
    outline = BorderGray,
    error = JalRed
)

private val JalDarkColorScheme = darkColorScheme(
    primary = JalRed,
    onPrimary = PureWhite,
    primaryContainer = JalRedDark,
    onPrimaryContainer = PureWhite,
    secondary = PureWhite,
    onSecondary = CharcoalBlack,
    secondaryContainer = SoftCharcoal,
    onSecondaryContainer = PureWhite,
    tertiary = StatusGold,
    background = CharcoalBlack,
    onBackground = PureWhite,
    surface = SoftCharcoal,
    onSurface = PureWhite,
    surfaceVariant = CharcoalBlack,
    onSurfaceVariant = BorderGray,
    outline = SoftCharcoal,
    error = JalRed
)

@Composable
fun JalTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) JalDarkColorScheme else JalLightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = JalTypography,
        content = content
    )
}
