package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsWalk
import androidx.compose.material.icons.filled.Elevator
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.i18n.Language
import com.example.ui.theme.*

@Composable
fun AirportWayfindingMapCard(
    currentGate: String,
    previousGate: String?,
    language: Language
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, BorderGray, RoundedCornerShape(12.dp))
            .testTag("airport_wayfinding_map_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            // Airport Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "TOKYO HANEDA AIRPORT (HND)",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = CharcoalBlack
                    )
                    Text(
                        text = "Terminal 3 Departure Concourse - 3F Floorplan",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted
                    )
                }

                Surface(
                    color = JalRedLight,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.DirectionsWalk,
                            contentDescription = "Walk",
                            tint = JalRed,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (currentGate == "152") "8 MIN WALK (620m)" else "5 MIN WALK (410m)",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = JalRed
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Architectural Map Canvas
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .background(AirportSilver, RoundedCornerShape(8.dp))
                    .border(1.dp, BorderGray, RoundedCornerShape(8.dp))
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val width = size.width
                    val height = size.height

                    // Drawing Concourse Hallways
                    drawRect(
                        color = Color.White,
                        topLeft = Offset(width * 0.1f, height * 0.3f),
                        size = androidx.compose.ui.geometry.Size(width * 0.8f, height * 0.4f)
                    )

                    // Draw Path Line from Security -> Lounge -> Gate
                    val pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                    val startPt = Offset(width * 0.15f, height * 0.5f)
                    val loungePt = Offset(width * 0.45f, height * 0.5f)
                    val gate148Pt = Offset(width * 0.72f, height * 0.35f)
                    val gate152Pt = Offset(width * 0.85f, height * 0.65f)

                    // Security Point
                    drawCircle(color = StatusEmerald, radius = 12f, center = startPt)

                    // Sakura Lounge Point
                    drawCircle(color = StatusGold, radius = 14f, center = loungePt)

                    // Target Gate
                    val targetPt = if (currentGate == "152") gate152Pt else gate148Pt

                    // Route line
                    drawLine(
                        color = JalRed,
                        start = startPt,
                        end = loungePt,
                        strokeWidth = 6f
                    )
                    drawLine(
                        color = JalRed,
                        start = loungePt,
                        end = targetPt,
                        strokeWidth = 6f,
                        pathEffect = pathEffect
                    )

                    drawCircle(color = JalRed, radius = 18f, center = targetPt)
                }

                // Map Overlay Labels
                Box(modifier = Modifier.fillMaxSize().padding(12.dp)) {
                    Text(
                        text = "保安検査場 (Security)",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = StatusEmerald,
                        modifier = Modifier.align(Alignment.CenterStart)
                    )

                    Text(
                        text = "サクララウンジ (Lounge)",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = StatusGold,
                        modifier = Modifier.align(Alignment.Center)
                    )

                    Text(
                        text = "GATE $currentGate",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
                        color = JalRed,
                        modifier = Modifier.align(
                            if (currentGate == "152") Alignment.BottomEnd else Alignment.TopEnd
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Step-by-Step Wayfinding Node List
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Navigation, contentDescription = "Step 1", tint = StatusEmerald, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (language == Language.JA) "1. 保安検査場通過 (所要時間 3分)" else "1. Clear Central Security Checkpoint (3 min)",
                        style = MaterialTheme.typography.bodyMedium,
                        color = CharcoalBlack
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Elevator, contentDescription = "Step 2", tint = StatusGold, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (language == Language.JA) "2. エスカレーターで4F JALサクララウンジへ" else "2. Elevator to 4F JAL Sakura Lounge",
                        style = MaterialTheme.typography.bodyMedium,
                        color = CharcoalBlack
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.DirectionsWalk, contentDescription = "Step 3", tint = JalRed, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (currentGate == "152") {
                            if (language == Language.JA) "3. 【変更】152番ゲートへ動く歩道で進む（徒歩8分）" else "3. [UPDATED] Move to Gate 152 via travelator (8 min)"
                        } else {
                            if (language == Language.JA) "3. 148番ゲートへ直進（徒歩5分）" else "3. Proceed straight to Gate 148 (5 min)"
                        },
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = JalRed
                    )
                }
            }
        }
    }
}
