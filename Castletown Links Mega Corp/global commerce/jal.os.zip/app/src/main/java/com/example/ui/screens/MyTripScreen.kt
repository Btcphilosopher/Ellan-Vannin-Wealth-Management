package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.models.BoardingPassModel
import com.example.domain.models.FlightInfo
import com.example.i18n.Language
import com.example.simulation.SimulationScenarioStep
import com.example.ui.components.DigitalBoardingPassCard
import com.example.ui.theme.*

data class TimelineStageNode(
    val stageIndex: Int,
    val titleJa: String,
    val titleEn: String,
    val detailJa: String,
    val detailEn: String,
    val timeLabel: String
)

val journeyTimelineNodes = listOf(
    TimelineStageNode(1, "オンラインチェックイン", "Online Check-in", "✓ 完了 (座席4A確定)", "✓ Complete (Seat 4A confirmed)", "前日"),
    TimelineStageNode(2, "手荷物お預け", "Baggage Drop", "✓ 自動手荷物預け機通過", "✓ Self Bag Drop Complete", "14:00"),
    TimelineStageNode(3, "保安検査場通過", "Security Checkpoint", "中央保安検査場推奨", "Central Security Checkpoint", "14:20"),
    TimelineStageNode(4, "サクララウンジ", "JAL Sakura Lounge", "本館4F 寿司バー・ダイニング", "Main Concourse 4F Dining", "14:40"),
    TimelineStageNode(5, "搭乗ゲート案内", "Gate Boarding", "152番ゲート（変更後）", "Gate 152 (Updated)", "15:15"),
    TimelineStageNode(6, "出発 JL041", "Departure JL041", "東京羽田 T3 → ロンドン LHR T3", "HND T3 → LHR T3", "15:55"),
    TimelineStageNode(7, "到着・手荷物返却", "Arrival & Baggage", "ヒースロー 7番ターンテーブル", "LHR Baggage Belt 7", "22:20")
)

@Composable
fun MyTripScreen(
    flight: FlightInfo,
    boardingPass: BoardingPassModel,
    step: SimulationScenarioStep,
    language: Language
) {
    var showBoardingPassModal by remember { mutableStateOf(false) }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
        modifier = Modifier
            .fillMaxSize()
            .testTag("my_trip_screen")
    ) {
        // Digital Boarding Pass Button / Preview
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = JalRed),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("show_boarding_pass_btn")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "JAL DIGITAL BOARDING PASS",
                            style = MaterialTheme.typography.labelSmall,
                            color = PureWhite.copy(alpha = 0.8f)
                        )
                        Text(
                            text = "${flight.flightNumber} • Seat ${boardingPass.seat} • Gate ${step.gateNumber}",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = PureWhite
                        )
                    }

                    Button(
                        onClick = { showBoardingPassModal = true },
                        colors = ButtonDefaults.buttonColors(containerColor = PureWhite),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Icon(Icons.Default.QrCode, contentDescription = "QR", tint = JalRed, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("表示", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = JalRed)
                    }
                }
            }
        }

        // Expanded Boarding Pass Card
        item {
            DigitalBoardingPassCard(boardingPass = boardingPass, language = language)
        }

        // Chronological Journey Timeline Header
        item {
            Text(
                text = if (language == Language.JA) "時系列ジャーニータイムライン (22 SEP 2026)" else "Chronological Journey Timeline (22 SEP 2026)",
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                color = CharcoalBlack
            )
        }

        // Timeline Node Items
        items(journeyTimelineNodes) { node ->
            val isCurrent = (step.stepIndex in ((node.stageIndex - 1) * 3)..(node.stageIndex * 3))
            val isCompleted = step.stepIndex > (node.stageIndex * 3)

            Card(
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isCurrent) JalRedLight else MaterialTheme.colorScheme.surface
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = if (isCurrent) 3.dp else 1.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        if (isCurrent) JalRed else BorderGray,
                        RoundedCornerShape(10.dp)
                    )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Node Icon Status Indicator
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(
                                if (isCompleted) StatusEmerald else if (isCurrent) JalRed else AirportSilver
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isCompleted) {
                            Icon(Icons.Default.Check, contentDescription = "Done", tint = PureWhite, modifier = Modifier.size(18.dp))
                        } else {
                            Text(
                                text = node.timeLabel,
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontWeight = FontWeight.Bold),
                                color = if (isCurrent) PureWhite else TextMuted
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (language == Language.JA) node.titleJa else node.titleEn,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium
                            ),
                            color = if (isCurrent) JalRed else if (isCompleted) TextMuted else CharcoalBlack
                        )
                        Text(
                            text = if (language == Language.JA) node.detailJa else node.detailEn,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (isCompleted) TextMuted else CharcoalBlack
                        )
                    }
                }
            }
        }
    }
}
