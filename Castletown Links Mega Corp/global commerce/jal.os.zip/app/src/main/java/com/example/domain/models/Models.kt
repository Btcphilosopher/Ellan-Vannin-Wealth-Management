package com.example.domain.models

import java.util.UUID

enum class JourneyStage(val titleJa: String, val titleEn: String) {
    DISCOVER_PLAN("探す・計画する", "Discover & Plan"),
    ONE_MONTH_PREPARE("ご搭乗前の準備", "Prepare for Departure"),
    DAY_BEFORE_CHECKIN("オンラインチェックイン", "Online Check-in"),
    CHECKED_IN_SECURITY("保安検査場のご案内", "Security Checkpoint"),
    AIRPORT_GATE_ASSIGNED("搭乗口案内", "Airport & Gate"),
    BOARDING_NOW("搭乗中", "Boarding"),
    ON_BOARD_FLIGHT("ご搭乗中 (JAL SKY)", "On Board"),
    ARRIVAL_BAGGAGE("到着・手荷物受け取り", "Arrival & Baggage"),
    POST_TRIP_MEMORY("旅の記録・マイル", "Post-Trip Memory")
}

enum class FlightStatusType(val labelJa: String, val labelEn: String) {
    SCHEDULED("定刻", "Scheduled"),
    CHECK_IN_OPEN("チェックイン受付中", "Check-in Open"),
    CHECK_IN_COMPLETE("チェックイン完了", "Checked In"),
    SECURITY_NEXT("保安検査へお進みください", "Proceed to Security"),
    GATE_ASSIGNED("搭乗口確定", "Gate Assigned"),
    GATE_CHANGED("搭乗口変更", "Gate Changed"),
    BOARDING("搭乗案内中", "Boarding"),
    FINAL_CALL("最終案内", "Final Call"),
    AIRBORNE("巡航飛行中", "En Route"),
    LANDED("羽田/ヒースロー到着", "Landed"),
    DELAYED("遅延", "Delayed")
}

data class FlightInfo(
    val id: String = "JL041",
    val flightNumber: String = "JL041",
    val originCode: String = "HND",
    val originNameJa: String = "東京 羽田 (HND) 第3ターミナル",
    val originNameEn: String = "Tokyo Haneda (HND) T3",
    val destinationCode: String = "LHR",
    val destinationNameJa: String = "ロンドン ヒースロー (LHR) 第3ターミナル",
    val destinationNameEn: String = "London Heathrow (LHR) T3",
    val departureTime: String = "15:55",
    val arrivalTime: String = "22:20",
    val dateString: String = "2026年9月23日",
    val aircraftModel: String = "Boeing 787-9 Dreamliner",
    val cabinClass: String = "ビジネスクラス (JAL SKY SUITE)",
    val fareCategory: String = "Flex Business",
    val gateNumber: String = "148",
    val previousGate: String? = null,
    val boardingGroup: String = "Group 2",
    val seatNumber: String = "4A",
    val terminal: String = "T3",
    val baggageBelt: String = "BELT 7",
    val durationText: String = "14時間25分",
    val status: FlightStatusType = FlightStatusType.CHECK_IN_OPEN,
    val isInternational: Boolean = true
)

data class PassengerRecord(
    val passengerId: String = "PAX-001",
    val fullName: String = "Tom Miller",
    val dob: String = "1988-06-15",
    val nationality: String = "United Kingdom",
    val passportNumber: String = "GB987654321",
    val frequentFlyerNumber: String = "JMB 84920129",
    val contactEmail: String = "tom@ahyx.org",
    val specialAssistance: String = "None Required",
    val mealPreference: String = "Japanese Kaiseki (和食選定)",
    val seatPreference: String = "Window (窓側 4A)"
)

data class BoardingPassModel(
    val boardingPassId: String = "BP-JL041-4A",
    val flightNumber: String = "JL041",
    val passengerName: String = "TOM / MILLER MR",
    val originCode: String = "HND",
    val destinationCode: String = "LHR",
    val departureDate: String = "22 SEP 2026",
    val departureTime: String = "15:55",
    val boardingTime: String = "15:15",
    val gate: String = "148",
    val seat: String = "4A",
    val group: String = "GROUP 2",
    val classCode: String = "BUSINESS (C)",
    val barcodeValue: String = "M1MILLER/TOM         EJL041 HNDLHRJL 0041 265C004A0001 147",
    val statusBadge: String = "CHECKED IN ✓"
)

enum class SeatCabinClass { BUSINESS, PREMIUM_ECONOMY, ECONOMY }
enum class SeatType { WINDOW, AISLE, MIDDLE }
enum class SeatStatus { AVAILABLE, OCCUPIED, SELECTED, BLOCKED }

data class AircraftSeat(
    val id: String,
    val row: Int,
    val column: String,
    val cabin: SeatCabinClass,
    val type: SeatType,
    var status: SeatStatus,
    val isBassinet: Boolean = false,
    val isEmergencyExit: Boolean = false
)

data class AircraftLayout(
    val aircraftName: String = "Boeing 787-9 (JAL SKY SUITE)",
    val cabins: List<SeatCabinClass> = listOf(
        SeatCabinClass.BUSINESS,
        SeatCabinClass.PREMIUM_ECONOMY,
        SeatCabinClass.ECONOMY
    )
)

data class BaggageStatusItem(
    val tagId: String = "JL041-98203",
    val passengerName: String = "Tom Miller",
    val statusStage: String = "CHECKED IN", // CHECKED IN, LOADED, IN FLIGHT, ARRIVED, BELT_7
    val currentStepIndex: Int = 1,
    val beltNumber: String = "BELT 7",
    val lastUpdated: String = "15:10 JST"
)

data class InflightMealItem(
    val courseType: String, // JAPANESE or WESTERN
    val titleJa: String,
    val titleEn: String,
    val descriptionJa: String,
    val descriptionEn: String,
    val expectedServiceTime: String = "18:20 JST"
)

data class InflightWiFiState(
    val isConnected: Boolean = false,
    val ssid: String = "JAL-SKY-WIFI",
    val ipAddress: String = "10.24.188.42",
    val dataUsedMb: Float = 142.5f,
    val connectionSpeed: String = "48 Mbps (Satellite)"
)

data class InflightTelemetry(
    val altitudeFeet: Int = 38000,
    val speedKmh: Int = 892,
    val remainingHours: Int = 10,
    val remainingMinutes: Int = 24,
    val originLocalTime: String = "17:45 JST",
    val destLocalTime: String = "09:45 BST",
    val routeProgressFraction: Float = 0.35f
)

data class MileageAccountModel(
    val memberName: String = "Tom Miller",
    val jmbNumber: String = "849 201 290",
    val milesBalance: Int = 84250,
    val lifeStatusPoints: Int = 24800,
    val currentTier: String = "JGC SAPPHIRE",
    val nextTier: String = "JMB DIAMOND",
    val pointsToNextTier: Int = 5200,
    val progressFraction: Float = 0.82f
)

data class AirportWayfindingStep(
    val stepIndex: Int,
    val instructionJa: String,
    val instructionEn: String,
    val distanceMeters: Int,
    val durationMinutes: Int,
    val hasElevator: Boolean = true
)

data class NotificationMessage(
    val id: String = UUID.randomUUID().toString(),
    val titleJa: String,
    val titleEn: String,
    val bodyJa: String,
    val bodyEn: String,
    val timestamp: String,
    val isAlert: Boolean = false,
    val isRead: Boolean = false
)

data class DestinationItem(
    val id: String,
    val cityJa: String,
    val cityEn: String,
    val countryEn: String,
    val airportCode: String,
    val descriptionJa: String,
    val descriptionEn: String,
    val samplePriceJpy: Int,
    val category: String = "International"
)
