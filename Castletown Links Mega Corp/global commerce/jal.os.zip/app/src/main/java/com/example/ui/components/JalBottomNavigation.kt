package com.example.ui.components

import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.i18n.Language
import com.example.i18n.Strings
import com.example.ui.theme.JalRed
import com.example.ui.theme.TextMuted

data class NavTabItem(
    val id: String,
    val titleKey: String,
    val activeIcon: androidx.compose.ui.graphics.vector.ImageVector,
    val inactiveIcon: androidx.compose.ui.graphics.vector.ImageVector
)

val navTabs = listOf(
    NavTabItem("home", "app_subtitle", Icons.Filled.FlightTakeoff, Icons.Outlined.FlightTakeoff),
    NavTabItem("trips", "my_trips", Icons.Filled.ConfirmationNumber, Icons.Outlined.ConfirmationNumber),
    NavTabItem("book", "search_flights", Icons.Filled.Search, Icons.Outlined.Search),
    NavTabItem("airport", "airport_mode", Icons.Filled.Place, Icons.Outlined.Place),
    NavTabItem("inflight", "inflight_mode", Icons.Filled.AirlineSeatReclineExtra, Icons.Outlined.AirlineSeatReclineExtra),
    NavTabItem("mileage", "mileage_bank", Icons.Filled.CardMembership, Icons.Outlined.CardMembership),
    NavTabItem("guide", "guide_to_japan", Icons.Filled.Explore, Icons.Outlined.Explore)
)

@Composable
fun JalBottomNavigation(
    activeTab: String,
    onTabSelected: (String) -> Unit,
    language: Language
) {
    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 6.dp,
        modifier = Modifier
            .windowInsetsPadding(WindowInsets.navigationBars)
            .testTag("jal_bottom_navigation")
    ) {
        navTabs.forEach { tab ->
            val isSelected = activeTab == tab.id
            val title = Strings.get(tab.titleKey, language)

            NavigationBarItem(
                selected = isSelected,
                onClick = { onTabSelected(tab.id) },
                icon = {
                    Icon(
                        imageVector = if (isSelected) tab.activeIcon else tab.inactiveIcon,
                        contentDescription = title,
                        tint = if (isSelected) JalRed else TextMuted
                    )
                },
                label = {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = JalRed,
                    selectedTextColor = JalRed,
                    indicatorColor = MaterialTheme.colorScheme.primaryContainer
                ),
                modifier = Modifier.testTag("nav_tab_${tab.id}")
            )
        }
    }
}
