package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.models.FlightInfo
import com.example.domain.models.FlightStatusType
import com.example.i18n.Language
import com.example.i18n.Strings
import com.example.simulation.SimulationScenarioStep
import com.example.ui.theme.*

@Composable
fun WhatToDoNowCard(
    flight: FlightInfo,
    step: SimulationScenarioStep,
    language: Language,
    onPrimaryAction: () -> Unit,
    onNavigateToAirport: () -> Unit
) {
    var countdownSeconds by remember { mutableStateOf(8072) } // 02:14:32

    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(1000)
            if (countdownSeconds > 0) countdownSeconds--
        }
    }

    val hours = countdownSeconds / 3600
    val minutes = (countdownSeconds % 3600) / 60
    val seconds = countdownSeconds % 60
    val formattedTimer = String.format("%02d:%02d:%02d", hours, minutes, seconds)

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, BorderGray, RoundedCornerShape(12.dp))
            .testTag("what_to_do_now_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            // Header: WHAT TO DO NOW
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(if (step.hasAlert) JalRed else StatusEmerald)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = Strings.get("what_to_do_now", language),
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp
                        ),
                        color = TextMuted
                    )
                }

                Surface(
                    color = AirportSilver,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = "DEPARTURE IN $formattedTimer",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = CharcoalBlack,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Gate Change Alert Banner if active
            AnimatedVisibility(
                visible = step.hasAlert,
                enter = expandVertically(),
                exit = shrinkVertically()
            ) {
                Surface(
                    color = JalRedLight,
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, JalRed),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Gate Change Alert",
                            tint = JalRed,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = if (language == Language.JA) "【搭乗口変更】" else "[GATE CHANGE NOTICE]",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = JalRed
                            )
                            Text(
                                text = if (language == Language.JA) step.alertMessageJa ?: "" else step.alertMessageEn ?: "",
                                style = MaterialTheme.typography.bodyMedium,
                                color = CharcoalBlack
                            )
                        }
                    }
                }
            }

            // Primary Current Action Status
            Text(
                text = if (language == Language.JA) step.titleJa else step.titleEn,
                style = MaterialTheme.typography.displaySmall.copy(fontWeight = FontWeight.Bold),
                color = CharcoalBlack
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = if (language == Language.JA) step.descriptionJa else step.descriptionEn,
                style = MaterialTheme.typography.bodyLarge,
                color = TextMuted
            )

            Spacer(modifier = Modifier.height(18.dp))

            // Operational Details Timeline Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(AirportSilver, RoundedCornerShape(8.dp))
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Check-in status
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("CHECK-IN", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Spacer(modifier = Modifier.height(2.dp))
                    Text("✓ Complete", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold), color = StatusEmerald)
                }

                Divider(modifier = Modifier.height(24.dp).width(1.dp), color = BorderGray)

                // Security status
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("SECURITY", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Spacer(modifier = Modifier.height(2.dp))
                    Text("By 14:20", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold), color = CharcoalBlack)
                }

                Divider(modifier = Modifier.height(24.dp).width(1.dp), color = BorderGray)

                // Gate assignment
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("GATE", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Spacer(modifier = Modifier.height(2.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (step.previousGate != null) {
                            Text(step.previousGate, style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Normal), color = TextMuted)
                            Text("→", style = MaterialTheme.typography.labelMedium, color = JalRed)
                        }
                        Text(
                            text = step.gateNumber,
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black),
                            color = if (step.previousGate != null) JalRed else CharcoalBlack
                        )
                    }
                }

                Divider(modifier = Modifier.height(24.dp).width(1.dp), color = BorderGray)

                // Boarding status
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("BOARDING", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Spacer(modifier = Modifier.height(2.dp))
                    Text("15:15", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold), color = CharcoalBlack)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Primary Action Button
            Button(
                onClick = onPrimaryAction,
                colors = ButtonDefaults.buttonColors(containerColor = JalRed),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("what_to_do_primary_action_btn")
            ) {
                Text(
                    text = when (step.stepIndex) {
                        1, 2 -> if (language == Language.JA) "オンラインチェックインを開始" else "Start Online Check-in"
                        3 -> if (language == Language.JA) "モバイル搭乗券を表示" else "View Digital Boarding Pass"
                        in 4..8 -> if (language == Language.JA) "羽田空港ナビ・保安検査へ" else "Open Haneda Airport Navigation"
                        9, 10 -> if (language == Language.JA) "152番ゲートへのルートを表示" else "Take Me to Gate 152"
                        11, 12 -> if (language == Language.JA) "搭乗ゲート通過コード表示" else "Show Boarding Gate Barcode"
                        in 13..16 -> if (language == Language.JA) "機内モード JAL SKY を開く" else "Open In-Flight Portal"
                        in 17..19 -> if (language == Language.JA) "手荷物返却7番カウンターへ" else "Track Baggage Belt 7"
                        else -> if (language == Language.JA) "旅の記録と獲得マイルを確認" else "View Travel Memory & Miles"
                    },
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = PureWhite
                )
            }
        }
    }
}
