package com.example.ui.components

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.models.FlightInfo
import com.example.ui.theme.*

@Composable
fun FlightResultCard(
    flight: FlightInfo,
    onSelectFlight: (FlightInfo) -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, BorderGray, RoundedCornerShape(12.dp))
            .testTag("flight_result_card_${flight.flightNumber}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            // Timetable Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = flight.flightNumber,
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black),
                        color = JalRed
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Surface(
                        color = AirportSilver,
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = flight.aircraftModel,
                            style = MaterialTheme.typography.labelSmall,
                            color = CharcoalBlack,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Text(
                    text = flight.durationText,
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = TextMuted
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Airport Departure & Arrival Timetable Layout
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Departure
                Column {
                    Text(
                        text = flight.departureTime,
                        style = MaterialTheme.typography.displayMedium.copy(fontWeight = FontWeight.Black),
                        color = CharcoalBlack
                    )
                    Text(
                        text = "${flight.originCode} / 羽田",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = CharcoalBlack
                    )
                    Text(
                        text = "T3 Terminal",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted
                    )
                }

                // Flight Route Arrow
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("直行便", style = MaterialTheme.typography.labelSmall, color = StatusEmerald)
                    Text("────────►", style = MaterialTheme.typography.bodyLarge, color = TextMuted)
                    Text("Boeing 787-9", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                }

                // Arrival
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = flight.arrivalTime,
                        style = MaterialTheme.typography.displayMedium.copy(fontWeight = FontWeight.Black),
                        color = CharcoalBlack
                    )
                    Text(
                        text = "${flight.destinationCode} / LHR",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = CharcoalBlack
                    )
                    Text(
                        text = "T3 Terminal (+1日)",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Divider(color = BorderGray, thickness = 1.dp)

            Spacer(modifier = Modifier.height(12.dp))

            // Pricing & Selection Button Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = flight.cabinClass,
                        style = MaterialTheme.typography.labelMedium,
                        color = TextMuted
                    )
                    Text(
                        text = "¥580,000 / £3,850",
                        style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Black),
                        color = CharcoalBlack
                    )
                }

                Button(
                    onClick = { onSelectFlight(flight) },
                    colors = ButtonDefaults.buttonColors(containerColor = JalRed),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.testTag("select_flight_btn_${flight.flightNumber}")
                ) {
                    Text("選択", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                }
            }
        }
    }
}
