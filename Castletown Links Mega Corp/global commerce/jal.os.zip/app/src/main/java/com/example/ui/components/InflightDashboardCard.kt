package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.WifiTethering
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.models.InflightWiFiState
import com.example.i18n.Language
import com.example.ui.theme.*

@Composable
fun InflightDashboardCard(
    wifiState: InflightWiFiState,
    onConnectWiFi: () -> Unit,
    language: Language
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, BorderGray, RoundedCornerShape(12.dp))
            .testTag("inflight_dashboard_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            // Title Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "ON BOARD — JAL SKY",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        ),
                        color = JalRed
                    )
                    Text(
                        text = "JL041 • Tokyo (HND) → London (LHR)",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted
                    )
                }

                Surface(
                    color = AirportSilver,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = "10h 24m remaining",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = CharcoalBlack,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Inflight Telemetry Grid
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(AirportSilver, RoundedCornerShape(8.dp))
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("ALTITUDE", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Text("38,000 ft", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold), color = CharcoalBlack)
                    Text("11,582 m", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                }

                Divider(modifier = Modifier.height(36.dp).width(1.dp), color = BorderGray)

                Column {
                    Text("SPEED", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Text("892 km/h", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold), color = CharcoalBlack)
                    Text("554 mph", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                }

                Divider(modifier = Modifier.height(36.dp).width(1.dp), color = BorderGray)

                Column {
                    Text("DESTINATION", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Text("09:45 BST", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold), color = JalRed)
                    Text("London LHR", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Inflight Meal Section
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderGray),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Restaurant, contentDescription = "Meal", tint = JalRed, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (language == Language.JA) "本日のお食事（18:20 JST 頃ご用意）" else "Today's Meal Service (Expected 18:20 JST)",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = CharcoalBlack
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = if (language == Language.JA) "【和食】 季節の前菜盛り合わせ・銀鱈西京焼き・炊き立て新潟県産コシヒカリ・お味噌汁"
                        else "[JAPANESE KAISEKI] Seasonal appetizers, Saikyo Miso Grilled Sablefish, Niigata Koshihikari Rice, Miso Soup",
                        style = MaterialTheme.typography.bodyMedium,
                        color = CharcoalBlack
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // JAL SKY Wi-Fi Section
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (wifiState.isConnected) Icons.Default.Wifi else Icons.Default.WifiTethering,
                        contentDescription = "Wi-Fi",
                        tint = if (wifiState.isConnected) StatusEmerald else TextMuted,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = if (wifiState.isConnected) "JAL SKY Wi-Fi 接続中" else "JAL SKY Wi-Fi 利用可能",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = CharcoalBlack
                        )
                        Text(
                            text = if (wifiState.isConnected) "速度: ${wifiState.connectionSpeed} • IP: ${wifiState.ipAddress}" else "機内WiFiネットワーク: JAL-SKY-WIFI",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted
                        )
                    }
                }

                Button(
                    onClick = onConnectWiFi,
                    enabled = !wifiState.isConnected,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (wifiState.isConnected) StatusEmerald else JalRed,
                        disabledContainerColor = StatusEmerald.copy(alpha = 0.2f)
                    ),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.testTag("wifi_connect_btn")
                ) {
                    Text(
                        text = if (wifiState.isConnected) "CONNECTED ✓" else "CONNECT",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = PureWhite
                    )
                }
            }
        }
    }
}
