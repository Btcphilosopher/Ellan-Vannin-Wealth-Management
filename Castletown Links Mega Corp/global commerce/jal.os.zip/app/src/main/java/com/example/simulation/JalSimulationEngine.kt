package com.example.simulation

import com.example.domain.models.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class SimulationScenarioStep(
    val stepIndex: Int, // 1 to 20
    val titleJa: String,
    val titleEn: String,
    val descriptionJa: String,
    val descriptionEn: String,
    val stage: JourneyStage,
    val flightStatus: FlightStatusType,
    val gateNumber: String = "148",
    val previousGate: String? = null,
    val baggageStatus: String = "CHECKED IN",
    val wifiConnected: Boolean = false,
    val hasAlert: Boolean = false,
    val alertMessageJa: String? = null,
    val alertMessageEn: String? = null
)

class JalSimulationEngine {

    val stepsList: List<SimulationScenarioStep> = listOf(
        SimulationScenarioStep(
            stepIndex = 1,
            titleJa = "1. JAL.OS起動",
            titleEn = "1. Launch JAL.OS",
            descriptionJa = "アプリ起動。リアルタイム運行管理エンジンと同期中",
            descriptionEn = "App launched. Syncing with live operational engine.",
            stage = JourneyStage.DISCOVER_PLAN,
            flightStatus = FlightStatusType.SCHEDULED
        ),
        SimulationScenarioStep(
            stepIndex = 2,
            titleJa = "2. 次のフライト識別",
            titleEn = "2. Identify Upcoming Flight",
            descriptionJa = "ホーム画面が自動的にJL041（羽田→ヒースロー）を提示",
            descriptionEn = "Home screen displays upcoming JL041 (HND → LHR).",
            stage = JourneyStage.ONE_MONTH_PREPARE,
            flightStatus = FlightStatusType.SCHEDULED
        ),
        SimulationScenarioStep(
            stepIndex = 3,
            titleJa = "3. チェックイン手続き",
            titleEn = "3. Passenger Check-in",
            descriptionJa = "パスポート確認・座席4A確定でオンラインチェックイン完了",
            descriptionEn = "Passport verified, Seat 4A confirmed. Online check-in done.",
            stage = JourneyStage.DAY_BEFORE_CHECKIN,
            flightStatus = FlightStatusType.CHECK_IN_COMPLETE
        ),
        SimulationScenarioStep(
            stepIndex = 4,
            titleJa = "4. モバイル搭乗券発行",
            titleEn = "4. Digital Boarding Pass",
            descriptionJa = "QRコード付きデジタル搭乗券発行。グループ2 / 座席4A",
            descriptionEn = "Digital boarding pass generated with QR code. Group 2 / Seat 4A.",
            stage = JourneyStage.CHECKED_IN_SECURITY,
            flightStatus = FlightStatusType.CHECK_IN_COMPLETE
        ),
        SimulationScenarioStep(
            stepIndex = 5,
            titleJa = "5. 空港モード起動",
            titleEn = "5. Airport Mode Active",
            descriptionJa = "羽田空港第3ターミナル検知。空港ウェイファイディング表示",
            descriptionEn = "Tokyo Haneda Terminal 3 detected. Airport wayfinding active.",
            stage = JourneyStage.CHECKED_IN_SECURITY,
            flightStatus = FlightStatusType.SECURITY_NEXT
        ),
        SimulationScenarioStep(
            stepIndex = 6,
            titleJa = "6. 保安検査場通過推奨",
            titleEn = "6. Security Recommendation",
            descriptionJa = "「14:20までに保安検査場へお進みください」と案内",
            descriptionEn = "Security checkpoint recommendation: Proceed by 14:20.",
            stage = JourneyStage.CHECKED_IN_SECURITY,
            flightStatus = FlightStatusType.SECURITY_NEXT
        ),
        SimulationScenarioStep(
            stepIndex = 7,
            titleJa = "7. 搭乗口148指定",
            titleEn = "7. Gate 148 Assigned",
            descriptionJa = "搭乗口148番への案内ルート作成。サクララウンジ経由",
            descriptionEn = "Route to Gate 148 calculated via Sakura Lounge.",
            stage = JourneyStage.AIRPORT_GATE_ASSIGNED,
            flightStatus = FlightStatusType.GATE_ASSIGNED,
            gateNumber = "148"
        ),
        SimulationScenarioStep(
            stepIndex = 8,
            titleJa = "8. 搭乗口へ移動中",
            titleEn = "8. Walking to Gate",
            descriptionJa = "ラウンジから搭乗口148へ移動中（徒歩約5分）",
            descriptionEn = "En route from Sakura Lounge to Gate 148 (5 min walk).",
            stage = JourneyStage.AIRPORT_GATE_ASSIGNED,
            flightStatus = FlightStatusType.GATE_ASSIGNED,
            gateNumber = "148"
        ),
        SimulationScenarioStep(
            stepIndex = 9,
            titleJa = "9. 搭乗口変更発生",
            titleEn = "9. Gate Change Occurs",
            descriptionJa = "運行管理システムから搭乗口変更（148番 → 152番）を配信",
            descriptionEn = "Operational system dispatches Gate Change: 148 → 152.",
            stage = JourneyStage.AIRPORT_GATE_ASSIGNED,
            flightStatus = FlightStatusType.GATE_CHANGED,
            gateNumber = "152",
            previousGate = "148",
            hasAlert = true,
            alertMessageJa = "【搭乗口変更】JL041は152番ゲートに変更となりました（徒歩8分）",
            alertMessageEn = "[GATE CHANGE] JL041 now departs from Gate 152 (8 min walk)."
        ),
        SimulationScenarioStep(
            stepIndex = 10,
            titleJa = "10. アプリ画面即時更新",
            titleEn = "10. App UI Instant Update",
            descriptionJa = "カード・ナビマップが即時に152番ゲートへの新ルートを描画",
            descriptionEn = "Context card & indoor map dynamically updated for Gate 152.",
            stage = JourneyStage.AIRPORT_GATE_ASSIGNED,
            flightStatus = FlightStatusType.GATE_CHANGED,
            gateNumber = "152",
            previousGate = "148"
        ),
        SimulationScenarioStep(
            stepIndex = 11,
            titleJa = "11. 搭乗開始案内",
            titleEn = "11. Boarding Begins",
            descriptionJa = "「JL041便 Group 2の皆様 ご搭乗を開始いたします」",
            descriptionEn = "Boarding now open for Group 2 passengers.",
            stage = JourneyStage.BOARDING_NOW,
            flightStatus = FlightStatusType.BOARDING,
            gateNumber = "152"
        ),
        SimulationScenarioStep(
            stepIndex = 12,
            titleJa = "12. 搭乗・着席",
            titleEn = "12. Boarding Complete",
            descriptionJa = "機内改札通過。ボーイング787-9 座席4Aに着席",
            descriptionEn = "Boarding pass scanned. Seated at 4A on Boeing 787-9.",
            stage = JourneyStage.BOARDING_NOW,
            flightStatus = FlightStatusType.BOARDING,
            gateNumber = "152"
        ),
        SimulationScenarioStep(
            stepIndex = 13,
            titleJa = "13. ON BOARD モード起動",
            titleEn = "13. ON BOARD Mode Active",
            descriptionJa = "ドアクローズ・巡航中。テレメトリ（高度11,500m / 速度892km/h）表示",
            descriptionEn = "Door closed, cruising. Telemetry: 38,000 ft / 892 km/h active.",
            stage = JourneyStage.ON_BOARD_FLIGHT,
            flightStatus = FlightStatusType.AIRBORNE,
            baggageStatus = "LOADED ON AIRCRAFT"
        ),
        SimulationScenarioStep(
            stepIndex = 14,
            titleJa = "14. 機内食メニュー表示",
            titleEn = "14. Inflight Meal Info",
            descriptionJa = "本日のお食事「旬の和食コース（銀鱈西京焼き / 季節の小鉢）」案内",
            descriptionEn = "Today's Meal: Seasonal Kaiseki Course (Gindara Saikyo-yaki).",
            stage = JourneyStage.ON_BOARD_FLIGHT,
            flightStatus = FlightStatusType.AIRBORNE
        ),
        SimulationScenarioStep(
            stepIndex = 15,
            titleJa = "15. JAL SKY Wi-Fi 接続",
            titleEn = "15. Wi-Fi Connected",
            descriptionJa = "衛星機内Wi-Fi（JAL-SKY-WIFI）自動接続完了",
            descriptionEn = "Connected to satellite inflight Wi-Fi (JAL-SKY-WIFI).",
            stage = JourneyStage.ON_BOARD_FLIGHT,
            flightStatus = FlightStatusType.AIRBORNE,
            wifiConnected = true
        ),
        SimulationScenarioStep(
            stepIndex = 16,
            titleJa = "16. フライト進捗更新",
            titleEn = "16. Flight Route Progress",
            descriptionJa = "シベリア北極ルート通過中。残り飛行時間 10時間24分",
            descriptionEn = "Flight progress update: 10h 24m remaining to London Heathrow.",
            stage = JourneyStage.ON_BOARD_FLIGHT,
            flightStatus = FlightStatusType.AIRBORNE,
            wifiConnected = true
        ),
        SimulationScenarioStep(
            stepIndex = 17,
            titleJa = "17. ヒースロー着陸",
            titleEn = "17. Landed at Heathrow",
            descriptionJa = "ロンドン ヒースロー空港第3ターミナル着陸。定刻22:20到着",
            descriptionEn = "Landed safely at London Heathrow (LHR) Terminal 3 at 22:20.",
            stage = JourneyStage.ARRIVAL_BAGGAGE,
            flightStatus = FlightStatusType.LANDED,
            baggageStatus = "ARRIVED AT AIRPORT"
        ),
        SimulationScenarioStep(
            stepIndex = 18,
            titleJa = "18. 手荷物ターンテーブル表示",
            titleEn = "18. Baggage Claim Belt 7",
            descriptionJa = "「お預け手荷物 タグJL041-98203 は 7番ターンテーブルで返却中」",
            descriptionEn = "Checked bag JL041-98203 delivered to Baggage Claim Belt 7.",
            stage = JourneyStage.ARRIVAL_BAGGAGE,
            flightStatus = FlightStatusType.LANDED,
            baggageStatus = "DELIVERED TO BELT 7"
        ),
        SimulationScenarioStep(
            stepIndex = 19,
            titleJa = "19. 到着モードナビゲーション",
            titleEn = "19. Arrival Mode Active",
            descriptionJa = "手荷物受取 → 入国審査 → ヒースロー・エクスプレス乗車ルート案内",
            descriptionEn = "Arrival navigation: Baggage → Passport Control → Heathrow Express.",
            stage = JourneyStage.ARRIVAL_BAGGAGE,
            flightStatus = FlightStatusType.LANDED
        ),
        SimulationScenarioStep(
            stepIndex = 20,
            titleJa = "20. 旅の記録 & マイル積算",
            titleEn = "20. Memory & Miles Earned",
            descriptionJa = "JL041便フライト完了。+11,250マイル＆LSP積算完了。お疲れ様でした。",
            descriptionEn = "Trip archived. +11,250 Miles & Life Status Points credited. Welcome to London!",
            stage = JourneyStage.POST_TRIP_MEMORY,
            flightStatus = FlightStatusType.LANDED
        )
    )

    private val _currentStepIndex = MutableStateFlow(2) // Default step 2: Upcoming flight
    val currentStepIndex: StateFlow<Int> = _currentStepIndex.asStateFlow()

    fun setStep(step: Int) {
        if (step in 1..20) {
            _currentStepIndex.value = step
        }
    }

    fun nextStep() {
        if (_currentStepIndex.value < 20) {
            _currentStepIndex.value++
        }
    }

    fun previousStep() {
        if (_currentStepIndex.value > 1) {
            _currentStepIndex.value--
        }
    }

    fun getCurrentStep(): SimulationScenarioStep {
        return stepsList.find { it.stepIndex == _currentStepIndex.value } ?: stepsList[1]
    }
}
