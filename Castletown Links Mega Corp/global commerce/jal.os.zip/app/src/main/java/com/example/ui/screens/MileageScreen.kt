package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardMembership
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.models.MileageAccountModel
import com.example.i18n.Language
import com.example.ui.theme.*

@Composable
fun MileageScreen(
    mileage: MileageAccountModel,
    language: Language
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
        modifier = Modifier
            .fillMaxSize()
            .testTag("mileage_screen")
    ) {
        // JAL Mileage Bank Header Card
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = CharcoalBlack),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("mileage_account_card")
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "JAL MILEAGE BANK",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 1.5.sp
                                ),
                                color = StatusGold
                            )
                            Text(
                                text = "JMB Member: ${mileage.jmbNumber}",
                                style = MaterialTheme.typography.labelSmall,
                                color = PureWhite.copy(alpha = 0.7f)
                            )
                        }

                        Surface(
                            color = StatusGold,
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = mileage.currentTier,
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = CharcoalBlack,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Text(
                        text = "84,250",
                        style = MaterialTheme.typography.displayLarge.copy(fontWeight = FontWeight.Black),
                        color = PureWhite
                    )
                    Text(
                        text = "TOTAL MILES (有効マイル数)",
                        style = MaterialTheme.typography.labelMedium,
                        color = PureWhite.copy(alpha = 0.8f)
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    Divider(color = SoftCharcoal, thickness = 1.dp)

                    Spacer(modifier = Modifier.height(14.dp))

                    // Life Status Points Progress
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Life Status Points (LSP)", style = MaterialTheme.typography.labelSmall, color = PureWhite.copy(alpha = 0.7f))
                            Text("24,800 LSP", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = StatusGold)
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text("Next Status", style = MaterialTheme.typography.labelSmall, color = PureWhite.copy(alpha = 0.7f))
                            Text(mileage.nextTier, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = PureWhite)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    LinearProgressIndicator(
                        progress = { mileage.progressFraction },
                        color = StatusGold,
                        trackColor = SoftCharcoal,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                    )
                }
            }
        }

        // Tier Benefits List
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderGray, RoundedCornerShape(12.dp))
                    .padding(16.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "JGC SAPPHIRE 会員特典",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = CharcoalBlack
                    )

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Star, contentDescription = "Benefit", tint = StatusGold, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("サクララウンジ・同行者1名無料利用", style = MaterialTheme.typography.bodyMedium)
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Star, contentDescription = "Benefit", tint = StatusGold, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("専用チェックインカウンター・優先保安検査場", style = MaterialTheme.typography.bodyMedium)
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Star, contentDescription = "Benefit", tint = StatusGold, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("優先搭乗 (Group 2) & 手荷物優先受取り", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}
