package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.JalDatabase
import com.example.data.JalRepository
import com.example.domain.models.*
import com.example.i18n.Language
import com.example.simulation.JalSimulationEngine
import com.example.simulation.SimulationScenarioStep
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class FlightSearchQuery(
    val origin: String = "HND (Tokyo Haneda)",
    val destination: String = "LHR (London Heathrow)",
    val departureDate: String = "2026-09-22",
    val returnDate: String = "2026-09-29",
    val passengers: Int = 1,
    val cabin: SeatCabinClass = SeatCabinClass.BUSINESS
)

enum class BookingStep { SEARCH, FLIGHT_LIST, PASSENGER_DETAILS, SEAT_MAP, CONFIRMATION }

class JalViewModel(application: Application) : AndroidViewModel(application) {

    private val db = JalDatabase.getDatabase(application)
    private val repository = JalRepository(db.jalDao())
    val simulationEngine = JalSimulationEngine()

    // Active Language
    private val _language = MutableStateFlow(Language.JA)
    val language: StateFlow<Language> = _language.asStateFlow()

    // Simulation Step
    val currentStepIndex: StateFlow<Int> = simulationEngine.currentStepIndex

    private val _currentStep = MutableStateFlow(simulationEngine.getCurrentStep())
    val currentStep: StateFlow<SimulationScenarioStep> = _currentStep.asStateFlow()

    // Active Tab Navigation
    private val _activeTab = MutableStateFlow("home")
    val activeTab: StateFlow<String> = _activeTab.asStateFlow()

    // Active Flight State
    private val _activeFlight = MutableStateFlow(FlightInfo())
    val activeFlight: StateFlow<FlightInfo> = _activeFlight.asStateFlow()

    // Boarding Pass State
    private val _boardingPass = MutableStateFlow(BoardingPassModel())
    val boardingPass: StateFlow<BoardingPassModel> = _boardingPass.asStateFlow()

    // Mileage State
    private val _mileageAccount = MutableStateFlow(MileageAccountModel())
    val mileageAccount: StateFlow<MileageAccountModel> = _mileageAccount.asStateFlow()

    // Wi-Fi Session
    private val _wifiState = MutableStateFlow(InflightWiFiState())
    val wifiState: StateFlow<InflightWiFiState> = _wifiState.asStateFlow()

    // Seat Selection Map
    private val _seatsList = MutableStateFlow(generateBoeing787Seats())
    val seatsList: StateFlow<List<AircraftSeat>> = _seatsList.asStateFlow()

    private val _selectedSeatId = MutableStateFlow("4A")
    val selectedSeatId: StateFlow<String> = _selectedSeatId.asStateFlow()

    // Flight Search & Booking Flow
    private val _searchQuery = MutableStateFlow(FlightSearchQuery())
    val searchQuery: StateFlow<FlightSearchQuery> = _searchQuery.asStateFlow()

    private val _bookingStep = MutableStateFlow(BookingStep.SEARCH)
    val bookingStep: StateFlow<BookingStep> = _bookingStep.asStateFlow()

    private val _selectedBookingFlight = MutableStateFlow<FlightInfo?>(null)
    val selectedBookingFlight: StateFlow<FlightInfo?> = _selectedBookingFlight.asStateFlow()

    // Offline / Network Status Mode
    private val _isOfflineMode = MutableStateFlow(false)
    val isOfflineMode: StateFlow<Boolean> = _isOfflineMode.asStateFlow()

    init {
        viewModelScope.launch {
            simulationEngine.currentStepIndex.collect { stepIdx ->
                val step = simulationEngine.getCurrentStep()
                _currentStep.value = step

                val updatedFlight = _activeFlight.value.copy(
                    status = step.flightStatus,
                    gateNumber = step.gateNumber,
                    previousGate = step.previousGate
                )
                _activeFlight.value = updatedFlight

                _boardingPass.value = _boardingPass.value.copy(
                    gate = step.gateNumber,
                    statusBadge = if (step.stepIndex >= 3) "CHECKED IN ✓" else "NOT CHECKED IN"
                )

                _wifiState.value = _wifiState.value.copy(isConnected = step.wifiConnected)

                // Persist state in Room
                repository.updateSimulationStep(
                    stepIndex = stepIdx,
                    gate = step.gateNumber,
                    status = step.flightStatus.name,
                    prevGate = step.previousGate
                )

                if (step.hasAlert && step.alertMessageJa != null) {
                    repository.addNotification(
                        NotificationMessage(
                            titleJa = "搭乗口変更のお知らせ",
                            titleEn = "Gate Change Notice",
                            bodyJa = step.alertMessageJa,
                            bodyEn = step.alertMessageEn ?: "",
                            timestamp = "14:45",
                            isAlert = true
                        )
                    )
                }
            }
        }
    }

    fun setLanguage(lang: Language) {
        _language.value = lang
    }

    fun setActiveTab(tab: String) {
        _activeTab.value = tab
    }

    fun selectStep(step: Int) {
        simulationEngine.setStep(step)
    }

    fun nextStep() {
        simulationEngine.nextStep()
    }

    fun previousStep() {
        simulationEngine.previousStep()
    }

    fun toggleOfflineMode() {
        _isOfflineMode.value = !_isOfflineMode.value
    }

    fun connectWiFi() {
        _wifiState.value = _wifiState.value.copy(
            isConnected = true,
            ipAddress = "10.24.188.42"
        )
    }

    fun selectSeat(seatId: String) {
        _selectedSeatId.value = seatId
        _seatsList.value = _seatsList.value.map { seat ->
            if (seat.id == seatId) {
                seat.copy(status = SeatStatus.SELECTED)
            } else if (seat.status == SeatStatus.SELECTED) {
                seat.copy(status = SeatStatus.AVAILABLE)
            } else {
                seat
            }
        }
        _boardingPass.value = _boardingPass.value.copy(seat = seatId)
        _activeFlight.value = _activeFlight.value.copy(seatNumber = seatId)
    }

    fun updateSearchQuery(query: FlightSearchQuery) {
        _searchQuery.value = query
    }

    fun startBookingFlow() {
        _bookingStep.value = BookingStep.FLIGHT_LIST
    }

    fun selectFlightForBooking(flight: FlightInfo) {
        _selectedBookingFlight.value = flight
        _bookingStep.value = BookingStep.PASSENGER_DETAILS
    }

    fun proceedToSeatSelection() {
        _bookingStep.value = BookingStep.SEAT_MAP
    }

    fun confirmBooking() {
        _bookingStep.value = BookingStep.CONFIRMATION
    }

    fun resetBookingFlow() {
        _bookingStep.value = BookingStep.SEARCH
        _selectedBookingFlight.value = null
    }

    private fun generateBoeing787Seats(): List<AircraftSeat> {
        val seats = mutableListOf<AircraftSeat>()
        // Business Class (1-2-1 layout, rows 1-8)
        for (r in 1..8) {
            val cols = listOf("A", "D", "G", "K")
            cols.forEach { col ->
                val seatId = "$r$col"
                val type = if (col == "A" || col == "K") SeatType.WINDOW else SeatType.AISLE
                val status = if (seatId == "4A") SeatStatus.SELECTED else if (r == 2 || r == 5) SeatStatus.OCCUPIED else SeatStatus.AVAILABLE
                seats.add(
                    AircraftSeat(
                        id = seatId,
                        row = r,
                        column = col,
                        cabin = SeatCabinClass.BUSINESS,
                        type = type,
                        status = status
                    )
                )
            }
        }
        // Premium Economy (2-3-2 layout, rows 17-21)
        for (r in 17..21) {
            val cols = listOf("A", "C", "D", "E", "G", "H", "K")
            cols.forEach { col ->
                val seatId = "$r$col"
                val type = if (col == "A" || col == "K") SeatType.WINDOW else if (col == "C" || col == "D" || col == "G" || col == "H") SeatType.AISLE else SeatType.MIDDLE
                seats.add(
                    AircraftSeat(
                        id = seatId,
                        row = r,
                        column = col,
                        cabin = SeatCabinClass.PREMIUM_ECONOMY,
                        type = type,
                        status = if (r % 2 == 0) SeatStatus.OCCUPIED else SeatStatus.AVAILABLE
                    )
                )
            }
        }
        return seats
    }
}
