package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface JalDao {
    @Query("SELECT * FROM bookings WHERE pnr = :pnr LIMIT 1")
    fun getBookingByPnr(pnr: String): Flow<BookingEntity?>

    @Query("SELECT * FROM bookings ORDER BY pnr DESC")
    fun getAllBookings(): Flow<List<BookingEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateBooking(booking: BookingEntity)

    @Query("SELECT * FROM notifications ORDER BY timestamp DESC")
    fun getAllNotifications(): Flow<List<NotificationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationEntity)

    @Query("SELECT * FROM simulation_state WHERE id = 1 LIMIT 1")
    fun getSimulationState(): Flow<SimulationStateEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveSimulationState(state: SimulationStateEntity)
}
