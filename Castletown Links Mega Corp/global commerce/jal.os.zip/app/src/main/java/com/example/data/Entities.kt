package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "bookings")
data class BookingEntity(
    @PrimaryKey val pnr: String,
    val flightNumber: String,
    val passengerName: String,
    val originCode: String,
    val destinationCode: String,
    val departureTime: String,
    val arrivalTime: String,
    val dateString: String,
    val seatNumber: String,
    val gateNumber: String,
    val boardingGroup: String,
    val cabinClass: String,
    val journeyStageName: String,
    val isCheckedIn: Boolean
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey val id: String,
    val titleJa: String,
    val titleEn: String,
    val bodyJa: String,
    val bodyEn: String,
    val timestamp: String,
    val isAlert: Boolean,
    val isRead: Boolean
)

@Entity(tableName = "simulation_state")
data class SimulationStateEntity(
    @PrimaryKey val id: Int = 1,
    val stepIndex: Int,
    val currentGate: String,
    val previousGate: String?,
    val flightStatus: String,
    val wifiConnected: Boolean,
    val lastUpdatedTimestamp: Long
)
