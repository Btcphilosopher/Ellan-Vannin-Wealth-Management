package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.i18n.Language
import com.example.simulation.JalSimulationEngine
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SimulationControllerSheet(
    engine: JalSimulationEngine,
    currentStepIndex: Int,
    onSelectStep: (Int) -> Unit,
    onDismiss: () -> Unit,
    language: Language
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        scrimColor = CharcoalBlack.copy(alpha = 0.5f)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "JAL.OS シナリオシミュレーター",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = JalRed
                    )
                    Text(
                        text = "Flagship Demo: JL041 Tokyo Haneda → London Heathrow (20 Steps)",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted
                    )
                }

                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = CharcoalBlack)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Navigation Step Buttons (Previous / Next)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        if (currentStepIndex > 1) onSelectStep(currentStepIndex - 1)
                    },
                    enabled = currentStepIndex > 1,
                    modifier = Modifier.weight(1f).height(44.dp)
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Prev", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("前ステップ")
                }

                Button(
                    onClick = {
                        if (currentStepIndex < 20) onSelectStep(currentStepIndex + 1)
                    },
                    enabled = currentStepIndex < 20,
                    colors = ButtonDefaults.buttonColors(containerColor = JalRed),
                    modifier = Modifier.weight(1f).height(44.dp)
                ) {
                    Text("次ステップ")
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(Icons.Default.ArrowForward, contentDescription = "Next", modifier = Modifier.size(16.dp))
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "全20ステップから直接選択:",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = CharcoalBlack
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Scrollable List of 20 Flagship Demo Steps
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 360.dp)
            ) {
                items(engine.stepsList) { step ->
                    val isSelected = step.stepIndex == currentStepIndex

                    Surface(
                        onClick = { onSelectStep(step.stepIndex) },
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSelected) JalRedLight else AirportSilver,
                        border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, JalRed) else null,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (isSelected) {
                                Icon(Icons.Default.CheckCircle, contentDescription = "Active", tint = JalRed, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                            }

                            Column {
                                Text(
                                    text = if (language == Language.JA) step.titleJa else step.titleEn,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                    ),
                                    color = if (isSelected) JalRed else CharcoalBlack
                                )
                                Text(
                                    text = if (language == Language.JA) step.descriptionJa else step.descriptionEn,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextMuted
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
