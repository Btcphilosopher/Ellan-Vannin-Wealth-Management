package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [BookingEntity::class, NotificationEntity::class, SimulationStateEntity::class],
    version = 1,
    exportSchema = false
)
abstract class JalDatabase : RoomDatabase() {
    abstract fun jalDao(): JalDao

    companion object {
        @Volatile
        private var INSTANCE: JalDatabase? = null

        fun getDatabase(context: Context): JalDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    JalDatabase::class.java,
                    "jal_os_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
