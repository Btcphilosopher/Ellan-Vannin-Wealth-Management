package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.models.*
import com.example.i18n.Language
import com.example.ui.BookingStep
import com.example.ui.FlightSearchQuery
import com.example.ui.components.FlightResultCard
import com.example.ui.theme.*

val mockFlightResults = listOf(
    FlightInfo(
        flightNumber = "JL041",
        originCode = "HND",
        destinationCode = "LHR",
        departureTime = "15:55",
        arrivalTime = "06:55",
        aircraftModel = "Boeing 787-9",
        cabinClass = "JAL SKY SUITE (Business)",
        durationText = "14h 00m"
    ),
    FlightInfo(
        flightNumber = "JL043",
        originCode = "HND",
        destinationCode = "LHR",
        departureTime = "09:55",
        arrivalTime = "16:25",
        aircraftModel = "Airbus A350-1000",
        cabinClass = "JAL First Class Suite",
        durationText = "14h 30m"
    ),
    FlightInfo(
        flightNumber = "JL005",
        originCode = "HND",
        destinationCode = "JFK",
        departureTime = "11:05",
        arrivalTime = "11:00",
        aircraftModel = "Airbus A350-1000",
        cabinClass = "JAL SKY PREMIUM",
        durationText = "12h 55m"
    )
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookFlightScreen(
    searchQuery: FlightSearchQuery,
    onUpdateQuery: (FlightSearchQuery) -> Unit,
    bookingStep: BookingStep,
    onStartSearch: () -> Unit,
    onSelectFlight: (FlightInfo) -> Unit,
    seatsList: List<AircraftSeat>,
    selectedSeatId: String,
    onSelectSeat: (String) -> Unit,
    onConfirmBooking: () -> Unit,
    onResetBooking: () -> Unit,
    language: Language
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier
            .fillMaxSize()
            .testTag("book_flight_screen")
    ) {
        // Step Indicator Wizard Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = when (bookingStep) {
                        BookingStep.SEARCH -> "1/4 航空券検索"
                        BookingStep.FLIGHT_LIST -> "2/4 フライト＆運賃選択"
                        BookingStep.PASSENGER_DETAILS -> "3/4 搭乗者情報入力"
                        BookingStep.SEAT_MAP -> "4/4 座席選択 (B787-9)"
                        BookingStep.CONFIRMATION -> "予約完了 (PNR JAL-2026)"
                    },
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = JalRed
                )

                if (bookingStep != BookingStep.SEARCH) {
                    TextButton(onClick = onResetBooking) {
                        Text("最初からやり直す", color = TextMuted)
                    }
                }
            }
        }

        when (bookingStep) {
            BookingStep.SEARCH -> {
                item {
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.border(1.dp, BorderGray, RoundedCornerShape(12.dp))
                    ) {
                        Column(modifier = Modifier.padding(18.dp)) {
                            Text("FROM (出発地)", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                            OutlinedTextField(
                                value = searchQuery.origin,
                                onValueChange = { onUpdateQuery(searchQuery.copy(origin = it)) },
                                modifier = Modifier.fillMaxWidth().testTag("search_origin_input")
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Text("TO (目的地)", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                            OutlinedTextField(
                                value = searchQuery.destination,
                                onValueChange = { onUpdateQuery(searchQuery.copy(destination = it)) },
                                modifier = Modifier.fillMaxWidth().testTag("search_destination_input")
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("DEPARTURE", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                    OutlinedTextField(value = searchQuery.departureDate, onValueChange = {}, readOnly = true)
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("RETURN", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                    OutlinedTextField(value = searchQuery.returnDate, onValueChange = {}, readOnly = true)
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Button(
                                onClick = onStartSearch,
                                colors = ButtonDefaults.buttonColors(containerColor = JalRed),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("submit_flight_search_btn")
                            ) {
                                Icon(Icons.Default.Search, contentDescription = "Search", tint = PureWhite)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("空席照会・フライト検索", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                            }
                        }
                    }
                }
            }

            BookingStep.FLIGHT_LIST -> {
                items(mockFlightResults) { flight ->
                    FlightResultCard(flight = flight, onSelectFlight = onSelectFlight)
                }
            }

            BookingStep.PASSENGER_DETAILS -> {
                item {
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.border(1.dp, BorderGray, RoundedCornerShape(12.dp))
                    ) {
                        Column(modifier = Modifier.padding(18.dp)) {
                            Text("搭乗者プロファイル (JMB連携)", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("Name: Tom Miller (MR)", style = MaterialTheme.typography.bodyMedium)
                            Text("Passport: GB987654321", style = MaterialTheme.typography.bodyMedium)
                            Text("JMB Number: JMB 84920129 (JGC Sapphire)", style = MaterialTheme.typography.bodyMedium)
                            Text("Meal Preference: Japanese Kaiseki Course (和食)", style = MaterialTheme.typography.bodyMedium)

                            Spacer(modifier = Modifier.height(18.dp))

                            Button(
                                onClick = { onSelectFlight(mockFlightResults[0]) },
                                colors = ButtonDefaults.buttonColors(containerColor = JalRed),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth().height(48.dp)
                            ) {
                                Text("座席選択へ進む (Boeing 787-9)", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                            }
                        }
                    }
                }
            }

            BookingStep.SEAT_MAP -> {
                item {
                    Text("BOEING 787-9 JAL SKY SUITE (1-2-1 Business Class)", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("選択済み座席: $selectedSeatId (窓側 4A)", style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold), color = JalRed)
                }

                // Interactive Aircraft Seat Grid
                item {
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, BorderGray, RoundedCornerShape(12.dp))
                            .padding(12.dp)
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("▲ COCKPIT / AIRCRAFT NOSE ▲", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                            Spacer(modifier = Modifier.height(12.dp))

                            val businessSeats = seatsList.filter { it.cabin == SeatCabinClass.BUSINESS }
                            val rows = businessSeats.map { it.row }.distinct()

                            rows.forEach { rowNum ->
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceEvenly,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    val rowSeats = businessSeats.filter { it.row == rowNum }
                                    rowSeats.forEach { seat ->
                                        val isSelected = seat.id == selectedSeatId
                                        val isOccupied = seat.status == SeatStatus.OCCUPIED

                                        Surface(
                                            onClick = { if (!isOccupied) onSelectSeat(seat.id) },
                                            enabled = !isOccupied,
                                            shape = RoundedCornerShape(6.dp),
                                            color = if (isSelected) JalRed else if (isOccupied) AirportSilver else PureWhite,
                                            border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) JalRed else BorderGray),
                                            modifier = Modifier.size(44.dp).testTag("seat_btn_${seat.id}")
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Text(
                                                    text = seat.id,
                                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                                    color = if (isSelected) PureWhite else if (isOccupied) TextMuted else CharcoalBlack
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Button(
                                onClick = onConfirmBooking,
                                colors = ButtonDefaults.buttonColors(containerColor = JalRed),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth().height(48.dp).testTag("confirm_booking_btn")
                            ) {
                                Text("予約確定・搭乗券発行", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                            }
                        }
                    }
                }
            }

            BookingStep.CONFIRMATION -> {
                item {
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.border(1.dp, StatusEmerald, RoundedCornerShape(12.dp))
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = "Success", tint = StatusEmerald, modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("ご予約が完了いたしました", style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold), color = StatusEmerald)
                            Text("予約番号 (PNR): JAL-JL041-2026", style = MaterialTheme.typography.titleMedium)
                            Text("JL041 羽田 (HND) → ヒースロー (LHR) 座席 $selectedSeatId", style = MaterialTheme.typography.bodyMedium, color = TextMuted)

                            Spacer(modifier = Modifier.height(16.dp))

                            Button(
                                onClick = onResetBooking,
                                colors = ButtonDefaults.buttonColors(containerColor = JalRed)
                            ) {
                                Text("ホーム・搭乗券一覧へ戻る")
                            }
                        }
                    }
                }
            }
        }
    }
}
