/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
app.use(express.json());

const PORT = 3000;

// Lazy initialization of GoogleGenAI client
let aiClient: GoogleGenAI | null = null;

function getAiClient(): GoogleGenAI | null {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (key && key !== "MY_GEMINI_API_KEY") {
      aiClient = new GoogleGenAI({
        apiKey: key,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build",
          },
        },
      });
    }
  }
  return aiClient;
}

// 1. Guideline & Safety API
app.get("/api/guidelines", (req, res) => {
  res.json({
    message: "Authoritative Safety Guidelines loaded successfully.",
    jurisdictions: ["UK", "EU", "US", "WHO", "CUSTOM"],
    defaultJurisdiction: "UK"
  });
});

// 2. Synthetic Recalls Database API
app.get("/api/recalls", (req, res) => {
  res.json({
    recalls: [
      {
        recall_id: "RC-2026-001",
        brand: "Synthetic First Infant Milk",
        product_name: "Premium Infant Formula Stage 1",
        affected_batches: ["SYN-2026-001", "SYN-2026-002"],
        published_at: "2026-08-15",
        source: "Synthetic Food Safety Authority",
        description: "Precautionary recall due to potential trace levels of physical contamination in the container sealing system.",
        severity: "CRITICAL"
      },
      {
        recall_id: "RC-2026-002",
        brand: "Organic Baby Grow",
        product_name: "Gentle Formula Stage 2",
        affected_batches: ["ORG-GENTLE-B4", "ORG-GENTLE-B5"],
        published_at: "2026-09-01",
        source: "Synthetic Health & Safety Board",
        description: "Recall on specific batches due to moisture intrusion leading to premature powder clumping and reduction in shelf-life.",
        severity: "WARNING"
      }
    ]
  });
});

// 3. Gemini-powered Formula Assistant Chat Endpoint
app.post("/api/gemini/chat", async (req, res) => {
  const { messages, selectedFormula, jurisdiction } = req.body;

  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: "Invalid messages payload." });
  }

  // Define safety-critical constraints for the AI response
  const systemInstruction = `You are the 'Formula Assistant' for the 'Baby Formula OS' platform. 
Your purpose is to answer caregiver questions about infant formula preparation, safety rules, temperatures, bottle sterilisation, and platform usage.

CRITICAL SAFETY DIRECTIVES:
1. This is NOT a medical device. You must NEVER diagnose illnesses, prescribe formula types, recommend medications, calculate medical dosing, or interpret symptoms.
2. If asked 'how much should my baby drink?' or similar, you MUST NOT manufacture a personalized quantity. Instead, answer: "I can show the preparation instructions for your selected formula or help you record guidance you've received from your healthcare professional."
3. Every safety-related answer must identify its authoritative source, date, and jurisdiction (e.g., UK NHS 2026 Guidelines, WHO 2007, US CDC 2026).
4. Do NOT make up formula reconstitution temperatures. The NHS under UK rules explicitly mandates water must be at least 70°C when powder is added to kill any harmful pathogens (like Cronobacter sakazakii).
5. If jurisdiction and manufacturer instructions conflict, acknowledge the conflict, display instructions/guidelines for both, and advise consulting a healthcare professional or midwife.
6. Currently selected context: 
   - Formula Product in use: ${selectedFormula ? JSON.stringify(selectedFormula) : "None selected yet"}
   - Active Safety Jurisdiction: ${jurisdiction || "UK (NHS Guidance)"}

Maintain a calm, professional, authoritative, and helpful tone. Avoid marketing hype or flowery self-praising words.`;

  try {
    const ai = getAiClient();
    
    // Fallback if API key is missing
    if (!ai) {
      // Simulate an intelligent offline assistant response with safety compliance
      const userMsg = messages[messages.length - 1]?.content || "";
      let simulatedReply = "I am currently running in Offline/Demo mode because no Gemini API Key is configured in AI Studio secrets.";
      
      const lowerMsg = userMsg.toLowerCase();
      if (lowerMsg.includes("how much") || lowerMsg.includes("drink") || lowerMsg.includes("volume")) {
        simulatedReply = "I can show the preparation instructions for your selected formula or help you record guidance you've received from your healthcare professional. As an AI assistant, I do not manufacture drinking targets, as feeding is responsive to your baby's hunger cues.";
      } else if (lowerMsg.includes("temperature") || lowerMsg.includes("hot") || lowerMsg.includes("70")) {
        simulatedReply = "Under UK NHS Guidance (2026), powdered infant formula must be prepared with water that is at least 70°C (cooled for no more than 30 minutes after boiling) when the powder is added. This temperature is necessary to kill any bacteria that might be present in the powdered formula itself. Remember to cool the feed to body temperature (~37°C) before offering it to the infant.";
      } else if (lowerMsg.includes("reboiled") || lowerMsg.includes("water")) {
        simulatedReply = "According to UK NHS guidelines, you should use fresh tap water for every feed. Do not use previously boiled water or artificially softened water, as the mineral balance is unsafe for infant reconstitution.";
      } else if (lowerMsg.includes("steril")) {
        simulatedReply = "Bottles and all preparation equipment must be sterilised before every feed. Common safe methods include steam sterilising, boiling, or cold water chemical sterilising. Under Baby Formula OS, a preparation workflow is blocked if the selected bottle is not marked as 'STERILISED'.";
      } else {
        simulatedReply = `Thank you for your question. As your Formula Assistant (Offline Mode), I want to remind you that the central object in Baby Formula OS is the Feed. We enforce rigorous safety parameters based on ${jurisdiction || "UK NHS"} guidelines. For specific medical queries, please contact your midwife, paediatrician, or health visitor.`;
      }

      return res.json({
        content: simulatedReply,
        isMock: true
      });
    }

    // Format history for Gemini chat API
    // Gemini chat API uses 'user' and 'model' roles. We need to convert incoming message list:
    const formattedContents = messages.map((m: any) => ({
      role: m.role === "assistant" ? "model" : "user",
      parts: [{ text: m.content }]
    }));

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: formattedContents,
      config: {
        systemInstruction,
        temperature: 0.2, // low temperature for precise, safe responses
      }
    });

    const replyText = response.text || "I was unable to formulate a response. Please try again.";

    res.json({
      content: replyText,
      isMock: false
    });
  } catch (error: any) {
    console.error("Gemini Assistant Error:", error);
    res.status(500).json({ error: "Failed to communicate with AI Assistant. " + error.message });
  }
});

// Serve frontend build or handle Dev mode via Vite
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    console.log("Starting server in development mode with Vite...");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    console.log("Starting server in production mode...");
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Baby Formula OS Server running on http://localhost:${PORT}`);
  });
}

startServer();
