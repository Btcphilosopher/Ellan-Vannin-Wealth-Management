/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import {
  Baby,
  Thermometer,
  ShieldCheck,
  History,
  Layers,
  Sparkles,
  Heart,
  Cpu,
  AlertTriangle,
  Play
} from "lucide-react";
import {
  Feed,
  Bottle,
  FormulaContainer,
  FormulaProduct,
  FormulaBatch,
  FeedState,
  BottleState,
  Jurisdiction
} from "./types";
import {
  SYNTHETIC_PRODUCTS,
  SYNTHETIC_BATCHES,
  SYNTHETIC_CONTAINERS,
  SYNTHETIC_BOTTLES,
  SYNTHETIC_FEED_HISTORY
} from "./data";
import { Dashboard } from "./components/Dashboard";
import { PrepareWorkflow } from "./components/PrepareWorkflow";
import { InventoryBottles } from "./components/InventoryBottles";
import { FeedHistory } from "./components/FeedHistory";
import { MasterSimulator } from "./components/MasterSimulator";
import { HealthcareExport } from "./components/HealthcareExport";
import { FormulaAssistant } from "./components/FormulaAssistant";

export default function App() {
  const [activeTab, setActiveTab] = useState<string>("dashboard");

  // Domain states
  const [feeds, setFeeds] = useState<Feed[]>(() => {
    const saved = localStorage.getItem("bfo_feeds");
    return saved ? JSON.parse(saved) : SYNTHETIC_FEED_HISTORY;
  });

  const [bottles, setBottles] = useState<Bottle[]>(() => {
    const saved = localStorage.getItem("bfo_bottles");
    return saved ? JSON.parse(saved) : SYNTHETIC_BOTTLES;
  });

  const [containers, setContainers] = useState<FormulaContainer[]>(() => {
    const saved = localStorage.getItem("bfo_containers");
    return saved ? JSON.parse(saved) : SYNTHETIC_CONTAINERS;
  });

  const [activeFeed, setActiveFeed] = useState<Feed | null>(() => {
    const saved = localStorage.getItem("bfo_active_feed");
    return saved ? JSON.parse(saved) : null;
  });

  // Simulator state: failure injection from digital twin panel
  const [triggerFailure, setTriggerFailure] = useState<string>("NONE");

  // Synced local storage persistence
  useEffect(() => {
    localStorage.setItem("bfo_feeds", JSON.stringify(feeds));
  }, [feeds]);

  useEffect(() => {
    localStorage.setItem("bfo_bottles", JSON.stringify(bottles));
  }, [bottles]);

  useEffect(() => {
    localStorage.setItem("bfo_containers", JSON.stringify(containers));
  }, [containers]);

  useEffect(() => {
    if (activeFeed) {
      localStorage.setItem("bfo_active_feed", JSON.stringify(activeFeed));
    } else {
      localStorage.removeItem("bfo_active_feed");
    }
  }, [activeFeed]);

  const handleSaveFeed = (completedFeed: Feed) => {
    setFeeds((prev) => [...prev, completedFeed]);

    // Handle inventory consumption of powder
    if (completedFeed.state === FeedState.COMPLETED) {
      const scoopsUsed = completedFeed.powder_scoops || 0;
      const gUsed = scoopsUsed * 4.3; // estimated g

      setContainers((prevContainers) =>
        prevContainers.map((c) => {
          if (c.container_id === completedFeed.formula_container_id) {
            return {
              ...c,
              remaining_quantity_g: Math.max(0, c.remaining_quantity_g - gUsed)
            };
          }
          return c;
        })
      );

      // Handle bottle sterility decay
      setBottles((prevBottles) =>
        prevBottles.map((b) => {
          if (b.bottle_id === completedFeed.bottle_id) {
            return {
              ...b,
              sterility_state: BottleState.DIRTY,
              usage_count: b.usage_count + 1
            };
          }
          return b;
        })
      );
    }
  };

  const handleResetApp = () => {
    if (window.confirm("Are you sure you want to restore default synthetic data?")) {
      localStorage.removeItem("bfo_feeds");
      localStorage.removeItem("bfo_bottles");
      localStorage.removeItem("bfo_containers");
      localStorage.removeItem("bfo_active_feed");
      setFeeds(SYNTHETIC_FEED_HISTORY);
      setBottles(SYNTHETIC_BOTTLES);
      setContainers(SYNTHETIC_CONTAINERS);
      setActiveFeed(null);
      setTriggerFailure("NONE");
      setActiveTab("dashboard");
    }
  };

  return (
    <div className="min-h-screen bg-neutral-50/30 text-neutral-800 font-sans flex flex-col antialiased">
      {/* 1. Master System Navigation Top Bar */}
      <header className="sticky top-0 z-40 bg-white border-b border-neutral-200/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="bg-neutral-900 text-white p-2 rounded-lg flex items-center justify-center">
              <Baby className="h-5 w-5" />
            </div>
            <div>
              <span className="text-xs font-bold text-neutral-400 uppercase tracking-widest block">Operational System</span>
              <h1 className="text-sm font-bold tracking-tight text-neutral-900">BABY FORMULA OS</h1>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={handleResetApp}
              className="text-[10px] font-bold text-neutral-400 hover:text-neutral-900 border border-neutral-200/60 hover:border-neutral-400 px-2.5 py-1.5 rounded transition"
            >
              Restore Defaults
            </button>
          </div>
        </div>
      </header>

      {/* 2. Main content viewport grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-1 w-full flex flex-col md:flex-row gap-8">
        {/* Left column navigation sidebar */}
        <aside className="md:w-60 shrink-0">
          <nav className="sticky top-24 space-y-1">
            <button
              onClick={() => setActiveTab("dashboard")}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-bold transition text-left ${
                activeTab === "dashboard"
                  ? "bg-neutral-900 text-white"
                  : "text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100"
              }`}
            >
              <Cpu className="h-4 w-4" />
              <span>Operational Dashboard</span>
            </button>

            <button
              onClick={() => setActiveTab("prepare")}
              className={`w-full flex items-center justify-between px-4 py-3 rounded-xl text-xs font-bold transition text-left ${
                activeTab === "prepare"
                  ? "bg-neutral-900 text-white"
                  : "text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100"
              }`}
            >
              <div className="flex items-center gap-3">
                <Thermometer className="h-4 w-4" />
                <span>Guided Preparation</span>
              </div>
              {activeFeed && (
                <span className="h-2 w-2 rounded-full bg-amber-500 animate-pulse"></span>
              )}
            </button>

            <button
              onClick={() => setActiveTab("inventory")}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-bold transition text-left ${
                activeTab === "inventory"
                  ? "bg-neutral-900 text-white"
                  : "text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100"
              }`}
            >
              <Layers className="h-4 w-4" />
              <span>Bottles & Canisters</span>
            </button>

            <button
              onClick={() => setActiveTab("history")}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-bold transition text-left ${
                activeTab === "history"
                  ? "bg-neutral-900 text-white"
                  : "text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100"
              }`}
            >
              <History className="h-4 w-4" />
              <span>Traceability Log</span>
            </button>

            <button
              onClick={() => setActiveTab("healthcare")}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-bold transition text-left ${
                activeTab === "healthcare"
                  ? "bg-neutral-900 text-white"
                  : "text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100"
              }`}
            >
              <Heart className="h-4 w-4" />
              <span>Clinical Reporting</span>
            </button>

            <button
              onClick={() => setActiveTab("assistant")}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-bold transition text-left ${
                activeTab === "assistant"
                  ? "bg-neutral-900 text-white"
                  : "text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100"
              }`}
            >
              <Sparkles className="h-4 w-4" />
              <span>AI Formula Assistant</span>
            </button>

            <button
              onClick={() => setActiveTab("simulator")}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-bold transition text-left ${
                activeTab === "simulator"
                  ? "bg-neutral-900 text-white"
                  : "text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100"
              }`}
            >
              <Cpu className="h-4 w-4" />
              <span>Twin Failure Simulator</span>
            </button>
          </nav>

          {/* Sticky active hazard indicator on sidebar if failure mode active */}
          {triggerFailure !== "NONE" && (
            <div className="mt-8 bg-red-50 border border-red-200 p-4 rounded-xl space-y-2">
              <div className="flex items-center gap-1.5 text-xs font-bold text-red-900">
                <AlertTriangle className="h-4 w-4 text-red-600 animate-bounce" />
                <span>Hazard Injected</span>
              </div>
              <p className="text-[10px] text-red-700 leading-normal font-semibold">
                Active Simulator Toggle: **{triggerFailure}**. Review Guided Preparation workflow constraints.
              </p>
            </div>
          )}
        </aside>

        {/* Right column main view */}
        <main className="flex-1 min-w-0 bg-white border border-neutral-200/60 rounded-3xl p-6 md:p-8 shadow-xs">
          {activeTab === "dashboard" && (
            <Dashboard
              feeds={feeds}
              bottles={bottles}
              containers={containers}
              activeFeed={activeFeed}
              onNavigate={(tab) => setActiveTab(tab)}
              onResumeFeed={() => setActiveTab("prepare")}
            />
          )}

          {activeTab === "prepare" && (
            <PrepareWorkflow
              products={SYNTHETIC_PRODUCTS}
              bottles={bottles}
              activeFeed={activeFeed}
              onSaveFeed={handleSaveFeed}
              onUpdateActiveFeed={setActiveFeed}
              triggerFailure={triggerFailure}
            />
          )}

          {activeTab === "inventory" && (
            <InventoryBottles
              bottles={bottles}
              containers={containers}
              products={SYNTHETIC_PRODUCTS}
              batches={SYNTHETIC_BATCHES}
              onUpdateBottles={setBottles}
              onUpdateContainers={setContainers}
            />
          )}

          {activeTab === "history" && (
            <FeedHistory feeds={feeds} onUpdateFeeds={setFeeds} />
          )}

          {activeTab === "healthcare" && <HealthcareExport feeds={feeds} />}

          {activeTab === "assistant" && (
            <FormulaAssistant
              selectedProduct={SYNTHETIC_PRODUCTS[0]}
              jurisdiction="UK"
            />
          )}

          {activeTab === "simulator" && (
            <MasterSimulator
              triggerFailure={triggerFailure}
              setTriggerFailure={setTriggerFailure}
              onNavigate={(tab) => setActiveTab(tab)}
            />
          )}
        </main>
      </div>

      {/* 3. Footer disclaimer */}
      <footer className="bg-white border-t border-neutral-200 mt-auto py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-[10px] text-neutral-400 font-bold tracking-widest text-center md:text-left uppercase">
            BABY FORMULA OS • PRECISE PREPARATION. CLEAR RECORDS. SAFER FEEDING.
          </p>
          <p className="text-[10px] text-neutral-400 font-semibold max-w-md text-center md:text-right leading-normal">
            This is NOT a medical device. This is NOT a substitute for a pediatrician, midwife, health visitor, pharmacist, dietitian or formula manufacturer's instructions.
          </p>
        </div>
      </footer>
    </div>
  );
}
