/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from "react";
import {
  Sparkles,
  Send,
  User,
  ShieldAlert,
  BookOpen,
  RefreshCw,
  Info
} from "lucide-react";
import { FormulaProduct } from "../types";

interface Message {
  role: "user" | "assistant";
  content: string;
}

interface FormulaAssistantProps {
  selectedProduct: FormulaProduct | null;
  jurisdiction: string;
}

export const FormulaAssistant: React.FC<FormulaAssistantProps> = ({
  selectedProduct,
  jurisdiction
}) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: "Hello! I am your Formula Assistant. I can help answer questions about infant formula preparation guidelines, water temperatures, sterilization, or specific formula packaging details. What would you like to discuss?"
    }
  ]);
  const [input, setInput] = useState<string>("");
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = async (customText?: string) => {
    const textToSend = customText || input;
    if (!textToSend.trim() || isLoading) return;

    if (!customText) setInput("");

    const updatedMessages = [...messages, { role: "user" as const, content: textToSend }];
    setMessages(updatedMessages);
    setIsLoading(true);

    try {
      const response = await fetch("/api/gemini/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: updatedMessages,
          selectedFormula: selectedProduct,
          jurisdiction
        })
      });

      if (!response.ok) {
        throw new Error("Failed to contact backend API server.");
      }

      const data = await response.json();
      setMessages((prev) => [...prev, { role: "assistant", content: data.content }]);
    } catch (err: any) {
      console.error(err);
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: "I experienced a network disruption connecting to the server. Please verify your internet connection or check the Gemini API Key configuration in AI Studio."
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const quickQuestions = [
    { label: "Why is 70°C water mandatory?", q: "Explain why reconstituting infant formula powder requires water at least 70°C, and cite guidelines." },
    { label: "Can I use reboiled water?", q: "Is it safe to use water that has been reboiled or boiled multiple times for formula feeds?" },
    { label: "How long can prepared feeds be stored?", q: "What are the storage time limits for prepared formula in the fridge vs room temperature under NHS/WHO rules?" },
    { label: "How much formula should my baby drink?", q: "How much formula should my baby drink today? Give me personalized recommendations." }
  ];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 h-[calc(100vh-220px)] min-h-[500px]" id="assistant-tab">
      {/* LEFT: Prompt Helpers & Clinical Guardrail rules */}
      <div className="space-y-6 lg:col-span-1">
        <div className="bg-neutral-50 border border-neutral-200 rounded-2xl p-5 space-y-6">
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-400">Clinical Safety Grounding</h3>
            <p className="text-xs text-neutral-500 mt-1">
              To guarantee extreme food-safety compliance, this AI operates under rigorous real-world boundaries.
            </p>
          </div>

          <div className="space-y-4 text-xs text-neutral-600">
            <div className="flex items-start gap-2.5">
              <ShieldAlert className="h-4 w-4 text-neutral-500 shrink-0 mt-0.5" />
              <p>
                <strong>No Diagnostics</strong>: AI will never diagnose physical illnesses or prescribe custom liquid quantities.
              </p>
            </div>
            <div className="flex items-start gap-2.5">
              <BookOpen className="h-4 w-4 text-neutral-500 shrink-0 mt-0.5" />
              <p>
                <strong>Citations Required</strong>: Every safety-critical answer is mapped to WHO, US CDC, or UK NHS standards.
              </p>
            </div>
          </div>

          <div className="border-t border-neutral-200 pt-4">
            <span className="text-[10px] font-bold uppercase text-neutral-400">Quick Safety Prompts</span>
            <div className="flex flex-col gap-2 mt-2">
              {quickQuestions.map((q) => (
                <button
                  key={q.label}
                  disabled={isLoading}
                  onClick={() => handleSendMessage(q.q)}
                  className="w-full text-left bg-white hover:bg-neutral-100 border border-neutral-200 text-neutral-700 font-semibold p-2.5 rounded-lg text-xs leading-normal transition"
                >
                  {q.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* CENTER & RIGHT: Chat log & send container */}
      <div className="lg:col-span-2 bg-white border border-neutral-200 rounded-2xl flex flex-col justify-between overflow-hidden shadow-xs">
        {/* Chat Logs Window */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4 max-h-[400px]">
          {messages.map((m, idx) => {
            const isUser = m.role === "user";
            return (
              <div key={idx} className={`flex gap-3 max-w-xl ${isUser ? "ml-auto flex-row-reverse" : "mr-auto"}`}>
                <div className={`p-2 rounded-lg shrink-0 h-8 w-8 flex items-center justify-center text-xs font-bold ${isUser ? "bg-neutral-900 text-white" : "bg-neutral-100 text-neutral-800"}`}>
                  {isUser ? <User className="h-4 w-4" /> : <Sparkles className="h-4 w-4" />}
                </div>
                <div className={`p-3.5 rounded-2xl text-xs leading-relaxed ${isUser ? "bg-neutral-950 text-white rounded-tr-none" : "bg-neutral-50 text-neutral-800 border border-neutral-150 rounded-tl-none"}`}>
                  <p className="whitespace-pre-line">{m.content}</p>
                </div>
              </div>
            );
          })}
          {isLoading && (
            <div className="flex gap-3 mr-auto items-center text-xs text-neutral-500">
              <div className="bg-neutral-100 p-2 rounded-lg animate-spin text-neutral-800">
                <RefreshCw className="h-4 w-4" />
              </div>
              <span>Formulating safety grounded response...</span>
            </div>
          )}
          <div ref={chatEndRef} />
        </div>

        {/* Input box */}
        <div className="border-t border-neutral-100 p-4 bg-neutral-50/50 flex items-center gap-3">
          <input
            type="text"
            placeholder="Ask about water temperature, reboiled water, clean containers, or NHS rules..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") handleSendMessage();
            }}
            disabled={isLoading}
            className="flex-1 bg-white border border-neutral-200 text-xs rounded-xl p-3 focus:outline-none focus:border-neutral-900"
          />
          <button
            onClick={() => handleSendMessage()}
            disabled={isLoading || !input.trim()}
            className="bg-neutral-950 hover:bg-neutral-800 disabled:opacity-40 text-white p-3 rounded-xl transition shadow shrink-0"
          >
            <Send className="h-4 w-4 fill-current" />
          </button>
        </div>
      </div>
    </div>
  );
};
