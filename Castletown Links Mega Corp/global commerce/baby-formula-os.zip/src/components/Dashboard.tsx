/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import {
  Baby,
  Thermometer,
  ShieldCheck,
  AlertTriangle,
  Flame,
  Calendar,
  Layers,
  ArrowRight,
  TrendingUp,
  Droplet
} from "lucide-react";
import { Feed, Bottle, FormulaContainer, BottleState, FeedState } from "../types";

interface DashboardProps {
  feeds: Feed[];
  bottles: Bottle[];
  containers: FormulaContainer[];
  activeFeed: Feed | null;
  onNavigate: (tab: string) => void;
  onResumeFeed: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  feeds,
  bottles,
  containers,
  activeFeed,
  onNavigate,
  onResumeFeed
}) => {
  // Calculations
  const feedsToday = feeds.filter((f) => {
    const todayStr = new Date().toISOString().split("T")[0];
    const feedStr = new Date(f.preparation_started_at).toISOString().split("T")[0];
    return feedStr === todayStr && f.state === FeedState.COMPLETED;
  });

  const totalPreparedToday = feedsToday.reduce((sum, f) => sum + (f.feed_volume_ml || 0), 0);
  const totalConsumedToday = feedsToday.reduce((sum, f) => sum + (f.volume_consumed || 0), 0);

  // Sterile bottles
  const sterilisedBottles = bottles.filter((b) => b.sterility_state === BottleState.STERILISED);

  // Low stock prediction
  const totalFormulaLeft = containers.reduce((sum, c) => sum + (c.is_opened ? c.remaining_quantity_g : 0), 0);
  // Estimate consumption rate: assuming average feed size 120ml and 15g powder per feed, approx 90g per day.
  const estimatedDaysLeft = totalFormulaLeft > 0 ? Math.ceil(totalFormulaLeft / 90) : 0;

  // Recalled matches
  const hasRecallWarning = containers.some(c => c.batch_id === "SYN-2026-RECALL" && !c.is_opened);

  return (
    <div className="space-y-8" id="dashboard-tab">
      {/* 1. Header greeting & status summary */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 border-b border-neutral-100 pb-6">
        <div>
          <span className="text-xs font-semibold uppercase tracking-wider text-neutral-400">System Live</span>
          <h1 className="text-3xl font-bold tracking-tight text-neutral-900 mt-1">Emma's Feeding Feed</h1>
          <p className="text-sm text-neutral-500 mt-1">Precise formula preparation conditions and caregiver audit trail.</p>
        </div>
        <div className="flex items-center gap-3 bg-emerald-50 text-emerald-800 px-4 py-2 rounded-lg border border-emerald-100 text-sm font-medium self-start md:self-center">
          <ShieldCheck className="h-4 w-4" />
          <span>Active Safety Rules: UK NHS 2026</span>
        </div>
      </div>

      {/* 2. Critical Active Warning banner if any */}
      {hasRecallWarning && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-start gap-3">
          <AlertTriangle className="h-5 w-5 text-red-600 shrink-0 mt-0.5" />
          <div>
            <h4 className="text-sm font-semibold text-red-900">CRITICAL PRODUCT ALERT MATCH</h4>
            <p className="text-xs text-red-700 mt-1">
              A batch lot matching container inventory has been reported in the synthetic recalls database: **SYN-2026-RECALL**. Do not proceed with preparation using this batch.
            </p>
          </div>
        </div>
      )}

      {/* 3. In-Progress feed alert */}
      {activeFeed && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="flex items-start gap-3">
            <Flame className="h-5 w-5 text-amber-600 animate-pulse mt-1" />
            <div>
              <h4 className="text-sm font-bold text-amber-900">ACTIVE PREPARATION IN PROGRESS</h4>
              <p className="text-xs text-amber-700 mt-1">
                A feed is currently in state <span className="font-semibold">{activeFeed.state}</span>. Water was recorded at {activeFeed.water_temperature_c?.toFixed(1) || "--"}°C.
              </p>
            </div>
          </div>
          <button
            onClick={onResumeFeed}
            className="flex items-center gap-1 bg-amber-600 text-white text-xs font-semibold px-4 py-2 rounded-lg hover:bg-amber-700 transition self-start sm:self-center shrink-0"
          >
            <span>Resume Preparation</span>
            <ArrowRight className="h-3 w-3" />
          </button>
        </div>
      )}

      {/* 4. Stat Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white border border-neutral-100 rounded-2xl p-5 shadow-xs flex flex-col justify-between">
          <div>
            <span className="text-xs text-neutral-400 font-medium">Completed Feeds Today</span>
            <h3 className="text-2xl font-bold text-neutral-900 mt-1">{feedsToday.length}</h3>
          </div>
          <div className="mt-4 text-xs text-neutral-500 border-t border-neutral-50 pt-3 flex items-center gap-1.5">
            <Calendar className="h-3.5 w-3.5" />
            <span>Responsive tracking active</span>
          </div>
        </div>

        <div className="bg-white border border-neutral-100 rounded-2xl p-5 shadow-xs flex flex-col justify-between">
          <div>
            <span className="text-xs text-neutral-400 font-medium">Prepared vs Consumed</span>
            <h3 className="text-2xl font-bold text-neutral-900 mt-1">
              {totalPreparedToday}ml / {totalConsumedToday}ml
            </h3>
          </div>
          <div className="mt-4 text-xs text-neutral-500 border-t border-neutral-50 pt-3 flex items-center gap-1">
            <TrendingUp className="h-3.5 w-3.5 text-emerald-500" />
            <span>{(totalPreparedToday - totalConsumedToday)}ml leftover discarded</span>
          </div>
        </div>

        <div className="bg-white border border-neutral-100 rounded-2xl p-5 shadow-xs flex flex-col justify-between">
          <div>
            <span className="text-xs text-neutral-400 font-medium">Sterilised Bottles</span>
            <h3 className="text-2xl font-bold text-neutral-900 mt-1">
              {sterilisedBottles.length} <span className="text-xs text-neutral-400 font-normal">/ {bottles.length} ready</span>
            </h3>
          </div>
          <div className="mt-4 text-xs text-neutral-500 border-t border-neutral-50 pt-3 flex items-center gap-1.5">
            <Layers className="h-3.5 w-3.5" />
            <span onClick={() => onNavigate("inventory")} className="cursor-pointer underline hover:text-neutral-700">Manage sterilization</span>
          </div>
        </div>

        <div className="bg-white border border-neutral-100 rounded-2xl p-5 shadow-xs flex flex-col justify-between">
          <div>
            <span className="text-xs text-neutral-400 font-medium">Formula Stock Estimate</span>
            <h3 className="text-2xl font-bold text-neutral-900 mt-1">
              ~{estimatedDaysLeft} <span className="text-xs text-neutral-400 font-normal">Days Left</span>
            </h3>
          </div>
          <div className="mt-4 text-xs text-amber-600 bg-amber-50/50 px-2 py-1 rounded border border-amber-100/30 font-medium text-[11px] self-start">
            ESTIMATE - Based on {totalFormulaLeft}g active inventory
          </div>
        </div>
      </div>

      {/* 5. Core Operational Workflow Shortcuts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-4">
        {/* Left column: Quick Actions */}
        <div className="space-y-4">
          <h2 className="text-lg font-bold text-neutral-900 tracking-tight">Standard Safe Workflows</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <button
              onClick={() => onNavigate("prepare")}
              className="flex flex-col items-start text-left p-5 border border-neutral-200 rounded-xl hover:border-neutral-900 transition bg-white space-y-3"
            >
              <div className="bg-neutral-100 p-2.5 rounded-lg">
                <Thermometer className="h-5 w-5 text-neutral-800" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-neutral-900">Prepare Fresh Feed</h4>
                <p className="text-xs text-neutral-500 mt-1">Guided safety checklist & temperature verification step-by-step.</p>
              </div>
            </button>

            <button
              onClick={() => onNavigate("inventory")}
              className="flex flex-col items-start text-left p-5 border border-neutral-200 rounded-xl hover:border-neutral-900 transition bg-white space-y-3"
            >
              <div className="bg-neutral-100 p-2.5 rounded-lg">
                <Layers className="h-5 w-5 text-neutral-800" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-neutral-900">Manage Bottles & Stock</h4>
                <p className="text-xs text-neutral-500 mt-1">Log sterilisation sessions and open new formula canisters.</p>
              </div>
            </button>
          </div>
        </div>

        {/* Right column: Last Feed Details */}
        <div className="bg-neutral-50 border border-neutral-100 rounded-2xl p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold uppercase tracking-wider text-neutral-400">Last Feed Provenance</h2>
              <span className="text-xs text-neutral-500 font-medium">Completed</span>
            </div>
            {feeds.length > 0 ? (
              <div className="mt-4 space-y-3">
                <div className="flex justify-between items-center text-sm border-b border-neutral-200/50 pb-2">
                  <span className="text-neutral-500">Prepared Volume</span>
                  <span className="font-semibold text-neutral-900">{feeds[feeds.length-1].feed_volume_ml}ml</span>
                </div>
                <div className="flex justify-between items-center text-sm border-b border-neutral-200/50 pb-2">
                  <span className="text-neutral-500">Consumed Volume</span>
                  <span className="font-semibold text-neutral-900">{feeds[feeds.length-1].volume_consumed}ml</span>
                </div>
                <div className="flex justify-between items-center text-sm border-b border-neutral-200/50 pb-2">
                  <span className="text-neutral-500">Water Temperature</span>
                  <span className="font-semibold text-neutral-900 flex items-center gap-1 text-emerald-600">
                    <Droplet className="h-3.5 w-3.5 fill-current" />
                    {feeds[feeds.length-1].water_temperature_c?.toFixed(1)}°C (Safe)
                  </span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span className="text-neutral-500">Audit Reference</span>
                  <span className="text-xs font-mono bg-neutral-200/50 px-1.5 py-0.5 rounded text-neutral-700">
                    {feeds[feeds.length-1].formula_batch_id}
                  </span>
                </div>
              </div>
            ) : (
              <p className="text-sm text-neutral-500 mt-4">No completed feeds logged yet.</p>
            )}
          </div>
          <button
            onClick={() => onNavigate("history")}
            className="flex items-center justify-center gap-2 mt-6 bg-neutral-900 text-white text-xs font-semibold py-2.5 rounded-lg hover:bg-neutral-800 transition"
          >
            <span>View Provenance Log</span>
            <ArrowRight className="h-3 w-3" />
          </button>
        </div>
      </div>
    </div>
  );
};
