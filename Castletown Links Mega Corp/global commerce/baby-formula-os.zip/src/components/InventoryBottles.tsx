/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import {
  Layers,
  Sparkles,
  Flame,
  AlertCircle,
  FolderOpen,
  Calendar,
  CheckCircle2,
  Trash2,
  Plus
} from "lucide-react";
import {
  Bottle,
  FormulaContainer,
  FormulaProduct,
  BottleState,
  SterilisationMethod,
  SterilisationSession,
  FormulaBatch
} from "../types";

interface InventoryBottlesProps {
  bottles: Bottle[];
  containers: FormulaContainer[];
  products: FormulaProduct[];
  batches: FormulaBatch[];
  onUpdateBottles: (bottles: Bottle[]) => void;
  onUpdateContainers: (containers: FormulaContainer[]) => void;
}

export const InventoryBottles: React.FC<InventoryBottlesProps> = ({
  bottles,
  containers,
  products,
  batches,
  onUpdateBottles,
  onUpdateContainers
}) => {
  // Sterilisation session local state
  const [selectedBottlesForSterilisation, setSelectedBottlesForSterilisation] = useState<string[]>([]);
  const [sterilisationMethod, setSterilisationMethod] = useState<SterilisationMethod>(SterilisationMethod.STEAM);
  const [sessionActive, setSessionActive] = useState<boolean>(false);
  const [sessionMessage, setSessionMessage] = useState<string>("");

  // New canister local state
  const [newBrand, setNewBrand] = useState<string>("");
  const [newLot, setNewLot] = useState<string>("");
  const [newCapacity, setNewCapacity] = useState<number>(800);

  // Toggle bottle select for sterilization
  const handleToggleBottleSelect = (bottleId: string) => {
    setSelectedBottlesForSterilisation((prev) =>
      prev.includes(bottleId) ? prev.filter((id) => id !== bottleId) : [...prev, bottleId]
    );
  };

  // Run sterilization session
  const handleRunSterilisation = () => {
    if (selectedBottlesForSterilisation.length === 0) return;

    setSessionActive(true);
    setSessionMessage(`Running ${sterilisationMethod} sterilisation session...`);

    setTimeout(() => {
      // Transition selected bottles to STERILISED
      const updatedBottles = bottles.map((b) => {
        if (selectedBottlesForSterilisation.includes(b.bottle_id)) {
          return {
            ...b,
            sterility_state: BottleState.STERILISED,
            last_cleaned_at: new Date().toISOString(),
            last_sterilised_at: new Date().toISOString()
          };
        }
        return b;
      });

      onUpdateBottles(updatedBottles);
      setSessionActive(false);
      setSessionMessage(`Sterilisation completed! ${selectedBottlesForSterilisation.length} bottle(s) are now ready.`);
      setSelectedBottlesForSterilisation([]);
    }, 2000);
  };

  // Mark a bottle as dirty (simulates usage decay)
  const handleMarkBottleDirty = (bottleId: string) => {
    const updated = bottles.map((b) => {
      if (b.bottle_id === bottleId) {
        return { ...b, sterility_state: BottleState.DIRTY };
      }
      return b;
    });
    onUpdateBottles(updated);
  };

  // Open a sealed formula container
  const handleOpenContainer = (containerId: string) => {
    const updated = containers.map((c) => {
      if (c.container_id === containerId) {
        return {
          ...c,
          is_opened: true,
          opened_at: new Date().toISOString()
        };
      }
      return c;
    });
    onUpdateContainers(updated);
  };

  // Delete canister
  const handleDeleteContainer = (containerId: string) => {
    const updated = containers.filter((c) => c.container_id !== containerId);
    onUpdateContainers(updated);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8" id="inventory-tab">
      {/* LEFT & CENTER: Formula Stock & Containers */}
      <div className="lg:col-span-2 space-y-8">
        {/* Formula Stock tracker */}
        <div className="bg-white border border-neutral-200 rounded-2xl p-6 shadow-xs space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-neutral-900 flex items-center gap-2">
              <Layers className="h-5 w-5 text-neutral-700" />
              <span>Formula Containers Inventory</span>
            </h2>
            <span className="text-xs text-neutral-500 font-semibold uppercase bg-neutral-100 px-2.5 py-1 rounded">
              Batch Traceability Active
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {containers.map((c) => {
              const product = products.find((p) => p.product_id === c.product_id);
              const batch = batches.find((b) => b.batch_id === c.batch_id);
              const percentRemaining = (c.remaining_quantity_g / c.capacity_g) * 100;

              return (
                <div
                  key={c.container_id}
                  className={`border rounded-xl p-5 space-y-4 transition ${
                    batch?.recalled
                      ? "border-red-300 bg-red-50/20"
                      : c.is_opened
                      ? "border-neutral-200 bg-white"
                      : "border-neutral-200/50 bg-neutral-50/50"
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="text-sm font-bold text-neutral-900">{product?.brand}</h4>
                      <p className="text-xs text-neutral-400 mt-0.5">{product?.stage}</p>
                    </div>
                    {batch?.recalled ? (
                      <span className="text-[10px] bg-red-600 text-white font-bold px-2 py-0.5 rounded">
                        RECALLED
                      </span>
                    ) : c.is_opened ? (
                      <span className="text-[10px] bg-emerald-600 text-white font-bold px-2 py-0.5 rounded">
                        OPENED
                      </span>
                    ) : (
                      <span className="text-[10px] bg-neutral-400 text-white font-bold px-2 py-0.5 rounded">
                        SEALED
                      </span>
                    )}
                  </div>

                  {/* Stock Bar */}
                  <div className="space-y-1.5">
                    <div className="flex justify-between text-xs font-semibold text-neutral-600">
                      <span>Stock Remaining</span>
                      <span>{c.remaining_quantity_g}g / {c.capacity_g}g</span>
                    </div>
                    <div className="w-full bg-neutral-100 h-2 rounded-full overflow-hidden">
                      <div
                        className={`h-full transition-all ${
                          batch?.recalled ? "bg-red-500" : percentRemaining < 25 ? "bg-amber-500" : "bg-neutral-900"
                        }`}
                        style={{ width: `${percentRemaining}%` }}
                      ></div>
                    </div>
                  </div>

                  {/* Metadata fields */}
                  <div className="grid grid-cols-2 gap-2 text-[11px] text-neutral-500 border-t border-neutral-100 pt-3">
                    <div>
                      <span className="font-medium text-neutral-400">Batch Code:</span>
                      <p className="font-mono font-bold text-neutral-700 mt-0.5">{batch?.lot_code || "Unknown"}</p>
                    </div>
                    <div>
                      <span className="font-medium text-neutral-400">Expiry Date:</span>
                      <p className="font-semibold text-neutral-700 mt-0.5">{batch?.expiry_date}</p>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2 pt-2 justify-between">
                    {!c.is_opened && !batch?.recalled && (
                      <button
                        onClick={() => handleOpenContainer(c.container_id)}
                        className="text-xs font-bold text-neutral-900 hover:bg-neutral-100 px-3 py-1.5 rounded border border-neutral-300"
                      >
                        Open Canister
                      </button>
                    )}
                    {batch?.recalled && (
                      <div className="text-[11px] text-red-600 font-bold flex items-center gap-1">
                        <AlertCircle className="h-3.5 w-3.5" />
                        <span>DO NOT USE THIS BATCH</span>
                      </div>
                    )}
                    <button
                      onClick={() => handleDeleteContainer(c.container_id)}
                      className="text-neutral-400 hover:text-red-600 p-1.5 rounded"
                      title="Discard canister record"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Sterilisation tracking session */}
        <div className="bg-white border border-neutral-200 rounded-2xl p-6 shadow-xs space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-neutral-900 flex items-center gap-2">
              <Flame className="h-5 w-5 text-neutral-700" />
              <span>Sterilisation Control Panel</span>
            </h2>
            <span className="text-xs text-neutral-500">NHS Recommended: Boiling / Steam</span>
          </div>

          <p className="text-xs text-neutral-500">
            Select unsterilised bottles below to include in the upcoming sterilisation chamber.
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {bottles.map((b) => {
              const selected = selectedBottlesForSterilisation.includes(b.bottle_id);
              const unsterilised = b.sterility_state !== BottleState.STERILISED;

              return (
                <button
                  key={b.bottle_id}
                  disabled={!unsterilised || sessionActive}
                  onClick={() => handleToggleBottleSelect(b.bottle_id)}
                  className={`border rounded-xl p-3 text-left transition relative ${
                    !unsterilised
                      ? "border-emerald-100 bg-emerald-50/10 cursor-not-allowed opacity-60"
                      : selected
                      ? "border-neutral-900 bg-neutral-50"
                      : "border-neutral-200 hover:border-neutral-400 bg-white"
                  }`}
                >
                  <span className="text-xs font-bold text-neutral-950 block truncate">{b.name}</span>
                  <span className="text-[10px] text-neutral-400 mt-1 block">State: {b.sterility_state}</span>
                  {selected && (
                    <div className="absolute top-2 right-2 bg-neutral-900 text-white rounded-full p-0.5">
                      <Check className="h-3 w-3" />
                    </div>
                  )}
                </button>
              );
            })}
          </div>

          {/* Controls */}
          <div className="border-t border-neutral-100 pt-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <label className="text-xs font-bold uppercase text-neutral-400 shrink-0">Method</label>
              <select
                value={sterilisationMethod}
                onChange={(e) => setSterilisationMethod(e.target.value as SterilisationMethod)}
                className="bg-white border border-neutral-200 rounded-lg p-2 text-xs font-semibold text-neutral-800"
              >
                <option value={SterilisationMethod.STEAM}>Electric Steam Sterilizer</option>
                <option value={SterilisationMethod.BOILING}>Boiling Water (10 mins)</option>
                <option value={SterilisationMethod.COLD_WATER}>Cold Water Chemical Sanitizer</option>
              </select>
            </div>

            <button
              onClick={handleRunSterilisation}
              disabled={selectedBottlesForSterilisation.length === 0 || sessionActive}
              className="flex items-center gap-2 bg-neutral-950 hover:bg-neutral-800 disabled:opacity-40 text-white text-xs font-bold px-5 py-2.5 rounded-lg transition"
            >
              <Sparkles className="h-3.5 w-3.5" />
              <span>{sessionActive ? "Sterilizing chamber..." : "Run Sterilizer Cycle"}</span>
            </button>
          </div>

          {sessionMessage && (
            <div className="bg-neutral-50 border border-neutral-200 p-3 rounded-xl flex items-center gap-2 text-xs text-neutral-800">
              <CheckCircle2 className="h-4 w-4 text-emerald-600" />
              <span>{sessionMessage}</span>
            </div>
          )}
        </div>
      </div>

      {/* RIGHT: Bottles management & status */}
      <div className="space-y-6">
        <div className="bg-neutral-50 border border-neutral-200 rounded-2xl p-6 space-y-6">
          <h3 className="text-sm font-bold uppercase tracking-wider text-neutral-400">Bottles Inventory & State</h3>

          <div className="space-y-4">
            {bottles.map((b) => (
              <div key={b.bottle_id} className="bg-white border border-neutral-200/50 p-4 rounded-xl space-y-2">
                <div className="flex justify-between items-start">
                  <div>
                    <h5 className="text-xs font-bold text-neutral-900">{b.name}</h5>
                    <p className="text-[10px] text-neutral-400 mt-0.5">{b.material} • {b.capacity_ml}ml</p>
                  </div>
                  <span
                    className={`text-[9px] font-bold uppercase px-2 py-0.5 rounded ${
                      b.sterility_state === BottleState.STERILISED
                        ? "bg-emerald-100 text-emerald-800"
                        : b.sterility_state === BottleState.DIRTY
                        ? "bg-red-100 text-red-800"
                        : "bg-amber-100 text-amber-800"
                    }`}
                  >
                    {b.sterility_state}
                  </span>
                </div>

                <div className="flex justify-between items-center text-[10px] text-neutral-500 pt-2 border-t border-neutral-50">
                  <span>Usage Count: {b.usage_count}</span>
                  {b.sterility_state === BottleState.STERILISED && (
                    <button
                      onClick={() => handleMarkBottleDirty(b.bottle_id)}
                      className="text-red-600 hover:underline font-semibold"
                    >
                      Mark Dirty
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

// Helper Check component missing in lucide-react imports sometimes
const Check = ({ className }: { className?: string }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="3"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
  >
    <polyline points="20 6 9 17 4 12" />
  </svg>
);
