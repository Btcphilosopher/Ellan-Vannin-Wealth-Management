/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import {
  Cpu,
  AlertTriangle,
  Radio,
  ToggleLeft,
  ToggleRight,
  HelpCircle,
  Activity,
  Droplet
} from "lucide-react";

interface MasterSimulatorProps {
  triggerFailure: string;
  setTriggerFailure: (failure: string) => void;
  onNavigate: (tab: string) => void;
}

export const MasterSimulator: React.FC<MasterSimulatorProps> = ({
  triggerFailure,
  setTriggerFailure,
  onNavigate
}) => {
  return (
    <div className="space-y-6" id="simulator-tab">
      <div className="border-b border-neutral-100 pb-4">
        <h2 className="text-xl font-bold text-neutral-900 tracking-tight">Digital Twin & Failure Injector</h2>
        <p className="text-xs text-neutral-500 mt-1">
          Simulate real-world infant feeding safety hazards to test how the decoupled Safety Rules Engine behaves.
        </p>
      </div>

      {/* 1. Digital Twin Component status indicators */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white border border-neutral-200 rounded-xl p-5 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-neutral-400 uppercase">IoT Thermometer</span>
            <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
          </div>
          <h4 className="text-sm font-bold text-neutral-900">Calibration Profile #1</h4>
          <p className="text-xs text-neutral-500">
            Current Calibration: **±0.2°C accuracy**. Automatic safety thresholds verified every 2.5 seconds.
          </p>
          <div className="text-[10px] text-emerald-600 bg-emerald-50 px-2 py-1 rounded inline-block font-semibold">
            Status: ONLINE & CALIBRATED
          </div>
        </div>

        <div className="bg-white border border-neutral-200 rounded-xl p-5 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-neutral-400 uppercase">Volumetric Machine</span>
            <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
          </div>
          <h4 className="text-sm font-bold text-neutral-900">Dosing Nozzle A</h4>
          <p className="text-xs text-neutral-500">
            Integrity check: Zero residual moisture detected on the nozzle body to prevent premature mold buildup.
          </p>
          <div className="text-[10px] text-emerald-600 bg-emerald-50 px-2 py-1 rounded inline-block font-semibold">
            Status: READY FOR RECONSTITUTION
          </div>
        </div>

        <div className="bg-white border border-neutral-200 rounded-xl p-5 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-neutral-400 uppercase">Bottle Balance</span>
            <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
          </div>
          <h4 className="text-sm font-bold text-neutral-900">Load Cell Sensor</h4>
          <p className="text-xs text-neutral-500">
            Gravity sensor calibration: Tared to zero at current environmental pressure of 101.3 kPa.
          </p>
          <div className="text-[10px] text-emerald-600 bg-emerald-50 px-2 py-1 rounded inline-block font-semibold">
            Status: TARED
          </div>
        </div>
      </div>

      {/* 2. Failure Injector buttons */}
      <div className="bg-white border border-neutral-200 rounded-2xl p-6 space-y-6">
        <div>
          <h3 className="text-md font-bold text-neutral-950">Active Hazard Scenarios Injector</h3>
          <p className="text-xs text-neutral-500 mt-1">
            Toggle a scenario below, then head over to the **Prepare Feed** tab to witness the immediate safety guardrails in action.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Scenario 1 */}
          <button
            onClick={() => {
              setTriggerFailure(triggerFailure === "COLD_WATER" ? "NONE" : "COLD_WATER");
              onNavigate("prepare");
            }}
            className={`flex items-start text-left p-4 border rounded-xl transition ${
              triggerFailure === "COLD_WATER"
                ? "border-red-500 bg-red-50/20"
                : "border-neutral-200 hover:border-neutral-300 bg-white"
            }`}
          >
            <div className="bg-red-100 p-2 rounded-lg text-red-600 shrink-0 mt-0.5 mr-3">
              <Droplet className="h-4 w-4" />
            </div>
            <div>
              <h5 className="text-xs font-bold text-neutral-900">Inject: Water Temp Below 70°C</h5>
              <p className="text-[11px] text-neutral-500 mt-1 leading-relaxed">
                Forces water thermometer sensor output to 68.4°C. Tests if the system blocks reconstitution.
              </p>
            </div>
          </button>

          {/* Scenario 2 */}
          <button
            onClick={() => {
              setTriggerFailure(triggerFailure === "RECALLED_BATCH" ? "NONE" : "RECALLED_BATCH");
              onNavigate("prepare");
            }}
            className={`flex items-start text-left p-4 border rounded-xl transition ${
              triggerFailure === "RECALLED_BATCH"
                ? "border-red-500 bg-red-50/20"
                : "border-neutral-200 hover:border-neutral-300 bg-white"
            }`}
          >
            <div className="bg-red-100 p-2 rounded-lg text-red-600 shrink-0 mt-0.5 mr-3">
              <AlertTriangle className="h-4 w-4" />
            </div>
            <div>
              <h5 className="text-xs font-bold text-neutral-900">Inject: Formula Batch Recalled</h5>
              <p className="text-[11px] text-neutral-500 mt-1 leading-relaxed">
                Matches the scanned batch code to safety alert (SYN-2026-RECALL) issued by food standards authority.
              </p>
            </div>
          </button>

          {/* Scenario 3 */}
          <button
            onClick={() => {
              setTriggerFailure(triggerFailure === "UNSTERILISED_BOTTLE" ? "NONE" : "UNSTERILISED_BOTTLE");
              onNavigate("prepare");
            }}
            className={`flex items-start text-left p-4 border rounded-xl transition ${
              triggerFailure === "UNSTERILISED_BOTTLE"
                ? "border-red-500 bg-red-50/20"
                : "border-neutral-200 hover:border-neutral-300 bg-white"
            }`}
          >
            <div className="bg-red-100 p-2 rounded-lg text-red-600 shrink-0 mt-0.5 mr-3">
              <Cpu className="h-4 w-4" />
            </div>
            <div>
              <h5 className="text-xs font-bold text-neutral-900">Inject: Unsterilised Bottle Selection</h5>
              <p className="text-[11px] text-neutral-500 mt-1 leading-relaxed">
                Selects an unwashed/dirty bottle for feed preparation. Verifies block on equipment sterility validation.
              </p>
            </div>
          </button>

          {/* Reset Scenario */}
          <button
            onClick={() => setTriggerFailure("NONE")}
            className="flex items-start text-left p-4 border border-neutral-300 hover:border-neutral-900 rounded-xl transition bg-white"
          >
            <div className="bg-neutral-100 p-2 rounded-lg text-neutral-700 shrink-0 mt-0.5 mr-3">
              <Activity className="h-4 w-4" />
            </div>
            <div>
              <h5 className="text-xs font-bold text-neutral-900">Clear All Simulator Injections</h5>
              <p className="text-[11px] text-neutral-500 mt-1 leading-relaxed">
                Restore the IoT digital twin and thermometer systems to verified normal parameters (72.4°C safe boiled water).
              </p>
            </div>
          </button>
        </div>
      </div>

      {/* 3. Safety Architecture Grounding discussion block */}
      <div className="bg-neutral-50 border border-neutral-150 rounded-2xl p-6 space-y-4">
        <h4 className="text-sm font-bold text-neutral-900 flex items-center gap-1.5">
          <HelpCircle className="h-4 w-4 text-neutral-500" />
          <span>Decoupled Rules Engine Architecture</span>
        </h4>
        <p className="text-xs text-neutral-600 leading-relaxed">
          The central architectural rule of **Baby Formula OS** dictates that the UI state can never overrule safety parameters. Even if a user attempts to manually force progress, the internal validator classes (`PreparationValidator`, `BottleSterilityState`) act as non-negotiable gates.
        </p>
        <p className="text-xs text-neutral-600 leading-relaxed">
          This protects against food safety failures like infant ingestion of unsterilised powder pathogens or dangerously concentrated/diluted formulas which could lead to physical complications (malnutrition or renal strain).
        </p>
      </div>
    </div>
  );
};
