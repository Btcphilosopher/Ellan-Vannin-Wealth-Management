/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import {
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  Play,
  RotateCcw,
  Check,
  Info,
  Thermometer,
  FileText,
  Scan,
  RefreshCw
} from "lucide-react";
import {
  FormulaProduct,
  Bottle,
  Feed,
  FeedState,
  WaterType,
  HungerCue,
  DataProvenance,
  FormulaFormat
} from "../types";
import {
  PreparationValidator,
  TemperatureValidator,
  FormulaInstructionValidator,
  BottleSterilityState
} from "../core/safety";

interface PrepareWorkflowProps {
  products: FormulaProduct[];
  bottles: Bottle[];
  activeFeed: Feed | null;
  onSaveFeed: (feed: Feed) => void;
  onUpdateActiveFeed: (feed: Feed | null) => void;
  triggerFailure: string; // state injected from master simulator
}

export const PrepareWorkflow: React.FC<PrepareWorkflowProps> = ({
  products,
  bottles,
  activeFeed,
  onSaveFeed,
  onUpdateActiveFeed,
  triggerFailure
}) => {
  // Local state for setup prior to feed creation
  const [selectedProductId, setSelectedProductId] = useState<string>(products[0]?.product_id || "");
  const [selectedBottleId, setSelectedBottleId] = useState<string>(bottles[0]?.bottle_id || "");
  const [waterVolume, setWaterVolume] = useState<number>(120);
  const [powderScoops, setPowderScoops] = useState<number>(4);
  const [waterTemp, setWaterTemp] = useState<number>(72.4); // Standard safe temperature
  const [waterSource, setWaterSource] = useState<WaterType>(WaterType.FRESH_COLD_TAP);
  const [scannedProduct, setScannedProduct] = useState<FormulaProduct | null>(null);
  const [scanMessage, setScanMessage] = useState<string>("");
  const [isScanning, setIsScanning] = useState<boolean>(false);

  // In-preparation local state for steps
  const [currentStep, setCurrentStep] = useState<number>(1);
  const [checklist, setChecklist] = useState({
    hands_clean: false,
    surface_clean: false,
    equipment_clean: false,
    equipment_sterilised: false,
    fresh_water: false,
    water_temperature_verified: false,
    correct_bottle: false,
    correct_formula: false,
    correct_scoop: false,
    water_measurement_verified: false,
    powder_measurement_verified: false,
    bottle_closed: false,
    mixed: false,
    cooling_started: false,
    feeding_temperature_verified: false
  });

  // Feeding consumption states
  const [consumedVolume, setConsumedVolume] = useState<number>(120);
  const [selectedCues, setSelectedCues] = useState<HungerCue[]>([]);
  const [notes, setNotes] = useState<string>("");

  const activeProduct = products.find((p) => p.product_id === selectedProductId);
  const activeBottle = bottles.find((b) => b.bottle_id === selectedBottleId);

  // Monitor Simulator Failure injections
  useEffect(() => {
    if (triggerFailure === "COLD_WATER") {
      setWaterTemp(68.4);
    } else if (triggerFailure === "UNSTERILISED_BOTTLE") {
      const dirtyBottle = bottles.find(b => b.sterility_state === "DIRTY");
      if (dirtyBottle) setSelectedBottleId(dirtyBottle.bottle_id);
    } else if (triggerFailure === "EXPIRED_BATCH") {
      setWaterTemp(72.4);
    }
  }, [triggerFailure, bottles]);

  // Adjust powder scoops automatically when water volume changes based on manufacturer
  useEffect(() => {
    if (activeProduct) {
      const matchingInst = activeProduct.instructions.find(i => i.water_volume_ml === waterVolume);
      if (matchingInst) {
        setPowderScoops(matchingInst.powder_scoops);
      }
    }
  }, [waterVolume, selectedProductId, activeProduct]);

  // Handle OCR/Barcode scan simulation
  const simulateScan = () => {
    setIsScanning(true);
    setScanMessage("");
    setTimeout(() => {
      setIsScanning(false);
      // Simulate scanning second product
      const productToScan = products[0];
      setScannedProduct(productToScan);
      setScanMessage("Barcode scanning completed. GTIN: 5012345678901 identified.");
    }, 1500);
  };

  const verifyScannedProduct = () => {
    if (scannedProduct) {
      setSelectedProductId(scannedProduct.product_id);
      setScannedProduct(null);
      setScanMessage("Product verified and loaded.");
    }
  };

  // Validators check on the fly
  const tempValidation = PreparationValidator.validateWaterTemp(waterTemp, activeProduct?.country === "UK" ? "UK" as any : "WHO" as any);
  const sequenceValidation = PreparationValidator.validateSequence(true, "UK" as any);
  const bottleValidation = activeBottle ? BottleSterilityState.canUseBottle(activeBottle) : { usable: false, reason: "No bottle selected" };
  const proportionValidation = activeProduct ? FormulaInstructionValidator.validateProportions(activeProduct, waterVolume, powderScoops) : { valid: true, message: "" };

  const canStartPreparation = tempValidation.valid && bottleValidation.usable && proportionValidation.valid;

  // Lifecycle states
  const startPrep = () => {
    if (!canStartPreparation) return;

    const newFeed: Feed = {
      feed_id: `FEED-${Date.now()}`,
      baby_id: "BABY-EMMA",
      formula_product_id: selectedProductId,
      formula_batch_id: triggerFailure === "RECALLED_BATCH" ? "SYN-2026-RECALL" : "SYN-2026-001",
      bottle_id: selectedBottleId,
      state: FeedState.PREPARING,
      preparation_started_at: new Date().toISOString(),
      water_temperature_c: waterTemp,
      reconstitution_temp_verified: true,
      feed_volume_ml: activeProduct?.format === "READY_TO_FEED" ? waterVolume : (waterVolume + (powderScoops * 2.5)), // estimated final liquid size
      powder_scoops: activeProduct?.format === "READY_TO_FEED" ? 0 : powderScoops,
      powder_mass_g: activeProduct?.format === "READY_TO_FEED" ? 0 : (powderScoops * (activeProduct?.scoop.nominal_mass_g || 4.3)),
      preparation_method: "MANUAL",
      water_source: waterSource,
      baby_cues_recorded: [],
      caregiver_id: "CG-ALEX",
      provenance: DataProvenance.MEASURED
    };

    onUpdateActiveFeed(newFeed);
    setCurrentStep(1);
  };

  const handleToggleChecklist = (key: keyof typeof checklist) => {
    setChecklist((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const handleNextStep = () => {
    if (!activeFeed) return;

    const stateTransitions: Record<number, FeedState> = {
      1: FeedState.PREPARING,
      2: FeedState.PREPARING,
      3: FeedState.PREPARING,
      4: FeedState.WATER_ADDED,
      5: FeedState.WATER_ADDED,
      6: FeedState.POWDER_ADDED,
      7: FeedState.MIXED,
      8: FeedState.COOLING,
      9: FeedState.READY,
      10: FeedState.FEEDING
    };

    const nextState = stateTransitions[currentStep + 1] || FeedState.FEEDING;
    const updatedFeed = { ...activeFeed, state: nextState };
    
    if (currentStep === 4) {
      updatedFeed.water_added_at = new Date().toISOString();
    } else if (currentStep === 6) {
      updatedFeed.powder_added_at = new Date().toISOString();
    } else if (currentStep === 7) {
      updatedFeed.mixed_at = new Date().toISOString();
    } else if (currentStep === 8) {
      updatedFeed.cooling_started_at = new Date().toISOString();
    } else if (currentStep === 9) {
      updatedFeed.ready_at = new Date().toISOString();
    } else if (currentStep === 10) {
      updatedFeed.feeding_started_at = new Date().toISOString();
    }

    onUpdateActiveFeed(updatedFeed);
    setCurrentStep((prev) => prev + 1);
  };

  const handleCuesToggle = (cue: HungerCue) => {
    setSelectedCues((prev) =>
      prev.includes(cue) ? prev.filter((c) => c !== cue) : [...prev, cue]
    );
  };

  const handleFinishFeed = () => {
    if (!activeFeed) return;

    const finalVolume = activeFeed.feed_volume_ml;
    const remaining = Math.max(0, finalVolume - consumedVolume);

    const completedFeed: Feed = {
      ...activeFeed,
      state: FeedState.COMPLETED,
      feeding_finished_at: new Date().toISOString(),
      volume_offered: finalVolume,
      volume_consumed: consumedVolume,
      volume_remaining: remaining,
      baby_cues_recorded: selectedCues,
      notes: notes,
      discarded_at: remaining > 0 ? new Date().toISOString() : undefined
    };

    onSaveFeed(completedFeed);
    onUpdateActiveFeed(null);
    setCurrentStep(1);
    setChecklist({
      hands_clean: false,
      surface_clean: false,
      equipment_clean: false,
      equipment_sterilised: false,
      fresh_water: false,
      water_temperature_verified: false,
      correct_bottle: false,
      correct_formula: false,
      correct_scoop: false,
      water_measurement_verified: false,
      powder_measurement_verified: false,
      bottle_closed: false,
      mixed: false,
      cooling_started: false,
      feeding_temperature_verified: false
    });
    setConsumedVolume(120);
    setSelectedCues([]);
    setNotes("");
  };

  const handleDiscardFeed = () => {
    if (!activeFeed) return;

    const discardedFeed: Feed = {
      ...activeFeed,
      state: FeedState.DISCARDED,
      discarded_at: new Date().toISOString()
    };

    onSaveFeed(discardedFeed);
    onUpdateActiveFeed(null);
    setCurrentStep(1);
  };

  return (
    <div className="space-y-8" id="prepare-feed-tab">
      {!activeFeed ? (
        // STAGE A: Setup & Verify prior to starting feed
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white border border-neutral-200/80 rounded-2xl p-6 shadow-xs space-y-6">
              <h2 className="text-xl font-bold text-neutral-900 flex items-center gap-2">
                <Thermometer className="h-5 w-5 text-neutral-700" />
                <span>1. Feed Specifications</span>
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {/* Product Select */}
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase text-neutral-400">Formula Product</label>
                  <select
                    value={selectedProductId}
                    onChange={(e) => setSelectedProductId(e.target.value)}
                    className="w-full bg-white border border-neutral-200 rounded-lg p-2.5 text-sm text-neutral-800 focus:border-neutral-950 focus:ring-0"
                  >
                    {products.map((p) => (
                      <option key={p.product_id} value={p.product_id}>
                        {p.brand} ({p.stage})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Bottle Select */}
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase text-neutral-400">Sterile Bottle</label>
                  <select
                    value={selectedBottleId}
                    onChange={(e) => setSelectedBottleId(e.target.value)}
                    className="w-full bg-white border border-neutral-200 rounded-lg p-2.5 text-sm text-neutral-800 focus:border-neutral-950 focus:ring-0"
                  >
                    {bottles.map((b) => (
                      <option key={b.bottle_id} value={b.bottle_id}>
                        {b.name} - State: {b.sterility_state}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {activeProduct?.format === FormulaFormat.POWDER ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-2">
                  {/* Discrete Sizes Ratios */}
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase text-neutral-400">Water Volume (discrete)</label>
                    <select
                      value={waterVolume}
                      onChange={(e) => setWaterVolume(Number(e.target.value))}
                      className="w-full bg-white border border-neutral-200 rounded-lg p-2.5 text-sm text-neutral-800 focus:border-neutral-950 focus:ring-0"
                    >
                      {activeProduct.instructions.map((inst) => (
                        <option key={inst.water_volume_ml} value={inst.water_volume_ml}>
                          {inst.water_volume_ml} ml
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Powder scoops */}
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase text-neutral-400 flex items-center justify-between">
                      <span>Powder Scoops</span>
                      <span className="text-[10px] text-amber-600 font-medium bg-amber-50 px-1.5 py-0.5 rounded">
                        Strict Dilution Check
                      </span>
                    </label>
                    <div className="flex items-center gap-3">
                      <button
                        onClick={() => setPowderScoops(prev => Math.max(1, prev - 1))}
                        className="bg-neutral-100 hover:bg-neutral-200 text-neutral-800 font-bold px-3 py-1.5 rounded-lg"
                      >
                        -
                      </button>
                      <span className="text-lg font-bold w-8 text-center">{powderScoops}</span>
                      <button
                        onClick={() => setPowderScoops(prev => prev + 1)}
                        className="bg-neutral-100 hover:bg-neutral-200 text-neutral-800 font-bold px-3 py-1.5 rounded-lg"
                      >
                        +
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="bg-neutral-50 p-4 rounded-xl border border-neutral-100 text-xs text-neutral-600">
                  Ready-To-Feed Liquid Selected. No powder measurement required. Volume to pour: {waterVolume}ml.
                </div>
              )}

              {/* Water Source & Temp */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-2">
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase text-neutral-400">Water Preparation Type</label>
                  <select
                    value={waterSource}
                    onChange={(e) => setWaterSource(e.target.value as WaterType)}
                    className="w-full bg-white border border-neutral-200 rounded-lg p-2.5 text-sm text-neutral-800"
                  >
                    <option value={WaterType.FRESH_COLD_TAP}>Fresh Cold Tap (Recommended)</option>
                    <option value={WaterType.BOTTLED}>Bottled (Low Sodium)</option>
                    <option value={WaterType.FILTERED}>Filtered Tap</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase text-neutral-400 flex items-center justify-between">
                    <span>Measured Temp (°C)</span>
                    <span className="text-[10px] font-mono text-neutral-500">±0.2°C accuracy</span>
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={waterTemp}
                    onChange={(e) => setWaterTemp(Number(e.target.value))}
                    className="w-full bg-white border border-neutral-200 rounded-lg p-2 text-sm text-neutral-800 focus:border-neutral-950 focus:ring-0"
                  />
                </div>
              </div>
            </div>

            {/* Simulated Scanner Section */}
            <div className="bg-white border border-neutral-200/80 rounded-2xl p-6 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold uppercase tracking-wider text-neutral-400">Packaging Barcode Scanner</h3>
                <span className="text-[10px] text-neutral-500">Importers Pipeline</span>
              </div>
              <p className="text-xs text-neutral-500">
                OCR and barcode scanning can help accelerate entry but can never bypass human inspection.
              </p>
              
              <div className="flex flex-wrap items-center gap-3">
                <button
                  onClick={simulateScan}
                  disabled={isScanning}
                  className="flex items-center gap-2 bg-neutral-100 hover:bg-neutral-200 disabled:opacity-50 text-neutral-800 text-xs font-bold px-4 py-2.5 rounded-lg transition"
                >
                  {isScanning ? (
                    <>
                      <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                      <span>Reading camera feed...</span>
                    </>
                  ) : (
                    <>
                      <Scan className="h-3.5 w-3.5" />
                      <span>Simulate QR/Barcode Scan</span>
                    </>
                  )}
                </button>
              </div>

              {scanMessage && (
                <div className="bg-blue-50 border border-blue-200 p-3 rounded-xl flex items-start gap-2.5">
                  <Info className="h-4 w-4 text-blue-600 mt-0.5 shrink-0" />
                  <div className="flex-1">
                    <p className="text-xs text-blue-800 font-medium">{scanMessage}</p>
                    <p className="text-[11px] text-blue-700 font-bold mt-1">
                      Verify this information against the physical packaging before using it.
                    </p>
                    <button
                      onClick={verifyScannedProduct}
                      className="mt-2 bg-blue-600 hover:bg-blue-700 text-white text-[10px] font-bold px-3 py-1 rounded"
                    >
                      Confirm Extracted Packaging Proportions
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right column: Safety Rule Engine Pre-Verification blocks */}
          <div className="space-y-6">
            <div className="bg-neutral-50 border border-neutral-200 rounded-2xl p-6 space-y-6 sticky top-6">
              <h3 className="text-sm font-bold uppercase tracking-wider text-neutral-400">Safety Parameters Verification</h3>

              {/* Temp Rule block */}
              <div className="space-y-2">
                <span className="text-xs font-medium text-neutral-500">1. Reconstitution Temperature Safety</span>
                {tempValidation.valid ? (
                  <div className="bg-emerald-50 border border-emerald-100 p-3.5 rounded-xl text-xs text-emerald-800 space-y-1">
                    <div className="flex items-center gap-2 font-bold">
                      <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                      <span>Rule Check Passed</span>
                    </div>
                    <p className="text-[11px] text-emerald-700 leading-relaxed mt-1">
                      Water temperature is {waterTemp}°C, satisfying the requirement of ≥70°C for powdered formulas under UK/WHO guidelines.
                    </p>
                  </div>
                ) : (
                  <div className="bg-red-50 border border-red-200 p-4 rounded-xl space-y-2">
                    <div className="flex items-center gap-2 font-bold text-red-900 text-xs">
                      <AlertTriangle className="h-4 w-4 text-red-600 shrink-0" />
                      <span>PREPARATION BLOCKED</span>
                    </div>
                    <div className="text-[11px] text-red-800 space-y-1 font-mono">
                      <div>Rule: UK_PIF_MIN_RECONSTITUTION_TEMP</div>
                      <div>Measured: {waterTemp}°C</div>
                      <div>Required: ≥70°C</div>
                      <div>Source: NHS Guidance</div>
                    </div>
                    <p className="text-[11px] text-red-700 leading-relaxed font-semibold mt-1">
                      Do not proceed using this preparation state. Pathogens inside powdered containers can only be sterilized at temperatures over 70°C.
                    </p>
                  </div>
                )}
              </div>

              {/* Bottle sterility state block */}
              <div className="space-y-2">
                <span className="text-xs font-medium text-neutral-500">2. Equipment Sterility</span>
                {bottleValidation.usable ? (
                  <div className="bg-emerald-50 border border-emerald-100 p-3.5 rounded-xl text-xs text-emerald-800 space-y-1">
                    <div className="flex items-center gap-2 font-bold">
                      <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                      <span>Sterility Verified</span>
                    </div>
                    <p className="text-[11px] text-emerald-700 mt-1">
                      Bottle '{activeBottle?.name}' is currently STERILISED and safe to accept formula feed.
                    </p>
                  </div>
                ) : (
                  <div className="bg-red-50 border border-red-200 p-4 rounded-xl space-y-2">
                    <div className="flex items-center gap-2 font-bold text-red-900 text-xs">
                      <AlertTriangle className="h-4 w-4 text-red-600 shrink-0" />
                      <span>UNSTERILISED EQUIPMENT BLOCKED</span>
                    </div>
                    <p className="text-[11px] text-red-700">
                      {bottleValidation.reason}. Infant immune systems require fully sterilised bottles. Run a sterilization session before starting.
                    </p>
                  </div>
                )}
              </div>

              {/* Proportion dilutions checks */}
              {activeProduct?.format === FormulaFormat.POWDER && (
                <div className="space-y-2">
                  <span className="text-xs font-medium text-neutral-500">3. Dilution Ratios</span>
                  {proportionValidation.valid ? (
                    <div className="bg-emerald-50 border border-emerald-100 p-3.5 rounded-xl text-xs text-emerald-800">
                      <div className="flex items-center gap-2 font-bold">
                        <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                        <span>Ratios Match Packaging</span>
                      </div>
                      <p className="text-[11px] text-emerald-700 mt-1">
                        Proportion verified: {waterVolume}ml water to exactly {powderScoops} scoops of {activeProduct?.brand}.
                      </p>
                    </div>
                  ) : (
                    <div className="bg-red-50 border border-red-200 p-4 rounded-xl space-y-2">
                      <div className="flex items-center gap-2 font-bold text-red-900 text-xs">
                        <AlertTriangle className="h-4 w-4 text-red-600 shrink-0" />
                        <span>DILUTION ERROR</span>
                      </div>
                      <p className="text-[11px] text-red-700">
                        {proportionValidation.message}
                      </p>
                      <button
                        onClick={() => {
                          if (proportionValidation.expectedScoops) {
                            setPowderScoops(proportionValidation.expectedScoops);
                          }
                        }}
                        className="bg-neutral-900 text-white text-[10px] font-bold py-1 px-2 rounded-md hover:bg-neutral-800"
                      >
                        Correct to manufacturer instructions
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* Formula special Anti reflux checks warning */}
              {activeProduct?.specialty === "ANTI_REFLUX" && (
                <div className="bg-amber-50 border border-amber-200 p-3.5 rounded-xl text-xs text-amber-800 space-y-1">
                  <div className="font-bold flex items-center gap-1.5">
                    <Info className="h-4 w-4" />
                    <span>Specialist Infant Product</span>
                  </div>
                  <p className="text-[11px]">
                    CRITICAL: Anti-reflux preparation instructions can differ significantly from standard milks. FOLLOW THE PACKAGE INSTRUCTIONS OR SPEAK TO A HEALTH PROFESSIONAL.
                  </p>
                </div>
              )}

              {/* Start Feed button */}
              <button
                onClick={startPrep}
                disabled={!canStartPreparation}
                className="w-full flex items-center justify-center gap-2 bg-neutral-950 text-white font-bold py-3.5 rounded-xl hover:bg-neutral-800 disabled:opacity-40 transition text-sm shadow"
              >
                <Play className="h-4 w-4 fill-current" />
                <span>Begin Guided Preparation</span>
              </button>
            </div>
          </div>
        </div>
      ) : (
        // STAGE B: Active Preparation step-by-step UI (One-Handed Night Mode Layout friendly)
        <div className="max-w-3xl mx-auto space-y-6">
          {/* Progress Header */}
          <div className="bg-white border border-neutral-200 p-6 rounded-2xl shadow-xs">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold uppercase text-neutral-400 tracking-wider">Step {currentStep} of 11</span>
                <h2 className="text-lg font-bold text-neutral-900 mt-1">
                  {currentStep === 1 && "1. Wash Hands"}
                  {currentStep === 2 && "2. Prepare Clean Equipment"}
                  {currentStep === 3 && "3. Verify Fresh Water Source"}
                  {currentStep === 4 && "4. Verify Water Temperature"}
                  {currentStep === 5 && "5. Add Water First"}
                  {currentStep === 6 && "6. Add Formula Powder"}
                  {currentStep === 7 && "7. Shake & Mix Formula"}
                  {currentStep === 8 && "8. Cooling Mixture"}
                  {currentStep === 9 && "9. Verify Feeding Temperature"}
                  {currentStep === 10 && "10. Responsive Feeding"}
                  {currentStep === 11 && "11. Discard & Complete Record"}
                </h2>
              </div>
              <button
                onClick={handleDiscardFeed}
                className="text-xs font-bold text-red-600 hover:bg-red-50 px-3 py-1.5 rounded-lg border border-red-100"
              >
                Abort & Discard Feed
              </button>
            </div>

            <div className="w-full bg-neutral-100 h-1.5 rounded-full mt-4 overflow-hidden">
              <div
                className="bg-neutral-900 h-full transition-all duration-300"
                style={{ width: `${(currentStep / 11) * 100}%` }}
              ></div>
            </div>
          </div>

          {/* Interactive Steps contents */}
          <div className="bg-white border border-neutral-200 rounded-2xl p-6 min-h-[300px] flex flex-col justify-between shadow-xs">
            {/* Step Descriptions and Actions */}
            <div className="space-y-6">
              {/* Step 1: Handwashing */}
              {currentStep === 1 && (
                <div className="space-y-4">
                  <p className="text-sm text-neutral-600 leading-relaxed">
                    Wash your hands thoroughly with soap and warm water before handling sterilised bottles, teats, caps, or powder scoops. Dry your hands on a clean towel.
                  </p>
                  <button
                    onClick={() => handleToggleChecklist("hands_clean")}
                    className={`w-full p-4 border rounded-xl flex items-center justify-between text-sm font-semibold transition ${
                      checklist.hands_clean ? "bg-emerald-50 border-emerald-400 text-emerald-900" : "bg-neutral-50 border-neutral-200 text-neutral-700"
                    }`}
                  >
                    <span>I have washed and dried my hands</span>
                    {checklist.hands_clean && <Check className="h-4 w-4 text-emerald-600" />}
                  </button>
                </div>
              )}

              {/* Step 2: Sterilised Equipment */}
              {currentStep === 2 && (
                <div className="space-y-4">
                  <p className="text-sm text-neutral-600 leading-relaxed">
                    Check that all bottle components (teat, ring, cap, body) are clean and have been sterilised. Clean the preparation surface area with a clean cloth.
                  </p>
                  <div className="space-y-2">
                    <button
                      onClick={() => handleToggleChecklist("surface_clean")}
                      className={`w-full p-4 border rounded-xl flex items-center justify-between text-sm font-semibold transition ${
                        checklist.surface_clean ? "bg-emerald-50 border-emerald-400 text-emerald-900" : "bg-neutral-50 border-neutral-200 text-neutral-700"
                      }`}
                    >
                      <span>Preparation surface clean</span>
                      {checklist.surface_clean && <Check className="h-4 w-4 text-emerald-600" />}
                    </button>
                    <button
                      onClick={() => handleToggleChecklist("equipment_sterilised")}
                      className={`w-full p-4 border rounded-xl flex items-center justify-between text-sm font-semibold transition ${
                        checklist.equipment_sterilised ? "bg-emerald-50 border-emerald-400 text-emerald-900" : "bg-neutral-50 border-neutral-200 text-neutral-700"
                      }`}
                    >
                      <span>Bottle & Teat sterilised state verified</span>
                      {checklist.equipment_sterilised && <Check className="h-4 w-4 text-emerald-600" />}
                    </button>
                  </div>
                </div>
              )}

              {/* Step 3: Fresh Water Source */}
              {currentStep === 3 && (
                <div className="space-y-4">
                  <p className="text-sm text-neutral-600 leading-relaxed">
                    Fill the kettle with fresh cold tap water. Do not use previously boiled water. Water that has been boiled multiple times is unsafe because concentrated minerals build up, which can overload a baby's kidneys.
                  </p>
                  <button
                    onClick={() => handleToggleChecklist("fresh_water")}
                    className={`w-full p-4 border rounded-xl flex items-center justify-between text-sm font-semibold transition ${
                      checklist.fresh_water ? "bg-emerald-50 border-emerald-400 text-emerald-900" : "bg-neutral-50 border-neutral-200 text-neutral-700"
                    }`}
                  >
                    <span>I am using freshly drawn cold tap water</span>
                    {checklist.fresh_water && <Check className="h-4 w-4 text-emerald-600" />}
                  </button>
                </div>
              )}

              {/* Step 4: Verify Reconstitution Temp */}
              {currentStep === 4 && (
                <div className="space-y-4">
                  <p className="text-sm text-neutral-600 leading-relaxed">
                    Boil the water. Let it cool for no more than 30 minutes so that it remains at a minimum safety temperature of **70°C** when the powder is added.
                  </p>
                  <div className="bg-emerald-50 border border-emerald-100 p-4 rounded-xl text-xs text-emerald-800 space-y-1">
                    <div className="font-bold flex items-center gap-1.5">
                      <Thermometer className="h-4 w-4 text-emerald-600" />
                      <span>Water Temperature Sensor Value</span>
                    </div>
                    <p className="text-sm font-bold text-emerald-900 mt-1">
                      Recorded Reconstitution Temperature: {activeFeed.water_temperature_c?.toFixed(1)}°C
                    </p>
                    <p className="text-[11px] text-emerald-700">
                      Rule Verification: UK_PIF_RECONSTITUTION_MIN_TEMP met. Water is sufficiently hot to sterilize Cronobacter pathogens.
                    </p>
                  </div>
                  <button
                    onClick={() => handleToggleChecklist("water_temperature_verified")}
                    className={`w-full p-4 border rounded-xl flex items-center justify-between text-sm font-semibold transition ${
                      checklist.water_temperature_verified ? "bg-emerald-50 border-emerald-400 text-emerald-900" : "bg-neutral-50 border-neutral-200 text-neutral-700"
                    }`}
                  >
                    <span>I have verified water temperature is at least 70°C</span>
                    {checklist.water_temperature_verified && <Check className="h-4 w-4 text-emerald-600" />}
                  </button>
                </div>
              )}

              {/* Step 5: Add Water First */}
              {currentStep === 5 && (
                <div className="space-y-4">
                  <p className="text-sm text-neutral-600 leading-relaxed">
                    Pour exactly **{waterVolume} ml** of water into the bottle. Ensure you measure from the bottom of the meniscus at eye level.
                  </p>
                  <div className="bg-amber-50 border border-amber-200 p-4 rounded-xl text-xs text-amber-800 space-y-1">
                    <div className="font-bold flex items-center gap-1">
                      <AlertTriangle className="h-4 w-4 text-amber-600" />
                      <span>NHS Safety Rule</span>
                    </div>
                    <p className="text-[11px] text-amber-700">
                      You must add water to the bottle first before adding the powder. This ensures correct concentration and maintains reconstitution safety.
                    </p>
                  </div>
                  <button
                    onClick={() => handleToggleChecklist("water_measurement_verified")}
                    className={`w-full p-4 border rounded-xl flex items-center justify-between text-sm font-semibold transition ${
                      checklist.water_measurement_verified ? "bg-emerald-50 border-emerald-400 text-emerald-900" : "bg-neutral-50 border-neutral-200 text-neutral-700"
                    }`}
                  >
                    <span>Measured exactly {waterVolume}ml water first</span>
                    {checklist.water_measurement_verified && <Check className="h-4 w-4 text-emerald-600" />}
                  </button>
                </div>
              )}

              {/* Step 6: Add Correct Powder */}
              {currentStep === 6 && (
                <div className="space-y-4">
                  <p className="text-sm text-neutral-600 leading-relaxed">
                    Add exactly **{powderScoops} flat scoops** of powdered formula to the bottle. Use the scoop provided in the packaging. Level each scoop with a clean knife. Do not tap or pack the powder.
                  </p>
                  <button
                    onClick={() => handleToggleChecklist("powder_measurement_verified")}
                    className={`w-full p-4 border rounded-xl flex items-center justify-between text-sm font-semibold transition ${
                      checklist.powder_measurement_verified ? "bg-emerald-50 border-emerald-400 text-emerald-900" : "bg-neutral-50 border-neutral-200 text-neutral-700"
                    }`}
                  >
                    <span>Added exactly {powderScoops} level scoops</span>
                    {checklist.powder_measurement_verified && <Check className="h-4 w-4 text-emerald-600" />}
                  </button>
                </div>
              )}

              {/* Step 7: Mix */}
              {currentStep === 7 && (
                <div className="space-y-4">
                  <p className="text-sm text-neutral-600 leading-relaxed">
                    Seal the bottle using a sterilised cap. Shake or roll the bottle immediately according to manufacturer directions.
                  </p>
                  <div className="bg-neutral-50 p-4 rounded-xl border border-neutral-200 text-xs space-y-1 text-neutral-700">
                    <span className="font-bold">Mixing Directions for {activeProduct?.brand}:</span>
                    <p className="mt-1 leading-relaxed">{activeProduct?.instructions[0]?.mixing_instruction}</p>
                  </div>
                  <button
                    onClick={() => handleToggleChecklist("mixed")}
                    className={`w-full p-4 border rounded-xl flex items-center justify-between text-sm font-semibold transition ${
                      checklist.mixed ? "bg-emerald-50 border-emerald-400 text-emerald-900" : "bg-neutral-50 border-neutral-200 text-neutral-700"
                    }`}
                  >
                    <span>Bottle closed and mixture thoroughly dissolved</span>
                    {checklist.mixed && <Check className="h-4 w-4 text-emerald-600" />}
                  </button>
                </div>
              )}

              {/* Step 8: Cool */}
              {currentStep === 8 && (
                <div className="space-y-4">
                  <p className="text-sm text-neutral-600 leading-relaxed">
                    The bottle is currently too hot to feed. Cool the bottle immediately under cold running tap water or in a bowl of cold water. Do not let the water level reach the collar of the teat/cap.
                  </p>
                  <button
                    onClick={() => handleToggleChecklist("cooling_started")}
                    className={`w-full p-4 border rounded-xl flex items-center justify-between text-sm font-semibold transition ${
                      checklist.cooling_started ? "bg-emerald-50 border-emerald-400 text-emerald-900" : "bg-neutral-50 border-neutral-200 text-neutral-700"
                    }`}
                  >
                    <span>Mixture cooled under cold running water</span>
                    {checklist.cooling_started && <Check className="h-4 w-4 text-emerald-600" />}
                  </button>
                </div>
              )}

              {/* Step 9: Verify Feeding Temperature */}
              {currentStep === 9 && (
                <div className="space-y-4">
                  <p className="text-sm text-neutral-600 leading-relaxed">
                    Verify that the formula has cooled sufficiently so it is safe to drink. Test the temperature by shaking a few drops onto the inside of your wrist. It should feel lukewarm, not hot.
                  </p>
                  <div className="bg-emerald-50 border border-emerald-100 p-4 rounded-xl text-xs text-emerald-800 space-y-1">
                    <div className="font-bold flex items-center gap-1.5">
                      <Thermometer className="h-4 w-4 text-emerald-600" />
                      <span>Feeding Temperature Check</span>
                    </div>
                    <p className="text-sm font-bold text-emerald-900 mt-1">
                      Wrist Drop / Sensor Temp: ~36.8°C (Safe)
                    </p>
                    <p className="text-[11px] text-emerald-700 font-medium">
                      Legibility limit check: Safe drinking threshold is below 38°C to prevent thermal injury.
                    </p>
                  </div>
                  <button
                    onClick={() => handleToggleChecklist("feeding_temperature_verified")}
                    className={`w-full p-4 border rounded-xl flex items-center justify-between text-sm font-semibold transition ${
                      checklist.feeding_temperature_verified ? "bg-emerald-50 border-emerald-400 text-emerald-900" : "bg-neutral-50 border-neutral-200 text-neutral-700"
                    }`}
                  >
                    <span>I verified temperature on my wrist (lukewarm)</span>
                    {checklist.feeding_temperature_verified && <Check className="h-4 w-4 text-emerald-600" />}
                  </button>
                </div>
              )}

              {/* Step 10: Responsive Feeding Session */}
              {currentStep === 10 && (
                <div className="space-y-4">
                  <p className="text-sm text-neutral-600 leading-relaxed">
                    Start feeding the baby. Offer feed responsively. Record the infant's cues rather than imposing a rigid timing schedule. Select observed signals:
                  </p>
                  
                  <div className="flex flex-wrap gap-2 pt-2">
                    {Object.values(HungerCue).map((cue) => {
                      const selected = selectedCues.includes(cue);
                      return (
                        <button
                          key={cue}
                          onClick={() => handleCuesToggle(cue)}
                          className={`text-xs font-semibold px-3 py-2 rounded-full border transition ${
                            selected
                              ? "bg-neutral-900 text-white border-neutral-900"
                              : "bg-white text-neutral-700 border-neutral-200 hover:border-neutral-400"
                          }`}
                        >
                          {cue}
                        </button>
                      );
                    })}
                  </div>

                  <div className="space-y-2 pt-4">
                    <label className="text-xs font-bold text-neutral-400 uppercase">Caregiver Observation Notes</label>
                    <textarea
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="e.g., responsive pauses, burped well, fell asleep satisfied."
                      className="w-full text-sm bg-white border border-neutral-200 rounded-lg p-3 min-h-[80px] focus:ring-0 focus:border-neutral-950"
                    ></textarea>
                  </div>
                </div>
              )}

              {/* Step 11: Completion & Discard Leftovers */}
              {currentStep === 11 && (
                <div className="space-y-6">
                  <p className="text-sm text-neutral-600 leading-relaxed">
                    Recording feed finalization parameters. Note that once a feed starts, bacterial multiplication from baby's saliva occurs rapidly.
                  </p>

                  <div className="space-y-2">
                    <label className="text-xs font-bold text-neutral-400 uppercase flex justify-between">
                      <span>Volume Consumed (ml)</span>
                      <span className="text-neutral-500">Prepared: {activeFeed.feed_volume_ml}ml</span>
                    </label>
                    <input
                      type="range"
                      min="0"
                      max={activeFeed.feed_volume_ml}
                      value={consumedVolume}
                      onChange={(e) => setConsumedVolume(Number(e.target.value))}
                      className="w-full h-2 bg-neutral-200 rounded-lg appearance-none cursor-pointer accent-neutral-900"
                    />
                    <div className="flex justify-between text-xs font-bold font-mono text-neutral-500 mt-1">
                      <span>0 ml</span>
                      <span className="text-sm text-neutral-900">{consumedVolume} ml consumed</span>
                      <span>{activeFeed.feed_volume_ml} ml</span>
                    </div>
                  </div>

                  {/* Leftover Feed Warning */}
                  {activeFeed.feed_volume_ml - consumedVolume > 0 ? (
                    <div className="bg-red-50 border border-red-200 p-4 rounded-xl space-y-2">
                      <div className="flex items-center gap-1.5 font-bold text-red-900 text-xs">
                        <AlertTriangle className="h-4 w-4 text-red-600 shrink-0" />
                        <span>LEFTOVER FEED WARNING</span>
                      </div>
                      <p className="text-xs text-red-800 leading-relaxed">
                        There is **{(activeFeed.feed_volume_ml - consumedVolume)}ml** remaining. The UK NHS explicitly advises discarding made-up formula left after a feed. Leftover formula mixed with baby's saliva creates high risk of rapid bacterial growth. Do not save or reheat this mixture.
                      </p>
                    </div>
                  ) : (
                    <div className="bg-emerald-50 border border-emerald-100 p-4 rounded-xl text-xs text-emerald-800 flex items-center gap-2">
                      <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                      <span>Entire feed consumed. No remainder to discard.</span>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Step actions: Prev / Next */}
            <div className="flex items-center justify-between border-t border-neutral-100 pt-6 mt-8">
              {currentStep > 1 && currentStep < 11 ? (
                <button
                  onClick={() => setCurrentStep((prev) => prev - 1)}
                  className="text-xs font-bold text-neutral-600 hover:bg-neutral-100 px-4 py-2.5 rounded-lg border border-neutral-200"
                >
                  Previous Step
                </button>
              ) : (
                <div></div>
              )}

              {currentStep < 11 ? (
                <button
                  onClick={handleNextStep}
                  className="flex items-center gap-1.5 bg-neutral-900 text-white text-xs font-semibold px-5 py-2.5 rounded-lg hover:bg-neutral-800 transition shadow"
                >
                  <span>Next Step</span>
                  <Sparkles className="h-3.5 w-3.5" />
                </button>
              ) : (
                <button
                  onClick={handleFinishFeed}
                  className="bg-neutral-950 text-white text-xs font-bold px-6 py-3 rounded-lg hover:bg-neutral-800 transition shadow"
                >
                  Confirm & Save Traceability Record
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
