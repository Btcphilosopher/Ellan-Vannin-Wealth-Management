/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import {
  FileText,
  Clock,
  User,
  Activity,
  AlertTriangle,
  CornerDownRight,
  PlusCircle,
  HelpCircle
} from "lucide-react";
import { Feed, FeedState } from "../types";

interface FeedHistoryProps {
  feeds: Feed[];
  onUpdateFeeds: (feeds: Feed[]) => void;
}

export const FeedHistory: React.FC<FeedHistoryProps> = ({ feeds, onUpdateFeeds }) => {
  const [selectedFeedId, setSelectedFeedId] = useState<string | null>(null);
  const [correctionText, setCorrectionText] = useState<string>("");
  const [correctionVolume, setCorrectionVolume] = useState<number>(100);
  const [showCorrectionFormId, setShowCorrectionFormId] = useState<string | null>(null);

  const handleApplyCorrection = (feedId: string) => {
    if (!correctionText) return;

    const updated = feeds.map((f) => {
      if (f.feed_id === feedId) {
        return {
          ...f,
          volume_consumed: correctionVolume,
          notes: `${f.notes || ""} [CORRECTION ADDED: ${correctionText} (Adjusted consumed volume to ${correctionVolume}ml)]`
        };
      }
      return f;
    });

    onUpdateFeeds(updated);
    setCorrectionText("");
    setShowCorrectionFormId(null);
  };

  return (
    <div className="space-y-6" id="history-tab">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-neutral-100 pb-4">
        <div>
          <h2 className="text-xl font-bold text-neutral-900 tracking-tight">Audit Trail & Feeding Logs</h2>
          <p className="text-xs text-neutral-500 mt-1">Immutable historic sequence of reconstituted infant formula. Silent editing is locked.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Logs list (Left & Center) */}
        <div className="lg:col-span-2 space-y-4">
          {feeds.length === 0 ? (
            <div className="bg-white border border-neutral-200 p-8 text-center rounded-xl">
              <Clock className="h-8 w-8 text-neutral-300 mx-auto" />
              <p className="text-sm text-neutral-500 mt-2">No historical feeds recorded yet.</p>
            </div>
          ) : (
            feeds.map((f) => {
              const isOpen = selectedFeedId === f.feed_id;
              const hasCorrection = f.notes?.includes("CORRECTION ADDED:");

              return (
                <div
                  key={f.feed_id}
                  className={`bg-white border rounded-xl overflow-hidden shadow-xs transition ${
                    isOpen ? "border-neutral-900" : "border-neutral-200/60 hover:border-neutral-400"
                  }`}
                >
                  {/* Summary row */}
                  <div
                    onClick={() => setSelectedFeedId(isOpen ? null : f.feed_id)}
                    className="p-5 flex items-center justify-between cursor-pointer"
                  >
                    <div className="flex items-center gap-4">
                      <div className="bg-neutral-100 p-2.5 rounded-lg text-neutral-800">
                        <Activity className="h-4 w-4" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-sm font-bold text-neutral-900">
                            {f.volume_consumed !== undefined ? `${f.volume_consumed} ml` : "Incomplete"}
                          </h4>
                          <span className="text-xs text-neutral-400">consumed</span>
                          {hasCorrection && (
                            <span className="text-[9px] font-bold bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded">
                              CORRECTED
                            </span>
                          )}
                          {f.state === FeedState.DISCARDED && (
                            <span className="text-[9px] font-bold bg-red-100 text-red-800 px-1.5 py-0.5 rounded">
                              DISCARDED
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-neutral-400 mt-1">
                          {new Date(f.preparation_started_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} • {f.formula_batch_id}
                        </p>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="text-xs font-semibold text-neutral-600 block">
                        Prepared {f.feed_volume_ml}ml
                      </span>
                      <span className="text-[10px] text-neutral-400 mt-0.5 block">
                        Temp: {f.water_temperature_c?.toFixed(1)}°C
                      </span>
                    </div>
                  </div>

                  {/* Details section */}
                  {isOpen && (
                    <div className="border-t border-neutral-100 bg-neutral-50/50 p-5 space-y-4 text-xs text-neutral-600">
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                        <div>
                          <span className="text-neutral-400 font-medium">Reconstitution Temp</span>
                          <p className="font-bold text-neutral-900 mt-0.5">{f.water_temperature_c?.toFixed(1)}°C</p>
                        </div>
                        <div>
                          <span className="text-neutral-400 font-medium">Powder Measures</span>
                          <p className="font-bold text-neutral-900 mt-0.5">{f.powder_scoops} scoops</p>
                        </div>
                        <div>
                          <span className="text-neutral-400 font-medium">Water Preparation</span>
                          <p className="font-bold text-neutral-900 mt-0.5">{f.water_source || "Cold Tap"}</p>
                        </div>
                        <div>
                          <span className="text-neutral-400 font-medium">Provenance</span>
                          <p className="font-bold text-neutral-900 mt-0.5">{f.provenance}</p>
                        </div>
                      </div>

                      <div className="border-t border-neutral-100/70 pt-3 space-y-1">
                        <span className="text-neutral-400 font-medium">Observed Infant Feeding Cues</span>
                        <div className="flex flex-wrap gap-1.5 mt-1">
                          {f.baby_cues_recorded && f.baby_cues_recorded.length > 0 ? (
                            f.baby_cues_recorded.map((c) => (
                              <span key={c} className="bg-neutral-200/50 text-neutral-700 text-[10px] px-2 py-0.5 rounded-full">
                                {c}
                              </span>
                            ))
                          ) : (
                            <span className="text-[10px] text-neutral-400">No observed cues logged</span>
                          )}
                        </div>
                      </div>

                      {f.notes && (
                        <div className="border-t border-neutral-100/70 pt-3">
                          <span className="text-neutral-400 font-medium">Caregiver Session Notes:</span>
                          <p className="mt-1 leading-relaxed text-neutral-700 bg-white p-2.5 rounded-lg border border-neutral-150">
                            {f.notes}
                          </p>
                        </div>
                      )}

                      {/* Correct historic events buttons */}
                      <div className="border-t border-neutral-100/70 pt-3 flex justify-between items-center">
                        <span className="text-[10px] text-neutral-400">Record Reference ID: {f.feed_id}</span>
                        <button
                          onClick={() => {
                            setCorrectionVolume(f.volume_consumed || 100);
                            setShowCorrectionFormId(showCorrectionFormId === f.feed_id ? null : f.feed_id);
                          }}
                          className="flex items-center gap-1 text-[11px] font-bold text-neutral-900 hover:underline"
                        >
                          <PlusCircle className="h-3.5 w-3.5" />
                          <span>Correction Event</span>
                        </button>
                      </div>

                      {showCorrectionFormId === f.feed_id && (
                        <div className="bg-amber-50/50 border border-amber-200 rounded-xl p-4 space-y-3 mt-3">
                          <h5 className="text-xs font-bold text-amber-900 flex items-center gap-1">
                            <AlertTriangle className="h-3.5 w-3.5 text-amber-600" />
                            <span>Correct Historical Feeding Parameters</span>
                          </h5>
                          <p className="text-[11px] text-amber-800 leading-relaxed">
                            Under safety architecture guidelines, previous data is retained. Your correction notes will be permanently appended as an audit event below.
                          </p>

                          <div className="space-y-3">
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                              <div>
                                <label className="text-[10px] font-bold text-neutral-400 uppercase">Correct Consumed Volume</label>
                                <input
                                  type="number"
                                  value={correctionVolume}
                                  max={f.feed_volume_ml}
                                  onChange={(e) => setCorrectionVolume(Number(e.target.value))}
                                  className="w-full bg-white border border-neutral-200 rounded p-1.5 text-xs text-neutral-800 focus:outline-none"
                                />
                              </div>
                            </div>

                            <textarea
                              value={correctionText}
                              onChange={(e) => setCorrectionText(e.target.value)}
                              placeholder="Reason for historical adjustment..."
                              className="w-full text-xs bg-white border border-neutral-200 rounded p-2 focus:outline-none min-h-[60px]"
                            />

                            <button
                              onClick={() => handleApplyCorrection(f.feed_id)}
                              className="bg-neutral-900 hover:bg-neutral-800 text-white text-[10px] font-bold py-1.5 px-3 rounded"
                            >
                              Append Correction Log
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Audit preservation sidebar */}
        <div className="bg-neutral-50 border border-neutral-200 rounded-2xl p-6 space-y-6 self-start">
          <h3 className="text-sm font-bold uppercase tracking-wider text-neutral-400">Traceability Principles</h3>
          <div className="space-y-4 text-xs text-neutral-600 leading-relaxed">
            <div className="flex items-start gap-2">
              <CornerDownRight className="h-4 w-4 text-neutral-400 shrink-0 mt-0.5" />
              <p>
                <strong>No Silent Overwrites</strong>: To maintain regulatory confidence for health professionals, once a feed enters terminal state, its values cannot be silently mutated.
              </p>
            </div>
            <div className="flex items-start gap-2">
              <CornerDownRight className="h-4 w-4 text-neutral-400 shrink-0 mt-0.5" />
              <p>
                <strong>Recall Isolation</strong>: Recording batch lot numbers against each feed lets families isolate historical feeds immediately if a manufacturer announces a safety recall.
              </p>
            </div>
            <div className="flex items-start gap-2">
              <CornerDownRight className="h-4 w-4 text-neutral-400 shrink-0 mt-0.5" />
              <p>
                <strong>Caregiver Logins</strong>: Every session tracks the registered Caregiver ID who prepared the milk to prevent mixed coordination among multiple helpers.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
