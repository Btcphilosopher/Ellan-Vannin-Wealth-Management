/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import {
  FileText,
  Download,
  AlertTriangle,
  User,
  Heart,
  Plus,
  Trash2,
  Printer
} from "lucide-react";
import { Feed } from "../types";

interface HealthcareExportProps {
  feeds: Feed[];
}

export interface CarePlanEntry {
  id: string;
  hcp_name: string;
  hcp_role: string;
  recommendation: string;
  logged_at: string;
}

export const HealthcareExport: React.FC<HealthcareExportProps> = ({ feeds }) => {
  const [carePlans, setCarePlans] = useState<CarePlanEntry[]>([
    {
      id: "CP-01",
      hcp_name: "Dr. Catherine Vance",
      hcp_role: "Paediatrician",
      recommendation: "Feed 100-130ml of whey-based infant formula stage 1 responsively based on early hunger cues. Do not impose a rigid schedule.",
      logged_at: "2026-09-02T10:00:00Z"
    }
  ]);

  const [hcpName, setHcpName] = useState<string>("");
  const [hcpRole, setHcpRole] = useState<string>("");
  const [recommendationText, setRecommendationText] = useState<string>("");

  const handleAddCarePlan = () => {
    if (!hcpName || !recommendationText) return;

    const newEntry: CarePlanEntry = {
      id: `CP-${Date.now()}`,
      hcp_name: hcpName,
      hcp_role: hcpRole || "Health Professional",
      recommendation: recommendationText,
      logged_at: new Date().toISOString()
    };

    setCarePlans([newEntry, ...carePlans]);
    setHcpName("");
    setHcpRole("");
    setRecommendationText("");
  };

  const handleDeleteCarePlan = (id: string) => {
    setCarePlans(carePlans.filter((cp) => cp.id !== id));
  };

  // CSV Generator
  const handleExportCSV = () => {
    const headers = ["Feed ID", "Started At", "Water Temp (C)", "Water Source", "Formula Product ID", "Batch Code", "Scoops Used", "Volume Prepared (ml)", "Volume Consumed (ml)", "Leftover Volume (ml)", "Caregiver Notes"];
    const rows = feeds.map((f) => [
      f.feed_id,
      f.preparation_started_at,
      f.water_temperature_c?.toFixed(1) || "",
      f.water_source || "",
      f.formula_product_id,
      f.formula_batch_id,
      f.powder_scoops || 0,
      f.feed_volume_ml || 0,
      f.volume_consumed || 0,
      f.volume_remaining || 0,
      f.notes?.replace(/,/g, " ") || ""
    ]);

    const csvContent = "data:text/csv;charset=utf-8,"
      + [headers.join(","), ...rows.map(e => e.join(","))].join("\n");

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Emma_Feeding_Traceability_Export_${new Date().toISOString().split("T")[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // JSON Generator
  const handleExportJSON = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(feeds, null, 2));
    const downloadAnchor = document.createElement("a");
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `Emma_Feeding_Data_Dump_${new Date().toISOString().split("T")[0]}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    document.body.removeChild(downloadAnchor);
  };

  return (
    <div className="space-y-8" id="healthcare-export-tab">
      <div className="border-b border-neutral-100 pb-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-neutral-900 tracking-tight">Healthcare Provider Export Center</h2>
          <p className="text-xs text-neutral-500 mt-1">Export raw feed parameters or manage care plan recommendations for clinics.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-xs font-semibold px-4 py-2 rounded-lg border border-neutral-250 transition"
          >
            <Download className="h-3.5 w-3.5" />
            <span>Export CSV Report</span>
          </button>
          <button
            onClick={handleExportJSON}
            className="flex items-center gap-1.5 bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-xs font-semibold px-4 py-2 rounded-lg border border-neutral-250 transition"
          >
            <Download className="h-3.5 w-3.5" />
            <span>Export Raw JSON</span>
          </button>
        </div>
      </div>

      {/* 1. Legal & Clinical Safety Warnings */}
      <div className="bg-amber-50 border border-amber-200 rounded-2xl p-5 flex items-start gap-4">
        <AlertTriangle className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
        <div className="space-y-2">
          <h4 className="text-xs font-bold text-amber-900 uppercase tracking-wider">Clinical Scope Guardrails</h4>
          <p className="text-xs text-amber-800 leading-relaxed">
            **Baby Formula OS is not a medical device.** This dashboard presents historical data recorded by caregivers. It is not a substitute for professional paediatric diagnostics, advice, or therapy.
          </p>
          <p className="text-xs text-amber-800 leading-relaxed">
            Always contact your paediatrician, midwife, health visitor, or emergency care services if you notice changes in your baby's feeding habits, signs of dehydration, unusual stools, vomiting, or lethargy.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left column: Pediatric care plans manager */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white border border-neutral-200 rounded-2xl p-6 shadow-xs space-y-6">
            <h3 className="text-sm font-bold uppercase tracking-wider text-neutral-400">HCP Recommendations log</h3>

            <div className="space-y-4">
              {carePlans.map((cp) => (
                <div key={cp.id} className="border border-neutral-150 p-4 rounded-xl space-y-3 relative bg-neutral-50/20">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="text-xs font-bold text-neutral-900">{cp.hcp_name}</h4>
                      <span className="text-[10px] text-neutral-400 font-semibold">{cp.hcp_role}</span>
                    </div>
                    <button
                      onClick={() => handleDeleteCarePlan(cp.id)}
                      className="text-neutral-400 hover:text-red-600 transition p-1"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                  <p className="text-xs text-neutral-700 leading-relaxed font-medium bg-white p-3 rounded-lg border border-neutral-100">
                    "{cp.recommendation}"
                  </p>
                  <span className="text-[9px] text-neutral-400 block text-right">
                    Logged: {new Date(cp.logged_at).toLocaleDateString()}
                  </span>
                </div>
              ))}
            </div>

            {/* Add recommendations form */}
            <div className="border-t border-neutral-100 pt-5 space-y-4">
              <h4 className="text-xs font-bold uppercase text-neutral-500">Add Clinic Recommendation</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <input
                  type="text"
                  placeholder="Professional Name (e.g., Dr. Smith)"
                  value={hcpName}
                  onChange={(e) => setHcpName(e.target.value)}
                  className="bg-white border border-neutral-200 p-2 text-xs text-neutral-800 rounded focus:outline-none"
                />
                <input
                  type="text"
                  placeholder="Role (e.g., Pediatrician, Midwife)"
                  value={hcpRole}
                  onChange={(e) => setHcpRole(e.target.value)}
                  className="bg-white border border-neutral-200 p-2 text-xs text-neutral-800 rounded focus:outline-none"
                />
              </div>
              <textarea
                placeholder="Details of the clinic instruction..."
                value={recommendationText}
                onChange={(e) => setRecommendationText(e.target.value)}
                className="w-full text-xs bg-white border border-neutral-200 p-3 min-h-[80px] rounded focus:outline-none"
              />
              <button
                onClick={handleAddCarePlan}
                className="flex items-center gap-1.5 bg-neutral-900 text-white text-xs font-bold py-2 px-4 rounded-lg hover:bg-neutral-800 transition"
              >
                <Plus className="h-4 w-4" />
                <span>Save Clinic Guideline</span>
              </button>
            </div>
          </div>
        </div>

        {/* Clinical stats quickview summary cards */}
        <div className="space-y-6">
          <div className="bg-neutral-50 border border-neutral-200 rounded-2xl p-6 space-y-6">
            <h3 className="text-sm font-bold uppercase tracking-wider text-neutral-400">Export Metrics</h3>

            <div className="space-y-4 text-xs text-neutral-600">
              <div className="flex justify-between items-center border-b border-neutral-200/50 pb-2.5">
                <span>Total Traceable Feeds</span>
                <span className="font-bold text-neutral-950">{feeds.length}</span>
              </div>
              <div className="flex justify-between items-center border-b border-neutral-200/50 pb-2.5">
                <span>Calculated Volume (Consumed)</span>
                <span className="font-bold text-neutral-950">
                  {feeds.reduce((sum, f) => sum + (f.volume_consumed || 0), 0)} ml
                </span>
              </div>
              <div className="flex justify-between items-center pb-2.5">
                <span>Average Preparation Water Temp</span>
                <span className="font-bold text-neutral-950">
                  {(feeds.reduce((sum, f) => sum + (f.water_temperature_c || 0), 0) / (feeds.length || 1)).toFixed(1)}°C
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
