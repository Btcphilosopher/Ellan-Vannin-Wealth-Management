/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  FormulaProduct,
  FormulaFormat,
  FormulaSpecialty,
  FormulaBatch,
  FormulaContainer,
  Bottle,
  BottleState,
  Caregiver,
  CaregiverRole,
  CaregiverPermission,
  BabyProfile,
  Feed,
  FeedState,
  DataProvenance,
  HungerCue,
  WaterType
} from "./types";

// 1. Synthetic Products
export const SYNTHETIC_PRODUCTS: FormulaProduct[] = [
  {
    product_id: "PROD-SYN-STG1",
    brand: "Synthetic First Infant Milk",
    product_name: "Premium Infant Formula Stage 1",
    variant: "Standard Whey-Based First Milk",
    stage: "Stage 1",
    age_range: "0-6 Months",
    format: FormulaFormat.POWDER,
    specialty: FormulaSpecialty.STANDARD,
    manufacturer: "Synthetic Infant Nutrition Ltd",
    country: "UK",
    instructions_version: "2026-STG1-V2",
    scoop: {
      product_id: "PROD-SYN-STG1",
      nominal_volume_ml: 30, // 30ml water per scoop
      nominal_mass_g: 4.3,
      manufacturer: "Synthetic Infant Nutrition Ltd",
      version: "SCP-V1"
    },
    instructions: [
      {
        water_volume_ml: 90,
        powder_scoops: 3,
        powder_mass_g: 12.9,
        final_volume_ml: 100,
        preparation_temperature_c: 70,
        mixing_instruction: "Cover with sterilized cap and shake well for 15 seconds until powder is fully dissolved.",
        cooling_instruction: "Cool immediately under cold running water or in a bowl of cold water.",
        storage_instruction: "Use immediately or refrigerate at <5°C for no more than 24 hours.",
        discard_instruction: "Discard any leftover formula within 2 hours of starting feed."
      },
      {
        water_volume_ml: 120,
        powder_scoops: 4,
        powder_mass_g: 17.2,
        final_volume_ml: 130,
        preparation_temperature_c: 70,
        mixing_instruction: "Cover with sterilized cap and shake well for 15 seconds until powder is fully dissolved.",
        cooling_instruction: "Cool immediately under cold running water or in a bowl of cold water.",
        storage_instruction: "Use immediately or refrigerate at <5°C for no more than 24 hours.",
        discard_instruction: "Discard any leftover formula within 2 hours of starting feed."
      },
      {
        water_volume_ml: 150,
        powder_scoops: 5,
        powder_mass_g: 21.5,
        final_volume_ml: 170,
        preparation_temperature_c: 70,
        mixing_instruction: "Cover with sterilized cap and shake well for 15 seconds until powder is fully dissolved.",
        cooling_instruction: "Cool immediately under cold running water or in a bowl of cold water.",
        storage_instruction: "Use immediately or refrigerate at <5°C for no more than 24 hours.",
        discard_instruction: "Discard any leftover formula within 2 hours of starting feed."
      },
      {
        water_volume_ml: 180,
        powder_scoops: 6,
        powder_mass_g: 25.8,
        final_volume_ml: 200,
        preparation_temperature_c: 70,
        mixing_instruction: "Cover with sterilized cap and shake well for 15 seconds until powder is fully dissolved.",
        cooling_instruction: "Cool immediately under cold running water or in a bowl of cold water.",
        storage_instruction: "Use immediately or refrigerate at <5°C for no more than 24 hours.",
        discard_instruction: "Discard any leftover formula within 2 hours of starting feed."
      }
    ],
    verified: true
  },
  {
    product_id: "PROD-SYN-STG2",
    brand: "Organic Baby Grow",
    product_name: "Gentle Follow-On Formula",
    variant: "Organic Casein-Dominant Follow-On Milk",
    stage: "Stage 2",
    age_range: "6-12 Months",
    format: FormulaFormat.POWDER,
    specialty: FormulaSpecialty.STANDARD,
    manufacturer: "Organic Baby Nutrition Group",
    country: "EU",
    instructions_version: "2026-ORG-V1",
    scoop: {
      product_id: "PROD-SYN-STG2",
      nominal_volume_ml: 30,
      nominal_mass_g: 4.5,
      manufacturer: "Organic Baby Nutrition Group",
      version: "SCP-V2"
    },
    instructions: [
      {
        water_volume_ml: 120,
        powder_scoops: 4,
        powder_mass_g: 18.0,
        final_volume_ml: 130,
        preparation_temperature_c: 70,
        mixing_instruction: "Roll bottle horizontally for 5 seconds, then shake vertically for 10 seconds to reduce foam.",
        cooling_instruction: "Hold lower half of sealed bottle in cold water bowl for 2-3 minutes.",
        storage_instruction: "Keep chilled and use within 24 hours.",
        discard_instruction: "Discard leftovers immediately."
      },
      {
        water_volume_ml: 150,
        powder_scoops: 5,
        powder_mass_g: 22.5,
        final_volume_ml: 170,
        preparation_temperature_c: 70,
        mixing_instruction: "Roll bottle horizontally for 5 seconds, then shake vertically for 10 seconds to reduce foam.",
        cooling_instruction: "Hold lower half of sealed bottle in cold water bowl for 2-3 minutes.",
        storage_instruction: "Keep chilled and use within 24 hours.",
        discard_instruction: "Discard leftovers immediately."
      },
      {
        water_volume_ml: 180,
        powder_scoops: 6,
        powder_mass_g: 27.0,
        final_volume_ml: 200,
        preparation_temperature_c: 70,
        mixing_instruction: "Roll bottle horizontally for 5 seconds, then shake vertically for 10 seconds to reduce foam.",
        cooling_instruction: "Hold lower half of sealed bottle in cold water bowl for 2-3 minutes.",
        storage_instruction: "Keep chilled and use within 24 hours.",
        discard_instruction: "Discard leftovers immediately."
      }
    ],
    verified: true
  },
  {
    product_id: "PROD-SYN-AR",
    brand: "MediCare Infant Special",
    product_name: "Anti-Reflux Thickened Formula",
    variant: "Starch-Thickened Anti-Regurgitation Formula",
    stage: "Specialty",
    age_range: "0-12 Months",
    format: FormulaFormat.POWDER,
    specialty: FormulaSpecialty.ANTI_REFLUX,
    manufacturer: "MediCare Pharma Specialties",
    country: "UK",
    instructions_version: "2026-MC-AR-V3",
    scoop: {
      product_id: "PROD-SYN-AR",
      nominal_volume_ml: 30,
      nominal_mass_g: 4.4,
      manufacturer: "MediCare Pharma Specialties",
      version: "SCP-AR"
    },
    instructions: [
      {
        water_volume_ml: 90,
        powder_scoops: 3,
        powder_mass_g: 13.2,
        final_volume_ml: 100,
        preparation_temperature_c: 70,
        mixing_instruction: "CRITICAL: Leave boiled water to stand for exactly 15 minutes before mixing to let starch activate. Shake vigorously.",
        cooling_instruction: "Cool slowly at room temperature, then finish in cold water.",
        storage_instruction: "Prepare fresh on-demand. Do not refrigerate or pre-make this specialty formula.",
        discard_instruction: "Discard immediately after feed starts."
      },
      {
        water_volume_ml: 120,
        powder_scoops: 4,
        powder_mass_g: 17.6,
        final_volume_ml: 130,
        preparation_temperature_c: 70,
        mixing_instruction: "CRITICAL: Leave boiled water to stand for exactly 15 minutes before mixing to let starch activate. Shake vigorously.",
        cooling_instruction: "Cool slowly at room temperature, then finish in cold water.",
        storage_instruction: "Prepare fresh on-demand. Do not refrigerate or pre-make this specialty formula.",
        discard_instruction: "Discard immediately after feed starts."
      }
    ],
    verified: false // Demonstration of an unverified formula packaging scanner
  },
  {
    product_id: "PROD-RTF-MILK",
    brand: "Synthetic First Infant Milk",
    product_name: "Ready-To-Feed First Infant Liquid",
    variant: "Ready to Feed Liquid Formula",
    stage: "Stage 1",
    age_range: "0-6 Months",
    format: FormulaFormat.READY_TO_FEED,
    specialty: FormulaSpecialty.STANDARD,
    manufacturer: "Synthetic Infant Nutrition Ltd",
    country: "UK",
    instructions_version: "2026-RTF-V1",
    scoop: {
      product_id: "PROD-RTF-MILK",
      nominal_volume_ml: 0,
      nominal_mass_g: 0,
      manufacturer: "Synthetic Infant Nutrition Ltd",
      version: "NONE"
    },
    instructions: [
      {
        water_volume_ml: 0,
        powder_scoops: 0,
        powder_mass_g: 0,
        final_volume_ml: 200,
        preparation_temperature_c: 20, // Room temperature preparation
        mixing_instruction: "Shake bottle container vigorously before opening. Pour desired quantity directly into sterilized feed bottle.",
        cooling_instruction: "No cooling required unless warmed. Feed at room temperature.",
        storage_instruction: "Once opened, recap container immediately and store in refrigerator (<5°C) for up to 24 hours.",
        discard_instruction: "Discard unused portion left in feed bottle after 1 hour."
      }
    ],
    verified: true
  }
];

// 2. Synthetic Initial Batches
export const SYNTHETIC_BATCHES: FormulaBatch[] = [
  {
    batch_id: "SYN-2026-001",
    product_id: "PROD-SYN-STG1",
    lot_code: "L12046-A",
    expiry_date: "2027-12-31",
    recalled: false
  },
  {
    batch_id: "SYN-2026-RECALL", // Demonstrates recalled batch safety checks
    product_id: "PROD-SYN-STG1",
    lot_code: "SYN-2026-001", // Match user instructions lot
    expiry_date: "2026-10-30",
    recalled: true,
    recall_reason: "Precautionary recall issued due to potential physical sealing failure at packaging line B."
  },
  {
    batch_id: "ORG-2026-003",
    product_id: "PROD-SYN-STG2",
    lot_code: "L8932-B",
    expiry_date: "2027-06-15",
    recalled: false
  },
  {
    batch_id: "AR-2026-009",
    product_id: "PROD-SYN-AR",
    lot_code: "L5521-E",
    expiry_date: "2026-05-01", // Demonstrates EXPIRED batch safety check
    recalled: false
  }
];

// 3. Synthetic Initial Containers
export const SYNTHETIC_CONTAINERS: FormulaContainer[] = [
  {
    container_id: "CONT-001",
    batch_id: "SYN-2026-001",
    product_id: "PROD-SYN-STG1",
    opened_at: "2026-09-01T08:00:00Z",
    is_opened: true,
    remaining_quantity_g: 350,
    capacity_g: 800
  },
  {
    container_id: "CONT-002",
    batch_id: "SYN-2026-RECALL",
    product_id: "PROD-SYN-STG1",
    opened_at: undefined,
    is_opened: false,
    remaining_quantity_g: 800,
    capacity_g: 800
  },
  {
    container_id: "CONT-003",
    batch_id: "ORG-2026-003",
    product_id: "PROD-SYN-STG2",
    opened_at: "2026-09-10T10:00:00Z",
    is_opened: true,
    remaining_quantity_g: 620,
    capacity_g: 800
  }
];

// 4. Standard Sterile Bottles
export const SYNTHETIC_BOTTLES: Bottle[] = [
  {
    bottle_id: "BTL-001",
    name: "Classic Anti-Colic 150ml",
    capacity_ml: 150,
    material: "Plastic (BPA-Free)",
    manufacturer: "Aventi Baby",
    sterility_state: BottleState.STERILISED,
    last_cleaned_at: "2026-09-14T08:00:00Z",
    last_sterilised_at: "2026-09-14T08:30:00Z",
    usage_count: 42
  },
  {
    bottle_id: "BTL-002",
    name: "Pure Glass 240ml",
    capacity_ml: 240,
    material: "Borosilicate Glass",
    manufacturer: "EcoPure Infant",
    sterility_state: BottleState.STERILISED,
    last_cleaned_at: "2026-09-14T09:00:00Z",
    last_sterilised_at: "2026-09-14T09:45:00Z",
    usage_count: 18
  },
  {
    bottle_id: "BTL-003",
    name: "EasyLatch Slim 120ml",
    capacity_ml: 120,
    material: "Plastic (BPA-Free)",
    manufacturer: "FirstYears",
    sterility_state: BottleState.DIRTY,
    last_cleaned_at: "2026-09-13T21:00:00Z",
    usage_count: 85
  },
  {
    bottle_id: "BTL-004",
    name: "Smart-Temp Sensor Bottle 200ml",
    capacity_ml: 200,
    material: "Plastic (Premium Co-Polyester)",
    manufacturer: "SmartInfant IoT",
    sterility_state: BottleState.WASHING,
    last_cleaned_at: undefined,
    usage_count: 5
  }
];

// 5. Initial Profiles and Caregivers
export const MASTER_BABY: BabyProfile = {
  baby_id: "BABY-EMMA",
  display_name: "Emma",
  date_of_birth: "2026-06-15",
  feeding_method: "Infant Formula",
  formula_products: ["PROD-SYN-STG1"]
};

export const MASTER_CAREGIVER: Caregiver = {
  caregiver_id: "CG-ALEX",
  display_name: "Alex",
  role: CaregiverRole.PARENT,
  permissions: [
    CaregiverPermission.VIEW,
    CaregiverPermission.PREPARE,
    CaregiverPermission.RECORD,
    CaregiverPermission.EDIT,
    CaregiverPermission.ADMIN
  ]
};

// 6. Chronological Feed History Seeds
export const SYNTHETIC_FEED_HISTORY: Feed[] = [
  {
    feed_id: "FEED-001",
    baby_id: "BABY-EMMA",
    formula_product_id: "PROD-SYN-STG1",
    formula_batch_id: "SYN-2026-001",
    formula_container_id: "CONT-001",
    bottle_id: "BTL-001",
    state: FeedState.COMPLETED,
    preparation_started_at: "2026-09-14T07:10:00Z",
    water_added_at: "2026-09-14T07:12:00Z",
    powder_added_at: "2026-09-14T07:13:00Z",
    mixed_at: "2026-09-14T07:14:00Z",
    cooling_started_at: "2026-09-14T07:15:00Z",
    ready_at: "2026-09-14T07:22:00Z",
    feeding_started_at: "2026-09-14T07:24:00Z",
    feeding_finished_at: "2026-09-14T07:41:00Z",
    water_temperature_c: 72.4,
    reconstitution_temp_verified: true,
    feed_volume_ml: 130, // 120ml water + 4 scoops
    powder_scoops: 4,
    powder_mass_g: 17.2,
    preparation_method: "MANUAL",
    water_source: WaterType.FRESH_COLD_TAP,
    volume_offered: 130,
    volume_consumed: 110,
    volume_remaining: 20,
    baby_cues_recorded: [HungerCue.ROOTING, HungerCue.SATISFIED],
    caregiver_id: "CG-ALEX",
    notes: "Woke up very hungry. Fed well, paused once, fell asleep satisfied with 20ml leftover.",
    provenance: DataProvenance.MEASURED
  },
  {
    feed_id: "FEED-002",
    baby_id: "BABY-EMMA",
    formula_product_id: "PROD-SYN-STG1",
    formula_batch_id: "SYN-2026-001",
    formula_container_id: "CONT-001",
    bottle_id: "BTL-002",
    state: FeedState.COMPLETED,
    preparation_started_at: "2026-09-14T10:15:00Z",
    water_added_at: "2026-09-14T10:16:00Z",
    powder_added_at: "2026-09-14T10:18:00Z",
    mixed_at: "2026-09-14T10:19:00Z",
    cooling_started_at: "2026-09-14T10:20:00Z",
    ready_at: "2026-09-14T10:28:00Z",
    feeding_started_at: "2026-09-14T10:30:00Z",
    feeding_finished_at: "2026-09-14T10:45:00Z",
    water_temperature_c: 71.1,
    reconstitution_temp_verified: true,
    feed_volume_ml: 100, // 90ml water + 3 scoops
    powder_scoops: 3,
    powder_mass_g: 12.9,
    preparation_method: "MANUAL",
    water_source: WaterType.FRESH_COLD_TAP,
    volume_offered: 100,
    volume_consumed: 100,
    volume_remaining: 0,
    baby_cues_recorded: [HungerCue.HAND_TO_MOUTH, HungerCue.SATISFIED],
    caregiver_id: "CG-ALEX",
    notes: "Consumed entire bottle rapidly. Responsive signals clear.",
    provenance: DataProvenance.MEASURED
  }
];
