/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  Jurisdiction,
  Severity,
  SafetyRule,
  FeedState,
  Feed,
  Bottle,
  BottleState,
  FormulaProduct,
  FormulaBatch,
  GuidelineSource
} from "../types";

// Authoritative sources definitions
export const GUIDELINE_SOURCES: GuidelineSource[] = [
  {
    id: "UK_NHS_2026",
    jurisdiction: Jurisdiction.UK,
    source: "National Health Service (NHS) - Preparing infant formula",
    source_url: "https://www.nhs.uk/conditions/baby/breastfeeding-and-bottle-feeding/bottle-feeding/making-up-single-feed/",
    effective_date: "2026-01-01",
    review_date: "2028-01-01",
    version: "2026.1"
  },
  {
    id: "WHO_FAO_2007",
    jurisdiction: Jurisdiction.WHO,
    source: "World Health Organization (WHO) - Safe preparation, storage and handling of powdered infant formula",
    source_url: "https://www.who.int/publications/i/item/9789241595414",
    effective_date: "2007-01-01",
    review_date: "2027-01-01",
    version: "1.0"
  },
  {
    id: "US_CDC_2026",
    jurisdiction: Jurisdiction.US,
    source: "Centers for Disease Control and Prevention (CDC) - Infant Formula Preparation and Storage",
    source_url: "https://www.cdc.gov/nutrition/infantandtoddlernutrition/formula-feeding/infant-formula-preparation-and-storage.html",
    effective_date: "2026-01-01",
    review_date: "2028-01-01",
    version: "2026.1"
  }
];

export const SAFETY_RULES: SafetyRule[] = [
  // 1. UK RULES
  {
    rule_id: "UK_PIF_RECONSTITUTION_MIN_TEMP",
    jurisdiction: Jurisdiction.UK,
    source: "NHS Guidance",
    source_url: "https://www.nhs.uk/conditions/baby/breastfeeding-and-bottle-feeding/bottle-feeding/making-up-single-feed/",
    effective_date: "2026-01-01",
    review_date: "2028-01-01",
    severity: Severity.HIGH,
    rule_text: "Freshly boiled water cooled for no more than 30 minutes must be at least 70°C when powder is added to kill any harmful bacteria.",
    machine_testable_condition: "water_temperature_c >= 70",
    min_reconstitution_temp_c: 70
  },
  {
    rule_id: "UK_FRESH_WATER_REQUIRED",
    jurisdiction: Jurisdiction.UK,
    source: "NHS Guidance",
    source_url: "https://www.nhs.uk/conditions/baby/breastfeeding-and-bottle-feeding/bottle-feeding/making-up-single-feed/",
    effective_date: "2026-01-01",
    review_date: "2028-01-01",
    severity: Severity.WARNING,
    rule_text: "Use fresh tap water from the cold tap. Do not use artificially softened water or water that has been boiled before.",
    machine_testable_condition: "water_source === 'FRESH_COLD_TAP' && reboiled_water === false",
    fresh_water_required: true,
    reboiled_water_allowed: false
  },
  {
    rule_id: "UK_WATER_FIRST",
    jurisdiction: Jurisdiction.UK,
    source: "NHS Guidance",
    source_url: "https://www.nhs.uk/conditions/baby/breastfeeding-and-bottle-feeding/bottle-feeding/making-up-single-feed/",
    effective_date: "2026-01-01",
    review_date: "2028-01-01",
    severity: Severity.CRITICAL,
    rule_text: "Water must be added to the sterilised bottle first, before adding the powdered formula. This ensures correct dilution and temperature safety.",
    machine_testable_condition: "water_added_before_powder === true",
    water_first: true
  },
  {
    rule_id: "UK_LEFTOVER_FEED_DISCARD",
    jurisdiction: Jurisdiction.UK,
    source: "NHS Guidance",
    source_url: "https://www.nhs.uk/conditions/baby/breastfeeding-and-bottle-feeding/bottle-feeding/making-up-single-feed/",
    effective_date: "2026-01-01",
    review_date: "2028-01-01",
    severity: Severity.CRITICAL,
    rule_text: "Discard any leftover formula immediately after a feed. Leftover formula mixed with baby's saliva creates a high risk of bacterial growth.",
    machine_testable_condition: "volume_remaining > 0 -> discarded_at !== null",
    leftover_feed_discard: true
  },
  {
    rule_id: "UK_MANUFACTURER_INSTRUCTIONS_REQUIRED",
    jurisdiction: Jurisdiction.UK,
    source: "NHS Guidance",
    source_url: "https://www.nhs.uk/conditions/baby/breastfeeding-and-bottle-feeding/bottle-feeding/making-up-single-feed/",
    effective_date: "2026-01-01",
    review_date: "2028-01-01",
    severity: Severity.CRITICAL,
    rule_text: "Follow the manufacturer's exact proportions on the packaging. Adding extra powder can cause constipation/dehydration; too little can cause malnutrition.",
    machine_testable_condition: "proportions_match_manufacturer === true",
    manufacturer_instructions_required: true
  },

  // 2. WHO RULES
  {
    rule_id: "WHO_PIF_RECONSTITUTION_TEMP",
    jurisdiction: Jurisdiction.WHO,
    source: "WHO Guidelines 2007",
    source_url: "https://www.who.int/publications/i/item/9789241595414",
    effective_date: "2007-01-01",
    review_date: "2027-01-01",
    severity: Severity.HIGH,
    rule_text: "Reconstitute powdered infant formula with water no cooler than 70°C to eliminate Cronobacter sakazakii and Salmonella.",
    machine_testable_condition: "water_temperature_c >= 70",
    min_reconstitution_temp_c: 70
  },
  {
    rule_id: "WHO_STORAGE_LIMITS",
    jurisdiction: Jurisdiction.WHO,
    source: "WHO Guidelines 2007",
    source_url: "https://www.who.int/publications/i/item/9789241595414",
    effective_date: "2007-01-01",
    review_date: "2027-01-01",
    severity: Severity.HIGH,
    rule_text: "Prepared formula must be consumed or refrigerated immediately. Do not keep prepared feeds at room temperature for more than 2 hours.",
    machine_testable_condition: "room_temp_storage_hours <= 2",
    max_room_temp_storage_hours: 2,
    max_fridge_storage_hours: 24
  },

  // 3. US CDC RULES
  {
    rule_id: "US_CDC_RECONSTITUTION_TEMP_CRITERIA",
    jurisdiction: Jurisdiction.US,
    source: "US CDC Guidance",
    source_url: "https://www.cdc.gov/nutrition/infantandtoddlernutrition/formula-feeding/infant-formula-preparation-and-storage.html",
    effective_date: "2026-01-01",
    review_date: "2028-01-01",
    severity: Severity.HIGH,
    rule_text: "For infants under 3 months, born prematurely, or with weakened immune systems, water must be heated to at least 70°C and cooled slightly before adding powder.",
    machine_testable_condition: "vulnerable_baby -> water_temperature_c >= 70",
    min_reconstitution_temp_c: 70
  },
  {
    rule_id: "US_CDC_FEEDING_DURATION_LIMIT",
    jurisdiction: Jurisdiction.US,
    source: "US CDC Guidance",
    source_url: "https://www.cdc.gov/nutrition/infantandtoddlernutrition/formula-feeding/infant-formula-preparation-and-storage.html",
    effective_date: "2026-01-01",
    review_date: "2028-01-01",
    severity: Severity.HIGH,
    rule_text: "Use prepared formula within 2 hours of preparation and within 1 hour from when feeding starts. Discard any remaining.",
    machine_testable_condition: "feeding_duration_hours <= 1",
    max_room_temp_storage_hours: 2
  }
];

// Structural validator classes
export class SafetyRulesEngine {
  static getRulesForJurisdiction(jurisdiction: Jurisdiction): SafetyRule[] {
    return SAFETY_RULES.filter((rule) => rule.jurisdiction === jurisdiction);
  }

  static getRule(ruleId: string): SafetyRule | undefined {
    return SAFETY_RULES.find((rule) => rule.rule_id === ruleId);
  }
}

export class PreparationValidator {
  /**
   * Validates if the water temp matches the reconstitution safety rules
   */
  static validateWaterTemp(
    tempC: number,
    jurisdiction: Jurisdiction
  ): { valid: boolean; message: string; ruleId?: string; source?: string } {
    const rules = SafetyRulesEngine.getRulesForJurisdiction(jurisdiction);
    const tempRule = rules.find((r) => r.min_reconstitution_temp_c !== undefined);

    if (tempRule && tempRule.min_reconstitution_temp_c) {
      if (tempC < tempRule.min_reconstitution_temp_c) {
        return {
          valid: false,
          message: `Water temperature recorded at ${tempC.toFixed(1)}°C. The selected ${jurisdiction} preparation rule requires at least ${tempRule.min_reconstitution_temp_c}°C when powdered formula is added to ensure sterility. Do not proceed using this preparation state.`,
          ruleId: tempRule.rule_id,
          source: tempRule.source
        };
      }
    }

    return {
      valid: true,
      message: "Reconstitution water temperature check passed."
    };
  }

  /**
   * Validates water/powder sequence
   */
  static validateSequence(
    waterAddedFirst: boolean,
    jurisdiction: Jurisdiction
  ): { valid: boolean; message: string; ruleId?: string } {
    const rules = SafetyRulesEngine.getRulesForJurisdiction(jurisdiction);
    const seqRule = rules.find((r) => r.water_first === true);

    if (seqRule && !waterAddedFirst) {
      return {
        valid: false,
        message: "SEQUENCE ERROR: Standard guidelines state water must always be added to the bottle before adding powder. Adding powder first can alter the volumetric measurement and lead to incorrect mixing concentration.",
        ruleId: seqRule.rule_id
      };
    }

    return {
      valid: true,
      message: "Preparation sequence validated."
    };
  }
}

export class TemperatureValidator {
  /**
   * Verifies feeding temperature.
   * Feeds should generally be body temperature ~36-37C or cooler.
   * Max feeding temperature should never exceed 40C to avoid burning baby's mouth.
   */
  static validateFeedingTemp(tempC: number): { valid: boolean; message: string } {
    if (tempC > 40) {
      return {
        valid: false,
        message: `CRITICAL: The mixture temperature is ${tempC.toFixed(1)}°C. This is too hot! Formula must be cooled down to body temperature (around 37°C or room temp) before feeding. Run the sealed bottle under cool running tap water.`
      };
    }
    if (tempC > 38) {
      return {
        valid: true,
        message: `Notice: Feed is warm (${tempC.toFixed(1)}°C). Ensure you test a drop on the inside of your wrist before giving it to the baby.`
      };
    }
    return {
      valid: true,
      message: "Feeding temperature is safe (below 38°C)."
    };
  }
}

export class StorageValidator {
  /**
   * Evaluates storage time limits based on location and preparation timestamp.
   */
  static validateStorage(
    prepTimeStr: string,
    storageLocation: "ROOM_TEMPERATURE" | "REFRIGERATOR" | "COOL_BAG" | "INSULATED_CONTAINER",
    jurisdiction: Jurisdiction
  ): { valid: boolean; timeRemainingMinutes: number; message: string } {
    const prepDate = new Date(prepTimeStr);
    const now = new Date();
    const elapsedMs = now.getTime() - prepDate.getTime();
    const elapsedHours = elapsedMs / (1000 * 60 * 60);

    // Default parameters if no specific rule matched
    let maxHours = 2; // Room temp limit
    if (storageLocation === "REFRIGERATOR") {
      maxHours = 24; // standard max fridge holding
    } else if (storageLocation === "COOL_BAG") {
      maxHours = 4;
    } else if (storageLocation === "INSULATED_CONTAINER") {
      maxHours = 4;
    }

    const rules = SafetyRulesEngine.getRulesForJurisdiction(jurisdiction);
    const storageRule = rules.find((r) => r.max_room_temp_storage_hours !== undefined);

    if (storageRule) {
      if (storageLocation === "ROOM_TEMPERATURE" && storageRule.max_room_temp_storage_hours) {
        maxHours = storageRule.max_room_temp_storage_hours;
      }
      if (storageLocation === "REFRIGERATOR" && storageRule.max_fridge_storage_hours) {
        maxHours = storageRule.max_fridge_storage_hours;
      }
    }

    const totalMinutesLimit = maxHours * 60;
    const elapsedMinutes = elapsedMs / (1000 * 60);
    const timeRemainingMinutes = Math.max(0, totalMinutesLimit - elapsedMinutes);

    if (elapsedHours > maxHours) {
      return {
        valid: false,
        timeRemainingMinutes: 0,
        message: `EXPIRED: Prepared feed has been held for ${elapsedHours.toFixed(1)} hours in ${storageLocation}. The safety limit is ${maxHours} hours. Discard the feed immediately.`
      };
    }

    return {
      valid: true,
      timeRemainingMinutes,
      message: `Safe storage. Remaining safe storage limit is ${timeRemainingMinutes.toFixed(0)} minutes in ${storageLocation}.`
    };
  }
}

export class FormulaInstructionValidator {
  /**
   * Validates that the measured water and powder amounts match a verified instruction step.
   * Adds warning if users arbitrarily change proportions.
   */
  static validateProportions(
    product: FormulaProduct,
    waterVolumeMl: number,
    scoops: number
  ): { valid: boolean; expectedScoops?: number; message: string } {
    // Look for matching water volume
    const matchingInstruction = product.instructions.find(
      (inst) => inst.water_volume_ml === waterVolumeMl
    );

    if (!matchingInstruction) {
      // Find closest standard water volume
      const standardVolumes = product.instructions.map((i) => i.water_volume_ml).join(", ");
      return {
        valid: false,
        message: `UNSUPPORTED VOLUME: The water amount of ${waterVolumeMl}ml is not a standard discrete preparation size for this product. Valid options are: ${standardVolumes}ml. Do not invent custom intermediate ratios.`
      };
    }

    if (matchingInstruction.powder_scoops !== scoops) {
      return {
        valid: false,
        expectedScoops: matchingInstruction.powder_scoops,
        message: `DILUTION WARNING: For ${waterVolumeMl}ml of water, the manufacturer instructions explicitly require exactly ${matchingInstruction.powder_scoops} scoops of powder. You have selected ${scoops} scoops. Adding extra or fewer scoops violates safety guidelines and can harm the infant.`
      };
    }

    return {
      valid: true,
      message: "Proportions match manufacturer instructions."
    };
  }
}

export class BottleSterilityState {
  static canUseBottle(bottle: Bottle): { usable: boolean; reason?: string } {
    if (bottle.sterility_state !== BottleState.STERILISED) {
      return {
        usable: false,
        reason: `The selected bottle '${bottle.name}' is currently in state '${bottle.sterility_state}'. Only bottles marked 'STERILISED' can be used for feed preparation.`
      };
    }
    return { usable: true };
  }
}

export class FeedLifecycleValidator {
  /**
   * Deterministic State Machine Transitions
   * Fails if transition is invalid.
   */
  static validateTransition(
    currentState: FeedState,
    nextState: FeedState
  ): { allowed: boolean; message?: string } {
    // If they are in the same state, it is fine
    if (currentState === nextState) return { allowed: true };

    // Terminal states can NEVER transition to any other state
    const terminalStates = [
      FeedState.COMPLETED,
      FeedState.DISCARDED,
      FeedState.EXPIRED,
      FeedState.ABANDONED,
      FeedState.INVALIDATED
    ];
    if (terminalStates.includes(currentState)) {
      return {
        allowed: false,
        message: `State machine error: Cannot transition from terminal state '${currentState}' to '${nextState}'. This feed lifecycle has already ended.`
      };
    }

    // Define valid edges
    const allowedTransitions: Record<FeedState, FeedState[]> = {
      [FeedState.PLANNED]: [FeedState.PREPARING, FeedState.DISCARDED, FeedState.ABANDONED],
      [FeedState.PREPARING]: [FeedState.WATER_ADDED, FeedState.DISCARDED, FeedState.ABANDONED],
      [FeedState.WATER_ADDED]: [FeedState.POWDER_ADDED, FeedState.DISCARDED, FeedState.ABANDONED],
      [FeedState.POWDER_ADDED]: [FeedState.MIXED, FeedState.DISCARDED, FeedState.ABANDONED],
      [FeedState.MIXED]: [FeedState.COOLING, FeedState.DISCARDED, FeedState.ABANDONED],
      [FeedState.COOLING]: [FeedState.READY, FeedState.DISCARDED, FeedState.EXPIRED],
      [FeedState.READY]: [FeedState.FEEDING, FeedState.DISCARDED, FeedState.EXPIRED],
      [FeedState.FEEDING]: [FeedState.COMPLETED, FeedState.DISCARDED, FeedState.INVALIDATED],
      
      // Terminals can't move
      [FeedState.COMPLETED]: [],
      [FeedState.DISCARDED]: [],
      [FeedState.EXPIRED]: [],
      [FeedState.ABANDONED]: [],
      [FeedState.INVALIDATED]: []
    };

    const targets = allowedTransitions[currentState] || [];
    if (targets.includes(nextState)) {
      return { allowed: true };
    }

    return {
      allowed: false,
      message: `Invalid state transition: Cannot change feed state from '${currentState}' straight to '${nextState}'. It must follow the exact preparation computational chain.`
    };
  }
}
