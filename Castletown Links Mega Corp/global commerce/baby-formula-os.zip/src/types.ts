/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// 1. Core State Enums
export enum FeedState {
  PLANNED = "PLANNED",
  PREPARING = "PREPARING",
  WATER_ADDED = "WATER_ADDED",
  POWDER_ADDED = "POWDER_ADDED",
  MIXED = "MIXED",
  COOLING = "COOLING",
  READY = "READY",
  FEEDING = "FEEDING",
  COMPLETED = "COMPLETED",
  // Terminal failures or exceptions
  DISCARDED = "DISCARDED",
  EXPIRED = "EXPIRED",
  ABANDONED = "ABANDONED",
  INVALIDATED = "INVALIDATED"
}

export enum Jurisdiction {
  UK = "UK",
  EU = "EU",
  US = "US",
  WHO = "WHO",
  CUSTOM = "CUSTOM"
}

export enum Severity {
  INFO = "INFO",
  NOTICE = "NOTICE",
  WARNING = "WARNING",
  HIGH = "HIGH",
  CRITICAL = "CRITICAL"
}

export enum FormulaFormat {
  POWDER = "POWDER",
  READY_TO_FEED = "READY_TO_FEED"
}

export enum FormulaSpecialty {
  STANDARD = "STANDARD",
  ANTI_REFLUX = "ANTI_REFLUX",
  HYDROLYSED = "HYDROLYSED",
  AMINO_ACID = "AMINO_ACID",
  PRETERM = "PRETERM",
  SPECIALIST = "SPECIALIST",
  OTHER = "OTHER"
}

export enum TemperatureUnit {
  C = "C",
  F = "F"
}

export enum TemperatureSource {
  MANUAL = "MANUAL",
  BLUETOOTH_THERMOMETER = "BLUETOOTH_THERMOMETER",
  SMART_BOTTLE = "SMART_BOTTLE",
  FORMULA_MACHINE = "FORMULA_MACHINE",
  IMPORTED = "IMPORTED"
}

export enum BottleState {
  CLEAN = "CLEAN",
  DIRTY = "DIRTY",
  WASHING = "WASHING",
  STERILISED = "STERILISED",
  IN_USE = "IN_USE",
  QUARANTINED = "QUARANTINED",
  RETIRED = "RETIRED"
}

export enum SterilisationMethod {
  STEAM = "STEAM",
  BOILING = "BOILING",
  COLD_WATER = "COLD_WATER",
  OTHER = "OTHER"
}

export enum CaregiverRole {
  PARENT = "PARENT",
  PARTNER = "PARTNER",
  GRANDPARENT = "GRANDPARENT",
  NANNY = "NANNY",
  HEALTHCARE_PROFESSIONAL = "HEALTHCARE_PROFESSIONAL",
  OTHER = "OTHER"
}

export enum CaregiverPermission {
  VIEW = "VIEW",
  PREPARE = "PREPARE",
  RECORD = "RECORD",
  EDIT = "EDIT",
  ADMIN = "ADMIN"
}

export enum WaterType {
  FRESH_COLD_TAP = "FRESH_COLD_TAP",
  BOTTLED = "BOTTLED",
  FILTERED = "FILTERED",
  OTHER = "OTHER"
}

export enum DataProvenance {
  MEASURED = "MEASURED",
  MANUFACTURER = "MANUFACTURER",
  HEALTHCARE_PROFESSIONAL = "HEALTHCARE_PROFESSIONAL",
  USER_ENTERED = "USER_ENTERED",
  OCR = "OCR",
  SENSOR = "SENSOR",
  CALCULATED = "CALCULATED",
  ESTIMATED = "ESTIMATED",
  SYNTHETIC = "SYNTHETIC"
}

export enum HungerCue {
  HUNGER_CUE = "HUNGER_CUE",
  ROOTING = "ROOTING",
  HAND_TO_MOUTH = "HAND_TO_MOUTH",
  FUSSING = "FUSSING",
  PAUSE = "PAUSE",
  TURNING_AWAY = "TURNING_AWAY",
  STOPPING = "STOPPING",
  SATISFIED = "SATISFIED"
}

// 2. Data Interfaces
export interface GuidelineSource {
  id: string;
  jurisdiction: Jurisdiction;
  source: string;
  source_url: string;
  effective_date: string;
  review_date: string;
  version: string;
}

export interface SafetyRule {
  rule_id: string;
  jurisdiction: Jurisdiction;
  source: string;
  source_url: string;
  effective_date: string;
  review_date: string;
  severity: Severity;
  rule_text: string;
  machine_testable_condition: string;
  // Parameter values
  min_reconstitution_temp_c?: number;
  fresh_water_required?: boolean;
  reboiled_water_allowed?: boolean;
  water_first?: boolean;
  manufacturer_instructions_required?: boolean;
  leftover_feed_discard?: boolean;
  max_room_temp_storage_hours?: number;
  max_fridge_storage_hours?: number;
}

export interface FormulaScoop {
  product_id: string;
  nominal_volume_ml: number; // e.g. how much water per scoop, standard is usually 30ml
  nominal_mass_g: number;
  manufacturer: string;
  version: string;
}

export interface FormulaInstruction {
  water_volume_ml: number;
  powder_scoops: number;
  powder_mass_g: number;
  final_volume_ml: number;
  preparation_temperature_c: number;
  mixing_instruction: string;
  cooling_instruction: string;
  storage_instruction: string;
  discard_instruction: string;
  special_notes?: string;
}

export interface FormulaProduct {
  product_id: string;
  brand: string;
  product_name: string;
  variant: string; // standard, anti-reflux, hydrolysed, amino acid, etc.
  stage: string; // e.g. "Stage 1", "Stage 2"
  age_range: string;
  format: FormulaFormat;
  specialty: FormulaSpecialty;
  manufacturer: string;
  country: string;
  instructions_version: string;
  instructions: FormulaInstruction[]; // List of valid volume preparation sizes
  scoop: FormulaScoop;
  verified: boolean; // Flag to indicate if instructions are user-verified against packaging
}

export interface FormulaBatch {
  batch_id: string; // e.g. "SYN-2026-001"
  product_id: string;
  lot_code: string;
  expiry_date: string;
  recalled: boolean;
  recall_reason?: string;
}

export interface FormulaContainer {
  container_id: string;
  batch_id: string;
  product_id: string;
  opened_at?: string; // date opened
  is_opened: boolean;
  remaining_quantity_g: number;
  capacity_g: number;
}

export interface FormulaInventory {
  containers: FormulaContainer[];
  batches: FormulaBatch[];
  products: FormulaProduct[];
}

export interface Bottle {
  bottle_id: string;
  name: string; // e.g. "Bottle #1"
  capacity_ml: number;
  material: string; // glass, plastic
  manufacturer: string;
  sterility_state: BottleState;
  last_cleaned_at?: string;
  last_sterilised_at?: string;
  usage_count: number;
}

export interface SterilisationSession {
  session_id: string;
  started_at: string;
  completed_at?: string;
  method: SterilisationMethod;
  bottles_included: string[]; // bottle_ids
  duration_minutes: number;
}

export interface TemperatureReading {
  value: number;
  unit: TemperatureUnit;
  timestamp: string;
  source: TemperatureSource;
  sensor_id?: string;
  confidence: number; // 0.0 to 1.0
  precision?: number; // e.g. 0.1
  accuracy?: number; // e.g. 0.5
}

export interface Caregiver {
  caregiver_id: string;
  display_name: string;
  role: CaregiverRole;
  permissions: CaregiverPermission[];
}

export interface BabyProfile {
  baby_id: string;
  display_name: string;
  date_of_birth: string;
  feeding_method: string;
  formula_products: string[]; // product_ids
}

export interface PreparationChecklist {
  hands_clean: boolean;
  surface_clean: boolean;
  equipment_clean: boolean;
  equipment_sterilised: boolean;
  fresh_water: boolean;
  water_temperature_verified: boolean;
  correct_bottle: boolean;
  correct_formula: boolean;
  correct_scoop: boolean;
  water_measurement_verified: boolean;
  powder_measurement_verified: boolean;
  bottle_closed: boolean;
  mixed: boolean;
  cooling_started: boolean;
  feeding_temperature_verified: boolean;
}

export interface Feed {
  feed_id: string;
  baby_id: string;
  formula_product_id: string;
  formula_batch_id: string;
  formula_container_id?: string;
  bottle_id: string;
  
  state: FeedState;
  preparation_started_at: string;
  water_added_at?: string;
  powder_added_at?: string;
  mixed_at?: string;
  cooling_started_at?: string;
  ready_at?: string;
  feeding_started_at?: string;
  feeding_finished_at?: string;
  discarded_at?: string;
  
  water_temperature_c?: number;
  reconstitution_temp_verified?: boolean;
  feed_volume_ml: number; // Volume planned / prepared
  powder_scoops?: number;
  powder_mass_g?: number;
  preparation_method: string; // MANUAL, MACHINE
  water_source?: WaterType;
  
  // Consumption metrics
  volume_offered?: number;
  volume_consumed?: number;
  volume_remaining?: number;
  baby_cues_recorded: HungerCue[];
  caregiver_id: string;
  
  notes?: string;
  provenance: DataProvenance;
}

export interface FeedEvent {
  event_id: string;
  feed_id: string;
  event_type: string; // FeedCreated, WaterAdded, TemperatureRecorded, etc.
  timestamp: string;
  caregiver_id: string;
  details: Record<string, any>;
}

export interface FormulaRecall {
  recall_id: string;
  brand: string;
  product_name: string;
  affected_batches: string[]; // batch lot codes
  published_at: string;
  source: string;
  description: string;
  severity: Severity;
}

export interface CarePlanInstruction {
  instruction_id: string;
  source: string; // e.g. "HCP", "Paediatrician"
  author: string;
  date_recorded: string;
  expiry_date?: string;
  instruction_text: string;
}

export interface AuditLogEntry {
  audit_id: string;
  timestamp: string;
  who: string;
  what: string;
  device: string;
  previous_state: string;
  new_state: string;
  source: string;
}

export interface DeviceCalibration {
  device_id: string;
  device_name: string;
  device_type: "THERMOMETER" | "SCALE" | "MACHINE";
  last_calibrated: string;
  calibration_source: string;
  calibration_result: string;
  status: "CALIBRATED" | "NEEDS_CALIBRATION" | "FAILED";
}
