import { 
  ChangeDetectionStrategy, 
  Component, 
  ElementRef, 
  HostListener, 
  OnInit, 
  AfterViewInit, 
  OnDestroy, 
  ViewChild, 
  signal, 
  computed, 
  effect 
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

interface Track {
  callsign: string;
  aircraftType: string;
  squawk: string;
  origin: string;
  destination: string;
  x: number; // Simulated position on screen coordinates
  y: number;
  altitude: number; // in feet (e.g., 35000)
  clearedAltitude: number; 
  speed: number; // in knots
  clearedSpeed: number; 
  heading: number; // in degrees
  clearedHeading: number; 
  verticalRate: number; // feet per minute
  history: { x: number; y: number }[];
  status: 'EN_ROUTE' | 'APPROACH' | 'DEPARTURE' | 'LANDED' | 'TAXI' | 'GATE';
  emergency: string | null;
  hasRadioFailure: boolean;
  wakeCategory: 'L' | 'M' | 'H' | 'S'; // Light, Medium, Heavy, Super
  route: string[]; 
  currentWaypointIndex: number;
  assignedGate?: string;
  assignedRunway?: string;
  groundState?: 'GATE' | 'PUSHBACK' | 'TAXI_HOLD' | 'TAXIING' | 'LINE_UP' | 'TAKEOFF_ROLL' | 'DEPARTED';
  taxiProgress?: number; // 0 to 1 along a ground path
  eta?: string;
  coordinationState?: string;
}

interface Conflict {
  id: string;
  flightA: string;
  flightB: string;
  separation: number; // NM
  verticalDiff: number; // FT
  timeToCpa: number; // seconds
}

interface Scenario {
  id: string;
  nameAr: string;
  nameEn: string;
  descriptionAr: string;
  descriptionEn: string;
  trafficDensity: 'LOW' | 'MEDIUM' | 'HIGH';
  windDirection: number;
  windSpeed: number;
  visibility: number;
  sandstormLevel: string;
  weatherCells: { x: number; y: number; radius: number; severity: string; labelAr: string; labelEn: string }[];
}

interface Notam {
  id: string;
  severity: string;
  textAr: string;
  textEn: string;
  validity: string;
}

interface CPDLCMessage {
  id: string;
  timestamp: string;
  callsign: string;
  speaker: 'ATC' | 'PILOT';
  english: string;
  arabic: string;
  audioTranscript?: string;
}

interface AuditLog {
  id: string;
  timestamp: string;
  callsign: string;
  action: string;
  details: string;
}

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [CommonModule, MatIconModule],
  templateUrl: './app.html',
})
export class App implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild('radarCanvas', { static: false }) radarCanvas!: ElementRef<HTMLCanvasElement>;
  @ViewChild('radarContainer', { static: false }) radarContainer!: ElementRef<HTMLDivElement>;
  @ViewChild('groundCanvas', { static: false }) groundCanvas!: ElementRef<HTMLCanvasElement>;
  @ViewChild('chatContainer', { static: false }) chatContainer!: ElementRef<HTMLDivElement>;

  // Static reference data for Gulf Airspace
  activeWaypoints = [
    { name: 'MIREB', x: 200, y: 150, ar: 'ميريب', en: 'MIREB' },
    { name: 'SIVAL', x: 380, y: 220, ar: 'سيفال', en: 'SIVAL' },
    { name: 'RAPTO', x: 480, y: 340, ar: 'رابتوه', en: 'RAPTO' },
    { name: 'GIDUP', x: 180, y: 420, ar: 'جيدوب', en: 'GIDUP' },
    { name: 'NABIX', x: 320, y: 520, ar: 'نابيكس', en: 'NABIX' },
    { name: 'ALKOS', x: 550, y: 180, ar: 'الكوس', en: 'ALKOS' },
    { name: 'DEKUT', x: 120, y: 250, ar: 'ديكوت', en: 'DEKUT' },
    { name: 'ORSAR', x: 280, y: 310, ar: 'أورصار', en: 'ORSAR' },
    { name: 'DESDI', x: 420, y: 440, ar: 'ديسدي', en: 'DESDI' },
  ];

  restrictedAreas = [
    { nameAr: 'منطقة تدريب عسكرية OM-D12', nameEn: 'Military Area OM-D12', points: [{ x: 140, y: 180 }, { x: 220, y: 180 }, { x: 220, y: 240 }, { x: 140, y: 240 }] },
    { nameAr: 'منطقة محظورة قصر جبل علي OM-R04', nameEn: 'Jebel Ali No-Fly OM-R04', points: [{ x: 450, y: 480 }, { x: 530, y: 480 }, { x: 530, y: 540 }, { x: 450, y: 540 }] }
  ];

  rolesList = [
    { id: 'TOWER', ar: 'مراقب البرج (TWR)', en: 'Tower Controller (TWR)' },
    { id: 'APPROACH', ar: 'مراقب الاقتراب (APP)', en: 'Approach Controller (APP)' },
    { id: 'AREA', ar: 'مراقب المنطقة (ACC)', en: 'Area Controller (ACC)' },
    { id: 'DEPARTURE', ar: 'مراقب المغادرة (DEP)', en: 'Departure Controller (DEP)' }
  ];

  tabsList = [
    { id: 'vectors', ar: 'التوجيهات والمسارات', en: 'Vector Clearances' },
    { id: 'ground', ar: 'الرادار الأرضي', en: 'Ground Surveillance' },
    { id: 'flow', ar: 'تدفق الحركة', en: 'Flow Capacity' },
    { id: 'notam', ar: 'الطقس والإشعارات', en: 'Weather & NOTAMs' },
    { id: 'instructor', ar: 'لوحة المشرف', en: 'Instructor panel' },
    { id: 'report', ar: 'تقييم الأداء', en: 'After Action' }
  ];

  // Core App States (using Signals)
  isRtl = signal<boolean>(true);
  activeRole = signal<string>('APPROACH');
  activeTab = signal<string>('vectors');
  simSpeed = signal<number>(1); // 0 = Paused, 1x, 2x, 5x, 10x
  radarRange = signal<number>(100); // NM zoom scope
  searchQuery = signal<string>('');
  selectedFlight = signal<Track | null>(null);
  flights = signal<Track[]>([]);
  radioLog = signal<CPDLCMessage[]>([]);
  auditLogs = signal<AuditLog[]>([]);
  
  // Scenarios and METAR lists
  scenarios = signal<Scenario[]>([]);
  activeScenarioId = signal<string>('GULF_MORNING_PEAK');
  activeNotams = signal<Notam[]>([]);
  aar = signal<number>(48); // Arrival Acceptance Rate DXB
  dar = signal<number>(40); // Departure Acceptance Rate

  // Hardware Status / Fail Safe Toggles
  ssrOnline = signal<boolean>(true);
  surveillanceDegraded = signal<boolean>(false);

  // Radar Layers Visibility States
  showWeather = signal<boolean>(true);
  showWaypoints = signal<boolean>(true);
  showRestricted = signal<boolean>(true);
  showHistory = signal<boolean>(true);
  showVectors = signal<boolean>(true);

  // Computed Values
  activeFlightsCount = computed(() => this.flights().length);
  activeSector = computed(() => {
    switch (this.activeRole()) {
      case 'TOWER': return 'DXB_TWR_118.75';
      case 'APPROACH': return 'DXB_APP_EAST_124.90';
      case 'AREA': return 'EMIRATES_ACC_132.50';
      case 'DEPARTURE': return 'DXB_DEP_120.40';
      default: return 'GULF_ACC_124.40';
    }
  });
  activeAcc = computed(() => {
    return this.isRtl() ? 'مركز مراقبة طيران الإمارات (FIR)' : 'Emirates Control Centre (OMAE FIR)';
  });

  // Time Signals
  timeStringUtc = signal<string>('06:00:00');
  timeStringLocal = signal<string>('+04:00');

  // Interactive Variables
  radarZoom = signal<number>(1.0);
  isTransmitting = signal<boolean>(false);
  breachCount = signal<number>(0);
  emergenciesHandledCount = signal<number>(0);

  // Weather cells configuration
  weatherCells = signal<{ x: number; y: number; radius: number; severity: string; labelAr: string; labelEn: string }[]>([]);

  // Simulation frame handles
  private animationFrameId: number | null = null;
  private timerIntervalId: ReturnType<typeof setInterval> | null = null;
  private localTimeSeconds = 6 * 3600; // starts at 06:00:00

  // Computed filtered flights under current role jurisdiction
  filteredFlights = computed(() => {
    const role = this.activeRole();
    const query = this.searchQuery().toLowerCase().trim();
    let list = this.flights();

    // Filter by ATC Role / Jurisdiction
    if (role === 'TOWER') {
      list = list.filter(f => f.status === 'TAXI' || f.status === 'GATE' || f.status === 'LANDED');
    } else if (role === 'APPROACH') {
      list = list.filter(f => f.status === 'APPROACH' || f.status === 'LANDED' || f.status === 'EN_ROUTE');
    } else if (role === 'DEPARTURE') {
      list = list.filter(f => f.status === 'DEPARTURE' || f.status === 'TAXI');
    } else if (role === 'AREA') {
      list = list.filter(f => f.status === 'EN_ROUTE');
    }

    // Search query matching
    if (query) {
      list = list.filter(f => 
        f.callsign.toLowerCase().includes(query) || 
        f.aircraftType.toLowerCase().includes(query) ||
        f.origin.toLowerCase().includes(query) ||
        f.destination.toLowerCase().includes(query)
      );
    }

    return list;
  });

  // Computes short-term conflict alerts (STCA)
  activeConflictsList = computed<Conflict[]>(() => {
    const list = this.flights().filter(f => f.status !== 'TAXI' && f.status !== 'GATE' && f.status !== 'LANDED');
    const conflicts: Conflict[] = [];

    for (let i = 0; i < list.length; i++) {
      for (let j = i + 1; j < list.length; j++) {
        const fA = list[i];
        const fB = list[j];

        // Euclidean distance in canvas pixels
        const dx = fA.x - fB.x;
        const dy = fA.y - fB.y;
        const pixelDist = Math.sqrt(dx * dx + dy * dy);

        // Convert pixel distance to simulated nautical miles (NM)
        // Let's calibrate 600px radar screen size as 100 NM
        const scale = this.radarRange() / 300; 
        const distNM = pixelDist * scale;

        const altDiff = Math.abs(fA.altitude - fB.altitude);

        // STCA separation minima: 5.0 NM horizontally and 1000 FT vertically
        if (distNM < 5.0 && altDiff < 1000) {
          // Calculate closest point of approach time
          // Relative velocity approximations
          const speedA_x = Math.sin(fA.heading * Math.PI / 180) * (fA.speed / 3600);
          const speedA_y = -Math.cos(fA.heading * Math.PI / 180) * (fA.speed / 3600);
          const speedB_x = Math.sin(fB.heading * Math.PI / 180) * (fB.speed / 3600);
          const speedB_y = -Math.cos(fB.heading * Math.PI / 180) * (fB.speed / 3600);

          const rV_x = speedA_x - speedB_x;
          const rV_y = speedA_y - speedB_y;
          const rV_sq = rV_x * rV_x + rV_y * rV_y;

          let timeToCpa = 0;
          if (rV_sq > 0) {
            timeToCpa = Math.max(0, Math.round(-((dx * scale * rV_x) + (dy * scale * rV_y)) / rV_sq));
          }

          conflicts.push({
            id: `${fA.callsign}_${fB.callsign}`,
            flightA: fA.callsign,
            flightB: fB.callsign,
            separation: distNM,
            verticalDiff: altDiff,
            timeToCpa: Math.min(timeToCpa, 180)
          });
        }
      }
    }
    return conflicts;
  });

  activeConflictsCount = computed(() => this.activeConflictsList().length);

  // Workload factor calculation
  workloadPercentage = computed(() => {
    const flightCount = this.flights().length;
    const conflictsCount = this.activeConflictsCount();
    const commsCount = this.radioLog().length;
    
    let score = (flightCount * 3) + (conflictsCount * 25) + (commsCount * 0.5);
    if (this.surveillanceDegraded()) score += 20;
    
    return Math.min(100, Math.max(10, Math.round(score)));
  });

  // Dynamic safety index score (%)
  safetyScore = computed(() => {
    const base = 100;
    const breachPenalty = this.breachCount() * 15;
    const activeConflictsPenalty = this.activeConflictsCount() * 10;
    const degradedPenalty = this.surveillanceDegraded() ? 10 : 0;
    
    return Math.max(20, base - breachPenalty - activeConflictsPenalty - degradedPenalty);
  });

  // Dynamic arrival queue sequencing
  arrivalsQueue = computed(() => {
    return this.flights()
      .filter(f => f.status === 'APPROACH' || (f.status === 'EN_ROUTE' && f.destination === 'OMDB'))
      .map(f => {
        // approximate ETA based on remaining distance to DXB (which is near screen center: x=300, y=300)
        const dx = f.x - 300;
        const dy = f.y - 300;
        const dist = Math.sqrt(dx*dx + dy*dy);
        const etaMinutes = Math.round(dist / 4);
        const etaSeconds = (this.localTimeSeconds + etaMinutes * 60) % 86400;
        const hh = Math.floor(etaSeconds / 3600).toString().padStart(2, '0');
        const mm = Math.floor((etaSeconds % 3600) / 60).toString().padStart(2, '0');
        
        return {
          callsign: f.callsign,
          eta: `${hh}:${mm} UTC`
        };
      });
  });

  constructor() {
    // Watch for active conflicts to increment breach stats
    effect(() => {
      const conflicts = this.activeConflictsList();
      if (conflicts.length > 0) {
        // Increment once per newly discovered conflict
        this.breachCount.update(c => c + 1);
      }
    });
  }

  ngOnInit() {
    this.loadScenariosAndAirports();
    this.initializeDefaultFlights();
    this.startClock();
    this.initializeDefaultNotams();
  }

  ngAfterViewInit() {
    this.setupCanvases();
    this.startAnimationLoop();
  }

  ngOnDestroy() {
    if (this.animationFrameId) cancelAnimationFrame(this.animationFrameId);
    if (this.timerIntervalId) clearInterval(this.timerIntervalId);
  }

  // Set up resize listener for perfect radar drawing boundaries
  @HostListener('window:resize')
  onResize() {
    this.setupCanvases();
  }

  setupCanvases() {
    const radar = this.radarCanvas?.nativeElement;
    const container = this.radarContainer?.nativeElement;
    if (radar && container) {
      radar.width = container.clientWidth;
      radar.height = container.clientHeight;
    }

    const ground = this.groundCanvas?.nativeElement;
    if (ground) {
      // Small preview container standard sizing
      ground.width = ground.parentElement?.clientWidth || 350;
      ground.height = 240;
    }
  }

  // Load scenarios from Server Express API
  async loadScenariosAndAirports() {
    try {
      const res = await fetch('/api/v1/scenarios');
      if (res.ok) {
        const data = await res.json();
        this.scenarios.set(data);
      }
    } catch (e) {
      console.error('Failed to load scenarios from Server API', e);
    }
  }

  // Initialize METARs and NOTAMs lists
  initializeDefaultNotams() {
    this.activeNotams.set([
      { id: 'A0412/26', severity: 'HIGH', textAr: 'تنبيه غبار عالي: الرؤية الأفقية متوقعة للانخفاض بسبب نشاط الرياح المغبرة.', textEn: 'DUST ADVISORY: Reduced visibility expected due to active suspended particulate matter.', validity: '30-OCT-2026 / 18:00 UTC' },
      { id: 'B0892/26', severity: 'MEDIUM', textAr: 'ممر سيارات الأجرة K مغلق مؤقتاً لأعمال التطوير والصيانة.', textEn: 'TAXIWAY K1 CLOSED DUE TO PLANNED REPAIRS AND MAINTENANCE.', validity: '31-OCT-2026 / 12:00 UTC' }
    ]);
  }

  // Initialize Flight Data Records
  initializeDefaultFlights() {
    this.flights.set([
      {
        callsign: 'EK412',
        aircraftType: 'B77W',
        squawk: '4120',
        origin: 'OMDB',
        destination: 'EGLL',
        x: 220,
        y: 160,
        altitude: 21000,
        clearedAltitude: 21000,
        speed: 310,
        clearedSpeed: 310,
        heading: 300,
        clearedHeading: 300,
        verticalRate: 0,
        history: [],
        status: 'EN_ROUTE',
        emergency: null,
        hasRadioFailure: false,
        wakeCategory: 'H',
        route: ['MIREB', 'ORSAR', 'DESDI'],
        currentWaypointIndex: 0
      },
      {
        callsign: 'QR781',
        aircraftType: 'A359',
        squawk: '1502',
        origin: 'OTHH',
        destination: 'WSSS',
        x: 410,
        y: 430,
        altitude: 35000,
        clearedAltitude: 35000,
        speed: 460,
        clearedSpeed: 460,
        heading: 110,
        clearedHeading: 110,
        verticalRate: 0,
        history: [],
        status: 'EN_ROUTE',
        emergency: null,
        hasRadioFailure: false,
        wakeCategory: 'H',
        route: ['DESDI', 'SIVAL', 'RAPTO'],
        currentWaypointIndex: 0
      },
      {
        callsign: 'SV204',
        aircraftType: 'B789',
        squawk: '3104',
        origin: 'OERK',
        destination: 'OMDB',
        x: 490,
        y: 330,
        altitude: 18000,
        clearedAltitude: 18000,
        speed: 280,
        clearedSpeed: 280,
        heading: 301,
        clearedHeading: 301,
        verticalRate: 0,
        history: [],
        status: 'APPROACH',
        emergency: null,
        hasRadioFailure: false,
        wakeCategory: 'H',
        route: ['RAPTO', 'SIVAL', 'OMDB_CENTER'],
        currentWaypointIndex: 0
      },
      {
        callsign: 'EY17',
        aircraftType: 'A388',
        squawk: '5512',
        origin: 'OMAA',
        destination: 'KJFK',
        x: 170,
        y: 430,
        altitude: 8000,
        clearedAltitude: 14000,
        speed: 240,
        clearedSpeed: 250,
        heading: 310,
        clearedHeading: 310,
        verticalRate: 1200,
        history: [],
        status: 'APPROACH',
        emergency: null,
        hasRadioFailure: false,
        wakeCategory: 'S',
        route: ['GIDUP', 'NABIX'],
        currentWaypointIndex: 0
      },
      {
        callsign: 'WY601',
        aircraftType: 'B738',
        squawk: '2024',
        origin: 'OOMS',
        destination: 'OMDB',
        x: 520,
        y: 200,
        altitude: 12000,
        clearedAltitude: 12000,
        speed: 260,
        clearedSpeed: 260,
        heading: 240,
        clearedHeading: 240,
        verticalRate: 0,
        history: [],
        status: 'APPROACH',
        emergency: null,
        hasRadioFailure: false,
        wakeCategory: 'M',
        route: ['ALKOS', 'SIVAL'],
        currentWaypointIndex: 0
      },
      {
        callsign: 'EK201',
        aircraftType: 'A388',
        squawk: '4001',
        origin: 'OMDB',
        destination: 'KJFK',
        x: 300,
        y: 300,
        altitude: 62,
        clearedAltitude: 62,
        speed: 0,
        clearedSpeed: 0,
        heading: 301,
        clearedHeading: 301,
        verticalRate: 0,
        history: [],
        status: 'GATE',
        emergency: null,
        hasRadioFailure: false,
        wakeCategory: 'S',
        route: ['MIREB', 'DESDI'],
        currentWaypointIndex: 0,
        assignedGate: 'B24',
        assignedRunway: '30R',
        groundState: 'GATE',
        taxiProgress: 0
      }
    ]);
  }

  // Load a Scenario from local template data or API parameters
  loadScenario(scenarioId: string) {
    this.activeScenarioId.set(scenarioId);
    this.selectedFlight.set(null);
    
    // Reset performance review
    this.breachCount.set(0);
    this.emergenciesHandledCount.set(0);

    if (scenarioId === 'SANDSTORM_WARNING') {
      this.aar.set(12); // drastically reduce airport arrivals capacity
      this.dar.set(16);
      this.weatherCells.set([
        { x: 300, y: 250, radius: 120, severity: 'HIGH', labelAr: 'غبار وعاصفة رملية شديدة', labelEn: 'Dust & Sandstorm Area' },
        { x: 100, y: 150, radius: 80, severity: 'MEDIUM', labelAr: 'رؤية متدنية جداً', labelEn: 'Low Visibility Dust Cloud' },
      ]);
      // Trigger degraded warning
      this.surveillanceDegraded.set(true);
      this.ssrOnline.set(false);

      // Mutate some flights for sandstorm behavior
      const sandstormFlights = [...this.flights()];
      sandstormFlights.forEach(f => {
        if (f.callsign === 'EK412') {
          f.clearedAltitude = 26000;
          f.clearedHeading = 280;
        }
      });
      this.flights.set(sandstormFlights);

    } else if (scenarioId === 'THUNDERSTORM_ROUTE') {
      this.aar.set(32);
      this.dar.set(28);
      this.weatherCells.set([
        { x: 250, y: 150, radius: 75, severity: 'SEVERE', labelAr: 'خلايا رعدية شديدة ومطبات', labelEn: 'Convective Severe Thunderstorm' },
        { x: 380, y: 300, radius: 95, severity: 'HIGH', labelAr: 'مطر غزير', labelEn: 'Heavy Rain Precipitation Cell' },
      ]);
      this.surveillanceDegraded.set(false);
      this.ssrOnline.set(true);

    } else if (scenarioId === 'EMERGENCY_DEGRADED') {
      this.aar.set(40);
      this.weatherCells.set([]);
      this.surveillanceDegraded.set(true);
      this.ssrOnline.set(false);

      // Set emergency flight
      const emergencyFlights = [...this.flights()];
      const target = emergencyFlights.find(f => f.callsign === 'EK412');
      if (target) {
        target.emergency = 'LOW_FUEL';
        target.clearedAltitude = 9000;
        target.verticalRate = -1800;
        this.selectedFlight.set(target);
      }
      this.flights.set(emergencyFlights);
      this.emergenciesHandledCount.update(c => c + 1);

    } else {
      // Normal gulf peak
      this.aar.set(48);
      this.dar.set(40);
      this.weatherCells.set([]);
      this.surveillanceDegraded.set(false);
      this.ssrOnline.set(true);
      this.initializeDefaultFlights();
    }

    // Add scenario load log
    this.addAuditLog('SYSTEM', 'SCENARIO_LOADED', `Scenario ${scenarioId} successfully loaded into simulation core.`);
  }

  // Triggered manually by the instructor
  triggerEmergency(type: string) {
    const list = [...this.flights()];
    if (list.length === 0) return;

    // Trigger on current selected flight, or first flight
    const target = this.selectedFlight() ? list.find(f => f.callsign === this.selectedFlight()?.callsign) : list[0];
    
    if (target) {
      if (type === 'RADIO_FAILURE') {
        target.hasRadioFailure = true;
        this.addAuditLog(target.callsign, 'RADIO_LOSS', 'Lost all voice and CPDLC communication (SQUAWK 7600 initiated).');
        this.addRadioLog('PILOT', target.callsign, 'RADIO TRANSMISSION LOST // SQUAWK 7600 INITIATED', 'انقطاع تام للاتصالات اللاسلكية // تم تفعيل الرمز الملاحي ٧٦٠٠');
        target.squawk = '7600';
      } else {
        target.emergency = type;
        target.squawk = '7700'; // emergency squawk code
        this.addAuditLog(target.callsign, 'EMERGENCY_DECLARE', `Declared emergency status: ${type}.`);
        this.addRadioLog('PILOT', target.callsign, `MAYDAY MAYDAY MAYDAY, declaring flight emergency: ${type}. Requesting priority sequencing.`, `ميديه ميديه ميديه، نعلن حالة طوارئ جوية: ${type}. نطلب أولوية الهبوط والترتيب.`);
      }
      this.emergenciesHandledCount.update(c => c + 1);
      // force UI refresh
      this.flights.set(list);
    }
  }

  // Inject a dust storm via NOTAM panel
  injectSandstorm() {
    this.loadScenario('SANDSTORM_WARNING');
  }

  // Reset entire simulator
  resetSimulation() {
    this.initializeDefaultFlights();
    this.simSpeed.set(1);
    this.breachCount.set(0);
    this.emergenciesHandledCount.set(0);
    this.radioLog.set([]);
    this.auditLogs.set([]);
    this.selectedFlight.set(null);
    this.addAuditLog('SYSTEM', 'SIM_RESET', 'Aeronautical training simulator reset to peak morning conditions.');
  }

  // Start UTC Clocks
  startClock() {
    this.timerIntervalId = setInterval(() => {
      if (this.simSpeed() === 0) return; // Paused

      // Increment clock based on simulation speed multiplier
      this.localTimeSeconds += this.simSpeed();

      const hh = Math.floor(this.localTimeSeconds / 3600).toString().padStart(2, '0');
      const mm = Math.floor((this.localTimeSeconds % 3600) / 60).toString().padStart(2, '0');
      const ss = Math.floor(this.localTimeSeconds % 60).toString().padStart(2, '0');
      
      this.timeStringUtc.set(`${hh}:${mm}:${ss}`);
    }, 1000);
  }

  // Main high frequency game rendering / physics loop
  startAnimationLoop() {
    const frame = () => {
      this.updatePhysics();
      this.drawRadar();
      this.drawGroundRadar();
      this.animationFrameId = requestAnimationFrame(frame);
    };
    this.animationFrameId = requestAnimationFrame(frame);
  }

  // Flight simulation math - coordinates updates, target course convergence, altitude climbing
  updatePhysics() {
    if (this.simSpeed() === 0) return;

    const list = [...this.flights()];
    const dt = 0.05 * this.simSpeed(); // delta step

    list.forEach(f => {
      // 1. GROUND TAXI PHYSICS & MOVEMENT
      if (f.status === 'GATE' || f.status === 'TAXI') {
        if (f.groundState === 'PUSHBACK') {
          f.x -= 0.03 * dt; // slowly pushback backwards
          f.heading = 121; // face runway course
          f.clearedHeading = 121;
        } else if (f.groundState === 'TAXIING') {
          // move along taxiway towards runway 30R start point (approx x=280, y=320)
          const tx = 270;
          const ty = 310;
          const dx = tx - f.x;
          const dy = ty - f.y;
          const dist = Math.sqrt(dx*dx + dy*dy);
          
          if (dist > 5) {
            f.x += (dx / dist) * 0.4 * dt;
            f.y += (dy / dist) * 0.4 * dt;
            f.speed = 18; // taxi speed knots
            f.heading = Math.atan2(dx, -dy) * 180 / Math.PI;
            if (f.heading < 0) f.heading += 360;
            f.clearedHeading = f.heading;
          } else {
            f.groundState = 'TAXI_HOLD';
            f.speed = 0;
            this.addAuditLog(f.callsign, 'HOLD_SHORT', 'Holding short of runway 30R at intersection Bravo.');
            this.addRadioLog('PILOT', f.callsign, 'Holding short of runway 30R at intersection Bravo, ready for departure sequence.', 'نقف قبل المدرج ٣٠ يمين عند التقاطع برافو، جاهزون لتلقي تصريح الإقلاع.');
          }
        } else if (f.groundState === 'LINE_UP') {
          // align to runway course 30R (approx start x=270, y=310)
          f.heading = 301;
          f.clearedHeading = 301;
          f.speed = 0;
        } else if (f.groundState === 'TAKEOFF_ROLL') {
          // accelerate on runway 301 heading
          f.speed += 8 * dt;
          const rad = (f.heading * Math.PI) / 180;
          f.x += Math.sin(rad) * (f.speed / 200) * dt;
          f.y -= Math.cos(rad) * (f.speed / 200) * dt;

          if (f.speed >= 140) { // V2 takeoff speed
            f.status = 'DEPARTURE';
            f.groundState = 'DEPARTED';
            f.clearedAltitude = 6000;
            f.altitude = 500;
            f.verticalRate = 1500;
            f.speed = 180;
            f.clearedSpeed = 250;
            this.addAuditLog(f.callsign, 'AIRBORNE', 'Aircraft liftoff completed, climbing to FL060 on runway heading.');
            this.addRadioLog('PILOT', f.callsign, 'Airborne, climbing to Flight Level 060, switching to departure radar on 120.40.', 'أقلعنا ونرتقي لمستوى الطيران ٦٠، نتحول لموجة مراقبة المغادرة على التردد ١٢٠.٤٠.');
          }
        }
        return; // skip airborne physics for ground states
      }

      // 2. AIRBORNE FLIGHT PHYSICS
      // Gradual Turn Heading adjustments
      let hdgDiff = f.clearedHeading - f.heading;
      if (hdgDiff > 180) hdgDiff -= 360;
      if (hdgDiff < -180) hdgDiff += 360;

      if (Math.abs(hdgDiff) > 1) {
        // Max turn rate 3 degrees per second
        f.heading += Math.sign(hdgDiff) * Math.min(3 * dt, Math.abs(hdgDiff));
        if (f.heading < 0) f.heading += 360;
        if (f.heading >= 360) f.heading -= 360;
      }

      // Altitude Climbing / Descending adjustments
      const altDiff = f.clearedAltitude - f.altitude;
      if (Math.abs(altDiff) > 50) {
        // climb rates
        f.verticalRate = Math.sign(altDiff) * Math.min(1500, Math.abs(altDiff));
        f.altitude += (f.verticalRate / 60) * dt;
      } else {
        f.altitude = f.clearedAltitude;
        f.verticalRate = 0;
      }

      // Speed accelerations / decelerations
      const spdDiff = f.clearedSpeed - f.speed;
      if (Math.abs(spdDiff) > 2) {
        f.speed += Math.sign(spdDiff) * Math.min(4 * dt, Math.abs(spdDiff));
      }

      // 3. RADAR POSITION UPDATES (Using polar movement math)
      const rad = (f.heading * Math.PI) / 180;
      // Convert knots to screen pixels movement
      // let's say 400 knots = 2 pixels per step
      const stepScale = f.speed / 200;
      f.x += Math.sin(rad) * stepScale * dt;
      f.y -= Math.cos(rad) * stepScale * dt;

      // 4. ROUTE WAYPOINT SEQUENCE PROGRESSION
      if (f.route && f.route.length > 0) {
        const nextWpName = f.route[f.currentWaypointIndex];
        const wp = this.activeWaypoints.find(w => w.name === nextWpName);
        if (wp) {
          const dx = wp.x - f.x;
          const dy = wp.y - f.y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          // If aircraft is within 15 pixels of waypoint, sequence to next
          if (dist < 15) {
            if (f.currentWaypointIndex < f.route.length - 1) {
              f.currentWaypointIndex++;
              // automatically vector heading to next waypoint
              const nextNextWp = f.route[f.currentWaypointIndex];
              const nextWpObj = this.activeWaypoints.find(w => w.name === nextNextWp);
              if (nextWpObj) {
                const angle = Math.atan2(nextWpObj.x - f.x, -(nextWpObj.y - f.y)) * 180 / Math.PI;
                f.clearedHeading = Math.round(angle < 0 ? angle + 360 : angle);
              }
            } else if (f.destination === 'OMDB' && f.status !== 'LANDED') {
              // Terminal approach completed, trigger auto descent to land on runway 30L (x=300, y=300)
              f.clearedAltitude = 62;
              f.clearedSpeed = 140;
              const angle = Math.atan2(300 - f.x, -(300 - f.y)) * 180 / Math.PI;
              f.clearedHeading = Math.round(angle < 0 ? angle + 360 : angle);

              if (f.altitude <= 500) {
                f.status = 'LANDED';
                f.speed = 60;
                f.x = 300;
                f.y = 300;
                f.clearedHeading = 301;
                f.heading = 301;
                this.addAuditLog(f.callsign, 'LANDING', 'Successfully touched down on runway 30L.');
                this.addRadioLog('PILOT', f.callsign, 'Touchdown completed on runway 30L. Decelerating, exiting runway via taxiway Delta.', 'هبطنا بسلام على المدرج ٣٠ يسار. نهدئ السرعة ونخلي المدرج عبر الممر ديلتا.');
              }
            }
          }
        }
      }

      // Store historical trail
      if (Math.random() < 0.15) {
        f.history.push({ x: f.x, y: f.y });
        if (f.history.length > 5) f.history.shift();
      }
    });

    this.flights.set(list);

    // Sync selected flight if active
    const selected = this.selectedFlight();
    if (selected) {
      const updated = list.find(f => f.callsign === selected.callsign);
      if (updated) this.selectedFlight.set(updated);
    }
  }

  // Render high-fidelity 2D Radar Display
  drawRadar() {
    const canvas = this.radarCanvas?.nativeElement;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;
    ctx.clearRect(0, 0, w, h);

    const cx = w / 2;
    const cy = h / 2;

    // Apply Zoom factor around center point
    ctx.save();
    ctx.translate(cx, cy);
    ctx.scale(this.radarZoom(), this.radarZoom());
    ctx.translate(-cx, -cy);

    // 1. DRAW SUBTLE ALIGNMENT COMPASS COAXIAL GRID
    ctx.strokeStyle = 'rgba(30, 41, 59, 0.4)';
    ctx.lineWidth = 1;
    ctx.setLineDash([4, 4]);

    // Cross axes lines
    ctx.beginPath();
    ctx.moveTo(cx, 0); ctx.lineTo(cx, h);
    ctx.moveTo(0, cy); ctx.lineTo(w, cy);
    ctx.stroke();

    // Concentric range circles
    ctx.setLineDash([2, 5]);
    const maxRangeRing = 4;
    for (let r = 1; r <= maxRangeRing; r++) {
      const radius = (r * 100) / this.radarZoom(); // calibrated
      ctx.beginPath();
      ctx.arc(cx, cy, radius, 0, 2 * Math.PI);
      ctx.stroke();

      // Range Labels
      ctx.fillStyle = '#64748B';
      ctx.font = '9px monospace';
      ctx.fillText(`${r * 25} NM`, cx + radius + 3, cy - 3);
    }
    ctx.setLineDash([]); // Reset line dash

    // 2. DRAW ACTIVE RESTRICTED AIRSPACE POLYGONS
    if (this.showRestricted()) {
      this.restrictedAreas.forEach(area => {
        ctx.strokeStyle = 'rgba(239, 68, 68, 0.4)';
        ctx.fillStyle = 'rgba(239, 68, 68, 0.04)';
        ctx.lineWidth = 1.5;
        ctx.setLineDash([5, 3]);

        ctx.beginPath();
        // Convert local coordinates to screen coordinates relative to center
        area.points.forEach((pt, index) => {
          const screenX = cx + (pt.x - 300);
          const screenY = cy + (pt.y - 300);
          if (index === 0) ctx.moveTo(screenX, screenY);
          else ctx.lineTo(screenX, screenY);
        });
        ctx.closePath();
        ctx.stroke();
        ctx.fill();

        // Label
        ctx.fillStyle = 'rgba(239, 68, 68, 0.6)';
        ctx.font = '10px sans-serif';
        const textLabel = this.isRtl() ? area.nameAr : area.nameEn;
        ctx.fillText(textLabel, cx + (area.points[0].x - 300) + 5, cy + (area.points[0].y - 300) - 5);
      });
      ctx.setLineDash([]);
    }

    // 3. DRAW WEATHER RADAR CONVECTIVE STORM CELLS
    if (this.showWeather() && this.weatherCells().length > 0) {
      this.weatherCells().forEach(cell => {
        const x = cx + (cell.x - 300);
        const y = cy + (cell.y - 300);
        const rad = cell.radius;

        // Draw multiple gradient rings to mimic real meteorology radar
        const grad = ctx.createRadialGradient(x, y, rad * 0.1, x, y, rad);
        if (cell.severity === 'SEVERE') {
          grad.addColorStop(0, 'rgba(239, 68, 68, 0.4)'); // Deep Red convective cell
          grad.addColorStop(0.5, 'rgba(245, 158, 11, 0.25)'); // Orange boundary
          grad.addColorStop(1, 'rgba(6, 182, 212, 0.05)'); // Soft Blue/Cyan edge
        } else {
          grad.addColorStop(0, 'rgba(245, 158, 11, 0.3)'); // Medium dust amber
          grad.addColorStop(0.7, 'rgba(245, 158, 11, 0.1)');
          grad.addColorStop(1, 'transparent');
        }

        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(x, y, rad, 0, 2 * Math.PI);
        ctx.fill();

        // Cell boundary
        ctx.strokeStyle = cell.severity === 'SEVERE' ? 'rgba(239, 68, 68, 0.25)' : 'rgba(245, 158, 11, 0.15)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(x, y, rad, 0, 2 * Math.PI);
        ctx.stroke();

        // Meteorological label
        ctx.fillStyle = cell.severity === 'SEVERE' ? '#EF4444' : '#F59E0B';
        ctx.font = '9px monospace';
        const labelText = this.isRtl() ? cell.labelAr : cell.labelEn;
        ctx.fillText(labelText, x - 30, y + 4);
      });
    }

    // 4. DRAW GULF WAYPOINTS RNAV FIXES
    if (this.showWaypoints()) {
      this.activeWaypoints.forEach(wp => {
        const x = cx + (wp.x - 300);
        const y = cy + (wp.y - 300);

        // draw triangle representing GPS waypoint fix
        ctx.strokeStyle = '#64748B';
        ctx.fillStyle = '#1E293B';
        ctx.lineWidth = 1.5;

        ctx.beginPath();
        ctx.moveTo(x, y - 4);
        ctx.lineTo(x + 5, y + 4);
        ctx.lineTo(x - 5, y + 4);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();

        // Label
        ctx.fillStyle = '#94A3B8';
        ctx.font = 'bold 9px monospace';
        ctx.fillText(wp.name, x + 8, y + 3);
      });
    }

    // 5. DRAW ACTIVE AIRCRAFT SURVEILLANCE TRACKS
    const list = this.flights();
    const conflictsList = this.activeConflictsList();

    list.forEach(f => {
      // Don't draw grounded aircraft on airborne airspace map
      if (f.status === 'GATE' || f.status === 'TAXI') return;

      const sx = cx + (f.x - 300);
      const sy = cy + (f.y - 300);

      const inConflict = conflictsList.some(c => c.flightA === f.callsign || c.flightB === f.callsign);
      const isSelected = this.selectedFlight()?.callsign === f.callsign;

      // Draw past path dots
      if (this.showHistory() && f.history.length > 0) {
        ctx.fillStyle = inConflict ? 'rgba(239, 68, 68, 0.4)' : 'rgba(6, 182, 212, 0.3)';
        f.history.forEach((hPos, idx) => {
          const hx = cx + (hPos.x - 300);
          const hy = cy + (hPos.y - 300);
          ctx.beginPath();
          ctx.arc(hx, hy, 1.5 + (idx * 0.4), 0, 2 * Math.PI);
          ctx.fill();
        });
      }

      // Draw heading direction vector prediction line (+3 mins)
      if (this.showVectors()) {
        const rad = (f.heading * Math.PI) / 180;
        const speedKts = f.speed;
        const vectorLength = speedKts / 8; // calibrated visual scale

        ctx.strokeStyle = inConflict ? '#EF4444' : (isSelected ? '#06B6D4' : '#64748B');
        ctx.lineWidth = isSelected ? 1.5 : 1;
        ctx.setLineDash([2, 2]);

        ctx.beginPath();
        ctx.moveTo(sx, sy);
        ctx.lineTo(sx + Math.sin(rad) * vectorLength, sy - Math.cos(rad) * vectorLength);
        ctx.stroke();
        ctx.setLineDash([]);
      }

      // Draw main aircraft target symbol
      ctx.fillStyle = inConflict ? '#EF4444' : (isSelected ? '#06B6D4' : '#F8FAFC');
      
      ctx.beginPath();
      ctx.arc(sx, sy, isSelected ? 4.5 : 3, 0, 2 * Math.PI);
      ctx.fill();

      // Dotted active halo rings for conflicts / selected states
      if (inConflict) {
        ctx.strokeStyle = '#EF4444';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.arc(sx, sy, 10 + Math.sin(Date.now() / 80) * 3, 0, 2 * Math.PI);
        ctx.stroke();
      } else if (isSelected) {
        ctx.strokeStyle = '#06B6D4';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(sx, sy, 8, 0, 2 * Math.PI);
        ctx.stroke();
      }

      // Draw Flight label data block
      ctx.fillStyle = inConflict ? '#EF4444' : (isSelected ? '#06B6D4' : '#94A3B8');
      ctx.font = isSelected ? 'bold 10px monospace' : '9px monospace';

      // 3-line telemetry data label block
      const callsign = f.callsign;
      const altitudeFL = `FL${Math.round(f.altitude / 100).toString().padStart(3, '0')}`;
      const trend = f.verticalRate > 0 ? '↑' : (f.verticalRate < 0 ? '↓' : '=');
      const speedKts = `${Math.round(f.speed / 10)}T`; // standard Ground speed representation tenths knots

      // Draw nice label offset pointer lines
      ctx.strokeStyle = 'rgba(148, 163, 184, 0.3)';
      ctx.lineWidth = 0.5;
      ctx.beginPath();
      ctx.moveTo(sx, sy);
      ctx.lineTo(sx + 15, sy - 15);
      ctx.lineTo(sx + 40, sy - 15);
      ctx.stroke();

      const lx = sx + 20;
      const ly = sy - 20;

      ctx.fillText(callsign, lx, ly);
      ctx.fillText(`${altitudeFL}${trend}`, lx, ly + 9);
      ctx.fillText(`${speedKts} S${f.squawk}`, lx, ly + 18);
    });

    ctx.restore();
  }

  // Draw secondary Dubai Airport Surface Radar (Digital Twin map)
  drawGroundRadar() {
    const canvas = this.groundCanvas?.nativeElement;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    const w = canvas.width;
    const h = canvas.height;

    // Draw background texture grid
    ctx.strokeStyle = '#111827';
    ctx.lineWidth = 1;
    for (let x = 0; x < w; x += 30) {
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, h); ctx.stroke();
    }
    for (let y = 0; y < h; y += 30) {
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke();
    }

    // Draw runways (represented as wide dark grey blocks)
    // Dubai Runway 30L (represented horizontally or angled)
    ctx.strokeStyle = '#1E293B';
    ctx.lineWidth = 10;
    ctx.beginPath();
    ctx.moveTo(30, 80);
    ctx.lineTo(w - 30, 80);
    ctx.stroke();

    // Dubai Runway 30R
    ctx.beginPath();
    ctx.moveTo(30, 140);
    ctx.lineTo(w - 30, 140);
    ctx.stroke();

    // Runway markings centerlines
    ctx.strokeStyle = '#94A3B8';
    ctx.lineWidth = 1;
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.moveTo(40, 80); ctx.lineTo(w - 40, 80);
    ctx.moveTo(40, 140); ctx.lineTo(w - 40, 140);
    ctx.stroke();
    ctx.setLineDash([]);

    // Runway Label Texts
    ctx.fillStyle = '#64748B';
    ctx.font = 'bold 9px monospace';
    ctx.fillText('RWY 30L', 45, 73);
    ctx.fillText('RWY 30R', 45, 133);

    // Draw taxiway pathways ( Bravo, Alpha links )
    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 3;
    ctx.beginPath();
    // Link Alpha
    ctx.moveTo(50, 80); ctx.lineTo(50, 140); ctx.lineTo(50, 190);
    // Link Bravo
    ctx.moveTo(w - 50, 80); ctx.lineTo(w - 50, 140); ctx.lineTo(w - 50, 190);
    // Link Delta connectors
    ctx.moveTo(w / 2, 80); ctx.lineTo(w / 2, 140); ctx.lineTo(w / 2, 190);
    ctx.stroke();

    // Taxiway Line Bravo bottom lane
    ctx.beginPath();
    ctx.moveTo(50, 190);
    ctx.lineTo(w - 50, 190);
    ctx.stroke();

    // Draw Gatestands positions (labeled spots)
    const gates = [
      { id: 'B24', x: 60, y: 215 },
      { id: 'B25', x: 130, y: 215 },
      { id: 'A1', x: 200, y: 215 },
      { id: 'A12', x: 270, y: 215 }
    ];

    gates.forEach(gate => {
      ctx.fillStyle = '#1E293B';
      ctx.strokeStyle = '#334155';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.rect(gate.x - 12, gate.y - 10, 24, 16);
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = '#94A3B8';
      ctx.font = '8px monospace';
      ctx.fillText(gate.id, gate.x - 7, gate.y + 1);
    });

    // Draw active grounded aircraft on the map
    this.flights().forEach(f => {
      if (f.status === 'GATE' || f.status === 'TAXI') {
        // Map ground coordinates to surface preview map sizes
        // Let's approximate positions based on groundState
        let gx = w / 2;
        let gy = h / 2;

        if (f.groundState === 'GATE' && f.assignedGate) {
          const match = gates.find(g => g.id === f.assignedGate);
          if (match) { gx = match.x; gy = match.y - 15; }
        } else if (f.groundState === 'PUSHBACK') {
          const match = gates.find(g => g.id === f.assignedGate);
          if (match) { gx = match.x; gy = match.y - 35; }
        } else if (f.groundState === 'TAXIING') {
          // moving slowly along taxi lane Bravo
          gx = 110;
          gy = 190;
        } else if (f.groundState === 'TAXI_HOLD') {
          gx = 50;
          gy = 155;
        } else if (f.groundState === 'LINE_UP') {
          gx = 70;
          gy = 140;
        } else if (f.groundState === 'TAKEOFF_ROLL') {
          gx = 160;
          gy = 140;
        }

        // Draw ground aircraft symbol
        ctx.fillStyle = '#F59E0B';
        ctx.beginPath();
        ctx.arc(gx, gy, 4, 0, 2 * Math.PI);
        ctx.fill();

        ctx.fillStyle = '#F8FAFC';
        ctx.font = 'bold 8px monospace';
        ctx.fillText(f.callsign, gx + 6, gy + 3);
      }
    });
  }

  // Operator HUD actions
  setRole(roleId: string) {
    this.activeRole.set(roleId);
    this.selectedFlight.set(null);
  }

  setActiveTab(tabId: string) {
    this.activeTab.set(tabId);
  }

  setSimulationSpeed(speed: number) {
    this.simSpeed.set(speed);
  }

  setRadarRange(range: number) {
    this.radarRange.set(range);
  }

  toggleLanguage() {
    this.isRtl.set(!this.isRtl());
  }

  updateSearch(val: string) {
    this.searchQuery.set(val);
  }

  selectFlight(flight: Track) {
    this.selectedFlight.set(flight);
    // Switch to vectors tab immediately
    this.activeTab.set('vectors');
  }

  // Vector clearance updates
  updateAltitudeVector(val: string | number) {
    const flight = this.selectedFlight();
    if (flight) {
      flight.clearedAltitude = Number(val);
    }
  }

  updateHeadingVector(val: string | number) {
    const flight = this.selectedFlight();
    if (flight) {
      flight.clearedHeading = Number(val);
    }
  }

  updateSpeedVector(val: string | number) {
    const flight = this.selectedFlight();
    if (flight) {
      flight.clearedSpeed = Number(val);
    }
  }

  proceedDirectTo(waypointName: string) {
    const flight = this.selectedFlight();
    if (flight) {
      // replace target route index
      const wpIdx = flight.route.indexOf(waypointName);
      if (wpIdx !== -1) {
        flight.currentWaypointIndex = wpIdx;
        const targetWp = this.activeWaypoints.find(w => w.name === waypointName);
        if (targetWp) {
          const angle = Math.atan2(targetWp.x - flight.x, -(targetWp.y - flight.y)) * 180 / Math.PI;
          flight.clearedHeading = Math.round(angle < 0 ? angle + 360 : angle);
          this.addAuditLog(flight.callsign, 'DIRECT_TO', `Cleared direct proceed to waypoint ${waypointName}.`);
        }
      }
    }
  }

  commandGroundState(state: 'PUSHBACK' | 'TAXIING' | 'LINE_UP' | 'TAKEOFF_ROLL') {
    const flight = this.selectedFlight();
    if (flight) {
      flight.groundState = state;
      if (state === 'PUSHBACK') {
        this.addAuditLog(flight.callsign, 'PUSHBACK_START', 'Pushback clearance and engine startup approved.');
        this.addRadioLog('PILOT', flight.callsign, 'Roger Emirates 201, pushback approved, face Runway 12L.', 'علم طيران الإمارات ٢٠١، تصريح الدفع الخلفي معتمد، نوجه الطائرة للمدرج ١٢ يسار.');
      } else if (state === 'TAXIING') {
        this.addAuditLog(flight.callsign, 'TAXI_START', 'Cleared to taxi to runway 30R holding point.');
        this.addRadioLog('PILOT', flight.callsign, 'Taxiing Bravo to Runway 30R hold short, Emirates 201.', 'علم، نتحرك عبر الممر برافو إلى نقطة التوقف قبل المدرج ٣٠ يمين، طيران الإمارات ٢٠١.');
      } else if (state === 'LINE_UP') {
        this.addAuditLog(flight.callsign, 'LINE_UP_RUNWAY', 'Cleared to line up and hold short Runway 30R.');
        this.addRadioLog('PILOT', flight.callsign, 'Aligning and holding Runway 30R, Emirates 201.', 'علم، ندخل المدرج وننتظر التوجيه اللاحق ٣٠ يمين، طيران الإمارات ٢٠١.');
      } else if (state === 'TAKEOFF_ROLL') {
        this.addAuditLog(flight.callsign, 'TAKEOFF_APPROVED', 'Cleared for takeoff Runway 30R, wind 240/18kts.');
        this.addRadioLog('PILOT', flight.callsign, 'Cleared for takeoff Runway 30R, Emirates 201.', 'علم، مصرح لنا بالإقلاع المدرج ٣٠ يمين، طيران الإمارات ٢٠١.');
      }
    }
  }

  // CPDLC TRANSMIT TO BACKEND API (CONNECTS TO THE LIVE GEMINI MODEL!)
  async transmitCpdlcClearance(flight: Track) {
    if (this.isTransmitting()) return;
    this.isTransmitting.set(true);

    const actionDesc = `Altitude FL${flight.clearedAltitude / 100}, Heading ${flight.clearedHeading}°, Speed ${flight.clearedSpeed}kts`;
    
    // Add ATC original message onto CPDLC list immediately
    this.addRadioLog('ATC', flight.callsign, 
      `${flight.callsign}, clear altitude FL${flight.clearedAltitude / 100}, heading ${flight.clearedHeading} degrees, speed ${flight.clearedSpeed} knots. Verify.`,
      `${flight.callsign}، مصرح لك بالصعود إلى مستوى الطيران ${flight.clearedAltitude / 100}، والتحول إلى الاتجاه ${flight.clearedHeading} درجة، والسرعة ${flight.clearedSpeed} عقدة. أكد الاستلام.`
    );

    this.addAuditLog(flight.callsign, 'ATC_CPDLC_TRANSMIT', `ATC vector dispatch clearance: ${actionDesc}`);

    try {
      const res = await fetch('/api/v1/cpdlc', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          callsign: flight.callsign,
          altitude: Math.round(flight.clearedAltitude / 100),
          heading: flight.clearedHeading,
          speed: flight.clearedSpeed,
          emergency: flight.emergency
        })
      });

      if (res.ok) {
        const data = await res.json();
        
        // Push Pilot's response onto console stream
        this.addRadioLog('PILOT', flight.callsign, data.english, data.arabic, data.audioTranscript);
        this.addAuditLog(flight.callsign, 'PILOT_CPDLC_READBACK', `CPDLC Pilot Readback confirmed: "${data.english}"`);

        // Trigger realistic Web Speech synthesis for pilot audio response!
        if (data.audioTranscript) {
          this.speakVoice(data.audioTranscript);
        }
      }
    } catch (e) {
      console.error('Failed to dispatch CPDLC clearance via Server API', e);
    } finally {
      this.isTransmitting.set(false);
      this.scrollRadioChatToBottom();
    }
  }

  // Speak voice using system Text-to-Speech synthesis (fully client-side out-of-the-box!)
  speakVoice(text: string) {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.95; // professional slow air traffic voice
      utterance.pitch = 0.85; // deep robotic radio cockpit sound
      
      // select English pilot voice if available
      const voices = window.speechSynthesis.getVoices();
      const pilotVoice = voices.find(v => v.lang.includes('en-US') || v.lang.includes('en-GB'));
      if (pilotVoice) utterance.voice = pilotVoice;

      window.speechSynthesis.speak(utterance);
    }
  }

  // Toggle visible layers
  toggleLayer(layer: string) {
    if (layer === 'weather') this.showWeather.set(!this.showWeather());
    else if (layer === 'waypoints') this.showWaypoints.set(!this.showWaypoints());
    else if (layer === 'restricted') this.showRestricted.set(!this.showRestricted());
    else if (layer === 'history') this.showHistory.set(!this.showHistory());
    else if (layer === 'vectors') this.showVectors.set(!this.showVectors());
  }

  adjustZoom(factor: number) {
    const current = this.radarZoom();
    this.radarZoom.set(Math.max(0.5, Math.min(2.5, current + factor)));
  }

  // Helper getters
  getWeatherClass() {
    const scen = this.activeScenarioId();
    if (scen === 'SANDSTORM_WARNING') return 'text-amber-500 font-bold';
    if (scen === 'THUNDERSTORM_ROUTE') return 'text-rose-500 font-bold animate-pulse';
    return 'text-emerald-500 font-bold';
  }

  getWeatherLabelAr() {
    const scen = this.activeScenarioId();
    if (scen === 'SANDSTORM_WARNING') return 'عاصفة رملية شديدة';
    if (scen === 'THUNDERSTORM_ROUTE') return 'عواصف رعدية نشطة';
    return 'صحو / متاح بالكامل';
  }

  getWeatherLabelEn() {
    const scen = this.activeScenarioId();
    if (scen === 'SANDSTORM_WARNING') return 'SEVERE SANDSTORM';
    if (scen === 'THUNDERSTORM_ROUTE') return 'ACTIVE THUNDERSTORM';
    return 'NOMINAL / VIS VFR';
  }

  getWorkloadClass() {
    const p = this.workloadPercentage();
    if (p > 80) return 'text-rose-500 animate-pulse';
    if (p > 50) return 'text-amber-500';
    return 'text-emerald-500';
  }

  getWorkloadAr() {
    const p = this.workloadPercentage();
    if (p > 80) return 'مرتفع جداً - قطاع مزدحم';
    if (p > 50) return 'معتدل تشغيلياً';
    return 'مستقر / طبيعي';
  }

  getWorkloadEn() {
    const p = this.workloadPercentage();
    if (p > 80) return 'CONGESTED OVERLOAD';
    if (p > 50) return 'MODERATE OPERATIONAL';
    return 'STABLE NOMINAL';
  }

  getWorkloadProgressClass() {
    const p = this.workloadPercentage();
    if (p > 80) return 'bg-rose-500 animate-pulse';
    if (p > 50) return 'bg-amber-500';
    return 'bg-emerald-500';
  }

  getTrendColor(flight: Track) {
    if (flight.verticalRate > 0) return 'text-emerald-400';
    if (flight.verticalRate < 0) return 'text-rose-400';
    return 'text-white';
  }

  isGateOccupied(gateId: string) {
    return this.flights().some(f => f.assignedGate === gateId && f.status === 'GATE');
  }

  getFlightStripClass(flight: Track) {
    const isSelected = this.selectedFlight()?.callsign === flight.callsign;
    const inConflict = this.activeConflictsList().some(c => c.flightA === flight.callsign || c.flightB === flight.callsign);

    if (flight.emergency) {
      return isSelected ? 'border-rose-500 bg-rose-950/60 ring-2 ring-rose-500/40' : 'border-rose-900/60 bg-rose-950/20';
    }
    if (inConflict) {
      return isSelected ? 'border-rose-500 bg-rose-950/50 ring-2 ring-rose-500/40' : 'border-rose-800/40 bg-rose-950/10 animate-pulse';
    }
    if (isSelected) {
      return 'border-[#06B6D4] bg-[#111827]/80 ring-2 ring-[#06B6D4]/30';
    }
    return 'border-[#1E293B] bg-[#111827]/40 hover:border-[#334155]';
  }

  // Internal log management
  addRadioLog(speaker: 'ATC' | 'PILOT', callsign: string, english: string, arabic: string, audioTranscript?: string) {
    const logs = [...this.radioLog()];
    logs.push({
      id: `msg_${Math.random().toString(36).substr(2, 9)}`,
      timestamp: this.timeStringUtc(),
      callsign,
      speaker,
      english,
      arabic,
      audioTranscript
    });
    this.radioLog.set(logs);
    this.scrollRadioChatToBottom();
  }

  addAuditLog(callsign: string, action: string, details: string) {
    const logs = [...this.auditLogs()];
    const timestamp = new Date().toISOString();
    
    logs.unshift({
      id: `audit_${Math.random().toString(36).substr(2, 9)}`,
      timestamp,
      callsign,
      action,
      details
    });
    this.auditLogs.set(logs);

    // Persist log to Server API for playback statistics
    fetch('/api/v1/logs', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ callsign, action, details })
    }).catch(e => console.error('Failed to post live audit logs to server', e));
  }

  clearRadio() {
    this.radioLog.set([]);
  }

  scrollRadioChatToBottom() {
    setTimeout(() => {
      const container = this.chatContainer?.nativeElement;
      if (container) {
        container.scrollTop = container.scrollHeight;
      }
    }, 100);
  }
}
