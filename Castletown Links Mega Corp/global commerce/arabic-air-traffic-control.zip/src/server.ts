import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';
import { GoogleGenAI, Type } from '@google/genai';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json());

const angularApp = new AngularNodeAppEngine();

// Initialize Google Gen AI
const apiKey = process.env['GEMINI_API_KEY'];
const ai = apiKey ? new GoogleGenAI({
  apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
}) : null;

// In-Memory Database for active logs / audit trials
interface AuditLog {
  id: string;
  timestamp: string;
  callsign: string;
  action: string;
  details: string;
  operator: string;
}
const auditLogs: AuditLog[] = [];

// API Endpoints
app.get('/api/v1/scenarios', (req, res) => {
  res.json([
    {
      id: 'GULF_MORNING_PEAK',
      nameAr: 'ذروة الصباح في الخليج',
      nameEn: 'GULF MORNING PEAK',
      descriptionAr: 'حركة ملاحة عالية الكثافة مع وصول الطائرات من أوروبا وآسيا إلى مطارات دبي وأبوظبي والدوحة.',
      descriptionEn: 'High-density international arrival peak connecting Europe, Gulf, and Indian Subcontinent.',
      trafficDensity: 'HIGH',
      windDirection: 240,
      windSpeed: 12,
      visibility: 9999,
      sandstormLevel: 'NONE',
      weatherCells: [],
      initialFlightsCount: 22,
    },
    {
      id: 'SANDSTORM_WARNING',
      nameAr: 'العواصف الرملية الشديدة',
      nameEn: 'SEVERE SANDSTORM',
      descriptionAr: 'عاصفة ترابية شديدة تقلل الرؤية الأفقية في مطار دبي الدولي إلى 400 متر، مع فرض إجراءات اقتراب منخفض الرؤية وتأخير الرحلات.',
      descriptionEn: 'Severe sandstorm active over the UAE FIR. Visibility reduced to 400m, requiring CAT III operations and diversions.',
      trafficDensity: 'MEDIUM',
      windDirection: 40,
      windSpeed: 28,
      visibility: 400,
      sandstormLevel: 'SEVERE',
      weatherCells: [
        { x: 300, y: 250, radius: 120, severity: 'HIGH', labelAr: 'غبار وعاصفة رملية', labelEn: 'Dust & Sandstorm' },
        { x: 100, y: 150, radius: 80, severity: 'MEDIUM', labelAr: 'رؤية متدنية', labelEn: 'Low Visibility' },
      ],
      initialFlightsCount: 14,
    },
    {
      id: 'THUNDERSTORM_ROUTE',
      nameAr: 'منخفض جوي وعواصف رعدية',
      nameEn: 'CONVECTIVE THUNDERSTORM',
      descriptionAr: 'عواصف رعدية نشطة فوق بحر عمان والخليج العربي تجبر الطائرات على الالتفاف خارج المسارات الجوية المعتادة.',
      descriptionEn: 'Active convective storm cells over Gulf of Oman and northern sectors. Heavy rerouting required.',
      trafficDensity: 'MEDIUM',
      windDirection: 180,
      windSpeed: 22,
      visibility: 5000,
      sandstormLevel: 'NONE',
      weatherCells: [
        { x: 250, y: 150, radius: 70, severity: 'SEVERE', labelAr: 'خلايا رعدية شديدة', labelEn: 'Severe Convective Cell' },
        { x: 380, y: 300, radius: 90, severity: 'HIGH', labelAr: 'مطر غزير ومطبات', labelEn: 'Heavy Rain & Turb' },
        { x: 120, y: 400, radius: 60, severity: 'MEDIUM', labelAr: 'رياح قصيرة نشطة', labelEn: 'Wind Shear Area' },
      ],
      initialFlightsCount: 16,
    },
    {
      id: 'EMERGENCY_DEGRADED',
      nameAr: 'حالات الطوارئ والمجال المتدهور',
      nameEn: 'AIRCRAFT EMERGENCY & DEGRADED SURVEILLANCE',
      descriptionAr: 'طائرة تعلن طوارئ طبية وانخفاض الوقود مع تعطل رادار المراقبة الثانوي وتأخر الرصد.',
      descriptionEn: 'In-flight medical emergency coupled with secondary radar degradation. Prioritize sequencing.',
      trafficDensity: 'LOW',
      windDirection: 290,
      windSpeed: 8,
      visibility: 8000,
      sandstormLevel: 'NONE',
      weatherCells: [],
      initialFlightsCount: 10,
    }
  ]);
});

app.get('/api/v1/airports', (req, res) => {
  res.json({
    OMDB: {
      icao: 'OMDB',
      iata: 'DXB',
      nameAr: 'مطار دبي الدولي',
      nameEn: 'Dubai International Airport',
      elevation: 62, // feet
      atisFreq: '131.725 MHz',
      towerFreq: '118.750 MHz',
      approachFreq: '124.900 MHz',
      groundFreq: '118.350 MHz',
      runways: [
        { id: '30L', heading: 301, length: 4447, width: 60, status: 'OPERATIONAL', ilsFreq: '110.15 I-DBS' },
        { id: '30R', heading: 301, length: 4000, width: 60, status: 'OPERATIONAL', ilsFreq: '110.90 I-DXB' },
        { id: '12L', heading: 121, length: 4000, width: 60, status: 'SECONDARY', ilsFreq: '109.90 I-OMD' },
        { id: '12R', heading: 121, length: 4447, width: 60, status: 'SECONDARY', ilsFreq: '110.50 I-AAU' }
      ],
      taxiways: ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'K', 'L', 'M', 'P', 'R', 'S', 'T'],
      gates: ['A1', 'A12', 'B3', 'B24', 'C5', 'D2', 'F18']
    },
    OMAA: {
      icao: 'OMAA',
      iata: 'AUH',
      nameAr: 'مطار زايد الدولي - أبوظبي',
      nameEn: 'Zayed International Airport',
      elevation: 88,
      atisFreq: '135.250 MHz',
      towerFreq: '118.100 MHz',
      approachFreq: '124.400 MHz',
      groundFreq: '121.800 MHz',
      runways: [
        { id: '31L', heading: 309, length: 4100, width: 60, status: 'OPERATIONAL', ilsFreq: '110.3 I-AUH' },
        { id: '31R', heading: 309, length: 4100, width: 60, status: 'OPERATIONAL', ilsFreq: '110.7 I-ZAY' }
      ]
    },
    OTHH: {
      icao: 'OTHH',
      iata: 'DOH',
      nameAr: 'مطار حمد الدولي - الدوحة',
      nameEn: 'Hamad International Airport',
      elevation: 13,
      atisFreq: '125.800 MHz',
      towerFreq: '118.900 MHz',
      approachFreq: '119.400 MHz',
      groundFreq: '121.600 MHz',
      runways: [
        { id: '34L', heading: 336, length: 4850, width: 60, status: 'OPERATIONAL', ilsFreq: '110.1 I-DOH' },
        { id: '34R', heading: 336, length: 4250, width: 60, status: 'OPERATIONAL', ilsFreq: '110.5 I-HAM' }
      ]
    }
  });
});

app.post('/api/v1/cpdlc', async (req, res) => {
  const { callsign, instruction, altitude, heading, speed, waypoint, emergency } = req.body;
  
  const instructionDesc = [
    altitude ? `climb/descend to FL${altitude}` : '',
    heading ? `turn to heading ${heading} degrees` : '',
    speed ? `adjust speed to ${speed} knots` : '',
    waypoint ? `proceed direct to waypoint ${waypoint}` : '',
    emergency ? `declare emergency: ${emergency}` : '',
    instruction || 'maintain present position'
  ].filter(Boolean).join(', ');

  const prompt = `You are an airline captain of flight ${callsign || 'Emirates 412'} flying through Arab airspace under Air Traffic Control (ATC).
The Air Traffic Controller just issued this clearance or instruction: "${instructionDesc}".
Generate a professional, high-fidelity airline pilot CPDLC readback (Controller-Pilot Data Link Communications) and VHF voice transcript.
Provide the output strictly as a JSON object matching this schema:
{
  "english": "Strict professional English readback including callsign and instruction back",
  "arabic": "Proper Arabic readback using standard Arab Civil Aviation phraseology",
  "audioTranscript": "VHF phonetics representation of the English, e.g., 'Emirates four one two, climb flight level three five zero, heading one two zero'",
  "speaker": "PILOT",
  "squawk": "A simulated 4-digit octal code if transponder instruction requested, else keep empty"
}
Ensure there is absolutely NO markdown formatting or wrapping outside of the JSON object (do not write \`\`\`json, just pure raw JSON). Output the JSON directly.`;

  if (ai) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              english: { type: Type.STRING },
              arabic: { type: Type.STRING },
              audioTranscript: { type: Type.STRING },
              speaker: { type: Type.STRING },
              squawk: { type: Type.STRING }
            },
            required: ['english', 'arabic', 'audioTranscript', 'speaker']
          }
        }
      });

      const responseText = response.text;
      if (responseText) {
        return res.json(JSON.parse(responseText.trim()));
      }
    } catch (e) {
      console.error('Gemini API Error, falling back to synthetic templates:', e);
    }
  }

  // Fallback to high-quality synthetic templates if Gemini is missing or fails
  const mockSquawk = String(Math.floor(Math.random() * 7000) + 1000);
  let cpdlcEn = `ROGER, ${callsign || 'EK412'}. `;
  let cpdlcAr = `علم، ${callsign || 'طيران الإمارات ٤١٢'}. `;
  let phonetic = `${callsign || 'Emirates four one two'}. `;

  if (altitude) {
    cpdlcEn += `Climbing to Flight Level ${altitude}. `;
    cpdlcAr += `صعود إلى مستوى الطيران ${altitude}. `;
    phonetic += `climbing flight level ${altitude}. `;
  }
  if (heading) {
    cpdlcEn += `Heading ${heading}. `;
    cpdlcAr += `الاتجاه ${heading}. `;
    phonetic += `heading ${heading}. `;
  }
  if (waypoint) {
    cpdlcEn += `Direct to waypoint ${waypoint}. `;
    cpdlcAr += `مباشرة إلى النقطة الملاحية ${waypoint}. `;
    phonetic += `direct ${waypoint.split('').join(' ')}. `;
  }
  if (emergency) {
    cpdlcEn += `MAYDAY MAYDAY MAYDAY, declaring emergency ${emergency}. `;
    cpdlcAr += `ميديه ميديه ميديه، نعلن حالة طوارئ: ${emergency}. `;
    phonetic += `mayday mayday mayday, declaring emergency. `;
  }

  return res.json({
    english: cpdlcEn.trim() || `ROGER, maintaining flight level and course, ${callsign}.`,
    arabic: cpdlcAr.trim() || `علم، نحافظ على مستوى الطيران والمسار المحدد، ${callsign}.`,
    audioTranscript: phonetic.trim(),
    speaker: 'PILOT',
    squawk: mockSquawk
  });
});

app.post('/api/v1/logs', (req, res) => {
  const { callsign, action, details, operator } = req.body;
  const newLog: AuditLog = {
    id: `log_${Math.random().toString(36).substr(2, 9)}`,
    timestamp: new Date().toISOString(),
    callsign: callsign || 'SYSTEM',
    action: action || 'CLEARANCE',
    details: details || '',
    operator: operator || 'ATC_DXB_EAST'
  };
  auditLogs.push(newLog);
  res.json({ success: true, log: newLog });
});

app.get('/api/v1/logs', (req, res) => {
  res.json(auditLogs);
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);
