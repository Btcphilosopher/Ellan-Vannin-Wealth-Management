/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { create } from 'zustand';
import { 
  SimulationState, 
  NbpBalanceSheet, 
  Bank, 
  PaymentInstitution, 
  Transaction, 
  Wallet, 
  ProgrammablePayment, 
  Voucher, 
  TokenisedAsset, 
  KycAlert, 
  CyberIncident, 
  InfrastructureMetrics, 
  EconomicStats, 
  SystemFailure, 
  NodeFlow, 
  Merchant, 
  EvMachine, 
  AiAgent, 
  ScenarioType,
  TransactionStatus,
  TransactionType
} from './types';

// Helper to format simulation time
export const formatSimulationTime = (date: Date): string => {
  const pad = (n: number) => n.toString().padStart(2, '0');
  const d = pad(date.getDate());
  const m = pad(date.getMonth() + 1);
  const y = date.getFullYear();
  const h = pad(date.getHours());
  const min = pad(date.getMinutes());
  const s = pad(date.getSeconds());
  return `${d}.${m}.${y} ${h}:${min}:${s}`;
};

interface SimulationActions {
  tick: () => void;
  setSpeed: (speed: number) => void;
  setModelMode: (mode: 'Account' | 'Wallet') => void;
  setScenario: (scenario: ScenarioType) => void;
  
  // NBP Core Operations
  issueCbdc: (amount: number, bankId: string, fundingType: 'RESERVES' | 'LOAN') => boolean;
  redeemCbdc: (amount: number, bankId: string) => boolean;
  verifyLedger: () => { success: boolean; message: string; details: string };
  
  // Wallet / Consumer Transactions
  executeWalletTransaction: (type: TransactionType, amount: number, receiverName: string, channel: 'QR' | 'NFC' | 'Instant' | 'Offline') => boolean;
  syncOfflineBalance: () => void;
  
  // Interbank & Settlement Operations
  transferInterbank: (senderBankId: string, receiverBankId: string, amount: number, asset: 'Cyfrowy Złoty' | 'Depozyt Bankowy') => boolean;
  resolveLiquidityShortage: (bankId: string) => void;
  
  // Programmable Payments & Vouchers
  createProgrammablePayment: (payment: Omit<ProgrammablePayment, 'id' | 'status' | 'progressStep'>) => void;
  advanceProgrammablePayment: (id: string) => void;
  spendVoucher: (voucherId: string, merchantId: string) => boolean;
  
  // Tokenisation & Securities (DvP)
  executeSecuritiesTrade: (assetId: string, buyerBankId: string) => boolean;
  
  // Failure Simulation
  toggleFailure: (failureId: string) => void;
  resetFailures: () => void;
  
  // Interactive Demos
  advanceEvMachine: () => void;
  resetEvMachine: () => void;
  advanceAiAgent: () => void;
  resetAiAgent: () => void;
  
  // Administrative / Audits
  clearAuditLogs: () => void;
  resolveKycAlert: (alertId: string, approve: boolean) => void;
  resolveCyberIncident: (incidentId: string) => void;
}

// Initial state values
const INITIAL_NBP_BALANCE_SHEET: NbpBalanceSheet = {
  securities: 310_000_000_000,
  foreignAssets: 180_000_000_000,
  loans: 45_000_000_000,
  repo: 25_000_000_000,
  collateralisedOperations: 15_000_000_000,
  
  banknotes: 120_000_000_000,
  bankReserves: 110_000_000_000,
  digitalZloty: 284_700_000_000,
  otherLiabilities: 10_300_000_000,
  
  capital: 50_000_000_000
};

const INITIAL_BANKS: Bank[] = [
  { id: 'bank-mazowiecki', name: 'Bank Mazowiecki', deposits: 145_000_000_000, loans: 110_000_000_000, reserves: 15_200_000_000, digitalZloty: 34_200_000_000, securities: 42_000_000_000, liquidity: 15_200_000_000, capital: 14_000_000_000, collateral: 18_000_000_000, paymentVolume: 12_400_000_000, settlementQueueLength: 0, riskScore: 12 },
  { id: 'bank-baltycki', name: 'Bank Bałtycki', deposits: 112_000_000_000, loans: 85_000_000_000, reserves: 12_800_000_000, digitalZloty: 28_500_000_000, securities: 31_000_000_000, liquidity: 12_800_000_000, capital: 11_000_000_000, collateral: 15_000_000_000, paymentVolume: 8_900_000_000, settlementQueueLength: 0, riskScore: 15 },
  { id: 'bank-slaski', name: 'Bank Śląski Nowej Generacji', deposits: 168_000_000_000, loans: 130_000_000_000, reserves: 18_500_000_000, digitalZloty: 41_200_000_000, securities: 48_000_000_000, liquidity: 18_500_000_000, capital: 16_500_000_000, collateral: 22_000_000_000, paymentVolume: 16_100_000_000, settlementQueueLength: 0, riskScore: 9 },
  { id: 'polonia-bank', name: 'Polonia Bank', deposits: 72_000_000_000, loans: 58_000_000_000, reserves: 9_100_000_000, digitalZloty: 18_400_000_000, securities: 19_000_000_000, liquidity: 9_100_000_000, capital: 7_500_000_000, collateral: 10_000_000_000, paymentVolume: 4_500_000_000, settlementQueueLength: 0, riskScore: 18 },
  { id: 'wisla-bank', name: 'Wisła Bank', deposits: 94_000_000_000, loans: 74_000_000_000, reserves: 11_400_000_000, digitalZloty: 22_800_000_000, securities: 26_000_000_000, liquidity: 11_400_000_000, capital: 9_000_000_000, collateral: 12_000_000_000, paymentVolume: 6_700_000_000, settlementQueueLength: 0, riskScore: 14 },
  { id: 'warsaw-comm', name: 'Warsaw Commercial Bank', deposits: 210_000_000_000, loans: 165_000_000_000, reserves: 24_300_000_000, digitalZloty: 55_100_000_000, securities: 62_000_000_000, liquidity: 24_300_000_000, capital: 22_000_000_000, collateral: 30_000_000_000, paymentVolume: 21_200_000_000, settlementQueueLength: 0, riskScore: 8 },
  { id: 'krakow-fin', name: 'Kraków Financial', deposits: 64_000_000_000, loans: 49_000_000_000, reserves: 8_200_000_000, digitalZloty: 16_300_000_000, securities: 18_000_000_000, liquidity: 8_200_000_000, capital: 6_800_000_000, collateral: 8_500_000_000, paymentVolume: 3_900_000_000, settlementQueueLength: 0, riskScore: 21 },
  { id: 'poznan-bank', name: 'Poznań Bank', deposits: 88_000_000_000, loans: 69_000_000_000, reserves: 10_500_000_000, digitalZloty: 22_500_000_000, securities: 25_000_000_000, liquidity: 10_500_000_000, capital: 8_400_000_000, collateral: 11_000_000_000, paymentVolume: 5_800_000_000, settlementQueueLength: 0, riskScore: 13 }
];

const INITIAL_PAYMENT_INSTITUTIONS: PaymentInstitution[] = [
  { id: 'orzel-pay', name: 'Orzeł Pay S.A.', customers: 850000, transactionVolume: 125000000, digitalZlotyBalance: 12500000, electronicMoney: 45000000, liquidity: 25000000, apiStatus: 'ONLINE', risk: 8, compliance: 98 },
  { id: 'wisla-mobile', name: 'Wisła Mobile Sp. z o.o.', customers: 1200000, transactionVolume: 198000000, digitalZlotyBalance: 18400000, electronicMoney: 62000000, liquidity: 35000000, apiStatus: 'ONLINE', risk: 12, compliance: 95 },
  { id: 'syrena-transfer', name: 'Syrena Transfer Krajowy', customers: 450000, transactionVolume: 82000000, digitalZlotyBalance: 6800000, electronicMoney: 22000000, liquidity: 15000000, apiStatus: 'ONLINE', risk: 15, compliance: 99 },
  { id: 'tatry-fin', name: 'Tatry Finanse Cyfrowe', customers: 650000, transactionVolume: 94000000, digitalZlotyBalance: 7900000, electronicMoney: 28000000, liquidity: 18000000, apiStatus: 'ONLINE', risk: 11, compliance: 94 }
];

const INITIAL_WALLET: Wallet = {
  ownerName: 'ANNA KOWALSKA',
  balance: 18420.75,
  available: 17920.75,
  offline: 500.00,
  dailyLimit: 25000.00,
  dailySpent: 0.00,
  identityConfirmed: true,
  intermediaryBank: 'Bank Mazowiecki'
};

const INITIAL_FAILURES: SystemFailure[] = [
  { id: 'fail-bank', label: 'AWARIA BANKU (Mazowiecki)', active: false, description: 'Bank Mazowiecki doświadcza awarii systemów IT. Blokada autoryzacji CBDC i depozytów.' },
  { id: 'fail-node', label: 'AWARIA WĘZŁA LEDGERA', active: false, description: 'Jeden z uprawnionych węzłów rejestru centralnego traci synchronizację. Opóźnienie zapisu.' },
  { id: 'fail-liquidity', label: 'BRAK PŁYNNOŚCI (Bank Śląski)', active: false, description: 'Nagły odpływ płynności w Banku Śląskim. Kolejka rozrachunkowa ulega wydłużeniu.' },
  { id: 'fail-network', label: 'AWARIA SIECI KRAJOWEJ', active: false, description: 'Szeroka awaria sieci telekomunikacyjnej. Przejście terminali płatniczych w tryb Offline.' },
  { id: 'fail-cyber', label: 'ATAK CYBERNETYCZNY (DDoS)', active: false, description: 'Zmasowany atak na infrastrukturę NBP. Spadek wydajności TPS i wzrost API latency.' },
  { id: 'fail-default', label: 'DEFAULT KONTRAHENTA', active: false, description: 'Niewypłacalność dużej instytucji niebankowej. Propagacja ryzyka systemowego.' }
];

const INITIAL_NODES: NodeFlow[] = [
  { id: 'warszawa', name: 'Warszawa', x: 62, y: 50, flowIn: 48000000, flowOut: 45000000, flowCbdc: 12000000 },
  { id: 'krakow', name: 'Kraków', x: 60, y: 82, flowIn: 22000000, flowOut: 21000000, flowCbdc: 5500000 },
  { id: 'wroclaw', name: 'Wrocław', x: 31, y: 68, flowIn: 18500000, flowOut: 18000000, flowCbdc: 4600000 },
  { id: 'poznan', name: 'Poznań', x: 28, y: 44, flowIn: 15800000, flowOut: 15200000, flowCbdc: 3900000 },
  { id: 'gdansk', name: 'Gdańsk', x: 44, y: 15, flowIn: 14500000, flowOut: 14000000, flowCbdc: 3600000 },
  { id: 'lodz', name: 'Łódź', x: 50, y: 52, flowIn: 11200000, flowOut: 11000000, flowCbdc: 2800000 },
  { id: 'katowice', name: 'Katowice', x: 50, y: 79, flowIn: 16000000, flowOut: 15800000, flowCbdc: 4000000 },
  { id: 'szczecin', name: 'Szczecin', x: 10, y: 28, flowIn: 9800000, flowOut: 9600000, flowCbdc: 2450000 },
  { id: 'lublin', name: 'Lublin', x: 80, y: 62, flowIn: 8500000, flowOut: 8300000, flowCbdc: 2100000 },
  { id: 'bialystok', name: 'Białystok', x: 82, y: 32, flowIn: 6800000, flowOut: 6600000, flowCbdc: 1700000 },
  { id: 'rzeszow', name: 'Rzeszów', x: 74, y: 84, flowIn: 5900000, flowOut: 5700000, flowCbdc: 1450000 },
  { id: 'olsztyn', name: 'Olsztyn', x: 60, y: 24, flowIn: 5200000, flowOut: 5100000, flowCbdc: 1300000 }
];

const INITIAL_MERCHANTS: Merchant[] = [
  { id: 'zabka-synth', name: 'Zielony Market Spożywczy', category: 'Spożywczy', volume: 450000, avgPayment: 42.50, cbdcShare: 28, qrSupport: true, nfcSupport: true, instantPaymentSupport: true, voucherSupport: true, latency: 0.35 },
  { id: 'orlen-synth', name: 'Wisła Petro-Stacje', category: 'Paliwowy', volume: 1850000, avgPayment: 210.00, cbdcShare: 24, qrSupport: true, nfcSupport: true, instantPaymentSupport: true, voucherSupport: true, latency: 0.45 },
  { id: 'allegro-synth', name: 'Vistula Plaza E-Commerce', category: 'E-commerce', volume: 4500000, avgPayment: 155.00, cbdcShare: 35, qrSupport: true, nfcSupport: false, instantPaymentSupport: true, voucherSupport: false, latency: 0.28 },
  { id: 'pge-synth', name: 'Krajowy Operator Energii', category: 'Energia', volume: 8500000, avgPayment: 480.00, cbdcShare: 18, qrSupport: false, nfcSupport: false, instantPaymentSupport: true, voucherSupport: true, latency: 0.60 },
  { id: 'pkp-synth', name: 'Koleje Bałtyckie', category: 'Transport', volume: 720000, avgPayment: 68.00, cbdcShare: 32, qrSupport: true, nfcSupport: true, instantPaymentSupport: true, voucherSupport: true, latency: 0.40 },
  { id: 'hotel-synth', name: 'Hotel Tatry Resort', category: 'Hotele', volume: 280000, avgPayment: 850.00, cbdcShare: 15, qrSupport: true, nfcSupport: true, instantPaymentSupport: true, voucherSupport: true, latency: 0.50 }
];

const INITIAL_VOUCHERS: Voucher[] = [
  { id: 'voucher-1', title: 'Bon Energetyczny 2026', type: 'Energy', amount: 5000.00, allowedCategory: 'Energia', expiryDate: '31.12.2026', status: 'AKTYWNY', owner: 'ANNA KOWALSKA' },
  { id: 'voucher-2', title: 'Cyfrowy Bon Turystyczny', type: 'Tourism', amount: 1500.00, allowedCategory: 'Turystyka', expiryDate: '30.06.2027', status: 'AKTYWNY', owner: 'ANNA KOWALSKA' },
  { id: 'voucher-3', title: 'SME Subsydium Paliwowe', type: 'SME', amount: 12000.00, allowedCategory: 'Paliwowy', expiryDate: '30.11.2026', status: 'AKTYWNY', owner: 'Wisła Petro-Stacje' }
];

const INITIAL_TOKENISED_ASSETS: TokenisedAsset[] = [
  { id: 'bond-os2029', name: 'Obligacja Skarbowa OS1029', type: 'Obligacja Skarbowa', nominal: 1000000, price: 980000, yield: 6.25, maturity: '15.10.2029', owner: 'Bank Mazowiecki', settlementStatus: 'AKTYWNY' },
  { id: 'bond-bs2026', name: 'Bon Skarbowy BS0926', type: 'Bon Skarbowy', nominal: 5000000, price: 4850000, yield: 5.80, maturity: '18.12.2026', owner: 'Bank Bałtycki', settlementStatus: 'AKTYWNY' },
  { id: 'corp-pkn2030', name: 'Obligacja Wisła Petro PKN30', type: 'Obligacja Przedsiębiorstwa', nominal: 2000000, price: 1950000, yield: 7.45, maturity: '30.06.2030', owner: 'Bank Śląski Nowej Generacji', settlementStatus: 'AKTYWNY' }
];

const INITIAL_PROGRAMMABLE_PAYMENTS: ProgrammablePayment[] = [
  { id: 'prog-escrow-1', title: 'Zabezpieczona płatność za maszyny', amount: 2500000, conditionType: 'Dostawa', conditionText: 'Potwierdzenie odbioru technicznego w Gdańsku', status: 'OCZEKUJE', sender: 'Bank Mazowiecki', recipient: 'Przemysłowy Dostawca S.A.', progressStep: 0 },
  { id: 'prog-m2m-1', title: 'Automatyczne rozliczenie floty EV', amount: 450, conditionType: 'M2M', conditionText: 'Autoryzacja portfela pojazdu i pobór energii', status: 'OCZEKUJE', sender: 'Flota Sp. z o.o.', recipient: 'Wisła Petro-Stacje', progressStep: 0 }
];

const INITIAL_KYC_ALERTS: KycAlert[] = [
  { id: 'PLN-48291', amount: 18400000, type: 'NIETYPOWA AKTYWNOŚĆ', risk: 'HIGH', status: 'WERYFIKACJA', timestamp: '18.09.2026 09:32:11', details: 'Nietypowy transfer środków CBDC o dużej wartości poza standardowym oknem rozliczeniowym.' },
  { id: 'PLN-48292', amount: 48000, type: 'STRUKTURYZACJA', risk: 'MEDIUM', status: 'WERYFIKACJA', timestamp: '18.09.2026 09:15:42', details: 'Seryjne mikropłatności o wartości tuż poniżej limitu raportowania (15 000 EUR).' }
];

const INITIAL_CYBER_INCIDENTS: CyberIncident[] = [
  { id: 'CBDC-PL-00482', type: 'ANOMALIA TRANSAKCYJNA', bank: 'Bank Mazowiecki', amount: 420000000, status: 'ANALIZA', timestamp: '18.09.2026 08:52:14' }
];

const INITIAL_ECONOMICS: EconomicStats = {
  cbdcSupply: 284.7,
  bankDeposits: 954.2,
  bankReserves: 110.0,
  moneySupply: 1348.9, // M3
  velocity: 1.42,
  credit: 724.8,
  liquidity: 110.0,
  interestRates: 5.75, // Stopa NBP
  consumption: 104.2,
  investment: 98.5,
  gdp: 3.2,
  inflation: 4.1,
  digitalAdoption: 42.5
};

const INITIAL_INFRASTRUCTURE: InfrastructureMetrics = {
  cpu: 24,
  memory: 42,
  networkLatency: 4,
  apiLatency: 12,
  ledgerSyncStatus: 'ZAKTUALIZOWANY',
  tps: 4812,
  queueDepth: 0,
  errorRate: 0.02
};

// Seed-based random generator to keep things deterministic yet lively
let seed = 42;
function random() {
  const x = Math.sin(seed++) * 10000;
  return x - Math.floor(x);
}

// Generate unique transaction ID
function generateTxId(): string {
  const chars = '0123456789ABCDEF';
  let res = 'PLN-CBDC-';
  for (let i = 0; i < 6; i++) {
    res += chars[Math.floor(random() * 16)];
  }
  return res;
}

export const useSimulationStore = create<SimulationState & SimulationActions>((set, get) => ({
  // Core State
  time: '18.09.2026 09:42:17',
  nbpBalanceSheet: { ...INITIAL_NBP_BALANCE_SHEET },
  banks: [ ...INITIAL_BANKS ],
  paymentInstitutions: [ ...INITIAL_PAYMENT_INSTITUTIONS ],
  wallet: { ...INITIAL_WALLET },
  transactions: [],
  programmablePayments: [ ...INITIAL_PROGRAMMABLE_PAYMENTS ],
  vouchers: [ ...INITIAL_VOUCHERS ],
  tokenisedAssets: [ ...INITIAL_TOKENISED_ASSETS ],
  kycAlerts: [ ...INITIAL_KYC_ALERTS ],
  cyberIncidents: [ ...INITIAL_CYBER_INCIDENTS ],
  infrastructure: { ...INITIAL_INFRASTRUCTURE },
  economics: { ...INITIAL_ECONOMICS },
  failures: [ ...INITIAL_FAILURES ],
  nodes: [ ...INITIAL_NODES ],
  merchants: [ ...INITIAL_MERCHANTS ],
  evMachine: {
    battery: 31,
    chargingNeeded: true,
    maxAuthorised: 500,
    stationVerified: false,
    priceVerified: false,
    walletAuthorised: false,
    zlotySpent: 0,
    status: 'IDLE'
  },
  aiAgent: {
    id: 'wisla-01',
    name: 'WISŁA-01',
    balance: 50000,
    maxTransactionLimit: 5000,
    approvedCategories: ['Energia', 'Transport', 'Logistyka'],
    currentTask: 'Brak aktywnego zadania. Oczekiwanie na uruchomienie autonomiczne.',
    status: 'IDLE'
  },
  simulationSpeed: 1,
  modelMode: 'Account',
  selectedScenario: 'BAZOWY',

  // Actions
  setSpeed: (speed: number) => set({ simulationSpeed: speed }),
  setModelMode: (mode: 'Account' | 'Wallet') => set({ modelMode: mode }),
  
  setScenario: (scenario: ScenarioType) => set(state => {
    // Modify economics metrics based on scenario selection
    const baseEco = { ...INITIAL_ECONOMICS };
    let newEco = { ...baseEco };
    
    switch (scenario) {
      case 'WYSOKA_ADOPCJA':
        newEco.digitalAdoption = 82.0;
        newEco.cbdcSupply = 412.5;
        newEco.bankDeposits = 826.1; // Outflow of deposits into CBDC
        newEco.velocity = 1.68;
        break;
      case 'NISKA_ADOPCJA':
        newEco.digitalAdoption = 12.5;
        newEco.cbdcSupply = 120.4;
        newEco.bankDeposits = 1118.5;
        newEco.velocity = 1.21;
        break;
      case 'SZOK_PŁYNNOŚCIOWY':
        newEco.liquidity = 42.0;
        newEco.credit = 610.2;
        newEco.consumption = 92.1;
        break;
      case 'SZOK_SYSTEMU_PŁATNICZEGO':
        newEco.velocity = 0.65;
        newEco.consumption = 85.0;
        break;
      case 'WYSOKA_TOKENIZACJA':
        newEco.investment = 125.4;
        newEco.velocity = 1.55;
        break;
      case 'ODPŁYW_DEPOZYTÓW':
        newEco.bankDeposits = 650.0;
        newEco.cbdcSupply = 512.0;
        newEco.liquidity = 65.0;
        newEco.credit = 520.0;
        break;
      case 'KRYZYS_FINANSOWY':
        newEco.inflation = 8.5;
        newEco.gdp = -2.1;
        newEco.credit = 510.0;
        newEco.interestRates = 7.25;
        newEco.consumption = 78.4;
        newEco.investment = 62.0;
        break;
      case 'BAZOWY':
      default:
        newEco = { ...INITIAL_ECONOMICS };
        break;
    }

    // Double-entry: Adjust NBP Balance Sheet according to scenario
    const newNbp = { ...state.nbpBalanceSheet };
    newNbp.digitalZloty = newEco.cbdcSupply * 1_000_000_000;
    // Counterbalance NBP Liabilities: if digitalZloty changes, we adjust reserves or securities to balance AKTYWA = PASYWA + KAPITAŁ
    const liabilitiesDiff = newNbp.digitalZloty - state.nbpBalanceSheet.digitalZloty;
    newNbp.bankReserves = Math.max(10_000_000_000, newNbp.bankReserves - liabilitiesDiff * 0.5);
    newNbp.securities = Math.max(150_000_000_000, newNbp.securities + liabilitiesDiff * 0.5);

    // Reconcile banks
    const updatedBanks = state.banks.map(bank => {
      if (scenario === 'ODPŁYW_DEPOZYTÓW' || scenario === 'KRYZYS_FINANSOWY') {
        return {
          ...bank,
          deposits: bank.deposits * 0.7,
          digitalZloty: bank.digitalZloty * 1.4,
          liquidity: bank.liquidity * 0.6,
          riskScore: Math.min(95, bank.riskScore + 25)
        };
      }
      return {
        ...bank,
        riskScore: Math.max(5, Math.min(95, bank.riskScore + (scenario === 'BAZOWY' ? 0 : 5)))
      };
    });

    return {
      selectedScenario: scenario,
      economics: newEco,
      nbpBalanceSheet: newNbp,
      banks: updatedBanks
    };
  }),

  // Double-entry CBDC Issuance
  issueCbdc: (amount: number, bankId: string, fundingType: 'RESERVES' | 'LOAN') => {
    let success = false;
    
    set(state => {
      const targetBank = state.banks.find(b => b.id === bankId);
      if (!targetBank) return {};

      const nbp = { ...state.nbpBalanceSheet };
      const banks = state.banks.map(b => {
        if (b.id === bankId) {
          if (fundingType === 'RESERVES') {
            // Convertible reserves: Bank reserves drop, digital złoty goes up
            if (b.reserves < amount) {
              return b; // Insufficient reserves
            }
            success = true;
            return {
              ...b,
              reserves: b.reserves - amount,
              digitalZloty: b.digitalZloty + amount,
              liquidity: b.liquidity - amount // Reserves converted, liquidity remains, but direct reserves cash changed
            };
          } else {
            // Funded via NBP credit: Bank receives loan from NBP, liabilities increase
            success = true;
            return {
              ...b,
              loans: b.loans + amount,
              digitalZloty: b.digitalZloty + amount,
              capital: b.capital // stable
            };
          }
        }
        return b;
      });

      if (!success) return {};

      // Reflect in NBP double-entry:
      if (fundingType === 'RESERVES') {
        // Reserves decrease, Digital Złoty increases on the liabilities side.
        // Total Liabilities remain identical, total assets remain identical. Balanced!
        nbp.bankReserves -= amount;
        nbp.digitalZloty += amount;
      } else {
        // NBP provides a loan: Loans (Assets) increase, Digital Złoty (Liabilities) increases.
        // Both sides increase by amount. Balanced!
        nbp.loans += amount;
        nbp.digitalZloty += amount;
      }

      // Generate transaction log
      const tx: Transaction = {
        id: generateTxId(),
        timestamp: formatSimulationTime(new Date()),
        sender: 'Narodowy Bank Polski',
        receiver: targetBank.name,
        institution: 'NBP',
        asset: 'Cyfrowy Złoty',
        amount: amount,
        status: 'FINALIZACJA',
        type: 'Rządowa',
        authorization: 'SIG_NBP_' + Math.floor(random() * 1000000),
        settlement: 'Instant (RTGS)',
        auditId: 'AUDIT-' + Math.floor(random() * 1000000)
      };

      return {
        nbpBalanceSheet: nbp,
        banks,
        transactions: [tx, ...state.transactions].slice(0, 100)
      };
    });

    return success;
  },

  // Redemption
  redeemCbdc: (amount: number, bankId: string) => {
    let success = false;

    set(state => {
      const targetBank = state.banks.find(b => b.id === bankId);
      if (!targetBank || targetBank.digitalZloty < amount) return {};

      const nbp = { ...state.nbpBalanceSheet };
      const banks = state.banks.map(b => {
        if (b.id === bankId) {
          success = true;
          return {
            ...b,
            digitalZloty: b.digitalZloty - amount,
            reserves: b.reserves + amount // converts back to traditional reserves
          };
        }
        return b;
      });

      if (!success) return {};

      // Reflect in NBP double-entry:
      // Digital Złoty decreases, Bank Reserves increases on Liabilities side.
      // Total liabilities remain balanced. Total Assets unchanged. Balanced!
      nbp.digitalZloty -= amount;
      nbp.bankReserves += amount;

      const tx: Transaction = {
        id: generateTxId(),
        timestamp: formatSimulationTime(new Date()),
        sender: targetBank.name,
        receiver: 'Narodowy Bank Polski',
        institution: 'NBP',
        asset: 'Cyfrowy Złoty',
        amount: amount,
        status: 'FINALIZACJA',
        type: 'Rządowa',
        authorization: 'SIG_REDEEM_' + Math.floor(random() * 1000000),
        settlement: 'Instant (RTGS)',
        auditId: 'AUDIT-' + Math.floor(random() * 1000000)
      };

      return {
        nbpBalanceSheet: nbp,
        banks,
        transactions: [tx, ...state.transactions].slice(0, 100)
      };
    });

    return success;
  },

  // Verify Ledger integrity
  verifyLedger: () => {
    const state = get();
    // Audit check: NBP Assets = Liabilities + Capital
    const assets = state.nbpBalanceSheet.securities + state.nbpBalanceSheet.foreignAssets + state.nbpBalanceSheet.loans + state.nbpBalanceSheet.repo + state.nbpBalanceSheet.collateralisedOperations;
    const liabilitiesAndCapital = state.nbpBalanceSheet.banknotes + state.nbpBalanceSheet.bankReserves + state.nbpBalanceSheet.digitalZloty + state.nbpBalanceSheet.otherLiabilities + state.nbpBalanceSheet.capital;
    
    // Check if the sum of all banks' reserves matches NBP liabilities bankReserves
    const sumReserves = state.banks.reduce((acc, b) => acc + b.reserves, 0);
    const reservesReconciled = Math.abs(sumReserves - state.nbpBalanceSheet.bankReserves) < 100; // tolerance

    const success = (assets === liabilitiesAndCapital) && reservesReconciled;
    return {
      success,
      message: success ? 'REJESTR ZWERYFIKOWANY INTEGRALNIE' : 'NIEZGODNOŚĆ KSIĘGOWA WYKRYTA',
      details: `Bilans NBP: Aktywa = ${assets.toLocaleString('pl-PL')} zł, Pasywa + Kapitał = ${liabilitiesAndCapital.toLocaleString('pl-PL')} zł. Rezerwy banków: Rejestr NBP = ${state.nbpBalanceSheet.bankReserves.toLocaleString('pl-PL')} zł, Suma rezerw bankowych = ${sumReserves.toLocaleString('pl-PL')} zł.`
    };
  },

  // Wallet user transaction
  executeWalletTransaction: (type: TransactionType, amount: number, receiverName: string, channel: 'QR' | 'NFC' | 'Instant' | 'Offline') => {
    let success = false;
    const state = get();

    // Check if the consumer cell phone has been disabled or is offline
    const isNetworkFailure = state.failures.find(f => f.id === 'fail-network')?.active;
    const isBankFailure = state.failures.find(f => f.id === 'fail-bank')?.active;

    if (channel !== 'Offline' && isNetworkFailure) {
      // Cannot execute non-offline transactions if network is down!
      return false;
    }

    if (isBankFailure && state.wallet.intermediaryBank === 'Bank Mazowiecki' && channel !== 'Offline') {
      // Bank Mazowiecki is down, cannot process transactions online!
      return false;
    }

    set(state => {
      const wallet = { ...state.wallet };
      
      if (channel === 'Offline') {
        if (wallet.offline < amount) return {}; // Insufficient offline balance
        success = true;
        wallet.offline -= amount;
        wallet.balance -= amount;
        wallet.dailySpent += amount;
      } else {
        if (wallet.available < amount) return {}; // Insufficient online balance
        success = true;
        wallet.available -= amount;
        wallet.balance -= amount;
        wallet.dailySpent += amount;
      }

      // Find intermediary bank and charge its Digital Złoty reserve
      const updatedBanks = state.banks.map(b => {
        if (b.name === wallet.intermediaryBank) {
          // Decrement bank CBDC pool
          return {
            ...b,
            digitalZloty: Math.max(0, b.digitalZloty - amount),
            paymentVolume: b.paymentVolume + amount
          };
        }
        return b;
      });

      // Find if receiver is a synthetic merchant to enrich their metrics
      const updatedMerchants = state.merchants.map(m => {
        if (m.name === receiverName || m.id === receiverName) {
          return {
            ...m,
            volume: m.volume + amount,
            cbdcShare: Math.min(100, m.cbdcShare + 0.1)
          };
        }
        return m;
      });

      // Update NBP Balance Sheet - Digital Złoty in circulation remains balanced since it resides in wallet now or transferred to receiver, 
      // but let's reduce digitalZloty total if spent on a non-cbdc merchant, or keep same.
      // To keep standard: it flows into merchant's wallet/account
      const nbp = { ...state.nbpBalanceSheet };
      // CBDC remains in circulation.

      const tx: Transaction = {
        id: generateTxId(),
        timestamp: formatSimulationTime(new Date()),
        sender: 'ANNA KOWALSKA',
        receiver: receiverName,
        institution: wallet.intermediaryBank,
        asset: 'Cyfrowy Złoty',
        amount: amount,
        status: 'FINALIZACJA',
        type: type,
        authorization: 'SIG_AUTH_' + Math.floor(random() * 1000000),
        settlement: channel === 'Offline' ? 'Offline Sync' : 'Instant (RTGS)',
        auditId: 'AUDIT-' + Math.floor(random() * 1000000)
      };

      // KYC Trigger for massive payments
      let updatedKycAlerts = [ ...state.kycAlerts ];
      if (amount > 10000) {
        const newAlert: KycAlert = {
          id: 'PLN-' + Math.floor(10000 + random() * 90000),
          amount,
          type: 'NIETYPOWA AKTYWNOŚĆ',
          risk: amount > 50000 ? 'HIGH' : 'MEDIUM',
          status: 'WERYFIKACJA',
          timestamp: formatSimulationTime(new Date()),
          details: `Portfel ANNA KOWALSKA wykonał transakcję o wysokiej wartości przez kanał ${channel}.`
        };
        updatedKycAlerts = [newAlert, ...updatedKycAlerts];
      }

      return {
        wallet,
        banks: updatedBanks,
        merchants: updatedMerchants,
        transactions: [tx, ...state.transactions].slice(0, 100),
        kycAlerts: updatedKycAlerts
      };
    });

    return success;
  },

  syncOfflineBalance: () => {
    set(state => {
      // Reconciles offline wallet with online.
      // Moves offline quota to online available if requested.
      const wallet = { ...state.wallet };
      const transferBack = wallet.offline;
      
      wallet.available += transferBack;
      wallet.offline = 0;

      const tx: Transaction = {
        id: generateTxId(),
        timestamp: formatSimulationTime(new Date()),
        sender: 'OFFLINE_CHIP',
        receiver: 'ONLINE_SECURE',
        institution: wallet.intermediaryBank,
        asset: 'Cyfrowy Złoty',
        amount: transferBack,
        status: 'FINALIZACJA',
        type: 'Rządowa',
        authorization: 'SYNC_OFFLINE_' + Math.floor(random() * 1000000),
        settlement: 'Offline Sync',
        auditId: 'AUDIT-' + Math.floor(random() * 1000000)
      };

      return {
        wallet,
        transactions: [tx, ...state.transactions].slice(0, 100)
      };
    });
  },

  // Interbank operations
  transferInterbank: (senderBankId: string, receiverBankId: string, amount: number, asset: 'Cyfrowy Złoty' | 'Depozyt Bankowy') => {
    let success = false;
    
    set(state => {
      const sender = state.banks.find(b => b.id === senderBankId);
      const receiver = state.banks.find(b => b.id === receiverBankId);
      
      if (!sender || !receiver) return {};

      // Check balance constraints
      if (asset === 'Cyfrowy Złoty') {
        if (sender.digitalZloty < amount) return {};
      } else {
        if (sender.deposits < amount) return {};
      }

      success = true;
      const updatedBanks = state.banks.map(b => {
        if (b.id === senderBankId) {
          return {
            ...b,
            digitalZloty: asset === 'Cyfrowy Złoty' ? b.digitalZloty - amount : b.digitalZloty,
            deposits: asset === 'Depozyt Bankowy' ? b.deposits - amount : b.deposits,
            paymentVolume: b.paymentVolume + amount
          };
        }
        if (b.id === receiverBankId) {
          return {
            ...b,
            digitalZloty: asset === 'Cyfrowy Złoty' ? b.digitalZloty + amount : b.digitalZloty,
            deposits: asset === 'Depozyt Bankowy' ? b.deposits + amount : b.deposits,
            paymentVolume: b.paymentVolume + amount
          };
        }
        return b;
      });

      // If it is a real reserve or Cyfrowy Złoty transfer, total remains same in NBP sheet but bank allocations adjust.
      // If it's a deposit bank transfer, NBP is not directly affected, but reserve requirements might shift.
      const tx: Transaction = {
        id: generateTxId(),
        timestamp: formatSimulationTime(new Date()),
        sender: sender.name,
        receiver: receiver.name,
        institution: 'RTGS_SYSTEM',
        asset: asset,
        amount: amount,
        status: 'FINALIZACJA',
        type: 'B2B',
        authorization: 'SIG_RTGS_' + Math.floor(random() * 1000000),
        settlement: 'Instant (RTGS)',
        auditId: 'AUDIT-' + Math.floor(random() * 1000000)
      };

      return {
        banks: updatedBanks,
        transactions: [tx, ...state.transactions].slice(0, 100)
      };
    });

    return success;
  },

  // Resolve stress scenarios
  resolveLiquidityShortage: (bankId: string) => {
    set(state => {
      // Repo operation to restore liquidity: NBP buys securities from bank, gives reserves
      const bank = state.banks.find(b => b.id === bankId);
      if (!bank) return {};

      const injection = 1_000_000_000; // 1 mld zł repo
      const nbp = { ...state.nbpBalanceSheet };
      
      // NBP buys securities: Assets (repo) increases by 1 mld, Bank Reserves (Liabilities) increases by 1 mld
      nbp.repo += injection;
      nbp.bankReserves += injection;

      const updatedBanks = state.banks.map(b => {
        if (b.id === bankId) {
          return {
            ...b,
            securities: Math.max(0, b.securities - injection),
            reserves: b.reserves + injection,
            liquidity: b.liquidity + injection,
            riskScore: Math.max(10, b.riskScore - 15) // risk drops
          };
        }
        return b;
      });

      const tx: Transaction = {
        id: generateTxId(),
        timestamp: formatSimulationTime(new Date()),
        sender: 'Narodowy Bank Polski',
        receiver: bank.name,
        institution: 'NBP_REPO_DESK',
        asset: 'Cyfrowy Złoty',
        amount: injection,
        status: 'FINALIZACJA',
        type: 'Rządowa',
        authorization: 'SIG_REPO_' + Math.floor(random() * 1000000),
        settlement: 'Instant (RTGS)',
        auditId: 'AUDIT-' + Math.floor(random() * 1000000)
      };

      return {
        nbpBalanceSheet: nbp,
        banks: updatedBanks,
        transactions: [tx, ...state.transactions].slice(0, 100)
      };
    });
  },

  // Programmable payments & vouchers
  createProgrammablePayment: (payment: Omit<ProgrammablePayment, 'id' | 'status' | 'progressStep'>) => {
    set(state => {
      const newPayment: ProgrammablePayment = {
        ...payment,
        id: 'prog-' + Math.floor(10000 + random() * 90000),
        status: 'OCZEKUJE',
        progressStep: 0
      };
      return {
        programmablePayments: [newPayment, ...state.programmablePayments]
      };
    });
  },

  advanceProgrammablePayment: (id: string) => {
    set(state => {
      let isSettled = false;
      const updatedPayments = state.programmablePayments.map(p => {
        if (p.id === id) {
          if (p.status === 'OCZEKUJE') {
            return {
              ...p,
              status: 'WARUNEK_SPEŁNIONY' as const,
              progressStep: 1
            };
          } else if (p.status === 'WARUNEK_SPEŁNIONY') {
            isSettled = true;
            return {
              ...p,
              status: 'ROZLICZONE' as const,
              progressStep: 2
            };
          }
        }
        return p;
      });

      if (isSettled) {
        // Trigger transaction!
        const payment = state.programmablePayments.find(p => p.id === id);
        if (payment) {
          const tx: Transaction = {
            id: generateTxId(),
            timestamp: formatSimulationTime(new Date()),
            sender: payment.sender,
            receiver: payment.recipient,
            institution: 'PROG_LEDGER',
            asset: 'Cyfrowy Złoty',
            amount: payment.amount,
            status: 'FINALIZACJA',
            type: 'Warunkowa',
            authorization: 'SIG_SMART_' + Math.floor(random() * 1000000),
            settlement: 'Instant (RTGS)',
            auditId: 'AUDIT-' + Math.floor(random() * 1000000)
          };
          return {
            programmablePayments: updatedPayments,
            transactions: [tx, ...state.transactions].slice(0, 100)
          };
        }
      }

      return {
        programmablePayments: updatedPayments
      };
    });
  },

  spendVoucher: (voucherId: string, merchantId: string) => {
    let success = false;
    set(state => {
      const voucher = state.vouchers.find(v => v.id === voucherId);
      const merchant = state.merchants.find(m => m.id === merchantId || m.name === merchantId);
      
      if (!voucher || voucher.status !== 'AKTYWNY' || !merchant) return {};

      // Check spending restriction: allowed category
      if (voucher.allowedCategory !== merchant.category && voucher.allowedCategory !== 'Wszystkie') {
        return {}; // restricted category!
      }

      success = true;
      const updatedVouchers = state.vouchers.map(v => {
        if (v.id === voucherId) {
          return {
            ...v,
            status: 'ZREALIZOWANY' as const
          };
        }
        return v;
      });

      // Increase merchant volume
      const updatedMerchants = state.merchants.map(m => {
        if (m.id === merchant.id) {
          return {
            ...m,
            volume: m.volume + voucher.amount
          };
        }
        return m;
      });

      const tx: Transaction = {
        id: generateTxId(),
        timestamp: formatSimulationTime(new Date()),
        sender: 'ZUS_GOV_VOUCHER_POOL',
        receiver: merchant.name,
        institution: 'KRAJOWY_REJESTR_BONÓW',
        asset: 'Cyfrowy Złoty',
        amount: voucher.amount,
        status: 'FINALIZACJA',
        type: 'Bony',
        authorization: 'VOUCHER_REDEEM_' + Math.floor(random() * 1000000),
        settlement: 'Instant (RTGS)',
        auditId: 'AUDIT-' + Math.floor(random() * 1000000)
      };

      return {
        vouchers: updatedVouchers,
        merchants: updatedMerchants,
        transactions: [tx, ...state.transactions].slice(0, 100)
      };
    });

    return success;
  },

  // DvP atomic securities settlement
  executeSecuritiesTrade: (assetId: string, buyerBankId: string) => {
    let success = false;
    
    set(state => {
      const asset = state.tokenisedAssets.find(a => a.id === assetId);
      const buyer = state.banks.find(b => b.id === buyerBankId);
      
      if (!asset || asset.settlementStatus !== 'AKTYWNY' || !buyer) return {};
      
      const sellerName = asset.owner;
      const seller = state.banks.find(b => b.name === sellerName);
      
      if (!seller) return {}; // Seller bank must be a simulated bank

      // Buyer needs Cyfrowy Złoty to pay
      const price = asset.price;
      if (buyer.digitalZloty < price) return {}; // Insufficient funds

      success = true;

      // Transfer Digital Złoty: Buyer -> Seller
      // Deliver Asset: Seller -> Buyer (Atomic delivery vs payment!)
      const updatedBanks = state.banks.map(b => {
        if (b.id === buyerBankId) {
          return {
            ...b,
            digitalZloty: b.digitalZloty - price,
            securities: b.securities + asset.nominal // takes physical asset representation
          };
        }
        if (b.id === seller.id) {
          return {
            ...b,
            digitalZloty: b.digitalZloty + price,
            securities: Math.max(0, b.securities - asset.nominal)
          };
        }
        return b;
      });

      const updatedAssets = state.tokenisedAssets.map(a => {
        if (a.id === assetId) {
          return {
            ...a,
            owner: buyer.name,
            settlementStatus: 'ROZLICZONY_DVP' as const
          };
        }
        return a;
      });

      const tx: Transaction = {
        id: generateTxId(),
        timestamp: formatSimulationTime(new Date()),
        sender: buyer.name,
        receiver: seller.name,
        institution: 'KDPW_DLT_SETTLEMENT',
        asset: 'Tokenizowany Aktyw',
        amount: price,
        status: 'FINALIZACJA',
        type: 'B2B',
        authorization: 'DVP_ATOMIC_' + Math.floor(random() * 1000000),
        settlement: 'Atomic DvP',
        auditId: 'AUDIT-' + Math.floor(random() * 1000000)
      };

      return {
        banks: updatedBanks,
        tokenisedAssets: updatedAssets,
        transactions: [tx, ...state.transactions].slice(0, 100)
      };
    });

    return success;
  },

  // Toggle failure simulation
  toggleFailure: (id: string) => {
    set(state => {
      const updated = state.failures.map(f => {
        if (f.id === id) {
          return { ...f, active: !f.active };
        }
        return f;
      });

      // Side-effects of turning failures on/off
      let kyc = [ ...state.kycAlerts ];
      let cyber = [ ...state.cyberIncidents ];
      const infra = { ...state.infrastructure };

      const activeF = updated.find(f => f.id === id);
      if (activeF?.active) {
        if (id === 'fail-cyber') {
          infra.cpu = 95;
          infra.apiLatency = 145;
          infra.tps = 1205; // choked
          infra.errorRate = 4.2;
          infra.ledgerSyncStatus = 'ZAGROŻONY';
          
          cyber = [{
            id: 'INCYDENT-' + Math.floor(random() * 100000),
            type: 'ATAK DDOS',
            bank: 'Główna Bramka NBP',
            amount: 0,
            status: 'ANALIZA',
            timestamp: formatSimulationTime(new Date())
          }, ...cyber];
        } else if (id === 'fail-bank') {
          // Mazowiecki is down
          const bM = state.banks.find(b => b.id === 'bank-mazowiecki');
          if (bM) {
            kyc = [{
              id: 'PLN-99812',
              amount: 420000000,
              type: 'KOMPROMITACJA PORTFELA',
              risk: 'HIGH',
              status: 'WERYFIKACJA',
              timestamp: formatSimulationTime(new Date()),
              details: 'Anomalia sieciowa na węźle rozliczeniowym Banku Mazowieckiego. Próba masowego rozrachunku.'
            }, ...kyc];
          }
        } else if (id === 'fail-network') {
          infra.networkLatency = 240;
        }
      } else {
        // Recover
        if (id === 'fail-cyber') {
          infra.cpu = 28;
          infra.apiLatency = 11;
          infra.tps = 4800;
          infra.errorRate = 0.01;
          infra.ledgerSyncStatus = 'ZAKTUALIZOWANY';
        } else if (id === 'fail-network') {
          infra.networkLatency = 4;
        }
      }

      return {
        failures: updated,
        kycAlerts: kyc,
        cyberIncidents: cyber,
        infrastructure: infra
      };
    });
  },

  resetFailures: () => {
    set({
      failures: INITIAL_FAILURES.map(f => ({ ...f, active: false })),
      infrastructure: { ...INITIAL_INFRASTRUCTURE }
    });
  },

  // Interactive EV Machine
  advanceEvMachine: () => {
    set(state => {
      const ev = { ...state.evMachine };
      switch (ev.status) {
        case 'IDLE':
          ev.status = 'WERYFIKACJA';
          ev.battery = 31;
          break;
        case 'WERYFIKACJA':
          ev.stationVerified = true;
          ev.priceVerified = true;
          ev.status = 'AUTORYZACJA';
          break;
        case 'AUTORYZACJA':
          ev.walletAuthorised = true;
          ev.status = 'ŁADOWANIE';
          break;
        case 'ŁADOWANIE':
          if (ev.battery < 95) {
            ev.battery += 15;
            ev.zlotySpent += 45;
          } else {
            ev.battery = 100;
            ev.status = 'ZAKOŃCZONE';
            // execute actual payment
          }
          break;
        case 'ZAKOŃCZONE':
          // trigger transaction
          const paymentResult = get().executeWalletTransaction('M2M', ev.zlotySpent, 'Zielony Market Spożywczy', 'NFC');
          ev.status = 'IDLE';
          ev.battery = 100;
          ev.stationVerified = false;
          ev.priceVerified = false;
          ev.walletAuthorised = false;
          ev.zlotySpent = 0;
          break;
      }
      return { evMachine: ev };
    });
  },

  resetEvMachine: () => {
    set({
      evMachine: {
        battery: 31,
        chargingNeeded: true,
        maxAuthorised: 500,
        stationVerified: false,
        priceVerified: false,
        walletAuthorised: false,
        zlotySpent: 0,
        status: 'IDLE'
      }
    });
  },

  // AI Agent step
  advanceAiAgent: () => {
    set(state => {
      const agent = { ...state.aiAgent };
      switch (agent.status) {
        case 'IDLE':
          agent.status = 'ANALIZA';
          agent.currentTask = 'Skanowanie sieci w poszukiwaniu najlepszych warunków dostaw energii dla węzła ładowania. Wykryto: Wisła Petro-Stacje (Cena: 1.82 zł/kWh, Dostępność: 100%).';
          break;
        case 'ANALIZA':
          agent.status = 'REALIZACJA_PŁATNOŚCI';
          agent.currentTask = 'Nawiązywanie kontaktu z bramką Wisła Petro-Stacje. Kalkulacja zapotrzebowania: 1200 kWh. Wartość kontraktu: 2184 zł. Generowanie podpisu kryptograficznego...';
          break;
        case 'REALIZACJA_PŁATNOŚCI':
          agent.status = 'ZAKOŃCZONE_SUKCESEM';
          agent.currentTask = 'Płatność cyfrowym złotym zrealizowana pomyślnie. Rejestr audytowy zaktualizowany o hash transakcji. Pobór energii autoryzowany.';
          agent.balance -= 2184;
          // Trigger actual simulation transfer
          const paymentResult = get().executeWalletTransaction('M2M', 2184, 'Wisła Petro-Stacje', 'Instant');
          break;
        case 'ZAKOŃCZONE_SUKCESEM':
          agent.status = 'IDLE';
          agent.currentTask = 'Oczekiwanie na kolejne zlecenie optymalizacyjne.';
          break;
      }
      return { aiAgent: agent };
    });
  },

  resetAiAgent: () => {
    set({
      aiAgent: {
        id: 'wisla-01',
        name: 'WISŁA-01',
        balance: 50000,
        maxTransactionLimit: 5000,
        approvedCategories: ['Energia', 'Transport', 'Logistyka'],
        currentTask: 'Brak aktywnego zadania. Oczekiwanie na uruchomienie autonomiczne.',
        status: 'IDLE'
      }
    });
  },

  clearAuditLogs: () => set({ transactions: [] }),

  resolveKycAlert: (alertId: string, approve: boolean) => {
    set(state => {
      const alert = state.kycAlerts.find(a => a.id === alertId);
      if (!alert) return {};

      const updated = state.kycAlerts.map(a => {
        if (a.id === alertId) {
          return {
            ...a,
            status: approve ? ('ZATWIERDZONE' as const) : ('ZABLOKOWANE' as const)
          };
        }
        return a;
      });

      // If approved, verify and complete if it was on hold, or just change state.
      return { kycAlerts: updated };
    });
  },

  resolveCyberIncident: (incidentId: string) => {
    set(state => {
      return {
        cyberIncidents: state.cyberIncidents.map(i => {
          if (i.id === incidentId) {
            return { ...i, status: 'OPANOWANO' as const };
          }
          return i;
        })
      };
    });
  },

  // Deterministic simulation tick
  tick: () => {
    const state = get();
    const speed = state.simulationSpeed;

    // Fast-forward simulator time
    set(state => {
      // Parse current simulated clock date
      const parts = state.time.split(' ');
      const dParts = parts[0].split('.');
      const tParts = parts[1].split(':');
      const date = new Date(
        parseInt(dParts[2]),
        parseInt(dParts[1]) - 1,
        parseInt(dParts[0]),
        parseInt(tParts[0]),
        parseInt(tParts[1]),
        parseInt(tParts[2])
      );

      // Advance by speed * seconds
      date.setSeconds(date.getSeconds() + speed);
      const newTimeStr = formatSimulationTime(date);

      // Dynamic transaction generation based on simulation speed
      // High speed generates more flows
      const newTxs: Transaction[] = [];
      let volIncrement = 0;
      let countIncrement = 0;

      // Check failures
      const isBankFailure = state.failures.find(f => f.id === 'fail-bank')?.active;
      const isCyberAttack = state.failures.find(f => f.id === 'fail-cyber')?.active;
      const isNodeFailure = state.failures.find(f => f.id === 'fail-node')?.active;
      const isLiquidityShortage = state.failures.find(f => f.id === 'fail-liquidity')?.active;

      // Adjust infrastructure stats
      const infra = { ...state.infrastructure };
      infra.cpu = Math.min(100, Math.max(15, INITIAL_INFRASTRUCTURE.cpu + Math.floor(random() * 8) - 4 + (isCyberAttack ? 65 : 0) + (speed > 100 ? 20 : 0)));
      infra.memory = Math.min(100, Math.max(25, INITIAL_INFRASTRUCTURE.memory + Math.floor(random() * 4) - 2 + (speed > 1000 ? 15 : 0)));
      infra.apiLatency = Math.max(1, INITIAL_INFRASTRUCTURE.apiLatency + Math.floor(random() * 6) - 3 + (isCyberAttack ? 130 : 0) + (isNodeFailure ? 45 : 0));
      infra.errorRate = Math.max(0, INITIAL_INFRASTRUCTURE.errorRate + (random() * 0.05) - 0.02 + (isCyberAttack ? 0.04 : 0) + (isBankFailure ? 0.02 : 0));
      
      // Node Ledger Sync Status
      if (isNodeFailure) {
        infra.ledgerSyncStatus = 'SYNCHRONIZACJA';
      } else if (isCyberAttack) {
        infra.ledgerSyncStatus = 'ZAGROŻONY';
      } else {
        infra.ledgerSyncStatus = 'ZAKTUALIZOWANY';
      }

      // Generate 1-3 transactions per tick
      const txCount = Math.min(5, Math.ceil(speed / 10) + Math.floor(random() * 2) + 1);
      
      const PolishFirstNames = ['Jan', 'Andrzej', 'Piotr', 'Krzysztof', 'Tomasz', 'Paweł', 'Michał', 'Marcin', 'Jakub', 'Adam', 'Anna', 'Maria', 'Katarzyna', 'Małgorzata', 'Agnieszka', 'Barbara', 'Ewa', 'Krystyna', 'Magdalena', 'Joanna'];
      const PolishLastNames = ['Kowalski', 'Nowak', 'Wiśniewski', 'Wójcik', 'Kowalczyk', 'Kamiński', 'Lewandowski', 'Zieliński', 'Szymański', 'Woźniak', 'Dąbrowski', 'Kozłowski', 'Jankowski', 'Mazur', 'Wojciechowski'];

      const syntheticMerchants = state.merchants;
      const syntheticBanks = state.banks;

      for (let i = 0; i < (isCyberAttack ? 1 : txCount); i++) {
        const randMerchant = syntheticMerchants[Math.floor(random() * syntheticMerchants.length)];
        const randBank = syntheticBanks[Math.floor(random() * syntheticBanks.length)];
        
        // Random payment size
        let amount = Math.floor(random() * 450) + 15;
        if (random() > 0.85) amount = Math.floor(random() * 12000) + 500; // larger biz payment
        
        const firstName = PolishFirstNames[Math.floor(random() * PolishFirstNames.length)];
        const lastName = PolishLastNames[Math.floor(random() * PolishLastNames.length)];
        const senderName = `${firstName} ${lastName}`;

        const assetsPool: Array<'Cyfrowy Złoty' | 'Depozyt Bankowy' | 'Pieniądz Elektroniczny'> = ['Cyfrowy Złoty', 'Depozyt Bankowy', 'Pieniądz Elektroniczny'];
        const chosenAsset = assetsPool[Math.floor(random() * 3)];

        // Block Bank Mazowiecki if failure is active
        if (isBankFailure && randBank.id === 'bank-mazowiecki') {
          continue;
        }

        const newTx: Transaction = {
          id: generateTxId(),
          timestamp: formatSimulationTime(date),
          sender: senderName,
          receiver: randMerchant.name,
          institution: randBank.name,
          asset: chosenAsset,
          amount: amount,
          status: 'FINALIZACJA',
          type: random() > 0.5 ? 'P2M' : 'E-commerce',
          authorization: 'SIG_A_' + Math.floor(random() * 1000000),
          settlement: chosenAsset === 'Cyfrowy Złoty' ? 'Instant (RTGS)' : 'Deferred Net',
          auditId: 'AUDIT-' + Math.floor(random() * 1000000)
        };

        newTxs.push(newTx);
        volIncrement += amount;
        countIncrement += 1;
      }

      // Dynamic adjustments of Bank reserves based on flows
      const updatedBanks = state.banks.map(bank => {
        let reservesDelta = (random() * 50_000_000 - 25_000_000) * speed;
        let digitalDelta = (random() * 40_000_000 - 20_000_000) * speed;
        let depositDelta = (random() * 80_000_000 - 40_000_000) * speed;

        if (isLiquidityShortage && bank.id === 'bank-slaski') {
          // Drain bank Śląski liquidity
          reservesDelta = -180_000_000 * speed;
          digitalDelta = -120_000_000 * speed;
          depositDelta = -350_000_000 * speed;
        }

        const nextReserves = Math.max(1_000_000_000, bank.reserves + reservesDelta);
        const nextCbdc = Math.max(500_000_000, bank.digitalZloty + digitalDelta);
        const nextDeposits = Math.max(10_000_000_000, bank.deposits + depositDelta);

        // Adjust queue length based on speed and failures
        let queue = bank.settlementQueueLength;
        if (isLiquidityShortage && bank.id === 'bank-slaski') {
          queue = Math.min(45, queue + Math.floor(random() * 3) + 1);
        } else if (queue > 0) {
          queue = Math.max(0, queue - Math.floor(random() * 2) - 1);
        }

        // Adjust risk score
        let risk = bank.riskScore;
        if (isLiquidityShortage && bank.id === 'bank-slaski') risk = Math.min(95, risk + 2);
        if (isBankFailure && bank.id === 'bank-mazowiecki') risk = 95;
        if (!isLiquidityShortage && bank.id === 'bank-slaski' && risk > INITIAL_BANKS[2].riskScore) risk = Math.max(INITIAL_BANKS[2].riskScore, risk - 0.5);
        if (!isBankFailure && bank.id === 'bank-mazowiecki' && risk > INITIAL_BANKS[0].riskScore) risk = Math.max(INITIAL_BANKS[0].riskScore, risk - 1);

        return {
          ...bank,
          reserves: nextReserves,
          digitalZloty: nextCbdc,
          deposits: nextDeposits,
          liquidity: nextReserves, // simplified liquidity
          settlementQueueLength: queue,
          riskScore: risk,
          paymentVolume: bank.paymentVolume + (volIncrement / state.banks.length)
        };
      });

      // Update Node flows on the map to animate them
      const updatedNodes = state.nodes.map(n => {
        const variance = (random() * 0.1 - 0.05);
        return {
          ...n,
          flowIn: n.flowIn * (1 + variance),
          flowOut: n.flowOut * (1 + variance),
          flowCbdc: n.flowCbdc * (1 + variance)
        };
      });

      // Update NBP Balance sheet liabilities to maintain identity:
      // Pasywa bankReserves must be equal to sum of all bank reserves
      const nbp = { ...state.nbpBalanceSheet };
      const sumReserves = updatedBanks.reduce((acc, b) => acc + b.reserves, 0);
      nbp.bankReserves = sumReserves;

      const sumCbdcBanks = updatedBanks.reduce((acc, b) => acc + b.digitalZloty, 0);
      const sumCbdcFintechs = state.paymentInstitutions.reduce((acc, p) => acc + p.digitalZlotyBalance, 0);
      nbp.digitalZloty = sumCbdcBanks + sumCbdcFintechs + (state.wallet.balance * 1000) + 45_700_000_000; // plus public retail block

      // To maintain AKTYWA = PASYWA + KAPITAŁ
      // Assets must equal Liabilities + Capital.
      // Total liabilities = banknotes + bankReserves + digitalZloty + otherLiabilities
      const liabilities = nbp.banknotes + nbp.bankReserves + nbp.digitalZloty + nbp.otherLiabilities;
      const targetAssets = liabilities + nbp.capital;
      // Balance via adjusting NBP securities and foreign assets
      const assetsDiff = targetAssets - (nbp.securities + nbp.foreignAssets + nbp.loans + nbp.repo + nbp.collateralisedOperations);
      nbp.securities += assetsDiff * 0.6;
      nbp.foreignAssets += assetsDiff * 0.4;

      // Recalculate GDP / Inflation / Supply
      const eco = { ...state.economics };
      eco.cbdcSupply = parseFloat((nbp.digitalZloty / 1_000_000_000).toFixed(1));
      eco.bankReserves = parseFloat((nbp.bankReserves / 1_000_000_000).toFixed(1));
      eco.bankDeposits = parseFloat((updatedBanks.reduce((acc, b) => acc + b.deposits, 0) / 1_000_000_000).toFixed(1));
      eco.moneySupply = parseFloat((eco.cbdcSupply + eco.bankDeposits).toFixed(1));

      // Calculate dynamic TPS
      infra.tps = Math.floor(INITIAL_INFRASTRUCTURE.tps + (random() * 400 - 200) + (speed > 1 ? speed * 2 : 0));
      if (isCyberAttack) infra.tps = Math.floor(infra.tps * 0.25);

      return {
        time: newTimeStr,
        banks: updatedBanks,
        nbpBalanceSheet: nbp,
        nodes: updatedNodes,
        infrastructure: infra,
        economics: eco,
        transactions: [...newTxs, ...state.transactions].slice(0, 100)
      };
    });
  }
}));
