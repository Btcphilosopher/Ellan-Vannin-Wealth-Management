/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface NbpBalanceSheet {
  // Aktywa
  securities: number;         // Papiery wartościowe (np. obligacje rządowe)
  foreignAssets: number;      // Aktywa zagraniczne / rezerwy dewizowe
  loans: number;              // Kredyty dla banków komercyjnych
  repo: number;               // Operacje REPO
  collateralisedOperations: number; // Inne operacje zabezpieczone
  
  // Pasywa
  banknotes: number;          // Gotówka w obiegu (banknoty i monety)
  bankReserves: number;       // Rezerwy banków komercyjnych w NBP
  digitalZloty: number;       // Cyfrowy Złoty (CBDC) - zobowiązanie NBP
  otherLiabilities: number;   // Inne pasywa
  
  // Kapitał
  capital: number;            // Kapitał własny NBP
}

export interface Bank {
  id: string;
  name: string;
  deposits: number;           // Depozyty klientów (pieniądz komercyjny)
  loans: number;              // Kredyty udzielone
  reserves: number;           // Rezerwy w NBP
  digitalZloty: number;       // Cyfrowy Złoty utrzymywany przez bank jako pośrednika / rezerwa
  securities: number;         // Papiery wartościowe w portfelu banku
  liquidity: number;          // Bieżąca płynność intraday
  capital: number;            // Kapitał własny banku
  collateral: number;         // Zabezpieczenia zdeponowane w NBP
  paymentVolume: number;      // Dzisiejszy wolumen płatności (zł)
  settlementQueueLength: number; // Liczba transakcji w kolejce rozrachunkowej
  riskScore: number;          // Wskaźnik ryzyka banku (1-100)
}

export interface PaymentInstitution {
  id: string;
  name: string;
  customers: number;
  transactionVolume: number;
  digitalZlotyBalance: number;
  electronicMoney: number;    // Pieniądz elektroniczny (e-money)
  liquidity: number;
  apiStatus: 'ONLINE' | 'DEGRADED' | 'OFFLINE';
  risk: number;               // 1-100
  compliance: number;         // Zgodność (1-100)
}

export type TransactionStatus =
  | 'UTWORZENIE'
  | 'AUTORYZACJA'
  | 'WERYFIKACJA_SALDA'
  | 'KONTROLA_ZGODNOŚCI'
  | 'KONTROLA_PŁYNNOŚCI'
  | 'ROZLICZENIE'
  | 'FINALIZACJA'
  | 'ODRZUCONA';

export type TransactionType =
  | 'P2P'
  | 'P2M'
  | 'B2B'
  | 'B2C'
  | 'C2B'
  | 'Rządowa'
  | 'Wynagrodzenie'
  | 'Podatki'
  | 'Faktura'
  | 'E-commerce'
  | 'QR'
  | 'NFC'
  | 'M2M'
  | 'Warunkowa'
  | 'Bony';

export interface Transaction {
  id: string;
  timestamp: string;          // Format: 18.09.2026 09:42:17.421
  sender: string;
  receiver: string;
  institution: string;
  asset: 'Cyfrowy Złoty' | 'Depozyt Bankowy' | 'Pieniądz Elektroniczny' | 'Tokenizowany Aktyw';
  amount: number;
  status: TransactionStatus;
  type: TransactionType;
  authorization: string;      // Kod kryptograficzny
  settlement: 'Instant (RTGS)' | 'Deferred Net' | 'Offline Sync' | 'Atomic DvP';
  auditId: string;            // Format UUID / hash
}

export interface Wallet {
  ownerName: string;
  balance: number;
  available: number;
  offline: number;
  dailyLimit: number;
  dailySpent: number;
  identityConfirmed: boolean;
  intermediaryBank: string;
}

export interface ProgrammablePayment {
  id: string;
  title: string;
  amount: number;
  conditionType: 'Escrow' | 'Dostawa' | 'Kamień milowy' | 'Cykliczna' | 'M2M';
  conditionText: string;
  status: 'OCZEKUJE' | 'WARUNEK_SPEŁNIONY' | 'ROZLICZONE' | 'ANULOWANE';
  sender: string;
  recipient: string;
  progressStep: number; // 0: OCZEKUJE, 1: WARUNEK SPEŁNIONY, 2: ROZLICZONO
}

export interface Voucher {
  id: string;
  title: string;
  type: 'Energy' | 'Transport' | 'Education' | 'Tourism' | 'SME' | 'Agriculture' | 'LocalGov';
  amount: number;
  allowedCategory: string;
  expiryDate: string;
  status: 'AKTYWNY' | 'ZREALIZOWANY' | 'WYGAŚNIĘTY';
  owner: string;
}

export interface TokenisedAsset {
  id: string;
  name: string;
  type: 'Obligacja Skarbowa' | 'Bon Skarbowy' | 'Obligacja Przedsiębiorstwa' | 'Jednostka Funduszu' | 'Papier Rynku Pieniężnego';
  nominal: number;
  price: number;
  yield: number;
  maturity: string;
  owner: string;
  settlementStatus: 'AKTYWNY' | 'W_ROZRACHUNKU' | 'ROZLICZONY_DVP';
}

export interface KycAlert {
  id: string;
  amount: number;
  type: 'NIETYPOWA AKTYWNOŚĆ' | 'STRUKTURYZACJA' | 'ANOMALIA SPRZEDAWCY' | 'KOMPROMITACJA PORTFELA' | 'NIEZGODNOŚĆ TOŻSAMOŚCI';
  risk: 'LOW' | 'MEDIUM' | 'HIGH';
  status: 'WERYFIKACJA' | 'ZATWIERDZONE' | 'ZABLOKOWANE';
  timestamp: string;
  details: string;
}

export interface CyberIncident {
  id: string;
  type: 'ANOMALIA TRANSAKCYJNA' | 'ATAK DDOS' | 'PRÓBA WYŁUDZENIA TOŻSAMOŚCI' | 'PRZERWANIE SYNC LEDGERA';
  bank: string;
  amount: number;
  status: 'ANALIZA' | 'OPANOWANO' | 'ZAGROŻENIE_ZMINIMALIZOWANE';
  timestamp: string;
}

export interface InfrastructureMetrics {
  cpu: number;
  memory: number;
  networkLatency: number; // ms
  apiLatency: number; // ms
  ledgerSyncStatus: 'ZAKTUALIZOWANY' | 'SYNCHRONIZACJA' | 'ZAGROŻONY';
  tps: number;
  queueDepth: number;
  errorRate: number; // %
}

export interface EconomicStats {
  cbdcSupply: number;         // mld zł
  bankDeposits: number;       // mld zł
  bankReserves: number;       // mld zł
  moneySupply: number;        // mld zł (M3)
  velocity: number;           // prędkość obiegu
  credit: number;             // wolumen kredytowy mld zł
  liquidity: number;          // mld zł
  interestRates: number;      // % (stopa referencyjna NBP)
  consumption: number;        // indeks
  investment: number;         // indeks
  gdp: number;                // wzrost % r/r
  inflation: number;          // inflacja % r/r
  digitalAdoption: number;    // % społeczeństwa
}

export interface SystemFailure {
  id: string;
  label: string;
  active: boolean;
  description: string;
}

export interface NodeFlow {
  id: string;
  name: string;
  x: number; // współrzędne procentowe na mapie Polski
  y: number;
  flowIn: number; // zł/s
  flowOut: number; // zł/s
  flowCbdc: number; // zł/s
}

export interface Merchant {
  id: string;
  name: string;
  category: 'Detaliczny' | 'Spożywczy' | 'Paliwowy' | 'Restauracje' | 'Hotele' | 'Transport' | 'Przemysł' | 'Budownictwo' | 'E-commerce' | 'Energia' | 'Edukacja' | 'Zdrowie' | 'Turystyka';
  volume: number; // zł/dzień
  avgPayment: number; // zł
  cbdcShare: number; // %
  qrSupport: boolean;
  nfcSupport: boolean;
  instantPaymentSupport: boolean;
  voucherSupport: boolean;
  latency: number; // s
}

export interface EvMachine {
  battery: number; // %
  chargingNeeded: boolean;
  maxAuthorised: number; // zł
  stationVerified: boolean;
  priceVerified: boolean;
  walletAuthorised: boolean;
  zlotySpent: number;
  status: 'IDLE' | 'WERYFIKACJA' | 'AUTORYZACJA' | 'ŁADOWANIE' | 'ZAKOŃCZONE';
}

export interface AiAgent {
  id: string;
  name: string;
  balance: number;
  maxTransactionLimit: number;
  approvedCategories: string[];
  currentTask: string;
  status: 'IDLE' | 'ANALIZA' | 'REALIZACJA_PŁATNOŚCI' | 'ZAKOŃCZONE_SUKCESEM';
}

export type ScenarioType =
  | 'BAZOWY'
  | 'WYSOKA_ADOPCJA'
  | 'NISKA_ADOPCJA'
  | 'SZOK_PŁYNNOŚCIOWY'
  | 'SZOK_SYSTEMU_PŁATNICZEGO'
  | 'WYSOKA_TOKENIZACJA'
  | 'ODPŁYW_DEPOZYTÓW'
  | 'KRYZYS_FINANSOWY';

export interface SimulationState {
  time: string;
  nbpBalanceSheet: NbpBalanceSheet;
  banks: Bank[];
  paymentInstitutions: PaymentInstitution[];
  wallet: Wallet;
  transactions: Transaction[];
  programmablePayments: ProgrammablePayment[];
  vouchers: Voucher[];
  tokenisedAssets: TokenisedAsset[];
  kycAlerts: KycAlert[];
  cyberIncidents: CyberIncident[];
  infrastructure: InfrastructureMetrics;
  economics: EconomicStats;
  failures: SystemFailure[];
  nodes: NodeFlow[];
  merchants: Merchant[];
  evMachine: EvMachine;
  aiAgent: AiAgent;
  simulationSpeed: number; // 1, 10, 100, 1000, 10000
  modelMode: 'Account' | 'Wallet';
  selectedScenario: ScenarioType;
}
