/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useSimulationStore } from '../simulationStore';
import { Landmark, ArrowUpRight, ArrowDownLeft, ShieldCheck, RefreshCw, Layers } from 'lucide-react';

export const NbpCore: React.FC = () => {
  const { nbpBalanceSheet, banks, issueCbdc, redeemCbdc, verifyLedger, economics } = useSimulationStore();
  
  const [issueAmount, setIssueAmount] = useState<string>('500000000'); // 500 mln zł
  const [targetBank, setTargetBank] = useState<string>('bank-mazowiecki');
  const [fundingType, setFundingType] = useState<'RESERVES' | 'LOAN'>('RESERVES');
  
  const [redeemAmount, setRedeemAmount] = useState<string>('200000000'); // 200 mln zł
  const [sourceBank, setSourceBank] = useState<string>('bank-mazowiecki');

  const [auditResult, setAuditResult] = useState<{ success: boolean; message: string; details: string } | null>(null);

  const formatPLN = (val: number) => {
    if (val >= 1_000_000_000_000) return `${(val / 1_000_000_000_000).toLocaleString('pl-PL', { maximumFractionDigits: 2 })} bln zł`;
    if (val >= 1_000_000_000) return `${(val / 1_000_000_000).toLocaleString('pl-PL', { maximumFractionDigits: 1 })} mld zł`;
    if (val >= 1_000_000) return `${(val / 1_000_000).toLocaleString('pl-PL', { maximumFractionDigits: 1 })} mln zł`;
    return `${val.toLocaleString('pl-PL')} zł`;
  };

  const handleIssue = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(issueAmount);
    if (isNaN(amt) || amt <= 0) return;
    const ok = issueCbdc(amt, targetBank, fundingType);
    if (ok) {
      setIssueAmount('500000000');
      runAudit();
    }
  };

  const handleRedeem = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(redeemAmount);
    if (isNaN(amt) || amt <= 0) return;
    const ok = redeemCbdc(amt, sourceBank);
    if (ok) {
      setRedeemAmount('200000000');
      runAudit();
    }
  };

  const runAudit = () => {
    const res = verifyLedger();
    setAuditResult(res);
  };

  // Math variables
  const assetsTotal = nbpBalanceSheet.securities + nbpBalanceSheet.foreignAssets + nbpBalanceSheet.loans + nbpBalanceSheet.repo + nbpBalanceSheet.collateralisedOperations;
  const liabilitiesTotal = nbpBalanceSheet.banknotes + nbpBalanceSheet.bankReserves + nbpBalanceSheet.digitalZloty + nbpBalanceSheet.otherLiabilities;
  const equityTotal = nbpBalanceSheet.capital;
  const totalLiabEq = liabilitiesTotal + equityTotal;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="nbp-core-section">
      
      {/* Balance Sheet Column */}
      <div className="lg:col-span-7 bg-white border border-slate-200 shadow-sm rounded-lg p-5 flex flex-col justify-between" id="nbp-balance-sheet">
        <div>
          <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-slate-100 text-slate-800 rounded">
                <Landmark size={20} />
              </div>
              <div>
                <h2 className="text-sm font-bold text-slate-900 tracking-wide">NARODOWY BANK POLSKI</h2>
                <p className="text-xs text-slate-500 uppercase tracking-wider">Bilans Pieniężny Banku Centralnego</p>
              </div>
            </div>
            <div className="text-right">
              <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-green-50 text-green-700 border border-green-200">
                REJESTR ZBILANSOWANY
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* AKTYWA */}
            <div>
              <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2 border-b border-slate-100 pb-1">AKTYWA (ASSETS)</h3>
              <div className="space-y-2.5">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-600 font-medium">Papiery wartościowe (Securities)</span>
                  <span className="font-mono text-slate-900 font-bold">{formatPLN(nbpBalanceSheet.securities)}</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-600 font-medium">Rezerwy dewizowe (Foreign Assets)</span>
                  <span className="font-mono text-slate-900 font-bold">{formatPLN(nbpBalanceSheet.foreignAssets)}</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-600 font-medium">Kredyty dla banków (Loans)</span>
                  <span className="font-mono text-slate-900 font-bold">{formatPLN(nbpBalanceSheet.loans)}</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-600 font-medium">Operacje REPO (Repo desk)</span>
                  <span className="font-mono text-slate-900 font-bold">{formatPLN(nbpBalanceSheet.repo)}</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-600 font-medium">Operacje zabezpieczone (Collateralised)</span>
                  <span className="font-mono text-slate-900 font-bold">{formatPLN(nbpBalanceSheet.collateralisedOperations)}</span>
                </div>
              </div>
            </div>

            {/* PASYWA & KAPITAŁ */}
            <div>
              <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2 border-b border-slate-100 pb-1">PASYWA &amp; KAPITAŁ (LIABILITIES &amp; EQUITY)</h3>
              <div className="space-y-2.5">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-600 font-medium">Gotówka w obiegu (Banknotes)</span>
                  <span className="font-mono text-slate-900 font-bold">{formatPLN(nbpBalanceSheet.banknotes)}</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-600 font-medium">Rezerwy banków (Bank Reserves)</span>
                  <span className="font-mono text-slate-900 font-bold">{formatPLN(nbpBalanceSheet.bankReserves)}</span>
                </div>
                <div className="flex justify-between items-center text-xs bg-slate-50 p-1.5 rounded border border-slate-200">
                  <span className="text-slate-700 font-semibold flex items-center gap-1">
                    <span className="w-2 h-2 bg-red-600 rounded-full"></span>
                    Cyfrowy Złoty w obiegu (CBDC)
                  </span>
                  <span className="font-mono text-red-700 font-black">{formatPLN(nbpBalanceSheet.digitalZloty)}</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-600 font-medium">Inne zobowiązania (Other)</span>
                  <span className="font-mono text-slate-900 font-bold">{formatPLN(nbpBalanceSheet.otherLiabilities)}</span>
                </div>
                <div className="pt-1.5 border-t border-dashed border-slate-200">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-600 font-medium">Kapitał własny (Equity Capital)</span>
                    <span className="font-mono text-slate-900 font-bold">{formatPLN(equityTotal)}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Totals Banner */}
        <div className="mt-6 pt-4 border-t border-slate-100 grid grid-cols-2 gap-4 text-center bg-slate-50 p-3 rounded border border-slate-200">
          <div>
            <div className="text-xs text-slate-500 font-medium uppercase tracking-wider">SUMA AKTYWÓW</div>
            <div className="text-sm font-bold font-mono text-slate-900">{formatPLN(assetsTotal)}</div>
          </div>
          <div>
            <div className="text-xs text-slate-500 font-medium uppercase tracking-wider">SUMA PASYWÓW + KAPITAŁU</div>
            <div className="text-sm font-bold font-mono text-slate-900">{formatPLN(totalLiabEq)}</div>
          </div>
        </div>
      </div>

      {/* Issuance & Redemption Panel */}
      <div className="lg:col-span-5 bg-white border border-slate-200 shadow-sm rounded-lg p-5 flex flex-col justify-between" id="nbp-issuance-controls">
        <div>
          <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
            <h2 className="text-sm font-bold text-slate-900 tracking-wide uppercase flex items-center gap-2">
              <Layers size={16} className="text-red-600" />
              EMISJA CYFROWEGO ZŁOTEGO
            </h2>
            <button
              onClick={runAudit}
              className="p-1 text-xs font-semibold text-slate-700 hover:text-slate-900 flex items-center gap-1 border border-slate-200 rounded hover:bg-slate-50 transition cursor-pointer"
            >
              <RefreshCw size={12} />
              Audyt
            </button>
          </div>

          {/* Audit Result Banner */}
          {auditResult && (
            <div className={`p-3 rounded text-xs mb-4 border ${auditResult.success ? 'bg-green-50 border-green-200 text-green-800' : 'bg-red-50 border-red-200 text-red-800'}`}>
              <div className="font-bold flex items-center gap-1.5">
                <ShieldCheck size={14} />
                {auditResult.message}
              </div>
              <p className="mt-1 text-[11px] leading-relaxed font-mono">{auditResult.details}</p>
            </div>
          )}

          {/* Issue form */}
          <form onSubmit={handleIssue} className="space-y-3 pb-4 mb-4 border-b border-slate-100">
            <div className="text-xs font-bold text-slate-700 uppercase tracking-wider">1. NOWA EMISJA (ISSUANCE)</div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[10px] font-bold text-slate-500 mb-1">KWOTA EMISJI (PLN)</label>
                <input
                  type="number"
                  value={issueAmount}
                  onChange={(e) => setIssueAmount(e.target.value)}
                  className="w-full text-xs p-1.5 border border-slate-200 rounded font-mono focus:outline-none focus:border-slate-400 bg-slate-50"
                  placeholder="Kwota w zł"
                />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-slate-500 mb-1">BANK ODBIORCA</label>
                <select
                  value={targetBank}
                  onChange={(e) => setTargetBank(e.target.value)}
                  className="w-full text-xs p-1.5 border border-slate-200 rounded focus:outline-none bg-slate-50"
                >
                  {banks.map(b => (
                    <option key={b.id} value={b.id}>{b.name}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex space-x-4">
                <label className="inline-flex items-center text-xs text-slate-600">
                  <input
                    type="radio"
                    checked={fundingType === 'RESERVES'}
                    onChange={() => setFundingType('RESERVES')}
                    className="mr-1.5 accent-red-600"
                  />
                  Konwersja rezerw
                </label>
                <label className="inline-flex items-center text-xs text-slate-600">
                  <input
                    type="radio"
                    checked={fundingType === 'LOAN'}
                    onChange={() => setFundingType('LOAN')}
                    className="mr-1.5 accent-red-600"
                  />
                  Zabezpieczony kredyt NBP
                </label>
              </div>

              <button
                type="submit"
                className="bg-red-700 hover:bg-red-800 text-white font-bold text-xs py-1.5 px-4 rounded shadow-sm flex items-center gap-1.5 transition cursor-pointer"
              >
                <ArrowUpRight size={14} />
                EMITUJ CBDC
              </button>
            </div>
          </form>

          {/* Redemption form */}
          <form onSubmit={handleRedeem} className="space-y-3">
            <div className="text-xs font-bold text-slate-700 uppercase tracking-wider">2. UMORZENIE (REDEMPTION)</div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[10px] font-bold text-slate-500 mb-1">KWOTA UMORZENIA (PLN)</label>
                <input
                  type="number"
                  value={redeemAmount}
                  onChange={(e) => setRedeemAmount(e.target.value)}
                  className="w-full text-xs p-1.5 border border-slate-200 rounded font-mono focus:outline-none focus:border-slate-400 bg-slate-50"
                  placeholder="Kwota w zł"
                />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-slate-500 mb-1">BANK ŹRÓDŁOWY</label>
                <select
                  value={sourceBank}
                  onChange={(e) => setSourceBank(e.target.value)}
                  className="w-full text-xs p-1.5 border border-slate-200 rounded focus:outline-none bg-slate-50"
                >
                  {banks.map(b => (
                    <option key={b.id} value={b.id}>{b.name}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="flex justify-end">
              <button
                type="submit"
                className="bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs py-1.5 px-4 rounded shadow-sm flex items-center gap-1.5 transition cursor-pointer"
              >
                <ArrowDownLeft size={14} />
                UMÓRZ W NBP
              </button>
            </div>
          </form>
        </div>

        {/* Small footer warning */}
        <div className="mt-5 text-[10px] text-slate-400 leading-relaxed italic border-t border-slate-100 pt-3">
          * Emisja cyfrowego złotego w modelach badawczych NBP nie zmienia agregatu pieniężnego M0 bezpośrednio, o ile następuje poprzez konwersję rezerw płynnych banków komercyjnych.
        </div>
      </div>
      
    </div>
  );
};
