/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useSimulationStore } from '../simulationStore';
import { Map, ShoppingBag, Radio, Compass, RefreshCcw } from 'lucide-react';

export const MapFlows: React.FC = () => {
  const { nodes, merchants, infrastructure } = useSimulationStore();

  const formatPLN = (val: number) => {
    if (val >= 1_000_000) return `${(val / 1_000_000).toFixed(1)} mln zł`;
    return `${val.toLocaleString('pl-PL')} zł`;
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="map-flows-section">
      
      {/* Dynamic SVG Map of Poland */}
      <div className="lg:col-span-6 bg-white border border-slate-200 shadow-sm rounded-lg p-5 flex flex-col justify-between" id="polish-network-map">
        <div>
          <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide flex items-center gap-1.5">
              <Map size={16} className="text-red-600" />
              CYFROWY BLIŹNIAK SYSTEMU MONETARNEGO (MAPA PRZEPŁYWÓW)
            </h3>
            <span className="text-[10px] font-mono text-slate-500 flex items-center gap-1">
              <Radio size={12} className="text-red-500 animate-pulse" />
              Live Flows (RTGS Net)
            </span>
          </div>

          <p className="text-xs text-slate-600 leading-relaxed mb-4">
            Wizualizacja natężenia transakcji detalicznych i rozrachunków hurtowych CBDC na terenie Rzeczypospolitej Polskiej. Średnia prędkość rozliczenia: <strong className="text-red-700">0,42 s</strong>.
          </p>

          {/* SVG Map Container */}
          <div className="relative aspect-[4/3] bg-slate-950 rounded-lg overflow-hidden border border-slate-900 flex items-center justify-center p-2">
            
            {/* Outline map placeholder or abstract vector lines */}
            <svg className="absolute inset-0 w-full h-full opacity-20 pointer-events-none" viewBox="0 0 100 100">
              {/* Draw connecting network wires between major cities */}
              <line x1="62" y1="50" x2="44" y2="15" stroke="#ef4444" strokeWidth="0.5" strokeDasharray="1 1" />
              <line x1="62" y1="50" x2="60" y2="82" stroke="#ef4444" strokeWidth="0.5" strokeDasharray="1 1" />
              <line x1="62" y1="50" x2="31" y2="68" stroke="#ef4444" strokeWidth="0.5" strokeDasharray="1 1" />
              <line x1="31" y1="68" x2="28" y2="44" stroke="#475569" strokeWidth="0.5" />
              <line x1="44" y1="15" x2="10" y2="28" stroke="#475569" strokeWidth="0.5" />
              <line x1="28" y1="44" x2="10" y2="28" stroke="#475569" strokeWidth="0.5" />
              <line x1="60" y1="82" x2="74" y2="84" stroke="#475569" strokeWidth="0.5" />
              <line x1="62" y1="50" x2="80" y2="62" stroke="#ef4444" strokeWidth="0.5" strokeDasharray="1 1" />
            </svg>

            {/* Nodes layer */}
            <div className="absolute inset-0 w-full h-full">
              {nodes.map(node => {
                // Scale circle size based on flowIn
                const size = Math.min(24, Math.max(8, node.flowIn / 2000000));
                return (
                  <div
                    key={node.id}
                    className="absolute group"
                    style={{ left: `${node.x}%`, top: `${node.y}%`, transform: 'translate(-50%, -50%)' }}
                  >
                    {/* Pulsing ring */}
                    <span 
                      className="absolute -inset-2 rounded-full bg-red-600/15 animate-ping"
                      style={{ animationDuration: `${Math.max(1, 3 - (node.flowCbdc / 3000000))}s` }}
                    ></span>
                    
                    {/* City Marker dot */}
                    <div 
                      className="rounded-full bg-red-600 border border-white shadow-sm flex items-center justify-center text-[7px] text-white font-bold cursor-help"
                      style={{ width: `${size}px`, height: `${size}px` }}
                      title={`${node.name}: CBDC ${formatPLN(node.flowCbdc)}/s`}
                    >
                    </div>

                    {/* Tooltip on Hover */}
                    <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 hidden group-hover:block bg-slate-900 text-white font-mono text-[9px] p-2 rounded shadow-xl border border-slate-700 z-30 pointer-events-none whitespace-nowrap leading-tight">
                      <div className="font-sans font-bold text-slate-200">{node.name}</div>
                      <div className="mt-1">Płatności In: <span className="text-slate-100">{formatPLN(node.flowIn)}/s</span></div>
                      <div>Cyfrowy Złoty: <span className="text-red-400 font-bold">{formatPLN(node.flowCbdc)}/s</span></div>
                    </div>

                    {/* Simple city label */}
                    <span className="absolute left-full ml-1.5 top-1/2 -translate-y-1/2 text-[9px] font-bold text-slate-300 font-sans tracking-wide drop-shadow pointer-events-none whitespace-nowrap">
                      {node.name}
                    </span>
                  </div>
                );
              })}
            </div>

            {/* Scale legend inside container */}
            <div className="absolute bottom-2 left-2 text-[8px] font-mono text-slate-500 space-y-0.5 pointer-events-none bg-slate-900/50 p-1.5 rounded">
              <div>* SKALA SYMULACJI: 1 KROK = 1 SEKUNDA</div>
              <div>* TRANSMISJA LEJKOWA: ISO 20022 XML</div>
            </div>
          </div>
        </div>

        <div className="text-[10px] text-slate-400 mt-4 leading-relaxed italic border-t border-slate-100 pt-3">
          * Cyfrowy Bliźniak (Digital Twin) NBP odzwierciedla relacje wektorowe i rozkład prędkości transakcyjnej w ujęciu geolokalizacyjnym na podstawie historycznego rozkładu logistycznego Polski.
        </div>
      </div>

      {/* Merchant Network table */}
      <div className="lg:col-span-6 bg-white border border-slate-200 shadow-sm rounded-lg p-5 flex flex-col justify-between" id="merchant-network-details">
        <div>
          <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide flex items-center gap-1.5">
              <ShoppingBag size={16} className="text-red-600" />
              KRAJOWA SIEĆ AKCEPTANTÓW CYFROWEGO ZŁOTEGO
            </h3>
            <span className="text-[10px] font-bold bg-slate-100 px-2 py-0.5 rounded text-slate-600">
              INTEGRACJA DETALICZNA
            </span>
          </div>

          {/* Table display */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider text-[9px]">
                  <th className="py-2 px-2.5">Akceptant</th>
                  <th className="py-2 px-2.5">Sektor</th>
                  <th className="py-2 px-2.5 text-right">Obrót (24h)</th>
                  <th className="py-2 px-2.5 text-right">Średnia płatność</th>
                  <th className="py-2 px-2.5 text-right text-red-700">Udział CBDC</th>
                  <th className="py-2 px-2.5 text-center">QR/NFC</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium font-mono text-[11px] text-slate-700">
                {merchants.map(merchant => (
                  <tr key={merchant.id} className="hover:bg-slate-50 transition">
                    <td className="py-2.5 px-2.5 font-sans font-bold text-slate-900">{merchant.name}</td>
                    <td className="py-2.5 px-2.5 font-sans text-slate-500">{merchant.category}</td>
                    <td className="py-2.5 px-2.5 text-right text-slate-800">{merchant.volume.toLocaleString('pl-PL')} zł</td>
                    <td className="py-2.5 px-2.5 text-right text-slate-800">{merchant.avgPayment.toFixed(2)} zł</td>
                    <td className="py-2.5 px-2.5 text-right text-red-700 font-bold">{merchant.cbdcShare.toFixed(1)}%</td>
                    <td className="py-2.5 px-2.5 text-center font-sans">
                      <div className="flex justify-center gap-1 text-[9px]">
                        {merchant.qrSupport && <span className="bg-slate-100 px-1 rounded text-slate-600">QR</span>}
                        {merchant.nfcSupport && <span className="bg-slate-100 px-1 rounded text-slate-600">NFC</span>}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="text-[10px] text-slate-400 mt-4 leading-relaxed italic border-t border-slate-100 pt-3">
          * Integracja akceptantów ulega stopniowemu rozszerzeniu. Wpływ na udział CBDC w obrocie mają bezpośrednio scenariusze adopcji modelowej uruchamiane w Laboratorium Monetarnym.
        </div>
      </div>

    </div>
  );
};
