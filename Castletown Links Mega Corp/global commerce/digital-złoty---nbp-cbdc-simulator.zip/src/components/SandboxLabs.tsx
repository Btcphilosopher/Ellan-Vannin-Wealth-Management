/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useSimulationStore } from '../simulationStore';
import { 
  Terminal, ShieldCheck, Cpu, Play, FastForward, RefreshCw, 
  Car, Eye, Coins, CheckCircle, Flame, ArrowRight, Server, Layers
} from 'lucide-react';
import { ScenarioType } from '../types';

export const SandboxLabs: React.FC = () => {
  const { 
    programmablePayments, advanceProgrammablePayment, createProgrammablePayment,
    vouchers, spendVoucher, merchants,
    tokenisedAssets, executeSecuritiesTrade, banks,
    evMachine, advanceEvMachine, resetEvMachine,
    aiAgent, advanceAiAgent, resetAiAgent,
    selectedScenario, setScenario, economics, modelMode, setModelMode
  } = useSimulationStore();

  const [activeLab, setActiveTab] = useState<'PROG' | 'OFFLINE' | 'VOUCHERS' | 'TOKENISATION' | 'MACRO' | 'M2M_AI' | 'ARCHITECTURES'>('PROG');

  // New conditional payment form state
  const [newTitle, setNewTitle] = useState<string>('Kontrakt za usługi chmurowe');
  const [newAmt, setNewAmt] = useState<string>('50000');
  const [newCond, setNewCond] = useState<string>('Dostarczenie raportu audytowego');

  const formatPLN = (val: number) => {
    return `${val.toLocaleString('pl-PL', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} zł`;
  };

  const handleCreateContract = (e: React.FormEvent) => {
    e.preventDefault();
    const amtNum = parseFloat(newAmt);
    if (isNaN(amtNum) || amtNum <= 0) return;
    createProgrammablePayment({
      title: newTitle,
      amount: amtNum,
      conditionType: 'Kamień milowy',
      conditionText: newCond,
      sender: 'Bank Mazowiecki',
      recipient: 'Krajowe Konsorcjum DLT'
    });
    setNewTitle('');
    setNewAmt('');
    setNewCond('');
  };

  // Offline demo state
  const [devA, setDevA] = useState<number>(500);
  const [devB, setDevB] = useState<number>(0);
  const [offlineStatus, setOfflineStatus] = useState<string>('ZRECONCYLIOWANY (ONLINE)');
  const [offlineLog, setOfflineLog] = useState<string[]>(['Inicjalizacja bezpiecznych elementów (Secure Element v2).']);

  const executeOfflinePayment = () => {
    if (devA < 150) {
      setOfflineLog(prev => [...prev, 'Odmowa: Niewystarczający bilans w Secure Element pojazdu A.']);
      return;
    }
    setDevA(prev => prev - 150);
    setDevB(prev => prev + 150);
    setOfflineStatus('ROZPROSZONA ZGODA (OFFLINE)');
    setOfflineLog(prev => [
      ...prev,
      'Zbliżenie urządzeń: Protokół NFC-Secure-Element wykrył pojazd B.',
      'Kryptograficzny dowód braku podwójnego wydatku (Double-spend protection proof) wygenerowany.',
      'Transfer 150.00 zł: Urządzenie A -> Urządzenie B pomyślny.'
    ]);
  };

  const syncOfflineNetwork = () => {
    setOfflineStatus('ROZLICZANIE W GŁÓWNYM REJESTRZE NBP');
    setOfflineLog(prev => [...prev, 'Połączenie z siecią krajową przywrócone. Rozpoczęto wysyłanie transakcji...']);
    setTimeout(() => {
      setOfflineStatus('ZRECONCYLIOWANY (ONLINE)');
      setOfflineLog(prev => [
        ...prev,
        'Zgłoszenie transakcji offline do rozrachunku RTGS w NBP.',
        'Księgowanie: Rezerwy bankowe dostosowane o sumę 150.00 zł.',
        'Rozrachunek zakończony integralnie.'
      ]);
    }, 1500);
  };

  return (
    <div className="bg-white border border-slate-200 shadow-sm rounded-lg p-5" id="sandbox-labs-component">
      
      {/* Tab Navigation header */}
      <div className="flex flex-wrap gap-1 border-b border-slate-100 pb-3 mb-5">
        {[
          { id: 'PROG', label: 'Programowalne płatności' },
          { id: 'OFFLINE', label: 'Model Offline' },
          { id: 'VOUCHERS', label: 'Bony cyfrowe' },
          { id: 'TOKENISATION', label: 'Tokenizacja i DvP' },
          { id: 'MACRO', label: 'Symulator Monetarny' },
          { id: 'M2M_AI', label: 'M2M & Autonomiczni Agenci' },
          { id: 'ARCHITECTURES', label: 'Architektury CBDC' }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-3 py-1.5 text-xs font-bold uppercase rounded cursor-pointer ${
              activeLab === tab.id 
                ? 'bg-red-700 text-white shadow-sm' 
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* LAB 1: PROGRAMMABLE PAYMENTS */}
      {activeLab === 'PROG' && (
        <div className="space-y-6" id="programmable-payments-lab">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Conditional List */}
            <div className="lg:col-span-7 space-y-4">
              <div>
                <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-1">Aktywne Kontrakty Warunkowe</h3>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  Przeanalizuj i przetwórz cykl rozliczeniowy smart-kontaktów w ekosystemie cyfrowego złotego. Środki są blokowane (Escrow), dopóki warunek transakcyjny nie zostanie spełniony.
                </p>
              </div>

              <div className="space-y-3">
                {programmablePayments.map(pay => (
                  <div key={pay.id} className="border border-slate-200 rounded p-4 bg-slate-50 hover:bg-slate-100/50 transition">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <div className="font-bold text-slate-900 text-xs">{pay.title}</div>
                        <div className="text-[10px] text-slate-400 font-mono">ID: {pay.id} | Nadawca: {pay.sender}</div>
                      </div>
                      <span className={`px-2 py-0.5 rounded text-[9px] font-bold border ${
                        pay.status === 'ROZLICZONE' 
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200' 
                          : pay.status === 'WARUNEK_SPEŁNIONY' 
                            ? 'bg-blue-50 text-blue-700 border-blue-200' 
                            : 'bg-yellow-50 text-yellow-700 border-yellow-200'
                      }`}>
                        {pay.status}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-4 text-xs font-mono my-2.5 bg-white p-2 rounded border border-slate-200">
                      <div>
                        <span className="text-[9px] text-slate-400 uppercase block font-bold">Wartość kontraktu</span>
                        <strong className="text-slate-900">{formatPLN(pay.amount)}</strong>
                      </div>
                      <div>
                        <span className="text-[9px] text-slate-400 uppercase block font-bold">Warunek wyzwalający</span>
                        <span className="text-slate-700 font-bold">{pay.conditionText}</span>
                      </div>
                    </div>

                    {/* Progression controller button */}
                    <div className="flex justify-between items-center mt-3">
                      <span className="text-[10px] text-slate-500">Odbiorca: <strong className="text-slate-700">{pay.recipient}</strong></span>
                      {pay.status !== 'ROZLICZONE' && (
                        <button
                          onClick={() => advanceProgrammablePayment(pay.id)}
                          className="bg-slate-800 hover:bg-slate-900 text-white text-[10px] font-bold py-1.5 px-3 rounded flex items-center gap-1 transition cursor-pointer"
                        >
                          <Play size={10} />
                          {pay.status === 'OCZEKUJE' ? 'POTWIERDŹ WARUNEK' : 'DOKONAJ ATOMICZNEGO ROZRACHUNKU'}
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Contract creator */}
            <div className="lg:col-span-5 bg-slate-50 border border-slate-200 rounded p-4">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2">Utwórz nowy smart-kontrakt</h3>
              <form onSubmit={handleCreateContract} className="space-y-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-1 uppercase">Nazwa Projektu / Kontraktu</label>
                  <input
                    type="text"
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    className="w-full text-xs p-1.5 border border-slate-200 rounded focus:outline-none bg-white font-medium"
                    required
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-1 uppercase">Warunek techniczny rozliczenia</label>
                  <input
                    type="text"
                    value={newCond}
                    onChange={(e) => setNewCond(e.target.value)}
                    className="w-full text-xs p-1.5 border border-slate-200 rounded focus:outline-none bg-white"
                    placeholder="np. Skan podpisu dostawy cargo"
                    required
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-1 uppercase">Kwota blokowana (PLN)</label>
                  <input
                    type="number"
                    value={newAmt}
                    onChange={(e) => setNewAmt(e.target.value)}
                    className="w-full text-xs p-1.5 border border-slate-200 rounded font-mono focus:outline-none bg-white"
                    required
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-red-700 hover:bg-red-800 text-white text-xs font-bold py-1.5 rounded transition cursor-pointer"
                >
                  DEPOZYTUJ W ESCROW
                </button>
              </form>
            </div>

          </div>
        </div>
      )}

      {/* LAB 2: OFFLINE PAYMENTS MODEL */}
      {activeLab === 'OFFLINE' && (
        <div className="space-y-5" id="offline-payments-model">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Visual Devices Representation */}
            <div className="space-y-4">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-1">Stateful Hardware NFC Simulation</h3>
              <p className="text-[11px] text-slate-500 leading-relaxed">
                Płatność offline w cyfrowym złotym odbywa się bezpośrednio między bezpiecznymi mikroprocesorami (Secure Element) bez udziału sieci komórkowej czy serwerów NBP. Chroni to przed podwójnym wydatkowaniem lokalnie.
              </p>

              {/* Devices diagram */}
              <div className="border border-slate-200 rounded-lg p-5 bg-slate-50 flex flex-col items-center justify-center space-y-4">
                <div className="flex items-center justify-between w-full max-w-sm">
                  {/* DEVICE A */}
                  <div className="bg-slate-900 text-white border-2 border-slate-800 rounded-xl p-3 w-36 text-center shadow">
                    <div className="text-[8px] font-mono font-bold text-red-500 tracking-wider">SECURE CHIP A</div>
                    <div className="text-xs font-bold mt-1">NFC Terminal</div>
                    <div className="text-lg font-mono font-black mt-2 text-white">{devA.toFixed(2)} zł</div>
                    <div className="text-[9px] text-slate-400 mt-1 uppercase">Zgoda Offline: OK</div>
                  </div>

                  <div className="flex flex-col items-center space-y-1">
                    <span className="text-[10px] font-bold text-red-700 uppercase tracking-widest">{offlineStatus}</span>
                    <div className="h-0.5 w-16 bg-dashed bg-slate-300"></div>
                  </div>

                  {/* DEVICE B */}
                  <div className="bg-slate-900 text-white border-2 border-slate-800 rounded-xl p-3 w-36 text-center shadow">
                    <div className="text-[8px] font-mono font-bold text-red-500 tracking-wider">SECURE CHIP B</div>
                    <div className="text-xs font-bold mt-1">Smartfon Odbiorcy</div>
                    <div className="text-lg font-mono font-black mt-2 text-white">{devB.toFixed(2)} zł</div>
                    <div className="text-[9px] text-slate-400 mt-1 uppercase font-bold text-emerald-400">Offline Active</div>
                  </div>
                </div>

                {/* Operation controls */}
                <div className="flex space-x-3 w-full max-w-sm">
                  <button
                    onClick={executeOfflinePayment}
                    className="flex-1 bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold py-2 rounded transition flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Coins size={12} />
                    Prześlij 150.00 zł
                  </button>
                  <button
                    onClick={syncOfflineNetwork}
                    className="flex-1 bg-red-700 hover:bg-red-800 text-white text-xs font-bold py-2 rounded transition flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <RefreshCw size={12} />
                    Przywróć Sieć (Sync)
                  </button>
                </div>
              </div>
            </div>

            {/* Secure Element Audit Shell Logs */}
            <div className="bg-slate-950 text-emerald-400 font-mono p-4 rounded-lg shadow border border-slate-900 flex flex-col justify-between">
              <div>
                <div className="text-[10px] text-slate-500 font-bold uppercase tracking-wider mb-2 pb-1.5 border-b border-emerald-950/50">
                  Konsola diagnostyczna chipu zabezpieczającego
                </div>
                <div className="space-y-1 text-[11px] max-h-52 overflow-y-auto leading-relaxed">
                  {offlineLog.map((log, idx) => (
                    <div key={idx} className="flex gap-1.5">
                      <span className="text-emerald-700 shrink-0">[$]</span>
                      <span>{log}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="mt-4 pt-2 border-t border-emerald-950/50 text-[10px] text-emerald-600 flex items-center justify-between">
                <span>SE_FIRMWARE: v2.48_RETAIL_SECURE</span>
                <span>STATE_INTEGRITY: NORMAL</span>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* LAB 3: DIGITAL VOUCHERS */}
      {activeLab === 'VOUCHERS' && (
        <div className="space-y-5" id="digital-vouchers-lab">
          <div>
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-1">Cyfrowe bony celowe (Targeted Digital Vouchers)</h3>
            <p className="text-[11px] text-slate-500 leading-relaxed mb-4">
              Narodowy program bonów celowych umożliwia programowanie wydatków budżetowych. Bon może zostać wydany wyłącznie u sprzedawców o pasującej kategorii branżowej (np. Bon Energetyczny tylko u dostawców energii).
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Vouchers List */}
            <div className="space-y-3">
              <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Zdeponowane bony celowe</h4>
              {vouchers.map(v => (
                <div key={v.id} className="border border-slate-200 p-3.5 rounded bg-slate-50 flex flex-col justify-between hover:bg-slate-100/50 transition">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <div className="font-bold text-slate-900 text-xs flex items-center gap-1.5">
                        <Flame size={14} className="text-red-600 animate-pulse" />
                        {v.title}
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono">Dozwolone wydatki: <strong className="text-slate-700">{v.allowedCategory}</strong></div>
                    </div>
                    <span className={`px-2 py-0.5 rounded text-[9px] font-bold border ${v.status === 'AKTYWNY' ? 'bg-green-50 text-green-700 border-green-200' : 'bg-slate-100 text-slate-400'}`}>
                      {v.status}
                    </span>
                  </div>

                  <div className="flex justify-between items-center mt-3 pt-2.5 border-t border-slate-200/50">
                    <span className="font-mono font-bold text-sm text-slate-900">{formatPLN(v.amount)}</span>
                    {v.status === 'AKTYWNY' && (
                      <div className="flex gap-1">
                        <button
                          onClick={() => spendVoucher(v.id, 'Zielony Market Spożywczy')}
                          className="bg-slate-800 hover:bg-slate-900 text-white text-[10px] font-bold py-1 px-2 rounded cursor-pointer"
                        >
                          Zrealizuj (Market)
                        </button>
                        <button
                          onClick={() => spendVoucher(v.id, 'Krajowy Operator Energii')}
                          className="bg-red-700 hover:bg-red-800 text-white text-[10px] font-bold py-1 px-2 rounded cursor-pointer"
                        >
                          Zrealizuj (Energia)
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* Rules visualizer */}
            <div className="bg-slate-50 border border-slate-200 rounded p-4 text-xs text-slate-600 flex flex-col justify-between">
              <div>
                <h4 className="text-[10px] font-bold text-slate-700 uppercase tracking-wider mb-2">Jak działają ograniczenia (Restrictions Ledger)</h4>
                <div className="space-y-3 leading-relaxed">
                  <p>
                    Silnik rozliczeniowy CBDC na poziomie API weryfikuje kod MCC (Merchant Category Code) odbiorcy płatności.
                  </p>
                  <div className="bg-white p-3 rounded border border-slate-200 space-y-2">
                    <div className="flex items-center justify-between text-[11px] font-mono">
                      <span>Próba: Bon Energetyczny {"->"} Zielony Market</span>
                      <span className="text-red-600 font-bold uppercase">BŁĄD KONTROLI</span>
                    </div>
                    <div className="h-px bg-slate-100"></div>
                    <div className="flex items-center justify-between text-[11px] font-mono">
                      <span>Próba: Bon Energetyczny {"->"} Operator Energii</span>
                      <span className="text-emerald-600 font-bold uppercase">ZATWIERDZONO (DvP)</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="text-[10px] text-slate-400 mt-4 leading-relaxed">
                * Bony są w pełni zintegrowane z Krajową Tożsamością Cyfrową i kontem skarbowym, co eliminuje fałszerstwa czy nieautoryzowaną odsprzedaż subsydiów.
              </div>
            </div>
          </div>
        </div>
      )}

      {/* LAB 4: TOKENISATION & SECURITIES DvP */}
      {activeLab === 'TOKENISATION' && (
        <div className="space-y-5" id="tokenisation-dvp-lab">
          <div>
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-1">DVP Securities Settlement (Rozrachunek DVP DLT)</h3>
            <p className="text-[11px] text-slate-500 leading-relaxed mb-4">
              Zasymuluj atomowy rozrachunek Delivery-versus-Payment (DvP) na tokenizowanych obligacjach rządowych przy użyciu Cyfrowego Złotego. Przeniesienie własności obligacji (Asset Leg) i płatność (Cash Leg) odbywają się równocześnie - uniemożliwia to powstanie ryzyka niewykonania zobowiązania przez kontrahenta (settlement risk).
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* List of securities */}
            <div className="space-y-3">
              <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Krajowe Papiery Wartościowe na Ledgerze</h4>
              {tokenisedAssets.map(asset => (
                <div key={asset.id} className="border border-slate-200 p-3 rounded bg-slate-50 hover:bg-slate-100/50 transition">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <div className="font-bold text-slate-900 text-xs">{asset.name}</div>
                      <div className="text-[10px] text-slate-400 font-mono">Emitent: Skarb Państwa | Rentowność: {asset.yield}%</div>
                    </div>
                    <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${
                      asset.settlementStatus === 'ROZLICZONY_DVP' 
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-200' 
                        : 'bg-blue-50 text-blue-700 border-blue-200'
                    }`}>
                      {asset.settlementStatus}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-4 text-xs font-mono my-2.5 bg-white p-2 rounded border border-slate-200">
                    <div>
                      <div className="text-[9px] text-slate-400 block font-bold">CENA ROZRACHUNKU</div>
                      <strong className="text-slate-900">{formatPLN(asset.price)}</strong>
                    </div>
                    <div>
                      <div className="text-[9px] text-slate-400 block font-bold">WŁAŚCICIEL (ASSET OWNER)</div>
                      <strong className="text-slate-700">{asset.owner}</strong>
                    </div>
                  </div>

                  {asset.settlementStatus !== 'ROZLICZONY_DVP' && (
                    <div className="flex justify-end gap-1.5">
                      <button
                        onClick={() => executeSecuritiesTrade(asset.id, 'bank-mazowiecki')}
                        className="bg-red-700 hover:bg-red-800 text-white text-[10px] font-bold py-1 px-3 rounded cursor-pointer"
                      >
                        Kup jako Bank Mazowiecki (DvP)
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* DLT Settlement flow chart */}
            <div className="bg-slate-50 border border-slate-200 rounded p-4 text-xs text-slate-600 flex flex-col justify-between">
              <div>
                <h4 className="text-[10px] font-bold text-slate-700 uppercase tracking-wider mb-2">Schemat atomowego DvP (Atomic Ledger Settlement)</h4>
                <div className="space-y-4">
                  <div className="flex items-center justify-between border-b border-slate-200 pb-1.5">
                    <span>Instytucja Kupująca</span>
                    <strong className="text-slate-900">Bank Mazowiecki</strong>
                  </div>
                  <div className="flex items-center justify-between border-b border-slate-200 pb-1.5">
                    <span>Instytucja Sprzedająca</span>
                    <strong className="text-slate-900">Bank Bałtycki / Śląski</strong>
                  </div>

                  <div className="bg-white p-3 border border-slate-200 rounded space-y-2">
                    <div className="flex items-center justify-between text-[10px] font-mono">
                      <span className="text-blue-700 font-bold">KROK 1: Blokada Aktywów (Securities Leg)</span>
                      <span>POTWIERDZONE</span>
                    </div>
                    <div className="flex items-center justify-between text-[10px] font-mono">
                      <span className="text-red-700 font-bold">KROK 2: Blokada CBDC (Cash Leg)</span>
                      <span>POTWIERDZONE</span>
                    </div>
                    <div className="h-px bg-slate-100"></div>
                    <div className="flex items-center justify-between text-[11px] font-mono font-bold text-emerald-700">
                      <span>KROK 3: Zamiana i rozrachunek (DvP Settlement)</span>
                      <span>ROZLICZONY ATOMICZNIE</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="text-[10px] text-slate-400 mt-4 leading-relaxed">
                * DvP na zunifikowanym rejestrze eliminuje potrzebę pośrednictwa tradycyjnych izb rozrachunkowych i minimalizuje zapotrzebowanie banków na intraday płynność o ponad 35%.
              </div>
            </div>
          </div>
        </div>
      )}

      {/* LAB 5: MONETARY SYSTEM SIMULATOR */}
      {activeLab === 'MACRO' && (
        <div className="space-y-5" id="macroeconomic-simulator-lab">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Scenarios trigger */}
            <div className="lg:col-span-4 bg-slate-50 border border-slate-200 rounded p-4 space-y-3.5">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">Scenariusze rynkowe i stresowe</h3>
              <p className="text-[11px] text-slate-500 leading-relaxed">
                Wybierz makroekonomiczny scenariusz badawczy. Zmiana parametrów wpłynie na popyt na depozyty bankowe, rotację gotówki, prędkość obiegu cyfrowej waluty (Velocity) oraz wskaźniki płynności systemu.
              </p>

              <div className="space-y-2">
                {[
                  { id: 'BAZOWY', label: 'BAZOWY (DEFAULT)' },
                  { id: 'WYSOKA_ADOPCJA', label: 'WYSOKA ADOPCJA CBDC' },
                  { id: 'NISKA_ADOPCJA', label: 'SŁABA ADOPCJA SPOŁECZNA' },
                  { id: 'SZOK_PŁYNNOŚCIOWY', label: 'SZOK PŁYNNOŚCIOWY RYNKU' },
                  { id: 'WYSOKA_TOKENIZACJA', label: 'WYSOKA TOKENIZACJA DLT' },
                  { id: 'ODPŁYW_DEPOZYTÓW', label: 'ODPŁYW DEPOZYTÓW DO CBDC' },
                  { id: 'KRYZYS_FINANSOWY', label: 'KRYZYS FINANSOWY I INFLACJA' }
                ].map(scen => (
                  <button
                    key={scen.id}
                    onClick={() => setScenario(scen.id as ScenarioType)}
                    className={`w-full text-left text-xs font-bold p-2 rounded border transition cursor-pointer ${
                      selectedScenario === scen.id 
                        ? 'border-red-600 bg-red-50 text-red-700' 
                        : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    {scen.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Simulated macroeconomic output indicators */}
            <div className="lg:col-span-8 bg-white border border-slate-200 rounded-lg p-4 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                <span className="font-bold text-xs uppercase text-slate-700">Symulowane Parametry Makroekonometrii</span>
                <span className="text-[10px] font-bold text-red-700 bg-red-50 border border-red-200 px-2 py-0.5 rounded">
                  SYMULACJA MODELOWA
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs font-mono">
                <div className="p-3 bg-slate-50 rounded border border-slate-100">
                  <div className="text-[9px] text-slate-400 font-bold uppercase">Podręczna podaż CBDC (M0)</div>
                  <strong className="text-slate-900 text-sm">{economics.cbdcSupply.toFixed(1)} mld zł</strong>
                </div>
                <div className="p-3 bg-slate-50 rounded border border-slate-100">
                  <div className="text-[9px] text-slate-400 font-bold uppercase">Depozyty bankowe komercyjne</div>
                  <strong className="text-slate-900 text-sm">{economics.bankDeposits.toFixed(1)} mld zł</strong>
                </div>
                <div className="p-3 bg-slate-50 rounded border border-slate-100">
                  <div className="text-[9px] text-slate-400 font-bold uppercase">Rezerwy w banku centralnym</div>
                  <strong className="text-slate-900 text-sm">{economics.bankReserves.toFixed(1)} mld zł</strong>
                </div>
                <div className="p-3 bg-slate-50 rounded border border-slate-100">
                  <div className="text-[9px] text-slate-400 font-bold uppercase">Łączna Podaż Pieniądza (M3)</div>
                  <strong className="text-slate-900 text-sm">{economics.moneySupply.toFixed(1)} mld zł</strong>
                </div>
                <div className="p-3 bg-slate-50 rounded border border-slate-100">
                  <div className="text-[9px] text-slate-400 font-bold uppercase">Wzrost PKB (r/r)</div>
                  <strong className={`text-sm ${economics.gdp < 0 ? 'text-red-700' : 'text-slate-900'}`}>{economics.gdp.toFixed(1)}%</strong>
                </div>
                <div className="p-3 bg-slate-50 rounded border border-slate-100">
                  <div className="text-[9px] text-slate-400 font-bold uppercase">Prędkość Obiegu (Velocity)</div>
                  <strong className="text-slate-900 text-sm">{economics.velocity.toFixed(2)}x</strong>
                </div>
                <div className="p-3 bg-slate-50 rounded border border-slate-100">
                  <div className="text-[9px] text-slate-400 font-bold uppercase">Stopa referencyjna NBP</div>
                  <strong className="text-slate-900 text-sm">{economics.interestRates.toFixed(2)}%</strong>
                </div>
                <div className="p-3 bg-slate-50 rounded border border-slate-100">
                  <div className="text-[9px] text-slate-400 font-bold uppercase">Wskaźnik Inflacji</div>
                  <strong className="text-slate-900 text-sm">{economics.inflation.toFixed(1)}%</strong>
                </div>
                <div className="p-3 bg-slate-50 rounded border border-slate-100">
                  <div className="text-[9px] text-slate-400 font-bold uppercase">Adopcja Cyfrowa</div>
                  <strong className="text-slate-900 text-sm">{economics.digitalAdoption.toFixed(1)}%</strong>
                </div>
              </div>

              <div className="text-[10px] text-slate-400 italic leading-relaxed pt-2.5 border-t border-slate-100">
                WYNIK SYMULACJI: Powyższe wartości stanowią matematycznie deterministyczny model behawioralny, wywołany przez zmiany stóp procentowych, stopień migracji depozytów rynkowych i adopcję technologii CBDC. Nie są prognozami Narodowego Banku Polskiego.
              </div>
            </div>

          </div>
        </div>
      )}

      {/* LAB 6: M2M & AI AUTONOMOUS AGENTS */}
      {activeLab === 'M2M_AI' && (
        <div className="space-y-6" id="m2m-ai-agents-lab">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* EV M2M CHARGER */}
            <div className="border border-slate-200 rounded-lg p-4 bg-slate-50 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between border-b border-slate-200 pb-2 mb-3">
                  <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                    <Car size={16} className="text-red-600" />
                    Płatności Maszyna-Maszyna (M2M) · Elektromobilność
                  </h4>
                  <span className="text-[9px] font-mono bg-slate-200 text-slate-700 font-bold px-1.5 py-0.5 rounded">
                    EV DEMO
                  </span>
                </div>

                <p className="text-[11px] text-slate-500 leading-relaxed mb-4">
                  Autonomiczne mikropłatności między inteligentnymi systemami fizycznymi. Samochód elektryczny (EV) samodzielnie negocjuje i rozlicza pobór prądu bezpośrednio na ładowarce w standardzie cyfrowego złotego.
                </p>

                {/* EV Display card */}
                <div className="bg-slate-900 text-white rounded-lg p-4 space-y-3 font-mono text-[11px] border border-slate-950">
                  <div className="flex justify-between">
                    <span>POJAZD: Tesla Model S (Synthetic)</span>
                    <span className="text-emerald-400 font-bold">STATUS: {evMachine.status}</span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-center text-[10px]">
                    <div className="bg-slate-800 p-1.5 rounded">
                      <div className="text-[8px] text-slate-400">Akumulator</div>
                      <div className="font-bold text-sm text-slate-100">{evMachine.battery}%</div>
                    </div>
                    <div className="bg-slate-800 p-1.5 rounded">
                      <div className="text-[8px] text-slate-400">Limit Autoryz.</div>
                      <div className="font-bold text-sm text-slate-100">{evMachine.maxAuthorised} zł</div>
                    </div>
                    <div className="bg-slate-800 p-1.5 rounded">
                      <div className="text-[8px] text-slate-400">Koszt naliczony</div>
                      <div className="font-bold text-sm text-red-400">{evMachine.zlotySpent} zł</div>
                    </div>
                  </div>

                  {/* Flow Steps */}
                  <div className="text-[9px] space-y-1 text-slate-300">
                    <div>[✓] Bramka ładowarki zweryfikowana: {evMachine.stationVerified ? 'TAK' : 'NIE'}</div>
                    <div>[✓] Taryfa energetyczna potwierdzona: {evMachine.priceVerified ? 'TAK' : 'NIE'}</div>
                    <div>[✓] Rezerwa portfela zabezpieczona: {evMachine.walletAuthorised ? 'TAK' : 'NIE'}</div>
                  </div>
                </div>
              </div>

              <div className="flex gap-2 mt-4">
                <button
                  onClick={advanceEvMachine}
                  className="flex-1 bg-red-700 hover:bg-red-800 text-white font-bold text-xs py-1.5 rounded cursor-pointer text-center"
                >
                  Postępuj Krok M2M (TICK)
                </button>
                <button
                  onClick={resetEvMachine}
                  className="bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs py-1.5 px-3 rounded cursor-pointer"
                >
                  Reset
                </button>
              </div>
            </div>

            {/* AI AGENT WISLA-01 */}
            <div className="border border-slate-200 rounded-lg p-4 bg-slate-50 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between border-b border-slate-200 pb-2 mb-3">
                  <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                    <Cpu size={16} className="text-red-600 animate-pulse" />
                    Autonomiczni Agenci Płatniczy (AI Agents Core)
                  </h4>
                  <span className="text-[9px] font-mono bg-red-100 text-red-700 font-bold px-1.5 py-0.5 rounded">
                    WISŁA-01
                  </span>
                </div>

                <p className="text-[11px] text-slate-500 leading-relaxed mb-4">
                  Autonomiczny agent finansowy wyposażony w ściśle zdefiniowane limity budżetowe i dozwolone kategorie branżowe. Służy do automatyzacji płatności logistycznych i skarbowych.
                </p>

                {/* AI Agent Console */}
                <div className="bg-slate-950 text-emerald-400 rounded-lg p-4 space-y-3 font-mono text-[11px] border border-slate-900">
                  <div className="flex justify-between text-[10px] text-emerald-600">
                    <span>AGENT ID: CBDC-AGENT-WISLA-01</span>
                    <span>STAN: {aiAgent.status}</span>
                  </div>

                  <div>
                    <div className="text-[8px] text-slate-500 font-bold">ZADANIE AGENTA (CURRENT TASK LOG):</div>
                    <p className="text-[10px] text-slate-300 mt-1 leading-relaxed">
                      {aiAgent.currentTask}
                    </p>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-[10px] border-t border-slate-900 pt-2 text-slate-400">
                    <div>Portfel agenta: <strong className="text-emerald-400">{aiAgent.balance.toLocaleString('pl-PL')} zł</strong></div>
                    <div>Max limit / tx: <strong className="text-slate-200">{aiAgent.maxTransactionLimit} zł</strong></div>
                  </div>
                </div>
              </div>

              <div className="flex gap-2 mt-4">
                <button
                  onClick={advanceAiAgent}
                  className="flex-1 bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs py-1.5 rounded cursor-pointer text-center"
                >
                  Uruchom krok AI Agent (TICK)
                </button>
                <button
                  onClick={resetAiAgent}
                  className="bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs py-1.5 px-3 rounded cursor-pointer"
                >
                  Reset
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* LAB 7: SYSTEM ARCHITECTURES */}
      {activeLab === 'ARCHITECTURES' && (
        <div className="space-y-4 text-xs text-slate-700" id="cbdc-architectures-comp">
          <div>
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-1">Architektury Cyfrowego Złotego (Porównanie Neutralne)</h3>
            <p className="text-[11px] text-slate-500 leading-relaxed mb-4">
              Zarówno model kontowy jak i tokenowy posiadają unikalne cechy techniczne. System badawczy nie deklaruje przewagi żadnej z architektur, lecz analizuje ich stabilność systemową.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Model A: Account based */}
            <div className={`p-4 rounded border transition ${modelMode === 'Account' ? 'border-red-600 bg-red-50/20' : 'border-slate-200 bg-white'}`}>
              <div className="flex justify-between items-center mb-3">
                <strong className="text-sm text-slate-900 font-bold">MODEL A: Cyfrowy Złoty kontowy (Account-based)</strong>
                <button
                  onClick={() => setModelMode('Account')}
                  className={`text-[10px] font-bold px-2 py-0.5 rounded cursor-pointer ${modelMode === 'Account' ? 'bg-red-700 text-white' : 'bg-slate-100 text-slate-700'}`}
                >
                  WYBIERZ W SYMULACJI
                </button>
              </div>
              <ul className="space-y-2 leading-relaxed">
                <li>• <strong>Weryfikacja:</strong> Tożsamościowa (KYC) powiązana bezpośrednio z kontem rozliczeniowym.</li>
                <li>• <strong>Płatności offline:</strong> Bardzo ograniczone, wymagające okresowej synchronizacji rezerw.</li>
                <li>• <strong>Intermediacja:</strong> Silna rola banków komercyjnych jako podmiotów prowadzących rachunki.</li>
                <li>• <strong>Skalowalność:</strong> Wysoka (tradycyjne rozproszone systemy baz danych).</li>
              </ul>
            </div>

            {/* Model B: Wallet based */}
            <div className={`p-4 rounded border transition ${modelMode === 'Wallet' ? 'border-red-600 bg-red-50/20' : 'border-slate-200 bg-white'}`}>
              <div className="flex justify-between items-center mb-3">
                <strong className="text-sm text-slate-900 font-bold">MODEL B: Cyfrowy Złoty tokenowy (Wallet-based)</strong>
                <button
                  onClick={() => setModelMode('Wallet')}
                  className={`text-[10px] font-bold px-2 py-0.5 rounded cursor-pointer ${modelMode === 'Wallet' ? 'bg-red-700 text-white' : 'bg-slate-100 text-slate-700'}`}
                >
                  WYBIERZ W SYMULACJI
                </button>
              </div>
              <ul className="space-y-2 leading-relaxed">
                <li>• <strong>Weryfikacja:</strong> Kryptograficzna (podpisy cyfrowe i klucze prywatne).</li>
                <li>• <strong>Płatności offline:</strong> Natywne, bezpośrednie transfery hardware-to-hardware.</li>
                <li>• <strong>Intermediacja:</strong> Model hybrydowy (banki są tylko dystrybutorami portfeli).</li>
                <li>• <strong>Prywatność:</strong> Wyższa stopa pseudonimizacji dla płatności detalicznych.</li>
              </ul>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
