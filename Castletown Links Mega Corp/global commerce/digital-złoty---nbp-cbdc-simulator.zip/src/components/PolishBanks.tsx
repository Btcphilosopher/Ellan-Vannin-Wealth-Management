/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useSimulationStore } from '../simulationStore';
import { Building2, ShieldAlert, Award, Zap, Activity, Coins, HeartCrack } from 'lucide-react';

export const PolishBanks: React.FC = () => {
  const { banks, paymentInstitutions, resolveLiquidityShortage, failures, toggleFailure } = useSimulationStore();

  const formatPLN = (val: number) => {
    if (val >= 1_000_000_000) return `${(val / 1_000_000_000).toLocaleString('pl-PL', { maximumFractionDigits: 2 })} mld zł`;
    if (val >= 1_000_000) return `${(val / 1_000_000).toLocaleString('pl-PL', { maximumFractionDigits: 1 })} mln zł`;
    return `${val.toLocaleString('pl-PL')} zł`;
  };

  const getRiskColor = (score: number) => {
    if (score < 12) return 'bg-green-50 text-green-700 border-green-200';
    if (score < 25) return 'bg-yellow-50 text-yellow-700 border-yellow-200';
    return 'bg-red-50 text-red-700 border-red-200 animate-pulse';
  };

  // Find if a bank has liquidity deficit (reserves < 5 mld or active stress)
  const isLiquidityShortageActive = failures.find(f => f.id === 'fail-liquidity')?.active;

  return (
    <div className="space-y-6" id="polish-banks-section">
      
      {/* SECTION 1: COMMERCIAL BANKS WORKSTATION */}
      <div className="bg-white border border-slate-200 shadow-sm rounded-lg p-5">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-slate-100 text-slate-800 rounded">
              <Building2 size={20} />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900 tracking-wide uppercase">Krajowy System Bankowości Komercyjnej</h2>
              <p className="text-xs text-slate-500 uppercase tracking-wider">Pośrednicy Finansowi i Dystrybutorzy Cyfrowego Złotego</p>
            </div>
          </div>
          <div className="text-right text-xs text-slate-500 font-medium">
            Aktywne podmioty: <span className="font-bold text-slate-950 font-mono">{banks.length}</span>
          </div>
        </div>

        {/* Dense Financial Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider text-[10px]">
                <th className="py-2.5 px-3">Nazwa Instytucji</th>
                <th className="py-2.5 px-3 text-right">Depozyty Klientów</th>
                <th className="py-2.5 px-3 text-right">Rezerwy NBP</th>
                <th className="py-2.5 px-3 text-right text-red-700">Cyfrowy Złoty (CBDC)</th>
                <th className="py-2.5 px-3 text-right">Portfel Papierów</th>
                <th className="py-2.5 px-3 text-right">Zabezpieczenia (Collateral)</th>
                <th className="py-2.5 px-3 text-center">Kolejka (RTGS)</th>
                <th className="py-2.5 px-3 text-center">Risk Score</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {banks.map(bank => (
                <tr key={bank.id} className="hover:bg-slate-50 transition">
                  <td className="py-3 px-3 font-bold text-slate-900 flex items-center gap-2">
                    <span className={`w-2 h-2 rounded-full ${bank.riskScore > 30 ? 'bg-red-500 animate-ping' : 'bg-green-500'}`}></span>
                    {bank.name}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-slate-900">{formatPLN(bank.deposits)}</td>
                  <td className="py-3 px-3 text-right font-mono text-slate-900">{formatPLN(bank.reserves)}</td>
                  <td className="py-3 px-3 text-right font-mono text-red-700 font-bold">{formatPLN(bank.digitalZloty)}</td>
                  <td className="py-3 px-3 text-right font-mono text-slate-900">{formatPLN(bank.securities)}</td>
                  <td className="py-3 px-3 text-right font-mono text-slate-900">{formatPLN(bank.collateral)}</td>
                  <td className="py-3 px-3 text-center">
                    {bank.settlementQueueLength > 0 ? (
                      <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold bg-yellow-100 text-yellow-800 animate-pulse">
                        {bank.settlementQueueLength} tx
                      </span>
                    ) : (
                      <span className="text-slate-400 font-mono">-</span>
                    )}
                  </td>
                  <td className="py-3 px-3 text-center">
                    <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold border ${getRiskColor(bank.riskScore)}`}>
                      {bank.riskScore.toFixed(0)} / 100
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* SECTION 2: LIQUIDITY DESK & STRESS RESOLUTION */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Liquidity Desk */}
        <div className="lg:col-span-7 bg-white border border-slate-200 shadow-sm rounded-lg p-5 flex flex-col justify-between" id="liquidity-risk-manager">
          <div>
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide flex items-center gap-2">
                <Activity size={16} className="text-red-600" />
                CENTRUM ZARZĄDZANIA PŁYNNOŚCIĄ &amp; STABILNOŚĆ SYSTEMU
              </h3>
              <span className="text-[10px] font-bold bg-slate-100 px-2 py-0.5 rounded border border-slate-200 text-slate-600">
                MONITORING LIQUIDITY INTRADAY
              </span>
            </div>

            <p className="text-xs text-slate-600 mb-4 leading-relaxed">
              Każda instytucja rozliczeniowa w systemie Cyfrowego Złotego musi utrzymywać odpowiednie pokrycie rezerwami w NBP do natychmiastowego clearingu. W przypadku niedoborów płynności, transakcje trafiają do kolejki rozrachunkowej (RTGS Queue).
            </p>

            {/* Stress Simulator controls */}
            <div className="bg-slate-50 border border-slate-200 rounded p-4 mb-4">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                  <ShieldAlert size={15} className="text-red-600 animate-pulse" />
                  Symulacja Szoku Płynnościowego (Stress Testing)
                </span>
                <button
                  onClick={() => toggleFailure('fail-liquidity')}
                  className={`text-xs font-bold px-3 py-1 rounded transition cursor-pointer ${
                    isLiquidityShortageActive 
                      ? 'bg-red-700 text-white hover:bg-red-800' 
                      : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                  }`}
                >
                  {isLiquidityShortageActive ? 'WYŁĄCZ SZOK' : 'URUCHOM SZOK (BANK ŚLĄSKI)'}
                </button>
              </div>
              <p className="text-[11px] text-slate-500 leading-relaxed mb-3">
                Zasymuluj nagły odpływ depozytów i rezerw w <strong>Banku Śląskim Nowej Generacji</strong>. Dostępna płynność spadnie poniżej wymaganego progu rozrachunkowego, blokując clearing i powodując wzrost kolejki transakcyjnej.
              </p>
              
              {isLiquidityShortageActive && (
                <div className="bg-red-50 border border-red-200 rounded p-3 text-xs text-red-800 flex items-start gap-2 animate-pulse">
                  <HeartCrack size={16} className="mt-0.5 shrink-0" />
                  <div>
                    <span className="font-bold">STATUS OSTRZEGAWCZY:</span> Wykryto niedobór płynności w Banku Śląskim Nowej Generacji! Kolejka rozrachunkowa rośnie. Wymagane natychmiastowe uruchomienie operacji REPO lub linii kredytowej NBP.
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Quick resolution triggers */}
          <div className="border-t border-slate-100 pt-4 flex justify-between items-center">
            <span className="text-xs text-slate-500">Płynność całego systemu: <strong className="text-green-700">ZADOWALAJĄCA</strong></span>
            <button
              onClick={() => resolveLiquidityShortage('bank-slaski')}
              className="bg-green-700 hover:bg-green-700 text-white text-xs font-bold py-1.5 px-4 rounded shadow-sm flex items-center gap-1.5 transition cursor-pointer"
            >
              <Zap size={14} />
              URUCHOM REPO (WSTRZYKNIJ 1 MLD ZŁ)
            </button>
          </div>
        </div>

        {/* Payment & E-money Institutions */}
        <div className="lg:col-span-5 bg-white border border-slate-200 shadow-sm rounded-lg p-5 flex flex-col justify-between" id="fintech-emoney-desk">
          <div>
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide flex items-center gap-2">
                <Coins size={16} className="text-red-600" />
                KRAJOWE INSTYTUCJE PŁATNICZE
              </h3>
              <span className="text-[10px] font-bold bg-slate-50 border border-slate-200 text-red-700 px-1.5 py-0.5 rounded">
                API FINTECH
              </span>
            </div>

            <div className="space-y-3.5">
              {paymentInstitutions.map(inst => (
                <div key={inst.id} className="border border-slate-200 p-3 rounded hover:bg-slate-50 transition">
                  <div className="flex justify-between items-center mb-1">
                    <span className="font-bold text-slate-900 text-xs">{inst.name}</span>
                    <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[9px] font-bold bg-green-50 text-green-700 border border-green-200">
                      API: {inst.apiStatus}
                    </span>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-2 text-[10px] text-slate-600 font-mono pt-1.5 border-t border-slate-100">
                    <div>
                      <div className="text-[9px] text-slate-400 font-bold uppercase">Użytkownicy</div>
                      <div className="font-bold text-slate-800">{(inst.customers / 1000).toFixed(0)}k</div>
                    </div>
                    <div>
                      <div className="text-[9px] text-slate-400 font-bold uppercase">E-money</div>
                      <div className="font-bold text-slate-800">{formatPLN(inst.electronicMoney)}</div>
                    </div>
                    <div>
                      <div className="text-[9px] text-slate-400 font-bold uppercase">Saldo CBDC</div>
                      <div className="font-bold text-red-700">{formatPLN(inst.digitalZlotyBalance)}</div>
                    </div>
                  </div>

                  <div className="mt-2 flex items-center justify-between text-[9px]">
                    <span className="text-slate-400">Zgodność KYC/AML: <strong className="text-slate-700">{inst.compliance}%</strong></span>
                    <span className="text-slate-400">Wskaźnik ryzyka: <strong className="text-slate-700">{inst.risk}/100</strong></span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="text-[10px] text-slate-400 mt-4 italic leading-relaxed border-t border-slate-100 pt-3">
            * Instytucje Pieniądza Elektronicznego (EMI) utrzymują 100% pokrycia wyemitowanego e-money w tradycyjnych depozytach bankowych lub bezpośrednio w cyfrowym złotym na rachunku powierniczym w NBP.
          </div>
        </div>

      </div>

    </div>
  );
};
