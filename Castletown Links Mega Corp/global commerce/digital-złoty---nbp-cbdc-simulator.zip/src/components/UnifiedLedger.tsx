/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useSimulationStore } from '../simulationStore';
import { Search, ListFilter, Trash2, CheckCircle2, RefreshCw, Eye, XCircle } from 'lucide-react';
import { Transaction } from '../types';

export const UnifiedLedger: React.FC = () => {
  const { transactions, clearAuditLogs } = useSimulationStore();
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedAsset, setSelectedAsset] = useState<string>('Wszystkie');
  const [selectedTx, setSelectedTx] = useState<Transaction | null>(null);

  const filteredTxs = transactions.filter(t => {
    const matchesSearch = 
      t.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.sender.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.receiver.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.institution.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.auditId.toLowerCase().includes(searchTerm.toLowerCase());
      
    const matchesAsset = selectedAsset === 'Wszystkie' || t.asset === selectedAsset;

    return matchesSearch && matchesAsset;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'FINALIZACJA':
      case 'ROZLICZENIE':
        return 'text-emerald-700 bg-emerald-50 border-emerald-200';
      case 'ODRZUCONA':
        return 'text-red-700 bg-red-50 border-red-200';
      default:
        return 'text-yellow-700 bg-yellow-50 border-yellow-200';
    }
  };

  return (
    <div className="bg-white border border-slate-200 shadow-sm rounded-lg p-5" id="unified-ledger-component">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-slate-100 pb-4 mb-4 gap-4">
        <div>
          <h2 className="text-sm font-bold text-slate-900 tracking-wide uppercase flex items-center gap-1.5">
            <ListFilter size={16} className="text-red-600" />
            GŁÓWNY REJESTR TRANSAKCYJNY CYFROWEGO ZŁOTEGO
          </h2>
          <p className="text-xs text-slate-500 uppercase tracking-wider">Czas Rzeczywisty · Rozrachunek RTGS / DLT · Standard ISO 20022</p>
        </div>

        <div className="flex items-center space-x-2 shrink-0">
          <div className="relative">
            <Search size={14} className="absolute left-2.5 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="Szukaj ID, nadawcy, odbiorcy..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="text-xs pl-8 pr-3 py-1.5 border border-slate-200 rounded w-48 focus:outline-none focus:border-slate-400 bg-slate-50"
            />
          </div>

          <select
            value={selectedAsset}
            onChange={(e) => setSelectedAsset(e.target.value)}
            className="text-xs py-1.5 px-2 border border-slate-200 rounded bg-slate-50 focus:outline-none"
          >
            <option value="Wszystkie">Wszystkie aktywa</option>
            <option value="Cyfrowy Złoty">Cyfrowy Złoty</option>
            <option value="Depozyt Bankowy">Pieniądz Bankowy</option>
            <option value="Pieniądz Elektroniczny">E-money</option>
            <option value="Tokenizowany Aktyw">Tokenizowane Aktywa</option>
          </select>

          <button
            onClick={clearAuditLogs}
            className="p-1.5 text-slate-500 hover:text-red-600 border border-slate-200 rounded hover:bg-slate-50 transition cursor-pointer"
            title="Wyczyść logi sesji"
          >
            <Trash2 size={14} />
          </button>
        </div>
      </div>

      {/* Main Ledger Table */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Logs List Table */}
        <div className={`${selectedTx ? 'lg:col-span-8' : 'lg:col-span-12'} transition-all overflow-x-auto`}>
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider text-[10px]">
                <th className="py-2 px-2">ID Transakcji</th>
                <th className="py-2 px-2">Czas rozrachunku</th>
                <th className="py-2 px-2">Nadawca</th>
                <th className="py-2 px-2">Odbiorca</th>
                <th className="py-2 px-2">Instytucja</th>
                <th className="py-2 px-2">Typ aktywa</th>
                <th className="py-2 px-2 text-right">Kwota</th>
                <th className="py-2 px-2 text-center">Status</th>
                <th className="py-2 px-2 text-center">Akcja</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium font-mono text-[11px] text-slate-700">
              {filteredTxs.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-6 text-center text-slate-400 italic font-sans">
                    Brak transakcji w rejestrze spełniających kryteria wyszukiwania.
                  </td>
                </tr>
              ) : (
                filteredTxs.map(t => (
                  <tr key={t.id} className="hover:bg-slate-50/50 transition">
                    <td className="py-2 px-2 font-bold text-slate-900">{t.id}</td>
                    <td className="py-2 px-2 text-slate-500">{t.timestamp}</td>
                    <td className="py-2 px-2 truncate max-w-[100px] font-sans font-medium text-slate-800" title={t.sender}>{t.sender}</td>
                    <td className="py-2 px-2 truncate max-w-[100px] font-sans font-medium text-slate-800" title={t.receiver}>{t.receiver}</td>
                    <td className="py-2 px-2 font-sans text-slate-500">{t.institution}</td>
                    <td className="py-2 px-2 font-sans">
                      <span className={`px-1 rounded text-[10px] ${
                        t.asset === 'Cyfrowy Złoty' 
                          ? 'bg-red-50 text-red-700 font-bold' 
                          : t.asset === 'Tokenizowany Aktyw' 
                            ? 'bg-blue-50 text-blue-700' 
                            : 'bg-slate-100 text-slate-600'
                      }`}>
                        {t.asset}
                      </span>
                    </td>
                    <td className="py-2 px-2 text-right font-bold text-slate-900">
                      {t.amount.toLocaleString('pl-PL', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} zł
                    </td>
                    <td className="py-2 px-2 text-center">
                      <span className={`inline-flex items-center px-1.5 py-0.2 rounded text-[9px] font-bold border ${getStatusColor(t.status)}`}>
                        {t.status}
                      </span>
                    </td>
                    <td className="py-2 px-2 text-center font-sans">
                      <button
                        onClick={() => setSelectedTx(t)}
                        className="p-1 text-slate-600 hover:text-slate-900 border border-slate-200 rounded hover:bg-slate-50 transition cursor-pointer"
                        title="Szczegóły cyklu transakcji"
                      >
                        <Eye size={12} />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Selected Transaction Inspector Detail Panel */}
        {selectedTx && (
          <div className="lg:col-span-4 bg-slate-50 border border-slate-200 rounded-lg p-4 text-xs font-sans text-slate-700 flex flex-col justify-between animate-fadeIn">
            <div>
              <div className="flex items-center justify-between border-b border-slate-200 pb-2 mb-3">
                <span className="font-bold text-slate-900 uppercase">Inspektor cyklu transakcji</span>
                <button
                  onClick={() => setSelectedTx(null)}
                  className="p-0.5 text-slate-400 hover:text-slate-700 hover:bg-slate-200 rounded cursor-pointer"
                >
                  <XCircle size={14} />
                </button>
              </div>

              {/* Transaction lifecycle milestones */}
              <div className="space-y-3.5">
                <div>
                  <div className="text-[10px] text-slate-400 font-bold uppercase">Identyfikator ISO 20022</div>
                  <div className="font-mono font-bold text-slate-900">{selectedTx.id}</div>
                </div>

                {/* Simulated Steps */}
                <div className="relative border-l border-slate-300 ml-2.5 pl-4 space-y-3">
                  <div className="relative">
                    <span className="absolute -left-[21px] top-0.5 w-3.5 h-3.5 rounded-full bg-slate-800 border-2 border-white flex items-center justify-center text-[8px] text-white font-bold">1</span>
                    <div className="font-bold text-slate-900">UTWORZENIE</div>
                    <div className="text-[10px] text-slate-500 font-mono">Inicjalizacja transakcji z portfela nadawcy</div>
                  </div>

                  <div className="relative">
                    <span className="absolute -left-[21px] top-0.5 w-3.5 h-3.5 rounded-full bg-slate-800 border-2 border-white flex items-center justify-center text-[8px] text-white font-bold">2</span>
                    <div className="font-bold text-slate-900">AUTORYZACJA KRYPTOGRAFICZNA</div>
                    <div className="text-[10px] text-slate-500 font-mono">Podpis: {selectedTx.authorization}</div>
                  </div>

                  <div className="relative">
                    <span className="absolute -left-[21px] top-0.5 w-3.5 h-3.5 rounded-full bg-slate-800 border-2 border-white flex items-center justify-center text-[8px] text-white font-bold">3</span>
                    <div className="font-bold text-slate-900">KONTROLA ZGODNOŚCI &amp; PŁYNNOŚCI</div>
                    <div className="text-[10px] text-slate-500 font-mono">Automatyczna weryfikacja AML/KYC i rezerw banku {selectedTx.institution}</div>
                  </div>

                  <div className="relative">
                    <span className="absolute -left-[21px] top-0.5 w-3.5 h-3.5 rounded-full bg-red-600 border-2 border-white flex items-center justify-center text-[8px] text-white font-bold">4</span>
                    <div className="font-bold text-red-600">ROZRACHUNEK RTGS</div>
                    <div className="text-[10px] text-slate-500">Zapis o statusie: <strong className="text-emerald-700 font-bold">{selectedTx.status}</strong></div>
                  </div>
                </div>

                <div className="border-t border-slate-200 pt-3 mt-2 grid grid-cols-2 gap-3 text-[10px]">
                  <div>
                    <div className="text-slate-400 font-bold uppercase">Metoda clearingu</div>
                    <div className="font-mono font-bold text-slate-800">{selectedTx.settlement}</div>
                  </div>
                  <div>
                    <div className="text-slate-400 font-bold uppercase">Hash Audytowy</div>
                    <div className="font-mono font-bold text-slate-800 truncate" title={selectedTx.auditId}>{selectedTx.auditId}</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-200 text-[10px] text-slate-500 leading-relaxed italic flex items-center gap-1">
              <CheckCircle2 size={12} className="text-emerald-600 shrink-0" />
              Zabezpieczone kryptografią kwantowo-odporną (Post-Quantum Cryptography).
            </div>
          </div>
        )}

      </div>

    </div>
  );
};
