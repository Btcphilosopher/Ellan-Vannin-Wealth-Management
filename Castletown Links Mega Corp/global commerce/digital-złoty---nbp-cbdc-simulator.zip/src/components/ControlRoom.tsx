/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { useSimulationStore } from '../simulationStore';
import { NbpCore } from './NbpCore';
import { PolishBanks } from './PolishBanks';
import { DigitalWallet } from './DigitalWallet';
import { UnifiedLedger } from './UnifiedLedger';
import { SandboxLabs } from './SandboxLabs';
import { MapFlows } from './MapFlows';
import { SystemOperations } from './SystemOperations';
import { 
  ShieldAlert, Activity, Landmark, Wallet, Layers, Database, 
  MapPin, HelpCircle, AlertOctagon, Flame, Cpu, Play, Pause, FastForward
} from 'lucide-react';
import { ScenarioType } from '../types';

export const ControlRoom: React.FC = () => {
  const { 
    time, tick, simulationSpeed, setSpeed, selectedScenario, setScenario, 
    transactions, nbpBalanceSheet, failures, resetFailures 
  } = useSimulationStore();

  const [activeWorkspaceTab, setActiveWorkspaceTab] = useState<'CONTROL' | 'NBP' | 'BANKS' | 'WALLET' | 'LEDGER' | 'LABS'>('CONTROL');
  const [isPlaying, setIsPlaying] = useState<boolean>(true);

  // Core ticker loop based on play state and speed
  useEffect(() => {
    let interval: any = null;
    if (isPlaying) {
      // Calculate interval duration: faster speed = shorter interval
      const intervalMs = Math.max(100, 1000 / Math.min(10, simulationSpeed));
      interval = setInterval(() => {
        tick();
      }, intervalMs);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isPlaying, simulationSpeed, tick]);

  // Aggregate stats
  const totalVolumeToday = transactions.reduce((sum, t) => sum + t.amount, 0) + 1_840_000_000_000; // base scale + simulated
  const totalTransactionsCount = transactions.length + 31_800_000;
  
  const formatPLN = (val: number) => {
    if (val >= 1_000_000_000_000) return `${(val / 1_000_000_000_000).toLocaleString('pl-PL', { maximumFractionDigits: 2 })} bln zł`;
    if (val >= 1_000_000_000) return `${(val / 1_000_000_000).toLocaleString('pl-PL', { maximumFractionDigits: 1 })} mld zł`;
    return `${val.toLocaleString('pl-PL')} zł`;
  };

  const getSystemStatus = () => {
    const hasActiveFailure = failures.some(f => f.active);
    if (hasActiveFailure) return { label: 'BŁĘDY OPERACYJNE', color: 'text-yellow-600 bg-yellow-50 border-yellow-200' };
    return { label: 'DZIAŁA PRAWIDŁOWO', color: 'text-emerald-700 bg-emerald-50 border-emerald-200' };
  };

  const status = getSystemStatus();

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans selection:bg-red-200 selection:text-red-900" id="main-control-room">
      
      {/* 1. PERSISTENT INSTITUTIONAL TOP BANNER */}
      <div className="bg-red-700 text-white text-[11px] font-bold py-1.5 px-4 flex flex-col md:flex-row justify-between items-center tracking-wider uppercase border-b border-red-800" id="top-persistent-banner">
        <span>ŚRODOWISKO SYMULACYJNE · DANE SYNTETYCZNE · PROTOTYP BADAWCZY</span>
        <span className="hidden md:inline">SIMULATION ENVIRONMENT · SYNTHETIC DATA · RESEARCH PROTOTYPE</span>
      </div>

      {/* 2. WARSAW FINANCIAL INFRASTRUCTURE SYSTEM HEADER */}
      <header className="bg-slate-900 text-white border-b border-slate-950 px-5 py-4 flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4" id="nbp-system-header">
        <div>
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-red-600 rounded">
              <Landmark size={22} className="text-white" />
            </div>
            <div>
              <h1 className="text-sm font-black tracking-widest text-slate-100">CYFROWY ZŁOTY</h1>
              <p className="text-[10px] text-slate-400 font-bold tracking-widest uppercase">Krajowe Centrum Badawcze Pieniądza Cyfrowego NBP</p>
            </div>
          </div>
        </div>

        {/* Top Operations Panel Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:flex lg:items-center gap-3 md:gap-4 text-[10px] font-mono uppercase text-slate-400">
          <div className="bg-slate-950 p-2 rounded border border-slate-800">
            <div>SYSTEM:</div>
            <strong className="text-emerald-400">{status.label}</strong>
          </div>
          <div className="bg-slate-950 p-2 rounded border border-slate-800">
            <div>NBP NODE:</div>
            <strong className="text-slate-100">AKTYWNY</strong>
          </div>
          <div className="bg-slate-950 p-2 rounded border border-slate-800">
            <div>REJESTR LEDGER:</div>
            <strong className="text-slate-100">ZAKTUALIZOWANY</strong>
          </div>
          <div className="bg-slate-950 p-2 rounded border border-slate-800">
            <div>PŁYNNOŚĆ KRAJOWA:</div>
            <strong className="text-emerald-400">STABILNA</strong>
          </div>
        </div>
      </header>

      {/* 3. SIMULATION CONTROLLER & STATS BOARD */}
      <section className="bg-white border-b border-slate-200 px-5 py-4 grid grid-cols-1 md:grid-cols-12 gap-6 items-center" id="simulation-stats-board">
        
        {/* Playback & Speed Dock */}
        <div className="md:col-span-5 flex flex-wrap items-center gap-4 border-r border-slate-100 pr-4">
          
          {/* Clock */}
          <div className="bg-slate-100 px-3 py-1.5 rounded border border-slate-200 font-mono text-xs text-slate-800">
            <span className="text-[9px] text-slate-400 block font-bold uppercase">Czas Symulacji</span>
            <strong className="text-slate-950 font-extrabold">{time}</strong>
          </div>

          {/* Play / Pause button */}
          <div className="flex items-center space-x-1.5">
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className={`p-2 rounded border transition cursor-pointer ${
                isPlaying ? 'bg-red-700 hover:bg-red-800 text-white border-red-800' : 'bg-slate-100 hover:bg-slate-200 text-slate-800 border-slate-200'
              }`}
              title={isPlaying ? 'Wstrzymaj symulację' : 'Wznów symulację'}
            >
              {isPlaying ? <Pause size={14} /> : <Play size={14} />}
            </button>

            {/* Speeds */}
            <div className="inline-flex bg-slate-100 p-1 rounded border border-slate-200 text-[10px] font-mono">
              {[1, 10, 100, 1000, 10000].map(speed => (
                <button
                  key={speed}
                  onClick={() => setSpeed(speed)}
                  className={`px-2 py-1 rounded font-bold cursor-pointer transition ${
                    simulationSpeed === speed 
                      ? 'bg-slate-800 text-white font-black' 
                      : 'text-slate-500 hover:text-slate-900'
                  }`}
                >
                  {speed}x
                </button>
              ))}
            </div>
          </div>

          {/* Scenario active display */}
          <div className="text-[10px] leading-tight">
            <span className="text-slate-400 uppercase font-bold block">Scenariusz makro</span>
            <strong className="text-red-700 font-extrabold">{selectedScenario}</strong>
          </div>

        </div>

        {/* Core Financial Metrics Rows */}
        <div className="md:col-span-7 grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-mono">
          <div>
            <span className="text-[9px] text-slate-400 uppercase font-bold block">CBDC w Obiegu</span>
            <strong className="text-red-700 text-sm font-black">{formatPLN(nbpBalanceSheet.digitalZloty)}</strong>
          </div>
          <div>
            <span className="text-[9px] text-slate-400 uppercase font-bold block">Transakcje Dzisiaj</span>
            <strong className="text-slate-900 text-sm font-bold">{(totalTransactionsCount / 1_000_000).toFixed(2)} mln</strong>
          </div>
          <div>
            <span className="text-[9px] text-slate-400 uppercase font-bold block">Wartość dzienna</span>
            <strong className="text-slate-900 text-sm font-bold">{formatPLN(totalVolumeToday)}</strong>
          </div>
          <div>
            <span className="text-[9px] text-slate-400 uppercase font-bold block">TPS Średni</span>
            <strong className="text-slate-900 text-sm font-bold">4 812 tps</strong>
          </div>
        </div>

      </section>

      {/* 4. WORKSPACE SELECTOR TABS DOCK */}
      <nav className="bg-slate-100 border-b border-slate-200 px-5 flex overflow-x-auto space-x-1 py-1" id="workspace-navigator">
        {[
          { id: 'CONTROL', label: 'Centrum Operacyjne (Krajowe)', icon: <Activity size={13} /> },
          { id: 'NBP', label: 'Narodowy Bank Polski (Core)', icon: <Landmark size={13} /> },
          { id: 'BANKS', label: 'System Bankowy & EMI', icon: <Layers size={13} /> },
          { id: 'WALLET', label: 'Portfel Klienta (Retail)', icon: <Wallet size={13} /> },
          { id: 'LEDGER', label: 'Eksplorator Rejestru', icon: <Database size={13} /> },
          { id: 'LABS', label: 'Sandbox & Badania', icon: <Cpu size={13} /> }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveWorkspaceTab(tab.id as any)}
            className={`px-4 py-2 text-xs font-bold uppercase flex items-center gap-1.5 border-b-2 transition cursor-pointer ${
              activeWorkspaceTab === tab.id 
                ? 'border-red-700 text-slate-900 bg-white shadow-sm' 
                : 'border-transparent text-slate-500 hover:text-slate-900 hover:border-slate-300'
            }`}
          >
            {tab.icon}
            {tab.label}
          </button>
        ))}
      </nav>

      {/* 5. ACTIVE WORKSPACE CONTAINER */}
      <main className="flex-1 p-5 max-w-7xl mx-auto w-full space-y-6" id="active-work-view">
        
        {activeWorkspaceTab === 'CONTROL' && (
          <div className="space-y-6 animate-fadeIn">
            {/* Visual network flows & merchant data */}
            <MapFlows />
            {/* Cybersecurity and KYC alert systems */}
            <SystemOperations />
          </div>
        )}

        {activeWorkspaceTab === 'NBP' && (
          <div className="animate-fadeIn">
            <NbpCore />
          </div>
        )}

        {activeWorkspaceTab === 'BANKS' && (
          <div className="animate-fadeIn">
            <PolishBanks />
          </div>
        )}

        {activeWorkspaceTab === 'WALLET' && (
          <div className="animate-fadeIn">
            <DigitalWallet />
          </div>
        )}

        {activeWorkspaceTab === 'LEDGER' && (
          <div className="animate-fadeIn">
            <UnifiedLedger />
          </div>
        )}

        {activeWorkspaceTab === 'LABS' && (
          <div className="animate-fadeIn">
            <SandboxLabs />
          </div>
        )}

      </main>

      {/* 6. PERSISTENT POLISH & ENGLISH INSTITUTIONAL FOOTER */}
      <footer className="bg-slate-900 text-slate-400 text-[10px] px-6 py-5 border-t border-slate-950 mt-12 space-y-3" id="bottom-persistent-disclaimer">
        <p className="leading-relaxed text-justify">
          <strong>OŚWIADCZENIE BADAWCZE:</strong> Niniejsza aplikacja jest fikcyjnym prototypem badawczym i edukacyjnym dotyczącym potencjalnej infrastruktury cyfrowego złotego. Nie jest systemem produkcyjnym Narodowego Banku Polskiego i nie jest połączona z rzeczywistą infrastrukturą płatniczą, bankami ani rachunkami klientów. Wszystkie dane, wskaźniki rynkowe, nazwy banków i alerty bezpieczeństwa są całkowicie syntetyczne i determinowane lokalnym silnikiem symulacyjnym.
        </p>
        <p className="leading-relaxed text-justify border-t border-slate-800 pt-2 text-slate-500">
          <strong>RESEARCH DISCLAIMER:</strong> This application is a fictional research and educational prototype concerning potential Digital Złoty infrastructure. It is not a production system of Narodowy Bank Polski and does not connect to real payment infrastructure, banks or customer accounts. All data, market indicators, bank names and security alerts are entirely synthetic and determined by the local simulation engine.
        </p>
      </footer>

    </div>
  );
};
