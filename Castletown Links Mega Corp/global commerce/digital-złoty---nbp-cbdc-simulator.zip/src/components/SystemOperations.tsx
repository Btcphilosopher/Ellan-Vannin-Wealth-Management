/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useSimulationStore } from '../simulationStore';
import { ShieldCheck, Cpu, HardDrive, ShieldAlert, Check, Ban, AlertOctagon, Terminal } from 'lucide-react';

export const SystemOperations: React.FC = () => {
  const { kycAlerts, cyberIncidents, infrastructure, resolveKycAlert, resolveCyberIncident, failures, toggleFailure } = useSimulationStore();

  const formatPLN = (val: number) => {
    return `${val.toLocaleString('pl-PL')} zł`;
  };

  const getAlertStatusColor = (status: string) => {
    switch (status) {
      case 'ZATWIERDZONE':
        return 'text-green-700 bg-green-50 border-green-200';
      case 'ZABLOKOWANE':
        return 'text-red-700 bg-red-50 border-red-200';
      default:
        return 'text-yellow-700 bg-yellow-50 border-yellow-200 animate-pulse';
    }
  };

  const isCyberAttackActive = failures.find(f => f.id === 'fail-cyber')?.active;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="system-operations-section">
      
      {/* Infrastructure Telemetry */}
      <div className="lg:col-span-4 bg-white border border-slate-200 shadow-sm rounded-lg p-5 flex flex-col justify-between" id="infra-telemetry">
        <div>
          <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide flex items-center gap-1.5">
              <Cpu size={16} className="text-red-600" />
              DIAGNOSTYKA INFRASTRUKTURY GŁÓWNEJ
            </h3>
            <span className="inline-flex items-center px-1.5 py-0.2 rounded text-[9px] font-bold bg-green-50 text-green-700 border border-green-200">
              OK
            </span>
          </div>

          <div className="space-y-4 font-mono text-xs">
            {/* CPU */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <span className="text-slate-500 uppercase tracking-wider text-[10px]">Obciążenie procesora (CPU load)</span>
                <span className="font-bold text-slate-900">{infrastructure.cpu}%</span>
              </div>
              <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                <div 
                  className={`h-full transition-all duration-500 ${infrastructure.cpu > 80 ? 'bg-red-600' : 'bg-slate-800'}`} 
                  style={{ width: `${infrastructure.cpu}%` }}
                ></div>
              </div>
            </div>

            {/* MEMORY */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <span className="text-slate-500 uppercase tracking-wider text-[10px]">Użycie pamięci (RAM foot)</span>
                <span className="font-bold text-slate-900">{infrastructure.memory}%</span>
              </div>
              <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                <div className="h-full bg-slate-800 transition-all duration-500" style={{ width: `${infrastructure.memory}%` }}></div>
              </div>
            </div>

            {/* Metrics items */}
            <div className="grid grid-cols-2 gap-4 border-t border-slate-100 pt-3 text-[11px] leading-tight">
              <div>
                <span className="text-[9px] text-slate-400 font-bold uppercase block">API Latency (Intraday)</span>
                <strong className="text-slate-900 text-sm">{infrastructure.apiLatency} ms</strong>
              </div>
              <div>
                <span className="text-[9px] text-slate-400 font-bold uppercase block">Network delay</span>
                <strong className="text-slate-900 text-sm">{infrastructure.networkLatency} ms</strong>
              </div>
              <div>
                <span className="text-[9px] text-slate-400 font-bold uppercase block">Zunifikowany Rejestr</span>
                <strong className="text-slate-900 uppercase">{infrastructure.ledgerSyncStatus}</strong>
              </div>
              <div>
                <span className="text-[9px] text-slate-400 font-bold uppercase block">Współczynnik błędów</span>
                <strong className="text-slate-900 text-sm">{(infrastructure.errorRate * 100).toFixed(2)}%</strong>
              </div>
            </div>
          </div>
        </div>

        {/* Cyber attack trigger */}
        <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between">
          <span className="text-[10px] text-slate-400">Symulator cyberataków:</span>
          <button
            onClick={() => toggleFailure('fail-cyber')}
            className={`text-[10px] font-bold py-1 px-3 rounded transition cursor-pointer ${
              isCyberAttackActive ? 'bg-red-700 text-white hover:bg-red-800' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            {isCyberAttackActive ? 'WYŁĄCZ ATAK DDOS' : 'URUCHOM ATAK DDOS'}
          </button>
        </div>
      </div>

      {/* KYC/AML Compliance Monitoring alerts */}
      <div className="lg:col-span-4 bg-white border border-slate-200 shadow-sm rounded-lg p-5 flex flex-col justify-between" id="compliance-alerts">
        <div>
          <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide flex items-center gap-1.5">
              <ShieldAlert size={16} className="text-red-600" />
              MONITORING TRANSAKCJI &amp; COMPLIANCE (KYC/AML)
            </h3>
            <span className="text-[9px] font-bold bg-slate-100 px-1.5 py-0.5 border border-slate-200 rounded text-slate-600">
              ALERTY BEZPIECZEŃSTWA
            </span>
          </div>

          <div className="space-y-3 max-h-56 overflow-y-auto">
            {kycAlerts.length === 0 ? (
              <p className="text-slate-400 italic text-center py-6 text-xs">Brak aktywnych ostrzeżeń KYC/AML.</p>
            ) : (
              kycAlerts.map(alert => (
                <div key={alert.id} className="border border-slate-200 p-3 rounded bg-slate-50 space-y-2 hover:bg-slate-100/50 transition">
                  <div className="flex justify-between items-center">
                    <span className="font-mono font-bold text-[11px] text-red-600">ALERT #{alert.id}</span>
                    <span className={`px-1.5 py-0.2 rounded text-[9px] font-bold border ${getAlertStatusColor(alert.status)}`}>
                      {alert.status}
                    </span>
                  </div>

                  <div className="text-[11px] text-slate-700 leading-relaxed font-sans">
                    {alert.details}
                  </div>

                  <div className="flex justify-between items-center text-[10px] font-mono border-t border-slate-200/50 pt-2 text-slate-600">
                    <div>Kwota: <strong className="text-slate-900">{formatPLN(alert.amount)}</strong></div>
                    <div>Ryzyko: <strong className={`font-bold ${alert.risk === 'HIGH' ? 'text-red-600' : 'text-slate-700'}`}>{alert.risk}</strong></div>
                  </div>

                  {alert.status === 'WERYFIKACJA' && (
                    <div className="flex gap-1.5 pt-1.5 justify-end">
                      <button
                        onClick={() => resolveKycAlert(alert.id, true)}
                        className="p-1 bg-green-50 hover:bg-green-100 text-green-700 border border-green-200 rounded cursor-pointer"
                        title="Zatwierdź transakcję"
                      >
                        <Check size={12} />
                      </button>
                      <button
                        onClick={() => resolveKycAlert(alert.id, false)}
                        className="p-1 bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 rounded cursor-pointer"
                        title="Zablokuj transakcję"
                      >
                        <Ban size={12} />
                      </button>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </div>

        <div className="text-[9px] text-slate-400 italic leading-relaxed border-t border-slate-100 pt-3 mt-4">
          * Algorytm heurystyczny NBP wykrywa próby strukturyzacji, anomalie obrotów handlowych oraz próby kompromitacji portfeli sprzętowych w czasie rzeczywistym.
        </div>
      </div>

      {/* Cyber Incident logs response */}
      <div className="lg:col-span-4 bg-white border border-slate-200 shadow-sm rounded-lg p-5 flex flex-col justify-between" id="cyber-incidents">
        <div>
          <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide flex items-center gap-1.5">
              <AlertOctagon size={16} className="text-red-600" />
              CYBER-BEZPIECZEŃSTWO &amp; INCYDENTY
            </h3>
            <span className="text-[9px] font-bold text-red-700 bg-red-50 px-1.5 py-0.5 border border-red-200 rounded">
              ZAGROŻENIA PL
            </span>
          </div>

          <div className="space-y-3 max-h-56 overflow-y-auto">
            {cyberIncidents.length === 0 ? (
              <p className="text-slate-400 italic text-center py-6 text-xs">Brak zarejestrowanych incydentów bezpieczeństwa.</p>
            ) : (
              cyberIncidents.map(inc => (
                <div key={inc.id} className="border border-red-200 p-3 rounded bg-red-50/20 space-y-2 hover:bg-slate-100/50 transition">
                  <div className="flex justify-between items-center text-[10px] font-mono">
                    <span className="font-bold text-red-700">INCYDENT #{inc.id}</span>
                    <span className={`px-1.5 py-0.2 rounded font-bold text-[9px] ${inc.status === 'OPANOWANO' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800 animate-pulse'}`}>
                      {inc.status}
                    </span>
                  </div>

                  <div className="text-[11px] text-slate-700 font-sans leading-relaxed">
                    Wykryto nietypowy napływ pakietów i próby zapytań API na węźle: <strong className="text-slate-900">{inc.bank}</strong>. 
                  </div>

                  {inc.amount > 0 && (
                    <div className="text-[10px] font-mono text-slate-600">
                      Wartość anomali: <strong className="text-slate-900">{formatPLN(inc.amount)}</strong>
                    </div>
                  )}

                  {inc.status === 'ANALIZA' && (
                    <div className="flex justify-end pt-1">
                      <button
                        onClick={() => resolveCyberIncident(inc.id)}
                        className="bg-red-700 hover:bg-red-800 text-white font-bold text-[10px] py-1 px-3 rounded transition cursor-pointer"
                      >
                        Wdróż kwarantannę sieciową
                      </button>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </div>

        <div className="text-[9px] text-slate-400 italic leading-relaxed border-t border-slate-100 pt-3 mt-4">
          * Krajowy protokół bezpieczeństwa (Krajowe Cyber Centrum CBDC) izoluje podejrzane węzły bez uszczerbku dla rozliczeń pozostałych uczestników.
        </div>
      </div>

    </div>
  );
};
