/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useSimulationStore } from '../simulationStore';
import { Wallet as WalletIcon, Send, QrCode, Smartphone, WifiOff, RefreshCw, UserCheck, CheckCircle2, AlertCircle } from 'lucide-react';
import { Transaction } from '../types';

export const DigitalWallet: React.FC = () => {
  const { wallet, executeWalletTransaction, syncOfflineBalance, transactions, merchants, banks, failures } = useSimulationStore();
  
  const [activeTab, setActiveTab] = useState<'SEND' | 'PAY' | 'REQUEST' | 'SETTINGS'>('SEND');
  
  // Send parameters
  const [sendAmount, setSendAmount] = useState<string>('120.00');
  const [recipient, setRecipient] = useState<string>('Zielony Market Spożywczy');
  const [channel, setChannel] = useState<'QR' | 'NFC' | 'Instant' | 'Offline'>('Instant');
  
  // UI messages
  const [txSuccess, setTxSuccess] = useState<boolean | null>(null);
  const [errMsg, setErrMsg] = useState<string | null>(null);

  // Settings parameters
  const [walletLimit, setWalletLimit] = useState<string>(wallet.dailyLimit.toString());
  const [currentBank, setCurrentBank] = useState<string>(wallet.intermediaryBank);

  const formatPLN = (val: number) => {
    return `${val.toLocaleString('pl-PL', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} zł`;
  };

  const handleSendSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setTxSuccess(null);
    setErrMsg(null);

    const amt = parseFloat(sendAmount);
    if (isNaN(amt) || amt <= 0) {
      setErrMsg('Wprowadź prawidłową kwotę.');
      return;
    }

    if (channel === 'Offline' && wallet.offline < amt) {
      setErrMsg('Niewystarczające saldo Offline w bezpiecznym elemencie (Secure Element).');
      return;
    }

    if (channel !== 'Offline' && wallet.available < amt) {
      setErrMsg('Niewystarczające saldo online.');
      return;
    }

    if (wallet.dailySpent + amt > wallet.dailyLimit) {
      setErrMsg('Przekroczono dzienny limit transakcyjny.');
      return;
    }

    // Check failures
    const networkFail = failures.find(f => f.id === 'fail-network')?.active;
    const bankFail = failures.find(f => f.id === 'fail-bank')?.active;

    if (channel !== 'Offline' && networkFail) {
      setErrMsg('Brak połączenia z siecią krajową. Przełącz transakcję w tryb Offline.');
      return;
    }

    if (bankFail && wallet.intermediaryBank === 'Bank Mazowiecki' && channel !== 'Offline') {
      setErrMsg('Twój bank pośredniczący (Bank Mazowiecki) jest offline. Transakcja odrzucona przez bramkę RTGS.');
      return;
    }

    // Execute
    const type = channel === 'Offline' ? 'Bony' : 'P2M'; // map to types
    const ok = executeWalletTransaction(type, amt, recipient, channel);
    
    if (ok) {
      setTxSuccess(true);
      setSendAmount('120.00');
    } else {
      setErrMsg('Transakcja została odrzucona przez silnik walidacyjny (KYC/AML lub brak pokrycia).');
    }
  };

  // Filter transactions for Anna Kowalska
  const myTxs = transactions.filter(t => t.sender === 'ANNA KOWALSKA' || t.receiver === 'ANNA KOWALSKA');

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="digital-wallet-section">
      
      {/* Wallet Pass / Card Panel */}
      <div className="lg:col-span-5 bg-gradient-to-br from-slate-900 to-slate-800 text-white border border-slate-950 shadow-md rounded-xl p-5 flex flex-col justify-between" id="wallet-card-panel">
        <div>
          {/* Header */}
          <div className="flex justify-between items-start mb-6">
            <div className="flex items-center space-x-2">
              <div className="p-1.5 bg-red-600 rounded">
                <WalletIcon size={16} />
              </div>
              <div>
                <h3 className="text-xs font-bold tracking-widest uppercase">CYFROWY ZŁOTY</h3>
                <p className="text-[9px] text-slate-400 uppercase tracking-widest">NBP PORTFEL RETALNY</p>
              </div>
            </div>
            <span className="text-[10px] font-mono font-bold text-emerald-400 bg-emerald-950/50 border border-emerald-800/60 px-2 py-0.5 rounded flex items-center gap-1">
              <UserCheck size={10} />
              TOŻSAMOŚĆ POTWIERDZONA
            </span>
          </div>

          {/* Balance Metrics */}
          <div className="space-y-4">
            <div>
              <div className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">ŁĄCZNE SALDO PORTFELA</div>
              <div className="text-2xl font-mono font-black text-white">{formatPLN(wallet.balance)}</div>
            </div>

            <div className="grid grid-cols-2 gap-4 border-t border-slate-700/50 pt-3">
              <div>
                <div className="text-[9px] text-slate-400 uppercase font-bold tracking-wider">Dostępne Online</div>
                <div className="text-sm font-mono font-bold text-slate-200">{formatPLN(wallet.available)}</div>
              </div>
              <div className="bg-slate-800/80 p-2 rounded border border-slate-700/50">
                <div className="text-[9px] text-red-400 uppercase font-bold tracking-wider flex items-center gap-1">
                  <WifiOff size={10} />
                  Offline (Chip/NFC)
                </div>
                <div className="text-sm font-mono font-bold text-red-100">{formatPLN(wallet.offline)}</div>
              </div>
            </div>
          </div>
        </div>

        {/* Intermediary Bank & Action Bar */}
        <div className="mt-8 pt-4 border-t border-slate-800 flex justify-between items-center text-[11px] text-slate-400">
          <div>
            <div>Pośrednik operacyjny:</div>
            <strong className="text-slate-200">{wallet.intermediaryBank}</strong>
          </div>
          <div>
            <button
              onClick={syncOfflineBalance}
              disabled={wallet.offline === 0}
              className={`px-3 py-1.5 rounded text-xs font-bold flex items-center gap-1 transition ${
                wallet.offline > 0 
                  ? 'bg-red-700 hover:bg-red-800 text-white cursor-pointer' 
                  : 'bg-slate-800 text-slate-500 cursor-not-allowed'
              }`}
            >
              <RefreshCw size={12} />
              Sync Offline
            </button>
          </div>
        </div>
      </div>

      {/* Transaction & Operations Form Panel */}
      <div className="lg:col-span-7 bg-white border border-slate-200 shadow-sm rounded-lg p-5 flex flex-col justify-between" id="wallet-operations-tabs">
        <div>
          {/* Navigation Tabs */}
          <div className="flex space-x-1 border-b border-slate-100 pb-3 mb-4">
            <button
              onClick={() => { setActiveTab('SEND'); setTxSuccess(null); setErrMsg(null); }}
              className={`px-3 py-1 text-xs font-bold uppercase rounded cursor-pointer ${activeTab === 'SEND' ? 'bg-red-50 text-red-700 border border-red-200' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'}`}
            >
              Wyślij / Zapłać
            </button>
            <button
              onClick={() => { setActiveTab('PAY'); setTxSuccess(null); setErrMsg(null); }}
              className={`px-3 py-1 text-xs font-bold uppercase rounded cursor-pointer ${activeTab === 'PAY' ? 'bg-red-50 text-red-700 border border-red-200' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'}`}
            >
              Skanuj QR
            </button>
            <button
              onClick={() => { setActiveTab('REQUEST'); setTxSuccess(null); setErrMsg(null); }}
              className={`px-3 py-1 text-xs font-bold uppercase rounded cursor-pointer ${activeTab === 'REQUEST' ? 'bg-red-50 text-red-700 border border-red-200' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'}`}
            >
              Poproś o płatność
            </button>
            <button
              onClick={() => { setActiveTab('SETTINGS'); setTxSuccess(null); setErrMsg(null); }}
              className={`px-3 py-1 text-xs font-bold uppercase rounded cursor-pointer ${activeTab === 'SETTINGS' ? 'bg-red-50 text-red-700 border border-red-200' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'}`}
            >
              Ustawienia portfela
            </button>
          </div>

          {/* TAB CONTENT: SEND / PAY */}
          {activeTab === 'SEND' && (
            <form onSubmit={handleSendSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-1 uppercase">Odbiorca transakcji</label>
                  <select
                    value={recipient}
                    onChange={(e) => setRecipient(e.target.value)}
                    className="w-full text-xs p-2 border border-slate-200 rounded focus:outline-none bg-slate-50"
                  >
                    {merchants.map(m => (
                      <option key={m.id} value={m.name}>{m.name}</option>
                    ))}
                    <option value="Jan Kowalski">Jan Kowalski (P2P Private)</option>
                    <option value="Skarb Państwa - Podatki">Krajowa Administracja Skarbowa (Gov)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-1 uppercase">Kwota (PLN)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={sendAmount}
                    onChange={(e) => setSendAmount(e.target.value)}
                    className="w-full text-xs p-2 border border-slate-200 rounded font-mono focus:outline-none bg-slate-50"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-500 mb-1 uppercase">Kanał transferu</label>
                <div className="grid grid-cols-4 gap-2">
                  {[
                    { id: 'Instant', label: 'Błyskawiczny', desc: 'Bramka NBP' },
                    { id: 'QR', label: 'Kod QR', desc: 'Skanowanie' },
                    { id: 'NFC', label: 'Zliżeniowo NFC', desc: 'Terminale' },
                    { id: 'Offline', label: 'Płatność Offline', desc: 'Hardware-to-Hard' }
                  ].map(ch => (
                    <button
                      key={ch.id}
                      type="button"
                      onClick={() => setChannel(ch.id as any)}
                      className={`p-2 border rounded text-left transition cursor-pointer ${
                        channel === ch.id 
                          ? 'border-red-600 bg-red-50/50' 
                          : 'border-slate-200 bg-white hover:bg-slate-50'
                      }`}
                    >
                      <div className="font-bold text-[11px] text-slate-900">{ch.label}</div>
                      <div className="text-[9px] text-slate-400">{ch.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Status responses */}
              {txSuccess && (
                <div className="bg-green-50 border border-green-200 text-green-800 p-2.5 rounded text-xs flex items-center gap-2">
                  <CheckCircle2 size={16} className="text-green-600" />
                  <div>
                    <span className="font-bold">TRANSKACJA ZREALIZOWANA POMYŚLNIE.</span> Środki zostały zaksięgowane w rejestrze cyfrowego złotego w trybie natychmiastowym.
                  </div>
                </div>
              )}

              {errMsg && (
                <div className="bg-red-50 border border-red-200 text-red-800 p-2.5 rounded text-xs flex items-center gap-2">
                  <AlertCircle size={16} className="text-red-600" />
                  <div>
                    <span className="font-bold">BŁĄD SYSTEMU ROZRACHUNKOWEGO:</span> {errMsg}
                  </div>
                </div>
              )}

              <div className="flex justify-between items-center text-xs text-slate-500">
                <span>Dzienny limit: <strong className="text-slate-800 font-mono">{(wallet.dailySpent).toFixed(2)} / {wallet.dailyLimit.toLocaleString('pl-PL')} zł</strong></span>
                <button
                  type="submit"
                  className="bg-red-700 hover:bg-red-800 text-white font-bold py-1.5 px-4 rounded shadow-sm flex items-center gap-1.5 transition cursor-pointer"
                >
                  <Send size={14} />
                  AUTORYZUJ I WYŚLIJ
                </button>
              </div>
            </form>
          )}

          {/* TAB CONTENT: PAY QR */}
          {activeTab === 'PAY' && (
            <div className="text-center py-4 space-y-4">
              <div className="mx-auto w-32 h-32 bg-slate-100 border-2 border-slate-300 rounded flex items-center justify-center">
                <QrCode size={96} className="text-slate-800" />
              </div>
              <p className="text-xs text-slate-600 max-w-sm mx-auto leading-relaxed">
                Skieruj aparat urządzenia na kod QR sprzedawcy. Terminal wygeneruje automatycznie bezpieczne zapytanie o autoryzację do Twojego portfela w standardzie ISO 20022.
              </p>
              <button
                onClick={() => {
                  executeWalletTransaction('QR', 18.50, 'Zielony Market Spożywczy', 'QR');
                  setTxSuccess(true);
                }}
                className="bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold py-1.5 px-4 rounded shadow-sm transition cursor-pointer"
              >
                Zasymuluj Zeskanowanie (18,50 zł)
              </button>
            </div>
          )}

          {/* TAB CONTENT: REQUEST */}
          {activeTab === 'REQUEST' && (
            <div className="text-center py-4 space-y-4">
              <div className="mx-auto w-32 h-32 bg-slate-100 border-2 border-slate-300 rounded p-2 flex items-center justify-center">
                <Smartphone size={96} className="text-slate-800" />
              </div>
              <p className="text-xs text-slate-600 max-w-sm mx-auto leading-relaxed">
                Przedstaw ten kod płatnikowi. Transakcja zostanie skierowana bezpośrednio na Twój portfel powiązany z tożsamością eDO App / cyfrowym ID.
              </p>
              <div className="bg-slate-50 border border-slate-200 p-2.5 rounded font-mono text-[11px] text-slate-700 inline-block">
                pln-cbdc:request?address=anna_kowalska_nbp&amp;amount=0.00
              </div>
            </div>
          )}

          {/* TAB CONTENT: SETTINGS */}
          {activeTab === 'SETTINGS' && (
            <div className="space-y-4 text-xs text-slate-700">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-1 uppercase">Dzienny limit wydatków (PLN)</label>
                  <input
                    type="number"
                    value={walletLimit}
                    onChange={(e) => setWalletLimit(e.target.value)}
                    className="w-full text-xs p-2 border border-slate-200 rounded font-mono bg-slate-50"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-1 uppercase">Zmień Pośrednika (Intermediary Bank)</label>
                  <select
                    value={currentBank}
                    onChange={(e) => {
                      setCurrentBank(e.target.value);
                      useSimulationStore.setState(state => ({
                        wallet: { ...state.wallet, intermediaryBank: e.target.value }
                      }));
                    }}
                    className="w-full text-xs p-2 border border-slate-200 rounded bg-slate-50"
                  >
                    {banks.map(b => (
                      <option key={b.id} value={b.name}>{b.name}</option>
                    ))}
                  </select>
                </div>
              </div>
              <p className="text-[10px] text-slate-500 leading-relaxed italic">
                * Zmiana banku pośredniczącego przenosi Twoje klucze operacyjne i salda rezerwowe na inne konto powiernicze u nowego pośrednika w rejestrze centralnym NBP. Wszystkie środki pozostają bezpośrednim zobowiązaniem banku centralnego.
              </p>
            </div>
          )}
        </div>

        {/* History Log Specific for Anna Kowalska */}
        <div className="border-t border-slate-100 pt-4 mt-4">
          <div className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2">Moja Historia Transakcji</div>
          <div className="max-h-24 overflow-y-auto space-y-1 text-[11px]">
            {myTxs.length === 0 ? (
              <p className="text-slate-400 italic text-center py-2">Brak transakcji z tego portfela w dzisiejszej sesji.</p>
            ) : (
              myTxs.map(t => (
                <div key={t.id} className="flex justify-between items-center p-1.5 border border-slate-100 rounded hover:bg-slate-50">
                  <span className="font-mono text-slate-400">{t.id}</span>
                  <span className="text-slate-600">{t.receiver}</span>
                  <span className="font-mono font-bold text-red-600">-{t.amount.toLocaleString('pl-PL', { minimumFractionDigits: 2 })} zł</span>
                  <span className="text-[9px] bg-slate-100 px-1 py-0.2 text-slate-500 rounded">{t.settlement}</span>
                </div>
              ))
            )}
          </div>
        </div>

      </div>

    </div>
  );
};
