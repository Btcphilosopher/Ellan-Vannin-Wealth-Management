/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ControlRoom } from './components/ControlRoom';

export default function App() {
  return <ControlRoom />;
}

