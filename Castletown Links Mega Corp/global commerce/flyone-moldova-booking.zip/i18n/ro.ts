export const ro = {
  // Navigation & Header
  nav: {
    flights: 'Zboruri',
    destinations: 'Destinații',
    baggage: 'Bagaje',
    checkin: 'Check-in',
    myBooking: 'Rezervarea mea',
    account: 'Cont',
    brand: 'FLYONE',
    subBrand: 'MOLDOVA'
  },

  // Homepage Hero
  hero: {
    title: 'Zboară mai departe.',
    subtitle: 'Descoperă Europa din Chișinău.'
  },

  // Flight Search Form
  search: {
    roundTrip: 'Dus-întors',
    oneWay: 'Dus',
    from: 'De la',
    to: 'Către',
    selectOrigin: 'Selectați originea',
    selectDestination: 'Selectați destinația',
    departureDate: 'Plecare',
    returnDate: 'Întoarcere',
    passengers: 'Pasageri',
    adults: 'Adulți',
    children: 'Copii',
    infants: 'Bebeluși',
    adultsDesc: 'Peste 12 ani',
    childrenDesc: '2-11 ani',
    infantsDesc: 'Sub 2 ani',
    searchBtn: 'Caută zboruri',
    placeholderAirport: 'Căutați aeroport sau oraș',
    validation: {
      destinationRequired: 'Destinația este obligatorie',
      departureDateRequired: 'Data de plecare este obligatorie',
      returnDateRequired: 'Data de întoarcere este obligatorie pentru zborurile dus-întors',
      returnBeforeDeparture: 'Data de întoarcere nu poate fi înainte de data plecării',
      atLeastOneAdult: 'Trebuie să fie cel puțin 1 adult'
    }
  },

  // Flight Results
  results: {
    availableFlights: 'Zboruri disponibile',
    outbound: 'Zbor de plecare',
    return: 'Zbor de întoarcere',
    direct: 'Zbor direct',
    fromPrice: 'de la',
    chooseBtn: 'Alege',
    selectedBtn: 'Selectat',
    filters: {
      title: 'Filtre',
      departure: 'Plecare',
      arrival: 'Sosire',
      duration: 'Durata',
      price: 'Preț maxim',
      directOnly: 'Doar zbor direct'
    },
    sorting: {
      recommended: 'Recomandate',
      cheapest: 'Cel mai ieftin',
      fastest: 'Cel mai rapid'
    },
    noFlights: 'Nu am găsit zboruri pentru această combinație de date.',
    tryOtherDates: 'Încercați o altă dată sau destinație.'
  },

  // Fare Selection
  fares: {
    title: 'Alegeți tariful',
    basic: {
      name: 'BASIC',
      features: [
        'Bagaj personal de mână (40x30x20 cm)',
        'Loc standard contra cost',
        'Modificări zbor contra cost'
      ]
    },
    standard: {
      name: 'STANDARD',
      features: [
        'Bagaj personal de mână (40x30x20 cm)',
        'Bagaj de cabină (50x40x25 cm, 10 kg)',
        'Selectare standard gratuită a locului',
        'Modificare zbor permisă cu taxă redusă'
      ]
    },
    premium: {
      name: 'PREMIUM',
      features: [
        'Bagaj personal de mână (40x30x20 cm)',
        'Bagaj de cabină (50x40x25 cm, 10 kg)',
        'Bagaj de cală (până la 20 kg)',
        'Selectare orice loc (inclusiv extra legroom)',
        'Modificări flexibile gratuite',
        'Prioritate la îmbarcare inclusă'
      ]
    }
  },

  // Passengers Form
  passengersForm: {
    title: 'Datele pasagerilor',
    subtitle: 'Vă rugăm să introduceți datele exact cum apar în documentul de călătorie.',
    passengerIndex: 'Pasager {index}',
    firstName: 'Prenume',
    lastName: 'Nume de familie',
    birthDate: 'Data nașterii',
    nationality: 'Naționalitate',
    docType: 'Document de călătorie',
    docNumber: 'Număr document',
    docExpiry: 'Data expirării documentului',
    gender: 'Sex',
    genderMale: 'Masculin',
    genderFemale: 'Feminin',
    passport: 'Pașaport',
    idCard: 'Carte de identitate',
    contactTitle: 'Informații de contact',
    email: 'Adresă de email',
    phone: 'Număr de telefon',
    disclaimer: 'DEMO — Datele introduse sunt utilizate numai pentru simularea rezervării.',
    continue: 'Continuă spre bagaje',
    validation: {
      required: 'Acest câmp este obligatoriu',
      emailInvalid: 'Adresa de email este invalidă',
      phoneInvalid: 'Numărul de telefon este invalid'
    }
  },

  // Baggage Page
  baggagePage: {
    title: 'Personalizați bagajele',
    subtitle: 'Adăugați bagaje suplimentare pentru fiecare pasager pentru a economisi până la 50% față de taxele din aeroport.',
    personalBag: 'Bagaj personal',
    personalBagDesc: 'Inclus (rucsac sau geantă mică, se plasează sub scaunul din față)',
    cabinBag: 'Bagaj de cabină (10kg)',
    cabinBagDesc: 'Se plasează în compartimentul de deasupra capului',
    checkedBag20: 'Bagaj de cală (20kg)',
    checkedBag20Desc: 'Predat la ghișeul de check-in',
    checkedBag32: 'Bagaj de cală (32kg)',
    checkedBag32Desc: 'Greutate maximă pentru articole grele',
    included: 'Inclus',
    addBtn: 'Adaugă',
    removeBtn: 'Elimină',
    continue: 'Continuă spre selectarea locurilor'
  },

  // Seats Page
  seatsPage: {
    title: 'Alegeți locurile în avion',
    subtitle: 'Asigurați-vă că stați împreună și alegeți locurile preferate în cabină.',
    legend: {
      available: 'Disponibil',
      selected: 'Locul tău',
      occupied: 'Ocupat',
      extraLegroom: 'Spațiu extra',
      premium: 'Premium frontal'
    },
    extraLegroomLabel: 'Spațiu suplimentar picioare',
    premiumLabel: 'Premium frontal',
    standardLabel: 'Standard',
    seatRow: 'Rândul {row}',
    selectedSeat: 'Locul {seat}',
    noSeat: 'Fără loc selectat',
    continue: 'Continuă spre extras și plată'
  },

  // Extras Page
  extrasPage: {
    title: 'Servicii suplimentare',
    subtitle: 'Adăugați servicii premium pentru un zbor și mai confortabil.',
    priority: {
      name: 'Prioritate la îmbarcare',
      desc: 'Fii printre primii care urcă la bord și securizează spațiul pentru bagajul de mână.'
    },
    assistance: {
      name: 'Asistență aeroport',
      desc: 'Suport dedicat la check-in, control de securitate și îmbarcare pentru persoanele care au nevoie.'
    },
    smsNotification: {
      name: 'Notificări SMS în timp real',
      desc: 'Primești instant actualizări despre starea zborului tău direct pe telefon.'
    },
    continue: 'Continuă spre plată'
  },

  // Price Summary
  summary: {
    title: 'Rezumat rezervare',
    flight: 'Zbor',
    outbound: 'Plecare',
    return: 'Întoarcere',
    passengers: 'Pasageri',
    fare: 'Tarif de bază',
    baggage: 'Bagaje suplimentare',
    seats: 'Locuri selectate',
    extras: 'Servicii suplimentare',
    taxes: 'Taxe de aeroport',
    total: 'TOTAL',
    demoNotice: 'Aceasta este o simulare. Nu se va efectua nicio tranzacție reală.',
    payBtn: 'Plătește în siguranță'
  },

  // Checkout Page
  checkout: {
    title: 'Finalizare rezervare',
    subtitle: 'Verificați datele rezervării și introduceți detaliile de plată pentru a emite biletul.',
    reviewTitle: 'Verificare rezervare',
    paymentTitle: 'Metodă de plată',
    cardPayment: 'Card bancar (Visa / Mastercard)',
    cardNumber: 'Număr card',
    cardExpiry: 'Data expirării (LL/AA)',
    cardCvv: 'CVV',
    cardHolder: 'Nume titular card',
    demoDisclaimer: 'Plata este complet simulată. Nu introduceți datele unui card real. Utilizați numere fictive pentru test.',
    processing: 'Se procesează plata securizată...',
    paymentSuccess: 'Plată efectuată cu succes!',
    validation: {
      cardNumber: 'Număr card invalid (16 cifre)',
      expiry: 'Dată expirare invalidă (LL/AA)',
      cvv: 'CVV invalid (3 cifre)',
      holder: 'Numele titularului este obligatoriu'
    }
  },

  // Confirmation Page
  confirmation: {
    success: 'Rezervare confirmată!',
    subtitle: 'Vă mulțumim că ați ales FLYONE Moldova. Detaliile biletului dvs. au fost trimise pe email.',
    refCode: 'Cod rezervare',
    flightDetails: 'Detalii zbor',
    passengerDetails: 'Pasageri',
    actions: {
      title: 'Acțiuni rapide',
      view: 'Vezi rezervarea mea',
      download: 'Descarcă confirmarea (PDF)',
      email: 'Trimite din nou pe email',
      home: 'Înapoi la pagina principală'
    },
    simulatedAction: 'Acțiune simulată cu succes!'
  },

  // My Booking Page
  myBooking: {
    title: 'Gestionarea rezervării',
    subtitle: 'Modificați zborul, adăugați bagaje, selectați locuri sau efectuați check-in-ul online.',
    searchTitle: 'Găsește rezervarea',
    refCode: 'Cod rezervare (e.g. FO8K2M)',
    lastName: 'Nume de familie pasager',
    searchBtn: 'Caută rezervare',
    notFound: 'Nu am găsit nicio rezervare cu aceste detalii.',
    status: 'Statut',
    statusConfirmed: 'CONFIRMATĂ',
    aircraft: 'Aeronave',
    actions: {
      changeFlight: 'Modifică zborul',
      addBaggage: 'Adaugă bagaj',
      chooseSeats: 'Alege loc',
      checkIn: 'Check-in online',
      downloadDocs: 'Descarcă documentele',
      simulatedSuccess: 'Simularea serviciului "{service}" a fost efectuată cu succes!'
    }
  },

  // Check-In Page
  checkinPage: {
    title: 'Check-In Online',
    subtitle: 'Check-in online este disponibil cu 24 ore înainte de decolare. Obțineți permisul de îmbarcare instant.',
    searchTitle: 'Inițiază check-in',
    startBtn: 'Începe check-in-ul',
    alreadyDone: 'Check-in finalizat cu succes! Permisul de îmbarcare a fost generat.',
    downloadBoardingPass: 'Descarcă permis de îmbarcare (Demo)',
    statusReady: 'Pregătit de check-in'
  },

  // Destinations Page
  destinationsPage: {
    title: 'Destinațiile noastre',
    subtitle: 'Zburăm către cele mai populare orașe din Europa. Alege-ți următoarea aventură cu FLYONE.',
    searchPlaceholder: 'Căutați o destinație...',
    bookNow: 'Rezervă de la {price}',
    moldovaTitle: 'Chișinău - Inima Moldovei',
    moldovaDesc: 'Punctul central de plecare pentru toate zborurile FLYONE Moldova.'
  },

  // Baggage Guide Page
  baggageGuide: {
    title: 'Reguli de bagaje FLYONE',
    subtitle: 'Tot ce trebuie să știți despre dimensiunile și greutățile admise pe zborurile noastre.',
    personal: {
      title: 'Bagaj personal de mână',
      desc: 'Fiecare pasager are dreptul la un singur bagaj personal gratuit. Trebuie să încapă sub scaunul din față.',
      dims: 'Dimensiuni max: 40 x 30 x 20 cm',
      weight: 'Greutate: Fără limită (dar rezonabil)'
    },
    cabin: {
      title: 'Bagaj de cabină de 10 kg',
      desc: 'Opțiune contra cost sau inclusă în tarifele Standard/Premium. Se plasează în compartimentul de sus.',
      dims: 'Dimensiuni max: 50 x 40 x 25 cm',
      weight: 'Greutate max: 10 kg'
    },
    checked: {
      title: 'Bagaj de cală înregistrat',
      desc: 'Se predă la ghișeul de drop-off din aeroport înainte de controlul de securitate.',
      dims: 'Suma dimensiunilor max: 158 cm',
      weight: 'Greutate: 20 kg sau 32 kg'
    },
    prohibited: {
      title: 'Articole interzise',
      desc: 'Este strict interzis transportul de substanțe inflamabile, arme, baterii de litiu neprotejate sau alte materiale periculoase.'
    }
  }
};
