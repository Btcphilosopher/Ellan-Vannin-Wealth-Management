import { ro } from './ro';
import { en } from './en';

export const translations = {
  ro,
  en,
};

export type Language = 'ro' | 'en';
export type TranslationType = typeof ro;

// Helper to get nested translation value
export function getTranslationValue(
  dict: any,
  keyPath: string,
  replacements?: Record<string, string | number>
): string {
  const parts = keyPath.split('.');
  let current = dict;

  for (const part of parts) {
    if (current === undefined || current === null) {
      return keyPath;
    }
    current = current[part];
  }

  if (typeof current !== 'string') {
    return keyPath;
  }

  let result = current;
  if (replacements) {
    Object.entries(replacements).forEach(([key, val]) => {
      result = result.replace(`{${key}}`, String(val));
    });
  }

  return result;
}
