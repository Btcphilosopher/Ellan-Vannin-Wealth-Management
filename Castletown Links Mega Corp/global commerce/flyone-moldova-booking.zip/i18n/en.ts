export const en = {
  // Navigation & Header
  nav: {
    flights: 'Flights',
    destinations: 'Destinations',
    baggage: 'Baggage',
    checkin: 'Check-in',
    myBooking: 'My Booking',
    account: 'Account',
    brand: 'FLYONE',
    subBrand: 'MOLDOVA'
  },

  // Homepage Hero
  hero: {
    title: 'Fly further.',
    subtitle: 'Discover Europe from Chișinău.'
  },

  // Flight Search Form
  search: {
    roundTrip: 'Round-Trip',
    oneWay: 'One-Way',
    from: 'From',
    to: 'To',
    selectOrigin: 'Select origin',
    selectDestination: 'Select destination',
    departureDate: 'Departure',
    returnDate: 'Return',
    passengers: 'Passengers',
    adults: 'Adults',
    children: 'Children',
    infants: 'Infants',
    adultsDesc: 'Over 12 years',
    childrenDesc: '2-11 years',
    infantsDesc: 'Under 2 years',
    searchBtn: 'Search Flights',
    placeholderAirport: 'Search airport or city',
    validation: {
      destinationRequired: 'Destination is required',
      departureDateRequired: 'Departure date is required',
      returnDateRequired: 'Return date is required for round-trips',
      returnBeforeDeparture: 'Return date cannot precede departure date',
      atLeastOneAdult: 'At least 1 adult is required'
    }
  },

  // Flight Results
  results: {
    availableFlights: 'Available Flights',
    outbound: 'Outbound Flight',
    return: 'Return Flight',
    direct: 'Direct flight',
    fromPrice: 'from',
    chooseBtn: 'Choose',
    selectedBtn: 'Selected',
    filters: {
      title: 'Filters',
      departure: 'Departure',
      arrival: 'Arrival',
      duration: 'Duration',
      price: 'Max Price',
      directOnly: 'Direct only'
    },
    sorting: {
      recommended: 'Recommended',
      cheapest: 'Cheapest',
      fastest: 'Fastest'
    },
    noFlights: 'No flights found for this date combination.',
    tryOtherDates: 'Try other dates or destinations.'
  },

  // Fare Selection
  fares: {
    title: 'Choose your fare',
    basic: {
      name: 'BASIC',
      features: [
        'Personal hand bag (40x30x20 cm) included',
        'Standard seat selection for a fee',
        'Flight changes for a fee'
      ]
    },
    standard: {
      name: 'STANDARD',
      features: [
        'Personal hand bag (40x30x20 cm) included',
        'Cabin bag (50x40x25 cm, 10 kg) included',
        'Free standard seat selection',
        'Flight changes with reduced fee'
      ]
    },
    premium: {
      name: 'PREMIUM',
      features: [
        'Personal hand bag (40x30x20 cm) included',
        'Cabin bag (50x40x25 cm, 10 kg) included',
        'Checked baggage up to 20 kg included',
        'Free seat selection (including extra legroom)',
        'Free flexible flight changes',
        'Priority boarding included'
      ]
    }
  },

  // Passengers Form
  passengersForm: {
    title: 'Passenger Details',
    subtitle: 'Please enter passenger details exactly as they appear on your travel document.',
    passengerIndex: 'Passenger {index}',
    firstName: 'First Name',
    lastName: 'Last Name',
    birthDate: 'Date of Birth',
    nationality: 'Nationality',
    docType: 'Travel Document',
    docNumber: 'Document Number',
    docExpiry: 'Document Expiration Date',
    gender: 'Gender',
    genderMale: 'Male',
    genderFemale: 'Female',
    passport: 'Passport',
    idCard: 'ID Card',
    contactTitle: 'Contact Information',
    email: 'Email Address',
    phone: 'Phone Number',
    disclaimer: 'DEMO — The entered details are only used for simulation purposes.',
    continue: 'Continue to Baggage',
    validation: {
      required: 'This field is required',
      emailInvalid: 'Email address is invalid',
      phoneInvalid: 'Phone number is invalid'
    }
  },

  // Baggage Page
  baggagePage: {
    title: 'Customize Baggage',
    subtitle: 'Add extra baggage for each passenger to save up to 50% compared to airport check-in rates.',
    personalBag: 'Personal Bag',
    personalBagDesc: 'Included (backpack or small handbag, fits under the seat in front of you)',
    cabinBag: 'Cabin Bag (10kg)',
    cabinBagDesc: 'Fits in the overhead compartment',
    checkedBag20: 'Checked Bag (20kg)',
    checkedBag20Desc: 'Dropped off at the airport check-in counter',
    checkedBag32: 'Checked Bag (32kg)',
    checkedBag32Desc: 'Maximum weight for heavy luggage items',
    included: 'Included',
    addBtn: 'Add',
    removeBtn: 'Remove',
    continue: 'Continue to Seats'
  },

  // Seats Page
  seatsPage: {
    title: 'Select Seats',
    subtitle: 'Ensure you sit together and choose your preferred cabin seats.',
    legend: {
      available: 'Available',
      selected: 'Your seat',
      occupied: 'Occupied',
      extraLegroom: 'Extra space',
      premium: 'Front premium'
    },
    extraLegroomLabel: 'Extra legroom space',
    premiumLabel: 'Front premium',
    standardLabel: 'Standard',
    seatRow: 'Row {row}',
    selectedSeat: 'Seat {seat}',
    noSeat: 'No seat selected',
    continue: 'Continue to Extras & Payment'
  },

  // Extras Page
  extrasPage: {
    title: 'Additional Services',
    subtitle: 'Add premium extras for an even more comfortable flight experience.',
    priority: {
      name: 'Priority Boarding',
      desc: 'Be among the first to board and secure space for your cabin baggage.'
    },
    assistance: {
      name: 'Airport Assistance',
      desc: 'Dedicated support at check-in, security screening, and boarding for those in need.'
    },
    smsNotification: {
      name: 'Real-time SMS Alerts',
      desc: 'Receive flight status updates instantly on your phone.'
    },
    continue: 'Continue to Checkout'
  },

  // Price Summary
  summary: {
    title: 'Booking Summary',
    flight: 'Flight',
    outbound: 'Departure',
    return: 'Return',
    passengers: 'Passengers',
    fare: 'Base Fare',
    baggage: 'Extra Baggage',
    seats: 'Selected Seats',
    extras: 'Additional Services',
    taxes: 'Airport Taxes',
    total: 'TOTAL',
    demoNotice: 'This is a simulation. No real transactions will be processed.',
    payBtn: 'Pay Securely'
  },

  // Checkout Page
  checkout: {
    title: 'Complete Your Booking',
    subtitle: 'Review your booking details and enter payment details to issue your ticket.',
    reviewTitle: 'Review Booking',
    paymentTitle: 'Payment Method',
    cardPayment: 'Credit Card (Visa / Mastercard)',
    cardNumber: 'Card Number',
    cardExpiry: 'Expiration Date (MM/YY)',
    cardCvv: 'CVV',
    cardHolder: 'Cardholder Name',
    demoDisclaimer: 'Payment is fully simulated. Do not enter real credit card details. Use mock values for testing.',
    processing: 'Processing secure payment...',
    paymentSuccess: 'Payment completed successfully!',
    validation: {
      cardNumber: 'Invalid card number (16 digits)',
      expiry: 'Invalid expiration date (MM/YY)',
      cvv: 'Invalid CVV (3 digits)',
      holder: 'Cardholder name is required'
    }
  },

  // Confirmation Page
  confirmation: {
    success: 'Booking Confirmed!',
    subtitle: 'Thank you for choosing FLYONE Moldova. Your ticket details have been sent to your email.',
    refCode: 'Booking Reference',
    flightDetails: 'Flight Details',
    passengerDetails: 'Passengers',
    actions: {
      title: 'Quick Actions',
      view: 'View My Booking',
      download: 'Download Confirmation (PDF)',
      email: 'Resend Email',
      home: 'Back to Homepage'
    },
    simulatedAction: 'Action simulated successfully!'
  },

  // My Booking Page
  myBooking: {
    title: 'Manage My Booking',
    subtitle: 'Modify flights, add baggage, select seats, or perform online check-in.',
    searchTitle: 'Find your booking',
    refCode: 'Booking code (e.g. FO8K2M)',
    lastName: 'Passenger last name',
    searchBtn: 'Search Booking',
    notFound: 'No booking found with these details.',
    status: 'Status',
    statusConfirmed: 'CONFIRMED',
    aircraft: 'Aircraft',
    actions: {
      changeFlight: 'Change Flight',
      addBaggage: 'Add Baggage',
      chooseSeats: 'Choose Seat',
      checkIn: 'Online Check-in',
      downloadDocs: 'Download Documents',
      simulatedSuccess: 'Simulation of service "{service}" completed successfully!'
    }
  },

  // Check-In Page
  checkinPage: {
    title: 'Online Check-In',
    subtitle: 'Online check-in is available 24 hours prior to departure. Get your boarding pass instantly.',
    searchTitle: 'Initiate Check-in',
    startBtn: 'Begin Check-In',
    alreadyDone: 'Check-in completed successfully! Your boarding pass has been generated.',
    downloadBoardingPass: 'Download Boarding Pass (Demo)',
    statusReady: 'Ready for Check-In'
  },

  // Destinations Page
  destinationsPage: {
    title: 'Our Destinations',
    subtitle: 'We fly to the most popular European cities. Choose your next adventure with FLYONE.',
    searchPlaceholder: 'Search for a destination...',
    bookNow: 'Book from {price}',
    moldovaTitle: 'Chișinău - Heart of Moldova',
    moldovaDesc: 'The central hub and primary departure point for all FLYONE Moldova flights.'
  },

  // Baggage Guide Page
  baggageGuide: {
    title: 'FLYONE Baggage Rules',
    subtitle: 'Everything you need to know about dimensions and weights allowed on our flights.',
    personal: {
      title: 'Personal Hand Bag',
      desc: 'Each passenger is entitled to one free small hand bag. It must fit under the seat in front of you.',
      dims: 'Max size: 40 x 30 x 20 cm',
      weight: 'Weight: No limit (must be reasonable)'
    },
    cabin: {
      title: '10 kg Cabin Baggage',
      desc: 'Paid option, or included in Standard/Premium fares. Placed in the overhead storage bin.',
      dims: 'Max size: 50 x 40 x 25 cm',
      weight: 'Max weight: 10 kg'
    },
    checked: {
      title: 'Registered Checked Baggage',
      desc: 'Must be checked in at the airport drop-off desk before security screening.',
      dims: 'Max combined size: 158 cm',
      weight: 'Weight options: 20 kg or 32 kg'
    },
    prohibited: {
      title: 'Prohibited Items',
      desc: 'It is strictly forbidden to carry flammable substances, weapons, unprotected lithium batteries, or other hazardous materials.'
    }
  }
};
