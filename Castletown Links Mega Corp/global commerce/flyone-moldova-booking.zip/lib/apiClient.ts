import { Airport, Booking, Flight, FlightSearchQuery, Passenger } from '@/types/booking';
import { generateFlightsForDate, AIRPORTS } from '@/lib/flightEngine';

export async function fetchAirports(): Promise<Airport[]> {
  try {
    const res = await fetch('/api/v1/airports');
    if (res.ok) {
      return await res.json();
    }
  } catch (e) {
    console.warn('Airports API failed, falling back to local list', e);
  }
  return AIRPORTS;
}

export async function fetchDestinations() {
  try {
    const res = await fetch('/api/v1/destinations');
    if (res.ok) {
      return await res.json();
    }
  } catch (e) {
    console.warn('Destinations API failed, falling back to local mock', e);
  }
  // Return mock destinations as fallback
  return [
    {
      code: 'FCO',
      city: 'Roma',
      country: 'Italia',
      name: 'Fiumicino Airport',
      basePrice: 79.99,
      image: '/images/destination_rome_1790840834133.jpg',
      desc: {
        ro: 'Descoperiți Cetatea Eternă: istorie antică, delicii culinare și o atmosferă romantică inegalabilă.',
        en: 'Discover the Eternal City: ancient history, culinary delights, and an unparalleled romantic atmosphere.'
      }
    },
    {
      code: 'CDG',
      city: 'Paris',
      country: 'Franța',
      name: 'Charles de Gaulle',
      basePrice: 119.99,
      image: '/images/destination_paris_1790840843809.jpg',
      desc: {
        ro: 'Orașul Luminilor vă așteaptă cu bulevarde elegante, artă de clasă mondială și monumente iconice.',
        en: 'The City of Lights awaits you with elegant boulevards, world-class art, and iconic monuments.'
      }
    },
    {
      code: 'LTN',
      city: 'Londra',
      country: 'Marea Britanie',
      name: 'Luton Airport',
      basePrice: 129.99,
      image: '/images/destination_london_1790840855786.jpg',
      desc: {
        ro: 'Explorați o metropolă vibrantă plină de istorie regală, muzee de top și diversitate culturală.',
        en: 'Explore a vibrant metropolis filled with royal history, world-class museums, and cultural diversity.'
      }
    }
  ];
}

export async function searchFlights(query: FlightSearchQuery): Promise<{ outboundFlights: Flight[]; returnFlights: Flight[] }> {
  try {
    const res = await fetch('/api/v1/search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(query),
    });
    if (res.ok) {
      return await res.json();
    }
  } catch (e) {
    console.warn('Search API failed, falling back to local generation', e);
  }

  // Fallback
  const outbound = generateFlightsForDate(query.originCode, query.destinationCode, query.departureDate);
  const back = query.tripType === 'roundTrip' && query.returnDate
    ? generateFlightsForDate(query.destinationCode, query.originCode, query.returnDate)
    : [];
  return { outboundFlights: outbound, returnFlights: back };
}

export async function createBooking(bookingData: Omit<Booking, 'reference' | 'paymentStatus' | 'checkInStatus' | 'createdAt'>): Promise<Booking> {
  try {
    const res = await fetch('/api/v1/bookings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(bookingData),
    });
    if (res.ok) {
      const created = await res.json();
      // Cache locally as well
      saveBookingLocally(created);
      return created;
    }
  } catch (e) {
    console.warn('Booking API failed, falling back to local simulation', e);
  }

  // Fallback
  const reference = 'FO' + Math.floor(100000 + Math.random() * 900000).toString().substring(0, 4);
  const mockBooking: Booking = {
    ...bookingData,
    reference,
    paymentStatus: 'paid',
    checkInStatus: bookingData.passengers.reduce((acc, p) => ({ ...acc, [p.id]: false }), {}),
    createdAt: new Date().toISOString(),
  };
  saveBookingLocally(mockBooking);
  return mockBooking;
}

export async function getBooking(reference: string, lastName: string): Promise<Booking> {
  try {
    const res = await fetch(`/api/v1/bookings/${reference}?lastName=${encodeURIComponent(lastName)}`);
    if (res.ok) {
      return await res.json();
    }
  } catch (e) {
    console.warn('Get Booking API failed, searching local storage', e);
  }

  // Fallback to local storage
  const localList = getLocalBookings();
  const found = localList.find(
    b => b.reference.toUpperCase() === reference.toUpperCase() &&
    b.passengers.some(p => p.lastName.toLowerCase() === lastName.toLowerCase())
  );

  if (found) {
    return found;
  }

  // If even local storage doesn't have it, but it's the pre-seeded FO8K2M code, mock it!
  if (reference.toUpperCase() === 'FO8K2M' && lastName.toLowerCase() === 'almeida') {
    return getPreseededDemoBooking();
  }

  throw new Error('Booking not found');
}

export async function updateBooking(reference: string, updatedData: Partial<Booking>): Promise<Booking> {
  try {
    const res = await fetch(`/api/v1/bookings/${reference}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updatedData),
    });
    if (res.ok) {
      const updated = await res.json();
      saveBookingLocally(updated);
      return updated;
    }
  } catch (e) {
    console.warn('Update Booking API failed, applying locally', e);
  }

  const localList = getLocalBookings();
  const idx = localList.findIndex(b => b.reference.toUpperCase() === reference.toUpperCase());
  if (idx !== -1) {
    const updated = { ...localList[idx], ...updatedData };
    localList[idx] = updated;
    localStorage.setItem('flyone_local_bookings', JSON.stringify(localList));
    return updated;
  }
  throw new Error('Booking not found for update');
}

export async function performCheckIn(reference: string, lastName: string, passengerId?: string): Promise<Booking> {
  try {
    const res = await fetch('/api/v1/checkin', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reference, lastName, passengerId }),
    });
    if (res.ok) {
      const { booking } = await res.json();
      saveBookingLocally(booking);
      return booking;
    }
  } catch (e) {
    console.warn('Checkin API failed, executing locally', e);
  }

  const booking = await getBooking(reference, lastName);
  const updatedCheckIn = { ...booking.checkInStatus };
  if (passengerId) {
    updatedCheckIn[passengerId] = true;
  } else {
    booking.passengers.forEach(p => {
      updatedCheckIn[p.id] = true;
    });
  }
  const updated = { ...booking, checkInStatus: updatedCheckIn };
  saveBookingLocally(updated);
  return updated;
}

// Local Storage helpers to make sure bookings persist perfectly
function getLocalBookings(): Booking[] {
  if (typeof window === 'undefined') return [];
  const raw = localStorage.getItem('flyone_local_bookings');
  return raw ? JSON.parse(raw) : [];
}

function saveBookingLocally(booking: Booking) {
  if (typeof window === 'undefined') return;
  const list = getLocalBookings();
  const idx = list.findIndex(b => b.reference === booking.reference);
  if (idx !== -1) {
    list[idx] = booking;
  } else {
    list.push(booking);
  }
  localStorage.setItem('flyone_local_bookings', JSON.stringify(list));
}

function getPreseededDemoBooking(): Booking {
  return {
    reference: 'FO8K2M',
    outboundFlight: {
      id: 'RMO-FCO-20261012-5F-123',
      flightNumber: '5F 123',
      origin: { code: 'RMO', name: 'Chișinău International', city: 'Chișinău', country: 'Moldova' },
      destination: { code: 'FCO', name: 'Fiumicino Airport', city: 'Roma', country: 'Italia' },
      departureTime: '2026-10-12T06:30:00.000Z',
      arrivalTime: '2026-10-12T08:00:00.000Z',
      durationMinutes: 150,
      aircraft: 'Airbus A320',
      basePrice: 79.99,
    },
    returnFlight: {
      id: 'FCO-RMO-20261019-5F-124',
      flightNumber: '5F 124',
      origin: { code: 'FCO', name: 'Fiumicino Airport', city: 'Roma', country: 'Italia' },
      destination: { code: 'RMO', name: 'Chișinău International', city: 'Chișinău', country: 'Moldova' },
      departureTime: '2026-10-19T19:40:00.000Z',
      arrivalTime: '2026-10-19T23:05:00.000Z',
      durationMinutes: 145,
      aircraft: 'Airbus A320',
      basePrice: 79.99,
    },
    fareClass: 'standard',
    passengers: [
      {
        id: 'p-1',
        firstName: 'John',
        lastName: 'Almeida',
        birthDate: '1988-06-15',
        nationality: 'Moldova',
        docType: 'passport',
        docNumber: 'A1234567',
        docExpiry: '2030-10-12',
        gender: 'male',
        baggage: {
          personal: true,
          cabin: true,
          checked20: 1,
          checked32: 0,
        },
        seat: '12A',
      }
    ],
    contact: {
      email: 'john.almeida@example.com',
      phone: '+373 60 123 456',
    },
    totalAmount: 196.99,
    paymentStatus: 'paid',
    checkInStatus: { 'p-1': false },
    createdAt: new Date().toISOString(),
  };
}
