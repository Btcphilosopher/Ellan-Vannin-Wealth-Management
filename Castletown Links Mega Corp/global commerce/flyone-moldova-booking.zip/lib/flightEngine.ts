import { Airport, Flight } from '@/types/booking';

export const AIRPORTS: Airport[] = [
  { code: 'RMO', name: 'Chișinău International', city: 'Chișinău', country: 'Moldova' },
  { code: 'OTP', name: 'Henri Coandă', city: 'București', country: 'România' },
  { code: 'CDG', name: 'Charles de Gaulle', city: 'Paris', country: 'Franța' },
  { code: 'LTN', name: 'Luton Airport', city: 'Londra', country: 'Marea Britanie' },
  { code: 'FCO', name: 'Fiumicino Airport', city: 'Roma', country: 'Italia' },
  { code: 'MXP', name: 'Malpensa Airport', city: 'Milano', country: 'Italia' },
  { code: 'VCE', name: 'Marco Polo', city: 'Veneția', country: 'Italia' },
  { code: 'VRN', name: 'Valerio Catullo', city: 'Verona', country: 'Italia' },
  { code: 'BRU', name: 'Brussels Airport', city: 'Bruxelles', country: 'Belgia' },
  { code: 'DUB', name: 'Dublin Airport', city: 'Dublin', country: 'Irlanda' },
  { code: 'FRA', name: 'Frankfurt Airport', city: 'Frankfurt', country: 'Germania' },
  { code: 'IST', name: 'Istanbul Airport', city: 'Istanbul', country: 'Turcia' },
];

// Seed-based simple random generator to make flights deterministic for a given date and route
class SeededRandom {
  private seed: number;
  constructor(seedStr: string) {
    let hash = 0;
    for (let i = 0; i < seedStr.length; i++) {
      hash = seedStr.charCodeAt(i) + ((hash << 5) - hash);
    }
    this.seed = Math.abs(hash);
  }

  next(): number {
    const x = Math.sin(this.seed++) * 10000;
    return x - Math.floor(x);
  }

  range(min: number, max: number): number {
    return min + this.next() * (max - min);
  }

  choice<T>(arr: T[]): T {
    const index = Math.floor(this.next() * arr.length);
    return arr[index];
  }
}

// Distance / duration mapper for routes from RMO
const ROUTE_DATA: Record<string, { minutes: number; price: number }> = {
  'OTP': { minutes: 50, price: 49 },
  'FCO': { minutes: 150, price: 79 },
  'CDG': { minutes: 190, price: 119 },
  'LTN': { minutes: 210, price: 129 },
  'MXP': { minutes: 140, price: 89 },
  'VCE': { minutes: 130, price: 89 },
  'VRN': { minutes: 135, price: 89 },
  'BRU': { minutes: 180, price: 109 },
  'DUB': { minutes: 230, price: 139 },
  'FRA': { minutes: 150, price: 119 },
  'IST': { minutes: 90, price: 69 },
};

export function getRouteDetails(origin: string, destination: string) {
  const key = origin === 'RMO' ? destination : origin;
  const data = ROUTE_DATA[key];
  if (data) {
    return data;
  }
  // Fallback for non-RMO routes (just in case)
  return { minutes: 120, price: 99 };
}

export function generateFlightsForDate(originCode: string, destinationCode: string, dateStr: string): Flight[] {
  const origin = AIRPORTS.find(a => a.code === originCode);
  const destination = AIRPORTS.find(a => a.code === destinationCode);

  if (!origin || !destination) {
    return [];
  }

  // Determine flight parameters
  const details = getRouteDetails(originCode, destinationCode);
  const basePrice = details.price;
  const duration = details.minutes;

  const rand = new SeededRandom(`${originCode}-${destinationCode}-${dateStr}`);
  
  // We'll generate 3 flights for the day: Morning (06:30), Afternoon (13:15), and Evening (20:45)
  const flightTimes = [
    { dep: '06:30', arrTimeOffset: duration },
    { dep: '13:15', arrTimeOffset: duration },
    { dep: '20:45', arrTimeOffset: duration },
  ];

  return flightTimes.map((time, idx) => {
    const [hours, mins] = time.dep.split(':').map(Number);
    const departure = new Date(dateStr);
    departure.setHours(hours, mins, 0, 0);

    const arrival = new Date(departure.getTime() + time.arrTimeOffset * 60 * 1000);

    const flightNum = `${rand.choice(['5F', 'FO'])}-${Math.floor(rand.range(100, 999))}`;

    // Adjust price slightly based on departure slot (morning/evening can be slightly cheaper or more expensive)
    const timeFactor = idx === 0 ? 0.95 : idx === 1 ? 1.1 : 1.0;
    const finalPrice = Math.round(basePrice * timeFactor * 100) / 100;

    return {
      id: `${originCode}-${destinationCode}-${dateStr.replace(/-/g, '')}-${flightNum}`,
      flightNumber: flightNum,
      origin,
      destination,
      departureTime: departure.toISOString(),
      arrivalTime: arrival.toISOString(),
      durationMinutes: duration,
      aircraft: 'Airbus A320',
      basePrice: finalPrice,
    };
  });
}
