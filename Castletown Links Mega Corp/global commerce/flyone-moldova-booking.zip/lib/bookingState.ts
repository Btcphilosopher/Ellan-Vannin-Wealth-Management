import { Booking, BookingContact, FareClass, Flight, FlightSearchQuery, Passenger } from '@/types/booking';

export type StepName =
  | 'home'
  | 'results'
  | 'fares'
  | 'passengers'
  | 'baggage'
  | 'seats'
  | 'extras'
  | 'checkout'
  | 'confirmation'
  | 'my-booking'
  | 'check-in'
  | 'destinations'
  | 'baggage-info';

export interface BookingFlowState {
  step: StepName;
  searchQuery: FlightSearchQuery | null;
  outboundFlights: Flight[];
  returnFlights: Flight[];
  selectedOutbound: Flight | null;
  selectedReturn: Flight | null;
  selectedFare: FareClass | null;
  passengers: Passenger[];
  contact: BookingContact;
  extras: {
    priority: boolean; // €15 per passenger
    assistance: boolean; // €0
    smsNotification: boolean; // €5 per booking
  };
  createdBooking: Booking | null;
}

export const INITIAL_CONTACT: BookingContact = {
  email: '',
  phone: '',
};

export const INITIAL_STATE: BookingFlowState = {
  step: 'home',
  searchQuery: null,
  outboundFlights: [],
  returnFlights: [],
  selectedOutbound: null,
  selectedReturn: null,
  selectedFare: null,
  passengers: [],
  contact: INITIAL_CONTACT,
  extras: {
    priority: false,
    assistance: false,
    smsNotification: false,
  },
  createdBooking: null,
};

// Pricing constants
export const TAXES_PER_PASSENGER = 24.0; // Euros
export const BAGGAGE_PRICES = {
  personal: 0,
  cabin: 25.0, // Euros
  checked20: 45.0, // Euros
  checked32: 65.0, // Euros
};
export const EXTRA_LEG_ROOM_COST = 18.0; // Euros
export const STANDARD_SEAT_COST = 8.0; // Euros (Basic fare has to pay this if selected)
export const PRIORITY_BOARDING_COST = 15.0; // Euros
export const SMS_NOTIFICATION_COST = 5.0; // Euros

export function calculateTotal(state: BookingFlowState): {
  base: number;
  taxes: number;
  baggage: number;
  seats: number;
  extras: number;
  total: number;
} {
  const numPassengers = state.passengers.length || 1;
  const flightsCount = state.selectedReturn ? 2 : 1;

  // 1. Base fare depending on Selected Fare Class
  let basePricePerPassenger = 0;
  if (state.selectedOutbound) {
    let outboundBase = state.selectedOutbound.basePrice;
    if (state.selectedFare === 'standard') outboundBase += 30; // +€30 standard markup
    if (state.selectedFare === 'premium') outboundBase += 80;  // +€80 premium markup
    basePricePerPassenger += outboundBase;
  }
  if (state.selectedReturn) {
    let returnBase = state.selectedReturn.basePrice;
    if (state.selectedFare === 'standard') returnBase += 30;
    if (state.selectedFare === 'premium') returnBase += 80;
    basePricePerPassenger += returnBase;
  }

  const baseTotal = basePricePerPassenger * numPassengers;

  // 2. Airport Taxes
  const taxesTotal = TAXES_PER_PASSENGER * numPassengers * flightsCount;

  // 3. Baggage costs
  let baggageTotal = 0;
  state.passengers.forEach(p => {
    // Basic fare has nothing included except personal.
    // Standard fare includes personal & cabin bag.
    // Premium fare includes personal, cabin, and 1 checked bag (20kg).
    const isBasic = state.selectedFare === 'basic';
    const isStandard = state.selectedFare === 'standard';
    const isPremium = state.selectedFare === 'premium';

    // Cabin bag cost
    if (p.baggage.cabin) {
      // Free for Standard and Premium
      if (isBasic) {
        baggageTotal += BAGGAGE_PRICES.cabin * flightsCount;
      }
    }

    // Checked bag 20kg
    if (p.baggage.checked20 > 0) {
      let billableCount = p.baggage.checked20;
      if (isPremium) {
        // First one is free
        billableCount = Math.max(0, billableCount - 1);
      }
      baggageTotal += billableCount * BAGGAGE_PRICES.checked20 * flightsCount;
    }

    // Checked bag 32kg
    if (p.baggage.checked32 > 0) {
      baggageTotal += p.baggage.checked32 * BAGGAGE_PRICES.checked32 * flightsCount;
    }
  });

  // 4. Seats costs
  let seatsTotal = 0;
  state.passengers.forEach(p => {
    if (p.seat) {
      const isExtraLegroom = ['1', '2', '12', '13'].some(row => p.seat?.startsWith(row));
      if (isExtraLegroom) {
        // Premium includes all seats, Standard/Basic pay for extra legroom
        if (state.selectedFare !== 'premium') {
          seatsTotal += EXTRA_LEG_ROOM_COST * flightsCount;
        }
      } else {
        // Standard seats
        // Basic pays for standard seats. Standard/Premium have them free.
        if (state.selectedFare === 'basic') {
          seatsTotal += STANDARD_SEAT_COST * flightsCount;
        }
      }
    }
  });

  // 5. Extras
  let extrasTotal = 0;
  if (state.extras.priority) {
    // Standard/Basic pay €15 per passenger per flight. Premium has it included.
    if (state.selectedFare !== 'premium') {
      extrasTotal += PRIORITY_BOARDING_COST * numPassengers * flightsCount;
    }
  }
  if (state.extras.smsNotification) {
    extrasTotal += SMS_NOTIFICATION_COST;
  }

  const grandTotal = baseTotal + taxesTotal + baggageTotal + seatsTotal + extrasTotal;

  return {
    base: parseFloat(baseTotal.toFixed(2)),
    taxes: parseFloat(taxesTotal.toFixed(2)),
    baggage: parseFloat(baggageTotal.toFixed(2)),
    seats: parseFloat(seatsTotal.toFixed(2)),
    extras: parseFloat(extrasTotal.toFixed(2)),
    total: parseFloat(grandTotal.toFixed(2)),
  };
}
