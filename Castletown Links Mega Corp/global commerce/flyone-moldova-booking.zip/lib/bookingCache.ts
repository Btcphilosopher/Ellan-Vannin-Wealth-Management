import { Booking, Flight, Passenger } from '@/types/booking';
import { AIRPORTS } from '@/lib/flightEngine';

// Next.js Global Singleton Pattern for persistent bookings in-memory
const globalForBookings = global as typeof globalThis & {
  bookings?: Record<string, Booking>;
};

if (!globalForBookings.bookings) {
  globalForBookings.bookings = {};
}

export const bookingsCache = globalForBookings.bookings;

// Preseed the required demo booking
const demoOutbound: Flight = {
  id: 'RMO-FCO-20261012-5F-123',
  flightNumber: '5F 123',
  origin: AIRPORTS.find(a => a.code === 'RMO')!,
  destination: AIRPORTS.find(a => a.code === 'FCO')!,
  departureTime: '2026-10-12T06:30:00.000Z',
  arrivalTime: '2026-10-12T08:00:00.000Z',
  durationMinutes: 150,
  aircraft: 'Airbus A320',
  basePrice: 79.99,
};

const demoReturn: Flight = {
  id: 'FCO-RMO-20261019-5F-124',
  flightNumber: '5F 124',
  origin: AIRPORTS.find(a => a.code === 'FCO')!,
  destination: AIRPORTS.find(a => a.code === 'RMO')!,
  departureTime: '2026-10-19T19:40:00.000Z',
  arrivalTime: '2026-10-19T23:05:00.000Z',
  durationMinutes: 145,
  aircraft: 'Airbus A320',
  basePrice: 79.99,
};

const demoPassenger: Passenger = {
  id: 'p-1',
  firstName: 'John',
  lastName: 'Almeida',
  birthDate: '1988-06-15',
  nationality: 'Moldova',
  docType: 'passport',
  docNumber: 'A1234567',
  docExpiry: '2030-10-12',
  gender: 'male',
  baggage: {
    personal: true,
    cabin: true,
    checked20: 1,
    checked32: 0,
  },
  seat: '12A',
};

const demoBooking: Booking = {
  reference: 'FO8K2M',
  outboundFlight: demoOutbound,
  returnFlight: demoReturn,
  fareClass: 'standard',
  passengers: [demoPassenger],
  contact: {
    email: 'john.almeida@example.com',
    phone: '+373 60 123 456',
  },
  totalAmount: 196.99,
  paymentStatus: 'paid',
  checkInStatus: { 'p-1': false },
  createdAt: new Date().toISOString(),
};

// Seed the booking if not already present
if (!bookingsCache['FO8K2M']) {
  bookingsCache['FO8K2M'] = demoBooking;
}
