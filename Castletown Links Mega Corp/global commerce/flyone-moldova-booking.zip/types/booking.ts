export interface Airport {
  code: string; // e.g. RMO
  name: string; // e.g. Chișinău
  city: string; // e.g. Chișinău
  country: string; // e.g. Moldova
}

export interface Flight {
  id: string;
  flightNumber: string; // e.g. 5F 123
  origin: Airport;
  destination: Airport;
  departureTime: string; // ISO String
  arrivalTime: string; // ISO String
  durationMinutes: number;
  aircraft: string; // e.g. Airbus A320
  basePrice: number; // in Euros
}

export type FareClass = 'basic' | 'standard' | 'premium';

export interface FareOption {
  type: FareClass;
  price: number;
  features: string[];
}

export interface Passenger {
  id: string;
  firstName: string;
  lastName: string;
  birthDate: string;
  nationality: string;
  docType: 'passport' | 'idCard';
  docNumber: string;
  docExpiry: string;
  gender: 'male' | 'female';
  baggage: {
    personal: boolean; // always true
    cabin: boolean; // standard and premium might have it included, or added
    checked20: number; // count of 20kg bags
    checked32: number; // count of 32kg bags
  };
  seat: string | null; // e.g. "12A"
}

export interface BookingContact {
  email: string;
  phone: string;
}

export interface Booking {
  reference: string; // e.g. FO8K2M
  outboundFlight: Flight;
  returnFlight: Flight | null;
  fareClass: FareClass;
  passengers: Passenger[];
  contact: BookingContact;
  totalAmount: number;
  paymentStatus: 'pending' | 'paid' | 'failed';
  checkInStatus: Record<string, boolean>; // PassengerId -> checkin status
  createdAt: string;
}

export interface FlightSearchQuery {
  originCode: string;
  destinationCode: string;
  departureDate: string;
  returnDate: string | null;
  tripType: 'roundTrip' | 'oneWay';
  passengers: {
    adults: number;
    children: number;
    infants: number;
  };
}
