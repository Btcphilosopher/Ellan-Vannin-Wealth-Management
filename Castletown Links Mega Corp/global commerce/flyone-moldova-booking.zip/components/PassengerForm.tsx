'use client';

import React, { useState } from 'react';
import { useBooking } from '@/components/BookingProvider';
import { Passenger, BookingContact } from '@/types/booking';
import { User, ShieldAlert, Mail, Phone, Calendar, Globe, FileText } from 'lucide-react';

interface PassengerFormProps {
  onContinue: () => void;
}

export default function PassengerForm({ onContinue }: PassengerFormProps) {
  const { state, t, updatePassenger, setContact } = useBooking();
  const [errors, setErrors] = useState<Record<string, string>>({});

  const [contactEmail, setContactEmail] = useState(state.contact.email || '');
  const [contactPhone, setContactPhone] = useState(state.contact.phone || '');

  const validate = () => {
    const newErrors: Record<string, string> = {};

    // Validate each passenger
    state.passengers.forEach((p, idx) => {
      if (!p.firstName.trim()) newErrors[`p_${idx}_firstName`] = t('passengersForm.validation.required');
      if (!p.lastName.trim()) newErrors[`p_${idx}_lastName`] = t('passengersForm.validation.required');
      if (!p.birthDate) newErrors[`p_${idx}_birthDate`] = t('passengersForm.validation.required');
      if (!p.docNumber.trim()) newErrors[`p_${idx}_docNumber`] = t('passengersForm.validation.required');
      if (!p.docExpiry) newErrors[`p_${idx}_docExpiry`] = t('passengersForm.validation.required');
    });

    // Validate contact info
    if (!contactEmail.trim()) {
      newErrors['contactEmail'] = t('passengersForm.validation.required');
    } else if (!/\S+@\S+\.\S+/.test(contactEmail)) {
      newErrors['contactEmail'] = t('passengersForm.validation.emailInvalid');
    }

    if (!contactPhone.trim()) {
      newErrors['contactPhone'] = t('passengersForm.validation.required');
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      setContact({
        email: contactEmail,
        phone: contactPhone,
      });
      onContinue();
    } else {
      // Scroll to first error
      const firstErrorKey = Object.keys(errors)[0];
      if (firstErrorKey) {
        const el = document.getElementsByName(firstErrorKey)[0];
        if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-8 pb-16">
      
      {/* Demo notice alert banner */}
      <div className="flex items-start gap-3 rounded-lg border border-blue-200 bg-blue-50/50 p-4">
        <ShieldAlert className="h-5 w-5 text-blue-900 shrink-0 mt-0.5" />
        <p className="text-xs font-semibold text-blue-950 leading-relaxed">
          {t('passengersForm.disclaimer')}
        </p>
      </div>

      <div className="space-y-6">
        {state.passengers.map((passenger, idx) => (
          <div key={passenger.id} className="bg-white rounded-xl border border-slate-100 shadow-sm p-5 sm:p-6 space-y-5">
            <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
              <User className="h-5 w-5 text-blue-900" />
              <h3 className="font-black text-sm sm:text-base tracking-wider text-blue-950 uppercase">
                {t('passengersForm.passengerIndex', { index: idx + 1 })}
              </h3>
            </div>

            {/* Inputs Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              
              {/* First Name */}
              <div>
                <label className="block text-2xs font-extrabold text-slate-500 uppercase tracking-widest mb-1">
                  {t('passengersForm.firstName')}
                </label>
                <input
                  type="text"
                  name={`p_${idx}_firstName`}
                  value={passenger.firstName}
                  onChange={e => updatePassenger(idx, { firstName: e.target.value })}
                  placeholder="John"
                  className={`w-full min-h-[44px] px-3.5 py-2 text-sm font-semibold text-slate-800 bg-white border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900 ${
                    errors[`p_${idx}_firstName`] ? 'border-red-500 ring-1 ring-red-500' : 'border-slate-200 hover:border-slate-300'
                  }`}
                />
                {errors[`p_${idx}_firstName`] && (
                  <span className="text-xs text-red-500 mt-1 block font-semibold">{errors[`p_${idx}_firstName`]}</span>
                )}
              </div>

              {/* Last Name */}
              <div>
                <label className="block text-2xs font-extrabold text-slate-500 uppercase tracking-widest mb-1">
                  {t('passengersForm.lastName')}
                </label>
                <input
                  type="text"
                  name={`p_${idx}_lastName`}
                  value={passenger.lastName}
                  onChange={e => updatePassenger(idx, { lastName: e.target.value })}
                  placeholder="Almeida"
                  className={`w-full min-h-[44px] px-3.5 py-2 text-sm font-semibold text-slate-800 bg-white border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900 ${
                    errors[`p_${idx}_lastName`] ? 'border-red-500 ring-1 ring-red-500' : 'border-slate-200 hover:border-slate-300'
                  }`}
                />
                {errors[`p_${idx}_lastName`] && (
                  <span className="text-xs text-red-500 mt-1 block font-semibold">{errors[`p_${idx}_lastName`]}</span>
                )}
              </div>

              {/* Birthdate */}
              <div>
                <label className="block text-2xs font-extrabold text-slate-500 uppercase tracking-widest mb-1">
                  {t('passengersForm.birthDate')}
                </label>
                <div className="relative">
                  <Calendar className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 pointer-events-none" />
                  <input
                    type="date"
                    name={`p_${idx}_birthDate`}
                    value={passenger.birthDate}
                    onChange={e => updatePassenger(idx, { birthDate: e.target.value })}
                    className={`w-full min-h-[44px] px-3.5 py-2 text-sm font-semibold text-slate-800 bg-white border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900 ${
                      errors[`p_${idx}_birthDate`] ? 'border-red-500 ring-1 ring-red-500' : 'border-slate-200 hover:border-slate-300'
                    }`}
                  />
                </div>
                {errors[`p_${idx}_birthDate`] && (
                  <span className="text-xs text-red-500 mt-1 block font-semibold">{errors[`p_${idx}_birthDate`]}</span>
                )}
              </div>

              {/* Nationality */}
              <div>
                <label className="block text-2xs font-extrabold text-slate-500 uppercase tracking-widest mb-1">
                  {t('passengersForm.nationality')}
                </label>
                <div className="relative">
                  <Globe className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 pointer-events-none" />
                  <select
                    value={passenger.nationality}
                    onChange={e => updatePassenger(idx, { nationality: e.target.value })}
                    className="w-full min-h-[44px] px-3.5 py-2 text-sm font-semibold text-slate-800 bg-white border border-slate-200 rounded-lg hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-900 appearance-none"
                  >
                    <option value="Moldova">Moldova</option>
                    <option value="România">România</option>
                    <option value="Franța">Franța</option>
                    <option value="Italia">Italia</option>
                    <option value="Marea Britanie">Marea Britanie</option>
                    <option value="Germania">Germania</option>
                    <option value="Turcia">Turcia</option>
                  </select>
                </div>
              </div>

              {/* Gender */}
              <div>
                <label className="block text-2xs font-extrabold text-slate-500 uppercase tracking-widest mb-1">
                  {t('passengersForm.gender')}
                </label>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => updatePassenger(idx, { gender: 'male' })}
                    className={`flex-1 min-h-[44px] text-xs font-bold rounded-lg border transition-all ${
                      passenger.gender === 'male'
                        ? 'border-blue-900 bg-blue-50/40 text-blue-900 font-extrabold shadow-sm'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {t('passengersForm.genderMale')}
                  </button>
                  <button
                    type="button"
                    onClick={() => updatePassenger(idx, { gender: 'female' })}
                    className={`flex-1 min-h-[44px] text-xs font-bold rounded-lg border transition-all ${
                      passenger.gender === 'female'
                        ? 'border-blue-900 bg-blue-50/40 text-blue-900 font-extrabold shadow-sm'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {t('passengersForm.genderFemale')}
                  </button>
                </div>
              </div>

              {/* Document Type */}
              <div>
                <label className="block text-2xs font-extrabold text-slate-500 uppercase tracking-widest mb-1">
                  {t('passengersForm.docType')}
                </label>
                <div className="relative">
                  <FileText className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 pointer-events-none" />
                  <select
                    value={passenger.docType}
                    onChange={e => updatePassenger(idx, { docType: e.target.value as any })}
                    className="w-full min-h-[44px] px-3.5 py-2 text-sm font-semibold text-slate-800 bg-white border border-slate-200 rounded-lg hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-900 appearance-none"
                  >
                    <option value="passport">{t('passengersForm.passport')}</option>
                    <option value="idCard">{t('passengersForm.idCard')}</option>
                  </select>
                </div>
              </div>

              {/* Document Number */}
              <div>
                <label className="block text-2xs font-extrabold text-slate-500 uppercase tracking-widest mb-1">
                  {t('passengersForm.docNumber')}
                </label>
                <input
                  type="text"
                  name={`p_${idx}_docNumber`}
                  value={passenger.docNumber}
                  onChange={e => updatePassenger(idx, { docNumber: e.target.value })}
                  placeholder="A1234567"
                  className={`w-full min-h-[44px] px-3.5 py-2 text-sm font-semibold text-slate-800 bg-white border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900 ${
                    errors[`p_${idx}_docNumber`] ? 'border-red-500 ring-1 ring-red-500' : 'border-slate-200 hover:border-slate-300'
                  }`}
                />
                {errors[`p_${idx}_docNumber`] && (
                  <span className="text-xs text-red-500 mt-1 block font-semibold">{errors[`p_${idx}_docNumber`]}</span>
                )}
              </div>

              {/* Expiry Date */}
              <div>
                <label className="block text-2xs font-extrabold text-slate-500 uppercase tracking-widest mb-1">
                  {t('passengersForm.docExpiry')}
                </label>
                <div className="relative">
                  <Calendar className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 pointer-events-none" />
                  <input
                    type="date"
                    name={`p_${idx}_docExpiry`}
                    value={passenger.docExpiry}
                    onChange={e => updatePassenger(idx, { docExpiry: e.target.value })}
                    className={`w-full min-h-[44px] px-3.5 py-2 text-sm font-semibold text-slate-800 bg-white border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900 ${
                      errors[`p_${idx}_docExpiry`] ? 'border-red-500 ring-1 ring-red-500' : 'border-slate-200 hover:border-slate-300'
                    }`}
                  />
                </div>
                {errors[`p_${idx}_docExpiry`] && (
                  <span className="text-xs text-red-500 mt-1 block font-semibold">{errors[`p_${idx}_docExpiry`]}</span>
                )}
              </div>

            </div>
          </div>
        ))}
      </div>

      {/* Contact Section */}
      <div className="bg-white rounded-xl border border-slate-100 shadow-sm p-5 sm:p-6 space-y-5">
        <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
          <Mail className="h-5 w-5 text-blue-900" />
          <h3 className="font-black text-sm sm:text-base tracking-wider text-blue-950 uppercase">
            {t('passengersForm.contactTitle')}
          </h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Email */}
          <div>
            <label className="block text-2xs font-extrabold text-slate-500 uppercase tracking-widest mb-1">
              {t('passengersForm.email')}
            </label>
            <div className="relative">
              <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 pointer-events-none" />
              <input
                type="email"
                name="contactEmail"
                value={contactEmail}
                onChange={e => setContactEmail(e.target.value)}
                placeholder="example@flyone.md"
                className={`w-full min-h-[44px] pl-10 pr-3.5 py-2 text-sm font-semibold text-slate-800 bg-white border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900 ${
                  errors.contactEmail ? 'border-red-500 ring-1 ring-red-500' : 'border-slate-200 hover:border-slate-300'
                }`}
              />
            </div>
            {errors.contactEmail && (
              <span className="text-xs text-red-500 mt-1 block font-semibold">{errors.contactEmail}</span>
            )}
          </div>

          {/* Phone */}
          <div>
            <label className="block text-2xs font-extrabold text-slate-500 uppercase tracking-widest mb-1">
              {t('passengersForm.phone')}
            </label>
            <div className="relative">
              <Phone className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 pointer-events-none" />
              <input
                type="tel"
                name="contactPhone"
                value={contactPhone}
                onChange={e => setContactPhone(e.target.value)}
                placeholder="+373 60 123 456"
                className={`w-full min-h-[44px] pl-10 pr-3.5 py-2 text-sm font-semibold text-slate-800 bg-white border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900 ${
                  errors.contactPhone ? 'border-red-500 ring-1 ring-red-500' : 'border-slate-200 hover:border-slate-300'
                }`}
              />
            </div>
            {errors.contactPhone && (
              <span className="text-xs text-red-500 mt-1 block font-semibold">{errors.contactPhone}</span>
            )}
          </div>
        </div>
      </div>

      {/* Hidden native submit for accessibility */}
      <button type="submit" className="hidden" />

    </form>
  );
}
