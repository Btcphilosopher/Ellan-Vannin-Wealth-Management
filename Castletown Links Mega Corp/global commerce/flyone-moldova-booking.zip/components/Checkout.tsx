'use client';

import React, { useState } from 'react';
import { useBooking } from '@/components/BookingProvider';
import { calculateTotal } from '@/lib/bookingState';
import { createBooking } from '@/lib/apiClient';
import { CreditCard, Lock, ShieldAlert, CheckCircle2, Loader2 } from 'lucide-react';

interface CheckoutProps {
  onSuccess: () => void;
}

export default function Checkout({ onSuccess }: CheckoutProps) {
  const { state, t, setCreatedBooking } = useBooking();
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [stage, setStage] = useState<'input' | 'processing' | 'success'>('input');

  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');
  const [cardHolder, setCardHolder] = useState('');

  const { total } = calculateTotal(state);

  const formatCardNumber = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    const matches = v.match(/\d{4,16}/g);
    const match = (matches && matches[0]) || '';
    const parts = [];

    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }

    if (parts.length > 0) {
      return parts.join(' ');
    } else {
      return v;
    }
  };

  const formatExpiry = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    if (v.length >= 2) {
      return `${v.slice(0, 2)}/${v.slice(2, 4)}`;
    }
    return v;
  };

  const validate = () => {
    const newErrors: Record<string, string> = {};
    const rawCard = cardNumber.replace(/\s/g, '');

    if (rawCard.length !== 16 || !/^\d+$/.test(rawCard)) {
      newErrors.cardNumber = t('checkout.validation.cardNumber');
    }
    if (!/^\d{2}\/\d{2}$/.test(cardExpiry)) {
      newErrors.expiry = t('checkout.validation.expiry');
    }
    if (cardCvv.length !== 3 || !/^\d+$/.test(cardCvv)) {
      newErrors.cvv = t('checkout.validation.cvv');
    }
    if (!cardHolder.trim()) {
      newErrors.holder = t('checkout.validation.holder');
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handlePay = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setStage('processing');
    setLoading(true);

    // Simulate airline payment gateway processing
    await new Promise(resolve => setTimeout(resolve, 2000));

    try {
      const result = await createBooking({
        outboundFlight: state.selectedOutbound!,
        returnFlight: state.selectedReturn,
        fareClass: state.selectedFare!,
        passengers: state.passengers,
        contact: state.contact,
        totalAmount: total,
      });

      setCreatedBooking(result);
      setStage('success');

      // Short delay for success animation
      await new Promise(resolve => setTimeout(resolve, 1000));
      onSuccess();
    } catch (err) {
      console.error(err);
      setErrors({ payment: 'Plata nu a putut fi procesată. Încercați din nou.' });
      setStage('input');
    } finally {
      setLoading(false);
    }
  };

  if (stage === 'processing') {
    return (
      <div className="flex flex-col items-center justify-center py-16 px-4 space-y-6 text-center animate-fadeIn">
        <Loader2 className="h-12 w-12 text-blue-900 animate-spin" />
        <div>
          <h3 className="font-black text-lg text-blue-950 uppercase tracking-widest leading-none mb-2">
            {t('checkout.processing')}
          </h3>
          <p className="text-sm text-slate-500 font-semibold">
            {t('checkout.cardPayment')}
          </p>
        </div>
      </div>
    );
  }

  if (stage === 'success') {
    return (
      <div className="flex flex-col items-center justify-center py-16 px-4 space-y-6 text-center animate-fadeIn">
        <CheckCircle2 className="h-16 w-16 text-emerald-600 animate-bounce" />
        <div>
          <h3 className="font-black text-xl text-blue-950 uppercase tracking-widest leading-none mb-2">
            {t('checkout.paymentSuccess')}
          </h3>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={handlePay} className="space-y-6 pb-16">
      
      {/* Simulation Banner */}
      <div className="flex items-start gap-3 rounded-lg border border-amber-200 bg-amber-50/50 p-4">
        <ShieldAlert className="h-5 w-5 text-amber-700 shrink-0 mt-0.5" />
        <p className="text-xs font-semibold text-amber-950 leading-relaxed">
          {t('checkout.demoDisclaimer')}
        </p>
      </div>

      <div className="bg-white rounded-xl border border-slate-100 shadow-sm p-5 sm:p-6 space-y-5">
        
        {/* Header */}
        <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
          <CreditCard className="h-5 w-5 text-blue-900" />
          <h3 className="font-black text-sm sm:text-base tracking-wider text-blue-950 uppercase">
            {t('checkout.paymentTitle')}
          </h3>
        </div>

        <div className="space-y-4">
          
          {/* Cardholder Name */}
          <div>
            <label className="block text-2xs font-extrabold text-slate-500 uppercase tracking-widest mb-1">
              {t('checkout.cardHolder')}
            </label>
            <input
              type="text"
              value={cardHolder}
              onChange={e => setCardHolder(e.target.value.toUpperCase())}
              placeholder="JOHN ALMEIDA"
              className={`w-full min-h-[44px] px-3.5 py-2 text-sm font-semibold text-slate-800 bg-white border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900 uppercase ${
                errors.holder ? 'border-red-500 ring-1 ring-red-500' : 'border-slate-200 hover:border-slate-300'
              }`}
            />
            {errors.holder && (
              <span className="text-xs text-red-500 mt-1 block font-semibold">{errors.holder}</span>
            )}
          </div>

          {/* Card Number */}
          <div>
            <label className="block text-2xs font-extrabold text-slate-500 uppercase tracking-widest mb-1">
              {t('checkout.cardNumber')}
            </label>
            <div className="relative">
              <CreditCard className="absolute right-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 pointer-events-none" />
              <input
                type="text"
                maxLength={19}
                value={cardNumber}
                onChange={e => setCardNumber(formatCardNumber(e.target.value))}
                placeholder="4111 2222 3333 4444"
                className={`w-full min-h-[44px] px-3.5 py-2 text-sm font-semibold text-slate-800 bg-white border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900 ${
                  errors.cardNumber ? 'border-red-500 ring-1 ring-red-500' : 'border-slate-200 hover:border-slate-300'
                }`}
              />
            </div>
            {errors.cardNumber && (
              <span className="text-xs text-red-500 mt-1 block font-semibold">{errors.cardNumber}</span>
            )}
          </div>

          {/* Expiry & CVV Grid */}
          <div className="grid grid-cols-2 gap-4">
            
            {/* Expiry */}
            <div>
              <label className="block text-2xs font-extrabold text-slate-500 uppercase tracking-widest mb-1">
                {t('checkout.cardExpiry')}
              </label>
              <input
                type="text"
                maxLength={5}
                value={cardExpiry}
                onChange={e => setCardExpiry(formatExpiry(e.target.value))}
                placeholder="12/28"
                className={`w-full min-h-[44px] px-3.5 py-2 text-sm font-semibold text-slate-800 bg-white border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900 text-center ${
                  errors.expiry ? 'border-red-500 ring-1 ring-red-500' : 'border-slate-200 hover:border-slate-300'
                }`}
              />
              {errors.expiry && (
                <span className="text-xs text-red-500 mt-1 block font-semibold">{errors.expiry}</span>
              )}
            </div>

            {/* CVV */}
            <div>
              <label className="block text-2xs font-extrabold text-slate-500 uppercase tracking-widest mb-1">
                {t('checkout.cardCvv')}
              </label>
              <div className="relative">
                <Lock className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 pointer-events-none" />
                <input
                  type="password"
                  maxLength={3}
                  value={cardCvv}
                  onChange={e => setCardCvv(e.target.value.replace(/\D/g, ''))}
                  placeholder="123"
                  className={`w-full min-h-[44px] px-3.5 py-2 text-sm font-semibold text-slate-800 bg-white border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900 text-center ${
                    errors.cvv ? 'border-red-500 ring-1 ring-red-500' : 'border-slate-200 hover:border-slate-300'
                  }`}
                />
              </div>
              {errors.cvv && (
                <span className="text-xs text-red-500 mt-1 block font-semibold">{errors.cvv}</span>
              )}
            </div>

          </div>

        </div>

      </div>

      {errors.payment && (
        <span className="text-sm text-red-500 text-center block font-semibold">{errors.payment}</span>
      )}

      {/* Hidden native button to catch form submit triggers */}
      <button type="submit" className="hidden" />

    </form>
  );
}
