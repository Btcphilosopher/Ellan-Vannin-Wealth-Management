'use client';

import React, { useState } from 'react';
import { useBooking } from '@/components/BookingProvider';
import { User, ShieldAlert } from 'lucide-react';
import { EXTRA_LEG_ROOM_COST, STANDARD_SEAT_COST } from '@/lib/bookingState';

interface SeatMapProps {
  onContinue: () => void;
}

export default function SeatMap({ onContinue }: SeatMapProps) {
  const { state, t, updatePassengerSeat } = useBooking();
  const [activePassengerIdx, setActivePassengerIdx] = useState(0);

  const activePassenger = state.passengers[activePassengerIdx];
  if (!activePassenger) return null;

  // Let's generate rows for the Airbus A320
  // Rows: 1 to 24 (A320 standard has ~30 rows, we can display rows 1 to 15 for a premium visual scroll map)
  const rows = Array.from({ length: 15 }, (_, i) => i + 1);
  const seatsInRow = ['A', 'B', 'C', 'D', 'E', 'F'];

  const getSeatType = (row: number) => {
    if (row <= 2 || row === 12 || row === 13) {
      return 'extra-legroom';
    }
    if (row <= 5) {
      return 'premium';
    }
    return 'standard';
  };

  const getSeatCost = (row: number) => {
    const type = getSeatType(row);
    if (type === 'extra-legroom') {
      return state.selectedFare === 'premium' ? 0 : EXTRA_LEG_ROOM_COST;
    }
    // Standard and Premium have standard seats free. Basic pays STANDARD_SEAT_COST.
    if (state.selectedFare === 'basic') {
      return STANDARD_SEAT_COST;
    }
    return 0;
  };

  const isSeatOccupied = (row: number, letter: string) => {
    // Deterministic occupied seats based on a hash of row and letter
    const hash = (row * 7 + letter.charCodeAt(0) * 13) % 5;
    return hash === 0 || hash === 2; // ~40% seats occupied
  };

  const isSeatSelectedByOthers = (seatCode: string) => {
    return state.passengers.some((p, idx) => idx !== activePassengerIdx && p.seat === seatCode);
  };

  const handleSeatClick = (row: number, letter: string) => {
    const seatCode = `${row}${letter}`;
    if (isSeatOccupied(row, letter) || isSeatSelectedByOthers(seatCode)) {
      return;
    }

    if (activePassenger.seat === seatCode) {
      updatePassengerSeat(activePassengerIdx, null);
    } else {
      updatePassengerSeat(activePassengerIdx, seatCode);
    }
  };

  return (
    <div className="space-y-6 pb-16">
      {/* Passenger selector tabs (if more than 1 passenger) */}
      {state.passengers.length > 1 && (
        <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-thin">
          {state.passengers.map((p, idx) => (
            <button
              key={p.id}
              type="button"
              onClick={() => setActivePassengerIdx(idx)}
              className={`flex items-center gap-1.5 px-4 py-2.5 rounded-lg border text-xs font-bold whitespace-nowrap transition-all ${
                activePassengerIdx === idx
                  ? 'border-blue-900 bg-blue-900 text-white'
                  : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
              }`}
            >
              <User className="h-3.5 w-3.5" />
              <span>
                {p.firstName && p.lastName
                  ? `${p.firstName} ${p.lastName}`
                  : `${t('passengersForm.passengerIndex', { index: idx + 1 })}`}
                {p.seat ? ` (${p.seat})` : ''}
              </span>
            </button>
          ))}
        </div>
      )}

      {/* Seat Selection Main Panel */}
      <div className="bg-white rounded-xl border border-slate-100 shadow-sm p-5 sm:p-6">
        <h3 className="font-black text-sm sm:text-base tracking-wider text-blue-950 uppercase border-b border-slate-100 pb-3 mb-5">
          {t('seatsPage.title')} (
          {activePassenger.firstName && activePassenger.lastName
            ? `${activePassenger.firstName} ${activePassenger.lastName}`
            : `${t('passengersForm.passengerIndex', { index: activePassengerIdx + 1 })}`}
          )
        </h3>

        {/* Legend */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 bg-slate-50 border border-slate-150 p-4 rounded-xl text-2xs sm:text-xs font-bold text-slate-600 mb-8">
          <div className="flex items-center gap-2">
            <span className="h-5 w-5 rounded bg-white border border-slate-200 block shadow-sm"></span>
            <span>{t('seatsPage.legend.available')}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="h-5 w-5 rounded bg-blue-900 border border-blue-900 block shadow-sm"></span>
            <span>{t('seatsPage.legend.selected')}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="h-5 w-5 rounded bg-slate-200 border border-slate-200 block"></span>
            <span>{t('seatsPage.legend.occupied')}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="h-5 w-5 rounded bg-amber-50 border border-amber-300 block"></span>
            <span>{t('seatsPage.legend.extraLegroom')} (+€18)</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="h-5 w-5 rounded bg-blue-50 border border-blue-200 block"></span>
            <span>{t('seatsPage.legend.premium')}</span>
          </div>
        </div>

        {/* Airbus Cabin Layout Scroll Container */}
        <div className="max-w-md mx-auto border-x border-slate-200 bg-slate-50/50 rounded-2xl py-6 px-4 shadow-inner max-h-[500px] overflow-y-auto scrollbar-thin relative">
          
          {/* Plane Nose Indicator */}
          <div className="w-full flex justify-center mb-8">
            <div className="bg-slate-300 h-1.5 w-16 rounded-full relative">
              <span className="absolute -top-6 left-1/2 -translate-x-1/2 text-3xs font-extrabold text-slate-400 uppercase tracking-widest">
                CABIN FRONT
              </span>
            </div>
          </div>

          <div className="space-y-4">
            {/* Headers row (A B C D E F) */}
            <div className="grid grid-cols-7 items-center text-center font-bold text-xs text-slate-400">
              <span>A</span>
              <span>B</span>
              <span>C</span>
              <span className="text-2xs font-bold text-slate-300">AISLE</span>
              <span>D</span>
              <span>E</span>
              <span>F</span>
            </div>

            {/* Seats Map Row-by-Row */}
            {rows.map(row => {
              const seatType = getSeatType(row);
              const seatCost = getSeatCost(row);

              return (
                <div key={row} className="grid grid-cols-7 items-center text-center relative">
                  {/* Left Group (A B C) */}
                  {seatsInRow.slice(0, 3).map(letter => {
                    const seatCode = `${row}${letter}`;
                    const occupied = isSeatOccupied(row, letter);
                    const selectedByMe = activePassenger.seat === seatCode;
                    const selectedByOther = isSeatSelectedByOthers(seatCode);

                    let bgClass = 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50';
                    if (seatType === 'extra-legroom') bgClass = 'bg-amber-50/50 border-amber-300 hover:bg-amber-100/50';
                    if (seatType === 'premium') bgClass = 'bg-blue-50/50 border-blue-200 hover:bg-blue-100/50';
                    if (occupied || selectedByOther) bgClass = 'bg-slate-200 border-slate-200 text-slate-400 cursor-not-allowed';
                    if (selectedByMe) bgClass = 'bg-blue-900 border-blue-900 text-white hover:bg-blue-800';

                    return (
                      <button
                        key={letter}
                        type="button"
                        disabled={occupied || selectedByOther}
                        onClick={() => handleSeatClick(row, letter)}
                        className={`h-9 w-9 rounded-lg border text-2xs font-extrabold flex items-center justify-center transition-all ${bgClass}`}
                        title={occupied ? 'Occupied' : `Seat ${seatCode} (${seatType})`}
                      >
                        {selectedByMe ? letter : ''}
                      </button>
                    );
                  })}

                  {/* Row Indicator */}
                  <span className="text-2xs font-bold text-slate-400 font-mono">
                    {row}
                  </span>

                  {/* Right Group (D E F) */}
                  {seatsInRow.slice(3).map(letter => {
                    const seatCode = `${row}${letter}`;
                    const occupied = isSeatOccupied(row, letter);
                    const selectedByMe = activePassenger.seat === seatCode;
                    const selectedByOther = isSeatSelectedByOthers(seatCode);

                    let bgClass = 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50';
                    if (seatType === 'extra-legroom') bgClass = 'bg-amber-50/50 border-amber-300 hover:bg-amber-100/50';
                    if (seatType === 'premium') bgClass = 'bg-blue-50/50 border-blue-200 hover:bg-blue-100/50';
                    if (occupied || selectedByOther) bgClass = 'bg-slate-200 border-slate-200 text-slate-400 cursor-not-allowed';
                    if (selectedByMe) bgClass = 'bg-blue-900 border-blue-900 text-white hover:bg-blue-800';

                    return (
                      <button
                        key={letter}
                        type="button"
                        disabled={occupied || selectedByOther}
                        onClick={() => handleSeatClick(row, letter)}
                        className={`h-9 w-9 rounded-lg border text-2xs font-extrabold flex items-center justify-center transition-all ${bgClass}`}
                        title={occupied ? 'Occupied' : `Seat ${seatCode} (${seatType})`}
                      >
                        {selectedByMe ? letter : ''}
                      </button>
                    );
                  })}
                </div>
              );
            })}
          </div>

        </div>
      </div>
    </div>
  );
}
