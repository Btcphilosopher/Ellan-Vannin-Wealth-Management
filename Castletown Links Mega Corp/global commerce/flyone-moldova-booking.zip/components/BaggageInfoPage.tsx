'use client';

import React from 'react';
import { useBooking } from '@/components/BookingProvider';
import { ShoppingBag, Briefcase, Info, AlertTriangle, Scale, Maximize } from 'lucide-react';

export default function BaggageInfoPage() {
  const { t } = useBooking();

  return (
    <div className="max-w-3xl mx-auto space-y-6 pb-16 animate-fadeIn px-4">
      
      {/* Intro Header */}
      <div className="text-center max-w-xl mx-auto space-y-3">
        <h2 className="text-xl sm:text-2xl font-black text-blue-950 uppercase tracking-wider">
          {t('baggageGuide.title')}
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 font-semibold">
          {t('baggageGuide.subtitle')}
        </p>
      </div>

      <div className="space-y-6 pt-4">
        
        {/* 1. Personal Hand Bag */}
        <div className="bg-white rounded-xl border border-slate-100 p-5 sm:p-6 shadow-sm flex flex-col md:flex-row gap-5 items-start">
          <div className="p-3 bg-slate-50 text-slate-500 rounded-xl shrink-0">
            <ShoppingBag className="h-6 w-6" />
          </div>
          <div className="space-y-3.5 flex-1">
            <h3 className="font-black text-sm sm:text-base text-blue-950 uppercase tracking-wider leading-none">
              {t('baggageGuide.personal.title')}
            </h3>
            <p className="text-xs text-slate-500 font-semibold leading-relaxed">
              {t('baggageGuide.personal.desc')}
            </p>
            <div className="grid grid-cols-2 gap-4 pt-1 text-2xs sm:text-xs font-bold text-slate-600">
              <div className="flex items-center gap-2">
                <Maximize className="h-4 w-4 text-slate-400 shrink-0" />
                <span>{t('baggageGuide.personal.dims')}</span>
              </div>
              <div className="flex items-center gap-2">
                <Scale className="h-4 w-4 text-slate-400 shrink-0" />
                <span>{t('baggageGuide.personal.weight')}</span>
              </div>
            </div>
          </div>
        </div>

        {/* 2. Cabin Bag 10kg */}
        <div className="bg-white rounded-xl border border-slate-100 p-5 sm:p-6 shadow-sm flex flex-col md:flex-row gap-5 items-start">
          <div className="p-3 bg-blue-50 text-blue-900 rounded-xl shrink-0">
            <Briefcase className="h-6 w-6" />
          </div>
          <div className="space-y-3.5 flex-1">
            <h3 className="font-black text-sm sm:text-base text-blue-950 uppercase tracking-wider leading-none">
              {t('baggageGuide.cabin.title')}
            </h3>
            <p className="text-xs text-slate-500 font-semibold leading-relaxed">
              {t('baggageGuide.cabin.desc')}
            </p>
            <div className="grid grid-cols-2 gap-4 pt-1 text-2xs sm:text-xs font-bold text-slate-600">
              <div className="flex items-center gap-2">
                <Maximize className="h-4 w-4 text-slate-400 shrink-0" />
                <span>{t('baggageGuide.cabin.dims')}</span>
              </div>
              <div className="flex items-center gap-2">
                <Scale className="h-4 w-4 text-slate-400 shrink-0" />
                <span>{t('baggageGuide.cabin.weight')}</span>
              </div>
            </div>
          </div>
        </div>

        {/* 3. Checked Baggage */}
        <div className="bg-white rounded-xl border border-slate-100 p-5 sm:p-6 shadow-sm flex flex-col md:flex-row gap-5 items-start">
          <div className="p-3 bg-indigo-50 text-indigo-900 rounded-xl shrink-0">
            <Briefcase className="h-7 w-7" />
          </div>
          <div className="space-y-3.5 flex-1">
            <h3 className="font-black text-sm sm:text-base text-blue-950 uppercase tracking-wider leading-none">
              {t('baggageGuide.checked.title')}
            </h3>
            <p className="text-xs text-slate-500 font-semibold leading-relaxed">
              {t('baggageGuide.checked.desc')}
            </p>
            <div className="grid grid-cols-2 gap-4 pt-1 text-2xs sm:text-xs font-bold text-slate-600">
              <div className="flex items-center gap-2">
                <Maximize className="h-4 w-4 text-slate-400 shrink-0" />
                <span>{t('baggageGuide.checked.dims')}</span>
              </div>
              <div className="flex items-center gap-2">
                <Scale className="h-4 w-4 text-slate-400 shrink-0" />
                <span>{t('baggageGuide.checked.weight')}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Prohibited items */}
        <div className="bg-red-50 border border-red-200 rounded-xl p-5 sm:p-6 flex gap-5 items-start">
          <div className="p-3 bg-red-100 text-red-600 rounded-xl shrink-0">
            <AlertTriangle className="h-6 w-6" />
          </div>
          <div className="space-y-2">
            <h3 className="font-black text-sm sm:text-base text-red-950 uppercase tracking-wider leading-none">
              {t('baggageGuide.prohibited.title')}
            </h3>
            <p className="text-xs text-red-800 font-medium leading-relaxed">
              {t('baggageGuide.prohibited.desc')}
            </p>
          </div>
        </div>

      </div>

    </div>
  );
}
