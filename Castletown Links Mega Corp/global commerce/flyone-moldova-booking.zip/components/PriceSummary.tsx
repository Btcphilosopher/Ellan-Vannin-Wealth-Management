'use client';

import React, { useState } from 'react';
import { useBooking } from '@/components/BookingProvider';
import { calculateTotal, TAXES_PER_PASSENGER } from '@/lib/bookingState';
import { Plane, ChevronUp, ChevronDown } from 'lucide-react';

interface PriceSummaryProps {
  onContinue?: () => void;
  continueLabel?: string;
  disableContinue?: boolean;
  showContinue?: boolean;
}

export default function PriceSummary({
  onContinue,
  continueLabel,
  disableContinue = false,
  showContinue = true,
}: PriceSummaryProps) {
  const { state, t, lang } = useBooking();
  const [isExpanded, setIsExpanded] = useState(false);

  const { base, taxes, baggage, seats, extras, total } = calculateTotal(state);

  const numPassengers = state.passengers.length || 1;
  const isRoundTrip = !!state.selectedReturn;

  const formatDate = (dateStr: string) => {
    if (!dateStr) return '';
    try {
      const d = new Date(dateStr);
      return d.toLocaleDateString(lang === 'ro' ? 'ro-RO' : 'en-US', {
        day: 'numeric',
        month: 'short',
      });
    } catch {
      return dateStr;
    }
  };

  const hasBaggage = baggage > 0;
  const hasSeats = seats > 0;
  const hasExtras = extras > 0;

  const renderBreakdown = () => (
    <div className="space-y-3.5 text-xs sm:text-sm">
      {/* Outbound */}
      {state.selectedOutbound && (
        <div className="flex items-start gap-2 text-slate-700">
          <Plane className="h-4 w-4 text-blue-900 shrink-0 mt-0.5 rotate-45" />
          <div className="flex-1 min-w-0">
            <span className="font-bold block truncate">
              {state.selectedOutbound.origin.code} → {state.selectedOutbound.destination.code}
            </span>
            <span className="text-2xs text-slate-400 block mt-0.5">
              {formatDate(state.selectedOutbound.departureTime)} · {state.selectedOutbound.flightNumber}
            </span>
          </div>
        </div>
      )}

      {/* Return */}
      {state.selectedReturn && (
        <div className="flex items-start gap-2 text-slate-700">
          <Plane className="h-4 w-4 text-blue-900 shrink-0 mt-0.5 -rotate-135" />
          <div className="flex-1 min-w-0">
            <span className="font-bold block truncate">
              {state.selectedReturn.origin.code} → {state.selectedReturn.destination.code}
            </span>
            <span className="text-2xs text-slate-400 block mt-0.5">
              {formatDate(state.selectedReturn.departureTime)} · {state.selectedReturn.flightNumber}
            </span>
          </div>
        </div>
      )}

      <hr className="border-slate-100" />

      {/* Breakdown Details */}
      <div className="space-y-2 text-slate-600 font-medium">
        <div className="flex justify-between items-center">
          <span>{t('summary.fare')} ({numPassengers} ×)</span>
          <span className="font-mono font-bold text-slate-800">€{base.toFixed(2)}</span>
        </div>

        <div className="flex justify-between items-center">
          <span>{t('summary.taxes')}</span>
          <span className="font-mono font-bold text-slate-800">€{taxes.toFixed(2)}</span>
        </div>

        {hasBaggage && (
          <div className="flex justify-between items-center">
            <span>{t('summary.baggage')}</span>
            <span className="font-mono font-bold text-slate-800">€{baggage.toFixed(2)}</span>
          </div>
        )}

        {hasSeats && (
          <div className="flex justify-between items-center">
            <span>{t('summary.seats')}</span>
            <span className="font-mono font-bold text-slate-800">€{seats.toFixed(2)}</span>
          </div>
        )}

        {hasExtras && (
          <div className="flex justify-between items-center">
            <span>{t('summary.extras')}</span>
            <span className="font-mono font-bold text-slate-800">€{extras.toFixed(2)}</span>
          </div>
        )}
      </div>

      <hr className="border-slate-100" />

      {/* Demo notice */}
      <p className="text-3xs text-slate-400 italic font-medium leading-normal bg-slate-50 p-2 rounded-lg border border-slate-100">
        {t('summary.demoNotice')}
      </p>
    </div>
  );

  return (
    <>
      {/* Desktop Panel View */}
      <div className="hidden lg:block w-full bg-white rounded-xl border border-slate-100 p-6 shadow-md sticky top-24 self-start">
        <h3 className="text-base font-black text-blue-950 uppercase tracking-wider mb-5">
          {t('summary.title')}
        </h3>

        <div className="space-y-5">
          {renderBreakdown()}

          <div className="pt-4 border-t border-slate-200">
            <div className="flex justify-between items-baseline mb-4">
              <span className="text-sm font-extrabold text-blue-950">{t('summary.total')}</span>
              <span className="text-2xl font-black font-mono text-blue-950">€{total.toFixed(2)}</span>
            </div>

            {showContinue && onContinue && (
              <button
                disabled={disableContinue}
                onClick={onContinue}
                className="w-full min-h-[48px] rounded-lg bg-blue-900 font-extrabold text-sm text-white uppercase tracking-wider shadow hover:bg-blue-800 active:scale-[0.98] transition-all disabled:opacity-50"
              >
                {continueLabel || t('passengersForm.continue')}
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Mobile Sticky Bottom Summary (aggregated fixed height within 15% mobile viewport limit) */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-slate-200 shadow-[0_-8px_30px_rgb(0,0,0,0.08)]">
        
        {/* Expanded overlay menu */}
        {isExpanded && (
          <div className="p-4 border-b border-slate-100 bg-slate-50 max-h-[300px] overflow-y-auto animate-slideUp">
            <h4 className="text-xs font-bold text-blue-950 uppercase tracking-widest mb-3">
              {t('summary.title')}
            </h4>
            {renderBreakdown()}
          </div>
        )}

        {/* Small sticky row (height limited to fit mobile rules nicely) */}
        <div className="flex items-center justify-between px-4 py-3 h-16">
          <button
            type="button"
            onClick={() => setIsExpanded(!isExpanded)}
            className="flex items-center gap-1.5 py-1 text-slate-700 focus:outline-none"
          >
            <div>
              <span className="text-2xs font-extrabold text-slate-400 uppercase tracking-wider block leading-none">
                {t('summary.total')}
              </span>
              <span className="text-lg font-black font-mono text-blue-950">
                €{total.toFixed(2)}
              </span>
            </div>
            {isExpanded ? <ChevronDown className="h-4 w-4 text-slate-400" /> : <ChevronUp className="h-4 w-4 text-slate-400" />}
          </button>

          {showContinue && onContinue && (
            <button
              disabled={disableContinue}
              onClick={onContinue}
              className="px-5 min-h-[44px] flex items-center justify-center rounded-lg bg-blue-900 font-bold text-xs text-white uppercase tracking-wider hover:bg-blue-800 active:scale-[0.98] transition-all disabled:opacity-50"
            >
              {continueLabel || t('passengersForm.continue')}
            </button>
          )}
        </div>
      </div>
    </>
  );
}
