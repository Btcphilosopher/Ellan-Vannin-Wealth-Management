'use client';

import React from 'react';
import { Flight } from '@/types/booking';
import { useBooking } from '@/components/BookingProvider';
import { Plane, Clock } from 'lucide-react';

interface FlightCardProps {
  flight: Flight;
  isSelected: boolean;
  onSelect: () => void;
}

export default function FlightCard({ flight, isSelected, onSelect }: FlightCardProps) {
  const { t, lang } = useBooking();

  const formatTime = (timeStr: string) => {
    try {
      const date = new Date(timeStr);
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
    } catch {
      return timeStr;
    }
  };

  const getDurationString = (mins: number) => {
    const hours = Math.floor(mins / 60);
    const m = mins % 60;
    return `${hours}h ${m > 0 ? `${m}m` : ''}`;
  };

  return (
    <div
      onClick={onSelect}
      className={`group w-full rounded-xl border p-4 sm:p-5 transition-all cursor-pointer flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 sm:gap-6 ${
        isSelected
          ? 'border-blue-900 bg-blue-50/40 ring-1 ring-blue-950'
          : 'border-slate-200 bg-white hover:border-slate-300 hover:shadow-sm'
      }`}
    >
      {/* Flight visual time layout */}
      <div className="flex-1 flex items-center justify-between gap-4 max-w-lg">
        {/* Origin */}
        <div className="text-left w-24">
          <span className="font-mono text-xl sm:text-2xl font-black text-blue-950 tracking-tight leading-none block">
            {formatTime(flight.departureTime)}
          </span>
          <span className="font-bold text-xs sm:text-sm text-slate-500 block mt-1.5 uppercase">
            {flight.origin.code}
          </span>
          <span className="text-3xs text-slate-400 font-semibold block mt-0.5 truncate max-w-[80px]">
            {flight.origin.city}
          </span>
        </div>

        {/* Path Indicator */}
        <div className="flex-1 flex flex-col items-center justify-center relative px-2">
          <span className="text-3xs text-slate-400 font-extrabold uppercase tracking-widest leading-none mb-1">
            {getDurationString(flight.durationMinutes)}
          </span>
          <div className="w-full flex items-center justify-center relative">
            <div className="absolute left-0 right-0 h-0.5 bg-slate-200"></div>
            <div className="relative z-10 flex h-6 w-6 items-center justify-center rounded-full bg-white border border-slate-200 shadow-sm group-hover:scale-105 transition-transform">
              <Plane className="h-3 w-3 text-blue-900 rotate-45" />
            </div>
          </div>
          <span className="text-2xs font-extrabold text-emerald-600 uppercase tracking-widest mt-1.5 leading-none">
            {t('results.direct')}
          </span>
        </div>

        {/* Destination */}
        <div className="text-right w-24">
          <span className="font-mono text-xl sm:text-2xl font-black text-blue-950 tracking-tight leading-none block">
            {formatTime(flight.arrivalTime)}
          </span>
          <span className="font-bold text-xs sm:text-sm text-slate-500 block mt-1.5 uppercase">
            {flight.destination.code}
          </span>
          <span className="text-3xs text-slate-400 font-semibold block mt-0.5 truncate max-w-[80px] ml-auto">
            {flight.destination.city}
          </span>
        </div>
      </div>

      <hr className="sm:hidden border-slate-100" />

      {/* Flight details and Price Selection action */}
      <div className="flex sm:flex-col items-center sm:items-end justify-between sm:justify-center gap-3">
        <div className="text-left sm:text-right">
          <span className="text-4xs font-extrabold text-slate-400 uppercase tracking-widest block leading-none">
            {flight.aircraft} · {flight.flightNumber}
          </span>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-3xs font-semibold text-slate-400 uppercase">
              {t('results.fromPrice')}
            </span>
            <span className="text-lg sm:text-xl font-black font-mono text-blue-950">
              €{flight.basePrice.toFixed(2)}
            </span>
          </div>
        </div>

        {/* Button (min height 44px for tactile taps) */}
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onSelect();
          }}
          className={`px-5 min-h-[44px] flex items-center justify-center text-xs font-bold rounded-lg uppercase tracking-wider transition-all shadow-sm ${
            isSelected
              ? 'bg-blue-900 text-white shadow-blue-900/10'
              : 'bg-slate-100 text-slate-800 hover:bg-slate-200'
          }`}
        >
          {isSelected ? t('results.selectedBtn') : t('results.chooseBtn')}
        </button>
      </div>

    </div>
  );
}
