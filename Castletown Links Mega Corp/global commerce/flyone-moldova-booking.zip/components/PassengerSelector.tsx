'use client';

import React, { useState, useRef, useEffect } from 'react';
import { Users, Plus, Minus, ChevronDown } from 'lucide-react';
import { useBooking } from '@/components/BookingProvider';

interface PassengerSelectorProps {
  adults: number;
  childrenCount: number;
  infants: number;
  onChange: (counts: { adults: number; children: number; infants: number }) => void;
}

export default function PassengerSelector({
  adults,
  childrenCount,
  infants,
  onChange,
}: PassengerSelectorProps) {
  const { t } = useBooking();
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const totalPassengers = adults + childrenCount + infants;

  const handleUpdate = (type: 'adults' | 'children' | 'infants', op: 'add' | 'sub') => {
    let newAdults = adults;
    let newChildren = childrenCount;
    let newInfants = infants;

    if (type === 'adults') {
      newAdults = op === 'add' ? adults + 1 : Math.max(1, adults - 1);
      // Ensure infants don't exceed adults
      if (newInfants > newAdults) {
        newInfants = newAdults;
      }
    } else if (type === 'children') {
      newChildren = op === 'add' ? childrenCount + 1 : Math.max(0, childrenCount - 1);
    } else if (type === 'infants') {
      newInfants = op === 'add' ? infants + 1 : Math.max(0, infants - 1);
      // Infants cannot exceed adults
      if (newInfants > newAdults) {
        newInfants = newAdults;
      }
    }

    onChange({ adults: newAdults, children: newChildren, infants: newInfants });
  };

  return (
    <div className="relative w-full" ref={containerRef}>
      <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">
        {t('search.passengers')}
      </label>

      {/* Popover trigger */}
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="flex w-full min-h-[52px] items-center justify-between rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-left transition-all hover:border-blue-300 hover:shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-900 focus:ring-offset-1"
      >
        <div className="flex items-center gap-3">
          <Users className="h-5 w-5 text-blue-900 shrink-0" />
          <span className="font-bold text-slate-800 text-sm sm:text-base">
            {totalPassengers} {totalPassengers === 1 ? 'Pasager' : 'Pasageri'}
          </span>
        </div>
        <ChevronDown className="h-4 w-4 text-slate-500 shrink-0 transition-transform duration-200" style={{ transform: isOpen ? 'rotate(180deg)' : 'none' }} />
      </button>

      {/* Popover Content */}
      {isOpen && (
        <div className="absolute right-0 mt-1 z-50 w-full sm:w-[320px] rounded-xl border border-slate-200 bg-white p-4 shadow-xl animate-fadeIn">
          <div className="space-y-4">
            
            {/* Adults Counter */}
            <div className="flex items-center justify-between">
              <div>
                <span className="font-bold text-slate-800 text-sm block">
                  {t('search.adults')}
                </span>
                <span className="text-slate-400 text-xs">
                  {t('search.adultsDesc')}
                </span>
              </div>
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  disabled={adults <= 1}
                  onClick={() => handleUpdate('adults', 'sub')}
                  className="flex h-8 w-8 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-600 hover:bg-slate-50 disabled:opacity-50"
                >
                  <Minus className="h-4 w-4" />
                </button>
                <span className="font-mono font-bold text-sm w-4 text-center">{adults}</span>
                <button
                  type="button"
                  onClick={() => handleUpdate('adults', 'add')}
                  className="flex h-8 w-8 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-600 hover:bg-slate-50"
                >
                  <Plus className="h-4 w-4" />
                </button>
              </div>
            </div>

            <hr className="border-slate-100" />

            {/* Children Counter */}
            <div className="flex items-center justify-between">
              <div>
                <span className="font-bold text-slate-800 text-sm block">
                  {t('search.children')}
                </span>
                <span className="text-slate-400 text-xs">
                  {t('search.childrenDesc')}
                </span>
              </div>
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  disabled={childrenCount <= 0}
                  onClick={() => handleUpdate('children', 'sub')}
                  className="flex h-8 w-8 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-600 hover:bg-slate-50 disabled:opacity-50"
                >
                  <Minus className="h-4 w-4" />
                </button>
                <span className="font-mono font-bold text-sm w-4 text-center">{childrenCount}</span>
                <button
                  type="button"
                  onClick={() => handleUpdate('children', 'add')}
                  className="flex h-8 w-8 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-600 hover:bg-slate-50"
                >
                  <Plus className="h-4 w-4" />
                </button>
              </div>
            </div>

            <hr className="border-slate-100" />

            {/* Infants Counter */}
            <div className="flex items-center justify-between">
              <div>
                <span className="font-bold text-slate-800 text-sm block">
                  {t('search.infants')}
                </span>
                <span className="text-slate-400 text-xs">
                  {t('search.infantsDesc')}
                </span>
              </div>
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  disabled={infants <= 0}
                  onClick={() => handleUpdate('infants', 'sub')}
                  className="flex h-8 w-8 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-600 hover:bg-slate-50 disabled:opacity-50"
                >
                  <Minus className="h-4 w-4" />
                </button>
                <span className="font-mono font-bold text-sm w-4 text-center">{infants}</span>
                <button
                  type="button"
                  disabled={infants >= adults}
                  onClick={() => handleUpdate('infants', 'add')}
                  className="flex h-8 w-8 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-600 hover:bg-slate-50 disabled:opacity-50"
                >
                  <Plus className="h-4 w-4" />
                </button>
              </div>
            </div>

            <div className="pt-2">
              <button
                type="button"
                onClick={() => setIsOpen(false)}
                className="w-full rounded-lg bg-blue-900 py-2 text-center text-xs font-bold text-white shadow hover:bg-blue-800 transition-colors"
              >
                Done
              </button>
            </div>

          </div>
        </div>
      )}
    </div>
  );
}
