'use client';

import React, { useState, useRef, useEffect } from 'react';
import { Airport } from '@/types/booking';
import { AIRPORTS } from '@/lib/flightEngine';
import { Search, MapPin, X } from 'lucide-react';
import { useBooking } from '@/components/BookingProvider';

interface AirportSelectorProps {
  label: string;
  selectedAirport: Airport | null;
  onSelect: (airport: Airport) => void;
  excludeCode?: string;
}

export default function AirportSelector({
  label,
  selectedAirport,
  onSelect,
  excludeCode,
}: AirportSelectorProps) {
  const { t } = useBooking();
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown on outside click
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const filteredAirports = AIRPORTS.filter(airport => {
    if (excludeCode && airport.code === excludeCode) return false;
    const q = searchQuery.toLowerCase();
    return (
      airport.name.toLowerCase().includes(q) ||
      airport.code.toLowerCase().includes(q) ||
      airport.city.toLowerCase().includes(q) ||
      airport.country.toLowerCase().includes(q)
    );
  });

  // Group airports
  const moldova = filteredAirports.filter(a => a.country === 'Moldova');
  const romania = filteredAirports.filter(a => a.country === 'România');
  const europe = filteredAirports.filter(a => a.country !== 'Moldova' && a.country !== 'România');

  const handleSelect = (airport: Airport) => {
    onSelect(airport);
    setIsOpen(false);
    setSearchQuery('');
  };

  return (
    <div className="relative w-full" ref={dropdownRef}>
      <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">
        {label}
      </label>

      {/* Selector button (min touch target height 44px) */}
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="flex w-full min-h-[52px] items-center justify-between rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-left transition-all hover:border-blue-300 hover:shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-900 focus:ring-offset-1"
      >
        <div className="flex items-center gap-3">
          <MapPin className="h-5 w-5 text-blue-900 shrink-0" />
          <div>
            {selectedAirport ? (
              <>
                <span className="font-bold text-slate-800 text-sm sm:text-base">
                  {selectedAirport.city}
                </span>
                <span className="ml-1.5 font-semibold text-slate-400 text-xs sm:text-sm">
                  ({selectedAirport.code})
                </span>
              </>
            ) : (
              <span className="text-slate-400 text-sm">
                {t('search.placeholderAirport')}
              </span>
            )}
          </div>
        </div>
      </button>

      {/* Dropdown list */}
      {isOpen && (
        <div className="absolute left-0 mt-1 z-50 w-full rounded-xl border border-slate-200 bg-white shadow-xl max-h-[380px] flex flex-col overflow-hidden animate-fadeIn">
          {/* Search Header */}
          <div className="flex items-center gap-2 border-b border-slate-100 p-3 bg-slate-50">
            <Search className="h-4 w-4 text-slate-400 shrink-0" />
            <input
              type="text"
              autoFocus
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder={t('search.placeholderAirport')}
              className="w-full bg-transparent text-sm text-slate-800 focus:outline-none placeholder-slate-400"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="rounded-full p-1 hover:bg-slate-200 text-slate-500"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            )}
          </div>

          {/* List Content */}
          <div className="overflow-y-auto flex-1 py-2 text-sm max-h-[320px]">
            {filteredAirports.length === 0 ? (
              <div className="py-6 text-center text-slate-400 text-xs">
                No destinations match your search
              </div>
            ) : (
              <>
                {/* Moldova Group */}
                {moldova.length > 0 && (
                  <div>
                    <div className="bg-slate-50 px-4 py-1.5 text-2xs font-extrabold text-slate-400 uppercase tracking-wider">
                      Moldova
                    </div>
                    {moldova.map(airport => (
                      <button
                        key={airport.code}
                        type="button"
                        onClick={() => handleSelect(airport)}
                        className="flex w-full items-center justify-between px-4 py-3 text-left hover:bg-slate-50 focus:bg-slate-50"
                      >
                        <div>
                          <span className="font-bold text-slate-800">{airport.city}</span>
                          <span className="text-slate-400 text-xs block">{airport.name}</span>
                        </div>
                        <span className="font-mono font-bold text-xs bg-slate-100 rounded px-2 py-1 text-slate-500">
                          {airport.code}
                        </span>
                      </button>
                    ))}
                  </div>
                )}

                {/* Romania Group */}
                {romania.length > 0 && (
                  <div>
                    <div className="bg-slate-50 px-4 py-1.5 text-2xs font-extrabold text-slate-400 uppercase tracking-wider">
                      România
                    </div>
                    {romania.map(airport => (
                      <button
                        key={airport.code}
                        type="button"
                        onClick={() => handleSelect(airport)}
                        className="flex w-full items-center justify-between px-4 py-3 text-left hover:bg-slate-50 focus:bg-slate-50"
                      >
                        <div>
                          <span className="font-bold text-slate-800">{airport.city}</span>
                          <span className="text-slate-400 text-xs block">{airport.name}</span>
                        </div>
                        <span className="font-mono font-bold text-xs bg-slate-100 rounded px-2 py-1 text-slate-500">
                          {airport.code}
                        </span>
                      </button>
                    ))}
                  </div>
                )}

                {/* Europe Group */}
                {europe.length > 0 && (
                  <div>
                    <div className="bg-slate-50 px-4 py-1.5 text-2xs font-extrabold text-slate-400 uppercase tracking-wider">
                      Europa
                    </div>
                    {europe.map(airport => (
                      <button
                        key={airport.code}
                        type="button"
                        onClick={() => handleSelect(airport)}
                        className="flex w-full items-center justify-between px-4 py-3 text-left hover:bg-slate-50 focus:bg-slate-50 animate-fadeIn"
                      >
                        <div>
                          <span className="font-bold text-slate-800">{airport.city}</span>
                          <span className="text-slate-400 text-xs block">{airport.name}, {airport.country}</span>
                        </div>
                        <span className="font-mono font-bold text-xs bg-slate-100 rounded px-2 py-1 text-slate-500">
                          {airport.code}
                        </span>
                      </button>
                    ))}
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
