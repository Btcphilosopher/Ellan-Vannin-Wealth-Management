'use client';

import React, { useState } from 'react';
import { useBooking } from '@/components/BookingProvider';
import { CheckCircle2, Download, Mail, ArrowRight, Plane, User, Info } from 'lucide-react';

export default function BookingConfirmation() {
  const { state, t, lang, setStep } = useBooking();
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const booking = state.createdBooking;
  if (!booking) return null;

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 2500);
  };

  const handleAction = (serviceKey: string) => {
    showToast(t('confirmation.simulatedAction'));
  };

  const formatTime = (timeStr: string) => {
    try {
      const date = new Date(timeStr);
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
    } catch {
      return timeStr;
    }
  };

  const formatDate = (dateStr: string) => {
    try {
      const d = new Date(dateStr);
      return d.toLocaleDateString(lang === 'ro' ? 'ro-RO' : 'en-US', {
        weekday: 'short',
        day: 'numeric',
        month: 'short',
        year: 'numeric',
      });
    } catch {
      return dateStr;
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6 pb-16 animate-fadeIn">
      
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 bg-slate-900 text-white text-xs font-bold px-4 py-2.5 rounded-full shadow-lg flex items-center gap-2 animate-fadeIn">
          <Info className="h-4 w-4 text-amber-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Success Hero Header */}
      <div className="bg-white rounded-xl border border-slate-100 p-6 sm:p-8 text-center space-y-4 shadow-sm">
        <div className="flex justify-center">
          <CheckCircle2 className="h-14 w-14 text-emerald-600" />
        </div>
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-blue-950 uppercase tracking-wider">
            {t('confirmation.success')}
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 font-semibold mt-1">
            {t('confirmation.subtitle')}
          </p>
        </div>

        {/* Reference Ticket Badge */}
        <div className="inline-block bg-blue-50 border border-blue-200 rounded-lg px-6 py-3.5">
          <span className="block text-4xs font-extrabold text-blue-950 uppercase tracking-widest leading-none mb-1">
            {t('confirmation.refCode')}
          </span>
          <span className="block text-2xl font-black font-mono text-blue-900 tracking-wide">
            {booking.reference}
          </span>
        </div>
      </div>

      {/* Flight Detail Segment */}
      <div className="bg-white rounded-xl border border-slate-100 p-5 sm:p-6 shadow-sm space-y-5">
        <h3 className="font-black text-xs sm:text-sm text-blue-950 uppercase tracking-wider border-b border-slate-100 pb-2.5">
          {t('confirmation.flightDetails')}
        </h3>

        <div className="space-y-5">
          {/* Outbound */}
          <div className="flex items-start gap-3">
            <Plane className="h-5 w-5 text-blue-900 shrink-0 mt-0.5 rotate-45" />
            <div className="flex-1 min-w-0">
              <span className="text-2xs font-extrabold text-blue-900 uppercase tracking-wider block">
                {t('results.outbound')}
              </span>
              <div className="flex items-center gap-2 mt-1 font-bold text-slate-800 text-sm">
                <span>{booking.outboundFlight.origin.city} ({booking.outboundFlight.origin.code})</span>
                <ArrowRight className="h-4 w-4 text-slate-400 shrink-0" />
                <span>{booking.outboundFlight.destination.city} ({booking.outboundFlight.destination.code})</span>
              </div>
              <p className="text-xs text-slate-400 font-semibold mt-1">
                {formatDate(booking.outboundFlight.departureTime)} · {formatTime(booking.outboundFlight.departureTime)} - {formatTime(booking.outboundFlight.arrivalTime)} · {booking.outboundFlight.flightNumber}
              </p>
            </div>
          </div>

          {/* Return */}
          {booking.returnFlight && (
            <div className="flex items-start gap-3 pt-4 border-t border-slate-100">
              <Plane className="h-5 w-5 text-blue-900 shrink-0 mt-0.5 -rotate-135" />
              <div className="flex-1 min-w-0">
                <span className="text-2xs font-extrabold text-blue-900 uppercase tracking-wider block">
                  {t('results.return')}
                </span>
                <div className="flex items-center gap-2 mt-1 font-bold text-slate-800 text-sm">
                  <span>{booking.returnFlight.origin.city} ({booking.returnFlight.origin.code})</span>
                  <ArrowRight className="h-4 w-4 text-slate-400 shrink-0" />
                  <span>{booking.returnFlight.destination.city} ({booking.returnFlight.destination.code})</span>
                </div>
                <p className="text-xs text-slate-400 font-semibold mt-1">
                  {formatDate(booking.returnFlight.departureTime)} · {formatTime(booking.returnFlight.departureTime)} - {formatTime(booking.returnFlight.arrivalTime)} · {booking.returnFlight.flightNumber}
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Passengers Summary */}
      <div className="bg-white rounded-xl border border-slate-100 p-5 sm:p-6 shadow-sm space-y-4">
        <h3 className="font-black text-xs sm:text-sm text-blue-950 uppercase tracking-wider border-b border-slate-100 pb-2.5">
          {t('confirmation.passengerDetails')}
        </h3>

        <div className="divide-y divide-slate-100 space-y-3.5">
          {booking.passengers.map((p, idx) => (
            <div key={p.id} className="flex items-start justify-between gap-4 pt-3 first:pt-0">
              <div className="flex items-start gap-3">
                <User className="h-4 w-4 text-slate-400 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-slate-800 text-sm block">
                    {p.firstName} {p.lastName}
                  </span>
                  <span className="text-2xs text-slate-400 font-semibold block mt-0.5">
                    {t('passengersForm.docType')}: {p.docType === 'passport' ? t('passengersForm.passport') : t('passengersForm.idCard')} ({p.docNumber})
                  </span>
                </div>
              </div>

              {p.seat && (
                <span className="font-mono font-bold text-xs bg-blue-50 text-blue-900 border border-blue-200 px-2 py-1 rounded">
                  Loc: {p.seat}
                </span>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Quick Action Dashboard */}
      <div className="bg-white rounded-xl border border-slate-100 p-5 sm:p-6 shadow-sm space-y-4">
        <h3 className="font-black text-xs sm:text-sm text-blue-950 uppercase tracking-wider border-b border-slate-100 pb-2.5">
          {t('confirmation.actions.title')}
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          
          <button
            onClick={() => handleAction('download')}
            className="flex items-center gap-2.5 border border-slate-200 rounded-lg p-3 text-left hover:bg-slate-50 transition-colors"
          >
            <Download className="h-5 w-5 text-blue-900 shrink-0" />
            <div>
              <span className="font-bold text-slate-800 text-xs block">
                {t('confirmation.actions.download')}
              </span>
            </div>
          </button>

          <button
            onClick={() => handleAction('email')}
            className="flex items-center gap-2.5 border border-slate-200 rounded-lg p-3 text-left hover:bg-slate-50 transition-colors"
          >
            <Mail className="h-5 w-5 text-blue-900 shrink-0" />
            <div>
              <span className="font-bold text-slate-800 text-xs block">
                {t('confirmation.actions.email')}
              </span>
            </div>
          </button>

        </div>
      </div>

      <div className="text-center pt-2">
        <button
          onClick={() => setStep('home')}
          className="inline-flex min-h-[48px] items-center justify-center rounded-lg bg-blue-900 px-6 py-2.5 font-bold text-sm text-white uppercase tracking-wider shadow hover:bg-blue-800 transition-colors"
        >
          {t('confirmation.actions.home')}
        </button>
      </div>

    </div>
  );
}
