'use client';

import React, { useState } from 'react';
import { useBooking } from '@/components/BookingProvider';
import { Menu, X, Globe, User, Plane } from 'lucide-react';

export default function Header() {
  const { lang, setLang, setStep, t, resetBooking } = useBooking();
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleNav = (step: any) => {
    if (step === 'home') {
      resetBooking();
    } else {
      setStep(step);
    }
    setMobileOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b border-slate-100 bg-white/95 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        
        {/* Zone 1: Brand Wordmark (Single text element layout) */}
        <button
          onClick={() => handleNav('home')}
          className="group flex items-center gap-2 text-left"
        >
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-900 text-white transition-transform group-hover:scale-105">
            <Plane className="h-5 w-5 rotate-45 text-amber-400" />
          </div>
          <div>
            <span className="block text-lg font-black tracking-tight text-blue-950 uppercase leading-none">
              {t('nav.brand')}
            </span>
            <span className="block text-xs font-bold tracking-widest text-slate-500 uppercase leading-none mt-0.5">
              {t('nav.subBrand')}
            </span>
          </div>
        </button>

        {/* Zone 2: Navigation Links (4-6 links, single line) */}
        <nav className="hidden md:flex items-center gap-8 text-sm font-semibold text-slate-600">
          <button
            onClick={() => handleNav('home')}
            className="hover:text-blue-900 hover:underline underline-offset-4 transition-colors"
          >
            {t('nav.flights')}
          </button>
          <button
            onClick={() => handleNav('destinations')}
            className="hover:text-blue-900 hover:underline underline-offset-4 transition-colors"
          >
            {t('nav.destinations')}
          </button>
          <button
            onClick={() => handleNav('baggage-info')}
            className="hover:text-blue-900 hover:underline underline-offset-4 transition-colors"
          >
            {t('nav.baggage')}
          </button>
          <button
            onClick={() => handleNav('check-in')}
            className="hover:text-blue-900 hover:underline underline-offset-4 transition-colors"
          >
            {t('nav.checkin')}
          </button>
          <button
            onClick={() => handleNav('my-booking')}
            className="hover:text-blue-900 hover:underline underline-offset-4 transition-colors font-bold text-blue-900"
          >
            {t('nav.myBooking')}
          </button>
        </nav>

        {/* Zone 3: Primary Actions (Language switcher, Account) */}
        <div className="hidden md:flex items-center gap-4">
          <div className="flex items-center gap-1 rounded-md bg-slate-50 p-1 border border-slate-200">
            <button
              onClick={() => setLang('ro')}
              className={`rounded px-2 py-1 text-xs font-bold transition-all ${
                lang === 'ro'
                  ? 'bg-blue-900 text-white shadow-sm'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              RO
            </button>
            <button
              onClick={() => setLang('en')}
              className={`rounded px-2 py-1 text-xs font-bold transition-all ${
                lang === 'en'
                  ? 'bg-blue-900 text-white shadow-sm'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              EN
            </button>
          </div>

          <button className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-bold text-slate-700 hover:bg-slate-50 transition-colors">
            <User className="h-4 w-4 text-slate-500" />
            <span>{t('nav.account')}</span>
          </button>
        </div>

        {/* Mobile menu trigger button */}
        <div className="flex items-center gap-2 md:hidden">
          <button
            onClick={() => setLang(lang === 'ro' ? 'en' : 'ro')}
            className="flex items-center gap-1 rounded-md bg-slate-50 border border-slate-200 px-2 py-1.5 text-xs font-bold text-slate-700"
          >
            <Globe className="h-3.5 w-3.5" />
            <span>{lang.toUpperCase()}</span>
          </button>
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="inline-flex h-10 w-10 items-center justify-center rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50"
            aria-label="Toggle menu"
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileOpen && (
        <div className="md:hidden border-t border-slate-100 bg-white px-4 py-4 space-y-3 shadow-lg animate-fadeIn">
          <button
            onClick={() => handleNav('home')}
            className="block w-full text-left py-2.5 font-semibold text-slate-700 border-b border-slate-50"
          >
            {t('nav.flights')}
          </button>
          <button
            onClick={() => handleNav('destinations')}
            className="block w-full text-left py-2.5 font-semibold text-slate-700 border-b border-slate-50"
          >
            {t('nav.destinations')}
          </button>
          <button
            onClick={() => handleNav('baggage-info')}
            className="block w-full text-left py-2.5 font-semibold text-slate-700 border-b border-slate-50"
          >
            {t('nav.baggage')}
          </button>
          <button
            onClick={() => handleNav('check-in')}
            className="block w-full text-left py-2.5 font-semibold text-slate-700 border-b border-slate-50"
          >
            {t('nav.checkin')}
          </button>
          <button
            onClick={() => handleNav('my-booking')}
            className="block w-full text-left py-2.5 font-bold text-blue-900 border-b border-slate-50"
          >
            {t('nav.myBooking')}
          </button>

          <button className="flex w-full items-center justify-center gap-2 rounded-lg bg-blue-900 px-4 py-3 text-sm font-bold text-white shadow">
            <User className="h-4 w-4" />
            <span>{t('nav.account')}</span>
          </button>
        </div>
      )}
    </header>
  );
}
