'use client';

import React, { useState, useEffect } from 'react';
import { useBooking } from '@/components/BookingProvider';
import { fetchDestinations } from '@/lib/apiClient';
import { Search, MapPin, ArrowRight, Loader2 } from 'lucide-react';
import Image from 'next/image';

interface Destination {
  code: string;
  city: string;
  country: string;
  name: string;
  basePrice: number;
  image: string;
  desc: {
    ro: string;
    en: string;
  };
}

export default function DestinationsPage() {
  const { t, lang, setStep, setSearchQuery } = useBooking();
  const [destinations, setDestinations] = useState<Destination[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    async function load() {
      try {
        const data = await fetchDestinations();
        setDestinations(data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  const handleBook = (dest: Destination) => {
    // Preset booking search query
    setSearchQuery({
      originCode: 'RMO',
      destinationCode: dest.code,
      departureDate: '2026-10-12',
      returnDate: '2026-10-19',
      tripType: 'roundTrip',
      passengers: { adults: 1, children: 0, infants: 0 },
    });
    setStep('home');
  };

  const filtered = destinations.filter(d => {
    const q = search.toLowerCase();
    return (
      d.city.toLowerCase().includes(q) ||
      d.country.toLowerCase().includes(q) ||
      d.code.toLowerCase().includes(q)
    );
  });

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-16 animate-fadeIn px-4">
      
      {/* Intro Header */}
      <div className="text-center max-w-xl mx-auto space-y-3">
        <h2 className="text-xl sm:text-2xl font-black text-blue-950 uppercase tracking-wider balance">
          {t('destinationsPage.title')}
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 font-semibold balance">
          {t('destinationsPage.subtitle')}
        </p>
      </div>

      {/* Dynamic Search Box */}
      <div className="max-w-md mx-auto relative">
        <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400 pointer-events-none" />
        <input
          type="text"
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder={t('destinationsPage.searchPlaceholder')}
          className="w-full min-h-[48px] pl-11 pr-4 py-2.5 text-sm font-semibold text-slate-800 bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900"
        />
      </div>

      {loading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="h-8 w-8 text-blue-900 animate-spin" />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 pt-4">
          {filtered.map(dest => (
            <div
              key={dest.code}
              className="group bg-white rounded-xl border border-slate-100 overflow-hidden shadow-sm hover:shadow-md transition-all flex flex-col h-full"
            >
              {/* Destination Image (with Next.js Image component optimized, no-referrer rule applied) */}
              <div className="relative h-48 w-full bg-slate-100 overflow-hidden">
                <Image
                  src={dest.image}
                  alt={dest.city}
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-3 left-3 bg-blue-900 text-white font-mono font-bold text-xs rounded px-2 py-1 shadow-sm uppercase">
                  {dest.code}
                </div>
              </div>

              {/* Card Body */}
              <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                <div>
                  <div className="flex items-center gap-1.5 text-slate-500 text-2xs font-extrabold uppercase tracking-widest leading-none mb-1">
                    <MapPin className="h-3.5 w-3.5" />
                    <span>{dest.country}</span>
                  </div>
                  <h3 className="text-lg font-black text-blue-950 uppercase tracking-wider">
                    {dest.city}
                  </h3>
                  <p className="text-xs text-slate-500 font-semibold leading-relaxed mt-2.5">
                    {lang === 'ro' ? dest.desc.ro : dest.desc.en}
                  </p>
                </div>

                {/* Booking CTA Button */}
                <div className="pt-2 border-t border-slate-50">
                  <button
                    type="button"
                    onClick={() => handleBook(dest)}
                    className="w-full min-h-[44px] flex items-center justify-between rounded-lg bg-blue-900 px-4 py-2 text-xs font-black text-white uppercase tracking-wider hover:bg-blue-800 transition-colors"
                  >
                    <span>{t('destinationsPage.bookNow', { price: `€${dest.basePrice.toFixed(2)}` })}</span>
                    <ArrowRight className="h-4 w-4 shrink-0 transition-transform group-hover:translate-x-1" />
                  </button>
                </div>
              </div>

            </div>
          ))}
        </div>
      )}

    </div>
  );
}
