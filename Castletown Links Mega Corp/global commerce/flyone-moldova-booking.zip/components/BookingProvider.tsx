'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';
import { Booking, BookingContact, FareClass, Flight, FlightSearchQuery, Passenger } from '@/types/booking';
import { BookingFlowState, INITIAL_STATE, INITIAL_CONTACT } from '@/lib/bookingState';
import { Language, translations, getTranslationValue } from '@/i18n';

interface BookingContextProps {
  state: BookingFlowState;
  lang: Language;
  t: (keyPath: string, replacements?: Record<string, string | number>) => string;
  setLang: (lang: Language) => void;
  setStep: (step: BookingFlowState['step']) => void;
  setSearchQuery: (query: FlightSearchQuery | null) => void;
  setOutboundFlights: (flights: Flight[]) => void;
  setReturnFlights: (flights: Flight[]) => void;
  selectOutbound: (flight: Flight | null) => void;
  selectReturn: (flight: Flight | null) => void;
  selectFare: (fare: FareClass | null) => void;
  setPassengers: (passengers: Passenger[]) => void;
  updatePassenger: (index: number, updated: Partial<Passenger>) => void;
  updatePassengerBaggage: (index: number, type: 'cabin' | 'checked20' | 'checked32', change: number | boolean) => void;
  updatePassengerSeat: (index: number, seat: string | null) => void;
  setContact: (contact: BookingContact) => void;
  updateExtras: (key: 'priority' | 'assistance' | 'smsNotification', value: boolean) => void;
  setCreatedBooking: (booking: Booking | null) => void;
  resetBooking: () => void;
}

const BookingContext = createContext<BookingContextProps | undefined>(undefined);

export function BookingProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<BookingFlowState>(INITIAL_STATE);
  const [lang, setLangState] = useState<Language>('ro');
  const [isHydrated, setIsHydrated] = useState(false);

  // Hydrate state from localStorage on client-side mount
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const savedState = localStorage.getItem('flyone_active_booking_state');
      const savedLang = localStorage.getItem('flyone_active_language');

      if (savedState) {
        try {
          const parsed = JSON.parse(savedState);
          setTimeout(() => {
            setState(parsed);
          }, 0);
        } catch (e) {
          console.error('Failed to parse saved booking state', e);
        }
      }

      if (savedLang === 'ro' || savedLang === 'en') {
        setTimeout(() => {
          setLangState(savedLang as Language);
        }, 0);
      }
      setTimeout(() => {
        setIsHydrated(true);
      }, 0);
    }
  }, []);

  // Sync state changes to localStorage
  useEffect(() => {
    if (isHydrated && typeof window !== 'undefined') {
      localStorage.setItem('flyone_active_booking_state', JSON.stringify(state));
    }
  }, [state, isHydrated]);

  const setLang = (newLang: Language) => {
    setLangState(newLang);
    if (typeof window !== 'undefined') {
      localStorage.setItem('flyone_active_language', newLang);
    }
  };

  const t = (keyPath: string, replacements?: Record<string, string | number>) => {
    const dict = translations[lang];
    return getTranslationValue(dict, keyPath, replacements);
  };

  const setStep = (step: BookingFlowState['step']) => {
    setState(prev => ({ ...prev, step }));
  };

  const setSearchQuery = (searchQuery: FlightSearchQuery | null) => {
    setState(prev => ({ ...prev, searchQuery }));
  };

  const setOutboundFlights = (outboundFlights: Flight[]) => {
    setState(prev => ({ ...prev, outboundFlights }));
  };

  const setReturnFlights = (returnFlights: Flight[]) => {
    setState(prev => ({ ...prev, returnFlights }));
  };

  const selectOutbound = (selectedOutbound: Flight | null) => {
    setState(prev => ({ ...prev, selectedOutbound }));
  };

  const selectReturn = (selectedReturn: Flight | null) => {
    setState(prev => ({ ...prev, selectedReturn }));
  };

  const selectFare = (selectedFare: FareClass | null) => {
    setState(prev => ({ ...prev, selectedFare }));
  };

  const setPassengers = (passengers: Passenger[]) => {
    setState(prev => ({ ...prev, passengers }));
  };

  const updatePassenger = (index: number, updated: Partial<Passenger>) => {
    setState(prev => {
      const copy = [...prev.passengers];
      if (copy[index]) {
        copy[index] = { ...copy[index], ...updated };
      }
      return { ...prev, passengers: copy };
    });
  };

  const updatePassengerBaggage = (index: number, type: 'cabin' | 'checked20' | 'checked32', change: number | boolean) => {
    setState(prev => {
      const copy = [...prev.passengers];
      if (copy[index]) {
        const bagCopy = { ...copy[index].baggage };
        if (type === 'cabin') {
          bagCopy.cabin = change as boolean;
        } else if (type === 'checked20') {
          bagCopy.checked20 = Math.max(0, (bagCopy.checked20 || 0) + (change as number));
        } else if (type === 'checked32') {
          bagCopy.checked32 = Math.max(0, (bagCopy.checked32 || 0) + (change as number));
        }
        copy[index] = { ...copy[index], baggage: bagCopy };
      }
      return { ...prev, passengers: copy };
    });
  };

  const updatePassengerSeat = (index: number, seat: string | null) => {
    setState(prev => {
      const copy = [...prev.passengers];
      if (copy[index]) {
        copy[index] = { ...copy[index], seat };
      }
      return { ...prev, passengers: copy };
    });
  };

  const setContact = (contact: BookingContact) => {
    setState(prev => ({ ...prev, contact }));
  };

  const updateExtras = (key: 'priority' | 'assistance' | 'smsNotification', value: boolean) => {
    setState(prev => ({
      ...prev,
      extras: {
        ...prev.extras,
        [key]: value,
      },
    }));
  };

  const setCreatedBooking = (createdBooking: Booking | null) => {
    setState(prev => ({ ...prev, createdBooking }));
  };

  const resetBooking = () => {
    setState({
      ...INITIAL_STATE,
      step: 'home',
    });
  };

  return (
    <BookingContext.Provider
      value={{
        state,
        lang,
        t,
        setLang,
        setStep,
        setSearchQuery,
        setOutboundFlights,
        setReturnFlights,
        selectOutbound,
        selectReturn,
        selectFare,
        setPassengers,
        updatePassenger,
        updatePassengerBaggage,
        updatePassengerSeat,
        setContact,
        updateExtras,
        setCreatedBooking,
        resetBooking,
      }}
    >
      {children}
    </BookingContext.Provider>
  );
}

export function useBooking() {
  const context = useContext(BookingContext);
  if (!context) {
    throw new Error('useBooking must be used within a BookingProvider');
  }
  return context;
}
