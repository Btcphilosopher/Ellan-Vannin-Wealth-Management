'use client';

import React from 'react';
import { FareClass } from '@/types/booking';
import { useBooking } from '@/components/BookingProvider';
import { Check, ShieldCheck, Zap, Briefcase } from 'lucide-react';

interface FareCardProps {
  type: FareClass;
  basePrice: number;
  isSelected: boolean;
  onSelect: () => void;
}

export default function FareCard({ type, basePrice, isSelected, onSelect }: FareCardProps) {
  const { t } = useBooking();

  // Pricing markups
  const getMarkup = () => {
    if (type === 'standard') return 30;
    if (type === 'premium') return 80;
    return 0;
  };

  const finalPrice = basePrice + getMarkup();

  const getFeatures = (): string[] => {
    return t(`fares.${type}.features`) as unknown as string[];
  };

  const getIcon = () => {
    if (type === 'premium') return <Zap className="h-5 w-5 text-amber-500" />;
    if (type === 'standard') return <ShieldCheck className="h-5 w-5 text-blue-600" />;
    return <Briefcase className="h-5 w-5 text-slate-500" />;
  };

  const getFareTitle = () => {
    return t(`fares.${type}.name`);
  };

  return (
    <div
      onClick={onSelect}
      className={`group relative rounded-xl border p-5 sm:p-6 transition-all cursor-pointer flex flex-col justify-between h-full ${
        isSelected
          ? 'border-blue-900 bg-blue-50/20 ring-1 ring-blue-950 shadow-md'
          : 'border-slate-200 bg-white hover:border-slate-300 hover:shadow-sm'
      }`}
    >
      {/* Decorative tag for premium */}
      {type === 'premium' && (
        <span className="absolute -top-3 left-4 bg-amber-400 text-blue-950 text-3xs font-extrabold tracking-widest uppercase px-2.5 py-1 rounded-full shadow-sm leading-none">
          RECOMMENDED
        </span>
      )}

      <div>
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className={`p-1.5 rounded-lg ${isSelected ? 'bg-white' : 'bg-slate-50'}`}>
              {getIcon()}
            </div>
            <span className="font-black text-sm sm:text-base tracking-wider text-blue-950 uppercase">
              {getFareTitle()}
            </span>
          </div>
          <div className="text-right">
            <span className="text-xl sm:text-2xl font-black font-mono text-blue-950">
              €{finalPrice.toFixed(2)}
            </span>
          </div>
        </div>

        {/* Features List */}
        <ul className="space-y-2.5 my-4">
          {getFeatures().map((feature, idx) => (
            <li key={idx} className="flex items-start gap-2 text-xs sm:text-sm text-slate-600 font-medium">
              <Check className="h-4 w-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>{feature}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Button footer */}
      <div className="pt-4 mt-auto">
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onSelect();
          }}
          className={`w-full min-h-[44px] flex items-center justify-center text-xs font-bold rounded-lg uppercase tracking-wider transition-all ${
            isSelected
              ? 'bg-blue-900 text-white shadow shadow-blue-900/10'
              : 'bg-slate-100 text-slate-800 hover:bg-slate-200'
          }`}
        >
          {isSelected ? t('results.selectedBtn') : t('results.chooseBtn')}
        </button>
      </div>

    </div>
  );
}
