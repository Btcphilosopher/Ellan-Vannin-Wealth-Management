'use client';

import React, { useState, useEffect } from 'react';
import { useBooking } from '@/components/BookingProvider';
import { Airport, FlightSearchQuery, Passenger } from '@/types/booking';
import { searchFlights } from '@/lib/apiClient';
import AirportSelector from './AirportSelector';
import PassengerSelector from './PassengerSelector';
import { Calendar, RefreshCw, AlertCircle } from 'lucide-react';

export default function FlightSearch() {
  const {
    state,
    t,
    setStep,
    setSearchQuery,
    setOutboundFlights,
    setReturnFlights,
    setPassengers,
    selectOutbound,
    selectReturn,
    selectFare,
  } = useBooking();

  const [tripType, setTripType] = useState<'roundTrip' | 'oneWay'>('roundTrip');
  const [origin, setOrigin] = useState<Airport | null>({
    code: 'RMO',
    name: 'Chișinău International',
    city: 'Chișinău',
    country: 'Moldova',
  });
  const [destination, setDestination] = useState<Airport | null>(null);
  
  // Default search dates pre-seeded for October 12, 2026 and October 19, 2026
  const [departureDate, setDepartureDate] = useState('2026-10-12');
  const [returnDate, setReturnDate] = useState('2026-10-19');

  const [pCount, setPCount] = useState({ adults: 1, children: 0, infants: 0 });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);

  // Pre-fill search values if already present in state
  useEffect(() => {
    if (state.searchQuery) {
      const q = state.searchQuery;
      setTimeout(() => {
        setTripType(q.tripType);
        setDepartureDate(q.departureDate);
        setReturnDate(q.returnDate || '');
        setPCount({
          adults: q.passengers.adults,
          children: q.passengers.children,
          infants: q.passengers.infants,
        });
      }, 0);
    }
  }, [state.searchQuery]);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors: Record<string, string> = {};

    if (!origin) {
      newErrors.origin = 'Originea este obligatorie';
    }
    if (!destination) {
      newErrors.destination = t('search.validation.destinationRequired');
    }
    if (!departureDate) {
      newErrors.departureDate = t('search.validation.departureDateRequired');
    }
    if (tripType === 'roundTrip' && !returnDate) {
      newErrors.returnDate = t('search.validation.returnDateRequired');
    }
    if (tripType === 'roundTrip' && departureDate && returnDate && returnDate < departureDate) {
      newErrors.returnDate = t('search.validation.returnBeforeDeparture');
    }
    if (pCount.adults <= 0) {
      newErrors.passengers = t('search.validation.atLeastOneAdult');
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setErrors({});
    setLoading(true);

    const query: FlightSearchQuery = {
      originCode: origin!.code,
      destinationCode: destination!.code,
      departureDate,
      returnDate: tripType === 'roundTrip' ? returnDate : null,
      tripType,
      passengers: pCount,
    };

    try {
      const results = await searchFlights(query);
      
      // Initialize passenger records
      const numPassengers = pCount.adults + pCount.children + pCount.infants;
      const initialPassengersList: Passenger[] = [];
      
      for (let i = 0; i < numPassengers; i++) {
        initialPassengersList.push({
          id: `p-${i + 1}`,
          firstName: '',
          lastName: '',
          birthDate: '',
          nationality: 'Moldova',
          docType: 'passport',
          docNumber: '',
          docExpiry: '',
          gender: 'male',
          baggage: {
            personal: true,
            cabin: false,
            checked20: 0,
            checked32: 0,
          },
          seat: null,
        });
      }

      setSearchQuery(query);
      setOutboundFlights(results.outboundFlights);
      setReturnFlights(results.returnFlights);
      setPassengers(initialPassengersList);

      // Reset selection when starting a new search
      selectOutbound(null);
      selectReturn(null);
      selectFare(null);

      setStep('results');
    } catch (err) {
      console.error(err);
      setErrors({ api: 'Nu am putut căuta zboruri. Încercați din nou.' });
    } finally {
      setLoading(false);
    }
  };

  const handleSwap = () => {
    const temp = origin;
    setOrigin(destination);
    setDestination(temp);
  };

  return (
    <div className="w-full bg-white rounded-xl shadow-xl border border-slate-100 p-5 sm:p-6 lg:p-8">
      <form onSubmit={handleSearch} className="space-y-6">
        
        {/* Trip type segmented controls (interactive button styling) */}
        <div className="flex gap-1 p-1 bg-slate-100 rounded-lg max-w-[280px]">
          <button
            type="button"
            onClick={() => setTripType('roundTrip')}
            className={`flex-1 text-center py-2 text-xs font-bold rounded-md transition-all whitespace-nowrap leading-none ${
              tripType === 'roundTrip'
                ? 'bg-blue-900 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {t('search.roundTrip')}
          </button>
          <button
            type="button"
            onClick={() => setTripType('oneWay')}
            className={`flex-1 text-center py-2 text-xs font-bold rounded-md transition-all whitespace-nowrap leading-none ${
              tripType === 'oneWay'
                ? 'bg-blue-900 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {t('search.oneWay')}
          </button>
        </div>

        {/* Origin / Destination Grid */}
        <div className="grid grid-cols-1 md:grid-cols-[1fr_auto_1fr] items-end gap-3 md:gap-2">
          <AirportSelector
            label={t('search.from')}
            selectedAirport={origin}
            onSelect={setOrigin}
            excludeCode={destination?.code}
          />

          <div className="flex justify-center pt-2 md:pt-0">
            <button
              type="button"
              onClick={handleSwap}
              className="flex h-11 w-11 items-center justify-center rounded-full border border-slate-200 bg-white text-blue-900 shadow hover:bg-slate-50 transition-all rotate-0 hover:rotate-185 duration-300"
              title="Inversați aeroporturile"
            >
              <RefreshCw className="h-4 w-4" />
            </button>
          </div>

          <AirportSelector
            label={t('search.to')}
            selectedAirport={destination}
            onSelect={setDestination}
            excludeCode={origin?.code}
          />
        </div>

        {/* Dates & Passengers Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          
          {/* Departure Date */}
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">
              {t('search.departureDate')}
            </label>
            <div className="relative">
              <Calendar className="absolute left-3.5 top-1/2 -translate-y-1/2 h-5 w-5 text-blue-900 pointer-events-none" />
              <input
                type="date"
                min="2026-10-01"
                value={departureDate}
                onChange={e => setDepartureDate(e.target.value)}
                className="w-full min-h-[52px] pl-11 pr-4 py-2.5 text-sm sm:text-base font-bold text-slate-800 bg-white border border-slate-200 rounded-lg hover:border-blue-300 focus:outline-none focus:ring-2 focus:ring-blue-900"
              />
            </div>
            {errors.departureDate && (
              <span className="text-xs text-red-500 mt-1 block font-medium">{errors.departureDate}</span>
            )}
          </div>

          {/* Return Date */}
          <div className={`${tripType === 'oneWay' ? 'opacity-40 pointer-events-none' : ''}`}>
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">
              {t('search.returnDate')}
            </label>
            <div className="relative">
              <Calendar className="absolute left-3.5 top-1/2 -translate-y-1/2 h-5 w-5 text-blue-900 pointer-events-none" />
              <input
                type="date"
                min={departureDate || '2026-10-01'}
                disabled={tripType === 'oneWay'}
                value={tripType === 'oneWay' ? '' : returnDate}
                onChange={e => setReturnDate(e.target.value)}
                className="w-full min-h-[52px] pl-11 pr-4 py-2.5 text-sm sm:text-base font-bold text-slate-800 bg-white border border-slate-200 rounded-lg hover:border-blue-300 focus:outline-none focus:ring-2 focus:ring-blue-900"
              />
            </div>
            {errors.returnDate && tripType === 'roundTrip' && (
              <span className="text-xs text-red-500 mt-1 block font-medium">{errors.returnDate}</span>
            )}
          </div>

          {/* Passenger Selector */}
          <div className="sm:col-span-2 md:col-span-1">
            <PassengerSelector
              adults={pCount.adults}
              childrenCount={pCount.children}
              infants={pCount.infants}
              onChange={setPCount}
            />
            {errors.passengers && (
              <span className="text-xs text-red-500 mt-1 block font-medium">{errors.passengers}</span>
            )}
          </div>

        </div>

        {/* Global form errors */}
        {errors.destination && (
          <div className="flex items-center gap-2 p-3 rounded-lg bg-red-50 border border-red-200 text-red-700 text-xs">
            <AlertCircle className="h-4 w-4 shrink-0" />
            <span>{errors.destination}</span>
          </div>
        )}

        {/* Submit button (large touch height 48px) */}
        <div className="pt-2">
          <button
            type="submit"
            disabled={loading}
            className="w-full min-h-[52px] flex items-center justify-center rounded-lg bg-blue-900 font-extrabold text-sm sm:text-base text-white tracking-wide uppercase shadow-lg shadow-blue-900/10 hover:bg-blue-800 active:scale-[0.99] transition-all disabled:opacity-50"
          >
            {loading ? 'Se caută...' : t('search.searchBtn')}
          </button>
        </div>

      </form>
    </div>
  );
}
