'use client';

import React, { useState } from 'react';
import { useBooking } from '@/components/BookingProvider';
import { getBooking, updateBooking } from '@/lib/apiClient';
import { Booking } from '@/types/booking';
import { Search, Plane, ShieldCheck, User, Calendar, Briefcase, Plus, Ticket, Download, ArrowRight, RefreshCw, Info } from 'lucide-react';

export default function MyBookingPage() {
  const { t, lang, setStep } = useBooking();
  const [refCode, setRefCode] = useState('');
  const [lastName, setLastName] = useState('');
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [booking, setBooking] = useState<Booking | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => {
      setToast(null);
    }, 3000);
  };

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!refCode.trim() || !lastName.trim()) {
      setError(t('myBooking.notFound'));
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const result = await getBooking(refCode, lastName);
      setBooking(result);
    } catch (err: any) {
      console.error(err);
      setError(t('myBooking.notFound'));
      setBooking(null);
    } finally {
      setLoading(false);
    }
  };

  const handleAction = async (actionKey: string) => {
    if (!booking) return;

    if (actionKey === 'checkIn') {
      // Direct transition to online checkin screen
      setStep('check-in');
      return;
    }

    showToast(t('myBooking.actions.simulatedSuccess', { service: t(`myBooking.actions.${actionKey}`) }));
  };

  const formatTime = (timeStr: string) => {
    try {
      const date = new Date(timeStr);
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
    } catch {
      return timeStr;
    }
  };

  const formatDate = (dateStr: string) => {
    try {
      const d = new Date(dateStr);
      return d.toLocaleDateString(lang === 'ro' ? 'ro-RO' : 'en-US', {
        weekday: 'short',
        day: 'numeric',
        month: 'short',
        year: 'numeric',
      });
    } catch {
      return dateStr;
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6 pb-16 animate-fadeIn">
      
      {/* Toast alert banner */}
      {toast && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 bg-slate-900 text-white text-xs font-bold px-4 py-2.5 rounded-full shadow-lg flex items-center gap-2 animate-fadeIn">
          <Info className="h-4 w-4 text-amber-400" />
          <span>{toast}</span>
        </div>
      )}

      {/* Query panel */}
      <div className="bg-white rounded-xl border border-slate-100 p-5 sm:p-6 shadow-sm space-y-5">
        <div>
          <h2 className="text-lg font-black text-blue-950 uppercase tracking-wider">
            {t('myBooking.title')}
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            {t('myBooking.subtitle')}
          </p>
        </div>

        <form onSubmit={handleSearch} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            {/* Booking Code */}
            <div>
              <label className="block text-2xs font-extrabold text-slate-500 uppercase tracking-widest mb-1.5">
                {t('myBooking.refCode')}
              </label>
              <input
                type="text"
                value={refCode}
                onChange={e => setRefCode(e.target.value.toUpperCase())}
                placeholder="FO8K2M"
                className="w-full min-h-[44px] px-3.5 py-2 text-sm font-semibold text-slate-800 bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900 uppercase"
              />
            </div>

            {/* Passenger Last Name */}
            <div>
              <label className="block text-2xs font-extrabold text-slate-500 uppercase tracking-widest mb-1.5">
                {t('myBooking.lastName')}
              </label>
              <input
                type="text"
                value={lastName}
                onChange={e => setLastName(e.target.value)}
                placeholder="Almeida"
                className="w-full min-h-[44px] px-3.5 py-2 text-sm font-semibold text-slate-800 bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900"
              />
            </div>

          </div>

          {error && (
            <p className="text-xs text-red-500 font-bold">{error}</p>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full min-h-[44px] flex items-center justify-center gap-2 rounded-lg bg-blue-900 font-extrabold text-xs text-white uppercase tracking-wider hover:bg-blue-800 active:scale-[0.98] transition-all"
          >
            <Search className="h-4 w-4" />
            <span>{loading ? 'Se caută...' : t('myBooking.searchBtn')}</span>
          </button>
        </form>
      </div>

      {/* Booking View Segment */}
      {booking && (
        <div className="space-y-6 animate-fadeIn">
          
          {/* Header Status segment */}
          <div className="bg-white rounded-xl border border-slate-100 p-5 sm:p-6 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <span className="text-4xs font-extrabold text-slate-400 uppercase tracking-widest leading-none block">
                {t('confirmation.refCode')}
              </span>
              <span className="text-xl font-black font-mono text-blue-950 mt-1 block">
                {booking.reference}
              </span>
            </div>
            <div className="flex items-center gap-2 bg-emerald-50 border border-emerald-200 rounded-full px-4 py-1.5">
              <ShieldCheck className="h-4 w-4 text-emerald-600 shrink-0" />
              <span className="text-3xs font-extrabold text-emerald-700 uppercase tracking-widest leading-none">
                {t('myBooking.statusConfirmed')}
              </span>
            </div>
          </div>

          {/* Flight Details */}
          <div className="bg-white rounded-xl border border-slate-100 p-5 sm:p-6 shadow-sm space-y-5">
            <h3 className="font-black text-xs sm:text-sm text-blue-950 uppercase tracking-wider border-b border-slate-100 pb-2.5">
              {t('confirmation.flightDetails')}
            </h3>

            <div className="space-y-5">
              {/* Outbound */}
              <div className="flex items-start gap-3">
                <Plane className="h-5 w-5 text-blue-900 shrink-0 mt-0.5 rotate-45" />
                <div className="flex-1 min-w-0">
                  <span className="text-2xs font-extrabold text-blue-900 uppercase tracking-wider block">
                    {t('results.outbound')}
                  </span>
                  <div className="flex items-center gap-2 mt-1 font-bold text-slate-800 text-sm">
                    <span>{booking.outboundFlight.origin.city} ({booking.outboundFlight.origin.code})</span>
                    <ArrowRight className="h-4 w-4 text-slate-400 shrink-0" />
                    <span>{booking.outboundFlight.destination.city} ({booking.outboundFlight.destination.code})</span>
                  </div>
                  <p className="text-xs text-slate-400 font-semibold mt-1">
                    {formatDate(booking.outboundFlight.departureTime)} · {formatTime(booking.outboundFlight.departureTime)} - {formatTime(booking.outboundFlight.arrivalTime)} · {booking.outboundFlight.flightNumber} · {booking.outboundFlight.aircraft}
                  </p>
                </div>
              </div>

              {/* Return */}
              {booking.returnFlight && (
                <div className="flex items-start gap-3 pt-4 border-t border-slate-100">
                  <Plane className="h-5 w-5 text-blue-900 shrink-0 mt-0.5 -rotate-135" />
                  <div className="flex-1 min-w-0">
                    <span className="text-2xs font-extrabold text-blue-900 uppercase tracking-wider block">
                      {t('results.return')}
                    </span>
                    <div className="flex items-center gap-2 mt-1 font-bold text-slate-800 text-sm">
                      <span>{booking.returnFlight.origin.city} ({booking.returnFlight.origin.code})</span>
                      <ArrowRight className="h-4 w-4 text-slate-400 shrink-0" />
                      <span>{booking.returnFlight.destination.city} ({booking.returnFlight.destination.code})</span>
                    </div>
                    <p className="text-xs text-slate-400 font-semibold mt-1">
                      {formatDate(booking.returnFlight.departureTime)} · {formatTime(booking.returnFlight.departureTime)} - {formatTime(booking.returnFlight.arrivalTime)} · {booking.returnFlight.flightNumber} · {booking.returnFlight.aircraft}
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Passengers */}
          <div className="bg-white rounded-xl border border-slate-100 p-5 sm:p-6 shadow-sm space-y-4">
            <h3 className="font-black text-xs sm:text-sm text-blue-950 uppercase tracking-wider border-b border-slate-100 pb-2.5">
              {t('confirmation.passengerDetails')}
            </h3>

            <div className="divide-y divide-slate-100 space-y-3.5">
              {booking.passengers.map((p, idx) => (
                <div key={p.id} className="flex items-start justify-between gap-4 pt-3 first:pt-0 animate-fadeIn">
                  <div className="flex items-start gap-3">
                    <User className="h-4 w-4 text-slate-400 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold text-slate-800 text-sm block">
                        {p.firstName} {p.lastName}
                      </span>
                      <span className="text-2xs text-slate-400 font-semibold block mt-0.5">
                        {t('passengersForm.docType')}: {p.docType === 'passport' ? t('passengersForm.passport') : t('passengersForm.idCard')} ({p.docNumber})
                      </span>
                    </div>
                  </div>

                  {p.seat && (
                    <span className="font-mono font-bold text-xs bg-blue-50 text-blue-900 border border-blue-200 px-2.5 py-1 rounded">
                      Loc: {p.seat}
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Quick Actions Dashboard */}
          <div className="bg-white rounded-xl border border-slate-100 p-5 sm:p-6 shadow-sm space-y-4">
            <h3 className="font-black text-xs sm:text-sm text-blue-950 uppercase tracking-wider border-b border-slate-100 pb-2.5">
              {t('myBooking.actions.changeFlight')} / Servicii
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              
              <button
                type="button"
                onClick={() => handleAction('changeFlight')}
                className="flex items-center gap-3 border border-slate-200 rounded-lg p-3 text-left hover:bg-slate-50 transition-colors"
              >
                <RefreshCw className="h-5 w-5 text-blue-900 shrink-0" />
                <span className="font-bold text-slate-800 text-xs">{t('myBooking.actions.changeFlight')}</span>
              </button>

              <button
                type="button"
                onClick={() => handleAction('addBaggage')}
                className="flex items-center gap-3 border border-slate-200 rounded-lg p-3 text-left hover:bg-slate-50 transition-colors"
              >
                <Briefcase className="h-5 w-5 text-blue-900 shrink-0" />
                <span className="font-bold text-slate-800 text-xs">{t('myBooking.actions.addBaggage')}</span>
              </button>

              <button
                type="button"
                onClick={() => handleAction('chooseSeats')}
                className="flex items-center gap-3 border border-slate-200 rounded-lg p-3 text-left hover:bg-slate-50 transition-colors"
              >
                <Ticket className="h-5 w-5 text-blue-900 shrink-0" />
                <span className="font-bold text-slate-800 text-xs">{t('myBooking.actions.chooseSeats')}</span>
              </button>

              <button
                type="button"
                onClick={() => handleAction('checkIn')}
                className="flex items-center gap-3 border border-blue-200 bg-blue-50/50 rounded-lg p-3 text-left hover:bg-blue-50 transition-colors"
              >
                <ShieldCheck className="h-5 w-5 text-blue-900 shrink-0 animate-pulse" />
                <span className="font-black text-blue-900 text-xs">{t('myBooking.actions.checkIn')}</span>
              </button>

            </div>
          </div>

        </div>
      )}

    </div>
  );
}
