'use client';

import React, { useState } from 'react';
import { useBooking } from '@/components/BookingProvider';
import { getBooking, performCheckIn } from '@/lib/apiClient';
import { Booking } from '@/types/booking';
import { Search, ShieldCheck, User, Plane, CheckCircle2, Download, ArrowRight, Info } from 'lucide-react';

export default function CheckInPage() {
  const { t, lang } = useBooking();
  const [refCode, setRefCode] = useState('');
  const [lastName, setLastName] = useState('');

  const [loading, setLoading] = useState(false);
  const [checkingIn, setCheckingIn] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [booking, setBooking] = useState<Booking | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => {
      setToast(null);
    }, 3000);
  };

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!refCode.trim() || !lastName.trim()) {
      setError(t('myBooking.notFound'));
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const result = await getBooking(refCode, lastName);
      setBooking(result);
    } catch (err: any) {
      console.error(err);
      setError(t('myBooking.notFound'));
      setBooking(null);
    } finally {
      setLoading(false);
    }
  };

  const handlePerformCheckIn = async () => {
    if (!booking) return;

    setCheckingIn(true);
    try {
      const updated = await performCheckIn(booking.reference, lastName);
      setBooking(updated);
      showToast(t('checkinPage.alreadyDone'));
    } catch (err: any) {
      console.error(err);
      setError('Check-in failed. Try again.');
    } finally {
      setCheckingIn(false);
    }
  };

  const formatTime = (timeStr: string) => {
    try {
      const date = new Date(timeStr);
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
    } catch {
      return timeStr;
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6 pb-16 animate-fadeIn">
      
      {/* Toast Alert Banner */}
      {toast && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 bg-slate-900 text-white text-xs font-bold px-4 py-2.5 rounded-full shadow-lg flex items-center gap-2 animate-fadeIn">
          <Info className="h-4 w-4 text-amber-400" />
          <span>{toast}</span>
        </div>
      )}

      {/* Query Search Form */}
      <div className="bg-white rounded-xl border border-slate-100 p-5 sm:p-6 shadow-sm space-y-5">
        <div>
          <h2 className="text-lg font-black text-blue-950 uppercase tracking-wider">
            {t('checkinPage.title')}
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            {t('checkinPage.subtitle')}
          </p>
        </div>

        <form onSubmit={handleSearch} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            {/* Booking Code */}
            <div>
              <label className="block text-2xs font-extrabold text-slate-500 uppercase tracking-widest mb-1.5">
                {t('myBooking.refCode')}
              </label>
              <input
                type="text"
                value={refCode}
                onChange={e => setRefCode(e.target.value.toUpperCase())}
                placeholder="FO8K2M"
                className="w-full min-h-[44px] px-3.5 py-2 text-sm font-semibold text-slate-800 bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900 uppercase"
              />
            </div>

            {/* Passenger Last Name */}
            <div>
              <label className="block text-2xs font-extrabold text-slate-500 uppercase tracking-widest mb-1.5">
                {t('myBooking.lastName')}
              </label>
              <input
                type="text"
                value={lastName}
                onChange={e => setLastName(e.target.value)}
                placeholder="Almeida"
                className="w-full min-h-[44px] px-3.5 py-2 text-sm font-semibold text-slate-800 bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900"
              />
            </div>

          </div>

          {error && (
            <p className="text-xs text-red-500 font-bold">{error}</p>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full min-h-[44px] flex items-center justify-center gap-2 rounded-lg bg-blue-900 font-extrabold text-xs text-white uppercase tracking-wider hover:bg-blue-800 active:scale-[0.98] transition-all"
          >
            <Search className="h-4 w-4" />
            <span>{loading ? 'Se caută...' : t('checkinPage.searchTitle')}</span>
          </button>
        </form>
      </div>

      {/* Checkin Status Card */}
      {booking && (
        <div className="bg-white rounded-xl border border-slate-100 p-5 sm:p-6 shadow-sm space-y-6 animate-fadeIn">
          
          <div className="flex justify-between items-center border-b border-slate-100 pb-3">
            <div>
              <span className="text-4xs font-extrabold text-slate-400 uppercase tracking-widest leading-none block">
                {booking.outboundFlight.flightNumber}
              </span>
              <div className="flex items-center gap-1.5 mt-1 font-bold text-slate-800 text-sm">
                <span>{booking.outboundFlight.origin.code}</span>
                <ArrowRight className="h-4 w-4 text-slate-400 shrink-0" />
                <span>{booking.outboundFlight.destination.code}</span>
              </div>
            </div>
            <span className="text-2xs font-black font-mono text-blue-950 bg-blue-50 border border-blue-250 px-2.5 py-1 rounded">
              REF: {booking.reference}
            </span>
          </div>

          {/* Passenger checkin rows */}
          <div className="space-y-4">
            {booking.passengers.map(p => {
              const isCheckedIn = booking.checkInStatus[p.id];

              return (
                <div key={p.id} className="flex items-center justify-between gap-4 p-3.5 rounded-lg border border-slate-100 bg-slate-50/50">
                  <div className="flex items-start gap-3">
                    <User className="h-4 w-4 text-slate-400 shrink-0 mt-1" />
                    <div>
                      <span className="font-bold text-slate-800 text-sm block">
                        {p.firstName} {p.lastName}
                      </span>
                      <span className="text-3xs text-slate-400 font-semibold block mt-0.5">
                        {p.seat ? `Loc selectat: ${p.seat}` : 'Fără loc selectat'}
                      </span>
                    </div>
                  </div>

                  {isCheckedIn ? (
                    <div className="flex items-center gap-1.5 bg-emerald-50 text-emerald-700 px-3 py-1 rounded-full border border-emerald-200">
                      <CheckCircle2 className="h-3.5 w-3.5 shrink-0" />
                      <span className="text-3xs font-extrabold uppercase tracking-widest">
                        CHECKED-IN
                      </span>
                    </div>
                  ) : (
                    <span className="text-3xs font-extrabold text-blue-900 bg-blue-50 border border-blue-150 px-2.5 py-1 rounded-full uppercase tracking-widest">
                      {t('checkinPage.statusReady')}
                    </span>
                  )}
                </div>
              );
            })}
          </div>

          {/* Action button */}
          <div className="pt-2">
            {Object.values(booking.checkInStatus).every(status => status) ? (
              <button
                type="button"
                onClick={() => showToast(t('confirmation.simulatedAction'))}
                className="w-full min-h-[44px] flex items-center justify-center gap-2 rounded-lg bg-emerald-600 font-extrabold text-xs text-white uppercase tracking-wider hover:bg-emerald-700 transition-all shadow shadow-emerald-600/10"
              >
                <Download className="h-4 w-4" />
                <span>{t('checkinPage.downloadBoardingPass')}</span>
              </button>
            ) : (
              <button
                type="button"
                disabled={checkingIn}
                onClick={handlePerformCheckIn}
                className="w-full min-h-[44px] flex items-center justify-center gap-2 rounded-lg bg-blue-900 font-extrabold text-xs text-white uppercase tracking-wider hover:bg-blue-800 active:scale-[0.98] transition-all"
              >
                <ShieldCheck className="h-4 w-4 text-amber-400 shrink-0" />
                <span>{checkingIn ? 'Se procesează...' : t('checkinPage.startBtn')}</span>
              </button>
            )}
          </div>

        </div>
      )}

    </div>
  );
}
