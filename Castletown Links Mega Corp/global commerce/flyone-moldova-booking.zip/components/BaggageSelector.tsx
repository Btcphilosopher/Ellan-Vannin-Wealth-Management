'use client';

import React, { useState } from 'react';
import { useBooking } from '@/components/BookingProvider';
import { Briefcase, ShoppingBag, Plus, Minus, User } from 'lucide-react';
import { BAGGAGE_PRICES } from '@/lib/bookingState';

interface BaggageSelectorProps {
  onContinue: () => void;
}

export default function BaggageSelector({ onContinue }: BaggageSelectorProps) {
  const { state, t, updatePassengerBaggage } = useBooking();
  const [activePassengerIdx, setActivePassengerIdx] = useState(0);

  const activePassenger = state.passengers[activePassengerIdx];
  if (!activePassenger) return null;

  const isBasic = state.selectedFare === 'basic';
  const isStandard = state.selectedFare === 'standard';
  const isPremium = state.selectedFare === 'premium';

  return (
    <div className="space-y-6 pb-16">
      
      {/* Passenger selector tabs (if more than 1 passenger) */}
      {state.passengers.length > 1 && (
        <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-thin">
          {state.passengers.map((p, idx) => (
            <button
              key={p.id}
              type="button"
              onClick={() => setActivePassengerIdx(idx)}
              className={`flex items-center gap-1.5 px-4 py-2.5 rounded-lg border text-xs font-bold whitespace-nowrap transition-all ${
                activePassengerIdx === idx
                  ? 'border-blue-900 bg-blue-900 text-white'
                  : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
              }`}
            >
              <User className="h-3.5 w-3.5" />
              <span>
                {p.firstName && p.lastName
                  ? `${p.firstName} ${p.lastName}`
                  : `${t('passengersForm.passengerIndex', { index: idx + 1 })}`}
              </span>
            </button>
          ))}
        </div>
      )}

      {/* Baggage Cards List */}
      <div className="bg-white rounded-xl border border-slate-100 shadow-sm p-5 sm:p-6 space-y-5">
        
        <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
          <Briefcase className="h-5 w-5 text-blue-900" />
          <h3 className="font-black text-sm sm:text-base tracking-wider text-blue-950 uppercase">
            {t('baggagePage.title')} (
            {activePassenger.firstName && activePassenger.lastName
              ? `${activePassenger.firstName} ${activePassenger.lastName}`
              : `${t('passengersForm.passengerIndex', { index: activePassengerIdx + 1 })}`}
            )
          </h3>
        </div>

        <div className="divide-y divide-slate-100 space-y-5">
          
          {/* 1. Personal Bag (Always Free) */}
          <div className="flex items-center justify-between gap-4 pt-2">
            <div className="flex items-start gap-3">
              <div className="p-2 bg-slate-50 rounded-lg text-slate-500 shrink-0 mt-0.5">
                <ShoppingBag className="h-5 w-5" />
              </div>
              <div>
                <span className="font-bold text-slate-800 text-sm block">
                  {t('baggagePage.personalBag')}
                </span>
                <span className="text-slate-400 text-xs mt-0.5 block">
                  {t('baggagePage.personalBagDesc')}
                </span>
                <span className="text-slate-400 font-semibold text-xs mt-0.5 block">
                  {t('baggageGuide.personal.dims')}
                </span>
              </div>
            </div>
            <span className="text-xs font-extrabold text-emerald-600 uppercase tracking-wider bg-emerald-50 rounded-lg px-2.5 py-1">
              {t('baggagePage.included')}
            </span>
          </div>

          {/* 2. Cabin Bag (Included in Standard/Premium, Paid in Basic) */}
          <div className="flex items-center justify-between gap-4 pt-5">
            <div className="flex items-start gap-3">
              <div className="p-2 bg-slate-50 rounded-lg text-blue-900 shrink-0 mt-0.5">
                <Briefcase className="h-5 w-5" />
              </div>
              <div>
                <span className="font-bold text-slate-800 text-sm block">
                  {t('baggagePage.cabinBag')}
                </span>
                <span className="text-slate-400 text-xs mt-0.5 block">
                  {t('baggagePage.cabinBagDesc')}
                </span>
                <span className="text-slate-400 font-semibold text-xs mt-0.5 block">
                  {t('baggageGuide.cabin.dims')}
                </span>
              </div>
            </div>

            {/* Controls */}
            {isStandard || isPremium ? (
              <span className="text-xs font-extrabold text-emerald-600 uppercase tracking-wider bg-emerald-50 rounded-lg px-2.5 py-1">
                {t('baggagePage.included')}
              </span>
            ) : (
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  disabled={!activePassenger.baggage.cabin}
                  onClick={() => updatePassengerBaggage(activePassengerIdx, 'cabin', false)}
                  className="flex h-8 w-8 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-600 hover:bg-slate-50 disabled:opacity-50"
                >
                  <Minus className="h-4 w-4" />
                </button>
                <span className="font-bold font-mono text-sm w-4 text-center">
                  {activePassenger.baggage.cabin ? '1' : '0'}
                </span>
                <button
                  type="button"
                  disabled={activePassenger.baggage.cabin}
                  onClick={() => updatePassengerBaggage(activePassengerIdx, 'cabin', true)}
                  className="flex h-8 w-8 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-600 hover:bg-slate-50 disabled:opacity-50"
                >
                  <Plus className="h-4 w-4" />
                </button>
                <span className="text-2xs font-extrabold font-mono text-slate-500 w-12 text-right">
                  +€{BAGGAGE_PRICES.cabin.toFixed(2)}
                </span>
              </div>
            )}
          </div>

          {/* 3. Checked Bag 20kg (Included in Premium first, Paid elsewhere) */}
          <div className="flex items-center justify-between gap-4 pt-5">
            <div className="flex items-start gap-3">
              <div className="p-2 bg-slate-50 rounded-lg text-indigo-900 shrink-0 mt-0.5">
                <Briefcase className="h-5.5 w-5.5" />
              </div>
              <div>
                <span className="font-bold text-slate-800 text-sm block">
                  {t('baggagePage.checkedBag20')}
                </span>
                <span className="text-slate-400 text-xs mt-0.5 block">
                  {t('baggagePage.checkedBag20Desc')}
                </span>
                <span className="text-slate-400 font-semibold text-xs mt-0.5 block">
                  {t('baggageGuide.checked.dims')}
                </span>
              </div>
            </div>

            {/* Counter */}
            <div className="flex items-center gap-3">
              <button
                type="button"
                disabled={activePassenger.baggage.checked20 <= 0}
                onClick={() => updatePassengerBaggage(activePassengerIdx, 'checked20', -1)}
                className="flex h-8 w-8 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-600 hover:bg-slate-50 disabled:opacity-50"
              >
                <Minus className="h-4 w-4" />
              </button>
              <span className="font-bold font-mono text-sm w-4 text-center">
                {activePassenger.baggage.checked20}
              </span>
              <button
                type="button"
                onClick={() => updatePassengerBaggage(activePassengerIdx, 'checked20', 1)}
                className="flex h-8 w-8 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-600 hover:bg-slate-50"
              >
                <Plus className="h-4 w-4" />
              </button>
              <span className="text-2xs font-extrabold font-mono text-slate-500 w-12 text-right">
                {isPremium && activePassenger.baggage.checked20 === 1 ? (
                  <span className="text-emerald-600 uppercase">FREE</span>
                ) : (
                  `+€${BAGGAGE_PRICES.checked20.toFixed(2)}`
                )}
              </span>
            </div>
          </div>

          {/* 4. Checked Bag 32kg (Always Paid) */}
          <div className="flex items-center justify-between gap-4 pt-5">
            <div className="flex items-start gap-3">
              <div className="p-2 bg-slate-50 rounded-lg text-indigo-950 shrink-0 mt-0.5">
                <Briefcase className="h-6 w-6" />
              </div>
              <div>
                <span className="font-bold text-slate-800 text-sm block">
                  {t('baggagePage.checkedBag32')}
                </span>
                <span className="text-slate-400 text-xs mt-0.5 block">
                  {t('baggagePage.checkedBag32Desc')}
                </span>
              </div>
            </div>

            {/* Counter */}
            <div className="flex items-center gap-3">
              <button
                type="button"
                disabled={activePassenger.baggage.checked32 <= 0}
                onClick={() => updatePassengerBaggage(activePassengerIdx, 'checked32', -1)}
                className="flex h-8 w-8 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-600 hover:bg-slate-50 disabled:opacity-50"
              >
                <Minus className="h-4 w-4" />
              </button>
              <span className="font-bold font-mono text-sm w-4 text-center">
                {activePassenger.baggage.checked32}
              </span>
              <button
                type="button"
                onClick={() => updatePassengerBaggage(activePassengerIdx, 'checked32', 1)}
                className="flex h-8 w-8 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-600 hover:bg-slate-50"
              >
                <Plus className="h-4 w-4" />
              </button>
              <span className="text-2xs font-extrabold font-mono text-slate-500 w-12 text-right">
                +€{BAGGAGE_PRICES.checked32.toFixed(2)}
              </span>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
