import { NextResponse } from 'next/server';

interface DestinationInfo {
  code: string;
  city: string;
  country: string;
  name: string;
  basePrice: number;
  image: string;
  desc: {
    ro: string;
    en: string;
  };
}

const DESTINATIONS: DestinationInfo[] = [
  {
    code: 'FCO',
    city: 'Roma',
    country: 'Italia',
    name: 'Fiumicino Airport',
    basePrice: 79.99,
    image: '/images/destination_rome_1790840834133.jpg',
    desc: {
      ro: 'Descoperiți Cetatea Eternă: istorie antică, delicii culinare și o atmosferă romantică inegalabilă.',
      en: 'Discover the Eternal City: ancient history, culinary delights, and an unparalleled romantic atmosphere.'
    }
  },
  {
    code: 'CDG',
    city: 'Paris',
    country: 'Franța',
    name: 'Charles de Gaulle',
    basePrice: 119.99,
    image: '/images/destination_paris_1790840843809.jpg',
    desc: {
      ro: 'Orașul Luminilor vă așteaptă cu bulevarde elegante, artă de clasă mondială și monumente iconice.',
      en: 'The City of Lights awaits you with elegant boulevards, world-class art, and iconic monuments.'
    }
  },
  {
    code: 'LTN',
    city: 'Londra',
    country: 'Marea Britanie',
    name: 'Luton Airport',
    basePrice: 129.99,
    image: '/images/destination_london_1790840855786.jpg',
    desc: {
      ro: 'Explorați o metropolă vibrantă plină de istorie regală, muzee de top și diversitate culturală.',
      en: 'Explore a vibrant metropolis filled with royal history, world-class museums, and cultural diversity.'
    }
  },
  {
    code: 'IST',
    city: 'Istanbul',
    country: 'Turcia',
    name: 'Istanbul Airport',
    basePrice: 69.99,
    image: '/images/destination_rome_1790840834133.jpg',
    desc: {
      ro: 'Puntea dintre două continente: bazaruri animate, moschei maiestuoase și arome orientale unice.',
      en: 'The bridge between two continents: bustling bazaars, majestic mosques, and unique oriental flavors.'
    }
  },
  {
    code: 'BRU',
    city: 'Bruxelles',
    country: 'Belgia',
    name: 'Brussels Airport',
    basePrice: 109.99,
    image: '/images/destination_paris_1790840843809.jpg',
    desc: {
      ro: 'Capitala Europei: ciocolată fină, arhitectură gotică de excepție și atmosfera cosmopolită.',
      en: 'The capital of Europe: fine chocolate, outstanding Gothic architecture, and cosmopolitan vibes.'
    }
  },
  {
    code: 'OTP',
    city: 'București',
    country: 'România',
    name: 'Henri Coandă',
    basePrice: 49.99,
    image: '/images/destination_london_1790840855786.jpg',
    desc: {
      ro: 'Capitala României, un amestec fermecător de istorie, viață de noapte dinamică și parcuri întinse.',
      en: 'The capital of Romania, a charming mix of history, dynamic nightlife, and expansive parks.'
    }
  }
];

export async function GET() {
  return NextResponse.json(DESTINATIONS);
}
