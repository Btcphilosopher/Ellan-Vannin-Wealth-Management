import { NextResponse } from 'next/server';
import { AIRPORTS } from '@/lib/flightEngine';

export async function GET() {
  return NextResponse.json(AIRPORTS);
}
