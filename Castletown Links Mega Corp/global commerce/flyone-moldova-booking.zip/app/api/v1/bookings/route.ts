import { NextRequest, NextResponse } from 'next/server';
import { Booking, Passenger } from '@/types/booking';
import { bookingsCache } from '@/lib/bookingCache';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { outboundFlight, returnFlight, fareClass, passengers, contact, totalAmount } = body;

    if (!outboundFlight || !fareClass || !passengers || !contact) {
      return NextResponse.json({ error: 'Missing required booking fields' }, { status: 400 });
    }

    // Generate random 6-character uppercase reference
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let reference = '';
    do {
      reference = '';
      for (let i = 0; i < 6; i++) {
        reference += characters.charAt(Math.floor(Math.random() * characters.length));
      }
    } while (bookingsCache[reference]); // Make sure it's unique

    const checkInStatus: Record<string, boolean> = {};
    passengers.forEach((p: Passenger) => {
      checkInStatus[p.id] = false;
    });

    const newBooking: Booking = {
      reference,
      outboundFlight,
      returnFlight,
      fareClass,
      passengers,
      contact,
      totalAmount,
      paymentStatus: 'paid', // Instant checkout for mock booking
      checkInStatus,
      createdAt: new Date().toISOString(),
    };

    bookingsCache[reference] = newBooking;

    return NextResponse.json(newBooking);
  } catch (err: any) {
    return NextResponse.json({ error: 'Failed to create booking', message: err.message }, { status: 400 });
  }
}

export async function GET() {
  // Return all bookings for debug/demo list purposes if needed
  return NextResponse.json(Object.values(bookingsCache));
}
