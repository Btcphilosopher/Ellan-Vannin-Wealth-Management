import { NextRequest, NextResponse } from 'next/server';
import { bookingsCache } from '@/lib/bookingCache';

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ reference: string }> }
) {
  try {
    const { reference } = await params;
    const refUpper = reference.toUpperCase();
    const searchParams = req.nextUrl.searchParams;
    const lastName = searchParams.get('lastName')?.toLowerCase();

    const booking = bookingsCache[refUpper];

    if (!booking) {
      return NextResponse.json({ error: 'Booking not found' }, { status: 404 });
    }

    if (lastName) {
      const passengerMatch = booking.passengers.some(
        p => p.lastName.toLowerCase() === lastName
      );
      if (!passengerMatch) {
        return NextResponse.json({ error: 'Passenger last name does not match reservation records' }, { status: 400 });
      }
    }

    return NextResponse.json(booking);
  } catch (err: any) {
    return NextResponse.json({ error: 'Failed to retrieve booking', message: err.message }, { status: 500 });
  }
}

// Allows updating booking data (e.g. seats, bags) in My Booking simulation
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ reference: string }> }
) {
  try {
    const { reference } = await params;
    const refUpper = reference.toUpperCase();
    const body = await req.json();

    const booking = bookingsCache[refUpper];
    if (!booking) {
      return NextResponse.json({ error: 'Booking not found' }, { status: 404 });
    }

    // Update fields
    if (body.passengers) {
      booking.passengers = body.passengers;
    }
    if (body.totalAmount !== undefined) {
      booking.totalAmount = body.totalAmount;
    }
    if (body.checkInStatus) {
      booking.checkInStatus = {
        ...booking.checkInStatus,
        ...body.checkInStatus,
      };
    }

    bookingsCache[refUpper] = { ...booking };

    return NextResponse.json(booking);
  } catch (err: any) {
    return NextResponse.json({ error: 'Failed to update booking', message: err.message }, { status: 500 });
  }
}
