import { NextRequest, NextResponse } from 'next/server';
import { generateFlightsForDate } from '@/lib/flightEngine';
import { Flight } from '@/types/booking';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { originCode, destinationCode, departureDate, returnDate, tripType } = body;

    if (!originCode || !destinationCode || !departureDate) {
      return NextResponse.json(
        { error: 'Missing required parameters: originCode, destinationCode, departureDate' },
        { status: 400 }
      );
    }

    const outboundFlights = generateFlightsForDate(originCode, destinationCode, departureDate);
    let returnFlights: Flight[] = [];

    if (tripType === 'roundTrip' && returnDate) {
      returnFlights = generateFlightsForDate(destinationCode, originCode, returnDate);
    }

    return NextResponse.json({
      outboundFlights,
      returnFlights,
    });
  } catch (err: any) {
    return NextResponse.json({ error: 'Invalid search query', message: err.message }, { status: 400 });
  }
}
