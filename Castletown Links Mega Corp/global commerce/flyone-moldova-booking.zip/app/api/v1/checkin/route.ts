import { NextRequest, NextResponse } from 'next/server';
import { bookingsCache } from '@/lib/bookingCache';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { reference, lastName, passengerId } = body;

    if (!reference || !lastName) {
      return NextResponse.json({ error: 'Missing reference or lastName' }, { status: 400 });
    }

    const refUpper = reference.toUpperCase();
    const booking = bookingsCache[refUpper];

    if (!booking) {
      return NextResponse.json({ error: 'Booking not found' }, { status: 404 });
    }

    const nameMatch = booking.passengers.some(
      p => p.lastName.toLowerCase() === lastName.toLowerCase()
    );

    if (!nameMatch) {
      return NextResponse.json({ error: 'Passenger last name does not match reservation' }, { status: 400 });
    }

    // Perform checkin
    const updatedCheckIn = { ...booking.checkInStatus };
    if (passengerId) {
      updatedCheckIn[passengerId] = true;
    } else {
      // Check in all passengers
      booking.passengers.forEach(p => {
        updatedCheckIn[p.id] = true;
      });
    }

    booking.checkInStatus = updatedCheckIn;
    bookingsCache[refUpper] = { ...booking };

    return NextResponse.json({
      success: true,
      booking,
    });
  } catch (err: any) {
    return NextResponse.json({ error: 'Check-in failed', message: err.message }, { status: 500 });
  }
}
