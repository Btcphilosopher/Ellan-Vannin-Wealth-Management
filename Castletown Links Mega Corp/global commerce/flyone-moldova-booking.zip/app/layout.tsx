import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'FLYONE Moldova - Airline Booking',
  description: 'Official booking portal for FLYONE Moldova. Quick, premium, and seamless European airline booking experience from Chișinău.',
  openGraph: {
    title: 'FLYONE Moldova - Airline Booking',
    description: 'Official booking portal for FLYONE Moldova. Quick, premium, and seamless European airline booking experience from Chișinău.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'FLYONE Moldova - Airline Booking',
    description: 'Official booking portal for FLYONE Moldova. Quick, premium, and seamless European airline booking experience from Chișinău.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
