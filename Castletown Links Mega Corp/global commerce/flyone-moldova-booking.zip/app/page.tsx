'use client';

import React, { useTransition } from 'react';
import { BookingProvider, useBooking } from '@/components/BookingProvider';
import Header from '@/components/Header';
import FlightSearch from '@/components/FlightSearch';
import FlightCard from '@/components/FlightCard';
import FareCard from '@/components/FareCard';
import PriceSummary from '@/components/PriceSummary';
import PassengerForm from '@/components/PassengerForm';
import BaggageSelector from '@/components/BaggageSelector';
import SeatMap from '@/components/SeatMap';
import Checkout from '@/components/Checkout';
import BookingConfirmation from '@/components/BookingConfirmation';
import MyBookingPage from '@/components/MyBookingPage';
import CheckInPage from '@/components/CheckInPage';
import DestinationsPage from '@/components/DestinationsPage';
import BaggageInfoPage from '@/components/BaggageInfoPage';
import { calculateTotal } from '@/lib/bookingState';
import { motion, AnimatePresence } from 'motion/react';
import { Plane, Star, Award, Shield, AlertCircle, ArrowLeft, ArrowRight, Check, CheckSquare } from 'lucide-react';
import Image from 'next/image';

function BookingFlowContent() {
  const { state, t, setStep, selectOutbound, selectReturn, selectFare, updateExtras, setSearchQuery } = useBooking();
  const [, startTransition] = useTransition();

  const currentStep = state.step;
  const isRoundTrip = state.searchQuery?.tripType === 'roundTrip';

  const navigateTo = (step: typeof state.step) => {
    startTransition(() => {
      setStep(step);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  };

  // Step Indicators for Progress Stepper (Active during booking flow)
  const isBookingFlow = [
    'results',
    'fares',
    'passengers',
    'baggage',
    'seats',
    'extras',
    'checkout',
  ].includes(currentStep);

  const stepsList = [
    { key: 'results', label: t('nav.flights') },
    { key: 'fares', label: 'Tarif' },
    { key: 'passengers', label: 'Pasageri' },
    { key: 'baggage', label: t('nav.baggage') },
    { key: 'seats', label: 'Locuri' },
    { key: 'checkout', label: 'Plată' },
  ];

  const getActiveStepIdx = () => {
    if (currentStep === 'results') return 0;
    if (currentStep === 'fares') return 1;
    if (currentStep === 'passengers') return 2;
    if (currentStep === 'baggage') return 3;
    if (currentStep === 'seats') return 4;
    return 5; // checkout
  };

  return (
    <div className="flex flex-col min-h-screen bg-slate-50/50 text-slate-800">
      
      {/* Header element (RO/EN, navigation) */}
      <Header />

      <main className="flex-grow py-6 sm:py-8">
        
        {/* Dynamic Progress Stepper */}
        {isBookingFlow && (
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 mb-6 sm:mb-8">
            <div className="bg-white border border-slate-100 rounded-xl p-3 sm:p-4 shadow-2xs flex items-center justify-between overflow-x-auto scrollbar-none gap-4">
              {stepsList.map((st, idx) => {
                const activeIdx = getActiveStepIdx();
                const isCompleted = idx < activeIdx;
                const isActive = idx === activeIdx;

                return (
                  <div key={st.key} className="flex items-center gap-2 shrink-0">
                    <div
                      className={`h-6 w-6 rounded-full flex items-center justify-center text-3xs font-extrabold tracking-tight transition-all ${
                        isCompleted
                          ? 'bg-emerald-600 text-white'
                          : isActive
                          ? 'bg-blue-900 text-white shadow-sm shadow-blue-900/15 ring-2 ring-blue-100'
                          : 'bg-slate-100 text-slate-400'
                      }`}
                    >
                      {isCompleted ? <Check className="h-3.5 w-3.5" /> : idx + 1}
                    </div>
                    <span
                      className={`text-2xs sm:text-xs font-black uppercase tracking-wider ${
                        isActive ? 'text-blue-950 font-black' : 'text-slate-400 font-bold'
                      }`}
                    >
                      {st.label}
                    </span>
                    {idx < stepsList.length - 1 && (
                      <span className="text-slate-300 text-3xs font-extrabold ml-2">/</span>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.25, ease: 'easeOut' }}
            className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8"
          >
            
            {/* 1. HOMEPAGE VIEW */}
            {currentStep === 'home' && (
              <div className="space-y-16">
                
                {/* Hero section */}
                <div className="relative rounded-2xl overflow-hidden min-h-[440px] sm:min-h-[500px] flex items-center">
                  <div className="absolute inset-0 z-0">
                    <Image
                      src="/images/hero_aircraft_chisinau_1790840824927.jpg"
                      alt="FLYONE Moldova aircraft"
                      fill
                      className="object-cover brightness-[0.4]"
                      priority
                      referrerPolicy="no-referrer"
                    />
                  </div>

                  <div className="relative z-10 w-full px-6 sm:px-12 lg:px-16 py-12 text-white max-w-2xl space-y-4">
                    <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black uppercase tracking-wide text-wrap balance leading-none drop-shadow">
                      {t('hero.title')}
                    </h1>
                    <p className="text-base sm:text-lg font-semibold tracking-wider text-amber-400">
                      {t('hero.subtitle')}
                    </p>
                  </div>
                </div>

                {/* Main Flight Search block */}
                <div className="relative -mt-24 sm:-mt-32 z-25 max-w-5xl mx-auto">
                  <FlightSearch />
                </div>

                {/* Popular Destinations Cards */}
                <div className="space-y-6 pt-6">
                  <div className="text-center max-w-md mx-auto space-y-2">
                    <h2 className="text-lg sm:text-xl font-black text-blue-950 uppercase tracking-wider">
                      Destinații în vogă
                    </h2>
                    <p className="text-xs text-slate-500 font-semibold leading-relaxed">
                      Zboruri directe către inima Europei, cu tarife promoționale accesibile.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    
                    {/* Destination 1: Rome */}
                    <div className="group rounded-xl border border-slate-100 bg-white overflow-hidden shadow-2xs hover:shadow-sm transition-all flex flex-col h-full">
                      <div className="relative h-44 w-full bg-slate-50">
                        <Image
                          src="/images/destination_rome_1790840834133.jpg"
                          alt="Rome Colosseum"
                          fill
                          className="object-cover group-hover:scale-102 transition-transform duration-300"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                      <div className="p-4 flex-1 flex flex-col justify-between space-y-4">
                        <div>
                          <span className="text-3xs font-extrabold text-blue-900 uppercase tracking-widest block">
                            Italia
                          </span>
                          <h3 className="font-black text-sm uppercase tracking-wider text-blue-950 mt-1">
                            Roma (FCO)
                          </h3>
                        </div>
                        <button
                          onClick={() => {
                            setSearchQuery({
                              originCode: 'RMO',
                              destinationCode: 'FCO',
                              departureDate: '2026-10-12',
                              returnDate: '2026-10-19',
                              tripType: 'roundTrip',
                              passengers: { adults: 1, children: 0, infants: 0 },
                            });
                            navigateTo('home');
                            window.scrollTo({ top: 400, behavior: 'smooth' });
                          }}
                          className="w-full text-center py-2.5 rounded-lg bg-blue-900 text-white font-black text-xs uppercase tracking-wider hover:bg-blue-800 transition-colors"
                        >
                          Zboară de la €79,99
                        </button>
                      </div>
                    </div>

                    {/* Destination 2: Paris */}
                    <div className="group rounded-xl border border-slate-100 bg-white overflow-hidden shadow-2xs hover:shadow-sm transition-all flex flex-col h-full">
                      <div className="relative h-44 w-full bg-slate-50">
                        <Image
                          src="/images/destination_paris_1790840843809.jpg"
                          alt="Eiffel Tower Paris"
                          fill
                          className="object-cover group-hover:scale-102 transition-transform duration-300"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                      <div className="p-4 flex-1 flex flex-col justify-between space-y-4">
                        <div>
                          <span className="text-3xs font-extrabold text-blue-900 uppercase tracking-widest block">
                            Franța
                          </span>
                          <h3 className="font-black text-sm uppercase tracking-wider text-blue-950 mt-1">
                            Paris (CDG)
                          </h3>
                        </div>
                        <button
                          onClick={() => {
                            setSearchQuery({
                              originCode: 'RMO',
                              destinationCode: 'CDG',
                              departureDate: '2026-10-12',
                              returnDate: '2026-10-19',
                              tripType: 'roundTrip',
                              passengers: { adults: 1, children: 0, infants: 0 },
                            });
                            navigateTo('home');
                            window.scrollTo({ top: 400, behavior: 'smooth' });
                          }}
                          className="w-full text-center py-2.5 rounded-lg bg-blue-900 text-white font-black text-xs uppercase tracking-wider hover:bg-blue-800 transition-colors"
                        >
                          Zboară de la €119,99
                        </button>
                      </div>
                    </div>

                    {/* Destination 3: London */}
                    <div className="group rounded-xl border border-slate-100 bg-white overflow-hidden shadow-2xs hover:shadow-sm transition-all flex flex-col h-full">
                      <div className="relative h-44 w-full bg-slate-50">
                        <Image
                          src="/images/destination_london_1790840855786.jpg"
                          alt="Big Ben London"
                          fill
                          className="object-cover group-hover:scale-102 transition-transform duration-300"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                      <div className="p-4 flex-1 flex flex-col justify-between space-y-4">
                        <div>
                          <span className="text-3xs font-extrabold text-blue-900 uppercase tracking-widest block">
                            Marea Britanie
                          </span>
                          <h3 className="font-black text-sm uppercase tracking-wider text-blue-950 mt-1">
                            Londra (LTN)
                          </h3>
                        </div>
                        <button
                          onClick={() => {
                            setSearchQuery({
                              originCode: 'RMO',
                              destinationCode: 'LTN',
                              departureDate: '2026-10-12',
                              returnDate: '2026-10-19',
                              tripType: 'roundTrip',
                              passengers: { adults: 1, children: 0, infants: 0 },
                            });
                            navigateTo('home');
                            window.scrollTo({ top: 400, behavior: 'smooth' });
                          }}
                          className="w-full text-center py-2.5 rounded-lg bg-blue-900 text-white font-black text-xs uppercase tracking-wider hover:bg-blue-800 transition-colors"
                        >
                          Zboară de la €129,99
                        </button>
                      </div>
                    </div>

                  </div>
                </div>

                {/* Trust and Values features */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 bg-slate-100 rounded-2xl p-6 sm:p-8 border border-slate-200">
                  <div className="space-y-2">
                    <Award className="h-7 w-7 text-blue-900" />
                    <h4 className="font-black text-xs uppercase tracking-wider text-blue-950">
                      Zboruri directe rapide
                    </h4>
                    <p className="text-xs text-slate-500 font-semibold leading-relaxed">
                      Zburăm direct de la Chișinău RMO către cele mai mari noduri aeriene și capitale din Europa.
                    </p>
                  </div>
                  <div className="space-y-2">
                    <Star className="h-7 w-7 text-blue-900" />
                    <h4 className="font-black text-xs uppercase tracking-wider text-blue-950">
                      Cea mai tânără flotă
                    </h4>
                    <p className="text-xs text-slate-500 font-semibold leading-relaxed">
                      Flotă modernă formată din aeronave premium din familia Airbus A320 pentru un confort sporit.
                    </p>
                  </div>
                  <div className="space-y-2">
                    <Shield className="h-7 w-7 text-blue-900" />
                    <h4 className="font-black text-xs uppercase tracking-wider text-blue-950">
                      Simplitate & Încredere
                    </h4>
                    <p className="text-xs text-slate-500 font-semibold leading-relaxed">
                      Proceduri simple, transparență deplină de tarifare și check-in rapid online.
                    </p>
                  </div>
                </div>

              </div>
            )}

            {/* 2. FLIGHT RESULTS VIEW */}
            {currentStep === 'results' && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 space-y-6">
                  
                  {/* Outbound section header */}
                  <div className="space-y-4">
                    <button
                      onClick={() => navigateTo('home')}
                      className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-500 hover:text-blue-950 transition-colors"
                    >
                      <ArrowLeft className="h-4 w-4" />
                      <span>{t('confirmation.actions.home')}</span>
                    </button>

                    <div>
                      <h2 className="text-lg font-black text-blue-950 uppercase tracking-wider">
                        {t('results.outbound')}
                      </h2>
                      <p className="text-xs text-slate-400 font-bold mt-1">
                        {state.searchQuery?.originCode} → {state.searchQuery?.destinationCode} · {state.searchQuery?.departureDate}
                      </p>
                    </div>

                    <div className="space-y-3">
                      {state.outboundFlights.map(flight => (
                        <FlightCard
                          key={flight.id}
                          flight={flight}
                          isSelected={state.selectedOutbound?.id === flight.id}
                          onSelect={() => selectOutbound(flight)}
                        />
                      ))}
                    </div>
                  </div>

                  {/* Return Flight Segment */}
                  {isRoundTrip && state.selectedOutbound && (
                    <div className="space-y-4 pt-4 border-t border-slate-200 animate-slideUp">
                      <div>
                        <h2 className="text-lg font-black text-blue-950 uppercase tracking-wider">
                          {t('results.return')}
                        </h2>
                        <p className="text-xs text-slate-400 font-bold mt-1">
                          {state.searchQuery?.destinationCode} → {state.searchQuery?.originCode} · {state.searchQuery?.returnDate}
                        </p>
                      </div>

                      <div className="space-y-3">
                        {state.returnFlights.map(flight => (
                          <FlightCard
                            key={flight.id}
                            flight={flight}
                            isSelected={state.selectedReturn?.id === flight.id}
                            onSelect={() => selectReturn(flight)}
                          />
                        ))}
                      </div>
                    </div>
                  )}

                </div>

                {/* Right hand pricing Summary Sidebar */}
                <div className="lg:col-span-1">
                  <PriceSummary
                    onContinue={() => navigateTo('fares')}
                    continueLabel="Alege tariful"
                    disableContinue={!state.selectedOutbound || (isRoundTrip && !state.selectedReturn)}
                  />
                </div>
              </div>
            )}

            {/* 3. FARES COMPILATION VIEW */}
            {currentStep === 'fares' && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 space-y-6">
                  
                  <button
                    onClick={() => navigateTo('results')}
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-500 hover:text-blue-950 transition-colors"
                  >
                    <ArrowLeft className="h-4 w-4" />
                    <span>Inapoi la zboruri</span>
                  </button>

                  <div>
                    <h2 className="text-lg font-black text-blue-950 uppercase tracking-wider">
                      {t('fares.title')}
                    </h2>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-5 items-stretch">
                    <FareCard
                      type="basic"
                      basePrice={state.selectedOutbound?.basePrice || 79}
                      isSelected={state.selectedFare === 'basic'}
                      onSelect={() => selectFare('basic')}
                    />
                    <FareCard
                      type="standard"
                      basePrice={state.selectedOutbound?.basePrice || 79}
                      isSelected={state.selectedFare === 'standard'}
                      onSelect={() => selectFare('standard')}
                    />
                    <FareCard
                      type="premium"
                      basePrice={state.selectedOutbound?.basePrice || 79}
                      isSelected={state.selectedFare === 'premium'}
                      onSelect={() => selectFare('premium')}
                    />
                  </div>

                </div>

                <div className="lg:col-span-1">
                  <PriceSummary
                    onContinue={() => navigateTo('passengers')}
                    continueLabel="Date pasageri"
                    disableContinue={!state.selectedFare}
                  />
                </div>
              </div>
            )}

            {/* 4. PASSENGER DETAILS FORM VIEW */}
            {currentStep === 'passengers' && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 space-y-4">
                  <button
                    onClick={() => navigateTo('fares')}
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-500 hover:text-blue-950 transition-colors"
                  >
                    <ArrowLeft className="h-4 w-4" />
                    <span>Inapoi la tarife</span>
                  </button>

                  <div>
                    <h2 className="text-lg font-black text-blue-950 uppercase tracking-wider">
                      {t('passengersForm.title')}
                    </h2>
                    <p className="text-xs text-slate-400 mt-1">
                      {t('passengersForm.subtitle')}
                    </p>
                  </div>

                  <PassengerForm onContinue={() => navigateTo('baggage')} />
                </div>

                <div className="lg:col-span-1">
                  <PriceSummary
                    onContinue={() => {
                      // Trigger submit inside child via custom DOM event or just native trigger
                      const submitBtn = document.querySelector('form button[type="submit"]') as HTMLButtonElement;
                      if (submitBtn) submitBtn.click();
                    }}
                    continueLabel="Continuă la bagaje"
                  />
                </div>
              </div>
            )}

            {/* 5. BAGGAGE CUSTOMIZATION VIEW */}
            {currentStep === 'baggage' && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 space-y-4">
                  <button
                    onClick={() => navigateTo('passengers')}
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-500 hover:text-blue-950 transition-colors"
                  >
                    <ArrowLeft className="h-4 w-4" />
                    <span>Inapoi la date pasageri</span>
                  </button>

                  <div>
                    <h2 className="text-lg font-black text-blue-950 uppercase tracking-wider">
                      {t('baggagePage.title')}
                    </h2>
                    <p className="text-xs text-slate-400 mt-1">
                      {t('baggagePage.subtitle')}
                    </p>
                  </div>

                  <BaggageSelector onContinue={() => navigateTo('seats')} />
                </div>

                <div className="lg:col-span-1">
                  <PriceSummary
                    onContinue={() => navigateTo('seats')}
                    continueLabel="Alege locurile"
                  />
                </div>
              </div>
            )}

            {/* 6. CABIN SEATS SELECTION VIEW */}
            {currentStep === 'seats' && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 space-y-4">
                  <button
                    onClick={() => navigateTo('baggage')}
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-500 hover:text-blue-950 transition-colors"
                  >
                    <ArrowLeft className="h-4 w-4" />
                    <span>Inapoi la bagaje</span>
                  </button>

                  <div>
                    <h2 className="text-lg font-black text-blue-950 uppercase tracking-wider">
                      {t('seatsPage.title')}
                    </h2>
                    <p className="text-xs text-slate-400 mt-1">
                      {t('seatsPage.subtitle')}
                    </p>
                  </div>

                  <SeatMap onContinue={() => navigateTo('extras')} />
                </div>

                <div className="lg:col-span-1">
                  <PriceSummary
                    onContinue={() => navigateTo('extras')}
                    continueLabel="Servicii extra"
                  />
                </div>
              </div>
            )}

            {/* 7. ADDITIONAL EXTRAS VIEW */}
            {currentStep === 'extras' && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 space-y-6">
                  <button
                    onClick={() => navigateTo('seats')}
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-500 hover:text-blue-950 transition-colors"
                  >
                    <ArrowLeft className="h-4 w-4" />
                    <span>Inapoi la locuri</span>
                  </button>

                  <div>
                    <h2 className="text-lg font-black text-blue-950 uppercase tracking-wider">
                      {t('extrasPage.title')}
                    </h2>
                    <p className="text-xs text-slate-400 mt-1">
                      {t('extrasPage.subtitle')}
                    </p>
                  </div>

                  {/* Extras Choices Grid */}
                  <div className="grid grid-cols-1 gap-4">
                    
                    {/* Priority boarding */}
                    <div
                      onClick={() => updateExtras('priority', !state.extras.priority)}
                      className={`group rounded-xl border p-5 flex items-center justify-between gap-4 cursor-pointer transition-all ${
                        state.extras.priority
                          ? 'border-blue-900 bg-blue-50/20'
                          : 'border-slate-200 bg-white hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-start gap-3.5">
                        <CheckSquare className={`h-5 w-5 shrink-0 mt-0.5 ${state.extras.priority ? 'text-blue-900' : 'text-slate-300'}`} />
                        <div>
                          <span className="font-bold text-slate-800 text-sm block">
                            {t('extrasPage.priority.name')}
                          </span>
                          <span className="text-xs text-slate-400 font-semibold block mt-1">
                            {t('extrasPage.priority.desc')}
                          </span>
                        </div>
                      </div>
                      <span className="text-xs font-black font-mono text-blue-950 shrink-0">
                        {state.selectedFare === 'premium' ? <span className="text-emerald-600 uppercase">FREE</span> : '+€15.00'}
                      </span>
                    </div>

                    {/* Airport Assistance */}
                    <div
                      onClick={() => updateExtras('assistance', !state.extras.assistance)}
                      className={`group rounded-xl border p-5 flex items-center justify-between gap-4 cursor-pointer transition-all ${
                        state.extras.assistance
                          ? 'border-blue-900 bg-blue-50/20'
                          : 'border-slate-200 bg-white hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-start gap-3.5">
                        <CheckSquare className={`h-5 w-5 shrink-0 mt-0.5 ${state.extras.assistance ? 'text-blue-900' : 'text-slate-300'}`} />
                        <div>
                          <span className="font-bold text-slate-800 text-sm block">
                            {t('extrasPage.assistance.name')}
                          </span>
                          <span className="text-xs text-slate-400 font-semibold block mt-1">
                            {t('extrasPage.assistance.desc')}
                          </span>
                        </div>
                      </div>
                      <span className="text-xs font-black font-mono text-emerald-600 shrink-0 uppercase">
                        FREE
                      </span>
                    </div>

                    {/* SMS alerts */}
                    <div
                      onClick={() => updateExtras('smsNotification', !state.extras.smsNotification)}
                      className={`group rounded-xl border p-5 flex items-center justify-between gap-4 cursor-pointer transition-all ${
                        state.extras.smsNotification
                          ? 'border-blue-900 bg-blue-50/20'
                          : 'border-slate-200 bg-white hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-start gap-3.5">
                        <CheckSquare className={`h-5 w-5 shrink-0 mt-0.5 ${state.extras.smsNotification ? 'text-blue-900' : 'text-slate-300'}`} />
                        <div>
                          <span className="font-bold text-slate-800 text-sm block">
                            {t('extrasPage.smsNotification.name')}
                          </span>
                          <span className="text-xs text-slate-400 font-semibold block mt-1">
                            {t('extrasPage.smsNotification.desc')}
                          </span>
                        </div>
                      </div>
                      <span className="text-xs font-black font-mono text-blue-950 shrink-0">
                        +€5.00
                      </span>
                    </div>

                  </div>

                </div>

                <div className="lg:col-span-1">
                  <PriceSummary
                    onContinue={() => navigateTo('checkout')}
                    continueLabel="Continuă la plată"
                  />
                </div>
              </div>
            )}

            {/* 8. CHECKOUT SECURE PAYMENT VIEW */}
            {currentStep === 'checkout' && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 space-y-4">
                  <button
                    onClick={() => navigateTo('extras')}
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-500 hover:text-blue-950 transition-colors"
                  >
                    <ArrowLeft className="h-4 w-4" />
                    <span>Inapoi la servicii suplimentare</span>
                  </button>

                  <div>
                    <h2 className="text-lg font-black text-blue-950 uppercase tracking-wider">
                      {t('checkout.title')}
                    </h2>
                    <p className="text-xs text-slate-400 mt-1">
                      {t('checkout.subtitle')}
                    </p>
                  </div>

                  <Checkout onSuccess={() => navigateTo('confirmation')} />
                </div>

                <div className="lg:col-span-1">
                  <PriceSummary
                    onContinue={() => {
                      const submitBtn = document.querySelector('form button[type="submit"]') as HTMLButtonElement;
                      if (submitBtn) submitBtn.click();
                    }}
                    continueLabel={t('summary.payBtn')}
                  />
                </div>
              </div>
            )}

            {/* 9. BOOKING CONFIRMATION COMPLETED */}
            {currentStep === 'confirmation' && <BookingConfirmation />}

            {/* 10. MANAGED BOOKINGS VIEW */}
            {currentStep === 'my-booking' && <MyBookingPage />}

            {/* 11. ONLINE CHECK-IN VIEW */}
            {currentStep === 'check-in' && <CheckInPage />}

            {/* 12. DESTINATIONS DIRECTORY */}
            {currentStep === 'destinations' && <DestinationsPage />}

            {/* 13. BAGGAGE GUIDE BOOKLET */}
            {currentStep === 'baggage-info' && <BaggageInfoPage />}

          </motion.div>
        </AnimatePresence>
      </main>

      {/* Footer (clean, non-telemetry, non-clutter) */}
      <footer className="bg-slate-900 text-slate-400 text-xs py-10 mt-12 border-t border-slate-800">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="text-center md:text-left space-y-1">
            <span className="block text-base font-black text-white tracking-widest uppercase">
              {t('nav.brand')} MOLDOVA
            </span>
            <span className="text-3xs block text-slate-500">
              © {new Date().getFullYear()} FLYONE Moldova. Toate drepturile rezervate. Proiect demonstrativ premium.
            </span>
          </div>

          <div className="flex gap-6 font-bold text-3xs text-slate-500 uppercase tracking-widest">
            <button onClick={() => navigateTo('destinations')} className="hover:text-white transition-colors">
              {t('nav.destinations')}
            </button>
            <button onClick={() => navigateTo('baggage-info')} className="hover:text-white transition-colors">
              {t('nav.baggage')}
            </button>
            <button onClick={() => navigateTo('check-in')} className="hover:text-white transition-colors">
              {t('nav.checkin')}
            </button>
            <button onClick={() => navigateTo('my-booking')} className="hover:text-white transition-colors">
              {t('nav.myBooking')}
            </button>
          </div>
        </div>
      </footer>

    </div>
  );
}

export default function BookingFlow() {
  return (
    <BookingProvider>
      <BookingFlowContent />
    </BookingProvider>
  );
}
