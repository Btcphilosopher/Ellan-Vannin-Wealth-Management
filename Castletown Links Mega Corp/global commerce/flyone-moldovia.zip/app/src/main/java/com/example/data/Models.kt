package com.example.data

import com.example.R

data class Airport(
    val code: String,
    val name: String,
    val city: String,
    val country: String
)

data class Destination(
    val code: String,
    val city: String,
    val country: String,
    val descriptionEn: String,
    val descriptionAm: String,
    val descriptionRu: String,
    val minPriceEuro: Int,
    val imageResId: Int? = null
) {
    fun getDescription(lang: Language): String {
        return when (lang) {
            Language.EN -> descriptionEn
            Language.AM -> descriptionAm
            Language.RU -> descriptionRu
        }
    }
}

data class Flight(
    val number: String,
    val fromCode: String,
    val toCode: String,
    val departureTime: String,
    val arrivalTime: String,
    val duration: String,
    val basePriceEuro: Int,
    val isDirect: Boolean = true,
    val isBestPrice: Boolean = false,
    val isRecommended: Boolean = false
)

data class Booking(
    val reference: String,
    val flightNumber: String,
    val fromCode: String,
    val fromCity: String,
    val toCode: String,
    val toCity: String,
    val date: String,
    val departureTime: String,
    val arrivalTime: String,
    val passengerFirstName: String,
    val passengerLastName: String,
    val seat: String,
    val baggage: String,
    val fareType: String,
    val totalPaidEuro: Int,
    val isCheckedIn: Boolean = false
)

object MockData {
    val airports = listOf(
        Airport("EVN", "Zvartnots International Airport", "Yerevan", "Armenia"),
        Airport("CDG", "Charles de Gaulle Airport", "Paris", "France"),
        Airport("FCO", "Leonardo da Vinci–Fiumicino Airport", "Rome", "Italy"),
        Airport("MXP", "Malpensa Airport", "Milan", "Italy"),
        Airport("TBS", "Tbilisi International Airport", "Tbilisi", "Georgia"),
        Airport("DME", "Domodedovo International Airport", "Moscow", "Russia")
    )

    val destinations = listOf(
        Destination(
            "CDG", "Paris", "France",
            "Experience the romance of the Seine, world-class art, and standard French architecture.",
            "Զգացեք Սենայի ռոմանտիկան, համաշխարհային արվեստը և ֆրանսիական ստանդարտ ճարտարապետությունը:",
            "Ощутите романтику Сены, шедевры мирового искусства и классическую французскую архитектуру.",
            129,
            R.drawable.img_yerevan_banner // fallback, we can use gradient cards or same banner with filter
        ),
        Destination(
            "FCO", "Rome", "Italy",
            "Walk through millennia of history, from the Colosseum to the Vatican and exquisite cuisine.",
            "Քայլեք հազարամյակների պատմության միջով՝ Կոլիզեումից մինչև Վատիկան և նրբագեղ խոհանոց:",
            "Пройдите сквозь тысячелетия истории, от Колизея до Ватикана, и насладитесь изысканной кухней.",
            149,
            R.drawable.img_yerevan_banner
        ),
        Destination(
            "MXP", "Milan", "Italy",
            "The capital of global fashion, design, and majestic Gothic architectures.",
            "Համաշխարհային նորաձևության, դիզայնի և վեհասքանչ գոթական ճարտարապետության մայրաքաղաքը:",
            "Столица мировой моды, изысканного дизайна и величественной готической архитектуры.",
            139,
            R.drawable.img_yerevan_banner
        ),
        Destination(
            "TBS", "Tbilisi", "Georgia",
            "A sulfur-bath retreat framed by warm Georgian hospitality and ancient fortress walls.",
            "Ծծմբային բաղնիքների հանգստավայր՝ շրջապատված վրացական ջերմ հյուրընկալությամբ և հին ամրոցի պատերով:",
            "Курорт серных бань в окружении теплого грузинского гостеприимства и древних крепостных стен.",
            59,
            R.drawable.img_yerevan_banner
        ),
        Destination(
            "DME", "Moscow", "Russia",
            "A bustling metropolis where rich historical heritage meets absolute modern scale.",
            "Եռուզեռով լի մեգապոլիս, որտեղ հարուստ պատմական ժառանգությունը հանդիպում է ժամանակակից մասշտաբներին:",
            "Оживленный мегаполис, где богатое историческое наследие сочетается с современным размахом.",
            119,
            R.drawable.img_yerevan_banner
        )
    )

    val flights = mapOf(
        "CDG" to listOf(
            Flight("F1 204", "EVN", "CDG", "09:20", "12:05", "4h 45m", 129, isBestPrice = true),
            Flight("F1 206", "EVN", "CDG", "14:15", "17:00", "4h 45m", 179, isRecommended = true),
            Flight("F1 208", "EVN", "CDG", "20:30", "23:15", "4h 45m", 149)
        ),
        "FCO" to listOf(
            Flight("F1 311", "EVN", "FCO", "06:10", "08:45", "4h 35m", 149, isBestPrice = true),
            Flight("F1 313", "EVN", "FCO", "16:40", "19:15", "4h 35m", 199, isRecommended = true)
        ),
        "MXP" to listOf(
            Flight("F1 325", "EVN", "MXP", "08:00", "10:30", "4h 30m", 139, isBestPrice = true),
            Flight("F1 327", "EVN", "MXP", "18:15", "20:45", "4h 30m", 189, isRecommended = true)
        ),
        "TBS" to listOf(
            Flight("F1 101", "EVN", "TBS", "11:30", "12:15", "0h 45m", 59, isBestPrice = true),
            Flight("F1 103", "EVN", "TBS", "21:00", "21:45", "0h 45m", 79, isRecommended = true)
        ),
        "DME" to listOf(
            Flight("F1 501", "EVN", "DME", "05:30", "07:50", "3h 20m", 119, isBestPrice = true),
            Flight("F1 503", "EVN", "DME", "13:00", "15:20", "3h 20m", 159, isRecommended = true),
            Flight("F1 505", "EVN", "DME", "19:40", "22:00", "3h 20m", 139)
        )
    )

    val defaultBooking = Booking(
        reference = "F1A7KQ",
        flightNumber = "F1 204",
        fromCode = "EVN",
        fromCity = "Yerevan",
        toCode = "CDG",
        toCity = "Paris",
        date = "14 Oct 2026",
        departureTime = "09:20",
        arrivalTime = "12:05",
        passengerFirstName = "Tom",
        passengerLastName = "Example",
        seat = "12A",
        baggage = "Standard (1x 23kg Checked)",
        fareType = "Standard",
        totalPaidEuro = 211,
        isCheckedIn = false
    )
}
