package com.example.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import com.example.data.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

sealed class AppScreen {
    object Home : AppScreen()
    object SearchResults : AppScreen()
    object FareSelection : AppScreen()
    object PassengerDetails : AppScreen()
    object SeatSelection : AppScreen()
    object Summary : AppScreen()
    object ProcessingPayment : AppScreen()
    data class Confirmation(val bookingReference: String) : AppScreen()
    data class TripDetails(val bookingRef: String) : AppScreen()
    data class CheckInScreen(val bookingRef: String) : AppScreen()
    data class BoardingPassScreen(val bookingRef: String) : AppScreen()
    object BaggageInfo : AppScreen()
    object DestinationsInfo : AppScreen()
}

enum class NavigationTab {
    HOME, SEARCH, TRIPS, STATUS, ACCOUNT
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("flyone_prefs", Context.MODE_PRIVATE)

    // Language State
    private val _language = MutableStateFlow(Language.EN)
    val language: StateFlow<Language> = _language.asStateFlow()

    // Navigation Tab
    private val _currentTab = MutableStateFlow(NavigationTab.HOME)
    val currentTab: StateFlow<NavigationTab> = _currentTab.asStateFlow()

    // Screen State within the current tab
    private val _currentScreen = MutableStateFlow<AppScreen>(AppScreen.Home)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    // Screen navigation stack to support back handler
    private val screenStack = mutableListOf<AppScreen>()

    // Bookings State
    private val _bookings = MutableStateFlow<List<Booking>>(listOf(MockData.defaultBooking))
    val bookings: StateFlow<List<Booking>> = _bookings.asStateFlow()

    // Booking Flow State
    private val _searchTo = MutableStateFlow<Destination?>(null)
    val searchTo: StateFlow<Destination?> = _searchTo.asStateFlow()

    private val _isRoundTrip = MutableStateFlow(false)
    val isRoundTrip: StateFlow<Boolean> = _isRoundTrip.asStateFlow()

    private val _searchDate = MutableStateFlow("14 Oct 2026")
    val searchDate: StateFlow<String> = _searchDate.asStateFlow()

    private val _searchReturnDate = MutableStateFlow("21 Oct 2026")
    val searchReturnDate: StateFlow<String> = _searchReturnDate.asStateFlow()

    private val _passengerCount = MutableStateFlow(1)
    val passengerCount: StateFlow<Int> = _passengerCount.asStateFlow()

    // Active Results
    private val _availableFlights = MutableStateFlow<List<Flight>>(emptyList())
    val availableFlights: StateFlow<List<Flight>> = _availableFlights.asStateFlow()

    private val _selectedFlight = MutableStateFlow<Flight?>(null)
    val selectedFlight: StateFlow<Flight?> = _selectedFlight.asStateFlow()

    private val _selectedFareType = MutableStateFlow("Standard") // Basic, Standard, Premium
    val selectedFareType: StateFlow<String> = _selectedFareType.asStateFlow()

    // Passenger details form inputs
    val firstName = MutableStateFlow("")
    val lastName = MutableStateFlow("")
    val dob = MutableStateFlow("")
    val nationality = MutableStateFlow("Armenia")
    val passportNumber = MutableStateFlow("")
    val email = MutableStateFlow("")
    val phone = MutableStateFlow("")

    // Seat Selection
    private val _selectedSeat = MutableStateFlow("12A")
    val selectedSeat: StateFlow<String> = _selectedSeat.asStateFlow()

    // Occupied Seats for Mock A320
    val occupiedSeats = setOf("12B", "12C", "14A", "15D", "15E", "10A", "10C", "8F", "16F")
    val premiumSeats = setOf("1A", "1B", "1C", "1D", "1E", "1F", "2A", "2F", "5A", "5B")

    // Flight Status Tracker State
    val statusQuery = MutableStateFlow("")
    private val _searchedFlightStatus = MutableStateFlow<Flight?>(null)
    val searchedFlightStatus: StateFlow<Flight?> = _searchedFlightStatus.asStateFlow()

    // Live flight timeline stage: 0=Check-in, 1=Boarding, 2=Departed, 3=Airborne, 4=Landed
    private val _timelineStage = MutableStateFlow(0)
    val timelineStage: StateFlow<Int> = _timelineStage.asStateFlow()

    init {
        // Load Saved Language
        val savedLang = prefs.getString("lang", "EN") ?: "EN"
        _language.value = Language.valueOf(savedLang)

        // Load Saved Passenger Details
        firstName.value = prefs.getString("p_first", "") ?: ""
        lastName.value = prefs.getString("p_last", "") ?: ""
        dob.value = prefs.getString("p_dob", "") ?: ""
        nationality.value = prefs.getString("p_nationality", "Armenia") ?: "Armenia"
        passportNumber.value = prefs.getString("p_passport", "") ?: ""
        email.value = prefs.getString("p_email", "") ?: ""
        phone.value = prefs.getString("p_phone", "") ?: ""
    }

    fun setLanguage(lang: Language) {
        _language.value = lang
        prefs.edit().putString("lang", lang.name).apply()
    }

    fun selectTab(tab: NavigationTab) {
        _currentTab.value = tab
        // Clear stack when switching tabs, go to respective Home/Start screens of tabs
        screenStack.clear()
        when (tab) {
            NavigationTab.HOME -> navigateToScreen(AppScreen.Home)
            NavigationTab.SEARCH -> {
                // Pre-populate search with a default destination to make it immediately demonstrable
                _searchTo.value = MockData.destinations[0] // Paris
                executeSearch()
            }
            NavigationTab.TRIPS -> navigateToScreen(AppScreen.Home) // Trips listed in tab directly
            NavigationTab.STATUS -> {
                statusQuery.value = "F1 204"
                searchFlightStatus()
                navigateToScreen(AppScreen.Home)
            }
            NavigationTab.ACCOUNT -> navigateToScreen(AppScreen.Home)
        }
    }

    fun navigateToScreen(screen: AppScreen) {
        screenStack.add(_currentScreen.value)
        _currentScreen.value = screen
    }

    fun navigateBack(): Boolean {
        if (screenStack.isNotEmpty()) {
            val prev = screenStack.removeAt(screenStack.size - 1)
            _currentScreen.value = prev
            return true
        }
        return false
    }

    fun setRoundTrip(round: Boolean) {
        _isRoundTrip.value = round
    }

    fun setDestination(dest: Destination) {
        _searchTo.value = dest
    }

    fun setPassengerCount(count: Int) {
        if (count in 1..9) {
            _passengerCount.value = count
        }
    }

    fun setDepartureDate(date: String) {
        _searchDate.value = date
    }

    fun setReturnDate(date: String) {
        _searchReturnDate.value = date
    }

    fun selectFlight(flight: Flight) {
        _selectedFlight.value = flight
        navigateToScreen(AppScreen.FareSelection)
    }

    fun selectFareType(type: String) {
        _selectedFareType.value = type
    }

    fun savePassengerDetails() {
        prefs.edit()
            .putString("p_first", firstName.value)
            .putString("p_last", lastName.value)
            .putString("p_dob", dob.value)
            .putString("p_nationality", nationality.value)
            .putString("p_passport", passportNumber.value)
            .putString("p_email", email.value)
            .putString("p_phone", phone.value)
            .apply()
    }

    fun selectSeat(seatCode: String) {
        if (!occupiedSeats.contains(seatCode)) {
            _selectedSeat.value = seatCode
        }
    }

    fun executeSearch() {
        val dest = _searchTo.value
        if (dest != null) {
            _availableFlights.value = MockData.flights[dest.code] ?: emptyList()
            navigateToScreen(AppScreen.SearchResults)
        }
    }

    fun startPayment() {
        navigateToScreen(AppScreen.ProcessingPayment)
    }

    fun completeBooking() {
        val ref = generateBookingReference()
        val dest = _searchTo.value ?: MockData.destinations[0]
        val flight = _selectedFlight.value ?: MockData.flights[dest.code]!![0]

        val baseFare = flight.basePriceEuro
        val fareAddon = when (_selectedFareType.value) {
            "Standard" -> 50
            "Premium" -> 110
            else -> 0
        }
        val seatAddon = if (premiumSeats.contains(_selectedSeat.value)) 25 else 12
        val taxes = 32
        val finalPrice = (baseFare + fareAddon) * _passengerCount.value + seatAddon + taxes

        val newBooking = Booking(
            reference = ref,
            flightNumber = flight.number,
            fromCode = "EVN",
            fromCity = "Yerevan",
            toCode = dest.code,
            toCity = dest.city,
            date = _searchDate.value,
            departureTime = flight.departureTime,
            arrivalTime = flight.arrivalTime,
            passengerFirstName = firstName.value.ifBlank { "Tom" },
            passengerLastName = lastName.value.ifBlank { "Example" },
            seat = _selectedSeat.value,
            baggage = when (_selectedFareType.value) {
                "Basic" -> "Cabin Bag Only (8kg)"
                "Standard" -> "Standard (1x 23kg Checked)"
                else -> "Premium Priority (1x 23kg Checked + Cabin)"
            },
            fareType = _selectedFareType.value,
            totalPaidEuro = finalPrice,
            isCheckedIn = false
        )

        // Save Traveler Profile automatically if checkboxes checked
        savePassengerDetails()

        // Append to state
        val updatedList = _bookings.value.toMutableList()
        updatedList.add(0, newBooking)
        _bookings.value = updatedList

        _currentScreen.value = AppScreen.Confirmation(ref)
    }

    fun checkInBooking(ref: String) {
        val list = _bookings.value.map {
            if (it.reference == ref) {
                it.copy(isCheckedIn = true)
            } else {
                it
            }
        }
        _bookings.value = list
        navigateToScreen(AppScreen.BoardingPassScreen(ref))
    }

    fun searchFlightStatus() {
        val query = statusQuery.value.trim().uppercase()
        // Simple filter matching query across all mock flights
        var found: Flight? = null
        for (flightsList in MockData.flights.values) {
            for (f in flightsList) {
                if (f.number.replace(" ", "").uppercase() == query.replace(" ", "")) {
                    found = f
                    break
                }
            }
            if (found != null) break
        }
        // Fallback to F1 204
        _searchedFlightStatus.value = found ?: MockData.flights["CDG"]!![0]
        // Random timeline stage
        _timelineStage.value = (0..4).random()
    }

    fun advanceTimelineStage() {
        _timelineStage.value = (_timelineStage.value + 1) % 5
    }

    private fun generateBookingReference(): String {
        val chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        return "F1" + (1..4).map { chars.random() }.joinToString("")
    }
}
