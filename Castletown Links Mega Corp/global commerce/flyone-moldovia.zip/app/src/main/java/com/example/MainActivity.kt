package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.MainViewModel
import com.example.ui.theme.MyApplicationTheme
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.*
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val viewModel: MainViewModel = viewModel()
                AppShell(viewModel)
            }
        }
    }
}

@Composable
fun AppShell(viewModel: MainViewModel) {
    val currentTab by viewModel.currentTab.collectAsState()
    val currentScreen by viewModel.currentScreen.collectAsState()
    val language by viewModel.language.collectAsState()

    // Global back handler
    BackHandler(enabled = currentScreen != AppScreen.Home) {
        viewModel.navigateBack()
    }

    Scaffold(
        bottomBar = {
            NavigationBar(
                modifier = Modifier
                    .testTag("bottom_nav_bar")
                    .windowInsetsPadding(WindowInsets.navigationBars),
                containerColor = Color.White,
                tonalElevation = 8.dp
            ) {
                val items = listOf(
                    NavigationTab.HOME to Icons.Default.Home,
                    NavigationTab.SEARCH to Icons.Default.Search,
                    NavigationTab.TRIPS to Icons.Default.FlightTakeoff,
                    NavigationTab.STATUS to Icons.Default.Timeline,
                    NavigationTab.ACCOUNT to Icons.Default.Person
                )

                items.forEach { (tab, icon) ->
                    val isSelected = currentTab == tab
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { viewModel.selectTab(tab) },
                        icon = { Icon(icon, contentDescription = tab.name) },
                        label = {
                            Text(
                                text = Translations.get(tab.name.lowercase(), language),
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            AnimatedContent(
                targetState = Pair(currentTab, currentScreen),
                transitionSpec = {
                    fadeIn(animationSpec = tween(220)) togetherWith fadeOut(animationSpec = tween(220))
                },
                label = "screen_transitions"
            ) { (tab, screen) ->
                when (tab) {
                    NavigationTab.HOME -> {
                        when (screen) {
                            is AppScreen.Home -> HomeScreen(viewModel, language)
                            is AppScreen.SearchResults -> SearchResultsScreen(viewModel, language)
                            is AppScreen.FareSelection -> FareSelectionScreen(viewModel, language)
                            is AppScreen.PassengerDetails -> PassengerDetailsScreen(viewModel, language)
                            is AppScreen.SeatSelection -> SeatSelectionScreen(viewModel, language)
                            is AppScreen.Summary -> SummaryScreen(viewModel, language)
                            is AppScreen.ProcessingPayment -> ProcessingPaymentScreen(viewModel, language)
                            is AppScreen.Confirmation -> ConfirmationScreen(screen.bookingReference, viewModel, language)
                            is AppScreen.BaggageInfo -> BaggageInfoScreen(viewModel, language)
                            is AppScreen.DestinationsInfo -> DestinationsScreen(viewModel, language)
                            else -> HomeScreen(viewModel, language)
                        }
                    }
                    NavigationTab.SEARCH -> {
                        // Directly enters search results
                        when (screen) {
                            is AppScreen.SearchResults -> SearchResultsScreen(viewModel, language)
                            is AppScreen.FareSelection -> FareSelectionScreen(viewModel, language)
                            is AppScreen.PassengerDetails -> PassengerDetailsScreen(viewModel, language)
                            is AppScreen.SeatSelection -> SeatSelectionScreen(viewModel, language)
                            is AppScreen.Summary -> SummaryScreen(viewModel, language)
                            is AppScreen.ProcessingPayment -> ProcessingPaymentScreen(viewModel, language)
                            is AppScreen.Confirmation -> ConfirmationScreen(screen.bookingReference, viewModel, language)
                            else -> SearchResultsScreen(viewModel, language)
                        }
                    }
                    NavigationTab.TRIPS -> {
                        when (screen) {
                            is AppScreen.Home -> TripsListScreen(viewModel, language)
                            is AppScreen.TripDetails -> TripDetailsScreen(screen.bookingRef, viewModel, language)
                            is AppScreen.CheckInScreen -> CheckInScreen(screen.bookingRef, viewModel, language)
                            is AppScreen.BoardingPassScreen -> BoardingPassScreen(screen.bookingRef, viewModel, language)
                            else -> TripsListScreen(viewModel, language)
                        }
                    }
                    NavigationTab.STATUS -> {
                        FlightStatusScreen(viewModel, language)
                    }
                    NavigationTab.ACCOUNT -> {
                        AccountScreen(viewModel, language)
                    }
                }
            }
        }
    }
}

// ==================== HOME TAB SCREEN ====================
@Composable
fun HomeScreen(viewModel: MainViewModel, lang: Language) {
    var showDestDropdown by remember { mutableStateOf(false) }
    val searchTo by viewModel.searchTo.collectAsState()
    val isRoundTrip by viewModel.isRoundTrip.collectAsState()
    val searchDate by viewModel.searchDate.collectAsState()
    val searchReturnDate by viewModel.searchReturnDate.collectAsState()
    val passengers by viewModel.passengerCount.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("home_screen_scroll"),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // App Top Bar / Wordmark Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "FLYONE",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 24.sp,
                        letterSpacing = 2.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    // Custom Armenian tricolor accent line
                    Row(modifier = Modifier.width(60.dp).height(3.dp)) {
                        Box(modifier = Modifier.weight(1f).fillMaxHeight().background(Color(0xFFD0312D))) // Red
                        Box(modifier = Modifier.weight(1f).fillMaxHeight().background(Color(0xFF0033A0))) // Blue
                        Box(modifier = Modifier.weight(1f).fillMaxHeight().background(Color(0xFFF2A800))) // Orange
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = when(lang) {
                                Language.EN -> "🇬🇧 EN"
                                Language.AM -> "🇦🇲 AM"
                                Language.RU -> "🇷🇺 RU"
                            },
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Icon(
                        Icons.Outlined.AccountCircle,
                        contentDescription = "Profile",
                        modifier = Modifier.size(32.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        // Hero Banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .padding(horizontal = 16.dp)
                    .clip(RoundedCornerShape(16.dp))
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_yerevan_banner),
                    contentDescription = "Yerevan Banner",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                // Gradient overlay
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.7f))
                            )
                        )
                )
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(16.dp)
                ) {
                    Text(
                        text = Translations.get("where_to", lang),
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = Translations.get("synthetic_disclaimer", lang),
                        color = Color.LightGray,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Search Flight Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Journey Type Tabs (Roundtrip / OneWay)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFFF3F1ED))
                            .padding(3.dp)
                    ) {
                        Button(
                            onClick = { viewModel.setRoundTrip(true) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(6.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isRoundTrip) Color.White else Color.Transparent,
                                contentColor = if (isRoundTrip) MaterialTheme.colorScheme.primary else Color.Gray
                            ),
                            contentPadding = PaddingValues(vertical = 8.dp),
                            elevation = null
                        ) {
                            Text(Translations.get("round_trip", lang), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = { viewModel.setRoundTrip(false) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(6.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (!isRoundTrip) Color.White else Color.Transparent,
                                contentColor = if (!isRoundTrip) MaterialTheme.colorScheme.primary else Color.Gray
                            ),
                            contentPadding = PaddingValues(vertical = 8.dp),
                            elevation = null
                        ) {
                            Text(Translations.get("one_way", lang), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Origin Input (EVN - Yerevan)
                    Text(
                        text = Translations.get("from", lang).uppercase(),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.FlightTakeoff, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("Yerevan", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text("Zvartnots Intl • EVN", fontSize = 12.sp, color = Color.Gray)
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    // Destination Selector
                    Text(
                        text = Translations.get("to", lang).uppercase(),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showDestDropdown = true }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.FlightLand, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            if (searchTo != null) {
                                Text(searchTo!!.city, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Text("${searchTo!!.country} • ${searchTo!!.code}", fontSize = 12.sp, color = Color.Gray)
                            } else {
                                Text("Select destination", fontWeight = FontWeight.Bold, color = Color.LightGray, fontSize = 16.sp)
                            }
                        }
                        Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                    }

                    // Destinations Dropdown Modal
                    DropdownMenu(
                        expanded = showDestDropdown,
                        onDismissRequest = { showDestDropdown = false },
                        modifier = Modifier.fillMaxWidth(0.85f).background(Color.White)
                    ) {
                        MockData.destinations.forEach { dest ->
                            DropdownMenuItem(
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.LocationOn, contentDescription = null, tint = Color.Gray)
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column {
                                            Text(dest.city, fontWeight = FontWeight.Bold, color = Color.Black)
                                            Text("${dest.country} (${dest.code})", fontSize = 12.sp, color = Color.Gray)
                                        }
                                    }
                                },
                                onClick = {
                                    viewModel.setDestination(dest)
                                    showDestDropdown = false
                                }
                            )
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    // Departure & Return Dates
                    Row(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = Translations.get("departure", lang).uppercase(),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(searchDate, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        }

                        if (isRoundTrip) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = Translations.get("return_date", lang).uppercase(),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Gray
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(searchReturnDate, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            }
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                    // Passengers Count Selector
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = Translations.get("passengers", lang).uppercase(),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray
                            )
                            Text("$passengers Adult", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = { viewModel.setPassengerCount(passengers - 1) },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(Icons.Default.RemoveCircleOutline, contentDescription = "Decrease", tint = MaterialTheme.colorScheme.primary)
                            }
                            Text(
                                text = "$passengers",
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 12.dp)
                            )
                            IconButton(
                                onClick = { viewModel.setPassengerCount(passengers + 1) },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(Icons.Default.AddCircleOutline, contentDescription = "Increase", tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Search Button
                    Button(
                        onClick = { viewModel.executeSearch() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("search_flights_btn"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = Color.White
                        )
                    ) {
                        Text(
                            text = Translations.get("search_flights", lang),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Popular Destinations Carousel
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                Text(
                    text = Translations.get("popular_dest", lang),
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(12.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    contentPadding = PaddingValues(end = 16.dp)
                ) {
                    items(MockData.destinations) { dest ->
                        DestinationCard(dest, lang) {
                            viewModel.setDestination(dest)
                            viewModel.executeSearch()
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DestinationCard(dest: Destination, lang: Language, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .width(160.dp)
            .height(220.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Image(
                painter = painterResource(id = R.drawable.img_yerevan_banner),
                contentDescription = dest.city,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            // Overlay gradient to make text readable
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f))
                        )
                    )
            )

            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(12.dp)
            ) {
                Text(
                    text = "EVN ➔ ${dest.code}",
                    color = Color.LightGray,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = dest.city,
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "From €${dest.minPriceEuro}",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Icon(
                        Icons.Filled.ArrowCircleRight,
                        contentDescription = "Select",
                        tint = MaterialTheme.colorScheme.tertiary,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }
    }
}

// ==================== SEARCH RESULTS SCREEN ====================
@Composable
fun SearchResultsScreen(viewModel: MainViewModel, lang: Language) {
    val searchTo by viewModel.searchTo.collectAsState()
    val availableFlights by viewModel.availableFlights.collectAsState()
    val date by viewModel.searchDate.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        // App bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateBack() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "Yerevan (EVN) ➔ ${searchTo?.city ?: ""} (${searchTo?.code ?: ""})",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                Text(
                    text = date,
                    fontSize = 13.sp,
                    color = Color.Gray
                )
            }
        }

        if (availableFlights.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(text = "No flights available for this route.", color = Color.Gray)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                items(availableFlights) { flight ->
                    FlightCardItem(flight, lang) {
                        viewModel.selectFlight(flight)
                    }
                }
            }
        }
    }
}

@Composable
fun FlightCardItem(flight: Flight, lang: Language, onSelect: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelect() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Badges
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(
                    text = flight.number,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                if (flight.isBestPrice) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color(0xFFE8F5E9))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(Translations.get("best_price", lang), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
                    }
                } else if (flight.isRecommended) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color(0xFFE3F2FD))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(Translations.get("recommended", lang), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1565C0))
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Flight details row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(flight.departureTime, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(flight.fromCode, fontSize = 12.sp, color = Color.Gray)
                }

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(flight.duration, fontSize = 12.sp, color = Color.Gray)
                    // Visual timeline line
                    Row(
                        modifier = Modifier.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(Color.Gray))
                        Box(modifier = Modifier.width(80.dp).height(1.dp).background(Color.Gray))
                        Icon(Icons.Default.FlightTakeoff, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                        Box(modifier = Modifier.width(80.dp).height(1.dp).background(Color.Gray))
                        Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(Color.Gray))
                    }
                    Text(Translations.get("direct", lang), fontSize = 12.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(flight.arrivalTime, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(flight.toCode, fontSize = 12.sp, color = Color.Gray)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Price & Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "€${flight.basePriceEuro}",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.primary
                )
                Button(
                    onClick = { onSelect() },
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text(Translations.get("select", lang), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ==================== FARE SELECTION SCREEN ====================
@Composable
fun FareSelectionScreen(viewModel: MainViewModel, lang: Language) {
    val selectedFlight by viewModel.selectedFlight.collectAsState()
    val activeFareType by viewModel.selectedFareType.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateBack() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = Translations.get("choose_fare", lang),
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        }

        if (selectedFlight == null) return

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            val fares = listOf(
                Triple("Basic", 0, listOf(Translations.get("cabin_bag", lang), Translations.get("seat_selection_inc", lang))),
                Triple("Standard", 50, listOf(Translations.get("cabin_bag", lang), Translations.get("checked_bag", lang), Translations.get("seat_selection_inc", lang))),
                Triple("Premium", 110, listOf(Translations.get("cabin_bag", lang), Translations.get("checked_bag", lang), Translations.get("premium_seat_inc", lang), Translations.get("priority", lang), Translations.get("flexibility", lang)))
            )

            items(fares) { (name, addon, itemsList) ->
                val price = selectedFlight!!.basePriceEuro + addon
                val isSelected = activeFareType == name

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            width = if (isSelected) 2.dp else 1.dp,
                            color = if (isSelected) MaterialTheme.colorScheme.primary else Color.LightGray,
                            shape = RoundedCornerShape(16.dp)
                        )
                        .clickable { viewModel.selectFareType(name) },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = if (isSelected) Color(0xFFF0F4F8) else Color.White)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(name, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = MaterialTheme.colorScheme.primary)
                            Text("€$price", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        itemsList.forEach { detail ->
                            Row(
                                modifier = Modifier.padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF2E7D32), modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(detail, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
        }

        // Bottom summary and action
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Total Price", fontSize = 12.sp, color = Color.Gray)
                    val base = selectedFlight!!.basePriceEuro
                    val addon = when (activeFareType) {
                        "Standard" -> 50
                        "Premium" -> 110
                        else -> 0
                    }
                    Text("€${base + addon}", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                }

                Button(
                    onClick = { viewModel.navigateToScreen(AppScreen.PassengerDetails) },
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(Translations.get("continue", lang), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ==================== PASSENGER DETAILS SCREEN ====================
@Composable
fun PassengerDetailsScreen(viewModel: MainViewModel, lang: Language) {
    val firstName by viewModel.firstName.collectAsState()
    val lastName by viewModel.lastName.collectAsState()
    val dob by viewModel.dob.collectAsState()
    val nationality by viewModel.nationality.collectAsState()
    val passportNumber by viewModel.passportNumber.collectAsState()
    val email by viewModel.email.collectAsState()
    val phone by viewModel.phone.collectAsState()

    var attemptedSubmit by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateBack() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = Translations.get("passenger_details", lang),
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                OutlinedTextField(
                    value = firstName,
                    onValueChange = { viewModel.firstName.value = it },
                    label = { Text(Translations.get("first_name", lang)) },
                    modifier = Modifier.fillMaxWidth().testTag("first_name_input"),
                    isError = attemptedSubmit && firstName.isBlank()
                )
            }

            item {
                OutlinedTextField(
                    value = lastName,
                    onValueChange = { viewModel.lastName.value = it },
                    label = { Text(Translations.get("last_name", lang)) },
                    modifier = Modifier.fillMaxWidth().testTag("last_name_input"),
                    isError = attemptedSubmit && lastName.isBlank()
                )
            }

            item {
                OutlinedTextField(
                    value = dob,
                    onValueChange = { viewModel.dob.value = it },
                    label = { Text("${Translations.get("dob", lang)} (DD/MM/YYYY)") },
                    modifier = Modifier.fillMaxWidth(),
                    isError = attemptedSubmit && dob.isBlank(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
            }

            item {
                OutlinedTextField(
                    value = nationality,
                    onValueChange = { viewModel.nationality.value = it },
                    label = { Text(Translations.get("nationality", lang)) },
                    modifier = Modifier.fillMaxWidth(),
                    isError = attemptedSubmit && nationality.isBlank()
                )
            }

            item {
                OutlinedTextField(
                    value = passportNumber,
                    onValueChange = { viewModel.passportNumber.value = it },
                    label = { Text(Translations.get("passport", lang)) },
                    modifier = Modifier.fillMaxWidth().testTag("passport_input"),
                    isError = attemptedSubmit && passportNumber.length < 5
                )
            }

            item {
                OutlinedTextField(
                    value = email,
                    onValueChange = { viewModel.email.value = it },
                    label = { Text(Translations.get("email", lang)) },
                    modifier = Modifier.fillMaxWidth(),
                    isError = attemptedSubmit && (!email.contains("@") || email.isBlank()),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                )
            }

            item {
                OutlinedTextField(
                    value = phone,
                    onValueChange = { viewModel.phone.value = it },
                    label = { Text(Translations.get("phone", lang)) },
                    modifier = Modifier.fillMaxWidth(),
                    isError = attemptedSubmit && phone.isBlank(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                )
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(checked = true, onCheckedChange = { })
                    Text(Translations.get("save_profile", lang), fontSize = 14.sp)
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
                Button(
                    onClick = {
                        attemptedSubmit = true
                        if (firstName.isNotBlank() && lastName.isNotBlank() && dob.isNotBlank() && passportNumber.length >= 5 && email.contains("@") && phone.isNotBlank()) {
                            viewModel.savePassengerDetails()
                            viewModel.navigateToScreen(AppScreen.SeatSelection)
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("passenger_details_submit"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(Translations.get("continue", lang), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }
        }
    }
}

// ==================== SEAT SELECTION SCREEN ====================
@Composable
fun SeatSelectionScreen(viewModel: MainViewModel, lang: Language) {
    val selectedSeat by viewModel.selectedSeat.collectAsState()
    val premiumSeats = viewModel.premiumSeats
    val occupiedSeats = viewModel.occupiedSeats

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateBack() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = Translations.get("seat_selection", lang),
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        }

        Text(
            text = Translations.get("select_seat_desc", lang),
            fontSize = 13.sp,
            color = Color.Gray,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
        )

        // Seats Map Layout
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Legend
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp, horizontal = 20.dp),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(16.dp).clip(RoundedCornerShape(4.dp)).background(MaterialTheme.colorScheme.primary))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(Translations.get("selected_seat", lang), fontSize = 11.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(16.dp).clip(RoundedCornerShape(4.dp)).background(Color.White).border(1.dp, Color.LightGray, RoundedCornerShape(4.dp)))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(Translations.get("standard_seat", lang), fontSize = 11.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(16.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xFFD4AF37)))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(Translations.get("premium_seat", lang), fontSize = 11.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(16.dp).clip(RoundedCornerShape(4.dp)).background(Color.LightGray))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(Translations.get("occupied", lang), fontSize = 11.sp)
                }
            }

            // Aircraft Cabin Outline
            Card(
                modifier = Modifier
                    .width(320.dp)
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                shape = RoundedCornerShape(topStart = 60.dp, topEnd = 60.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(top = 40.dp, bottom = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Flight Deck Door label
                    Text(
                        text = "FLIGHT DECK / COCKPIT",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.LightGray,
                        modifier = Modifier.padding(bottom = 24.dp)
                    )

                    // We represent rows 1..18
                    for (row in 1..18) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp, horizontal = 12.dp),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Left 3 seats: A, B, C
                            listOf("A", "B", "C").forEach { letter ->
                                val seatCode = "$row$letter"
                                SeatButton(seatCode, selectedSeat, premiumSeats, occupiedSeats) {
                                    viewModel.selectSeat(seatCode)
                                }
                            }

                            // Row number in Aisle
                            Text(
                                text = "$row",
                                modifier = Modifier.width(28.dp),
                                textAlign = TextAlign.Center,
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray,
                                fontSize = 12.sp
                            )

                            // Right 3 seats: D, E, F
                            listOf("D", "E", "F").forEach { letter ->
                                val seatCode = "$row$letter"
                                SeatButton(seatCode, selectedSeat, premiumSeats, occupiedSeats) {
                                    viewModel.selectSeat(seatCode)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Selected seat summary footer
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    val isPremium = premiumSeats.contains(selectedSeat)
                    Text("Seat $selectedSeat (${if (isPremium) "Premium" else "Standard"})", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Text(text = "Fee: €${if (isPremium) 25 else 12}", fontSize = 12.sp, color = Color.Gray)
                }

                Button(
                    onClick = { viewModel.navigateToScreen(AppScreen.Summary) },
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("seat_confirm_btn")
                ) {
                    Text(Translations.get("continue", lang), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun SeatButton(
    seatCode: String,
    selectedSeat: String,
    premiumSeats: Set<String>,
    occupiedSeats: Set<String>,
    onClick: () -> Unit
) {
    val isSelected = seatCode == selectedSeat
    val isPremium = premiumSeats.contains(seatCode)
    val isOccupied = occupiedSeats.contains(seatCode)

    val bgColor = when {
        isSelected -> MaterialTheme.colorScheme.primary
        isOccupied -> Color.LightGray
        isPremium -> Color(0xFFD4AF37) // Gold
        else -> Color.White
    }

    val textColor = when {
        isSelected -> Color.White
        isOccupied -> Color.Gray
        else -> Color.Black
    }

    Box(
        modifier = Modifier
            .size(34.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .border(
                1.dp,
                if (isSelected || isOccupied) Color.Transparent else Color.LightGray,
                RoundedCornerShape(6.dp)
            )
            .clickable(enabled = !isOccupied) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = seatCode.takeLast(1),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = textColor
        )
    }
}

// ==================== BOOKING SUMMARY & CHECKOUT SCREEN ====================
@Composable
fun SummaryScreen(viewModel: MainViewModel, lang: Language) {
    val selectedFlight by viewModel.selectedFlight.collectAsState()
    val searchTo by viewModel.searchTo.collectAsState()
    val selectedFareType by viewModel.selectedFareType.collectAsState()
    val selectedSeat by viewModel.selectedSeat.collectAsState()
    val passengerCount by viewModel.passengerCount.collectAsState()
    val pFirst by viewModel.firstName.collectAsState()
    val pLast by viewModel.lastName.collectAsState()

    // Simulated Checkout card fields
    var cardNumber by remember { mutableStateOf("") }
    var cardName by remember { mutableStateOf("") }
    var expiry by remember { mutableStateOf("") }
    var cvv by remember { mutableStateOf("") }

    if (selectedFlight == null || searchTo == null) return

    val baseFare = selectedFlight!!.basePriceEuro
    val fareAddon = when (selectedFareType) {
        "Standard" -> 50
        "Premium" -> 110
        else -> 0
    }
    val seatAddon = if (viewModel.premiumSeats.contains(selectedSeat)) 25 else 12
    val taxes = 32
    val totalAmount = (baseFare + fareAddon) * passengerCount + seatAddon + taxes

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateBack() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = Translations.get("booking_summary", lang),
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Details Ticket Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                "Yerevan (EVN) ➔ ${searchTo!!.city} (${searchTo!!.code})",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 15.sp
                            )
                            Text(
                                text = selectedFlight!!.number,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("Departure", fontSize = 11.sp, color = Color.Gray)
                                Text(selectedFlight!!.departureTime, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Arrival", fontSize = 11.sp, color = Color.Gray)
                                Text(selectedFlight!!.arrivalTime, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            }
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = Color.LightGray)

                        // Passenger names & seat
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("Passenger", fontSize = 11.sp, color = Color.Gray)
                                Text("$pFirst $pLast", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Seat", fontSize = 11.sp, color = Color.Gray)
                                Text(selectedSeat, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }

            // Fare breakdown card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Fare Breakdown", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Base Fare ($selectedFareType) x $passengerCount", fontSize = 13.sp)
                            Text("€${(baseFare + fareAddon) * passengerCount}", fontSize = 13.sp)
                        }
                        Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Seat Selection Fee ($selectedSeat)", fontSize = 13.sp)
                            Text("€$seatAddon", fontSize = 13.sp)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(Translations.get("taxes", lang), fontSize = 13.sp)
                            Text("€$taxes", fontSize = 13.sp)
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(Translations.get("total", lang), fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                            Text("€$totalAmount", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = MaterialTheme.colorScheme.tertiary)
                        }
                    }
                }
            }

            // Payment Input form
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Simulated Secure Checkout", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = cardNumber,
                            onValueChange = { if (it.length <= 16) cardNumber = it },
                            label = { Text("Card Number") },
                            modifier = Modifier.fillMaxWidth().testTag("card_number_input"),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = cardName,
                            onValueChange = { cardName = it },
                            label = { Text("Cardholder Name") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(modifier = Modifier.fillMaxWidth()) {
                            OutlinedTextField(
                                value = expiry,
                                onValueChange = { if (it.length <= 5) expiry = it },
                                label = { Text("Expiry (MM/YY)") },
                                modifier = Modifier.weight(1f),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            OutlinedTextField(
                                value = cvv,
                                onValueChange = { if (it.length <= 3) cvv = it },
                                label = { Text("CVV") },
                                modifier = Modifier.weight(1f),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                            )
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = {
                        viewModel.startPayment()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("pay_checkout_btn"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary)
                ) {
                    Text("${Translations.get("pay_now", lang)} €$totalAmount", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = Color.White)
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

// ==================== PROCESSING PAYMENT SCREEN (LOADING ANIMATION) ====================
@Composable
fun ProcessingPaymentScreen(viewModel: MainViewModel, lang: Language) {
    // We launch a delay then advance to confirmation
    LaunchedEffect(Unit) {
        delay(2500)
        viewModel.completeBooking()
    }

    val infiniteTransition = rememberInfiniteTransition(label = "airplane_loop")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(80.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Default.Autorenew,
                contentDescription = null,
                modifier = Modifier
                    .size(44.dp)
                    .rotate(rotation),
                tint = MaterialTheme.colorScheme.primary
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = Translations.get("processing_payment", lang),
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp,
            color = MaterialTheme.colorScheme.primary
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = Translations.get("payment_secure", lang),
            fontSize = 13.sp,
            color = Color.Gray,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 40.dp)
        )
    }
}

// ==================== BOOKING CONFIRMATION SCREEN ====================
@Composable
fun ConfirmationScreen(reference: String, viewModel: MainViewModel, lang: Language) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // High-polish Success Symbol
        Box(
            modifier = Modifier
                .size(100.dp)
                .clip(CircleShape)
                .background(Color(0xFFE8F5E9)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Default.CheckCircle,
                contentDescription = "Success",
                tint = Color(0xFF2E7D32),
                modifier = Modifier.size(64.dp)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = Translations.get("booking_confirmed", lang),
            fontWeight = FontWeight.ExtraBold,
            fontSize = 24.sp,
            color = MaterialTheme.colorScheme.primary
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = Translations.get("congrats", lang),
            fontSize = 14.sp,
            color = Color.Gray,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(32.dp))

        // Booking ticket detail style
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = Translations.get("booking_ref", lang).uppercase(),
                    fontSize = 11.sp,
                    color = Color.Gray,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = reference,
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.tertiary,
                    letterSpacing = 2.sp
                )

                HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("ROUTE", fontSize = 10.sp, color = Color.Gray)
                        Text("EVN ➔ CDG", fontWeight = FontWeight.Bold)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("DATE", fontSize = 10.sp, color = Color.Gray)
                        Text("14 Oct 2026", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(40.dp))

        Button(
            onClick = {
                viewModel.selectTab(NavigationTab.TRIPS)
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("view_trips_btn"),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text(Translations.get("view_trip", lang), fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedButton(
            onClick = { },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(Translations.get("add_wallet", lang), fontWeight = FontWeight.Bold)
        }
    }
}

// ==================== TRIPS TAB: TRIPS LIST ====================
@Composable
fun TripsListScreen(viewModel: MainViewModel, lang: Language) {
    val bookings by viewModel.bookings.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        Text(
            text = Translations.get("trips", lang),
            fontWeight = FontWeight.Bold,
            fontSize = 22.sp,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp)
        )

        if (bookings.isEmpty()) {
            Box(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Text(Translations.get("no_trips", lang), color = Color.Gray)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                items(bookings) { booking ->
                    TripCardItem(booking, lang) {
                        viewModel.navigateToScreen(AppScreen.TripDetails(booking.reference))
                    }
                }
            }
        }
    }
}

@Composable
fun TripCardItem(booking: Booking, lang: Language, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = booking.toCity,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = booking.date,
                        fontSize = 13.sp,
                        color = Color.Gray
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (booking.isCheckedIn) Color(0xFFE8F5E9) else Color(0xFFFFF3E0))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (booking.isCheckedIn) "Checked In" else "Confirmed",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = if (booking.isCheckedIn) Color(0xFF2E7D32) else Color(0xFFEF6C00)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(booking.fromCode, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(Icons.Default.FlightTakeoff, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(booking.toCode, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }

                Text(
                    text = "Ref: ${booking.reference}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Gray
                )
            }
        }
    }
}

// ==================== TRIP DETAILS SCREEN ====================
@Composable
fun TripDetailsScreen(bookingRef: String, viewModel: MainViewModel, lang: Language) {
    val bookings by viewModel.bookings.collectAsState()
    val booking = bookings.find { it.reference == bookingRef } ?: return

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateBack() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Trip details",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Main Ticket Detail Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text(booking.fromCity, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Text(booking.fromCode, fontSize = 24.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                                Text(booking.departureTime, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.align(Alignment.CenterVertically)) {
                                Icon(Icons.Default.Flight, contentDescription = null, modifier = Modifier.size(24.dp), tint = MaterialTheme.colorScheme.primary)
                                Text("DIRECT", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(booking.toCity, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Text(booking.toCode, fontSize = 24.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                                Text(booking.arrivalTime, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("FLIGHT", fontSize = 11.sp, color = Color.Gray)
                                Text(booking.flightNumber, fontWeight = FontWeight.Bold)
                            }
                            Column {
                                Text("DATE", fontSize = 11.sp, color = Color.Gray)
                                Text(booking.date, fontWeight = FontWeight.Bold)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("REF CODE", fontSize = 11.sp, color = Color.Gray)
                                Text(booking.reference, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.tertiary)
                            }
                        }
                    }
                }
            }

            // Passenger, Seat, Baggage details
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("PASSENGER", fontSize = 11.sp, color = Color.Gray)
                                Text("${booking.passengerFirstName} ${booking.passengerLastName}", fontWeight = FontWeight.Bold)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("SEAT", fontSize = 11.sp, color = Color.Gray)
                                Text(booking.seat, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            }
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                        Column {
                            Text("BAGGAGE ALLOWANCE", fontSize = 11.sp, color = Color.Gray)
                            Text(booking.baggage, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Check-in and Boarding Pass Action Block
            item {
                Spacer(modifier = Modifier.height(12.dp))
                if (!booking.isCheckedIn) {
                    Button(
                        onClick = { viewModel.navigateToScreen(AppScreen.CheckInScreen(booking.reference)) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("check_in_trip_btn"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(Translations.get("check_in", lang), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                } else {
                    Button(
                        onClick = { viewModel.navigateToScreen(AppScreen.BoardingPassScreen(booking.reference)) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("view_boarding_pass_btn"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
                    ) {
                        Icon(Icons.Default.QrCode, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(Translations.get("view_boarding_pass", lang), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                }
            }
        }
    }
}

// ==================== CHECK-IN SCREEN ====================
@Composable
fun CheckInScreen(bookingRef: String, viewModel: MainViewModel, lang: Language) {
    val bookings by viewModel.bookings.collectAsState()
    val booking = bookings.find { it.reference == bookingRef } ?: return

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateBack() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = Translations.get("check_in", lang),
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.VerifiedUser,
                        contentDescription = null,
                        modifier = Modifier.size(44.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                Text(
                    text = "Confirm Passenger Information",
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = MaterialTheme.colorScheme.primary
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "You are checking in for flight ${booking.flightNumber} to ${booking.toCity}.",
                    textAlign = TextAlign.Center,
                    color = Color.Gray,
                    fontSize = 14.sp
                )

                Spacer(modifier = Modifier.height(32.dp))

                // Passenger verification summary
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Passenger:", color = Color.Gray)
                            Text("${booking.passengerFirstName} ${booking.passengerLastName}", fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Seat:", color = Color.Gray)
                            Text(booking.seat, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Flight Date:", color = Color.Gray)
                            Text(booking.date, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Button(
                onClick = { viewModel.checkInBooking(booking.reference) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("confirm_check_in_btn"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Confirm & Check-In", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }
    }
}

// ==================== BOARDING PASS SCREEN ====================
@Composable
fun BoardingPassScreen(bookingRef: String, viewModel: MainViewModel, lang: Language) {
    val bookings by viewModel.bookings.collectAsState()
    val booking = bookings.find { it.reference == bookingRef } ?: return

    val infiniteTransition = rememberInfiniteTransition(label = "scanning_line")
    val lineOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 180f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "lineOffset"
    )

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateBack() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = Translations.get("boarding_pass", lang),
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            // Elegant Ticket Composition
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        // Header
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("FLYONE ARMENIA", color = Color.White, fontWeight = FontWeight.Black, fontSize = 15.sp, letterSpacing = 1.sp)
                            Icon(Icons.Default.FlightTakeoff, contentDescription = null, tint = Color.White)
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        // Destination Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(booking.fromCode, fontSize = 36.sp, fontWeight = FontWeight.Black, color = Color.White)
                                Text("Yerevan", fontSize = 13.sp, color = Color.LightGray)
                            }

                            Icon(
                                Icons.Default.Flight,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(32.dp).rotate(90f)
                            )

                            Column(horizontalAlignment = Alignment.End) {
                                Text(booking.toCode, fontSize = 36.sp, fontWeight = FontWeight.Black, color = Color.White)
                                Text(booking.toCity, fontSize = 13.sp, color = Color.LightGray)
                            }
                        }

                        HorizontalDivider(
                            modifier = Modifier.padding(vertical = 16.dp),
                            color = Color.White.copy(alpha = 0.3f)
                        )

                        // Info row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("PASSENGER", fontSize = 10.sp, color = Color.LightGray)
                                Text("${booking.passengerFirstName} ${booking.passengerLastName}", fontWeight = FontWeight.Bold, color = Color.White)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("SEAT", fontSize = 10.sp, color = Color.LightGray)
                                Text(booking.seat, fontWeight = FontWeight.ExtraBold, color = Color.White, fontSize = 16.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("FLIGHT", fontSize = 10.sp, color = Color.LightGray)
                                Text(booking.flightNumber, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                            Column {
                                Text("DATE", fontSize = 10.sp, color = Color.LightGray)
                                Text(booking.date, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("GATE", fontSize = 10.sp, color = Color.LightGray)
                                Text("12", fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("BOARDING", fontSize = 10.sp, color = Color.LightGray)
                                Text("08:35", fontWeight = FontWeight.Bold, color = Color.White)
                            }
                            Column {
                                Text("DEPARTURE", fontSize = 10.sp, color = Color.LightGray)
                                Text(booking.departureTime, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("CLASS", fontSize = 10.sp, color = Color.LightGray)
                                Text("Economy", fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }
                }
            }

            // Beautiful QR Code drawing
            item {
                Card(
                    modifier = Modifier.width(260.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(180.dp)
                                .clip(RoundedCornerShape(8.dp))
                        ) {
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                // Background
                                drawRect(Color.White)

                                // Let's draw some high-fidelity QR Code blocks
                                val sizePx = size.width
                                val blockSize = sizePx / 15f

                                // Draw big locator squares (Top Left, Top Right, Bottom Left)
                                fun drawLocator(offsetX: Float, offsetY: Float) {
                                    drawRect(
                                        color = Color.Black,
                                        topLeft = Offset(offsetX, offsetY),
                                        size = Size(blockSize * 4, blockSize * 4)
                                    )
                                    drawRect(
                                        color = Color.White,
                                        topLeft = Offset(offsetX + blockSize, offsetY + blockSize),
                                        size = Size(blockSize * 2, blockSize * 2)
                                    )
                                }

                                drawLocator(0f, 0f)
                                drawLocator(sizePx - blockSize * 4, 0f)
                                drawLocator(0f, sizePx - blockSize * 4)

                                // Dynamic pseudorandom QR pixels drawing based on booking reference hash
                                val refHash = booking.reference.hashCode()
                                for (col in 0 until 15) {
                                    for (row in 0 until 15) {
                                        // Skip locator zones
                                        if (col < 4 && row < 4) continue
                                        if (col > 10 && row < 4) continue
                                        if (col < 4 && row > 10) continue

                                        // Pseudorandom noise
                                        val pixelHash = (col * 31 + row * 17 + refHash) % 7
                                        if (pixelHash == 0 || pixelHash == 2 || pixelHash == 5) {
                                            drawRect(
                                                color = Color.Black,
                                                topLeft = Offset(col * blockSize, row * blockSize),
                                                size = Size(blockSize, blockSize)
                                            )
                                        }
                                    }
                                }
                            }

                            // Glowing scan line
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                val lineY = lineOffset * (size.height / 180f)
                                drawLine(
                                    color = Color(0xFFD0312D), // Crimson red
                                    start = Offset(0f, lineY),
                                    end = Offset(size.width, lineY),
                                    strokeWidth = 3f,
                                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = booking.reference,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 18.sp,
                            letterSpacing = 2.sp
                        )

                        Text(
                            text = Translations.get("not_valid_disclaimer", lang),
                            fontSize = 10.sp,
                            color = Color.Gray,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                }
            }

            // Wallet buttons
            item {
                Button(
                    onClick = { },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(Translations.get("add_wallet", lang), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ==================== FLIGHT STATUS SCREEN ====================
@Composable
fun FlightStatusScreen(viewModel: MainViewModel, lang: Language) {
    val statusQuery by viewModel.statusQuery.collectAsState()
    val searchedFlight by viewModel.searchedFlightStatus.collectAsState()
    val timelineStage by viewModel.timelineStage.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = Translations.get("flight_status", lang),
            fontWeight = FontWeight.Bold,
            fontSize = 22.sp,
            color = MaterialTheme.colorScheme.primary
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Search Block
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = statusQuery,
                onValueChange = { viewModel.statusQuery.value = it },
                label = { Text(Translations.get("enter_flight", lang)) },
                modifier = Modifier.weight(1f).testTag("flight_status_search_input")
            )
            Spacer(modifier = Modifier.width(12.dp))
            Button(
                onClick = { viewModel.searchFlightStatus() },
                modifier = Modifier.height(56.dp).testTag("flight_status_search_btn")
            ) {
                Icon(Icons.Default.Search, contentDescription = "Search")
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        if (searchedFlight != null) {
            val flight = searchedFlight!!
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(flight.number, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.primary)
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(0xFFE8F5E9))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                Translations.get("on_time", lang),
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF2E7D32),
                                fontSize = 11.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("EVN", fontSize = 24.sp, fontWeight = FontWeight.Black)
                            Text("Yerevan", fontSize = 13.sp, color = Color.Gray)
                            Text(flight.departureTime, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(flight.toCode, fontSize = 24.sp, fontWeight = FontWeight.Black)
                            Text(flight.toCode, fontSize = 13.sp, color = Color.Gray) // fallback to code for city
                            Text(flight.arrivalTime, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp))

                    // Horizontal Progress Timeline Stage Tracking
                    Text(
                        text = "LIVE TRACKING STAGE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val stages = listOf(
                            Translations.get("check_in", lang),
                            Translations.get("boarding", lang),
                            Translations.get("departed", lang),
                            Translations.get("airborne", lang),
                            Translations.get("landed", lang)
                        )

                        stages.forEachIndexed { index, name ->
                            val isReached = index <= timelineStage
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(
                                    modifier = Modifier
                                        .size(16.dp)
                                        .clip(CircleShape)
                                        .background(if (isReached) MaterialTheme.colorScheme.primary else Color.LightGray)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = name,
                                    fontSize = 9.sp,
                                    fontWeight = if (isReached) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isReached) MaterialTheme.colorScheme.primary else Color.Gray
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { viewModel.advanceTimelineStage() },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                    ) {
                        Text("Advance Timeline Stage (Demo)", fontWeight = FontWeight.Bold)
                    }

                    Text(
                        text = Translations.get("synthetic_disclaimer", lang),
                        fontSize = 10.sp,
                        color = Color.Gray,
                        modifier = Modifier.padding(top = 12.dp)
                    )
                }
            }
        }
    }
}

// ==================== ACCOUNT & SETTINGS SCREEN ====================
@Composable
fun AccountScreen(viewModel: MainViewModel, lang: Language) {
    val activeLang by viewModel.language.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = Translations.get("account", lang),
            fontWeight = FontWeight.Bold,
            fontSize = 22.sp,
            color = MaterialTheme.colorScheme.primary
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Profile details
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Person, contentDescription = null, modifier = Modifier.size(32.dp), tint = MaterialTheme.colorScheme.primary)
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(
                        text = "${viewModel.firstName.value.ifBlank { "Tom" }} ${viewModel.lastName.value.ifBlank { "Example" }}",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 18.sp
                    )
                    Text(text = viewModel.email.value.ifBlank { "tom@example.com" }, fontSize = 13.sp, color = Color.Gray)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Dynamic Language Selector Section
        Text(
            text = Translations.get("language", lang),
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.padding(8.dp)) {
                listOf(
                    Language.EN to "English (UK)",
                    Language.AM to "Հայերեն (AM)",
                    Language.RU to "Русский (RU)"
                ).forEach { (l, label) ->
                    val isSelected = activeLang == l
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.setLanguage(l) }
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(label, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal)
                        RadioButton(selected = isSelected, onClick = { viewModel.setLanguage(l) })
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Expandable baggage rules info action
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { viewModel.navigateToScreen(AppScreen.BaggageInfo) },
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(Translations.get("baggage_info", lang), fontWeight = FontWeight.Bold)
                Icon(Icons.Default.ArrowForwardIos, contentDescription = null, modifier = Modifier.size(16.dp))
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { viewModel.navigateToScreen(AppScreen.DestinationsInfo) },
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(Translations.get("destinations", lang), fontWeight = FontWeight.Bold)
                Icon(Icons.Default.ArrowForwardIos, contentDescription = null, modifier = Modifier.size(16.dp))
            }
        }
    }
}

// ==================== ADDITIONAL BAGGAGE INFO SHEET ====================
@Composable
fun BaggageInfoScreen(viewModel: MainViewModel, lang: Language) {
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateBack() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = Translations.get("baggage_info", lang),
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text("Cabin Baggage Limits", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(
                    "Each passenger is allowed 1 carry-on bag with dimensions up to 43 x 34 x 20 cm and maximum weight of 8kg. Must fit under the seat in front.",
                    fontSize = 13.sp, color = Color.Gray, modifier = Modifier.padding(top = 4.dp)
                )
            }
            item {
                Text("Checked Baggage Allowance", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(
                    "Standard checked baggage must not exceed 23kg and a maximum linear dimension of 158 cm (height + width + depth). Multi-bag options can be booked in advance.",
                    fontSize = 13.sp, color = Color.Gray, modifier = Modifier.padding(top = 4.dp)
                )
            }
            item {
                Text("Prohibited Items", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(
                    "Explosives, flammable liquids, toxic substances, and items containing lithium metal batteries are strictly prohibited on board standard passenger cabins.",
                    fontSize = 13.sp, color = Color.Gray, modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }
}

// ==================== ADDITIONAL DESTINATIONS DETAIL SCREEN ====================
@Composable
fun DestinationsScreen(viewModel: MainViewModel, lang: Language) {
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateBack() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = Translations.get("destinations", lang),
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            items(MockData.destinations) { dest ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(dest.city, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.primary)
                            Text("From €${dest.minPriceEuro}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.tertiary)
                        }
                        Text(
                            text = "Airport Code: ${dest.code} • Country: ${dest.country}",
                            fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(top = 2.dp)
                        )
                        Text(
                            text = dest.getDescription(lang),
                            fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                }
            }
        }
    }
}
