package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val AviationBlue = Color(0xFF0C1E36)
val AviationDark = Color(0xFF0A1424)
val ArmenianRed = Color(0xFFD0312D)
val AviationWarmOffWhite = Color(0xFFFAF9F6)
val AviationSoftGrey = Color(0xFFEBE8E2)
val GoldAccent = Color(0xFFD4AF37)

val BlueDark = Color(0xFF071221)
val BlueLight = Color(0xFF1E3A5F)
val GreyLight = Color(0xFFF3F1ED)
