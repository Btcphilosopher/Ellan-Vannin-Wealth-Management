package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = Color.White,
    onPrimary = AviationDark,
    primaryContainer = AviationBlue,
    secondary = AviationSoftGrey,
    onSecondary = Color.White,
    tertiary = ArmenianRed,
    background = AviationDark,
    onBackground = Color.White,
    surface = AviationBlue,
    onSurface = Color.White,
    surfaceVariant = BlueDark,
    onSurfaceVariant = AviationSoftGrey
)

private val LightColorScheme = lightColorScheme(
    primary = AviationBlue,
    onPrimary = Color.White,
    primaryContainer = GreyLight,
    secondary = BlueLight,
    onSecondary = Color.White,
    tertiary = ArmenianRed,
    background = AviationWarmOffWhite,
    onBackground = AviationDark,
    surface = Color.White,
    onSurface = AviationDark,
    surfaceVariant = AviationSoftGrey,
    onSurfaceVariant = AviationDark
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
