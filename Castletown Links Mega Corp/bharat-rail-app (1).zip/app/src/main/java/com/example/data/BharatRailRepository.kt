package com.example.data

import android.content.Context
import com.example.data.local.*
import com.example.domain.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.*

class BharatRailRepository(context: Context) {

    private val db = BharatRailDatabase.getDatabase(context)
    private val stationDao = db.stationDao()
    private val ticketDao = db.ticketDao()
    private val incidentDao = db.incidentDao()
    private val auditDao = db.auditDao()

    // State Flows
    private val _currentPersona = MutableStateFlow(SyntheticRailwayData.DEMO_PERSONAS[0]) // Asha Sharma (Passenger)
    val currentPersona: StateFlow<DemoPersona> = _currentPersona.asStateFlow()

    private val _currentLanguage = MutableStateFlow(SupportedLanguage.EN)
    val currentLanguage: StateFlow<SupportedLanguage> = _currentLanguage.asStateFlow()

    private val _isOfflineMode = MutableStateFlow(false)
    val isOfflineMode: StateFlow<Boolean> = _isOfflineMode.asStateFlow()

    private val _incidents = MutableStateFlow(SyntheticRailwayData.SAMPLE_INCIDENTS)
    val incidents: StateFlow<List<IncidentReport>> = _incidents.asStateFlow()

    private val _passengers12951 = MutableStateFlow(SyntheticRailwayData.SAMPLE_PASSENGERS_12951)
    val passengers12951: StateFlow<List<PassengerManifestItem>> = _passengers12951.asStateFlow()

    private val _auditLogs = MutableStateFlow(SyntheticRailwayData.SAMPLE_AUDIT_LOGS)
    val auditLogs: StateFlow<List<AuditEvent>> = _auditLogs.asStateFlow()

    private val _activeTickets = MutableStateFlow(listOf(SyntheticRailwayData.SAMPLE_TICKET))
    val activeTickets: StateFlow<List<Ticket>> = _activeTickets.asStateFlow()

    fun setPersona(persona: DemoPersona) {
        _currentPersona.value = persona
        logAudit("SWITCH_PERSONA", "UserRole", persona.role.name, "Switched role to ${persona.name} (${persona.role.displayName})")
    }

    fun setLanguage(language: SupportedLanguage) {
        _currentLanguage.value = language
    }

    fun toggleOfflineMode() {
        _isOfflineMode.value = !_isOfflineMode.value
    }

    fun verifyPassenger(pnr: String, seatNumber: Int) {
        val updated = _passengers12951.value.map { p ->
            if (p.pnr == pnr && p.seatNumber == seatNumber) {
                p.copy(isVerified = true)
            } else p
        }
        _passengers12951.value = updated
        logAudit("VERIFY_TICKET", "PassengerManifest", "$pnr-$seatNumber", "Passenger verified on coach B1 seat $seatNumber")
    }

    fun addIncident(title: String, category: String, severity: IncidentSeverity, location: String, description: String) {
        val sdf = SimpleDateFormat("dd-MMM-yyyy hh:mm a", Locale.ENGLISH)
        val newIncident = IncidentReport(
            id = "INC-2026-${(1000..9999).random()}",
            title = title,
            category = category,
            severity = severity,
            location = location,
            reportedBy = _currentPersona.value.name,
            reporterRole = _currentPersona.value.role.displayName,
            timestamp = sdf.format(Date()),
            description = description,
            status = IncidentStatus.OPEN,
            assignedTo = "Pending Assignment",
            auditHistory = listOf("Logged by ${_currentPersona.value.name}")
        )
        _incidents.value = listOf(newIncident) + _incidents.value
        logAudit("CREATE_INCIDENT", "Incident", newIncident.id, "Logged incident: $title")
    }

    fun updateIncidentStatus(id: String, newStatus: IncidentStatus) {
        val updated = _incidents.value.map { inc ->
            if (inc.id == id) {
                inc.copy(
                    status = newStatus,
                    auditHistory = inc.auditHistory + "Status changed to ${newStatus.label} by ${_currentPersona.value.name}"
                )
            } else inc
        }
        _incidents.value = updated
        logAudit("UPDATE_INCIDENT", "Incident", id, "Status updated to ${newStatus.label}")
    }

    fun bookSyntheticTicket(
        train: Train,
        journeyDate: String,
        travelClass: String,
        quota: String,
        passengersList: List<Pair<String, Int>> // Name, Age
    ): Ticket {
        val pnr = "${(1000000000..9999999999L).random()}"
        val bookingId = "BKG-2026-${(100000..999999).random()}"
        val baseFare = when (travelClass) {
            "1A" -> 3200L
            "2A" -> 2100L
            "3A" -> 1450L
            "SL" -> 580L
            else -> 1800L
        } * passengersList.size
        val totalPaisa = (baseFare + 180L) * 100L // Rs + taxes in paisa

        val manifestItems = passengersList.mapIndexed { idx, pair ->
            PassengerManifestItem(
                pnr = pnr,
                ticketId = "TKT-${(1000000..9999999).random()}",
                passengerName = pair.first,
                age = pair.second,
                gender = if (idx % 2 == 0) "Female" else "Male",
                coach = if (travelClass.contains("3A")) "B1" else "A1",
                seatNumber = 12 + idx,
                berthType = if (idx % 2 == 0) "LB (Lower Berth)" else "UB (Upper Berth)",
                bookingStatus = BookingStatus.CONFIRMED,
                isVerified = false,
                boardingStation = train.originCode,
                destinationStation = train.destCode
            )
        }

        val newTicket = Ticket(
            pnr = pnr,
            bookingId = bookingId,
            trainNumber = train.number,
            trainName = train.name,
            originCode = train.originCode,
            originName = train.originName,
            destCode = train.destCode,
            destName = train.destName,
            journeyDate = journeyDate,
            depTime = train.depTime,
            arrTime = train.arrTime,
            travelClass = travelClass,
            quota = quota,
            passengers = manifestItems,
            totalFarePaisa = totalPaisa,
            paymentTxnId = "TXN-UPI-${(10000000..99999999).random()}",
            bookingTimestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'IST'", Locale.ENGLISH).format(Date()),
            qrCodePayload = "BHARATRAIL:PNR:$pnr:BKG:$bookingId:VERIFIED",
            isDemo = true
        )

        _activeTickets.value = listOf(newTicket) + _activeTickets.value
        logAudit("BOOK_TICKET", "PNR", pnr, "Booked ticket for train ${train.number} (${passengersList.size} pax)")
        return newTicket
    }

    fun lookupPnr(pnr: String): Ticket? {
        return _activeTickets.value.firstOrNull { it.pnr.trim() == pnr.trim() }
            ?: if (pnr.trim() == "2849102948") SyntheticRailwayData.SAMPLE_TICKET else null
    }

    private fun logAudit(action: String, resource: String, resourceId: String, details: String) {
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH)
        val event = AuditEvent(
            eventId = "AUD-${(1000..9999).random()}",
            timestamp = sdf.format(Date()),
            actor = "${_currentPersona.value.name} (${_currentPersona.value.badgeNumber})",
            role = _currentPersona.value.role.name,
            action = action,
            resource = resource,
            resourceId = resourceId,
            status = "SUCCESS",
            dataClassification = if (_currentPersona.value.role == UserRole.ADMIN) DataClassification.RESTRICTED else DataClassification.INTERNAL
        )
        _auditLogs.value = listOf(event) + _auditLogs.value
    }
}
