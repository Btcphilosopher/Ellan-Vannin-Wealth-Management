package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SyntheticRailwayData
import com.example.domain.model.DemoPersona
import com.example.domain.model.IncidentReport

@Composable
fun StationOpsScreen(
    persona: DemoPersona,
    incidents: List<IncidentReport>,
    onBroadcastAnnouncement: (String) -> Unit
) {
    var announcementText by remember { mutableStateOf("") }
    val station = SyntheticRailwayData.STATIONS[0] // New Delhi (NDLS)

    val trainsBoard = listOf(
        Triple("12951", "Mumbai Rajdhani", "PF 1 • ARR: 08:32 • STATUS: ON TIME"),
        Triple("22436", "Vande Bharat Express", "PF 3 • DEP: 06:00 • STATUS: BOARDING"),
        Triple("12002", "Bhopal Shatabdi", "PF 2 • DEP: 06:00 • STATUS: DELAYED 12M"),
        Triple("12301", "Howrah Rajdhani", "PF 16 • ARR: 10:05 • STATUS: ON TIME")
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .padding(24.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // Station Command Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "STATION SUPERINTENDENT WORKSPACE — ${station.code}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF059669),
                    letterSpacing = 1.sp
                )
                Text(
                    text = "${station.nameEn} (${station.nameHi})",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "Zone: ${station.zone} • Division: ${station.division} • Platforms: ${station.platformsCount}",
                    fontSize = 13.sp,
                    color = Color(0xFF94A3B8)
                )
            }

            Surface(color = Color(0xFF065F46), shape = RoundedCornerShape(12.dp)) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Sensors, contentDescription = null, tint = Color(0xFF34D399))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("STATION OPS ACTIVE", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Station Announcement Tool Box
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.VolumeUp, contentDescription = null, tint = Color(0xFFFFB800))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("PUBLIC ANNOUNCEMENT BROADCASTER (PAS)", fontWeight = FontWeight.Bold, color = Color.White)
                }
                Spacer(modifier = Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = announcementText,
                        onValueChange = { announcementText = it },
                        placeholder = { Text("Enter announcement in English / Hindi...", color = Color(0xFF64748B)) },
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("station_announcement_input")
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Button(
                        onClick = {
                            if (announcementText.isNotBlank()) {
                                onBroadcastAnnouncement(announcementText)
                                announcementText = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFB800), contentColor = Color(0xFF0F172A)),
                        modifier = Modifier.testTag("broadcast_announcement_button")
                    ) {
                        Icon(Icons.Default.Campaign, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("BROADCAST")
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Platform & Train Board Split View
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Live Train Board Card
            Card(
                modifier = Modifier
                    .weight(1f)
                    .height(320.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("LIVE PLATFORM ARRIVALS / DEPARTURES", fontWeight = FontWeight.Bold, color = Color(0xFFFFB800), fontSize = 13.sp)
                    HorizontalDivider(color = Color(0xFF334155), modifier = Modifier.padding(vertical = 10.dp))

                    trainsBoard.forEach { item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("${item.first} - ${item.second}", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                                Text(item.third, color = Color(0xFF94A3B8), fontSize = 11.sp)
                            }
                            Icon(Icons.Default.DirectionsRailway, contentDescription = null, tint = Color(0xFF60A5FA))
                        }
                    }
                }
            }

            // Station Facilities Telemetry Card
            Card(
                modifier = Modifier
                    .weight(1f)
                    .height(320.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("STATION FACILITIES TELEMETRY", fontWeight = FontWeight.Bold, color = Color(0xFF34D399), fontSize = 13.sp)
                    HorizontalDivider(color = Color(0xFF334155), modifier = Modifier.padding(vertical = 10.dp))

                    station.facilities.forEach { fac ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(fac, color = Color.White, fontSize = 13.sp)
                            }
                            Text("OPERATIONAL", fontSize = 10.sp, color = Color(0xFF34D399), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
