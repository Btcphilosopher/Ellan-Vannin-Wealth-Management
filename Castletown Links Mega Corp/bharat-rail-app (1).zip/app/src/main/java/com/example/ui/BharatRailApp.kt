package com.example.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.domain.model.UserRole
import com.example.ui.components.BharatRailAiSheet
import com.example.ui.components.IPadNavRail
import com.example.ui.components.RoleHeaderBar
import com.example.ui.screens.*

@Composable
fun BharatRailApp(
    viewModel: BharatRailViewModel = viewModel()
) {
    val context = LocalContext.current

    val currentPersona by viewModel.currentPersona.collectAsState()
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isOffline by viewModel.isOfflineMode.collectAsState()
    val currentScreen by viewModel.currentScreen.collectAsState()

    val incidents by viewModel.incidents.collectAsState()
    val passengers12951 by viewModel.passengers12951.collectAsState()
    val auditLogs by viewModel.auditLogs.collectAsState()
    val activeTickets by viewModel.activeTickets.collectAsState()
    val searchedTicket by viewModel.searchedTicket.collectAsState()

    val originQuery by viewModel.originQuery.collectAsState()
    val destQuery by viewModel.destQuery.collectAsState()
    val selectedClass by viewModel.selectedClass.collectAsState()
    val selectedQuota by viewModel.selectedQuota.collectAsState()
    val searchDate by viewModel.searchDate.collectAsState()
    val pnrQuery by viewModel.pnrQuery.collectAsState()
    val manifestSearch by viewModel.manifestSearch.collectAsState()

    val chatMessages by viewModel.chatMessages.collectAsState()
    val isAiLoading by viewModel.isAiLoading.collectAsState()
    var showAiSheet by remember { mutableStateOf(false) }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFF0F172A)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Top Bar with Role & Language Switcher
            RoleHeaderBar(
                currentPersona = currentPersona,
                currentLanguage = currentLanguage,
                isOffline = isOffline,
                onPersonaSelected = { persona ->
                    viewModel.switchPersona(persona)
                    Toast.makeText(context, "Role workspace switched to ${persona.role.displayName}", Toast.LENGTH_SHORT).show()
                },
                onLanguageSelected = { lang ->
                    viewModel.setLanguage(lang)
                },
                onToggleOffline = {
                    viewModel.toggleOffline()
                },
                onOpenAiAssistant = {
                    showAiSheet = true
                }
            )

            // Main Body: iPad Nav Rail on the Left + Active Workspace Screen on the Right
            Row(modifier = Modifier.weight(1f)) {
                IPadNavRail(
                    currentScreen = currentScreen,
                    userRole = currentPersona.role,
                    onNavigate = { screen ->
                        viewModel.navigateTo(screen)
                    }
                )

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .background(Color(0xFF0F172A))
                ) {
                    when (currentScreen) {
                        AppScreen.PASSENGER_HOME -> {
                            PassengerHomeScreen(
                                persona = currentPersona,
                                activeTicket = activeTickets.firstOrNull(),
                                onNavigate = { screen -> viewModel.navigateTo(screen) }
                            )
                        }

                        AppScreen.TRAIN_SEARCH -> {
                            TrainSearchScreen(
                                originQuery = originQuery,
                                destQuery = destQuery,
                                selectedClass = selectedClass,
                                selectedQuota = selectedQuota,
                                searchDate = searchDate,
                                onSearchUpdate = { o, d, c, q, dt ->
                                    viewModel.updateSearchQueries(o, d, c, q, dt)
                                },
                                onBookClick = { train, paxList ->
                                    val newTicket = viewModel.bookTicket(train, paxList)
                                    Toast.makeText(context, "Ticket Booked! PNR: ${newTicket.pnr}", Toast.LENGTH_LONG).show()
                                    viewModel.navigateTo(AppScreen.PNR_STATUS)
                                }
                            )
                        }

                        AppScreen.PNR_STATUS -> {
                            PnrStatusScreen(
                                initialPnr = pnrQuery,
                                searchedTicket = searchedTicket,
                                onSearchPnr = { pnr ->
                                    viewModel.searchPnr(pnr)
                                }
                            )
                        }

                        AppScreen.LIVE_TRACKING -> {
                            ControlRoomScreen(persona = currentPersona)
                        }

                        AppScreen.STATION_INFO -> {
                            StationOpsScreen(
                                persona = currentPersona,
                                incidents = incidents,
                                onBroadcastAnnouncement = { text ->
                                    Toast.makeText(context, "Broadcasting Announcement across Station: $text", Toast.LENGTH_LONG).show()
                                }
                            )
                        }

                        AppScreen.TTE_INSPECTION -> {
                            TteInspectionScreen(
                                persona = currentPersona,
                                manifestItems = passengers12951,
                                searchQuery = manifestSearch,
                                onSearchChange = { q -> viewModel.setManifestSearch(q) },
                                onVerifyPax = { pnr, seat ->
                                    viewModel.verifyPassenger(pnr, seat)
                                    Toast.makeText(context, "Passenger Seat $seat Verified!", Toast.LENGTH_SHORT).show()
                                },
                                onLogIncident = { title, cat, sev, loc, desc ->
                                    viewModel.addIncident(title, cat, sev, loc, desc)
                                    Toast.makeText(context, "Incident Logged!", Toast.LENGTH_SHORT).show()
                                }
                            )
                        }

                        AppScreen.STATION_OPS -> {
                            StationOpsScreen(
                                persona = currentPersona,
                                incidents = incidents,
                                onBroadcastAnnouncement = { text ->
                                    Toast.makeText(context, "Station PA Announcement Broadcasted: $text", Toast.LENGTH_LONG).show()
                                }
                            )
                        }

                        AppScreen.CONTROL_ROOM -> {
                            ControlRoomScreen(persona = currentPersona)
                        }

                        AppScreen.STAFF_DUTY -> {
                            TteInspectionScreen(
                                persona = currentPersona,
                                manifestItems = passengers12951,
                                searchQuery = manifestSearch,
                                onSearchChange = { q -> viewModel.setManifestSearch(q) },
                                onVerifyPax = { pnr, seat -> viewModel.verifyPassenger(pnr, seat) },
                                onLogIncident = { title, cat, sev, loc, desc -> viewModel.addIncident(title, cat, sev, loc, desc) }
                            )
                        }

                        AppScreen.INCIDENT_MGMT -> {
                            StationOpsScreen(
                                persona = currentPersona,
                                incidents = incidents,
                                onBroadcastAnnouncement = { }
                            )
                        }

                        AppScreen.ADMIN_CONSOLE -> {
                            AdminConsoleScreen(
                                persona = currentPersona,
                                auditLogs = auditLogs
                            )
                        }

                        AppScreen.AUDIT_TRAIL -> {
                            AdminConsoleScreen(
                                persona = currentPersona,
                                auditLogs = auditLogs
                            )
                        }
                    }
                }
            }
        }

        // AI Assistant Bottom Sheet
        if (showAiSheet) {
            BharatRailAiSheet(
                messages = chatMessages,
                isLoading = isAiLoading,
                onSendMessage = { prompt ->
                    viewModel.sendAiPrompt(prompt)
                },
                onDismiss = {
                    showAiSheet = false
                }
            )
        }
    }
}
