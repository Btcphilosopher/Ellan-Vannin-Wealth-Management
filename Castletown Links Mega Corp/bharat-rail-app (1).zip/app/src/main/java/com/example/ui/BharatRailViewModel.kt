package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.BharatRailRepository
import com.example.data.LocalizationRepository
import com.example.data.SyntheticRailwayData
import com.example.domain.model.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class AppScreen(val title: String, val passengerAccessible: Boolean, val staffAccessible: Boolean, val adminAccessible: Boolean) {
    PASSENGER_HOME("Home", true, true, true),
    TRAIN_SEARCH("Search & Book", true, true, true),
    PNR_STATUS("PNR & Tickets", true, true, true),
    LIVE_TRACKING("Live Train Status", true, true, true),
    STATION_INFO("Station Facilities", true, true, true),

    // Staff Workspaces
    TTE_INSPECTION("TTE Passenger Verification", false, true, true),
    STATION_OPS("Station Operations Workspace", false, true, true),
    CONTROL_ROOM("Control Room Dashboard", false, true, true),
    STAFF_DUTY("Duty Command & Roster", false, true, true),
    INCIDENT_MGMT("Incident Management", false, true, true),

    // Admin Workspace
    ADMIN_CONSOLE("Governance & Admin Console", false, false, true),
    AUDIT_TRAIL("Audit Log Viewer", false, true, true)
}

data class ChatMessage(
    val id: String,
    val sender: String, // "User" or "Bharat Rail AI"
    val content: String,
    val provenance: String? = null,
    val isUser: Boolean
)

class BharatRailViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = BharatRailRepository(application)

    val currentPersona: StateFlow<DemoPersona> = repository.currentPersona
    val currentLanguage: StateFlow<SupportedLanguage> = repository.currentLanguage
    val isOfflineMode: StateFlow<Boolean> = repository.isOfflineMode
    val incidents: StateFlow<List<IncidentReport>> = repository.incidents
    val passengers12951: StateFlow<List<PassengerManifestItem>> = repository.passengers12951
    val auditLogs: StateFlow<List<AuditEvent>> = repository.auditLogs
    val activeTickets: StateFlow<List<Ticket>> = repository.activeTickets

    // Active UI Screen
    private val _currentScreen = MutableStateFlow(AppScreen.PASSENGER_HOME)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    // Train Search state
    private val _originQuery = MutableStateFlow("MMCT")
    val originQuery: StateFlow<String> = _originQuery.asStateFlow()

    private val _destQuery = MutableStateFlow("NDLS")
    val destQuery: StateFlow<String> = _destQuery.asStateFlow()

    private val _selectedClass = MutableStateFlow("3A")
    val selectedClass: StateFlow<String> = _selectedClass.asStateFlow()

    private val _selectedQuota = MutableStateFlow("GENERAL")
    val selectedQuota: StateFlow<String> = _selectedQuota.asStateFlow()

    private val _searchDate = MutableStateFlow("14-Sep-2026")
    val searchDate: StateFlow<String> = _searchDate.asStateFlow()

    // PNR Lookup Query
    private val _pnrQuery = MutableStateFlow("2849102948")
    val pnrQuery: StateFlow<String> = _pnrQuery.asStateFlow()

    private val _searchedTicket = MutableStateFlow<Ticket?>(SyntheticRailwayData.SAMPLE_TICKET)
    val searchedTicket: StateFlow<Ticket?> = _searchedTicket.asStateFlow()

    // Manifest Filter in TTE mode
    private val _manifestSearch = MutableStateFlow("")
    val manifestSearch: StateFlow<String> = _manifestSearch.asStateFlow()

    // AI Assistant State
    private val _chatMessages = MutableStateFlow(
        listOf(
            ChatMessage(
                id = "1",
                sender = "Bharat Rail AI",
                content = "Namaste! I am the Bharat Rail National Assistant. How may I assist your railway travel or operational duty today?",
                provenance = "Data Source: Authoritative IRCTC & NTES Adapter",
                isUser = false
            )
        )
    )
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _isAiLoading = MutableStateFlow(false)
    val isAiLoading: StateFlow<Boolean> = _isAiLoading.asStateFlow()

    fun navigateTo(screen: AppScreen) {
        _currentScreen.value = screen
    }

    fun switchPersona(persona: DemoPersona) {
        repository.setPersona(persona)
        // Automatically switch active screen according to role
        _currentScreen.value = when (persona.role) {
            UserRole.PASSENGER -> AppScreen.PASSENGER_HOME
            UserRole.TTE -> AppScreen.TTE_INSPECTION
            UserRole.STATION_STAFF -> AppScreen.STATION_OPS
            UserRole.CONTROL_ROOM -> AppScreen.CONTROL_ROOM
            UserRole.ADMIN -> AppScreen.ADMIN_CONSOLE
        }
    }

    fun setLanguage(language: SupportedLanguage) {
        repository.setLanguage(language)
    }

    fun toggleOffline() {
        repository.toggleOfflineMode()
    }

    fun updateSearchQueries(origin: String, dest: String, travelClass: String, quota: String, date: String) {
        _originQuery.value = origin
        _destQuery.value = dest
        _selectedClass.value = travelClass
        _selectedQuota.value = quota
        _searchDate.value = date
    }

    fun searchPnr(pnr: String) {
        _pnrQuery.value = pnr
        _searchedTicket.value = repository.lookupPnr(pnr)
    }

    fun verifyPassenger(pnr: String, seatNumber: Int) {
        repository.verifyPassenger(pnr, seatNumber)
    }

    fun addIncident(title: String, category: String, severity: IncidentSeverity, location: String, desc: String) {
        repository.addIncident(title, category, severity, location, desc)
    }

    fun updateIncidentStatus(id: String, status: IncidentStatus) {
        repository.updateIncidentStatus(id, status)
    }

    fun bookTicket(train: Train, passengers: List<Pair<String, Int>>): Ticket {
        val ticket = repository.bookSyntheticTicket(
            train = train,
            journeyDate = _searchDate.value,
            travelClass = _selectedClass.value,
            quota = _selectedQuota.value,
            passengersList = passengers
        )
        _searchedTicket.value = ticket
        _pnrQuery.value = ticket.pnr
        return ticket
    }

    fun setManifestSearch(query: String) {
        _manifestSearch.value = query
    }

    fun sendAiPrompt(promptText: String) {
        if (promptText.isBlank()) return
        val userMsg = ChatMessage(
            id = System.currentTimeMillis().toString(),
            sender = currentPersona.value.name,
            content = promptText,
            isUser = true
        )
        _chatMessages.value = _chatMessages.value + userMsg
        _isAiLoading.value = true

        viewModelScope.launch {
            // Generate intelligent AI response based on domain context
            val responseText: String
            val provenanceStr: String
            val lower = promptText.lowercase()

            when {
                lower.contains("pnr") || lower.contains("ticket") -> {
                    val ticket = searchedTicket.value ?: SyntheticRailwayData.SAMPLE_TICKET
                    responseText = "PNR ${ticket.pnr} status: Train ${ticket.trainNumber} (${ticket.trainName}) from ${ticket.originCode} to ${ticket.destCode}. Date: ${ticket.journeyDate}. Status: CONFIRMED. Total Passengers: ${ticket.passengers.size}."
                    provenanceStr = "Data Source: IRCTC Passenger Reservation Database Adapter"
                }
                lower.contains("delay") || lower.contains("running") || lower.contains("status") -> {
                    responseText = "Train 12951 (Mumbai Rajdhani) is currently running 4 mins late near Surat Junction (ST). Speed: 128 km/h. Expected Arrival at New Delhi: 08:36 (+1 day)."
                    provenanceStr = "Data Source: National Train Enquiry System (NTES) Telemetry"
                }
                lower.contains("incident") || lower.contains("complaint") -> {
                    val inc = incidents.value.firstOrNull()
                    responseText = "Current Active Incidents count: ${incidents.value.size}. Latest alert: ${inc?.title} at ${inc?.location} (Status: ${inc?.status?.label})."
                    provenanceStr = "Data Source: RailMadad & Control Room Operations Database"
                }
                lower.contains("duty") || lower.contains("shift") -> {
                    val duty = SyntheticRailwayData.SAMPLE_DUTY
                    responseText = "Duty Assignment for ${currentPersona.value.name}: ${duty.shiftName} (${duty.startTime} - ${duty.endTime}). Target: ${duty.assignedTarget}. Supervisor: ${duty.supervisorName}. Verified Pax: 98/142."
                    provenanceStr = "Data Source: Enterprise Duty Roster System"
                }
                else -> {
                    responseText = "As the Bharat Rail National Assistant, I have retrieved context for ${currentPersona.value.role.displayName}. Train 12951 Mumbai Rajdhani is operating normally on Platform 1. Facilities available at NDLS include Executive Lounge, RPF Desk, and Divyangjan Ramps."
                    provenanceStr = "Data Source: Indian Railways Enterprise Knowledge Base"
                }
            }

            _chatMessages.value = _chatMessages.value + ChatMessage(
                id = (System.currentTimeMillis() + 1).toString(),
                sender = "Bharat Rail AI",
                content = responseText,
                provenance = provenanceStr,
                isUser = false
            )
            _isAiLoading.value = false
        }
    }

    fun getString(key: String): String {
        return LocalizationRepository.getString(key, currentLanguage.value)
    }
}
