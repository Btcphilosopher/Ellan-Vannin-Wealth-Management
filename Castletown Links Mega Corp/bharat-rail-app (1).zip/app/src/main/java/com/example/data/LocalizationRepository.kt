package com.example.data

import com.example.domain.model.SupportedLanguage

object LocalizationRepository {

    private val dictionary: Map<SupportedLanguage, Map<String, String>> = mapOf(
        SupportedLanguage.EN to mapOf(
            "app_title" to "BHARAT RAIL",
            "tagline" to "Indian Railways Enterprise Platform",
            "good_morning" to "Good Morning",
            "good_afternoon" to "Good Afternoon",
            "good_evening" to "Good Evening",
            "next_journey" to "NEXT JOURNEY",
            "book_train" to "Book Train",
            "my_journeys" to "My Journeys",
            "pnr_status" to "PNR Status",
            "track_train" to "Track Train",
            "stations" to "Stations",
            "fares" to "Fares & Quotas",
            "refunds" to "Refunds",
            "food" to "E-Catering",
            "hotels" to "Hotels & Stays",
            "retiring_rooms" to "Retiring Rooms",
            "railmadad" to "RailMadad Help",
            "help" to "Support Kiosk",
            "duty_dashboard" to "Duty Command Dashboard",
            "station_ops" to "Station Operations",
            "control_dashboard" to "Network Control Room",
            "admin_console" to "Governance & System Admin",
            "search_trains" to "Search Trains",
            "from_station" to "Origin Station",
            "to_station" to "Destination Station",
            "journey_date" to "Travel Date",
            "class" to "Class",
            "quota" to "Quota",
            "search" to "Search Trains",
            "demo_badge" to "DEMONSTRATION SYSTEM — SYNTHETIC IRCTC ADAPTER",
            "pnr_label" to "PNR NUMBER",
            "coach" to "Coach",
            "berth" to "Seat / Berth",
            "platform" to "Platform",
            "live_status" to "Live Status",
            "verified" to "Verified",
            "pending" to "Pending Verification",
            "incident_reports" to "Incident Management",
            "audit_trail" to "Security & Audit Trail",
            "system_health" to "System Observability"
        ),
        SupportedLanguage.HI to mapOf(
            "app_title" to "भारत रेल",
            "tagline" to "भारतीय रेल एंटरप्राइज प्लेटफॉर्म",
            "good_morning" to "सुप्रभात",
            "good_afternoon" to "नमस्कार",
            "good_evening" to "शुभ संध्या",
            "next_journey" to "अगली यात्रा",
            "book_train" to "ट्रेन टिकट बुक करें",
            "my_journeys" to "मेरी यात्राएं",
            "pnr_status" to "पीएनआर स्थिति",
            "track_train" to "ट्रेन ट्रैक करें",
            "stations" to "स्टेशन सुविधा",
            "fares" to "किराया एवं कोटा",
            "refunds" to "रिफंड इतिहास",
            "food" to "ई-कैटरिंग भोजन",
            "hotels" to "होटल एवं स्टे",
            "retiring_rooms" to "रिटायरिंग रूम",
            "railmadad" to "रेल मदद",
            "help" to "सहायता केंद्र",
            "duty_dashboard" to "ड्यूटी कमांड डैशबोर्ड",
            "station_ops" to "स्टेशन संचालन",
            "control_dashboard" to "नेटवर्क नियंत्रण कक्ष",
            "admin_console" to "प्रशासन एवं प्रणाली",
            "search_trains" to "ट्रेन खोजें",
            "from_station" to "प्रस्थान स्टेशन",
            "to_station" to "गंतव्य स्टेशन",
            "journey_date" to "यात्रा तिथि",
            "class" to "श्रेणी",
            "quota" to "कोटा",
            "search" to "ट्रेन खोजें",
            "demo_badge" to "प्रदर्शन प्रणाली — सिमुलेटेड डेटा",
            "pnr_label" to "पीएनआर संख्या",
            "coach" to "कोच",
            "berth" to "सीट / बर्थ",
            "platform" to "प्लेटफॉर्म",
            "live_status" to "लाइव स्थिति",
            "verified" to "सत्यापित",
            "pending" to "सत्यापन लंबित",
            "incident_reports" to "घटना प्रबंधन",
            "audit_trail" to "सुरक्षा एवं ऑडिट",
            "system_health" to "सिस्टम स्वास्थ्य"
        ),
        SupportedLanguage.BN to mapOf(
            "app_title" to "ভারত রেল",
            "tagline" to "ভারতীয় রেলওয়ে এন্টারপ্রাইজ প্ল্যাটফর্ম",
            "good_morning" to "শুভ সকাল",
            "next_journey" to "পরবর্তী যাত্রা",
            "book_train" to "ট্রেন বুকিং",
            "pnr_status" to "পিএনআর স্ট্যাটাস",
            "track_train" to "লাইভ ট্রেন রানিং",
            "demo_badge" to "ডেমো সিস্টেম — সিমুলেটেড তথ্য"
        ),
        SupportedLanguage.TE to mapOf(
            "app_title" to "భారత్ రైల్",
            "tagline" to "భారతీయ రైల్వే వేదిక",
            "good_morning" to "శుభోదయం",
            "next_journey" to "తరువాతి ప్రయాణం",
            "book_train" to "రైలు బుకింగ్",
            "pnr_status" to "పిఎన్ఆర్ స్టేటస్",
            "track_train" to "రైలు ట్రాకింగ్",
            "demo_badge" to "డెమో సిస్టమ్ — సిమ్యులేటెడ్ సమాచారం"
        ),
        SupportedLanguage.UR to mapOf(
            "app_title" to "بھارت ریل",
            "tagline" to "انڈین ریلویز انٹرپرائز پلیٹ فارم",
            "good_morning" to "صبح بخیر",
            "next_journey" to "اگلا سفر",
            "book_train" to "ٹرین ٹکٹ بک کریں",
            "pnr_status" to "پی این آر کی صورتحال",
            "track_train" to "لائیو ٹرین ٹریکنگ",
            "demo_badge" to "ڈیمو سسٹم — سمیولیٹڈ ڈیٹا"
        )
    )

    fun getString(key: String, lang: SupportedLanguage): String {
        val langMap = dictionary[lang] ?: dictionary[SupportedLanguage.EN]!!
        return langMap[key] ?: dictionary[SupportedLanguage.EN]!![key] ?: key
    }
}
