package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cached_stations")
data class StationEntity(
    @PrimaryKey val code: String,
    val nameEn: String,
    val nameHi: String,
    val city: String,
    val zone: String,
    val division: String,
    val platformsCount: Int
)

@Entity(tableName = "cached_tickets")
data class TicketEntity(
    @PrimaryKey val pnr: String,
    val bookingId: String,
    val trainNumber: String,
    val trainName: String,
    val originCode: String,
    val destCode: String,
    val journeyDate: String,
    val depTime: String,
    val arrTime: String,
    val passengerCount: Int,
    val totalFarePaisa: Long,
    val qrCodePayload: String,
    val cachedTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "incidents")
data class IncidentEntity(
    @PrimaryKey val id: String,
    val title: String,
    val category: String,
    val severity: String,
    val location: String,
    val reportedBy: String,
    val reporterRole: String,
    val timestamp: String,
    val description: String,
    val status: String,
    val assignedTo: String?
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey val eventId: String,
    val timestamp: String,
    val actor: String,
    val role: String,
    val action: String,
    val resource: String,
    val resourceId: String,
    val status: String,
    val dataClassification: String
)
