package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SyntheticRailwayData
import com.example.domain.model.DemoPersona

@Composable
fun ControlRoomScreen(
    persona: DemoPersona
) {
    val telemetryList = SyntheticRailwayData.LIVE_TELEMETRY

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .padding(24.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // Control Room Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "CENTRAL CONTROL ROOM (CCR) — RAIL BHAVAN",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFDC2626),
                    letterSpacing = 1.sp
                )
                Text(
                    text = "National Railway Operational Command",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "Chief Controller: ${persona.name} (${persona.badgeNumber})",
                    fontSize = 13.sp,
                    color = Color(0xFF94A3B8)
                )
            }

            Surface(color = Color(0xFF991B1B), shape = RoundedCornerShape(12.dp)) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Emergency, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("NETWORK MONITORING LIVE", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Status Metrics Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            MetricCard("TOTAL TRAINS RUNNING", "13,420", Color(0xFF2563EB), Modifier.weight(1f))
            MetricCard("ON-TIME PERFORMANCE", "94.2%", Color(0xFF10B981), Modifier.weight(1f))
            MetricCard("ACTIVE DISRUPTIONS", "3 SECTORS", Color(0xFFF59E0B), Modifier.weight(1f))
            MetricCard("EMERGENCY ALERTS", "0 CRITICAL", Color(0xFF7C3AED), Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Network Map Visualization Representation
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(220.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(Icons.Default.Map, contentDescription = null, tint = Color(0xFF60A5FA), modifier = Modifier.size(48.dp))
                Spacer(modifier = Modifier.height(10.dp))
                Text("INDIAN RAILWAYS ZONAL NETWORK TELEMETRY MAP", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 16.sp)
                Text("Northern (NR) • Western (WR) • Eastern (ER) • Southern (SR) • Central (CR) • SWR • SCR", color = Color(0xFF94A3B8), fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Live Telemetry Feed List
        Text("LIVE TRAIN TELEMETRY FEED", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
        Spacer(modifier = Modifier.height(10.dp))

        telemetryList.forEach { telem ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("TRAIN ${telem.trainNumber}", fontWeight = FontWeight.Bold, color = Color(0xFFFFB800), fontSize = 16.sp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Surface(color = Color(telem.status.colorHex), shape = RoundedCornerShape(4.dp)) {
                                Text(telem.status.label, fontSize = 10.sp, color = Color.White, modifier = Modifier.padding(4.dp))
                            }
                        }
                        Text("Current: ${telem.currentStationName} (${telem.currentStationCode}) → Next: ${telem.nextStationName} (${telem.nextStationCode})", fontSize = 12.sp, color = Color.White)
                        Text(telem.lastUpdated, fontSize = 11.sp, color = Color(0xFF94A3B8))
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text("${telem.currentSpeedKmh} KM/H", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF60A5FA))
                        Text(if (telem.delayMinutes > 0) "Delay: +${telem.delayMinutes}m" else "On Time", fontSize = 12.sp, color = if (telem.delayMinutes > 0) Color(0xFFF59E0B) else Color(0xFF10B981))
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricCard(title: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.height(90.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Text(title, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF94A3B8))
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = color)
        }
    }
}
