package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SyntheticRailwayData
import com.example.domain.model.Train

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrainSearchScreen(
    originQuery: String,
    destQuery: String,
    selectedClass: String,
    selectedQuota: String,
    searchDate: String,
    onSearchUpdate: (String, String, String, String, String) -> Unit,
    onBookClick: (Train, List<Pair<String, Int>>) -> Unit
) {
    var origin by remember { mutableStateOf(originQuery) }
    var dest by remember { mutableStateOf(destQuery) }
    var travelClass by remember { mutableStateOf(selectedClass) }
    var quota by remember { mutableStateOf(selectedQuota) }
    var selectedDate by remember { mutableStateOf(searchDate) }

    var selectedTrainForBooking by remember { mutableStateOf<Train?>(null) }
    var showPaymentModal by remember { mutableStateOf(false) }
    var passenger1Name by remember { mutableStateOf("Asha Sharma") }
    var passenger1Age by remember { mutableStateOf("34") }
    var passenger2Name by remember { mutableStateOf("Rohan Sharma") }
    var passenger2Age by remember { mutableStateOf("38") }

    val classes = listOf("3A", "2A", "1A", "SL", "CC", "EC")
    val quotas = listOf("GENERAL", "TATKAL", "SENIOR CITIZEN", "LADIES", "DIVYANGJAN")

    val matchingTrains = SyntheticRailwayData.TRAINS.filter { train ->
        val origMatch = train.originCode.contains(origin, ignoreCase = true) || train.originName.contains(origin, ignoreCase = true)
        val destMatch = train.destCode.contains(dest, ignoreCase = true) || train.destName.contains(dest, ignoreCase = true)
        origMatch || destMatch || origin.isBlank() || dest.isBlank()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .padding(24.dp)
    ) {
        Text(
            text = "TRAIN SEARCH & RESERVATION ENGINE",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFFFFB800),
            letterSpacing = 1.sp
        )
        Text(
            text = "Discover Trains across Indian Railways Network",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Search Form Box
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Origin Input
                    OutlinedTextField(
                        value = origin,
                        onValueChange = {
                            origin = it
                            onSearchUpdate(it, dest, travelClass, quota, selectedDate)
                        },
                        label = { Text("FROM (Station Name / Code)") },
                        leadingIcon = { Icon(Icons.Default.TripOrigin, contentDescription = null, tint = Color(0xFF60A5FA)) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("origin_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFFFFB800),
                            unfocusedBorderColor = Color(0xFF334155)
                        )
                    )

                    // Destination Input
                    OutlinedTextField(
                        value = dest,
                        onValueChange = {
                            dest = it
                            onSearchUpdate(origin, it, travelClass, quota, selectedDate)
                        },
                        label = { Text("TO (Station Name / Code)") },
                        leadingIcon = { Icon(Icons.Default.Place, contentDescription = null, tint = Color(0xFF34D399)) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("dest_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFFFFB800),
                            unfocusedBorderColor = Color(0xFF334155)
                        )
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Class & Quota Selectors
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("CLASS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF94A3B8))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            classes.forEach { c ->
                                FilterChip(
                                    selected = travelClass == c,
                                    onClick = {
                                        travelClass = c
                                        onSearchUpdate(origin, dest, c, quota, selectedDate)
                                    },
                                    label = { Text(c, fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = Color(0xFF2563EB),
                                        selectedLabelColor = Color.White,
                                        containerColor = Color(0xFF0F172A),
                                        labelColor = Color(0xFF94A3B8)
                                    )
                                )
                            }
                        }
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text("QUOTA", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF94A3B8))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            quotas.take(3).forEach { q ->
                                FilterChip(
                                    selected = quota == q,
                                    onClick = {
                                        quota = q
                                        onSearchUpdate(origin, dest, travelClass, q, selectedDate)
                                    },
                                    label = { Text(q, fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = Color(0xFFD97706),
                                        selectedLabelColor = Color.White,
                                        containerColor = Color(0xFF0F172A),
                                        labelColor = Color(0xFF94A3B8)
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Search Results Count
        Text(
            text = "AVAILABLE TRAINS (${matchingTrains.size})",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF94A3B8),
            letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(10.dp))

        // Train List
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(matchingTrains) { train ->
                TrainCardItem(
                    train = train,
                    selectedClass = travelClass,
                    quota = quota,
                    onBook = {
                        selectedTrainForBooking = train
                        showPaymentModal = true
                    }
                )
            }
        }
    }

    // Payment & Booking Confirmation Modal
    if (showPaymentModal && selectedTrainForBooking != null) {
        val train = selectedTrainForBooking!!
        val estimatedFare = when (travelClass) {
            "1A" -> 3200
            "2A" -> 2100
            "3A" -> 1450
            "SL" -> 580
            else -> 1800
        } * 2

        AlertDialog(
            onDismissRequest = { showPaymentModal = false },
            containerColor = Color(0xFF1E293B),
            titleContentColor = Color.White,
            title = {
                Text("BOOK TICKET — TRAIN ${train.number}")
            },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text(
                        text = "${train.name} (${train.originCode} → ${train.destCode})",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFFFB800)
                    )
                    Text(
                        text = "Departure: ${train.depTime} • Class: $travelClass • Quota: $quota",
                        fontSize = 12.sp,
                        color = Color(0xFF94A3B8)
                    )

                    HorizontalDivider(color = Color(0xFF334155), modifier = Modifier.padding(vertical = 12.dp))

                    Text("PASSENGER DETAILS", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = passenger1Name,
                            onValueChange = { passenger1Name = it },
                            label = { Text("Pax 1 Name") },
                            modifier = Modifier.weight(2f),
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                        )
                        OutlinedTextField(
                            value = passenger1Age,
                            onValueChange = { passenger1Age = it },
                            label = { Text("Age") },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = passenger2Name,
                            onValueChange = { passenger2Name = it },
                            label = { Text("Pax 2 Name") },
                            modifier = Modifier.weight(2f),
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                        )
                        OutlinedTextField(
                            value = passenger2Age,
                            onValueChange = { passenger2Age = it },
                            label = { Text("Age") },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                        )
                    }

                    HorizontalDivider(color = Color(0xFF334155), modifier = Modifier.padding(vertical = 12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("TOTAL FARE", fontSize = 11.sp, color = Color(0xFF94A3B8))
                            Text("₹$estimatedFare.00", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color(0xFF10B981))
                            Text("Includes IRCTC service tax & GST", fontSize = 10.sp, color = Color(0xFF64748B))
                        }

                        Surface(color = Color(0xFF0F172A), shape = RoundedCornerShape(8.dp)) {
                            Text("UPI / Mock Payment Gateway", fontSize = 11.sp, color = Color(0xFF60A5FA), modifier = Modifier.padding(8.dp))
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val paxList = listOf(
                            Pair(passenger1Name.ifBlank { "Passenger 1" }, passenger1Age.toIntOrNull() ?: 30),
                            Pair(passenger2Name.ifBlank { "Passenger 2" }, passenger2Age.toIntOrNull() ?: 35)
                        )
                        onBookClick(train, paxList)
                        showPaymentModal = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                    modifier = Modifier.testTag("confirm_payment_button")
                ) {
                    Icon(Icons.Default.Payment, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("AUTHORISE & ISSUE TICKET")
                }
            },
            dismissButton = {
                TextButton(onClick = { showPaymentModal = false }) {
                    Text("CANCEL", color = Color(0xFF94A3B8))
                }
            }
        )
    }
}

@Composable
private fun TrainCardItem(
    train: Train,
    selectedClass: String,
    quota: String,
    onBook: () -> Unit
) {
    val estimatedFare = when (selectedClass) {
        "1A" -> 3200
        "2A" -> 2100
        "3A" -> 1450
        "SL" -> 580
        else -> 1800
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("train_item_${train.number}"),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(color = Color(0xFF2563EB), shape = RoundedCornerShape(6.dp)) {
                        Text(
                            text = train.number,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = train.name,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Surface(color = Color(0xFF065F46), shape = RoundedCornerShape(6.dp)) {
                    Text(
                        text = "AVAILABLE - 42 SEATS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF34D399),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(train.originName, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("Dep: ${train.depTime}", fontSize = 12.sp, color = Color(0xFF60A5FA), fontWeight = FontWeight.Bold)
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(train.duration, fontSize = 11.sp, color = Color(0xFFFFB800), fontWeight = FontWeight.Bold)
                    Icon(Icons.Default.East, contentDescription = null, tint = Color(0xFF94A3B8), modifier = Modifier.size(20.dp))
                    Text("${train.distanceKm} km", fontSize = 10.sp, color = Color(0xFF94A3B8))
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(train.destName, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("Arr: ${train.arrTime}", fontSize = 12.sp, color = Color(0xFF34D399), fontWeight = FontWeight.Bold)
                }
            }

            HorizontalDivider(color = Color(0xFF334155), modifier = Modifier.padding(vertical = 12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(color = Color(0xFF0F172A), shape = RoundedCornerShape(6.dp)) {
                        Text("Class: $selectedClass", fontSize = 11.sp, color = Color.White, modifier = Modifier.padding(6.dp))
                    }
                    Surface(color = Color(0xFF0F172A), shape = RoundedCornerShape(6.dp)) {
                        Text("Quota: $quota", fontSize = 11.sp, color = Color.White, modifier = Modifier.padding(6.dp))
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "₹$estimatedFare.00",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF10B981)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Button(
                        onClick = onBook,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFB800), contentColor = Color(0xFF0F172A)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("book_button_${train.number}")
                    ) {
                        Text("BOOK NOW", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
