package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SyntheticRailwayData
import com.example.domain.model.DataClassification
import com.example.domain.model.DemoPersona
import com.example.domain.model.SupportedLanguage
import com.example.domain.model.UserRole

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoleHeaderBar(
    currentPersona: DemoPersona,
    currentLanguage: SupportedLanguage,
    isOffline: Boolean,
    onPersonaSelected: (DemoPersona) -> Unit,
    onLanguageSelected: (SupportedLanguage) -> Unit,
    onToggleOffline: () -> Unit,
    onOpenAiAssistant: () -> Unit
) {
    var showPersonaMenu by remember { mutableStateOf(false) }
    var showLangMenu by remember { mutableStateOf(false) }

    val classification = if (currentPersona.role == UserRole.PASSENGER) DataClassification.PUBLIC
    else if (currentPersona.role == UserRole.ADMIN) DataClassification.RESTRICTED
    else DataClassification.INTERNAL

    Surface(
        color = Color(0xFF0B192C),
        contentColor = Color.White,
        shadowElevation = 4.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Left: App Logo & Enterprise Branding
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFFFFB800)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.DirectionsRailway,
                        contentDescription = "Bharat Rail Logo",
                        tint = Color(0xFF0B192C),
                        modifier = Modifier.size(26.dp)
                    )
                }

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "BHARAT RAIL",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = Color.White,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            color = Color(0xFF1E3A8A),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "ENTERPRISE iPadOS",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF93C5FD),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = when (classification) {
                                DataClassification.PUBLIC -> Color(0xFF065F46)
                                DataClassification.RESTRICTED -> Color(0xFF991B1B)
                                else -> Color(0xFF92400E)
                            },
                            shape = RoundedCornerShape(3.dp)
                        ) {
                            Text(
                                text = classification.label,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Synthetic Railway Integration Adapter",
                            fontSize = 10.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }
                }
            }

            // Right: Persona Selector, Language Switcher, AI Assistant, Offline toggle
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Offline / Online Indicator Pill
                FilterChip(
                    selected = isOffline,
                    onClick = onToggleOffline,
                    label = {
                        Text(
                            text = if (isOffline) "OFFLINE DEMO" else "ONLINE ADAPTER",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = if (isOffline) Icons.Default.WifiOff else Icons.Default.Wifi,
                            contentDescription = "Sync State",
                            modifier = Modifier.size(14.dp)
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFF7F1D1D),
                        selectedLabelColor = Color(0xFFFCA5A5),
                        containerColor = Color(0xFF064E3B),
                        labelColor = Color(0xFF6EE7B7)
                    ),
                    modifier = Modifier.testTag("offline_toggle_chip")
                )

                // Language Switcher Menu
                Box {
                    OutlinedButton(
                        onClick = { showLangMenu = true },
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = Color.White
                        ),
                        border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(Color(0xFF334155))),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.testTag("language_selector_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Language,
                            contentDescription = "Select Language",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${currentLanguage.nativeName} (${currentLanguage.code.uppercase()})",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Icon(
                            imageVector = Icons.Default.ArrowDropDown,
                            contentDescription = null
                        )
                    }

                    DropdownMenu(
                        expanded = showLangMenu,
                        onDismissRequest = { showLangMenu = false },
                        modifier = Modifier.background(Color(0xFF1E293B))
                    ) {
                        SupportedLanguage.values().forEach { lang ->
                            DropdownMenuItem(
                                text = {
                                    Row(
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(lang.nativeName, color = Color.White, fontWeight = FontWeight.Bold)
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Text(lang.englishName, color = Color(0xFF94A3B8), fontSize = 12.sp)
                                    }
                                },
                                onClick = {
                                    onLanguageSelected(lang)
                                    showLangMenu = false
                                }
                            )
                        }
                    }
                }

                // AI Assistant Button
                IconButton(
                    onClick = onOpenAiAssistant,
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(Color(0xFF4338CA))
                        .testTag("ai_assistant_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.SmartToy,
                        contentDescription = "Bharat Rail AI Assistant",
                        tint = Color(0xFFFDE047)
                    )
                }

                // Persona Dynamic Transformer Menu
                Box {
                    Surface(
                        onClick = { showPersonaMenu = true },
                        shape = RoundedCornerShape(20.dp),
                        color = Color(currentPersona.role.badgeColorHex),
                        contentColor = Color.White,
                        modifier = Modifier.testTag("persona_switcher_chip")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(Color.White.copy(alpha = 0.25f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = currentPersona.avatarInitials,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = currentPersona.name,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = currentPersona.role.displayName,
                                    fontSize = 10.sp,
                                    color = Color.White.copy(alpha = 0.85f)
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                imageVector = Icons.Default.SwapHoriz,
                                contentDescription = "Switch Persona Role",
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    DropdownMenu(
                        expanded = showPersonaMenu,
                        onDismissRequest = { showPersonaMenu = false },
                        modifier = Modifier.background(Color(0xFF0F172A))
                    ) {
                        Text(
                            text = "SELECT DEMO PERSONA & ROLE WORKSPACE",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF94A3B8),
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                        HorizontalDivider(color = Color(0xFF334155))

                        SyntheticRailwayData.DEMO_PERSONAS.forEach { persona ->
                            DropdownMenuItem(
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(28.dp)
                                                .clip(CircleShape)
                                                .background(Color(persona.role.badgeColorHex)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = persona.avatarInitials,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = persona.name,
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp
                                            )
                                            Text(
                                                text = "${persona.role.displayName} • ${persona.organization}",
                                                color = Color(0xFF94A3B8),
                                                fontSize = 11.sp
                                            )
                                        }
                                    }
                                },
                                onClick = {
                                    onPersonaSelected(persona)
                                    showPersonaMenu = false
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
