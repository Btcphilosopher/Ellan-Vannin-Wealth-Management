package com.example.domain.model

enum class UserRole(val displayName: String, val badgeColorHex: Long) {
    PASSENGER("Passenger", 0xFF3B82F6),
    TTE("Train Ticket Examiner (TTE)", 0xFF8B5CF6),
    STATION_STAFF("Station Manager", 0xFF059669),
    CONTROL_ROOM("Control Room Officer", 0xFFDC2626),
    ADMIN("System Administrator", 0xFFD97706)
}

enum class DataClassification(val label: String) {
    PUBLIC("PUBLIC"),
    INTERNAL("INTERNAL - RAILWAY STAFF"),
    CONFIDENTIAL("CONFIDENTIAL - RESTRICTED ACCESS"),
    RESTRICTED("CRITICAL INFRASTRUCTURE")
}

data class DemoPersona(
    val id: String,
    val name: String,
    val role: UserRole,
    val designation: String,
    val organization: String,
    val stationCode: String? = null,
    val trainNumber: String? = null,
    val badgeNumber: String,
    val avatarInitials: String
)

data class Station(
    val code: String,
    val nameEn: String,
    val nameHi: String,
    val nameRegional: String,
    val city: String,
    val zone: String,
    val division: String,
    val platformsCount: Int,
    val lat: Double,
    val lng: Double,
    val facilities: List<String>
)

data class Train(
    val number: String,
    val name: String,
    val type: String, // Rajdhani, Shatabdi, Vande Bharat, Superfast
    val originCode: String,
    val originName: String,
    val destCode: String,
    val destName: String,
    val depTime: String,
    val arrTime: String,
    val duration: String,
    val distanceKm: Int,
    val coachComposition: List<String> // e.g., ["LOCO", "EOG", "H1", "A1", "B1", "B2", "B3", "S1", "S2", "PC", "GS"]
)

enum class TrainRunningStatus(val label: String, val colorHex: Long) {
    ON_TIME("On Time", 0xFF10B981),
    RUNNING("Running En Route", 0xFF10B981),
    DELAYED("Delayed", 0xFFF59E0B),
    HELD("Held at Signal", 0xFFEF4444),
    BOARDING("Boarding Open", 0xFF3B82F6),
    DEPARTED("Departed", 0xFF6366F1),
    CANCELLED("Cancelled", 0xFF9CA3AF)
}

data class LiveTrainTelemetry(
    val trainNumber: String,
    val currentStationCode: String,
    val currentStationName: String,
    val nextStationCode: String,
    val nextStationName: String,
    val delayMinutes: Int,
    val status: TrainRunningStatus,
    val currentSpeedKmh: Int,
    val lastUpdated: String,
    val platformNumber: Int,
    val isSimulated: Boolean = true
)

enum class BookingStatus(val label: String) {
    CONFIRMED("CNF - Confirmed"),
    RAC("RAC - Reservation Against Cancellation"),
    WAITLIST("WL - Waiting List"),
    CANCELLED("CAN - Cancelled")
}

data class SeatBerthInfo(
    val coach: String,
    val seatNumber: Int,
    val berthType: String, // LB, MB, UB, SL, SU, Window, Aisle
    val classCode: String  // 1A, 2A, 3A, SL, CC, EC
)

data class PassengerManifestItem(
    val pnr: String,
    val ticketId: String,
    val passengerName: String,
    val age: Int,
    val gender: String,
    val coach: String,
    val seatNumber: Int,
    val berthType: String,
    val bookingStatus: BookingStatus,
    val isVerified: Boolean = false,
    val boardingStation: String,
    val destinationStation: String,
    val concessionCategory: String? = null,
    val specialAssistance: String? = null
)

data class Ticket(
    val pnr: String,
    val bookingId: String,
    val trainNumber: String,
    val trainName: String,
    val originCode: String,
    val originName: String,
    val destCode: String,
    val destName: String,
    val journeyDate: String,
    val depTime: String,
    val arrTime: String,
    val travelClass: String,
    val quota: String,
    val passengers: List<PassengerManifestItem>,
    val totalFarePaisa: Long, // Stored as minor monetary units (paisa) to avoid float inaccuracies
    val currency: String = "INR",
    val paymentTxnId: String,
    val bookingTimestamp: String,
    val qrCodePayload: String,
    val isDemo: Boolean = true
)

enum class IncidentSeverity(val label: String, val colorHex: Long) {
    MINOR("Minor", 0xFF10B981),
    MODERATE("Moderate", 0xFFF59E0B),
    CRITICAL("Critical", 0xFFEF4444),
    EMERGENCY("Emergency", 0xFF7C3AED)
}

enum class IncidentStatus(val label: String) {
    OPEN("Open"),
    ACKNOWLEDGED("Acknowledged"),
    IN_PROGRESS("In Progress"),
    RESOLVED("Resolved"),
    CLOSED("Closed")
}

data class IncidentReport(
    val id: String,
    val title: String,
    val category: String, // Security, Medical, Equipment, Cleanliness, Catering, Signal
    val severity: IncidentSeverity,
    val location: String, // Station or Train
    val reportedBy: String,
    val reporterRole: String,
    val timestamp: String,
    val description: String,
    val status: IncidentStatus,
    val assignedTo: String? = null,
    val auditHistory: List<String> = emptyList()
)

data class StaffDuty(
    val dutyId: String,
    val staffId: String,
    val staffName: String,
    val role: UserRole,
    val shiftName: String, // Morning Shift, Night Duty, etc.
    val startTime: String,
    val endTime: String,
    val assignedTarget: String, // e.g. "Train 12951 (MMCT-NDLS)" or "Platform 1-4 (NDLS)"
    val zone: String,
    val division: String,
    val supervisorName: String,
    val tasksCount: Int,
    val completedTasksCount: Int,
    val isHandoverCompleted: Boolean = false
)

data class AuditEvent(
    val eventId: String,
    val timestamp: String,
    val actor: String,
    val role: String,
    val action: String,
    val resource: String,
    val resourceId: String,
    val status: String,
    val ipAddress: String = "10.14.88.19 (iPad Terminal)",
    val dataClassification: DataClassification = DataClassification.INTERNAL
)

data class SystemHealthMetric(
    val serviceName: String,
    val status: String, // HEALTHY, DEGRADED, DOWN
    val latencyMs: Int,
    val uptimePercent: Double,
    val syncQueueDepth: Int
)

enum class SupportedLanguage(
    val code: String,
    val nativeName: String,
    val englishName: String,
    val isRtl: Boolean = false
) {
    EN("en", "English", "English"),
    HI("hi", "हिन्दी", "Hindi"),
    BN("bn", "বাংলা", "Bengali"),
    TE("te", "తెలుగు", "Telugu"),
    MR("mr", "मराठी", "Marathi"),
    TA("ta", "தமிழ்", "Tamil"),
    GU("gu", "ગુજરાતી", "Gujarati"),
    KN("kn", "ಕನ್ನಡ", "Kannada"),
    ML("ml", "മലയാളം", "Malayalam"),
    OR("or", "ଓଡ଼ିଆ", "Odia"),
    PA("pa", "ਪੰਜਾਬੀ", "Punjabi"),
    AS("as", "অসমীয়া", "Assamese"),
    UR("ur", "اردو", "Urdu", isRtl = true)
}
