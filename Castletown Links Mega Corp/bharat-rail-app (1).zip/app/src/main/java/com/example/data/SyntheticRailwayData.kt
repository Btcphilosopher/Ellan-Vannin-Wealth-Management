package com.example.data

import com.example.domain.model.*

object SyntheticRailwayData {

    val DEMO_PERSONAS = listOf(
        DemoPersona(
            id = "PER-1001",
            name = "Asha Sharma",
            role = UserRole.PASSENGER,
            designation = "Frequent Traveler / Executive",
            organization = "General Passenger Services",
            badgeNumber = "PAS-994821",
            avatarInitials = "AS"
        ),
        DemoPersona(
            id = "PER-2004",
            name = "Rajiv Kumar",
            role = UserRole.TTE,
            designation = "Senior Ticket Examiner (TTE)",
            organization = "Western Railway (WR) - Mumbai Division",
            trainNumber = "12951",
            badgeNumber = "TTE-847291",
            avatarInitials = "RK"
        ),
        DemoPersona(
            id = "PER-3012",
            name = "Anita Rao",
            role = UserRole.STATION_STAFF,
            designation = "Chief Station Superintendent",
            organization = "Northern Railway (NR) - Delhi Division",
            stationCode = "NDLS",
            badgeNumber = "SS-402910",
            avatarInitials = "AR"
        ),
        DemoPersona(
            id = "PER-4008",
            name = "Vikram Singh",
            role = UserRole.CONTROL_ROOM,
            designation = "Chief Train Controller",
            organization = "Central Control Room (CCR) - Rail Bhavan",
            badgeNumber = "CTC-00192",
            avatarInitials = "VS"
        ),
        DemoPersona(
            id = "PER-5001",
            name = "Meera Patel",
            role = UserRole.ADMIN,
            designation = "Principal Systems Administrator",
            organization = "Centre for Railway Information Systems (CRIS)",
            badgeNumber = "ADM-00001",
            avatarInitials = "MP"
        )
    )

    val STATIONS = listOf(
        Station("NDLS", "New Delhi", "नई दिल्ली", "નવી દિલ્હી", "Delhi", "Northern Railway (NR)", "Delhi", 16, 28.6143, 77.2185, listOf("Executive Lounge", "Platform WiFi", "RPF Desk", "Divyangjan Ramp", "Retiring Rooms", "Medical Clinic")),
        Station("MMCT", "Mumbai Central", "मुंबई सेंट्रल", "મુંબઈ સેન્ટ્રલ", "Mumbai", "Western Railway (WR)", "Mumbai", 9, 18.9696, 72.8193, listOf("AC Waiting Hall", "Cyber Cafe", "Food Court", "Escalators", "Prepaid Taxi")),
        Station("HWH", "Howrah Junction", "हावड़ा जंक्शन", "হাওড়া জংশন", "Kolkata", "Eastern Railway (ER)", "Howrah", 23, 22.5839, 88.3426, listOf("Heritage Lounge", "Cloak Room", "Battery Carts", "Subway Connection")),
        Station("MAS", "Chennai Central", "चेन्नई सेंट्रल", "சென்னை சென்ட்ரல்", "Chennai", "Southern Railway (SR)", "Chennai", 12, 13.0827, 80.2757, listOf("Jan Ahaar", "Dormitory", "ATM", "Metro Interchange")),
        Station("SBC", "KSR Bengaluru", "केएसआर बेंगलुरु", "கேஎஸ்ஆர் பெங்களூரு", "Bengaluru", "South Western Railway (SWR)", "Bengaluru", 10, 12.9781, 77.5697, listOf("EV Charging", "Executive Lounge", "Wheelchair Hub")),
        Station("HYB", "Hyderabad Deccan", "हैदराबाद दक्कन", "హైదరాబాద్ దక్కన్", "Hyderabad", "South Central Railway (SCR)", "Secunderabad", 6, 17.3930, 78.4730, listOf("AC Waiting Room", "Self Check-in Kiosk")),
        Station("ADI", "Ahmedabad Junction", "अहमदाबाद जंक्शन", "અમદાવાદ જંકશન", "Ahmedabad", "Western Railway (WR)", "Ahmedabad", 12, 23.0225, 72.6004, listOf("Amul Parlour", "Luggage Scanner", "VIP Room")),
        Station("PUNE", "Pune Junction", "पुणे जंक्शन", "पुणे जंक्शन", "Pune", "Central Railway (CR)", "Pune", 6, 18.5289, 73.8744, listOf("Retiring Rooms", "Food Plaza", "RPF Post")),
        Station("JP", "Jaipur Junction", "जयपुर जंक्शन", "જયપુર જંકશન", "Jaipur", "North Western Railway (NWR)", "Jaipur", 8, 26.9196, 75.7878, listOf("Rajasthan Tourism Helpdesk", "Lounge")),
        Station("LKO", "Lucknow Charbagh", "लखनऊ चारबाग", "লখনউ চারবাগ", "Lucknow", "Northern Railway (NR)", "Lucknow", 9, 26.8322, 80.9238, listOf("Heritage Canopy", "Dormitories", "Food Kiosk")),
        Station("BSB", "Varanasi Junction", "वाराणसी जंक्शन", "বারাণসী জংশন", "Varanasi", "North Eastern Railway (NER)", "Varanasi", 9, 25.3267, 82.9868, listOf("Tourist Desk", "Cloak Room", "E-Cart")),
        Station("ASR", "Amritsar Junction", "अमृतसर जंक्शन", "ਅੰਮ੍ਰਿਤਸਰ ਜੰਕਸ਼ਨ", "Amritsar", "Northern Railway (NR)", "Firozpur", 6, 31.6340, 74.8723, listOf("Free WiFi", "Helpdesk", "Taxi Stand")),
        Station("BPL", "Bhopal Junction", "भोपाल जंक्शन", "ભોપાલ જંકશન", "Bhopal", "West Central Railway (WCR)", "Bhopal", 6, 23.2599, 77.4126, listOf("Passenger Lounge", "Wheelchairs")),
        Station("PNBE", "Patna Junction", "पटना जंक्शन", "পাটনা জংশন", "Patna", "East Central Railway (ECR)", "Danapur", 10, 25.6022, 85.1376, listOf("Fast Food Counter", "Information Desk")),
        Station("GHY", "Guwahati", "गुवाहाटी", "গৌহাটী", "Guwahati", "Northeast Frontier Railway (NFR)", "Lumding", 7, 26.1806, 91.7539, listOf("Northeast Craft Kiosk", "Resting Pods")),
        Station("TVC", "Thiruvananthapuram Central", "तिरुवनंतपुरम सेंट्रल", "തിരുവനന്തപുരം സെൻട്രൽ", "Thiruvananthapuram", "Southern Railway (SR)", "Trivandrum", 5, 8.4862, 76.9525, listOf("Kerala Tourism Hub", "AC Lounge"))
    )

    val TRAINS = listOf(
        Train(
            number = "12951",
            name = "Mumbai Rajdhani Express",
            type = "Superfast Rajdhani",
            originCode = "MMCT",
            originName = "Mumbai Central",
            destCode = "NDLS",
            destName = "New Delhi",
            depTime = "17:00",
            arrTime = "08:32 (+1 day)",
            duration = "15h 32m",
            distanceKm = 1386,
            coachComposition = listOf("LOCO", "EOG", "H1", "A1", "A2", "B1", "B2", "B3", "B4", "B5", "PC", "B6", "B7", "EOG")
        ),
        Train(
            number = "22436",
            name = "Vande Bharat Express",
            type = "Vande Bharat semi-high speed",
            originCode = "NDLS",
            originName = "New Delhi",
            destCode = "BSB",
            destName = "Varanasi Junction",
            depTime = "06:00",
            arrTime = "14:00",
            duration = "8h 00m",
            distanceKm = 759,
            coachComposition = listOf("D1", "C1", "C2", "C3", "C4", "EC1", "EC2", "C5", "C6", "C7", "D2")
        ),
        Train(
            number = "12002",
            name = "Bhopal Shatabdi Express",
            type = "Shatabdi Express",
            originCode = "NDLS",
            originName = "New Delhi",
            destCode = "RKMP",
            destName = "Rani Kamlapati (Bhopal)",
            depTime = "06:00",
            arrTime = "14:40",
            duration = "8h 40m",
            distanceKm = 708,
            coachComposition = listOf("LOCO", "EOG", "E1", "C1", "C2", "C3", "C4", "C5", "C6", "C7", "C8", "EOG")
        ),
        Train(
            number = "12301",
            name = "Howrah Rajdhani Express",
            type = "Superfast Rajdhani",
            originCode = "HWH",
            originName = "Howrah Junction",
            destCode = "NDLS",
            destName = "New Delhi",
            depTime = "16:50",
            arrTime = "10:05 (+1 day)",
            duration = "17h 15m",
            distanceKm = 1447,
            coachComposition = listOf("LOCO", "EOG", "H1", "A1", "A2", "B1", "B2", "B3", "B4", "PC", "B5", "B6", "EOG")
        ),
        Train(
            number = "12626",
            name = "Kerala Express",
            type = "Superfast Express",
            originCode = "NDLS",
            originName = "New Delhi",
            destCode = "TVC",
            destName = "Thiruvananthapuram Central",
            depTime = "20:10",
            arrTime = "18:00 (+2 days)",
            duration = "45h 50m",
            distanceKm = 3031,
            coachComposition = listOf("LOCO", "SLR", "GS", "S1", "S2", "S3", "S4", "S5", "B1", "B2", "A1", "PC", "S6", "S7", "GS", "SLR")
        )
    )

    val LIVE_TELEMETRY = listOf(
        LiveTrainTelemetry(
            trainNumber = "12951",
            currentStationCode = "ST",
            currentStationName = "Surat Junction",
            nextStationCode = "BRC",
            nextStationName = "Vadodara Junction",
            delayMinutes = 4,
            status = TrainRunningStatus.RUNNING,
            currentSpeedKmh = 128,
            lastUpdated = "10 mins ago via IRCTC-NTES Adapter",
            platformNumber = 1
        ),
        LiveTrainTelemetry(
            trainNumber = "22436",
            currentStationCode = "CNB",
            currentStationName = "Kanpur Central",
            nextStationCode = "PRYJ",
            nextStationName = "Prayagraj Junction",
            delayMinutes = 0,
            status = TrainRunningStatus.ON_TIME,
            currentSpeedKmh = 130,
            lastUpdated = "2 mins ago via GPS Telemetry",
            platformNumber = 3
        ),
        LiveTrainTelemetry(
            trainNumber = "12002",
            currentStationCode = "AGC",
            currentStationName = "Agra Cantt",
            nextStationCode = "GWL",
            nextStationName = "Gwalior Junction",
            delayMinutes = 12,
            status = TrainRunningStatus.DELAYED,
            currentSpeedKmh = 110,
            lastUpdated = "5 mins ago via Track Circuit Sensor",
            platformNumber = 2
        )
    )

    val SAMPLE_PASSENGERS_12951 = listOf(
        PassengerManifestItem(
            pnr = "2849102948",
            ticketId = "TKT-8839210",
            passengerName = "Asha Sharma",
            age = 34,
            gender = "Female",
            coach = "B1",
            seatNumber = 23,
            berthType = "LB (Lower Berth)",
            bookingStatus = BookingStatus.CONFIRMED,
            isVerified = true,
            boardingStation = "MMCT",
            destinationStation = "NDLS",
            specialAssistance = "Vegetarian Meal"
        ),
        PassengerManifestItem(
            pnr = "2849102948",
            ticketId = "TKT-8839210",
            passengerName = "Rohan Sharma",
            age = 38,
            gender = "Male",
            coach = "B1",
            seatNumber = 24,
            berthType = "UB (Upper Berth)",
            bookingStatus = BookingStatus.CONFIRMED,
            isVerified = true,
            boardingStation = "MMCT",
            destinationStation = "NDLS"
        ),
        PassengerManifestItem(
            pnr = "4810293847",
            ticketId = "TKT-9910482",
            passengerName = "Rajesh Gupta",
            age = 62,
            gender = "Male",
            coach = "B1",
            seatNumber = 11,
            berthType = "LB (Lower Berth)",
            bookingStatus = BookingStatus.CONFIRMED,
            isVerified = false,
            boardingStation = "MMCT",
            destinationStation = "NDLS",
            concessionCategory = "Senior Citizen"
        ),
        PassengerManifestItem(
            pnr = "5529183749",
            ticketId = "TKT-7729104",
            passengerName = "Priya Nair",
            age = 29,
            gender = "Female",
            coach = "B1",
            seatNumber = 45,
            berthType = "SL (Side Lower)",
            bookingStatus = BookingStatus.RAC,
            isVerified = false,
            boardingStation = "ST",
            destinationStation = "NDLS"
        ),
        PassengerManifestItem(
            pnr = "8839102931",
            ticketId = "TKT-6610293",
            passengerName = "Sanjay Verma",
            age = 45,
            gender = "Male",
            coach = "A1",
            seatNumber = 14,
            berthType = "LB (Lower Berth)",
            bookingStatus = BookingStatus.CONFIRMED,
            isVerified = true,
            boardingStation = "MMCT",
            destinationStation = "NDLS"
        )
    )

    val SAMPLE_TICKET = Ticket(
        pnr = "2849102948",
        bookingId = "BKG-2026-994821",
        trainNumber = "12951",
        trainName = "Mumbai Rajdhani Express",
        originCode = "MMCT",
        originName = "Mumbai Central",
        destCode = "NDLS",
        destName = "New Delhi",
        journeyDate = "14-Sep-2026",
        depTime = "17:00",
        arrTime = "08:32 (+1 day)",
        travelClass = "3AC (3rd AC)",
        quota = "GENERAL",
        passengers = listOf(SAMPLE_PASSENGERS_12951[0], SAMPLE_PASSENGERS_12951[1]),
        totalFarePaisa = 428000L, // Rs. 4,280.00
        currency = "INR",
        paymentTxnId = "TXN-UPI-99201948",
        bookingTimestamp = "2026-09-10 14:32:00 IST",
        qrCodePayload = "BHARATRAIL:PNR:2849102948:TKT:TKT-8839210:SIG:8aef91204c8"
    )

    val SAMPLE_INCIDENTS = listOf(
        IncidentReport(
            id = "INC-2026-0491",
            title = "AC Cooling Issue in Coach B1",
            category = "Equipment",
            severity = IncidentSeverity.MODERATE,
            location = "Train 12951 (En route Surat)",
            reportedBy = "Rajiv Kumar (TTE)",
            reporterRole = "TTE",
            timestamp = "12-Sep-2026 09:15 AM",
            description = "Compressor trip alert in Coach B1. Mechanical staff notified at Vadodara junction for inspection.",
            status = IncidentStatus.IN_PROGRESS,
            assignedTo = "Elect. Supervisor BRC",
            auditHistory = listOf("Logged by TTE Rajiv Kumar", "Assigned to Electrical Maintenance Team BRC")
        ),
        IncidentReport(
            id = "INC-2026-0382",
            title = "Platform 3 Escalator Maintenance",
            category = "Station Facility",
            severity = IncidentSeverity.MINOR,
            location = "New Delhi Station (NDLS)",
            reportedBy = "Anita Rao",
            reporterRole = "Station Staff",
            timestamp = "12-Sep-2026 08:30 AM",
            description = "Step sensor fault on Upward Escalator PF-3. Technicians on site.",
            status = IncidentStatus.ACKNOWLEDGED,
            assignedTo = "OTIS Station Tech",
            auditHistory = listOf("Logged by SS Anita Rao", "Vendor dispatch notified")
        ),
        IncidentReport(
            id = "INC-2026-0104",
            title = "Unscheduled Signal Delay near Mathura",
            category = "Signalling & Interlocking",
            severity = IncidentSeverity.CRITICAL,
            location = "Agra-Delhi Section",
            reportedBy = "Vikram Singh",
            reporterRole = "Control Room",
            timestamp = "12-Sep-2026 07:45 AM",
            description = "Track circuit failure S-42. Manual piloting enabled. 3 trains held.",
            status = IncidentStatus.IN_PROGRESS,
            assignedTo = "S&T Inspector Mathura",
            auditHistory = listOf("Logged by Control Room", "Speed restriction 15kmh imposed")
        )
    )

    val SAMPLE_DUTY = StaffDuty(
        dutyId = "DUTY-2026-8819",
        staffId = "EMP-847291",
        staffName = "Rajiv Kumar",
        role = UserRole.TTE,
        shiftName = "Day Express Duty",
        startTime = "06:00 IST",
        endTime = "18:00 IST",
        assignedTarget = "Train 12951 (MMCT -> NDLS) Coaches B1-B5",
        zone = "Western Railway (WR)",
        division = "Mumbai Division",
        supervisorName = "DCM Suresh Mehta",
        tasksCount = 142,
        completedTasksCount = 98,
        isHandoverCompleted = false
    )

    val SAMPLE_AUDIT_LOGS = listOf(
        AuditEvent("AUD-9901", "2026-09-12 09:42:10", "TTE Rajiv Kumar (EMP-847291)", "TTE", "VERIFY_PASSENGER", "PNR", "2849102948", "SUCCESS", dataClassification = DataClassification.CONFIDENTIAL),
        AuditEvent("AUD-9902", "2026-09-12 09:30:04", "System Administrator Meera Patel", "ADMIN", "UPDATE_FARE_RULE", "RuleEngine", "FR-2026-V4", "SUCCESS", dataClassification = DataClassification.RESTRICTED),
        AuditEvent("AUD-9903", "2026-09-12 09:15:22", "Station Manager Anita Rao", "STATION_STAFF", "CREATE_INCIDENT", "Incident", "INC-2026-0382", "SUCCESS", dataClassification = DataClassification.INTERNAL),
        AuditEvent("AUD-9904", "2026-09-12 08:50:11", "Passenger Asha Sharma", "PASSENGER", "BOOK_TICKET", "Booking", "BKG-2026-994821", "SUCCESS", dataClassification = DataClassification.PUBLIC)
    )
}
