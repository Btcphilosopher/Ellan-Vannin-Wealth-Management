package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.Ticket
import com.example.ui.components.PNRCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PnrStatusScreen(
    initialPnr: String,
    searchedTicket: Ticket?,
    onSearchPnr: (String) -> Unit
) {
    var pnrInput by remember { mutableStateOf(initialPnr) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .padding(24.dp)
    ) {
        Text(
            text = "PASSENGER RESERVATION STATUS & DIGITAL TICKET",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFFFFB800),
            letterSpacing = 1.sp
        )
        Text(
            text = "Instant PNR Lookup & Ticket Verification",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )

        Spacer(modifier = Modifier.height(16.dp))

        // PNR Search Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = pnrInput,
                onValueChange = { pnrInput = it },
                label = { Text("Enter 10-Digit PNR Number") },
                leadingIcon = { Icon(Icons.Default.QrCodeScanner, contentDescription = null, tint = Color(0xFFFFB800)) },
                modifier = Modifier
                    .weight(1f)
                    .testTag("pnr_search_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedBorderColor = Color(0xFFFFB800),
                    unfocusedBorderColor = Color(0xFF334155),
                    focusedContainerColor = Color(0xFF1E293B),
                    unfocusedContainerColor = Color(0xFF1E293B)
                ),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.width(12.dp))

            Button(
                onClick = { onSearchPnr(pnrInput) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFB800), contentColor = Color(0xFF0F172A)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .height(56.dp)
                    .testTag("lookup_pnr_button")
            ) {
                Icon(Icons.Default.Search, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("LOOKUP PNR", fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        if (searchedTicket != null) {
            PNRCard(ticket = searchedTicket)

            Spacer(modifier = Modifier.height(16.dp))

            // Export Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = { /* Export simulation */ },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Download, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("DOWNLOAD PDF TICKET")
                }

                OutlinedButton(
                    onClick = { /* Share simulation */ },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Share, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("SHARE TICKET PASS")
                }
            }
        } else {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.SearchOff, contentDescription = null, tint = Color(0xFF94A3B8), modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("No PNR Record Found", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("Please check the 10-digit PNR number or book a new ticket.", fontSize = 12.sp, color = Color(0xFF94A3B8))
                }
            }
        }
    }
}
