package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.DemoPersona
import com.example.domain.model.Ticket
import com.example.ui.AppScreen

data class PassengerActionItem(
    val title: String,
    val icon: ImageVector,
    val color: Color,
    val targetScreen: AppScreen? = null
)

@Composable
fun PassengerHomeScreen(
    persona: DemoPersona,
    activeTicket: Ticket?,
    onNavigate: (AppScreen) -> Unit
) {
    val scrollState = rememberScrollState()

    val actionItems = listOf(
        PassengerActionItem("BOOK TRAIN", Icons.Default.ConfirmationNumber, Color(0xFF2563EB), AppScreen.TRAIN_SEARCH),
        PassengerActionItem("MY JOURNEYS", Icons.Default.Luggage, Color(0xFF7C3AED), AppScreen.PNR_STATUS),
        PassengerActionItem("PNR STATUS", Icons.Default.QrCodeScanner, Color(0xFFD97706), AppScreen.PNR_STATUS),
        PassengerActionItem("TRACK TRAIN", Icons.Default.ShareLocation, Color(0xFF059669), AppScreen.LIVE_TRACKING),
        PassengerActionItem("STATION", Icons.Default.Storefront, Color(0xFF0284C7), AppScreen.STATION_INFO),
        PassengerActionItem("FARES & QUOTA", Icons.Default.AccountBalanceWallet, Color(0xFF4F46E5)),
        PassengerActionItem("REFUNDS", Icons.Default.CurrencyRupee, Color(0xFF10B981)),
        PassengerActionItem("FOOD / E-CATERING", Icons.Default.Fastfood, Color(0xFFEA580C)),
        PassengerActionItem("HOTELS & STAYS", Icons.Default.Hotel, Color(0xFF8B5CF6)),
        PassengerActionItem("RETIRING ROOMS", Icons.Default.Bed, Color(0xFF065F46)),
        PassengerActionItem("RAILMADAD", Icons.Default.ContactSupport, Color(0xFFDC2626)),
        PassengerActionItem("HELP KIOSK", Icons.Default.Help, Color(0xFF64748B))
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .padding(24.dp)
            .verticalScroll(scrollState)
    ) {
        // Welcome Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "GOOD MORNING,",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFFFB800),
                    letterSpacing = 1.sp
                )
                Text(
                    text = persona.name,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "Welcome to Indian Railways Enterprise Travel Hub",
                    fontSize = 13.sp,
                    color = Color(0xFF94A3B8)
                )
            }

            Surface(
                color = Color(0xFF1E293B),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.padding(8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.Star, contentDescription = null, tint = Color(0xFFFFB800))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Frequent Traveler Elite", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Next Journey Hero Card
        if (activeTicket != null) {
            Text(
                text = "UPCOMING JOURNEY",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF94A3B8),
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("next_journey_card"),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(color = Color(0xFF2563EB), shape = RoundedCornerShape(6.dp)) {
                            Text(
                                text = "TRAIN ${activeTicket.trainNumber}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                        Text(
                            text = activeTicket.trainName,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Surface(color = Color(0xFF065F46), shape = RoundedCornerShape(6.dp)) {
                            Text(
                                text = "RUNNING ON TIME",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF34D399),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF0F172A))
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = activeTicket.originName, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text(text = "Dep: ${activeTicket.depTime}", fontSize = 13.sp, color = Color(0xFF60A5FA), fontWeight = FontWeight.Bold)
                            Text(text = "Platform 1", fontSize = 12.sp, color = Color(0xFFFFB800))
                        }

                        Icon(
                            imageVector = Icons.Default.East,
                            contentDescription = null,
                            tint = Color(0xFFFFB800),
                            modifier = Modifier.size(28.dp)
                        )

                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = activeTicket.destName, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text(text = "Arr: ${activeTicket.arrTime}", fontSize = 13.sp, color = Color(0xFF34D399), fontWeight = FontWeight.Bold)
                            Text(text = "Date: ${activeTicket.journeyDate}", fontSize = 12.sp, color = Color(0xFF94A3B8))
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    val firstPax = activeTicket.passengers.firstOrNull()
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                            Column {
                                Text("COACH", fontSize = 11.sp, color = Color(0xFF94A3B8))
                                Text(firstPax?.coach ?: "B1", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                            Column {
                                Text("SEAT / BERTH", fontSize = 11.sp, color = Color(0xFF94A3B8))
                                Text("${firstPax?.seatNumber ?: 23} (${firstPax?.berthType ?: "LB"})", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                            Column {
                                Text("PNR", fontSize = 11.sp, color = Color(0xFF94A3B8))
                                Text(activeTicket.pnr, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFFB800))
                            }
                        }

                        Button(
                            onClick = { onNavigate(AppScreen.PNR_STATUS) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                            modifier = Modifier.testTag("view_digital_ticket_button")
                        ) {
                            Icon(imageVector = Icons.Default.QrCode, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("VIEW TICKET & QR")
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Quick Actions Grid
        Text(
            text = "PASSENGER SERVICES",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF94A3B8),
            letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(12.dp))

        // 4 Columns Grid for iPad screen space
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            actionItems.chunked(4).forEach { rowItems ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    rowItems.forEach { item ->
                        Card(
                            modifier = Modifier
                                .weight(1f)
                                .height(90.dp)
                                .clickable {
                                    if (item.targetScreen != null) {
                                        onNavigate(item.targetScreen)
                                    }
                                }
                                .testTag("action_${item.title.lowercase().replace(" ", "_")}"),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(item.color.copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = item.icon,
                                        contentDescription = item.title,
                                        tint = item.color,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = item.title,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
