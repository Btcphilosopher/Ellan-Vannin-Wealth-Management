package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SyntheticRailwayData
import com.example.domain.model.AuditEvent
import com.example.domain.model.DemoPersona

@Composable
fun AdminConsoleScreen(
    persona: DemoPersona,
    auditLogs: List<AuditEvent>
) {
    var selectedTab by remember { mutableStateOf(0) } // 0: Audit Logs, 1: RBAC Matrix, 2: System Health

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .padding(24.dp)
    ) {
        // Admin Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "CRIS / RAILWAY BOARD GOVERNANCE CONSOLE",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFD97706),
                    letterSpacing = 1.sp
                )
                Text(
                    text = "System Administration & RBAC Security",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "Administrator: ${persona.name} (${persona.organization})",
                    fontSize = 13.sp,
                    color = Color(0xFF94A3B8)
                )
            }

            Surface(color = Color(0xFF92400E), shape = RoundedCornerShape(12.dp)) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Security, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("FULL ADMIN ACCESS", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Navigation Tabs
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color(0xFF1E293B),
            contentColor = Color.White
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("IMMUTABLE AUDIT LOGS", fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("RBAC / ABAC PERMISSIONS", fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = selectedTab == 2,
                onClick = { selectedTab = 2 },
                text = { Text("SYSTEM OBSERVABILITY", fontWeight = FontWeight.Bold) }
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        when (selectedTab) {
            0 -> AuditLogsView(auditLogs)
            1 -> RbacMatrixView()
            2 -> SystemHealthView()
        }
    }
}

@Composable
private fun AuditLogsView(logs: List<AuditEvent>) {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(logs) { log ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(log.eventId, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = Color(0xFFFFB800), fontSize = 13.sp)
                        Text(log.timestamp, fontSize = 11.sp, color = Color(0xFF94A3B8))
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Actor: ${log.actor} [Role: ${log.role}]", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                    Text("Action: ${log.action} on ${log.resource} (${log.resourceId})", color = Color(0xFFCBD5E1), fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Surface(color = Color(0xFF0F172A), shape = RoundedCornerShape(4.dp)) {
                            Text(log.dataClassification.label, fontSize = 9.sp, color = Color(0xFF60A5FA), modifier = Modifier.padding(4.dp))
                        }
                        Text("IP: ${log.ipAddress}", fontSize = 10.sp, color = Color(0xFF64748B))
                    }
                }
            }
        }
    }
}

@Composable
private fun RbacMatrixView() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        Text("ROLE BASED ACCESS CONTROL (RBAC) POLICIES", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 16.sp)
        Spacer(modifier = Modifier.height(12.dp))

        val rolesList = listOf(
            Triple("PASSENGER", "Public Travel Search, Booking, PNR Lookup", "PUBLIC"),
            Triple("TTE (Ticket Examiner)", "Passenger Manifest Inspection, Seat Verification, Incident Reporting", "CONFIDENTIAL"),
            Triple("STATION SUPERINTENDENT", "Platform Assignments, Public Announcement, Station Facilities", "INTERNAL"),
            Triple("CONTROL ROOM OFFICER", "Zonal Train Telemetry, Speed Restrictions, Network Emergency Dispatch", "CRITICAL"),
            Triple("SYSTEM ADMINISTRATOR", "Full System Governance, User Roster, Immutable Audit Logs, Fare Engine", "RESTRICTED")
        )

        rolesList.forEach { item ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(item.first, fontWeight = FontWeight.Bold, color = Color(0xFFFFB800), fontSize = 15.sp)
                        Surface(color = Color(0xFF0F172A), shape = RoundedCornerShape(4.dp)) {
                            Text(item.third, fontSize = 10.sp, color = Color(0xFF34D399), modifier = Modifier.padding(4.dp))
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(item.second, color = Color.White, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
private fun SystemHealthView() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        Text("SYSTEM OBSERVABILITY TELEMETRY", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 16.sp)
        Spacer(modifier = Modifier.height(12.dp))

        val services = listOf(
            Triple("IRCTC Reservation Gateway Adapter", "HEALTHY", "Latency: 42ms • Uptime: 99.99%"),
            Triple("NTES GPS Train Telemetry Service", "HEALTHY", "Latency: 28ms • Uptime: 99.98%"),
            Triple("RailMadad Incident Sync Engine", "HEALTHY", "Latency: 65ms • Uptime: 99.95%"),
            Triple("Room Local Database Sync Queue", "SYNCED", "Depth: 0 pending transactions")
        )

        services.forEach { item ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(item.first, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                        Text(item.third, color = Color(0xFF94A3B8), fontSize = 11.sp)
                    }
                    Surface(color = Color(0xFF065F46), shape = RoundedCornerShape(4.dp)) {
                        Text(item.second, fontSize = 10.sp, color = Color(0xFF34D399), fontWeight = FontWeight.Bold, modifier = Modifier.padding(6.dp))
                    }
                }
            }
        }
    }
}
