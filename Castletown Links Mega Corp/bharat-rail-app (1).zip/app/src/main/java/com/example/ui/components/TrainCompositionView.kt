package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.Train

@Composable
fun TrainCompositionView(
    train: Train,
    selectedCoach: String? = "B1",
    onSelectCoach: (String) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("train_composition_card"),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.DirectionsRailway,
                        contentDescription = null,
                        tint = Color(0xFFFFB800)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "COACH POSITION & COMPOSITION (${train.coachComposition.size} COACHES)",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Text(
                    text = "Tap Coach to Inspect Manifest",
                    fontSize = 11.sp,
                    color = Color(0xFF94A3B8)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Horizontal scrolling coach diagram
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                contentPadding = PaddingValues(horizontal = 4.dp)
            ) {
                items(train.coachComposition) { coachCode ->
                    val isLoco = coachCode == "LOCO"
                    val isPantry = coachCode == "PC"
                    val isGenerator = coachCode == "EOG"
                    val isSelected = coachCode == selectedCoach

                    val bgColor = when {
                        isLoco -> Color(0xFFDC2626) // Engine Red
                        isPantry -> Color(0xFFD97706) // Pantry Amber
                        isGenerator -> Color(0xFF475569) // Generator Dark
                        coachCode.startsWith("H") -> Color(0xFF7C3AED) // 1st AC Purple
                        coachCode.startsWith("A") -> Color(0xFF2563EB) // 2nd AC Blue
                        coachCode.startsWith("B") -> Color(0xFF0284C7) // 3rd AC Cyan
                        coachCode.startsWith("S") -> Color(0xFF059669) // Sleeper Green
                        else -> Color(0xFF64748B) // Unreserved / General
                    }

                    Box(
                        modifier = Modifier
                            .width(76.dp)
                            .height(68.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(bgColor)
                            .clickable { onSelectCoach(coachCode) }
                            .padding(6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            if (isLoco) {
                                Icon(
                                    imageVector = Icons.Default.Train,
                                    contentDescription = "Locomotive Engine",
                                    tint = Color.White,
                                    modifier = Modifier.size(22.dp)
                                )
                                Text("ENGINE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            } else if (isPantry) {
                                Icon(
                                    imageVector = Icons.Default.Restaurant,
                                    contentDescription = "Pantry Car",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text("PANTRY", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            } else {
                                Text(
                                    text = coachCode,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = when {
                                        coachCode.startsWith("H") -> "1st AC"
                                        coachCode.startsWith("A") -> "2nd AC"
                                        coachCode.startsWith("B") -> "3rd AC"
                                        coachCode.startsWith("S") -> "Sleeper"
                                        else -> "General"
                                    },
                                    fontSize = 9.sp,
                                    color = Color.White.copy(alpha = 0.85f)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
