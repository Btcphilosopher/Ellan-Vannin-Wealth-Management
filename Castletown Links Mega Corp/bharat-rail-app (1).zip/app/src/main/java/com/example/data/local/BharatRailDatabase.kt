package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        StationEntity::class,
        TicketEntity::class,
        IncidentEntity::class,
        AuditLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class BharatRailDatabase : RoomDatabase() {
    abstract fun stationDao(): StationDao
    abstract fun ticketDao(): TicketDao
    abstract fun incidentDao(): IncidentDao
    abstract fun auditDao(): AuditDao

    companion object {
        @Volatile
        private var INSTANCE: BharatRailDatabase? = null

        fun getDatabase(context: Context): BharatRailDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    BharatRailDatabase::class.java,
                    "bharat_rail_db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
