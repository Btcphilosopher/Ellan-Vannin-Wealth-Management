package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.UserRole
import com.example.ui.AppScreen

@Composable
fun IPadNavRail(
    currentScreen: AppScreen,
    userRole: UserRole,
    onNavigate: (AppScreen) -> Unit
) {
    NavigationRail(
        containerColor = Color(0xFF0F172A),
        contentColor = Color.White,
        modifier = Modifier.width(96.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxHeight()
                .padding(vertical = 12.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Common / Passenger items
                NavRailItemHelper(
                    screen = AppScreen.PASSENGER_HOME,
                    icon = Icons.Default.Home,
                    label = "Home",
                    isSelected = currentScreen == AppScreen.PASSENGER_HOME,
                    onNavigate = onNavigate
                )
                NavRailItemHelper(
                    screen = AppScreen.TRAIN_SEARCH,
                    icon = Icons.Default.ConfirmationNumber,
                    label = "Book",
                    isSelected = currentScreen == AppScreen.TRAIN_SEARCH,
                    onNavigate = onNavigate
                )
                NavRailItemHelper(
                    screen = AppScreen.PNR_STATUS,
                    icon = Icons.Default.QrCodeScanner,
                    label = "PNR",
                    isSelected = currentScreen == AppScreen.PNR_STATUS,
                    onNavigate = onNavigate
                )
                NavRailItemHelper(
                    screen = AppScreen.LIVE_TRACKING,
                    icon = Icons.Default.ShareLocation,
                    label = "Live Status",
                    isSelected = currentScreen == AppScreen.LIVE_TRACKING,
                    onNavigate = onNavigate
                )
                NavRailItemHelper(
                    screen = AppScreen.STATION_INFO,
                    icon = Icons.Default.Storefront,
                    label = "Stations",
                    isSelected = currentScreen == AppScreen.STATION_INFO,
                    onNavigate = onNavigate
                )

                HorizontalDivider(
                    color = Color(0xFF334155),
                    modifier = Modifier
                        .padding(vertical = 4.dp, horizontal = 12.dp)
                        .fillMaxWidth()
                )

                // Staff items (Visible for TTE, Station Staff, Control Room, Admin)
                if (userRole != UserRole.PASSENGER) {
                    if (userRole == UserRole.TTE || userRole == UserRole.ADMIN) {
                        NavRailItemHelper(
                            screen = AppScreen.TTE_INSPECTION,
                            icon = Icons.Default.Badge,
                            label = "TTE Verify",
                            isSelected = currentScreen == AppScreen.TTE_INSPECTION,
                            onNavigate = onNavigate
                        )
                    }
                    if (userRole == UserRole.STATION_STAFF || userRole == UserRole.ADMIN) {
                        NavRailItemHelper(
                            screen = AppScreen.STATION_OPS,
                            icon = Icons.Default.MeetingRoom,
                            label = "Station Ops",
                            isSelected = currentScreen == AppScreen.STATION_OPS,
                            onNavigate = onNavigate
                        )
                    }
                    if (userRole == UserRole.CONTROL_ROOM || userRole == UserRole.ADMIN) {
                        NavRailItemHelper(
                            screen = AppScreen.CONTROL_ROOM,
                            icon = Icons.Default.Dashboard,
                            label = "Control Room",
                            isSelected = currentScreen == AppScreen.CONTROL_ROOM,
                            onNavigate = onNavigate
                        )
                    }
                    NavRailItemHelper(
                        screen = AppScreen.STAFF_DUTY,
                        icon = Icons.Default.AssignmentInd,
                        label = "Duty",
                        isSelected = currentScreen == AppScreen.STAFF_DUTY,
                        onNavigate = onNavigate
                    )
                    NavRailItemHelper(
                        screen = AppScreen.INCIDENT_MGMT,
                        icon = Icons.Default.Warning,
                        label = "Incidents",
                        isSelected = currentScreen == AppScreen.INCIDENT_MGMT,
                        onNavigate = onNavigate
                    )
                }

                // Admin Console
                if (userRole == UserRole.ADMIN) {
                    NavRailItemHelper(
                        screen = AppScreen.ADMIN_CONSOLE,
                        icon = Icons.Default.AdminPanelSettings,
                        label = "Admin",
                        isSelected = currentScreen == AppScreen.ADMIN_CONSOLE,
                        onNavigate = onNavigate
                    )
                    NavRailItemHelper(
                        screen = AppScreen.AUDIT_TRAIL,
                        icon = Icons.Default.ReceiptLong,
                        label = "Audit",
                        isSelected = currentScreen == AppScreen.AUDIT_TRAIL,
                        onNavigate = onNavigate
                    )
                }
            }

            // Bottom role status badge
            Surface(
                color = Color(0xFF1E293B),
                shape = MaterialTheme.shapes.small
            ) {
                Text(
                    text = userRole.name.take(4),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF94A3B8),
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
        }
    }
}

@Composable
private fun NavRailItemHelper(
    screen: AppScreen,
    icon: ImageVector,
    label: String,
    isSelected: Boolean,
    onNavigate: (AppScreen) -> Unit
) {
    NavigationRailItem(
        selected = isSelected,
        onClick = { onNavigate(screen) },
        icon = {
            Icon(
                imageVector = icon,
                contentDescription = label,
                modifier = Modifier.size(20.dp)
            )
        },
        label = {
            Text(
                text = label,
                fontSize = 10.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
            )
        },
        colors = NavigationRailItemDefaults.colors(
            selectedIconColor = Color(0xFF0F172A),
            selectedTextColor = Color(0xFFFFB800),
            indicatorColor = Color(0xFFFFB800),
            unselectedIconColor = Color(0xFF94A3B8),
            unselectedTextColor = Color(0xFF94A3B8)
        ),
        modifier = Modifier.testTag("nav_${screen.name.lowercase()}")
    )
}
