package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SyntheticRailwayData
import com.example.domain.model.DemoPersona
import com.example.domain.model.IncidentSeverity
import com.example.domain.model.PassengerManifestItem
import com.example.ui.components.TrainCompositionView

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TteInspectionScreen(
    persona: DemoPersona,
    manifestItems: List<PassengerManifestItem>,
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    onVerifyPax: (String, Int) -> Unit,
    onLogIncident: (String, String, IncidentSeverity, String, String) -> Unit
) {
    var selectedCoach by remember { mutableStateOf("B1") }
    var showQrScannerModal by remember { mutableStateOf(false) }
    var showIncidentModal by remember { mutableStateOf(false) }
    var incidentTitle by remember { mutableStateOf("") }
    var incidentDesc by remember { mutableStateOf("") }
    var incidentCategory by remember { mutableStateOf("Passenger Assistance") }

    val train = SyntheticRailwayData.TRAINS[0] // 12951 Mumbai Rajdhani

    val filteredPax = manifestItems.filter { pax ->
        val matchesCoach = (pax.coach == selectedCoach || selectedCoach == "ALL")
        val matchesSearch = pax.passengerName.contains(searchQuery, ignoreCase = true) ||
                pax.pnr.contains(searchQuery) ||
                pax.seatNumber.toString().contains(searchQuery)
        matchesCoach && matchesSearch
    }

    val verifiedCount = manifestItems.count { it.isVerified }
    val totalCount = manifestItems.size

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .padding(24.dp)
    ) {
        // Top TTE Command Banner
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "TTE WORKSPACE — ${persona.name.uppercase()} (${persona.badgeNumber})",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF8B5CF6),
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Train 12951 • Mumbai Rajdhani Express",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "Duty: MMCT → NDLS • Verified: $verifiedCount / $totalCount Passengers",
                    fontSize = 13.sp,
                    color = Color(0xFF94A3B8)
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = { showQrScannerModal = true },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8B5CF6)),
                    modifier = Modifier.testTag("simulate_qr_scanner_button")
                ) {
                    Icon(Icons.Default.QrCodeScanner, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("DIGITAL QR SCANNER")
                }

                Button(
                    onClick = { showIncidentModal = true },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                    modifier = Modifier.testTag("log_tte_incident_button")
                ) {
                    Icon(Icons.Default.ReportProblem, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("LOG INCIDENT")
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Train Composition Coach Visualizer
        TrainCompositionView(
            train = train,
            selectedCoach = selectedCoach,
            onSelectCoach = { selectedCoach = it }
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Manifest Search Bar & Coach Filter Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchChange,
                placeholder = { Text("Search by Name, PNR, or Seat Number...", color = Color(0xFF64748B)) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFF8B5CF6)) },
                modifier = Modifier
                    .weight(1f)
                    .testTag("tte_manifest_search"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedBorderColor = Color(0xFF8B5CF6),
                    unfocusedBorderColor = Color(0xFF334155),
                    focusedContainerColor = Color(0xFF1E293B),
                    unfocusedContainerColor = Color(0xFF1E293B)
                ),
                shape = RoundedCornerShape(10.dp)
            )

            Spacer(modifier = Modifier.width(16.dp))

            Surface(color = Color(0xFF1E293B), shape = RoundedCornerShape(10.dp)) {
                Text(
                    text = "COACH $selectedCoach MANIFEST (${filteredPax.size})",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 14.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Passenger List Table
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(filteredPax) { pax ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("pax_manifest_item_${pax.pnr}_${pax.seatNumber}"),
                    colors = CardDefaults.cardColors(
                        containerColor = if (pax.isVerified) Color(0xFF0F291E) else Color(0xFF1E293B)
                    ),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                color = if (pax.isVerified) Color(0xFF059669) else Color(0xFF334155),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.size(44.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = "${pax.seatNumber}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp,
                                        color = Color.White
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(14.dp))

                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(pax.passengerName, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("(${pax.age} y/o, ${pax.gender})", fontSize = 12.sp, color = Color(0xFF94A3B8))
                                }
                                Text("PNR: ${pax.pnr} • Coach ${pax.coach} • ${pax.berthType}", fontSize = 12.sp, color = Color(0xFFCBD5E1))
                                if (pax.specialAssistance != null) {
                                    Text("Note: ${pax.specialAssistance}", fontSize = 11.sp, color = Color(0xFFFDE047))
                                }
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(color = Color(0xFF0F172A), shape = RoundedCornerShape(6.dp)) {
                                Text(
                                    text = pax.bookingStatus.label,
                                    fontSize = 11.sp,
                                    color = Color(0xFF60A5FA),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            if (pax.isVerified) {
                                Button(
                                    onClick = { },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                                    enabled = false
                                ) {
                                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("VERIFIED")
                                }
                            } else {
                                Button(
                                    onClick = { onVerifyPax(pax.pnr, pax.seatNumber) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFB800), contentColor = Color(0xFF0F172A)),
                                    modifier = Modifier.testTag("verify_btn_${pax.seatNumber}")
                                ) {
                                    Text("MARK PRESENT", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // QR Code Scanner Simulation Modal
    if (showQrScannerModal) {
        AlertDialog(
            onDismissRequest = { showQrScannerModal = false },
            containerColor = Color(0xFF1E293B),
            title = { Text("DIGITAL TICKET QR SCANNER", color = Color.White) },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier
                            .size(180.dp)
                            .background(Color.Black, shape = RoundedCornerShape(12.dp))
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.QrCodeScanner, contentDescription = null, tint = Color(0xFF8B5CF6), modifier = Modifier.size(64.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Camera Active", color = Color.Green, fontSize = 12.sp)
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Align passenger digital ticket QR inside frame.", fontSize = 12.sp, color = Color(0xFF94A3B8))
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onVerifyPax("2849102948", 23)
                        showQrScannerModal = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669))
                ) {
                    Text("SIMULATE SUCCESSFUL SCAN")
                }
            },
            dismissButton = {
                TextButton(onClick = { showQrScannerModal = false }) {
                    Text("CANCEL", color = Color(0xFF94A3B8))
                }
            }
        )
    }

    // Log Incident Modal
    if (showIncidentModal) {
        AlertDialog(
            onDismissRequest = { showIncidentModal = false },
            containerColor = Color(0xFF1E293B),
            title = { Text("LOG TTE INCIDENT REPORT", color = Color.White) },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    OutlinedTextField(
                        value = incidentTitle,
                        onValueChange = { incidentTitle = it },
                        label = { Text("Incident Title") },
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = incidentDesc,
                        onValueChange = { incidentDesc = it },
                        label = { Text("Description & Evidence Details") },
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (incidentTitle.isNotBlank()) {
                            onLogIncident(
                                incidentTitle,
                                incidentCategory,
                                IncidentSeverity.MODERATE,
                                "Train 12951 (Coach $selectedCoach)",
                                incidentDesc
                            )
                            showIncidentModal = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text("SUBMIT INCIDENT REPORT")
                }
            },
            dismissButton = {
                TextButton(onClick = { showIncidentModal = false }) {
                    Text("CANCEL", color = Color(0xFF94A3B8))
                }
            }
        )
    }
}
