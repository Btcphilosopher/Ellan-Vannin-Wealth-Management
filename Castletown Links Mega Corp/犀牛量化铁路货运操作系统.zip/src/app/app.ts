import { ChangeDetectionStrategy, Component, OnInit, OnDestroy, signal, inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { ReactiveFormsModule, FormGroup, FormControl, Validators } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { Station, Section, Locomotive, Order, Waybill, ActiveTrain, LogEvent, RouteOption } from '../rail-engine';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [ReactiveFormsModule, MatIconModule],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App implements OnInit, OnDestroy {
  private platformId = inject(PLATFORM_ID);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private pollIntervalId: any;

  // Tabs navigation
  public activeTab = signal<string>('dashboard');

  // Grounded stats & listings
  public stats = signal<{
    todayVolume: number;
    todayDepartures: number;
    todayArrivals: number;
    delayedCount: number;
    congestionRate: number;
    fuelPrice: number;
    carbonSavingsCo2: number;
  }>({
    todayVolume: 245000,
    todayDepartures: 142,
    todayArrivals: 135,
    delayedCount: 4,
    congestionRate: 0.12,
    fuelPrice: 7.2,
    carbonSavingsCo2: 1250000
  });
  public logs = signal<LogEvent[]>([]);
  public activeTrains = signal<ActiveTrain[]>([]);
  public stations = signal<Station[]>([]);
  public sections = signal<Section[]>([]);
  public orders = signal<Order[]>([]);
  public waybills = signal<Waybill[]>([]);
  public locomotives = signal<Locomotive[]>([]);

  // Detailed selections
  public selectedTrain = signal<ActiveTrain | null>(null);

  // Forms
  public routeForm: FormGroup;
  public orderForm: FormGroup;
  public chatForm: FormGroup;

  // Form Outputs
  public calculatedRoutes = signal<RouteOption[] | null>(null);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public calculatedPricing = signal<any | null>(null);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public multimodalComparison = signal<any[] | null>(null);
  public isCalculatingRoutes = signal<boolean>(false);
  public isCreatingOrder = signal<boolean>(false);

  // AI Assistant Chat
  public chatHistory = signal<{ role: 'user' | 'assistant', text: string }[]>([]);
  public chatLoading = signal<boolean>(false);

  //河钢集团 10000吨钢材主流程演示状态
  public steelStep = signal<number>(0); 
  // 0: 未开始
  // 1: 需求建立，方案及三条径路规划中
  // 2: 车辆配车 & 列车编组已生成
  // 3: 运行图及调度排点完毕，列车正点发车
  // 4: 模拟线路突发拥堵，异常诊断与替代路由计算
  // 5: 克服拥堵，到达终点站并成功卸车交付
  // 6: 运费结算、高精度成本利润核算，进入经营分析
  
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public steelOrder = signal<any | null>(null);
  public steelRoutes = signal<RouteOption[] | null>(null);

  constructor() {
    this.routeForm = new FormGroup({
      fromStationId: new FormControl('ST-TAIYUAN', Validators.required),
      toStationId: new FormControl('ST-SHANGHAI', Validators.required),
      weight: new FormControl(5000, [Validators.required, Validators.min(1)]),
      cargoType: new FormControl('钢材', Validators.required)
    });

    this.orderForm = new FormGroup({
      customerName: new FormControl('', Validators.required),
      cargoType: new FormControl('集装箱', Validators.required),
      weight: new FormControl(2000, [Validators.required, Validators.min(1)]),
      fromStationId: new FormControl('ST-BEIJING', Validators.required),
      toStationId: new FormControl('ST-ZHENGZHOU', Validators.required),
      agreedPrice: new FormControl(null)
    });

    this.chatForm = new FormGroup({
      message: new FormControl('', Validators.required)
    });
  }

  ngOnInit() {
    this.fetchStatus();
    this.fetchStations();
    
    // Seed helper message in AI console
    this.chatHistory.set([
      { role: 'assistant', text: '您好！我是「犀牛量化·铁路货运操作系统」智能助理。我可以帮您检索今日异常车流、测算吨公里最优定价、进行径路冲突重构，或者规划大规模货运方案。您可以随时提问！' }
    ]);

    if (isPlatformBrowser(this.platformId)) {
      this.pollIntervalId = setInterval(() => {
        this.fetchStatus();
      }, 4000);
    }
  }

  ngOnDestroy() {
    if (this.pollIntervalId) {
      clearInterval(this.pollIntervalId);
    }
  }

  // Fetch status and active trains from Server API
  private async fetchStatus() {
    try {
      const res = await fetch('/api/rail/status');
      if (res.ok) {
        const data = await res.json();
        this.stats.set(data.stats);
        this.logs.set(data.logs);
      }

      const trainsRes = await fetch('/api/rail/active-trains');
      if (trainsRes.ok) {
        const trains = await trainsRes.json();
        this.activeTrains.set(trains);
        // Refresh selected train if open
        const current = this.selectedTrain();
        if (current) {
          const updated = trains.find((t: ActiveTrain) => t.id === current.id);
          if (updated) this.selectedTrain.set(updated);
        }
      }

      const ordersRes = await fetch('/api/rail/orders');
      if (ordersRes.ok) {
        this.orders.set(await ordersRes.json());
      }

      const waybillsRes = await fetch('/api/rail/waybills');
      if (waybillsRes.ok) {
        this.waybills.set(await waybillsRes.json());
      }

      const locRes = await fetch('/api/rail/locomotives');
      if (locRes.ok) {
        this.locomotives.set(await locRes.json());
      }
    } catch (err) {
      console.error('Failed to poll status', err);
    }
  }

  private async fetchStations() {
    try {
      const res = await fetch('/api/rail/stations');
      if (res.ok) {
        this.stations.set(await res.json());
      }
      const secRes = await fetch('/api/rail/sections');
      if (secRes.ok) {
        this.sections.set(await secRes.json());
      }
    } catch (err) {
      console.error('Failed to load initial stations/sections', err);
    }
  }

  public setTab(tab: string) {
    this.activeTab.set(tab);
  }

  // Dijkstra Multi-objective Path calculation & Carbon emissions
  public async onCalculateRoutes() {
    if (this.routeForm.invalid) return;
    this.isCalculatingRoutes.set(true);

    const values = this.routeForm.value;
    try {
      // 1. Calculate Routes
      const routeRes = await fetch('/api/rail/route-query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(values)
      });
      if (routeRes.ok) {
        const routes = await routeRes.json();
        this.calculatedRoutes.set(routes);

        // Compute pricing for first route as primary
        if (routes.length > 0) {
          const pricingRes = await fetch('/api/rail/dynamic-price', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              distance: routes[0].distance,
              weight: values.weight,
              cargoType: values.cargoType,
              congestion: this.stats().congestionRate
            })
          });
          if (pricingRes.ok) {
            this.calculatedPricing.set(await pricingRes.json());
          }
        }
      }

      // 2. Multimodal Comparison
      const multiRes = await fetch('/api/rail/compare-multimodal', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fromStationId: values.fromStationId,
          toStationId: values.toStationId,
          weight: values.weight
        })
      });
      if (multiRes.ok) {
        this.multimodalComparison.set(await multiRes.json());
      }
    } catch (err) {
      console.error('Calculation failed', err);
    } finally {
      this.isCalculatingRoutes.set(false);
    }
  }

  // Create a Custom Order from Form
  public async onCreateOrder() {
    if (this.orderForm.invalid) return;
    this.isCreatingOrder.set(true);

    const values = this.orderForm.value;
    try {
      const res = await fetch('/api/rail/create-order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(values)
      });
      if (res.ok) {
        this.orderForm.patchValue({ customerName: '' });
        this.fetchStatus();
        this.setTab('orders');
      }
    } catch (err) {
      console.error('Order creation failed', err);
    } finally {
      this.isCreatingOrder.set(false);
    }
  }

  // Manual step/tick simulation
  public async onManualTick() {
    try {
      const res = await fetch('/api/rail/tick', { method: 'POST' });
      if (res.ok) {
        this.fetchStatus();
      }
    } catch (err) {
      console.error('Manual tick failed', err);
    }
  }

  // ==========================================
  // 河钢集团 10000吨钢材主流程演示控制机
  // ==========================================
  public async advanceSteelStep() {
    const current = this.steelStep();
    if (current === 0) {
      // Step 1: Establish Demand & Calculate candidate routes
      this.steelStep.set(1);
      try {
        const routeRes = await fetch('/api/rail/route-query', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            fromStationId: 'ST-TAIYUAN',
            toStationId: 'ST-SHANGHAI',
            weight: 10000,
            cargoType: '钢材'
          })
        });
        if (routeRes.ok) {
          this.steelRoutes.set(await routeRes.json());
        }
      } catch (err) {
        console.error(err);
      }
    } else if (current === 1) {
      // Step 2: Trigger creation of order on server, wagon matchmaking & train consist generated
      this.steelStep.set(2);
      try {
        const res = await fetch('/api/rail/trigger-steel-workflow', { method: 'POST' });
        if (res.ok) {
          const data = await res.json();
          this.steelOrder.set(data.order);
          this.fetchStatus();
        }
      } catch (err) {
        console.error(err);
      }
    } else if (current === 2) {
      // Step 3: Train departs
      this.steelStep.set(3);
      this.fetchStatus();
    } else if (current === 3) {
      // Step 4: Simulate Congestion / Blockage
      this.steelStep.set(4);
      // Tweak the active steel train on client to look delayed and recalculate alternative
      const trainList = this.activeTrains();
      const steelTrain = trainList.find(t => t.trainNumber.includes('钢材专列'));
      if (steelTrain) {
        steelTrain.status = '异常中转';
        steelTrain.isCongested = true;
        this.selectedTrain.set(steelTrain);
      }
    } else if (current === 4) {
      // Step 5: Overcome and continue running to destination
      this.steelStep.set(5);
      const trainList = this.activeTrains();
      const steelTrain = trainList.find(t => t.trainNumber.includes('钢材专列'));
      if (steelTrain) {
        steelTrain.status = '在途';
        steelTrain.isCongested = false;
        steelTrain.progressPercent = 100; // instant arrival
        this.selectedTrain.set(steelTrain);
      }
      this.onManualTick(); // force arrival state change on server
    } else if (current === 5) {
      // Step 6: Settlement & Profit Analysis
      this.steelStep.set(6);
      this.fetchStatus();
    } else if (current === 6) {
      // Reset
      this.steelStep.set(0);
      this.steelOrder.set(null);
      this.steelRoutes.set(null);
    }
  }

  // ==========================================
  // Gemini AI Assistant Console
  // ==========================================
  public async onSendMessage() {
    if (this.chatForm.invalid || this.chatLoading()) return;

    const query = this.chatForm.value.message;
    this.chatHistory.update(history => [...history, { role: 'user', text: query }]);
    this.chatForm.reset();
    this.chatLoading.set(true);

    try {
      const res = await fetch('/api/rail/gemini-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: query })
      });
      if (res.ok) {
        const data = await res.json();
        this.chatHistory.update(history => [...history, { role: 'assistant', text: data.text }]);
      } else {
        this.chatHistory.update(history => [...history, { role: 'assistant', text: '抱歉，智能控制塔数据中心接口暂时响应超时，请重试。' }]);
      }
    } catch (err) {
      console.error(err);
      this.chatHistory.update(history => [...history, { role: 'assistant', text: '请求发生网络错误，请核实系统连接状态。' }]);
    } finally {
      this.chatLoading.set(false);
    }
  }

  // Quick prompt triggers in chat
  public applyQuickPrompt(promptText: string) {
    this.chatForm.patchValue({ message: promptText });
  }

  public getStationName(id: string): string {
    const s = this.stations().find(st => st.id === id);
    return s ? s.name : id;
  }

  public getStation(id: string): Station | undefined {
    return this.stations().find(st => st.id === id);
  }

  // Helpers for Angular HTML templates
  public Math = Math;

  public isNumber(val: unknown): boolean {
    return typeof val === 'number';
  }
}
