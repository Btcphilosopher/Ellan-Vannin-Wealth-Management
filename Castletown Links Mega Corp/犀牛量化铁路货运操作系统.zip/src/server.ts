import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';
import { RailEngine, Order, Waybill } from './rail-engine.js';
import { GoogleGenAI } from '@google/genai';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json());

const angularApp = new AngularNodeAppEngine();
const engine = new RailEngine();

// Periodic tick to simulate trains moving over segments (dynamic digital twin)
setInterval(() => {
  engine.tick();
}, 4000);

/**
 * Express Rest API endpoints
 */

// Get global stats, active trains, and recent logs
app.get('/api/rail/status', (req, res) => {
  res.json({
    stats: engine.stats,
    logs: engine.logs,
    activeTrainsCount: engine.activeTrains.length,
    ordersCount: engine.orders.length,
    waybillsCount: engine.waybills.length,
    locomotivesCount: engine.locomotives.length,
    stationsCount: engine.stations.length,
    sectionsCount: engine.sections.length
  });
});

// Get core stations list
app.get('/api/rail/stations', (req, res) => {
  // Return first 50 stations to prevent sending huge payloads to client, keeping it very high performance
  res.json(engine.stations.slice(0, 50));
});

// Get sections list
app.get('/api/rail/sections', (req, res) => {
  res.json(engine.sections.slice(0, 100));
});

// Get active trains
app.get('/api/rail/active-trains', (req, res) => {
  res.json(engine.activeTrains);
});

// Get orders list
app.get('/api/rail/orders', (req, res) => {
  res.json(engine.orders);
});

// Get waybills list
app.get('/api/rail/waybills', (req, res) => {
  res.json(engine.waybills);
});

// Get locomotives list
app.get('/api/rail/locomotives', (req, res) => {
  res.json(engine.locomotives);
});

// Trigger a single-tick manually
app.post('/api/rail/tick', (req, res) => {
  engine.tick();
  res.json({ success: true, logs: engine.logs.slice(0, 5) });
});

// Calculate route options (Dijkstra paths)
app.post('/api/rail/route-query', (req, res) => {
  const { fromStationId, toStationId, weight, cargoType } = req.body;
  if (!fromStationId || !toStationId) {
    return res.status(400).json({ error: '起点与终点站ID不能为空' });
  }
  const routes = engine.calculateRoutes(fromStationId, toStationId, weight || 1000, cargoType || '普通货物');
  return res.json(routes);
});

// Get dynamic pricing calculations
app.post('/api/rail/dynamic-price', (req, res) => {
  const { distance, weight, cargoType, congestion } = req.body;
  const pricing = engine.calculateDynamicPrice(
    distance || 500,
    weight || 1000,
    cargoType || '普通货物',
    congestion || 0.12
  );
  res.json(pricing);
});

// Compare with alternative modes of transport (multimodal logic)
app.post('/api/rail/compare-multimodal', (req, res) => {
  const { fromStationId, toStationId, weight } = req.body;
  const comparison = engine.compareMultimodal(fromStationId, toStationId, weight || 1000);
  res.json(comparison);
});

// Trigger the complete river-to-sea / steel freight workflow (河钢集团 10000吨钢材主流程)
app.post('/api/rail/trigger-steel-workflow', (req, res) => {
  try {
    const order = engine.createSteelShipmentWorkflow();
    res.json({ success: true, order });
  } catch (err) {
    const error = err as Error;
    res.status(500).json({ error: '流程创建失败', details: error.message });
  }
});

// Create a custom simulated order
app.post('/api/rail/create-order', (req, res) => {
  const { customerName, cargoType, weight, fromStationId, toStationId, agreedPrice } = req.body;
  
  const fromSt = engine.stations.find(s => s.id === fromStationId);
  const toSt = engine.stations.find(s => s.id === toStationId);
  if (!fromSt || !toSt) {
    return res.status(400).json({ error: '无效的起点或终点货站ID' });
  }

  const routes = engine.calculateRoutes(fromStationId, toStationId, weight || 1000, cargoType);
  const route = routes[0];
  const finalPrice = agreedPrice || Math.round(route.cost * 1.15);

  const orderId = `ORD-2026-${Math.floor(Math.random() * 90000 + 10000)}`;
  const newOrder: Order = {
    id: orderId,
    customerName: customerName || '匿名托运人',
    cargoType: cargoType || '普通货物',
    weight: weight || 1000,
    fromStationId,
    toStationId,
    requestDate: '2026-09-15',
    deliveryDate: '2026-09-18',
    status: '已确认',
    selectedRouteId: 0,
    agreedPrice: finalPrice,
    totalCost: route.cost,
    profit: finalPrice - route.cost,
    createdTime: Date.now()
  };

  engine.orders.unshift(newOrder);

  // Auto-generate waybill
  const neededWagons = Math.ceil(weight / 70);
  const waybill: Waybill = {
    id: `WB-2026-${Math.floor(Math.random() * 90000 + 10000)}`,
    orderId: orderId,
    shipper: newOrder.customerName,
    consignee: `${newOrder.customerName}分公司`,
    cargoName: newOrder.cargoType,
    weight: newOrder.weight,
    fromStationId,
    toStationId,
    status: '受理',
    wagonIds: Array.from({ length: neededWagons }, (_, k) => `WAGON-${65000 + k}`)
  };
  engine.waybills.unshift(waybill);

  engine.log('订单', `新建货运订单 ${orderId}，客户：${newOrder.customerName}，品名：${newOrder.cargoType}，重量：${weight}吨。`);

  return res.json({ success: true, order: newOrder, waybill });
});

// Server-side AI Assistant API Route grounded in system data
app.post('/api/rail/gemini-chat', async (req, res) => {
  const { prompt } = req.body;
  if (!prompt) {
    return res.status(400).json({ error: '缺少 prompt 提问内容' });
  }

  try {
    const currentStatsContext = {
      activeOrdersCount: engine.orders.length,
      activeTrainsCount: engine.activeTrains.length,
      delayedTrainsCount: engine.activeTrains.filter(t => t.status === '晚点').length,
      congestedTrainsCount: engine.activeTrains.filter(t => t.isCongested).length,
      totalWagonsPool: 50000,
      totalLocomotives: engine.locomotives.length,
      idleLocomotivesCount: engine.locomotives.filter(l => l.status === '空闲').length,
      todayVolumeTons: engine.stats.todayVolume,
      todayDepartures: engine.stats.todayDepartures,
      todayArrivals: engine.stats.todayArrivals,
      lowestProfitOrder: engine.orders.length > 0 ? [...engine.orders].sort((a,b) => a.profit - b.profit)[0] : null,
      topOrders: engine.orders.slice(0, 5).map(o => ({ id: o.id, customer: o.customerName, cargo: o.cargoType, profit: o.profit, status: o.status })),
      recentLogs: engine.logs.slice(0, 8).map(l => `[${l.timestamp}] ${l.type}: ${l.message}`)
    };

    const apiKey = process.env['GEMINI_API_KEY'];
    if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
      return res.json({
        text: `【模拟智能控制中心助理】您的 GEMINI_API_KEY 尚未在 secrets 面板中配置。
以下是基于系统当前的**统一真实状态源**为您执行的精确本地数据分析：

* **今日实绩**：今日累计货运发运量 **${currentStatsContext.todayVolumeTons.toLocaleString()} 吨**，新发列车 **${currentStatsContext.todayDepartures} 列**，正点到达 **${currentStatsContext.todayArrivals} 列**。
* **路网压力**：目前运行中的班列共 **${currentStatsContext.activeTrainsCount} 列**，其中有 **${currentStatsContext.congestedTrainsCount} 列** 处于高拥堵路段。
* **经营效益**：系统中最低利润的订单是：${currentStatsContext.lowestProfitOrder ? `ID ${currentStatsContext.lowestProfitOrder.id} (${currentStatsContext.lowestProfitOrder.customerName}，品名：${currentStatsContext.lowestProfitOrder.cargoType}，当前毛利润: ${currentStatsContext.lowestProfitOrder.profit.toLocaleString()} 元)` : '暂无'}。
* **运力池储备**：全路总共有 50,000 辆货车调配。可用内燃及电力机车数量为 **${currentStatsContext.idleLocomotivesCount} / ${currentStatsContext.totalLocomotives} 台**。

请在“Settings > Secrets”中配置 \`GEMINI_API_KEY\` 开启全功能大语言模型智慧决策。`
      });
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build'
        }
      }
    });

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: `你是一个部署在中国铁路货运智能操作系统（犀牛量化·铁路货运操作系统）控制中心的AI助理和高级决策系统。

当前系统真实的指标、经营数据和运行状态汇总如下：
${JSON.stringify(currentStatsContext, null, 2)}

请根据上述真实的系统状态指标数据，专业、清晰、富有条理地回答用户的提问。
回答准则：
1. 必须完全使用简体中文回答，语气克制、严谨、符合企业级运营规范。
2. 绝对不能编造指标数据，如果数据内没有，请坦诚说“系统数据中心未检索到此部分模拟参数”。
3. 在回答中结构化地包含：【数据来源说明】、【系统运行分析】、【最优优化建议】。
4. 提供高度专业化的中国铁路运作概念，比如车流组织、班列开行方案、吨公里单价、配车排空策略等。

用户提问：
"${prompt}"`
    });

    return res.json({ text: response.text });
  } catch (err) {
    console.error('Gemini API query failed:', err);
    const error = err as Error;
    return res.status(500).json({ error: '智能助手分析异常', details: error.message });
  }
});

// Serve static files from /browser
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);

