import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import {
  INITIAL_RELIANCE_GROUP,
  INITIAL_BUSINESSES,
  INITIAL_GRAPH_NODES,
  INITIAL_GRAPH_EDGES,
  INITIAL_GROUP_KPIS,
  INITIAL_CAPITAL_REQUESTS,
  INITIAL_INDUSTRIAL_ASSETS,
  INITIAL_NETWORK_SITES,
  INITIAL_NETWORK_INCIDENTS,
  INITIAL_RETAIL_STORES,
  INITIAL_QUICK_COMMERCE_DELIVERIES,
  INITIAL_AI_MODELS,
  INITIAL_AI_RECOMMENDATIONS,
  INITIAL_CARBON_RECORDS,
  INITIAL_AUDIT_RECORDS,
  REOS_REPOSITORY_STRUCTURE
} from './src/data/syntheticStore';
import {
  CapitalRequest,
  NetworkIncident,
  AIRecommendation,
  AuditRecord,
  SimulationScenario,
  SimulationResult
} from './src/types';

async function startServer() {
  const app = express();
  app.use(express.json());
  const PORT = 3000;

  // In-memory state initialized from synthetic store
  let group = { ...INITIAL_RELIANCE_GROUP };
  let businesses = [...INITIAL_BUSINESSES];
  let graphNodes = [...INITIAL_GRAPH_NODES];
  let graphEdges = [...INITIAL_GRAPH_EDGES];
  let groupKPIs = [...INITIAL_GROUP_KPIS];
  let capitalRequests: CapitalRequest[] = [...INITIAL_CAPITAL_REQUESTS];
  let industrialAssets = [...INITIAL_INDUSTRIAL_ASSETS];
  let networkSites = [...INITIAL_NETWORK_SITES];
  let networkIncidents: NetworkIncident[] = [...INITIAL_NETWORK_INCIDENTS];
  let retailStores = [...INITIAL_RETAIL_STORES];
  let quickDeliveries = [...INITIAL_QUICK_COMMERCE_DELIVERIES];
  let aiModels = [...INITIAL_AI_MODELS];
  let aiRecommendations: AIRecommendation[] = [...INITIAL_AI_RECOMMENDATIONS];
  let carbonRecords = [...INITIAL_CARBON_RECORDS];
  let auditTrail: AuditRecord[] = [...INITIAL_AUDIT_RECORDS];

  // Lazy initialization helper for Gemini
  let genAIClient: GoogleGenAI | null = null;
  function getGeminiClient(): GoogleGenAI | null {
    if (!genAIClient) {
      const apiKey = process.env.GEMINI_API_KEY;
      if (apiKey && apiKey !== 'MY_GEMINI_API_KEY') {
        genAIClient = new GoogleGenAI({ apiKey });
      }
    }
    return genAIClient;
  }

  // Helper to add audit record
  function recordAudit(
    userId: string,
    userName: string,
    userRole: any,
    action: string,
    targetObject: string,
    beforeState: string,
    afterState: string,
    reason: string
  ) {
    const newAudit: AuditRecord = {
      auditId: `AUD-${Date.now()}`,
      userId,
      userName,
      userRole,
      deviceInfo: 'REOS Enterprise Gateway v4.2',
      timestamp: new Date().toISOString(),
      ipAddress: '10.100.2.18',
      action,
      targetObject,
      beforeState,
      afterState,
      reason,
      policyValidationPassed: true,
      correlationId: `CORR-${Math.floor(Math.random() * 89999 + 10000)}`
    };
    auditTrail.unshift(newAudit);
  }

  // REST API Endpoints

  // 1. Group & Businesses
  app.get('/api/group', (req, res) => {
    res.json({
      group,
      businesses,
      notice: 'SYNTHETIC DATA | सिंथETIC डेटा - Reliance Enterprise Operating System (REOS)'
    });
  });

  // 2. KPIs
  app.get('/api/kpis', (req, res) => {
    res.json(groupKPIs);
  });

  // 3. Enterprise Graph
  app.get('/api/graph', (req, res) => {
    res.json({ nodes: graphNodes, edges: graphEdges });
  });

  // 4. Capital Allocation
  app.get('/api/capital', (req, res) => {
    res.json(capitalRequests);
  });

  app.post('/api/capital/approve', (req, res) => {
    const { requestId, approvedBy, role, reason } = req.body;
    const item = capitalRequests.find((c) => c.id === requestId);
    if (!item) {
      return res.status(404).json({ error: 'Capital request not found' });
    }
    const oldStatus = item.status;
    item.status = 'BOARD_APPROVED';
    recordAudit(
      approvedBy || 'USR-EXEC-001',
      approvedBy || 'Group Executive',
      role || 'GroupExecutive',
      'CAPITAL_ALLOCATION_APPROVE',
      `CapitalRequest #${item.id} (${item.title})`,
      oldStatus,
      'BOARD_APPROVED',
      reason || 'Board approval granted after risk model evaluation'
    );
    res.json({ success: true, updated: item });
  });

  // 5. Industrial Assets & Digital Twins
  app.get('/api/industrial/assets', (req, res) => {
    res.json(industrialAssets);
  });

  // 6. Telecom & NOC
  app.get('/api/telecom/noc', (req, res) => {
    res.json({ sites: networkSites, incidents: networkIncidents });
  });

  app.post('/api/telecom/incident/update', (req, res) => {
    const { incidentId, newStatus, engineer, reason } = req.body;
    const inc = networkIncidents.find((i) => i.incidentId === incidentId);
    if (!inc) {
      return res.status(404).json({ error: 'Incident not found' });
    }
    const oldStatus = inc.status;
    inc.status = newStatus;
    recordAudit(
      engineer || 'USR-NOC-ENGINEER',
      engineer || 'NOC Engineer',
      'NetworkEngineer',
      'INCIDENT_STATUS_CHANGE',
      `NetworkIncident #${inc.incidentId}`,
      oldStatus,
      newStatus,
      reason || 'Routine NOC triage update'
    );
    res.json({ success: true, updated: inc });
  });

  // 7. Retail & Quick Commerce
  app.get('/api/retail', (req, res) => {
    res.json({ stores: retailStores, quickCommerce: quickDeliveries });
  });

  // 8. AI & Governance
  app.get('/api/ai/recommendations', (req, res) => {
    res.json({ models: aiModels, recommendations: aiRecommendations });
  });

  app.post('/api/ai/recommendation/approve', (req, res) => {
    const { recId, approvedBy, role } = req.body;
    const rec = aiRecommendations.find((r) => r.id === recId);
    if (!rec) {
      return res.status(404).json({ error: 'Recommendation not found' });
    }
    const oldStatus = rec.status;
    rec.status = 'APPROVED';
    rec.approvedBy = approvedBy || 'Group COO';
    recordAudit(
      approvedBy || 'USR-COO',
      approvedBy || 'Group COO',
      role || 'COO',
      'AI_DECISION_HUMAN_APPROVAL',
      `AIRecommendation #${rec.id} (${rec.title})`,
      oldStatus,
      'APPROVED',
      'Human sign-off completed per AI Governance Policy 20.1'
    );
    res.json({ success: true, updated: rec });
  });

  // 9. Reliance Executive Copilot Endpoint
  app.post('/api/ai/copilot', async (req, res) => {
    const { question, language } = req.body;
    const promptText = question || 'What is happening across our industrial and digital business graph right now?';
    
    try {
      const client = getGeminiClient();
      let responseText = '';
      
      if (client) {
        // Query Gemini 2.5 Flash server-side with context
        const sysPrompt = `You are RELIANCE EXECUTIVE COPILOT in REOS (Reliance Enterprise Operating System).
You operate on synthetic enterprise data for a massive Indian conglomerate spanning O2C, Petrochemicals, New Energy Giga Complex, Jio 5G Telecom, Reliance Retail, and Cloud.
Current Group Financials: Consolidated Revenue = ₹9,84,500 Cr, EBITDA = ₹1,68,500 Cr, Active Telecom Base = 485.4M, CapEx Deployed = ₹1,25,000 Cr.
Always state clear reasoning summaries, recommended actions, confidence scores, and cite synthetic source records (e.g. GL-CONS-2026-Q2-REV, NOC-TRAFFIC-TELEMETRY-MAIN, O2C-JMN-TELEMETRY-4491).
Respond in ${language || 'English'}. Include clear synthetic data disclaimers.`;

        const response = await client.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: `${sysPrompt}\n\nExecutive Query: ${promptText}`
        });
        responseText = response.text || '';
      }
      
      if (!responseText) {
        // Fallback synthetic reasoning response
        responseText = `[RELIANCE EXECUTIVE COPILOT | सिंथेटिक डेटा Analysis]
Language Context: ${language || 'English'}

1. Executive Summary:
Across the consolidated REOS graph, group operational health is OPTIMAL at 98.2%. O2C refinery throughput at Jamnagar is running at 1.385M BPD (98.9% capacity). Jio 5G data traffic is at 412 PB/day across 480,000 active towers.

2. Source Citations:
- Source Record: GL-CONS-2026-Q2-REV (Consolidated Revenue ₹9,84,500 Cr, +14.2% YoY)
- Source Record: O2C-JMN-TELEMETRY-4491 (Jamnagar Coker Yield Predictor Twin MDL-O2C-YIELD-v3)
- Source Record: CAPEX-POOL-2026-ALLOC (₹1,25,000 Cr Deployed)

3. Confidence & Recommendation:
Confidence Score: 0.985
Recommended Action: Execute Capital Request CAP-2026-001 (50GW Jamnagar Solar Wafer Phase III) to capture green bond lower borrowing costs. Re-route 1,200 MT/day heavy naphtha to polymer cracker 2 for +₹1.8 Cr/day gross margin.`;
      }

      res.json({
        answer: responseText,
        model: 'REOS Executive Copilot (Gemini 2.5 Flash / Synthetic Logic)',
        timestamp: new Date().toISOString(),
        confidenceScore: 0.985,
        sourceCitations: ['GL-CONS-2026-Q2-REV', 'NOC-TRAFFIC-TELEMETRY-MAIN', 'O2C-JMN-TELEMETRY-4491']
      });
    } catch (err: any) {
      console.error('Copilot API error:', err);
      res.status(500).json({ error: 'Executive Copilot processing failed', details: err.message });
    }
  });

  // 10. ESG Carbon Ledger
  app.get('/api/esg/carbon', (req, res) => {
    res.json(carbonRecords);
  });

  // 11. Simulation Engine
  app.post('/api/simulation/run', (req, res) => {
    const scenario: SimulationScenario = req.body.scenario || {
      id: 'SIM-USER-1',
      name: 'Custom Scenario Shock',
      oilPriceChangePct: 20,
      gasProductionChangePct: -10,
      retailDemandChangePct: 15,
      networkTrafficMultiplier: 2.0,
      inrUsdExchangeRate: 84.50,
      solarEfficiencyDeltaPct: 2.5
    };

    // Calculate dynamic impacts based on scenario inputs
    const baseRev = group.totalCapExAllocated * 7.876; // ~984,500 Cr
    const oilImpact = (scenario.oilPriceChangePct * 0.45) * 4850;
    const retailImpact = (scenario.retailDemandChangePct * 0.35) * 3060;
    const trafficImpact = ((scenario.networkTrafficMultiplier - 1) * 0.2) * 1180;
    const fxImpact = (scenario.inrUsdExchangeRate - 84.25) * 1200;

    const projectedRevenue = Math.round(baseRev + oilImpact + retailImpact + trafficImpact + fxImpact);
    const projectedEbitda = Math.round(projectedRevenue * 0.171);
    const projectedCashImpact = Math.round(oilImpact * 0.6 + retailImpact * 0.4 - fxImpact * 0.5);

    const result: SimulationResult = {
      scenarioName: scenario.name,
      projectedRevenueCrores: projectedRevenue,
      projectedEbitdaCrores: projectedEbitda,
      projectedCashImpactCrores: projectedCashImpact,
      netCarbonImpactTons: Math.round(28400000 * (1 - scenario.solarEfficiencyDeltaPct / 100)),
      riskScoreDelta: scenario.oilPriceChangePct > 15 ? 4.8 : -2.1,
      bottlenecksIdentified: [
        scenario.networkTrafficMultiplier > 1.8 ? '5G Fiber Backhaul Congestion in Mumbai Circle' : 'Normal Traffic Load',
        scenario.oilPriceChangePct > 10 ? 'Jamnagar Coker Crude Blend Viscosity Limit' : 'Crude Supply Optimal',
        scenario.retailDemandChangePct > 12 ? 'Bhiwandi FC Dark Store Picking Capacity' : 'Supply Chain Clear'
      ]
    };

    recordAudit(
      'USR-EXEC-001',
      'Group Executive',
      'GroupExecutive',
      'SIMULATION_RUN',
      `Simulation Scenario: ${scenario.name}`,
      'BASE_CASE',
      `REV_SHOCK: ₹${projectedRevenue} Cr`,
      `Ran scenario shock oil=${scenario.oilPriceChangePct}%, traffic=${scenario.networkTrafficMultiplier}x`
    );

    res.json(result);
  });

  // 12. Audit Trail
  app.get('/api/audit', (req, res) => {
    res.json(auditTrail);
  });

  // 13. Repository Tree Explorer
  app.get('/api/repo/tree', (req, res) => {
    res.json(REOS_REPOSITORY_STRUCTURE);
  });

  // Vite middleware for dev / static for prod
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`REOS Enterprise OS Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
