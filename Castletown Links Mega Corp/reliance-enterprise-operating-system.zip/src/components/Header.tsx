import React from 'react';
import {
  ShieldAlert,
  Globe,
  DollarSign,
  UserCheck,
  Building2,
  Cpu,
  RefreshCw,
  Search,
  Activity
} from 'lucide-react';
import { RoleType, IndianLanguage } from '../types';

interface HeaderProps {
  currentRole: RoleType;
  onRoleChange: (role: RoleType) => void;
  currentLang: IndianLanguage;
  onLangChange: (lang: IndianLanguage) => void;
  displayModeLakhCrore: boolean;
  onToggleCurrencyFormat: () => void;
  activeViewTitle: string;
}

export const Header: React.FC<HeaderProps> = ({
  currentRole,
  onRoleChange,
  currentLang,
  onLangChange,
  displayModeLakhCrore,
  onToggleCurrencyFormat,
  activeViewTitle
}) => {
  return (
    <header className="bg-slate-900 border-b border-slate-800 sticky top-0 z-50 text-slate-100">
      {/* Legal & Architectural Synthetic Data Banner */}
      <div className="bg-gradient-to-r from-amber-900/90 via-orange-900/90 to-amber-900/90 border-b border-amber-600/40 px-4 py-1.5 flex items-center justify-between text-xs font-semibold text-amber-100">
        <div className="flex items-center space-x-2">
          <ShieldAlert className="w-4 h-4 text-amber-400 animate-pulse" />
          <span>SYNTHETIC DATA | सिंथेटिक डेटा — REOS Reference Architecture</span>
          <span className="hidden md:inline text-amber-300/80 font-normal">
            (Not Reliance Industries Limited internal software • All operational metrics & topology are synthetic)
          </span>
        </div>
        <div className="flex items-center space-x-3 text-[11px]">
          <span className="px-2 py-0.5 rounded bg-amber-950/60 border border-amber-700/50 text-amber-300">
            Node: IN-WEST-JAMNAGAR-01
          </span>
          <span className="text-emerald-400 flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            LIVE GRAPH
          </span>
        </div>
      </div>

      {/* Main Top Header Bar */}
      <div className="px-6 py-3 flex items-center justify-between flex-wrap gap-4">
        {/* Brand & Active View Title */}
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-600 via-indigo-600 to-amber-600 p-0.5 shadow-lg shadow-indigo-900/20">
              <div className="w-full h-full bg-slate-950 rounded-[7px] flex items-center justify-center font-bold text-lg text-amber-400 tracking-wider">
                REOS
              </div>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-base font-bold text-slate-100 tracking-wide font-mono">
                  RELIANCE ENTERPRISE OPERATING SYSTEM
                </h1>
                <span className="px-1.5 py-0.5 text-[10px] font-mono bg-blue-950 text-blue-400 border border-blue-800 rounded">
                  v4.2-PROD
                </span>
              </div>
              <p className="text-xs text-slate-400 flex items-center gap-2">
                <span>Conglomerate Operating System</span>
                <span>•</span>
                <span className="text-amber-400/90 font-medium">{activeViewTitle}</span>
              </p>
            </div>
          </div>
        </div>

        {/* Global Controls: Role Selector, Language, Currency Display */}
        <div className="flex items-center space-x-3 text-xs">
          {/* Currency Display Format Toggle */}
          <button
            onClick={onToggleCurrencyFormat}
            className="flex items-center space-x-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-md transition text-slate-200"
            title="Toggle between Indian Lakh/Crore (₹1,25,000 Cr) and Full Numerical representation"
          >
            <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
            <span>Format: {displayModeLakhCrore ? 'Lakh / Crore (₹)' : 'Numeric Standard'}</span>
          </button>

          {/* Indian Language Selector */}
          <div className="flex items-center space-x-1.5 bg-slate-800 border border-slate-700 rounded-md px-2.5 py-1">
            <Globe className="w-3.5 h-3.5 text-blue-400" />
            <select
              value={currentLang}
              onChange={(e) => onLangChange(e.target.value as IndianLanguage)}
              className="bg-transparent text-slate-200 outline-none cursor-pointer font-medium"
            >
              <option value="English" className="bg-slate-900 text-slate-200">English</option>
              <option value="Hindi" className="bg-slate-900 text-slate-200">Hindi (हिंदी)</option>
              <option value="Tamil" className="bg-slate-900 text-slate-200">Tamil (தமிழ்)</option>
              <option value="Telugu" className="bg-slate-900 text-slate-200">Telugu (తెలుగు)</option>
              <option value="Bengali" className="bg-slate-900 text-slate-200">Bengali (বাংলা)</option>
              <option value="Marathi" className="bg-slate-900 text-slate-200">Marathi (मराठी)</option>
              <option value="Gujarati" className="bg-slate-900 text-slate-200">Gujarati (ગુજરાતી)</option>
              <option value="Kannada" className="bg-slate-900 text-slate-200">Kannada (ಕನ್ನಡ)</option>
              <option value="Malayalam" className="bg-slate-900 text-slate-200">Malayalam (മലയാളം)</option>
              <option value="Punjabi" className="bg-slate-900 text-slate-200">Punjabi (ਪੰਜਾਬੀ)</option>
            </select>
          </div>

          {/* Enterprise Role Model Selector */}
          <div className="flex items-center space-x-1.5 bg-slate-800 border border-slate-700 rounded-md px-2.5 py-1">
            <UserCheck className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-slate-400 font-mono text-[11px]">Role:</span>
            <select
              value={currentRole}
              onChange={(e) => onRoleChange(e.target.value as RoleType)}
              className="bg-transparent text-amber-300 outline-none cursor-pointer font-semibold font-mono"
            >
              <option value="GroupExecutive" className="bg-slate-900">Group Executive (Chairman)</option>
              <option value="CFO" className="bg-slate-900">Group CFO</option>
              <option value="COO" className="bg-slate-900">Group COO</option>
              <option value="CTO" className="bg-slate-900">Group CTO</option>
              <option value="PlantManager" className="bg-slate-900">Jamnagar Plant Manager</option>
              <option value="RefineryManager" className="bg-slate-900">Refinery O2C Director</option>
              <option value="NetworkEngineer" className="bg-slate-900">Jio NOC Lead Engineer</option>
              <option value="RetailManager" className="bg-slate-900">Retail Supply Chain VP</option>
              <option value="SecurityOfficer" className="bg-slate-900">Chief Security Officer</option>
            </select>
          </div>
        </div>
      </div>
    </header>
  );
};
